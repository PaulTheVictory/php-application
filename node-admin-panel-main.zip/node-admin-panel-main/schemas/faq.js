var FAQSCHEMA = {
    question: String,
    answer: String,
    status: Boolean
};

module.exports = FAQSCHEMA;
module.exports = {
    url: 'mongodb://localhost:27017/flipkart',
    hostname: "localhost",
    port: "5000"
}
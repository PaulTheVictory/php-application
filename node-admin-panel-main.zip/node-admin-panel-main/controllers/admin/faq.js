const express = require('express');
const Router = express.Router();
const DB = require('../../models/db');

const project = {
    createdAt: 0,
    updatedAt: 0,
}
Router.get('/getFaq', function (req, res) {
    DB.GetDocument('faqs', {}, project, {}, function (err, result) {
        if (err) {
            res.status(400).end();
        } else {
            return res.status(200).json(result);
        }
    });
});

Router.post('/addFaq', function (req, res) {
    const formData = {
        question: req.body.question,
        answer: req.body.answer,
        status: req.body.status ? req.body.status : 1,
    }

    DB.InsertDocument('faqs', formData, function (err, result) {
        if (err) {
            res.status(400).end();
        } else {
            res.statusMessage = "FAQ created successfully";
            return res.status(201).json(result);
        }
    });
});

Router.post('/editFaq/:id', function (req, res) {
    const formData = {
        question: req.body.question,
        answer: req.body.answer,
        status: req.body.status,
    }
    DB.FindUpdateDocument('faqs', { _id: req.params.id }, formData, function (err, result) {
        if (err) {
            res.status(400).end();
        } else {
            res.statusMessage = "FAQ updated successfully";
            return res.status(200).json(result);
        }
    });
});

Router.post('/deleteFaq/:id', function (req, res) {
    DB.DeleteDocument('faqs', { _id: req.params.id }, function (err, result) {
        if (err) {
            res.status(400).end();
        } else {
            res.statusMessage = "FAQ deleted successfully";
            return res.status(200).end();
        }
    });
});

Router.get('/viewFaq/:id', function (req, res) {
    DB.GetOneDocument('faqs', { _id: req.params.id }, project, {}, function (err, result) {
        if (err) {
            res.status(400).end();
        } else {
            return res.status(200).json(result);
        }
    });
});


module.exports = Router;
const BaseUrl = '/api/v1/';
module.exports = function (app) {
    app.use(BaseUrl + "faq", require("../controllers/admin/faq"));
}
const mongoose = require('mongoose');

// importing schemas to create model
const importedFaqSchema = require('../schemas/faq');

// Creating schema
const FaqSchema = mongoose.Schema(importedFaqSchema, { timestamps: true, versionKey: false });

// Creating models
const FaqModel = mongoose.model('faqs', FaqSchema);

module.exports = {
    faqs: FaqModel,
}

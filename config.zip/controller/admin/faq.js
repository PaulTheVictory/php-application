const express = require('express');
const Faq = require('../../models/Faq');

const Router = express.Router();
const Response = require("../../utils/response");
const asyncHandler = require('express-async-handler');
const ValidateMongoId = require('../../utils/ValidateId');


const project = {
    createdAt: 0,
    updatedAt: 0,
}
Router.get('/getFaq', asyncHandler( async  (req, res)=> {
     try{
         let AllFaqData= await Faq.find()
         return Response.success( res, 200, true,"Get Details Successfully",AllFaqData);
     }
      catch(err){
         throw new Error(err)
      }

    //middleware 1st =>product access=> optionload 1,2,3,4,5
    
 
}));

Router.post('/addFaq', asyncHandler (  async  (req, res)=> {
     try{
         let addFaq= await Faq.create(req.body)
         return Response.success( res, 200, true,"Data Added Successfully",addFaq);

     }
      catch(err){
         throw new Error(err)
      }

}));


Router.put('/editFaq/:id', asyncHandler( async (req, res)=> {
      const {id}=req?.params
      ValidateMongoId(id)
    try{
        let edidFaq= await Faq.findByIdAndUpdate(id,req.body,{new:true})
        return Response.success( res, 200, true,"Data Updated Successfully",edidFaq);

    }
     catch(err){
        throw new Error(err)
     }


}));

Router.delete('/deleteFaq/:id', asyncHandler( async  (req, res)=> {
    const {id}=req?.params
    ValidateMongoId(id)
    try{
        let deleteFaq= await Faq.findByIdAndDelete(id)
        console.log(deleteFaq)
        if(!deleteFaq) throw new Error(`Resource Not Found this id : ${id}`)
        return Response.success( res, 200, true,"Data Deleted Successfully");

    }
     catch(err){
        throw new Error(err)
     }
   
}));

Router.get('/viewFaq/:id',asyncHandler( async (req, res,)=> {
    const {id}=req?.params
    ValidateMongoId(id)
    try{
        let viewFaq= await Faq.findById(id)
         if(!viewFaq) throw new Error(`Resource Not Found this id : ${id}`)
        return Response.success( res, 200, true,"Get Detail Successfully",viewFaq);

    }
     catch(err){
        throw new Error(err)
     }
   
}));


module.exports = Router;
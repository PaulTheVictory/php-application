const express = require('express');
const Tax = require('../../models/Tax');

const Router = express.Router();
const Response = require("../../utils/response");
const asyncHandler = require('express-async-handler');
const ValidateMongoId = require('../../utils/ValidateId');


const project = {
    createdAt: 0,
    updatedAt: 0,
}
Router.get('/getTax', asyncHandler( async  (req, res)=> {
     try{
         let AllTaxData= await Tax.find()
         return Response.success( res, 200, true,"Get Details Successfully",AllTaxData);
     }
      catch(err){
         throw new Error(err)
      }

    //middleware 1st =>product access=> optionload 1,2,3,4,5
    
 
}));

Router.post('/addTax', asyncHandler (  async  (req, res)=> {
     try{
         let addTax= await Tax.create(req.body)
         return Response.success( res, 200, true,"Data Added Successfully",addTax);

     }
      catch(err){
         throw new Error(err)
      }

}));


Router.put('/editTax/:id', asyncHandler( async (req, res)=> {
      const {id}=req?.params
      ValidateMongoId(id)
    try{
        let edidTax= await Tax.findByIdAndUpdate(id,req.body,{new:true})
        return Response.success( res, 200, true,"Data Updated Successfully");

    }
     catch(err){
        throw new Error(err)
     }


}));

Router.delete('/deleteTax/:id', asyncHandler( async  (req, res)=> {
    const {id}=req?.params
    ValidateMongoId(id)
    try{
        let deleteTax= await Tax.findByIdAndDelete(id)
        console.log(deleteTax)
        if(!deleteTax) throw new Error(`Resource Not Found this id : ${id}`)
        return Response.success( res, 200, true,"Data Deleted Successfully");

    }
     catch(err){
        throw new Error(err)
     }
   
}));

Router.get('/viewTax/:id',asyncHandler( async (req, res,)=> {
    const {id}=req?.params
    ValidateMongoId(id)
    try{
        let viewTax= await Tax.findById(id)
         if(!viewTax) throw new Error(`Resource Not Found this id : ${id}`)
        return Response.success( res, 200, true,"Get Detail Successfully",viewTax);

    }
     catch(err){
        throw new Error(err)
     }
   
}));


module.exports = Router;
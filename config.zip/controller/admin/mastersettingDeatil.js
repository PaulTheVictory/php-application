const express = require('express');
const MasterSettingDetail = require('../../models/MasterSettingDetail');

const Router = express.Router();
const Response = require("../../utils/response");
const asyncHandler = require('express-async-handler');
const ValidateMongoId = require('../../utils/ValidateId');


const project = {
    createdAt: 0,
    updatedAt: 0,
}
Router.get('/getMasterSettingDetail', asyncHandler( async  (req, res)=> {
     try{
         let AllMasterSettingDetailData= await MasterSettingDetail.find()
         return Response.success( res, 200, true,"Get Details Successfully",AllMasterSettingDetailData);
     }
      catch(err){
         throw new Error(err)
      }

    //middleware 1st =>product access=> optionload 1,2,3,4,5
    
 
}));

Router.post('/addMasterSettingDetail', asyncHandler (  async  (req, res)=> {
     try{
         let addMasterSettingDetail= await MasterSettingDetail.create(req.body)
         return Response.success( res, 200, true,"Data Added Successfully",addMasterSettingDetail);

     }
      catch(err){
         throw new Error(err)
      }

}));


Router.put('/editMasterSettingDetail/:id', asyncHandler( async (req, res)=> {
      const {id}=req?.params
      ValidateMongoId(id)
    try{
        let edidMasterSettingDetail= await MasterSettingDetail.findByIdAndUpdate(id,req.body,{new:true})
        return Response.success( res, 200, true,"Data Updated Successfully",edidMasterSettingDetail);

    }
     catch(err){
        throw new Error(err)
     }


}));

Router.delete('/deleteMasterSettingDetail/:id', asyncHandler( async  (req, res)=> {
    const {id}=req?.params
    ValidateMongoId(id)
    try{
        let deleteMasterSettingDetail= await MasterSettingDetail.findByIdAndDelete(id)
        console.log(deleteMasterSettingDetail)
        if(!deleteMasterSettingDetail) throw new Error(`Resource Not Found this id : ${id}`)
        return Response.success( res, 200, true,"Data Deleted Successfully");

    }
     catch(err){
        throw new Error(err)
     }
   
}));

Router.get('/viewMasterSettingDetail/:id',asyncHandler( async (req, res,)=> {
    const {id}=req?.params
    ValidateMongoId(id)
    try{
        let viewMasterSettingDetail= await MasterSettingDetail.findById(id)
         if(!viewMasterSettingDetail) throw new Error(`Resource Not Found this id : ${id}`)
        return Response.success( res, 200, true,"Get Detail Successfully",viewMasterSettingDetail);

    }
     catch(err){
        throw new Error(err)
     }
   
}));


module.exports = Router;
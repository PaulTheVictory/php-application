const mongoose = require("mongoose");
const bcrypt = require("bcrypt");
var Schema = mongoose.Schema;

var OfferSchema = new mongoose.Schema(
   {
    offer_title: {
        type: String,
      },
      offer_valid_from: {
        type: Date,
      },
      offer_valid_to: {
        type: Date,
      },
      offer: {
        type: String,
      },
      offer_rules: {
        type: Boolean,
      },
      status: {
        type: Boolean,
        default:true
      },
    done_by:{ type: Schema.Types.ObjectId, ref: "master-users" },
       
   }
   
   ,{
    timestamps: true,
    versionKey: false,
  }
)




module.exports = mongoose.model("Offer",OfferSchema );
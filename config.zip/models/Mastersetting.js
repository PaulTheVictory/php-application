const mongoose = require("mongoose");
var Schema = mongoose.Schema;



var MastersettingSchema = new mongoose.Schema(
   {
    name: { type: String, required: true, },

    details_available: {
      type: Boolean,
    },
    mode: {
      type: String,
      required:true,
      enum:['brand','category','speceification']
    },
    user_id: { type: Schema.Types.ObjectId, ref: "master-users" },
    parent_id: { type: Schema.Types.ObjectId, ref: "mastersettings" },
    company_code: { type: Schema.Types.ObjectId, ref: "master-users" },
    createddatetime: { type: Date, default: Date.now },
    status: {
      type: Boolean,
      default: true,
    },
    done_by:{ type: Schema.Types.ObjectId, ref: "master-users" },
   }
   

);




module.exports = mongoose.model("Mastersetting",MastersettingSchema );
const mongoose = require("mongoose");
const bcrypt = require("bcrypt");
var Schema = mongoose.Schema;

var TaxSchema = new mongoose.Schema(
   {
    company_code: { type: Schema.Types.ObjectId, ref: "master-users" },
    hsn_code: {
      type: Number,
      required:true
    },
     tax_name:{
       type:String
     },
    tax_percentage: {
      type: Number,
      required:true
    },
    status: {
      type: Boolean,
    },
    doneby:{ type: Schema.Types.ObjectId, ref: "master-users" }
   }
   
   ,{
    timestamps: true,
    versionKey: false,
  }
)




module.exports = mongoose.model("Tax",TaxSchema );
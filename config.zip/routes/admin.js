const express = require('express');
const { createAdmin,loginAdmin,logoutAdmin ,GetUser} = require('../controller/adminCtrl');
const router = express.Router();
const { authAdmin } = require('../middlewares/authMiddlewares');
router.post('/register', createAdmin);
router.post("/login", loginAdmin);
router.get('/getUser',GetUser)
router.put("/logout", authAdmin, logoutAdmin);





module.exports = router;

<?php
$title = 'Rooms | CJ Pallazzio';
$description = "";
$keyword = "";
$banner_text = "Executive Room";
include('includes/header.php');
?>


<!--inner_banner_section-->

<section class="inner_banner_section">
  <img src="./assets/images/banner/inner.jpg" alt="Banner">
  <div class="inner_banner_heading">
    <h1><?= $banner_text; ?></h1>
  </div>
</section>

<!--inner_banner_section-->



<!--single_room_section-->

<section class="single_room_section">
  <div class="wrapper">
    <div class="single_room_align">
      <div class="single_room_left">
        <div class="single_gallery">
          <div class="single_gallery_top">
            <div class="swiper-wrapper">
              <div class="swiper-slide">
                <a data-fancybox="singleroom" data-src="./assets/images/r1.jpg" data-caption="Executive Room">
                  <img src="./assets/images/r1.jpg" alt="Executive Room">
                </a>
              </div>
              <div class="swiper-slide">
                <a data-fancybox="singleroom" data-src="./assets/images/r2.jpg" data-caption="Executive Room">
                  <img src="./assets/images/r2.jpg" alt="Executive Room">
                </a>
              </div>
              <div class="swiper-slide">
                <a data-fancybox="singleroom" data-src="./assets/images/r3.jpg" data-caption="Executive Room">
                  <img src="./assets/images/r3.jpg" alt="Executive Room">
                </a>
              </div>
              <div class="swiper-slide">
                <a data-fancybox="singleroom" data-src="./assets/images/r4.jpg" data-caption="Executive Room">
                  <img src="./assets/images/r4.jpg" alt="Executive Room">
                </a>
              </div>
              <div class="swiper-slide">
                <a data-fancybox="singleroom" data-src="./assets/images/r5.jpg" data-caption="Executive Room">
                  <img src="./assets/images/r5.jpg" alt="Executive Room">
                </a>
              </div>
            </div>
            <div class="single_gallery_top_prev btn_slide"></div>
            <div class="single_gallery_top_next btn_slide"></div>
          </div>
          <div class="single_gallery_bottom">
            <div class="swiper-wrapper">
              <div class="swiper-slide">
                <img src="./assets/images/r1.jpg" alt="Executive Room">
              </div>
              <div class="swiper-slide">
                <img src="./assets/images/r2.jpg" alt="Executive Room">
              </div>
              <div class="swiper-slide">
                <img src="./assets/images/r3.jpg" alt="Executive Room">
              </div>
              <div class="swiper-slide">
                <img src="./assets/images/r4.jpg" alt="Executive Room">
              </div>
              <div class="swiper-slide">
                <img src="./assets/images/r5.jpg" alt="Executive Room">
              </div>
            </div>
          </div>
        </div>
        <div class="single_room_content">
          <h4>Description</h4>
          <p>The Executive Rooms are crafted in modern, comfortable furnishings and restful neutral tones. Rejuvenate after a busy day at work in irresistible bed. Rooms come with either two double beds or one king-sized bed. Spacious bathrooms are appointed with separate shower cubicle, and refreshing bath amenities-plus the vanity counter. The room tariff includes a complimentary breakfast at Saffron - Multi Cuisine Restaurant.</p>
          <hr />
          <h4>Room Facilities</h4>
          <ul class="facilities">
            <li>24 hrs Check in / Check out </li>
            <li>Complimentary Breakfast </li>
            <li>Central air-conditioning</li>
            <li>24-hours hot &amp; cold water</li>
            <li>24-hours Housekeeping</li>
            <li>Secretarial services on request </li>
            <li>Eco-friendly bath amenities</li>
            <li>Complimentary tea/coffee maker</li>
            <li>Soundproof Rooms</li>
            <li>24-hours In-room dining</li>
            <li>Digital in-room safe</li>
            <li>DVD player on request </li>
            <li>40" flat screen TV with International Entertainment and News</li>
            <li>International in-room direct dial on request</li>
            <li>Separate shower cubicle</li>
          </ul>
        </div>
      </div>
      <div class="single_room_right">
        <div class="details">
          <h4>Tariff</h4>
          <ul>
            <li><span>Single</span><span>3500</span></li>
            <li><span>Double</span><span>4000</span></li>
            <li><span>Extra person</span><span>1250</span></li>
          </ul>
          <p>Taxes as Applicable.</p>
          <p>* - Promotonal Offers.</p>
          <a href="javascript:void(0)" title="Book Now">
            <button>Book Now</button>
          </a>
        </div>
        <hr />
        <div class="category">
          <h4>Category</h4>
          <ul>
            <li>
              <span>Rooms</span>
              <span>(15)</span>
            </li>
            <li>
              <span>Banquet</span>
              <span>(20)</span>
            </li>
            <li>
              <span>Dining</span>
              <span>(40)</span>
            </li>
            <li>
              <span>Facilities</span>
              <span>(60)</span>
            </li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</section>

<!--single_room_section-->



<!--ourroom_services-->

<section class="ourroom_services inner_page">
  <div class="wrapper">
    <div class="head_text">
      <h4>Similar Rooms</h4>
      <h2>Our Luxury Rooms</h2>
    </div>
    <div class="ourroom_align">
      <div class="ourroom_box">
        <div class="ourrrom_img">
          <img src="./assets/images/s1.jpg" alt="">
        </div>
        <div class="ourroom_content">
          <h4>Deluxe Room</h4>
          <h5>Rs 1500<span> / per night</span></h5>
          <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod.</p>
          <div class="benifits">
            <div class="benifits_items" data-bs-toggle="tooltip" title="Mini Bar Included">
              <i class="fa fa-glass"></i>
            </div>
            <div class="benifits_items" data-bs-toggle="tooltip" title="Sauna Included">
              <i class="fa fa-bath"></i>
            </div>
            <div class="benifits_items" data-bs-toggle="tooltip" title="Wi-Fi Included">
              <i class="fa fa-wifi"></i>
            </div>
            <div class="benifits_items" data-bs-toggle="tooltip" title="Breakfast Included">
              <i class="fa fa-cutlery"></i>
            </div>
            <div class="benifits_items" data-bs-toggle="tooltip" title="Coffee Maker Included">
              <i class="fa fa-coffee"></i>
            </div>
            <div class="benifits_items" data-bs-toggle="tooltip" title="Hair Dryer Included">
              <i class="fa fa-female"></i>
            </div>
            <div class="benifits_items" data-bs-toggle="tooltip" title="Widescreen TV Included">
              <i class="fa fa-television"></i>
            </div>

          </div>
          <div class="details">
            <a href="javascript:void(0)" title="Details">
              <button>Details <i class="fa fa-long-arrow-right" aria-hidden="true"></i></button>
            </a>
          </div>
        </div>
      </div>
      <div class="ourroom_box">
        <div class="ourrrom_img">
          <img src="./assets/images/s2.jpg" alt="">
        </div>
        <div class="ourroom_content">
          <h4>Deluxe Room</h4>
          <h5>Rs 1500<span> / per night</span></h5>
          <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod.</p>
          <div class="benifits">
            <div class="benifits_items" data-bs-toggle="tooltip" title="Mini Bar Included">
              <i class="fa fa-glass"></i>
            </div>
            <div class="benifits_items" data-bs-toggle="tooltip" title="Sauna Included">
              <i class="fa fa-bath"></i>
            </div>
            <div class="benifits_items" data-bs-toggle="tooltip" title="Wi-Fi Included">
              <i class="fa fa-wifi"></i>
            </div>
            <div class="benifits_items" data-bs-toggle="tooltip" title="Breakfast Included">
              <i class="fa fa-cutlery"></i>
            </div>
            <div class="benifits_items" data-bs-toggle="tooltip" title="Coffee Maker Included">
              <i class="fa fa-coffee"></i>
            </div>
            <div class="benifits_items" data-bs-toggle="tooltip" title="Hair Dryer Included">
              <i class="fa fa-female"></i>
            </div>
            <div class="benifits_items" data-bs-toggle="tooltip" title="Widescreen TV Included">
              <i class="fa fa-television"></i>
            </div>

          </div>
          <div class="details">
            <a href="javascript:void(0)" title="Details">
              <button>Details <i class="fa fa-long-arrow-right" aria-hidden="true"></i></button>
            </a>
          </div>
        </div>
      </div>
      <div class="ourroom_box">
        <div class="ourrrom_img">
          <img src="./assets/images/s3.jpg" alt="">
        </div>
        <div class="ourroom_content">
          <h4>Deluxe Room</h4>
          <h5>Rs 1500<span> / per night</span></h5>
          <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod.</p>
          <div class="benifits">
            <div class="benifits_items" data-bs-toggle="tooltip" title="Mini Bar Included">
              <i class="fa fa-glass"></i>
            </div>
            <div class="benifits_items" data-bs-toggle="tooltip" title="Sauna Included">
              <i class="fa fa-bath"></i>
            </div>
            <div class="benifits_items" data-bs-toggle="tooltip" title="Wi-Fi Included">
              <i class="fa fa-wifi"></i>
            </div>
            <div class="benifits_items" data-bs-toggle="tooltip" title="Breakfast Included">
              <i class="fa fa-cutlery"></i>
            </div>
            <div class="benifits_items" data-bs-toggle="tooltip" title="Coffee Maker Included">
              <i class="fa fa-coffee"></i>
            </div>
            <div class="benifits_items" data-bs-toggle="tooltip" title="Hair Dryer Included">
              <i class="fa fa-female"></i>
            </div>
            <div class="benifits_items" data-bs-toggle="tooltip" title="Widescreen TV Included">
              <i class="fa fa-television"></i>
            </div>

          </div>
          <div class="details">
            <a href="javascript:void(0)" title="Details">
              <button>Details <i class="fa fa-long-arrow-right" aria-hidden="true"></i></button>
            </a>
          </div>
        </div>
      </div>
      <div class="ourroom_box">
        <div class="ourrrom_img">
          <img src="./assets/images/s4.jpg" alt="">
        </div>
        <div class="ourroom_content">
          <h4>Deluxe Room</h4>
          <h5>Rs 1500<span> / per night</span></h5>
          <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod.</p>
          <div class="benifits">
            <div class="benifits_items" data-bs-toggle="tooltip" title="Mini Bar Included">
              <i class="fa fa-glass"></i>
            </div>
            <div class="benifits_items" data-bs-toggle="tooltip" title="Sauna Included">
              <i class="fa fa-bath"></i>
            </div>
            <div class="benifits_items" data-bs-toggle="tooltip" title="Wi-Fi Included">
              <i class="fa fa-wifi"></i>
            </div>
            <div class="benifits_items" data-bs-toggle="tooltip" title="Breakfast Included">
              <i class="fa fa-cutlery"></i>
            </div>
            <div class="benifits_items" data-bs-toggle="tooltip" title="Coffee Maker Included">
              <i class="fa fa-coffee"></i>
            </div>
            <div class="benifits_items" data-bs-toggle="tooltip" title="Hair Dryer Included">
              <i class="fa fa-female"></i>
            </div>
            <div class="benifits_items" data-bs-toggle="tooltip" title="Widescreen TV Included">
              <i class="fa fa-television"></i>
            </div>

          </div>
          <div class="details">
            <a href="javascript:void(0)" title="Details">
              <button>Details <i class="fa fa-long-arrow-right" aria-hidden="true"></i></button>
            </a>
          </div>
        </div>
      </div>
      <div class="ourroom_box">
        <div class="ourrrom_img">
          <img src="./assets/images/s5.jpg" alt="">
        </div>
        <div class="ourroom_content">
          <h4>Deluxe Room</h4>
          <h5>Rs 1500<span> / per night</span></h5>
          <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod.</p>
          <div class="benifits">
            <div class="benifits_items" data-bs-toggle="tooltip" title="Mini Bar Included">
              <i class="fa fa-glass"></i>
            </div>
            <div class="benifits_items" data-bs-toggle="tooltip" title="Sauna Included">
              <i class="fa fa-bath"></i>
            </div>
            <div class="benifits_items" data-bs-toggle="tooltip" title="Wi-Fi Included">
              <i class="fa fa-wifi"></i>
            </div>
            <div class="benifits_items" data-bs-toggle="tooltip" title="Breakfast Included">
              <i class="fa fa-cutlery"></i>
            </div>
            <div class="benifits_items" data-bs-toggle="tooltip" title="Coffee Maker Included">
              <i class="fa fa-coffee"></i>
            </div>
            <div class="benifits_items" data-bs-toggle="tooltip" title="Hair Dryer Included">
              <i class="fa fa-female"></i>
            </div>
            <div class="benifits_items" data-bs-toggle="tooltip" title="Widescreen TV Included">
              <i class="fa fa-television"></i>
            </div>

          </div>
          <div class="details">
            <a href="javascript:void(0)" title="Details">
              <button>Details <i class="fa fa-long-arrow-right" aria-hidden="true"></i></button>
            </a>
          </div>
        </div>
      </div>




    </div>
  </div>
</section>

<!--ourroom_services-->








<?php

include('includes/footer.php');
?>
<?php
$title = 'Hotel';
$description = "";
$keyword = "";
include('includes/header.php');
?>

<!--slider_section-->

<section class="slider_section">
  <div class="banner">
    <div class="swiper-wrapper">
      <div class="swiper-slide">
        <div class="banner_item">
          <img src="./assets/images/banner/1.jpg" alt="" class="d_banner">
          <div class="banner_item_content">
            <div class="banner_item_content_text">
              <div class="rating">
                <i class="fa fa-star" aria-hidden="true"></i>
                <i class="fa fa-star" aria-hidden="true"></i>
                <i class="fa fa-star" aria-hidden="true"></i>
                <i class="fa fa-star" aria-hidden="true"></i>
                <i class="fa fa-star" aria-hidden="true"></i>
              </div>
              <h4>The Ultimate Luxury Experience</h4>
              <h2>Enjoy The Best <br />Moments of Life</h2>
              <div class="banner_btn">
                <button class="get_cta">Rooms & Suites</button>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="swiper-slide">
        <div class="banner_item">
          <img src="./assets/images/banner/2.jpg" alt="" class="d_banner">
          <div class="banner_item_content">
            <div class="banner_item_content_text">
              <div class="rating">
                <i class="fa fa-star" aria-hidden="true"></i>
                <i class="fa fa-star" aria-hidden="true"></i>
                <i class="fa fa-star" aria-hidden="true"></i>
                <i class="fa fa-star" aria-hidden="true"></i>
                <i class="fa fa-star" aria-hidden="true"></i>
              </div>
              <h4>The Ultimate Luxury Experience</h4>
              <h2>The Perfect Base <br /> For You</h2>
              <div class="banner_btn">
                <button class="get_cta">Rooms & Suites</button>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="swiper-slide">
        <div class="banner_item">
          <img src="./assets/images/banner/4.jpg" alt="" class="d_banner">
          <div class="banner_item_content">
            <div class="banner_item_content_text">
              <div class="rating">
                <i class="fa fa-star" aria-hidden="true"></i>
                <i class="fa fa-star" aria-hidden="true"></i>
                <i class="fa fa-star" aria-hidden="true"></i>
                <i class="fa fa-star" aria-hidden="true"></i>
                <i class="fa fa-star" aria-hidden="true"></i>
              </div>
              <h4>The Ultimate Luxury Experience</h4>
              <h2>Enjoy a Luxury <br /> Experience</h2>
              <div class="banner_btn">
                <button class="get_cta">Rooms & Suites</button>
              </div>
            </div>
          </div>
        </div>
      </div>


    </div>
  </div>
  <div class="banner_form">
    <form id="banner_form">
      <input type="text" placeholder="Check in" name="checkin" id="checkin" />
      <input type="text" placeholder="Check out" name="checkout" id="checkout" />
      <select name="adult" id="adult">
        <option value="" selected hidden>- Adult -</option>
        <option value="1">1 Adault</option>
        <option value="2">2 Adaults</option>
        <option value="3">3 Adaults</option>
        <option value="4">4 Adaults</option>
        <option value="5">5 Adaults Plus</option>
      </select>
      <select name="children" id="children">
        <option value="" selected hidden>- Children -</option>
        <option value="1">1 Child</option>
        <option value="2">2 Children</option>
        <option value="3">3 Children</option>
        <option value="4">4 Children</option>
        <option value="5">5 Children Plus</option>
      </select>
      <select name="room" id="room">
        <option value="" selected hidden>- Room -</option>
        <option value="1">1 Room</option>
        <option value="2">2 Rooms</option>
        <option value="3">3 Rooms</option>
        <option value="4">4 Rooms</option>
        <option value="5">5 Rooms Plus</option>
      </select>
      <button type="submit" name="step1" id="step1">Book Now</button>
    </form>
  </div>
  <div class="banner_cal_section">
    <div class="call_icon">
      <img src="./assets/images/call.png" alt="Call Btn">
    </div>
    <div class="call_text">
      <h6>Reservation</h6>
      <h4>+91 7094463507</h4>
    </div>
  </div>
  <div class="home_slider_pagination"></div>
</section>

<!--slider_section-->


<!--aboutus_section-->

<section class="aboutus_section">
  <div class="wrapper">
    <div class="aboutus_align">
      <div class="aboutus_left">
        <div class="head_text">
          <h4>About Us</h4>
          <h1>Welcome Our Hotels And Resorts</h1>
        </div>
        <p>CJ Pallazzio is a "Business Class Luxury" hotel offering comfort stay for it's guests, located at the Salem - Bangalore NH7 - Junction Main Road Circle, fitted with 72 Rooms, including 12 Suites, 4 Conference halls capable of accommodating more than 800 guests. The Multi Cuisine restaurant, Coffee Shop, Bar, Lounge and Rooftop barbeque at the hotel add to your comfort.</p>
        <a href="javascript:void(0)" title="Read More">
          <button>Read More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></button>
        </a>
      </div>
      <div class="aboutus_right">
        <img src="./assets/images/aboutus.jpg" alt="Welcome Our Hotels And Resorts">
      </div>
    </div>
  </div>
</section>

<!--aboutus_section-->



<!--ourroom_services-->

<section class="ourroom_services">
  <div class="wrapper">
    <div class="head_text">
      <h4>Deluxe And Luxury</h4>
      <h2>Our Luxury Rooms</h2>
    </div>
    <div class="ourroom_align">
      <div class="ourroom_box">
        <div class="ourrrom_img">
          <img src="./assets/images/s1.jpg" alt="">
        </div>
        <div class="ourroom_content">
          <h4>Deluxe Room</h4>
          <h5>Rs 1500<span> / per night</span></h5>
          <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod.</p>
          <div class="benifits">
            <div class="benifits_items" data-bs-toggle="tooltip" title="Mini Bar Included">
              <i class="fa fa-glass"></i>
            </div>
            <div class="benifits_items" data-bs-toggle="tooltip" title="Sauna Included">
              <i class="fa fa-bath"></i>
            </div>
            <div class="benifits_items" data-bs-toggle="tooltip" title="Wi-Fi Included">
              <i class="fa fa-wifi"></i>
            </div>
            <div class="benifits_items" data-bs-toggle="tooltip" title="Breakfast Included">
              <i class="fa fa-cutlery"></i>
            </div>
            <div class="benifits_items" data-bs-toggle="tooltip" title="Coffee Maker Included">
              <i class="fa fa-coffee"></i>
            </div>
            <div class="benifits_items" data-bs-toggle="tooltip" title="Hair Dryer Included">
              <i class="fa fa-female"></i>
            </div>
            <div class="benifits_items" data-bs-toggle="tooltip" title="Widescreen TV Included">
              <i class="fa fa-television"></i>
            </div>

          </div>
          <div class="details">
            <a href="javascript:void(0)" title="Details">
              <button>Details <i class="fa fa-long-arrow-right" aria-hidden="true"></i></button>
            </a>
          </div>
        </div>
      </div>
      <div class="ourroom_box">
        <div class="ourrrom_img">
          <img src="./assets/images/s2.jpg" alt="">
        </div>
        <div class="ourroom_content">
          <h4>Deluxe Room</h4>
          <h5>Rs 1500<span> / per night</span></h5>
          <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod.</p>
          <div class="benifits">
            <div class="benifits_items" data-bs-toggle="tooltip" title="Mini Bar Included">
              <i class="fa fa-glass"></i>
            </div>
            <div class="benifits_items" data-bs-toggle="tooltip" title="Sauna Included">
              <i class="fa fa-bath"></i>
            </div>
            <div class="benifits_items" data-bs-toggle="tooltip" title="Wi-Fi Included">
              <i class="fa fa-wifi"></i>
            </div>
            <div class="benifits_items" data-bs-toggle="tooltip" title="Breakfast Included">
              <i class="fa fa-cutlery"></i>
            </div>
            <div class="benifits_items" data-bs-toggle="tooltip" title="Coffee Maker Included">
              <i class="fa fa-coffee"></i>
            </div>
            <div class="benifits_items" data-bs-toggle="tooltip" title="Hair Dryer Included">
              <i class="fa fa-female"></i>
            </div>
            <div class="benifits_items" data-bs-toggle="tooltip" title="Widescreen TV Included">
              <i class="fa fa-television"></i>
            </div>

          </div>
          <div class="details">
            <a href="javascript:void(0)" title="Details">
              <button>Details <i class="fa fa-long-arrow-right" aria-hidden="true"></i></button>
            </a>
          </div>
        </div>
      </div>
      <div class="ourroom_box">
        <div class="ourrrom_img">
          <img src="./assets/images/s3.jpg" alt="">
        </div>
        <div class="ourroom_content">
          <h4>Deluxe Room</h4>
          <h5>Rs 1500<span> / per night</span></h5>
          <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod.</p>
          <div class="benifits">
            <div class="benifits_items" data-bs-toggle="tooltip" title="Mini Bar Included">
              <i class="fa fa-glass"></i>
            </div>
            <div class="benifits_items" data-bs-toggle="tooltip" title="Sauna Included">
              <i class="fa fa-bath"></i>
            </div>
            <div class="benifits_items" data-bs-toggle="tooltip" title="Wi-Fi Included">
              <i class="fa fa-wifi"></i>
            </div>
            <div class="benifits_items" data-bs-toggle="tooltip" title="Breakfast Included">
              <i class="fa fa-cutlery"></i>
            </div>
            <div class="benifits_items" data-bs-toggle="tooltip" title="Coffee Maker Included">
              <i class="fa fa-coffee"></i>
            </div>
            <div class="benifits_items" data-bs-toggle="tooltip" title="Hair Dryer Included">
              <i class="fa fa-female"></i>
            </div>
            <div class="benifits_items" data-bs-toggle="tooltip" title="Widescreen TV Included">
              <i class="fa fa-television"></i>
            </div>

          </div>
          <div class="details">
            <a href="javascript:void(0)" title="Details">
              <button>Details <i class="fa fa-long-arrow-right" aria-hidden="true"></i></button>
            </a>
          </div>
        </div>
      </div>
      <div class="ourroom_box">
        <div class="ourrrom_img">
          <img src="./assets/images/s4.jpg" alt="">
        </div>
        <div class="ourroom_content">
          <h4>Deluxe Room</h4>
          <h5>Rs 1500<span> / per night</span></h5>
          <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod.</p>
          <div class="benifits">
            <div class="benifits_items" data-bs-toggle="tooltip" title="Mini Bar Included">
              <i class="fa fa-glass"></i>
            </div>
            <div class="benifits_items" data-bs-toggle="tooltip" title="Sauna Included">
              <i class="fa fa-bath"></i>
            </div>
            <div class="benifits_items" data-bs-toggle="tooltip" title="Wi-Fi Included">
              <i class="fa fa-wifi"></i>
            </div>
            <div class="benifits_items" data-bs-toggle="tooltip" title="Breakfast Included">
              <i class="fa fa-cutlery"></i>
            </div>
            <div class="benifits_items" data-bs-toggle="tooltip" title="Coffee Maker Included">
              <i class="fa fa-coffee"></i>
            </div>
            <div class="benifits_items" data-bs-toggle="tooltip" title="Hair Dryer Included">
              <i class="fa fa-female"></i>
            </div>
            <div class="benifits_items" data-bs-toggle="tooltip" title="Widescreen TV Included">
              <i class="fa fa-television"></i>
            </div>

          </div>
          <div class="details">
            <a href="javascript:void(0)" title="Details">
              <button>Details <i class="fa fa-long-arrow-right" aria-hidden="true"></i></button>
            </a>
          </div>
        </div>
      </div>
      <div class="ourroom_box">
        <div class="ourrrom_img">
          <img src="./assets/images/s5.jpg" alt="">
        </div>
        <div class="ourroom_content">
          <h4>Deluxe Room</h4>
          <h5>Rs 1500<span> / per night</span></h5>
          <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod.</p>
          <div class="benifits">
            <div class="benifits_items" data-bs-toggle="tooltip" title="Mini Bar Included">
              <i class="fa fa-glass"></i>
            </div>
            <div class="benifits_items" data-bs-toggle="tooltip" title="Sauna Included">
              <i class="fa fa-bath"></i>
            </div>
            <div class="benifits_items" data-bs-toggle="tooltip" title="Wi-Fi Included">
              <i class="fa fa-wifi"></i>
            </div>
            <div class="benifits_items" data-bs-toggle="tooltip" title="Breakfast Included">
              <i class="fa fa-cutlery"></i>
            </div>
            <div class="benifits_items" data-bs-toggle="tooltip" title="Coffee Maker Included">
              <i class="fa fa-coffee"></i>
            </div>
            <div class="benifits_items" data-bs-toggle="tooltip" title="Hair Dryer Included">
              <i class="fa fa-female"></i>
            </div>
            <div class="benifits_items" data-bs-toggle="tooltip" title="Widescreen TV Included">
              <i class="fa fa-television"></i>
            </div>

          </div>
          <div class="details">
            <a href="javascript:void(0)" title="Details">
              <button>Details <i class="fa fa-long-arrow-right" aria-hidden="true"></i></button>
            </a>
          </div>
        </div>
      </div>
      <div class="ourroom_box">
        <div class="ourrrom_img">
          <img src="./assets/images/s6.jpg" alt="">
        </div>
        <div class="ourroom_content">
          <h4>Deluxe Room</h4>
          <h5>Rs 1500<span> / per night</span></h5>
          <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod.</p>
          <div class="benifits">
            <div class="benifits_items" data-bs-toggle="tooltip" title="Mini Bar Included">
              <i class="fa fa-glass"></i>
            </div>
            <div class="benifits_items" data-bs-toggle="tooltip" title="Sauna Included">
              <i class="fa fa-bath"></i>
            </div>
            <div class="benifits_items" data-bs-toggle="tooltip" title="Wi-Fi Included">
              <i class="fa fa-wifi"></i>
            </div>
            <div class="benifits_items" data-bs-toggle="tooltip" title="Breakfast Included">
              <i class="fa fa-cutlery"></i>
            </div>
            <div class="benifits_items" data-bs-toggle="tooltip" title="Coffee Maker Included">
              <i class="fa fa-coffee"></i>
            </div>
            <div class="benifits_items" data-bs-toggle="tooltip" title="Hair Dryer Included">
              <i class="fa fa-female"></i>
            </div>
            <div class="benifits_items" data-bs-toggle="tooltip" title="Widescreen TV Included">
              <i class="fa fa-television"></i>
            </div>

          </div>
          <div class="details">
            <a href="javascript:void(0)" title="Details">
              <button>Details <i class="fa fa-long-arrow-right" aria-hidden="true"></i></button>
            </a>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<!--ourroom_services-->


<!--extra_service-->

<section class="extra_service">
  <div class="wrapper">
    <div class="head_text">
      <h4>BEST PRICES</h4>
      <h2>Our Awesome Services</h2>
    </div>
    <div class="extra_align">
      <div class="extra_left">

        <div class="extra_main">
          <div class="extra_main_box" id="ser_1">
            <img src="./assets/images/serm1.jpg" alt="Restaurant">
          </div>

          <div class="extra_main_box" id="ser_2">
            <img src="./assets/images/serm2.jpg" alt="Spa - Beauty & Health">
          </div>

          <div class="extra_main_box" id="ser_3">
            <img src="./assets/images/serm3.jpg" alt="Conference Room">
          </div>

          <div class="extra_main_box" id="ser_4">
            <img src="./assets/images/serm4.jpg" alt="Swimming Pool">
          </div>

        </div>
      </div>

      <div class="extra_right">
        <div class="extra_thump">


          <div class="extra_thump_box">
            <a href="#ser_1" title="Restaurant">
              <div class="extra_thump_box_left">
                <img src="./assets/images/ser1.png" alt="Restaurant">
              </div>
              <div class="extra_thump_box_right">
                <h4>Restaurant</h4>
                <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh.</p>
              </div>
            </a>
          </div>


          <div class="extra_thump_box">
            <a href="#ser_2" title="Spa - Beauty & Health">
              <div class="extra_thump_box_left">
                <img src="./assets/images/ser2.png" alt="Spa - Beauty & Health">
              </div>
              <div class="extra_thump_box_right">
                <h4>Spa - Beauty & Health</h4>
                <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh.</p>
              </div>
            </a>
          </div>


          <div class="extra_thump_box">
            <a href="#ser_3" title="Conference Room">
              <div class="extra_thump_box_left">
                <img src="./assets/images/ser3.png" alt="Conference Room">
              </div>
              <div class="extra_thump_box_right">
                <h4>Conference Room</h4>
                <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh.</p>
              </div>
            </a>
          </div>


          <div class="extra_thump_box">
            <a href="#ser_4" title="Swimming Pool">
              <div class="extra_thump_box_left">
                <img src="./assets/images/ser4.png" alt="Swimming Pool">
              </div>
              <div class="extra_thump_box_right">
                <h4>Swimming Pool</h4>
                <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh.</p>
              </div>
            </a>
          </div>

        </div>

      </div>
    </div>
  </div>
  </div>
</section>




<!--extra_service-->



<!--facilities_section-->

<section class="facilities_section">
  <div class="wrapper">
    <div class="head_text">
      <h4>OUR SERVICES</h4>
      <h2>Hotel Facilities</h2>
    </div>
    <div class="facilities_align">
      <div class="facilities_box">
        <i class="fa fa-plane" aria-hidden="true"></i>
        <h4>Airport Pickup</h4>
      </div>
      <div class="facilities_box">
        <i class="fa fa-wifi"></i>
        <h4>Wi-Fi</h4>
      </div>
      <div class="facilities_box">
        <i class="fa fa-eye-slash"></i>
        <h4>Private Balcony</h4>
      </div>
      <div class="facilities_box">
        <i class="fa fa-snowflake-o"></i>
        <h4>Air Conditioner</h4>
      </div>
      <div class="facilities_box">
        <i class="fa fa-television"></i>
        <h4>Widescreen TV</h4>
      </div>
      <div class="facilities_box">
        <i class="fa-solid fa-spa"></i>
        <h4>Massage & Spa</h4>
      </div>
      <div class="facilities_box">
        <i class="fa fa-coffee"></i>
        <h4>Coffee Maker</h4>
      </div>
      <div class="facilities_box">
        <i class="fa fa-female"></i>
        <h4>Hair Dryer</h4>
      </div>
      <div class="facilities_box">
        <i class="fa fa-cutlery"></i>
        <h4>Breakfast</h4>
      </div>
      <div class="facilities_box">
        <i class="fa fa-bath"></i>
        <h4>Sauna</h4>
      </div>
      <div class="facilities_box">
        <i class="fa fa-glass"></i>
        <h4>Mini Bar</h4>
      </div>
      <div class="facilities_box">
        <i class="fa fa-mobile"></i>
        <h4>Free-to-use Smartphone</h4>
      </div>
    </div>

  </div>
</section>

<!--facilities_section-->




<!--dining_section-->

<section class="dining_section">
  <div class="wrapper">
    <div class="head_text">
      <h4>Dining</h4>
      <h2>Our Luxury Dining</h2>
    </div>
    <div class="dining_align">
      <div class="swiper-wrapper">
        <div class="swiper-slide">
          <div class="dining_box">
            <div class="dining_img">
              <img src="./assets/images/dining1.jpg" alt="">
            </div>
            <div class="dining_content">
              <h4>Saffron</h4>
              <p>The specialty multi cuisine restaurant at CJ Pallazzio serves food platters that cater to the palates of guests far and near. Be it Continental food for its international guests...</p>
              <a href="javascript:void(0)" title="Details">
                <button>Details <i class="fa fa-long-arrow-right" aria-hidden="true"></i></button>
              </a>
            </div>
          </div>
        </div>
        <div class="swiper-slide">
          <div class="dining_box">
            <div class="dining_img">
              <img src="./assets/images/dining2.jpg" alt="">
            </div>
            <div class="dining_content">
              <h4>Chicory</h4>
              <p>Whether its business over a cup coffee or beating the head over cool stuff from a range of juices and mocktails, Chicory is the perfect hangout for the young and the old...</p>
              <a href="javascript:void(0)" title="Details">
                <button>Details <i class="fa fa-long-arrow-right" aria-hidden="true"></i></button>
              </a>
            </div>
          </div>
        </div>
        <div class="swiper-slide">
          <div class="dining_box">
            <div class="dining_img">
              <img src="./assets/images/dining3.jpg" alt="">
            </div>
            <div class="dining_content">
              <h4>Starz</h4>
              <p>The night skies, the starts, the moon and food are the reasons to be here. Enjoy the luxury of fresh air and the skies with friends and family at this 'must be there' evening roof top grill...</p>
              <a href="javascript:void(0)" title="Details">
                <button>Details <i class="fa fa-long-arrow-right" aria-hidden="true"></i></button>
              </a>
            </div>
          </div>
        </div>
        <div class="swiper-slide">
          <div class="dining_box">
            <div class="dining_img">
              <img src="./assets/images/dining4.jpg" alt="">
            </div>
            <div class="dining_content">
              <h4>Flying Monk</h4>
              <p>The Flying Monk at the CJ Pallazzio appeals in spirit to one's mind: whatever your passion the potions are perfect...</p>
              <a href="javascript:void(0)" title="Details">
                <button>Details <i class="fa fa-long-arrow-right" aria-hidden="true"></i></button>
              </a>
            </div>
          </div>
        </div>
        <div class="swiper-slide">
          <div class="dining_box">
            <div class="dining_img">
              <img src="./assets/images/dining5.jpg" alt="">
            </div>
            <div class="dining_content">
              <h4>Unwind Lounge</h4>
              <p>Unwind your mind and tunes to the relaxing feel, This lounge severs selected International beverages and tit bits ...</p>
              <a href="javascript:void(0)" title="Details">
                <button>Details <i class="fa fa-long-arrow-right" aria-hidden="true"></i></button>
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="dining_slider_pagination"></div>
  </div>
</section>

<!--dining_section-->


<!--testimonials_section-->

<section class="testimonials_section">
  <div class="wrapper">
    <div class="head_text">
      <h4>Testimonials</h4>
      <h2>Our Giests Love Us</h2>
    </div>
    <div class="testimonials_align">
      <div class="testimonails_slider">
        <div class="swiper-wrapper">
          <div class="swiper-slide">
            <p>Hotel dapibus asue metus the nec feusiate eraten miss hendreri net ve ante the lemon sanleo nectan feugiat erat hendrerit necuis ve ante otel inilla duiman at finibus viverra neca the sene on satien the miss drana inc fermen norttito sit space, mus nellentesque habitan.</p>
            <img src="./assets/images/user.jpg" alt="">
            <div class="rating">
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
            </div>
            <h4>Emily Brown</h4>
            <h5>Guest review</h5>
          </div>
          <div class="swiper-slide">
            <p>Hotel dapibus asue metus the nec feusiate eraten miss hendreri net ve ante the lemon sanleo nectan feugiat erat hendrerit necuis ve ante otel inilla duiman at finibus viverra neca the sene on satien the miss drana inc fermen norttito sit space, mus nellentesque habitan.</p>
            <img src="./assets/images/user.jpg" alt="">
            <div class="rating">
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
            </div>
            <h4>Emily Brown</h4>
            <h5>Guest review</h5>
          </div>
        </div>
      </div>

    </div>
    <div class="test_slider_pagination"></div>
  </div>
</section>

<!--testimonials_section-->


<!--local_attration-->


<section class="local_attration">
  <div class="wrapper">
    <div class="head_text">
      <h4>Local Attractions</h4>
      <h2>Most Popular Tours</h2>
    </div>
    <div class="local_attration_align">
      <div class="local_attration_box">
        <div class="local_attration_img">
          <img src="./assets/images/local1.jpg" alt="">
        </div>
        <div class="local_attration_content">
          <h4>Yercaud</h4>
        </div>
      </div>
      <div class="local_attration_box">
        <div class="local_attration_img">
          <img src="./assets/images/local2.jpg" alt="">
        </div>
        <div class="local_attration_content">
          <h4>Mettur Dam</h4>
        </div>
      </div>
      <div class="local_attration_box">
        <div class="local_attration_img">
          <img src="./assets/images/local3.jpg" alt="">
        </div>
        <div class="local_attration_content">
          <h4>Kiliyur Falls</h4>
        </div>
      </div>
      <div class="local_attration_box">
        <div class="local_attration_img">
          <img src="./assets/images/local4.jpg" alt="">
        </div>
        <div class="local_attration_content">
          <h4>1008 Lingam Temple</h4>
        </div>
      </div>
    </div>
  </div>
</section>

<!--local_attration-->














<?php

include('includes/footer.php');
?>
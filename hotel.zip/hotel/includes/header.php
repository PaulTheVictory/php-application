<?php
$title = isset($title) ? $title : '';
$description = isset($description) ? $description : '';
$keyword = isset($keyword) ? $keyword : '';
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="assets/css/bootstrap_min.css">
  <link rel="stylesheet" href="assets/css/aos_min.css">
  <link rel="stylesheet" href="assets/css/swiper_min.css">
  <link rel="stylesheet" href="assets/css/fafa_icon_min.css">
  <link rel="stylesheet" href="assets/css/fas_min.css">
  <link rel="stylesheet" href="assets/css/fafa_icon_min.css">
  <link rel="stylesheet" href="assets/css/animate_min.css">
  <link rel="stylesheet" href="assets/css/gallery_min.css">
  <link rel="stylesheet" href="assets/css/style.css">
  <link rel="stylesheet" href="assets/css/style_media.css">
  <title><?php echo $title; ?></title>
  <meta name="description" content="<?php echo $description; ?>" />
  <meta name="keyword" content="<?php echo $keyword; ?>" />
  <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
  <link rel="icon" href="favicon.ico" type="image/x-icon">

</head>

<body>



  <!--header_section-->

  <header class="header_section">
    <div class="wrapper">
      <div class="header_align">
        <div class="header_left">
          <div class="menu">
            <img src="./assets/images/menu.png" alt="Menubar">
          </div>
        </div>
        <div class="header_center">
          <a href="./" title="Cj Pallazzio">
            <img src="./assets/images/logo.png" alt="Cj Pallazzio">
          </a>
        </div>
        <div class="header_right">
          <div class="head_btn">
            <a href="javascript:void(0)" title="Book Now">
              <button class="book_now">Book Now <i class="fa fa-long-arrow-right" aria-hidden="true"></i></button>
            </a>
          </div>
        </div>
      </div>
    </div>
  </header>

  <!--header_section-->
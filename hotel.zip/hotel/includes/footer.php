 <!--footer_section-->

 <footer class="footer_section">
   <div class="wrapper">
     <div class="footer_top">
       <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d3907.2589988146!2d78.128435!3d11.676048!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3babf06605bb0f7b%3A0x6cb77a910a563ec7!2sCJ%20Pallazzio!5e0!3m2!1sen!2sus!4v1678022083458!5m2!1sen!2sus" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
     </div>
     <div class="footer_bottom">
       <div class="footer_align">
         <div class="footer_1">
           <img src="./assets/images/logo.png" alt="Cjpallazzio">
           <p>Enjoy our hospitality; enjoy 'Business Class Luxury', be our guest whether you are looking for stopovers between trips or a business visit to the city.</p>
           <div class="social_media">
             <a href="javascript:void(0)" title="Facebook" target="_blank">
               <i class="fa fa-facebook"></i>
             </a>
             <a href="javascript:void(0)" title="Twitter" target="_blank">
               <i class="fa fa-twitter"></i>
             </a>
             <a href="javascript:void(0)" title="Instagram" target="_blank">
               <i class="fa fa-instagram"></i>
             </a>
             <a href="javascript:void(0)" title="Youtube" target="_blank">
               <i class="fa fa-youtube-play"></i>
             </a>
           </div>
         </div>
         <div class="footer_2">
           <h4>Quick Links</h4>
           <ul>
             <li>
               <a href="javascript:void(0)" title="Rooms">Rooms</a>
             </li>
             <li>
               <a href="javascript:void(0)" title="Banquet">Banquet</a>
             </li>
             <li>
               <a href="javascript:void(0)" title="Dining">Dining</a>
             </li>
             <li>
               <a href="javascript:void(0)" title="Spa & Gym">Spa & Gym</a>
             </li>
             <li>
               <a href="javascript:void(0)" title="Facilities">Facilities</a>
             </li>
           </ul>
         </div>
         <div class="footer_3">
           <h4>Contact Us</h4>
           <p class="address">201/6, Junction Main Road, Near NH -7, Salem - 636 005</p>
           <p class="call"><a href="tel:+91 427 2556677" title="Call Now">+91 427 2556677</a></p>
           <p class="mail"><a href="mailto:info@cjpallazzio.com" title="Mail To">info@cjpallazzio.com</a></p>
         </div>
         <div class="footer_4">
           <h4>Virtual tour</h4>
           <ul>
             <li>
               <img src="./assets/images/s1.jpg" alt="gallery">
             </li>
             <li>
               <img src="./assets/images/s1.jpg" alt="gallery">
             </li>
             <li>
               <img src="./assets/images/s1.jpg" alt="gallery">
             </li>
             <li>
               <img src="./assets/images/s1.jpg" alt="gallery">
             </li>
             <li>
               <img src="./assets/images/s1.jpg" alt="gallery">
             </li>
             <li>
               <img src="./assets/images/s1.jpg" alt="gallery">
             </li>
             <li>
               <img src="./assets/images/s1.jpg" alt="gallery">
             </li>
             <li>
               <img src="./assets/images/s1.jpg" alt="gallery">
             </li>
             <li>
               <img src="./assets/images/s1.jpg" alt="gallery">
             </li>
           </ul>
         </div>
       </div>
     </div>
   </div>
   <div class="copy_text">
     <div class="wrapper">
       <p>Copyright © 2023 CJ Pallazzio. All Rights Reserved.</p>
       <p>Designed by <a href="https://www.blazon.in" title="Blazon" target="_blank">Blazon</a></p>
     </div>
   </div>
 </footer>


 <!--footer_section-->

 <script src="assets/js/jquery_min.js"></script>
 <script src="assets/js/bootstrap_min.js"></script>
 <script src="assets/js/desk_menu_min.js"></script>
 <script src="assets/js/aos_min.js"></script>
 <script src="assets/js/swiper_min.js"></script>
 <script src="assets/js/gallery_min.js"></script>
 <script src="assets/js/website_script.js"></script>
 </body>

 </html>
<?php

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  date_default_timezone_set("Asia/Calcutta");
  $h_name = isset($_POST["name"]) ? $_POST["name"] : "";
  $h_phone = isset($_POST["phone"]) ? $_POST["phone"] : "";
  $h_email = isset($_POST["email"]) ? $_POST["email"] : "";
  $h_location = isset($_POST["location"]) ? $_POST["location"] : "";
  $h_message = isset($_POST["message"]) ? $_POST["message"] : "";
  $h_capchaans = isset($_POST["h_capchaans"]) ? $_POST["h_capchaans"] : "";
  $h_capchaques = isset($_POST["h_capchaques"]) ? $_POST["h_capchaques"] : "";

  if (empty($h_name) || empty($h_phone) || empty($h_email)) {
    // echo 1;
    echo json_encode(array(0 => "validation"));
    exit;
  }
  $to = 'triguninteriors@gmail.com';
  



  if ($h_capchaans !== $h_capchaques) {
    // echo 2;
    echo json_encode(array(0 => "capcha"));
    exit;
  } else {

    //$to = 'triguninteriors@gmail.com';
    $subject = "Trigun Studio Enquiry Form - Ads";
    $headers = "From: no-reply@triguninteriors.in\r\n";
    $headers .= "Reply-To:  triguninteriors@gmail.com\r\n";
    $headers .= "BCC: dm@blazon.in \r\n";  //venkat@blazon.in
    $headers .= "MIME-Version: 1.0\r\n";
    $headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";

    $msg = "<table width=70% border=0 cellspacing=0 cellpadding=0>  
    <tr>
      <td valign=top>Name</td>
      <td valign=top>:</td>
      <td valign=top>" . $h_name . "</td>
    </tr>
    <tr>
    <td valign=top>Phone No</td>
    <td valign=top>:</td>
    <td valign=top>" . $h_phone . "</td>
  </tr>
    <tr>
      <td valign=top>Email</td>
      <td valign=top>:</td> 
      <td valign=top>" . $h_email . "</td>
    </tr>
   
    <tr>
      <td valign=top>Location</td>
      <td valign=top>:</td>
      <td valign=top>" . $h_location . "</td>
    </tr>
    <tr>
      <td valign=top>Message</td>
      <td valign=top>:</td>
      <td valign=top>" . $h_message . "</td>
    </tr>
  </table>";

    $result = mail($to, $subject, $msg, $headers);

    if ($result) {
      // echo 3;
      echo json_encode(array(0 => "success"));
      exit;
    } else {
      // echo 4;
      echo json_encode(array(0 => "tryagain"));
      exit;
    }



    // echo 5;
    echo json_encode(array(0 => "tryagain"));
    exit(0);
  };
};

<?php
$title = 'Thank You | Trigun Studio';
include('includes/header.php');

?>
<!--banner-section-->

<!--banner-section-->

<section class="thankyou_pages">
  <div class="wrapper">
    <div class="thankyou_content">
      <img src="./assets/images/thankyou.png" alt="Thank You">
      <h1>Thank You</h1>
      <p>Thank you for taking the time to send us a message, a member of our team will contact you shortly, if you want to have a informal chat with one of our team do not hesitate to call us.</p>
      <h4><img src="./assets/images/logo.png" alt="Thank You" class="thank_you lazyload"></h4>
      <a href="./" title="Back Home">
        <button></i> Home</button>
      </a>
    </div>
  </div>
</section>


<?php
include('includes/footer.php');
?>


<style>
  .thankyou_pages {
    width: 100%;
    display: inline-block;
    margin: 80px 0 40px 0;
}
.thankyou_pages .thankyou_content {
    width: 100%;
    display: inline-block;
    position: relative;
    text-align: center;
    background: rgb(232 160 36 / 8%);
    padding: 60px 50px;
}
.thankyou_pages .thankyou_content img {
    height: 100px;
    margin: auto auto 25px;
}
.thankyou_pages .thankyou_content h1 {
    font-size: 40px;
    color: var(--bg_full);
    font-family: var(--bold);
    margin: 0 0 15px;
}
.thankyou_pages .thankyou_content p {
    color: #000;
    font-size: 15px;
    line-height: 26px;
    text-align: center;
    max-width: 80%;
    margin: auto;
}
.thankyou_pages .thankyou_content h4 {
    font-size: 25px;
    color: var(--bg_full);
    line-height: 1.5;
    margin: 30px 0 0 10px;
    font-family: 'f_bold';
}
.thankyou_pages .thankyou_content button {
    background: #000;
    font-size: 14px;
    text-transform: uppercase;
    font-family: var(--medium);
    width: auto;
    text-align: center;
    padding: 12px 20px;
    border: 0;
    display: flex;
    border-radius: 5px;
    transition: all .4s ease-in-out;
    margin: 15px auto 0 auto;
    display: flex;
    align-items: center;
    gap: 10px;
    color: #fff;
}

@media screen and (max-width:480px) {
  .thankyou_pages .thankyou_content {
    padding: 30px 15px;
  }
  .thankyou_pages .thankyou_content img {
    object-fit: contain;
  }
}
</style>
<?php
$title = 'Rooms | CJ Pallazzio';
$description = "";
$keyword = "";
$banner_text = "Rooms";
include('includes/header.php');
?>


<!--inner_banner_section-->

<section class="inner_banner_section">
  <img src="./assets/images/banner/inner.jpg" alt="Banner">
  <div class="inner_banner_heading">
    <h1><?= $banner_text; ?></h1>
  </div>
</section>

<!--inner_banner_section-->



<!--ourroom_services-->

<section class="ourroom_services inner_page">
  <div class="wrapper">
    <div class="head_text">
      <h4>Deluxe And Luxury</h4>
      <h2>Our Luxury Rooms</h2>
    </div>
    <div class="ourroom_align">
      <div class="ourroom_box">
        <div class="ourrrom_img">
          <img src="./assets/images/s1.jpg" alt="">
        </div>
        <div class="ourroom_content">
          <h4>Deluxe Room</h4>
          <h5>Rs 1500<span> / per night</span></h5>
          <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod.</p>
          <div class="benifits">
            <div class="benifits_items" data-bs-toggle="tooltip" title="Mini Bar Included">
              <i class="fa fa-glass"></i>
            </div>
            <div class="benifits_items" data-bs-toggle="tooltip" title="Sauna Included">
              <i class="fa fa-bath"></i>
            </div>
            <div class="benifits_items" data-bs-toggle="tooltip" title="Wi-Fi Included">
              <i class="fa fa-wifi"></i>
            </div>
            <div class="benifits_items" data-bs-toggle="tooltip" title="Breakfast Included">
              <i class="fa fa-cutlery"></i>
            </div>
            <div class="benifits_items" data-bs-toggle="tooltip" title="Coffee Maker Included">
              <i class="fa fa-coffee"></i>
            </div>
            <div class="benifits_items" data-bs-toggle="tooltip" title="Hair Dryer Included">
              <i class="fa fa-female"></i>
            </div>
            <div class="benifits_items" data-bs-toggle="tooltip" title="Widescreen TV Included">
              <i class="fa fa-television"></i>
            </div>

          </div>
          <div class="details">
            <a href="javascript:void(0)" title="Details">
              <button>Details <i class="fa fa-long-arrow-right" aria-hidden="true"></i></button>
            </a>
          </div>
        </div>
      </div>
      <div class="ourroom_box">
        <div class="ourrrom_img">
          <img src="./assets/images/s2.jpg" alt="">
        </div>
        <div class="ourroom_content">
          <h4>Deluxe Room</h4>
          <h5>Rs 1500<span> / per night</span></h5>
          <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod.</p>
          <div class="benifits">
            <div class="benifits_items" data-bs-toggle="tooltip" title="Mini Bar Included">
              <i class="fa fa-glass"></i>
            </div>
            <div class="benifits_items" data-bs-toggle="tooltip" title="Sauna Included">
              <i class="fa fa-bath"></i>
            </div>
            <div class="benifits_items" data-bs-toggle="tooltip" title="Wi-Fi Included">
              <i class="fa fa-wifi"></i>
            </div>
            <div class="benifits_items" data-bs-toggle="tooltip" title="Breakfast Included">
              <i class="fa fa-cutlery"></i>
            </div>
            <div class="benifits_items" data-bs-toggle="tooltip" title="Coffee Maker Included">
              <i class="fa fa-coffee"></i>
            </div>
            <div class="benifits_items" data-bs-toggle="tooltip" title="Hair Dryer Included">
              <i class="fa fa-female"></i>
            </div>
            <div class="benifits_items" data-bs-toggle="tooltip" title="Widescreen TV Included">
              <i class="fa fa-television"></i>
            </div>

          </div>
          <div class="details">
            <a href="javascript:void(0)" title="Details">
              <button>Details <i class="fa fa-long-arrow-right" aria-hidden="true"></i></button>
            </a>
          </div>
        </div>
      </div>
      <div class="ourroom_box">
        <div class="ourrrom_img">
          <img src="./assets/images/s3.jpg" alt="">
        </div>
        <div class="ourroom_content">
          <h4>Deluxe Room</h4>
          <h5>Rs 1500<span> / per night</span></h5>
          <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod.</p>
          <div class="benifits">
            <div class="benifits_items" data-bs-toggle="tooltip" title="Mini Bar Included">
              <i class="fa fa-glass"></i>
            </div>
            <div class="benifits_items" data-bs-toggle="tooltip" title="Sauna Included">
              <i class="fa fa-bath"></i>
            </div>
            <div class="benifits_items" data-bs-toggle="tooltip" title="Wi-Fi Included">
              <i class="fa fa-wifi"></i>
            </div>
            <div class="benifits_items" data-bs-toggle="tooltip" title="Breakfast Included">
              <i class="fa fa-cutlery"></i>
            </div>
            <div class="benifits_items" data-bs-toggle="tooltip" title="Coffee Maker Included">
              <i class="fa fa-coffee"></i>
            </div>
            <div class="benifits_items" data-bs-toggle="tooltip" title="Hair Dryer Included">
              <i class="fa fa-female"></i>
            </div>
            <div class="benifits_items" data-bs-toggle="tooltip" title="Widescreen TV Included">
              <i class="fa fa-television"></i>
            </div>

          </div>
          <div class="details">
            <a href="javascript:void(0)" title="Details">
              <button>Details <i class="fa fa-long-arrow-right" aria-hidden="true"></i></button>
            </a>
          </div>
        </div>
      </div>
      <div class="ourroom_box">
        <div class="ourrrom_img">
          <img src="./assets/images/s4.jpg" alt="">
        </div>
        <div class="ourroom_content">
          <h4>Deluxe Room</h4>
          <h5>Rs 1500<span> / per night</span></h5>
          <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod.</p>
          <div class="benifits">
            <div class="benifits_items" data-bs-toggle="tooltip" title="Mini Bar Included">
              <i class="fa fa-glass"></i>
            </div>
            <div class="benifits_items" data-bs-toggle="tooltip" title="Sauna Included">
              <i class="fa fa-bath"></i>
            </div>
            <div class="benifits_items" data-bs-toggle="tooltip" title="Wi-Fi Included">
              <i class="fa fa-wifi"></i>
            </div>
            <div class="benifits_items" data-bs-toggle="tooltip" title="Breakfast Included">
              <i class="fa fa-cutlery"></i>
            </div>
            <div class="benifits_items" data-bs-toggle="tooltip" title="Coffee Maker Included">
              <i class="fa fa-coffee"></i>
            </div>
            <div class="benifits_items" data-bs-toggle="tooltip" title="Hair Dryer Included">
              <i class="fa fa-female"></i>
            </div>
            <div class="benifits_items" data-bs-toggle="tooltip" title="Widescreen TV Included">
              <i class="fa fa-television"></i>
            </div>

          </div>
          <div class="details">
            <a href="javascript:void(0)" title="Details">
              <button>Details <i class="fa fa-long-arrow-right" aria-hidden="true"></i></button>
            </a>
          </div>
        </div>
      </div>
      <div class="ourroom_box">
        <div class="ourrrom_img">
          <img src="./assets/images/s5.jpg" alt="">
        </div>
        <div class="ourroom_content">
          <h4>Deluxe Room</h4>
          <h5>Rs 1500<span> / per night</span></h5>
          <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod.</p>
          <div class="benifits">
            <div class="benifits_items" data-bs-toggle="tooltip" title="Mini Bar Included">
              <i class="fa fa-glass"></i>
            </div>
            <div class="benifits_items" data-bs-toggle="tooltip" title="Sauna Included">
              <i class="fa fa-bath"></i>
            </div>
            <div class="benifits_items" data-bs-toggle="tooltip" title="Wi-Fi Included">
              <i class="fa fa-wifi"></i>
            </div>
            <div class="benifits_items" data-bs-toggle="tooltip" title="Breakfast Included">
              <i class="fa fa-cutlery"></i>
            </div>
            <div class="benifits_items" data-bs-toggle="tooltip" title="Coffee Maker Included">
              <i class="fa fa-coffee"></i>
            </div>
            <div class="benifits_items" data-bs-toggle="tooltip" title="Hair Dryer Included">
              <i class="fa fa-female"></i>
            </div>
            <div class="benifits_items" data-bs-toggle="tooltip" title="Widescreen TV Included">
              <i class="fa fa-television"></i>
            </div>

          </div>
          <div class="details">
            <a href="javascript:void(0)" title="Details">
              <button>Details <i class="fa fa-long-arrow-right" aria-hidden="true"></i></button>
            </a>
          </div>
        </div>
      </div>
      <div class="ourroom_box">
        <div class="ourrrom_img">
          <img src="./assets/images/s6.jpg" alt="">
        </div>
        <div class="ourroom_content">
          <h4>Deluxe Room</h4>
          <h5>Rs 1500<span> / per night</span></h5>
          <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod.</p>
          <div class="benifits">
            <div class="benifits_items" data-bs-toggle="tooltip" title="Mini Bar Included">
              <i class="fa fa-glass"></i>
            </div>
            <div class="benifits_items" data-bs-toggle="tooltip" title="Sauna Included">
              <i class="fa fa-bath"></i>
            </div>
            <div class="benifits_items" data-bs-toggle="tooltip" title="Wi-Fi Included">
              <i class="fa fa-wifi"></i>
            </div>
            <div class="benifits_items" data-bs-toggle="tooltip" title="Breakfast Included">
              <i class="fa fa-cutlery"></i>
            </div>
            <div class="benifits_items" data-bs-toggle="tooltip" title="Coffee Maker Included">
              <i class="fa fa-coffee"></i>
            </div>
            <div class="benifits_items" data-bs-toggle="tooltip" title="Hair Dryer Included">
              <i class="fa fa-female"></i>
            </div>
            <div class="benifits_items" data-bs-toggle="tooltip" title="Widescreen TV Included">
              <i class="fa fa-television"></i>
            </div>

          </div>
          <div class="details">
            <a href="javascript:void(0)" title="Details">
              <button>Details <i class="fa fa-long-arrow-right" aria-hidden="true"></i></button>
            </a>
          </div>
        </div>
      </div>
      <div class="ourroom_box">
        <div class="ourrrom_img">
          <img src="./assets/images/s4.jpg" alt="">
        </div>
        <div class="ourroom_content">
          <h4>Deluxe Room</h4>
          <h5>Rs 1500<span> / per night</span></h5>
          <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod.</p>
          <div class="benifits">
            <div class="benifits_items" data-bs-toggle="tooltip" title="Mini Bar Included">
              <i class="fa fa-glass"></i>
            </div>
            <div class="benifits_items" data-bs-toggle="tooltip" title="Sauna Included">
              <i class="fa fa-bath"></i>
            </div>
            <div class="benifits_items" data-bs-toggle="tooltip" title="Wi-Fi Included">
              <i class="fa fa-wifi"></i>
            </div>
            <div class="benifits_items" data-bs-toggle="tooltip" title="Breakfast Included">
              <i class="fa fa-cutlery"></i>
            </div>
            <div class="benifits_items" data-bs-toggle="tooltip" title="Coffee Maker Included">
              <i class="fa fa-coffee"></i>
            </div>
            <div class="benifits_items" data-bs-toggle="tooltip" title="Hair Dryer Included">
              <i class="fa fa-female"></i>
            </div>
            <div class="benifits_items" data-bs-toggle="tooltip" title="Widescreen TV Included">
              <i class="fa fa-television"></i>
            </div>

          </div>
          <div class="details">
            <a href="javascript:void(0)" title="Details">
              <button>Details <i class="fa fa-long-arrow-right" aria-hidden="true"></i></button>
            </a>
          </div>
        </div>
      </div>
      <div class="ourroom_box">
        <div class="ourrrom_img">
          <img src="./assets/images/s5.jpg" alt="">
        </div>
        <div class="ourroom_content">
          <h4>Deluxe Room</h4>
          <h5>Rs 1500<span> / per night</span></h5>
          <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod.</p>
          <div class="benifits">
            <div class="benifits_items" data-bs-toggle="tooltip" title="Mini Bar Included">
              <i class="fa fa-glass"></i>
            </div>
            <div class="benifits_items" data-bs-toggle="tooltip" title="Sauna Included">
              <i class="fa fa-bath"></i>
            </div>
            <div class="benifits_items" data-bs-toggle="tooltip" title="Wi-Fi Included">
              <i class="fa fa-wifi"></i>
            </div>
            <div class="benifits_items" data-bs-toggle="tooltip" title="Breakfast Included">
              <i class="fa fa-cutlery"></i>
            </div>
            <div class="benifits_items" data-bs-toggle="tooltip" title="Coffee Maker Included">
              <i class="fa fa-coffee"></i>
            </div>
            <div class="benifits_items" data-bs-toggle="tooltip" title="Hair Dryer Included">
              <i class="fa fa-female"></i>
            </div>
            <div class="benifits_items" data-bs-toggle="tooltip" title="Widescreen TV Included">
              <i class="fa fa-television"></i>
            </div>

          </div>
          <div class="details">
            <a href="javascript:void(0)" title="Details">
              <button>Details <i class="fa fa-long-arrow-right" aria-hidden="true"></i></button>
            </a>
          </div>
        </div>
      </div>
      <div class="ourroom_box">
        <div class="ourrrom_img">
          <img src="./assets/images/s6.jpg" alt="">
        </div>
        <div class="ourroom_content">
          <h4>Deluxe Room</h4>
          <h5>Rs 1500<span> / per night</span></h5>
          <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod.</p>
          <div class="benifits">
            <div class="benifits_items" data-bs-toggle="tooltip" title="Mini Bar Included">
              <i class="fa fa-glass"></i>
            </div>
            <div class="benifits_items" data-bs-toggle="tooltip" title="Sauna Included">
              <i class="fa fa-bath"></i>
            </div>
            <div class="benifits_items" data-bs-toggle="tooltip" title="Wi-Fi Included">
              <i class="fa fa-wifi"></i>
            </div>
            <div class="benifits_items" data-bs-toggle="tooltip" title="Breakfast Included">
              <i class="fa fa-cutlery"></i>
            </div>
            <div class="benifits_items" data-bs-toggle="tooltip" title="Coffee Maker Included">
              <i class="fa fa-coffee"></i>
            </div>
            <div class="benifits_items" data-bs-toggle="tooltip" title="Hair Dryer Included">
              <i class="fa fa-female"></i>
            </div>
            <div class="benifits_items" data-bs-toggle="tooltip" title="Widescreen TV Included">
              <i class="fa fa-television"></i>
            </div>

          </div>
          <div class="details">
            <a href="javascript:void(0)" title="Details">
              <button>Details <i class="fa fa-long-arrow-right" aria-hidden="true"></i></button>
            </a>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<!--ourroom_services-->
















<?php

include('includes/footer.php');
?>


(function($) {
  'use strict';
    $(window).on('load', function() {
        //$(".loader").fadeOut();
        //$("#preloder").delay(200).fadeOut("slow");
		$(".loader_img").fadeOut();
        $(".loading-bar").fadeOut();
        $("#preloder").delay(200).fadeOut("slow");
    });
})(jQuery);




  //OnScroll Animation
  window.addEventListener('load', () => {
    AOS.init({
      duration: 1000,
      easing: "ease-in-out",
      once: true,
      mirror: false, 
      disable: function() {
        var maxWidth = 800;
        return window.innerWidth < maxWidth;
      }
    });
  });
  
  // Swiper: Home Banner Slider
new Swiper(".banner", {
  loop: false,
  speed: 1000,
  slidesPerView: 1,
  effect: "fade", // coverflow cube fade
  //  parallax: true,
  paginationClickable: true,
  spaceBetween: 0,
  autoplay: {
    delay: 5000,
    disableOnInteraction: false,
  },
  watchSlidesProgress: true,
  // navigation: {
  //     nextEl: '.h_banner_slider_next',
  //     prevEl: '.h_banner_slider_prev',
  // },
  pagination: {
    el: ".home_slider_pagination",
    clickable: true,
  },
  breakpoints: {
    1920: {
      slidesPerView: 1,
      spaceBetween: 0,
    },
    1028: {
      slidesPerView: 1,
      spaceBetween: 0,
    },
    768: {
      slidesPerView: 1,
      spaceBetween: 0,
    },
  },
});

//dining

new Swiper(".dining_align", {
  loop: false,
  speed: 1000,
  slidesPerView: 3,
  effect: "slide", // coverflow cube fade
  //  parallax: true,
  paginationClickable: true,
  spaceBetween: 25,
  autoplay: {
    delay: 4000,
    disableOnInteraction: false,
  },
  watchSlidesProgress: true,
  // navigation: {
  //     nextEl: '.h_banner_slider_next',
  //     prevEl: '.h_banner_slider_prev',
  // },
  pagination: {
    el: ".dining_slider_pagination",
    clickable: true,
  },
  breakpoints: {
    1920: {
      slidesPerView: 3,
      spaceBetween: 25,
    },
    1028: {
      slidesPerView: 3,
      spaceBetween: 25,
    },
    768: {
      slidesPerView: 1,
      spaceBetween: 0,
    },
  },
});

new Swiper(".testimonails_slider", {
  loop: false,
  speed: 1000,
  slidesPerView: 1,
  effect: "slide", // coverflow cube fade
  //  parallax: true,
  paginationClickable: true,
  spaceBetween: 0,
  autoplay: {
    delay: 4000,
    disableOnInteraction: false,
  },
  watchSlidesProgress: true,
  // navigation: {
  //     nextEl: '.h_banner_slider_next',
  //     prevEl: '.h_banner_slider_prev',
  // },
  pagination: {
    el: ".test_slider_pagination",
    clickable: true,
  },
  breakpoints: {
    1920: {
      slidesPerView: 1,
      spaceBetween: 0,
    },
    1028: {
      slidesPerView: 1,
      spaceBetween: 0,
    },
    768: {
      slidesPerView: 1,
      spaceBetween: 0,
    },
  },
});



 var galleryTop = new Swiper(".single_gallery_top", {
   spaceBetween: 0,
   navigation: {
     nextEl: ".single_gallery_top_next",
     prevEl: ".single_gallery_top_prev",
   },
   loop: true,
   loopedSlides: 4,
 });
 var galleryThumbs = new Swiper(".single_gallery_bottom", {
   spaceBetween: 0,
   centeredSlides: true,
   slidesPerView: 5,
   touchRatio: 0.2,
   slideToClickedSlide: true,
   loop: true,
   loopedSlides: 4,
 });
 galleryTop.controller.control = galleryThumbs;
 galleryThumbs.controller.control = galleryTop;


$('[data-fancybox="gallery"]').fancybox({
  buttons: [
    "slideShow",
    "thumbs",
    "zoom",
    "fullScreen",
    "share",
    "close"
  ],
  loop: false,
  protect: true
});





 


$(document).ready(function(){

$(function() {
  var Accordion = function(el, multiple) {
      this.el = el || {};
      this.multiple = multiple || false;

      var links = this.el.find('.faq_question');
      links.on('click', {
          el: this.el,
          multiple: this.multiple
      }, this.dropdown)
  }

  Accordion.prototype.dropdown = function(e) {
      var $el = e.data.el;
      $this = $(this),
          $next = $this.next();

      $next.slideToggle();
      $this.parent().toggleClass('faq_open');

      if (!e.data.multiple) {
          $el.find('.faq_answer').not($next).slideUp().parent().removeClass('faq_open');
      };
  }
  var accordion = new Accordion($('.faq_section_page'), false);
});
});
// //

// //Sticky Navbar

// (function($) {
//   "use strict";
//   var $navbar = $("#navbar"),
//   y_pos = $navbar.offset().top,
//   height = $navbar.height();
//   $(document).scroll(function() {
//   var scrollTop = $(this).scrollTop();
//   if (scrollTop > y_pos + height) {
//   $navbar.addClass("navbar-fixed").animate({
//   top: 0
//   });
//   } else if (scrollTop <= y_pos) {
//   $navbar.removeClass("navbar-fixed").clearQueue().animate({
//   top: "-48px"
//   }, 0);
//   }
//   });
//   })(jQuery, undefined);

  //

  

  var tooltipTriggerList = [].slice.call(
    document.querySelectorAll('[data-bs-toggle="tooltip"]')
  );
  var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
    return new bootstrap.Tooltip(tooltipTriggerEl);
  });

// //Mob Menu

$(".extra_main_box").hide();
$(".extra_main_box:nth-child(1)").show();
$(".extra_thump .extra_thump_box:nth-child(1)").addClass("active");
// Click function
$(".extra_thump .extra_thump_box").click(function () {
  $(".extra_thump .extra_thump_box").removeClass("active");
  $(this).addClass("active");
  $(".extra_main_box").hide();
  var activeTab = $(this).find("a").attr("href");
  $(activeTab).fadeIn(300);
  $("html, body").animate(
    {
      scrollTop: $(activeTab).offset().top - 200,
    },
    200
  );
  return false;
});

//



jQuery(document).ready(function ($) {
  //Form Validation Home Page Form



  $("#contact_form").on("submit", function (e) {
    e.preventDefault();
    const h_name = $("#name").val();
    const h_phone = $("#phone").val();
    const h_email = $("#email").val();
    const h_capchaans = $("#h_capchaans").val();
    const h_capchaques = $("#h_capchaques").val();
    
    

    var regex = "";
    var valid;

    regex = "^[a-zA-Z][a-zA-Z. ]{2,40}$";
    valid = validateInputs(h_name, regex);

    if (!valid || h_name == "") {
      alert("Please enter valid name");
      return false;
    }
    regex = "^[0-9 -]{10,20}$";
    valid = validateInputs(h_phone, regex);

    if (!valid || h_phone == "") {
      alert("Please enter valid phone number");
      return false;
    }

    regex = "^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+.[a-zA-Z]{2,4}$";
    valid = validateInputs(h_email, regex);
    if (!valid || h_email == "") {
      alert("Please enter valid email address");
      return false;
    }

    

    if (h_capchaans !== h_capchaques) {
      alert("Please enter valid recapcha");
      return false;
    }

    if ($("#h_submit").hasClass("process")) {
      alert("Please wait while processing...");
    } else {
      $("#h_submit").addClass("process");
      $.ajax({
        url: "send_us_a_message_now_form.php",
        type: "POST",
        data: new FormData(this),
        processData: false,
        contentType: false,
        cache: false,
        success: function (data) {
          var obj1 = $.parseJSON(data);
          if (obj1[0] === "success") {
            $("#contact_form")[0].reset();
            $("#h_submit").removeClass("process");
            location.assign("thank-you.php");
          } else if (obj1[0] === "validation") {
            alert("Fill all mandatory fields");
            $("#h_submit").removeClass("process");
          } else if (obj1[0] === "branch") {
            alert("Please select branch location.");
            $("#h_submit").removeClass("process");
          } else if (obj1[0] === "capcha") {
            alert("Invalid Capcha.");
            $("#h_submit").removeClass("process");
          } else if (obj1[0] === "tryagain") {
            alert("Please try again.");
            $("#h_submit").removeClass("process");
          }
        },
      });
      // $("#send_message_form").submit();
    }
  });

  function validateInputs(value, pattern) {
    var regexppattern;
    regexppattern = new RegExp(pattern);
    var valid = regexppattern.test(value);
    return valid;
  }
});


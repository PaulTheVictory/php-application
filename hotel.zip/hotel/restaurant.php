<?php
$title = 'Restaurant | CJ Pallazzio';
$description = "";
$keyword = "";
$banner_text = "Restaurant";
include('includes/header.php');
?>


<!--inner_banner_section-->

<section class="inner_banner_section">
  <img src="./assets/images/banner/inner.jpg" alt="Banner">
  <div class="inner_banner_heading">
    <h1><?= $banner_text; ?></h1>
  </div>
</section>

<!--inner_banner_section-->



<!--res_section-->

<div class="res_section">
  <div class="wrapper">
    <div class="res1">
      <div class="res1_left">
        <h2>Our Restaurant</h2>
        <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te feugait nulla facilisi. Nam liber tempor cum soluta nobis eleifend option congue nihil imperdiet doming id quod mazim placerat facer possim assum. Typi non habent claritatem insitam; est usus legentis in iis qui facit eorum claritatem. Investigationes demonstraverunt lectores legere me lius quod ii legunt saepius. Claritas est etiam processus dynamicus.</p>
      </div>
      <div class="res1_right">
        <img src="./assets/images/res1.jpg" alt="Our Restaurant">
      </div>
    </div>
    <div class="res2">
      <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te feugait nulla facilisi. Nam liber tempor cum soluta nobis eleifend option congue nihil imperdiet doming id quod mazim placerat facer possim assum. Typi non habent claritatem insitam; est usus legentis in iis qui facit eorum claritatem. Investigationes demonstraverunt lectores legere me lius quod ii legunt saepius. Claritas est etiam processus dynamicus, qui sequitur mutationem consuetudium lectorum. Mirum est notare quam littera gothica, quam nunc putamus parum claram, anteposuerit litterarum formas humanitatis per seacula quarta decima et quinta decima. Eodem modo typi, qui nunc nobis videntur parum clari, fiant sollemnes in futurum.</p>
    </div>
    <div class="res_menu">
      <h2>Our Menu</h2>
      <div class="res_menu_align">
        <div class="res_menu_box">
          <div class="res_menu_left">
            <img src="./assets/images/res2.jpg" alt="menu">
          </div>
          <div class="res_menu_right">
            <div class="res_title">
              <h4>SALAD</h4>
              <h5>Rs 450/-</h5>
            </div>
            <p>Lorem ipsum dolor sit amet, elit, sed diam nonummy nibh euismod tincidunt ut laoreet</p>
          </div>
        </div>
        <div class="res_menu_box">
          <div class="res_menu_left">
            <img src="./assets/images/res2.jpg" alt="menu">
          </div>
          <div class="res_menu_right">
            <div class="res_title">
              <h4>SALAD</h4>
              <h5>Rs 450/-</h5>
            </div>
            <p>Lorem ipsum dolor sit amet, elit, sed diam nonummy nibh euismod tincidunt ut laoreet</p>
          </div>
        </div>
        <div class="res_menu_box">
          <div class="res_menu_left">
            <img src="./assets/images/res2.jpg" alt="menu">
          </div>
          <div class="res_menu_right">
            <div class="res_title">
              <h4>SALAD</h4>
              <h5>Rs 450/-</h5>
            </div>
            <p>Lorem ipsum dolor sit amet, elit, sed diam nonummy nibh euismod tincidunt ut laoreet</p>
          </div>
        </div>
        <div class="res_menu_box">
          <div class="res_menu_left">
            <img src="./assets/images/res2.jpg" alt="menu">
          </div>
          <div class="res_menu_right">
            <div class="res_title">
              <h4>SALAD</h4>
              <h5>Rs 450/-</h5>
            </div>
            <p>Lorem ipsum dolor sit amet, elit, sed diam nonummy nibh euismod tincidunt ut laoreet</p>
          </div>
        </div>
        <div class="res_menu_box">
          <div class="res_menu_left">
            <img src="./assets/images/res2.jpg" alt="menu">
          </div>
          <div class="res_menu_right">
            <div class="res_title">
              <h4>SALAD</h4>
              <h5>Rs 450/-</h5>
            </div>
            <p>Lorem ipsum dolor sit amet, elit, sed diam nonummy nibh euismod tincidunt ut laoreet</p>
          </div>
        </div>
        <div class="res_menu_box">
          <div class="res_menu_left">
            <img src="./assets/images/res2.jpg" alt="menu">
          </div>
          <div class="res_menu_right">
            <div class="res_title">
              <h4>SALAD</h4>
              <h5>Rs 450/-</h5>
            </div>
            <p>Lorem ipsum dolor sit amet, elit, sed diam nonummy nibh euismod tincidunt ut laoreet</p>
          </div>
        </div>
      </div>
    </div>
    <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te feugait nulla facilisi. Nam liber tempor cum soluta nobis eleifend option congue nihil imperdiet doming id quod mazim placerat facer possim assum. Typi non habent claritatem insitam; est usus legentis in iis qui facit eorum claritatem. Investigationes demonstraverunt lectores legere me lius quod ii legunt saepius. Claritas est etiam processus dynamicus, qui sequitur mutationem consuetudium lectorum. Mirum est notare quam littera gothica, quam nunc putamus parum claram, anteposuerit litterarum formas humanitatis</p>
  </div>
</div>

<!--res_section-->



<!--res_gallery-->

<section class="res_gallery">
  <div class="wrapper">
    <h2>Image Gallery</h2>
    <ul>
      <li>
        <a data-fancybox="singleroom" data-src="./assets/images/res3.jpg" data-caption="Gallery">
          <img src="./assets/images/res3.jpg" alt="Gallery">
        </a>
      </li>
      <li>
        <a data-fancybox="singleroom" data-src="./assets/images/res3.jpg" data-caption="Gallery">
          <img src="./assets/images/res3.jpg" alt="Gallery">
        </a>
      </li>
      <li>
        <a data-fancybox="singleroom" data-src="./assets/images/res3.jpg" data-caption="Gallery">
          <img src="./assets/images/res3.jpg" alt="Gallery">
        </a>
      </li>
      <li>
        <a data-fancybox="singleroom" data-src="./assets/images/res3.jpg" data-caption="Gallery">
          <img src="./assets/images/res3.jpg" alt="Gallery">
        </a>
      </li>
      <li>
        <a data-fancybox="singleroom" data-src="./assets/images/res3.jpg" data-caption="Gallery">
          <img src="./assets/images/res3.jpg" alt="Gallery">
        </a>
      </li>
      <li>
        <a data-fancybox="singleroom" data-src="./assets/images/res3.jpg" data-caption="Gallery">
          <img src="./assets/images/res3.jpg" alt="Gallery">
        </a>
      </li>
      <li>
        <a data-fancybox="singleroom" data-src="./assets/images/res3.jpg" data-caption="Gallery">
          <img src="./assets/images/res3.jpg" alt="Gallery">
        </a>
      </li>
      <li>
        <a data-fancybox="singleroom" data-src="./assets/images/res3.jpg" data-caption="Gallery">
          <img src="./assets/images/res3.jpg" alt="Gallery">
        </a>
      </li>
    </ul>
  </div>
</section>

<!--res_gallery-->

















<?php

include('includes/footer.php');
?>
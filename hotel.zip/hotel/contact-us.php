<?php
$title = 'Contact Us | CJ Pallazzio';
$description = "";
$keyword = "";
$banner_text = "Contact Us";
include('includes/header.php');
?>


<!--inner_banner_section-->

<section class="inner_banner_section">
  <img src="./assets/images/banner/inner.jpg" alt="Banner">
  <div class="inner_banner_heading">
    <h1><?= $banner_text; ?></h1>
  </div>
</section>

<!--inner_banner_section-->


















<?php

include('includes/footer.php');
?>
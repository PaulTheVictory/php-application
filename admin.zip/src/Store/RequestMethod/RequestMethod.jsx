import axios from "axios";

const BASE_URL = process.env.REACT_APP_API;
const user = JSON.parse(localStorage.getItem("persist:root"))?.user;
const isAuthenticated = user && JSON.parse(user).isAuthenticated;
const isToken = user && JSON.parse(user).user?.token;
const company = process.env.REACT_APP_COMPANY_NAME;





export const companyName = process.env.REACT_APP_COMPANY_NAME;

export const publicRequest = axios.create({
  baseURL: BASE_URL,
});

export const userRequest = axios.create({
  baseURL: BASE_URL,
  headers: {
    token: `Bearer ${isToken}`,
    company: company,
    "Content-Type": "application/json",
  },
});

export const uploadRequest = axios.create({
  baseURL: BASE_URL,
  headers: {
    token: `Bearer ${isToken}`,
    company: company,
    "Content-Type": "multipart/form-data",
  },
});

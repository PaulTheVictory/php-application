import {
  userRequest,
  publicRequest,
  uploadRequest,
} from "../RequestMethod/RequestMethod";
import {
  // REGISTER_USER_REQUEST,
  // REGISTER_USER_SUCCESS,
  // REGISTER_USER_FAIL,
  LOGIN_USER_REQUEST,
  LOGIN_USER_SUCCESS,
  LOGIN_USER_FAIL,
  LOGOUT_USER,
} from "../Contans/UserContans";

class User {
  constructor() {
    this.rootUrl = process.env.BASE_URL;
    this.company = process.env.REACT_APP_COMPANY_NAME;
  }
  // register = async (dispatch, data) => {
  //   dispatch({ type: REGISTER_USER_REQUEST });
  //   try {
  //     const res = await userRequest.post("api/register", data);
  //     console.log(res);
  //     dispatch({ type: REGISTER_USER_SUCCESS, payload: res.data });
  //     return res;
  //   } catch (error) {
  //     const res = error.response;
  //     dispatch({
  //       type: REGISTER_USER_FAIL,
  //       payload: error.response.data.message,
  //     });
  //     return res;
  //   }
  // };

  login = async (dispatch, data) => {
    dispatch({ type: LOGIN_USER_REQUEST });
    try {
      const res = await userRequest.post("api/admin/login", data);
      dispatch({ type: LOGIN_USER_SUCCESS, payload: res.data });
      return res;
    } catch (error) {
      const res = error.response;
      dispatch({
        type: LOGIN_USER_FAIL,
        payload: error.response.data.message,
      });
      return res;
    }
  };

  logout = async (dispatch) => {
    const user = JSON.parse(localStorage.getItem("persist:root"))?.user;
    const company = process.env.REACT_APP_COMPANY_NAME;

    const sessionid = user && JSON.parse(user).user?.user?.sessionid;
    try {
      const res = await userRequest.put("api/logout", {
        sessionid: sessionid,
      });
      dispatch({ type: LOGOUT_USER })
      return res;
    } catch (error) {
      const res = error.response;
      return res;
    }
  };

  getUserDetails = async () => {
    try {
      const res = await userRequest.get("api/admin/users");
      return res;
    } catch (error) {
      const res = error.response;
      return res;
    }
  };
}




export default User;

import {
  userRequest,
  uploadRequest,
} from "../Store/RequestMethod/RequestMethod";

class API {
  constructor() {
    this.rootUrl = process.env.BASE_URL;
    this.company = process.env.REACT_APP_COMPANY_NAME;
  }

//Add New Product
  
  addProduct = async (data) => {
    try
    {
      const res = await userRequest.post("api/admin/product/add", data); 
      return res;
    }
    catch (error)
    {
      const res = error.response;
      return res;
    }
  }


//Add New Category
  
  addCategory = async (data) => {
    try {
      const res = await userRequest.post("api/admin/category/add", data); 
      return res;
    }
    catch (error)
    {
      const res = error.response;
      return res;
    }
  }













}

export default API;
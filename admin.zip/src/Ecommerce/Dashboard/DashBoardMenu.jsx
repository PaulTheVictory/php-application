import React, {useState} from 'react'
import { Layout, Menu } from "antd";

import DashboardIcon from "@mui/icons-material/Dashboard";
import PushPinIcon from "@mui/icons-material/PushPin";
import PermMediaIcon from "@mui/icons-material/PermMedia";
import ShoppingCartIcon from "@mui/icons-material/ShoppingCart";
import DescriptionIcon from "@mui/icons-material/Description";
import PersonIcon from "@mui/icons-material/Person";
import LocalMallIcon from "@mui/icons-material/LocalMall";
import InventoryIcon from "@mui/icons-material/Inventory";
import CommentIcon from "@mui/icons-material/Comment";
import SettingsIcon from "@mui/icons-material/Settings";
import LogoutIcon from "@mui/icons-material/Logout";
import RssFeedIcon from "@mui/icons-material/RssFeed";
import InsertChartIcon from "@mui/icons-material/InsertChart";
import MonetizationOnIcon from "@mui/icons-material/MonetizationOn";
import LocalOfferIcon from "@mui/icons-material/LocalOffer";
import AssignmentIcon from "@mui/icons-material/Assignment";
import { Link } from 'react-router-dom';
const { Sider } = Layout;



const DashBoardMenu = () => {
  const [collapsed, setCollapsed] = useState(false);
  return (
    <React.Fragment>
      <Sider
        width={240}
        collapsible
        collapsed={collapsed}
        onCollapse={(value) => setCollapsed(value)}
      >
        <div className="logo">Paul</div>
        <Menu theme="light" defaultSelectedKeys={["1"]} mode="inline">
          <Menu.Item key="dashboard" icon={<DashboardIcon />}>
            <Link to="/">Dashboard</Link>
          </Menu.Item>
          <Menu.SubMenu title="Blogs" key="blogs" icon={<PushPinIcon />}>
            <Menu.Item>All Posts</Menu.Item>
            <Menu.Item>All New</Menu.Item>
            <Menu.Item>Category</Menu.Item>
            <Menu.Item>Tags</Menu.Item>
          </Menu.SubMenu>
          <Menu.SubMenu title="Media" key="media" icon={<PermMediaIcon />}>
            <Menu.Item>Library</Menu.Item>
            <Menu.Item>All New</Menu.Item>
          </Menu.SubMenu>
          <Menu.SubMenu
            title="Products"
            key="products"
            icon={<ShoppingCartIcon />}
          >
            <Menu.Item>All Products</Menu.Item>
            <Menu.Item>
              <Link to="/add-new-product">All New</Link>
            </Menu.Item>
            <Menu.Item><Link to="/product-category">Product Category</Link></Menu.Item>
            <Menu.Item>Attributes</Menu.Item>
            <Menu.Item>Reviews</Menu.Item>
          </Menu.SubMenu>
          <Menu.SubMenu title="Pages" key="pages" icon={<DescriptionIcon />}>
            <Menu.Item>All Pages</Menu.Item>
            <Menu.Item>All New</Menu.Item>
          </Menu.SubMenu>
          <Menu.SubMenu title="Buyer" key="buyer" icon={<LocalMallIcon />}>
            <Menu.Item>All Buyers</Menu.Item>
            <Menu.Item>Buyers Analytics</Menu.Item>
          </Menu.SubMenu>
          <Menu.SubMenu title="Orders" key="orders" icon={<InventoryIcon />}>
            <Menu.Item>All Orders</Menu.Item>
            <Menu.Item>Packing Orders</Menu.Item>
            <Menu.Item>Delevired Orders</Menu.Item>
            <Menu.Item>Cancelled Orders</Menu.Item>
          </Menu.SubMenu>
          <Menu.SubMenu
            title="Inventory"
            key="inventory"
            icon={<MonetizationOnIcon />}
          >
            <Menu.Item>Vendor List</Menu.Item>
            <Menu.Item>Create Vendor</Menu.Item>
          </Menu.SubMenu>
          <Menu.SubMenu title="Coupons" key="coupons" icon={<LocalOfferIcon />}>
            <Menu.Item>List Coupons</Menu.Item>
            <Menu.Item>Create Coupons</Menu.Item>
          </Menu.SubMenu>
          <Menu.Item icon={<AssignmentIcon />}>Reports</Menu.Item>
          <Menu.Item icon={<InsertChartIcon />}>Header & Footer</Menu.Item>
          <Menu.Item icon={<RssFeedIcon />}>SEO Analytics</Menu.Item>
          <Menu.Item icon={<CommentIcon />}>Comments</Menu.Item>
          <Menu.Item icon={<PersonIcon />}>My Profile</Menu.Item>
          <Menu.Item icon={<SettingsIcon />}>Settings</Menu.Item>
          <Menu.Item icon={<LogoutIcon />}>Logout</Menu.Item>
        </Menu>
      </Sider>
    </React.Fragment>
  );
};

export default DashBoardMenu;

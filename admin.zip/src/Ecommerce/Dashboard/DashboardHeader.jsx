import React from 'react'
import { Avatar, Badge, Dropdown, Input, Layout, Menu, message } from "antd";
import { UserOutlined } from "@ant-design/icons";
import NotificationsIcon from "@mui/icons-material/Notifications";
import MessageIcon from "@mui/icons-material/Message";
import styled from "styled-components";
import User from "../../Store/Actions/UserAction";
import { useDispatch } from "react-redux";

const { Search } = Input;
const onSearch = (value) => console.log(value);
const { Header } = Layout;

const DashboardHeader = () => {

  const api = new User();
const dispatch = useDispatch();
  const logout = () => {
    api
      .logout(dispatch)
      .then((res) => {
        let data = res.data;
        if (data.success === true) {
          message.success(data.message);
          window.location.reload()
        } else {
            message.error(data.message);
        }
      })
      .catch((err) => {
        message.error("Something went wrong!");
      });
  }
  const menu = (
    <Menu
      items={[
        {
          key: "1",
          label: <div>My Profile</div>,
        },
        {
          key: "2",
          label: <div>Account Settings</div>,
        },
        {
          key: "3",
          label: <div onClick={logout}>Logout</div>,
        },
      ]}
    />
  );

  return (
    <React.Fragment>
      <Header className='D_Header'>
        <HeaderLeft>
          <Search
            placeholder="Search"
            onSearch={onSearch}
            style={{
              width: 240,
            }}
          />
        </HeaderLeft>
        <HeaderRight>
          <Badge count={5} className="Notofication">
            <NotificationsIcon />
            <Avatar shape="circle" size="medium" />
          </Badge>
          <Badge count={2} className="MessageBox">
            <MessageIcon />
            <Avatar shape="circle" size="medium" />
          </Badge>
          <ProfilePic>
            <Avatar size={35} icon={<UserOutlined />} />
            <Dropdown placement="bottomRight" overlay={menu} arrow>
              <p>Paul D</p>
            </Dropdown>
          </ProfilePic>
        </HeaderRight>
      </Header>
    </React.Fragment>
  );
}

export default DashboardHeader


const HeaderLeft = styled.div``;
const HeaderRight = styled.div`
  display: flex;
  align-items: center;
  gap: 22px;

  .ant-avatar.ant-avatar-circle {
    background: transparent;
  }
  .ant-badge {
    display: flex;
    align-items: center;
    justify-content: center;
    position: relative;
    background: transparent;
    height: 29px;
    width: 29px;
  }
  svg {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
  }

  .ant-badge-count {
    height: 15px;
    width: 15px;
    min-width: 15px;
    padding: 0;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 11px;
    font-weight: 600;
    background: #dc3545;
    top: 4px;
  }
  .Notofication svg {
    color: #198754;
  }
  .MessageBox {
    color: #0d6efd;
  }
`;
const ProfilePic = styled.div`
  display: flex;
  align-items: center;
  gap: 10px;
  margin: 0 0 0 10px;
  .ant-select:not(.ant-select-customize-input) .ant-select-selector {
    border: 0;
    outline: none;
  }
  .ant-avatar.ant-avatar-circle {
    background: #bfbfbf;
  }
  p {
    margin: 0 !important;
    cursor: pointer;
    font-size: 15px;
    color: #000;
    font-weight: 600;
  }
  ul p {
    margin: 0;
  }
`;
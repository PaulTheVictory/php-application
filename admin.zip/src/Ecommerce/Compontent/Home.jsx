import React from 'react'
import { Calendar } from "antd";
import styled from 'styled-components';
import HomeReport from "./HomeReport";
import TodaySales from "./TodaySales";
import NewOrders from "./NewOrders";
import NewUsers from "./NewUsers";
import RecentUpdate from "./RecentUpdate";
import PagesDetails from "./PagesDetails";

const Home = () => {
  const onPanelChange = (value, mode) => {
    console.log(value.format("YYYY-MM-DD"), mode);
  };
  return (
    <React.Fragment>
      <HomeReport />
      <TowGrid>
        <TowGridBox>
          <NewOrders />
        </TowGridBox>
        <TowGridBox>
          <TodaySales />
        </TowGridBox>
      </TowGrid>
      <OneGrid>
        <NewUsers />
      </OneGrid>
      <ThreeGrid>
        <ThreeGridBox>
          <PagesDetails />
        </ThreeGridBox>
        <ThreeGridBox>
          <RecentUpdate />
        </ThreeGridBox>
        <ThreeGridBox>
          <Calendar fullscreen={false} onPanelChange={onPanelChange} />
        </ThreeGridBox>
      </ThreeGrid>
    </React.Fragment>
  );
}

export default Home;

const TowGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 24px;
`;
const TowGridBox = styled.div`
  padding: 24px;
  background: #fff;
  border-radius: 8px;
  box-shadow: 2px 4px 20px 1px rgb(201 201 201 / 30%);
  display: inline-block;
`;

const OneGrid = styled.div`
  width: 100%;
  display: inline-block;
  background: #fff;
  min-height: 250px;
  border-radius: 8px;
  padding: 24px;
  box-shadow: 2px 4px 20px 1px rgb(201 201 201 / 30%);
`;

const ThreeGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 24px;
`;
const ThreeGridBox = styled.div`
  width: 100%;
  display: inline-block;
  background: #fff;
  min-height: 350px;
  border-radius: 8px;
  padding: 24px;
  box-shadow: 2px 4px 20px 1px rgb(201 201 201 / 30%);
`;

import React, { useState } from "react";
import styled from "styled-components";
import {
  Button,
  Form,
  Input,
  Select,
  Upload,
  message,
} from "antd";
import {
  SafetyOutlined,
  LoadingOutlined,
  PlusOutlined,
} from "@ant-design/icons";
import API from "../../Api/ApiService";
const { Option } = Select;
const { TextArea } = Input;
const ProductCategory = () => {
  const [form] = Form.useForm();
  const [saving, setSaving] = useState(false);
  const [categoryTitle, setCategoryTitle] = useState("");
  
const getBase64 = (img, callback) => {
  const reader = new FileReader();
  reader.addEventListener("load", () => callback(reader.result));
  reader.readAsDataURL(img);
};
const beforeUpload = (file) => {
  const isJpgOrPng = file.type === "image/jpeg" || file.type === "image/png" || file.type === "image/webp" ||
    file.type === "image/jpg";
  if (!isJpgOrPng) {
    message.error("You can only upload JPG/PNG/WEBP file!");
  }
  const isLt2M = file.size / 1024 / 1024 < 2;
  if (!isLt2M) {
    message.error("Image must smaller than 2MB!");
  }
  return isJpgOrPng && isLt2M;
};

const [loading, setLoading] = useState(false);
const [imageUrl, setImageUrl] = useState();
const handleChange = (info) => {
  if (info.file.status === "uploading") {
    setLoading(true);
    return;
  }
  if (info.file.status === "done") {
    // Get this url from response in real world.
    // getBase64(info.file.originFileObj, (url) => {
    //   setLoading(false);
    //   setImageUrl(url);
    // });
     setLoading(false);
    setImageUrl(info.file.originFileObj);
  }
};
const uploadButton = (
  <div>
    {loading ? <LoadingOutlined /> : <PlusOutlined />}
    <div
      style={{
        marginTop: 8,
      }}
    >
      Upload
    </div>
  </div>
);



console.log(imageUrl);

const user = JSON.parse(localStorage.getItem("persist:root"))?.user;
const addedby = user && JSON.parse(user).user?.user?._id;
const company = user && JSON.parse(user).user?.user?.company;
const api = new API();

  const addNewCategory = (values) => {
    values["categoryimage"] = imageUrl;
     values["addedby"] = addedby;
     values["company"] = company;
    values["categoryname"] = categoryTitle.trim();
    values["categoryslug"] = categoryTitle.trim()
      .toLowerCase()
      .replace(/ /g, "-")
      .replace(/[^\w-]+/g, "");
    console.log(values)
    // api
    //   .addCategory(values)
    //   .then((res) => {
    //     setSaving(true);
    //     let data = res.data;
    //     console.log(data);
    //     if (data.status === 200) {
    //       form.resetFields();
    //       setImageUrl();
    //       message.success("Category Added Successfully");
    //       setSaving(false);
    //     } else {
    //       message.error(data.message);
    //       setSaving(false);
    //     }
    //   })
    //   .catch((err) => {
    //     message.error("Something went wrong!");
    //     setSaving(false);
    //   });

  }

  return (
    <React.Fragment>
      <ProductCategorySection>
        <div className="product_category_align">
          <div className="product_category_left">
            <h4>Create New Category</h4>
            <Form
              layout="vertical"
              size="medium"
              name="add_new_product"
              onFinish={addNewCategory}
              form={form}
            >
              <Form.Item
                label="Enter Category Name"
                onChange={(e) => setCategoryTitle(e.target.value.trim())}
                tooltip="Category Name"
                name="c_title"
                rules={[
                  {
                    required: true,
                    message: "Please enter category name",
                  },
                ]}
              >
                <Input placeholder="Category name" />
              </Form.Item>
              <Form.Item
                label="Parent Category"
                layout="inline"
                name="parentcategory"
                tooltip="Parent Category"
              >
                <Select placeholder="Parent Category" allowClear>
                  <Option value="simple">Simple Product</Option>
                  <Option value="varible">Varible Product</Option>
                </Select>
              </Form.Item>
              <Form.Item
                label="Category Description"
                name="categorydescription"
                tooltip="Category Description"
              >
                <TextArea placeholder="Category Description" rows={4} />
              </Form.Item>
              <div className="cat_upload">
                <p>Category Thumbnail</p>
                <Upload
                  name="categoryimage"
                  listType="picture-card"
                  className="avatar-uploader"
                  showUploadList={false}
                  action={process.env.REACT_APP_API}
                  beforeUpload={beforeUpload}
                  onChange={handleChange}
                >
                  {imageUrl ? (
                    <img
                      src={imageUrl}
                      alt="avatar"
                      style={{
                        width: "100%",
                      }}
                    />
                  ) : (
                    uploadButton
                  )}
                </Upload>
              </div>
              <Button
                type="primary"
                size="medium"
                htmlType="submit"
                loading={saving}
              >
                <SafetyOutlined />
                Create New
              </Button>
            </Form>
          </div>
          <div className="product_category_right">
            <h4>All Categories</h4>
          </div>
        </div>
      </ProductCategorySection>
    </React.Fragment>
  );
};

export default ProductCategory;

const ProductCategorySection = styled.section`
  display: inline-block;
  width: 100%;
  position: relative;

  .product_category_align {
    display: inline-block;
    width: 100%;
  }

  .product_category_left {
    padding: 24px;
    box-shadow: 2px 4px 20px 1px rgb(201 201 201 / 30%);
    background: #fff;
    display: inline-block;
    width: 32%;
    border-radius: 5px;
    float: left;
  }
  .product_category_right {
    padding: 24px;
    box-shadow: 2px 4px 20px 1px rgb(201 201 201 / 30%);
    background: #fff;
    display: inline-block;
    width: 66%;
    border-radius: 5px;
    float: right;
  }
  h4 {
    font-size: 18px;
    font-weight: 600;
    margin: 0 0 20px;
  }
  .cat_upload {
    margin: 0 0 20px;
    display: inline-block;
    width: 100%;
  }
  .ant-upload.ant-upload-select-picture-card,
  .ant-upload-list-picture-card-container {
    width: 85px !important;
    height: 85px !important;
  }
`;

import React, { useState } from "react";
import styled from "styled-components";
import { message,Button, Form, Input } from "antd";
import { LockOutlined, UserOutlined, LoginOutlined } from "@ant-design/icons";
import User from "../../Store/Actions/UserAction";
import { useDispatch } from "react-redux";

const Login = () => {
  const [form] = Form.useForm();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [saving, setSaving] = useState(false);
  const api = new User();
  const dispatch = useDispatch();
  const onFinish = (values) => {
     values["company"] = api.company;
     setSaving(true);
     api
       .login(dispatch, values)
       .then((res) => {
         let data = res.data;
         if (data.status === 200) {
           form.resetFields();
           message.success("Logged in successfully");
          window.location.reload()
           setSaving(false);
         } else {
           message.error(data.message);
           setSaving(false);
         }
       })
       .catch((err) => {
         message.error("Something went wrong!");
         setSaving(false);
       });
  };


  return (
    <React.Fragment>
      <LoginSection>
        <LoginAlign>
          <LoginRight>
            <H1>Admin Login</H1>
            <Form
              form={form}
              name="admin_login"
              layout="vertical"
              onFinish={onFinish}
              autoComplete="off"
            >
              <Form.Item
                name="email"
                values={email}
                onChange={(event) => setEmail(event.target.values)}
                rules={[
                  {
                    required: true,
                    message: "Please enter valid Email ID",
                  },
                ]}
              >
                <Input
                  prefix={<UserOutlined className="site-form-item-icon" />}
                  placeholder="Email ID"
                />
              </Form.Item>

              <Form.Item
                name="password"
                values={password}
                onChange={(event) => setPassword(event.target.values)}
                rules={[
                  {
                    required: true,
                    message: "Please enter valid password!",
                  },
                ]}
              >
                <Input.Password
                  prefix={<LockOutlined className="site-form-item-icon" />}
                  placeholder="Password"
                />
              </Form.Item>

              <Button type="primary" htmlType="submit" loading={saving}>
                <LoginOutlined /> Sign In
              </Button>
            </Form>
          </LoginRight>
        </LoginAlign>
      </LoginSection>
    </React.Fragment>
  );
};

export default Login;

const LoginSection = styled.div`
  display: flex;
  height: 100vh;
  width: 100%;
  overflow: auto;
  align-items: center;
  justify-content: center;
  padding: 50px 20px;
  .ant-input-prefix {
      color: #d9d9d9;
    margin: 0 8px 0 0;
}
`;
const LoginAlign = styled.div`
  display: flex;
  align-items: center;
  gap: 0;
  flex-wrap: wrap;
  width: 350px;
  justify-content: space-between;
  background: linear-gradient(to right, #fff 35%, #fff 35%);
  box-shadow: 0 0 45px rgb(0 0 0 / 10%);
  border-radius: 10px;

  @media screen and (max-width: 768px) {
    width: 450px;
    background: #fff;
  }

  @media screen and (max-width: 480px) {
    width: 100%;
    background: #fff;
  }
`;

const LoginRight = styled.div`
  width: 100%;
  display: inline-block;
  padding: 30px 30px;


  @media screen and (max-width: 768px) {
    width: 100%;
  }
  @media screen and (max-width: 480px) {
    padding: 40px 25px;
  }
`;



const H1 = styled.h1`
font-size: 25px !important;
margin: 0 0 25px !important;
text-transform: capitalize;
`;

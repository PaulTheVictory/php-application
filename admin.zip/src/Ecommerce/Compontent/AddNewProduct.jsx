import React, { useState, useEffect } from "react";
import {
  Button,
  Form,
  Input,
  Select,
  Tabs,
  Space,
  Divider,
  Checkbox,
  Row,
  Col,
  Modal,
  Upload,
  message,
} from "antd";
import styled from 'styled-components';
import ReactQuill from "react-quill";
import "react-quill/dist/quill.snow.css";
import API from "../../Api/ApiService"
import {
  SafetyOutlined,
  ToolOutlined,
  TagOutlined,
  ApartmentOutlined,
  ProfileOutlined,
  SettingOutlined,
  MinusCircleOutlined,
  PlusOutlined,
  HighlightOutlined,
  AccountBookOutlined,
} from "@ant-design/icons";
const { TextArea } = Input;
const { Option } = Select;




const AddNewProduct = () => {
  const [value, setValue] = useState("");
  const [form] = Form.useForm();
  const [productTitle, setProductTitle] = useState("");
   const [previewOpen, setPreviewOpen] = useState(false);
   const [previewImage, setPreviewImage] = useState("");
  const [previewTitle, setPreviewTitle] = useState("");
  const [imgGallery, setImgGallery] = useState([]);
  const [fileList, setFileList] = useState([]);
  const [saving, setSaving] = useState(false);
  const [isModalOpen, setIsModalOpen] = useState(false);
  
const handleCancel = () => setPreviewOpen(false);
  const handlePreview = async (file) => {
  
  if (!file.url && !file.preview) {
    file.preview = await getBase64(file.originFileObj);
  }
  setPreviewImage(file.url || file.preview);
  setPreviewOpen(true);
  setPreviewTitle(
    file.name || file.url.substring(file.url.lastIndexOf("/") + 1)
  );
  };
  const getBase64 = (file) =>
    new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => resolve(reader.result);
      reader.onerror = (error) => reject(error);
    });
const handleChange = ({ fileList: newFileList }) => setFileList(newFileList);
 const uploadButton = (
   <div>
     <PlusOutlined />
     <div
       style={{
         marginTop: 8,
       }}
     >
       Upload
     </div>
   </div>
 );
const beforeUpload = (file) => {
  const isJpgOrPng =
    file.type === "image/jpeg" ||
    file.type === "image/png" ||
    file.type === "image/webp" ||
    file.type === "image/jpg";
  if (!isJpgOrPng) {
    message.error("You can only upload JPG/PNG/WEBP file!");
  }
  const isLt2M = file.size / 1024 / 1024 < 2;
  if (!isLt2M) {
    message.error("Image must smaller than 2MB!");
  }
  return isJpgOrPng && isLt2M;
  };
  
const showModal = () => {
  setIsModalOpen(true);
};
const handleOk = () => {
  setIsModalOpen(false);
};
const handleCancel1 = () => {
  setIsModalOpen(false);
};
const user = JSON.parse(localStorage.getItem("persist:root"))?.user;
const addedby = user && JSON.parse(user).user?.user?._id;
const company = user && JSON.parse(user).user?.user?.company;
  const api = new API();

  
  const addNewProduct = (values) => {
    values["description"] = value;
    values["addedby"] = addedby;
    values["company"] = company;
    values["title"] = productTitle.trim();
    values["slug"] = productTitle
      .trim()
      .toLowerCase()
      .replace(/ /g, "-")
      .replace(/[^\w-]+/g, "");
    values["image"] = fileList;
    
    api
      .addProduct(values)
      .then((res) => {
        let data = res.data;
        console.log(data);
        if (data.status === 200) {
          form.resetFields();
          setValue("");
          setFileList([]);
          message.success("Product Added Successfully");
          setSaving(false);
        } else {
          message.error(data.message);
          setSaving(false);
        }
      })
      .catch((err) => {
        message.error("Something went wrong!");
        setSaving(false);
      });
  }
  



  
  
  return (
    <React.Fragment>
      <Form
        layout="vertical"
        size="medium"
        name="add_new_product"
        onFinish={addNewProduct}
        form={form}
      >
        <NewProductSection>
          <NewProductLeft>
            <BgWight>
              <Form.Item
                label="Enter Product Name"
                values={productTitle}
                onChange={(e) => setProductTitle(e.target.value.trim())}
                tooltip="Product Name"
                name="p_title"
                rules={[
                  {
                    required: true,
                    message: "Please enter product name",
                  },
                  
                ]}
              >
                <Input placeholder="Product name" />
              </Form.Item>
              <Form.Item
                label="Product Description"
                tooltip="Product Description"
              >
                <ReactQuill
                  theme="snow"
                  value={value}
                  onChange={setValue}
                  className="pro_dec"
                />
              </Form.Item>
            </BgWight>
            <BgWight>
              <Form.Item
                label="Product Type"
                layout="inline"
                name="producttype"
                tooltip="Product Type"
                rules={[
                  {
                    required: true,
                    message: "Please choose product type",
                  },
                ]}
              >
                <Select placeholder="Product Type" allowClear>
                  <Option value="simple">Simple Product</Option>
                  <Option value="varible">Varible Product</Option>
                </Select>
              </Form.Item>
              <Form.Item label="Product Data" tooltip="Product Data">
                <MyAccountAlign>
                  <Tabs defaultActiveKey="1" tabPosition="left">
                    <Tabs.TabPane
                      tab={
                        <>
                          <ToolOutlined />
                          General
                        </>
                      }
                      key="1"
                    >
                      <Dimension2>
                        <Form.Item
                          label="Regular price"
                          name="mrp"
                          className="flex_row"
                        >
                          <Input placeholder="Regular Price" />
                        </Form.Item>
                        <Form.Item
                          label="Sale price"
                          name="sp"
                          className="flex_row"
                        >
                          <Input placeholder="Sale Price" />
                        </Form.Item>

                        <Form.Item
                          label="SKU"
                          name="sku"
                          className="flex_row"
                          tooltip="Product SKU"
                          rules={[
                            {
                              required: true,
                              message: "Please enter SKU ID",
                            },
                          ]}
                        >
                          <Input placeholder="SKU ID" />
                        </Form.Item>
                        <Form.Item
                          label="Brand Name"
                          layout="inline"
                          name="brandname"
                          tooltip="Brand Name"
                        >
                          <Select placeholder="Choose Brand Name" allowClear>
                            <Option value="Paul">Paul</Option>
                          </Select>
                        </Form.Item>
                        <Form.Item
                          label="Model ID"
                          name="model"
                          className="flex_row"
                          tooltip="Model ID"
                        >
                          <Input placeholder="Model id" />
                        </Form.Item>

                        <Form.Item
                          label="Delivery Date"
                          name="deliverydate"
                          className="flex_row"
                          tooltip="Delivery Date"
                        >
                          <Input placeholder="Delivery Date" />
                        </Form.Item>
                      </Dimension2>
                    </Tabs.TabPane>

                    <Tabs.TabPane
                      tab={
                        <>
                          <TagOutlined />
                          Inventory
                        </>
                      }
                      key="2"
                    >
                      <Dimension2>
                        <Form.Item
                          label="Stock Quantity"
                          name="stockquantity"
                          className="flex_row"
                          tooltip="Stock Quantity"
                        >
                          <Input placeholder="Stock Quantity" />
                        </Form.Item>
                        <Form.Item
                          label="Stock Status"
                          layout="inline"
                          name="managestock"
                          tooltip="Stock Status"
                        >
                          <Select placeholder="Choose stock status" allowClear>
                            <Option value="instock">In Stock</Option>
                            <Option value="outofstock">Out of Stock</Option>
                          </Select>
                        </Form.Item>
                      </Dimension2>
                    </Tabs.TabPane>
                    <Tabs.TabPane
                      tab={
                        <>
                          <ApartmentOutlined />
                          Shipping
                        </>
                      }
                      key="3"
                    >
                      <Dimension2>
                        <Form.Item
                          label="Weight Type"
                          layout="inline"
                          name="weighttype"
                          tooltip="Choose weight type"
                        >
                          <Select placeholder="Choose weight type" allowClear>
                            <Option value="kg">kg</Option>
                            <Option value="grams">grams</Option>
                            <Option value="litres">litres</Option>
                          </Select>
                        </Form.Item>
                        <Form.Item
                          label="Weight Value"
                          tooltip="Weight Value"
                          name="weightvalue"
                          className="flex_row"
                        >
                          <Input placeholder="Weight" />
                        </Form.Item>
                      </Dimension2>
                      <Dimension2>
                        <Form.Item
                          label="Choose Dimension Type"
                          layout="inline"
                          name="dimensionstype"
                          tooltip="Choose Dimension Type"
                        >
                          <Select
                            placeholder="Choose Dimension Type"
                            allowClear
                          >
                            <Option value="meter">meter</Option>
                            <Option value="cm">cm</Option>
                          </Select>
                        </Form.Item>
                        <Form.Item
                          label="Length Value"
                          tooltip="Length Value"
                          name="dimensionslength"
                          className="flex_row"
                        >
                          <Input placeholder="Length" />
                        </Form.Item>
                        <Form.Item
                          label="Width Value"
                          tooltip="Width Value"
                          name="dimensionswidth"
                          className="flex_row"
                        >
                          <Input placeholder="Width" />
                        </Form.Item>
                        <Form.Item
                          label="Height Value"
                          tooltip="Height Value"
                          name="dimensionsheight"
                          className="flex_row"
                        >
                          <Input placeholder="Height" />
                        </Form.Item>
                      </Dimension2>
                    </Tabs.TabPane>
                    <Tabs.TabPane
                      tab={
                        <>
                          <ProfileOutlined />
                          Specification
                        </>
                      }
                      key="4"
                    >
                      <Form.List name="specification">
                        {(fields, { add, remove }) => (
                          <>
                            {fields.map(({ key, name, ...restField }) => (
                              <Space
                                key={key}
                                style={{
                                  display: "flex",
                                  marginBottom: 8,
                                }}
                                align="baseline"
                              >
                                <Form.Item
                                  {...restField}
                                  name={[name, "sname"]}
                                  rules={[
                                    {
                                      required: true,
                                      message: "Enter Name",
                                    },
                                  ]}
                                >
                                  <Input
                                    placeholder="Enter Name"
                                    style={{ width: "150px" }}
                                  />
                                </Form.Item>
                                <Form.Item
                                  {...restField}
                                  name={[name, "svalue"]}
                                  rules={[
                                    {
                                      required: true,
                                      message: "Enter Description",
                                    },
                                  ]}
                                >
                                  <Input
                                    placeholder="Enter Description"
                                    style={{ width: "300px" }}
                                  />
                                </Form.Item>
                                <MinusCircleOutlined
                                  onClick={() => remove(name)}
                                />
                              </Space>
                            ))}
                            <Form.Item>
                              <Button
                                type="dashed"
                                onClick={() => add()}
                                block
                                icon={<PlusOutlined />}
                              >
                                Add Specification
                              </Button>
                            </Form.Item>
                          </>
                        )}
                      </Form.List>
                    </Tabs.TabPane>
                    <Tabs.TabPane
                      tab={
                        <>
                          <HighlightOutlined />
                          Highlights
                        </>
                      }
                      key="7"
                    >
                      <Form.List name="highlights">
                        {(fields, { add, remove }) => (
                          <>
                            {fields.map(({ key, name, ...restField }) => (
                              <Space
                                key={key}
                                style={{
                                  display: "flex",
                                  marginBottom: 8,
                                }}
                                align="baseline"
                              >
                                <Form.Item
                                  {...restField}
                                  name={[name, "hname"]}
                                  rules={[
                                    {
                                      required: true,
                                      message: "Enter Name",
                                    },
                                  ]}
                                >
                                  <Input placeholder="Enter Name" />
                                </Form.Item>
                                <Form.Item
                                  {...restField}
                                  name={[name, "hvalue"]}
                                  rules={[
                                    {
                                      required: true,
                                      message: "Enter Description",
                                    },
                                  ]}
                                >
                                  <Input placeholder="Enter Description" />
                                </Form.Item>
                                <MinusCircleOutlined
                                  onClick={() => remove(name)}
                                />
                              </Space>
                            ))}
                            <Form.Item>
                              <Button
                                type="dashed"
                                onClick={() => add()}
                                block
                                icon={<PlusOutlined />}
                              >
                                Add Highlights
                              </Button>
                            </Form.Item>
                          </>
                        )}
                      </Form.List>
                    </Tabs.TabPane>
                    <Tabs.TabPane
                      tab={
                        <>
                          <AccountBookOutlined />
                          Tax and GST
                        </>
                      }
                      key="9"
                    >
                      <Dimension2>
                        <Form.Item
                          label="Tax Persentage"
                          layout="inline"
                          name="texpersentage"
                          tooltip="Tax Persentage"
                        >
                          <Select
                            placeholder="Choose Tax Persentage"
                            allowClear
                          >
                            <Option value="18">18</Option>
                          </Select>
                        </Form.Item>
                        <Form.Item
                          label="HSN Code"
                          name="hsncode"
                          className="flex_row"
                          tooltip="HSN Code"
                        >
                          <Input placeholder="HSN Code" />
                        </Form.Item>
                      </Dimension2>
                    </Tabs.TabPane>
                    <Tabs.TabPane
                      tab={
                        <>
                          <SettingOutlined />
                          Advanced
                        </>
                      }
                      key="5"
                    >
                      <Form.Item
                        label="Purchase Notes"
                        name="purchasenote"
                        tooltip="Purchase Notes"
                      >
                        <TextArea rows={4} />
                      </Form.Item>
                      <Dimension2>
                        <Form.Item
                          label="Product Visible Type"
                          layout="inline"
                          name="visible"
                          tooltip="Product Visible Type"
                        >
                          <Select placeholder="Choose Visible Type" allowClear>
                            <Option value="true">True</Option>
                            <Option value="false">False</Option>
                          </Select>
                        </Form.Item>
                        <Form.Item
                          label="Product Publish Type"
                          layout="inline"
                          name="publish"
                          tooltip="Product Publish Type"
                        >
                          <Select placeholder="Choose Publish Type" allowClear>
                            <Option value="true">True</Option>
                            <Option value="false">False</Option>
                          </Select>
                        </Form.Item>
                      </Dimension2>
                    </Tabs.TabPane>
                  </Tabs>
                </MyAccountAlign>
              </Form.Item>
            </BgWight>
          </NewProductLeft>
          <NewProductRight>
            <PublishRow>
              <Text></Text>
              <Button
                type="primary"
                size="medium"
                htmlType="submit"
                loading={saving}
              >
                <SafetyOutlined />
                Publish
              </Button>
            </PublishRow>
            <Divider />
            <H4>Product Categories</H4>
            <CatsBox className="catboxs">
              <Checkbox.Group>
                <Row>
                  <Col span={24}>
                    <Checkbox value="Category Name1">Category Name</Checkbox>
                  </Col>
                  <Col span={24}>
                    <Checkbox value="Category Name2">Category Name</Checkbox>
                  </Col>
                  <Col span={24}>
                    <Checkbox value="Category Name3">Category Name</Checkbox>
                  </Col>
                  <Col span={24}>
                    <Checkbox value="Category Name4">Category Name</Checkbox>
                  </Col>
                  <Col span={24}>
                    <Checkbox value="Category Name5">Category Name</Checkbox>
                  </Col>
                  <Col span={24}>
                    <Checkbox value="Category Name6">Category Name</Checkbox>
                  </Col>
                  <Col span={24}>
                    <Checkbox value="Category Name7">Category Name</Checkbox>
                  </Col>
                  <Col span={24}>
                    <Checkbox value="Category Name8">Category Name</Checkbox>
                  </Col>
                  <Col span={24}>
                    <Checkbox value="Category Name9">Category Name</Checkbox>
                  </Col>
                </Row>
              </Checkbox.Group>
            </CatsBox>
            <CatsNew>
              <Button type="dashed" block onClick={showModal}>
                <PlusOutlined />
                Add New Category
              </Button>
              <Modal
                title="Add New Category"
                open={isModalOpen}
                onOk={handleOk}
                onCancel={handleCancel1}
                footer={null}
              >
                <p>Some contents...</p>
                <p>Some contents...</p>
                <p>Some contents...</p>
              </Modal>
            </CatsNew>
            <Divider />
            <Thumbnail>
              <H4>Product Image</H4>
              <Upload
                action={process.env.REACT_APP_API}
                listType="picture-card"
                fileList={fileList}
                multiple
                name="image"
                onPreview={handlePreview}
                beforeUpload={beforeUpload}
                onChange={handleChange}
              >
                {fileList.length >= 5 ? null : uploadButton}
              </Upload>
              <Modal
                open={previewOpen}
                title={previewTitle}
                footer={null}
                onCancel={handleCancel}
              >
                <img
                  alt="example"
                  style={{
                    width: "100%",
                  }}
                  src={previewImage}
                />
              </Modal>
            </Thumbnail>
          </NewProductRight>
        </NewProductSection>
      </Form>
    </React.Fragment>
  );
}

export default AddNewProduct;



const Dimension2 = styled.div`
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 0 24px;
  align-items: flex-end;
`;

const CatsNew = styled.div`
width:100%;
margin: 20px 0 0 0;







`;

const Thumbnail = styled.div``;

const H4 = styled.div`
font-size: 20px;
font-weight: 600;
margin: 0 0 20px;
`;
const CatsBox = styled.div`
  height: 215px;
  overflow: auto;
  border: 1px solid #d9d9d9;
  padding: 20px;
  border-radius: 4px;
  .ant-col-24 {
    margin: 0 0 10px;
  }


`;

const PublishRow = styled.div`
display: flex;
align-items: center;
justify-content: space-between;
gap: 15px;
`;
const Text = styled.div``

const NewProductSection = styled.div`
  display: flex;
  align-items: flex-start;
  justify-content: space-between;

  .pro_dec {
    height: 200px;
    margin: 0 0 24px;
  }

  .ant-tabs-left
    > .ant-tabs-content-holder
    > .ant-tabs-content
    > .ant-tabs-tabpane,
  .ant-tabs-left
    > div
    > .ant-tabs-content-holder
    > .ant-tabs-content
    > .ant-tabs-tabpane {
    padding: 24px;
  }

  .ant-form-item.flex_row .ant-row.ant-form-item-row {
    display: flex !important;
    flex-direction: row !important;
  }
  .ant-form-item.flex_row
    .ant-row.ant-form-item-row
    .ant-col-24.ant-form-item-label,
  .ant-col-xl-24.ant-form-item-label,
  .ant-form-vertical .ant-form-item-label {
    flex: 1 !important;
  }
  .ant-form-item.flex_row
    .ant-row.ant-form-item-row
    .ant-form-vertical
    .ant-form-item
    .ant-form-item-control {
    width: 100% !important;
    flex: 3 !important;
  }
  /* width */
  .catboxs::-webkit-scrollbar {
    width: 5px;
  }

  /* Track */
  .catboxs::-webkit-scrollbar-track {
    background: #f1f1f1;
  }

  /* Handle */
  .catboxs::-webkit-scrollbar-thumb {
    background: #888;
    border-radius: 5px;
  }

  /* Handle on hover */
  .catboxs::-webkit-scrollbar-thumb:hover {
    background: #555;
  }
`;
const MyAccountAlign = styled.div`
  width: 100%;
  display: inline-block;
  position: relative;
  margin: 10px 0 0 0;
  border: 1px solid #d9d9d97a;
  .ant-tabs.ant-tabs-left {
    padding: 0px 0;
  }
  .ant-tabs-content-holder {
    padding: 20px 0;
  }
  .ant-tabs-tab {
    padding: 4px 20px !important;
    font-size: 14px;

    width: 200px;
    color: #000;
  }
  .ant-tabs > .ant-tabs-nav .ant-tabs-nav-list,
  .ant-tabs > div > .ant-tabs-nav .ant-tabs-nav-list {
    padding: 15px 0;
  }
  .ant-tabs-tab.ant-tabs-tab-active .ant-tabs-tab-btn {
    color: rgb(13 110 253);
    font-weight: 400;
    font-size: 14px;
  }
  .ant-tabs-tab-btn,
  .ant-tabs-tab-btn,
  .ant-tabs-tab-remove,
  .ant-tabs-tab-remove {
    font-weight: 400;
    font-size: 14px;
  }
  .ant-tabs-ink-bar {
    background: rgb(13 110 253);
  }
  
`;
const NewProductLeft = styled.div`
  width: 70%;
  display: flex;
  flex-direction: column;
  gap: 30px;
  position: relative;
  /* padding: 24px; */
  /* box-shadow: 2px 4px 20px 1px rgb(201 201 201 / 30%);
  background: #fff; */
  min-height: 550px;
  
`;

const BgWight = styled.div`
  padding: 24px;
  box-shadow: 2px 4px 20px 1px rgb(201 201 201 / 30%);
  background: #fff;
  display: inline-block;
  width: 100%;
  border-radius: 5px;
`;
const NewProductRight = styled.div`
  width: 27%;
  display: inline-block;
  position: relative;
  padding: 24px;
  box-shadow: 2px 4px 20px 1px rgb(201 201 201 / 30%);
  background: #fff;
  min-height: 550px;
  border-radius: 8px;
  .ant-upload.ant-upload-select-picture-card,
  .ant-upload-list-picture-card-container {
    width: 85px !important;
    height: 85px !important;
  }
`;

import React from "react";
import styled from "styled-components";

const PagesDetails = () => {
  return (
    <React.Fragment>
      <RecentUpdateSection>
        <Title>Overview</Title>
        <ul className="count_pages">
          <li>
            <span>Pages</span>
            <span>14</span>
          </li>
          <li>
            <span>Blog Posts</span>
            <span>17</span>
          </li>
          <li>
            <span>Products</span>
            <span>57</span>
          </li>
          <li>
            <span>Users</span>
            <span>35</span>
          </li>
          <li>
            <span>Vendors</span>
            <span>55</span>
          </li>
        </ul>
      </RecentUpdateSection>
    </React.Fragment>
  );
};

export default PagesDetails;

const RecentUpdateSection = styled.div`
  width: 100%;
  display: inline-block;
  position: relative;
  ul {
    padding: 0;
    display: flex;
    flex-direction: column;
    gap: 15px;
    list-style: none;
  }
  li {
    font-size: 15px;
    color: #000;
    font-weight: 600;
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 0 0 15px;
    border-bottom: 0px solid #f5f5f5;
  }
  li:last-child {
    padding: 0;
  }
  
  li span:nth-child(2) {
    height: 30px;
    min-width: 30px;
    padding: 0 7px;
    border-radius: 5px;
    display: flex;
    align-items: center;
    justify-content: center;
    text-align: center;
    font-size: 14px;
    font-weight: 600;
  }
  li:nth-child(1) span:nth-child(2) {
    color: crimson;
    background: rgb(237 20 61 / 20%);
  }
  li:nth-child(2) span:nth-child(2) {
    color: goldenrod;
    background: rgb(218 165 32 / 20%);
  }
  li:nth-child(3) span:nth-child(2) {
    color: green;
    background: rgb(0 128 0 / 20%);
  }
  li:nth-child(4) span:nth-child(2) {
    color: purple;
    background: rgb(128 0 128 / 20%);
  }
  li:nth-child(5) span:nth-child(2) {
    color: blue;
    background: rgb(0 0 255 / 20%);
  }
`;
const Title = styled.div`
  font-size: 20px;
  font-weight: 600;
  color: #000;
  margin: 0 0 20px;
`;

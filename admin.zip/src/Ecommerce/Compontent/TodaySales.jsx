
import React from 'react'
import {

  AreaChart,
  Area,
  XAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts";
import styled from "styled-components";
const data = [
  { name: "January", Total: 1200 },
  { name: "February", Total: 2100 },
  { name: "March", Total: 800 },
  { name: "April", Total: 1600 },
  { name: "May", Total: 900 },
  { name: "June", Total: 1700 },
];


const TodaySales = ({ aspect }) => {
  return (
    <React.Fragment>
      <ChartSection>
        
        <ChartTitle>Last 6 Months (Revenue)</ChartTitle>
        
        <ResponsiveContainer width="100%" aspect={aspect}>
          <AreaChart
            width={730}
            height={250}
            data={data}
            margin={{ top: 10, right: 30, left: 0, bottom: 0 }}
          >
            <defs>
              <linearGradient id="total" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#8884d8" stopOpacity={0.8} />
                <stop offset="95%" stopColor="#8884d8" stopOpacity={0} />
              </linearGradient>
            </defs>
            <XAxis dataKey="name" stroke="gray" />
            <CartesianGrid strokeDasharray="3 3" className="chartGrid" />
            <Tooltip />
            <Area
              type="monotone"
              dataKey="Total"
              stroke="#8884d8"
              fillOpacity={1}
              fill="url(#total)"
            />
          </AreaChart>
        </ResponsiveContainer>
      </ChartSection>
    </React.Fragment>
  );
};

export default TodaySales


const ChartSection = styled.div`
  width: 100%;
  height: 340px;
  padding: 0px;
  background: #fff;
  margin: 0 0 50px;
  .chart {
    flex: 4;
    -webkit-box-shadow: 2px 4px 10px 1px rgba(0, 0, 0, 0.47);
    box-shadow: 2px 4px 10px 1px rgba(201, 201, 201, 0.47);
    padding: 10px;
    color: gray;

    .chartGrid {
      stroke: rgb(228, 225, 225);
    }
  }
  .recharts-wrapper {
    width: 100% !important;
  }
`;
const ChartTitle = styled.div`
  font-size: 20px;
  font-weight: 600;
  color: #000;
  margin: 0 0 24px;
`;
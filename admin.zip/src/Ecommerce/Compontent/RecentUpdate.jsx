import React from 'react'
import styled from 'styled-components';

const RecentUpdate = () => {
  return (
    <React.Fragment>
      <RecentUpdateSection>
        <Title>Recent Updates</Title>
        <p>No updates available..</p>
      </RecentUpdateSection>
    </React.Fragment>
  );
}

export default RecentUpdate

const RecentUpdateSection = styled.div``;
const Title = styled.div`
  font-size: 20px;
  font-weight: 600;
  color: #000;
  margin: 0 0 20px;
`;
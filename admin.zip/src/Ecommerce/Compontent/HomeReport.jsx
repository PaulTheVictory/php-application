import React from "react";
import styled from "styled-components";
import PersonOutlineIcon from "@mui/icons-material/PersonOutline";
import ShoppingCartOutlinedIcon from "@mui/icons-material/ShoppingCartOutlined";
import MonetizationOnOutlinedIcon from "@mui/icons-material/MonetizationOnOutlined";
import AccountBalanceWalletOutlinedIcon from "@mui/icons-material/AccountBalanceWalletOutlined";
import ArrowUpwardIcon from "@mui/icons-material/ArrowUpward";
const HomeReport = () => {
  return (
    <React.Fragment>
      <HomeReportBox>
        <ReportBox>
          <ReportBoxLeft>
            <Title>USERS</Title>
            <Value>100</Value>
            <Btn>See all users</Btn>
          </ReportBoxLeft>
          <ReportBoxRight>
            <Percentage>
              <ArrowUpwardIcon />
              20%
            </Percentage>
            <BoxIcon className="box_pr1">
              <PersonOutlineIcon />
            </BoxIcon>
          </ReportBoxRight>
        </ReportBox>
        <ReportBox>
          <ReportBoxLeft>
            <Title>ORDERS</Title>
            <Value>100</Value>
            <Btn>View all orders</Btn>
          </ReportBoxLeft>
          <ReportBoxRight>
            <Percentage>
              <ArrowUpwardIcon />
              20%
            </Percentage>
            <BoxIcon className="box_pr2">
              <ShoppingCartOutlinedIcon />
            </BoxIcon>
          </ReportBoxRight>
        </ReportBox>
        <ReportBox>
          <ReportBoxLeft>
            <Title>EARNINGS</Title>
            <Value>$100</Value>
            <Btn>View net earnings</Btn>
          </ReportBoxLeft>
          <ReportBoxRight>
            <Percentage>
              <ArrowUpwardIcon />
              20%
            </Percentage>
            <BoxIcon className="box_pr3">
              <MonetizationOnOutlinedIcon />
            </BoxIcon>
          </ReportBoxRight>
        </ReportBox>
        <ReportBox>
          <ReportBoxLeft>
            <Title>BALANCE</Title>
            <Value>$100</Value>
            <Btn>See details</Btn>
          </ReportBoxLeft>
          <ReportBoxRight>
            <Percentage>
              <ArrowUpwardIcon />
              20%
            </Percentage>
            <BoxIcon className="box_pr4">
              <AccountBalanceWalletOutlinedIcon />
            </BoxIcon>
          </ReportBoxRight>
        </ReportBox>
      </HomeReportBox>
    </React.Fragment>
  );
};

export default HomeReport;

const HomeReportBox = styled.div`
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 24px;
  .box_pr1 {
    color: crimson;
    background-color: rgba(255, 0, 0, 0.2);
  }
  .box_pr2 {
    background-color: rgba(218, 165, 32, 0.2);
    color: goldenrod;
  }
  .box_pr3 {
    background-color: rgba(0, 128, 0, 0.2);
    color: green;
  }
  .box_pr4 {
    background-color: rgba(128, 0, 128, 0.2);
    color: purple;
  }
`;
const ReportBox = styled.div`
  display: flex;
  box-shadow: 2px 4px 20px 1px rgb(201 201 201 / 30%);
  min-height: 135px;
  width: 100%;
  background: #fff;
  border-radius: 8px;
  padding: 14px 14px;
  justify-content: space-between;
  
`;
const ReportBoxLeft = styled.div`
  display: flex;
  flex-direction: column;
  justify-content: space-between;
`;
const ReportBoxRight = styled.div`
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  text-align: end;
  align-items: flex-end;
`;

const Title = styled.div`
  color: rgb(160, 160, 160);
  font-weight: 600;
  letter-spacing: 0.5px;
`;
const Value = styled.div`
  font-size: 26px;
  color: #000;
  font-weight: 700;
`;
const Btn = styled.div`
  font-size: 13px;
  border-bottom: 1px solid gray;
  font-style: italic;
`;
const Percentage = styled.div`
  color: green;
  font-size: 14px;
  font-weight: 400;
  display: flex;
  align-items: center;
  gap: 1px;
  svg {
    font-size: 16px;
  }
`;
const BoxIcon = styled.div`
  color: crimson;
  background-color: rgba(255, 0, 0, 0.2);
  height: 32px;
  width: 32px;
  border-radius: 4px;
  align-items: center;
  display: flex;
  justify-content: center;
  font-size: 14px;
 
`;

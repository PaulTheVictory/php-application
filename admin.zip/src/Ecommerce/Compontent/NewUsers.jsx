import React, { useRef, useState, useEffect } from "react";
import styled from "styled-components";
import { SearchOutlined, UserOutlined } from "@ant-design/icons";
import { Button, Input, Space, Table, Tag } from "antd";
import Highlighter from "react-highlight-words";
import User from "../../Store/Actions/UserAction";
import moment from "moment";

const NewUsers = () => {
  const [searchText, setSearchText] = useState("");
  const [searchedColumn, setSearchedColumn] = useState("");
  const [userData, setUserData] = useState([]);
  const searchInput = useRef(null);
  const handleSearch = (selectedKeys, confirm, dataIndex) => {
    confirm();
    setSearchText(selectedKeys[0]);
    setSearchedColumn(dataIndex);
  };
  const handleReset = (clearFilters) => {
    clearFilters();
    setSearchText("");
  };
  const getColumnSearchProps = (dataIndex) => ({
    filterDropdown: ({
      setSelectedKeys,
      selectedKeys,
      confirm,
      clearFilters,
    }) => (
      <div
        style={{
          padding: 8,
        }}
      >
        <Input
          ref={searchInput}
          placeholder={`Search ${dataIndex}`}
          value={selectedKeys[0]}
          onChange={(e) =>
            setSelectedKeys(e.target.value ? [e.target.value] : [])
          }
          onPressEnter={() => handleSearch(selectedKeys, confirm, dataIndex)}
          style={{
            marginBottom: 8,
            display: "block",
          }}
        />
        <Space>
          <Button
            type="primary"
            onClick={() => handleSearch(selectedKeys, confirm, dataIndex)}
            icon={<SearchOutlined />}
            size="small"
            style={{
              width: 90,
            }}
          >
            Search
          </Button>
          <Button
            onClick={() => clearFilters && handleReset(clearFilters)}
            size="small"
            style={{
              width: 90,
            }}
          >
            Reset
          </Button>
          <Button
            type="link"
            size="small"
            onClick={() => {
              confirm({
                closeDropdown: false,
              });
              setSearchText(selectedKeys[0]);
              setSearchedColumn(dataIndex);
            }}
          >
            Filter
          </Button>
        </Space>
      </div>
    ),
    filterIcon: (filtered) => (
      <SearchOutlined
        style={{
          color: filtered ? "#1890ff" : undefined,
        }}
      />
    ),
    onFilter: (value, record) =>
      record[dataIndex].toString().toLowerCase().includes(value.toLowerCase()),
    onFilterDropdownOpenChange: (visible) => {
      if (visible) {
        setTimeout(() => searchInput.current?.select(), 100);
      }
    },
    render: (text) =>
      searchedColumn === dataIndex ? (
        <Highlighter
          highlightStyle={{
            backgroundColor: "#ffc069",
            padding: 0,
          }}
          searchWords={[searchText]}
          autoEscape
          textToHighlight={text ? text.toString() : ""}
        />
      ) : (
        text
      ),
  });
  const columns = [
    {
      title: "Name",
      dataIndex: "name",
      key: "name",
      width: "18%",
      ...getColumnSearchProps("name"),
    },
    {
      title: "Phone",
      dataIndex: "phone",
      key: "phone",
      width: "15%",
      ...getColumnSearchProps("phone"),
    },
    {
      title: "Email ID",
      dataIndex: "email",
      key: "email",
      width: "20%",
      ...getColumnSearchProps("email"),
    },
    {
      title: "Role",
      dataIndex: "role",
      key: "role",
      width: "6%",
    },
    {
      title: "Status",
      dataIndex: "status",
      key: "status",
      width: "8%",

      render: (_, { status }) => (
        <>
          {status.map((statu) => {
            let color = statu.length > 5 ? "geekblue" : "red";
            if (statu === "active") {
              color = "green";
            } else if (statu === "inactive") {
              color = "orange";
            } else if (statu === "block") {
              color = "red";
            }
            return (
              <Tag color={color} key={statu}>
                {statu.toUpperCase()}
              </Tag>
            );
          })}
        </>
      ),
    },
    {
      title: "Created",
      dataIndex: "created",
      key: "created",
      width: "9%",
    },
  ];

  const api = new User();
  useEffect(() => {
    getUsers();
  }, []);

  const getUsers = () => {
    api
      .getUserDetails()
      .then((res) => {
        let data = res.data;
        if (data.status === 200 && data.success === true) {
          setUserData(data.result);
        }
      })
      .catch((err) => {
       
      });
  };

  const data = [];
  {
    userData.map((item, i) =>
      data.push({
        key: item?._id,
        name: item?.name,
        phone: item?.phone,
        email: item?.email,
        role: item?.role,
        status: [item?.status],
        created: moment
          .utc(item?.createdAt)
          .local()
          .startOf("seconds")
          .fromNow(),
      })
    );
  }

  
  return (
    <React.Fragment>
      <NewUserSection>
        <Head>
          <Title>New Users</Title>
          <Button>View All</Button>
        </Head>
        <Table
          columns={columns}
          dataSource={data.reverse()}
          bordered
          responsive={true}
        />
      </NewUserSection>
    </React.Fragment>
  );
};

export default NewUsers;

const NewUserSection = styled.div``;
const Title = styled.div`
  font-size: 20px;
  font-weight: 600;
  color: #000;
  margin: 0 0 0px;
`;

const Head = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin: 0 0 24px;
  width: 100%;
`;

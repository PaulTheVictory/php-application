import React from 'react'
import styled from 'styled-components';
import { Table, Tag, Button } from "antd";

const columns = [
  {
    title: "Order Id",
    dataIndex: "id",
    key: "id",
    
  },
  {
    title: "Amout",
    dataIndex: "amout",
    key: "amout",
  },
  {
    title: "Payment Method",
    dataIndex: "method",
    key: "method",
  },
  {
    title: "Status",
    key: "status",
    dataIndex: "status",
    render: (_, { tags }) => (
      <>
        {tags.map((tag) => {
          let color = tag.length > 3 ? "geekblue" : "green";
          if (tag === "loser") {
            color = "volcano";
          }
          return (
            <Tag color={color} key={tag}>
              {tag.toUpperCase()}
            </Tag>
          );
        })}
      </>
    ),
  },
  
];
const data = [
  {
    key: "1",
    id: "324376",
    amout: 580,
    method: "Bank Transfers",
    tags: ["pending"],
  },
  {
    key: "2",
    id: "324376",
    amout: 580,
    method: "Bank Transfers",
    tags: ["pending"],
  },
  {
    key: "3",
    id: "324376",
    amout: 580,
    method: "Bank Transfers",
    tags: ["pending"],
  },
  {
    key: "4",
    id: "324376",
    amout: 580,
    method: "Bank Transfers",
    tags: ["pending"],
  },
  
];
const NewOrders = () => {
  return (
    <React.Fragment>
      <Head>
        <Title>New Orders</Title>
        <Button>View All</Button>
      </Head>
      <Table
        responsive={true}
        columns={columns}
        dataSource={data}
        bordered
        size="medium"
      />
    </React.Fragment>
  );
}

export default NewOrders


const Title = styled.div`
  font-size: 20px;
  font-weight: 600;
  color: #000;
 
`;

const Head = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin: 0 0 24px;
  width: 100%;
`;
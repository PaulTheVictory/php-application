import React from "react";
// import './Assets/Css/style.css'
import Dashboard from "./Ecommerce/Dashboard/Dashboard";
import Login from "./Ecommerce/Compontent/Login"

function App() {

  const user = JSON.parse(localStorage.getItem("persist:root"))?.user;
  const isAuthenticated = user && JSON.parse(user).isAuthenticated;


  return (
    <React.Fragment>
      {/* {isAuthenticated === true ? "" : <Login />} */}
      <Dashboard />
    </React.Fragment>
  );
}

export default App;

<?php
/*Template Name:Home*/
get_header(); ?>

<section class="inner_page_banner_section">
  <div class="slider">
    <div class="slider_box">
      <picture>
        <source media="(max-width:767px)" srcset="https://www.blazon.in/assets/images/banners/about-us-m.png">
        <img class=" lazyloaded" data-src="https://www.blazon.in/assets/images/banners/about-us-d.png" alt="Flowers" style="width:auto;" src="https://www.blazon.in/assets/images/banners/about-us-d.png">
      </picture>
      <h2>Blog</h2>
    </div>
  </div>
</section>

<!--blog_section-->


<section class="blog_section">
  <div class="wrapper">
    <div class="blog_section_align">
      <div class="blog_section_left">
        <ul>
          <li>
            <div class="blog_box">
              <div class="blog_box_left">
                <img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/6.png" alt="blog">
              </div>
              <div class="blog_box_right">
                <div class="blog_category">
                  <div class="blog_cat">NEWS</div>
                  <div class="blog_date"><i class="bi bi-clock me-1"></i>12 Days ago</div>
                </div>
                <h4>How To Become A Python Develop Expert</h4>
                <p>If there’s one way that wireless technology has changed the way we work, it’s that will everyone [...]</p>
                <div class="blog_author_details">
                  <div class="author"></div>
                  <div class="details">
                    <div class="comment"></div>
                    <div class="views"></div>
                  </div>
                </div>
              </div>
            </div>
          </li>
          <li>
            <div class="blog_box">
              <div class="blog_box_left">
                <img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/6.png" alt="blog">
              </div>
              <div class="blog_box_right">
                <div class="blog_category">
                  <div class="blog_cat">NEWS</div>
                  <div class="blog_date"><i class="bi bi-clock me-1"></i>12 Days ago</div>
                </div>
                <h4>How To Become A Python Develop Expert</h4>
                <p>If there’s one way that wireless technology has changed the way we work, it’s that will everyone [...]</p>
                <div class="blog_author_details">
                  <div class="author"></div>
                  <div class="details">
                    <div class="comment"></div>
                    <div class="views"></div>
                  </div>
                </div>
              </div>
            </div>
          </li>
          <li>
            <div class="blog_box">
              <div class="blog_box_left">
                <img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/6.png" alt="blog">
              </div>
              <div class="blog_box_right">
                <div class="blog_category">
                  <div class="blog_cat">NEWS</div>
                  <div class="blog_date"><i class="bi bi-clock me-1"></i>12 Days ago</div>
                </div>
                <h4>How To Become A Python Develop Expert</h4>
                <p>If there’s one way that wireless technology has changed the way we work, it’s that will everyone [...]</p>
                <div class="blog_author_details">
                  <div class="author"></div>
                  <div class="details">
                    <div class="comment"></div>
                    <div class="views"></div>
                  </div>
                </div>
              </div>
            </div>
          </li>
        </ul>
      </div>
      <div class="blog_section_right">

      </div>
    </div>
  </div>
</section>


<!--blog_section-->

















<?php
get_footer();
?>
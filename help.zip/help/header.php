<?php

/**
 * The template for displaying the header
 *
 * Displays all of the head element and everything up until the "site-content" div.
 *
 * @package WordPress
 * @subpackage Twenty_Sixteen
 * @since Twenty Sixteen 1.0
 */
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?> class="no-js">

<head>
	<meta charset="<?php bloginfo('charset'); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1" />
	<link rel="profile" href="http://gmpg.org/xfn/11">
	<?php if (is_singular() && pings_open(get_queried_object())) : ?>
		<link rel="pingback" href="<?php echo esc_url(get_bloginfo('pingback_url')); ?>">
	<?php endif; ?>
	<?php
	$url = home_url($wp->request);
	$meta = get_post_meta(get_the_ID(), '', true);
	$title = $meta['Title'][0];
	$description = $meta['Description'][0];
	$keyword = $meta['Keyword'][0];
	if ($title != "") {
		echo '<title>' . $title . '</title>' . PHP_EOL;
	} else { ?>
		<title><?php wp_title('|', true, 'right'); ?> <?php bloginfo('name'); ?></title>
	<?php
	}
	if ($description != "") echo '<meta name="description" content="' . $description . '" />' . PHP_EOL;
	if ($keyword != "") echo '<meta name="keywords" content="' . $keyword . '" />' . PHP_EOL;
	?>

	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta http-equiv="Cache-control" content="public" />
	<link rel="canonical" href="" />
	<style>
		/*bootstrap_min*/
		@charset "UTF-8";

		:root {
			--bs-blue: #0d6efd;
			--bs-indigo: #6610f2;
			--bs-purple: #6f42c1;
			--bs-pink: #d63384;
			--bs-red: #dc3545;
			--bs-orange: #fd7e14;
			--bs-yellow: #ffc107;
			--bs-green: #198754;
			--bs-teal: #20c997;
			--bs-cyan: #0dcaf0;
			--bs-black: #000;
			--bs-white: #fff;
			--bs-gray: #6c757d;
			--bs-gray-dark: #343a40;
			--bs-gray-100: #f8f9fa;
			--bs-gray-200: #e9ecef;
			--bs-gray-300: #dee2e6;
			--bs-gray-400: #ced4da;
			--bs-gray-500: #adb5bd;
			--bs-gray-600: #6c757d;
			--bs-gray-700: #495057;
			--bs-gray-800: #343a40;
			--bs-gray-900: #212529;
			--bs-primary: #0d6efd;
			--bs-secondary: #6c757d;
			--bs-success: #198754;
			--bs-info: #0dcaf0;
			--bs-warning: #ffc107;
			--bs-danger: #dc3545;
			--bs-light: #f8f9fa;
			--bs-dark: #212529;
			--bs-primary-rgb: 13, 110, 253;
			--bs-secondary-rgb: 108, 117, 125;
			--bs-success-rgb: 25, 135, 84;
			--bs-info-rgb: 13, 202, 240;
			--bs-warning-rgb: 255, 193, 7;
			--bs-danger-rgb: 220, 53, 69;
			--bs-light-rgb: 248, 249, 250;
			--bs-dark-rgb: 33, 37, 41;
			--bs-white-rgb: 255, 255, 255;
			--bs-black-rgb: 0, 0, 0;
			--bs-body-color-rgb: 33, 37, 41;
			--bs-body-bg-rgb: 255, 255, 255;
			--bs-font-sans-serif: system-ui, -apple-system, "Segoe UI", Roboto, "Helvetica Neue", "Noto Sans", "Liberation Sans", Arial, sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol", "Noto Color Emoji";
			--bs-font-monospace: SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace;
			--bs-gradient: linear-gradient(180deg, rgba(255, 255, 255, 0.15), rgba(255, 255, 255, 0));
			--bs-body-font-family: var(--bs-font-sans-serif);
			--bs-body-font-size: 1rem;
			--bs-body-font-weight: 400;
			--bs-body-line-height: 1.5;
			--bs-body-color: #212529;
			--bs-body-bg: #fff;
			--bs-border-width: 1px;
			--bs-border-style: solid;
			--bs-border-color: #dee2e6;
			--bs-border-color-translucent: rgba(0, 0, 0, 0.175);
			--bs-border-radius: 0.375rem;
			--bs-border-radius-sm: 0.25rem;
			--bs-border-radius-lg: 0.5rem;
			--bs-border-radius-xl: 1rem;
			--bs-border-radius-2xl: 2rem;
			--bs-border-radius-pill: 50rem;
			--bs-link-color: #0d6efd;
			--bs-link-hover-color: #0a58ca;
			--bs-code-color: #d63384;
			--bs-highlight-bg: #fff3cd
		}

		*,
		::after,
		::before {
			box-sizing: border-box
		}

		@media (prefers-reduced-motion:no-preference) {
			:root {
				scroll-behavior: smooth
			}
		}

		body {
			margin: 0;
			font-family: var(--bs-body-font-family);
			font-size: var(--bs-body-font-size);
			font-weight: var(--bs-body-font-weight);
			line-height: var(--bs-body-line-height);
			color: var(--bs-body-color);
			text-align: var(--bs-body-text-align);
			background-color: var(--bs-body-bg);
			-webkit-text-size-adjust: 100%;
			-webkit-tap-highlight-color: transparent
		}

		hr {
			margin: 1rem 0;
			color: inherit;
			border: 0;
			border-top: 1px solid;
			opacity: .25
		}

		.h1,
		.h2,
		.h3,
		.h4,
		.h5,
		.h6,
		h1,
		h2,
		h3,
		h4,
		h5,
		h6 {
			margin-top: 0;
			margin-bottom: .5rem;
			font-weight: 500;
			line-height: 1.2
		}

		.h1,
		h1 {
			font-size: calc(1.375rem + 1.5vw)
		}

		@media (min-width:1200px) {

			.h1,
			h1 {
				font-size: 2.5rem
			}
		}

		.h2,
		h2 {
			font-size: calc(1.325rem + .9vw)
		}

		@media (min-width:1200px) {

			.h2,
			h2 {
				font-size: 2rem
			}
		}

		.h3,
		h3 {
			font-size: calc(1.3rem + .6vw)
		}

		@media (min-width:1200px) {

			.h3,
			h3 {
				font-size: 1.75rem
			}
		}

		.h4,
		h4 {
			font-size: calc(1.275rem + .3vw)
		}

		@media (min-width:1200px) {

			.h4,
			h4 {
				font-size: 1.5rem
			}
		}

		.h5,
		h5 {
			font-size: 1.25rem
		}

		.h6,
		h6 {
			font-size: 1rem
		}

		p {
			margin-top: 0;
			margin-bottom: 1rem
		}

		abbr[title] {
			-webkit-text-decoration: underline dotted;
			text-decoration: underline dotted;
			cursor: help;
			-webkit-text-decoration-skip-ink: none;
			text-decoration-skip-ink: none
		}

		address {
			margin-bottom: 1rem;
			font-style: normal;
			line-height: inherit
		}

		ol,
		ul {
			padding-left: 2rem
		}

		dl,
		ol,
		ul {
			margin-top: 0;
			margin-bottom: 1rem
		}

		ol ol,
		ol ul,
		ul ol,
		ul ul {
			margin-bottom: 0
		}

		dt {
			font-weight: 700
		}

		dd {
			margin-bottom: .5rem;
			margin-left: 0
		}

		blockquote {
			margin: 0 0 1rem
		}

		b,
		strong {
			font-weight: bolder
		}

		.small,
		small {
			font-size: .875em
		}

		.mark,
		mark {
			padding: .1875em;
			background-color: var(--bs-highlight-bg)
		}

		sub,
		sup {
			position: relative;
			font-size: .75em;
			line-height: 0;
			vertical-align: baseline
		}

		sub {
			bottom: -.25em
		}

		sup {
			top: -.5em
		}

		a {
			color: var(--bs-link-color);
			text-decoration: underline
		}

		a:hover {
			color: var(--bs-link-hover-color)
		}

		a:not([href]):not([class]),
		a:not([href]):not([class]):hover {
			color: inherit;
			text-decoration: none
		}

		code,
		kbd,
		pre,
		samp {
			font-family: var(--bs-font-monospace);
			font-size: 1em
		}

		pre {
			display: block;
			margin-top: 0;
			margin-bottom: 1rem;
			overflow: auto;
			font-size: .875em
		}

		pre code {
			font-size: inherit;
			color: inherit;
			word-break: normal
		}

		code {
			font-size: .875em;
			color: var(--bs-code-color);
			word-wrap: break-word
		}

		a>code {
			color: inherit
		}

		kbd {
			padding: .1875rem .375rem;
			font-size: .875em;
			color: var(--bs-body-bg);
			background-color: var(--bs-body-color);
			border-radius: .25rem
		}

		kbd kbd {
			padding: 0;
			font-size: 1em
		}

		figure {
			margin: 0 0 1rem
		}

		img,
		svg {
			vertical-align: middle
		}

		table {
			caption-side: bottom;
			border-collapse: collapse
		}

		caption {
			padding-top: .5rem;
			padding-bottom: .5rem;
			color: #6c757d;
			text-align: left
		}

		th {
			text-align: inherit;
			text-align: -webkit-match-parent
		}

		tbody,
		td,
		tfoot,
		th,
		thead,
		tr {
			border-color: inherit;
			border-style: solid;
			border-width: 0
		}

		label {
			display: inline-block
		}

		button {
			border-radius: 0
		}

		button:focus:not(:focus-visible) {
			outline: 0
		}

		button,
		input,
		optgroup,
		select,
		textarea {
			margin: 0;
			font-family: inherit;
			font-size: inherit;
			line-height: inherit
		}

		button,
		select {
			text-transform: none
		}

		[role=button] {
			cursor: pointer
		}

		select {
			word-wrap: normal
		}

		select:disabled {
			opacity: 1
		}

		[list]:not([type=date]):not([type=datetime-local]):not([type=month]):not([type=week]):not([type=time])::-webkit-calendar-picker-indicator {
			display: none !important
		}

		[type=button],
		[type=reset],
		[type=submit],
		button {
			-webkit-appearance: button
		}

		[type=button]:not(:disabled),
		[type=reset]:not(:disabled),
		[type=submit]:not(:disabled),
		button:not(:disabled) {
			cursor: pointer
		}

		::-moz-focus-inner {
			padding: 0;
			border-style: none
		}

		textarea {
			resize: vertical
		}

		fieldset {
			min-width: 0;
			padding: 0;
			margin: 0;
			border: 0
		}

		legend {
			float: left;
			width: 100%;
			padding: 0;
			margin-bottom: .5rem;
			font-size: calc(1.275rem + .3vw);
			line-height: inherit
		}

		@media (min-width:1200px) {
			legend {
				font-size: 1.5rem
			}
		}

		legend+* {
			clear: left
		}

		::-webkit-datetime-edit-day-field,
		::-webkit-datetime-edit-fields-wrapper,
		::-webkit-datetime-edit-hour-field,
		::-webkit-datetime-edit-minute,
		::-webkit-datetime-edit-month-field,
		::-webkit-datetime-edit-text,
		::-webkit-datetime-edit-year-field {
			padding: 0
		}

		::-webkit-inner-spin-button {
			height: auto
		}

		[type=search] {
			outline-offset: -2px;
			-webkit-appearance: textfield
		}

		::-webkit-search-decoration {
			-webkit-appearance: none
		}

		::-webkit-color-swatch-wrapper {
			padding: 0
		}

		::-webkit-file-upload-button {
			font: inherit;
			-webkit-appearance: button
		}

		::file-selector-button {
			font: inherit;
			-webkit-appearance: button
		}

		output {
			display: inline-block
		}

		iframe {
			border: 0
		}

		summary {
			display: list-item;
			cursor: pointer
		}

		progress {
			vertical-align: baseline
		}

		[hidden] {
			display: none !important
		}

		.lead {
			font-size: 1.25rem;
			font-weight: 300
		}

		.display-1 {
			font-size: calc(1.625rem + 4.5vw);
			font-weight: 300;
			line-height: 1.2
		}

		@media (min-width:1200px) {
			.display-1 {
				font-size: 5rem
			}
		}

		.display-2 {
			font-size: calc(1.575rem + 3.9vw);
			font-weight: 300;
			line-height: 1.2
		}

		@media (min-width:1200px) {
			.display-2 {
				font-size: 4.5rem
			}
		}

		.display-3 {
			font-size: calc(1.525rem + 3.3vw);
			font-weight: 300;
			line-height: 1.2
		}

		@media (min-width:1200px) {
			.display-3 {
				font-size: 4rem
			}
		}

		.display-4 {
			font-size: calc(1.475rem + 2.7vw);
			font-weight: 300;
			line-height: 1.2
		}

		@media (min-width:1200px) {
			.display-4 {
				font-size: 3.5rem
			}
		}

		.display-5 {
			font-size: calc(1.425rem + 2.1vw);
			font-weight: 300;
			line-height: 1.2
		}

		@media (min-width:1200px) {
			.display-5 {
				font-size: 3rem
			}
		}

		.display-6 {
			font-size: calc(1.375rem + 1.5vw);
			font-weight: 300;
			line-height: 1.2
		}

		@media (min-width:1200px) {
			.display-6 {
				font-size: 2.5rem
			}
		}

		.list-unstyled {
			padding-left: 0;
			list-style: none
		}

		.list-inline {
			padding-left: 0;
			list-style: none
		}

		.list-inline-item {
			display: inline-block
		}

		.list-inline-item:not(:last-child) {
			margin-right: .5rem
		}

		.initialism {
			font-size: .875em;
			text-transform: uppercase
		}

		.blockquote {
			margin-bottom: 1rem;
			font-size: 1.25rem
		}

		.blockquote>:last-child {
			margin-bottom: 0
		}

		.blockquote-footer {
			margin-top: -1rem;
			margin-bottom: 1rem;
			font-size: .875em;
			color: #6c757d
		}

		.blockquote-footer::before {
			content: "— "
		}

		.img-fluid {
			max-width: 100%;
			height: auto
		}

		.img-thumbnail {
			padding: .25rem;
			background-color: #fff;
			border: 1px solid var(--bs-border-color);
			border-radius: .375rem;
			max-width: 100%;
			height: auto
		}

		.figure {
			display: inline-block
		}

		.figure-img {
			margin-bottom: .5rem;
			line-height: 1
		}

		.figure-caption {
			font-size: .875em;
			color: #6c757d
		}

		.container,
		.container-fluid,
		.container-lg,
		.container-md,
		.container-sm,
		.container-xl,
		.container-xxl {
			--bs-gutter-x: 1.5rem;
			--bs-gutter-y: 0;
			width: 100%;
			padding-right: calc(var(--bs-gutter-x) * .5);
			padding-left: calc(var(--bs-gutter-x) * .5);
			margin-right: auto;
			margin-left: auto
		}

		@media (min-width:576px) {

			.container,
			.container-sm {
				max-width: 540px
			}
		}

		@media (min-width:768px) {

			.container,
			.container-md,
			.container-sm {
				max-width: 720px
			}
		}

		@media (min-width:992px) {

			.container,
			.container-lg,
			.container-md,
			.container-sm {
				max-width: 960px
			}
		}

		@media (min-width:1200px) {

			.container,
			.container-lg,
			.container-md,
			.container-sm,
			.container-xl {
				max-width: 1140px
			}
		}

		@media (min-width:1400px) {

			.container,
			.container-lg,
			.container-md,
			.container-sm,
			.container-xl,
			.container-xxl {
				max-width: 1320px
			}
		}

		.row {
			--bs-gutter-x: 1.5rem;
			--bs-gutter-y: 0;
			display: flex;
			flex-wrap: wrap;
			margin-top: calc(-1 * var(--bs-gutter-y));
			margin-right: calc(-.5 * var(--bs-gutter-x));
			margin-left: calc(-.5 * var(--bs-gutter-x))
		}

		.row>* {
			flex-shrink: 0;
			width: 100%;
			max-width: 100%;
			padding-right: calc(var(--bs-gutter-x) * .5);
			padding-left: calc(var(--bs-gutter-x) * .5);
			margin-top: var(--bs-gutter-y)
		}

		.col {
			flex: 1 0 0%
		}

		.row-cols-auto>* {
			flex: 0 0 auto;
			width: auto
		}

		.row-cols-1>* {
			flex: 0 0 auto;
			width: 100%
		}

		.row-cols-2>* {
			flex: 0 0 auto;
			width: 50%
		}

		.row-cols-3>* {
			flex: 0 0 auto;
			width: 33.3333333333%
		}

		.row-cols-4>* {
			flex: 0 0 auto;
			width: 25%
		}

		.row-cols-5>* {
			flex: 0 0 auto;
			width: 20%
		}

		.row-cols-6>* {
			flex: 0 0 auto;
			width: 16.6666666667%
		}

		.col-auto {
			flex: 0 0 auto;
			width: auto
		}

		.col-1 {
			flex: 0 0 auto;
			width: 8.33333333%
		}

		.col-2 {
			flex: 0 0 auto;
			width: 16.66666667%
		}

		.col-3 {
			flex: 0 0 auto;
			width: 25%
		}

		.col-4 {
			flex: 0 0 auto;
			width: 33.33333333%
		}

		.col-5 {
			flex: 0 0 auto;
			width: 41.66666667%
		}

		.col-6 {
			flex: 0 0 auto;
			width: 50%
		}

		.col-7 {
			flex: 0 0 auto;
			width: 58.33333333%
		}

		.col-8 {
			flex: 0 0 auto;
			width: 66.66666667%
		}

		.col-9 {
			flex: 0 0 auto;
			width: 75%
		}

		.col-10 {
			flex: 0 0 auto;
			width: 83.33333333%
		}

		.col-11 {
			flex: 0 0 auto;
			width: 91.66666667%
		}

		.col-12 {
			flex: 0 0 auto;
			width: 100%
		}

		.offset-1 {
			margin-left: 8.33333333%
		}

		.offset-2 {
			margin-left: 16.66666667%
		}

		.offset-3 {
			margin-left: 25%
		}

		.offset-4 {
			margin-left: 33.33333333%
		}

		.offset-5 {
			margin-left: 41.66666667%
		}

		.offset-6 {
			margin-left: 50%
		}

		.offset-7 {
			margin-left: 58.33333333%
		}

		.offset-8 {
			margin-left: 66.66666667%
		}

		.offset-9 {
			margin-left: 75%
		}

		.offset-10 {
			margin-left: 83.33333333%
		}

		.offset-11 {
			margin-left: 91.66666667%
		}

		.g-0,
		.gx-0 {
			--bs-gutter-x: 0
		}

		.g-0,
		.gy-0 {
			--bs-gutter-y: 0
		}

		.g-1,
		.gx-1 {
			--bs-gutter-x: 0.25rem
		}

		.g-1,
		.gy-1 {
			--bs-gutter-y: 0.25rem
		}

		.g-2,
		.gx-2 {
			--bs-gutter-x: 0.5rem
		}

		.g-2,
		.gy-2 {
			--bs-gutter-y: 0.5rem
		}

		.g-3,
		.gx-3 {
			--bs-gutter-x: 1rem
		}

		.g-3,
		.gy-3 {
			--bs-gutter-y: 1rem
		}

		.g-4,
		.gx-4 {
			--bs-gutter-x: 1.5rem
		}

		.g-4,
		.gy-4 {
			--bs-gutter-y: 1.5rem
		}

		.g-5,
		.gx-5 {
			--bs-gutter-x: 3rem
		}

		.g-5,
		.gy-5 {
			--bs-gutter-y: 3rem
		}

		@media (min-width:576px) {
			.col-sm {
				flex: 1 0 0%
			}

			.row-cols-sm-auto>* {
				flex: 0 0 auto;
				width: auto
			}

			.row-cols-sm-1>* {
				flex: 0 0 auto;
				width: 100%
			}

			.row-cols-sm-2>* {
				flex: 0 0 auto;
				width: 50%
			}

			.row-cols-sm-3>* {
				flex: 0 0 auto;
				width: 33.3333333333%
			}

			.row-cols-sm-4>* {
				flex: 0 0 auto;
				width: 25%
			}

			.row-cols-sm-5>* {
				flex: 0 0 auto;
				width: 20%
			}

			.row-cols-sm-6>* {
				flex: 0 0 auto;
				width: 16.6666666667%
			}

			.col-sm-auto {
				flex: 0 0 auto;
				width: auto
			}

			.col-sm-1 {
				flex: 0 0 auto;
				width: 8.33333333%
			}

			.col-sm-2 {
				flex: 0 0 auto;
				width: 16.66666667%
			}

			.col-sm-3 {
				flex: 0 0 auto;
				width: 25%
			}

			.col-sm-4 {
				flex: 0 0 auto;
				width: 33.33333333%
			}

			.col-sm-5 {
				flex: 0 0 auto;
				width: 41.66666667%
			}

			.col-sm-6 {
				flex: 0 0 auto;
				width: 50%
			}

			.col-sm-7 {
				flex: 0 0 auto;
				width: 58.33333333%
			}

			.col-sm-8 {
				flex: 0 0 auto;
				width: 66.66666667%
			}

			.col-sm-9 {
				flex: 0 0 auto;
				width: 75%
			}

			.col-sm-10 {
				flex: 0 0 auto;
				width: 83.33333333%
			}

			.col-sm-11 {
				flex: 0 0 auto;
				width: 91.66666667%
			}

			.col-sm-12 {
				flex: 0 0 auto;
				width: 100%
			}

			.offset-sm-0 {
				margin-left: 0
			}

			.offset-sm-1 {
				margin-left: 8.33333333%
			}

			.offset-sm-2 {
				margin-left: 16.66666667%
			}

			.offset-sm-3 {
				margin-left: 25%
			}

			.offset-sm-4 {
				margin-left: 33.33333333%
			}

			.offset-sm-5 {
				margin-left: 41.66666667%
			}

			.offset-sm-6 {
				margin-left: 50%
			}

			.offset-sm-7 {
				margin-left: 58.33333333%
			}

			.offset-sm-8 {
				margin-left: 66.66666667%
			}

			.offset-sm-9 {
				margin-left: 75%
			}

			.offset-sm-10 {
				margin-left: 83.33333333%
			}

			.offset-sm-11 {
				margin-left: 91.66666667%
			}

			.g-sm-0,
			.gx-sm-0 {
				--bs-gutter-x: 0
			}

			.g-sm-0,
			.gy-sm-0 {
				--bs-gutter-y: 0
			}

			.g-sm-1,
			.gx-sm-1 {
				--bs-gutter-x: 0.25rem
			}

			.g-sm-1,
			.gy-sm-1 {
				--bs-gutter-y: 0.25rem
			}

			.g-sm-2,
			.gx-sm-2 {
				--bs-gutter-x: 0.5rem
			}

			.g-sm-2,
			.gy-sm-2 {
				--bs-gutter-y: 0.5rem
			}

			.g-sm-3,
			.gx-sm-3 {
				--bs-gutter-x: 1rem
			}

			.g-sm-3,
			.gy-sm-3 {
				--bs-gutter-y: 1rem
			}

			.g-sm-4,
			.gx-sm-4 {
				--bs-gutter-x: 1.5rem
			}

			.g-sm-4,
			.gy-sm-4 {
				--bs-gutter-y: 1.5rem
			}

			.g-sm-5,
			.gx-sm-5 {
				--bs-gutter-x: 3rem
			}

			.g-sm-5,
			.gy-sm-5 {
				--bs-gutter-y: 3rem
			}
		}

		@media (min-width:768px) {
			.col-md {
				flex: 1 0 0%
			}

			.row-cols-md-auto>* {
				flex: 0 0 auto;
				width: auto
			}

			.row-cols-md-1>* {
				flex: 0 0 auto;
				width: 100%
			}

			.row-cols-md-2>* {
				flex: 0 0 auto;
				width: 50%
			}

			.row-cols-md-3>* {
				flex: 0 0 auto;
				width: 33.3333333333%
			}

			.row-cols-md-4>* {
				flex: 0 0 auto;
				width: 25%
			}

			.row-cols-md-5>* {
				flex: 0 0 auto;
				width: 20%
			}

			.row-cols-md-6>* {
				flex: 0 0 auto;
				width: 16.6666666667%
			}

			.col-md-auto {
				flex: 0 0 auto;
				width: auto
			}

			.col-md-1 {
				flex: 0 0 auto;
				width: 8.33333333%
			}

			.col-md-2 {
				flex: 0 0 auto;
				width: 16.66666667%
			}

			.col-md-3 {
				flex: 0 0 auto;
				width: 25%
			}

			.col-md-4 {
				flex: 0 0 auto;
				width: 33.33333333%
			}

			.col-md-5 {
				flex: 0 0 auto;
				width: 41.66666667%
			}

			.col-md-6 {
				flex: 0 0 auto;
				width: 50%
			}

			.col-md-7 {
				flex: 0 0 auto;
				width: 58.33333333%
			}

			.col-md-8 {
				flex: 0 0 auto;
				width: 66.66666667%
			}

			.col-md-9 {
				flex: 0 0 auto;
				width: 75%
			}

			.col-md-10 {
				flex: 0 0 auto;
				width: 83.33333333%
			}

			.col-md-11 {
				flex: 0 0 auto;
				width: 91.66666667%
			}

			.col-md-12 {
				flex: 0 0 auto;
				width: 100%
			}

			.offset-md-0 {
				margin-left: 0
			}

			.offset-md-1 {
				margin-left: 8.33333333%
			}

			.offset-md-2 {
				margin-left: 16.66666667%
			}

			.offset-md-3 {
				margin-left: 25%
			}

			.offset-md-4 {
				margin-left: 33.33333333%
			}

			.offset-md-5 {
				margin-left: 41.66666667%
			}

			.offset-md-6 {
				margin-left: 50%
			}

			.offset-md-7 {
				margin-left: 58.33333333%
			}

			.offset-md-8 {
				margin-left: 66.66666667%
			}

			.offset-md-9 {
				margin-left: 75%
			}

			.offset-md-10 {
				margin-left: 83.33333333%
			}

			.offset-md-11 {
				margin-left: 91.66666667%
			}

			.g-md-0,
			.gx-md-0 {
				--bs-gutter-x: 0
			}

			.g-md-0,
			.gy-md-0 {
				--bs-gutter-y: 0
			}

			.g-md-1,
			.gx-md-1 {
				--bs-gutter-x: 0.25rem
			}

			.g-md-1,
			.gy-md-1 {
				--bs-gutter-y: 0.25rem
			}

			.g-md-2,
			.gx-md-2 {
				--bs-gutter-x: 0.5rem
			}

			.g-md-2,
			.gy-md-2 {
				--bs-gutter-y: 0.5rem
			}

			.g-md-3,
			.gx-md-3 {
				--bs-gutter-x: 1rem
			}

			.g-md-3,
			.gy-md-3 {
				--bs-gutter-y: 1rem
			}

			.g-md-4,
			.gx-md-4 {
				--bs-gutter-x: 1.5rem
			}

			.g-md-4,
			.gy-md-4 {
				--bs-gutter-y: 1.5rem
			}

			.g-md-5,
			.gx-md-5 {
				--bs-gutter-x: 3rem
			}

			.g-md-5,
			.gy-md-5 {
				--bs-gutter-y: 3rem
			}
		}

		@media (min-width:992px) {
			.col-lg {
				flex: 1 0 0%
			}

			.row-cols-lg-auto>* {
				flex: 0 0 auto;
				width: auto
			}

			.row-cols-lg-1>* {
				flex: 0 0 auto;
				width: 100%
			}

			.row-cols-lg-2>* {
				flex: 0 0 auto;
				width: 50%
			}

			.row-cols-lg-3>* {
				flex: 0 0 auto;
				width: 33.3333333333%
			}

			.row-cols-lg-4>* {
				flex: 0 0 auto;
				width: 25%
			}

			.row-cols-lg-5>* {
				flex: 0 0 auto;
				width: 20%
			}

			.row-cols-lg-6>* {
				flex: 0 0 auto;
				width: 16.6666666667%
			}

			.col-lg-auto {
				flex: 0 0 auto;
				width: auto
			}

			.col-lg-1 {
				flex: 0 0 auto;
				width: 8.33333333%
			}

			.col-lg-2 {
				flex: 0 0 auto;
				width: 16.66666667%
			}

			.col-lg-3 {
				flex: 0 0 auto;
				width: 25%
			}

			.col-lg-4 {
				flex: 0 0 auto;
				width: 33.33333333%
			}

			.col-lg-5 {
				flex: 0 0 auto;
				width: 41.66666667%
			}

			.col-lg-6 {
				flex: 0 0 auto;
				width: 50%
			}

			.col-lg-7 {
				flex: 0 0 auto;
				width: 58.33333333%
			}

			.col-lg-8 {
				flex: 0 0 auto;
				width: 66.66666667%
			}

			.col-lg-9 {
				flex: 0 0 auto;
				width: 75%
			}

			.col-lg-10 {
				flex: 0 0 auto;
				width: 83.33333333%
			}

			.col-lg-11 {
				flex: 0 0 auto;
				width: 91.66666667%
			}

			.col-lg-12 {
				flex: 0 0 auto;
				width: 100%
			}

			.offset-lg-0 {
				margin-left: 0
			}

			.offset-lg-1 {
				margin-left: 8.33333333%
			}

			.offset-lg-2 {
				margin-left: 16.66666667%
			}

			.offset-lg-3 {
				margin-left: 25%
			}

			.offset-lg-4 {
				margin-left: 33.33333333%
			}

			.offset-lg-5 {
				margin-left: 41.66666667%
			}

			.offset-lg-6 {
				margin-left: 50%
			}

			.offset-lg-7 {
				margin-left: 58.33333333%
			}

			.offset-lg-8 {
				margin-left: 66.66666667%
			}

			.offset-lg-9 {
				margin-left: 75%
			}

			.offset-lg-10 {
				margin-left: 83.33333333%
			}

			.offset-lg-11 {
				margin-left: 91.66666667%
			}

			.g-lg-0,
			.gx-lg-0 {
				--bs-gutter-x: 0
			}

			.g-lg-0,
			.gy-lg-0 {
				--bs-gutter-y: 0
			}

			.g-lg-1,
			.gx-lg-1 {
				--bs-gutter-x: 0.25rem
			}

			.g-lg-1,
			.gy-lg-1 {
				--bs-gutter-y: 0.25rem
			}

			.g-lg-2,
			.gx-lg-2 {
				--bs-gutter-x: 0.5rem
			}

			.g-lg-2,
			.gy-lg-2 {
				--bs-gutter-y: 0.5rem
			}

			.g-lg-3,
			.gx-lg-3 {
				--bs-gutter-x: 1rem
			}

			.g-lg-3,
			.gy-lg-3 {
				--bs-gutter-y: 1rem
			}

			.g-lg-4,
			.gx-lg-4 {
				--bs-gutter-x: 1.5rem
			}

			.g-lg-4,
			.gy-lg-4 {
				--bs-gutter-y: 1.5rem
			}

			.g-lg-5,
			.gx-lg-5 {
				--bs-gutter-x: 3rem
			}

			.g-lg-5,
			.gy-lg-5 {
				--bs-gutter-y: 3rem
			}
		}

		@media (min-width:1200px) {
			.col-xl {
				flex: 1 0 0%
			}

			.row-cols-xl-auto>* {
				flex: 0 0 auto;
				width: auto
			}

			.row-cols-xl-1>* {
				flex: 0 0 auto;
				width: 100%
			}

			.row-cols-xl-2>* {
				flex: 0 0 auto;
				width: 50%
			}

			.row-cols-xl-3>* {
				flex: 0 0 auto;
				width: 33.3333333333%
			}

			.row-cols-xl-4>* {
				flex: 0 0 auto;
				width: 25%
			}

			.row-cols-xl-5>* {
				flex: 0 0 auto;
				width: 20%
			}

			.row-cols-xl-6>* {
				flex: 0 0 auto;
				width: 16.6666666667%
			}

			.col-xl-auto {
				flex: 0 0 auto;
				width: auto
			}

			.col-xl-1 {
				flex: 0 0 auto;
				width: 8.33333333%
			}

			.col-xl-2 {
				flex: 0 0 auto;
				width: 16.66666667%
			}

			.col-xl-3 {
				flex: 0 0 auto;
				width: 25%
			}

			.col-xl-4 {
				flex: 0 0 auto;
				width: 33.33333333%
			}

			.col-xl-5 {
				flex: 0 0 auto;
				width: 41.66666667%
			}

			.col-xl-6 {
				flex: 0 0 auto;
				width: 50%
			}

			.col-xl-7 {
				flex: 0 0 auto;
				width: 58.33333333%
			}

			.col-xl-8 {
				flex: 0 0 auto;
				width: 66.66666667%
			}

			.col-xl-9 {
				flex: 0 0 auto;
				width: 75%
			}

			.col-xl-10 {
				flex: 0 0 auto;
				width: 83.33333333%
			}

			.col-xl-11 {
				flex: 0 0 auto;
				width: 91.66666667%
			}

			.col-xl-12 {
				flex: 0 0 auto;
				width: 100%
			}

			.offset-xl-0 {
				margin-left: 0
			}

			.offset-xl-1 {
				margin-left: 8.33333333%
			}

			.offset-xl-2 {
				margin-left: 16.66666667%
			}

			.offset-xl-3 {
				margin-left: 25%
			}

			.offset-xl-4 {
				margin-left: 33.33333333%
			}

			.offset-xl-5 {
				margin-left: 41.66666667%
			}

			.offset-xl-6 {
				margin-left: 50%
			}

			.offset-xl-7 {
				margin-left: 58.33333333%
			}

			.offset-xl-8 {
				margin-left: 66.66666667%
			}

			.offset-xl-9 {
				margin-left: 75%
			}

			.offset-xl-10 {
				margin-left: 83.33333333%
			}

			.offset-xl-11 {
				margin-left: 91.66666667%
			}

			.g-xl-0,
			.gx-xl-0 {
				--bs-gutter-x: 0
			}

			.g-xl-0,
			.gy-xl-0 {
				--bs-gutter-y: 0
			}

			.g-xl-1,
			.gx-xl-1 {
				--bs-gutter-x: 0.25rem
			}

			.g-xl-1,
			.gy-xl-1 {
				--bs-gutter-y: 0.25rem
			}

			.g-xl-2,
			.gx-xl-2 {
				--bs-gutter-x: 0.5rem
			}

			.g-xl-2,
			.gy-xl-2 {
				--bs-gutter-y: 0.5rem
			}

			.g-xl-3,
			.gx-xl-3 {
				--bs-gutter-x: 1rem
			}

			.g-xl-3,
			.gy-xl-3 {
				--bs-gutter-y: 1rem
			}

			.g-xl-4,
			.gx-xl-4 {
				--bs-gutter-x: 1.5rem
			}

			.g-xl-4,
			.gy-xl-4 {
				--bs-gutter-y: 1.5rem
			}

			.g-xl-5,
			.gx-xl-5 {
				--bs-gutter-x: 3rem
			}

			.g-xl-5,
			.gy-xl-5 {
				--bs-gutter-y: 3rem
			}
		}

		@media (min-width:1400px) {
			.col-xxl {
				flex: 1 0 0%
			}

			.row-cols-xxl-auto>* {
				flex: 0 0 auto;
				width: auto
			}

			.row-cols-xxl-1>* {
				flex: 0 0 auto;
				width: 100%
			}

			.row-cols-xxl-2>* {
				flex: 0 0 auto;
				width: 50%
			}

			.row-cols-xxl-3>* {
				flex: 0 0 auto;
				width: 33.3333333333%
			}

			.row-cols-xxl-4>* {
				flex: 0 0 auto;
				width: 25%
			}

			.row-cols-xxl-5>* {
				flex: 0 0 auto;
				width: 20%
			}

			.row-cols-xxl-6>* {
				flex: 0 0 auto;
				width: 16.6666666667%
			}

			.col-xxl-auto {
				flex: 0 0 auto;
				width: auto
			}

			.col-xxl-1 {
				flex: 0 0 auto;
				width: 8.33333333%
			}

			.col-xxl-2 {
				flex: 0 0 auto;
				width: 16.66666667%
			}

			.col-xxl-3 {
				flex: 0 0 auto;
				width: 25%
			}

			.col-xxl-4 {
				flex: 0 0 auto;
				width: 33.33333333%
			}

			.col-xxl-5 {
				flex: 0 0 auto;
				width: 41.66666667%
			}

			.col-xxl-6 {
				flex: 0 0 auto;
				width: 50%
			}

			.col-xxl-7 {
				flex: 0 0 auto;
				width: 58.33333333%
			}

			.col-xxl-8 {
				flex: 0 0 auto;
				width: 66.66666667%
			}

			.col-xxl-9 {
				flex: 0 0 auto;
				width: 75%
			}

			.col-xxl-10 {
				flex: 0 0 auto;
				width: 83.33333333%
			}

			.col-xxl-11 {
				flex: 0 0 auto;
				width: 91.66666667%
			}

			.col-xxl-12 {
				flex: 0 0 auto;
				width: 100%
			}

			.offset-xxl-0 {
				margin-left: 0
			}

			.offset-xxl-1 {
				margin-left: 8.33333333%
			}

			.offset-xxl-2 {
				margin-left: 16.66666667%
			}

			.offset-xxl-3 {
				margin-left: 25%
			}

			.offset-xxl-4 {
				margin-left: 33.33333333%
			}

			.offset-xxl-5 {
				margin-left: 41.66666667%
			}

			.offset-xxl-6 {
				margin-left: 50%
			}

			.offset-xxl-7 {
				margin-left: 58.33333333%
			}

			.offset-xxl-8 {
				margin-left: 66.66666667%
			}

			.offset-xxl-9 {
				margin-left: 75%
			}

			.offset-xxl-10 {
				margin-left: 83.33333333%
			}

			.offset-xxl-11 {
				margin-left: 91.66666667%
			}

			.g-xxl-0,
			.gx-xxl-0 {
				--bs-gutter-x: 0
			}

			.g-xxl-0,
			.gy-xxl-0 {
				--bs-gutter-y: 0
			}

			.g-xxl-1,
			.gx-xxl-1 {
				--bs-gutter-x: 0.25rem
			}

			.g-xxl-1,
			.gy-xxl-1 {
				--bs-gutter-y: 0.25rem
			}

			.g-xxl-2,
			.gx-xxl-2 {
				--bs-gutter-x: 0.5rem
			}

			.g-xxl-2,
			.gy-xxl-2 {
				--bs-gutter-y: 0.5rem
			}

			.g-xxl-3,
			.gx-xxl-3 {
				--bs-gutter-x: 1rem
			}

			.g-xxl-3,
			.gy-xxl-3 {
				--bs-gutter-y: 1rem
			}

			.g-xxl-4,
			.gx-xxl-4 {
				--bs-gutter-x: 1.5rem
			}

			.g-xxl-4,
			.gy-xxl-4 {
				--bs-gutter-y: 1.5rem
			}

			.g-xxl-5,
			.gx-xxl-5 {
				--bs-gutter-x: 3rem
			}

			.g-xxl-5,
			.gy-xxl-5 {
				--bs-gutter-y: 3rem
			}
		}

		.table {
			--bs-table-color: var(--bs-body-color);
			--bs-table-bg: transparent;
			--bs-table-border-color: var(--bs-border-color);
			--bs-table-accent-bg: transparent;
			--bs-table-striped-color: var(--bs-body-color);
			--bs-table-striped-bg: rgba(0, 0, 0, 0.05);
			--bs-table-active-color: var(--bs-body-color);
			--bs-table-active-bg: rgba(0, 0, 0, 0.1);
			--bs-table-hover-color: var(--bs-body-color);
			--bs-table-hover-bg: rgba(0, 0, 0, 0.075);
			width: 100%;
			margin-bottom: 1rem;
			color: var(--bs-table-color);
			vertical-align: top;
			border-color: var(--bs-table-border-color)
		}

		.table>:not(caption)>*>* {
			padding: .5rem .5rem;
			background-color: var(--bs-table-bg);
			border-bottom-width: 1px;
			box-shadow: inset 0 0 0 9999px var(--bs-table-accent-bg)
		}

		.table>tbody {
			vertical-align: inherit
		}

		.table>thead {
			vertical-align: bottom
		}

		.table-group-divider {
			border-top: 2px solid currentcolor
		}

		.caption-top {
			caption-side: top
		}

		.table-sm>:not(caption)>*>* {
			padding: .25rem .25rem
		}

		.table-bordered>:not(caption)>* {
			border-width: 1px 0
		}

		.table-bordered>:not(caption)>*>* {
			border-width: 0 1px
		}

		.table-borderless>:not(caption)>*>* {
			border-bottom-width: 0
		}

		.table-borderless>:not(:first-child) {
			border-top-width: 0
		}

		.table-striped>tbody>tr:nth-of-type(odd)>* {
			--bs-table-accent-bg: var(--bs-table-striped-bg);
			color: var(--bs-table-striped-color)
		}

		.table-striped-columns>:not(caption)>tr>:nth-child(2n) {
			--bs-table-accent-bg: var(--bs-table-striped-bg);
			color: var(--bs-table-striped-color)
		}

		.table-active {
			--bs-table-accent-bg: var(--bs-table-active-bg);
			color: var(--bs-table-active-color)
		}

		.table-hover>tbody>tr:hover>* {
			--bs-table-accent-bg: var(--bs-table-hover-bg);
			color: var(--bs-table-hover-color)
		}

		.table-primary {
			--bs-table-color: #000;
			--bs-table-bg: #cfe2ff;
			--bs-table-border-color: #bacbe6;
			--bs-table-striped-bg: #c5d7f2;
			--bs-table-striped-color: #000;
			--bs-table-active-bg: #bacbe6;
			--bs-table-active-color: #000;
			--bs-table-hover-bg: #bfd1ec;
			--bs-table-hover-color: #000;
			color: var(--bs-table-color);
			border-color: var(--bs-table-border-color)
		}

		.table-secondary {
			--bs-table-color: #000;
			--bs-table-bg: #e2e3e5;
			--bs-table-border-color: #cbccce;
			--bs-table-striped-bg: #d7d8da;
			--bs-table-striped-color: #000;
			--bs-table-active-bg: #cbccce;
			--bs-table-active-color: #000;
			--bs-table-hover-bg: #d1d2d4;
			--bs-table-hover-color: #000;
			color: var(--bs-table-color);
			border-color: var(--bs-table-border-color)
		}

		.table-success {
			--bs-table-color: #000;
			--bs-table-bg: #d1e7dd;
			--bs-table-border-color: #bcd0c7;
			--bs-table-striped-bg: #c7dbd2;
			--bs-table-striped-color: #000;
			--bs-table-active-bg: #bcd0c7;
			--bs-table-active-color: #000;
			--bs-table-hover-bg: #c1d6cc;
			--bs-table-hover-color: #000;
			color: var(--bs-table-color);
			border-color: var(--bs-table-border-color)
		}

		.table-info {
			--bs-table-color: #000;
			--bs-table-bg: #cff4fc;
			--bs-table-border-color: #badce3;
			--bs-table-striped-bg: #c5e8ef;
			--bs-table-striped-color: #000;
			--bs-table-active-bg: #badce3;
			--bs-table-active-color: #000;
			--bs-table-hover-bg: #bfe2e9;
			--bs-table-hover-color: #000;
			color: var(--bs-table-color);
			border-color: var(--bs-table-border-color)
		}

		.table-warning {
			--bs-table-color: #000;
			--bs-table-bg: #fff3cd;
			--bs-table-border-color: #e6dbb9;
			--bs-table-striped-bg: #f2e7c3;
			--bs-table-striped-color: #000;
			--bs-table-active-bg: #e6dbb9;
			--bs-table-active-color: #000;
			--bs-table-hover-bg: #ece1be;
			--bs-table-hover-color: #000;
			color: var(--bs-table-color);
			border-color: var(--bs-table-border-color)
		}

		.table-danger {
			--bs-table-color: #000;
			--bs-table-bg: #f8d7da;
			--bs-table-border-color: #dfc2c4;
			--bs-table-striped-bg: #eccccf;
			--bs-table-striped-color: #000;
			--bs-table-active-bg: #dfc2c4;
			--bs-table-active-color: #000;
			--bs-table-hover-bg: #e5c7ca;
			--bs-table-hover-color: #000;
			color: var(--bs-table-color);
			border-color: var(--bs-table-border-color)
		}

		.table-light {
			--bs-table-color: #000;
			--bs-table-bg: #f8f9fa;
			--bs-table-border-color: #dfe0e1;
			--bs-table-striped-bg: #ecedee;
			--bs-table-striped-color: #000;
			--bs-table-active-bg: #dfe0e1;
			--bs-table-active-color: #000;
			--bs-table-hover-bg: #e5e6e7;
			--bs-table-hover-color: #000;
			color: var(--bs-table-color);
			border-color: var(--bs-table-border-color)
		}

		.table-dark {
			--bs-table-color: #fff;
			--bs-table-bg: #212529;
			--bs-table-border-color: #373b3e;
			--bs-table-striped-bg: #2c3034;
			--bs-table-striped-color: #fff;
			--bs-table-active-bg: #373b3e;
			--bs-table-active-color: #fff;
			--bs-table-hover-bg: #323539;
			--bs-table-hover-color: #fff;
			color: var(--bs-table-color);
			border-color: var(--bs-table-border-color)
		}

		.table-responsive {
			overflow-x: auto;
			-webkit-overflow-scrolling: touch
		}

		@media (max-width:575.98px) {
			.table-responsive-sm {
				overflow-x: auto;
				-webkit-overflow-scrolling: touch
			}
		}

		@media (max-width:767.98px) {
			.table-responsive-md {
				overflow-x: auto;
				-webkit-overflow-scrolling: touch
			}
		}

		@media (max-width:991.98px) {
			.table-responsive-lg {
				overflow-x: auto;
				-webkit-overflow-scrolling: touch
			}
		}

		@media (max-width:1199.98px) {
			.table-responsive-xl {
				overflow-x: auto;
				-webkit-overflow-scrolling: touch
			}
		}

		@media (max-width:1399.98px) {
			.table-responsive-xxl {
				overflow-x: auto;
				-webkit-overflow-scrolling: touch
			}
		}

		.form-label {
			margin-bottom: .5rem
		}

		.col-form-label {
			padding-top: calc(.375rem + 1px);
			padding-bottom: calc(.375rem + 1px);
			margin-bottom: 0;
			font-size: inherit;
			line-height: 1.5
		}

		.col-form-label-lg {
			padding-top: calc(.5rem + 1px);
			padding-bottom: calc(.5rem + 1px);
			font-size: 1.25rem
		}

		.col-form-label-sm {
			padding-top: calc(.25rem + 1px);
			padding-bottom: calc(.25rem + 1px);
			font-size: .875rem
		}

		.form-text {
			margin-top: .25rem;
			font-size: .875em;
			color: #6c757d
		}

		.form-control {
			display: block;
			width: 100%;
			padding: .375rem .75rem;
			font-size: 1rem;
			font-weight: 400;
			line-height: 1.5;
			color: #212529;
			background-color: #fff;
			background-clip: padding-box;
			border: 1px solid #ced4da;
			-webkit-appearance: none;
			-moz-appearance: none;
			appearance: none;
			border-radius: .375rem;
			transition: border-color .15s ease-in-out, box-shadow .15s ease-in-out
		}

		@media (prefers-reduced-motion:reduce) {
			.form-control {
				transition: none
			}
		}

		.form-control[type=file] {
			overflow: hidden
		}

		.form-control[type=file]:not(:disabled):not([readonly]) {
			cursor: pointer
		}

		.form-control:focus {
			color: #212529;
			background-color: #fff;
			border-color: #86b7fe;
			outline: 0;
			box-shadow: 0 0 0 .25rem rgba(13, 110, 253, .25)
		}

		.form-control::-webkit-date-and-time-value {
			height: 1.5em
		}

		.form-control::-moz-placeholder {
			color: #6c757d;
			opacity: 1
		}

		.form-control::placeholder {
			color: #6c757d;
			opacity: 1
		}

		.form-control:disabled {
			background-color: #e9ecef;
			opacity: 1
		}

		.form-control::-webkit-file-upload-button {
			padding: .375rem .75rem;
			margin: -.375rem -.75rem;
			-webkit-margin-end: .75rem;
			margin-inline-end: .75rem;
			color: #212529;
			background-color: #e9ecef;
			pointer-events: none;
			border-color: inherit;
			border-style: solid;
			border-width: 0;
			border-inline-end-width: 1px;
			border-radius: 0;
			-webkit-transition: color .15s ease-in-out, background-color .15s ease-in-out, border-color .15s ease-in-out, box-shadow .15s ease-in-out;
			transition: color .15s ease-in-out, background-color .15s ease-in-out, border-color .15s ease-in-out, box-shadow .15s ease-in-out
		}

		.form-control::file-selector-button {
			padding: .375rem .75rem;
			margin: -.375rem -.75rem;
			-webkit-margin-end: .75rem;
			margin-inline-end: .75rem;
			color: #212529;
			background-color: #e9ecef;
			pointer-events: none;
			border-color: inherit;
			border-style: solid;
			border-width: 0;
			border-inline-end-width: 1px;
			border-radius: 0;
			transition: color .15s ease-in-out, background-color .15s ease-in-out, border-color .15s ease-in-out, box-shadow .15s ease-in-out
		}

		@media (prefers-reduced-motion:reduce) {
			.form-control::-webkit-file-upload-button {
				-webkit-transition: none;
				transition: none
			}

			.form-control::file-selector-button {
				transition: none
			}
		}

		.form-control:hover:not(:disabled):not([readonly])::-webkit-file-upload-button {
			background-color: #dde0e3
		}

		.form-control:hover:not(:disabled):not([readonly])::file-selector-button {
			background-color: #dde0e3
		}

		.form-control-plaintext {
			display: block;
			width: 100%;
			padding: .375rem 0;
			margin-bottom: 0;
			line-height: 1.5;
			color: #212529;
			background-color: transparent;
			border: solid transparent;
			border-width: 1px 0
		}

		.form-control-plaintext:focus {
			outline: 0
		}

		.form-control-plaintext.form-control-lg,
		.form-control-plaintext.form-control-sm {
			padding-right: 0;
			padding-left: 0
		}

		.form-control-sm {
			min-height: calc(1.5em + .5rem + 2px);
			padding: .25rem .5rem;
			font-size: .875rem;
			border-radius: .25rem
		}

		.form-control-sm::-webkit-file-upload-button {
			padding: .25rem .5rem;
			margin: -.25rem -.5rem;
			-webkit-margin-end: .5rem;
			margin-inline-end: .5rem
		}

		.form-control-sm::file-selector-button {
			padding: .25rem .5rem;
			margin: -.25rem -.5rem;
			-webkit-margin-end: .5rem;
			margin-inline-end: .5rem
		}

		.form-control-lg {
			min-height: calc(1.5em + 1rem + 2px);
			padding: .5rem 1rem;
			font-size: 1.25rem;
			border-radius: .5rem
		}

		.form-control-lg::-webkit-file-upload-button {
			padding: .5rem 1rem;
			margin: -.5rem -1rem;
			-webkit-margin-end: 1rem;
			margin-inline-end: 1rem
		}

		.form-control-lg::file-selector-button {
			padding: .5rem 1rem;
			margin: -.5rem -1rem;
			-webkit-margin-end: 1rem;
			margin-inline-end: 1rem
		}

		textarea.form-control {
			min-height: calc(1.5em + .75rem + 2px)
		}

		textarea.form-control-sm {
			min-height: calc(1.5em + .5rem + 2px)
		}

		textarea.form-control-lg {
			min-height: calc(1.5em + 1rem + 2px)
		}

		.form-control-color {
			width: 3rem;
			height: calc(1.5em + .75rem + 2px);
			padding: .375rem
		}

		.form-control-color:not(:disabled):not([readonly]) {
			cursor: pointer
		}

		.form-control-color::-moz-color-swatch {
			border: 0 !important;
			border-radius: .375rem
		}

		.form-control-color::-webkit-color-swatch {
			border-radius: .375rem
		}

		.form-control-color.form-control-sm {
			height: calc(1.5em + .5rem + 2px)
		}

		.form-control-color.form-control-lg {
			height: calc(1.5em + 1rem + 2px)
		}

		.form-select {
			display: block;
			width: 100%;
			padding: .375rem 2.25rem .375rem .75rem;
			-moz-padding-start: calc(0.75rem - 3px);
			font-size: 1rem;
			font-weight: 400;
			line-height: 1.5;
			color: #212529;
			background-color: #fff;
			background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16'%3e%3cpath fill='none' stroke='%23343a40' stroke-linecap='round' stroke-linejoin='round' stroke-width='2' d='m2 5 6 6 6-6'/%3e%3c/svg%3e");
			background-repeat: no-repeat;
			background-position: right .75rem center;
			background-size: 16px 12px;
			border: 1px solid #ced4da;
			border-radius: .375rem;
			transition: border-color .15s ease-in-out, box-shadow .15s ease-in-out;
			-webkit-appearance: none;
			-moz-appearance: none;
			appearance: none
		}

		@media (prefers-reduced-motion:reduce) {
			.form-select {
				transition: none
			}
		}

		.form-select:focus {
			border-color: #86b7fe;
			outline: 0;
			box-shadow: 0 0 0 .25rem rgba(13, 110, 253, .25)
		}

		.form-select[multiple],
		.form-select[size]:not([size="1"]) {
			padding-right: .75rem;
			background-image: none
		}

		.form-select:disabled {
			background-color: #e9ecef
		}

		.form-select:-moz-focusring {
			color: transparent;
			text-shadow: 0 0 0 #212529
		}

		.form-select-sm {
			padding-top: .25rem;
			padding-bottom: .25rem;
			padding-left: .5rem;
			font-size: .875rem;
			border-radius: .25rem
		}

		.form-select-lg {
			padding-top: .5rem;
			padding-bottom: .5rem;
			padding-left: 1rem;
			font-size: 1.25rem;
			border-radius: .5rem
		}

		.form-check {
			display: block;
			min-height: 1.5rem;
			padding-left: 1.5em;
			margin-bottom: .125rem
		}

		.form-check .form-check-input {
			float: left;
			margin-left: -1.5em
		}

		.form-check-reverse {
			padding-right: 1.5em;
			padding-left: 0;
			text-align: right
		}

		.form-check-reverse .form-check-input {
			float: right;
			margin-right: -1.5em;
			margin-left: 0
		}

		.form-check-input {
			width: 1em;
			height: 1em;
			margin-top: .25em;
			vertical-align: top;
			background-color: #fff;
			background-repeat: no-repeat;
			background-position: center;
			background-size: contain;
			border: 1px solid rgba(0, 0, 0, .25);
			-webkit-appearance: none;
			-moz-appearance: none;
			appearance: none;
			-webkit-print-color-adjust: exact;
			color-adjust: exact;
			print-color-adjust: exact
		}

		.form-check-input[type=checkbox] {
			border-radius: .25em
		}

		.form-check-input[type=radio] {
			border-radius: 50%
		}

		.form-check-input:active {
			filter: brightness(90%)
		}

		.form-check-input:focus {
			border-color: #86b7fe;
			outline: 0;
			box-shadow: 0 0 0 .25rem rgba(13, 110, 253, .25)
		}

		.form-check-input:checked {
			background-color: #0d6efd;
			border-color: #0d6efd
		}

		.form-check-input:checked[type=checkbox] {
			background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 20 20'%3e%3cpath fill='none' stroke='%23fff' stroke-linecap='round' stroke-linejoin='round' stroke-width='3' d='m6 10 3 3 6-6'/%3e%3c/svg%3e")
		}

		.form-check-input:checked[type=radio] {
			background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='-4 -4 8 8'%3e%3ccircle r='2' fill='%23fff'/%3e%3c/svg%3e")
		}

		.form-check-input[type=checkbox]:indeterminate {
			background-color: #0d6efd;
			border-color: #0d6efd;
			background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 20 20'%3e%3cpath fill='none' stroke='%23fff' stroke-linecap='round' stroke-linejoin='round' stroke-width='3' d='M6 10h8'/%3e%3c/svg%3e")
		}

		.form-check-input:disabled {
			pointer-events: none;
			filter: none;
			opacity: .5
		}

		.form-check-input:disabled~.form-check-label,
		.form-check-input[disabled]~.form-check-label {
			cursor: default;
			opacity: .5
		}

		.form-switch {
			padding-left: 2.5em
		}

		.form-switch .form-check-input {
			width: 2em;
			margin-left: -2.5em;
			background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='-4 -4 8 8'%3e%3ccircle r='3' fill='rgba%280, 0, 0, 0.25%29'/%3e%3c/svg%3e");
			background-position: left center;
			border-radius: 2em;
			transition: background-position .15s ease-in-out
		}

		@media (prefers-reduced-motion:reduce) {
			.form-switch .form-check-input {
				transition: none
			}
		}

		.form-switch .form-check-input:focus {
			background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='-4 -4 8 8'%3e%3ccircle r='3' fill='%2386b7fe'/%3e%3c/svg%3e")
		}

		.form-switch .form-check-input:checked {
			background-position: right center;
			background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='-4 -4 8 8'%3e%3ccircle r='3' fill='%23fff'/%3e%3c/svg%3e")
		}

		.form-switch.form-check-reverse {
			padding-right: 2.5em;
			padding-left: 0
		}

		.form-switch.form-check-reverse .form-check-input {
			margin-right: -2.5em;
			margin-left: 0
		}

		.form-check-inline {
			display: inline-block;
			margin-right: 1rem
		}

		.btn-check {
			position: absolute;
			clip: rect(0, 0, 0, 0);
			pointer-events: none
		}

		.btn-check:disabled+.btn,
		.btn-check[disabled]+.btn {
			pointer-events: none;
			filter: none;
			opacity: .65
		}

		.form-range {
			width: 100%;
			height: 1.5rem;
			padding: 0;
			background-color: transparent;
			-webkit-appearance: none;
			-moz-appearance: none;
			appearance: none
		}

		.form-range:focus {
			outline: 0
		}

		.form-range:focus::-webkit-slider-thumb {
			box-shadow: 0 0 0 1px #fff, 0 0 0 .25rem rgba(13, 110, 253, .25)
		}

		.form-range:focus::-moz-range-thumb {
			box-shadow: 0 0 0 1px #fff, 0 0 0 .25rem rgba(13, 110, 253, .25)
		}

		.form-range::-moz-focus-outer {
			border: 0
		}

		.form-range::-webkit-slider-thumb {
			width: 1rem;
			height: 1rem;
			margin-top: -.25rem;
			background-color: #0d6efd;
			border: 0;
			border-radius: 1rem;
			-webkit-transition: background-color .15s ease-in-out, border-color .15s ease-in-out, box-shadow .15s ease-in-out;
			transition: background-color .15s ease-in-out, border-color .15s ease-in-out, box-shadow .15s ease-in-out;
			-webkit-appearance: none;
			appearance: none
		}

		@media (prefers-reduced-motion:reduce) {
			.form-range::-webkit-slider-thumb {
				-webkit-transition: none;
				transition: none
			}
		}

		.form-range::-webkit-slider-thumb:active {
			background-color: #b6d4fe
		}

		.form-range::-webkit-slider-runnable-track {
			width: 100%;
			height: .5rem;
			color: transparent;
			cursor: pointer;
			background-color: #dee2e6;
			border-color: transparent;
			border-radius: 1rem
		}

		.form-range::-moz-range-thumb {
			width: 1rem;
			height: 1rem;
			background-color: #0d6efd;
			border: 0;
			border-radius: 1rem;
			-moz-transition: background-color .15s ease-in-out, border-color .15s ease-in-out, box-shadow .15s ease-in-out;
			transition: background-color .15s ease-in-out, border-color .15s ease-in-out, box-shadow .15s ease-in-out;
			-moz-appearance: none;
			appearance: none
		}

		@media (prefers-reduced-motion:reduce) {
			.form-range::-moz-range-thumb {
				-moz-transition: none;
				transition: none
			}
		}

		.form-range::-moz-range-thumb:active {
			background-color: #b6d4fe
		}

		.form-range::-moz-range-track {
			width: 100%;
			height: .5rem;
			color: transparent;
			cursor: pointer;
			background-color: #dee2e6;
			border-color: transparent;
			border-radius: 1rem
		}

		.form-range:disabled {
			pointer-events: none
		}

		.form-range:disabled::-webkit-slider-thumb {
			background-color: #adb5bd
		}

		.form-range:disabled::-moz-range-thumb {
			background-color: #adb5bd
		}

		.form-floating {
			position: relative
		}

		.form-floating>.form-control,
		.form-floating>.form-control-plaintext,
		.form-floating>.form-select {
			height: calc(3.5rem + 2px);
			line-height: 1.25
		}

		.form-floating>label {
			position: absolute;
			top: 0;
			left: 0;
			width: 100%;
			height: 100%;
			padding: 1rem .75rem;
			overflow: hidden;
			text-overflow: ellipsis;
			white-space: nowrap;
			pointer-events: none;
			border: 1px solid transparent;
			transform-origin: 0 0;
			transition: opacity .1s ease-in-out, transform .1s ease-in-out
		}

		@media (prefers-reduced-motion:reduce) {
			.form-floating>label {
				transition: none
			}
		}

		.form-floating>.form-control,
		.form-floating>.form-control-plaintext {
			padding: 1rem .75rem
		}

		.form-floating>.form-control-plaintext::-moz-placeholder,
		.form-floating>.form-control::-moz-placeholder {
			color: transparent
		}

		.form-floating>.form-control-plaintext::placeholder,
		.form-floating>.form-control::placeholder {
			color: transparent
		}

		.form-floating>.form-control-plaintext:not(:-moz-placeholder-shown),
		.form-floating>.form-control:not(:-moz-placeholder-shown) {
			padding-top: 1.625rem;
			padding-bottom: .625rem
		}

		.form-floating>.form-control-plaintext:focus,
		.form-floating>.form-control-plaintext:not(:placeholder-shown),
		.form-floating>.form-control:focus,
		.form-floating>.form-control:not(:placeholder-shown) {
			padding-top: 1.625rem;
			padding-bottom: .625rem
		}

		.form-floating>.form-control-plaintext:-webkit-autofill,
		.form-floating>.form-control:-webkit-autofill {
			padding-top: 1.625rem;
			padding-bottom: .625rem
		}

		.form-floating>.form-select {
			padding-top: 1.625rem;
			padding-bottom: .625rem
		}

		.form-floating>.form-control:not(:-moz-placeholder-shown)~label {
			opacity: .65;
			transform: scale(.85) translateY(-.5rem) translateX(.15rem)
		}

		.form-floating>.form-control-plaintext~label,
		.form-floating>.form-control:focus~label,
		.form-floating>.form-control:not(:placeholder-shown)~label,
		.form-floating>.form-select~label {
			opacity: .65;
			transform: scale(.85) translateY(-.5rem) translateX(.15rem)
		}

		.form-floating>.form-control:-webkit-autofill~label {
			opacity: .65;
			transform: scale(.85) translateY(-.5rem) translateX(.15rem)
		}

		.form-floating>.form-control-plaintext~label {
			border-width: 1px 0
		}

		.input-group {
			position: relative;
			display: flex;
			flex-wrap: wrap;
			align-items: stretch;
			width: 100%
		}

		.input-group>.form-control,
		.input-group>.form-floating,
		.input-group>.form-select {
			position: relative;
			flex: 1 1 auto;
			width: 1%;
			min-width: 0
		}

		.input-group>.form-control:focus,
		.input-group>.form-floating:focus-within,
		.input-group>.form-select:focus {
			z-index: 3
		}

		.input-group .btn {
			position: relative;
			z-index: 2
		}

		.input-group .btn:focus {
			z-index: 3
		}

		.input-group-text {
			display: flex;
			align-items: center;
			padding: .375rem .75rem;
			font-size: 1rem;
			font-weight: 400;
			line-height: 1.5;
			color: #212529;
			text-align: center;
			white-space: nowrap;
			background-color: #e9ecef;
			border: 1px solid #ced4da;
			border-radius: .375rem
		}

		.input-group-lg>.btn,
		.input-group-lg>.form-control,
		.input-group-lg>.form-select,
		.input-group-lg>.input-group-text {
			padding: .5rem 1rem;
			font-size: 1.25rem;
			border-radius: .5rem
		}

		.input-group-sm>.btn,
		.input-group-sm>.form-control,
		.input-group-sm>.form-select,
		.input-group-sm>.input-group-text {
			padding: .25rem .5rem;
			font-size: .875rem;
			border-radius: .25rem
		}

		.input-group-lg>.form-select,
		.input-group-sm>.form-select {
			padding-right: 3rem
		}

		.input-group:not(.has-validation)>.dropdown-toggle:nth-last-child(n+3),
		.input-group:not(.has-validation)>.form-floating:not(:last-child)>.form-control,
		.input-group:not(.has-validation)>.form-floating:not(:last-child)>.form-select,
		.input-group:not(.has-validation)>:not(:last-child):not(.dropdown-toggle):not(.dropdown-menu):not(.form-floating) {
			border-top-right-radius: 0;
			border-bottom-right-radius: 0
		}

		.input-group.has-validation>.dropdown-toggle:nth-last-child(n+4),
		.input-group.has-validation>.form-floating:nth-last-child(n+3)>.form-control,
		.input-group.has-validation>.form-floating:nth-last-child(n+3)>.form-select,
		.input-group.has-validation>:nth-last-child(n+3):not(.dropdown-toggle):not(.dropdown-menu):not(.form-floating) {
			border-top-right-radius: 0;
			border-bottom-right-radius: 0
		}

		.input-group>.form-floating:not(:first-child)>.form-control,
		.input-group>.form-floating:not(:first-child)>.form-select,
		.input-group>:not(:first-child):not(.dropdown-menu):not(.form-floating):not(.valid-tooltip):not(.valid-feedback):not(.invalid-tooltip):not(.invalid-feedback) {
			margin-left: -1px;
			border-top-left-radius: 0;
			border-bottom-left-radius: 0
		}

		.valid-feedback {
			display: none;
			width: 100%;
			margin-top: .25rem;
			font-size: .875em;
			color: #198754
		}

		.valid-tooltip {
			position: absolute;
			top: 100%;
			z-index: 5;
			display: none;
			max-width: 100%;
			padding: .25rem .5rem;
			margin-top: .1rem;
			font-size: .875rem;
			color: #fff;
			background-color: rgba(25, 135, 84, .9);
			border-radius: .375rem
		}

		.is-valid~.valid-feedback,
		.is-valid~.valid-tooltip,
		.was-validated :valid~.valid-feedback,
		.was-validated :valid~.valid-tooltip {
			display: block
		}

		.form-control.is-valid,
		.was-validated .form-control:valid {
			border-color: #198754;
			padding-right: calc(1.5em + .75rem);
			background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 8 8'%3e%3cpath fill='%23198754' d='M2.3 6.73.6 4.53c-.4-1.04.46-1.4 1.1-.8l1.1 1.4 3.4-3.8c.6-.63 1.6-.27 1.2.7l-4 4.6c-.43.5-.8.4-1.1.1z'/%3e%3c/svg%3e");
			background-repeat: no-repeat;
			background-position: right calc(.375em + .1875rem) center;
			background-size: calc(.75em + .375rem) calc(.75em + .375rem)
		}

		.form-control.is-valid:focus,
		.was-validated .form-control:valid:focus {
			border-color: #198754;
			box-shadow: 0 0 0 .25rem rgba(25, 135, 84, .25)
		}

		.was-validated textarea.form-control:valid,
		textarea.form-control.is-valid {
			padding-right: calc(1.5em + .75rem);
			background-position: top calc(.375em + .1875rem) right calc(.375em + .1875rem)
		}

		.form-select.is-valid,
		.was-validated .form-select:valid {
			border-color: #198754
		}

		.form-select.is-valid:not([multiple]):not([size]),
		.form-select.is-valid:not([multiple])[size="1"],
		.was-validated .form-select:valid:not([multiple]):not([size]),
		.was-validated .form-select:valid:not([multiple])[size="1"] {
			padding-right: 4.125rem;
			background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16'%3e%3cpath fill='none' stroke='%23343a40' stroke-linecap='round' stroke-linejoin='round' stroke-width='2' d='m2 5 6 6 6-6'/%3e%3c/svg%3e"), url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 8 8'%3e%3cpath fill='%23198754' d='M2.3 6.73.6 4.53c-.4-1.04.46-1.4 1.1-.8l1.1 1.4 3.4-3.8c.6-.63 1.6-.27 1.2.7l-4 4.6c-.43.5-.8.4-1.1.1z'/%3e%3c/svg%3e");
			background-position: right .75rem center, center right 2.25rem;
			background-size: 16px 12px, calc(.75em + .375rem) calc(.75em + .375rem)
		}

		.form-select.is-valid:focus,
		.was-validated .form-select:valid:focus {
			border-color: #198754;
			box-shadow: 0 0 0 .25rem rgba(25, 135, 84, .25)
		}

		.form-control-color.is-valid,
		.was-validated .form-control-color:valid {
			width: calc(3rem + calc(1.5em + .75rem))
		}

		.form-check-input.is-valid,
		.was-validated .form-check-input:valid {
			border-color: #198754
		}

		.form-check-input.is-valid:checked,
		.was-validated .form-check-input:valid:checked {
			background-color: #198754
		}

		.form-check-input.is-valid:focus,
		.was-validated .form-check-input:valid:focus {
			box-shadow: 0 0 0 .25rem rgba(25, 135, 84, .25)
		}

		.form-check-input.is-valid~.form-check-label,
		.was-validated .form-check-input:valid~.form-check-label {
			color: #198754
		}

		.form-check-inline .form-check-input~.valid-feedback {
			margin-left: .5em
		}

		.input-group .form-control.is-valid,
		.input-group .form-select.is-valid,
		.was-validated .input-group .form-control:valid,
		.was-validated .input-group .form-select:valid {
			z-index: 1
		}

		.input-group .form-control.is-valid:focus,
		.input-group .form-select.is-valid:focus,
		.was-validated .input-group .form-control:valid:focus,
		.was-validated .input-group .form-select:valid:focus {
			z-index: 3
		}

		.invalid-feedback {
			display: none;
			width: 100%;
			margin-top: .25rem;
			font-size: .875em;
			color: #dc3545
		}

		.invalid-tooltip {
			position: absolute;
			top: 100%;
			z-index: 5;
			display: none;
			max-width: 100%;
			padding: .25rem .5rem;
			margin-top: .1rem;
			font-size: .875rem;
			color: #fff;
			background-color: rgba(220, 53, 69, .9);
			border-radius: .375rem
		}

		.is-invalid~.invalid-feedback,
		.is-invalid~.invalid-tooltip,
		.was-validated :invalid~.invalid-feedback,
		.was-validated :invalid~.invalid-tooltip {
			display: block
		}

		.form-control.is-invalid,
		.was-validated .form-control:invalid {
			border-color: #dc3545;
			padding-right: calc(1.5em + .75rem);
			background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 12 12' width='12' height='12' fill='none' stroke='%23dc3545'%3e%3ccircle cx='6' cy='6' r='4.5'/%3e%3cpath stroke-linejoin='round' d='M5.8 3.6h.4L6 6.5z'/%3e%3ccircle cx='6' cy='8.2' r='.6' fill='%23dc3545' stroke='none'/%3e%3c/svg%3e");
			background-repeat: no-repeat;
			background-position: right calc(.375em + .1875rem) center;
			background-size: calc(.75em + .375rem) calc(.75em + .375rem)
		}

		.form-control.is-invalid:focus,
		.was-validated .form-control:invalid:focus {
			border-color: #dc3545;
			box-shadow: 0 0 0 .25rem rgba(220, 53, 69, .25)
		}

		.was-validated textarea.form-control:invalid,
		textarea.form-control.is-invalid {
			padding-right: calc(1.5em + .75rem);
			background-position: top calc(.375em + .1875rem) right calc(.375em + .1875rem)
		}

		.form-select.is-invalid,
		.was-validated .form-select:invalid {
			border-color: #dc3545
		}

		.form-select.is-invalid:not([multiple]):not([size]),
		.form-select.is-invalid:not([multiple])[size="1"],
		.was-validated .form-select:invalid:not([multiple]):not([size]),
		.was-validated .form-select:invalid:not([multiple])[size="1"] {
			padding-right: 4.125rem;
			background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16'%3e%3cpath fill='none' stroke='%23343a40' stroke-linecap='round' stroke-linejoin='round' stroke-width='2' d='m2 5 6 6 6-6'/%3e%3c/svg%3e"), url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 12 12' width='12' height='12' fill='none' stroke='%23dc3545'%3e%3ccircle cx='6' cy='6' r='4.5'/%3e%3cpath stroke-linejoin='round' d='M5.8 3.6h.4L6 6.5z'/%3e%3ccircle cx='6' cy='8.2' r='.6' fill='%23dc3545' stroke='none'/%3e%3c/svg%3e");
			background-position: right .75rem center, center right 2.25rem;
			background-size: 16px 12px, calc(.75em + .375rem) calc(.75em + .375rem)
		}

		.form-select.is-invalid:focus,
		.was-validated .form-select:invalid:focus {
			border-color: #dc3545;
			box-shadow: 0 0 0 .25rem rgba(220, 53, 69, .25)
		}

		.form-control-color.is-invalid,
		.was-validated .form-control-color:invalid {
			width: calc(3rem + calc(1.5em + .75rem))
		}

		.form-check-input.is-invalid,
		.was-validated .form-check-input:invalid {
			border-color: #dc3545
		}

		.form-check-input.is-invalid:checked,
		.was-validated .form-check-input:invalid:checked {
			background-color: #dc3545
		}

		.form-check-input.is-invalid:focus,
		.was-validated .form-check-input:invalid:focus {
			box-shadow: 0 0 0 .25rem rgba(220, 53, 69, .25)
		}

		.form-check-input.is-invalid~.form-check-label,
		.was-validated .form-check-input:invalid~.form-check-label {
			color: #dc3545
		}

		.form-check-inline .form-check-input~.invalid-feedback {
			margin-left: .5em
		}

		.input-group .form-control.is-invalid,
		.input-group .form-select.is-invalid,
		.was-validated .input-group .form-control:invalid,
		.was-validated .input-group .form-select:invalid {
			z-index: 2
		}

		.input-group .form-control.is-invalid:focus,
		.input-group .form-select.is-invalid:focus,
		.was-validated .input-group .form-control:invalid:focus,
		.was-validated .input-group .form-select:invalid:focus {
			z-index: 3
		}

		.btn {
			--bs-btn-padding-x: 0.75rem;
			--bs-btn-padding-y: 0.375rem;
			--bs-btn-font-family: ;
			--bs-btn-font-size: 1rem;
			--bs-btn-font-weight: 400;
			--bs-btn-line-height: 1.5;
			--bs-btn-color: #212529;
			--bs-btn-bg: transparent;
			--bs-btn-border-width: 1px;
			--bs-btn-border-color: transparent;
			--bs-btn-border-radius: 0.375rem;
			--bs-btn-box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.15), 0 1px 1px rgba(0, 0, 0, 0.075);
			--bs-btn-disabled-opacity: 0.65;
			--bs-btn-focus-box-shadow: 0 0 0 0.25rem rgba(var(--bs-btn-focus-shadow-rgb), .5);
			display: inline-block;
			padding: var(--bs-btn-padding-y) var(--bs-btn-padding-x);
			font-family: var(--bs-btn-font-family);
			font-size: var(--bs-btn-font-size);
			font-weight: var(--bs-btn-font-weight);
			line-height: var(--bs-btn-line-height);
			color: var(--bs-btn-color);
			text-align: center;
			text-decoration: none;
			vertical-align: middle;
			cursor: pointer;
			-webkit-user-select: none;
			-moz-user-select: none;
			user-select: none;
			border: var(--bs-btn-border-width) solid var(--bs-btn-border-color);
			border-radius: var(--bs-btn-border-radius);
			background-color: var(--bs-btn-bg);
			transition: color .15s ease-in-out, background-color .15s ease-in-out, border-color .15s ease-in-out, box-shadow .15s ease-in-out
		}

		@media (prefers-reduced-motion:reduce) {
			.btn {
				transition: none
			}
		}

		.btn:hover {
			color: var(--bs-btn-hover-color);
			background-color: var(--bs-btn-hover-bg);
			border-color: var(--bs-btn-hover-border-color)
		}

		.btn-check:focus+.btn,
		.btn:focus {
			color: var(--bs-btn-hover-color);
			background-color: var(--bs-btn-hover-bg);
			border-color: var(--bs-btn-hover-border-color);
			outline: 0;
			box-shadow: var(--bs-btn-focus-box-shadow)
		}

		.btn-check:active+.btn,
		.btn-check:checked+.btn,
		.btn.active,
		.btn.show,
		.btn:active {
			color: var(--bs-btn-active-color);
			background-color: var(--bs-btn-active-bg);
			border-color: var(--bs-btn-active-border-color)
		}

		.btn-check:active+.btn:focus,
		.btn-check:checked+.btn:focus,
		.btn.active:focus,
		.btn.show:focus,
		.btn:active:focus {
			box-shadow: var(--bs-btn-focus-box-shadow)
		}

		.btn.disabled,
		.btn:disabled,
		fieldset:disabled .btn {
			color: var(--bs-btn-disabled-color);
			pointer-events: none;
			background-color: var(--bs-btn-disabled-bg);
			border-color: var(--bs-btn-disabled-border-color);
			opacity: var(--bs-btn-disabled-opacity)
		}

		.btn-primary {
			--bs-btn-color: #fff;
			--bs-btn-bg: #0d6efd;
			--bs-btn-border-color: #0d6efd;
			--bs-btn-hover-color: #fff;
			--bs-btn-hover-bg: #0b5ed7;
			--bs-btn-hover-border-color: #0a58ca;
			--bs-btn-focus-shadow-rgb: 49, 132, 253;
			--bs-btn-active-color: #fff;
			--bs-btn-active-bg: #0a58ca;
			--bs-btn-active-border-color: #0a53be;
			--bs-btn-active-shadow: inset 0 3px 5px rgba(0, 0, 0, 0.125);
			--bs-btn-disabled-color: #fff;
			--bs-btn-disabled-bg: #0d6efd;
			--bs-btn-disabled-border-color: #0d6efd
		}

		.btn-secondary {
			--bs-btn-color: #fff;
			--bs-btn-bg: #6c757d;
			--bs-btn-border-color: #6c757d;
			--bs-btn-hover-color: #fff;
			--bs-btn-hover-bg: #5c636a;
			--bs-btn-hover-border-color: #565e64;
			--bs-btn-focus-shadow-rgb: 130, 138, 145;
			--bs-btn-active-color: #fff;
			--bs-btn-active-bg: #565e64;
			--bs-btn-active-border-color: #51585e;
			--bs-btn-active-shadow: inset 0 3px 5px rgba(0, 0, 0, 0.125);
			--bs-btn-disabled-color: #fff;
			--bs-btn-disabled-bg: #6c757d;
			--bs-btn-disabled-border-color: #6c757d
		}

		.btn-success {
			--bs-btn-color: #fff;
			--bs-btn-bg: #198754;
			--bs-btn-border-color: #198754;
			--bs-btn-hover-color: #fff;
			--bs-btn-hover-bg: #157347;
			--bs-btn-hover-border-color: #146c43;
			--bs-btn-focus-shadow-rgb: 60, 153, 110;
			--bs-btn-active-color: #fff;
			--bs-btn-active-bg: #146c43;
			--bs-btn-active-border-color: #13653f;
			--bs-btn-active-shadow: inset 0 3px 5px rgba(0, 0, 0, 0.125);
			--bs-btn-disabled-color: #fff;
			--bs-btn-disabled-bg: #198754;
			--bs-btn-disabled-border-color: #198754
		}

		.btn-info {
			--bs-btn-color: #000;
			--bs-btn-bg: #0dcaf0;
			--bs-btn-border-color: #0dcaf0;
			--bs-btn-hover-color: #000;
			--bs-btn-hover-bg: #31d2f2;
			--bs-btn-hover-border-color: #25cff2;
			--bs-btn-focus-shadow-rgb: 11, 172, 204;
			--bs-btn-active-color: #000;
			--bs-btn-active-bg: #3dd5f3;
			--bs-btn-active-border-color: #25cff2;
			--bs-btn-active-shadow: inset 0 3px 5px rgba(0, 0, 0, 0.125);
			--bs-btn-disabled-color: #000;
			--bs-btn-disabled-bg: #0dcaf0;
			--bs-btn-disabled-border-color: #0dcaf0
		}

		.btn-warning {
			--bs-btn-color: #000;
			--bs-btn-bg: #ffc107;
			--bs-btn-border-color: #ffc107;
			--bs-btn-hover-color: #000;
			--bs-btn-hover-bg: #ffca2c;
			--bs-btn-hover-border-color: #ffc720;
			--bs-btn-focus-shadow-rgb: 217, 164, 6;
			--bs-btn-active-color: #000;
			--bs-btn-active-bg: #ffcd39;
			--bs-btn-active-border-color: #ffc720;
			--bs-btn-active-shadow: inset 0 3px 5px rgba(0, 0, 0, 0.125);
			--bs-btn-disabled-color: #000;
			--bs-btn-disabled-bg: #ffc107;
			--bs-btn-disabled-border-color: #ffc107
		}

		.btn-danger {
			--bs-btn-color: #fff;
			--bs-btn-bg: #dc3545;
			--bs-btn-border-color: #dc3545;
			--bs-btn-hover-color: #fff;
			--bs-btn-hover-bg: #bb2d3b;
			--bs-btn-hover-border-color: #b02a37;
			--bs-btn-focus-shadow-rgb: 225, 83, 97;
			--bs-btn-active-color: #fff;
			--bs-btn-active-bg: #b02a37;
			--bs-btn-active-border-color: #a52834;
			--bs-btn-active-shadow: inset 0 3px 5px rgba(0, 0, 0, 0.125);
			--bs-btn-disabled-color: #fff;
			--bs-btn-disabled-bg: #dc3545;
			--bs-btn-disabled-border-color: #dc3545
		}

		.btn-light {
			--bs-btn-color: #000;
			--bs-btn-bg: #f8f9fa;
			--bs-btn-border-color: #f8f9fa;
			--bs-btn-hover-color: #000;
			--bs-btn-hover-bg: #d3d4d5;
			--bs-btn-hover-border-color: #c6c7c8;
			--bs-btn-focus-shadow-rgb: 211, 212, 213;
			--bs-btn-active-color: #000;
			--bs-btn-active-bg: #c6c7c8;
			--bs-btn-active-border-color: #babbbc;
			--bs-btn-active-shadow: inset 0 3px 5px rgba(0, 0, 0, 0.125);
			--bs-btn-disabled-color: #000;
			--bs-btn-disabled-bg: #f8f9fa;
			--bs-btn-disabled-border-color: #f8f9fa
		}

		.btn-dark {
			--bs-btn-color: #fff;
			--bs-btn-bg: #212529;
			--bs-btn-border-color: #212529;
			--bs-btn-hover-color: #fff;
			--bs-btn-hover-bg: #424649;
			--bs-btn-hover-border-color: #373b3e;
			--bs-btn-focus-shadow-rgb: 66, 70, 73;
			--bs-btn-active-color: #fff;
			--bs-btn-active-bg: #4d5154;
			--bs-btn-active-border-color: #373b3e;
			--bs-btn-active-shadow: inset 0 3px 5px rgba(0, 0, 0, 0.125);
			--bs-btn-disabled-color: #fff;
			--bs-btn-disabled-bg: #212529;
			--bs-btn-disabled-border-color: #212529
		}

		.btn-outline-primary {
			--bs-btn-color: #0d6efd;
			--bs-btn-border-color: #0d6efd;
			--bs-btn-hover-color: #fff;
			--bs-btn-hover-bg: #0d6efd;
			--bs-btn-hover-border-color: #0d6efd;
			--bs-btn-focus-shadow-rgb: 13, 110, 253;
			--bs-btn-active-color: #fff;
			--bs-btn-active-bg: #0d6efd;
			--bs-btn-active-border-color: #0d6efd;
			--bs-btn-active-shadow: inset 0 3px 5px rgba(0, 0, 0, 0.125);
			--bs-btn-disabled-color: #0d6efd;
			--bs-btn-disabled-bg: transparent;
			--bs-btn-disabled-border-color: #0d6efd;
			--bs-gradient: none
		}

		.btn-outline-secondary {
			--bs-btn-color: #6c757d;
			--bs-btn-border-color: #6c757d;
			--bs-btn-hover-color: #fff;
			--bs-btn-hover-bg: #6c757d;
			--bs-btn-hover-border-color: #6c757d;
			--bs-btn-focus-shadow-rgb: 108, 117, 125;
			--bs-btn-active-color: #fff;
			--bs-btn-active-bg: #6c757d;
			--bs-btn-active-border-color: #6c757d;
			--bs-btn-active-shadow: inset 0 3px 5px rgba(0, 0, 0, 0.125);
			--bs-btn-disabled-color: #6c757d;
			--bs-btn-disabled-bg: transparent;
			--bs-btn-disabled-border-color: #6c757d;
			--bs-gradient: none
		}

		.btn-outline-success {
			--bs-btn-color: #198754;
			--bs-btn-border-color: #198754;
			--bs-btn-hover-color: #fff;
			--bs-btn-hover-bg: #198754;
			--bs-btn-hover-border-color: #198754;
			--bs-btn-focus-shadow-rgb: 25, 135, 84;
			--bs-btn-active-color: #fff;
			--bs-btn-active-bg: #198754;
			--bs-btn-active-border-color: #198754;
			--bs-btn-active-shadow: inset 0 3px 5px rgba(0, 0, 0, 0.125);
			--bs-btn-disabled-color: #198754;
			--bs-btn-disabled-bg: transparent;
			--bs-btn-disabled-border-color: #198754;
			--bs-gradient: none
		}

		.btn-outline-info {
			--bs-btn-color: #0dcaf0;
			--bs-btn-border-color: #0dcaf0;
			--bs-btn-hover-color: #000;
			--bs-btn-hover-bg: #0dcaf0;
			--bs-btn-hover-border-color: #0dcaf0;
			--bs-btn-focus-shadow-rgb: 13, 202, 240;
			--bs-btn-active-color: #000;
			--bs-btn-active-bg: #0dcaf0;
			--bs-btn-active-border-color: #0dcaf0;
			--bs-btn-active-shadow: inset 0 3px 5px rgba(0, 0, 0, 0.125);
			--bs-btn-disabled-color: #0dcaf0;
			--bs-btn-disabled-bg: transparent;
			--bs-btn-disabled-border-color: #0dcaf0;
			--bs-gradient: none
		}

		.btn-outline-warning {
			--bs-btn-color: #ffc107;
			--bs-btn-border-color: #ffc107;
			--bs-btn-hover-color: #000;
			--bs-btn-hover-bg: #ffc107;
			--bs-btn-hover-border-color: #ffc107;
			--bs-btn-focus-shadow-rgb: 255, 193, 7;
			--bs-btn-active-color: #000;
			--bs-btn-active-bg: #ffc107;
			--bs-btn-active-border-color: #ffc107;
			--bs-btn-active-shadow: inset 0 3px 5px rgba(0, 0, 0, 0.125);
			--bs-btn-disabled-color: #ffc107;
			--bs-btn-disabled-bg: transparent;
			--bs-btn-disabled-border-color: #ffc107;
			--bs-gradient: none
		}

		.btn-outline-danger {
			--bs-btn-color: #dc3545;
			--bs-btn-border-color: #dc3545;
			--bs-btn-hover-color: #fff;
			--bs-btn-hover-bg: #dc3545;
			--bs-btn-hover-border-color: #dc3545;
			--bs-btn-focus-shadow-rgb: 220, 53, 69;
			--bs-btn-active-color: #fff;
			--bs-btn-active-bg: #dc3545;
			--bs-btn-active-border-color: #dc3545;
			--bs-btn-active-shadow: inset 0 3px 5px rgba(0, 0, 0, 0.125);
			--bs-btn-disabled-color: #dc3545;
			--bs-btn-disabled-bg: transparent;
			--bs-btn-disabled-border-color: #dc3545;
			--bs-gradient: none
		}

		.btn-outline-light {
			--bs-btn-color: #f8f9fa;
			--bs-btn-border-color: #f8f9fa;
			--bs-btn-hover-color: #000;
			--bs-btn-hover-bg: #f8f9fa;
			--bs-btn-hover-border-color: #f8f9fa;
			--bs-btn-focus-shadow-rgb: 248, 249, 250;
			--bs-btn-active-color: #000;
			--bs-btn-active-bg: #f8f9fa;
			--bs-btn-active-border-color: #f8f9fa;
			--bs-btn-active-shadow: inset 0 3px 5px rgba(0, 0, 0, 0.125);
			--bs-btn-disabled-color: #f8f9fa;
			--bs-btn-disabled-bg: transparent;
			--bs-btn-disabled-border-color: #f8f9fa;
			--bs-gradient: none
		}

		.btn-outline-dark {
			--bs-btn-color: #212529;
			--bs-btn-border-color: #212529;
			--bs-btn-hover-color: #fff;
			--bs-btn-hover-bg: #212529;
			--bs-btn-hover-border-color: #212529;
			--bs-btn-focus-shadow-rgb: 33, 37, 41;
			--bs-btn-active-color: #fff;
			--bs-btn-active-bg: #212529;
			--bs-btn-active-border-color: #212529;
			--bs-btn-active-shadow: inset 0 3px 5px rgba(0, 0, 0, 0.125);
			--bs-btn-disabled-color: #212529;
			--bs-btn-disabled-bg: transparent;
			--bs-btn-disabled-border-color: #212529;
			--bs-gradient: none
		}

		.btn-link {
			--bs-btn-font-weight: 400;
			--bs-btn-color: var(--bs-link-color);
			--bs-btn-bg: transparent;
			--bs-btn-border-color: transparent;
			--bs-btn-hover-color: var(--bs-link-hover-color);
			--bs-btn-hover-border-color: transparent;
			--bs-btn-active-color: var(--bs-link-hover-color);
			--bs-btn-active-border-color: transparent;
			--bs-btn-disabled-color: #6c757d;
			--bs-btn-disabled-border-color: transparent;
			--bs-btn-box-shadow: none;
			--bs-btn-focus-shadow-rgb: 49, 132, 253;
			text-decoration: underline
		}

		.btn-link:focus {
			color: var(--bs-btn-color)
		}

		.btn-link:hover {
			color: var(--bs-btn-hover-color)
		}

		.btn-group-lg>.btn,
		.btn-lg {
			--bs-btn-padding-y: 0.5rem;
			--bs-btn-padding-x: 1rem;
			--bs-btn-font-size: 1.25rem;
			--bs-btn-border-radius: 0.5rem
		}

		.btn-group-sm>.btn,
		.btn-sm {
			--bs-btn-padding-y: 0.25rem;
			--bs-btn-padding-x: 0.5rem;
			--bs-btn-font-size: 0.875rem;
			--bs-btn-border-radius: 0.25rem
		}

		.fade {
			transition: opacity .15s linear
		}

		@media (prefers-reduced-motion:reduce) {
			.fade {
				transition: none
			}
		}

		.fade:not(.show) {
			opacity: 0
		}

		.collapse:not(.show) {
			display: none
		}

		.collapsing {
			height: 0;
			overflow: hidden;
			transition: height .35s ease
		}

		@media (prefers-reduced-motion:reduce) {
			.collapsing {
				transition: none
			}
		}

		.collapsing.collapse-horizontal {
			width: 0;
			height: auto;
			transition: width .35s ease
		}

		@media (prefers-reduced-motion:reduce) {
			.collapsing.collapse-horizontal {
				transition: none
			}
		}

		.dropdown,
		.dropdown-center,
		.dropend,
		.dropstart,
		.dropup,
		.dropup-center {
			position: relative
		}

		.dropdown-toggle {
			white-space: nowrap
		}

		.dropdown-toggle::after {
			display: inline-block;
			margin-left: .255em;
			vertical-align: .255em;
			content: "";
			border-top: .3em solid;
			border-right: .3em solid transparent;
			border-bottom: 0;
			border-left: .3em solid transparent
		}

		.dropdown-toggle:empty::after {
			margin-left: 0
		}

		.dropdown-menu {
			--bs-dropdown-min-width: 10rem;
			--bs-dropdown-padding-x: 0;
			--bs-dropdown-padding-y: 0.5rem;
			--bs-dropdown-spacer: 0.125rem;
			--bs-dropdown-font-size: 1rem;
			--bs-dropdown-color: #212529;
			--bs-dropdown-bg: #fff;
			--bs-dropdown-border-color: var(--bs-border-color-translucent);
			--bs-dropdown-border-radius: 0.375rem;
			--bs-dropdown-border-width: 1px;
			--bs-dropdown-inner-border-radius: calc(0.375rem - 1px);
			--bs-dropdown-divider-bg: var(--bs-border-color-translucent);
			--bs-dropdown-divider-margin-y: 0.5rem;
			--bs-dropdown-box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.15);
			--bs-dropdown-link-color: #212529;
			--bs-dropdown-link-hover-color: #1e2125;
			--bs-dropdown-link-hover-bg: #e9ecef;
			--bs-dropdown-link-active-color: #fff;
			--bs-dropdown-link-active-bg: #0d6efd;
			--bs-dropdown-link-disabled-color: #adb5bd;
			--bs-dropdown-item-padding-x: 1rem;
			--bs-dropdown-item-padding-y: 0.25rem;
			--bs-dropdown-header-color: #6c757d;
			--bs-dropdown-header-padding-x: 1rem;
			--bs-dropdown-header-padding-y: 0.5rem;
			position: absolute;
			z-index: 1000;
			display: none;
			min-width: var(--bs-dropdown-min-width);
			padding: var(--bs-dropdown-padding-y) var(--bs-dropdown-padding-x);
			margin: 0;
			font-size: var(--bs-dropdown-font-size);
			color: var(--bs-dropdown-color);
			text-align: left;
			list-style: none;
			background-color: var(--bs-dropdown-bg);
			background-clip: padding-box;
			border: var(--bs-dropdown-border-width) solid var(--bs-dropdown-border-color);
			border-radius: var(--bs-dropdown-border-radius)
		}

		.dropdown-menu[data-bs-popper] {
			top: 100%;
			left: 0;
			margin-top: var(--bs-dropdown-spacer)
		}

		.dropdown-menu-start {
			--bs-position: start
		}

		.dropdown-menu-start[data-bs-popper] {
			right: auto;
			left: 0
		}

		.dropdown-menu-end {
			--bs-position: end
		}

		.dropdown-menu-end[data-bs-popper] {
			right: 0;
			left: auto
		}

		@media (min-width:576px) {
			.dropdown-menu-sm-start {
				--bs-position: start
			}

			.dropdown-menu-sm-start[data-bs-popper] {
				right: auto;
				left: 0
			}

			.dropdown-menu-sm-end {
				--bs-position: end
			}

			.dropdown-menu-sm-end[data-bs-popper] {
				right: 0;
				left: auto
			}
		}

		@media (min-width:768px) {
			.dropdown-menu-md-start {
				--bs-position: start
			}

			.dropdown-menu-md-start[data-bs-popper] {
				right: auto;
				left: 0
			}

			.dropdown-menu-md-end {
				--bs-position: end
			}

			.dropdown-menu-md-end[data-bs-popper] {
				right: 0;
				left: auto
			}
		}

		@media (min-width:992px) {
			.dropdown-menu-lg-start {
				--bs-position: start
			}

			.dropdown-menu-lg-start[data-bs-popper] {
				right: auto;
				left: 0
			}

			.dropdown-menu-lg-end {
				--bs-position: end
			}

			.dropdown-menu-lg-end[data-bs-popper] {
				right: 0;
				left: auto
			}
		}

		@media (min-width:1200px) {
			.dropdown-menu-xl-start {
				--bs-position: start
			}

			.dropdown-menu-xl-start[data-bs-popper] {
				right: auto;
				left: 0
			}

			.dropdown-menu-xl-end {
				--bs-position: end
			}

			.dropdown-menu-xl-end[data-bs-popper] {
				right: 0;
				left: auto
			}
		}

		@media (min-width:1400px) {
			.dropdown-menu-xxl-start {
				--bs-position: start
			}

			.dropdown-menu-xxl-start[data-bs-popper] {
				right: auto;
				left: 0
			}

			.dropdown-menu-xxl-end {
				--bs-position: end
			}

			.dropdown-menu-xxl-end[data-bs-popper] {
				right: 0;
				left: auto
			}
		}

		.dropup .dropdown-menu[data-bs-popper] {
			top: auto;
			bottom: 100%;
			margin-top: 0;
			margin-bottom: var(--bs-dropdown-spacer)
		}

		.dropup .dropdown-toggle::after {
			display: inline-block;
			margin-left: .255em;
			vertical-align: .255em;
			content: "";
			border-top: 0;
			border-right: .3em solid transparent;
			border-bottom: .3em solid;
			border-left: .3em solid transparent
		}

		.dropup .dropdown-toggle:empty::after {
			margin-left: 0
		}

		.dropend .dropdown-menu[data-bs-popper] {
			top: 0;
			right: auto;
			left: 100%;
			margin-top: 0;
			margin-left: var(--bs-dropdown-spacer)
		}

		.dropend .dropdown-toggle::after {
			display: inline-block;
			margin-left: .255em;
			vertical-align: .255em;
			content: "";
			border-top: .3em solid transparent;
			border-right: 0;
			border-bottom: .3em solid transparent;
			border-left: .3em solid
		}

		.dropend .dropdown-toggle:empty::after {
			margin-left: 0
		}

		.dropend .dropdown-toggle::after {
			vertical-align: 0
		}

		.dropstart .dropdown-menu[data-bs-popper] {
			top: 0;
			right: 100%;
			left: auto;
			margin-top: 0;
			margin-right: var(--bs-dropdown-spacer)
		}

		.dropstart .dropdown-toggle::after {
			display: inline-block;
			margin-left: .255em;
			vertical-align: .255em;
			content: ""
		}

		.dropstart .dropdown-toggle::after {
			display: none
		}

		.dropstart .dropdown-toggle::before {
			display: inline-block;
			margin-right: .255em;
			vertical-align: .255em;
			content: "";
			border-top: .3em solid transparent;
			border-right: .3em solid;
			border-bottom: .3em solid transparent
		}

		.dropstart .dropdown-toggle:empty::after {
			margin-left: 0
		}

		.dropstart .dropdown-toggle::before {
			vertical-align: 0
		}

		.dropdown-divider {
			height: 0;
			margin: var(--bs-dropdown-divider-margin-y) 0;
			overflow: hidden;
			border-top: 1px solid var(--bs-dropdown-divider-bg);
			opacity: 1
		}

		.dropdown-item {
			display: block;
			width: 100%;
			padding: var(--bs-dropdown-item-padding-y) var(--bs-dropdown-item-padding-x);
			clear: both;
			font-weight: 400;
			color: var(--bs-dropdown-link-color);
			text-align: inherit;
			text-decoration: none;
			white-space: nowrap;
			background-color: transparent;
			border: 0
		}

		.dropdown-item:focus,
		.dropdown-item:hover {
			color: var(--bs-dropdown-link-hover-color);
			background-color: var(--bs-dropdown-link-hover-bg)
		}

		.dropdown-item.active,
		.dropdown-item:active {
			color: var(--bs-dropdown-link-active-color);
			text-decoration: none;
			background-color: var(--bs-dropdown-link-active-bg)
		}

		.dropdown-item.disabled,
		.dropdown-item:disabled {
			color: var(--bs-dropdown-link-disabled-color);
			pointer-events: none;
			background-color: transparent
		}

		.dropdown-menu.show {
			display: block
		}

		.dropdown-header {
			display: block;
			padding: var(--bs-dropdown-header-padding-y) var(--bs-dropdown-header-padding-x);
			margin-bottom: 0;
			font-size: .875rem;
			color: var(--bs-dropdown-header-color);
			white-space: nowrap
		}

		.dropdown-item-text {
			display: block;
			padding: var(--bs-dropdown-item-padding-y) var(--bs-dropdown-item-padding-x);
			color: var(--bs-dropdown-link-color)
		}

		.dropdown-menu-dark {
			--bs-dropdown-color: #dee2e6;
			--bs-dropdown-bg: #343a40;
			--bs-dropdown-border-color: var(--bs-border-color-translucent);
			--bs-dropdown-box-shadow: ;
			--bs-dropdown-link-color: #dee2e6;
			--bs-dropdown-link-hover-color: #fff;
			--bs-dropdown-divider-bg: var(--bs-border-color-translucent);
			--bs-dropdown-link-hover-bg: rgba(255, 255, 255, 0.15);
			--bs-dropdown-link-active-color: #fff;
			--bs-dropdown-link-active-bg: #0d6efd;
			--bs-dropdown-link-disabled-color: #adb5bd;
			--bs-dropdown-header-color: #adb5bd
		}

		.btn-group,
		.btn-group-vertical {
			position: relative;
			display: inline-flex;
			vertical-align: middle
		}

		.btn-group-vertical>.btn,
		.btn-group>.btn {
			position: relative;
			flex: 1 1 auto
		}

		.btn-group-vertical>.btn-check:checked+.btn,
		.btn-group-vertical>.btn-check:focus+.btn,
		.btn-group-vertical>.btn.active,
		.btn-group-vertical>.btn:active,
		.btn-group-vertical>.btn:focus,
		.btn-group-vertical>.btn:hover,
		.btn-group>.btn-check:checked+.btn,
		.btn-group>.btn-check:focus+.btn,
		.btn-group>.btn.active,
		.btn-group>.btn:active,
		.btn-group>.btn:focus,
		.btn-group>.btn:hover {
			z-index: 1
		}

		.btn-toolbar {
			display: flex;
			flex-wrap: wrap;
			justify-content: flex-start
		}

		.btn-toolbar .input-group {
			width: auto
		}

		.btn-group {
			border-radius: .375rem
		}

		.btn-group>.btn-group:not(:first-child),
		.btn-group>.btn:not(:first-child) {
			margin-left: -1px
		}

		.btn-group>.btn-group:not(:last-child)>.btn,
		.btn-group>.btn.dropdown-toggle-split:first-child,
		.btn-group>.btn:not(:last-child):not(.dropdown-toggle) {
			border-top-right-radius: 0;
			border-bottom-right-radius: 0
		}

		.btn-group>.btn-group:not(:first-child)>.btn,
		.btn-group>.btn:nth-child(n+3),
		.btn-group>:not(.btn-check)+.btn {
			border-top-left-radius: 0;
			border-bottom-left-radius: 0
		}

		.dropdown-toggle-split {
			padding-right: .5625rem;
			padding-left: .5625rem
		}

		.dropdown-toggle-split::after,
		.dropend .dropdown-toggle-split::after,
		.dropup .dropdown-toggle-split::after {
			margin-left: 0
		}

		.dropstart .dropdown-toggle-split::before {
			margin-right: 0
		}

		.btn-group-sm>.btn+.dropdown-toggle-split,
		.btn-sm+.dropdown-toggle-split {
			padding-right: .375rem;
			padding-left: .375rem
		}

		.btn-group-lg>.btn+.dropdown-toggle-split,
		.btn-lg+.dropdown-toggle-split {
			padding-right: .75rem;
			padding-left: .75rem
		}

		.btn-group-vertical {
			flex-direction: column;
			align-items: flex-start;
			justify-content: center
		}

		.btn-group-vertical>.btn,
		.btn-group-vertical>.btn-group {
			width: 100%
		}

		.btn-group-vertical>.btn-group:not(:first-child),
		.btn-group-vertical>.btn:not(:first-child) {
			margin-top: -1px
		}

		.btn-group-vertical>.btn-group:not(:last-child)>.btn,
		.btn-group-vertical>.btn:not(:last-child):not(.dropdown-toggle) {
			border-bottom-right-radius: 0;
			border-bottom-left-radius: 0
		}

		.btn-group-vertical>.btn-group:not(:first-child)>.btn,
		.btn-group-vertical>.btn~.btn {
			border-top-left-radius: 0;
			border-top-right-radius: 0
		}

		.nav {
			--bs-nav-link-padding-x: 1rem;
			--bs-nav-link-padding-y: 0.5rem;
			--bs-nav-link-font-weight: ;
			--bs-nav-link-color: var(--bs-link-color);
			--bs-nav-link-hover-color: var(--bs-link-hover-color);
			--bs-nav-link-disabled-color: #6c757d;
			display: flex;
			flex-wrap: wrap;
			padding-left: 0;
			margin-bottom: 0;
			list-style: none
		}

		.nav-link {
			display: block;
			padding: var(--bs-nav-link-padding-y) var(--bs-nav-link-padding-x);
			font-size: var(--bs-nav-link-font-size);
			font-weight: var(--bs-nav-link-font-weight);
			color: var(--bs-nav-link-color);
			text-decoration: none;
			transition: color .15s ease-in-out, background-color .15s ease-in-out, border-color .15s ease-in-out
		}

		@media (prefers-reduced-motion:reduce) {
			.nav-link {
				transition: none
			}
		}

		.nav-link:focus,
		.nav-link:hover {
			color: var(--bs-nav-link-hover-color)
		}

		.nav-link.disabled {
			color: var(--bs-nav-link-disabled-color);
			pointer-events: none;
			cursor: default
		}

		.nav-tabs {
			--bs-nav-tabs-border-width: 1px;
			--bs-nav-tabs-border-color: #dee2e6;
			--bs-nav-tabs-border-radius: 0.375rem;
			--bs-nav-tabs-link-hover-border-color: #e9ecef #e9ecef #dee2e6;
			--bs-nav-tabs-link-active-color: #495057;
			--bs-nav-tabs-link-active-bg: #fff;
			--bs-nav-tabs-link-active-border-color: #dee2e6 #dee2e6 #fff;
			border-bottom: var(--bs-nav-tabs-border-width) solid var(--bs-nav-tabs-border-color)
		}

		.nav-tabs .nav-link {
			margin-bottom: calc(var(--bs-nav-tabs-border-width) * -1);
			background: 0 0;
			border: var(--bs-nav-tabs-border-width) solid transparent;
			border-top-left-radius: var(--bs-nav-tabs-border-radius);
			border-top-right-radius: var(--bs-nav-tabs-border-radius)
		}

		.nav-tabs .nav-link:focus,
		.nav-tabs .nav-link:hover {
			isolation: isolate;
			border-color: var(--bs-nav-tabs-link-hover-border-color)
		}

		.nav-tabs .nav-link.disabled,
		.nav-tabs .nav-link:disabled {
			color: var(--bs-nav-link-disabled-color);
			background-color: transparent;
			border-color: transparent
		}

		.nav-tabs .nav-item.show .nav-link,
		.nav-tabs .nav-link.active {
			color: var(--bs-nav-tabs-link-active-color);
			background-color: var(--bs-nav-tabs-link-active-bg);
			border-color: var(--bs-nav-tabs-link-active-border-color)
		}

		.nav-tabs .dropdown-menu {
			margin-top: calc(var(--bs-nav-tabs-border-width) * -1);
			border-top-left-radius: 0;
			border-top-right-radius: 0
		}

		.nav-pills {
			--bs-nav-pills-border-radius: 0.375rem;
			--bs-nav-pills-link-active-color: #fff;
			--bs-nav-pills-link-active-bg: #0d6efd
		}

		.nav-pills .nav-link {
			background: 0 0;
			border: 0;
			border-radius: var(--bs-nav-pills-border-radius)
		}

		.nav-pills .nav-link:disabled {
			color: var(--bs-nav-link-disabled-color);
			background-color: transparent;
			border-color: transparent
		}

		.nav-pills .nav-link.active,
		.nav-pills .show>.nav-link {
			color: var(--bs-nav-pills-link-active-color);
			background-color: var(--bs-nav-pills-link-active-bg)
		}

		.nav-fill .nav-item,
		.nav-fill>.nav-link {
			flex: 1 1 auto;
			text-align: center
		}

		.nav-justified .nav-item,
		.nav-justified>.nav-link {
			flex-basis: 0;
			flex-grow: 1;
			text-align: center
		}

		.nav-fill .nav-item .nav-link,
		.nav-justified .nav-item .nav-link {
			width: 100%
		}

		.tab-content>.tab-pane {
			display: none
		}

		.tab-content>.active {
			display: block
		}

		.navbar {
			--bs-navbar-padding-x: 0;
			--bs-navbar-padding-y: 0.5rem;
			--bs-navbar-color: rgba(0, 0, 0, 0.55);
			--bs-navbar-hover-color: rgba(0, 0, 0, 0.7);
			--bs-navbar-disabled-color: rgba(0, 0, 0, 0.3);
			--bs-navbar-active-color: rgba(0, 0, 0, 0.9);
			--bs-navbar-brand-padding-y: 0.3125rem;
			--bs-navbar-brand-margin-end: 1rem;
			--bs-navbar-brand-font-size: 1.25rem;
			--bs-navbar-brand-color: rgba(0, 0, 0, 0.9);
			--bs-navbar-brand-hover-color: rgba(0, 0, 0, 0.9);
			--bs-navbar-nav-link-padding-x: 0.5rem;
			--bs-navbar-toggler-padding-y: 0.25rem;
			--bs-navbar-toggler-padding-x: 0.75rem;
			--bs-navbar-toggler-font-size: 1.25rem;
			--bs-navbar-toggler-icon-bg: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 30 30'%3e%3cpath stroke='rgba%280, 0, 0, 0.55%29' stroke-linecap='round' stroke-miterlimit='10' stroke-width='2' d='M4 7h22M4 15h22M4 23h22'/%3e%3c/svg%3e");
			--bs-navbar-toggler-border-color: rgba(0, 0, 0, 0.1);
			--bs-navbar-toggler-border-radius: 0.375rem;
			--bs-navbar-toggler-focus-width: 0.25rem;
			--bs-navbar-toggler-transition: box-shadow 0.15s ease-in-out;
			position: relative;
			display: flex;
			flex-wrap: wrap;
			align-items: center;
			justify-content: space-between;
			padding: var(--bs-navbar-padding-y) var(--bs-navbar-padding-x)
		}

		.navbar>.container,
		.navbar>.container-fluid,
		.navbar>.container-lg,
		.navbar>.container-md,
		.navbar>.container-sm,
		.navbar>.container-xl,
		.navbar>.container-xxl {
			display: flex;
			flex-wrap: inherit;
			align-items: center;
			justify-content: space-between
		}

		.navbar-brand {
			padding-top: var(--bs-navbar-brand-padding-y);
			padding-bottom: var(--bs-navbar-brand-padding-y);
			margin-right: var(--bs-navbar-brand-margin-end);
			font-size: var(--bs-navbar-brand-font-size);
			color: var(--bs-navbar-brand-color);
			text-decoration: none;
			white-space: nowrap
		}

		.navbar-brand:focus,
		.navbar-brand:hover {
			color: var(--bs-navbar-brand-hover-color)
		}

		.navbar-nav {
			--bs-nav-link-padding-x: 0;
			--bs-nav-link-padding-y: 0.5rem;
			--bs-nav-link-font-weight: ;
			--bs-nav-link-color: var(--bs-navbar-color);
			--bs-nav-link-hover-color: var(--bs-navbar-hover-color);
			--bs-nav-link-disabled-color: var(--bs-navbar-disabled-color);
			display: flex;
			flex-direction: column;
			padding-left: 0;
			margin-bottom: 0;
			list-style: none
		}

		.navbar-nav .nav-link.active,
		.navbar-nav .show>.nav-link {
			color: var(--bs-navbar-active-color)
		}

		.navbar-nav .dropdown-menu {
			position: static
		}

		.navbar-text {
			padding-top: .5rem;
			padding-bottom: .5rem;
			color: var(--bs-navbar-color)
		}

		.navbar-text a,
		.navbar-text a:focus,
		.navbar-text a:hover {
			color: var(--bs-navbar-active-color)
		}

		.navbar-collapse {
			flex-basis: 100%;
			flex-grow: 1;
			align-items: center
		}

		.navbar-toggler {
			padding: var(--bs-navbar-toggler-padding-y) var(--bs-navbar-toggler-padding-x);
			font-size: var(--bs-navbar-toggler-font-size);
			line-height: 1;
			color: var(--bs-navbar-color);
			background-color: transparent;
			border: var(--bs-border-width) solid var(--bs-navbar-toggler-border-color);
			border-radius: var(--bs-navbar-toggler-border-radius);
			transition: var(--bs-navbar-toggler-transition)
		}

		@media (prefers-reduced-motion:reduce) {
			.navbar-toggler {
				transition: none
			}
		}

		.navbar-toggler:hover {
			text-decoration: none
		}

		.navbar-toggler:focus {
			text-decoration: none;
			outline: 0;
			box-shadow: 0 0 0 var(--bs-navbar-toggler-focus-width)
		}

		.navbar-toggler-icon {
			display: inline-block;
			width: 1.5em;
			height: 1.5em;
			vertical-align: middle;
			background-image: var(--bs-navbar-toggler-icon-bg);
			background-repeat: no-repeat;
			background-position: center;
			background-size: 100%
		}

		.navbar-nav-scroll {
			max-height: var(--bs-scroll-height, 75vh);
			overflow-y: auto
		}

		@media (min-width:576px) {
			.navbar-expand-sm {
				flex-wrap: nowrap;
				justify-content: flex-start
			}

			.navbar-expand-sm .navbar-nav {
				flex-direction: row
			}

			.navbar-expand-sm .navbar-nav .dropdown-menu {
				position: absolute
			}

			.navbar-expand-sm .navbar-nav .nav-link {
				padding-right: var(--bs-navbar-nav-link-padding-x);
				padding-left: var(--bs-navbar-nav-link-padding-x)
			}

			.navbar-expand-sm .navbar-nav-scroll {
				overflow: visible
			}

			.navbar-expand-sm .navbar-collapse {
				display: flex !important;
				flex-basis: auto
			}

			.navbar-expand-sm .navbar-toggler {
				display: none
			}

			.navbar-expand-sm .offcanvas {
				position: static;
				z-index: auto;
				flex-grow: 1;
				width: auto !important;
				height: auto !important;
				visibility: visible !important;
				background-color: transparent !important;
				border: 0 !important;
				transform: none !important;
				transition: none
			}

			.navbar-expand-sm .offcanvas .offcanvas-header {
				display: none
			}

			.navbar-expand-sm .offcanvas .offcanvas-body {
				display: flex;
				flex-grow: 0;
				padding: 0;
				overflow-y: visible
			}
		}

		@media (min-width:768px) {
			.navbar-expand-md {
				flex-wrap: nowrap;
				justify-content: flex-start
			}

			.navbar-expand-md .navbar-nav {
				flex-direction: row
			}

			.navbar-expand-md .navbar-nav .dropdown-menu {
				position: absolute
			}

			.navbar-expand-md .navbar-nav .nav-link {
				padding-right: var(--bs-navbar-nav-link-padding-x);
				padding-left: var(--bs-navbar-nav-link-padding-x)
			}

			.navbar-expand-md .navbar-nav-scroll {
				overflow: visible
			}

			.navbar-expand-md .navbar-collapse {
				display: flex !important;
				flex-basis: auto
			}

			.navbar-expand-md .navbar-toggler {
				display: none
			}

			.navbar-expand-md .offcanvas {
				position: static;
				z-index: auto;
				flex-grow: 1;
				width: auto !important;
				height: auto !important;
				visibility: visible !important;
				background-color: transparent !important;
				border: 0 !important;
				transform: none !important;
				transition: none
			}

			.navbar-expand-md .offcanvas .offcanvas-header {
				display: none
			}

			.navbar-expand-md .offcanvas .offcanvas-body {
				display: flex;
				flex-grow: 0;
				padding: 0;
				overflow-y: visible
			}
		}

		@media (min-width:992px) {
			.navbar-expand-lg {
				flex-wrap: nowrap;
				justify-content: flex-start
			}

			.navbar-expand-lg .navbar-nav {
				flex-direction: row
			}

			.navbar-expand-lg .navbar-nav .dropdown-menu {
				position: absolute
			}

			.navbar-expand-lg .navbar-nav .nav-link {
				padding-right: var(--bs-navbar-nav-link-padding-x);
				padding-left: var(--bs-navbar-nav-link-padding-x)
			}

			.navbar-expand-lg .navbar-nav-scroll {
				overflow: visible
			}

			.navbar-expand-lg .navbar-collapse {
				display: flex !important;
				flex-basis: auto
			}

			.navbar-expand-lg .navbar-toggler {
				display: none
			}

			.navbar-expand-lg .offcanvas {
				position: static;
				z-index: auto;
				flex-grow: 1;
				width: auto !important;
				height: auto !important;
				visibility: visible !important;
				background-color: transparent !important;
				border: 0 !important;
				transform: none !important;
				transition: none
			}

			.navbar-expand-lg .offcanvas .offcanvas-header {
				display: none
			}

			.navbar-expand-lg .offcanvas .offcanvas-body {
				display: flex;
				flex-grow: 0;
				padding: 0;
				overflow-y: visible
			}
		}

		@media (min-width:1200px) {
			.navbar-expand-xl {
				flex-wrap: nowrap;
				justify-content: flex-start
			}

			.navbar-expand-xl .navbar-nav {
				flex-direction: row
			}

			.navbar-expand-xl .navbar-nav .dropdown-menu {
				position: absolute
			}

			.navbar-expand-xl .navbar-nav .nav-link {
				padding-right: var(--bs-navbar-nav-link-padding-x);
				padding-left: var(--bs-navbar-nav-link-padding-x)
			}

			.navbar-expand-xl .navbar-nav-scroll {
				overflow: visible
			}

			.navbar-expand-xl .navbar-collapse {
				display: flex !important;
				flex-basis: auto
			}

			.navbar-expand-xl .navbar-toggler {
				display: none
			}

			.navbar-expand-xl .offcanvas {
				position: static;
				z-index: auto;
				flex-grow: 1;
				width: auto !important;
				height: auto !important;
				visibility: visible !important;
				background-color: transparent !important;
				border: 0 !important;
				transform: none !important;
				transition: none
			}

			.navbar-expand-xl .offcanvas .offcanvas-header {
				display: none
			}

			.navbar-expand-xl .offcanvas .offcanvas-body {
				display: flex;
				flex-grow: 0;
				padding: 0;
				overflow-y: visible
			}
		}

		@media (min-width:1400px) {
			.navbar-expand-xxl {
				flex-wrap: nowrap;
				justify-content: flex-start
			}

			.navbar-expand-xxl .navbar-nav {
				flex-direction: row
			}

			.navbar-expand-xxl .navbar-nav .dropdown-menu {
				position: absolute
			}

			.navbar-expand-xxl .navbar-nav .nav-link {
				padding-right: var(--bs-navbar-nav-link-padding-x);
				padding-left: var(--bs-navbar-nav-link-padding-x)
			}

			.navbar-expand-xxl .navbar-nav-scroll {
				overflow: visible
			}

			.navbar-expand-xxl .navbar-collapse {
				display: flex !important;
				flex-basis: auto
			}

			.navbar-expand-xxl .navbar-toggler {
				display: none
			}

			.navbar-expand-xxl .offcanvas {
				position: static;
				z-index: auto;
				flex-grow: 1;
				width: auto !important;
				height: auto !important;
				visibility: visible !important;
				background-color: transparent !important;
				border: 0 !important;
				transform: none !important;
				transition: none
			}

			.navbar-expand-xxl .offcanvas .offcanvas-header {
				display: none
			}

			.navbar-expand-xxl .offcanvas .offcanvas-body {
				display: flex;
				flex-grow: 0;
				padding: 0;
				overflow-y: visible
			}
		}

		.navbar-expand {
			flex-wrap: nowrap;
			justify-content: flex-start
		}

		.navbar-expand .navbar-nav {
			flex-direction: row
		}

		.navbar-expand .navbar-nav .dropdown-menu {
			position: absolute
		}

		.navbar-expand .navbar-nav .nav-link {
			padding-right: var(--bs-navbar-nav-link-padding-x);
			padding-left: var(--bs-navbar-nav-link-padding-x)
		}

		.navbar-expand .navbar-nav-scroll {
			overflow: visible
		}

		.navbar-expand .navbar-collapse {
			display: flex !important;
			flex-basis: auto
		}

		.navbar-expand .navbar-toggler {
			display: none
		}

		.navbar-expand .offcanvas {
			position: static;
			z-index: auto;
			flex-grow: 1;
			width: auto !important;
			height: auto !important;
			visibility: visible !important;
			background-color: transparent !important;
			border: 0 !important;
			transform: none !important;
			transition: none
		}

		.navbar-expand .offcanvas .offcanvas-header {
			display: none
		}

		.navbar-expand .offcanvas .offcanvas-body {
			display: flex;
			flex-grow: 0;
			padding: 0;
			overflow-y: visible
		}

		.navbar-dark {
			--bs-navbar-color: rgba(255, 255, 255, 0.55);
			--bs-navbar-hover-color: rgba(255, 255, 255, 0.75);
			--bs-navbar-disabled-color: rgba(255, 255, 255, 0.25);
			--bs-navbar-active-color: #fff;
			--bs-navbar-brand-color: #fff;
			--bs-navbar-brand-hover-color: #fff;
			--bs-navbar-toggler-border-color: rgba(255, 255, 255, 0.1);
			--bs-navbar-toggler-icon-bg: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 30 30'%3e%3cpath stroke='rgba%28255, 255, 255, 0.55%29' stroke-linecap='round' stroke-miterlimit='10' stroke-width='2' d='M4 7h22M4 15h22M4 23h22'/%3e%3c/svg%3e")
		}

		.card {
			--bs-card-spacer-y: 1rem;
			--bs-card-spacer-x: 1rem;
			--bs-card-title-spacer-y: 0.5rem;
			--bs-card-border-width: 1px;
			--bs-card-border-color: var(--bs-border-color-translucent);
			--bs-card-border-radius: 0.375rem;
			--bs-card-box-shadow: ;
			--bs-card-inner-border-radius: calc(0.375rem - 1px);
			--bs-card-cap-padding-y: 0.5rem;
			--bs-card-cap-padding-x: 1rem;
			--bs-card-cap-bg: rgba(0, 0, 0, 0.03);
			--bs-card-cap-color: ;
			--bs-card-height: ;
			--bs-card-color: ;
			--bs-card-bg: #fff;
			--bs-card-img-overlay-padding: 1rem;
			--bs-card-group-margin: 0.75rem;
			position: relative;
			display: flex;
			flex-direction: column;
			min-width: 0;
			height: var(--bs-card-height);
			word-wrap: break-word;
			background-color: var(--bs-card-bg);
			background-clip: border-box;
			border: var(--bs-card-border-width) solid var(--bs-card-border-color);
			border-radius: var(--bs-card-border-radius)
		}

		.card>hr {
			margin-right: 0;
			margin-left: 0
		}

		.card>.list-group {
			border-top: inherit;
			border-bottom: inherit
		}

		.card>.list-group:first-child {
			border-top-width: 0;
			border-top-left-radius: var(--bs-card-inner-border-radius);
			border-top-right-radius: var(--bs-card-inner-border-radius)
		}

		.card>.list-group:last-child {
			border-bottom-width: 0;
			border-bottom-right-radius: var(--bs-card-inner-border-radius);
			border-bottom-left-radius: var(--bs-card-inner-border-radius)
		}

		.card>.card-header+.list-group,
		.card>.list-group+.card-footer {
			border-top: 0
		}

		.card-body {
			flex: 1 1 auto;
			padding: var(--bs-card-spacer-y) var(--bs-card-spacer-x);
			color: var(--bs-card-color)
		}

		.card-title {
			margin-bottom: var(--bs-card-title-spacer-y)
		}

		.card-subtitle {
			margin-top: calc(-.5 * var(--bs-card-title-spacer-y));
			margin-bottom: 0
		}

		.card-text:last-child {
			margin-bottom: 0
		}

		.card-link+.card-link {
			margin-left: var(--bs-card-spacer-x)
		}

		.card-header {
			padding: var(--bs-card-cap-padding-y) var(--bs-card-cap-padding-x);
			margin-bottom: 0;
			color: var(--bs-card-cap-color);
			background-color: var(--bs-card-cap-bg);
			border-bottom: var(--bs-card-border-width) solid var(--bs-card-border-color)
		}

		.card-header:first-child {
			border-radius: var(--bs-card-inner-border-radius) var(--bs-card-inner-border-radius) 0 0
		}

		.card-footer {
			padding: var(--bs-card-cap-padding-y) var(--bs-card-cap-padding-x);
			color: var(--bs-card-cap-color);
			background-color: var(--bs-card-cap-bg);
			border-top: var(--bs-card-border-width) solid var(--bs-card-border-color)
		}

		.card-footer:last-child {
			border-radius: 0 0 var(--bs-card-inner-border-radius) var(--bs-card-inner-border-radius)
		}

		.card-header-tabs {
			margin-right: calc(-.5 * var(--bs-card-cap-padding-x));
			margin-bottom: calc(-1 * var(--bs-card-cap-padding-y));
			margin-left: calc(-.5 * var(--bs-card-cap-padding-x));
			border-bottom: 0
		}

		.card-header-tabs .nav-link.active {
			background-color: var(--bs-card-bg);
			border-bottom-color: var(--bs-card-bg)
		}

		.card-header-pills {
			margin-right: calc(-.5 * var(--bs-card-cap-padding-x));
			margin-left: calc(-.5 * var(--bs-card-cap-padding-x))
		}

		.card-img-overlay {
			position: absolute;
			top: 0;
			right: 0;
			bottom: 0;
			left: 0;
			padding: var(--bs-card-img-overlay-padding);
			border-radius: var(--bs-card-inner-border-radius)
		}

		.card-img,
		.card-img-bottom,
		.card-img-top {
			width: 100%
		}

		.card-img,
		.card-img-top {
			border-top-left-radius: var(--bs-card-inner-border-radius);
			border-top-right-radius: var(--bs-card-inner-border-radius)
		}

		.card-img,
		.card-img-bottom {
			border-bottom-right-radius: var(--bs-card-inner-border-radius);
			border-bottom-left-radius: var(--bs-card-inner-border-radius)
		}

		.card-group>.card {
			margin-bottom: var(--bs-card-group-margin)
		}

		@media (min-width:576px) {
			.card-group {
				display: flex;
				flex-flow: row wrap
			}

			.card-group>.card {
				flex: 1 0 0%;
				margin-bottom: 0
			}

			.card-group>.card+.card {
				margin-left: 0;
				border-left: 0
			}

			.card-group>.card:not(:last-child) {
				border-top-right-radius: 0;
				border-bottom-right-radius: 0
			}

			.card-group>.card:not(:last-child) .card-header,
			.card-group>.card:not(:last-child) .card-img-top {
				border-top-right-radius: 0
			}

			.card-group>.card:not(:last-child) .card-footer,
			.card-group>.card:not(:last-child) .card-img-bottom {
				border-bottom-right-radius: 0
			}

			.card-group>.card:not(:first-child) {
				border-top-left-radius: 0;
				border-bottom-left-radius: 0
			}

			.card-group>.card:not(:first-child) .card-header,
			.card-group>.card:not(:first-child) .card-img-top {
				border-top-left-radius: 0
			}

			.card-group>.card:not(:first-child) .card-footer,
			.card-group>.card:not(:first-child) .card-img-bottom {
				border-bottom-left-radius: 0
			}
		}

		.accordion {
			--bs-accordion-color: #000;
			--bs-accordion-bg: #fff;
			--bs-accordion-transition: color 0.15s ease-in-out, background-color 0.15s ease-in-out, border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out, border-radius 0.15s ease;
			--bs-accordion-border-color: var(--bs-border-color);
			--bs-accordion-border-width: 1px;
			--bs-accordion-border-radius: 0.375rem;
			--bs-accordion-inner-border-radius: calc(0.375rem - 1px);
			--bs-accordion-btn-padding-x: 1.25rem;
			--bs-accordion-btn-padding-y: 1rem;
			--bs-accordion-btn-color: var(--bs-body-color);
			--bs-accordion-btn-bg: var(--bs-accordion-bg);
			--bs-accordion-btn-icon: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16' fill='var%28--bs-body-color%29'%3e%3cpath fill-rule='evenodd' d='M1.646 4.646a.5.5 0 0 1 .708 0L8 10.293l5.646-5.647a.5.5 0 0 1 .708.708l-6 6a.5.5 0 0 1-.708 0l-6-6a.5.5 0 0 1 0-.708z'/%3e%3c/svg%3e");
			--bs-accordion-btn-icon-width: 1.25rem;
			--bs-accordion-btn-icon-transform: rotate(-180deg);
			--bs-accordion-btn-icon-transition: transform 0.2s ease-in-out;
			--bs-accordion-btn-active-icon: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16' fill='%230c63e4'%3e%3cpath fill-rule='evenodd' d='M1.646 4.646a.5.5 0 0 1 .708 0L8 10.293l5.646-5.647a.5.5 0 0 1 .708.708l-6 6a.5.5 0 0 1-.708 0l-6-6a.5.5 0 0 1 0-.708z'/%3e%3c/svg%3e");
			--bs-accordion-btn-focus-border-color: #86b7fe;
			--bs-accordion-btn-focus-box-shadow: 0 0 0 0.25rem rgba(13, 110, 253, 0.25);
			--bs-accordion-body-padding-x: 1.25rem;
			--bs-accordion-body-padding-y: 1rem;
			--bs-accordion-active-color: #0c63e4;
			--bs-accordion-active-bg: #e7f1ff
		}

		.accordion-button {
			position: relative;
			display: flex;
			align-items: center;
			width: 100%;
			padding: var(--bs-accordion-btn-padding-y) var(--bs-accordion-btn-padding-x);
			font-size: 1rem;
			color: var(--bs-accordion-btn-color);
			text-align: left;
			background-color: var(--bs-accordion-btn-bg);
			border: 0;
			border-radius: 0;
			overflow-anchor: none;
			transition: var(--bs-accordion-transition)
		}

		@media (prefers-reduced-motion:reduce) {
			.accordion-button {
				transition: none
			}
		}

		.accordion-button:not(.collapsed) {
			color: var(--bs-accordion-active-color);
			background-color: var(--bs-accordion-active-bg);
			box-shadow: inset 0 calc(var(--bs-accordion-border-width) * -1) 0 var(--bs-accordion-border-color)
		}

		.accordion-button:not(.collapsed)::after {
			background-image: var(--bs-accordion-btn-active-icon);
			transform: var(--bs-accordion-btn-icon-transform)
		}

		.accordion-button::after {
			flex-shrink: 0;
			width: var(--bs-accordion-btn-icon-width);
			height: var(--bs-accordion-btn-icon-width);
			margin-left: auto;
			content: "";
			background-image: var(--bs-accordion-btn-icon);
			background-repeat: no-repeat;
			background-size: var(--bs-accordion-btn-icon-width);
			transition: var(--bs-accordion-btn-icon-transition)
		}

		@media (prefers-reduced-motion:reduce) {
			.accordion-button::after {
				transition: none
			}
		}

		.accordion-button:hover {
			z-index: 2
		}

		.accordion-button:focus {
			z-index: 3;
			border-color: var(--bs-accordion-btn-focus-border-color);
			outline: 0;
			box-shadow: var(--bs-accordion-btn-focus-box-shadow)
		}

		.accordion-header {
			margin-bottom: 0
		}

		.accordion-item {
			color: var(--bs-accordion-color);
			background-color: var(--bs-accordion-bg);
			border: var(--bs-accordion-border-width) solid var(--bs-accordion-border-color)
		}

		.accordion-item:first-of-type {
			border-top-left-radius: var(--bs-accordion-border-radius);
			border-top-right-radius: var(--bs-accordion-border-radius)
		}

		.accordion-item:first-of-type .accordion-button {
			border-top-left-radius: var(--bs-accordion-inner-border-radius);
			border-top-right-radius: var(--bs-accordion-inner-border-radius)
		}

		.accordion-item:not(:first-of-type) {
			border-top: 0
		}

		.accordion-item:last-of-type {
			border-bottom-right-radius: var(--bs-accordion-border-radius);
			border-bottom-left-radius: var(--bs-accordion-border-radius)
		}

		.accordion-item:last-of-type .accordion-button.collapsed {
			border-bottom-right-radius: var(--bs-accordion-inner-border-radius);
			border-bottom-left-radius: var(--bs-accordion-inner-border-radius)
		}

		.accordion-item:last-of-type .accordion-collapse {
			border-bottom-right-radius: var(--bs-accordion-border-radius);
			border-bottom-left-radius: var(--bs-accordion-border-radius)
		}

		.accordion-body {
			padding: var(--bs-accordion-body-padding-y) var(--bs-accordion-body-padding-x)
		}

		.accordion-flush .accordion-collapse {
			border-width: 0
		}

		.accordion-flush .accordion-item {
			border-right: 0;
			border-left: 0;
			border-radius: 0
		}

		.accordion-flush .accordion-item:first-child {
			border-top: 0
		}

		.accordion-flush .accordion-item:last-child {
			border-bottom: 0
		}

		.accordion-flush .accordion-item .accordion-button {
			border-radius: 0
		}

		.breadcrumb {
			--bs-breadcrumb-padding-x: 0;
			--bs-breadcrumb-padding-y: 0;
			--bs-breadcrumb-margin-bottom: 1rem;
			--bs-breadcrumb-bg: ;
			--bs-breadcrumb-border-radius: ;
			--bs-breadcrumb-divider-color: #6c757d;
			--bs-breadcrumb-item-padding-x: 0.5rem;
			--bs-breadcrumb-item-active-color: #6c757d;
			display: flex;
			flex-wrap: wrap;
			padding: var(--bs-breadcrumb-padding-y) var(--bs-breadcrumb-padding-x);
			margin-bottom: var(--bs-breadcrumb-margin-bottom);
			font-size: var(--bs-breadcrumb-font-size);
			list-style: none;
			background-color: var(--bs-breadcrumb-bg);
			border-radius: var(--bs-breadcrumb-border-radius)
		}

		.breadcrumb-item+.breadcrumb-item {
			padding-left: var(--bs-breadcrumb-item-padding-x)
		}

		.breadcrumb-item+.breadcrumb-item::before {
			float: left;
			padding-right: var(--bs-breadcrumb-item-padding-x);
			color: var(--bs-breadcrumb-divider-color);
			content: var(--bs-breadcrumb-divider, "/")
		}

		.breadcrumb-item.active {
			color: var(--bs-breadcrumb-item-active-color)
		}

		.pagination {
			--bs-pagination-padding-x: 0.75rem;
			--bs-pagination-padding-y: 0.375rem;
			--bs-pagination-font-size: 1rem;
			--bs-pagination-color: var(--bs-link-color);
			--bs-pagination-bg: #fff;
			--bs-pagination-border-width: 1px;
			--bs-pagination-border-color: #dee2e6;
			--bs-pagination-border-radius: 0.375rem;
			--bs-pagination-hover-color: var(--bs-link-hover-color);
			--bs-pagination-hover-bg: #e9ecef;
			--bs-pagination-hover-border-color: #dee2e6;
			--bs-pagination-focus-color: var(--bs-link-hover-color);
			--bs-pagination-focus-bg: #e9ecef;
			--bs-pagination-focus-box-shadow: 0 0 0 0.25rem rgba(13, 110, 253, 0.25);
			--bs-pagination-active-color: #fff;
			--bs-pagination-active-bg: #0d6efd;
			--bs-pagination-active-border-color: #0d6efd;
			--bs-pagination-disabled-color: #6c757d;
			--bs-pagination-disabled-bg: #fff;
			--bs-pagination-disabled-border-color: #dee2e6;
			display: flex;
			padding-left: 0;
			list-style: none
		}

		.page-link {
			position: relative;
			display: block;
			padding: var(--bs-pagination-padding-y) var(--bs-pagination-padding-x);
			font-size: var(--bs-pagination-font-size);
			color: var(--bs-pagination-color);
			text-decoration: none;
			background-color: var(--bs-pagination-bg);
			border: var(--bs-pagination-border-width) solid var(--bs-pagination-border-color);
			transition: color .15s ease-in-out, background-color .15s ease-in-out, border-color .15s ease-in-out, box-shadow .15s ease-in-out
		}

		@media (prefers-reduced-motion:reduce) {
			.page-link {
				transition: none
			}
		}

		.page-link:hover {
			z-index: 2;
			color: var(--bs-pagination-hover-color);
			background-color: var(--bs-pagination-hover-bg);
			border-color: var(--bs-pagination-hover-border-color)
		}

		.page-link:focus {
			z-index: 3;
			color: var(--bs-pagination-focus-color);
			background-color: var(--bs-pagination-focus-bg);
			outline: 0;
			box-shadow: var(--bs-pagination-focus-box-shadow)
		}

		.active>.page-link,
		.page-link.active {
			z-index: 3;
			color: var(--bs-pagination-active-color);
			background-color: var(--bs-pagination-active-bg);
			border-color: var(--bs-pagination-active-border-color)
		}

		.disabled>.page-link,
		.page-link.disabled {
			color: var(--bs-pagination-disabled-color);
			pointer-events: none;
			background-color: var(--bs-pagination-disabled-bg);
			border-color: var(--bs-pagination-disabled-border-color)
		}

		.page-item:not(:first-child) .page-link {
			margin-left: -1px
		}

		.page-item:first-child .page-link {
			border-top-left-radius: var(--bs-pagination-border-radius);
			border-bottom-left-radius: var(--bs-pagination-border-radius)
		}

		.page-item:last-child .page-link {
			border-top-right-radius: var(--bs-pagination-border-radius);
			border-bottom-right-radius: var(--bs-pagination-border-radius)
		}

		.pagination-lg {
			--bs-pagination-padding-x: 1.5rem;
			--bs-pagination-padding-y: 0.75rem;
			--bs-pagination-font-size: 1.25rem;
			--bs-pagination-border-radius: 0.5rem
		}

		.pagination-sm {
			--bs-pagination-padding-x: 0.5rem;
			--bs-pagination-padding-y: 0.25rem;
			--bs-pagination-font-size: 0.875rem;
			--bs-pagination-border-radius: 0.25rem
		}

		.badge {
			--bs-badge-padding-x: 0.65em;
			--bs-badge-padding-y: 0.35em;
			--bs-badge-font-size: 0.75em;
			--bs-badge-font-weight: 700;
			--bs-badge-color: #fff;
			--bs-badge-border-radius: 0.375rem;
			display: inline-block;
			padding: var(--bs-badge-padding-y) var(--bs-badge-padding-x);
			font-size: var(--bs-badge-font-size);
			font-weight: var(--bs-badge-font-weight);
			line-height: 1;
			color: var(--bs-badge-color);
			text-align: center;
			white-space: nowrap;
			vertical-align: baseline;
			border-radius: var(--bs-badge-border-radius)
		}

		.badge:empty {
			display: none
		}

		.btn .badge {
			position: relative;
			top: -1px
		}

		.alert {
			--bs-alert-bg: transparent;
			--bs-alert-padding-x: 1rem;
			--bs-alert-padding-y: 1rem;
			--bs-alert-margin-bottom: 1rem;
			--bs-alert-color: inherit;
			--bs-alert-border-color: transparent;
			--bs-alert-border: 1px solid var(--bs-alert-border-color);
			--bs-alert-border-radius: 0.375rem;
			position: relative;
			padding: var(--bs-alert-padding-y) var(--bs-alert-padding-x);
			margin-bottom: var(--bs-alert-margin-bottom);
			color: var(--bs-alert-color);
			background-color: var(--bs-alert-bg);
			border: var(--bs-alert-border);
			border-radius: var(--bs-alert-border-radius)
		}

		.alert-heading {
			color: inherit
		}

		.alert-link {
			font-weight: 700
		}

		.alert-dismissible {
			padding-right: 3rem
		}

		.alert-dismissible .btn-close {
			position: absolute;
			top: 0;
			right: 0;
			z-index: 2;
			padding: 1.25rem 1rem
		}

		.alert-primary {
			--bs-alert-color: #084298;
			--bs-alert-bg: #cfe2ff;
			--bs-alert-border-color: #b6d4fe
		}

		.alert-primary .alert-link {
			color: #06357a
		}

		.alert-secondary {
			--bs-alert-color: #41464b;
			--bs-alert-bg: #e2e3e5;
			--bs-alert-border-color: #d3d6d8
		}

		.alert-secondary .alert-link {
			color: #34383c
		}

		.alert-success {
			--bs-alert-color: #0f5132;
			--bs-alert-bg: #d1e7dd;
			--bs-alert-border-color: #badbcc
		}

		.alert-success .alert-link {
			color: #0c4128
		}

		.alert-info {
			--bs-alert-color: #055160;
			--bs-alert-bg: #cff4fc;
			--bs-alert-border-color: #b6effb
		}

		.alert-info .alert-link {
			color: #04414d
		}

		.alert-warning {
			--bs-alert-color: #664d03;
			--bs-alert-bg: #fff3cd;
			--bs-alert-border-color: #ffecb5
		}

		.alert-warning .alert-link {
			color: #523e02
		}

		.alert-danger {
			--bs-alert-color: #842029;
			--bs-alert-bg: #f8d7da;
			--bs-alert-border-color: #f5c2c7
		}

		.alert-danger .alert-link {
			color: #6a1a21
		}

		.alert-light {
			--bs-alert-color: #636464;
			--bs-alert-bg: #fefefe;
			--bs-alert-border-color: #fdfdfe
		}

		.alert-light .alert-link {
			color: #4f5050
		}

		.alert-dark {
			--bs-alert-color: #141619;
			--bs-alert-bg: #d3d3d4;
			--bs-alert-border-color: #bcbebf
		}

		.alert-dark .alert-link {
			color: #101214
		}

		@-webkit-keyframes progress-bar-stripes {
			0% {
				background-position-x: 1rem
			}
		}

		@keyframes progress-bar-stripes {
			0% {
				background-position-x: 1rem
			}
		}

		.progress {
			--bs-progress-height: 1rem;
			--bs-progress-font-size: 0.75rem;
			--bs-progress-bg: #e9ecef;
			--bs-progress-border-radius: 0.375rem;
			--bs-progress-box-shadow: inset 0 1px 2px rgba(0, 0, 0, 0.075);
			--bs-progress-bar-color: #fff;
			--bs-progress-bar-bg: #0d6efd;
			--bs-progress-bar-transition: width 0.6s ease;
			display: flex;
			height: var(--bs-progress-height);
			overflow: hidden;
			font-size: var(--bs-progress-font-size);
			background-color: var(--bs-progress-bg);
			border-radius: var(--bs-progress-border-radius)
		}

		.progress-bar {
			display: flex;
			flex-direction: column;
			justify-content: center;
			overflow: hidden;
			color: var(--bs-progress-bar-color);
			text-align: center;
			white-space: nowrap;
			background-color: var(--bs-progress-bar-bg);
			transition: var(--bs-progress-bar-transition)
		}

		@media (prefers-reduced-motion:reduce) {
			.progress-bar {
				transition: none
			}
		}

		.progress-bar-striped {
			background-image: linear-gradient(45deg, rgba(255, 255, 255, .15) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, .15) 50%, rgba(255, 255, 255, .15) 75%, transparent 75%, transparent);
			background-size: var(--bs-progress-height) var(--bs-progress-height)
		}

		.progress-bar-animated {
			-webkit-animation: 1s linear infinite progress-bar-stripes;
			animation: 1s linear infinite progress-bar-stripes
		}

		@media (prefers-reduced-motion:reduce) {
			.progress-bar-animated {
				-webkit-animation: none;
				animation: none
			}
		}

		.list-group {
			--bs-list-group-color: #212529;
			--bs-list-group-bg: #fff;
			--bs-list-group-border-color: rgba(0, 0, 0, 0.125);
			--bs-list-group-border-width: 1px;
			--bs-list-group-border-radius: 0.375rem;
			--bs-list-group-item-padding-x: 1rem;
			--bs-list-group-item-padding-y: 0.5rem;
			--bs-list-group-action-color: #495057;
			--bs-list-group-action-hover-color: #495057;
			--bs-list-group-action-hover-bg: #f8f9fa;
			--bs-list-group-action-active-color: #212529;
			--bs-list-group-action-active-bg: #e9ecef;
			--bs-list-group-disabled-color: #6c757d;
			--bs-list-group-disabled-bg: #fff;
			--bs-list-group-active-color: #fff;
			--bs-list-group-active-bg: #0d6efd;
			--bs-list-group-active-border-color: #0d6efd;
			display: flex;
			flex-direction: column;
			padding-left: 0;
			margin-bottom: 0;
			border-radius: var(--bs-list-group-border-radius)
		}

		.list-group-numbered {
			list-style-type: none;
			counter-reset: section
		}

		.list-group-numbered>.list-group-item::before {
			content: counters(section, ".") ". ";
			counter-increment: section
		}

		.list-group-item-action {
			width: 100%;
			color: var(--bs-list-group-action-color);
			text-align: inherit
		}

		.list-group-item-action:focus,
		.list-group-item-action:hover {
			z-index: 1;
			color: var(--bs-list-group-action-hover-color);
			text-decoration: none;
			background-color: var(--bs-list-group-action-hover-bg)
		}

		.list-group-item-action:active {
			color: var(--bs-list-group-action-active-color);
			background-color: var(--bs-list-group-action-active-bg)
		}

		.list-group-item {
			position: relative;
			display: block;
			padding: var(--bs-list-group-item-padding-y) var(--bs-list-group-item-padding-x);
			color: var(--bs-list-group-color);
			text-decoration: none;
			background-color: var(--bs-list-group-bg);
			border: var(--bs-list-group-border-width) solid var(--bs-list-group-border-color)
		}

		.list-group-item:first-child {
			border-top-left-radius: inherit;
			border-top-right-radius: inherit
		}

		.list-group-item:last-child {
			border-bottom-right-radius: inherit;
			border-bottom-left-radius: inherit
		}

		.list-group-item.disabled,
		.list-group-item:disabled {
			color: var(--bs-list-group-disabled-color);
			pointer-events: none;
			background-color: var(--bs-list-group-disabled-bg)
		}

		.list-group-item.active {
			z-index: 2;
			color: var(--bs-list-group-active-color);
			background-color: var(--bs-list-group-active-bg);
			border-color: var(--bs-list-group-active-border-color)
		}

		.list-group-item+.list-group-item {
			border-top-width: 0
		}

		.list-group-item+.list-group-item.active {
			margin-top: calc(var(--bs-list-group-border-width) * -1);
			border-top-width: var(--bs-list-group-border-width)
		}

		.list-group-horizontal {
			flex-direction: row
		}

		.list-group-horizontal>.list-group-item:first-child {
			border-bottom-left-radius: var(--bs-list-group-border-radius);
			border-top-right-radius: 0
		}

		.list-group-horizontal>.list-group-item:last-child {
			border-top-right-radius: var(--bs-list-group-border-radius);
			border-bottom-left-radius: 0
		}

		.list-group-horizontal>.list-group-item.active {
			margin-top: 0
		}

		.list-group-horizontal>.list-group-item+.list-group-item {
			border-top-width: var(--bs-list-group-border-width);
			border-left-width: 0
		}

		.list-group-horizontal>.list-group-item+.list-group-item.active {
			margin-left: calc(var(--bs-list-group-border-width) * -1);
			border-left-width: var(--bs-list-group-border-width)
		}

		@media (min-width:576px) {
			.list-group-horizontal-sm {
				flex-direction: row
			}

			.list-group-horizontal-sm>.list-group-item:first-child {
				border-bottom-left-radius: var(--bs-list-group-border-radius);
				border-top-right-radius: 0
			}

			.list-group-horizontal-sm>.list-group-item:last-child {
				border-top-right-radius: var(--bs-list-group-border-radius);
				border-bottom-left-radius: 0
			}

			.list-group-horizontal-sm>.list-group-item.active {
				margin-top: 0
			}

			.list-group-horizontal-sm>.list-group-item+.list-group-item {
				border-top-width: var(--bs-list-group-border-width);
				border-left-width: 0
			}

			.list-group-horizontal-sm>.list-group-item+.list-group-item.active {
				margin-left: calc(var(--bs-list-group-border-width) * -1);
				border-left-width: var(--bs-list-group-border-width)
			}
		}

		@media (min-width:768px) {
			.list-group-horizontal-md {
				flex-direction: row
			}

			.list-group-horizontal-md>.list-group-item:first-child {
				border-bottom-left-radius: var(--bs-list-group-border-radius);
				border-top-right-radius: 0
			}

			.list-group-horizontal-md>.list-group-item:last-child {
				border-top-right-radius: var(--bs-list-group-border-radius);
				border-bottom-left-radius: 0
			}

			.list-group-horizontal-md>.list-group-item.active {
				margin-top: 0
			}

			.list-group-horizontal-md>.list-group-item+.list-group-item {
				border-top-width: var(--bs-list-group-border-width);
				border-left-width: 0
			}

			.list-group-horizontal-md>.list-group-item+.list-group-item.active {
				margin-left: calc(var(--bs-list-group-border-width) * -1);
				border-left-width: var(--bs-list-group-border-width)
			}
		}

		@media (min-width:992px) {
			.list-group-horizontal-lg {
				flex-direction: row
			}

			.list-group-horizontal-lg>.list-group-item:first-child {
				border-bottom-left-radius: var(--bs-list-group-border-radius);
				border-top-right-radius: 0
			}

			.list-group-horizontal-lg>.list-group-item:last-child {
				border-top-right-radius: var(--bs-list-group-border-radius);
				border-bottom-left-radius: 0
			}

			.list-group-horizontal-lg>.list-group-item.active {
				margin-top: 0
			}

			.list-group-horizontal-lg>.list-group-item+.list-group-item {
				border-top-width: var(--bs-list-group-border-width);
				border-left-width: 0
			}

			.list-group-horizontal-lg>.list-group-item+.list-group-item.active {
				margin-left: calc(var(--bs-list-group-border-width) * -1);
				border-left-width: var(--bs-list-group-border-width)
			}
		}

		@media (min-width:1200px) {
			.list-group-horizontal-xl {
				flex-direction: row
			}

			.list-group-horizontal-xl>.list-group-item:first-child {
				border-bottom-left-radius: var(--bs-list-group-border-radius);
				border-top-right-radius: 0
			}

			.list-group-horizontal-xl>.list-group-item:last-child {
				border-top-right-radius: var(--bs-list-group-border-radius);
				border-bottom-left-radius: 0
			}

			.list-group-horizontal-xl>.list-group-item.active {
				margin-top: 0
			}

			.list-group-horizontal-xl>.list-group-item+.list-group-item {
				border-top-width: var(--bs-list-group-border-width);
				border-left-width: 0
			}

			.list-group-horizontal-xl>.list-group-item+.list-group-item.active {
				margin-left: calc(var(--bs-list-group-border-width) * -1);
				border-left-width: var(--bs-list-group-border-width)
			}
		}

		@media (min-width:1400px) {
			.list-group-horizontal-xxl {
				flex-direction: row
			}

			.list-group-horizontal-xxl>.list-group-item:first-child {
				border-bottom-left-radius: var(--bs-list-group-border-radius);
				border-top-right-radius: 0
			}

			.list-group-horizontal-xxl>.list-group-item:last-child {
				border-top-right-radius: var(--bs-list-group-border-radius);
				border-bottom-left-radius: 0
			}

			.list-group-horizontal-xxl>.list-group-item.active {
				margin-top: 0
			}

			.list-group-horizontal-xxl>.list-group-item+.list-group-item {
				border-top-width: var(--bs-list-group-border-width);
				border-left-width: 0
			}

			.list-group-horizontal-xxl>.list-group-item+.list-group-item.active {
				margin-left: calc(var(--bs-list-group-border-width) * -1);
				border-left-width: var(--bs-list-group-border-width)
			}
		}

		.list-group-flush {
			border-radius: 0
		}

		.list-group-flush>.list-group-item {
			border-width: 0 0 var(--bs-list-group-border-width)
		}

		.list-group-flush>.list-group-item:last-child {
			border-bottom-width: 0
		}

		.list-group-item-primary {
			color: #084298;
			background-color: #cfe2ff
		}

		.list-group-item-primary.list-group-item-action:focus,
		.list-group-item-primary.list-group-item-action:hover {
			color: #084298;
			background-color: #bacbe6
		}

		.list-group-item-primary.list-group-item-action.active {
			color: #fff;
			background-color: #084298;
			border-color: #084298
		}

		.list-group-item-secondary {
			color: #41464b;
			background-color: #e2e3e5
		}

		.list-group-item-secondary.list-group-item-action:focus,
		.list-group-item-secondary.list-group-item-action:hover {
			color: #41464b;
			background-color: #cbccce
		}

		.list-group-item-secondary.list-group-item-action.active {
			color: #fff;
			background-color: #41464b;
			border-color: #41464b
		}

		.list-group-item-success {
			color: #0f5132;
			background-color: #d1e7dd
		}

		.list-group-item-success.list-group-item-action:focus,
		.list-group-item-success.list-group-item-action:hover {
			color: #0f5132;
			background-color: #bcd0c7
		}

		.list-group-item-success.list-group-item-action.active {
			color: #fff;
			background-color: #0f5132;
			border-color: #0f5132
		}

		.list-group-item-info {
			color: #055160;
			background-color: #cff4fc
		}

		.list-group-item-info.list-group-item-action:focus,
		.list-group-item-info.list-group-item-action:hover {
			color: #055160;
			background-color: #badce3
		}

		.list-group-item-info.list-group-item-action.active {
			color: #fff;
			background-color: #055160;
			border-color: #055160
		}

		.list-group-item-warning {
			color: #664d03;
			background-color: #fff3cd
		}

		.list-group-item-warning.list-group-item-action:focus,
		.list-group-item-warning.list-group-item-action:hover {
			color: #664d03;
			background-color: #e6dbb9
		}

		.list-group-item-warning.list-group-item-action.active {
			color: #fff;
			background-color: #664d03;
			border-color: #664d03
		}

		.list-group-item-danger {
			color: #842029;
			background-color: #f8d7da
		}

		.list-group-item-danger.list-group-item-action:focus,
		.list-group-item-danger.list-group-item-action:hover {
			color: #842029;
			background-color: #dfc2c4
		}

		.list-group-item-danger.list-group-item-action.active {
			color: #fff;
			background-color: #842029;
			border-color: #842029
		}

		.list-group-item-light {
			color: #636464;
			background-color: #fefefe
		}

		.list-group-item-light.list-group-item-action:focus,
		.list-group-item-light.list-group-item-action:hover {
			color: #636464;
			background-color: #e5e5e5
		}

		.list-group-item-light.list-group-item-action.active {
			color: #fff;
			background-color: #636464;
			border-color: #636464
		}

		.list-group-item-dark {
			color: #141619;
			background-color: #d3d3d4
		}

		.list-group-item-dark.list-group-item-action:focus,
		.list-group-item-dark.list-group-item-action:hover {
			color: #141619;
			background-color: #bebebf
		}

		.list-group-item-dark.list-group-item-action.active {
			color: #fff;
			background-color: #141619;
			border-color: #141619
		}

		.btn-close {
			box-sizing: content-box;
			width: 1em;
			height: 1em;
			padding: .25em .25em;
			color: #000;
			background: transparent url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16' fill='%23000'%3e%3cpath d='M.293.293a1 1 0 0 1 1.414 0L8 6.586 14.293.293a1 1 0 1 1 1.414 1.414L9.414 8l6.293 6.293a1 1 0 0 1-1.414 1.414L8 9.414l-6.293 6.293a1 1 0 0 1-1.414-1.414L6.586 8 .293 1.707a1 1 0 0 1 0-1.414z'/%3e%3c/svg%3e") center/1em auto no-repeat;
			border: 0;
			border-radius: .375rem;
			opacity: .5
		}

		.btn-close:hover {
			color: #000;
			text-decoration: none;
			opacity: .75
		}

		.btn-close:focus {
			outline: 0;
			box-shadow: 0 0 0 .25rem rgba(13, 110, 253, .25);
			opacity: 1
		}

		.btn-close.disabled,
		.btn-close:disabled {
			pointer-events: none;
			-webkit-user-select: none;
			-moz-user-select: none;
			user-select: none;
			opacity: .25
		}

		.btn-close-white {
			filter: invert(1) grayscale(100%) brightness(200%)
		}

		.toast {
			--bs-toast-padding-x: 0.75rem;
			--bs-toast-padding-y: 0.5rem;
			--bs-toast-spacing: 1.5rem;
			--bs-toast-max-width: 350px;
			--bs-toast-font-size: 0.875rem;
			--bs-toast-color: ;
			--bs-toast-bg: rgba(255, 255, 255, 0.85);
			--bs-toast-border-width: 1px;
			--bs-toast-border-color: var(--bs-border-color-translucent);
			--bs-toast-border-radius: 0.375rem;
			--bs-toast-box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.15);
			--bs-toast-header-color: #6c757d;
			--bs-toast-header-bg: rgba(255, 255, 255, 0.85);
			--bs-toast-header-border-color: rgba(0, 0, 0, 0.05);
			width: var(--bs-toast-max-width);
			max-width: 100%;
			font-size: var(--bs-toast-font-size);
			color: var(--bs-toast-color);
			pointer-events: auto;
			background-color: var(--bs-toast-bg);
			background-clip: padding-box;
			border: var(--bs-toast-border-width) solid var(--bs-toast-border-color);
			box-shadow: var(--bs-toast-box-shadow);
			border-radius: var(--bs-toast-border-radius)
		}

		.toast.showing {
			opacity: 0
		}

		.toast:not(.show) {
			display: none
		}

		.toast-container {
			position: absolute;
			z-index: 1090;
			width: -webkit-max-content;
			width: -moz-max-content;
			width: max-content;
			max-width: 100%;
			pointer-events: none
		}

		.toast-container>:not(:last-child) {
			margin-bottom: var(--bs-toast-spacing)
		}

		.toast-header {
			display: flex;
			align-items: center;
			padding: var(--bs-toast-padding-y) var(--bs-toast-padding-x);
			color: var(--bs-toast-header-color);
			background-color: var(--bs-toast-header-bg);
			background-clip: padding-box;
			border-bottom: var(--bs-toast-border-width) solid var(--bs-toast-header-border-color);
			border-top-left-radius: calc(var(--bs-toast-border-radius) - var(--bs-toast-border-width));
			border-top-right-radius: calc(var(--bs-toast-border-radius) - var(--bs-toast-border-width))
		}

		.toast-header .btn-close {
			margin-right: calc(var(--bs-toast-padding-x) * -.5);
			margin-left: var(--bs-toast-padding-x)
		}

		.toast-body {
			padding: var(--bs-toast-padding-x);
			word-wrap: break-word
		}

		.modal {
			--bs-modal-zindex: 1055;
			--bs-modal-width: 500px;
			--bs-modal-padding: 1rem;
			--bs-modal-margin: 0.5rem;
			--bs-modal-color: ;
			--bs-modal-bg: #fff;
			--bs-modal-border-color: var(--bs-border-color-translucent);
			--bs-modal-border-width: 1px;
			--bs-modal-border-radius: 0.5rem;
			--bs-modal-box-shadow: 0 0.125rem 0.25rem rgba(0, 0, 0, 0.075);
			--bs-modal-inner-border-radius: calc(0.5rem - 1px);
			--bs-modal-header-padding-x: 1rem;
			--bs-modal-header-padding-y: 1rem;
			--bs-modal-header-padding: 1rem 1rem;
			--bs-modal-header-border-color: var(--bs-border-color);
			--bs-modal-header-border-width: 1px;
			--bs-modal-title-line-height: 1.5;
			--bs-modal-footer-gap: 0.5rem;
			--bs-modal-footer-bg: ;
			--bs-modal-footer-border-color: var(--bs-border-color);
			--bs-modal-footer-border-width: 1px;
			position: fixed;
			top: 0;
			left: 0;
			z-index: var(--bs-modal-zindex);
			display: none;
			width: 100%;
			height: 100%;
			overflow-x: hidden;
			overflow-y: auto;
			outline: 0
		}

		.modal-dialog {
			position: relative;
			width: auto;
			margin: var(--bs-modal-margin);
			pointer-events: none
		}

		.modal.fade .modal-dialog {
			transition: transform .3s ease-out;
			transform: translate(0, -50px)
		}

		@media (prefers-reduced-motion:reduce) {
			.modal.fade .modal-dialog {
				transition: none
			}
		}

		.modal.show .modal-dialog {
			transform: none
		}

		.modal.modal-static .modal-dialog {
			transform: scale(1.02)
		}

		.modal-dialog-scrollable {
			height: calc(100% - var(--bs-modal-margin) * 2)
		}

		.modal-dialog-scrollable .modal-content {
			max-height: 100%;
			overflow: hidden
		}

		.modal-dialog-scrollable .modal-body {
			overflow-y: auto
		}

		.modal-dialog-centered {
			display: flex;
			align-items: center;
			min-height: calc(100% - var(--bs-modal-margin) * 2)
		}

		.modal-content {
			position: relative;
			display: flex;
			flex-direction: column;
			width: 100%;
			color: var(--bs-modal-color);
			pointer-events: auto;
			background-color: var(--bs-modal-bg);
			background-clip: padding-box;
			border: var(--bs-modal-border-width) solid var(--bs-modal-border-color);
			border-radius: var(--bs-modal-border-radius);
			outline: 0
		}

		.modal-backdrop {
			--bs-backdrop-zindex: 1050;
			--bs-backdrop-bg: #000;
			--bs-backdrop-opacity: 0.5;
			position: fixed;
			top: 0;
			left: 0;
			z-index: var(--bs-backdrop-zindex);
			width: 100vw;
			height: 100vh;
			background-color: var(--bs-backdrop-bg)
		}

		.modal-backdrop.fade {
			opacity: 0
		}

		.modal-backdrop.show {
			opacity: var(--bs-backdrop-opacity)
		}

		.modal-header {
			display: flex;
			flex-shrink: 0;
			align-items: center;
			justify-content: space-between;
			padding: var(--bs-modal-header-padding);
			border-bottom: var(--bs-modal-header-border-width) solid var(--bs-modal-header-border-color);
			border-top-left-radius: var(--bs-modal-inner-border-radius);
			border-top-right-radius: var(--bs-modal-inner-border-radius)
		}

		.modal-header .btn-close {
			padding: calc(var(--bs-modal-header-padding-y) * .5) calc(var(--bs-modal-header-padding-x) * .5);
			margin: calc(var(--bs-modal-header-padding-y) * -.5) calc(var(--bs-modal-header-padding-x) * -.5) calc(var(--bs-modal-header-padding-y) * -.5) auto
		}

		.modal-title {
			margin-bottom: 0;
			line-height: var(--bs-modal-title-line-height)
		}

		.modal-body {
			position: relative;
			flex: 1 1 auto;
			padding: var(--bs-modal-padding)
		}

		.modal-footer {
			display: flex;
			flex-shrink: 0;
			flex-wrap: wrap;
			align-items: center;
			justify-content: flex-end;
			padding: calc(var(--bs-modal-padding) - var(--bs-modal-footer-gap) * .5);
			background-color: var(--bs-modal-footer-bg);
			border-top: var(--bs-modal-footer-border-width) solid var(--bs-modal-footer-border-color);
			border-bottom-right-radius: var(--bs-modal-inner-border-radius);
			border-bottom-left-radius: var(--bs-modal-inner-border-radius)
		}

		.modal-footer>* {
			margin: calc(var(--bs-modal-footer-gap) * .5)
		}

		@media (min-width:576px) {
			.modal {
				--bs-modal-margin: 1.75rem;
				--bs-modal-box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.15)
			}

			.modal-dialog {
				max-width: var(--bs-modal-width);
				margin-right: auto;
				margin-left: auto
			}

			.modal-sm {
				--bs-modal-width: 300px
			}
		}

		@media (min-width:992px) {

			.modal-lg,
			.modal-xl {
				--bs-modal-width: 800px
			}
		}

		@media (min-width:1200px) {
			.modal-xl {
				--bs-modal-width: 1140px
			}
		}

		.modal-fullscreen {
			width: 100vw;
			max-width: none;
			height: 100%;
			margin: 0
		}

		.modal-fullscreen .modal-content {
			height: 100%;
			border: 0;
			border-radius: 0
		}

		.modal-fullscreen .modal-footer,
		.modal-fullscreen .modal-header {
			border-radius: 0
		}

		.modal-fullscreen .modal-body {
			overflow-y: auto
		}

		@media (max-width:575.98px) {
			.modal-fullscreen-sm-down {
				width: 100vw;
				max-width: none;
				height: 100%;
				margin: 0
			}

			.modal-fullscreen-sm-down .modal-content {
				height: 100%;
				border: 0;
				border-radius: 0
			}

			.modal-fullscreen-sm-down .modal-footer,
			.modal-fullscreen-sm-down .modal-header {
				border-radius: 0
			}

			.modal-fullscreen-sm-down .modal-body {
				overflow-y: auto
			}
		}

		@media (max-width:767.98px) {
			.modal-fullscreen-md-down {
				width: 100vw;
				max-width: none;
				height: 100%;
				margin: 0
			}

			.modal-fullscreen-md-down .modal-content {
				height: 100%;
				border: 0;
				border-radius: 0
			}

			.modal-fullscreen-md-down .modal-footer,
			.modal-fullscreen-md-down .modal-header {
				border-radius: 0
			}

			.modal-fullscreen-md-down .modal-body {
				overflow-y: auto
			}
		}

		@media (max-width:991.98px) {
			.modal-fullscreen-lg-down {
				width: 100vw;
				max-width: none;
				height: 100%;
				margin: 0
			}

			.modal-fullscreen-lg-down .modal-content {
				height: 100%;
				border: 0;
				border-radius: 0
			}

			.modal-fullscreen-lg-down .modal-footer,
			.modal-fullscreen-lg-down .modal-header {
				border-radius: 0
			}

			.modal-fullscreen-lg-down .modal-body {
				overflow-y: auto
			}
		}

		@media (max-width:1199.98px) {
			.modal-fullscreen-xl-down {
				width: 100vw;
				max-width: none;
				height: 100%;
				margin: 0
			}

			.modal-fullscreen-xl-down .modal-content {
				height: 100%;
				border: 0;
				border-radius: 0
			}

			.modal-fullscreen-xl-down .modal-footer,
			.modal-fullscreen-xl-down .modal-header {
				border-radius: 0
			}

			.modal-fullscreen-xl-down .modal-body {
				overflow-y: auto
			}
		}

		@media (max-width:1399.98px) {
			.modal-fullscreen-xxl-down {
				width: 100vw;
				max-width: none;
				height: 100%;
				margin: 0
			}

			.modal-fullscreen-xxl-down .modal-content {
				height: 100%;
				border: 0;
				border-radius: 0
			}

			.modal-fullscreen-xxl-down .modal-footer,
			.modal-fullscreen-xxl-down .modal-header {
				border-radius: 0
			}

			.modal-fullscreen-xxl-down .modal-body {
				overflow-y: auto
			}
		}

		.tooltip {
			--bs-tooltip-zindex: 1080;
			--bs-tooltip-max-width: 200px;
			--bs-tooltip-padding-x: 0.5rem;
			--bs-tooltip-padding-y: 0.25rem;
			--bs-tooltip-margin: ;
			--bs-tooltip-font-size: 0.875rem;
			--bs-tooltip-color: #fff;
			--bs-tooltip-bg: #000;
			--bs-tooltip-border-radius: 0.375rem;
			--bs-tooltip-opacity: 0.9;
			--bs-tooltip-arrow-width: 0.8rem;
			--bs-tooltip-arrow-height: 0.4rem;
			z-index: var(--bs-tooltip-zindex);
			display: block;
			padding: var(--bs-tooltip-arrow-height);
			margin: var(--bs-tooltip-margin);
			font-family: var(--bs-font-sans-serif);
			font-style: normal;
			font-weight: 400;
			line-height: 1.5;
			text-align: left;
			text-align: start;
			text-decoration: none;
			text-shadow: none;
			text-transform: none;
			letter-spacing: normal;
			word-break: normal;
			white-space: normal;
			word-spacing: normal;
			line-break: auto;
			font-size: var(--bs-tooltip-font-size);
			word-wrap: break-word;
			opacity: 0
		}

		.tooltip.show {
			opacity: var(--bs-tooltip-opacity)
		}

		.tooltip .tooltip-arrow {
			display: block;
			width: var(--bs-tooltip-arrow-width);
			height: var(--bs-tooltip-arrow-height)
		}

		.tooltip .tooltip-arrow::before {
			position: absolute;
			content: "";
			border-color: transparent;
			border-style: solid
		}

		.bs-tooltip-auto[data-popper-placement^=top] .tooltip-arrow,
		.bs-tooltip-top .tooltip-arrow {
			bottom: 0
		}

		.bs-tooltip-auto[data-popper-placement^=top] .tooltip-arrow::before,
		.bs-tooltip-top .tooltip-arrow::before {
			top: -1px;
			border-width: var(--bs-tooltip-arrow-height) calc(var(--bs-tooltip-arrow-width) * .5) 0;
			border-top-color: var(--bs-tooltip-bg)
		}

		.bs-tooltip-auto[data-popper-placement^=right] .tooltip-arrow,
		.bs-tooltip-end .tooltip-arrow {
			left: 0;
			width: var(--bs-tooltip-arrow-height);
			height: var(--bs-tooltip-arrow-width)
		}

		.bs-tooltip-auto[data-popper-placement^=right] .tooltip-arrow::before,
		.bs-tooltip-end .tooltip-arrow::before {
			right: -1px;
			border-width: calc(var(--bs-tooltip-arrow-width) * .5) var(--bs-tooltip-arrow-height) calc(var(--bs-tooltip-arrow-width) * .5) 0;
			border-right-color: var(--bs-tooltip-bg)
		}

		.bs-tooltip-auto[data-popper-placement^=bottom] .tooltip-arrow,
		.bs-tooltip-bottom .tooltip-arrow {
			top: 0
		}

		.bs-tooltip-auto[data-popper-placement^=bottom] .tooltip-arrow::before,
		.bs-tooltip-bottom .tooltip-arrow::before {
			bottom: -1px;
			border-width: 0 calc(var(--bs-tooltip-arrow-width) * .5) var(--bs-tooltip-arrow-height);
			border-bottom-color: var(--bs-tooltip-bg)
		}

		.bs-tooltip-auto[data-popper-placement^=left] .tooltip-arrow,
		.bs-tooltip-start .tooltip-arrow {
			right: 0;
			width: var(--bs-tooltip-arrow-height);
			height: var(--bs-tooltip-arrow-width)
		}

		.bs-tooltip-auto[data-popper-placement^=left] .tooltip-arrow::before,
		.bs-tooltip-start .tooltip-arrow::before {
			left: -1px;
			border-width: calc(var(--bs-tooltip-arrow-width) * .5) 0 calc(var(--bs-tooltip-arrow-width) * .5) var(--bs-tooltip-arrow-height);
			border-left-color: var(--bs-tooltip-bg)
		}

		.tooltip-inner {
			max-width: var(--bs-tooltip-max-width);
			padding: var(--bs-tooltip-padding-y) var(--bs-tooltip-padding-x);
			color: var(--bs-tooltip-color);
			text-align: center;
			background-color: var(--bs-tooltip-bg);
			border-radius: var(--bs-tooltip-border-radius)
		}

		.popover {
			--bs-popover-zindex: 1070;
			--bs-popover-max-width: 276px;
			--bs-popover-font-size: 0.875rem;
			--bs-popover-bg: #fff;
			--bs-popover-border-width: 1px;
			--bs-popover-border-color: var(--bs-border-color-translucent);
			--bs-popover-border-radius: 0.5rem;
			--bs-popover-inner-border-radius: calc(0.5rem - 1px);
			--bs-popover-box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.15);
			--bs-popover-header-padding-x: 1rem;
			--bs-popover-header-padding-y: 0.5rem;
			--bs-popover-header-font-size: 1rem;
			--bs-popover-header-color: var(--bs-heading-color);
			--bs-popover-header-bg: #f0f0f0;
			--bs-popover-body-padding-x: 1rem;
			--bs-popover-body-padding-y: 1rem;
			--bs-popover-body-color: #212529;
			--bs-popover-arrow-width: 1rem;
			--bs-popover-arrow-height: 0.5rem;
			--bs-popover-arrow-border: var(--bs-popover-border-color);
			z-index: var(--bs-popover-zindex);
			display: block;
			max-width: var(--bs-popover-max-width);
			font-family: var(--bs-font-sans-serif);
			font-style: normal;
			font-weight: 400;
			line-height: 1.5;
			text-align: left;
			text-align: start;
			text-decoration: none;
			text-shadow: none;
			text-transform: none;
			letter-spacing: normal;
			word-break: normal;
			white-space: normal;
			word-spacing: normal;
			line-break: auto;
			font-size: var(--bs-popover-font-size);
			word-wrap: break-word;
			background-color: var(--bs-popover-bg);
			background-clip: padding-box;
			border: var(--bs-popover-border-width) solid var(--bs-popover-border-color);
			border-radius: var(--bs-popover-border-radius)
		}

		.popover .popover-arrow {
			display: block;
			width: var(--bs-popover-arrow-width);
			height: var(--bs-popover-arrow-height)
		}

		.popover .popover-arrow::after,
		.popover .popover-arrow::before {
			position: absolute;
			display: block;
			content: "";
			border-color: transparent;
			border-style: solid;
			border-width: 0
		}

		.bs-popover-auto[data-popper-placement^=top]>.popover-arrow,
		.bs-popover-top>.popover-arrow {
			bottom: calc(var(--bs-popover-arrow-height) * -1 - var(--bs-popover-border-width))
		}

		.bs-popover-auto[data-popper-placement^=top]>.popover-arrow::after,
		.bs-popover-auto[data-popper-placement^=top]>.popover-arrow::before,
		.bs-popover-top>.popover-arrow::after,
		.bs-popover-top>.popover-arrow::before {
			border-width: var(--bs-popover-arrow-height) calc(var(--bs-popover-arrow-width) * .5) 0
		}

		.bs-popover-auto[data-popper-placement^=top]>.popover-arrow::before,
		.bs-popover-top>.popover-arrow::before {
			bottom: 0;
			border-top-color: var(--bs-popover-arrow-border)
		}

		.bs-popover-auto[data-popper-placement^=top]>.popover-arrow::after,
		.bs-popover-top>.popover-arrow::after {
			bottom: var(--bs-popover-border-width);
			border-top-color: var(--bs-popover-bg)
		}

		.bs-popover-auto[data-popper-placement^=right]>.popover-arrow,
		.bs-popover-end>.popover-arrow {
			left: calc(var(--bs-popover-arrow-height) * -1 - var(--bs-popover-border-width));
			width: var(--bs-popover-arrow-height);
			height: var(--bs-popover-arrow-width)
		}

		.bs-popover-auto[data-popper-placement^=right]>.popover-arrow::after,
		.bs-popover-auto[data-popper-placement^=right]>.popover-arrow::before,
		.bs-popover-end>.popover-arrow::after,
		.bs-popover-end>.popover-arrow::before {
			border-width: calc(var(--bs-popover-arrow-width) * .5) var(--bs-popover-arrow-height) calc(var(--bs-popover-arrow-width) * .5) 0
		}

		.bs-popover-auto[data-popper-placement^=right]>.popover-arrow::before,
		.bs-popover-end>.popover-arrow::before {
			left: 0;
			border-right-color: var(--bs-popover-arrow-border)
		}

		.bs-popover-auto[data-popper-placement^=right]>.popover-arrow::after,
		.bs-popover-end>.popover-arrow::after {
			left: var(--bs-popover-border-width);
			border-right-color: var(--bs-popover-bg)
		}

		.bs-popover-auto[data-popper-placement^=bottom]>.popover-arrow,
		.bs-popover-bottom>.popover-arrow {
			top: calc(var(--bs-popover-arrow-height) * -1 - var(--bs-popover-border-width))
		}

		.bs-popover-auto[data-popper-placement^=bottom]>.popover-arrow::after,
		.bs-popover-auto[data-popper-placement^=bottom]>.popover-arrow::before,
		.bs-popover-bottom>.popover-arrow::after,
		.bs-popover-bottom>.popover-arrow::before {
			border-width: 0 calc(var(--bs-popover-arrow-width) * .5) var(--bs-popover-arrow-height)
		}

		.bs-popover-auto[data-popper-placement^=bottom]>.popover-arrow::before,
		.bs-popover-bottom>.popover-arrow::before {
			top: 0;
			border-bottom-color: var(--bs-popover-arrow-border)
		}

		.bs-popover-auto[data-popper-placement^=bottom]>.popover-arrow::after,
		.bs-popover-bottom>.popover-arrow::after {
			top: var(--bs-popover-border-width);
			border-bottom-color: var(--bs-popover-bg)
		}

		.bs-popover-auto[data-popper-placement^=bottom] .popover-header::before,
		.bs-popover-bottom .popover-header::before {
			position: absolute;
			top: 0;
			left: 50%;
			display: block;
			width: var(--bs-popover-arrow-width);
			margin-left: calc(var(--bs-popover-arrow-width) * -.5);
			content: "";
			border-bottom: var(--bs-popover-border-width) solid var(--bs-popover-header-bg)
		}

		.bs-popover-auto[data-popper-placement^=left]>.popover-arrow,
		.bs-popover-start>.popover-arrow {
			right: calc(var(--bs-popover-arrow-height) * -1 - var(--bs-popover-border-width));
			width: var(--bs-popover-arrow-height);
			height: var(--bs-popover-arrow-width)
		}

		.bs-popover-auto[data-popper-placement^=left]>.popover-arrow::after,
		.bs-popover-auto[data-popper-placement^=left]>.popover-arrow::before,
		.bs-popover-start>.popover-arrow::after,
		.bs-popover-start>.popover-arrow::before {
			border-width: calc(var(--bs-popover-arrow-width) * .5) 0 calc(var(--bs-popover-arrow-width) * .5) var(--bs-popover-arrow-height)
		}

		.bs-popover-auto[data-popper-placement^=left]>.popover-arrow::before,
		.bs-popover-start>.popover-arrow::before {
			right: 0;
			border-left-color: var(--bs-popover-arrow-border)
		}

		.bs-popover-auto[data-popper-placement^=left]>.popover-arrow::after,
		.bs-popover-start>.popover-arrow::after {
			right: var(--bs-popover-border-width);
			border-left-color: var(--bs-popover-bg)
		}

		.popover-header {
			padding: var(--bs-popover-header-padding-y) var(--bs-popover-header-padding-x);
			margin-bottom: 0;
			font-size: var(--bs-popover-header-font-size);
			color: var(--bs-popover-header-color);
			background-color: var(--bs-popover-header-bg);
			border-bottom: var(--bs-popover-border-width) solid var(--bs-popover-border-color);
			border-top-left-radius: var(--bs-popover-inner-border-radius);
			border-top-right-radius: var(--bs-popover-inner-border-radius)
		}

		.popover-header:empty {
			display: none
		}

		.popover-body {
			padding: var(--bs-popover-body-padding-y) var(--bs-popover-body-padding-x);
			color: var(--bs-popover-body-color)
		}

		.carousel {
			position: relative
		}

		.carousel.pointer-event {
			touch-action: pan-y
		}

		.carousel-inner {
			position: relative;
			width: 100%;
			overflow: hidden
		}

		.carousel-inner::after {
			display: block;
			clear: both;
			content: ""
		}

		.carousel-item {
			position: relative;
			display: none;
			float: left;
			width: 100%;
			margin-right: -100%;
			-webkit-backface-visibility: hidden;
			backface-visibility: hidden;
			transition: transform .6s ease-in-out
		}

		@media (prefers-reduced-motion:reduce) {
			.carousel-item {
				transition: none
			}
		}

		.carousel-item-next,
		.carousel-item-prev,
		.carousel-item.active {
			display: block
		}

		.active.carousel-item-end,
		.carousel-item-next:not(.carousel-item-start) {
			transform: translateX(100%)
		}

		.active.carousel-item-start,
		.carousel-item-prev:not(.carousel-item-end) {
			transform: translateX(-100%)
		}

		.carousel-fade .carousel-item {
			opacity: 0;
			transition-property: opacity;
			transform: none
		}

		.carousel-fade .carousel-item-next.carousel-item-start,
		.carousel-fade .carousel-item-prev.carousel-item-end,
		.carousel-fade .carousel-item.active {
			z-index: 1;
			opacity: 1
		}

		.carousel-fade .active.carousel-item-end,
		.carousel-fade .active.carousel-item-start {
			z-index: 0;
			opacity: 0;
			transition: opacity 0s .6s
		}

		@media (prefers-reduced-motion:reduce) {

			.carousel-fade .active.carousel-item-end,
			.carousel-fade .active.carousel-item-start {
				transition: none
			}
		}

		.carousel-control-next,
		.carousel-control-prev {
			position: absolute;
			top: 0;
			bottom: 0;
			z-index: 1;
			display: flex;
			align-items: center;
			justify-content: center;
			width: 15%;
			padding: 0;
			color: #fff;
			text-align: center;
			background: 0 0;
			border: 0;
			opacity: .5;
			transition: opacity .15s ease
		}

		@media (prefers-reduced-motion:reduce) {

			.carousel-control-next,
			.carousel-control-prev {
				transition: none
			}
		}

		.carousel-control-next:focus,
		.carousel-control-next:hover,
		.carousel-control-prev:focus,
		.carousel-control-prev:hover {
			color: #fff;
			text-decoration: none;
			outline: 0;
			opacity: .9
		}

		.carousel-control-prev {
			left: 0
		}

		.carousel-control-next {
			right: 0
		}

		.carousel-control-next-icon,
		.carousel-control-prev-icon {
			display: inline-block;
			width: 2rem;
			height: 2rem;
			background-repeat: no-repeat;
			background-position: 50%;
			background-size: 100% 100%
		}

		.carousel-control-prev-icon {
			background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16' fill='%23fff'%3e%3cpath d='M11.354 1.646a.5.5 0 0 1 0 .708L5.707 8l5.647 5.646a.5.5 0 0 1-.708.708l-6-6a.5.5 0 0 1 0-.708l6-6a.5.5 0 0 1 .708 0z'/%3e%3c/svg%3e")
		}

		.carousel-control-next-icon {
			background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16' fill='%23fff'%3e%3cpath d='M4.646 1.646a.5.5 0 0 1 .708 0l6 6a.5.5 0 0 1 0 .708l-6 6a.5.5 0 0 1-.708-.708L10.293 8 4.646 2.354a.5.5 0 0 1 0-.708z'/%3e%3c/svg%3e")
		}

		.carousel-indicators {
			position: absolute;
			right: 0;
			bottom: 0;
			left: 0;
			z-index: 2;
			display: flex;
			justify-content: center;
			padding: 0;
			margin-right: 15%;
			margin-bottom: 1rem;
			margin-left: 15%;
			list-style: none
		}

		.carousel-indicators [data-bs-target] {
			box-sizing: content-box;
			flex: 0 1 auto;
			width: 30px;
			height: 3px;
			padding: 0;
			margin-right: 3px;
			margin-left: 3px;
			text-indent: -999px;
			cursor: pointer;
			background-color: #fff;
			background-clip: padding-box;
			border: 0;
			border-top: 10px solid transparent;
			border-bottom: 10px solid transparent;
			opacity: .5;
			transition: opacity .6s ease
		}

		@media (prefers-reduced-motion:reduce) {
			.carousel-indicators [data-bs-target] {
				transition: none
			}
		}

		.carousel-indicators .active {
			opacity: 1
		}

		.carousel-caption {
			position: absolute;
			right: 15%;
			bottom: 1.25rem;
			left: 15%;
			padding-top: 1.25rem;
			padding-bottom: 1.25rem;
			color: #fff;
			text-align: center
		}

		.carousel-dark .carousel-control-next-icon,
		.carousel-dark .carousel-control-prev-icon {
			filter: invert(1) grayscale(100)
		}

		.carousel-dark .carousel-indicators [data-bs-target] {
			background-color: #000
		}

		.carousel-dark .carousel-caption {
			color: #000
		}

		.spinner-border,
		.spinner-grow {
			display: inline-block;
			width: var(--bs-spinner-width);
			height: var(--bs-spinner-height);
			vertical-align: var(--bs-spinner-vertical-align);
			border-radius: 50%;
			-webkit-animation: var(--bs-spinner-animation-speed) linear infinite var(--bs-spinner-animation-name);
			animation: var(--bs-spinner-animation-speed) linear infinite var(--bs-spinner-animation-name)
		}

		@-webkit-keyframes spinner-border {
			to {
				transform: rotate(360deg)
			}
		}

		@keyframes spinner-border {
			to {
				transform: rotate(360deg)
			}
		}

		.spinner-border {
			--bs-spinner-width: 2rem;
			--bs-spinner-height: 2rem;
			--bs-spinner-vertical-align: -0.125em;
			--bs-spinner-border-width: 0.25em;
			--bs-spinner-animation-speed: 0.75s;
			--bs-spinner-animation-name: spinner-border;
			border: var(--bs-spinner-border-width) solid currentcolor;
			border-right-color: transparent
		}

		.spinner-border-sm {
			--bs-spinner-width: 1rem;
			--bs-spinner-height: 1rem;
			--bs-spinner-border-width: 0.2em
		}

		@-webkit-keyframes spinner-grow {
			0% {
				transform: scale(0)
			}

			50% {
				opacity: 1;
				transform: none
			}
		}

		@keyframes spinner-grow {
			0% {
				transform: scale(0)
			}

			50% {
				opacity: 1;
				transform: none
			}
		}

		.spinner-grow {
			--bs-spinner-width: 2rem;
			--bs-spinner-height: 2rem;
			--bs-spinner-vertical-align: -0.125em;
			--bs-spinner-animation-speed: 0.75s;
			--bs-spinner-animation-name: spinner-grow;
			background-color: currentcolor;
			opacity: 0
		}

		.spinner-grow-sm {
			--bs-spinner-width: 1rem;
			--bs-spinner-height: 1rem
		}

		@media (prefers-reduced-motion:reduce) {

			.spinner-border,
			.spinner-grow {
				--bs-spinner-animation-speed: 1.5s
			}
		}

		.offcanvas,
		.offcanvas-lg,
		.offcanvas-md,
		.offcanvas-sm,
		.offcanvas-xl,
		.offcanvas-xxl {
			--bs-offcanvas-width: 400px;
			--bs-offcanvas-height: 30vh;
			--bs-offcanvas-padding-x: 1rem;
			--bs-offcanvas-padding-y: 1rem;
			--bs-offcanvas-color: ;
			--bs-offcanvas-bg: #fff;
			--bs-offcanvas-border-width: 1px;
			--bs-offcanvas-border-color: var(--bs-border-color-translucent);
			--bs-offcanvas-box-shadow: 0 0.125rem 0.25rem rgba(0, 0, 0, 0.075)
		}

		@media (max-width:575.98px) {
			.offcanvas-sm {
				position: fixed;
				bottom: 0;
				z-index: 1045;
				display: flex;
				flex-direction: column;
				max-width: 100%;
				color: var(--bs-offcanvas-color);
				visibility: hidden;
				background-color: var(--bs-offcanvas-bg);
				background-clip: padding-box;
				outline: 0;
				transition: transform .3s ease-in-out
			}
		}

		@media (max-width:575.98px) and (prefers-reduced-motion:reduce) {
			.offcanvas-sm {
				transition: none
			}
		}

		@media (max-width:575.98px) {
			.offcanvas-sm.offcanvas-start {
				top: 0;
				left: 0;
				width: var(--bs-offcanvas-width);
				border-right: var(--bs-offcanvas-border-width) solid var(--bs-offcanvas-border-color);
				transform: translateX(-100%)
			}
		}

		@media (max-width:575.98px) {
			.offcanvas-sm.offcanvas-end {
				top: 0;
				right: 0;
				width: var(--bs-offcanvas-width);
				border-left: var(--bs-offcanvas-border-width) solid var(--bs-offcanvas-border-color);
				transform: translateX(100%)
			}
		}

		@media (max-width:575.98px) {
			.offcanvas-sm.offcanvas-top {
				top: 0;
				right: 0;
				left: 0;
				height: var(--bs-offcanvas-height);
				max-height: 100%;
				border-bottom: var(--bs-offcanvas-border-width) solid var(--bs-offcanvas-border-color);
				transform: translateY(-100%)
			}
		}

		@media (max-width:575.98px) {
			.offcanvas-sm.offcanvas-bottom {
				right: 0;
				left: 0;
				height: var(--bs-offcanvas-height);
				max-height: 100%;
				border-top: var(--bs-offcanvas-border-width) solid var(--bs-offcanvas-border-color);
				transform: translateY(100%)
			}
		}

		@media (max-width:575.98px) {

			.offcanvas-sm.show:not(.hiding),
			.offcanvas-sm.showing {
				transform: none
			}
		}

		@media (max-width:575.98px) {

			.offcanvas-sm.hiding,
			.offcanvas-sm.show,
			.offcanvas-sm.showing {
				visibility: visible
			}
		}

		@media (min-width:576px) {
			.offcanvas-sm {
				--bs-offcanvas-height: auto;
				--bs-offcanvas-border-width: 0;
				background-color: transparent !important
			}

			.offcanvas-sm .offcanvas-header {
				display: none
			}

			.offcanvas-sm .offcanvas-body {
				display: flex;
				flex-grow: 0;
				padding: 0;
				overflow-y: visible;
				background-color: transparent !important
			}
		}

		@media (max-width:767.98px) {
			.offcanvas-md {
				position: fixed;
				bottom: 0;
				z-index: 1045;
				display: flex;
				flex-direction: column;
				max-width: 100%;
				color: var(--bs-offcanvas-color);
				visibility: hidden;
				background-color: var(--bs-offcanvas-bg);
				background-clip: padding-box;
				outline: 0;
				transition: transform .3s ease-in-out
			}
		}

		@media (max-width:767.98px) and (prefers-reduced-motion:reduce) {
			.offcanvas-md {
				transition: none
			}
		}

		@media (max-width:767.98px) {
			.offcanvas-md.offcanvas-start {
				top: 0;
				left: 0;
				width: var(--bs-offcanvas-width);
				border-right: var(--bs-offcanvas-border-width) solid var(--bs-offcanvas-border-color);
				transform: translateX(-100%)
			}
		}

		@media (max-width:767.98px) {
			.offcanvas-md.offcanvas-end {
				top: 0;
				right: 0;
				width: var(--bs-offcanvas-width);
				border-left: var(--bs-offcanvas-border-width) solid var(--bs-offcanvas-border-color);
				transform: translateX(100%)
			}
		}

		@media (max-width:767.98px) {
			.offcanvas-md.offcanvas-top {
				top: 0;
				right: 0;
				left: 0;
				height: var(--bs-offcanvas-height);
				max-height: 100%;
				border-bottom: var(--bs-offcanvas-border-width) solid var(--bs-offcanvas-border-color);
				transform: translateY(-100%)
			}
		}

		@media (max-width:767.98px) {
			.offcanvas-md.offcanvas-bottom {
				right: 0;
				left: 0;
				height: var(--bs-offcanvas-height);
				max-height: 100%;
				border-top: var(--bs-offcanvas-border-width) solid var(--bs-offcanvas-border-color);
				transform: translateY(100%)
			}
		}

		@media (max-width:767.98px) {

			.offcanvas-md.show:not(.hiding),
			.offcanvas-md.showing {
				transform: none
			}
		}

		@media (max-width:767.98px) {

			.offcanvas-md.hiding,
			.offcanvas-md.show,
			.offcanvas-md.showing {
				visibility: visible
			}
		}

		@media (min-width:768px) {
			.offcanvas-md {
				--bs-offcanvas-height: auto;
				--bs-offcanvas-border-width: 0;
				background-color: transparent !important
			}

			.offcanvas-md .offcanvas-header {
				display: none
			}

			.offcanvas-md .offcanvas-body {
				display: flex;
				flex-grow: 0;
				padding: 0;
				overflow-y: visible;
				background-color: transparent !important
			}
		}

		@media (max-width:991.98px) {
			.offcanvas-lg {
				position: fixed;
				bottom: 0;
				z-index: 1045;
				display: flex;
				flex-direction: column;
				max-width: 100%;
				color: var(--bs-offcanvas-color);
				visibility: hidden;
				background-color: var(--bs-offcanvas-bg);
				background-clip: padding-box;
				outline: 0;
				transition: transform .3s ease-in-out
			}
		}

		@media (max-width:991.98px) and (prefers-reduced-motion:reduce) {
			.offcanvas-lg {
				transition: none
			}
		}

		@media (max-width:991.98px) {
			.offcanvas-lg.offcanvas-start {
				top: 0;
				left: 0;
				width: var(--bs-offcanvas-width);
				border-right: var(--bs-offcanvas-border-width) solid var(--bs-offcanvas-border-color);
				transform: translateX(-100%)
			}
		}

		@media (max-width:991.98px) {
			.offcanvas-lg.offcanvas-end {
				top: 0;
				right: 0;
				width: var(--bs-offcanvas-width);
				border-left: var(--bs-offcanvas-border-width) solid var(--bs-offcanvas-border-color);
				transform: translateX(100%)
			}
		}

		@media (max-width:991.98px) {
			.offcanvas-lg.offcanvas-top {
				top: 0;
				right: 0;
				left: 0;
				height: var(--bs-offcanvas-height);
				max-height: 100%;
				border-bottom: var(--bs-offcanvas-border-width) solid var(--bs-offcanvas-border-color);
				transform: translateY(-100%)
			}
		}

		@media (max-width:991.98px) {
			.offcanvas-lg.offcanvas-bottom {
				right: 0;
				left: 0;
				height: var(--bs-offcanvas-height);
				max-height: 100%;
				border-top: var(--bs-offcanvas-border-width) solid var(--bs-offcanvas-border-color);
				transform: translateY(100%)
			}
		}

		@media (max-width:991.98px) {

			.offcanvas-lg.show:not(.hiding),
			.offcanvas-lg.showing {
				transform: none
			}
		}

		@media (max-width:991.98px) {

			.offcanvas-lg.hiding,
			.offcanvas-lg.show,
			.offcanvas-lg.showing {
				visibility: visible
			}
		}

		@media (min-width:992px) {
			.offcanvas-lg {
				--bs-offcanvas-height: auto;
				--bs-offcanvas-border-width: 0;
				background-color: transparent !important
			}

			.offcanvas-lg .offcanvas-header {
				display: none
			}

			.offcanvas-lg .offcanvas-body {
				display: flex;
				flex-grow: 0;
				padding: 0;
				overflow-y: visible;
				background-color: transparent !important
			}
		}

		@media (max-width:1199.98px) {
			.offcanvas-xl {
				position: fixed;
				bottom: 0;
				z-index: 1045;
				display: flex;
				flex-direction: column;
				max-width: 100%;
				color: var(--bs-offcanvas-color);
				visibility: hidden;
				background-color: var(--bs-offcanvas-bg);
				background-clip: padding-box;
				outline: 0;
				transition: transform .3s ease-in-out
			}
		}

		@media (max-width:1199.98px) and (prefers-reduced-motion:reduce) {
			.offcanvas-xl {
				transition: none
			}
		}

		@media (max-width:1199.98px) {
			.offcanvas-xl.offcanvas-start {
				top: 0;
				left: 0;
				width: var(--bs-offcanvas-width);
				border-right: var(--bs-offcanvas-border-width) solid var(--bs-offcanvas-border-color);
				transform: translateX(-100%)
			}
		}

		@media (max-width:1199.98px) {
			.offcanvas-xl.offcanvas-end {
				top: 0;
				right: 0;
				width: var(--bs-offcanvas-width);
				border-left: var(--bs-offcanvas-border-width) solid var(--bs-offcanvas-border-color);
				transform: translateX(100%)
			}
		}

		@media (max-width:1199.98px) {
			.offcanvas-xl.offcanvas-top {
				top: 0;
				right: 0;
				left: 0;
				height: var(--bs-offcanvas-height);
				max-height: 100%;
				border-bottom: var(--bs-offcanvas-border-width) solid var(--bs-offcanvas-border-color);
				transform: translateY(-100%)
			}
		}

		@media (max-width:1199.98px) {
			.offcanvas-xl.offcanvas-bottom {
				right: 0;
				left: 0;
				height: var(--bs-offcanvas-height);
				max-height: 100%;
				border-top: var(--bs-offcanvas-border-width) solid var(--bs-offcanvas-border-color);
				transform: translateY(100%)
			}
		}

		@media (max-width:1199.98px) {

			.offcanvas-xl.show:not(.hiding),
			.offcanvas-xl.showing {
				transform: none
			}
		}

		@media (max-width:1199.98px) {

			.offcanvas-xl.hiding,
			.offcanvas-xl.show,
			.offcanvas-xl.showing {
				visibility: visible
			}
		}

		@media (min-width:1200px) {
			.offcanvas-xl {
				--bs-offcanvas-height: auto;
				--bs-offcanvas-border-width: 0;
				background-color: transparent !important
			}

			.offcanvas-xl .offcanvas-header {
				display: none
			}

			.offcanvas-xl .offcanvas-body {
				display: flex;
				flex-grow: 0;
				padding: 0;
				overflow-y: visible;
				background-color: transparent !important
			}
		}

		@media (max-width:1399.98px) {
			.offcanvas-xxl {
				position: fixed;
				bottom: 0;
				z-index: 1045;
				display: flex;
				flex-direction: column;
				max-width: 100%;
				color: var(--bs-offcanvas-color);
				visibility: hidden;
				background-color: var(--bs-offcanvas-bg);
				background-clip: padding-box;
				outline: 0;
				transition: transform .3s ease-in-out
			}
		}

		@media (max-width:1399.98px) and (prefers-reduced-motion:reduce) {
			.offcanvas-xxl {
				transition: none
			}
		}

		@media (max-width:1399.98px) {
			.offcanvas-xxl.offcanvas-start {
				top: 0;
				left: 0;
				width: var(--bs-offcanvas-width);
				border-right: var(--bs-offcanvas-border-width) solid var(--bs-offcanvas-border-color);
				transform: translateX(-100%)
			}
		}

		@media (max-width:1399.98px) {
			.offcanvas-xxl.offcanvas-end {
				top: 0;
				right: 0;
				width: var(--bs-offcanvas-width);
				border-left: var(--bs-offcanvas-border-width) solid var(--bs-offcanvas-border-color);
				transform: translateX(100%)
			}
		}

		@media (max-width:1399.98px) {
			.offcanvas-xxl.offcanvas-top {
				top: 0;
				right: 0;
				left: 0;
				height: var(--bs-offcanvas-height);
				max-height: 100%;
				border-bottom: var(--bs-offcanvas-border-width) solid var(--bs-offcanvas-border-color);
				transform: translateY(-100%)
			}
		}

		@media (max-width:1399.98px) {
			.offcanvas-xxl.offcanvas-bottom {
				right: 0;
				left: 0;
				height: var(--bs-offcanvas-height);
				max-height: 100%;
				border-top: var(--bs-offcanvas-border-width) solid var(--bs-offcanvas-border-color);
				transform: translateY(100%)
			}
		}

		@media (max-width:1399.98px) {

			.offcanvas-xxl.show:not(.hiding),
			.offcanvas-xxl.showing {
				transform: none
			}
		}

		@media (max-width:1399.98px) {

			.offcanvas-xxl.hiding,
			.offcanvas-xxl.show,
			.offcanvas-xxl.showing {
				visibility: visible
			}
		}

		@media (min-width:1400px) {
			.offcanvas-xxl {
				--bs-offcanvas-height: auto;
				--bs-offcanvas-border-width: 0;
				background-color: transparent !important
			}

			.offcanvas-xxl .offcanvas-header {
				display: none
			}

			.offcanvas-xxl .offcanvas-body {
				display: flex;
				flex-grow: 0;
				padding: 0;
				overflow-y: visible;
				background-color: transparent !important
			}
		}

		.offcanvas {
			position: fixed;
			bottom: 0;
			z-index: 1045;
			display: flex;
			flex-direction: column;
			max-width: 100%;
			color: var(--bs-offcanvas-color);
			visibility: hidden;
			background-color: var(--bs-offcanvas-bg);
			background-clip: padding-box;
			outline: 0;
			transition: transform .3s ease-in-out
		}

		@media (prefers-reduced-motion:reduce) {
			.offcanvas {
				transition: none
			}
		}

		.offcanvas.offcanvas-start {
			top: 0;
			left: 0;
			width: var(--bs-offcanvas-width);
			border-right: var(--bs-offcanvas-border-width) solid var(--bs-offcanvas-border-color);
			transform: translateX(-100%)
		}

		.offcanvas.offcanvas-end {
			top: 0;
			right: 0;
			width: var(--bs-offcanvas-width);
			border-left: var(--bs-offcanvas-border-width) solid var(--bs-offcanvas-border-color);
			transform: translateX(100%)
		}

		.offcanvas.offcanvas-top {
			top: 0;
			right: 0;
			left: 0;
			height: var(--bs-offcanvas-height);
			max-height: 100%;
			border-bottom: var(--bs-offcanvas-border-width) solid var(--bs-offcanvas-border-color);
			transform: translateY(-100%)
		}

		.offcanvas.offcanvas-bottom {
			right: 0;
			left: 0;
			height: var(--bs-offcanvas-height);
			max-height: 100%;
			border-top: var(--bs-offcanvas-border-width) solid var(--bs-offcanvas-border-color);
			transform: translateY(100%)
		}

		.offcanvas.show:not(.hiding),
		.offcanvas.showing {
			transform: none
		}

		.offcanvas.hiding,
		.offcanvas.show,
		.offcanvas.showing {
			visibility: visible
		}

		.offcanvas-backdrop {
			position: fixed;
			top: 0;
			left: 0;
			z-index: 1040;
			width: 100vw;
			height: 100vh;
			background-color: #000
		}

		.offcanvas-backdrop.fade {
			opacity: 0
		}

		.offcanvas-backdrop.show {
			opacity: .5
		}

		.offcanvas-header {
			display: flex;
			align-items: center;
			justify-content: space-between;
			padding: var(--bs-offcanvas-padding-y) var(--bs-offcanvas-padding-x)
		}

		.offcanvas-header .btn-close {
			padding: calc(var(--bs-offcanvas-padding-y) * .5) calc(var(--bs-offcanvas-padding-x) * .5);
			margin-top: calc(var(--bs-offcanvas-padding-y) * -.5);
			margin-right: calc(var(--bs-offcanvas-padding-x) * -.5);
			margin-bottom: calc(var(--bs-offcanvas-padding-y) * -.5)
		}

		.offcanvas-title {
			margin-bottom: 0;
			line-height: 1.5
		}

		.offcanvas-body {
			flex-grow: 1;
			padding: var(--bs-offcanvas-padding-y) var(--bs-offcanvas-padding-x);
			overflow-y: auto
		}

		.placeholder {
			display: inline-block;
			min-height: 1em;
			vertical-align: middle;
			cursor: wait;
			background-color: currentcolor;
			opacity: .5
		}

		.placeholder.btn::before {
			display: inline-block;
			content: ""
		}

		.placeholder-xs {
			min-height: .6em
		}

		.placeholder-sm {
			min-height: .8em
		}

		.placeholder-lg {
			min-height: 1.2em
		}

		.placeholder-glow .placeholder {
			-webkit-animation: placeholder-glow 2s ease-in-out infinite;
			animation: placeholder-glow 2s ease-in-out infinite
		}

		@-webkit-keyframes placeholder-glow {
			50% {
				opacity: .2
			}
		}

		@keyframes placeholder-glow {
			50% {
				opacity: .2
			}
		}

		.placeholder-wave {
			-webkit-mask-image: linear-gradient(130deg, #000 55%, rgba(0, 0, 0, 0.8) 75%, #000 95%);
			mask-image: linear-gradient(130deg, #000 55%, rgba(0, 0, 0, 0.8) 75%, #000 95%);
			-webkit-mask-size: 200% 100%;
			mask-size: 200% 100%;
			-webkit-animation: placeholder-wave 2s linear infinite;
			animation: placeholder-wave 2s linear infinite
		}

		@-webkit-keyframes placeholder-wave {
			100% {
				-webkit-mask-position: -200% 0%;
				mask-position: -200% 0%
			}
		}

		@keyframes placeholder-wave {
			100% {
				-webkit-mask-position: -200% 0%;
				mask-position: -200% 0%
			}
		}

		.clearfix::after {
			display: block;
			clear: both;
			content: ""
		}

		.text-bg-primary {
			color: #fff !important;
			background-color: RGBA(13, 110, 253, var(--bs-bg-opacity, 1)) !important
		}

		.text-bg-secondary {
			color: #fff !important;
			background-color: RGBA(108, 117, 125, var(--bs-bg-opacity, 1)) !important
		}

		.text-bg-success {
			color: #fff !important;
			background-color: RGBA(25, 135, 84, var(--bs-bg-opacity, 1)) !important
		}

		.text-bg-info {
			color: #000 !important;
			background-color: RGBA(13, 202, 240, var(--bs-bg-opacity, 1)) !important
		}

		.text-bg-warning {
			color: #000 !important;
			background-color: RGBA(255, 193, 7, var(--bs-bg-opacity, 1)) !important
		}

		.text-bg-danger {
			color: #fff !important;
			background-color: RGBA(220, 53, 69, var(--bs-bg-opacity, 1)) !important
		}

		.text-bg-light {
			color: #000 !important;
			background-color: RGBA(248, 249, 250, var(--bs-bg-opacity, 1)) !important
		}

		.text-bg-dark {
			color: #fff !important;
			background-color: RGBA(33, 37, 41, var(--bs-bg-opacity, 1)) !important
		}

		.link-primary {
			color: #0d6efd !important
		}

		.link-primary:focus,
		.link-primary:hover {
			color: #0a58ca !important
		}

		.link-secondary {
			color: #6c757d !important
		}

		.link-secondary:focus,
		.link-secondary:hover {
			color: #565e64 !important
		}

		.link-success {
			color: #198754 !important
		}

		.link-success:focus,
		.link-success:hover {
			color: #146c43 !important
		}

		.link-info {
			color: #0dcaf0 !important
		}

		.link-info:focus,
		.link-info:hover {
			color: #3dd5f3 !important
		}

		.link-warning {
			color: #ffc107 !important
		}

		.link-warning:focus,
		.link-warning:hover {
			color: #ffcd39 !important
		}

		.link-danger {
			color: #dc3545 !important
		}

		.link-danger:focus,
		.link-danger:hover {
			color: #b02a37 !important
		}

		.link-light {
			color: #f8f9fa !important
		}

		.link-light:focus,
		.link-light:hover {
			color: #f9fafb !important
		}

		.link-dark {
			color: #212529 !important
		}

		.link-dark:focus,
		.link-dark:hover {
			color: #1a1e21 !important
		}

		.ratio {
			position: relative;
			width: 100%
		}

		.ratio::before {
			display: block;
			padding-top: var(--bs-aspect-ratio);
			content: ""
		}

		.ratio>* {
			position: absolute;
			top: 0;
			left: 0;
			width: 100%;
			height: 100%
		}

		.ratio-1x1 {
			--bs-aspect-ratio: 100%
		}

		.ratio-4x3 {
			--bs-aspect-ratio: 75%
		}

		.ratio-16x9 {
			--bs-aspect-ratio: 56.25%
		}

		.ratio-21x9 {
			--bs-aspect-ratio: 42.8571428571%
		}

		.fixed-top {
			position: fixed;
			top: 0;
			right: 0;
			left: 0;
			z-index: 1030
		}

		.fixed-bottom {
			position: fixed;
			right: 0;
			bottom: 0;
			left: 0;
			z-index: 1030
		}

		.sticky-top {
			position: -webkit-sticky;
			position: sticky;
			top: 0;
			z-index: 1020
		}

		.sticky-bottom {
			position: -webkit-sticky;
			position: sticky;
			bottom: 0;
			z-index: 1020
		}

		@media (min-width:576px) {
			.sticky-sm-top {
				position: -webkit-sticky;
				position: sticky;
				top: 0;
				z-index: 1020
			}

			.sticky-sm-bottom {
				position: -webkit-sticky;
				position: sticky;
				bottom: 0;
				z-index: 1020
			}
		}

		@media (min-width:768px) {
			.sticky-md-top {
				position: -webkit-sticky;
				position: sticky;
				top: 0;
				z-index: 1020
			}

			.sticky-md-bottom {
				position: -webkit-sticky;
				position: sticky;
				bottom: 0;
				z-index: 1020
			}
		}

		@media (min-width:992px) {
			.sticky-lg-top {
				position: -webkit-sticky;
				position: sticky;
				top: 0;
				z-index: 1020
			}

			.sticky-lg-bottom {
				position: -webkit-sticky;
				position: sticky;
				bottom: 0;
				z-index: 1020
			}
		}

		@media (min-width:1200px) {
			.sticky-xl-top {
				position: -webkit-sticky;
				position: sticky;
				top: 0;
				z-index: 1020
			}

			.sticky-xl-bottom {
				position: -webkit-sticky;
				position: sticky;
				bottom: 0;
				z-index: 1020
			}
		}

		@media (min-width:1400px) {
			.sticky-xxl-top {
				position: -webkit-sticky;
				position: sticky;
				top: 0;
				z-index: 1020
			}

			.sticky-xxl-bottom {
				position: -webkit-sticky;
				position: sticky;
				bottom: 0;
				z-index: 1020
			}
		}

		.hstack {
			display: flex;
			flex-direction: row;
			align-items: center;
			align-self: stretch
		}

		.vstack {
			display: flex;
			flex: 1 1 auto;
			flex-direction: column;
			align-self: stretch
		}

		.visually-hidden,
		.visually-hidden-focusable:not(:focus):not(:focus-within) {
			position: absolute !important;
			width: 1px !important;
			height: 1px !important;
			padding: 0 !important;
			margin: -1px !important;
			overflow: hidden !important;
			clip: rect(0, 0, 0, 0) !important;
			white-space: nowrap !important;
			border: 0 !important
		}

		.stretched-link::after {
			position: absolute;
			top: 0;
			right: 0;
			bottom: 0;
			left: 0;
			z-index: 1;
			content: ""
		}

		.text-truncate {
			overflow: hidden;
			text-overflow: ellipsis;
			white-space: nowrap
		}

		.vr {
			display: inline-block;
			align-self: stretch;
			width: 1px;
			min-height: 1em;
			background-color: currentcolor;
			opacity: .25
		}

		.align-baseline {
			vertical-align: baseline !important
		}

		.align-top {
			vertical-align: top !important
		}

		.align-middle {
			vertical-align: middle !important
		}

		.align-bottom {
			vertical-align: bottom !important
		}

		.align-text-bottom {
			vertical-align: text-bottom !important
		}

		.align-text-top {
			vertical-align: text-top !important
		}

		.float-start {
			float: left !important
		}

		.float-end {
			float: right !important
		}

		.float-none {
			float: none !important
		}

		.opacity-0 {
			opacity: 0 !important
		}

		.opacity-25 {
			opacity: .25 !important
		}

		.opacity-50 {
			opacity: .5 !important
		}

		.opacity-75 {
			opacity: .75 !important
		}

		.opacity-100 {
			opacity: 1 !important
		}

		.overflow-auto {
			overflow: auto !important
		}

		.overflow-hidden {
			overflow: hidden !important
		}

		.overflow-visible {
			overflow: visible !important
		}

		.overflow-scroll {
			overflow: scroll !important
		}

		.d-inline {
			display: inline !important
		}

		.d-inline-block {
			display: inline-block !important
		}

		.d-block {
			display: block !important
		}

		.d-grid {
			display: grid !important
		}

		.d-table {
			display: table !important
		}

		.d-table-row {
			display: table-row !important
		}

		.d-table-cell {
			display: table-cell !important
		}

		.d-flex {
			display: flex !important
		}

		.d-inline-flex {
			display: inline-flex !important
		}

		.d-none {
			display: none !important
		}

		.shadow {
			box-shadow: 0 .5rem 1rem rgba(0, 0, 0, .15) !important
		}

		.shadow-sm {
			box-shadow: 0 .125rem .25rem rgba(0, 0, 0, .075) !important
		}

		.shadow-lg {
			box-shadow: 0 1rem 3rem rgba(0, 0, 0, .175) !important
		}

		.shadow-none {
			box-shadow: none !important
		}

		.position-static {
			position: static !important
		}

		.position-relative {
			position: relative !important
		}

		.position-absolute {
			position: absolute !important
		}

		.position-fixed {
			position: fixed !important
		}

		.position-sticky {
			position: -webkit-sticky !important;
			position: sticky !important
		}

		.top-0 {
			top: 0 !important
		}

		.top-50 {
			top: 50% !important
		}

		.top-100 {
			top: 100% !important
		}

		.bottom-0 {
			bottom: 0 !important
		}

		.bottom-50 {
			bottom: 50% !important
		}

		.bottom-100 {
			bottom: 100% !important
		}

		.start-0 {
			left: 0 !important
		}

		.start-50 {
			left: 50% !important
		}

		.start-100 {
			left: 100% !important
		}

		.end-0 {
			right: 0 !important
		}

		.end-50 {
			right: 50% !important
		}

		.end-100 {
			right: 100% !important
		}

		.translate-middle {
			transform: translate(-50%, -50%) !important
		}

		.translate-middle-x {
			transform: translateX(-50%) !important
		}

		.translate-middle-y {
			transform: translateY(-50%) !important
		}

		.border {
			border: var(--bs-border-width) var(--bs-border-style) var(--bs-border-color) !important
		}

		.border-0 {
			border: 0 !important
		}

		.border-top {
			border-top: var(--bs-border-width) var(--bs-border-style) var(--bs-border-color) !important
		}

		.border-top-0 {
			border-top: 0 !important
		}

		.border-end {
			border-right: var(--bs-border-width) var(--bs-border-style) var(--bs-border-color) !important
		}

		.border-end-0 {
			border-right: 0 !important
		}

		.border-bottom {
			border-bottom: var(--bs-border-width) var(--bs-border-style) var(--bs-border-color) !important
		}

		.border-bottom-0 {
			border-bottom: 0 !important
		}

		.border-start {
			border-left: var(--bs-border-width) var(--bs-border-style) var(--bs-border-color) !important
		}

		.border-start-0 {
			border-left: 0 !important
		}

		.border-primary {
			--bs-border-opacity: 1;
			border-color: rgba(var(--bs-primary-rgb), var(--bs-border-opacity)) !important
		}

		.border-secondary {
			--bs-border-opacity: 1;
			border-color: rgba(var(--bs-secondary-rgb), var(--bs-border-opacity)) !important
		}

		.border-success {
			--bs-border-opacity: 1;
			border-color: rgba(var(--bs-success-rgb), var(--bs-border-opacity)) !important
		}

		.border-info {
			--bs-border-opacity: 1;
			border-color: rgba(var(--bs-info-rgb), var(--bs-border-opacity)) !important
		}

		.border-warning {
			--bs-border-opacity: 1;
			border-color: rgba(var(--bs-warning-rgb), var(--bs-border-opacity)) !important
		}

		.border-danger {
			--bs-border-opacity: 1;
			border-color: rgba(var(--bs-danger-rgb), var(--bs-border-opacity)) !important
		}

		.border-light {
			--bs-border-opacity: 1;
			border-color: rgba(var(--bs-light-rgb), var(--bs-border-opacity)) !important
		}

		.border-dark {
			--bs-border-opacity: 1;
			border-color: rgba(var(--bs-dark-rgb), var(--bs-border-opacity)) !important
		}

		.border-white {
			--bs-border-opacity: 1;
			border-color: rgba(var(--bs-white-rgb), var(--bs-border-opacity)) !important
		}

		.border-1 {
			--bs-border-width: 1px
		}

		.border-2 {
			--bs-border-width: 2px
		}

		.border-3 {
			--bs-border-width: 3px
		}

		.border-4 {
			--bs-border-width: 4px
		}

		.border-5 {
			--bs-border-width: 5px
		}

		.border-opacity-10 {
			--bs-border-opacity: 0.1
		}

		.border-opacity-25 {
			--bs-border-opacity: 0.25
		}

		.border-opacity-50 {
			--bs-border-opacity: 0.5
		}

		.border-opacity-75 {
			--bs-border-opacity: 0.75
		}

		.border-opacity-100 {
			--bs-border-opacity: 1
		}

		.w-25 {
			width: 25% !important
		}

		.w-50 {
			width: 50% !important
		}

		.w-75 {
			width: 75% !important
		}

		.w-100 {
			width: 100% !important
		}

		.w-auto {
			width: auto !important
		}

		.mw-100 {
			max-width: 100% !important
		}

		.vw-100 {
			width: 100vw !important
		}

		.min-vw-100 {
			min-width: 100vw !important
		}

		.h-25 {
			height: 25% !important
		}

		.h-50 {
			height: 50% !important
		}

		.h-75 {
			height: 75% !important
		}

		.h-100 {
			height: 100% !important
		}

		.h-auto {
			height: auto !important
		}

		.mh-100 {
			max-height: 100% !important
		}

		.vh-100 {
			height: 100vh !important
		}

		.min-vh-100 {
			min-height: 100vh !important
		}

		.flex-fill {
			flex: 1 1 auto !important
		}

		.flex-row {
			flex-direction: row !important
		}

		.flex-column {
			flex-direction: column !important
		}

		.flex-row-reverse {
			flex-direction: row-reverse !important
		}

		.flex-column-reverse {
			flex-direction: column-reverse !important
		}

		.flex-grow-0 {
			flex-grow: 0 !important
		}

		.flex-grow-1 {
			flex-grow: 1 !important
		}

		.flex-shrink-0 {
			flex-shrink: 0 !important
		}

		.flex-shrink-1 {
			flex-shrink: 1 !important
		}

		.flex-wrap {
			flex-wrap: wrap !important
		}

		.flex-nowrap {
			flex-wrap: nowrap !important
		}

		.flex-wrap-reverse {
			flex-wrap: wrap-reverse !important
		}

		.justify-content-start {
			justify-content: flex-start !important
		}

		.justify-content-end {
			justify-content: flex-end !important
		}

		.justify-content-center {
			justify-content: center !important
		}

		.justify-content-between {
			justify-content: space-between !important
		}

		.justify-content-around {
			justify-content: space-around !important
		}

		.justify-content-evenly {
			justify-content: space-evenly !important
		}

		.align-items-start {
			align-items: flex-start !important
		}

		.align-items-end {
			align-items: flex-end !important
		}

		.align-items-center {
			align-items: center !important
		}

		.align-items-baseline {
			align-items: baseline !important
		}

		.align-items-stretch {
			align-items: stretch !important
		}

		.align-content-start {
			align-content: flex-start !important
		}

		.align-content-end {
			align-content: flex-end !important
		}

		.align-content-center {
			align-content: center !important
		}

		.align-content-between {
			align-content: space-between !important
		}

		.align-content-around {
			align-content: space-around !important
		}

		.align-content-stretch {
			align-content: stretch !important
		}

		.align-self-auto {
			align-self: auto !important
		}

		.align-self-start {
			align-self: flex-start !important
		}

		.align-self-end {
			align-self: flex-end !important
		}

		.align-self-center {
			align-self: center !important
		}

		.align-self-baseline {
			align-self: baseline !important
		}

		.align-self-stretch {
			align-self: stretch !important
		}

		.order-first {
			order: -1 !important
		}

		.order-0 {
			order: 0 !important
		}

		.order-1 {
			order: 1 !important
		}

		.order-2 {
			order: 2 !important
		}

		.order-3 {
			order: 3 !important
		}

		.order-4 {
			order: 4 !important
		}

		.order-5 {
			order: 5 !important
		}

		.order-last {
			order: 6 !important
		}

		.m-0 {
			margin: 0 !important
		}

		.m-1 {
			margin: .25rem !important
		}

		.m-2 {
			margin: .5rem !important
		}

		.m-3 {
			margin: 1rem !important
		}

		.m-4 {
			margin: 1.5rem !important
		}

		.m-5 {
			margin: 3rem !important
		}

		.m-auto {
			margin: auto !important
		}

		.mx-0 {
			margin-right: 0 !important;
			margin-left: 0 !important
		}

		.mx-1 {
			margin-right: .25rem !important;
			margin-left: .25rem !important
		}

		.mx-2 {
			margin-right: .5rem !important;
			margin-left: .5rem !important
		}

		.mx-3 {
			margin-right: 1rem !important;
			margin-left: 1rem !important
		}

		.mx-4 {
			margin-right: 1.5rem !important;
			margin-left: 1.5rem !important
		}

		.mx-5 {
			margin-right: 3rem !important;
			margin-left: 3rem !important
		}

		.mx-auto {
			margin-right: auto !important;
			margin-left: auto !important
		}

		.my-0 {
			margin-top: 0 !important;
			margin-bottom: 0 !important
		}

		.my-1 {
			margin-top: .25rem !important;
			margin-bottom: .25rem !important
		}

		.my-2 {
			margin-top: .5rem !important;
			margin-bottom: .5rem !important
		}

		.my-3 {
			margin-top: 1rem !important;
			margin-bottom: 1rem !important
		}

		.my-4 {
			margin-top: 1.5rem !important;
			margin-bottom: 1.5rem !important
		}

		.my-5 {
			margin-top: 3rem !important;
			margin-bottom: 3rem !important
		}

		.my-auto {
			margin-top: auto !important;
			margin-bottom: auto !important
		}

		.mt-0 {
			margin-top: 0 !important
		}

		.mt-1 {
			margin-top: .25rem !important
		}

		.mt-2 {
			margin-top: .5rem !important
		}

		.mt-3 {
			margin-top: 1rem !important
		}

		.mt-4 {
			margin-top: 1.5rem !important
		}

		.mt-5 {
			margin-top: 3rem !important
		}

		.mt-auto {
			margin-top: auto !important
		}

		.me-0 {
			margin-right: 0 !important
		}

		.me-1 {
			margin-right: .25rem !important
		}

		.me-2 {
			margin-right: .5rem !important
		}

		.me-3 {
			margin-right: 1rem !important
		}

		.me-4 {
			margin-right: 1.5rem !important
		}

		.me-5 {
			margin-right: 3rem !important
		}

		.me-auto {
			margin-right: auto !important
		}

		.mb-0 {
			margin-bottom: 0 !important
		}

		.mb-1 {
			margin-bottom: .25rem !important
		}

		.mb-2 {
			margin-bottom: .5rem !important
		}

		.mb-3 {
			margin-bottom: 1rem !important
		}

		.mb-4 {
			margin-bottom: 1.5rem !important
		}

		.mb-5 {
			margin-bottom: 3rem !important
		}

		.mb-auto {
			margin-bottom: auto !important
		}

		.ms-0 {
			margin-left: 0 !important
		}

		.ms-1 {
			margin-left: .25rem !important
		}

		.ms-2 {
			margin-left: .5rem !important
		}

		.ms-3 {
			margin-left: 1rem !important
		}

		.ms-4 {
			margin-left: 1.5rem !important
		}

		.ms-5 {
			margin-left: 3rem !important
		}

		.ms-auto {
			margin-left: auto !important
		}

		.p-0 {
			padding: 0 !important
		}

		.p-1 {
			padding: .25rem !important
		}

		.p-2 {
			padding: .5rem !important
		}

		.p-3 {
			padding: 1rem !important
		}

		.p-4 {
			padding: 1.5rem !important
		}

		.p-5 {
			padding: 3rem !important
		}

		.px-0 {
			padding-right: 0 !important;
			padding-left: 0 !important
		}

		.px-1 {
			padding-right: .25rem !important;
			padding-left: .25rem !important
		}

		.px-2 {
			padding-right: .5rem !important;
			padding-left: .5rem !important
		}

		.px-3 {
			padding-right: 1rem !important;
			padding-left: 1rem !important
		}

		.px-4 {
			padding-right: 1.5rem !important;
			padding-left: 1.5rem !important
		}

		.px-5 {
			padding-right: 3rem !important;
			padding-left: 3rem !important
		}

		.py-0 {
			padding-top: 0 !important;
			padding-bottom: 0 !important
		}

		.py-1 {
			padding-top: .25rem !important;
			padding-bottom: .25rem !important
		}

		.py-2 {
			padding-top: .5rem !important;
			padding-bottom: .5rem !important
		}

		.py-3 {
			padding-top: 1rem !important;
			padding-bottom: 1rem !important
		}

		.py-4 {
			padding-top: 1.5rem !important;
			padding-bottom: 1.5rem !important
		}

		.py-5 {
			padding-top: 3rem !important;
			padding-bottom: 3rem !important
		}

		.pt-0 {
			padding-top: 0 !important
		}

		.pt-1 {
			padding-top: .25rem !important
		}

		.pt-2 {
			padding-top: .5rem !important
		}

		.pt-3 {
			padding-top: 1rem !important
		}

		.pt-4 {
			padding-top: 1.5rem !important
		}

		.pt-5 {
			padding-top: 3rem !important
		}

		.pe-0 {
			padding-right: 0 !important
		}

		.pe-1 {
			padding-right: .25rem !important
		}

		.pe-2 {
			padding-right: .5rem !important
		}

		.pe-3 {
			padding-right: 1rem !important
		}

		.pe-4 {
			padding-right: 1.5rem !important
		}

		.pe-5 {
			padding-right: 3rem !important
		}

		.pb-0 {
			padding-bottom: 0 !important
		}

		.pb-1 {
			padding-bottom: .25rem !important
		}

		.pb-2 {
			padding-bottom: .5rem !important
		}

		.pb-3 {
			padding-bottom: 1rem !important
		}

		.pb-4 {
			padding-bottom: 1.5rem !important
		}

		.pb-5 {
			padding-bottom: 3rem !important
		}

		.ps-0 {
			padding-left: 0 !important
		}

		.ps-1 {
			padding-left: .25rem !important
		}

		.ps-2 {
			padding-left: .5rem !important
		}

		.ps-3 {
			padding-left: 1rem !important
		}

		.ps-4 {
			padding-left: 1.5rem !important
		}

		.ps-5 {
			padding-left: 3rem !important
		}

		.gap-0 {
			gap: 0 !important
		}

		.gap-1 {
			gap: .25rem !important
		}

		.gap-2 {
			gap: .5rem !important
		}

		.gap-3 {
			gap: 1rem !important
		}

		.gap-4 {
			gap: 1.5rem !important
		}

		.gap-5 {
			gap: 3rem !important
		}

		.font-monospace {
			font-family: var(--bs-font-monospace) !important
		}

		.fs-1 {
			font-size: calc(1.375rem + 1.5vw) !important
		}

		.fs-2 {
			font-size: calc(1.325rem + .9vw) !important
		}

		.fs-3 {
			font-size: calc(1.3rem + .6vw) !important
		}

		.fs-4 {
			font-size: calc(1.275rem + .3vw) !important
		}

		.fs-5 {
			font-size: 1.25rem !important
		}

		.fs-6 {
			font-size: 1rem !important
		}

		.fst-italic {
			font-style: italic !important
		}

		.fst-normal {
			font-style: normal !important
		}

		.fw-light {
			font-weight: 300 !important
		}

		.fw-lighter {
			font-weight: lighter !important
		}

		.fw-normal {
			font-weight: 400 !important
		}

		.fw-bold {
			font-weight: 700 !important
		}

		.fw-semibold {
			font-weight: 600 !important
		}

		.fw-bolder {
			font-weight: bolder !important
		}

		.lh-1 {
			line-height: 1 !important
		}

		.lh-sm {
			line-height: 1.25 !important
		}

		.lh-base {
			line-height: 1.5 !important
		}

		.lh-lg {
			line-height: 2 !important
		}

		.text-start {
			text-align: left !important
		}

		.text-end {
			text-align: right !important
		}

		.text-center {
			text-align: center !important
		}

		.text-decoration-none {
			text-decoration: none !important
		}

		.text-decoration-underline {
			text-decoration: underline !important
		}

		.text-decoration-line-through {
			text-decoration: line-through !important
		}

		.text-lowercase {
			text-transform: lowercase !important
		}

		.text-uppercase {
			text-transform: uppercase !important
		}

		.text-capitalize {
			text-transform: capitalize !important
		}

		.text-wrap {
			white-space: normal !important
		}

		.text-nowrap {
			white-space: nowrap !important
		}

		.text-break {
			word-wrap: break-word !important;
			word-break: break-word !important
		}

		.text-primary {
			--bs-text-opacity: 1;
			color: rgba(var(--bs-primary-rgb), var(--bs-text-opacity)) !important
		}

		.text-secondary {
			--bs-text-opacity: 1;
			color: rgba(var(--bs-secondary-rgb), var(--bs-text-opacity)) !important
		}

		.text-success {
			--bs-text-opacity: 1;
			color: rgba(var(--bs-success-rgb), var(--bs-text-opacity)) !important
		}

		.text-info {
			--bs-text-opacity: 1;
			color: rgba(var(--bs-info-rgb), var(--bs-text-opacity)) !important
		}

		.text-warning {
			--bs-text-opacity: 1;
			color: rgba(var(--bs-warning-rgb), var(--bs-text-opacity)) !important
		}

		.text-danger {
			--bs-text-opacity: 1;
			color: rgba(var(--bs-danger-rgb), var(--bs-text-opacity)) !important
		}

		.text-light {
			--bs-text-opacity: 1;
			color: rgba(var(--bs-light-rgb), var(--bs-text-opacity)) !important
		}

		.text-dark {
			--bs-text-opacity: 1;
			color: rgba(var(--bs-dark-rgb), var(--bs-text-opacity)) !important
		}

		.text-black {
			--bs-text-opacity: 1;
			color: rgba(var(--bs-black-rgb), var(--bs-text-opacity)) !important
		}

		.text-white {
			--bs-text-opacity: 1;
			color: rgba(var(--bs-white-rgb), var(--bs-text-opacity)) !important
		}

		.text-body {
			--bs-text-opacity: 1;
			color: rgba(var(--bs-body-color-rgb), var(--bs-text-opacity)) !important
		}

		.text-muted {
			--bs-text-opacity: 1;
			color: #6c757d !important
		}

		.text-black-50 {
			--bs-text-opacity: 1;
			color: rgba(0, 0, 0, .5) !important
		}

		.text-white-50 {
			--bs-text-opacity: 1;
			color: rgba(255, 255, 255, .5) !important
		}

		.text-reset {
			--bs-text-opacity: 1;
			color: inherit !important
		}

		.text-opacity-25 {
			--bs-text-opacity: 0.25
		}

		.text-opacity-50 {
			--bs-text-opacity: 0.5
		}

		.text-opacity-75 {
			--bs-text-opacity: 0.75
		}

		.text-opacity-100 {
			--bs-text-opacity: 1
		}

		.bg-primary {
			--bs-bg-opacity: 1;
			background-color: rgba(var(--bs-primary-rgb), var(--bs-bg-opacity)) !important
		}

		.bg-secondary {
			--bs-bg-opacity: 1;
			background-color: rgba(var(--bs-secondary-rgb), var(--bs-bg-opacity)) !important
		}

		.bg-success {
			--bs-bg-opacity: 1;
			background-color: rgba(var(--bs-success-rgb), var(--bs-bg-opacity)) !important
		}

		.bg-info {
			--bs-bg-opacity: 1;
			background-color: rgba(var(--bs-info-rgb), var(--bs-bg-opacity)) !important
		}

		.bg-warning {
			--bs-bg-opacity: 1;
			background-color: rgba(var(--bs-warning-rgb), var(--bs-bg-opacity)) !important
		}

		.bg-danger {
			--bs-bg-opacity: 1;
			background-color: rgba(var(--bs-danger-rgb), var(--bs-bg-opacity)) !important
		}

		.bg-light {
			--bs-bg-opacity: 1;
			background-color: rgba(var(--bs-light-rgb), var(--bs-bg-opacity)) !important
		}

		.bg-dark {
			--bs-bg-opacity: 1;
			background-color: rgba(var(--bs-dark-rgb), var(--bs-bg-opacity)) !important
		}

		.bg-black {
			--bs-bg-opacity: 1;
			background-color: rgba(var(--bs-black-rgb), var(--bs-bg-opacity)) !important
		}

		.bg-white {
			--bs-bg-opacity: 1;
			background-color: rgba(var(--bs-white-rgb), var(--bs-bg-opacity)) !important
		}

		.bg-body {
			--bs-bg-opacity: 1;
			background-color: rgba(var(--bs-body-bg-rgb), var(--bs-bg-opacity)) !important
		}

		.bg-transparent {
			--bs-bg-opacity: 1;
			background-color: transparent !important
		}

		.bg-opacity-10 {
			--bs-bg-opacity: 0.1
		}

		.bg-opacity-25 {
			--bs-bg-opacity: 0.25
		}

		.bg-opacity-50 {
			--bs-bg-opacity: 0.5
		}

		.bg-opacity-75 {
			--bs-bg-opacity: 0.75
		}

		.bg-opacity-100 {
			--bs-bg-opacity: 1
		}

		.bg-gradient {
			background-image: var(--bs-gradient) !important
		}

		.user-select-all {
			-webkit-user-select: all !important;
			-moz-user-select: all !important;
			user-select: all !important
		}

		.user-select-auto {
			-webkit-user-select: auto !important;
			-moz-user-select: auto !important;
			user-select: auto !important
		}

		.user-select-none {
			-webkit-user-select: none !important;
			-moz-user-select: none !important;
			user-select: none !important
		}

		.pe-none {
			pointer-events: none !important
		}

		.pe-auto {
			pointer-events: auto !important
		}

		.rounded {
			border-radius: var(--bs-border-radius) !important
		}

		.rounded-0 {
			border-radius: 0 !important
		}

		.rounded-1 {
			border-radius: var(--bs-border-radius-sm) !important
		}

		.rounded-2 {
			border-radius: var(--bs-border-radius) !important
		}

		.rounded-3 {
			border-radius: var(--bs-border-radius-lg) !important
		}

		.rounded-4 {
			border-radius: var(--bs-border-radius-xl) !important
		}

		.rounded-5 {
			border-radius: var(--bs-border-radius-2xl) !important
		}

		.rounded-circle {
			border-radius: 50% !important
		}

		.rounded-pill {
			border-radius: var(--bs-border-radius-pill) !important
		}

		.rounded-top {
			border-top-left-radius: var(--bs-border-radius) !important;
			border-top-right-radius: var(--bs-border-radius) !important
		}

		.rounded-end {
			border-top-right-radius: var(--bs-border-radius) !important;
			border-bottom-right-radius: var(--bs-border-radius) !important
		}

		.rounded-bottom {
			border-bottom-right-radius: var(--bs-border-radius) !important;
			border-bottom-left-radius: var(--bs-border-radius) !important
		}

		.rounded-start {
			border-bottom-left-radius: var(--bs-border-radius) !important;
			border-top-left-radius: var(--bs-border-radius) !important
		}

		.visible {
			visibility: visible !important
		}

		.invisible {
			visibility: hidden !important
		}

		@media (min-width:576px) {
			.float-sm-start {
				float: left !important
			}

			.float-sm-end {
				float: right !important
			}

			.float-sm-none {
				float: none !important
			}

			.d-sm-inline {
				display: inline !important
			}

			.d-sm-inline-block {
				display: inline-block !important
			}

			.d-sm-block {
				display: block !important
			}

			.d-sm-grid {
				display: grid !important
			}

			.d-sm-table {
				display: table !important
			}

			.d-sm-table-row {
				display: table-row !important
			}

			.d-sm-table-cell {
				display: table-cell !important
			}

			.d-sm-flex {
				display: flex !important
			}

			.d-sm-inline-flex {
				display: inline-flex !important
			}

			.d-sm-none {
				display: none !important
			}

			.flex-sm-fill {
				flex: 1 1 auto !important
			}

			.flex-sm-row {
				flex-direction: row !important
			}

			.flex-sm-column {
				flex-direction: column !important
			}

			.flex-sm-row-reverse {
				flex-direction: row-reverse !important
			}

			.flex-sm-column-reverse {
				flex-direction: column-reverse !important
			}

			.flex-sm-grow-0 {
				flex-grow: 0 !important
			}

			.flex-sm-grow-1 {
				flex-grow: 1 !important
			}

			.flex-sm-shrink-0 {
				flex-shrink: 0 !important
			}

			.flex-sm-shrink-1 {
				flex-shrink: 1 !important
			}

			.flex-sm-wrap {
				flex-wrap: wrap !important
			}

			.flex-sm-nowrap {
				flex-wrap: nowrap !important
			}

			.flex-sm-wrap-reverse {
				flex-wrap: wrap-reverse !important
			}

			.justify-content-sm-start {
				justify-content: flex-start !important
			}

			.justify-content-sm-end {
				justify-content: flex-end !important
			}

			.justify-content-sm-center {
				justify-content: center !important
			}

			.justify-content-sm-between {
				justify-content: space-between !important
			}

			.justify-content-sm-around {
				justify-content: space-around !important
			}

			.justify-content-sm-evenly {
				justify-content: space-evenly !important
			}

			.align-items-sm-start {
				align-items: flex-start !important
			}

			.align-items-sm-end {
				align-items: flex-end !important
			}

			.align-items-sm-center {
				align-items: center !important
			}

			.align-items-sm-baseline {
				align-items: baseline !important
			}

			.align-items-sm-stretch {
				align-items: stretch !important
			}

			.align-content-sm-start {
				align-content: flex-start !important
			}

			.align-content-sm-end {
				align-content: flex-end !important
			}

			.align-content-sm-center {
				align-content: center !important
			}

			.align-content-sm-between {
				align-content: space-between !important
			}

			.align-content-sm-around {
				align-content: space-around !important
			}

			.align-content-sm-stretch {
				align-content: stretch !important
			}

			.align-self-sm-auto {
				align-self: auto !important
			}

			.align-self-sm-start {
				align-self: flex-start !important
			}

			.align-self-sm-end {
				align-self: flex-end !important
			}

			.align-self-sm-center {
				align-self: center !important
			}

			.align-self-sm-baseline {
				align-self: baseline !important
			}

			.align-self-sm-stretch {
				align-self: stretch !important
			}

			.order-sm-first {
				order: -1 !important
			}

			.order-sm-0 {
				order: 0 !important
			}

			.order-sm-1 {
				order: 1 !important
			}

			.order-sm-2 {
				order: 2 !important
			}

			.order-sm-3 {
				order: 3 !important
			}

			.order-sm-4 {
				order: 4 !important
			}

			.order-sm-5 {
				order: 5 !important
			}

			.order-sm-last {
				order: 6 !important
			}

			.m-sm-0 {
				margin: 0 !important
			}

			.m-sm-1 {
				margin: .25rem !important
			}

			.m-sm-2 {
				margin: .5rem !important
			}

			.m-sm-3 {
				margin: 1rem !important
			}

			.m-sm-4 {
				margin: 1.5rem !important
			}

			.m-sm-5 {
				margin: 3rem !important
			}

			.m-sm-auto {
				margin: auto !important
			}

			.mx-sm-0 {
				margin-right: 0 !important;
				margin-left: 0 !important
			}

			.mx-sm-1 {
				margin-right: .25rem !important;
				margin-left: .25rem !important
			}

			.mx-sm-2 {
				margin-right: .5rem !important;
				margin-left: .5rem !important
			}

			.mx-sm-3 {
				margin-right: 1rem !important;
				margin-left: 1rem !important
			}

			.mx-sm-4 {
				margin-right: 1.5rem !important;
				margin-left: 1.5rem !important
			}

			.mx-sm-5 {
				margin-right: 3rem !important;
				margin-left: 3rem !important
			}

			.mx-sm-auto {
				margin-right: auto !important;
				margin-left: auto !important
			}

			.my-sm-0 {
				margin-top: 0 !important;
				margin-bottom: 0 !important
			}

			.my-sm-1 {
				margin-top: .25rem !important;
				margin-bottom: .25rem !important
			}

			.my-sm-2 {
				margin-top: .5rem !important;
				margin-bottom: .5rem !important
			}

			.my-sm-3 {
				margin-top: 1rem !important;
				margin-bottom: 1rem !important
			}

			.my-sm-4 {
				margin-top: 1.5rem !important;
				margin-bottom: 1.5rem !important
			}

			.my-sm-5 {
				margin-top: 3rem !important;
				margin-bottom: 3rem !important
			}

			.my-sm-auto {
				margin-top: auto !important;
				margin-bottom: auto !important
			}

			.mt-sm-0 {
				margin-top: 0 !important
			}

			.mt-sm-1 {
				margin-top: .25rem !important
			}

			.mt-sm-2 {
				margin-top: .5rem !important
			}

			.mt-sm-3 {
				margin-top: 1rem !important
			}

			.mt-sm-4 {
				margin-top: 1.5rem !important
			}

			.mt-sm-5 {
				margin-top: 3rem !important
			}

			.mt-sm-auto {
				margin-top: auto !important
			}

			.me-sm-0 {
				margin-right: 0 !important
			}

			.me-sm-1 {
				margin-right: .25rem !important
			}

			.me-sm-2 {
				margin-right: .5rem !important
			}

			.me-sm-3 {
				margin-right: 1rem !important
			}

			.me-sm-4 {
				margin-right: 1.5rem !important
			}

			.me-sm-5 {
				margin-right: 3rem !important
			}

			.me-sm-auto {
				margin-right: auto !important
			}

			.mb-sm-0 {
				margin-bottom: 0 !important
			}

			.mb-sm-1 {
				margin-bottom: .25rem !important
			}

			.mb-sm-2 {
				margin-bottom: .5rem !important
			}

			.mb-sm-3 {
				margin-bottom: 1rem !important
			}

			.mb-sm-4 {
				margin-bottom: 1.5rem !important
			}

			.mb-sm-5 {
				margin-bottom: 3rem !important
			}

			.mb-sm-auto {
				margin-bottom: auto !important
			}

			.ms-sm-0 {
				margin-left: 0 !important
			}

			.ms-sm-1 {
				margin-left: .25rem !important
			}

			.ms-sm-2 {
				margin-left: .5rem !important
			}

			.ms-sm-3 {
				margin-left: 1rem !important
			}

			.ms-sm-4 {
				margin-left: 1.5rem !important
			}

			.ms-sm-5 {
				margin-left: 3rem !important
			}

			.ms-sm-auto {
				margin-left: auto !important
			}

			.p-sm-0 {
				padding: 0 !important
			}

			.p-sm-1 {
				padding: .25rem !important
			}

			.p-sm-2 {
				padding: .5rem !important
			}

			.p-sm-3 {
				padding: 1rem !important
			}

			.p-sm-4 {
				padding: 1.5rem !important
			}

			.p-sm-5 {
				padding: 3rem !important
			}

			.px-sm-0 {
				padding-right: 0 !important;
				padding-left: 0 !important
			}

			.px-sm-1 {
				padding-right: .25rem !important;
				padding-left: .25rem !important
			}

			.px-sm-2 {
				padding-right: .5rem !important;
				padding-left: .5rem !important
			}

			.px-sm-3 {
				padding-right: 1rem !important;
				padding-left: 1rem !important
			}

			.px-sm-4 {
				padding-right: 1.5rem !important;
				padding-left: 1.5rem !important
			}

			.px-sm-5 {
				padding-right: 3rem !important;
				padding-left: 3rem !important
			}

			.py-sm-0 {
				padding-top: 0 !important;
				padding-bottom: 0 !important
			}

			.py-sm-1 {
				padding-top: .25rem !important;
				padding-bottom: .25rem !important
			}

			.py-sm-2 {
				padding-top: .5rem !important;
				padding-bottom: .5rem !important
			}

			.py-sm-3 {
				padding-top: 1rem !important;
				padding-bottom: 1rem !important
			}

			.py-sm-4 {
				padding-top: 1.5rem !important;
				padding-bottom: 1.5rem !important
			}

			.py-sm-5 {
				padding-top: 3rem !important;
				padding-bottom: 3rem !important
			}

			.pt-sm-0 {
				padding-top: 0 !important
			}

			.pt-sm-1 {
				padding-top: .25rem !important
			}

			.pt-sm-2 {
				padding-top: .5rem !important
			}

			.pt-sm-3 {
				padding-top: 1rem !important
			}

			.pt-sm-4 {
				padding-top: 1.5rem !important
			}

			.pt-sm-5 {
				padding-top: 3rem !important
			}

			.pe-sm-0 {
				padding-right: 0 !important
			}

			.pe-sm-1 {
				padding-right: .25rem !important
			}

			.pe-sm-2 {
				padding-right: .5rem !important
			}

			.pe-sm-3 {
				padding-right: 1rem !important
			}

			.pe-sm-4 {
				padding-right: 1.5rem !important
			}

			.pe-sm-5 {
				padding-right: 3rem !important
			}

			.pb-sm-0 {
				padding-bottom: 0 !important
			}

			.pb-sm-1 {
				padding-bottom: .25rem !important
			}

			.pb-sm-2 {
				padding-bottom: .5rem !important
			}

			.pb-sm-3 {
				padding-bottom: 1rem !important
			}

			.pb-sm-4 {
				padding-bottom: 1.5rem !important
			}

			.pb-sm-5 {
				padding-bottom: 3rem !important
			}

			.ps-sm-0 {
				padding-left: 0 !important
			}

			.ps-sm-1 {
				padding-left: .25rem !important
			}

			.ps-sm-2 {
				padding-left: .5rem !important
			}

			.ps-sm-3 {
				padding-left: 1rem !important
			}

			.ps-sm-4 {
				padding-left: 1.5rem !important
			}

			.ps-sm-5 {
				padding-left: 3rem !important
			}

			.gap-sm-0 {
				gap: 0 !important
			}

			.gap-sm-1 {
				gap: .25rem !important
			}

			.gap-sm-2 {
				gap: .5rem !important
			}

			.gap-sm-3 {
				gap: 1rem !important
			}

			.gap-sm-4 {
				gap: 1.5rem !important
			}

			.gap-sm-5 {
				gap: 3rem !important
			}

			.text-sm-start {
				text-align: left !important
			}

			.text-sm-end {
				text-align: right !important
			}

			.text-sm-center {
				text-align: center !important
			}
		}

		@media (min-width:768px) {
			.float-md-start {
				float: left !important
			}

			.float-md-end {
				float: right !important
			}

			.float-md-none {
				float: none !important
			}

			.d-md-inline {
				display: inline !important
			}

			.d-md-inline-block {
				display: inline-block !important
			}

			.d-md-block {
				display: block !important
			}

			.d-md-grid {
				display: grid !important
			}

			.d-md-table {
				display: table !important
			}

			.d-md-table-row {
				display: table-row !important
			}

			.d-md-table-cell {
				display: table-cell !important
			}

			.d-md-flex {
				display: flex !important
			}

			.d-md-inline-flex {
				display: inline-flex !important
			}

			.d-md-none {
				display: none !important
			}

			.flex-md-fill {
				flex: 1 1 auto !important
			}

			.flex-md-row {
				flex-direction: row !important
			}

			.flex-md-column {
				flex-direction: column !important
			}

			.flex-md-row-reverse {
				flex-direction: row-reverse !important
			}

			.flex-md-column-reverse {
				flex-direction: column-reverse !important
			}

			.flex-md-grow-0 {
				flex-grow: 0 !important
			}

			.flex-md-grow-1 {
				flex-grow: 1 !important
			}

			.flex-md-shrink-0 {
				flex-shrink: 0 !important
			}

			.flex-md-shrink-1 {
				flex-shrink: 1 !important
			}

			.flex-md-wrap {
				flex-wrap: wrap !important
			}

			.flex-md-nowrap {
				flex-wrap: nowrap !important
			}

			.flex-md-wrap-reverse {
				flex-wrap: wrap-reverse !important
			}

			.justify-content-md-start {
				justify-content: flex-start !important
			}

			.justify-content-md-end {
				justify-content: flex-end !important
			}

			.justify-content-md-center {
				justify-content: center !important
			}

			.justify-content-md-between {
				justify-content: space-between !important
			}

			.justify-content-md-around {
				justify-content: space-around !important
			}

			.justify-content-md-evenly {
				justify-content: space-evenly !important
			}

			.align-items-md-start {
				align-items: flex-start !important
			}

			.align-items-md-end {
				align-items: flex-end !important
			}

			.align-items-md-center {
				align-items: center !important
			}

			.align-items-md-baseline {
				align-items: baseline !important
			}

			.align-items-md-stretch {
				align-items: stretch !important
			}

			.align-content-md-start {
				align-content: flex-start !important
			}

			.align-content-md-end {
				align-content: flex-end !important
			}

			.align-content-md-center {
				align-content: center !important
			}

			.align-content-md-between {
				align-content: space-between !important
			}

			.align-content-md-around {
				align-content: space-around !important
			}

			.align-content-md-stretch {
				align-content: stretch !important
			}

			.align-self-md-auto {
				align-self: auto !important
			}

			.align-self-md-start {
				align-self: flex-start !important
			}

			.align-self-md-end {
				align-self: flex-end !important
			}

			.align-self-md-center {
				align-self: center !important
			}

			.align-self-md-baseline {
				align-self: baseline !important
			}

			.align-self-md-stretch {
				align-self: stretch !important
			}

			.order-md-first {
				order: -1 !important
			}

			.order-md-0 {
				order: 0 !important
			}

			.order-md-1 {
				order: 1 !important
			}

			.order-md-2 {
				order: 2 !important
			}

			.order-md-3 {
				order: 3 !important
			}

			.order-md-4 {
				order: 4 !important
			}

			.order-md-5 {
				order: 5 !important
			}

			.order-md-last {
				order: 6 !important
			}

			.m-md-0 {
				margin: 0 !important
			}

			.m-md-1 {
				margin: .25rem !important
			}

			.m-md-2 {
				margin: .5rem !important
			}

			.m-md-3 {
				margin: 1rem !important
			}

			.m-md-4 {
				margin: 1.5rem !important
			}

			.m-md-5 {
				margin: 3rem !important
			}

			.m-md-auto {
				margin: auto !important
			}

			.mx-md-0 {
				margin-right: 0 !important;
				margin-left: 0 !important
			}

			.mx-md-1 {
				margin-right: .25rem !important;
				margin-left: .25rem !important
			}

			.mx-md-2 {
				margin-right: .5rem !important;
				margin-left: .5rem !important
			}

			.mx-md-3 {
				margin-right: 1rem !important;
				margin-left: 1rem !important
			}

			.mx-md-4 {
				margin-right: 1.5rem !important;
				margin-left: 1.5rem !important
			}

			.mx-md-5 {
				margin-right: 3rem !important;
				margin-left: 3rem !important
			}

			.mx-md-auto {
				margin-right: auto !important;
				margin-left: auto !important
			}

			.my-md-0 {
				margin-top: 0 !important;
				margin-bottom: 0 !important
			}

			.my-md-1 {
				margin-top: .25rem !important;
				margin-bottom: .25rem !important
			}

			.my-md-2 {
				margin-top: .5rem !important;
				margin-bottom: .5rem !important
			}

			.my-md-3 {
				margin-top: 1rem !important;
				margin-bottom: 1rem !important
			}

			.my-md-4 {
				margin-top: 1.5rem !important;
				margin-bottom: 1.5rem !important
			}

			.my-md-5 {
				margin-top: 3rem !important;
				margin-bottom: 3rem !important
			}

			.my-md-auto {
				margin-top: auto !important;
				margin-bottom: auto !important
			}

			.mt-md-0 {
				margin-top: 0 !important
			}

			.mt-md-1 {
				margin-top: .25rem !important
			}

			.mt-md-2 {
				margin-top: .5rem !important
			}

			.mt-md-3 {
				margin-top: 1rem !important
			}

			.mt-md-4 {
				margin-top: 1.5rem !important
			}

			.mt-md-5 {
				margin-top: 3rem !important
			}

			.mt-md-auto {
				margin-top: auto !important
			}

			.me-md-0 {
				margin-right: 0 !important
			}

			.me-md-1 {
				margin-right: .25rem !important
			}

			.me-md-2 {
				margin-right: .5rem !important
			}

			.me-md-3 {
				margin-right: 1rem !important
			}

			.me-md-4 {
				margin-right: 1.5rem !important
			}

			.me-md-5 {
				margin-right: 3rem !important
			}

			.me-md-auto {
				margin-right: auto !important
			}

			.mb-md-0 {
				margin-bottom: 0 !important
			}

			.mb-md-1 {
				margin-bottom: .25rem !important
			}

			.mb-md-2 {
				margin-bottom: .5rem !important
			}

			.mb-md-3 {
				margin-bottom: 1rem !important
			}

			.mb-md-4 {
				margin-bottom: 1.5rem !important
			}

			.mb-md-5 {
				margin-bottom: 3rem !important
			}

			.mb-md-auto {
				margin-bottom: auto !important
			}

			.ms-md-0 {
				margin-left: 0 !important
			}

			.ms-md-1 {
				margin-left: .25rem !important
			}

			.ms-md-2 {
				margin-left: .5rem !important
			}

			.ms-md-3 {
				margin-left: 1rem !important
			}

			.ms-md-4 {
				margin-left: 1.5rem !important
			}

			.ms-md-5 {
				margin-left: 3rem !important
			}

			.ms-md-auto {
				margin-left: auto !important
			}

			.p-md-0 {
				padding: 0 !important
			}

			.p-md-1 {
				padding: .25rem !important
			}

			.p-md-2 {
				padding: .5rem !important
			}

			.p-md-3 {
				padding: 1rem !important
			}

			.p-md-4 {
				padding: 1.5rem !important
			}

			.p-md-5 {
				padding: 3rem !important
			}

			.px-md-0 {
				padding-right: 0 !important;
				padding-left: 0 !important
			}

			.px-md-1 {
				padding-right: .25rem !important;
				padding-left: .25rem !important
			}

			.px-md-2 {
				padding-right: .5rem !important;
				padding-left: .5rem !important
			}

			.px-md-3 {
				padding-right: 1rem !important;
				padding-left: 1rem !important
			}

			.px-md-4 {
				padding-right: 1.5rem !important;
				padding-left: 1.5rem !important
			}

			.px-md-5 {
				padding-right: 3rem !important;
				padding-left: 3rem !important
			}

			.py-md-0 {
				padding-top: 0 !important;
				padding-bottom: 0 !important
			}

			.py-md-1 {
				padding-top: .25rem !important;
				padding-bottom: .25rem !important
			}

			.py-md-2 {
				padding-top: .5rem !important;
				padding-bottom: .5rem !important
			}

			.py-md-3 {
				padding-top: 1rem !important;
				padding-bottom: 1rem !important
			}

			.py-md-4 {
				padding-top: 1.5rem !important;
				padding-bottom: 1.5rem !important
			}

			.py-md-5 {
				padding-top: 3rem !important;
				padding-bottom: 3rem !important
			}

			.pt-md-0 {
				padding-top: 0 !important
			}

			.pt-md-1 {
				padding-top: .25rem !important
			}

			.pt-md-2 {
				padding-top: .5rem !important
			}

			.pt-md-3 {
				padding-top: 1rem !important
			}

			.pt-md-4 {
				padding-top: 1.5rem !important
			}

			.pt-md-5 {
				padding-top: 3rem !important
			}

			.pe-md-0 {
				padding-right: 0 !important
			}

			.pe-md-1 {
				padding-right: .25rem !important
			}

			.pe-md-2 {
				padding-right: .5rem !important
			}

			.pe-md-3 {
				padding-right: 1rem !important
			}

			.pe-md-4 {
				padding-right: 1.5rem !important
			}

			.pe-md-5 {
				padding-right: 3rem !important
			}

			.pb-md-0 {
				padding-bottom: 0 !important
			}

			.pb-md-1 {
				padding-bottom: .25rem !important
			}

			.pb-md-2 {
				padding-bottom: .5rem !important
			}

			.pb-md-3 {
				padding-bottom: 1rem !important
			}

			.pb-md-4 {
				padding-bottom: 1.5rem !important
			}

			.pb-md-5 {
				padding-bottom: 3rem !important
			}

			.ps-md-0 {
				padding-left: 0 !important
			}

			.ps-md-1 {
				padding-left: .25rem !important
			}

			.ps-md-2 {
				padding-left: .5rem !important
			}

			.ps-md-3 {
				padding-left: 1rem !important
			}

			.ps-md-4 {
				padding-left: 1.5rem !important
			}

			.ps-md-5 {
				padding-left: 3rem !important
			}

			.gap-md-0 {
				gap: 0 !important
			}

			.gap-md-1 {
				gap: .25rem !important
			}

			.gap-md-2 {
				gap: .5rem !important
			}

			.gap-md-3 {
				gap: 1rem !important
			}

			.gap-md-4 {
				gap: 1.5rem !important
			}

			.gap-md-5 {
				gap: 3rem !important
			}

			.text-md-start {
				text-align: left !important
			}

			.text-md-end {
				text-align: right !important
			}

			.text-md-center {
				text-align: center !important
			}
		}

		@media (min-width:992px) {
			.float-lg-start {
				float: left !important
			}

			.float-lg-end {
				float: right !important
			}

			.float-lg-none {
				float: none !important
			}

			.d-lg-inline {
				display: inline !important
			}

			.d-lg-inline-block {
				display: inline-block !important
			}

			.d-lg-block {
				display: block !important
			}

			.d-lg-grid {
				display: grid !important
			}

			.d-lg-table {
				display: table !important
			}

			.d-lg-table-row {
				display: table-row !important
			}

			.d-lg-table-cell {
				display: table-cell !important
			}

			.d-lg-flex {
				display: flex !important
			}

			.d-lg-inline-flex {
				display: inline-flex !important
			}

			.d-lg-none {
				display: none !important
			}

			.flex-lg-fill {
				flex: 1 1 auto !important
			}

			.flex-lg-row {
				flex-direction: row !important
			}

			.flex-lg-column {
				flex-direction: column !important
			}

			.flex-lg-row-reverse {
				flex-direction: row-reverse !important
			}

			.flex-lg-column-reverse {
				flex-direction: column-reverse !important
			}

			.flex-lg-grow-0 {
				flex-grow: 0 !important
			}

			.flex-lg-grow-1 {
				flex-grow: 1 !important
			}

			.flex-lg-shrink-0 {
				flex-shrink: 0 !important
			}

			.flex-lg-shrink-1 {
				flex-shrink: 1 !important
			}

			.flex-lg-wrap {
				flex-wrap: wrap !important
			}

			.flex-lg-nowrap {
				flex-wrap: nowrap !important
			}

			.flex-lg-wrap-reverse {
				flex-wrap: wrap-reverse !important
			}

			.justify-content-lg-start {
				justify-content: flex-start !important
			}

			.justify-content-lg-end {
				justify-content: flex-end !important
			}

			.justify-content-lg-center {
				justify-content: center !important
			}

			.justify-content-lg-between {
				justify-content: space-between !important
			}

			.justify-content-lg-around {
				justify-content: space-around !important
			}

			.justify-content-lg-evenly {
				justify-content: space-evenly !important
			}

			.align-items-lg-start {
				align-items: flex-start !important
			}

			.align-items-lg-end {
				align-items: flex-end !important
			}

			.align-items-lg-center {
				align-items: center !important
			}

			.align-items-lg-baseline {
				align-items: baseline !important
			}

			.align-items-lg-stretch {
				align-items: stretch !important
			}

			.align-content-lg-start {
				align-content: flex-start !important
			}

			.align-content-lg-end {
				align-content: flex-end !important
			}

			.align-content-lg-center {
				align-content: center !important
			}

			.align-content-lg-between {
				align-content: space-between !important
			}

			.align-content-lg-around {
				align-content: space-around !important
			}

			.align-content-lg-stretch {
				align-content: stretch !important
			}

			.align-self-lg-auto {
				align-self: auto !important
			}

			.align-self-lg-start {
				align-self: flex-start !important
			}

			.align-self-lg-end {
				align-self: flex-end !important
			}

			.align-self-lg-center {
				align-self: center !important
			}

			.align-self-lg-baseline {
				align-self: baseline !important
			}

			.align-self-lg-stretch {
				align-self: stretch !important
			}

			.order-lg-first {
				order: -1 !important
			}

			.order-lg-0 {
				order: 0 !important
			}

			.order-lg-1 {
				order: 1 !important
			}

			.order-lg-2 {
				order: 2 !important
			}

			.order-lg-3 {
				order: 3 !important
			}

			.order-lg-4 {
				order: 4 !important
			}

			.order-lg-5 {
				order: 5 !important
			}

			.order-lg-last {
				order: 6 !important
			}

			.m-lg-0 {
				margin: 0 !important
			}

			.m-lg-1 {
				margin: .25rem !important
			}

			.m-lg-2 {
				margin: .5rem !important
			}

			.m-lg-3 {
				margin: 1rem !important
			}

			.m-lg-4 {
				margin: 1.5rem !important
			}

			.m-lg-5 {
				margin: 3rem !important
			}

			.m-lg-auto {
				margin: auto !important
			}

			.mx-lg-0 {
				margin-right: 0 !important;
				margin-left: 0 !important
			}

			.mx-lg-1 {
				margin-right: .25rem !important;
				margin-left: .25rem !important
			}

			.mx-lg-2 {
				margin-right: .5rem !important;
				margin-left: .5rem !important
			}

			.mx-lg-3 {
				margin-right: 1rem !important;
				margin-left: 1rem !important
			}

			.mx-lg-4 {
				margin-right: 1.5rem !important;
				margin-left: 1.5rem !important
			}

			.mx-lg-5 {
				margin-right: 3rem !important;
				margin-left: 3rem !important
			}

			.mx-lg-auto {
				margin-right: auto !important;
				margin-left: auto !important
			}

			.my-lg-0 {
				margin-top: 0 !important;
				margin-bottom: 0 !important
			}

			.my-lg-1 {
				margin-top: .25rem !important;
				margin-bottom: .25rem !important
			}

			.my-lg-2 {
				margin-top: .5rem !important;
				margin-bottom: .5rem !important
			}

			.my-lg-3 {
				margin-top: 1rem !important;
				margin-bottom: 1rem !important
			}

			.my-lg-4 {
				margin-top: 1.5rem !important;
				margin-bottom: 1.5rem !important
			}

			.my-lg-5 {
				margin-top: 3rem !important;
				margin-bottom: 3rem !important
			}

			.my-lg-auto {
				margin-top: auto !important;
				margin-bottom: auto !important
			}

			.mt-lg-0 {
				margin-top: 0 !important
			}

			.mt-lg-1 {
				margin-top: .25rem !important
			}

			.mt-lg-2 {
				margin-top: .5rem !important
			}

			.mt-lg-3 {
				margin-top: 1rem !important
			}

			.mt-lg-4 {
				margin-top: 1.5rem !important
			}

			.mt-lg-5 {
				margin-top: 3rem !important
			}

			.mt-lg-auto {
				margin-top: auto !important
			}

			.me-lg-0 {
				margin-right: 0 !important
			}

			.me-lg-1 {
				margin-right: .25rem !important
			}

			.me-lg-2 {
				margin-right: .5rem !important
			}

			.me-lg-3 {
				margin-right: 1rem !important
			}

			.me-lg-4 {
				margin-right: 1.5rem !important
			}

			.me-lg-5 {
				margin-right: 3rem !important
			}

			.me-lg-auto {
				margin-right: auto !important
			}

			.mb-lg-0 {
				margin-bottom: 0 !important
			}

			.mb-lg-1 {
				margin-bottom: .25rem !important
			}

			.mb-lg-2 {
				margin-bottom: .5rem !important
			}

			.mb-lg-3 {
				margin-bottom: 1rem !important
			}

			.mb-lg-4 {
				margin-bottom: 1.5rem !important
			}

			.mb-lg-5 {
				margin-bottom: 3rem !important
			}

			.mb-lg-auto {
				margin-bottom: auto !important
			}

			.ms-lg-0 {
				margin-left: 0 !important
			}

			.ms-lg-1 {
				margin-left: .25rem !important
			}

			.ms-lg-2 {
				margin-left: .5rem !important
			}

			.ms-lg-3 {
				margin-left: 1rem !important
			}

			.ms-lg-4 {
				margin-left: 1.5rem !important
			}

			.ms-lg-5 {
				margin-left: 3rem !important
			}

			.ms-lg-auto {
				margin-left: auto !important
			}

			.p-lg-0 {
				padding: 0 !important
			}

			.p-lg-1 {
				padding: .25rem !important
			}

			.p-lg-2 {
				padding: .5rem !important
			}

			.p-lg-3 {
				padding: 1rem !important
			}

			.p-lg-4 {
				padding: 1.5rem !important
			}

			.p-lg-5 {
				padding: 3rem !important
			}

			.px-lg-0 {
				padding-right: 0 !important;
				padding-left: 0 !important
			}

			.px-lg-1 {
				padding-right: .25rem !important;
				padding-left: .25rem !important
			}

			.px-lg-2 {
				padding-right: .5rem !important;
				padding-left: .5rem !important
			}

			.px-lg-3 {
				padding-right: 1rem !important;
				padding-left: 1rem !important
			}

			.px-lg-4 {
				padding-right: 1.5rem !important;
				padding-left: 1.5rem !important
			}

			.px-lg-5 {
				padding-right: 3rem !important;
				padding-left: 3rem !important
			}

			.py-lg-0 {
				padding-top: 0 !important;
				padding-bottom: 0 !important
			}

			.py-lg-1 {
				padding-top: .25rem !important;
				padding-bottom: .25rem !important
			}

			.py-lg-2 {
				padding-top: .5rem !important;
				padding-bottom: .5rem !important
			}

			.py-lg-3 {
				padding-top: 1rem !important;
				padding-bottom: 1rem !important
			}

			.py-lg-4 {
				padding-top: 1.5rem !important;
				padding-bottom: 1.5rem !important
			}

			.py-lg-5 {
				padding-top: 3rem !important;
				padding-bottom: 3rem !important
			}

			.pt-lg-0 {
				padding-top: 0 !important
			}

			.pt-lg-1 {
				padding-top: .25rem !important
			}

			.pt-lg-2 {
				padding-top: .5rem !important
			}

			.pt-lg-3 {
				padding-top: 1rem !important
			}

			.pt-lg-4 {
				padding-top: 1.5rem !important
			}

			.pt-lg-5 {
				padding-top: 3rem !important
			}

			.pe-lg-0 {
				padding-right: 0 !important
			}

			.pe-lg-1 {
				padding-right: .25rem !important
			}

			.pe-lg-2 {
				padding-right: .5rem !important
			}

			.pe-lg-3 {
				padding-right: 1rem !important
			}

			.pe-lg-4 {
				padding-right: 1.5rem !important
			}

			.pe-lg-5 {
				padding-right: 3rem !important
			}

			.pb-lg-0 {
				padding-bottom: 0 !important
			}

			.pb-lg-1 {
				padding-bottom: .25rem !important
			}

			.pb-lg-2 {
				padding-bottom: .5rem !important
			}

			.pb-lg-3 {
				padding-bottom: 1rem !important
			}

			.pb-lg-4 {
				padding-bottom: 1.5rem !important
			}

			.pb-lg-5 {
				padding-bottom: 3rem !important
			}

			.ps-lg-0 {
				padding-left: 0 !important
			}

			.ps-lg-1 {
				padding-left: .25rem !important
			}

			.ps-lg-2 {
				padding-left: .5rem !important
			}

			.ps-lg-3 {
				padding-left: 1rem !important
			}

			.ps-lg-4 {
				padding-left: 1.5rem !important
			}

			.ps-lg-5 {
				padding-left: 3rem !important
			}

			.gap-lg-0 {
				gap: 0 !important
			}

			.gap-lg-1 {
				gap: .25rem !important
			}

			.gap-lg-2 {
				gap: .5rem !important
			}

			.gap-lg-3 {
				gap: 1rem !important
			}

			.gap-lg-4 {
				gap: 1.5rem !important
			}

			.gap-lg-5 {
				gap: 3rem !important
			}

			.text-lg-start {
				text-align: left !important
			}

			.text-lg-end {
				text-align: right !important
			}

			.text-lg-center {
				text-align: center !important
			}
		}

		@media (min-width:1200px) {
			.float-xl-start {
				float: left !important
			}

			.float-xl-end {
				float: right !important
			}

			.float-xl-none {
				float: none !important
			}

			.d-xl-inline {
				display: inline !important
			}

			.d-xl-inline-block {
				display: inline-block !important
			}

			.d-xl-block {
				display: block !important
			}

			.d-xl-grid {
				display: grid !important
			}

			.d-xl-table {
				display: table !important
			}

			.d-xl-table-row {
				display: table-row !important
			}

			.d-xl-table-cell {
				display: table-cell !important
			}

			.d-xl-flex {
				display: flex !important
			}

			.d-xl-inline-flex {
				display: inline-flex !important
			}

			.d-xl-none {
				display: none !important
			}

			.flex-xl-fill {
				flex: 1 1 auto !important
			}

			.flex-xl-row {
				flex-direction: row !important
			}

			.flex-xl-column {
				flex-direction: column !important
			}

			.flex-xl-row-reverse {
				flex-direction: row-reverse !important
			}

			.flex-xl-column-reverse {
				flex-direction: column-reverse !important
			}

			.flex-xl-grow-0 {
				flex-grow: 0 !important
			}

			.flex-xl-grow-1 {
				flex-grow: 1 !important
			}

			.flex-xl-shrink-0 {
				flex-shrink: 0 !important
			}

			.flex-xl-shrink-1 {
				flex-shrink: 1 !important
			}

			.flex-xl-wrap {
				flex-wrap: wrap !important
			}

			.flex-xl-nowrap {
				flex-wrap: nowrap !important
			}

			.flex-xl-wrap-reverse {
				flex-wrap: wrap-reverse !important
			}

			.justify-content-xl-start {
				justify-content: flex-start !important
			}

			.justify-content-xl-end {
				justify-content: flex-end !important
			}

			.justify-content-xl-center {
				justify-content: center !important
			}

			.justify-content-xl-between {
				justify-content: space-between !important
			}

			.justify-content-xl-around {
				justify-content: space-around !important
			}

			.justify-content-xl-evenly {
				justify-content: space-evenly !important
			}

			.align-items-xl-start {
				align-items: flex-start !important
			}

			.align-items-xl-end {
				align-items: flex-end !important
			}

			.align-items-xl-center {
				align-items: center !important
			}

			.align-items-xl-baseline {
				align-items: baseline !important
			}

			.align-items-xl-stretch {
				align-items: stretch !important
			}

			.align-content-xl-start {
				align-content: flex-start !important
			}

			.align-content-xl-end {
				align-content: flex-end !important
			}

			.align-content-xl-center {
				align-content: center !important
			}

			.align-content-xl-between {
				align-content: space-between !important
			}

			.align-content-xl-around {
				align-content: space-around !important
			}

			.align-content-xl-stretch {
				align-content: stretch !important
			}

			.align-self-xl-auto {
				align-self: auto !important
			}

			.align-self-xl-start {
				align-self: flex-start !important
			}

			.align-self-xl-end {
				align-self: flex-end !important
			}

			.align-self-xl-center {
				align-self: center !important
			}

			.align-self-xl-baseline {
				align-self: baseline !important
			}

			.align-self-xl-stretch {
				align-self: stretch !important
			}

			.order-xl-first {
				order: -1 !important
			}

			.order-xl-0 {
				order: 0 !important
			}

			.order-xl-1 {
				order: 1 !important
			}

			.order-xl-2 {
				order: 2 !important
			}

			.order-xl-3 {
				order: 3 !important
			}

			.order-xl-4 {
				order: 4 !important
			}

			.order-xl-5 {
				order: 5 !important
			}

			.order-xl-last {
				order: 6 !important
			}

			.m-xl-0 {
				margin: 0 !important
			}

			.m-xl-1 {
				margin: .25rem !important
			}

			.m-xl-2 {
				margin: .5rem !important
			}

			.m-xl-3 {
				margin: 1rem !important
			}

			.m-xl-4 {
				margin: 1.5rem !important
			}

			.m-xl-5 {
				margin: 3rem !important
			}

			.m-xl-auto {
				margin: auto !important
			}

			.mx-xl-0 {
				margin-right: 0 !important;
				margin-left: 0 !important
			}

			.mx-xl-1 {
				margin-right: .25rem !important;
				margin-left: .25rem !important
			}

			.mx-xl-2 {
				margin-right: .5rem !important;
				margin-left: .5rem !important
			}

			.mx-xl-3 {
				margin-right: 1rem !important;
				margin-left: 1rem !important
			}

			.mx-xl-4 {
				margin-right: 1.5rem !important;
				margin-left: 1.5rem !important
			}

			.mx-xl-5 {
				margin-right: 3rem !important;
				margin-left: 3rem !important
			}

			.mx-xl-auto {
				margin-right: auto !important;
				margin-left: auto !important
			}

			.my-xl-0 {
				margin-top: 0 !important;
				margin-bottom: 0 !important
			}

			.my-xl-1 {
				margin-top: .25rem !important;
				margin-bottom: .25rem !important
			}

			.my-xl-2 {
				margin-top: .5rem !important;
				margin-bottom: .5rem !important
			}

			.my-xl-3 {
				margin-top: 1rem !important;
				margin-bottom: 1rem !important
			}

			.my-xl-4 {
				margin-top: 1.5rem !important;
				margin-bottom: 1.5rem !important
			}

			.my-xl-5 {
				margin-top: 3rem !important;
				margin-bottom: 3rem !important
			}

			.my-xl-auto {
				margin-top: auto !important;
				margin-bottom: auto !important
			}

			.mt-xl-0 {
				margin-top: 0 !important
			}

			.mt-xl-1 {
				margin-top: .25rem !important
			}

			.mt-xl-2 {
				margin-top: .5rem !important
			}

			.mt-xl-3 {
				margin-top: 1rem !important
			}

			.mt-xl-4 {
				margin-top: 1.5rem !important
			}

			.mt-xl-5 {
				margin-top: 3rem !important
			}

			.mt-xl-auto {
				margin-top: auto !important
			}

			.me-xl-0 {
				margin-right: 0 !important
			}

			.me-xl-1 {
				margin-right: .25rem !important
			}

			.me-xl-2 {
				margin-right: .5rem !important
			}

			.me-xl-3 {
				margin-right: 1rem !important
			}

			.me-xl-4 {
				margin-right: 1.5rem !important
			}

			.me-xl-5 {
				margin-right: 3rem !important
			}

			.me-xl-auto {
				margin-right: auto !important
			}

			.mb-xl-0 {
				margin-bottom: 0 !important
			}

			.mb-xl-1 {
				margin-bottom: .25rem !important
			}

			.mb-xl-2 {
				margin-bottom: .5rem !important
			}

			.mb-xl-3 {
				margin-bottom: 1rem !important
			}

			.mb-xl-4 {
				margin-bottom: 1.5rem !important
			}

			.mb-xl-5 {
				margin-bottom: 3rem !important
			}

			.mb-xl-auto {
				margin-bottom: auto !important
			}

			.ms-xl-0 {
				margin-left: 0 !important
			}

			.ms-xl-1 {
				margin-left: .25rem !important
			}

			.ms-xl-2 {
				margin-left: .5rem !important
			}

			.ms-xl-3 {
				margin-left: 1rem !important
			}

			.ms-xl-4 {
				margin-left: 1.5rem !important
			}

			.ms-xl-5 {
				margin-left: 3rem !important
			}

			.ms-xl-auto {
				margin-left: auto !important
			}

			.p-xl-0 {
				padding: 0 !important
			}

			.p-xl-1 {
				padding: .25rem !important
			}

			.p-xl-2 {
				padding: .5rem !important
			}

			.p-xl-3 {
				padding: 1rem !important
			}

			.p-xl-4 {
				padding: 1.5rem !important
			}

			.p-xl-5 {
				padding: 3rem !important
			}

			.px-xl-0 {
				padding-right: 0 !important;
				padding-left: 0 !important
			}

			.px-xl-1 {
				padding-right: .25rem !important;
				padding-left: .25rem !important
			}

			.px-xl-2 {
				padding-right: .5rem !important;
				padding-left: .5rem !important
			}

			.px-xl-3 {
				padding-right: 1rem !important;
				padding-left: 1rem !important
			}

			.px-xl-4 {
				padding-right: 1.5rem !important;
				padding-left: 1.5rem !important
			}

			.px-xl-5 {
				padding-right: 3rem !important;
				padding-left: 3rem !important
			}

			.py-xl-0 {
				padding-top: 0 !important;
				padding-bottom: 0 !important
			}

			.py-xl-1 {
				padding-top: .25rem !important;
				padding-bottom: .25rem !important
			}

			.py-xl-2 {
				padding-top: .5rem !important;
				padding-bottom: .5rem !important
			}

			.py-xl-3 {
				padding-top: 1rem !important;
				padding-bottom: 1rem !important
			}

			.py-xl-4 {
				padding-top: 1.5rem !important;
				padding-bottom: 1.5rem !important
			}

			.py-xl-5 {
				padding-top: 3rem !important;
				padding-bottom: 3rem !important
			}

			.pt-xl-0 {
				padding-top: 0 !important
			}

			.pt-xl-1 {
				padding-top: .25rem !important
			}

			.pt-xl-2 {
				padding-top: .5rem !important
			}

			.pt-xl-3 {
				padding-top: 1rem !important
			}

			.pt-xl-4 {
				padding-top: 1.5rem !important
			}

			.pt-xl-5 {
				padding-top: 3rem !important
			}

			.pe-xl-0 {
				padding-right: 0 !important
			}

			.pe-xl-1 {
				padding-right: .25rem !important
			}

			.pe-xl-2 {
				padding-right: .5rem !important
			}

			.pe-xl-3 {
				padding-right: 1rem !important
			}

			.pe-xl-4 {
				padding-right: 1.5rem !important
			}

			.pe-xl-5 {
				padding-right: 3rem !important
			}

			.pb-xl-0 {
				padding-bottom: 0 !important
			}

			.pb-xl-1 {
				padding-bottom: .25rem !important
			}

			.pb-xl-2 {
				padding-bottom: .5rem !important
			}

			.pb-xl-3 {
				padding-bottom: 1rem !important
			}

			.pb-xl-4 {
				padding-bottom: 1.5rem !important
			}

			.pb-xl-5 {
				padding-bottom: 3rem !important
			}

			.ps-xl-0 {
				padding-left: 0 !important
			}

			.ps-xl-1 {
				padding-left: .25rem !important
			}

			.ps-xl-2 {
				padding-left: .5rem !important
			}

			.ps-xl-3 {
				padding-left: 1rem !important
			}

			.ps-xl-4 {
				padding-left: 1.5rem !important
			}

			.ps-xl-5 {
				padding-left: 3rem !important
			}

			.gap-xl-0 {
				gap: 0 !important
			}

			.gap-xl-1 {
				gap: .25rem !important
			}

			.gap-xl-2 {
				gap: .5rem !important
			}

			.gap-xl-3 {
				gap: 1rem !important
			}

			.gap-xl-4 {
				gap: 1.5rem !important
			}

			.gap-xl-5 {
				gap: 3rem !important
			}

			.text-xl-start {
				text-align: left !important
			}

			.text-xl-end {
				text-align: right !important
			}

			.text-xl-center {
				text-align: center !important
			}
		}

		@media (min-width:1400px) {
			.float-xxl-start {
				float: left !important
			}

			.float-xxl-end {
				float: right !important
			}

			.float-xxl-none {
				float: none !important
			}

			.d-xxl-inline {
				display: inline !important
			}

			.d-xxl-inline-block {
				display: inline-block !important
			}

			.d-xxl-block {
				display: block !important
			}

			.d-xxl-grid {
				display: grid !important
			}

			.d-xxl-table {
				display: table !important
			}

			.d-xxl-table-row {
				display: table-row !important
			}

			.d-xxl-table-cell {
				display: table-cell !important
			}

			.d-xxl-flex {
				display: flex !important
			}

			.d-xxl-inline-flex {
				display: inline-flex !important
			}

			.d-xxl-none {
				display: none !important
			}

			.flex-xxl-fill {
				flex: 1 1 auto !important
			}

			.flex-xxl-row {
				flex-direction: row !important
			}

			.flex-xxl-column {
				flex-direction: column !important
			}

			.flex-xxl-row-reverse {
				flex-direction: row-reverse !important
			}

			.flex-xxl-column-reverse {
				flex-direction: column-reverse !important
			}

			.flex-xxl-grow-0 {
				flex-grow: 0 !important
			}

			.flex-xxl-grow-1 {
				flex-grow: 1 !important
			}

			.flex-xxl-shrink-0 {
				flex-shrink: 0 !important
			}

			.flex-xxl-shrink-1 {
				flex-shrink: 1 !important
			}

			.flex-xxl-wrap {
				flex-wrap: wrap !important
			}

			.flex-xxl-nowrap {
				flex-wrap: nowrap !important
			}

			.flex-xxl-wrap-reverse {
				flex-wrap: wrap-reverse !important
			}

			.justify-content-xxl-start {
				justify-content: flex-start !important
			}

			.justify-content-xxl-end {
				justify-content: flex-end !important
			}

			.justify-content-xxl-center {
				justify-content: center !important
			}

			.justify-content-xxl-between {
				justify-content: space-between !important
			}

			.justify-content-xxl-around {
				justify-content: space-around !important
			}

			.justify-content-xxl-evenly {
				justify-content: space-evenly !important
			}

			.align-items-xxl-start {
				align-items: flex-start !important
			}

			.align-items-xxl-end {
				align-items: flex-end !important
			}

			.align-items-xxl-center {
				align-items: center !important
			}

			.align-items-xxl-baseline {
				align-items: baseline !important
			}

			.align-items-xxl-stretch {
				align-items: stretch !important
			}

			.align-content-xxl-start {
				align-content: flex-start !important
			}

			.align-content-xxl-end {
				align-content: flex-end !important
			}

			.align-content-xxl-center {
				align-content: center !important
			}

			.align-content-xxl-between {
				align-content: space-between !important
			}

			.align-content-xxl-around {
				align-content: space-around !important
			}

			.align-content-xxl-stretch {
				align-content: stretch !important
			}

			.align-self-xxl-auto {
				align-self: auto !important
			}

			.align-self-xxl-start {
				align-self: flex-start !important
			}

			.align-self-xxl-end {
				align-self: flex-end !important
			}

			.align-self-xxl-center {
				align-self: center !important
			}

			.align-self-xxl-baseline {
				align-self: baseline !important
			}

			.align-self-xxl-stretch {
				align-self: stretch !important
			}

			.order-xxl-first {
				order: -1 !important
			}

			.order-xxl-0 {
				order: 0 !important
			}

			.order-xxl-1 {
				order: 1 !important
			}

			.order-xxl-2 {
				order: 2 !important
			}

			.order-xxl-3 {
				order: 3 !important
			}

			.order-xxl-4 {
				order: 4 !important
			}

			.order-xxl-5 {
				order: 5 !important
			}

			.order-xxl-last {
				order: 6 !important
			}

			.m-xxl-0 {
				margin: 0 !important
			}

			.m-xxl-1 {
				margin: .25rem !important
			}

			.m-xxl-2 {
				margin: .5rem !important
			}

			.m-xxl-3 {
				margin: 1rem !important
			}

			.m-xxl-4 {
				margin: 1.5rem !important
			}

			.m-xxl-5 {
				margin: 3rem !important
			}

			.m-xxl-auto {
				margin: auto !important
			}

			.mx-xxl-0 {
				margin-right: 0 !important;
				margin-left: 0 !important
			}

			.mx-xxl-1 {
				margin-right: .25rem !important;
				margin-left: .25rem !important
			}

			.mx-xxl-2 {
				margin-right: .5rem !important;
				margin-left: .5rem !important
			}

			.mx-xxl-3 {
				margin-right: 1rem !important;
				margin-left: 1rem !important
			}

			.mx-xxl-4 {
				margin-right: 1.5rem !important;
				margin-left: 1.5rem !important
			}

			.mx-xxl-5 {
				margin-right: 3rem !important;
				margin-left: 3rem !important
			}

			.mx-xxl-auto {
				margin-right: auto !important;
				margin-left: auto !important
			}

			.my-xxl-0 {
				margin-top: 0 !important;
				margin-bottom: 0 !important
			}

			.my-xxl-1 {
				margin-top: .25rem !important;
				margin-bottom: .25rem !important
			}

			.my-xxl-2 {
				margin-top: .5rem !important;
				margin-bottom: .5rem !important
			}

			.my-xxl-3 {
				margin-top: 1rem !important;
				margin-bottom: 1rem !important
			}

			.my-xxl-4 {
				margin-top: 1.5rem !important;
				margin-bottom: 1.5rem !important
			}

			.my-xxl-5 {
				margin-top: 3rem !important;
				margin-bottom: 3rem !important
			}

			.my-xxl-auto {
				margin-top: auto !important;
				margin-bottom: auto !important
			}

			.mt-xxl-0 {
				margin-top: 0 !important
			}

			.mt-xxl-1 {
				margin-top: .25rem !important
			}

			.mt-xxl-2 {
				margin-top: .5rem !important
			}

			.mt-xxl-3 {
				margin-top: 1rem !important
			}

			.mt-xxl-4 {
				margin-top: 1.5rem !important
			}

			.mt-xxl-5 {
				margin-top: 3rem !important
			}

			.mt-xxl-auto {
				margin-top: auto !important
			}

			.me-xxl-0 {
				margin-right: 0 !important
			}

			.me-xxl-1 {
				margin-right: .25rem !important
			}

			.me-xxl-2 {
				margin-right: .5rem !important
			}

			.me-xxl-3 {
				margin-right: 1rem !important
			}

			.me-xxl-4 {
				margin-right: 1.5rem !important
			}

			.me-xxl-5 {
				margin-right: 3rem !important
			}

			.me-xxl-auto {
				margin-right: auto !important
			}

			.mb-xxl-0 {
				margin-bottom: 0 !important
			}

			.mb-xxl-1 {
				margin-bottom: .25rem !important
			}

			.mb-xxl-2 {
				margin-bottom: .5rem !important
			}

			.mb-xxl-3 {
				margin-bottom: 1rem !important
			}

			.mb-xxl-4 {
				margin-bottom: 1.5rem !important
			}

			.mb-xxl-5 {
				margin-bottom: 3rem !important
			}

			.mb-xxl-auto {
				margin-bottom: auto !important
			}

			.ms-xxl-0 {
				margin-left: 0 !important
			}

			.ms-xxl-1 {
				margin-left: .25rem !important
			}

			.ms-xxl-2 {
				margin-left: .5rem !important
			}

			.ms-xxl-3 {
				margin-left: 1rem !important
			}

			.ms-xxl-4 {
				margin-left: 1.5rem !important
			}

			.ms-xxl-5 {
				margin-left: 3rem !important
			}

			.ms-xxl-auto {
				margin-left: auto !important
			}

			.p-xxl-0 {
				padding: 0 !important
			}

			.p-xxl-1 {
				padding: .25rem !important
			}

			.p-xxl-2 {
				padding: .5rem !important
			}

			.p-xxl-3 {
				padding: 1rem !important
			}

			.p-xxl-4 {
				padding: 1.5rem !important
			}

			.p-xxl-5 {
				padding: 3rem !important
			}

			.px-xxl-0 {
				padding-right: 0 !important;
				padding-left: 0 !important
			}

			.px-xxl-1 {
				padding-right: .25rem !important;
				padding-left: .25rem !important
			}

			.px-xxl-2 {
				padding-right: .5rem !important;
				padding-left: .5rem !important
			}

			.px-xxl-3 {
				padding-right: 1rem !important;
				padding-left: 1rem !important
			}

			.px-xxl-4 {
				padding-right: 1.5rem !important;
				padding-left: 1.5rem !important
			}

			.px-xxl-5 {
				padding-right: 3rem !important;
				padding-left: 3rem !important
			}

			.py-xxl-0 {
				padding-top: 0 !important;
				padding-bottom: 0 !important
			}

			.py-xxl-1 {
				padding-top: .25rem !important;
				padding-bottom: .25rem !important
			}

			.py-xxl-2 {
				padding-top: .5rem !important;
				padding-bottom: .5rem !important
			}

			.py-xxl-3 {
				padding-top: 1rem !important;
				padding-bottom: 1rem !important
			}

			.py-xxl-4 {
				padding-top: 1.5rem !important;
				padding-bottom: 1.5rem !important
			}

			.py-xxl-5 {
				padding-top: 3rem !important;
				padding-bottom: 3rem !important
			}

			.pt-xxl-0 {
				padding-top: 0 !important
			}

			.pt-xxl-1 {
				padding-top: .25rem !important
			}

			.pt-xxl-2 {
				padding-top: .5rem !important
			}

			.pt-xxl-3 {
				padding-top: 1rem !important
			}

			.pt-xxl-4 {
				padding-top: 1.5rem !important
			}

			.pt-xxl-5 {
				padding-top: 3rem !important
			}

			.pe-xxl-0 {
				padding-right: 0 !important
			}

			.pe-xxl-1 {
				padding-right: .25rem !important
			}

			.pe-xxl-2 {
				padding-right: .5rem !important
			}

			.pe-xxl-3 {
				padding-right: 1rem !important
			}

			.pe-xxl-4 {
				padding-right: 1.5rem !important
			}

			.pe-xxl-5 {
				padding-right: 3rem !important
			}

			.pb-xxl-0 {
				padding-bottom: 0 !important
			}

			.pb-xxl-1 {
				padding-bottom: .25rem !important
			}

			.pb-xxl-2 {
				padding-bottom: .5rem !important
			}

			.pb-xxl-3 {
				padding-bottom: 1rem !important
			}

			.pb-xxl-4 {
				padding-bottom: 1.5rem !important
			}

			.pb-xxl-5 {
				padding-bottom: 3rem !important
			}

			.ps-xxl-0 {
				padding-left: 0 !important
			}

			.ps-xxl-1 {
				padding-left: .25rem !important
			}

			.ps-xxl-2 {
				padding-left: .5rem !important
			}

			.ps-xxl-3 {
				padding-left: 1rem !important
			}

			.ps-xxl-4 {
				padding-left: 1.5rem !important
			}

			.ps-xxl-5 {
				padding-left: 3rem !important
			}

			.gap-xxl-0 {
				gap: 0 !important
			}

			.gap-xxl-1 {
				gap: .25rem !important
			}

			.gap-xxl-2 {
				gap: .5rem !important
			}

			.gap-xxl-3 {
				gap: 1rem !important
			}

			.gap-xxl-4 {
				gap: 1.5rem !important
			}

			.gap-xxl-5 {
				gap: 3rem !important
			}

			.text-xxl-start {
				text-align: left !important
			}

			.text-xxl-end {
				text-align: right !important
			}

			.text-xxl-center {
				text-align: center !important
			}
		}

		@media (min-width:1200px) {
			.fs-1 {
				font-size: 2.5rem !important
			}

			.fs-2 {
				font-size: 2rem !important
			}

			.fs-3 {
				font-size: 1.75rem !important
			}

			.fs-4 {
				font-size: 1.5rem !important
			}
		}

		@media print {
			.d-print-inline {
				display: inline !important
			}

			.d-print-inline-block {
				display: inline-block !important
			}

			.d-print-block {
				display: block !important
			}

			.d-print-grid {
				display: grid !important
			}

			.d-print-table {
				display: table !important
			}

			.d-print-table-row {
				display: table-row !important
			}

			.d-print-table-cell {
				display: table-cell !important
			}

			.d-print-flex {
				display: flex !important
			}

			.d-print-inline-flex {
				display: inline-flex !important
			}

			.d-print-none {
				display: none !important
			}
		}

		/*mob_min*/

		a,
		a:focus,
		a:hover {
			text-decoration: none;
			color: inherit
		}

		.dl-menuwrapper {
			width: 200px;
			z-index: 999;
			max-width: 300px;
			float: left;
			position: relative;
			-webkit-perspective: 1000px;
			perspective: 1000px;
			-webkit-perspective-origin: 50% 200%;
			perspective-origin: 50% 200%
		}

		.dl-menuwrapper button {
			background: url(https://www.blazon.in/assets/images/menu_close.png) no-repeat;
			border: 0;
			width: 100%;
			height: 28px;
			overflow: unset;
			position: relative;
			cursor: pointer;
			outline: 0;
			color: #181818;
			padding: 0;
			font-size: 16px;
			text-align: left;
			position: relative;
			background-position: center right !important;
			display: inline-block;
			background-size: contain !important
		}

		.dl-menuwrapper button.dl-active {
			background: url(https://www.blazon.in/assets/images/menu_open.png) no-repeat;
			background-size: 25px !important;
			background-position: center right 0 !important
		}

		.dl-menuwrapper ul {
			background: #fff;
			color: #181818
		}

		.dl-menuwrapper ul {
			padding: 0;
			list-style: none;
			-webkit-transform-style: preserve-3d;
			transform-style: preserve-3d;
			box-shadow: 0 0 30px rgb(0 0 0 / 10%);
			top: 45px;
			border-radius: 6px
		}

		.dl-menuwrapper li {
			position: relative
		}

		.dl-menuwrapper li a {
			display: block;
			position: relative;
			padding: 10px 20px 10px 20px;
			font-size: 16px;
			line-height: 20px;
			font-weight: 300;
			color: #000;
			outline: 0
		}

		.no-touch .dl-menuwrapper li a:hover {
			background: #1b1b1b
		}

		.dl-menuwrapper li a:hover {
			background: #1b1b1b;
			color: #fff
		}

		.dl-menuwrapper li.dl-back>a {
			padding-left: 40px;
			background: #000;
			color: #fff
		}

		.dl-menuwrapper li.dl-back:after,
		.dl-menuwrapper li>a:not(:only-child):after {
			position: absolute;
			top: 50%;
			line-height: 40px;
			font-family: icomoon;
			speak: none;
			-webkit-font-smoothing: antialiased;
			content: "";
			background: url(https://www.blazon.in/assets/images/arrow_1.png) no-repeat;
			height: 15px;
			width: 15px;
			right: 10px;
			transform: translate(0, -50%) rotate(270deg);
			filter: brightness(0)
		}

		.dl-menuwrapper li.dl-back:after {
			left: 10px;
			color: #fff;
			-webkit-transform: rotate(180deg);
			transform: rotate(180deg);
			top: 50%;
			filter: brightness(0) invert(1);
			transform: translate(0, -50%) rotate(90deg)
		}

		.dl-menuwrapper li>a:after {
			right: 10px;
			color: #181818
		}

		.dl-menuwrapper li>a:hover:after {
			right: 10px;
			color: #fff;
			filter: brightness(0) invert(1)
		}

		.dl-menuwrapper .dl-menu {
			margin: 0;
			position: absolute;
			width: 100%;
			padding: 0;
			opacity: 0;
			pointer-events: none;
			-webkit-transform: translateY(10px);
			transform: translateY(10px);
			-webkit-backface-visibility: hidden;
			backface-visibility: hidden
		}

		.dl-menuwrapper li .dl-submenu {
			max-height: 380px;
			overflow: auto
		}

		.dl-menuwrapper li .dl-submenu::-webkit-scrollbar {
			width: 6px;
			z-index: 100
		}

		.dl-menuwrapper li .dl-submenu::-webkit-scrollbar-track {
			background: #f1f1f1;
			z-index: 100
		}

		.dl-menuwrapper li .dl-submenu::-webkit-scrollbar-thumb {
			background: #000;
			border-radius: 0;
			z-index: 100
		}

		.dl-menuwrapper li .dl-submenu::-webkit-scrollbar-thumb:hover {
			background: #555;
			z-index: 100
		}

		.dl-menuwrapper .dl-menu.dl-menu-toggle {
			transition: all .3s ease
		}

		.dl-menuwrapper .dl-menu.dl-menuopen {
			opacity: 1;
			pointer-events: auto;
			-webkit-transform: translateY(0);
			transform: translateY(0);
			top: 140%
		}

		.dl-menuwrapper li .dl-submenu {
			display: none
		}

		.dl-menu.dl-subview li,
		.dl-menu.dl-subview li.dl-subview>a,
		.dl-menu.dl-subview li.dl-subviewopen>a {
			display: none
		}

		.dl-menu.dl-subview li.dl-subview,
		.dl-menu.dl-subview li.dl-subview .dl-submenu,
		.dl-menu.dl-subview li.dl-subviewopen,
		.dl-menu.dl-subview li.dl-subviewopen>.dl-submenu,
		.dl-menu.dl-subview li.dl-subviewopen>.dl-submenu>li {
			display: block
		}

		.dl-menuwrapper>.dl-submenu {
			position: absolute;
			width: 100%;
			top: 50px;
			left: 0;
			margin: 0
		}

		.dl-menu.dl-animate-out-1 {
			-webkit-animation: MenuAnimOut1 .4s;
			animation: MenuAnimOut1 .4s
		}

		.dl-menu.dl-animate-out-2 {
			-webkit-animation: MenuAnimOut2 .3s ease-in-out;
			animation: MenuAnimOut2 .3s ease-in-out
		}

		.dl-menu.dl-animate-out-3 {
			-webkit-animation: MenuAnimOut3 .4s ease;
			animation: MenuAnimOut3 .4s ease
		}

		.dl-menu.dl-animate-out-4 {
			-webkit-animation: MenuAnimOut4 .4s ease;
			animation: MenuAnimOut4 .4s ease
		}

		.dl-menu.dl-animate-out-5 {
			-webkit-animation: MenuAnimOut5 .4s ease;
			animation: MenuAnimOut5 .4s ease
		}

		@-webkit-keyframes MenuAnimOut1 {
			50% {
				-webkit-transform: translateZ(-250px) rotateY(30deg)
			}

			75% {
				-webkit-transform: translateZ(-372.5px) rotateY(15deg);
				opacity: .5
			}

			100% {
				-webkit-transform: translateZ(-500px) rotateY(0);
				opacity: 0
			}
		}

		@-webkit-keyframes MenuAnimOut2 {
			100% {
				-webkit-transform: translateX(-100%);
				opacity: 0
			}
		}

		@-webkit-keyframes MenuAnimOut3 {
			100% {
				-webkit-transform: translateZ(300px);
				opacity: 0
			}
		}

		@-webkit-keyframes MenuAnimOut4 {
			100% {
				-webkit-transform: translateZ(-300px);
				opacity: 0
			}
		}

		@-webkit-keyframes MenuAnimOut5 {
			100% {
				-webkit-transform: translateY(40%);
				opacity: 0
			}
		}

		@keyframes MenuAnimOut1 {
			50% {
				-webkit-transform: translateZ(-250px) rotateY(30deg);
				transform: translateZ(-250px) rotateY(30deg)
			}

			75% {
				-webkit-transform: translateZ(-372.5px) rotateY(15deg);
				transform: translateZ(-372.5px) rotateY(15deg);
				opacity: .5
			}

			100% {
				-webkit-transform: translateZ(-500px) rotateY(0);
				transform: translateZ(-500px) rotateY(0);
				opacity: 0
			}
		}

		@keyframes MenuAnimOut2 {
			100% {
				-webkit-transform: translateX(-100%);
				transform: translateX(-100%);
				opacity: 0
			}
		}

		@keyframes MenuAnimOut3 {
			100% {
				-webkit-transform: translateZ(300px);
				transform: translateZ(300px);
				opacity: 0
			}
		}

		@keyframes MenuAnimOut4 {
			100% {
				-webkit-transform: translateZ(-300px);
				transform: translateZ(-300px);
				opacity: 0
			}
		}

		@keyframes MenuAnimOut5 {
			100% {
				-webkit-transform: translateY(40%);
				transform: translateY(40%);
				opacity: 0
			}
		}

		.dl-menu.dl-animate-in-1 {
			-webkit-animation: MenuAnimIn1 .3s;
			animation: MenuAnimIn1 .3s
		}

		.dl-menu.dl-animate-in-2 {
			-webkit-animation: MenuAnimIn2 .3s ease-in-out;
			animation: MenuAnimIn2 .3s ease-in-out
		}

		.dl-menu.dl-animate-in-3 {
			-webkit-animation: MenuAnimIn3 .4s ease;
			animation: MenuAnimIn3 .4s ease
		}

		.dl-menu.dl-animate-in-4 {
			-webkit-animation: MenuAnimIn4 .4s ease;
			animation: MenuAnimIn4 .4s ease
		}

		.dl-menu.dl-animate-in-5 {
			-webkit-animation: MenuAnimIn5 .4s ease;
			animation: MenuAnimIn5 .4s ease
		}

		@-webkit-keyframes MenuAnimIn1 {
			0 {
				-webkit-transform: translateZ(-500px) rotateY(0);
				opacity: 0
			}

			20% {
				-webkit-transform: translateZ(-250px) rotateY(30deg);
				opacity: .5
			}

			100% {
				-webkit-transform: translateZ(0) rotateY(0);
				opacity: 1
			}
		}

		@-webkit-keyframes MenuAnimIn2 {
			0 {
				-webkit-transform: translateX(-100%);
				opacity: 0
			}

			100% {
				-webkit-transform: translateX(0);
				opacity: 1
			}
		}

		@-webkit-keyframes MenuAnimIn3 {
			0 {
				-webkit-transform: translateZ(300px);
				opacity: 0
			}

			100% {
				-webkit-transform: translateZ(0);
				opacity: 1
			}
		}

		@-webkit-keyframes MenuAnimIn4 {
			0 {
				-webkit-transform: translateZ(-300px);
				opacity: 0
			}

			100% {
				-webkit-transform: translateZ(0);
				opacity: 1
			}
		}

		@-webkit-keyframes MenuAnimIn5 {
			0 {
				-webkit-transform: translateY(40%);
				opacity: 0
			}

			100% {
				-webkit-transform: translateY(0);
				opacity: 1
			}
		}

		@keyframes MenuAnimIn1 {
			0 {
				-webkit-transform: translateZ(-500px) rotateY(0);
				transform: translateZ(-500px) rotateY(0);
				opacity: 0
			}

			20% {
				-webkit-transform: translateZ(-250px) rotateY(30deg);
				transform: translateZ(-250px) rotateY(30deg);
				opacity: .5
			}

			100% {
				-webkit-transform: translateZ(0) rotateY(0);
				transform: translateZ(0) rotateY(0);
				opacity: 1
			}
		}

		@keyframes MenuAnimIn2 {
			0 {
				-webkit-transform: translateX(-100%);
				transform: translateX(-100%);
				opacity: 0
			}

			100% {
				-webkit-transform: translateX(0);
				transform: translateX(0);
				opacity: 1
			}
		}

		@keyframes MenuAnimIn3 {
			0 {
				-webkit-transform: translateZ(300px);
				transform: translateZ(300px);
				opacity: 0
			}

			100% {
				-webkit-transform: translateZ(0);
				transform: translateZ(0);
				opacity: 1
			}
		}

		@keyframes MenuAnimIn4 {
			0 {
				-webkit-transform: translateZ(-300px);
				transform: translateZ(-300px);
				opacity: 0
			}

			100% {
				-webkit-transform: translateZ(0);
				transform: translateZ(0);
				opacity: 1
			}
		}

		@keyframes MenuAnimIn5 {
			0 {
				-webkit-transform: translateY(40%);
				transform: translateY(40%);
				opacity: 0
			}

			100% {
				-webkit-transform: translateY(0);
				transform: translateY(0);
				opacity: 1
			}
		}

		.dl-menuwrapper>.dl-submenu.dl-animate-in-1 {
			-webkit-animation: SubMenuAnimIn1 .4s ease;
			animation: SubMenuAnimIn1 .4s ease
		}

		.dl-menuwrapper>.dl-submenu.dl-animate-in-2 {
			-webkit-animation: SubMenuAnimIn2 .3s ease-in-out;
			animation: SubMenuAnimIn2 .3s ease-in-out
		}

		.dl-menuwrapper>.dl-submenu.dl-animate-in-3 {
			-webkit-animation: SubMenuAnimIn3 .4s ease;
			animation: SubMenuAnimIn3 .4s ease
		}

		.dl-menuwrapper>.dl-submenu.dl-animate-in-4 {
			-webkit-animation: SubMenuAnimIn4 .4s ease;
			animation: SubMenuAnimIn4 .4s ease
		}

		.dl-menuwrapper>.dl-submenu.dl-animate-in-5 {
			-webkit-animation: SubMenuAnimIn5 .4s ease;
			animation: SubMenuAnimIn5 .4s ease
		}

		@-webkit-keyframes SubMenuAnimIn1 {
			0 {
				-webkit-transform: translateX(50%);
				opacity: 0
			}

			100% {
				-webkit-transform: translateX(0);
				opacity: 1
			}
		}

		@-webkit-keyframes SubMenuAnimIn2 {
			0 {
				-webkit-transform: translateX(100%);
				opacity: 0
			}

			100% {
				-webkit-transform: translateX(0);
				opacity: 1
			}
		}

		@-webkit-keyframes SubMenuAnimIn3 {
			0 {
				-webkit-transform: translateZ(-300px);
				opacity: 0
			}

			100% {
				-webkit-transform: translateZ(0);
				opacity: 1
			}
		}

		@-webkit-keyframes SubMenuAnimIn4 {
			0 {
				-webkit-transform: translateZ(300px);
				opacity: 0
			}

			100% {
				-webkit-transform: translateZ(0);
				opacity: 1
			}
		}

		@-webkit-keyframes SubMenuAnimIn5 {
			0 {
				-webkit-transform: translateZ(-200px);
				opacity: 0
			}

			100% {
				-webkit-transform: translateZ(0);
				opacity: 1
			}
		}

		@keyframes SubMenuAnimIn1 {
			0 {
				-webkit-transform: translateX(50%);
				transform: translateX(50%);
				opacity: 0
			}

			100% {
				-webkit-transform: translateX(0);
				transform: translateX(0);
				opacity: 1
			}
		}

		@keyframes SubMenuAnimIn2 {
			0 {
				-webkit-transform: translateX(100%);
				transform: translateX(100%);
				opacity: 0
			}

			100% {
				-webkit-transform: translateX(0);
				transform: translateX(0);
				opacity: 1
			}
		}

		@keyframes SubMenuAnimIn3 {
			0 {
				-webkit-transform: translateZ(-300px);
				transform: translateZ(-300px);
				opacity: 0
			}

			100% {
				-webkit-transform: translateZ(0);
				transform: translateZ(0);
				opacity: 1
			}
		}

		@keyframes SubMenuAnimIn4 {
			0 {
				-webkit-transform: translateZ(300px);
				transform: translateZ(300px);
				opacity: 0
			}

			100% {
				-webkit-transform: translateZ(0);
				transform: translateZ(0);
				opacity: 1
			}
		}

		@keyframes SubMenuAnimIn5 {
			0 {
				-webkit-transform: translateZ(-200px);
				transform: translateZ(-200px);
				opacity: 0
			}

			100% {
				-webkit-transform: translateZ(0);
				transform: translateZ(0);
				opacity: 1
			}
		}

		.dl-menuwrapper>.dl-submenu.dl-animate-out-1 {
			-webkit-animation: SubMenuAnimOut1 .4s ease;
			animation: SubMenuAnimOut1 .4s ease
		}

		.dl-menuwrapper>.dl-submenu.dl-animate-out-2 {
			-webkit-animation: SubMenuAnimOut2 .3s ease-in-out;
			animation: SubMenuAnimOut2 .3s ease-in-out
		}

		.dl-menuwrapper>.dl-submenu.dl-animate-out-3 {
			-webkit-animation: SubMenuAnimOut3 .4s ease;
			animation: SubMenuAnimOut3 .4s ease
		}

		.dl-menuwrapper>.dl-submenu.dl-animate-out-4 {
			-webkit-animation: SubMenuAnimOut4 .4s ease;
			animation: SubMenuAnimOut4 .4s ease
		}

		.dl-menuwrapper>.dl-submenu.dl-animate-out-5 {
			-webkit-animation: SubMenuAnimOut5 .4s ease;
			animation: SubMenuAnimOut5 .4s ease
		}

		@-webkit-keyframes SubMenuAnimOut1 {
			0 {
				-webkit-transform: translateX(0);
				opacity: 1
			}

			100% {
				-webkit-transform: translateX(50%);
				opacity: 0
			}
		}

		@-webkit-keyframes SubMenuAnimOut2 {
			0 {
				-webkit-transform: translateX(0);
				opacity: 1
			}

			100% {
				-webkit-transform: translateX(100%);
				opacity: 0
			}
		}

		@-webkit-keyframes SubMenuAnimOut3 {
			0 {
				-webkit-transform: translateZ(0);
				opacity: 1
			}

			100% {
				-webkit-transform: translateZ(-300px);
				opacity: 0
			}
		}

		@-webkit-keyframes SubMenuAnimOut4 {
			0 {
				-webkit-transform: translateZ(0);
				opacity: 1
			}

			100% {
				-webkit-transform: translateZ(300px);
				opacity: 0
			}
		}

		@-webkit-keyframes SubMenuAnimOut5 {
			0 {
				-webkit-transform: translateZ(0);
				opacity: 1
			}

			100% {
				-webkit-transform: translateZ(-200px);
				opacity: 0
			}
		}

		@keyframes SubMenuAnimOut1 {
			0 {
				-webkit-transform: translateX(0);
				transform: translateX(0);
				opacity: 1
			}

			100% {
				-webkit-transform: translateX(50%);
				transform: translateX(50%);
				opacity: 0
			}
		}

		@keyframes SubMenuAnimOut2 {
			0 {
				-webkit-transform: translateX(0);
				transform: translateX(0);
				opacity: 1
			}

			100% {
				-webkit-transform: translateX(100%);
				transform: translateX(100%);
				opacity: 0
			}
		}

		@keyframes SubMenuAnimOut3 {
			0 {
				-webkit-transform: translateZ(0);
				transform: translateZ(0);
				opacity: 1
			}

			100% {
				-webkit-transform: translateZ(-300px);
				transform: translateZ(-300px);
				opacity: 0
			}
		}

		@keyframes SubMenuAnimOut4 {
			0 {
				-webkit-transform: translateZ(0);
				transform: translateZ(0);
				opacity: 1
			}

			100% {
				-webkit-transform: translateZ(300px);
				transform: translateZ(300px);
				opacity: 0
			}
		}

		@keyframes SubMenuAnimOut5 {
			0 {
				-webkit-transform: translateZ(0);
				transform: translateZ(0);
				opacity: 1
			}

			100% {
				-webkit-transform: translateZ(-200px);
				transform: translateZ(-200px);
				opacity: 0
			}
		}

		.no-js .dl-menuwrapper .dl-menu {
			position: relative;
			opacity: 1;
			-webkit-transform: none;
			transform: none
		}

		.no-js .dl-menuwrapper li .dl-submenu {
			display: block
		}

		.no-js .dl-menuwrapper li.dl-back {
			display: none
		}

		.no-js .dl-menuwrapper li>a:not(:only-child) {
			background: rgba(0, 0, 0, .1)
		}

		.no-js .dl-menuwrapper li>a:not(:only-child):after {
			content: ''
		}

		.demo-1 .dl-menuwrapper button {
			background: #c62860
		}

		.demo-1 .dl-menuwrapper button.dl-active,
		.demo-1 .dl-menuwrapper button:hover,
		.demo-1 .dl-menuwrapper ul {
			background: #9e1847
		}

		.demo-2 .dl-menuwrapper button {
			background: #e86814
		}

		.demo-2 .dl-menuwrapper button.dl-active,
		.demo-2 .dl-menuwrapper button:hover,
		.demo-2 .dl-menuwrapper ul {
			background: #d35400
		}

		.demo-3 .dl-menuwrapper button {
			background: #08cbc4
		}

		.demo-3 .dl-menuwrapper button.dl-active,
		.demo-3 .dl-menuwrapper button:hover,
		.demo-3 .dl-menuwrapper ul {
			background: #00b4ae
		}

		.demo-4 .dl-menuwrapper button {
			background: #90b912
		}

		.demo-4 .dl-menuwrapper button.dl-active,
		.demo-4 .dl-menuwrapper button:hover,
		.demo-4 .dl-menuwrapper ul {
			background: #79a002
		}

		.demo-5 .dl-menuwrapper button {
			background: #744783
		}

		.demo-5 .dl-menuwrapper button.dl-active,
		.demo-5 .dl-menuwrapper button:hover,
		.demo-5 .dl-menuwrapper ul {
			background: #643771
		}

		/*style*/
		img {
			height: auto;
			width: auto;
		}

		:root {
			--bg_full: #ee8f0a;
			--black: #1f2229;
			--bg_light: hwb(111deg 0 33% / 6%);
			--bg50: hwb(35deg 4% 7% / 50%);
			--bg15: hwb(35deg 4% 7% / 15%);
			--bg70: hwb(35deg 4% 7% / 70%);
			--bg10: hwb(35deg 4% 7% / 10%);
			--bg20: hwb(35deg 4% 7% / 20%);
			--bg40: hwb(35deg 4% 7% / 40%);
			--bg30: hwb(35deg 4% 7% / 30%);
			--gray: #888;
			--bold: "s_bold", "o_bold";
			--medium: "s_medium", "o_medium";
			--light: "s_light", "o_light";
			--regular: "s_regular", "o_regular";
			--semibold: "s_semibold", "o_semibold";
			--black: "s_black";
			--border: #d1d1d1
		}

		@font-face {
			font-family: 'o_bold';
			src: url('<?php echo esc_url(get_template_directory_uri()); ?>/assets/fonts/OpenSans-Bold.woff2') format('woff2'), url('<?php echo esc_url(get_template_directory_uri()); ?>/assets/fonts/OpenSans-Bold.woff') format('woff');
			font-weight: bold;
			font-style: normal;
			font-display: swap
		}

		@font-face {
			font-family: 'o_light';
			src: url('<?php echo esc_url(get_template_directory_uri()); ?>/assets/fonts/OpenSans-Light.woff2') format('woff2'), url('<?php echo esc_url(get_template_directory_uri()); ?>/assets/fonts/OpenSans-Light.woff') format('woff');
			font-weight: 300;
			font-style: normal;
			font-display: swap
		}

		@font-face {
			font-family: 'o_medium';
			src: url('<?php echo esc_url(get_template_directory_uri()); ?>/assets/fonts/OpenSans-Medium.woff2') format('woff2'), url('<?php echo esc_url(get_template_directory_uri()); ?>/assets/fonts/OpenSans-Medium.woff') format('woff');
			font-weight: 500;
			font-style: normal;
			font-display: swap
		}

		@font-face {
			font-family: 'o_semibold';
			src: url('<?php echo esc_url(get_template_directory_uri()); ?>/assets/fonts/OpenSans-SemiBold.woff2') format('woff2'), url('<?php echo esc_url(get_template_directory_uri()); ?>/assets/fonts/OpenSans-SemiBold.woff') format('woff');
			font-weight: 600;
			font-style: normal;
			font-display: swap
		}

		@font-face {
			font-family: 'o_regular';
			src: url('<?php echo esc_url(get_template_directory_uri()); ?>/assets/fonts/OpenSans-Regular.woff2') format('woff2'), url('<?php echo esc_url(get_template_directory_uri()); ?>/assets/fonts/OpenSans-Regular.woff') format('woff');
			font-weight: normal;
			font-style: normal;
			font-display: swap
		}

		@font-face {
			font-family: 's_black';
			src: url('<?php echo esc_url(get_template_directory_uri()); ?>/assets/fonts/SourceSansPro-Black.woff2') format('woff2'), url('<?php echo esc_url(get_template_directory_uri()); ?>/assets/fonts/SourceSansPro-Black.woff') format('woff');
			font-weight: 900;
			font-style: normal;
			font-display: swap
		}

		@font-face {
			font-family: 's_extralight';
			src: url('<?php echo esc_url(get_template_directory_uri()); ?>/assets/fonts/SourceSansPro-ExtraLight.woff2') format('woff2'), url('<?php echo esc_url(get_template_directory_uri()); ?>/assets/fonts/SourceSansPro-ExtraLight.woff') format('woff');
			font-weight: 200;
			font-style: normal;
			font-display: swap
		}

		@font-face {
			font-family: 's_bold';
			src: url('<?php echo esc_url(get_template_directory_uri()); ?>/assets/fonts/SourceSansPro-Bold.woff2') format('woff2'), url('<?php echo esc_url(get_template_directory_uri()); ?>/assets/fonts/SourceSansPro-Bold.woff') format('woff');
			font-weight: bold;
			font-style: normal;
			font-display: swap
		}

		@font-face {
			font-family: 's_italic';
			src: url('<?php echo esc_url(get_template_directory_uri()); ?>/assets/fonts/SourceSansPro-Italic.woff2') format('woff2'), url('<?php echo esc_url(get_template_directory_uri()); ?>/assets/fonts/SourceSansPro-Italic.woff') format('woff');
			font-weight: normal;
			font-style: italic;
			font-display: swap
		}

		@font-face {
			font-family: 's_light';
			src: url('<?php echo esc_url(get_template_directory_uri()); ?>/assets/fonts/SourceSansPro-Light.woff2') format('woff2'), url('<?php echo esc_url(get_template_directory_uri()); ?>/assets/fonts/SourceSansPro-Light.woff') format('woff');
			font-weight: 300;
			font-style: normal;
			font-display: swap
		}

		@font-face {
			font-family: 's_medium';
			src: url('<?php echo esc_url(get_template_directory_uri()); ?>/assets/fonts/SourceSansPro-Regular.woff2') format('woff2'), url('<?php echo esc_url(get_template_directory_uri()); ?>/assets/fonts/SourceSansPro-Regular.woff') format('woff');
			font-weight: normal;
			font-style: normal;
			font-display: swap
		}

		@font-face {
			font-family: 's_regular';
			src: url('<?php echo esc_url(get_template_directory_uri()); ?>/assets/fonts/SourceSansPro-Regular.woff2') format('woff2'), url('<?php echo esc_url(get_template_directory_uri()); ?>/assets/fonts/SourceSansPro-Regular.woff') format('woff');
			font-weight: normal;
			font-style: normal;
			font-display: swap
		}

		@font-face {
			font-family: 's_semibold';
			src: url('<?php echo esc_url(get_template_directory_uri()); ?>/assets/fonts/SourceSansPro-SemiBold.woff2') format('woff2'), url('<?php echo esc_url(get_template_directory_uri()); ?>/assets/fonts/SourceSansPro-SemiBold.woff') format('woff');
			font-weight: 600;
			font-style: normal;
			font-display: swap
		}

		html,
		body,
		div,
		span,
		object,
		iframe,
		h1,
		h2,
		h3,
		h4,
		h5,
		h6,
		p,
		blockquote,
		pre,
		abbr,
		address,
		cite,
		code,
		del,
		dfn,
		em,
		img,
		ins,
		kbd,
		q,
		samp,
		small,
		strong,
		sub,
		sup,
		var,
		b,
		i,
		dl,
		dt,
		dd,
		ol,
		ul,
		li,
		fieldset,
		form,
		label,
		legend,
		table,
		caption,
		tbody,
		tfoot,
		thead,
		tr,
		th,
		td,
		article,
		aside,
		canvas,
		details,
		figcaption,
		figure,
		footer,
		header,
		hgroup,
		menu,
		nav,
		section,
		summary,
		time,
		mark,
		audio,
		video {
			margin: 0;
			padding: 0;
			border: 0;
			outline: 0;
			font-size: 100%;
			vertical-align: baseline;
			background: transparent;
			font-family: 's_regular'
		}

		body {
			line-height: 1;
			background: #f5f5f5
		}

		* {
			word-wrap: break-word
		}

		article,
		aside,
		details,
		figcaption,
		figure,
		footer,
		header,
		hgroup,
		menu,
		nav,
		section {
			display: block
		}

		ul {
			list-style: none
		}

		blockquote,
		q {
			quotes: none
		}

		blockquote:before,
		blockquote:after,
		q:before,
		q:after {
			content: '';
			content: none
		}

		button {
			outline: none !important;
			cursor: pointer
		}

		a,
		a:hover,
		a:focus,
		a:active {
			font-size: 100%;
			vertical-align: baseline;
			background: transparent;
			text-decoration: none !important;
			color: inherit;
			cursor: pointer
		}

		ins {
			background-color: #ff9;
			color: #000;
			text-decoration: none
		}

		mark {
			background-color: #ff9;
			color: #000;
			font-style: italic;
			font-weight: bold
		}

		del {
			text-decoration: line-through
		}

		abbr[title],
		dfn[title] {
			border-bottom: 1px dotted;
			cursor: help
		}

		table {
			border-collapse: collapse;
			border-spacing: 0
		}

		hr {
			display: block;
			height: 1px;
			border: 0;
			border-top: 1px solid #ccc;
			margin: 1em 0;
			padding: 0
		}

		* {
			cursor: url("https://www.blazon.in/assets/images/cursor.png"), auto
		}

		input,
		select {
			vertical-align: middle
		}

		img {
			max-width: 100%;
			display: block
		}

		.wrapper {
			max-width: 1200px;
			padding: 0 10px;
			margin: 0 auto
		}

		.header_section {
			width: 100%;
			display: inline-block;
			position: fixed;
			top: 0;
			left: 0;
			z-index: 1000;
			padding: 20px 0
		}

		.header_section .wrapper_full {
			padding: 0 25px
		}

		.header_section .header_align {
			display: flex;
			flex-wrap: wrap;
			align-items: center;
			justify-content: space-between;
			width: 100%;
			height: 55px
		}

		.header_section .header_align .header_left {
			width: fit-content;
			display: inline-block
		}

		.header_section .header_align .header_left img {
			height: 47px
		}

		.header_section .header_align .header_right {
			display: flex;
			align-items: center;
			gap: 0;
			position: absolute;
			top: 50%;
			left: 50%;
			transform: translate(-50%, -50%);
			width: fit-content
		}

		.header_section .header_align .header_right .get_quote {
			width: fit-content;
			display: inline-block;
			position: relative
		}

		.header_section .header_align .header_icon {
			display: inline-block;
			width: fit-content;
			position: relative
		}

		.header_section .header_align .header_icon ul {
			list-style: none;
			display: flex;
			align-items: center;
			gap: 16px
		}

		.header_section .header_align .header_icon ul img {
			filter: brightness(0) invert(1);
			height: auto;
			margin: auto
		}

		.header_section .header_align .header_icon ul li a {
			display: flex;
			align-items: center;
			justify-content: center;
			border: 1px solid #fff;
			height: 40px;
			width: 40px;
			border-radius: 100%;
			padding: 10px
		}

		.header_section .header_align .header_icon ul li a:hover {
			border: 1px solid var(--bg_full)
		}

		.header_section .header_align .header_icon ul li a:hover img {
			filter: inherit
		}

		.header_section {
			transition: all .1s ease-in-out
		}

		.header_section.dark_header {
			padding: 10px 0;
			transition: all .1s ease-in-out;
			background: #1b1b1b;
			z-index: 1000;
			position: fixed;
		}

		#cssmenu,
		#cssmenu ul,
		#cssmenu ul li,
		#cssmenu ul li a,
		#cssmenu #menu-button {
			padding: 0;
			border: 0;
			list-style: none;
			line-height: 1;
			display: block;
			position: relative;
			box-sizing: border-box;
			z-index: 1000
		}

		#cssmenu:after,
		#cssmenu ul:after {
			content: ".";
			display: block;
			clear: both;
			visibility: hidden;
			line-height: 0;
			height: 0
		}

		#cssmenu #menu-button {
			display: none
		}

		#cssmenu {
			text-align: center;
			width: -webkit-fit-content;
			width: -moz-fit-content;
			width: fit-content;
			margin: auto auto auto auto;
			display: flex
		}

		#cssmenu ul li {
			align-items: center;
			display: flex;
			margin: 0
		}

		#cssmenu ul li img {
			height: 135px
		}

		#cssmenu.align-center ul {
			font-size: 0;
			text-align: center
		}

		#cssmenu.align-center ul li {
			display: inline-block;
			float: none
		}

		#cssmenu.align-center ul ul {
			text-align: left
		}

		#cssmenu.align-right ul li {
			float: right
		}

		#cssmenu ul>li>a {
			padding: 5px 15px;
			font-size: 18px;
			display: flex;
			text-decoration: none;
			color: #fff;
			margin: auto 0 auto 0;
			line-height: 1.5;
			position: relative;
			transition: all .2s ease;
			font-family: var(--regular);
			position: relative
		}

		#cssmenu ul>li:last-child {
			margin: 0
		}

		#cssmenu ul>li:last-child a {
			margin: 0
		}

		#cssmenu>ul {
			width: 100%;
			margin: auto;
			display: flex
		}

		#cssmenu>ul>li>a:hover {
			color: var(--bg_full)
		}

		#cssmenu ul li.has-sub:hover {
			color: var(--bg_full)
		}

		#cssmenu ul li.has-sub:hover span.submenu-button {
			filter: inherit
		}

		#cssmenu>ul>li.has-sub:hover>a:after {
			filter: inherit
		}

		#cssmenu ul ul {
			position: absolute;
			left: -9999px;
			background: 0;
			z-index: 10;
			padding: 0;
			width: 230px;
			background: #f5f5f5;
			box-shadow: 0 2px 5px #2e2e2e26;
			top: 100%;
			border-bottom: 0 solid var(--bg_full)
		}

		.custom_mega_menu {
			width: 1180px;
			background: #f5f5f5;
			position: absolute;
			left: -518px;
			top: 0;
			z-index: 100;
			box-shadow: 0 0 18px rgb(0 0 0 / 15%)
		}

		.custom_mega_menu h2 {
			font-size: 23px;
			width: 100%;
			padding: 13px 20px;
			text-align: center;
			border-bottom: 1px solid var(--border);
			font-family: var(--bold);
			color: #000
		}

		.mega_menu_footer {
			display: flex;
			align-items: center;
			justify-content: space-between;
			gap: 20px;
			border-top: 1px solid var(--border);
			padding: 12px 30px
		}

		.mega_menu_footer .mega_menu_footer_left {
			width: fit-content;
			display: flex;
			align-items: center;
			justify-content: center;
			gap: 15px;
			font-size: 18px;
			font-family: var(--bold);
			color: #000
		}

		.mega_menu_footer .mega_menu_footer_left a {
			display: flex !important;
			align-items: center;
			gap: 9px;
			font-size: 16px;
			font-family: var(--regular);
			color: #000
		}

		.mega_menu_footer .mega_menu_footer_right {
			width: fit-content;
			display: flex;
			align-items: center;
			justify-content: center;
			gap: 15px;
			font-size: 18px;
			font-family: var(--bold);
			color: #000
		}

		.mega_menu_footer img {
			height: 26px !important
		}

		.custom_mega_menu .custom_mega_menu_align {
			padding: 35px 35px;
			display: flex;
			align-items: flex-start;
			justify-content: space-between
		}

		.custom_mega_menu .custom_mega_menu_align .custom_mega_menu_box {
			display: flex;
			flex-direction: column;
			width: fit-content
		}

		.custom_mega_menu .custom_mega_menu_align .custom_mega_menu_box h4 {
			text-align: left;
			font-size: 18px;
			font-family: var(--bold);
			color: #000;
			padding: 0 0 10px;
			position: relative;
			margin: 0 0 15px
		}

		.custom_mega_menu .custom_mega_menu_align .custom_mega_menu_box h4::before {
			content: "";
			position: absolute;
			height: 2px;
			width: 40px;
			background: var(--bg_full);
			bottom: 0;
			left: 0
		}

		.custom_mega_menu .custom_mega_menu_align p {
			line-height: 1.8;
			margin: 0 0 3px;
			display: inline-block;
			text-align: left;
			width: fit-content;
			color: #000;
			font-size: 15px
		}

		.custom_mega_menu .custom_mega_menu_align p a {
			display: inline-block !important;
			position: relative !important;
			width: fit-content !important;
			padding: 0 0 0 32px !important
		}

		.custom_mega_menu .custom_mega_menu_align p a:hover {
			color: var(--bg_full)
		}

		.custom_mega_menu .custom_mega_menu_align p a:hover::before {
			filter: brightness(0) invert(61%) sepia(99%) saturate(739%) hue-rotate(345deg) brightness(89%) contrast(112%)
		}

		.custom_mega_menu .custom_mega_menu_align p a::before {
			content: "";
			position: absolute;
			background: url("https://www.blazon.in/assets/images/menu/custom-web-development.png")no-repeat;
			height: 18px;
			width: 18px;
			background-position: center left !important;
			background-size: contain !important;
			top: 1px;
			left: 0
		}

		#cssmenu ul ul.about_menu li {
			padding: 7px 15px !important
		}

		#cssmenu ul ul.about_menu a {
			padding: 0 0 0 32px !important;
			border: 0 !important
		}

		#cssmenu ul ul.about_menu a::before {
			content: "";
			position: absolute;
			background: url("https://www.blazon.in/assets/images/menu/custom-web-development.png")no-repeat;
			height: 18px;
			width: 18px;
			background-position: center left !important;
			background-size: contain !important;
			top: 4px;
			left: 0
		}

		#cssmenu ul ul.about_menu {
			padding: 12px 0
		}

		#cssmenu ul ul.about_menu a.ab_1::before {
			background: url("https://www.blazon.in/assets/images/menu/aboutus.png")no-repeat
		}

		#cssmenu ul ul.about_menu a.ab_2::before {
			background: url("https://www.blazon.in/assets/images/menu/leadership.png")no-repeat
		}

		#cssmenu ul ul.about_menu a.ab_3::before {
			background: url("https://www.blazon.in/assets/images/menu/client-supprot.png")no-repeat
		}

		#cssmenu ul ul.about_menu a.ab_4::before {
			background: url("https://www.blazon.in/assets/images/menu/case-studies.png")no-repeat
		}

		.custom_mega_menu .custom_mega_menu_align p a.ds_1::before {
			background: url("https://www.blazon.in/assets/images/menu/web-development.png")no-repeat
		}

		.custom_mega_menu .custom_mega_menu_align p a.ds_2::before {
			background: url("https://www.blazon.in/assets/images/menu/custom-web-development.png")no-repeat
		}

		.custom_mega_menu .custom_mega_menu_align p a.ds_3::before {
			background: url("https://www.blazon.in/assets/images/menu/mobile-app-development.png")no-repeat
		}

		.custom_mega_menu .custom_mega_menu_align p a.ds_4::before {
			background: url("https://www.blazon.in/assets/images/menu/ecommerce-development.png")no-repeat
		}

		.custom_mega_menu .custom_mega_menu_align p a.ds_5::before {
			background: url("https://www.blazon.in/assets/images/menu/web-portal-development.png")no-repeat
		}

		.custom_mega_menu .custom_mega_menu_align p a.ds_6::before {
			background: url("https://www.blazon.in/assets/images/menu/software-migration-re-engineering.png")no-repeat
		}

		.custom_mega_menu .custom_mega_menu_align p a.ds_7::before {
			background: url("https://www.blazon.in/assets/images/menu/software-support.png")no-repeat
		}

		.custom_mega_menu .custom_mega_menu_align p a.ds_8::before {
			background: url("https://www.blazon.in/assets/images/menu/software-testing.png")no-repeat
		}

		.custom_mega_menu .custom_mega_menu_align p a.ds_9::before {
			background: url("https://www.blazon.in/assets/images/menu/php-development.png")no-repeat
		}

		.custom_mega_menu .custom_mega_menu_align p a.ds_10::before {
			background: url("https://www.blazon.in/assets/images/menu/react-development.png")no-repeat
		}

		.custom_mega_menu .custom_mega_menu_align p a.des_1::before {
			background: url("https://www.blazon.in/assets/images/menu/logo-design.png")no-repeat
		}

		.custom_mega_menu .custom_mega_menu_align p a.des_2::before {
			background: url("https://www.blazon.in/assets/images/menu/printing-design.png")no-repeat
		}

		.custom_mega_menu .custom_mega_menu_align p a.des_3::before {
			background: url("https://www.blazon.in/assets/images/menu/packing-design.png")no-repeat
		}

		.custom_mega_menu .custom_mega_menu_align p a.des_4::before {
			background: url("https://www.blazon.in/assets/images/menu/ui-ux.png")no-repeat
		}

		.custom_mega_menu .custom_mega_menu_align p a.dm_1::before {
			background: url("https://www.blazon.in/assets/images/menu/search-engine-marketing.png")no-repeat
		}

		.custom_mega_menu .custom_mega_menu_align p a.dm_2::before {
			background: url("https://www.blazon.in/assets/images/menu/seo.png")no-repeat
		}

		.custom_mega_menu .custom_mega_menu_align p a.dm_3::before {
			background: url("https://www.blazon.in/assets/images/menu/social-media-marketing.png")no-repeat
		}

		.custom_mega_menu .custom_mega_menu_align p a.dm_4::before {
			background: url("https://www.blazon.in/assets/images/menu/social-media-optimisation.png")no-repeat
		}

		.custom_mega_menu .custom_mega_menu_align p a.dm_5::before {
			background: url("https://www.blazon.in/assets/images/menu/email-marketing.png")no-repeat
		}

		.custom_mega_menu .custom_mega_menu_align p a.ws_1::before {
			background: url("https://www.blazon.in/assets/images/menu/domain-register.png")no-repeat
		}

		.custom_mega_menu .custom_mega_menu_align p a.ws_2::before {
			background: url("https://www.blazon.in/assets/images/menu/web-hosting.png")no-repeat
		}

		.custom_mega_menu .custom_mega_menu_align p a.ws_3::before {
			background: url("https://www.blazon.in/assets/images/menu/web-maintenance.png")no-repeat
		}

		.custom_mega_menu .custom_mega_menu_align p:last-child {
			margin: 0
		}

		#cssmenu.align-right ul ul {
			text-align: right
		}

		#cssmenu ul ul li {
			height: 0;
			transition: all .25s ease
		}

		#cssmenu li:hover>ul {
			left: auto
		}

		#cssmenu.align-right li:hover>ul {
			left: auto;
			right: 0
		}

		#cssmenu li:hover>ul>li {
			height: auto;
			width: 100%
		}

		#cssmenu ul ul ul {
			margin-left: 100%;
			top: 0
		}

		#cssmenu.align-right ul ul ul {
			margin-left: 0;
			margin-right: 100%
		}

		#cssmenu ul ul li {
			background: 0
		}

		#cssmenu ul ul li:nth-child(1) {
			padding: 0
		}

		#cssmenu ul ul ul li:nth-child(1) {
			padding: 0
		}

		#cssmenu ul ul li a {
			border-bottom: 0 solid rgba(150, 150, 150, 0.15);
			padding: 10px 30px 10px 15px;
			z-index: 100;
			text-align: left;
			margin-top: 0;
			width: 100%;
			line-height: 1.5;
			font-family: var(--medium);
			letter-spacing: 0;
			font-size: 15px;
			text-decoration: none;
			background: #f5f5f5;
			margin: 0;
			border-bottom: 1px solid #f5f5f5;
			color: #060606
		}

		#cssmenu ul ul li {
			cursor: pointer
		}

		#cssmenu ul li.has-sub {
			padding: 0
		}

		#cssmenu ul li.has-sub ul li {
			padding: 0
		}

		#cssmenu ul ul li:last-child>a,
		#cssmenu ul ul li.last-item>a {
			border-bottom: 0
		}

		#cssmenu ul ul li:hover>a,
		#cssmenu ul ul li a:hover {
			color: var(--bg_full)
		}

		#cssmenu ul ul li a:hover::before {
			filter: brightness(0) invert(61%) sepia(99%) saturate(739%) hue-rotate(345deg) brightness(89%) contrast(112%)
		}

		#cssmenu ul ul li.has-sub>a:before {
			position: absolute;
			top: 45%;
			right: 7px;
			width: 10px;
			background-size: contain !important;
			height: 8px;
			display: block;
			content: '';
			background: url('https://www.blazon.in/assets/images/menu_arrow.png')no-repeat;
			transform: rotate(270deg) translate(0, -50%);
			background-position: center right
		}

		#cssmenu.align-right ul ul li.has-sub>a:before {
			right: auto;
			left: 14px
		}

		#cssmenu ul ul>li.has-sub:hover>a:before {
			-webkit-filter: brightness(0) invert(1);
			filter: brightness(0) invert(1)
		}

		#cssmenu ul ul li.bottom_zero ul {
			top: auto;
			bottom: 0
		}

		.slider_section {
			width: 100%;
			display: inline-block;
			margin: 0 0 60px;
			position: relative
		}

		.slider_section::before {
			content: "";
			position: absolute;
			background: linear-gradient(to bottom, rgb(0 0 0 / 60%), transparent);
			height: 100%;
			width: 100%
		}

		.slider_section video {
			width: 100%;
			height: 100vh;
			object-fit: cover
		}

		.slider_section .item_content {
			position: absolute;
			width: 100%;
			max-width: 900px;
			text-align: center;
			display: flex;
			flex-direction: column;
			gap: 25px;
			bottom: 35px;
			left: 50%;
			transform: translate(-50%, 0)
		}

		.slider_section .item_content h2 {
			font-size: 45px;
			text-align: center;
			color: #fff;
			line-height: 1.3;
			font-family: var(--semibold)
		}

		.think_big_section {
			width: 100%;
			display: inline-block;
			margin: 60px 0;
			overflow: hidden
		}

		.think_big_section .think_big_align {
			display: flex;
			align-items: center;
			justify-content: space-between;
			flex-wrap: wrap;
			width: 100%
		}

		.think_big_section .think_big_align .think_big_left {
			width: 40%;
			display: inline-block
		}

		.think_big_section .think_big_align .think_big_right {
			width: 50%;
			display: inline-block;
			position: relative;
			padding: 10px 0 0 0
		}

		.think_big_section .think_big_align .think_big_left h1,
		.think_big_section .think_big_align .think_big_left h1 span {
			font-size: 80px;
			font-family: var(--black);
			text-transform: uppercase;
			line-height: 1
		}

		.think_big_section .think_big_align .think_big_left h1 span {
			color: var(--bg_full)
		}

		.think_big_section .think_big_align .think_big_left h4 {
			margin: 22px 0;
			line-height: 1.5;
			font-family: var(--bold);
			color: #000;
			font-size: 32px
		}

		.think_big_section .think_big_align .think_big_left p {
			font-size: 18px;
			line-height: 26px;
			font-family: var(--regular);
			margin: 0 0 20px
		}

		.think_big_section .think_big_align .think_big_left a {
			width: fit-content;
			display: inline-block
		}

		.unique_btn {
			position: relative;
			padding: 20px 85px 20px 0vw;
			display: flex;
			text-decoration: none !important;
			font-size: 22px;
			line-height: 24px;
			color: #000;
			font-family: var(--bold);
			border: 0;
			background: 0;
			align-items: center;
			width: auto
		}

		.unique_btn span {
			color: #000;
			font-family: var(--bold);
			font-size: 20px;
			line-height: 24px
		}

		.unique_btn .arrow {
			position: absolute;
			height: 55px;
			width: 55px;
			border: 1px solid var(--border);
			top: 50%;
			right: 0;
			transform: translate(0, -50%);
			display: flex;
			align-items: center;
			justify-content: center;
			border-radius: 100%;
			transition: all .3s ease-in-out
		}

		.unique_btn:hover .arrow {
			transform: translate(0, -50%) scale(1.2);
			transition: all .3s ease-in-out
		}

		.unique_btn .arrow img {
			height: 10px
		}

		.think_big_section .think_big_align .think_big_right .think_box {
			width: 100%;
			display: inline-block
		}

		.think_big_section .think_big_align .think_big_right .think_box .think_box_head {
			width: 100%;
			display: inline-block;
			margin: 0 0 10px
		}

		.think_big_section .think_big_align .think_big_right .think_box .think_box_head h4 {
			font-size: 25px;
			font-family: var(--bold);
			line-height: 1.5;
			text-transform: uppercase
		}

		.think_big_section .think_big_align .think_big_right .think_box .think_box_image {
			width: 100%;
			display: inline-block;
			padding: 0 0 30px
		}

		.think_big_section .think_big_align .think_big_right .think_box .think_box_image img {
			width: 100%;
			display: inline-block
		}

		.think_big_section .think_big_align .think_big_right .think_box .think_box_image ul {
			display: grid;
			grid-template-columns: repeat(4, 1fr);
			gap: 20px;
			position: absolute;
			bottom: 3px;
			left: 0;
			padding: 0 30px
		}

		.think_big_section .think_big_align .think_big_right .think_box .think_box_image ul li {
			width: 100%;
			display: flex;
			border-radius: 100%;
			position: relative;
			z-index: 10;
			display: flex;
			align-items: center;
			justify-content: center;
			text-align: center;
			font-size: 12px;
			font-weight: 700;
			line-height: 1.4;
			border: 0 solid var(--bg_full)
		}

		.think_big_section .think_big_align .think_big_right .think_box .think_box_image ul li a {
			width: 100%;
			display: flex;
			border-radius: 100%
		}

		.think_big_section .think_big_align .think_big_right .think_box .think_box_image ul li a img {
			border-radius: 100%
		}

		.think_big_section .think_big_align .think_big_right .think_box .think_box_image ul li p {
			position: absolute;
			font-size: 12px;
			height: 100%;
			width: 100%;
			align-items: center;
			justify-content: center;
			display: flex;
			padding: 13px;
			text-transform: uppercase
		}

		.think_big_section .think_big_align .think_big_right .think_box .think_box_image ul li:last-child() p {
			padding: 22px
		}

		.think_slider_next,
		.think_slider_prev {
			height: 42px;
			width: 42px;
			border: 1px solid var(--border);
			border-radius: 100%;
			background: url("https://www.blazon.in/assets/images/nav.png")no-repeat;
			display: flex;
			align-items: center;
			justify-content: center;
			background-position: center center;
			background-size: 9px
		}

		.think_slider_next {
			transform: rotate(180deg)
		}

		.think_slider_prev.swiper-button-disabled {
			cursor: not-allowed;
			opacity: .4
		}

		.think_slider_next.swiper-button-disabled {
			cursor: not-allowed;
			opacity: .4
		}

		.think_slider_nav {
			display: flex;
			align-items: center;
			gap: 12px;
			position: absolute;
			top: 0;
			right: 40px;
			z-index: 10
		}

		.think_slider_nav a {
			display: flex;
			border-radius: 100%
		}

		.think_big_right .swiper-slide {
			opacity: 0
		}

		.think_big_right .swiper-slide.swiper-slide-visible.swiper-slide-active {
			background: #f5f5f5;
			opacity: 1
		}

		.expertise_section {
			margin: 60px 0;
			display: inline-block;
			position: relative;
			width: 100%
		}

		.head_text {
			width: 100%;
			display: flex;
			position: relative;
			flex-direction: column;
			gap: 20px
		}

		.head_text h2,
		.head_text h1 {
			font-size: 35px;
			font-family: var(--bold);
			text-align: center;
			display: flex;
			margin: auto;
			position: relative;
			line-height: 1.2;
			text-transform: uppercase;
			padding: 0 5px 0 5px
		}

		.head_text h2::before,
		.head_text h1::before {
			content: "";
			position: absolute;
			height: 15px;
			background: var(--bg_full);
			bottom: 0;
			left: 0;
			right: 0;
			z-index: -1
		}

		.head_text p,
		.head_text h6 {
			text-align: center;
			max-width: 65%;
			margin: auto;
			font-size: 18px;
			line-height: 26px;
			font-family: var(--regular)
		}

		.expertise_section .head_text {
			margin: 0 0 55px
		}

		.expertise_section ul {
			display: grid;
			grid-template-columns: repeat(3, 1fr);
			gap: 30px;
			width: 100%
		}

		.expertise_section ul.ul_service_mobile {
			display: none
		}

		.expertise_section ul li {
			padding: 35px 35px 50px;
			background: #fff;
			width: 100%;
			display: inline-block;
			position: relative;
			transition: all .4s ease-in-out
		}

		.expertise_section ul li .expertise {
			width: 100%;
			display: flex;
			flex-wrap: wrap;
			height: 100%;
			gap: 20px;
			position: relative;
			justify-content: space-between;
			transition: all .4s ease-in-out
		}

		.expertise_section ul li .expertise .e_icon {
			width: fit-content;
			display: inline-block;
			margin: auto
		}

		.expertise_section ul li .expertise .e_icon img {
			height: 60px;
			width: fit-content
		}

		.expertise_section ul li .expertise h4 {
			font-size: 23px;
			font-family: var(--bold);
			text-transform: uppercase;
			width: 100%
		}

		.expertise_section ul li .expertise p {
			font-size: 18px;
			line-height: 26px;
			font-family: var(--regular);
			min-height: 130px
		}

		.expertise_section ul li .expertise .e_btn {
			width: 100%;
			display: inline-block;
			margin: auto 0 0 0
		}

		.expertise_section ul li .expertise .e_btn .unique_btn span {
			font-size: 18px
		}

		.expertise_section ul li .expertise .e_btn .unique_btn .arrow {
			height: 45px;
			width: 45px
		}

		.expertise_section ul li .expertise .e_btn .unique_btn {
			padding: 15px 70px 15px 0vw
		}

		.expertise_section ul li .e_hover {
			position: absolute;
			top: 0;
			left: 0;
			height: 100%;
			width: 100%;
			padding: 40px 40px;
			display: flex;
			flex-direction: column;
			gap: 20px;
			background: #fff;
			overflow-y: auto;
			opacity: 0;
			display: none;
			transition: all .4s ease-in-out
		}

		.expertise_section ul li:hover .e_hover {
			opacity: 1;
			transition: all .4s ease-in-out
		}

		.expertise_section ul li .e_hover::before {
			content: "";
			background: rgb(0 0 0 / 75%);
			height: 100%;
			width: 100%;
			position: absolute;
			top: 0;
			left: 0;
			z-index: 6
		}

		.expertise_section ul li .e_hover::after {
			content: "";
			z-index: 7;
			top: 12px;
			left: 12px;
			bottom: 12px;
			right: 12px;
			border: 1px solid #fff;
			position: absolute
		}

		.expertise_section ul li .e_hover img {
			position: absolute;
			z-index: 5;
			height: 100%;
			width: 100%;
			top: 0;
			left: 0
		}

		.expertise_section ul li .e_hover h4 {
			position: relative;
			z-index: 10;
			font-size: 24px;
			line-height: 1.4;
			color: #fff;
			text-transform: uppercase;
			font-family: var(--semibold)
		}

		.expertise_section ul li .e_hover ul {
			display: flex;
			flex-direction: column;
			gap: 10px;
			z-index: 10
		}

		.expertise_section ul li .e_hover ul li {
			padding: 0;
			background: transparent;
			line-height: 1.5;
			color: #fff;
			font-size: 17px;
			font-family: var(--regular);
			padding: 0 0 0 22px
		}

		.expertise_section ul li .e_hover ul li::before {
			content: "";
			height: 6px;
			width: 6px;
			border-radius: 100%;
			position: absolute;
			top: 10px;
			left: 0;
			background: #fff
		}

		.expertise_section ul li .e_hover button {
			padding: 10px 30px;
			border: 2px solid var(--bg_full);
			color: #fff;
			font-size: 18px;
			position: relative;
			z-index: 10;
			background: transparent;
			margin: 20px 0 0 0
		}

		.expertise_section ul li .e_hover::-webkit-scrollbar {
			width: 6px;
			z-index: 100
		}

		.expertise_section ul li .e_hover::-webkit-scrollbar-track {
			background: #f1f1f1;
			z-index: 100
		}

		.expertise_section ul li .e_hover::-webkit-scrollbar-thumb {
			background: var(--bg_full);
			border-radius: 0;
			z-index: 100
		}

		.expertise_section ul li .e_hover::-webkit-scrollbar-thumb:hover {
			background: #555;
			z-index: 100
		}

		.footer_section {
			margin: 60px 0 0 0;
			display: inline-block;
			width: 100%;
			position: relative
		}

		.footer_section .footer_top {
			background: #35353e;
			position: relative;
			width: 100%;
			display: inline-block;
			padding: 60px 0
		}

		.footer_section .footer_top .footer_align {
			display: grid;
			align-items: flex-start;
			justify-content: space-between;
			grid-template-columns: repeat(2, 1fr);
			gap: 35px
		}

		.footer_section .footer_top .footer_align h4 {
			color: #fff;
			font-size: 19px;
			font-family: var(--medium);
			line-height: 1.5;
			position: relative;
			width: 100%;
			padding: 0 0 12px;
			margin: 0 0 15px
		}

		.footer_section .footer_top .footer_align h4::before {
			content: "";
			border-bottom: 1px solid rgba(255, 255, 255, 0.15);
			position: absolute;
			bottom: 0;
			left: 0;
			width: 100%;
			height: 1px
		}

		.footer_section .footer_top .footer_align p {
			color: rgba(255, 255, 255, 0.75);
			font-family: var(--light);
			font-size: 15px;
			line-height: 1.4;
			margin: 0 0 6px;
			padding: 0 20px 0 0
		}

		.footer_section .footer_top .footer_align p:last-child {
			margin: 0
		}

		.footer_section .footer_top .footer_align .footer_left ul {
			display: grid;
			grid-template-columns: repeat(2, 1fr);
			gap: 35px
		}

		.footer_section .footer_top .footer_align .footer_right img {
			margin: 50px auto 0 auto
		}

		.footer_section .footer_bottom {
			background: #292930;
			color: rgba(255, 255, 255, 0.65);
			padding: 60px 0
		}

		.footer_section .footer_bottom .footer_bottom_align {
			display: flex;
			align-items: flex-start;
			flex-wrap: wrap;
			justify-content: space-between;
			width: 100%
		}

		.footer_section .footer_bottom .footer_bottom_align .footer_bottom_left {
			width: 77%;
			display: inline-block
		}

		.footer_section .footer_bottom .footer_bottom_align .footer_bottom_right {
			width: fit-content;
			display: inline-block
		}

		.footer_section .footer_bottom .footer_bottom_align h4 {
			color: rgba(255, 255, 255, 0.65);
			font-size: 18px;
			font-family: var(--medium);
			line-height: 1.5;
			position: relative;
			width: 100%;
			padding: 0 0 12px;
			margin: 0 0 15px
		}

		.footer_section .footer_bottom .footer_bottom_align h4::before {
			content: "";
			border-bottom: 1px solid rgba(255, 255, 255, 0.15);
			position: absolute;
			bottom: 0;
			left: 0;
			width: 100%;
			height: 1px
		}

		.footer_section .footer_bottom .footer_bottom_align p {
			color: rgba(255, 255, 255, 0.75);
			font-family: var(--light);
			font-size: 15px;
			line-height: 1.4;
			margin: 0 0 6px;
			padding: 0 35px 0 0
		}

		.footer_section .footer_bottom .footer_bottom_align .footer_bottom_left ul {
			display: grid;
			grid-template-columns: repeat(4, 1fr);
			gap: 30px
		}

		.copy_text {
			background: #292930;
			color: rgba(255, 255, 255, 0.65);
			border-top: 1px solid rgba(255, 255, 255, 0.15);
			padding: 10px 0
		}

		.copy_text .copy_align {
			display: flex;
			align-items: center;
			justify-content: space-between;
			gap: 20px;
			flex-wrap: wrap;
			position: relative;
			width: 100%
		}

		.copy_text .copy_align .copy_left {
			width: fit-content;
			display: inline-block
		}

		.copy_text .copy_align .copy_right {
			width: fit-content;
			display: inline-block
		}

		.copy_text .copy_align .copy_left p {
			font-family: var(--light);
			font-size: 15px;
			line-height: 1.5
		}

		.copy_text .copy_align .copy_right ul {
			display: flex;
			align-items: center;
			gap: 15px
		}

		.copy_text .copy_align .copy_right ul li {
			font-size: 15px;
			font-family: var(--light)
		}

		.f_social_media {
			display: flex;
			align-items: center;
			gap: 22px;
			color: rgba(255, 255, 255, 0.45);
			margin: 18px 0 0 0;
			font-weight: 300;
			font-family: var(--light)
		}

		.blazon_process {
			background: #1b1b1b;
			padding: 80px 0;
			margin: 60px 0;
			width: 100%;
			display: inline-block
		}

		.blazon_process .head_text {
			margin: 0 0 65px
		}

		.blazon_process .head_text h2 text {
			color: #fff;
			position: relative;
			z-index: 2
		}

		.blazon_process .head_text h2::before {
			background: #585858;
			z-index: 1
		}

		.blazon_process .head_text h6 {
			color: #fff
		}

		.process_top_items {
			display: none
		}

		.blazon_process .blazon_process_tab {
			width: 100%;
			display: inline-block;
			position: relative
		}

		.blazon_process .blazon_process_tab .blazon_process_top {
			margin: 0 0 50px;
			width: 100%;
			display: inline-block
		}

		.blazon_process .blazon_process_tab .blazon_process_top ul {
			display: flex;
			align-items: flex-end;
			padding: 0 0 10px;
			border-bottom: 1px solid rgba(255, 255, 255, .15);
			color: #fff;
			flex-wrap: wrap;
			gap: 25px 45px;
			justify-content: center
		}

		.blazon_process .blazon_process_tab .blazon_process_top ul li a {
			padding: 5px;
			font-size: 18px;
			text-transform: uppercase;
			font-family: var(--semibold);
			display: inline-block;
			position: relative
		}

		.blazon_process .blazon_process_tab .blazon_process_top ul li.active a {
			color: var(--bg_full)
		}

		.blazon_process .blazon_process_tab .blazon_process_top ul li a::before {
			content: "";
			position: absolute;
			background: transparent;
			height: 4px;
			width: 100%;
			bottom: -11px;
			left: 0
		}

		.blazon_process .blazon_process_tab .blazon_process_top ul li.active a::before {
			background: var(--bg_full)
		}

		.blazon_process .blazon_process_tab .process_top_items_align {
			display: flex;
			align-items: center;
			width: 100%;
			flex-wrap: wrap;
			justify-content: space-between
		}

		.blazon_process .blazon_process_tab .process_top_items_align .process_top_items_left {
			width: 45%;
			display: inline-block;
			padding: 0
		}

		.blazon_process .blazon_process_tab .process_top_items_align .process_top_items_right {
			width: 45%;
			display: inline-block
		}

		.blazon_process .blazon_process_tab .process_top_items_align .process_top_items_left h4 {
			font-size: 45px;
			font-family: var(--bold);
			line-height: 1.3;
			margin: 0 0 25px;
			color: #fff
		}

		.blazon_process .blazon_process_tab .process_top_items_align .process_top_items_left p {
			font-size: 18px;
			line-height: 26px;
			font-family: var(--light);
			color: #fff;
			margin: 0 0 15px
		}

		.blazon_process .blazon_process_tab .process_top_items_align .process_top_items_left p:last-child {
			margin: 0
		}

		.ourclients_section {
			width: 100%;
			display: inline-block;
			margin: 60px 0;
			position: relative
		}

		.ourclients_section .head_text {
			margin: 0 0 55px
		}

		.ourclients_section ul {
			display: grid;
			grid-template-columns: repeat(5, 1fr);
			gap: 40px 25px
		}

		.ourclients_section ul li {
			box-shadow: 0 0 15px rgb(0 0 0 / 5%);
			width: 100%;
			display: flex;
			padding: 15px 15px;
			background: #fff;
			align-items: center;
			justify-content: center;
			height: 150px
		}

		.our_technologies {
			margin: 60px 0;
			display: inline-block;
			position: relative;
			width: 100%
		}

		.our_technologies .head_text {
			margin: 0 0 65px
		}

		.our_technologies ul {
			overflow: hidden
		}

		.our_technologies ul li {
			display: flex;
			flex-direction: column;
			gap: 25px;
			text-align: center
		}

		.our_technologies ul li img {
			margin: auto;
			height: 100px;
			width: 100px;
			object-fit: contain;
			cursor: auto
		}

		.our_technologies ul li h4 {
			text-align: center;
			font-family: var(--bold);
			font-size: 18px;
			text-transform: uppercase
		}

		.our_milestones {
			margin: 60px 0;
			display: inline-block;
			padding: 80px 0;
			background: #1b1b1b;
			width: 100%
		}

		.our_milestones .head_text {
			margin: 0 0 65px
		}

		.our_milestones .head_text h2 text {
			color: #fff;
			position: relative;
			z-index: 2
		}

		.our_milestones .head_text h2::before {
			background: #585858;
			z-index: 1
		}

		.our_milestones .head_text h6 {
			color: #fff
		}

		.our_milestones .our_milestones_align {
			display: flex;
			align-items: center;
			justify-content: space-between;
			width: 100%;
			flex-wrap: wrap
		}

		.our_milestones .our_milestones_align .our_milestones_left {
			width: 45%;
			display: inline-block
		}

		.our_milestones .our_milestones_align .our_milestones_right {
			width: 45%;
			display: inline-block
		}

		.our_milestones .our_milestones_align .our_milestones_right p {
			font-size: 18px;
			line-height: 26px;
			font-family: var(--light);
			color: #fff;
			margin: 0
		}

		.our_milestones .our_milestones_align .our_milestones_right ul {
			display: grid;
			grid-template-columns: repeat(2, 1fr);
			gap: 45px 40px;
			margin: 25px 0 0 0
		}

		.our_milestones .our_milestones_align .our_milestones_right ul li {
			width: 100%;
			display: inline-block;
			border-bottom: 1px solid var(--bg_full);
			padding: 0 0 15px
		}

		.our_milestones .our_milestones_align .our_milestones_right ul li h4 {
			font-family: var(--semibold);
			font-size: 50px;
			color: #fff;
			margin: 0 0 5px
		}

		.our_milestones .our_milestones_align .our_milestones_right ul li h4.plus::after {
			content: "+"
		}

		.our_milestones .our_milestones_align .our_milestones_right ul li h4.persentage::after {
			content: "%"
		}

		.our_milestones .our_milestones_align .our_milestones_right ul li p {
			font-family: var(--light)
		}

		.why_choose_blazon {
			display: inline-block;
			margin: 60px 0;
			width: 100%
		}

		.why_choose_blazon .head_text {
			margin: 0 0 55px
		}

		.why_choose_content {
			display: none
		}

		.why_choose_blazon .why_choose_align {
			display: flex;
			align-items: center;
			justify-content: space-between;
			width: 100%;
			flex-wrap: wrap;
			position: relative
		}

		.why_choose_blazon .why_choose_align .why_choose_left {
			width: 47%;
			display: inline-block
		}

		.why_choose_blazon .why_choose_align .why_choose_right {
			width: 47%;
			display: inline-block
		}

		.why_choose_blazon .why_choose_align .why_choose_left .why_choose_top {
			width: 100%;
			display: inline-block;
			margin: 0 0 40px
		}

		.why_choose_blazon .why_choose_align .why_choose_left .why_choose_top ul {
			display: grid;
			grid-template-columns: repeat(3, 1fr);
			width: 100%;
			position: relative;
			text-align: center;
			border-bottom: 3px solid #e4ecf1
		}

		.why_choose_blazon .why_choose_align .why_choose_left .why_choose_top ul li {
			width: 100%;
			display: inline-block
		}

		.why_choose_blazon .why_choose_align .why_choose_left .why_choose_top ul li a {
			padding: 15px;
			position: relative;
			width: 100%;
			display: inline-block;
			font-size: 20px;
			font-family: var(--bold);
			color: #000;
			text-transform: uppercase
		}

		.why_choose_blazon .why_choose_align .why_choose_left .why_choose_top ul li a::before {
			content: "";
			position: absolute;
			height: 3px;
			width: 100%;
			background: transparent;
			left: 0;
			bottom: -3px
		}

		.why_choose_blazon .why_choose_align .why_choose_left .why_choose_top ul li a::after {
			content: "";
			width: 0;
			height: 0;
			margin: 0;
			border-left: 6px solid transparent;
			border-right: 6px solid transparent;
			border-top: 10px solid transparent;
			position: absolute;
			bottom: -10px;
			left: 50%;
			transform: translate(-50%, 0)
		}

		.why_choose_blazon .why_choose_align .why_choose_left .why_choose_top ul li.active a::after {
			border-top: 10px solid var(--bg_full)
		}

		.why_choose_blazon .why_choose_align .why_choose_left .why_choose_top ul li.active a::before {
			background: var(--bg_full)
		}

		.why_choose_blazon .why_choose_align .why_choose_left .why_choose_top ul li.active a {
			color: var(--bg_full)
		}

		.why_choose_blazon .why_choose_align .why_choose_left .why_choose_bottom {
			width: 100%;
			display: inline-block
		}

		.why_choose_blazon .why_choose_align .why_choose_left .why_choose_bottom h2 {
			font-size: 35px;
			text-transform: uppercase;
			color: var(--bg_full);
			font-family: var(--bold);
			margin: 0 0 30px
		}

		.why_choose_blazon .why_choose_align .why_choose_left .why_choose_bottom h2 span {
			font-size: 35px;
			text-transform: capitalize;
			color: #000;
			font-family: var(--medium)
		}

		.why_choose_blazon .why_choose_align .why_choose_left .why_choose_bottom ul {
			display: flex;
			flex-direction: column;
			gap: 29px
		}

		.why_choose_blazon .why_choose_align .why_choose_left .why_choose_bottom ul li {
			font-size: 18px;
			line-height: 26px;
			color: #4a4a4a;
			position: relative;
			padding: 0 0 0 35px
		}

		.why_choose_blazon .why_choose_align .why_choose_left .why_choose_bottom ul li::before {
			content: "";
			position: absolute;
			background: url(https://www.blazon.in/assets/images/list.png)no-repeat;
			height: 19px;
			width: 19px;
			border-radius: 100%;
			background-size: contain;
			top: 5px;
			left: 0
		}

		.brands_trust_section {
			display: inline-block;
			margin: 60px 0;
			width: 100%;
			position: relative
		}

		.brands_trust_section .head_text {
			margin: 0 0 55px
		}

		.brands_trust_section .brands_trust_align {
			display: flex;
			width: 100%;
			align-items: center;
			justify-content: space-between;
			position: relative
		}

		.brands_trust_section .brands_trust_align .brands_trust_left {
			width: 45%;
			display: inline-block
		}

		.brands_trust_section .brands_trust_align .brands_trust_right {
			width: 40%;
			display: inline-block
		}

		.faq_answer {
			display: none
		}

		.faq_align:nth-child(1) .faq_answer {
			display: block
		}

		.faq_section_page {
			padding: 0 0 10px 50px;
			position: relative;
			width: 100%;
			display: flex !important;
			flex-direction: column;
			gap: 25px
		}

		.faq_section_page::before {
			content: "";
			position: absolute;
			background: var(--bg_full);
			width: 2px;
			height: 100%;
			top: 15px;
			left: 0;
			bottom: 0
		}

		.faq_section_page .faq_align {
			width: 100%;
			display: flex;
			flex-direction: column;
			gap: 25px;
			position: relative
		}

		.faq_section_page .faq_align::before {
			content: "";
			height: 11px;
			width: 11px;
			position: absolute;
			background: #e1e1e1;
			border-radius: 100%;
			top: 15px;
			left: -54px
		}

		.faq_section_page .faq_align::after {
			content: "";
			height: 56px;
			width: 56px;
			position: absolute;
			background: var(--bg_full) url(https://www.blazon.in/assets/images/t1.png)no-repeat;
			border-radius: 100%;
			top: 2px;
			left: -77px;
			background-position: center !important;
			background-size: 27px !important;
			opacity: 0
		}

		.faq_section_page .faq_align.connect.faq_open::after {
			background: var(--bg_full) url("https://www.blazon.in/assets/images/icon_1.png")no-repeat;
			opacity: 1
		}

		.faq_section_page .faq_align.create.faq_open::after {
			background: var(--bg_full) url("https://www.blazon.in/assets/images/icon_2.png")no-repeat;
			opacity: 1
		}

		.faq_section_page .faq_align.evolve.faq_open::after {
			background: var(--bg_full) url("https://www.blazon.in/assets/images/icon_3.png")no-repeat;
			opacity: 1
		}

		.faq_section_page .faq_align .faq_question {
			display: inline-block;
			width: 100%;
			position: relative
		}

		.faq_section_page .faq_align .faq_question h4 {
			font-size: 30px;
			font-family: var(--bold);
			text-transform: uppercase;
			letter-spacing: 1px;
			color: #e1e1e1;
			cursor: pointer
		}

		.faq_section_page .faq_align.faq_open .faq_question h4 {
			font-size: 42px;
			color: var(--bg_full)
		}

		.faq_content h5 {
			font-size: 22px;
			font-family: var(--bold);
			line-height: 1.4;
			margin: 0 0 12px
		}

		.faq_content p {
			font-size: 18px;
			line-height: 26px;
			font-family: var(--regular);
			color: #000;
			margin: 0 0 10px
		}

		.faq_section {
			margin: 60px 0;
			padding: 80px 0;
			background: #1b1b1b;
			display: inline-block;
			width: 100%
		}

		.faq_section .head_text h2 text {
			color: #fff;
			position: relative;
			z-index: 2
		}

		.faq_section .head_text h6 {
			color: #fff
		}

		.faq_section .head_text h2::before {
			background: #585858;
			z-index: 1
		}

		.faq_section .head_text {
			margin: 0 0 65px
		}

		.faq_section .faq_align {
			display: flex;
			align-items: center;
			justify-content: space-between;
			flex-wrap: wrap;
			width: 100%
		}

		.faq_section .faq_align .faq_left {
			width: 45%;
			display: inline-block;
			color: #fff
		}

		.faq_section .faq_align .faq_right {
			width: 45%;
			display: inline-block
		}

		.faq_section .faq_align .faq_left ul {
			list-style: none;
			display: flex;
			flex-direction: column;
			gap: 30px
		}

		.f_answer {
			display: none
		}

		.faq_section .faq_align .faq_left ul li .f_question h4 {
			width: 100%;
			display: inline-block;
			position: relative;
			padding: 15px 55px 15px 20px;
			border: 1px solid #585858;
			font-family: var(--medium);
			line-height: 1.4;
			font-size: 18px;
			cursor: pointer;
			text-transform: uppercase
		}

		.faq_section .faq_align .faq_left ul li.faq_open .f_question h4 {
			color: var(--bg_full);
			border: 1px solid var(--bg_full)
		}

		.faq_section .faq_align .faq_left ul li .f_question h4::before {
			content: "";
			position: absolute;
			background: url(https://www.blazon.in/assets/images/menu_arrow1.png)no-repeat;
			height: 11px;
			width: 11px;
			background-size: contain;
			background-position: center;
			top: 50%;
			transform: translate(0, -50%);
			right: 20px;
			filter: brightness(0) invert(1)
		}

		.faq_section .faq_align .faq_left ul li.faq_open .f_question h4::before {
			filter: inherit;
			transform: translate(0, -50%) rotate(180deg)
		}

		.faq_section .faq_align .faq_left ul li .f_answer p {
			color: rgba(255, 255, 255, 0.75);
			font-family: var(--light);
			font-size: 18px;
			line-height: 26px;
			margin: 0 0 6px;
			padding: 22px 20px 0 20px
		}

		.getintouch_section {
			margin: 60px 0;
			display: inline-block;
			position: relative;
			width: 100%
		}

		.getintouch_section form {
			width: 750px;
			display: flex;
			flex-wrap: wrap;
			justify-content: space-between;
			margin: 60px auto auto
		}

		.getintouch_section form input {
			width: 100%;
			padding: 15px 18px;
			border: 1px solid var(--border);
			outline: 0;
			width: 100%;
			background: transparent;
			margin: 0 0 25px
		}

		.getintouch_section form select {
			width: 100%;
			padding: 15px 18px;
			border: 1px solid var(--border);
			outline: 0;
			width: 100%;
			background: transparent;
			margin: 0 0 25px;
			color: #757575
		}

		.getintouch_section form textarea {
			width: 100%;
			padding: 15px 18px;
			border: 1px solid var(--border);
			outline: 0;
			width: 100%;
			background: transparent;
			margin: 0 0 25px;
			height: 120px;
			resize: none
		}

		#h_name,
		#h_email {
			width: 48%;
			float: left
		}

		#h_phone,
		#h_brand {
			width: 48%;
			float: right
		}

		.ourbrand_product {
			margin: 60px 0
		}

		.ourbrand_product .head_text {
			margin: 0 0 55px
		}

		.ourbrand_product ul {
			display: grid;
			grid-template-columns: repeat(3, 1fr);
			gap: 40px 30px
		}

		.ourbrand_product ul li {
			width: 100%;
			display: flex;
			padding: 45px 30px;
			position: relative;
			background: #fff
		}

		.ourbrand_product ul li .our_product_box {
			display: flex;
			flex-direction: column;
			gap: 0;
			height: 100%
		}

		.ourbrand_product ul li .our_product_box .our_product_img {
			width: 100%;
			display: flex;
			align-items: flex-start;
			justify-content: space-between;
			gap: 10px;
			margin: 0 0 30px
		}

		.ourbrand_product ul li .our_product_box .our_product_img span:nth-child(1) {
			height: 60px;
			width: fit-content;
			display: flex;
			align-items: center;
			justify-content: center;
			padding: 0
		}

		.ourbrand_product ul li .our_product_box .our_product_img span:nth-child(1) img {
			margin: auto;
			height: 60px
		}

		.ourbrand_product ul li .our_product_box .our_product_img span:nth-child(2) {
			color: #e1e1e1;
			font-size: 45px;
			line-height: 1.1;
			font-family: var(--regular);
			font-style: italic
		}

		.ourbrand_product ul li .our_product_box h4 {
			font-size: 25px;
			color: #000;
			font-family: var(--bold);
			line-height: 1.4;
			margin: 0 0 5px
		}

		.ourbrand_product ul li .our_product_box p {
			font-size: 18px;
			line-height: 26px;
			font-family: var(--regular);
			color: #000;
			margin: 0 0 15px
		}

		.ourbrand_product ul li .our_product_box button {
			padding: 13px 60px 13px 0vw
		}

		.ourbrand_product ul li .our_product_box .unique_btn span {
			font-size: 18px
		}

		.ourbrand_product ul li .our_product_box .unique_btn .arrow {
			height: 42px;
			width: 42px
		}

		.ourbrand_product ul li .our_product_box a {
			width: fit-content;
			margin: auto 0 0 0
		}

		.inner_page_banner_section {
			width: 100%;
			display: inline-block;
			margin: 0 0 60px;
			position: relative
		}

		.inner_page_banner_section::before {
			content: "";
			position: absolute;
			top: 0;
			left: 0;
			right: 0;
			bottom: 0;
			background: rgb(0 0 0 / 65%)
		}

		.inner_page_banner_section h2 {
			font-size: 55px;
			font-family: var(--bold);
			color: #fff;
			text-align: center;
			padding: 0 20px 50px 20px;
			position: absolute;
			bottom: 0;
			left: 0;
			width: 100%
		}

		.about_blazon_section {
			width: 100%;
			display: inline-block;
			margin: 60px 0;
			position: relative
		}

		.about_blazon_section .head_text {
			margin: 0 0 60px
		}

		.about_blazon_section ul {
			list-style: none;
			width: 100%;
			display: grid;
			grid-template-columns: repeat(1, 1fr);
			gap: 120px 0
		}

		.about_blazon_section ul li {
			width: 100%;
			display: inline-block
		}

		.about_blazon_section ul li .about_blazon_align {
			display: flex;
			align-items: center;
			justify-content: space-between;
			flex-wrap: wrap;
			width: 100%;
			position: relative
		}

		.about_blazon_section ul li:nth-child(even) .about_blazon_align {
			flex-direction: row-reverse
		}

		.about_blazon_section ul li .about_blazon_align .about_blazon_left {
			width: 50%;
			display: inline-block
		}

		.about_blazon_section ul li .about_blazon_align .about_blazon_right {
			width: 42%;
			display: inline-block
		}

		.about_blazon_section ul li .about_blazon_align .about_blazon_left img {
			width: 100%
		}

		.about_blazon_section ul li .about_blazon_align .about_blazon_right h2 {
			line-height: 1.4;
			font-family: var(--bold);
			color: #000;
			font-size: 37px;
			margin: 0 0 12px
		}

		.about_blazon_section ul li .about_blazon_align .about_blazon_right p {
			font-size: 18px;
			line-height: 26px;
			font-family: var(--regular);
			margin: 0 0 20px
		}

		.about_blazon_section ul li .about_blazon_align .about_blazon_right button {
			margin: 20px 0 0 0
		}

		.about_blazon_section ul li .about_blazon_align .about_blazon_right a {
			width: fit-content;
			display: inline-block
		}

		.aboutus_whychooseus_section {
			display: inline-block;
			margin: 60px 0;
			position: relative;
			width: 100%
		}

		.aboutus_whychooseus_section .head_text {
			margin: 0 0 55px
		}

		.aboutus_whychooseus_section .aboutus_whychooseus_align {
			display: flex;
			align-items: center;
			justify-content: space-between;
			width: 100%;
			position: relative
		}

		.aboutus_whychooseus_section .aboutus_whychooseus_align .aboutus_whychooseus_left {
			width: 45%;
			display: inline-block
		}

		.aboutus_whychooseus_section .aboutus_whychooseus_align .aboutus_whychooseus_right {
			width: 45%;
			display: inline-block
		}

		.aboutus_whychooseus_section .aboutus_whychooseus_align.even {
			flex-direction: row-reverse;
			margin: 120px 0 0 0
		}

		.aboutus_whychooseus_section .aboutus_whychooseus_align .aboutus_whychooseus_right h2 {
			line-height: 1.4;
			font-family: var(--bold);
			color: #000;
			font-size: 37px;
			margin: 0 0 12px
		}

		.aboutus_whychooseus_section .aboutus_whychooseus_align .aboutus_whychooseus_right p {
			font-size: 18px;
			line-height: 26px;
			font-family: var(--regular);
			margin: 0 0 20px
		}

		.about_counter_section {
			width: 100%;
			display: inline-block;
			padding: 100px 0;
			margin: 60px 0;
			position: relative;
			background: linear-gradient(to right, rgb(0 0 0 / 60%), rgb(0 0 0 / 60%)), url(https://www.blazon.in/assets/images/aboutus.jpg) no-repeat;
			background-position: center center;
			background-size: cover
		}

		.about_counter_section ul {
			display: grid;
			grid-template-columns: repeat(4, 1fr);
			gap: 50px;
			text-align: center
		}

		.about_counter_section ul li img {
			margin: auto auto 20px;
			filter: brightness(0) invert(57%) sepia(85%) saturate(1038%) hue-rotate(357deg) brightness(95%) contrast(96%);
			height: 65px
		}

		.about_counter_section ul li h4 {
			font-family: var(--semibold);
			font-size: 55px;
			color: #fff
		}

		.about_counter_section ul li h4.plus::after {
			content: "+"
		}

		.about_counter_section ul li p {
			text-align: center;
			line-height: 1.5;
			font-size: 18px;
			font-family: var(--light);
			color: #fff
		}

		.vision_mision_section {
			display: inline-block;
			position: relative;
			width: 100%;
			margin: 60px 0
		}

		.vision_mision_section ul {
			display: grid;
			grid-template-columns: repeat(3, 1fr);
			gap: 50px 30px;
			width: 100%;
			position: relative
		}

		.vision_mision_section ul li {
			width: 100%;
			display: inline-block;
			position: relative;
			background: #fff;
			padding: 40px 30px
		}

		.vision_mision_section ul li img {
			height: 65px;
			margin: 0 0 30px
		}

		.vision_mision_section ul li h4 {
			font-size: 30px;
			text-transform: uppercase;
			font-family: var(--bold);
			margin: 0 0 6px;
			line-height: 1.4
		}

		.vision_mision_section ul li p {
			font-size: 18px;
			line-height: 26px;
			font-family: var(--regular);
			color: #000
		}

		.vision_mision_section ul li ul {
			margin: 0;
			display: flex;
			flex-direction: column;
			gap: 0
		}

		.vision_mision_section ul li ul li {
			font-size: 18px;
			line-height: 26px;
			font-family: var(--regular);
			margin: 0 0 10px;
			position: relative;
			padding: 0 0 0 28px
		}

		.vision_mision_section ul li ul li::before {
			content: "";
			position: absolute;
			background: url("https://www.blazon.in/assets/images/list.png")no-repeat;
			height: 17px;
			width: 17px;
			background-size: contain;
			top: 6px;
			left: 0
		}

		.our_recent_project {
			display: inline-block;
			margin: 60px 0;
			width: 100%;
			position: relative
		}

		.our_recent_project .head_text {
			margin: 0 0 55px
		}

		.our_recent_project ul {
			display: grid;
			grid-template-columns: repeat(2, 1fr);
			gap: 0;
			width: 100%
		}

		.our_recent_project ul li {
			width: 100%;
			display: inline-block;
			position: relative
		}

		.our_recent_project ul li .project_box {
			overflow: hidden;
			display: flex;
			position: relative;
			align-items: center;
			justify-content: center
		}

		.our_recent_project ul li .project_box::before {
			content: "";
			z-index: 5;
			background: rgba(0, 0, 0, .5);
			height: 100%;
			width: 100%;
			position: absolute;
			top: 0;
			left: 0;
			opacity: 0;
			transition: all .3s ease-in-out
		}

		.our_recent_project ul li .project_box::after {
			content: "";
			z-index: 6;
			top: 9px;
			left: 9px;
			bottom: 9px;
			right: 9px;
			position: absolute;
			border: 1px solid #fff;
			opacity: 0;
			transition: all .3s ease-in-out
		}

		.our_recent_project ul li .project_box img {
			width: 100%;
			transition: all .5s ease-in-out
		}

		.our_recent_project ul li .project_box:hover img {
			width: 100%;
			transform: scale(1.1);
			transition: all .5s ease-in-out
		}

		.our_recent_project ul li .project_box .project_box_hover {
			position: absolute;
			z-index: 10;
			width: 100%;
			height: 100%;
			top: 0;
			left: 0;
			display: flex;
			align-items: center;
			justify-content: center;
			flex-direction: column;
			gap: 13px;
			padding: 45px;
			text-align: center;
			overflow-y: auto;
			opacity: 0;
			transition: all .3s ease-in-out
		}

		.our_recent_project ul li .project_box .project_box_hover h4 {
			font-size: 30px;
			line-height: 1.4;
			color: #fff;
			text-transform: uppercase;
			font-family: var(--bold)
		}

		.our_recent_project ul li .project_box .project_box_hover h5 {
			color: #fff;
			font-size: 18px;
			line-height: 28px;
			font-family: var(--regular)
		}

		.our_recent_project ul li .project_box .project_box_hover button {
			background: rgba(0, 0, 0, .5);
			border: 2px solid var(--bg_full);
			text-transform: uppercase;
			color: #fff;
			padding: 8px 12px;
			font-family: var(--semibold)
		}

		.our_recent_project ul li .project_box .project_box_hover button:hover {
			background: var(--bg_full)
		}

		.our_recent_project ul li .project_box .project_box_hover:hover,
		.our_recent_project ul li .project_box:hover::after,
		.our_recent_project ul li .project_box:hover::before {
			transition: all .3s ease-in-out;
			opacity: 1
		}

		.our_recent_project .view_all_project {
			margin: 50px 0 0 0;
			display: inline-block;
			width: 100%;
			position: relative
		}

		.our_recent_project .view_all_project a {
			width: fit-content;
			margin: auto;
			display: flex
		}

		.our_recent_project ul li .project_box .project_box_hover::-webkit-scrollbar {
			width: 6px
		}

		.our_recent_project ul li .project_box .project_box_hover::-webkit-scrollbar-track {
			background: #f1f1f1
		}

		.our_recent_project ul li .project_box .project_box_hover::-webkit-scrollbar-thumb {
			background: var(--bg_full);
			border-radius: 0
		}

		.our_recent_project ul li .project_box .project_box_hover::-webkit-scrollbar-thumb:hover {
			background: #555
		}

		.common_page_design {
			margin: 60px 0 30px 0;
			display: inline-block;
			width: 100%;
			position: relative
		}

		.common_page_design .head_text {
			margin: 0 0 55px
		}

		.common_page_design .content_all p,
		.common_page_design .content_all h6 {
			font-size: 18px;
			line-height: 26px;
			font-family: var(--regular);
			margin: 0 0 20px
		}

		.common_page_design .content_all h2 {
			font-size: 35px;
			line-height: 1.4;
			margin: 0 0 15px;
			font-family: var(--bold);
			color: #000
		}

		.common_page_design .content_all h3 {
			font-size: 30px;
			line-height: 1.4;
			margin: 0 0 15px;
			font-family: var(--bold);
			color: #000
		}

		.common_page_design .content_all h4 {
			font-size: 25px;
			line-height: 1.4;
			margin: 0 0 15px;
			font-family: var(--bold);
			color: #000
		}

		.common_page_design .content_all h5 {
			font-size: 20px;
			line-height: 1.4;
			margin: 0 0 15px;
			font-family: var(--bold);
			color: #000
		}

		.common_page_design .content_all ul {
			margin: 15px 0
		}

		.common_page_design .content_all ul li {
			font-size: 18px;
			line-height: 26px;
			font-family: var(--regular);
			margin: 0 0 10px;
			position: relative;
			padding: 0 0 0 28px
		}

		.common_page_design .content_all ul li::before {
			content: "";
			position: absolute;
			background: url(https://www.blazon.in/assets/images/list.png)no-repeat;
			height: 17px;
			width: 17px;
			background-size: contain;
			top: 6px;
			left: 0
		}

		.common_page_design .content_all img {
			margin: 20px auto
		}

		.mix {
			display: none
		}

		.cd-filter-content {
			display: none
		}

		.expertise_page_section {
			margin: 60px 0;
			display: inline-block;
			position: relative;
			width: 100%
		}

		.expertise_page_section .head_text {
			margin: 0 0 55px
		}

		main.cd-main-content {
			width: 100%;
			display: inline-block
		}

		.cd-tab-filter {
			width: 100%;
			display: inline-block;
			margin: auto;
			border-bottom: 3px solid #e4ecf1
		}

		.cd-tab-filter ul {
			display: flex;
			align-items: center;
			gap: 20px;
			width: fit-content;
			margin: auto
		}

		.cd-tab-filter ul li a {
			padding: 15px;
			position: relative;
			width: 100%;
			display: inline-block;
			font-size: 20px;
			font-family: var(--bold);
			color: #000;
			text-transform: uppercase
		}

		.cd-tab-filter ul li a::before {
			content: "";
			position: absolute;
			height: 3px;
			width: 100%;
			background: transparent;
			left: 0;
			bottom: -3px
		}

		.cd-tab-filter ul li a.selected {
			color: var(--bg_full)
		}

		.cd-tab-filter ul li a.selected::before {
			background: var(--bg_full)
		}

		.cd-tab-filter ul li a::after {
			content: "";
			width: 0;
			height: 0;
			margin: 0;
			border-left: 6px solid transparent;
			border-right: 6px solid transparent;
			border-top: 10px solid transparent;
			position: absolute;
			bottom: -10px;
			left: 50%;
			transform: translate(-50%, 0)
		}

		.cd-tab-filter ul li a.selected::after {
			border-top: 10px solid var(--bg_full)
		}

		.cd-gallery {
			width: 100%;
			display: inline-block;
			margin: 55px 0 0 0
		}

		.cd-gallery ul {
			display: grid;
			grid-template-columns: repeat(3, 1fr);
			gap: 30px 25px
		}

		.cd-gallery ul li {
			background: #fff
		}

		.cd-gallery ul li .e_service_box {
			width: 100%;
			display: inline-block;
			padding: 40px 24px
		}

		.cd-gallery ul li .e_service_box .e_icon {
			height: 150px;
			width: fit-content;
			margin: auto auto 25px;
			position: relative;
			display: flex;
			overflow: hidden
		}

		.cd-gallery ul li .e_service_box .e_icon img {
			margin: auto;
			height: 150px
		}

		[contenteditable] {
			outline: 0 solid transparent
		}

		.gif_video,
		.gif_video:hover,
		.gif_video:focus,
		.gif_video:active {
			position: relative;
			left: 0;
			top: 0;
			opacity: 1;
			outline: none !important;
			border: none !important;
			display: flex;
			box-shadow: none !important;
			height: 150px;
			width: 150px;
			object-fit: contain
		}

		.cd-gallery ul li .e_service_box h4 {
			font-size: 21px;
			font-family: var(--bold);
			color: #000;
			line-height: 1.4;
			margin: 0 0 8px;
			min-height: 58px
		}

		.cd-gallery ul li .e_service_box p {
			font-size: 16px;
			line-height: 26px;
			font-family: var(--regular);
			color: #000;
			margin: 0 0 10px;
			min-height: 130px
		}

		.search {
			display: inline-block !important;
			width: 100%;
			margin: 35px 0 0
		}

		.cd-gallery ul li .e_service_box a {
			width: fit-content
		}

		.cd-gallery ul li .e_service_box button {
			padding: 13px 60px 13px 0vw
		}

		.cd-gallery ul li .e_service_box button.unique_btn span {
			font-size: 18px
		}

		.cd-gallery ul li .e_service_box button.unique_btn .arrow {
			height: 42px;
			width: 42px
		}

		.search input {
			width: 300px;
			margin: 0 0 0 auto;
			display: flex;
			padding: 10px 15px;
			outline: 0;
			border: 1px solid var(--border);
			background: transparent
		}

		.location_content {
			display: none
		}

		.contactus_page_section {
			display: inline-block;
			margin: 60px 0;
			position: relative;
			width: 100%
		}

		.contactus_page_section .head_text {
			margin: 0 0 55px
		}

		.contactus_page_section .contactus_page_top {
			width: 100%;
			display: inline-block;
			margin: 0 0 50px
		}

		.contactus_page_section .contactus_page_top ul {
			display: flex;
			align-items: center;
			justify-content: center;
			width: 100%;
			gap: 10px;
			position: relative;
			text-align: center;
			border-bottom: 3px solid #e4ecf1
		}

		.contactus_page_section .contactus_page_top ul li a {
			padding: 15px;
			position: relative;
			width: 100%;
			display: inline-block;
			font-size: 20px;
			font-family: var(--bold);
			color: #000;
			text-transform: uppercase
		}

		.contactus_page_section .contactus_page_top ul li a img {
			height: 60px;
			margin: auto auto 20px;
			display: none
		}

		.contactus_page_section .contactus_page_top ul li.active a {
			color: var(--bg_full)
		}

		.contactus_page_section .contactus_page_top ul li a::before {
			content: "";
			position: absolute;
			height: 3px;
			width: 100%;
			background: transparent;
			left: 0;
			bottom: -3px
		}

		.contactus_page_section .contactus_page_top ul li.active a::before {
			background: var(--bg_full)
		}

		.contactus_page_section .contactus_page_top ul li a::after {
			content: "";
			width: 0;
			height: 0;
			margin: 0;
			border-left: 6px solid transparent;
			border-right: 6px solid transparent;
			border-top: 10px solid transparent;
			position: absolute;
			bottom: -10px;
			left: 50%;
			transform: translate(-50%, 0)
		}

		.contactus_page_section .contactus_page_top ul li.active a::after {
			border-top: 10px solid var(--bg_full)
		}

		.contactus_page_section .location_content_align {
			display: flex;
			align-items: center;
			justify-content: space-between;
			width: 100%
		}

		.contactus_page_section .location_content_align .location_content_left {
			width: 45%;
			display: inline-block
		}

		.contactus_page_section .location_content_align .location_content_right {
			width: 45%;
			display: inline-block
		}

		.contactus_page_section .location_content_align .location_content_right h2 {
			font-size: 38px;
			line-height: 1.4;
			margin: 0 0 25px;
			font-family: var(--bold)
		}

		.contactus_page_section .location_content_align .location_content_right ul {
			display: grid;
			grid-template-columns: repeat(1, 1fr);
			gap: 20px
		}

		.contactus_page_section .location_content_align .location_content_right ul li {
			width: 100%;
			display: inline-block
		}

		.contactus_page_section .location_content_align .location_content_right ul li h4 {
			font-size: 22px;
			font-family: var(--bold);
			line-height: 1.4;
			margin: 0 0 8px
		}

		.contactus_page_section .location_content_align .location_content_right ul li p {
			font-size: 18px;
			line-height: 26px;
			font-family: var(--regular);
			color: #000;
			margin: 0
		}

		.contactus_page_section .location_content_align .location_content_right ul li p:last-child {
			margin: 0
		}

		.related_product {
			margin: 60px 0;
			display: inline-block;
			width: 100%;
			position: relative
		}

		.related_product .head_text {
			margin: 0 0 55px
		}

		.related_product ul {
			display: grid;
			grid-template-columns: repeat(3, 1fr);
			gap: 30px 25px
		}

		.related_product ul li {
			background: #fff;
			display: flex;
			width: 100%
		}

		.related_product ul li .e_service_box {
			width: 100%;
			display: flex;
			flex-wrap: wrap;
			padding: 40px 24px
		}

		.related_product ul li .e_service_box .e_icon {
			height: auto;
			width: fit-content;
			border-radius: 100%;
			margin: auto auto 15px
		}

		.related_product ul li .e_service_box .e_icon img {
			margin: auto;
			height: 60px
		}

		.related_product ul li .e_service_box h4 {
			font-size: 25px;
			font-family: var(--bold);
			color: #000;
			line-height: 1.4;
			margin: 0 0 8px;
			min-height: 60px;
			width: 100%
		}

		.related_product ul li .e_service_box p {
			font-size: 16px;
			line-height: 26px;
			font-family: var(--regular);
			color: #000;
			margin: 0 0 15px;
			min-height: 130px
		}

		.related_product ul li .e_service_box button {
			padding: 13px 60px 13px 0vw
		}

		.related_product ul li .e_service_box button.unique_btn span {
			font-size: 18px
		}

		.related_product ul li .e_service_box button.unique_btn .arrow {
			height: 42px;
			width: 42px
		}

		.related_product ul li a {
			display: inline-block;
			margin: auto 0 0 0;
			width: 100%
		}

		.service_individual_page {
			margin: 60px 0;
			display: inline-block;
			width: 100%;
			position: relative
		}

		.service_individual_page .head_text {
			margin: 0 0 55px
		}

		.service_individual_page .service_dynamic {
			display: grid;
			grid-template-columns: repeat(1, 1fr);
			width: 100%;
			gap: 120px
		}

		.service_individual_page .service_dynamic .service_dynamic_align {
			display: flex;
			align-items: center;
			justify-content: space-between;
			flex-wrap: wrap;
			width: 100%;
			position: relative
		}

		.service_individual_page .service_dynamic .service_dynamic_align:nth-child(even) {
			flex-direction: row-reverse
		}

		.service_individual_page .service_dynamic .service_dynamic_align .service_dynamic_left {
			width: 45%;
			display: inline-block
		}

		.service_individual_page .service_dynamic .service_dynamic_align .service_dynamic_right {
			width: 45%;
			display: inline-block
		}

		.service_individual_page .service_dynamic .service_dynamic_align .service_dynamic_right h2 {
			font-size: 35px;
			line-height: 1.4;
			margin: 0 0 20px;
			font-family: var(--bold)
		}

		.service_individual_page .service_dynamic .service_dynamic_align .service_dynamic_right p {
			font-size: 18px;
			line-height: 26px;
			font-family: var(--regular);
			margin: 0 0 12px
		}

		.service_individual_page .service_dynamic .service_dynamic_align .service_dynamic_right p:last-child {
			margin: 0
		}

		.service_individual_page .service_dynamic .service_dynamic_align .service_dynamic_right ul {
			margin: 15px 0
		}

		.service_individual_page .service_dynamic .service_dynamic_align .service_dynamic_right ul li {
			font-size: 18px;
			line-height: 26px;
			font-family: var(--regular);
			margin: 0 0 10px;
			position: relative;
			padding: 0 0 0 28px
		}

		.service_individual_page .service_dynamic .service_dynamic_align .service_dynamic_right ul li::before {
			content: "";
			position: absolute;
			background: url(https://www.blazon.in/assets/images/list.png)no-repeat;
			height: 17px;
			width: 17px;
			background-size: contain;
			top: 6px;
			left: 0
		}

		.how_its_works {
			background: #1b1b1b;
			margin: 60px 0;
			width: 100%;
			position: relative;
			padding: 80px 0
		}

		.how_its_works .head_text h2 text {
			color: #fff;
			position: relative;
			z-index: 2
		}

		.how_its_works .head_text h2::before {
			background: #585858;
			z-index: 1
		}

		.how_its_works .head_text h6,
		.how_its_works .head_text h2 {
			color: #fff
		}

		.how_its_works .head_text {
			margin: 0 0 55px
		}

		.how_its_works ul {
			display: grid;
			grid-template-columns: repeat(3, 1fr);
			gap: 65px 60px
		}

		.how_its_works ul li {
			width: 100%;
			display: inline-block;
			text-align: center
		}

		.how_its_works ul li img {
			margin: auto auto 25px;
			height: 85px
		}

		.how_its_works ul li h4 {
			color: #fff;
			font-family: var(--semibold);
			font-size: 26px;
			margin: 0 0 12px
		}

		.how_its_works ul li p {
			font-family: var(--light);
			font-size: 18px;
			line-height: 26px;
			color: rgb(255 255 255 / 65%)
		}

		.mob_menu {
			display: none
		}

		.mobile_prodoct {
			overflow: hidden
		}

		.dd1 {
			display: none
		}

		.dd {
			display: none
		}

		.call_popup_align {
			padding: 10px;
			display: grid;
			grid-template-columns: repeat(2, 1fr);
			gap: 30px 30px;
			align-items: center;
			justify-content: center
		}

		.call_popup_align .call_popup_box {
			display: inline-block;
			width: 100%;
			position: relative;
			text-align: center;
			padding: 10px;
			border: 1px solid transparent
		}

		.call_popup_align .call_popup_box:hover {
			border: 1px solid var(--bg_full)
		}

		.call_popup_align .call_popup_box img {
			height: 60px;
			margin: auto auto 0
		}

		.call_popup_align .call_popup_box a {
			font-size: 20px;
			color: #000;
			font-family: var(--bold);
			line-height: 1.4;
			text-align: center
		}

		.recapcha {
			display: flex;
			width: 100%;
			flex-wrap: wrap;
			margin: 0 0 25px;
			align-items: center;
			gap: 20px
		}

		.recapcha span:nth-child(1) {
			font-size: 24px;
			font-family: var(--bold);
			color: #000;
			letter-spacing: 1px
		}

		.recapcha span:nth-child(2) input {
			width: 170px;
			margin: 0
		}

		.process {
			cursor: no-drop
		}

		.f_social_media img {
			height: 27px
		}

		.f_social_media {
			gap: 14px;
			margin: 23px 0 0 0
		}

		.leader_ship_section {
			width: 100%;
			display: inline-block;
			margin: 60px 0
		}

		.leader_ship_section .head_text {
			margin: 0 0 55px
		}

		.leader_ship_section .leader_row {
			width: 100%;
			display: inline-block
		}

		.leader_ship_section .leader_row .leader_grid {
			width: 100%;
			display: grid;
			grid-template-columns: repeat(1, 1fr);
			gap: 50px
		}

		.leader_ship_section .leader_row .leader_grid .leader_box {
			display: flex;
			align-items: flex-start;
			justify-content: space-between;
			flex-wrap: wrap;
			width: 100%;
			position: relative;
			padding: 30px 24px;
			border: 1px solid rgb(221 221 221 / 80%)
		}

		.leader_ship_section .leader_row .leader_grid .leader_box .leader_box_left {
			width: 60%;
			display: flex;
			align-items: flex-start;
			justify-content: space-between;
			flex-wrap: wrap;
			position: relative
		}

		.leader_ship_section .leader_row .leader_grid .leader_box .leader_box_right {
			width: 25%;
			padding: 0 0 0 30px;
			display: inline-block;
			border-left: 1px solid var(--bg_full)
		}

		.leader_ship_section .leader_row .leader_grid .leader_box .leader_box_left .leader_box_left_img {
			width: 22%;
			display: inline-block
		}

		.leader_ship_section .leader_row .leader_grid .leader_box .leader_box_left .leader_box_left_content {
			width: 73%;
			display: inline-block
		}

		.leader_ship_section .leader_row .leader_grid .leader_box .leader_box_left .leader_box_left_img .img_box {
			width: 100%;
			display: inline-block;
			margin: 0 0 15px;
			position: relative
		}

		.leader_ship_section .leader_row .leader_grid .leader_box .leader_box_left .leader_box_left_img .img_box img {
			width: 100%;
			position: relative;
			z-index: 10;
			padding: 0 8px 8px 0
		}

		.leader_ship_section .leader_row .leader_grid .leader_box .leader_box_left .leader_box_left_img .img_box::before {
			content: "";
			z-index: 1;
			background: var(--bg_full);
			position: absolute;
			top: 10px;
			right: 0;
			left: 10px;
			bottom: 0
		}

		.leader_ship_section .leader_row .leader_grid .leader_box .leader_box_left .exp {
			display: flex;
			flex-direction: column;
			gap: 0;
			text-align: center;
			width: 100%
		}

		.leader_ship_section .leader_row .leader_grid .leader_box .leader_box_left .exp h4 {
			font-size: 30px;
			font-family: var(--bold);
			color: #000;
			line-height: 1.2;
			margin: 0
		}

		.leader_ship_section .leader_row .leader_grid .leader_box .leader_box_left .exp p {
			font-family: var(--regular);
			font-size: 16px;
			line-height: 1.8
		}

		.leader_ship_section .leader_row .leader_grid .leader_box .leader_box_left_content h4 {
			font-size: 24px;
			font-family: var(--bold);
			color: #000;
			line-height: 1.3;
			margin: 0 0 5px
		}

		.leader_ship_section .leader_row .leader_grid .leader_box .leader_box_left_content h5 {
			font-size: 15px;
			font-style: italic;
			text-transform: uppercase
		}

		.leader_ship_section .leader_row .leader_grid .leader_box .leader_box_left_content .line {
			margin: 22px 0;
			display: block;
			width: 90px;
			border-bottom: 1px solid var(--bg_full)
		}

		.leader_ship_section .leader_row .leader_grid .leader_box .leader_box_left_content h3 {
			font-size: 24px;
			font-family: var(--bold);
			color: #000;
			line-height: 1.3;
			margin: 0 0 12px;
			position: relative;
			padding: 0 0 0 33px
		}

		.leader_ship_section .leader_row .leader_grid .leader_box .leader_box_left_content h3::before {
			content: "";
			position: absolute;
			background: url(https://www.blazon.in/assets/images/s_description.png)no-repeat;
			height: 22px;
			width: 22px;
			background-size: contain;
			background-position: center left;
			top: 4px;
			left: 0
		}

		.leader_ship_section .leader_row .leader_grid .leader_box .leader_box_left_content p {
			line-height: 24px;
			text-align: left;
			font-family: var(--regular)
		}

		.leader_ship_section .leader_row .leader_grid .leader_box .leader_box_left_content .content_btn {
			width: 100%;
			display: flex;
			align-items: center;
			flex-wrap: wrap;
			gap: 18px;
			margin: 22px 0 0 0
		}

		.leader_ship_section .leader_row .leader_grid .leader_box .leader_box_left_content .content_btn a:nth-child(1) button {
			padding: 8px 18px;
			border: 1px solid var(--bg_full);
			color: #000;
			font-size: 15px;
			text-transform: uppercase;
			font-family: var(--bold);
			background: transparent;
			width: 140px
		}

		.leader_ship_section .leader_row .leader_grid .leader_box .leader_box_left_content .content_btn a:nth-child(2) button {
			padding: 8px 18px;
			border: 1px solid var(--bg_full);
			color: #000;
			font-size: 15px;
			text-transform: uppercase;
			font-family: var(--bold);
			background: var(--bg_full);
			width: 140px
		}

		.leader_ship_section .leader_row .leader_grid .leader_box .leader_box_right ul {
			display: flex;
			flex-direction: column;
			gap: 20px
		}

		.leader_ship_section .leader_row .leader_grid .leader_box .leader_box_right ul li {
			position: relative;
			width: 100%;
			padding: 0 0 0 41px
		}

		.leader_ship_section .leader_row .leader_grid .leader_box .leader_box_right ul li::before {
			content: "";
			position: absolute;
			background: url("https://www.blazon.in/assets/images/branch.png")no-repeat;
			height: 23px;
			width: 23px;
			background-size: contain !important;
			top: 6px;
			left: 0
		}

		.leader_ship_section .leader_row .leader_grid .leader_box .leader_box_right ul li.l_brance::before {
			background: url("https://www.blazon.in/assets/images/branch.png")no-repeat
		}

		.leader_ship_section .leader_row .leader_grid .leader_box .leader_box_right ul li.l_time::before {
			background: url("https://www.blazon.in/assets/images/timing.png")no-repeat
		}

		.leader_ship_section .leader_row .leader_grid .leader_box .leader_box_right ul li.l_date::before {
			background: url("https://www.blazon.in/assets/images/appt_date.png")no-repeat
		}

		.leader_ship_section .leader_row .leader_grid .leader_box .leader_box_right ul li h4 {
			font-size: 20px;
			line-height: 1.3;
			font-family: var(--bold);
			margin: 0 0 6px
		}

		.leader_ship_section .leader_row .leader_grid .leader_box .leader_box_right ul li p {
			line-height: 24px;
			text-align: left;
			font-size: 15px;
			font-family: var(--regular)
		}

		.leader_profile_page {
			margin: 60px 0;
			display: inline-block;
			position: relative;
			width: 100%
		}

		.leader_profile_page .leader_profile_align {
			display: flex;
			align-items: flex-start;
			flex-wrap: wrap;
			width: 100%;
			justify-content: space-between
		}

		.leader_profile_page .leader_profile_align .leader_profile_left {
			width: 60%;
			display: inline-block
		}

		.leader_profile_page .leader_profile_align .leader_profile_right {
			width: 30%;
			display: inline-block
		}

		.leader_profile_page .leader_profile_align .leader_profile_left h1 {
			font-size: 35px;
			font-family: var(--bold);
			margin: 0;
			line-height: 1.3
		}

		.leader_profile_page .leader_profile_align .leader_profile_left p {
			font-size: 16px;
			font-family: var(--regular);
			line-height: 26px
		}

		.leader_profile_page .leader_profile_align .leader_profile_left h4 {
			font-size: 22px;
			font-family: var(--bold);
			margin: 0 0 5px;
			line-height: 1.3
		}

		.leader_profile_page .leader_profile_align .leader_profile_left .line {
			width: 100%;
			display: inline-block;
			margin: 20px 0;
			border: 0;
			border-bottom: 1px solid var(--border)
		}

		.leader_profile_page .leader_profile_align .leader_profile_right {
			background: #edeaea;
			padding: 15px 15px 40px
		}

		.leader_profile_page .leader_profile_align .leader_profile_right .l_profile_box img {
			width: 100%
		}

		.leader_profile_page .leader_profile_align .leader_profile_right h4 {
			text-align: center;
			font-size: 25px;
			font-family: var(--bold);
			color: #000;
			margin: 30px 0 12px
		}

		.sm_box {
			width: 100%;
			display: flex;
			flex-wrap: wrap;
			gap: 15px;
			align-items: center;
			justify-content: center
		}

		.sm_box img {
			height: 35px
		}

		.leader_profile_page .leader_profile_align .leader_profile_right button {
			margin: 40px 0 0 0;
			background: var(--bg_full);
			padding: 11px 10px;
			font-family: var(--bold);
			color: #000;
			text-transform: uppercase;
			border: 0;
			width: 100%;
			font-size: 18px
		}

		.body_overflow {
			width: 100%;
			display: block;
			overflow: hidden;
			float: left
		}

		.thankyou_pages .thankyou_content {
			width: 100%;
			display: inline-block;
			position: relative;
			text-align: center;
			background: hwb(35deg 3% 7% / 8%);
			padding: 60px 50px
		}

		.thankyou_pages .thankyou_content img {
			height: 100px;
			margin: auto auto 25px
		}

		.thankyou_pages .thankyou_content h1 {
			font-size: 50px;
			color: var(--bg_full);
			font-family: var(--bold);
			margin: 0 0 15px
		}

		.thankyou_pages .thankyou_content p {
			color: #000;
			font-size: 18px;
			line-height: 30px;
			text-align: center;
			max-width: 80%;
			margin: auto
		}

		.thankyou_pages .thankyou_content h4 {
			font-size: 25px;
			color: var(--bg_full);
			line-height: 1.5;
			margin: 30px 0 0 10px;
			font-family: 'f_bold'
		}

		.thankyou_pages .thankyou_content button {
			background: #000;
			font-size: 14px;
			text-transform: uppercase;
			font-family: var(--medium);
			width: auto;
			text-align: center;
			padding: 12px 20px;
			border: 0;
			display: flex;
			border-radius: 5px;
			transition: all .4s ease-in-out;
			margin: 15px auto 0 auto;
			display: flex;
			align-items: center;
			gap: 10px;
			color: #fff
		}

		.thankyou_pages .thankyou_content img.thank_you {
			height: 50px;
			margin: auto auto 35px auto;
			padding: 0 19px 0 0
		}

		.whatsappme__button {
			position: fixed;
			z-index: 300;
			bottom: 95px;
			right: 24px;
			background: #25d366;
			border-radius: 100%;
			transition: all .3s ease-in-out
		}

		.whatsappme__button:hover {
			background: var(--bg_full);
			transition: all .3s ease-in-out
		}

		.tawk-min-container .tawk-button-circle.tawk-button-large {
			background: var(--bg_full) !important
		}

		.whatsapp {
			position: fixed;
			top: 50%;
			transform: translateY(-50%);
			right: -95px;
			transition: .5s ease-in-out;
			z-index: 999
		}

		.whatsapp:hover {
			right: 0
		}

		.whatsapp a {
			display: flex;
			align-items: center;
			padding: 8px 15px 8px 15px;
			background: #378d3b;
			border-radius: 40px 0 0 40px
		}

		.whatsapp a span {
			margin-left: 10px;
			color: #fff;
			font-weight: 600;
			letter-spacing: 1px
		}

		.whatsapp img {
			height: 30px
		}

		.careers_form {
			width: 100%;
			display: inline-block;
			margin: 60px 0;
			position: relative
		}

		.careers_form form {
			width: 750px;
			display: flex;
			flex-wrap: wrap;
			justify-content: space-between;
			margin: 60px auto auto
		}

		.careers_form form input[type="text"] {
			width: 100%;
			padding: 15px 18px;
			border: 1px solid var(--border);
			outline: 0;
			width: 100%;
			background: transparent;
			margin: 0 0 25px
		}

		.careers_form form select {
			width: 100%;
			padding: 15px 18px;
			border: 1px solid var(--border);
			outline: 0;
			width: 100%;
			background: transparent;
			margin: 0 0 25px;
			color: #757575
		}

		.careers_form form textarea {
			width: 100%;
			padding: 15px 18px;
			border: 1px solid var(--border);
			outline: 0;
			width: 100%;
			background: transparent;
			margin: 0 0 25px;
			height: 120px;
			resize: none
		}

		#c_name,
		#c_email {
			width: 48%;
			float: left
		}

		#c_lname,
		#c_phone {
			width: 48%;
			float: right
		}

		.careers_form .recapcha input[type="text"] {
			margin: 0
		}

		.careers_form .resume_uplaod {
			width: 100%;
			border: 2px solid var(--border);
			border-style: dashed;
			position: relative;
			margin: 0 0 25px;
			display: flex;
			align-items: center;
			padding: 17px 12px;
			justify-content: center
		}

		.careers_form .resume_uplaod input[type="file"] {
			position: absolute;
			height: 100%;
			width: 100%;
			top: 0;
			left: 0;
			opacity: 0
		}

		.modal-title {
			font-family: var(--bold);
			text-transform: uppercase
		}

		.s_faq .faq_section {
			padding: 0;
			background: transparent
		}

		.s_faq .faq_section .head_text h2::before,
		.s_faq .faq_section .head_text h1::before {
			background: var(--bg_full)
		}

		.s_faq .faq_section .head_text h2,
		.s_faq .faq_section .head_text h1 {
			color: #000
		}

		.s_faq .faq_section .head_text h2 text {
			color: #000
		}

		.s_faq .faq_section .head_text h6 {
			color: #000
		}

		.s_faq .faq_section .faq_align .faq_left ul li .f_question h4 {
			color: #585858;
			font-family: var(--bold)
		}

		.s_faq .faq_section .faq_align .faq_left ul li .f_question h4::before {
			filter: brightness(0) invert(14%) sepia(5%) saturate(393%) hue-rotate(325deg) brightness(108%) contrast(85%)
		}

		.s_faq .faq_section .faq_align .faq_left ul li.faq_open .f_question h4::before {
			filter: inherit
		}

		.s_faq .faq_section .faq_align .faq_left ul li .f_answer p {
			color: #000
		}

		.think_big_section .think_big_align .think_big_right .think_box .think_box_image ul a {
			cursor: pointer;
			display: inline-block;
			width: 100%
		}

		.think_big_section .think_big_align .think_big_right .think_box .think_box_image ul a p {
			cursor: pointer
		}

		.whatsapp * {
			cursor: pointer
		}

		.f_social_media .f_item * {
			cursor: pointer
		}

		.header_section .header_align .header_left * {
			cursor: pointer
		}

		.header_section .header_align .header_icon ul li * {
			cursor: pointer
		}

		.image_banner {
			height: 100vh;
			display: inline-block;
			position: relative;
			width: 100%
		}

		.image_banner picture {
			height: 100vh;
			width: 100%;
			object-fit: cover
		}

		.image_banner picture img {
			height: 100vh;
			width: 100% !important;
			object-fit: cover
		}

		.unique_btn * {
			cursor: pointer
		}

		.clr-orng {
			color: var(--bg_full)
		}

		select {
			cursor: pointer
		}

		.type-wrap {
			font-size: 50px;
			padding: 20px
		}

		@keyframes type {

			0,
			100% {
				opacity: 1
			}

			50% {
				opacity: 0
			}
		}

		a * {
			cursor: pointer !important
		}

		.type-wrap {
			position: absolute;
			top: 50%;
			left: 50%;
			width: 100%;
			padding: 20px;
			text-align: center;
			transform: translate(-50%, -50%)
		}

		.type-wrap span {
			font-size: 5vw;
			font-weight: 700;
			color: #fff;
			min-height: 90px
		}

		.image_banner {
			overflow: hidden
		}

		.image_banner picture img {
			transition: all 15s ease-in-out;
			animation: h_zoom 50s ease-in-out infinite
		}

		@-webkit-keyframes h_zoom {
			0 {
				transform: scale(1)
			}

			25% {
				transform: scale(1.14)
			}

			50% {
				transform: scale(1)
			}

			75% {
				transform: scale(1.14)
			}

			100% {
				transform: scale(1)
			}
		}

		.blazon_process .blazon_process_tab .process_top_items_align .process_top_items_right h4 {
			display: none;
			font-size: 32px;
			font-family: var(--bold);
			line-height: 1.3;
			margin: 0 0 25px;
			color: #fff
		}

		.aboutus_whychooseus_section .aboutus_whychooseus_align .aboutus_whychooseus_left h2 {
			display: none
		}

		.aboutus_whychooseus_section .aboutus_whychooseus_align .aboutus_whychooseus_left h2 {
			line-height: 1.2;
			font-family: var(--bold);
			color: #000;
			font-size: 30px;
			margin: 0 0 20px;
			display: none
		}

		.service_individual_page .service_dynamic .service_dynamic_align .service_dynamic_left h2 {
			display: none;
			font-size: 30px;
			line-height: 1.4;
			margin: 0 0 20px;
			font-family: var(--bold)
		}

		.about_blazon_section ul li .about_blazon_align .about_blazon_left h2 {
			display: none;
			line-height: 1.4;
			font-family: var(--bold);
			color: #000;
			font-size: 32px;
			margin: 0 0 12px
		}


		/*style_media*/

		@media screen and (max-width:1200px) {

			.wrapper,
			.header_section .wrapper_full {
				padding: 0 40px
			}

			.mob_menu {
				display: block;
				position: absolute;
				top: 50%;
				right: 0;
				transform: translate(0, -50%);
				z-index: 99
			}

			#cssmenu {
				display: none
			}

			.header_section .header_align .header_icon {
				margin: 0 60px 0 0;
				z-index: 100;
				position: relative
			}

			.header_section .header_align .header_icon img {
				position: relative;
				z-index: 100
			}

			.header_section .header_align {
				position: relative
			}

			.mob_menu .dl-trigger {
				position: relative;
				width: 41px;
				height: 41px;
				display: flex;
				margin: 0 0 0 auto;
				align-items: center;
				justify-content: center
			}

			.mob_menu .dl-trigger .m_outline {
				height: 2px;
				width: 36px;
				background: #babdc5;
				border-radius: 3px;
				display: inline-block;
				position: relative;
				transition: all .4s ease-in-out
			}

			.mob_menu .dl-trigger .m_outline::before {
				content: "";
				height: 2px;
				width: 22px;
				background: #babdc5;
				border-radius: 3px;
				position: absolute;
				top: -13px;
				left: 0;
				transition: all .4s ease-in-out
			}

			.mob_menu .dl-trigger .m_outline::after {
				content: "";
				height: 2px;
				width: 22px;
				background: #babdc5;
				border-radius: 3px;
				position: absolute;
				bottom: -13px;
				right: 0;
				transition: all .4s ease-in-out
			}

			.mob_menu .dl-trigger.dl-active .m_outline {
				background: transparent;
				transition: all .4s ease-in-out;
				border: 1.5px solid #babdc5;
				height: 41px;
				width: 41px;
				border-radius: 100%;
				display: inline-block
			}

			.mob_menu .dl-trigger.dl-active .m_outline::before {
				width: 45%;
				transform: translate(-50%, -50%) rotate(45deg);
				top: 50%;
				transition: all .4s ease-in-out;
				left: 50%
			}

			.mob_menu .dl-trigger.dl-active .m_outline::after {
				width: 45%;
				transform: translate(-50%, -50%) rotate(-52deg);
				top: 50%;
				transition: all .4s ease-in-out;
				left: 50%
			}

			.slider_section {
				margin: 0 0 40px 0
			}

			.footer_section {
				margin: 40px 0 0 0
			}

			.think_big_section,
			.expertise_section,
			.blazon_process,
			.ourbrand_product,
			.our_technologies,
			.our_milestones,
			.why_choose_blazon,
			.brands_trust_section,
			.faq_section,
			.ourclients_section,
			.getintouch_section {
				margin: 40px 0
			}

			.blazon_process,
			.our_milestones,
			.faq_section {
				padding: 60px 0
			}

			.expertise_section .head_text,
			.blazon_process .head_text,
			.ourbrand_product .head_text,
			.our_milestones .head_text,
			.why_choose_blazon .head_text,
			.brands_trust_section .head_text,
			.faq_section .head_text,
			.ourclients_section .head_text {
				margin: 0 0 45px
			}

			.think_big_section .think_big_align .think_big_left,
			.think_big_section .think_big_align .think_big_right {
				width: 47%
			}

			.think_big_section .think_big_align .think_big_left h1,
			.think_big_section .think_big_align .think_big_left h1 span {
				font-size: 55px
			}

			.expertise_section ul {
				grid-template-columns: repeat(2, 1fr);
				gap: 40px 20px
			}

			.head_text p,
			.head_text h6 {
				max-width: 85%
			}

			.blazon_process .blazon_process_tab .process_top_items_align .process_top_items_right,
			.blazon_process .blazon_process_tab .process_top_items_align .process_top_items_left {
				width: 47%
			}

			.ourbrand_product ul {
				display: grid;
				grid-template-columns: repeat(2, 1fr);
				gap: 40px 20px
			}

			.brands_trust_section .brands_trust_align .brands_trust_left,
			.brands_trust_section .brands_trust_align .brands_trust_right {
				width: 45%
			}

			.faq_section .faq_align .faq_left,
			.faq_section .faq_align .faq_right {
				width: 47%
			}

			.ourclients_section ul {
				gap: 40px 20px
			}

			.getintouch_section form {
				margin: 45px auto auto
			}

			.inner_page_banner_section {
				margin: 0 0 40px 0
			}

			.about_blazon_section {
				margin: 40px 0
			}

			.about_blazon_section .head_text {
				margin: 0 0 45px
			}

			.about_blazon_section ul {
				gap: 80px 0
			}

			.about_blazon_section ul li .about_blazon_align .about_blazon_right h2 {
				font-size: 32px
			}

			.aboutus_whychooseus_section,
			.vision_mision_section,
			.our_recent_project {
				margin: 40px 0
			}

			.aboutus_whychooseus_section .head_text,
			.our_recent_project .head_text {
				margin: 0 0 45px
			}

			.aboutus_whychooseus_section .aboutus_whychooseus_align.even {
				margin: 80px 0 0 0
			}

			.about_counter_section {
				margin: 40px 0;
				padding: 60px 0
			}

			.expertise_page_section {
				margin: 60px 0
			}

			.expertise_page_section .head_text {
				margin: 0 0 45px
			}

			.cd-tab-filter ul {
				display: none
			}

			.cd-filter-content {
				display: block !important
			}

			.search input {
				margin: auto
			}

			.cd-select.cd-filters {
				display: flex;
				width: 100%;
				margin: 0 0 25px;
				align-items: center;
				justify-content: center
			}

			.cd-select.cd-filters select {
				padding: 10px 15px;
				background: transparent;
				border: 1px solid var(--border)
			}

			.contactus_page_section {
				margin: 40px 0
			}

			.contactus_page_section .head_text {
				margin: 0 0 45px
			}

			.service_individual_page,
			.related_product {
				margin: 40px 0
			}

			.service_individual_page .head_text,
			.how_its_works .head_text,
			.related_product .head_text {
				margin: 0 0 45px
			}

			.service_individual_page .service_dynamic {
				gap: 80px
			}

			.how_its_works {
				margin: 40px 0;
				padding: 60px 0
			}

			.how_its_works ul {
				gap: 65px 30px
			}

			.leader_ship_section {
				margin: 40px 0
			}

			.leader_ship_section .head_text {
				margin: 0 0 45px
			}

			.leader_ship_section ul {
				grid-template-columns: repeat(3, 1fr);
				gap: 40px 20px
			}
		}

		@media screen and (max-width:992px) {

			.wrapper,
			.header_section .wrapper_full {
				padding: 0 25px
			}

			.getintouch_section form {
				width: 100%
			}

			.footer_section .footer_bottom .footer_bottom_align .footer_bottom_left {
				width: 100%;
				margin: 0 0 40px 0
			}

			.footer_section .footer_bottom .footer_bottom_align .footer_bottom_right {
				width: 100%
			}

			.footer_section .footer_top .footer_align {
				grid-template-columns: repeat(1, 1fr)
			}

			.copy_text .copy_align {
				flex-direction: column-reverse;
				gap: 10px
			}

			.copy_text {
				padding: 15px 0
			}

			.slider_section .item_content h2 {
				font-size: 35px;
				padding: 0 30px
			}

			.vision_mision_section ul {
				grid-template-columns: repeat(1, 1fr)
			}

			.cd-gallery ul,
			.related_product ul,
			.how_its_works ul {
				grid-template-columns: repeat(2, 1fr)
			}

			.leader_ship_section ul {
				grid-template-columns: repeat(2, 1fr)
			}

			.leader_ship_section .leader_row .leader_grid .leader_box .leader_box_left {
				width: 100%
			}

			.leader_ship_section .leader_row .leader_grid .leader_box .leader_box_right {
				width: 100%;
				padding: 30px 0 0 0;
				border-top: 1px solid var(--bg_full);
				margin: 30px 0 0 0;
				border-left: 0
			}

			.leader_profile_page .leader_profile_align .leader_profile_left {
				width: 55%
			}

			.leader_profile_page .leader_profile_align .leader_profile_right {
				width: 40%
			}

			.thankyou_pages .thankyou_content {
				padding: 50px 25px
			}

			.thankyou_pages .thankyou_content p {
				max-width: 100%
			}
		}

		@media screen and (max-width:768px) {

			.wrapper,
			.header_section .wrapper_full {
				padding: 0 15px
			}

			.slider_section video {
				height: 65vh
			}

			.header_section {
				padding: 15px 0
			}

			.slider_section .item_content {
				bottom: 15px
			}

			.think_big_section .think_big_align .think_big_left {
				width: 100%;
				margin: 0 0 50px
			}

			.think_big_section .think_big_align .think_big_left h1,
			.think_big_section .think_big_align .think_big_left h1 span {
				text-align: center;
				margin: 0 0 35px
			}

			.think_big_section .think_big_align .think_big_left h1 br {
				display: contents
			}

			.think_big_section .think_big_align .think_big_left h4 {
				font-size: 30px;
				margin: 0 0 15px
			}

			.think_big_section .think_big_align .think_big_left p,
			.expertise_section ul li .expertise p {
				font-size: 16px;
				text-align: justify
			}

			.think_big_section .think_big_align .think_big_left a {
				width: fit-content;
				display: flex;
				margin: 0
			}

			.unique_btn span {
				font-size: 16px
			}

			.unique_btn .arrow {
				height: 42px;
				width: 42px
			}

			.unique_btn .arrow img {
				height: 8px
			}

			.unique_btn {
				padding: 10px 60px 10px 0vw
			}

			.think_big_section .think_big_align .think_big_right {
				width: 100%
			}

			.head_text p,
			.head_text h6 {
				font-size: 16px
			}

			.expertise_section ul li .expertise {
				gap: 15px
			}

			.expertise_section ul {
				display: inherit
			}

			.expertise_section ul.ul_service {
				display: none
			}

			.expertise_section ul.ul_service_mobile {
				display: flex;
				overflow: hidden
			}

			.expertise_section ul li {
				padding: 0;
				display: flex;
				height: 100%;
				align-items: stretch
			}

			.expertise_section ul li .expertise {
				padding: 35px 20px;
				position: inherit
			}

			.expertise_section ul li .e_hover ul {
				gap: 5px
			}

			.expertise_section ul li .e_hover ul li {
				font-size: 16px
			}

			.expertise_section ul li .e_hover {
				gap: 12px
			}

			.blazon_process .blazon_process_tab .blazon_process_top {
				display: none
			}

			.process_dropdown {
				position: relative;
				width: 100%;
				margin: 0 auto 40px;
				padding: 10px 15px;
				background: #fff;
				border-radius: 7px;
				border: 1px solid rgba(0, 0, 0, 0.15);
				box-shadow: 0 1px 1px rgb(50 50 50 / 10%);
				cursor: pointer;
				outline: 0;
				font-weight: bold;
				color: #8aa8bd;
				z-index: 100;
				text-transform: uppercase
			}

			.process_dropdown:after {
				content: "";
				width: 0;
				height: 0;
				position: absolute;
				right: 15px;
				top: 50%;
				margin-top: -3px;
				border-width: 6px 6px 0 6px;
				border-style: solid;
				border-color: #000 transparent
			}

			.process_dropdown .dropdown {
				position: absolute;
				top: 140%;
				left: 0;
				right: 0;
				background: white;
				border-radius: inherit;
				border: 1px solid rgba(0, 0, 0, 0.17);
				box-shadow: 0 0 5px rgba(0, 0, 0, 0.1);
				font-weight: normal;
				-webkit-transition: all .5s ease-in;
				-moz-transition: all .5s ease-in;
				-ms-transition: all .5s ease-in;
				-o-transition: all .5s ease-in;
				transition: all .5s ease-in;
				list-style: none;
				opacity: 0;
				pointer-events: none
			}

			.process_dropdown .dropdown:after {
				content: "";
				width: 0;
				height: 0;
				position: absolute;
				bottom: 100%;
				right: 15px;
				border-width: 0 6px 6px 6px;
				border-style: solid;
				border-color: #fff transparent
			}

			.process_dropdown .dropdown:before {
				content: "";
				width: 0;
				height: 0;
				position: absolute;
				bottom: 100%;
				right: 13px;
				border-width: 0 8px 8px 8px;
				border-style: solid;
				border-color: rgba(0, 0, 0, 0.1) transparent
			}

			.process_dropdown .dropdown li a {
				display: block;
				padding: 10px;
				text-decoration: none;
				color: #000;
				border-bottom: 1px solid #e6e8ea;
				box-shadow: inset 0 1px 0 rgba(255, 255, 255, 1);
				-webkit-transition: all .3s ease-out;
				-moz-transition: all .3s ease-out;
				-ms-transition: all .3s ease-out;
				-o-transition: all .3s ease-out;
				transition: all .3s ease-out
			}

			.dd span,
			.dd1 span {
				color: #000
			}

			.process_dropdown .dropdown li i {
				float: right;
				color: inherit
			}

			.process_dropdown .dropdown li:first-of-type a {
				border-radius: 7px 7px 0 0
			}

			.process_dropdown .dropdown li:last-of-type a {
				border: 0;
				border-radius: 0 0 7px 7px
			}

			.process_dropdown .dropdown li:hover a {
				background: #f3f8f8
			}

			.process_dropdown.active .dropdown {
				opacity: 1;
				pointer-events: auto
			}

			.no-opacity .process_dropdown .dropdown,
			.no-pointerevents .process_dropdown .dropdown {
				display: none;
				opacity: 1;
				pointer-events: auto
			}

			.no-opacity .process_dropdown.active .dropdown,
			.no-pointerevents .process_dropdown.active .dropdown {
				display: block
			}

			.blazon_process .blazon_process_tab .process_top_items_align .process_top_items_left h4 {
				font-size: 32px;
				margin: 0 0 15px
			}

			.blazon_process .blazon_process_tab .process_top_items_align .process_top_items_left p {
				font-size: 16px;
				text-align: justify
			}

			.blazon_process .blazon_process_tab .process_top_items_align .process_top_items_right,
			.blazon_process .blazon_process_tab .process_top_items_align .process_top_items_left {
				width: 100%
			}

			.blazon_process .blazon_process_tab .process_top_items_align {
				gap: 40px;
				flex-direction: column-reverse
			}

			.desktop_prodoct {
				display: none !important
			}

			.mobile_prodoct {
				display: flex !important;
				overflow: hidden
			}

			.our_milestones .our_milestones_align .our_milestones_left {
				width: 100%;
				margin: 0 0 45px
			}

			.our_milestones .our_milestones_align .our_milestones_left img {
				margin: auto
			}

			.our_milestones .our_milestones_align .our_milestones_right {
				width: 100%
			}

			.ourbrand_product ul li .our_product_box p,
			.our_milestones .our_milestones_align .our_milestones_right p {
				font-size: 16px;
				text-align: justify
			}

			.why_choose_blazon .why_choose_align .why_choose_left {
				width: 100%;
				margin: 0
			}

			.why_choose_blazon .why_choose_align {
				flex-direction: column-reverse;
				gap: 40px
			}

			.why_choose_blazon .why_choose_align .why_choose_right {
				width: 100%
			}

			.why_choose_blazon .why_choose_align .why_choose_left .why_choose_bottom ul li {
				font-size: 16px;
				padding: 0 0 0 30px
			}

			.why_choose_blazon .why_choose_align .why_choose_left .why_choose_bottom ul li::before {
				height: 17px;
				width: 17px;
				top: 9px
			}

			.why_choose_blazon .why_choose_align .why_choose_left .why_choose_bottom h2,
			.why_choose_blazon .why_choose_align .why_choose_left .why_choose_bottom h2 span {
				font-size: 30px
			}

			.faq_content p {
				font-size: 16px;
				text-align: justify
			}

			.brands_trust_section .brands_trust_align {
				flex-direction: column;
				gap: 45px
			}

			.brands_trust_section .brands_trust_align .brands_trust_right {
				width: 100%;
				margin: 0
			}

			.brands_trust_section .brands_trust_align .brands_trust_left {
				width: 100%
			}

			.faq_section_page .faq_align {
				padding: 0 0 0 40px
			}

			.faq_section_page::before {
				left: 40px
			}

			.faq_section_page .faq_align::before {
				left: -14px
			}

			.faq_section_page .faq_align::after {
				left: -37px
			}

			.faq_section .faq_align {
				flex-direction: column-reverse;
				gap: 45px
			}

			.faq_section .faq_align .faq_left {
				width: 100%;
				margin: 0
			}

			.faq_section .faq_align .faq_right {
				width: 100%
			}

			.faq_section .faq_align .faq_right img {
				margin: auto
			}

			.ourclients_section ul {
				grid-template-columns: repeat(3, 1fr)
			}

			.footer_section .footer_bottom .footer_bottom_align .footer_bottom_left ul {
				grid-template-columns: repeat(2, 1fr)
			}

			.why_choose_blazon .why_choose_align .why_choose_left .why_choose_top {
				display: none
			}

			.dd1 {
				display: block
			}

			.faq_section .faq_align .faq_left ul li .f_answer p {
				font-size: 16px
			}

			.faq_section .faq_align .faq_left ul li .f_question h4 {
				font-size: 16px
			}

			.about_blazon_section ul li .about_blazon_align,
			.about_blazon_section ul li:nth-child(even) .about_blazon_align {
				flex-direction: column-reverse
			}

			.about_blazon_section ul li .about_blazon_align .about_blazon_left {
				width: 100%
			}

			.about_blazon_section ul li .about_blazon_align .about_blazon_right {
				width: 100%;
				margin: 0 0 45px
			}

			.about_blazon_section ul li .about_blazon_align .about_blazon_right p {
				font-size: 16px;
				text-align: justify
			}

			.aboutus_whychooseus_section .aboutus_whychooseus_align,
			.aboutus_whychooseus_section .aboutus_whychooseus_align.even {
				flex-wrap: wrap;
				flex-direction: column;
				gap: 40px
			}

			.aboutus_whychooseus_section .aboutus_whychooseus_align .aboutus_whychooseus_left {
				width: 100%
			}

			.aboutus_whychooseus_section .aboutus_whychooseus_align .aboutus_whychooseus_right {
				width: 100%
			}

			.aboutus_whychooseus_section .aboutus_whychooseus_align .aboutus_whychooseus_right {
				width: 100%;
				margin: 0
			}

			.aboutus_whychooseus_section .aboutus_whychooseus_align .aboutus_whychooseus_right h2 {
				font-size: 32px
			}

			.about_counter_section ul {
				grid-template-columns: repeat(2, 1fr);
				gap: 50px 20px
			}

			.about_counter_section ul li h4 {
				font-size: 45px
			}

			.about_counter_section ul li p,
			.aboutus_whychooseus_section .aboutus_whychooseus_align .aboutus_whychooseus_right p,
			.vision_mision_section ul li p {
				font-size: 16px;
				text-align: justify
			}

			.vision_mision_section ul li img {
				margin: auto auto 30px
			}

			.vision_mision_section ul li h4,
			.vision_mision_section ul li p {
				text-align: center
			}

			.about_counter_section ul li p {
				text-align: center
			}

			.contactus_page_section .contactus_page_top ul {
				display: grid;
				grid-template-columns: repeat(2, 1fr);
				gap: 40px 20px
			}

			.contactus_page_section .contactus_page_top ul li a::before,
			.contactus_page_section .contactus_page_top ul li a::after {
				content: inherit
			}

			.contactus_page_section .contactus_page_top ul {
				border-bottom: 0
			}

			.contactus_page_section .contactus_page_top ul li a img {
				display: block
			}

			.contactus_page_section .contactus_page_top ul li a {
				border: 2px solid var(--border);
				padding: 30px 15px
			}

			.contactus_page_section .contactus_page_top ul li.active a {
				border: 2px solid var(--bg_full)
			}

			.contactus_page_section .location_content_align {
				flex-direction: column-reverse
			}

			.contactus_page_section .location_content_align .location_content_right {
				width: 100%;
				margin: 0 0 45px
			}

			.contactus_page_section .location_content_align .location_content_left {
				width: 100%
			}

			.contactus_page_section .location_content_align .location_content_right h2 {
				font-size: 32px;
				margin: 0 0 15px
			}

			.contactus_page_section .location_content_align .location_content_right ul li p {
				font-size: 16px
			}

			.service_individual_page .service_dynamic .service_dynamic_align,
			.service_individual_page .service_dynamic .service_dynamic_align:nth-child(even) {
				flex-direction: column-reverse;
				gap: 40px
			}

			.service_individual_page .service_dynamic .service_dynamic_align .service_dynamic_right {
				width: 100%;
				margin: 0
			}

			.service_individual_page .service_dynamic .service_dynamic_align .service_dynamic_left {
				width: 100%
			}

			.service_individual_page .service_dynamic .service_dynamic_align .service_dynamic_right p {
				font-size: 16px;
				text-align: justify
			}

			.service_individual_page .service_dynamic .service_dynamic_align .service_dynamic_right h2 {
				font-size: 30px
			}

			.cd-gallery ul,
			.related_product ul,
			.how_its_works ul {
				grid-template-columns: repeat(1, 1fr);
				gap: 45px
			}

			.how_its_works ul li p {
				font-size: 16px
			}

			.dd {
				display: block
			}

			.leader_profile_page .leader_profile_align {
				flex-wrap: wrap
			}

			.leader_profile_page .leader_profile_align .leader_profile_left {
				width: 100%;
				margin: 0 0 40px
			}

			.leader_profile_page .leader_profile_align .leader_profile_right {
				width: 100%
			}

			.thankyou_pages .thankyou_content p {
				font-size: 16px
			}

			.thankyou_pages .thankyou_content h1 {
				font-size: 35px
			}

			.thankyou_pages .thankyou_content img {
				height: 60px
			}

			.common_page_design .content_all p,
			.common_page_design .content_all h6 {
				font-size: 16px;
				text-align: justify
			}

			.common_page_design .content_all ul li {
				font-size: 16px;
				text-align: justify
			}

			.inner_page_banner_section h2 {
				font-size: 40px;
				padding: 0 15px 15px 15px
			}

			.blazon_process .blazon_process_tab .process_top_items_align .process_top_items_right h4 {
				display: block;
				text-align: center
			}

			.blazon_process .blazon_process_tab .process_top_items_align .process_top_items_left h4 {
				display: none
			}

			.blazon_process .blazon_process_tab .process_top_items_align {
				gap: 25px
			}

			.aboutus_whychooseus_section .aboutus_whychooseus_align .aboutus_whychooseus_left h2 {
				display: block
			}

			.aboutus_whychooseus_section .aboutus_whychooseus_align .aboutus_whychooseus_right h2 {
				display: none
			}

			.aboutus_whychooseus_section .aboutus_whychooseus_align,
			.aboutus_whychooseus_section .aboutus_whychooseus_align.even {
				gap: 25px
			}

			.aboutus_whychooseus_section .aboutus_whychooseus_align .aboutus_whychooseus_right p:last-child {
				margin: 0
			}

			.aboutus_whychooseus_section .aboutus_whychooseus_align.even {
				margin: 50px 0 0 0
			}

			.service_individual_page .service_dynamic .service_dynamic_align .service_dynamic_left h2 {
				display: block
			}

			.service_individual_page .service_dynamic .service_dynamic_align,
			.service_individual_page .service_dynamic .service_dynamic_align:nth-child(even) {
				flex-direction: column;
				gap: 25px
			}

			.service_individual_page .service_dynamic .service_dynamic_align .service_dynamic_right h2 {
				display: none
			}

			.about_blazon_section ul li .about_blazon_align .about_blazon_right h2 {
				display: none
			}

			.about_blazon_section ul li .about_blazon_align .about_blazon_left h2 {
				display: block
			}

			.about_blazon_section ul li .about_blazon_align .about_blazon_right {
				margin: 0
			}

			.about_blazon_section ul li .about_blazon_align,
			.about_blazon_section ul li:nth-child(even) .about_blazon_align {
				flex-direction: column;
				gap: 25px
			}
		}

		@media screen and (max-width:576px) {
			.header_section {
				padding: 12px 0
			}

			.header_section .header_align .header_left img {
				height: 40px
			}

			.header_section .header_align .header_icon ul li a {
				height: 37px;
				width: 37px;
				padding: 8px
			}

			.header_section .header_align .header_icon ul {
				gap: 13px
			}

			.header_section .header_align .header_icon {
				margin: 0 48px 0 0
			}

			.mob_menu .dl-trigger {
				width: 37px;
				height: 37px
			}

			.mob_menu .dl-trigger .m_outline {
				width: 31px
			}

			.mob_menu .dl-trigger .m_outline::before {
				width: 17px;
				top: -11px
			}

			.mob_menu .dl-trigger .m_outline::after {
				width: 17px;
				bottom: -11px
			}

			.mob_menu .dl-trigger.dl-active .m_outline {
				width: 37px;
				height: 37px
			}

			.think_slider_nav {
				right: 0;
				position: relative;
				float: right
			}

			.ourclients_section ul {
				grid-template-columns: repeat(2, 1fr)
			}

			.head_text p,
			.head_text h6 {
				max-width: 100%
			}

			.think_big_section .think_big_align .think_big_right .think_box .think_box_image ul {
				gap: 13px;
				bottom: 4px;
				padding: 0 15px
			}

			.faq_section_page .faq_align.faq_open .faq_question h4 {
				font-size: 35px
			}

			.faq_section_page .faq_align::after {
				height: 40px;
				width: 40px;
				background-size: 20px !important
			}

			.faq_section_page::before {
				left: 20px
			}

			.faq_section_page .faq_align::before {
				left: -34px
			}

			.faq_section_page .faq_align.connect.faq_open::after {
				left: -48px
			}

			.faq_section_page .faq_align {
				padding: 0 0 0 10px
			}

			.faq_section_page .faq_align::after {
				left: -49px
			}

			.head_text h2::before,
			.head_text h1::before {
				content: inherit
			}

			.cd-gallery ul {
				grid-template-columns: repeat(1, 1fr)
			}

			.search input {
				width: 260px
			}

			.ourbrand_product ul.case_studies {
				grid-template-columns: repeat(1, 1fr)
			}

			.header_section .header_align {
				height: 45px
			}

			.inner_page_banner_section h2 {
				font-size: 30px
			}
		}

		@media screen and (max-width:480px) {

			.getintouch_section form input,
			.getintouch_section form select {
				padding: 10px 15px
			}

			#h_name,
			#h_email,
			#h_phone,
			#h_brand {
				width: 100%;
				margin: 0 0 20px
			}

			.our_milestones .our_milestones_align .our_milestones_right ul li h4 {
				font-size: 40px
			}

			.our_milestones .our_milestones_align .our_milestones_right ul li {
				padding: 0 0 7px
			}

			.copy_text .copy_align .copy_right ul {
				flex-wrap: wrap;
				justify-content: center
			}

			.slider_section .item_content h2 {
				font-size: 30px;
				padding: 0 20px
			}

			.header_section .header_align .header_left {
				position: relative;
				z-index: 100
			}

			.header_section.dark_header {
				padding: 12px 0
			}

			.think_big_section .think_big_align .think_big_left h4 {
				font-size: 25px;
				margin: 0 0 15px;
				line-height: 1.4
			}

			.contactus_page_section .contactus_page_top ul li a {
				font-size: 15px
			}

			.leader_ship_section ul {
				grid-template-columns: repeat(1, 1fr)
			}

			.leader_ship_section .leader_row .leader_grid .leader_box .leader_box_left .leader_box_left_img {
				width: 100%
			}

			.leader_ship_section .leader_row .leader_grid .leader_box .leader_box_left .leader_box_left_content {
				width: 100%;
				margin: 20px 0 0 0
			}

			.leader_ship_section .leader_row .leader_grid .leader_box .leader_box_left_content .content_btn a:nth-child(1) button,
			.leader_ship_section .leader_row .leader_grid .leader_box .leader_box_left_content .content_btn a:nth-child(2) button {
				width: 100%
			}

			.leader_ship_section .leader_row .leader_grid .leader_box .leader_box_left_content .content_btn a {
				width: 100%
			}

			.think_big_section .think_big_align .think_big_right .think_box .think_box_image ul li {
				border-radius: 5px;
				height: auto
			}

			.think_big_section .think_big_align .think_big_right .think_box .think_box_image ul li {
				font-size: 15px;
				height: auto;
				box-shadow: inherit
			}

			.image_banner picture img,
			.image_banner picture,
			.image_banner {
				height: 65vh
			}

			.type-wrap span {
				font-size: 10vw
			}

			.ourbrand_product ul li {
				padding: 35px 20px
			}

			.footer_section .footer_top .footer_align .footer_left ul {
				grid-template-columns: repeat(1, 1fr)
			}

			.call_popup_align {
				gap: 30px 15px
			}

			.call_popup_align .call_popup_box a {
				font-size: 15px
			}

			.call_popup_align .call_popup_box img {
				height: 45px;
				margin: auto auto 10px
			}
		}

		@media screen and (max-width:380px) {

			.footer_section .footer_top .footer_align .footer_left ul,
			.footer_section .footer_bottom .footer_bottom_align .footer_bottom_left ul {
				grid-template-columns: repeat(1, 1fr)
			}

			.header_section .header_align .header_left img {
				height: 35px
			}

			.header_section .header_align .header_icon ul li a {
				height: 32px;
				width: 32px;
				padding: 7px
			}

			.mob_menu .dl-trigger.dl-active .m_outline {
				width: 34px;
				height: 34px
			}

			.call_popup_align .call_popup_box {
				padding: 5px
			}
		}

		/*site_map*/
		.sitemap_section {
			width: 100%;
			display: inline-block;
			margin: 20px 0;
		}

		.sitemap_section .head_text {
			text-align: center;
			margin: 0 0 45px;
		}

		.sitemap_section ul li::before {
			content: "\00BB";
			font-size: 22px;
			line-break: normal;
			margin-right: 4px;
			font-weight: 600;
		}

		.sitemap_section ul {
			padding: 0 0 0 0;
			width: fit-content;
			display: inline-block;
		}

		.sitemap_section ul ul {
			padding: 0 0 0 20px;
			width: 100%;
			display: inline-block;
		}

		.sitemap_section ul li {
			font-size: 18px;
			font-family: var(--bold);
			line-height: 1.4;
			width: fit-content;
		}

		.sitemap_section ul li.bold ul li {
			font-size: 18px;
			font-family: var(--bold);
			line-height: 1.4;
		}

		.sitemap_section ul ul li {
			font-size: 18px;
			font-family: var(--regular);
			line-height: 1.4;
		}

		.sitemap_section ul li.bold ul ul li {
			font-size: 18px;
			font-family: var(--regular);
			line-height: 1.4;
		}

		.sitemap_section ul li:hover {
			color: var(--bg_full)
		}

		.sitemap_section ul li:hover ul li {
			color: #000;
		}

		.sitemap_section ul li ul li:hover {
			color: var(--bg_full)
		}

		.think_big_section .think_big_align .think_big_right .think_box .think_box_image ul li img {
			background: #f7f8f8;
			border-radius: 100%;
		}

		.brand_color {
			color: var(--bg_full);
			font-weight: 600;
			text-decoration: underline;
		}

		.think_big_section .think_big_align .think_big_left p sup {
			vertical-align: sub;
		}

		#preloader {
			position: fixed;
			top: 0;
			left: 0;
			width: 100%;
			height: 100%;
			background-color: #f6f5f1;
			z-index: 999999;
			display: -webkit-box;
			display: -ms-flexbox;
			display: flex;
			-webkit-box-pack: center;
			-ms-flex-pack: center;
			justify-content: center;
			-webkit-box-align: center;
			-ms-flex-align: center;
			align-items: center;
		}

		.home-dark #preloader {
			background: #171719;
		}

		.deco-loader *,
		.deco-loader :after,
		.deco-loader :before {
			box-sizing: border-box;
			-o-box-sizing: border-box;
			-ms-box-sizing: border-box;
			-webkit-box-sizing: border-box;
			-moz-box-sizing: border-box;
		}

		.deco-loader {
			position: relative;
			margin: 97px auto;
			display: block;
			width: 49px;
		}

		.sheath {
			position: absolute;
			transform-origin: 50% 50%;
			-o-transform-origin: 50% 50%;
			-ms-transform-origin: 50% 50%;
			-webkit-transform-origin: 50% 50%;
			-moz-transform-origin: 50% 50%;
		}

		.segment {
			background-color: var(--bg_full);
			border-radius: 27px;
			height: 6px;
			transform-origin: 0 0;
			-o-transform-origin: 0 0;
			-ms-transform-origin: 0 0;
			-webkit-transform-origin: 0 0;
			-moz-transform-origin: 0 0;
			width: 18px;
		}

		.sheath:nth-child(1) {
			animation: segment-orbit-1 2.07s infinite linear, segment-opacity-1 1.293s infinite linear;
			-o-animation: segment-orbit-1 2.07s infinite linear, segment-opacity-1 1.293s infinite linear;
			-ms-animation: segment-orbit-1 2.07s infinite linear, segment-opacity-1 1.293s infinite linear;
			-webkit-animation: segment-orbit-1 2.07s infinite linear, segment-opacity-1 1.293s infinite linear;
			-moz-animation: segment-orbit-1 2.07s infinite linear, segment-opacity-1 1.293s infinite linear;
			transform: rotate(-30deg) translate(23px);
			-o-transform: rotate(-30deg) translate(23px);
			-ms-transform: rotate(-30deg) translate(23px);
			-webkit-transform: rotate(-30deg) translate(23px);
			-moz-transform: rotate(-30deg) translate(23px);
		}

		.sheath:nth-child(1) .segment {
			animation: segment-scale-1 1.293s infinite linear;
			-o-animation: segment-scale-1 1.293s infinite linear;
			-ms-animation: segment-scale-1 1.293s infinite linear;
			-webkit-animation: segment-scale-1 1.293s infinite linear;
			-moz-animation: segment-scale-1 1.293s infinite linear;
		}

		.sheath:nth-child(2) {
			animation: segment-orbit-2 2.07s infinite linear, segment-opacity-2 1.293s infinite linear;
			-o-animation: segment-orbit-2 2.07s infinite linear, segment-opacity-2 1.293s infinite linear;
			-ms-animation: segment-orbit-2 2.07s infinite linear, segment-opacity-2 1.293s infinite linear;
			-webkit-animation: segment-orbit-2 2.07s infinite linear, segment-opacity-2 1.293s infinite linear;
			-moz-animation: segment-orbit-2 2.07s infinite linear, segment-opacity-2 1.293s infinite linear;
			transform: rotate(-60deg) translate(23px);
			-o-transform: rotate(-60deg) translate(23px);
			-ms-transform: rotate(-60deg) translate(23px);
			-webkit-transform: rotate(-60deg) translate(23px);
			-moz-transform: rotate(-60deg) translate(23px);
		}

		.sheath:nth-child(2) .segment {
			animation: segment-scale-2 1.293s infinite linear;
			-o-animation: segment-scale-2 1.293s infinite linear;
			-ms-animation: segment-scale-2 1.293s infinite linear;
			-webkit-animation: segment-scale-2 1.293s infinite linear;
			-moz-animation: segment-scale-2 1.293s infinite linear;
		}

		.sheath:nth-child(3) {
			animation: segment-orbit-3 2.07s infinite linear, segment-opacity-3 1.293s infinite linear;
			-o-animation: segment-orbit-3 2.07s infinite linear, segment-opacity-3 1.293s infinite linear;
			-ms-animation: segment-orbit-3 2.07s infinite linear, segment-opacity-3 1.293s infinite linear;
			-webkit-animation: segment-orbit-3 2.07s infinite linear, segment-opacity-3 1.293s infinite linear;
			-moz-animation: segment-orbit-3 2.07s infinite linear, segment-opacity-3 1.293s infinite linear;
			transform: rotate(-90deg) translate(23px);
			-o-transform: rotate(-90deg) translate(23px);
			-ms-transform: rotate(-90deg) translate(23px);
			-webkit-transform: rotate(-90deg) translate(23px);
			-moz-transform: rotate(-90deg) translate(23px);
		}

		.sheath:nth-child(3) .segment {
			animation: segment-scale-3 1.293s infinite linear;
			-o-animation: segment-scale-3 1.293s infinite linear;
			-ms-animation: segment-scale-3 1.293s infinite linear;
			-webkit-animation: segment-scale-3 1.293s infinite linear;
			-moz-animation: segment-scale-3 1.293s infinite linear;
		}

		.sheath:nth-child(4) {
			animation: segment-orbit-4 2.07s infinite linear, segment-opacity-4 1.293s infinite linear;
			-o-animation: segment-orbit-4 2.07s infinite linear, segment-opacity-4 1.293s infinite linear;
			-ms-animation: segment-orbit-4 2.07s infinite linear, segment-opacity-4 1.293s infinite linear;
			-webkit-animation: segment-orbit-4 2.07s infinite linear, segment-opacity-4 1.293s infinite linear;
			-moz-animation: segment-orbit-4 2.07s infinite linear, segment-opacity-4 1.293s infinite linear;
			transform: rotate(-120deg) translate(23px);
			-o-transform: rotate(-120deg) translate(23px);
			-ms-transform: rotate(-120deg) translate(23px);
			-webkit-transform: rotate(-120deg) translate(23px);
			-moz-transform: rotate(-120deg) translate(23px);
		}

		.sheath:nth-child(4) .segment {
			animation: segment-scale-4 1.293s infinite linear;
			-o-animation: segment-scale-4 1.293s infinite linear;
			-ms-animation: segment-scale-4 1.293s infinite linear;
			-webkit-animation: segment-scale-4 1.293s infinite linear;
			-moz-animation: segment-scale-4 1.293s infinite linear;
		}

		.sheath:nth-child(5) {
			animation: segment-orbit-5 2.07s infinite linear, segment-opacity-5 1.293s infinite linear;
			-o-animation: segment-orbit-5 2.07s infinite linear, segment-opacity-5 1.293s infinite linear;
			-ms-animation: segment-orbit-5 2.07s infinite linear, segment-opacity-5 1.293s infinite linear;
			-webkit-animation: segment-orbit-5 2.07s infinite linear, segment-opacity-5 1.293s infinite linear;
			-moz-animation: segment-orbit-5 2.07s infinite linear, segment-opacity-5 1.293s infinite linear;
			transform: rotate(-150deg) translate(23px);
			-o-transform: rotate(-150deg) translate(23px);
			-ms-transform: rotate(-150deg) translate(23px);
			-webkit-transform: rotate(-150deg) translate(23px);
			-moz-transform: rotate(-150deg) translate(23px);
		}

		.sheath:nth-child(5) .segment {
			animation: segment-scale-5 1.293s infinite linear;
			-o-animation: segment-scale-5 1.293s infinite linear;
			-ms-animation: segment-scale-5 1.293s infinite linear;
			-webkit-animation: segment-scale-5 1.293s infinite linear;
			-moz-animation: segment-scale-5 1.293s infinite linear;
		}

		.sheath:nth-child(6) {
			animation: segment-orbit-6 2.07s infinite linear, segment-opacity-6 1.293s infinite linear;
			-o-animation: segment-orbit-6 2.07s infinite linear, segment-opacity-6 1.293s infinite linear;
			-ms-animation: segment-orbit-6 2.07s infinite linear, segment-opacity-6 1.293s infinite linear;
			-webkit-animation: segment-orbit-6 2.07s infinite linear, segment-opacity-6 1.293s infinite linear;
			-moz-animation: segment-orbit-6 2.07s infinite linear, segment-opacity-6 1.293s infinite linear;
			transform: rotate(-180deg) translate(23px);
			-o-transform: rotate(-180deg) translate(23px);
			-ms-transform: rotate(-180deg) translate(23px);
			-webkit-transform: rotate(-180deg) translate(23px);
			-moz-transform: rotate(-180deg) translate(23px);
		}

		.sheath:nth-child(6) .segment {
			animation: segment-scale-6 1.293s infinite linear;
			-o-animation: segment-scale-6 1.293s infinite linear;
			-ms-animation: segment-scale-6 1.293s infinite linear;
			-webkit-animation: segment-scale-6 1.293s infinite linear;
			-moz-animation: segment-scale-6 1.293s infinite linear;
		}

		.sheath:nth-child(7) {
			animation: segment-orbit-7 2.07s infinite linear, segment-opacity-7 1.293s infinite linear;
			-o-animation: segment-orbit-7 2.07s infinite linear, segment-opacity-7 1.293s infinite linear;
			-ms-animation: segment-orbit-7 2.07s infinite linear, segment-opacity-7 1.293s infinite linear;
			-webkit-animation: segment-orbit-7 2.07s infinite linear, segment-opacity-7 1.293s infinite linear;
			-moz-animation: segment-orbit-7 2.07s infinite linear, segment-opacity-7 1.293s infinite linear;
			transform: rotate(-210deg) translate(23px);
			-o-transform: rotate(-210deg) translate(23px);
			-ms-transform: rotate(-210deg) translate(23px);
			-webkit-transform: rotate(-210deg) translate(23px);
			-moz-transform: rotate(-210deg) translate(23px);
		}

		.sheath:nth-child(7) .segment {
			animation: segment-scale-7 1.293s infinite linear;
			-o-animation: segment-scale-7 1.293s infinite linear;
			-ms-animation: segment-scale-7 1.293s infinite linear;
			-webkit-animation: segment-scale-7 1.293s infinite linear;
			-moz-animation: segment-scale-7 1.293s infinite linear;
		}

		.sheath:nth-child(8) {
			animation: segment-orbit-8 2.07s infinite linear, segment-opacity-8 1.293s infinite linear;
			-o-animation: segment-orbit-8 2.07s infinite linear, segment-opacity-8 1.293s infinite linear;
			-ms-animation: segment-orbit-8 2.07s infinite linear, segment-opacity-8 1.293s infinite linear;
			-webkit-animation: segment-orbit-8 2.07s infinite linear, segment-opacity-8 1.293s infinite linear;
			-moz-animation: segment-orbit-8 2.07s infinite linear, segment-opacity-8 1.293s infinite linear;
			transform: rotate(-240deg) translate(23px);
			-o-transform: rotate(-240deg) translate(23px);
			-ms-transform: rotate(-240deg) translate(23px);
			-webkit-transform: rotate(-240deg) translate(23px);
			-moz-transform: rotate(-240deg) translate(23px);
		}

		.sheath:nth-child(8) .segment {
			animation: segment-scale-8 1.293s infinite linear;
			-o-animation: segment-scale-8 1.293s infinite linear;
			-ms-animation: segment-scale-8 1.293s infinite linear;
			-webkit-animation: segment-scale-8 1.293s infinite linear;
			-moz-animation: segment-scale-8 1.293s infinite linear;
		}

		.sheath:nth-child(9) {
			animation: segment-orbit-9 2.07s infinite linear, segment-opacity-9 1.293s infinite linear;
			-o-animation: segment-orbit-9 2.07s infinite linear, segment-opacity-9 1.293s infinite linear;
			-ms-animation: segment-orbit-9 2.07s infinite linear, segment-opacity-9 1.293s infinite linear;
			-webkit-animation: segment-orbit-9 2.07s infinite linear, segment-opacity-9 1.293s infinite linear;
			-moz-animation: segment-orbit-9 2.07s infinite linear, segment-opacity-9 1.293s infinite linear;
			transform: rotate(-270deg) translate(23px);
			-o-transform: rotate(-270deg) translate(23px);
			-ms-transform: rotate(-270deg) translate(23px);
			-webkit-transform: rotate(-270deg) translate(23px);
			-moz-transform: rotate(-270deg) translate(23px);
		}

		.sheath:nth-child(9) .segment {
			animation: segment-scale-9 1.293s infinite linear;
			-o-animation: segment-scale-9 1.293s infinite linear;
			-ms-animation: segment-scale-9 1.293s infinite linear;
			-webkit-animation: segment-scale-9 1.293s infinite linear;
			-moz-animation: segment-scale-9 1.293s infinite linear;
		}

		.sheath:nth-child(10) {
			animation: segment-orbit-10 2.07s infinite linear, segment-opacity-10 1.293s infinite linear;
			-o-animation: segment-orbit-10 2.07s infinite linear, segment-opacity-10 1.293s infinite linear;
			-ms-animation: segment-orbit-10 2.07s infinite linear, segment-opacity-10 1.293s infinite linear;
			-webkit-animation: segment-orbit-10 2.07s infinite linear, segment-opacity-10 1.293s infinite linear;
			-moz-animation: segment-orbit-10 2.07s infinite linear, segment-opacity-10 1.293s infinite linear;
			transform: rotate(-300deg) translate(23px);
			-o-transform: rotate(-300deg) translate(23px);
			-ms-transform: rotate(-300deg) translate(23px);
			-webkit-transform: rotate(-300deg) translate(23px);
			-moz-transform: rotate(-300deg) translate(23px);
		}

		.sheath:nth-child(10) .segment {
			animation: segment-scale-10 1.293s infinite linear;
			-o-animation: segment-scale-10 1.293s infinite linear;
			-ms-animation: segment-scale-10 1.293s infinite linear;
			-webkit-animation: segment-scale-10 1.293s infinite linear;
			-moz-animation: segment-scale-10 1.293s infinite linear;
		}

		.sheath:nth-child(11) {
			animation: segment-orbit-11 2.07s infinite linear, segment-opacity-11 1.293s infinite linear;
			-o-animation: segment-orbit-11 2.07s infinite linear, segment-opacity-11 1.293s infinite linear;
			-ms-animation: segment-orbit-11 2.07s infinite linear, segment-opacity-11 1.293s infinite linear;
			-webkit-animation: segment-orbit-11 2.07s infinite linear, segment-opacity-11 1.293s infinite linear;
			-moz-animation: segment-orbit-11 2.07s infinite linear, segment-opacity-11 1.293s infinite linear;
			transform: rotate(-330deg) translate(23px);
			-o-transform: rotate(-330deg) translate(23px);
			-ms-transform: rotate(-330deg) translate(23px);
			-webkit-transform: rotate(-330deg) translate(23px);
			-moz-transform: rotate(-330deg) translate(23px);
		}

		.sheath:nth-child(11) .segment {
			animation: segment-scale-11 1.293s infinite linear;
			-o-animation: segment-scale-11 1.293s infinite linear;
			-ms-animation: segment-scale-11 1.293s infinite linear;
			-webkit-animation: segment-scale-11 1.293s infinite linear;
			-moz-animation: segment-scale-11 1.293s infinite linear;
		}

		.sheath:nth-child(12) {
			animation: segment-orbit-12 2.07s infinite linear, segment-opacity-12 1.293s infinite linear;
			-o-animation: segment-orbit-12 2.07s infinite linear, segment-opacity-12 1.293s infinite linear;
			-ms-animation: segment-orbit-12 2.07s infinite linear, segment-opacity-12 1.293s infinite linear;
			-webkit-animation: segment-orbit-12 2.07s infinite linear, segment-opacity-12 1.293s infinite linear;
			-moz-animation: segment-orbit-12 2.07s infinite linear, segment-opacity-12 1.293s infinite linear;
			transform: rotate(-360deg) translate(23px);
			-o-transform: rotate(-360deg) translate(23px);
			-ms-transform: rotate(-360deg) translate(23px);
			-webkit-transform: rotate(-360deg) translate(23px);
			-moz-transform: rotate(-360deg) translate(23px);
		}

		.sheath:nth-child(12) .segment {
			animation: segment-scale-12 1.293s infinite linear;
			-o-animation: segment-scale-12 1.293s infinite linear;
			-ms-animation: segment-scale-12 1.293s infinite linear;
			-webkit-animation: segment-scale-12 1.293s infinite linear;
			-moz-animation: segment-scale-12 1.293s infinite linear;
		}

		@keyframes segment-orbit-1 {
			from {
				transform: rotate(30deg) translate(23px);
			}

			50% {
				transform: rotate(210deg) translate(28px);
			}

			to {
				transform: rotate(390deg) translate(23px);
			}
		}

		@-o-keyframes segment-orbit-1 {
			from {
				-o-transform: rotate(30deg) translate(23px);
			}

			50% {
				-o-transform: rotate(210deg) translate(28px);
			}

			to {
				-o-transform: rotate(390deg) translate(23px);
			}
		}

		@-ms-keyframes segment-orbit-1 {
			from {
				-ms-transform: rotate(30deg) translate(23px);
			}

			50% {
				-ms-transform: rotate(210deg) translate(28px);
			}

			to {
				-ms-transform: rotate(390deg) translate(23px);
			}
		}

		@-webkit-keyframes segment-orbit-1 {
			from {
				-webkit-transform: rotate(30deg) translate(23px);
			}

			50% {
				-webkit-transform: rotate(210deg) translate(28px);
			}

			to {
				-webkit-transform: rotate(390deg) translate(23px);
			}
		}

		@-moz-keyframes segment-orbit-1 {
			from {
				-moz-transform: rotate(30deg) translate(23px);
			}

			50% {
				-moz-transform: rotate(210deg) translate(28px);
			}

			to {
				-moz-transform: rotate(390deg) translate(23px);
			}
		}

		@keyframes segment-orbit-2 {
			from {
				transform: rotate(60deg) translate(23px);
			}

			50% {
				transform: rotate(240deg) translate(28px);
			}

			to {
				transform: rotate(420deg) translate(23px);
			}
		}

		@-o-keyframes segment-orbit-2 {
			from {
				-o-transform: rotate(60deg) translate(23px);
			}

			50% {
				-o-transform: rotate(240deg) translate(28px);
			}

			to {
				-o-transform: rotate(420deg) translate(23px);
			}
		}

		@-ms-keyframes segment-orbit-2 {
			from {
				-ms-transform: rotate(60deg) translate(23px);
			}

			50% {
				-ms-transform: rotate(240deg) translate(28px);
			}

			to {
				-ms-transform: rotate(420deg) translate(23px);
			}
		}

		@-webkit-keyframes segment-orbit-2 {
			from {
				-webkit-transform: rotate(60deg) translate(23px);
			}

			50% {
				-webkit-transform: rotate(240deg) translate(28px);
			}

			to {
				-webkit-transform: rotate(420deg) translate(23px);
			}
		}

		@-moz-keyframes segment-orbit-2 {
			from {
				-moz-transform: rotate(60deg) translate(23px);
			}

			50% {
				-moz-transform: rotate(240deg) translate(28px);
			}

			to {
				-moz-transform: rotate(420deg) translate(23px);
			}
		}

		@keyframes segment-orbit-3 {
			from {
				transform: rotate(90deg) translate(23px);
			}

			50% {
				transform: rotate(270deg) translate(28px);
			}

			to {
				transform: rotate(450deg) translate(23px);
			}
		}

		@-o-keyframes segment-orbit-3 {
			from {
				-o-transform: rotate(90deg) translate(23px);
			}

			50% {
				-o-transform: rotate(270deg) translate(28px);
			}

			to {
				-o-transform: rotate(450deg) translate(23px);
			}
		}

		@-ms-keyframes segment-orbit-3 {
			from {
				-ms-transform: rotate(90deg) translate(23px);
			}

			50% {
				-ms-transform: rotate(270deg) translate(28px);
			}

			to {
				-ms-transform: rotate(450deg) translate(23px);
			}
		}

		@-webkit-keyframes segment-orbit-3 {
			from {
				-webkit-transform: rotate(90deg) translate(23px);
			}

			50% {
				-webkit-transform: rotate(270deg) translate(28px);
			}

			to {
				-webkit-transform: rotate(450deg) translate(23px);
			}
		}

		@-moz-keyframes segment-orbit-3 {
			from {
				-moz-transform: rotate(90deg) translate(23px);
			}

			50% {
				-moz-transform: rotate(270deg) translate(28px);
			}

			to {
				-moz-transform: rotate(450deg) translate(23px);
			}
		}

		@keyframes segment-orbit-4 {
			from {
				transform: rotate(120deg) translate(23px);
			}

			50% {
				transform: rotate(300deg) translate(28px);
			}

			to {
				transform: rotate(480deg) translate(23px);
			}
		}

		@-o-keyframes segment-orbit-4 {
			from {
				-o-transform: rotate(120deg) translate(23px);
			}

			50% {
				-o-transform: rotate(300deg) translate(28px);
			}

			to {
				-o-transform: rotate(480deg) translate(23px);
			}
		}

		@-ms-keyframes segment-orbit-4 {
			from {
				-ms-transform: rotate(120deg) translate(23px);
			}

			50% {
				-ms-transform: rotate(300deg) translate(28px);
			}

			to {
				-ms-transform: rotate(480deg) translate(23px);
			}
		}

		@-webkit-keyframes segment-orbit-4 {
			from {
				-webkit-transform: rotate(120deg) translate(23px);
			}

			50% {
				-webkit-transform: rotate(300deg) translate(28px);
			}

			to {
				-webkit-transform: rotate(480deg) translate(23px);
			}
		}

		@-moz-keyframes segment-orbit-4 {
			from {
				-moz-transform: rotate(120deg) translate(23px);
			}

			50% {
				-moz-transform: rotate(300deg) translate(28px);
			}

			to {
				-moz-transform: rotate(480deg) translate(23px);
			}
		}

		@keyframes segment-orbit-5 {
			from {
				transform: rotate(150deg) translate(23px);
			}

			50% {
				transform: rotate(330deg) translate(28px);
			}

			to {
				transform: rotate(510deg) translate(23px);
			}
		}

		@-o-keyframes segment-orbit-5 {
			from {
				-o-transform: rotate(150deg) translate(23px);
			}

			50% {
				-o-transform: rotate(330deg) translate(28px);
			}

			to {
				-o-transform: rotate(510deg) translate(23px);
			}
		}

		@-ms-keyframes segment-orbit-5 {
			from {
				-ms-transform: rotate(150deg) translate(23px);
			}

			50% {
				-ms-transform: rotate(330deg) translate(28px);
			}

			to {
				-ms-transform: rotate(510deg) translate(23px);
			}
		}

		@-webkit-keyframes segment-orbit-5 {
			from {
				-webkit-transform: rotate(150deg) translate(23px);
			}

			50% {
				-webkit-transform: rotate(330deg) translate(28px);
			}

			to {
				-webkit-transform: rotate(510deg) translate(23px);
			}
		}

		@-moz-keyframes segment-orbit-5 {
			from {
				-moz-transform: rotate(150deg) translate(23px);
			}

			50% {
				-moz-transform: rotate(330deg) translate(28px);
			}

			to {
				-moz-transform: rotate(510deg) translate(23px);
			}
		}

		@keyframes segment-orbit-6 {
			from {
				transform: rotate(180deg) translate(23px);
			}

			50% {
				transform: rotate(360deg) translate(28px);
			}

			to {
				transform: rotate(540deg) translate(23px);
			}
		}

		@-o-keyframes segment-orbit-6 {
			from {
				-o-transform: rotate(180deg) translate(23px);
			}

			50% {
				-o-transform: rotate(360deg) translate(28px);
			}

			to {
				-o-transform: rotate(540deg) translate(23px);
			}
		}

		@-ms-keyframes segment-orbit-6 {
			from {
				-ms-transform: rotate(180deg) translate(23px);
			}

			50% {
				-ms-transform: rotate(360deg) translate(28px);
			}

			to {
				-ms-transform: rotate(540deg) translate(23px);
			}
		}

		@-webkit-keyframes segment-orbit-6 {
			from {
				-webkit-transform: rotate(180deg) translate(23px);
			}

			50% {
				-webkit-transform: rotate(360deg) translate(28px);
			}

			to {
				-webkit-transform: rotate(540deg) translate(23px);
			}
		}

		@-moz-keyframes segment-orbit-6 {
			from {
				-moz-transform: rotate(180deg) translate(23px);
			}

			50% {
				-moz-transform: rotate(360deg) translate(28px);
			}

			to {
				-moz-transform: rotate(540deg) translate(23px);
			}
		}

		@keyframes segment-orbit-7 {
			from {
				transform: rotate(210deg) translate(23px);
			}

			50% {
				transform: rotate(390deg) translate(28px);
			}

			to {
				transform: rotate(570deg) translate(23px);
			}
		}

		@-o-keyframes segment-orbit-7 {
			from {
				-o-transform: rotate(210deg) translate(23px);
			}

			50% {
				-o-transform: rotate(390deg) translate(28px);
			}

			to {
				-o-transform: rotate(570deg) translate(23px);
			}
		}

		@-ms-keyframes segment-orbit-7 {
			from {
				-ms-transform: rotate(210deg) translate(23px);
			}

			50% {
				-ms-transform: rotate(390deg) translate(28px);
			}

			to {
				-ms-transform: rotate(570deg) translate(23px);
			}
		}

		@-webkit-keyframes segment-orbit-7 {
			from {
				-webkit-transform: rotate(210deg) translate(23px);
			}

			50% {
				-webkit-transform: rotate(390deg) translate(28px);
			}

			to {
				-webkit-transform: rotate(570deg) translate(23px);
			}
		}

		@-moz-keyframes segment-orbit-7 {
			from {
				-moz-transform: rotate(210deg) translate(23px);
			}

			50% {
				-moz-transform: rotate(390deg) translate(28px);
			}

			to {
				-moz-transform: rotate(570deg) translate(23px);
			}
		}

		@keyframes segment-orbit-8 {
			from {
				transform: rotate(240deg) translate(23px);
			}

			50% {
				transform: rotate(420deg) translate(28px);
			}

			to {
				transform: rotate(600deg) translate(23px);
			}
		}

		@-o-keyframes segment-orbit-8 {
			from {
				-o-transform: rotate(240deg) translate(23px);
			}

			50% {
				-o-transform: rotate(420deg) translate(28px);
			}

			to {
				-o-transform: rotate(600deg) translate(23px);
			}
		}

		@-ms-keyframes segment-orbit-8 {
			from {
				-ms-transform: rotate(240deg) translate(23px);
			}

			50% {
				-ms-transform: rotate(420deg) translate(28px);
			}

			to {
				-ms-transform: rotate(600deg) translate(23px);
			}
		}

		@-webkit-keyframes segment-orbit-8 {
			from {
				-webkit-transform: rotate(240deg) translate(23px);
			}

			50% {
				-webkit-transform: rotate(420deg) translate(28px);
			}

			to {
				-webkit-transform: rotate(600deg) translate(23px);
			}
		}

		@-moz-keyframes segment-orbit-8 {
			from {
				-moz-transform: rotate(240deg) translate(23px);
			}

			50% {
				-moz-transform: rotate(420deg) translate(28px);
			}

			to {
				-moz-transform: rotate(600deg) translate(23px);
			}
		}

		@keyframes segment-orbit-9 {
			from {
				transform: rotate(270deg) translate(23px);
			}

			50% {
				transform: rotate(450deg) translate(28px);
			}

			to {
				transform: rotate(630deg) translate(23px);
			}
		}

		@-o-keyframes segment-orbit-9 {
			from {
				-o-transform: rotate(270deg) translate(23px);
			}

			50% {
				-o-transform: rotate(450deg) translate(28px);
			}

			to {
				-o-transform: rotate(630deg) translate(23px);
			}
		}

		@-ms-keyframes segment-orbit-9 {
			from {
				-ms-transform: rotate(270deg) translate(23px);
			}

			50% {
				-ms-transform: rotate(450deg) translate(28px);
			}

			to {
				-ms-transform: rotate(630deg) translate(23px);
			}
		}

		@-webkit-keyframes segment-orbit-9 {
			from {
				-webkit-transform: rotate(270deg) translate(23px);
			}

			50% {
				-webkit-transform: rotate(450deg) translate(28px);
			}

			to {
				-webkit-transform: rotate(630deg) translate(23px);
			}
		}

		@-moz-keyframes segment-orbit-9 {
			from {
				-moz-transform: rotate(270deg) translate(23px);
			}

			50% {
				-moz-transform: rotate(450deg) translate(28px);
			}

			to {
				-moz-transform: rotate(630deg) translate(23px);
			}
		}

		@keyframes segment-orbit-10 {
			from {
				transform: rotate(300deg) translate(23px);
			}

			50% {
				transform: rotate(480deg) translate(28px);
			}

			to {
				transform: rotate(660deg) translate(23px);
			}
		}

		@-o-keyframes segment-orbit-10 {
			from {
				-o-transform: rotate(300deg) translate(23px);
			}

			50% {
				-o-transform: rotate(480deg) translate(28px);
			}

			to {
				-o-transform: rotate(660deg) translate(23px);
			}
		}

		@-ms-keyframes segment-orbit-10 {
			from {
				-ms-transform: rotate(300deg) translate(23px);
			}

			50% {
				-ms-transform: rotate(480deg) translate(28px);
			}

			to {
				-ms-transform: rotate(660deg) translate(23px);
			}
		}

		@-webkit-keyframes segment-orbit-10 {
			from {
				-webkit-transform: rotate(300deg) translate(23px);
			}

			50% {
				-webkit-transform: rotate(480deg) translate(28px);
			}

			to {
				-webkit-transform: rotate(660deg) translate(23px);
			}
		}

		@-moz-keyframes segment-orbit-10 {
			from {
				-moz-transform: rotate(300deg) translate(23px);
			}

			50% {
				-moz-transform: rotate(480deg) translate(28px);
			}

			to {
				-moz-transform: rotate(660deg) translate(23px);
			}
		}

		@keyframes segment-orbit-11 {
			from {
				transform: rotate(330deg) translate(23px);
			}

			50% {
				transform: rotate(510deg) translate(28px);
			}

			to {
				transform: rotate(690deg) translate(23px);
			}
		}

		@-o-keyframes segment-orbit-11 {
			from {
				-o-transform: rotate(330deg) translate(23px);
			}

			50% {
				-o-transform: rotate(510deg) translate(28px);
			}

			to {
				-o-transform: rotate(690deg) translate(23px);
			}
		}

		@-ms-keyframes segment-orbit-11 {
			from {
				-ms-transform: rotate(330deg) translate(23px);
			}

			50% {
				-ms-transform: rotate(510deg) translate(28px);
			}

			to {
				-ms-transform: rotate(690deg) translate(23px);
			}
		}

		@-webkit-keyframes segment-orbit-11 {
			from {
				-webkit-transform: rotate(330deg) translate(23px);
			}

			50% {
				-webkit-transform: rotate(510deg) translate(28px);
			}

			to {
				-webkit-transform: rotate(690deg) translate(23px);
			}
		}

		@-moz-keyframes segment-orbit-11 {
			from {
				-moz-transform: rotate(330deg) translate(23px);
			}

			50% {
				-moz-transform: rotate(510deg) translate(28px);
			}

			to {
				-moz-transform: rotate(690deg) translate(23px);
			}
		}

		@keyframes segment-orbit-12 {
			from {
				transform: rotate(360deg) translate(23px);
			}

			50% {
				transform: rotate(540deg) translate(28px);
			}

			to {
				transform: rotate(720deg) translate(23px);
			}
		}

		@-o-keyframes segment-orbit-12 {
			from {
				-o-transform: rotate(360deg) translate(23px);
			}

			50% {
				-o-transform: rotate(540deg) translate(28px);
			}

			to {
				-o-transform: rotate(720deg) translate(23px);
			}
		}

		@-ms-keyframes segment-orbit-12 {
			from {
				-ms-transform: rotate(360deg) translate(23px);
			}

			50% {
				-ms-transform: rotate(540deg) translate(28px);
			}

			to {
				-ms-transform: rotate(720deg) translate(23px);
			}
		}

		@-webkit-keyframes segment-orbit-12 {
			from {
				-webkit-transform: rotate(360deg) translate(23px);
			}

			50% {
				-webkit-transform: rotate(540deg) translate(28px);
			}

			to {
				-webkit-transform: rotate(720deg) translate(23px);
			}
		}

		@-moz-keyframes segment-orbit-12 {
			from {
				-moz-transform: rotate(360deg) translate(23px);
			}

			50% {
				-moz-transform: rotate(540deg) translate(28px);
			}

			to {
				-moz-transform: rotate(720deg) translate(23px);
			}
		}

		@keyframes segment-scale-12 {
			0% {
				transform: scaleX(1);
			}

			8.33333% {
				transform: scaleX(0.93333);
			}

			16.66667% {
				transform: scaleX(0.86667);
			}

			25% {
				transform: scaleX(0.8);
			}

			33.33333% {
				transform: scaleX(0.73333);
			}

			41.66667% {
				transform: scaleX(0.66667);
			}

			50% {
				transform: scaleX(0.6);
			}

			58.33333% {
				transform: scaleX(0.53333);
			}

			66.66667% {
				transform: scaleX(0.46667);
			}

			75% {
				transform: scaleX(0.4);
			}

			83.33333% {
				transform: scaleX(0.33333);
			}

			91.66667% {
				transform: scaleX(0.26667);
			}

			100% {
				transform: scaleX(1);
			}
		}

		@-o-keyframes segment-scale-12 {
			0% {
				-o-transform: scaleX(1);
			}

			8.33333% {
				-o-transform: scaleX(0.93333);
			}

			16.66667% {
				-o-transform: scaleX(0.86667);
			}

			25% {
				-o-transform: scaleX(0.8);
			}

			33.33333% {
				-o-transform: scaleX(0.73333);
			}

			41.66667% {
				-o-transform: scaleX(0.66667);
			}

			50% {
				-o-transform: scaleX(0.6);
			}

			58.33333% {
				-o-transform: scaleX(0.53333);
			}

			66.66667% {
				-o-transform: scaleX(0.46667);
			}

			75% {
				-o-transform: scaleX(0.4);
			}

			83.33333% {
				-o-transform: scaleX(0.33333);
			}

			91.66667% {
				-o-transform: scaleX(0.26667);
			}

			100% {
				-o-transform: scaleX(1);
			}
		}

		@-ms-keyframes segment-scale-12 {
			0% {
				-ms-transform: scaleX(1);
			}

			8.33333% {
				-ms-transform: scaleX(0.93333);
			}

			16.66667% {
				-ms-transform: scaleX(0.86667);
			}

			25% {
				-ms-transform: scaleX(0.8);
			}

			33.33333% {
				-ms-transform: scaleX(0.73333);
			}

			41.66667% {
				-ms-transform: scaleX(0.66667);
			}

			50% {
				-ms-transform: scaleX(0.6);
			}

			58.33333% {
				-ms-transform: scaleX(0.53333);
			}

			66.66667% {
				-ms-transform: scaleX(0.46667);
			}

			75% {
				-ms-transform: scaleX(0.4);
			}

			83.33333% {
				-ms-transform: scaleX(0.33333);
			}

			91.66667% {
				-ms-transform: scaleX(0.26667);
			}

			100% {
				-ms-transform: scaleX(1);
			}
		}

		@-webkit-keyframes segment-scale-12 {
			0% {
				-webkit-transform: scaleX(1);
			}

			8.33333% {
				-webkit-transform: scaleX(0.93333);
			}

			16.66667% {
				-webkit-transform: scaleX(0.86667);
			}

			25% {
				-webkit-transform: scaleX(0.8);
			}

			33.33333% {
				-webkit-transform: scaleX(0.73333);
			}

			41.66667% {
				-webkit-transform: scaleX(0.66667);
			}

			50% {
				-webkit-transform: scaleX(0.6);
			}

			58.33333% {
				-webkit-transform: scaleX(0.53333);
			}

			66.66667% {
				-webkit-transform: scaleX(0.46667);
			}

			75% {
				-webkit-transform: scaleX(0.4);
			}

			83.33333% {
				-webkit-transform: scaleX(0.33333);
			}

			91.66667% {
				-webkit-transform: scaleX(0.26667);
			}

			100% {
				-webkit-transform: scaleX(1);
			}
		}

		@-moz-keyframes segment-scale-12 {
			0% {
				-moz-transform: scaleX(1);
			}

			8.33333% {
				-moz-transform: scaleX(0.93333);
			}

			16.66667% {
				-moz-transform: scaleX(0.86667);
			}

			25% {
				-moz-transform: scaleX(0.8);
			}

			33.33333% {
				-moz-transform: scaleX(0.73333);
			}

			41.66667% {
				-moz-transform: scaleX(0.66667);
			}

			50% {
				-moz-transform: scaleX(0.6);
			}

			58.33333% {
				-moz-transform: scaleX(0.53333);
			}

			66.66667% {
				-moz-transform: scaleX(0.46667);
			}

			75% {
				-moz-transform: scaleX(0.4);
			}

			83.33333% {
				-moz-transform: scaleX(0.33333);
			}

			91.66667% {
				-moz-transform: scaleX(0.26667);
			}

			100% {
				-moz-transform: scaleX(1);
			}
		}

		@keyframes segment-scale-11 {
			0% {
				transform: scaleX(0.93333);
			}

			8.33333% {
				transform: scaleX(0.86667);
			}

			16.66667% {
				transform: scaleX(0.8);
			}

			25% {
				transform: scaleX(0.73333);
			}

			33.33333% {
				transform: scaleX(0.66667);
			}

			41.66667% {
				transform: scaleX(0.6);
			}

			50% {
				transform: scaleX(0.53333);
			}

			58.33333% {
				transform: scaleX(0.46667);
			}

			66.66667% {
				transform: scaleX(0.4);
			}

			75% {
				transform: scaleX(0.33333);
			}

			83.33333% {
				transform: scaleX(0.26667);
			}

			91.66667% {
				transform: scaleX(1);
			}

			100% {
				transform: scaleX(0.93333);
			}
		}

		@-o-keyframes segment-scale-11 {
			0% {
				-o-transform: scaleX(0.93333);
			}

			8.33333% {
				-o-transform: scaleX(0.86667);
			}

			16.66667% {
				-o-transform: scaleX(0.8);
			}

			25% {
				-o-transform: scaleX(0.73333);
			}

			33.33333% {
				-o-transform: scaleX(0.66667);
			}

			41.66667% {
				-o-transform: scaleX(0.6);
			}

			50% {
				-o-transform: scaleX(0.53333);
			}

			58.33333% {
				-o-transform: scaleX(0.46667);
			}

			66.66667% {
				-o-transform: scaleX(0.4);
			}

			75% {
				-o-transform: scaleX(0.33333);
			}

			83.33333% {
				-o-transform: scaleX(0.26667);
			}

			91.66667% {
				-o-transform: scaleX(1);
			}

			100% {
				-o-transform: scaleX(0.93333);
			}
		}

		@-ms-keyframes segment-scale-11 {
			0% {
				-ms-transform: scaleX(0.93333);
			}

			8.33333% {
				-ms-transform: scaleX(0.86667);
			}

			16.66667% {
				-ms-transform: scaleX(0.8);
			}

			25% {
				-ms-transform: scaleX(0.73333);
			}

			33.33333% {
				-ms-transform: scaleX(0.66667);
			}

			41.66667% {
				-ms-transform: scaleX(0.6);
			}

			50% {
				-ms-transform: scaleX(0.53333);
			}

			58.33333% {
				-ms-transform: scaleX(0.46667);
			}

			66.66667% {
				-ms-transform: scaleX(0.4);
			}

			75% {
				-ms-transform: scaleX(0.33333);
			}

			83.33333% {
				-ms-transform: scaleX(0.26667);
			}

			91.66667% {
				-ms-transform: scaleX(1);
			}

			100% {
				-ms-transform: scaleX(0.93333);
			}
		}

		@-webkit-keyframes segment-scale-11 {
			0% {
				-webkit-transform: scaleX(0.93333);
			}

			8.33333% {
				-webkit-transform: scaleX(0.86667);
			}

			16.66667% {
				-webkit-transform: scaleX(0.8);
			}

			25% {
				-webkit-transform: scaleX(0.73333);
			}

			33.33333% {
				-webkit-transform: scaleX(0.66667);
			}

			41.66667% {
				-webkit-transform: scaleX(0.6);
			}

			50% {
				-webkit-transform: scaleX(0.53333);
			}

			58.33333% {
				-webkit-transform: scaleX(0.46667);
			}

			66.66667% {
				-webkit-transform: scaleX(0.4);
			}

			75% {
				-webkit-transform: scaleX(0.33333);
			}

			83.33333% {
				-webkit-transform: scaleX(0.26667);
			}

			91.66667% {
				-webkit-transform: scaleX(1);
			}

			100% {
				-webkit-transform: scaleX(0.93333);
			}
		}

		@-moz-keyframes segment-scale-11 {
			0% {
				-moz-transform: scaleX(0.93333);
			}

			8.33333% {
				-moz-transform: scaleX(0.86667);
			}

			16.66667% {
				-moz-transform: scaleX(0.8);
			}

			25% {
				-moz-transform: scaleX(0.73333);
			}

			33.33333% {
				-moz-transform: scaleX(0.66667);
			}

			41.66667% {
				-moz-transform: scaleX(0.6);
			}

			50% {
				-moz-transform: scaleX(0.53333);
			}

			58.33333% {
				-moz-transform: scaleX(0.46667);
			}

			66.66667% {
				-moz-transform: scaleX(0.4);
			}

			75% {
				-moz-transform: scaleX(0.33333);
			}

			83.33333% {
				-moz-transform: scaleX(0.26667);
			}

			91.66667% {
				-moz-transform: scaleX(1);
			}

			100% {
				-moz-transform: scaleX(0.93333);
			}
		}

		@keyframes segment-scale-10 {
			0% {
				transform: scaleX(0.86667);
			}

			8.33333% {
				transform: scaleX(0.8);
			}

			16.66667% {
				transform: scaleX(0.73333);
			}

			25% {
				transform: scaleX(0.66667);
			}

			33.33333% {
				transform: scaleX(0.6);
			}

			41.66667% {
				transform: scaleX(0.53333);
			}

			50% {
				transform: scaleX(0.46667);
			}

			58.33333% {
				transform: scaleX(0.4);
			}

			66.66667% {
				transform: scaleX(0.33333);
			}

			75% {
				transform: scaleX(0.26667);
			}

			83.33333% {
				transform: scaleX(1);
			}

			91.66667% {
				transform: scaleX(0.93333);
			}

			100% {
				transform: scaleX(0.86667);
			}
		}

		@-o-keyframes segment-scale-10 {
			0% {
				-o-transform: scaleX(0.86667);
			}

			8.33333% {
				-o-transform: scaleX(0.8);
			}

			16.66667% {
				-o-transform: scaleX(0.73333);
			}

			25% {
				-o-transform: scaleX(0.66667);
			}

			33.33333% {
				-o-transform: scaleX(0.6);
			}

			41.66667% {
				-o-transform: scaleX(0.53333);
			}

			50% {
				-o-transform: scaleX(0.46667);
			}

			58.33333% {
				-o-transform: scaleX(0.4);
			}

			66.66667% {
				-o-transform: scaleX(0.33333);
			}

			75% {
				-o-transform: scaleX(0.26667);
			}

			83.33333% {
				-o-transform: scaleX(1);
			}

			91.66667% {
				-o-transform: scaleX(0.93333);
			}

			100% {
				-o-transform: scaleX(0.86667);
			}
		}

		@-ms-keyframes segment-scale-10 {
			0% {
				-ms-transform: scaleX(0.86667);
			}

			8.33333% {
				-ms-transform: scaleX(0.8);
			}

			16.66667% {
				-ms-transform: scaleX(0.73333);
			}

			25% {
				-ms-transform: scaleX(0.66667);
			}

			33.33333% {
				-ms-transform: scaleX(0.6);
			}

			41.66667% {
				-ms-transform: scaleX(0.53333);
			}

			50% {
				-ms-transform: scaleX(0.46667);
			}

			58.33333% {
				-ms-transform: scaleX(0.4);
			}

			66.66667% {
				-ms-transform: scaleX(0.33333);
			}

			75% {
				-ms-transform: scaleX(0.26667);
			}

			83.33333% {
				-ms-transform: scaleX(1);
			}

			91.66667% {
				-ms-transform: scaleX(0.93333);
			}

			100% {
				-ms-transform: scaleX(0.86667);
			}
		}

		@-webkit-keyframes segment-scale-10 {
			0% {
				-webkit-transform: scaleX(0.86667);
			}

			8.33333% {
				-webkit-transform: scaleX(0.8);
			}

			16.66667% {
				-webkit-transform: scaleX(0.73333);
			}

			25% {
				-webkit-transform: scaleX(0.66667);
			}

			33.33333% {
				-webkit-transform: scaleX(0.6);
			}

			41.66667% {
				-webkit-transform: scaleX(0.53333);
			}

			50% {
				-webkit-transform: scaleX(0.46667);
			}

			58.33333% {
				-webkit-transform: scaleX(0.4);
			}

			66.66667% {
				-webkit-transform: scaleX(0.33333);
			}

			75% {
				-webkit-transform: scaleX(0.26667);
			}

			83.33333% {
				-webkit-transform: scaleX(1);
			}

			91.66667% {
				-webkit-transform: scaleX(0.93333);
			}

			100% {
				-webkit-transform: scaleX(0.86667);
			}
		}

		@-moz-keyframes segment-scale-10 {
			0% {
				-moz-transform: scaleX(0.86667);
			}

			8.33333% {
				-moz-transform: scaleX(0.8);
			}

			16.66667% {
				-moz-transform: scaleX(0.73333);
			}

			25% {
				-moz-transform: scaleX(0.66667);
			}

			33.33333% {
				-moz-transform: scaleX(0.6);
			}

			41.66667% {
				-moz-transform: scaleX(0.53333);
			}

			50% {
				-moz-transform: scaleX(0.46667);
			}

			58.33333% {
				-moz-transform: scaleX(0.4);
			}

			66.66667% {
				-moz-transform: scaleX(0.33333);
			}

			75% {
				-moz-transform: scaleX(0.26667);
			}

			83.33333% {
				-moz-transform: scaleX(1);
			}

			91.66667% {
				-moz-transform: scaleX(0.93333);
			}

			100% {
				-moz-transform: scaleX(0.86667);
			}
		}

		@keyframes segment-scale-9 {
			0% {
				transform: scaleX(0.8);
			}

			8.33333% {
				transform: scaleX(0.73333);
			}

			16.66667% {
				transform: scaleX(0.66667);
			}

			25% {
				transform: scaleX(0.6);
			}

			33.33333% {
				transform: scaleX(0.53333);
			}

			41.66667% {
				transform: scaleX(0.46667);
			}

			50% {
				transform: scaleX(0.4);
			}

			58.33333% {
				transform: scaleX(0.33333);
			}

			66.66667% {
				transform: scaleX(0.26667);
			}

			75% {
				transform: scaleX(1);
			}

			83.33333% {
				transform: scaleX(0.93333);
			}

			91.66667% {
				transform: scaleX(0.86667);
			}

			100% {
				transform: scaleX(0.8);
			}
		}

		@-o-keyframes segment-scale-9 {
			0% {
				-o-transform: scaleX(0.8);
			}

			8.33333% {
				-o-transform: scaleX(0.73333);
			}

			16.66667% {
				-o-transform: scaleX(0.66667);
			}

			25% {
				-o-transform: scaleX(0.6);
			}

			33.33333% {
				-o-transform: scaleX(0.53333);
			}

			41.66667% {
				-o-transform: scaleX(0.46667);
			}

			50% {
				-o-transform: scaleX(0.4);
			}

			58.33333% {
				-o-transform: scaleX(0.33333);
			}

			66.66667% {
				-o-transform: scaleX(0.26667);
			}

			75% {
				-o-transform: scaleX(1);
			}

			83.33333% {
				-o-transform: scaleX(0.93333);
			}

			91.66667% {
				-o-transform: scaleX(0.86667);
			}

			100% {
				-o-transform: scaleX(0.8);
			}
		}

		@-ms-keyframes segment-scale-9 {
			0% {
				-ms-transform: scaleX(0.8);
			}

			8.33333% {
				-ms-transform: scaleX(0.73333);
			}

			16.66667% {
				-ms-transform: scaleX(0.66667);
			}

			25% {
				-ms-transform: scaleX(0.6);
			}

			33.33333% {
				-ms-transform: scaleX(0.53333);
			}

			41.66667% {
				-ms-transform: scaleX(0.46667);
			}

			50% {
				-ms-transform: scaleX(0.4);
			}

			58.33333% {
				-ms-transform: scaleX(0.33333);
			}

			66.66667% {
				-ms-transform: scaleX(0.26667);
			}

			75% {
				-ms-transform: scaleX(1);
			}

			83.33333% {
				-ms-transform: scaleX(0.93333);
			}

			91.66667% {
				-ms-transform: scaleX(0.86667);
			}

			100% {
				-ms-transform: scaleX(0.8);
			}
		}

		@-webkit-keyframes segment-scale-9 {
			0% {
				-webkit-transform: scaleX(0.8);
			}

			8.33333% {
				-webkit-transform: scaleX(0.73333);
			}

			16.66667% {
				-webkit-transform: scaleX(0.66667);
			}

			25% {
				-webkit-transform: scaleX(0.6);
			}

			33.33333% {
				-webkit-transform: scaleX(0.53333);
			}

			41.66667% {
				-webkit-transform: scaleX(0.46667);
			}

			50% {
				-webkit-transform: scaleX(0.4);
			}

			58.33333% {
				-webkit-transform: scaleX(0.33333);
			}

			66.66667% {
				-webkit-transform: scaleX(0.26667);
			}

			75% {
				-webkit-transform: scaleX(1);
			}

			83.33333% {
				-webkit-transform: scaleX(0.93333);
			}

			91.66667% {
				-webkit-transform: scaleX(0.86667);
			}

			100% {
				-webkit-transform: scaleX(0.8);
			}
		}

		@-moz-keyframes segment-scale-9 {
			0% {
				-moz-transform: scaleX(0.8);
			}

			8.33333% {
				-moz-transform: scaleX(0.73333);
			}

			16.66667% {
				-moz-transform: scaleX(0.66667);
			}

			25% {
				-moz-transform: scaleX(0.6);
			}

			33.33333% {
				-moz-transform: scaleX(0.53333);
			}

			41.66667% {
				-moz-transform: scaleX(0.46667);
			}

			50% {
				-moz-transform: scaleX(0.4);
			}

			58.33333% {
				-moz-transform: scaleX(0.33333);
			}

			66.66667% {
				-moz-transform: scaleX(0.26667);
			}

			75% {
				-moz-transform: scaleX(1);
			}

			83.33333% {
				-moz-transform: scaleX(0.93333);
			}

			91.66667% {
				-moz-transform: scaleX(0.86667);
			}

			100% {
				-moz-transform: scaleX(0.8);
			}
		}

		@keyframes segment-scale-8 {
			0% {
				transform: scaleX(0.73333);
			}

			8.33333% {
				transform: scaleX(0.66667);
			}

			16.66667% {
				transform: scaleX(0.6);
			}

			25% {
				transform: scaleX(0.53333);
			}

			33.33333% {
				transform: scaleX(0.46667);
			}

			41.66667% {
				transform: scaleX(0.4);
			}

			50% {
				transform: scaleX(0.33333);
			}

			58.33333% {
				transform: scaleX(0.26667);
			}

			66.66667% {
				transform: scaleX(1);
			}

			75% {
				transform: scaleX(0.93333);
			}

			83.33333% {
				transform: scaleX(0.86667);
			}

			91.66667% {
				transform: scaleX(0.8);
			}

			100% {
				transform: scaleX(0.73333);
			}
		}

		@-o-keyframes segment-scale-8 {
			0% {
				-o-transform: scaleX(0.73333);
			}

			8.33333% {
				-o-transform: scaleX(0.66667);
			}

			16.66667% {
				-o-transform: scaleX(0.6);
			}

			25% {
				-o-transform: scaleX(0.53333);
			}

			33.33333% {
				-o-transform: scaleX(0.46667);
			}

			41.66667% {
				-o-transform: scaleX(0.4);
			}

			50% {
				-o-transform: scaleX(0.33333);
			}

			58.33333% {
				-o-transform: scaleX(0.26667);
			}

			66.66667% {
				-o-transform: scaleX(1);
			}

			75% {
				-o-transform: scaleX(0.93333);
			}

			83.33333% {
				-o-transform: scaleX(0.86667);
			}

			91.66667% {
				-o-transform: scaleX(0.8);
			}

			100% {
				-o-transform: scaleX(0.73333);
			}
		}

		@-ms-keyframes segment-scale-8 {
			0% {
				-ms-transform: scaleX(0.73333);
			}

			8.33333% {
				-ms-transform: scaleX(0.66667);
			}

			16.66667% {
				-ms-transform: scaleX(0.6);
			}

			25% {
				-ms-transform: scaleX(0.53333);
			}

			33.33333% {
				-ms-transform: scaleX(0.46667);
			}

			41.66667% {
				-ms-transform: scaleX(0.4);
			}

			50% {
				-ms-transform: scaleX(0.33333);
			}

			58.33333% {
				-ms-transform: scaleX(0.26667);
			}

			66.66667% {
				-ms-transform: scaleX(1);
			}

			75% {
				-ms-transform: scaleX(0.93333);
			}

			83.33333% {
				-ms-transform: scaleX(0.86667);
			}

			91.66667% {
				-ms-transform: scaleX(0.8);
			}

			100% {
				-ms-transform: scaleX(0.73333);
			}
		}

		@-webkit-keyframes segment-scale-8 {
			0% {
				-webkit-transform: scaleX(0.73333);
			}

			8.33333% {
				-webkit-transform: scaleX(0.66667);
			}

			16.66667% {
				-webkit-transform: scaleX(0.6);
			}

			25% {
				-webkit-transform: scaleX(0.53333);
			}

			33.33333% {
				-webkit-transform: scaleX(0.46667);
			}

			41.66667% {
				-webkit-transform: scaleX(0.4);
			}

			50% {
				-webkit-transform: scaleX(0.33333);
			}

			58.33333% {
				-webkit-transform: scaleX(0.26667);
			}

			66.66667% {
				-webkit-transform: scaleX(1);
			}

			75% {
				-webkit-transform: scaleX(0.93333);
			}

			83.33333% {
				-webkit-transform: scaleX(0.86667);
			}

			91.66667% {
				-webkit-transform: scaleX(0.8);
			}

			100% {
				-webkit-transform: scaleX(0.73333);
			}
		}

		@-moz-keyframes segment-scale-8 {
			0% {
				-moz-transform: scaleX(0.73333);
			}

			8.33333% {
				-moz-transform: scaleX(0.66667);
			}

			16.66667% {
				-moz-transform: scaleX(0.6);
			}

			25% {
				-moz-transform: scaleX(0.53333);
			}

			33.33333% {
				-moz-transform: scaleX(0.46667);
			}

			41.66667% {
				-moz-transform: scaleX(0.4);
			}

			50% {
				-moz-transform: scaleX(0.33333);
			}

			58.33333% {
				-moz-transform: scaleX(0.26667);
			}

			66.66667% {
				-moz-transform: scaleX(1);
			}

			75% {
				-moz-transform: scaleX(0.93333);
			}

			83.33333% {
				-moz-transform: scaleX(0.86667);
			}

			91.66667% {
				-moz-transform: scaleX(0.8);
			}

			100% {
				-moz-transform: scaleX(0.73333);
			}
		}

		@keyframes segment-scale-7 {
			0% {
				transform: scaleX(0.66667);
			}

			8.33333% {
				transform: scaleX(0.6);
			}

			16.66667% {
				transform: scaleX(0.53333);
			}

			25% {
				transform: scaleX(0.46667);
			}

			33.33333% {
				transform: scaleX(0.4);
			}

			41.66667% {
				transform: scaleX(0.33333);
			}

			50% {
				transform: scaleX(0.26667);
			}

			58.33333% {
				transform: scaleX(1);
			}

			66.66667% {
				transform: scaleX(0.93333);
			}

			75% {
				transform: scaleX(0.86667);
			}

			83.33333% {
				transform: scaleX(0.8);
			}

			91.66667% {
				transform: scaleX(0.73333);
			}

			100% {
				transform: scaleX(0.66667);
			}
		}

		@-o-keyframes segment-scale-7 {
			0% {
				-o-transform: scaleX(0.66667);
			}

			8.33333% {
				-o-transform: scaleX(0.6);
			}

			16.66667% {
				-o-transform: scaleX(0.53333);
			}

			25% {
				-o-transform: scaleX(0.46667);
			}

			33.33333% {
				-o-transform: scaleX(0.4);
			}

			41.66667% {
				-o-transform: scaleX(0.33333);
			}

			50% {
				-o-transform: scaleX(0.26667);
			}

			58.33333% {
				-o-transform: scaleX(1);
			}

			66.66667% {
				-o-transform: scaleX(0.93333);
			}

			75% {
				-o-transform: scaleX(0.86667);
			}

			83.33333% {
				-o-transform: scaleX(0.8);
			}

			91.66667% {
				-o-transform: scaleX(0.73333);
			}

			100% {
				-o-transform: scaleX(0.66667);
			}
		}

		@-ms-keyframes segment-scale-7 {
			0% {
				-ms-transform: scaleX(0.66667);
			}

			8.33333% {
				-ms-transform: scaleX(0.6);
			}

			16.66667% {
				-ms-transform: scaleX(0.53333);
			}

			25% {
				-ms-transform: scaleX(0.46667);
			}

			33.33333% {
				-ms-transform: scaleX(0.4);
			}

			41.66667% {
				-ms-transform: scaleX(0.33333);
			}

			50% {
				-ms-transform: scaleX(0.26667);
			}

			58.33333% {
				-ms-transform: scaleX(1);
			}

			66.66667% {
				-ms-transform: scaleX(0.93333);
			}

			75% {
				-ms-transform: scaleX(0.86667);
			}

			83.33333% {
				-ms-transform: scaleX(0.8);
			}

			91.66667% {
				-ms-transform: scaleX(0.73333);
			}

			100% {
				-ms-transform: scaleX(0.66667);
			}
		}

		@-webkit-keyframes segment-scale-7 {
			0% {
				-webkit-transform: scaleX(0.66667);
			}

			8.33333% {
				-webkit-transform: scaleX(0.6);
			}

			16.66667% {
				-webkit-transform: scaleX(0.53333);
			}

			25% {
				-webkit-transform: scaleX(0.46667);
			}

			33.33333% {
				-webkit-transform: scaleX(0.4);
			}

			41.66667% {
				-webkit-transform: scaleX(0.33333);
			}

			50% {
				-webkit-transform: scaleX(0.26667);
			}

			58.33333% {
				-webkit-transform: scaleX(1);
			}

			66.66667% {
				-webkit-transform: scaleX(0.93333);
			}

			75% {
				-webkit-transform: scaleX(0.86667);
			}

			83.33333% {
				-webkit-transform: scaleX(0.8);
			}

			91.66667% {
				-webkit-transform: scaleX(0.73333);
			}

			100% {
				-webkit-transform: scaleX(0.66667);
			}
		}

		@-moz-keyframes segment-scale-7 {
			0% {
				-moz-transform: scaleX(0.66667);
			}

			8.33333% {
				-moz-transform: scaleX(0.6);
			}

			16.66667% {
				-moz-transform: scaleX(0.53333);
			}

			25% {
				-moz-transform: scaleX(0.46667);
			}

			33.33333% {
				-moz-transform: scaleX(0.4);
			}

			41.66667% {
				-moz-transform: scaleX(0.33333);
			}

			50% {
				-moz-transform: scaleX(0.26667);
			}

			58.33333% {
				-moz-transform: scaleX(1);
			}

			66.66667% {
				-moz-transform: scaleX(0.93333);
			}

			75% {
				-moz-transform: scaleX(0.86667);
			}

			83.33333% {
				-moz-transform: scaleX(0.8);
			}

			91.66667% {
				-moz-transform: scaleX(0.73333);
			}

			100% {
				-moz-transform: scaleX(0.66667);
			}
		}

		@keyframes segment-scale-6 {
			0% {
				transform: scaleX(0.6);
			}

			8.33333% {
				transform: scaleX(0.53333);
			}

			16.66667% {
				transform: scaleX(0.46667);
			}

			25% {
				transform: scaleX(0.4);
			}

			33.33333% {
				transform: scaleX(0.33333);
			}

			41.66667% {
				transform: scaleX(0.26667);
			}

			50% {
				transform: scaleX(1);
			}

			58.33333% {
				transform: scaleX(0.93333);
			}

			66.66667% {
				transform: scaleX(0.86667);
			}

			75% {
				transform: scaleX(0.8);
			}

			83.33333% {
				transform: scaleX(0.73333);
			}

			91.66667% {
				transform: scaleX(0.66667);
			}

			100% {
				transform: scaleX(0.6);
			}
		}

		@-o-keyframes segment-scale-6 {
			0% {
				-o-transform: scaleX(0.6);
			}

			8.33333% {
				-o-transform: scaleX(0.53333);
			}

			16.66667% {
				-o-transform: scaleX(0.46667);
			}

			25% {
				-o-transform: scaleX(0.4);
			}

			33.33333% {
				-o-transform: scaleX(0.33333);
			}

			41.66667% {
				-o-transform: scaleX(0.26667);
			}

			50% {
				-o-transform: scaleX(1);
			}

			58.33333% {
				-o-transform: scaleX(0.93333);
			}

			66.66667% {
				-o-transform: scaleX(0.86667);
			}

			75% {
				-o-transform: scaleX(0.8);
			}

			83.33333% {
				-o-transform: scaleX(0.73333);
			}

			91.66667% {
				-o-transform: scaleX(0.66667);
			}

			100% {
				-o-transform: scaleX(0.6);
			}
		}

		@-ms-keyframes segment-scale-6 {
			0% {
				-ms-transform: scaleX(0.6);
			}

			8.33333% {
				-ms-transform: scaleX(0.53333);
			}

			16.66667% {
				-ms-transform: scaleX(0.46667);
			}

			25% {
				-ms-transform: scaleX(0.4);
			}

			33.33333% {
				-ms-transform: scaleX(0.33333);
			}

			41.66667% {
				-ms-transform: scaleX(0.26667);
			}

			50% {
				-ms-transform: scaleX(1);
			}

			58.33333% {
				-ms-transform: scaleX(0.93333);
			}

			66.66667% {
				-ms-transform: scaleX(0.86667);
			}

			75% {
				-ms-transform: scaleX(0.8);
			}

			83.33333% {
				-ms-transform: scaleX(0.73333);
			}

			91.66667% {
				-ms-transform: scaleX(0.66667);
			}

			100% {
				-ms-transform: scaleX(0.6);
			}
		}

		@-webkit-keyframes segment-scale-6 {
			0% {
				-webkit-transform: scaleX(0.6);
			}

			8.33333% {
				-webkit-transform: scaleX(0.53333);
			}

			16.66667% {
				-webkit-transform: scaleX(0.46667);
			}

			25% {
				-webkit-transform: scaleX(0.4);
			}

			33.33333% {
				-webkit-transform: scaleX(0.33333);
			}

			41.66667% {
				-webkit-transform: scaleX(0.26667);
			}

			50% {
				-webkit-transform: scaleX(1);
			}

			58.33333% {
				-webkit-transform: scaleX(0.93333);
			}

			66.66667% {
				-webkit-transform: scaleX(0.86667);
			}

			75% {
				-webkit-transform: scaleX(0.8);
			}

			83.33333% {
				-webkit-transform: scaleX(0.73333);
			}

			91.66667% {
				-webkit-transform: scaleX(0.66667);
			}

			100% {
				-webkit-transform: scaleX(0.6);
			}
		}

		@-moz-keyframes segment-scale-6 {
			0% {
				-moz-transform: scaleX(0.6);
			}

			8.33333% {
				-moz-transform: scaleX(0.53333);
			}

			16.66667% {
				-moz-transform: scaleX(0.46667);
			}

			25% {
				-moz-transform: scaleX(0.4);
			}

			33.33333% {
				-moz-transform: scaleX(0.33333);
			}

			41.66667% {
				-moz-transform: scaleX(0.26667);
			}

			50% {
				-moz-transform: scaleX(1);
			}

			58.33333% {
				-moz-transform: scaleX(0.93333);
			}

			66.66667% {
				-moz-transform: scaleX(0.86667);
			}

			75% {
				-moz-transform: scaleX(0.8);
			}

			83.33333% {
				-moz-transform: scaleX(0.73333);
			}

			91.66667% {
				-moz-transform: scaleX(0.66667);
			}

			100% {
				-moz-transform: scaleX(0.6);
			}
		}

		@keyframes segment-scale-5 {
			0% {
				transform: scaleX(0.53333);
			}

			8.33333% {
				transform: scaleX(0.46667);
			}

			16.66667% {
				transform: scaleX(0.4);
			}

			25% {
				transform: scaleX(0.33333);
			}

			33.33333% {
				transform: scaleX(0.26667);
			}

			41.66667% {
				transform: scaleX(1);
			}

			50% {
				transform: scaleX(0.93333);
			}

			58.33333% {
				transform: scaleX(0.86667);
			}

			66.66667% {
				transform: scaleX(0.8);
			}

			75% {
				transform: scaleX(0.73333);
			}

			83.33333% {
				transform: scaleX(0.66667);
			}

			91.66667% {
				transform: scaleX(0.6);
			}

			100% {
				transform: scaleX(0.53333);
			}
		}

		@-o-keyframes segment-scale-5 {
			0% {
				-o-transform: scaleX(0.53333);
			}

			8.33333% {
				-o-transform: scaleX(0.46667);
			}

			16.66667% {
				-o-transform: scaleX(0.4);
			}

			25% {
				-o-transform: scaleX(0.33333);
			}

			33.33333% {
				-o-transform: scaleX(0.26667);
			}

			41.66667% {
				-o-transform: scaleX(1);
			}

			50% {
				-o-transform: scaleX(0.93333);
			}

			58.33333% {
				-o-transform: scaleX(0.86667);
			}

			66.66667% {
				-o-transform: scaleX(0.8);
			}

			75% {
				-o-transform: scaleX(0.73333);
			}

			83.33333% {
				-o-transform: scaleX(0.66667);
			}

			91.66667% {
				-o-transform: scaleX(0.6);
			}

			100% {
				-o-transform: scaleX(0.53333);
			}
		}

		@-ms-keyframes segment-scale-5 {
			0% {
				-ms-transform: scaleX(0.53333);
			}

			8.33333% {
				-ms-transform: scaleX(0.46667);
			}

			16.66667% {
				-ms-transform: scaleX(0.4);
			}

			25% {
				-ms-transform: scaleX(0.33333);
			}

			33.33333% {
				-ms-transform: scaleX(0.26667);
			}

			41.66667% {
				-ms-transform: scaleX(1);
			}

			50% {
				-ms-transform: scaleX(0.93333);
			}

			58.33333% {
				-ms-transform: scaleX(0.86667);
			}

			66.66667% {
				-ms-transform: scaleX(0.8);
			}

			75% {
				-ms-transform: scaleX(0.73333);
			}

			83.33333% {
				-ms-transform: scaleX(0.66667);
			}

			91.66667% {
				-ms-transform: scaleX(0.6);
			}

			100% {
				-ms-transform: scaleX(0.53333);
			}
		}

		@-webkit-keyframes segment-scale-5 {
			0% {
				-webkit-transform: scaleX(0.53333);
			}

			8.33333% {
				-webkit-transform: scaleX(0.46667);
			}

			16.66667% {
				-webkit-transform: scaleX(0.4);
			}

			25% {
				-webkit-transform: scaleX(0.33333);
			}

			33.33333% {
				-webkit-transform: scaleX(0.26667);
			}

			41.66667% {
				-webkit-transform: scaleX(1);
			}

			50% {
				-webkit-transform: scaleX(0.93333);
			}

			58.33333% {
				-webkit-transform: scaleX(0.86667);
			}

			66.66667% {
				-webkit-transform: scaleX(0.8);
			}

			75% {
				-webkit-transform: scaleX(0.73333);
			}

			83.33333% {
				-webkit-transform: scaleX(0.66667);
			}

			91.66667% {
				-webkit-transform: scaleX(0.6);
			}

			100% {
				-webkit-transform: scaleX(0.53333);
			}
		}

		@-moz-keyframes segment-scale-5 {
			0% {
				-moz-transform: scaleX(0.53333);
			}

			8.33333% {
				-moz-transform: scaleX(0.46667);
			}

			16.66667% {
				-moz-transform: scaleX(0.4);
			}

			25% {
				-moz-transform: scaleX(0.33333);
			}

			33.33333% {
				-moz-transform: scaleX(0.26667);
			}

			41.66667% {
				-moz-transform: scaleX(1);
			}

			50% {
				-moz-transform: scaleX(0.93333);
			}

			58.33333% {
				-moz-transform: scaleX(0.86667);
			}

			66.66667% {
				-moz-transform: scaleX(0.8);
			}

			75% {
				-moz-transform: scaleX(0.73333);
			}

			83.33333% {
				-moz-transform: scaleX(0.66667);
			}

			91.66667% {
				-moz-transform: scaleX(0.6);
			}

			100% {
				-moz-transform: scaleX(0.53333);
			}
		}

		@keyframes segment-scale-4 {
			0% {
				transform: scaleX(0.46667);
			}

			8.33333% {
				transform: scaleX(0.4);
			}

			16.66667% {
				transform: scaleX(0.33333);
			}

			25% {
				transform: scaleX(0.26667);
			}

			33.33333% {
				transform: scaleX(1);
			}

			41.66667% {
				transform: scaleX(0.93333);
			}

			50% {
				transform: scaleX(0.86667);
			}

			58.33333% {
				transform: scaleX(0.8);
			}

			66.66667% {
				transform: scaleX(0.73333);
			}

			75% {
				transform: scaleX(0.66667);
			}

			83.33333% {
				transform: scaleX(0.6);
			}

			91.66667% {
				transform: scaleX(0.53333);
			}

			100% {
				transform: scaleX(0.46667);
			}
		}

		@-o-keyframes segment-scale-4 {
			0% {
				-o-transform: scaleX(0.46667);
			}

			8.33333% {
				-o-transform: scaleX(0.4);
			}

			16.66667% {
				-o-transform: scaleX(0.33333);
			}

			25% {
				-o-transform: scaleX(0.26667);
			}

			33.33333% {
				-o-transform: scaleX(1);
			}

			41.66667% {
				-o-transform: scaleX(0.93333);
			}

			50% {
				-o-transform: scaleX(0.86667);
			}

			58.33333% {
				-o-transform: scaleX(0.8);
			}

			66.66667% {
				-o-transform: scaleX(0.73333);
			}

			75% {
				-o-transform: scaleX(0.66667);
			}

			83.33333% {
				-o-transform: scaleX(0.6);
			}

			91.66667% {
				-o-transform: scaleX(0.53333);
			}

			100% {
				-o-transform: scaleX(0.46667);
			}
		}

		@-ms-keyframes segment-scale-4 {
			0% {
				-ms-transform: scaleX(0.46667);
			}

			8.33333% {
				-ms-transform: scaleX(0.4);
			}

			16.66667% {
				-ms-transform: scaleX(0.33333);
			}

			25% {
				-ms-transform: scaleX(0.26667);
			}

			33.33333% {
				-ms-transform: scaleX(1);
			}

			41.66667% {
				-ms-transform: scaleX(0.93333);
			}

			50% {
				-ms-transform: scaleX(0.86667);
			}

			58.33333% {
				-ms-transform: scaleX(0.8);
			}

			66.66667% {
				-ms-transform: scaleX(0.73333);
			}

			75% {
				-ms-transform: scaleX(0.66667);
			}

			83.33333% {
				-ms-transform: scaleX(0.6);
			}

			91.66667% {
				-ms-transform: scaleX(0.53333);
			}

			100% {
				-ms-transform: scaleX(0.46667);
			}
		}

		@-webkit-keyframes segment-scale-4 {
			0% {
				-webkit-transform: scaleX(0.46667);
			}

			8.33333% {
				-webkit-transform: scaleX(0.4);
			}

			16.66667% {
				-webkit-transform: scaleX(0.33333);
			}

			25% {
				-webkit-transform: scaleX(0.26667);
			}

			33.33333% {
				-webkit-transform: scaleX(1);
			}

			41.66667% {
				-webkit-transform: scaleX(0.93333);
			}

			50% {
				-webkit-transform: scaleX(0.86667);
			}

			58.33333% {
				-webkit-transform: scaleX(0.8);
			}

			66.66667% {
				-webkit-transform: scaleX(0.73333);
			}

			75% {
				-webkit-transform: scaleX(0.66667);
			}

			83.33333% {
				-webkit-transform: scaleX(0.6);
			}

			91.66667% {
				-webkit-transform: scaleX(0.53333);
			}

			100% {
				-webkit-transform: scaleX(0.46667);
			}
		}

		@-moz-keyframes segment-scale-4 {
			0% {
				-moz-transform: scaleX(0.46667);
			}

			8.33333% {
				-moz-transform: scaleX(0.4);
			}

			16.66667% {
				-moz-transform: scaleX(0.33333);
			}

			25% {
				-moz-transform: scaleX(0.26667);
			}

			33.33333% {
				-moz-transform: scaleX(1);
			}

			41.66667% {
				-moz-transform: scaleX(0.93333);
			}

			50% {
				-moz-transform: scaleX(0.86667);
			}

			58.33333% {
				-moz-transform: scaleX(0.8);
			}

			66.66667% {
				-moz-transform: scaleX(0.73333);
			}

			75% {
				-moz-transform: scaleX(0.66667);
			}

			83.33333% {
				-moz-transform: scaleX(0.6);
			}

			91.66667% {
				-moz-transform: scaleX(0.53333);
			}

			100% {
				-moz-transform: scaleX(0.46667);
			}
		}

		@keyframes segment-scale-3 {
			0% {
				transform: scaleX(0.4);
			}

			8.33333% {
				transform: scaleX(0.33333);
			}

			16.66667% {
				transform: scaleX(0.26667);
			}

			25% {
				transform: scaleX(1);
			}

			33.33333% {
				transform: scaleX(0.93333);
			}

			41.66667% {
				transform: scaleX(0.86667);
			}

			50% {
				transform: scaleX(0.8);
			}

			58.33333% {
				transform: scaleX(0.73333);
			}

			66.66667% {
				transform: scaleX(0.66667);
			}

			75% {
				transform: scaleX(0.6);
			}

			83.33333% {
				transform: scaleX(0.53333);
			}

			91.66667% {
				transform: scaleX(0.46667);
			}

			100% {
				transform: scaleX(0.4);
			}
		}

		@-o-keyframes segment-scale-3 {
			0% {
				-o-transform: scaleX(0.4);
			}

			8.33333% {
				-o-transform: scaleX(0.33333);
			}

			16.66667% {
				-o-transform: scaleX(0.26667);
			}

			25% {
				-o-transform: scaleX(1);
			}

			33.33333% {
				-o-transform: scaleX(0.93333);
			}

			41.66667% {
				-o-transform: scaleX(0.86667);
			}

			50% {
				-o-transform: scaleX(0.8);
			}

			58.33333% {
				-o-transform: scaleX(0.73333);
			}

			66.66667% {
				-o-transform: scaleX(0.66667);
			}

			75% {
				-o-transform: scaleX(0.6);
			}

			83.33333% {
				-o-transform: scaleX(0.53333);
			}

			91.66667% {
				-o-transform: scaleX(0.46667);
			}

			100% {
				-o-transform: scaleX(0.4);
			}
		}

		@-ms-keyframes segment-scale-3 {
			0% {
				-ms-transform: scaleX(0.4);
			}

			8.33333% {
				-ms-transform: scaleX(0.33333);
			}

			16.66667% {
				-ms-transform: scaleX(0.26667);
			}

			25% {
				-ms-transform: scaleX(1);
			}

			33.33333% {
				-ms-transform: scaleX(0.93333);
			}

			41.66667% {
				-ms-transform: scaleX(0.86667);
			}

			50% {
				-ms-transform: scaleX(0.8);
			}

			58.33333% {
				-ms-transform: scaleX(0.73333);
			}

			66.66667% {
				-ms-transform: scaleX(0.66667);
			}

			75% {
				-ms-transform: scaleX(0.6);
			}

			83.33333% {
				-ms-transform: scaleX(0.53333);
			}

			91.66667% {
				-ms-transform: scaleX(0.46667);
			}

			100% {
				-ms-transform: scaleX(0.4);
			}
		}

		@-webkit-keyframes segment-scale-3 {
			0% {
				-webkit-transform: scaleX(0.4);
			}

			8.33333% {
				-webkit-transform: scaleX(0.33333);
			}

			16.66667% {
				-webkit-transform: scaleX(0.26667);
			}

			25% {
				-webkit-transform: scaleX(1);
			}

			33.33333% {
				-webkit-transform: scaleX(0.93333);
			}

			41.66667% {
				-webkit-transform: scaleX(0.86667);
			}

			50% {
				-webkit-transform: scaleX(0.8);
			}

			58.33333% {
				-webkit-transform: scaleX(0.73333);
			}

			66.66667% {
				-webkit-transform: scaleX(0.66667);
			}

			75% {
				-webkit-transform: scaleX(0.6);
			}

			83.33333% {
				-webkit-transform: scaleX(0.53333);
			}

			91.66667% {
				-webkit-transform: scaleX(0.46667);
			}

			100% {
				-webkit-transform: scaleX(0.4);
			}
		}

		@-moz-keyframes segment-scale-3 {
			0% {
				-moz-transform: scaleX(0.4);
			}

			8.33333% {
				-moz-transform: scaleX(0.33333);
			}

			16.66667% {
				-moz-transform: scaleX(0.26667);
			}

			25% {
				-moz-transform: scaleX(1);
			}

			33.33333% {
				-moz-transform: scaleX(0.93333);
			}

			41.66667% {
				-moz-transform: scaleX(0.86667);
			}

			50% {
				-moz-transform: scaleX(0.8);
			}

			58.33333% {
				-moz-transform: scaleX(0.73333);
			}

			66.66667% {
				-moz-transform: scaleX(0.66667);
			}

			75% {
				-moz-transform: scaleX(0.6);
			}

			83.33333% {
				-moz-transform: scaleX(0.53333);
			}

			91.66667% {
				-moz-transform: scaleX(0.46667);
			}

			100% {
				-moz-transform: scaleX(0.4);
			}
		}

		@keyframes segment-scale-2 {
			0% {
				transform: scaleX(0.33333);
			}

			8.33333% {
				transform: scaleX(0.26667);
			}

			16.66667% {
				transform: scaleX(1);
			}

			25% {
				transform: scaleX(0.93333);
			}

			33.33333% {
				transform: scaleX(0.86667);
			}

			41.66667% {
				transform: scaleX(0.8);
			}

			50% {
				transform: scaleX(0.73333);
			}

			58.33333% {
				transform: scaleX(0.66667);
			}

			66.66667% {
				transform: scaleX(0.6);
			}

			75% {
				transform: scaleX(0.53333);
			}

			83.33333% {
				transform: scaleX(0.46667);
			}

			91.66667% {
				transform: scaleX(0.4);
			}

			100% {
				transform: scaleX(0.33333);
			}
		}

		@-o-keyframes segment-scale-2 {
			0% {
				-o-transform: scaleX(0.33333);
			}

			8.33333% {
				-o-transform: scaleX(0.26667);
			}

			16.66667% {
				-o-transform: scaleX(1);
			}

			25% {
				-o-transform: scaleX(0.93333);
			}

			33.33333% {
				-o-transform: scaleX(0.86667);
			}

			41.66667% {
				-o-transform: scaleX(0.8);
			}

			50% {
				-o-transform: scaleX(0.73333);
			}

			58.33333% {
				-o-transform: scaleX(0.66667);
			}

			66.66667% {
				-o-transform: scaleX(0.6);
			}

			75% {
				-o-transform: scaleX(0.53333);
			}

			83.33333% {
				-o-transform: scaleX(0.46667);
			}

			91.66667% {
				-o-transform: scaleX(0.4);
			}

			100% {
				-o-transform: scaleX(0.33333);
			}
		}

		@-ms-keyframes segment-scale-2 {
			0% {
				-ms-transform: scaleX(0.33333);
			}

			8.33333% {
				-ms-transform: scaleX(0.26667);
			}

			16.66667% {
				-ms-transform: scaleX(1);
			}

			25% {
				-ms-transform: scaleX(0.93333);
			}

			33.33333% {
				-ms-transform: scaleX(0.86667);
			}

			41.66667% {
				-ms-transform: scaleX(0.8);
			}

			50% {
				-ms-transform: scaleX(0.73333);
			}

			58.33333% {
				-ms-transform: scaleX(0.66667);
			}

			66.66667% {
				-ms-transform: scaleX(0.6);
			}

			75% {
				-ms-transform: scaleX(0.53333);
			}

			83.33333% {
				-ms-transform: scaleX(0.46667);
			}

			91.66667% {
				-ms-transform: scaleX(0.4);
			}

			100% {
				-ms-transform: scaleX(0.33333);
			}
		}

		@-webkit-keyframes segment-scale-2 {
			0% {
				-webkit-transform: scaleX(0.33333);
			}

			8.33333% {
				-webkit-transform: scaleX(0.26667);
			}

			16.66667% {
				-webkit-transform: scaleX(1);
			}

			25% {
				-webkit-transform: scaleX(0.93333);
			}

			33.33333% {
				-webkit-transform: scaleX(0.86667);
			}

			41.66667% {
				-webkit-transform: scaleX(0.8);
			}

			50% {
				-webkit-transform: scaleX(0.73333);
			}

			58.33333% {
				-webkit-transform: scaleX(0.66667);
			}

			66.66667% {
				-webkit-transform: scaleX(0.6);
			}

			75% {
				-webkit-transform: scaleX(0.53333);
			}

			83.33333% {
				-webkit-transform: scaleX(0.46667);
			}

			91.66667% {
				-webkit-transform: scaleX(0.4);
			}

			100% {
				-webkit-transform: scaleX(0.33333);
			}
		}

		@-moz-keyframes segment-scale-2 {
			0% {
				-moz-transform: scaleX(0.33333);
			}

			8.33333% {
				-moz-transform: scaleX(0.26667);
			}

			16.66667% {
				-moz-transform: scaleX(1);
			}

			25% {
				-moz-transform: scaleX(0.93333);
			}

			33.33333% {
				-moz-transform: scaleX(0.86667);
			}

			41.66667% {
				-moz-transform: scaleX(0.8);
			}

			50% {
				-moz-transform: scaleX(0.73333);
			}

			58.33333% {
				-moz-transform: scaleX(0.66667);
			}

			66.66667% {
				-moz-transform: scaleX(0.6);
			}

			75% {
				-moz-transform: scaleX(0.53333);
			}

			83.33333% {
				-moz-transform: scaleX(0.46667);
			}

			91.66667% {
				-moz-transform: scaleX(0.4);
			}

			100% {
				-moz-transform: scaleX(0.33333);
			}
		}

		@keyframes segment-scale-1 {
			0% {
				transform: scaleX(0.26667);
			}

			8.33333% {
				transform: scaleX(1);
			}

			16.66667% {
				transform: scaleX(0.93333);
			}

			25% {
				transform: scaleX(0.86667);
			}

			33.33333% {
				transform: scaleX(0.8);
			}

			41.66667% {
				transform: scaleX(0.73333);
			}

			50% {
				transform: scaleX(0.66667);
			}

			58.33333% {
				transform: scaleX(0.6);
			}

			66.66667% {
				transform: scaleX(0.53333);
			}

			75% {
				transform: scaleX(0.46667);
			}

			83.33333% {
				transform: scaleX(0.4);
			}

			91.66667% {
				transform: scaleX(0.33333);
			}

			100% {
				transform: scaleX(0.26667);
			}
		}

		@-o-keyframes segment-scale-1 {
			0% {
				-o-transform: scaleX(0.26667);
			}

			8.33333% {
				-o-transform: scaleX(1);
			}

			16.66667% {
				-o-transform: scaleX(0.93333);
			}

			25% {
				-o-transform: scaleX(0.86667);
			}

			33.33333% {
				-o-transform: scaleX(0.8);
			}

			41.66667% {
				-o-transform: scaleX(0.73333);
			}

			50% {
				-o-transform: scaleX(0.66667);
			}

			58.33333% {
				-o-transform: scaleX(0.6);
			}

			66.66667% {
				-o-transform: scaleX(0.53333);
			}

			75% {
				-o-transform: scaleX(0.46667);
			}

			83.33333% {
				-o-transform: scaleX(0.4);
			}

			91.66667% {
				-o-transform: scaleX(0.33333);
			}

			100% {
				-o-transform: scaleX(0.26667);
			}
		}

		@-ms-keyframes segment-scale-1 {
			0% {
				-ms-transform: scaleX(0.26667);
			}

			8.33333% {
				-ms-transform: scaleX(1);
			}

			16.66667% {
				-ms-transform: scaleX(0.93333);
			}

			25% {
				-ms-transform: scaleX(0.86667);
			}

			33.33333% {
				-ms-transform: scaleX(0.8);
			}

			41.66667% {
				-ms-transform: scaleX(0.73333);
			}

			50% {
				-ms-transform: scaleX(0.66667);
			}

			58.33333% {
				-ms-transform: scaleX(0.6);
			}

			66.66667% {
				-ms-transform: scaleX(0.53333);
			}

			75% {
				-ms-transform: scaleX(0.46667);
			}

			83.33333% {
				-ms-transform: scaleX(0.4);
			}

			91.66667% {
				-ms-transform: scaleX(0.33333);
			}

			100% {
				-ms-transform: scaleX(0.26667);
			}
		}

		@-webkit-keyframes segment-scale-1 {
			0% {
				-webkit-transform: scaleX(0.26667);
			}

			8.33333% {
				-webkit-transform: scaleX(1);
			}

			16.66667% {
				-webkit-transform: scaleX(0.93333);
			}

			25% {
				-webkit-transform: scaleX(0.86667);
			}

			33.33333% {
				-webkit-transform: scaleX(0.8);
			}

			41.66667% {
				-webkit-transform: scaleX(0.73333);
			}

			50% {
				-webkit-transform: scaleX(0.66667);
			}

			58.33333% {
				-webkit-transform: scaleX(0.6);
			}

			66.66667% {
				-webkit-transform: scaleX(0.53333);
			}

			75% {
				-webkit-transform: scaleX(0.46667);
			}

			83.33333% {
				-webkit-transform: scaleX(0.4);
			}

			91.66667% {
				-webkit-transform: scaleX(0.33333);
			}

			100% {
				-webkit-transform: scaleX(0.26667);
			}
		}

		@-moz-keyframes segment-scale-1 {
			0% {
				-moz-transform: scaleX(0.26667);
			}

			8.33333% {
				-moz-transform: scaleX(1);
			}

			16.66667% {
				-moz-transform: scaleX(0.93333);
			}

			25% {
				-moz-transform: scaleX(0.86667);
			}

			33.33333% {
				-moz-transform: scaleX(0.8);
			}

			41.66667% {
				-moz-transform: scaleX(0.73333);
			}

			50% {
				-moz-transform: scaleX(0.66667);
			}

			58.33333% {
				-moz-transform: scaleX(0.6);
			}

			66.66667% {
				-moz-transform: scaleX(0.53333);
			}

			75% {
				-moz-transform: scaleX(0.46667);
			}

			83.33333% {
				-moz-transform: scaleX(0.4);
			}

			91.66667% {
				-moz-transform: scaleX(0.33333);
			}

			100% {
				-moz-transform: scaleX(0.26667);
			}
		}

		@keyframes segment-opacity-12 {
			0% {
				opacity: 1;
			}

			8.33333% {
				opacity: 0.93333;
			}

			16.66667% {
				opacity: 0.86667;
			}

			25% {
				opacity: 0.8;
			}

			33.33333% {
				opacity: 0.73333;
			}

			41.66667% {
				opacity: 0.66667;
			}

			50% {
				opacity: 0.6;
			}

			58.33333% {
				opacity: 0.53333;
			}

			66.66667% {
				opacity: 0.46667;
			}

			75% {
				opacity: 0.4;
			}

			83.33333% {
				opacity: 0.33333;
			}

			91.66667% {
				opacity: 0.26667;
			}

			100% {
				opacity: 1;
			}
		}

		@-o-keyframes segment-opacity-12 {
			0% {
				opacity: 1;
			}

			8.33333% {
				opacity: 0.93333;
			}

			16.66667% {
				opacity: 0.86667;
			}

			25% {
				opacity: 0.8;
			}

			33.33333% {
				opacity: 0.73333;
			}

			41.66667% {
				opacity: 0.66667;
			}

			50% {
				opacity: 0.6;
			}

			58.33333% {
				opacity: 0.53333;
			}

			66.66667% {
				opacity: 0.46667;
			}

			75% {
				opacity: 0.4;
			}

			83.33333% {
				opacity: 0.33333;
			}

			91.66667% {
				opacity: 0.26667;
			}

			100% {
				opacity: 1;
			}
		}

		@-ms-keyframes segment-opacity-12 {
			0% {
				opacity: 1;
			}

			8.33333% {
				opacity: 0.93333;
			}

			16.66667% {
				opacity: 0.86667;
			}

			25% {
				opacity: 0.8;
			}

			33.33333% {
				opacity: 0.73333;
			}

			41.66667% {
				opacity: 0.66667;
			}

			50% {
				opacity: 0.6;
			}

			58.33333% {
				opacity: 0.53333;
			}

			66.66667% {
				opacity: 0.46667;
			}

			75% {
				opacity: 0.4;
			}

			83.33333% {
				opacity: 0.33333;
			}

			91.66667% {
				opacity: 0.26667;
			}

			100% {
				opacity: 1;
			}
		}

		@-webkit-keyframes segment-opacity-12 {
			0% {
				opacity: 1;
			}

			8.33333% {
				opacity: 0.93333;
			}

			16.66667% {
				opacity: 0.86667;
			}

			25% {
				opacity: 0.8;
			}

			33.33333% {
				opacity: 0.73333;
			}

			41.66667% {
				opacity: 0.66667;
			}

			50% {
				opacity: 0.6;
			}

			58.33333% {
				opacity: 0.53333;
			}

			66.66667% {
				opacity: 0.46667;
			}

			75% {
				opacity: 0.4;
			}

			83.33333% {
				opacity: 0.33333;
			}

			91.66667% {
				opacity: 0.26667;
			}

			100% {
				opacity: 1;
			}
		}

		@-moz-keyframes segment-opacity-12 {
			0% {
				opacity: 1;
			}

			8.33333% {
				opacity: 0.93333;
			}

			16.66667% {
				opacity: 0.86667;
			}

			25% {
				opacity: 0.8;
			}

			33.33333% {
				opacity: 0.73333;
			}

			41.66667% {
				opacity: 0.66667;
			}

			50% {
				opacity: 0.6;
			}

			58.33333% {
				opacity: 0.53333;
			}

			66.66667% {
				opacity: 0.46667;
			}

			75% {
				opacity: 0.4;
			}

			83.33333% {
				opacity: 0.33333;
			}

			91.66667% {
				opacity: 0.26667;
			}

			100% {
				opacity: 1;
			}
		}

		@keyframes segment-opacity-11 {
			0% {
				opacity: 0.93333;
			}

			8.33333% {
				opacity: 0.86667;
			}

			16.66667% {
				opacity: 0.8;
			}

			25% {
				opacity: 0.73333;
			}

			33.33333% {
				opacity: 0.66667;
			}

			41.66667% {
				opacity: 0.6;
			}

			50% {
				opacity: 0.53333;
			}

			58.33333% {
				opacity: 0.46667;
			}

			66.66667% {
				opacity: 0.4;
			}

			75% {
				opacity: 0.33333;
			}

			83.33333% {
				opacity: 0.26667;
			}

			91.66667% {
				opacity: 1;
			}

			100% {
				opacity: 0.93333;
			}
		}

		@-o-keyframes segment-opacity-11 {
			0% {
				opacity: 0.93333;
			}

			8.33333% {
				opacity: 0.86667;
			}

			16.66667% {
				opacity: 0.8;
			}

			25% {
				opacity: 0.73333;
			}

			33.33333% {
				opacity: 0.66667;
			}

			41.66667% {
				opacity: 0.6;
			}

			50% {
				opacity: 0.53333;
			}

			58.33333% {
				opacity: 0.46667;
			}

			66.66667% {
				opacity: 0.4;
			}

			75% {
				opacity: 0.33333;
			}

			83.33333% {
				opacity: 0.26667;
			}

			91.66667% {
				opacity: 1;
			}

			100% {
				opacity: 0.93333;
			}
		}

		@-ms-keyframes segment-opacity-11 {
			0% {
				opacity: 0.93333;
			}

			8.33333% {
				opacity: 0.86667;
			}

			16.66667% {
				opacity: 0.8;
			}

			25% {
				opacity: 0.73333;
			}

			33.33333% {
				opacity: 0.66667;
			}

			41.66667% {
				opacity: 0.6;
			}

			50% {
				opacity: 0.53333;
			}

			58.33333% {
				opacity: 0.46667;
			}

			66.66667% {
				opacity: 0.4;
			}

			75% {
				opacity: 0.33333;
			}

			83.33333% {
				opacity: 0.26667;
			}

			91.66667% {
				opacity: 1;
			}

			100% {
				opacity: 0.93333;
			}
		}

		@-webkit-keyframes segment-opacity-11 {
			0% {
				opacity: 0.93333;
			}

			8.33333% {
				opacity: 0.86667;
			}

			16.66667% {
				opacity: 0.8;
			}

			25% {
				opacity: 0.73333;
			}

			33.33333% {
				opacity: 0.66667;
			}

			41.66667% {
				opacity: 0.6;
			}

			50% {
				opacity: 0.53333;
			}

			58.33333% {
				opacity: 0.46667;
			}

			66.66667% {
				opacity: 0.4;
			}

			75% {
				opacity: 0.33333;
			}

			83.33333% {
				opacity: 0.26667;
			}

			91.66667% {
				opacity: 1;
			}

			100% {
				opacity: 0.93333;
			}
		}

		@-moz-keyframes segment-opacity-11 {
			0% {
				opacity: 0.93333;
			}

			8.33333% {
				opacity: 0.86667;
			}

			16.66667% {
				opacity: 0.8;
			}

			25% {
				opacity: 0.73333;
			}

			33.33333% {
				opacity: 0.66667;
			}

			41.66667% {
				opacity: 0.6;
			}

			50% {
				opacity: 0.53333;
			}

			58.33333% {
				opacity: 0.46667;
			}

			66.66667% {
				opacity: 0.4;
			}

			75% {
				opacity: 0.33333;
			}

			83.33333% {
				opacity: 0.26667;
			}

			91.66667% {
				opacity: 1;
			}

			100% {
				opacity: 0.93333;
			}
		}

		@keyframes segment-opacity-10 {
			0% {
				opacity: 0.86667;
			}

			8.33333% {
				opacity: 0.8;
			}

			16.66667% {
				opacity: 0.73333;
			}

			25% {
				opacity: 0.66667;
			}

			33.33333% {
				opacity: 0.6;
			}

			41.66667% {
				opacity: 0.53333;
			}

			50% {
				opacity: 0.46667;
			}

			58.33333% {
				opacity: 0.4;
			}

			66.66667% {
				opacity: 0.33333;
			}

			75% {
				opacity: 0.26667;
			}

			83.33333% {
				opacity: 1;
			}

			91.66667% {
				opacity: 0.93333;
			}

			100% {
				opacity: 0.86667;
			}
		}

		@-o-keyframes segment-opacity-10 {
			0% {
				opacity: 0.86667;
			}

			8.33333% {
				opacity: 0.8;
			}

			16.66667% {
				opacity: 0.73333;
			}

			25% {
				opacity: 0.66667;
			}

			33.33333% {
				opacity: 0.6;
			}

			41.66667% {
				opacity: 0.53333;
			}

			50% {
				opacity: 0.46667;
			}

			58.33333% {
				opacity: 0.4;
			}

			66.66667% {
				opacity: 0.33333;
			}

			75% {
				opacity: 0.26667;
			}

			83.33333% {
				opacity: 1;
			}

			91.66667% {
				opacity: 0.93333;
			}

			100% {
				opacity: 0.86667;
			}
		}

		@-ms-keyframes segment-opacity-10 {
			0% {
				opacity: 0.86667;
			}

			8.33333% {
				opacity: 0.8;
			}

			16.66667% {
				opacity: 0.73333;
			}

			25% {
				opacity: 0.66667;
			}

			33.33333% {
				opacity: 0.6;
			}

			41.66667% {
				opacity: 0.53333;
			}

			50% {
				opacity: 0.46667;
			}

			58.33333% {
				opacity: 0.4;
			}

			66.66667% {
				opacity: 0.33333;
			}

			75% {
				opacity: 0.26667;
			}

			83.33333% {
				opacity: 1;
			}

			91.66667% {
				opacity: 0.93333;
			}

			100% {
				opacity: 0.86667;
			}
		}

		@-webkit-keyframes segment-opacity-10 {
			0% {
				opacity: 0.86667;
			}

			8.33333% {
				opacity: 0.8;
			}

			16.66667% {
				opacity: 0.73333;
			}

			25% {
				opacity: 0.66667;
			}

			33.33333% {
				opacity: 0.6;
			}

			41.66667% {
				opacity: 0.53333;
			}

			50% {
				opacity: 0.46667;
			}

			58.33333% {
				opacity: 0.4;
			}

			66.66667% {
				opacity: 0.33333;
			}

			75% {
				opacity: 0.26667;
			}

			83.33333% {
				opacity: 1;
			}

			91.66667% {
				opacity: 0.93333;
			}

			100% {
				opacity: 0.86667;
			}
		}

		@-moz-keyframes segment-opacity-10 {
			0% {
				opacity: 0.86667;
			}

			8.33333% {
				opacity: 0.8;
			}

			16.66667% {
				opacity: 0.73333;
			}

			25% {
				opacity: 0.66667;
			}

			33.33333% {
				opacity: 0.6;
			}

			41.66667% {
				opacity: 0.53333;
			}

			50% {
				opacity: 0.46667;
			}

			58.33333% {
				opacity: 0.4;
			}

			66.66667% {
				opacity: 0.33333;
			}

			75% {
				opacity: 0.26667;
			}

			83.33333% {
				opacity: 1;
			}

			91.66667% {
				opacity: 0.93333;
			}

			100% {
				opacity: 0.86667;
			}
		}

		@keyframes segment-opacity-9 {
			0% {
				opacity: 0.8;
			}

			8.33333% {
				opacity: 0.73333;
			}

			16.66667% {
				opacity: 0.66667;
			}

			25% {
				opacity: 0.6;
			}

			33.33333% {
				opacity: 0.53333;
			}

			41.66667% {
				opacity: 0.46667;
			}

			50% {
				opacity: 0.4;
			}

			58.33333% {
				opacity: 0.33333;
			}

			66.66667% {
				opacity: 0.26667;
			}

			75% {
				opacity: 1;
			}

			83.33333% {
				opacity: 0.933333;
			}

			91.66667% {
				opacity: 0.86667;
			}

			100% {
				opacity: 0.8;
			}
		}

		@-o-keyframes segment-opacity-9 {
			0% {
				opacity: 0.8;
			}

			8.33333% {
				opacity: 0.73333;
			}

			16.66667% {
				opacity: 0.66667;
			}

			25% {
				opacity: 0.6;
			}

			33.33333% {
				opacity: 0.53333;
			}

			41.66667% {
				opacity: 0.46667;
			}

			50% {
				opacity: 0.4;
			}

			58.33333% {
				opacity: 0.33333;
			}

			66.66667% {
				opacity: 0.26667;
			}

			75% {
				opacity: 1;
			}

			83.33333% {
				opacity: 0.933333;
			}

			91.66667% {
				opacity: 0.86667;
			}

			100% {
				opacity: 0.8;
			}
		}

		@-ms-keyframes segment-opacity-9 {
			0% {
				opacity: 0.8;
			}

			8.33333% {
				opacity: 0.73333;
			}

			16.66667% {
				opacity: 0.66667;
			}

			25% {
				opacity: 0.6;
			}

			33.33333% {
				opacity: 0.53333;
			}

			41.66667% {
				opacity: 0.46667;
			}

			50% {
				opacity: 0.4;
			}

			58.33333% {
				opacity: 0.33333;
			}

			66.66667% {
				opacity: 0.26667;
			}

			75% {
				opacity: 1;
			}

			83.33333% {
				opacity: 0.933333;
			}

			91.66667% {
				opacity: 0.86667;
			}

			100% {
				opacity: 0.8;
			}
		}

		@-webkit-keyframes segment-opacity-9 {
			0% {
				opacity: 0.8;
			}

			8.33333% {
				opacity: 0.73333;
			}

			16.66667% {
				opacity: 0.66667;
			}

			25% {
				opacity: 0.6;
			}

			33.33333% {
				opacity: 0.53333;
			}

			41.66667% {
				opacity: 0.46667;
			}

			50% {
				opacity: 0.4;
			}

			58.33333% {
				opacity: 0.33333;
			}

			66.66667% {
				opacity: 0.26667;
			}

			75% {
				opacity: 1;
			}

			83.33333% {
				opacity: 0.933333;
			}

			91.66667% {
				opacity: 0.86667;
			}

			100% {
				opacity: 0.8;
			}
		}

		@-moz-keyframes segment-opacity-9 {
			0% {
				opacity: 0.8;
			}

			8.33333% {
				opacity: 0.73333;
			}

			16.66667% {
				opacity: 0.66667;
			}

			25% {
				opacity: 0.6;
			}

			33.33333% {
				opacity: 0.53333;
			}

			41.66667% {
				opacity: 0.46667;
			}

			50% {
				opacity: 0.4;
			}

			58.33333% {
				opacity: 0.33333;
			}

			66.66667% {
				opacity: 0.26667;
			}

			75% {
				opacity: 1;
			}

			83.33333% {
				opacity: 0.933333;
			}

			91.66667% {
				opacity: 0.86667;
			}

			100% {
				opacity: 0.8;
			}
		}

		@keyframes segment-opacity-8 {
			0% {
				opacity: 0.73333;
			}

			8.33333% {
				opacity: 0.66667;
			}

			16.66667% {
				opacity: 0.6;
			}

			25% {
				opacity: 0.53333;
			}

			33.33333% {
				opacity: 0.46667;
			}

			41.66667% {
				opacity: 0.4;
			}

			50% {
				opacity: 0.33333;
			}

			58.33333% {
				opacity: 0.26667;
			}

			66.66667% {
				opacity: 1;
			}

			75% {
				opacity: 0.93333;
			}

			83.33333% {
				opacity: 0.86667;
			}

			91.66667% {
				opacity: 0.8;
			}

			100% {
				opacity: 0.73333;
			}
		}

		@-o-keyframes segment-opacity-8 {
			0% {
				opacity: 0.73333;
			}

			8.33333% {
				opacity: 0.66667;
			}

			16.66667% {
				opacity: 0.6;
			}

			25% {
				opacity: 0.53333;
			}

			33.33333% {
				opacity: 0.46667;
			}

			41.66667% {
				opacity: 0.4;
			}

			50% {
				opacity: 0.33333;
			}

			58.33333% {
				opacity: 0.26667;
			}

			66.66667% {
				opacity: 1;
			}

			75% {
				opacity: 0.93333;
			}

			83.33333% {
				opacity: 0.86667;
			}

			91.66667% {
				opacity: 0.8;
			}

			100% {
				opacity: 0.73333;
			}
		}

		@-ms-keyframes segment-opacity-8 {
			0% {
				opacity: 0.73333;
			}

			8.33333% {
				opacity: 0.66667;
			}

			16.66667% {
				opacity: 0.6;
			}

			25% {
				opacity: 0.53333;
			}

			33.33333% {
				opacity: 0.46667;
			}

			41.66667% {
				opacity: 0.4;
			}

			50% {
				opacity: 0.33333;
			}

			58.33333% {
				opacity: 0.26667;
			}

			66.66667% {
				opacity: 1;
			}

			75% {
				opacity: 0.93333;
			}

			83.33333% {
				opacity: 0.86667;
			}

			91.66667% {
				opacity: 0.8;
			}

			100% {
				opacity: 0.73333;
			}
		}

		@-webkit-keyframes segment-opacity-8 {
			0% {
				opacity: 0.73333;
			}

			8.33333% {
				opacity: 0.66667;
			}

			16.66667% {
				opacity: 0.6;
			}

			25% {
				opacity: 0.53333;
			}

			33.33333% {
				opacity: 0.46667;
			}

			41.66667% {
				opacity: 0.4;
			}

			50% {
				opacity: 0.33333;
			}

			58.33333% {
				opacity: 0.26667;
			}

			66.66667% {
				opacity: 1;
			}

			75% {
				opacity: 0.93333;
			}

			83.33333% {
				opacity: 0.86667;
			}

			91.66667% {
				opacity: 0.8;
			}

			100% {
				opacity: 0.73333;
			}
		}

		@-moz-keyframes segment-opacity-8 {
			0% {
				opacity: 0.73333;
			}

			8.33333% {
				opacity: 0.66667;
			}

			16.66667% {
				opacity: 0.6;
			}

			25% {
				opacity: 0.53333;
			}

			33.33333% {
				opacity: 0.46667;
			}

			41.66667% {
				opacity: 0.4;
			}

			50% {
				opacity: 0.33333;
			}

			58.33333% {
				opacity: 0.26667;
			}

			66.66667% {
				opacity: 1;
			}

			75% {
				opacity: 0.93333;
			}

			83.33333% {
				opacity: 0.86667;
			}

			91.66667% {
				opacity: 0.8;
			}

			100% {
				opacity: 0.73333;
			}
		}

		@keyframes segment-opacity-7 {
			0% {
				opacity: 0.66667;
			}

			8.33333% {
				opacity: 0.6;
			}

			16.66667% {
				opacity: 0.53333;
			}

			25% {
				opacity: 0.46667;
			}

			33.33333% {
				opacity: 0.4;
			}

			41.66667% {
				opacity: 0.33333;
			}

			50% {
				opacity: 0.26667;
			}

			58.33333% {
				opacity: 1;
			}

			66.66667% {
				opacity: 0.93333;
			}

			75% {
				opacity: 0.86667;
			}

			83.33333% {
				opacity: 0.8;
			}

			91.66667% {
				opacity: 0.73333;
			}

			100% {
				opacity: 0.66667;
			}
		}

		@-o-keyframes segment-opacity-7 {
			0% {
				opacity: 0.66667;
			}

			8.33333% {
				opacity: 0.6;
			}

			16.66667% {
				opacity: 0.53333;
			}

			25% {
				opacity: 0.46667;
			}

			33.33333% {
				opacity: 0.4;
			}

			41.66667% {
				opacity: 0.33333;
			}

			50% {
				opacity: 0.26667;
			}

			58.33333% {
				opacity: 1;
			}

			66.66667% {
				opacity: 0.93333;
			}

			75% {
				opacity: 0.86667;
			}

			83.33333% {
				opacity: 0.8;
			}

			91.66667% {
				opacity: 0.73333;
			}

			100% {
				opacity: 0.66667;
			}
		}

		@-ms-keyframes segment-opacity-7 {
			0% {
				opacity: 0.66667;
			}

			8.33333% {
				opacity: 0.6;
			}

			16.66667% {
				opacity: 0.53333;
			}

			25% {
				opacity: 0.46667;
			}

			33.33333% {
				opacity: 0.4;
			}

			41.66667% {
				opacity: 0.33333;
			}

			50% {
				opacity: 0.26667;
			}

			58.33333% {
				opacity: 1;
			}

			66.66667% {
				opacity: 0.93333;
			}

			75% {
				opacity: 0.86667;
			}

			83.33333% {
				opacity: 0.8;
			}

			91.66667% {
				opacity: 0.73333;
			}

			100% {
				opacity: 0.66667;
			}
		}

		@-webkit-keyframes segment-opacity-7 {
			0% {
				opacity: 0.66667;
			}

			8.33333% {
				opacity: 0.6;
			}

			16.66667% {
				opacity: 0.53333;
			}

			25% {
				opacity: 0.46667;
			}

			33.33333% {
				opacity: 0.4;
			}

			41.66667% {
				opacity: 0.33333;
			}

			50% {
				opacity: 0.26667;
			}

			58.33333% {
				opacity: 1;
			}

			66.66667% {
				opacity: 0.93333;
			}

			75% {
				opacity: 0.86667;
			}

			83.33333% {
				opacity: 0.8;
			}

			91.66667% {
				opacity: 0.73333;
			}

			100% {
				opacity: 0.66667;
			}
		}

		@-moz-keyframes segment-opacity-7 {
			0% {
				opacity: 0.66667;
			}

			8.33333% {
				opacity: 0.6;
			}

			16.66667% {
				opacity: 0.53333;
			}

			25% {
				opacity: 0.46667;
			}

			33.33333% {
				opacity: 0.4;
			}

			41.66667% {
				opacity: 0.33333;
			}

			50% {
				opacity: 0.26667;
			}

			58.33333% {
				opacity: 1;
			}

			66.66667% {
				opacity: 0.93333;
			}

			75% {
				opacity: 0.86667;
			}

			83.33333% {
				opacity: 0.8;
			}

			91.66667% {
				opacity: 0.73333;
			}

			100% {
				opacity: 0.66667;
			}
		}

		@keyframes segment-opacity-6 {
			0% {
				opacity: 0.6;
			}

			8.33333% {
				opacity: 0.53333;
			}

			16.66667% {
				opacity: 0.46667;
			}

			25% {
				opacity: 0.4;
			}

			33.33333% {
				opacity: 0.33333;
			}

			41.66667% {
				opacity: 0.26667;
			}

			50% {
				opacity: 1;
			}

			58.33333% {
				opacity: 0.93333;
			}

			66.66667% {
				opacity: 0.86667;
			}

			75% {
				opacity: 0.8;
			}

			83.33333% {
				opacity: 0.73333;
			}

			91.66667% {
				acity: 0.66667;
			}

			100% {
				opacity: 0.6;
			}
		}

		@-o-keyframes segment-opacity-6 {
			0% {
				opacity: 0.6;
			}

			8.33333% {
				opacity: 0.53333;
			}

			16.66667% {
				opacity: 0.46667;
			}

			25% {
				opacity: 0.4;
			}

			33.33333% {
				opacity: 0.33333;
			}

			41.66667% {
				opacity: 0.26667;
			}

			50% {
				opacity: 1;
			}

			58.33333% {
				opacity: 0.93333;
			}

			66.66667% {
				opacity: 0.86667;
			}

			75% {
				opacity: 0.8;
			}

			83.33333% {
				opacity: 0.73333;
			}

			91.66667% {
				acity: 0.66667;
			}

			100% {
				opacity: 0.6;
			}
		}

		@-ms-keyframes segment-opacity-6 {
			0% {
				opacity: 0.6;
			}

			8.33333% {
				opacity: 0.53333;
			}

			16.66667% {
				opacity: 0.46667;
			}

			25% {
				opacity: 0.4;
			}

			33.33333% {
				opacity: 0.33333;
			}

			41.66667% {
				opacity: 0.26667;
			}

			50% {
				opacity: 1;
			}

			58.33333% {
				opacity: 0.93333;
			}

			66.66667% {
				opacity: 0.86667;
			}

			75% {
				opacity: 0.8;
			}

			83.33333% {
				opacity: 0.73333;
			}

			91.66667% {
				acity: 0.66667;
			}

			100% {
				opacity: 0.6;
			}
		}

		@-webkit-keyframes segment-opacity-6 {
			0% {
				opacity: 0.6;
			}

			8.33333% {
				opacity: 0.53333;
			}

			16.66667% {
				opacity: 0.46667;
			}

			25% {
				opacity: 0.4;
			}

			33.33333% {
				opacity: 0.33333;
			}

			41.66667% {
				opacity: 0.26667;
			}

			50% {
				opacity: 1;
			}

			58.33333% {
				opacity: 0.93333;
			}

			66.66667% {
				opacity: 0.86667;
			}

			75% {
				opacity: 0.8;
			}

			83.33333% {
				opacity: 0.73333;
			}

			91.66667% {
				acity: 0.66667;
			}

			100% {
				opacity: 0.6;
			}
		}

		@-moz-keyframes segment-opacity-6 {
			0% {
				opacity: 0.6;
			}

			8.33333% {
				opacity: 0.53333;
			}

			16.66667% {
				opacity: 0.46667;
			}

			25% {
				opacity: 0.4;
			}

			33.33333% {
				opacity: 0.33333;
			}

			41.66667% {
				opacity: 0.26667;
			}

			50% {
				opacity: 1;
			}

			58.33333% {
				opacity: 0.93333;
			}

			66.66667% {
				opacity: 0.86667;
			}

			75% {
				opacity: 0.8;
			}

			83.33333% {
				opacity: 0.73333;
			}

			91.66667% {
				acity: 0.66667;
			}

			100% {
				opacity: 0.6;
			}
		}

		@keyframes segment-opacity-5 {
			0% {
				opacity: 0.53333;
			}

			8.33333% {
				opacity: 0.46667;
			}

			16.66667% {
				opacity: 0.4;
			}

			25% {
				opacity: 0.33333;
			}

			33.33333% {
				opacity: 0.26667;
			}

			41.66667% {
				opacity: 1;
			}

			50% {
				opacity: 0.93333;
			}

			58.33333% {
				opacity: 0.86667;
			}

			66.66667% {
				opacity: 0.8;
			}

			75% {
				opacity: 0.73333;
			}

			83.33333% {
				opacity: 0.66667;
			}

			91.66667% {
				opacity: 0.6;
			}

			100% {
				opacity: 0.53333;
			}
		}

		@-o-keyframes segment-opacity-5 {
			0% {
				opacity: 0.53333;
			}

			8.33333% {
				opacity: 0.46667;
			}

			16.66667% {
				opacity: 0.4;
			}

			25% {
				opacity: 0.33333;
			}

			33.33333% {
				opacity: 0.26667;
			}

			41.66667% {
				opacity: 1;
			}

			50% {
				opacity: 0.93333;
			}

			58.33333% {
				opacity: 0.86667;
			}

			66.66667% {
				opacity: 0.8;
			}

			75% {
				opacity: 0.73333;
			}

			83.33333% {
				opacity: 0.66667;
			}

			91.66667% {
				opacity: 0.6;
			}

			100% {
				opacity: 0.53333;
			}
		}

		@-ms-keyframes segment-opacity-5 {
			0% {
				opacity: 0.53333;
			}

			8.33333% {
				opacity: 0.46667;
			}

			16.66667% {
				opacity: 0.4;
			}

			25% {
				opacity: 0.33333;
			}

			33.33333% {
				opacity: 0.26667;
			}

			41.66667% {
				opacity: 1;
			}

			50% {
				opacity: 0.93333;
			}

			58.33333% {
				opacity: 0.86667;
			}

			66.66667% {
				opacity: 0.8;
			}

			75% {
				opacity: 0.73333;
			}

			83.33333% {
				opacity: 0.66667;
			}

			91.66667% {
				opacity: 0.6;
			}

			100% {
				opacity: 0.53333;
			}
		}

		@-webkit-keyframes segment-opacity-5 {
			0% {
				opacity: 0.53333;
			}

			8.33333% {
				opacity: 0.46667;
			}

			16.66667% {
				opacity: 0.4;
			}

			25% {
				opacity: 0.33333;
			}

			33.33333% {
				opacity: 0.26667;
			}

			41.66667% {
				opacity: 1;
			}

			50% {
				opacity: 0.93333;
			}

			58.33333% {
				opacity: 0.86667;
			}

			66.66667% {
				opacity: 0.8;
			}

			75% {
				opacity: 0.73333;
			}

			83.33333% {
				opacity: 0.66667;
			}

			91.66667% {
				opacity: 0.6;
			}

			100% {
				opacity: 0.53333;
			}
		}

		@-moz-keyframes segment-opacity-5 {
			0% {
				opacity: 0.53333;
			}

			8.33333% {
				opacity: 0.46667;
			}

			16.66667% {
				opacity: 0.4;
			}

			25% {
				opacity: 0.33333;
			}

			33.33333% {
				opacity: 0.26667;
			}

			41.66667% {
				opacity: 1;
			}

			50% {
				opacity: 0.93333;
			}

			58.33333% {
				opacity: 0.86667;
			}

			66.66667% {
				opacity: 0.8;
			}

			75% {
				opacity: 0.73333;
			}

			83.33333% {
				opacity: 0.66667;
			}

			91.66667% {
				opacity: 0.6;
			}

			100% {
				opacity: 0.53333;
			}
		}

		@keyframes segment-opacity-4 {
			0% {
				opacity: 0.46667;
			}

			8.33333% {
				opacity: 0.4;
			}

			16.66667% {
				opacity: 0.33333;
			}

			25% {
				opacity: 0.26667;
			}

			33.33333% {
				opacity: 1;
			}

			41.66667% {
				opacity: 0.93333;
			}

			50% {
				opacity: 0.86667;
			}

			58.33333% {
				opacity: 0.8;
			}

			66.66667% {
				opacity: 0.73333;
			}

			75% {
				opacity: 0.66667;
			}

			83.33333% {
				opacity: 0.6;
			}

			91.66667% {
				opacity: 0.53333;
			}

			100% {
				opacity: 0.46667;
			}
		}

		@-o-keyframes segment-opacity-4 {
			0% {
				opacity: 0.46667;
			}

			8.33333% {
				opacity: 0.4;
			}

			16.66667% {
				opacity: 0.33333;
			}

			25% {
				opacity: 0.26667;
			}

			33.33333% {
				opacity: 1;
			}

			41.66667% {
				opacity: 0.93333;
			}

			50% {
				opacity: 0.86667;
			}

			58.33333% {
				opacity: 0.8;
			}

			66.66667% {
				opacity: 0.73333;
			}

			75% {
				opacity: 0.66667;
			}

			83.33333% {
				opacity: 0.6;
			}

			91.66667% {
				opacity: 0.53333;
			}

			100% {
				opacity: 0.46667;
			}
		}

		@-ms-keyframes segment-opacity-4 {
			0% {
				opacity: 0.46667;
			}

			8.33333% {
				opacity: 0.4;
			}

			16.66667% {
				opacity: 0.33333;
			}

			25% {
				opacity: 0.26667;
			}

			33.33333% {
				opacity: 1;
			}

			41.66667% {
				opacity: 0.93333;
			}

			50% {
				opacity: 0.86667;
			}

			58.33333% {
				opacity: 0.8;
			}

			66.66667% {
				opacity: 0.73333;
			}

			75% {
				opacity: 0.66667;
			}

			83.33333% {
				opacity: 0.6;
			}

			91.66667% {
				opacity: 0.53333;
			}

			100% {
				opacity: 0.46667;
			}
		}

		@-webkit-keyframes segment-opacity-4 {
			0% {
				opacity: 0.46667;
			}

			8.33333% {
				opacity: 0.4;
			}

			16.66667% {
				opacity: 0.33333;
			}

			25% {
				opacity: 0.26667;
			}

			33.33333% {
				opacity: 1;
			}

			41.66667% {
				opacity: 0.93333;
			}

			50% {
				opacity: 0.86667;
			}

			58.33333% {
				opacity: 0.8;
			}

			66.66667% {
				opacity: 0.73333;
			}

			75% {
				opacity: 0.66667;
			}

			83.33333% {
				opacity: 0.6;
			}

			91.66667% {
				opacity: 0.53333;
			}

			100% {
				opacity: 0.46667;
			}
		}

		@-moz-keyframes segment-opacity-4 {
			0% {
				opacity: 0.46667;
			}

			8.33333% {
				opacity: 0.4;
			}

			16.66667% {
				opacity: 0.33333;
			}

			25% {
				opacity: 0.26667;
			}

			33.33333% {
				opacity: 1;
			}

			41.66667% {
				opacity: 0.93333;
			}

			50% {
				opacity: 0.86667;
			}

			58.33333% {
				opacity: 0.8;
			}

			66.66667% {
				opacity: 0.73333;
			}

			75% {
				opacity: 0.66667;
			}

			83.33333% {
				opacity: 0.6;
			}

			91.66667% {
				opacity: 0.53333;
			}

			100% {
				opacity: 0.46667;
			}
		}

		@keyframes segment-opacity-3 {
			0% {
				opacity: 0.4;
			}

			8.33333% {
				opacity: 0.33333;
			}

			16.66667% {
				opacity: 0.26667;
			}

			25% {
				opacity: 1;
			}

			33.33333% {
				opacity: 0.93333;
			}

			41.66667% {
				opacity: 0.86667;
			}

			50% {
				opacity: 0.8;
			}

			58.33333% {
				opacity: 0.73333;
			}

			66.66667% {
				opacity: 0.66667;
			}

			75% {
				opacity: 0.6;
			}

			83.33333% {
				opacity: 0.53333;
			}

			91.66667% {
				opacity: 0.46667;
			}

			100% {
				opacity: 0.4;
			}
		}

		@-o-keyframes segment-opacity-3 {
			0% {
				opacity: 0.4;
			}

			8.33333% {
				opacity: 0.33333;
			}

			16.66667% {
				opacity: 0.26667;
			}

			25% {
				opacity: 1;
			}

			33.33333% {
				opacity: 0.93333;
			}

			41.66667% {
				opacity: 0.86667;
			}

			50% {
				opacity: 0.8;
			}

			58.33333% {
				opacity: 0.73333;
			}

			66.66667% {
				opacity: 0.66667;
			}

			75% {
				opacity: 0.6;
			}

			83.33333% {
				opacity: 0.53333;
			}

			91.66667% {
				opacity: 0.46667;
			}

			100% {
				opacity: 0.4;
			}
		}

		@-ms-keyframes segment-opacity-3 {
			0% {
				opacity: 0.4;
			}

			8.33333% {
				opacity: 0.33333;
			}

			16.66667% {
				opacity: 0.26667;
			}

			25% {
				opacity: 1;
			}

			33.33333% {
				opacity: 0.93333;
			}

			41.66667% {
				opacity: 0.86667;
			}

			50% {
				opacity: 0.8;
			}

			58.33333% {
				opacity: 0.73333;
			}

			66.66667% {
				opacity: 0.66667;
			}

			75% {
				opacity: 0.6;
			}

			83.33333% {
				opacity: 0.53333;
			}

			91.66667% {
				opacity: 0.46667;
			}

			100% {
				opacity: 0.4;
			}
		}

		@-webkit-keyframes segment-opacity-3 {
			0% {
				opacity: 0.4;
			}

			8.33333% {
				opacity: 0.33333;
			}

			16.66667% {
				opacity: 0.26667;
			}

			25% {
				opacity: 1;
			}

			33.33333% {
				opacity: 0.93333;
			}

			41.66667% {
				opacity: 0.86667;
			}

			50% {
				opacity: 0.8;
			}

			58.33333% {
				opacity: 0.73333;
			}

			66.66667% {
				opacity: 0.66667;
			}

			75% {
				opacity: 0.6;
			}

			83.33333% {
				opacity: 0.53333;
			}

			91.66667% {
				opacity: 0.46667;
			}

			100% {
				opacity: 0.4;
			}
		}

		@-moz-keyframes segment-opacity-3 {
			0% {
				opacity: 0.4;
			}

			8.33333% {
				opacity: 0.33333;
			}

			16.66667% {
				opacity: 0.26667;
			}

			25% {
				opacity: 1;
			}

			33.33333% {
				opacity: 0.93333;
			}

			41.66667% {
				opacity: 0.86667;
			}

			50% {
				opacity: 0.8;
			}

			58.33333% {
				opacity: 0.73333;
			}

			66.66667% {
				opacity: 0.66667;
			}

			75% {
				opacity: 0.6;
			}

			83.33333% {
				opacity: 0.53333;
			}

			91.66667% {
				opacity: 0.46667;
			}

			100% {
				opacity: 0.4;
			}
		}

		@keyframes segment-opacity-2 {
			0% {
				opacity: 0.33333;
			}

			8.33333% {
				opacity: 0.26667;
			}

			16.66667% {
				opacity: 1;
			}

			25% {
				opacity: 0.93333;
			}

			33.33333% {
				opacity: 0.86667;
			}

			41.66667% {
				opacity: 0.8;
			}

			50% {
				opacity: 0.73333;
			}

			58.33333% {
				opacity: 0.66667;
			}

			66.66667% {
				opacity: 0.6;
			}

			75% {
				opacity: 0.53333;
			}

			83.33333% {
				opacity: 0.46667;
			}

			91.66667% {
				opacity: 0.4;
			}

			100% {
				opacity: 0.33333;
			}
		}

		@-o-keyframes segment-opacity-2 {
			0% {
				opacity: 0.33333;
			}

			8.33333% {
				opacity: 0.26667;
			}

			16.66667% {
				opacity: 1;
			}

			25% {
				opacity: 0.93333;
			}

			33.33333% {
				opacity: 0.86667;
			}

			41.66667% {
				opacity: 0.8;
			}

			50% {
				opacity: 0.73333;
			}

			58.33333% {
				opacity: 0.66667;
			}

			66.66667% {
				opacity: 0.6;
			}

			75% {
				opacity: 0.53333;
			}

			83.33333% {
				opacity: 0.46667;
			}

			91.66667% {
				opacity: 0.4;
			}

			100% {
				opacity: 0.33333;
			}
		}

		@-ms-keyframes segment-opacity-2 {
			0% {
				opacity: 0.33333;
			}

			8.33333% {
				opacity: 0.26667;
			}

			16.66667% {
				opacity: 1;
			}

			25% {
				opacity: 0.93333;
			}

			33.33333% {
				opacity: 0.86667;
			}

			41.66667% {
				opacity: 0.8;
			}

			50% {
				opacity: 0.73333;
			}

			58.33333% {
				opacity: 0.66667;
			}

			66.66667% {
				opacity: 0.6;
			}

			75% {
				opacity: 0.53333;
			}

			83.33333% {
				opacity: 0.46667;
			}

			91.66667% {
				opacity: 0.4;
			}

			100% {
				opacity: 0.33333;
			}
		}

		@-webkit-keyframes segment-opacity-2 {
			0% {
				opacity: 0.33333;
			}

			8.33333% {
				opacity: 0.26667;
			}

			16.66667% {
				opacity: 1;
			}

			25% {
				opacity: 0.93333;
			}

			33.33333% {
				opacity: 0.86667;
			}

			41.66667% {
				opacity: 0.8;
			}

			50% {
				opacity: 0.73333;
			}

			58.33333% {
				opacity: 0.66667;
			}

			66.66667% {
				opacity: 0.6;
			}

			75% {
				opacity: 0.53333;
			}

			83.33333% {
				opacity: 0.46667;
			}

			91.66667% {
				opacity: 0.4;
			}

			100% {
				opacity: 0.33333;
			}
		}

		@-moz-keyframes segment-opacity-2 {
			0% {
				opacity: 0.33333;
			}

			8.33333% {
				opacity: 0.26667;
			}

			16.66667% {
				opacity: 1;
			}

			25% {
				opacity: 0.93333;
			}

			33.33333% {
				opacity: 0.86667;
			}

			41.66667% {
				opacity: 0.8;
			}

			50% {
				opacity: 0.73333;
			}

			58.33333% {
				opacity: 0.66667;
			}

			66.66667% {
				opacity: 0.6;
			}

			75% {
				opacity: 0.53333;
			}

			83.33333% {
				opacity: 0.46667;
			}

			91.66667% {
				opacity: 0.4;
			}

			100% {
				opacity: 0.33333;
			}
		}

		@keyframes segment-opacity-1 {
			0% {
				opacity: 0.26667;
			}

			8.33333% {
				opacity: 1;
			}

			16.66667% {
				opacity: 0.93333;
			}

			25% {
				opacity: 0.86667;
			}

			33.33333% {
				opacity: 0.8;
			}

			41.66667% {
				opacity: 0.73333;
			}

			50% {
				opacity: 0.66667;
			}

			58.33333% {
				opacity: 0.6;
			}

			66.66667% {
				opacity: 0.53333;
			}

			75% {
				opacity: 0.46667;
			}

			83.33333% {
				opacity: 0.4;
			}

			91.66667% {
				opacity: 0.33333;
			}

			100% {
				opacity: 0.26667;
			}
		}

		@-o-keyframes segment-opacity-1 {
			0% {
				opacity: 0.26667;
			}

			8.33333% {
				opacity: 1;
			}

			16.66667% {
				opacity: 0.93333;
			}

			25% {
				opacity: 0.86667;
			}

			33.33333% {
				opacity: 0.8;
			}

			41.66667% {
				opacity: 0.73333;
			}

			50% {
				opacity: 0.66667;
			}

			58.33333% {
				opacity: 0.6;
			}

			66.66667% {
				opacity: 0.53333;
			}

			75% {
				opacity: 0.46667;
			}

			83.33333% {
				opacity: 0.4;
			}

			91.66667% {
				opacity: 0.33333;
			}

			100% {
				opacity: 0.26667;
			}
		}

		@-ms-keyframes segment-opacity-1 {
			0% {
				opacity: 0.26667;
			}

			8.33333% {
				opacity: 1;
			}

			16.66667% {
				opacity: 0.93333;
			}

			25% {
				opacity: 0.86667;
			}

			33.33333% {
				opacity: 0.8;
			}

			41.66667% {
				opacity: 0.73333;
			}

			50% {
				opacity: 0.66667;
			}

			58.33333% {
				opacity: 0.6;
			}

			66.66667% {
				opacity: 0.53333;
			}

			75% {
				opacity: 0.46667;
			}

			83.33333% {
				opacity: 0.4;
			}

			91.66667% {
				opacity: 0.33333;
			}

			100% {
				opacity: 0.26667;
			}
		}

		@-webkit-keyframes segment-opacity-1 {
			0% {
				opacity: 0.26667;
			}

			8.33333% {
				opacity: 1;
			}

			16.66667% {
				opacity: 0.93333;
			}

			25% {
				opacity: 0.86667;
			}

			33.33333% {
				opacity: 0.8;
			}

			41.66667% {
				opacity: 0.73333;
			}

			50% {
				opacity: 0.66667;
			}

			58.33333% {
				opacity: 0.6;
			}

			66.66667% {
				opacity: 0.53333;
			}

			75% {
				opacity: 0.46667;
			}

			83.33333% {
				opacity: 0.4;
			}

			91.66667% {
				opacity: 0.33333;
			}

			100% {
				opacity: 0.26667;
			}
		}

		@-moz-keyframes segment-opacity-1 {
			0% {
				opacity: 0.26667;
			}

			8.33333% {
				opacity: 1;
			}

			16.66667% {
				opacity: 0.93333;
			}

			25% {
				opacity: 0.86667;
			}

			33.33333% {
				opacity: 0.8;
			}

			41.66667% {
				opacity: 0.73333;
			}

			50% {
				opacity: 0.66667;
			}

			58.33333% {
				opacity: 0.6;
			}

			66.66667% {
				opacity: 0.53333;
			}

			75% {
				opacity: 0.46667;
			}

			83.33333% {
				opacity: 0.4;
			}

			91.66667% {
				opacity: 0.33333;
			}

			100% {
				opacity: 0.26667;
			}
		}

		.whatsappme__button {
			bottom: 25px;
			right: 20px;
		}

		.whatsappme__button img {
			height: 55px;
		}

		.aboutus_whychooseus_section .aboutus_whychooseus_align .aboutus_whychooseus_right p sup {
			vertical-align: sub;
		}
	</style>
	<?php wp_head(); ?>


</head>



<body <?php body_class(); ?>>


	<script async src="https://www.googletagmanager.com/gtag/js?id=UA-180282467-1"></script>
	<script>
		window.dataLayer = window.dataLayer || [];

		function gtag() {
			dataLayer.push(arguments);
		}
		gtag('js', new Date());

		gtag('config', 'UA-180282467-1');
	</script>

	<script type="application/ld+json">
		{
			"@context": "https://schema.org",
			"@type": "Organization",
			"name": "Blazon",
			"image": "https://www.blazon.in/assets/images/logo1.png",
			"description": "Blazon is a Tech firm with over 15+ years of experience in digital services. We provide customized solutions to assist companies in reaching their objectives.",
			"logo": "https://www.blazon.in/assets/images/logo1.png",
			"telephone": "(0422)4206100",
			"email": "info@blazon.in",
			"address": {
				"@type": "PostalAddress",
				"streetAddress": "No.2, Srivari Kikani Centre, Flat No.3, 3rd Floor, Dr, Krishnaswamy Mudaliar Road",
				"addressLocality": "R.S. Puram, Coimbatore",
				"addressRegion": "Tamil Nadu",
				"addressCountry": "India",
				"postalCode": "641002"
			},
			"url": "https://www.blazon.in/",
			"sameAs": [
				"https://www.instagram.com/blazon__official/",
				"https://twitter.com/BlazonAppDevCbe"
			]
		}
	</script>

	</head>

	<body>

		<div id="preloader">
			<div class="deco-loader">
				<div class="sheath">
					<div class="segment"></div>
				</div>
				<div class="sheath">
					<div class="segment"></div>
				</div>
				<div class="sheath">
					<div class="segment"></div>
				</div>
				<div class="sheath">
					<div class="segment"></div>
				</div>
				<div class="sheath">
					<div class="segment"></div>
				</div>
				<div class="sheath">
					<div class="segment"></div>
				</div>
				<div class="sheath">
					<div class="segment"></div>
				</div>
				<div class="sheath">
					<div class="segment"></div>
				</div>
				<div class="sheath">
					<div class="segment"></div>
				</div>
				<div class="sheath">
					<div class="segment"></div>
				</div>
				<div class="sheath">
					<div class="segment"></div>
				</div>
				<div class="sheath">
					<div class="segment"></div>
				</div>
			</div>
		</div>
		<!-- Preloader-end -->

		<div class="body_overflow">

			<!-- <div class="cursor"></div>
    <div class="cursor2"></div> -->



			<header class="header_section">
				<div class="wrapper_full">
					<div class="header_align">
						<div class="header_left">
							<a href="./" title="Blazon">
								<img src="https://www.blazon.in/assets/images/logo.png" alt="Blazon">
							</a>
						</div>
						<div class="header_right">
							<div id="cssmenu">
								<ul>
									<li>
										<a href="./" title="Home">Home</a>
									</li>
									<li>
										<a href="javascript:void(0)" title="About Blazon">About Blazon</a>
										<ul class="about_menu">
											<li><a href="./about-us.php" title="About Us" class="ab_1">About Us</a></li>
											<!-- <li><a href="./leadership.php" title="Leadership" class="ab_2">Leadership</a></li>
                    <li><a href="./how-we-work-with-a-client.php" title="How we work with a client" class="ab_3">How we work with a client</a></li> -->
											<li><a href="./case-studies.php" title="Case Studies" class="ab_4">Case Studies</a></li>
										</ul>
									</li>
									<li>
										<a href="./expertise.php" title="Expertise">Expertise</a>
										<ul>
											<div class="custom_mega_menu">
												<h2>Our Services</h2>
												<div class="custom_mega_menu_align">
													<div class="custom_mega_menu_box">
														<h4>Development Services</h4>
														<p><a href="./software-development.php" title="Software Development" class="ds_1">Software Development</a></p>
														<p><a href="./web-app-development.php" title="Web App Development" class="ds_2">Web App Development</a></p>
														<p><a href="./mobile-app-development.php" title="Mobile App Development" class="ds_3">Mobile App Development</a></p>
														<p><a href="./e-commerce-development.php" title="e-Commerce Development" class="ds_4">e-Commerce Development</a></p>
														<p><a href="./web-portal-development.php" title="Web Portal Development" class="ds_5">Web Portal Development</a></p>
														<p><a href="./software-migration-re-engineering.php" title="Software Migration & Re-engineering" class="ds_6">Software Migration & Re-engineering</a></p>
														<p><a href="./software-support-and-maintenance.php" title="Software Support and Maintenance " class="ds_7">Software Support and Maintenance </a></p>
														<p><a href="./software-application-qa-testing.php" title="Software Application & QA Testing" class="ds_8">Software Application & QA Testing</a></p>
														<p><a href="./php-development.php" title="PHP Development" class="ds_9">PHP Development</a></p>
														<p><a href="./react-development.php" title="React Development" class="ds_10">React Development</a></p>
													</div>
													<div class="custom_mega_menu_box">
														<h4>Design Services</h4>
														<p><a href="./logo-design.php" title="Logo Design" class="des_1">Logo Design</a></p>
														<p><a href="./print-design.php" title="Print Design" class="des_2">Print Design</a></p>
														<p><a href="./packaging-design.php" title="Packaging Design" class="des_3">Packaging Design</a></p>
														<p><a href="./ui-ux-design.php" title="UI/UX Design" class="des_4">UI/UX Design</a></p>
													</div>
													<div class="custom_mega_menu_box">
														<h4>Digital Marketing</h4>
														<p><a href="./search-engine-marketing.php" title="Search Engine Marketing" class="dm_1">Search Engine Marketing</a></p>
														<p><a href="./search-engine-optimization.php" title="Search Engine Optimization" class="dm_2">Search Engine Optimization</a></p>
														<p><a href="./social-media-marketing.php" title="Social Media Marketing" class="dm_3">Social Media Marketing</a></p>
														<p><a href="./social-media-optimization.php" title="Social Media Optimization" class="dm_4">Social Media Optimization</a></p>
														<p><a href="./email-marketing.php" title="eMail Marketing" class="dm_5">eMail Marketing</a></p>
													</div>
													<div class="custom_mega_menu_box">
														<h4>Web Services</h4>
														<p><a href="./domain-registration.php" title="Domain Registration" class="ws_1">Domain Registration</a></p>
														<p><a href="./web-hosting.php" title="Web Hosting" class="ws_2">Web Hosting</a></p>
														<p><a href="./web-maintenance.php" title="Web Maintenance" class="ws_3">Web Maintenance</a></p>
													</div>
												</div>
												<div class="mega_menu_footer">
													<div class="mega_menu_footer_left">
														Contact Us:
														<a href="javascript:void(0)" title="Call Now" data-bs-toggle="modal" data-bs-target="#call_popup">
															<img class="lazyload" data-src="https://www.blazon.in/assets/images/menu/call_now.png" alt="Call Now">
														</a>
														<a href="javascript:void(0)" title="Email Us" data-bs-toggle="modal" data-bs-target="#mail_popup">
															<img class="lazyload" data-src="https://www.blazon.in/assets/images/menu/mail_us.png" alt="Email Us">
														</a>
													</div>
													<div class="mega_menu_footer_right">
														Follow Us:
														<a href="https://www.facebook.com/BlazonAppDevCbe" title="Facebook" rel="noopener" target="_blank">
															<img class="lazyload" data-src="https://www.blazon.in/assets/images/menu/facebook.png" alt="Facebook">
														</a>
														<a href="https://www.instagram.com/blazon__official/" title="Instagram" rel="noopener" target="_blank">
															<img class="lazyload" data-src="https://www.blazon.in/assets/images/menu/instagram.png" alt="Instagram">
														</a>
														<a href="https://www.linkedin.com/company/blazon-corp/" title="Linkedin" target="_blank" rel="noopener">
															<img class="lazyload" data-src="https://www.blazon.in/assets/images/menu/linkedin.png" alt="Linkedin">
														</a>
														<a href="https://twitter.com/BlazonAppDevCbe" title="Twitter" target="_blank" rel="noopener">
															<img class="lazyload" data-src="https://www.blazon.in/assets/images/menu/twitter.png" alt="Twitter">
														</a>
													</div>
												</div>
											</div>
										</ul>
									</li>
									<li>
										<a href="./our-products.php" title="Our Products">Our Products</a>
									</li>
									<li>
										<a href="./contact-us.php" title="Contact Us">Contact Us</a>
									</li>
								</ul>
							</div>
						</div>
						<div class="header_icon">
							<ul>
								<li>
									<a href="javascript:void(0)" title="Call Now" data-bs-toggle="modal" data-bs-target="#call_popup">
										<!-- <img src="https://www.blazon.in/assets/images/call.png" alt="Call Now"> -->
										<picture>
											<source srcset="https://www.blazon.in/assets/images/call.png" type="image/png">
											<source srcset="https://www.blazon.in/assets/images/call.webp" type="image/webp">
											<img data-src="https://www.blazon.in/assets/images/call.png" alt="Call Now" width="18" height="18" loading="lazy" decoding="async" class="lazyload">
										</picture>
									</a>
								</li>
								<li>
									<a href="javascript:void(0)" title="Mail Us" data-bs-toggle="modal" data-bs-target="#mail_popup">
										<!-- <img src="https://www.blazon.in/assets/images/mail.png" alt="Mail Us"> -->
										<picture>
											<source srcset="https://www.blazon.in/assets/images/mail.png" type="image/png">
											<source srcset="https://www.blazon.in/assets/images/mail.webp" type="image/webp">
											<img data-src="https://www.blazon.in/assets/images/mail.png" alt="Mail Us" width="18" height="18" loading="lazy" decoding="async" class="lazyload">
										</picture>
									</a>
								</li>
							</ul>

						</div>
						<div class="mob_menu">
							<div id="dl-menu" class="dl-menuwrapper">
								<div class="dl-trigger">
									<div class="m_outline"><span class="m_inline"></span></div>
								</div>
								<ul class="dl-menu">
									<li>
										<a href="./" title="Home">Home</a>
									</li>
									<li>
										<a href="javascript:void(0)" title="About Blazon">About Blazon</a>
										<ul class="dl-submenu">
											<li>
												<a href="./about-us.php" title="About Us">About Us</a>
											</li>
											<!-- <li>
                      <a href="./leadership.php" class="Leadership">Leadership</a>
                    </li>
                    <li>
                      <a href="./how-we-work-with-a-client.php" title="How we work with a client">How we work with a client</a>
                    </li> -->
											<li>
												<a href="./case-studies.php" title="Case Studies">Case Studies</a>
											</li>
										</ul>
									</li>
									<li>
										<a href="./expertise.php" title="Expertise">Expertise</a>
										<ul class="dl-submenu">
											<li>
												<a href="javascript:void(0)" title="Development Services">Development Services</a>
												<ul class="dl-submenu">
													<li><a href="./software-development.php" title="Web development">Software Development</a></li>
													<li><a href="./web-app-development.php" title="Web App Development">Web App Development</a></li>
													<li><a href="./mobile-app-development.php" title="Mobile App Development">Mobile App Development</a></li>
													<li><a href="./e-commerce-development.php" title="e-Commerce Development">e-Commerce Development</a></li>
													<li><a href="./web-portal-development.php" title="Web Portal Development">Web Portal Development</a></li>
													<li><a href="./software-migration-re-engineering.php" title="Software Migration & Re-engineering">Software Migration & Re-engineering</a></li>
													<li><a href="./software-support-and-maintenance.php" title="Software Support and Maintenance">Software Support and Maintenance</a></li>
													<li><a href="./software-application-qa-testing.php" title="Software Application & QA Testing">Software Application & QA Testing</a></li>
													<li><a href="./php-development.php" title="PHP Development">PHP Development</a></li>
													<li><a href="./react-development.php" title="React Development">React Development</a></li>
												</ul>
											</li>
											<li>
												<a href="javascript:void(0)" title="Design Services">Design Services</a>
												<ul class="dl-submenu">
													<li><a href="./logo-design.php" title="Logo Design">Logo Design</a></li>
													<li><a href="./print-design.php" title="Print Design">Print Design</a></li>
													<li><a href="./packaging-design.php" title="Packaging Design">Packaging Design</a></li>
													<li><a href="./ui-ux-design.php" title="UI/UX Design">UI/UX Design</a></li>
												</ul>
											</li>
											<li>
												<a href="javascript:void(0)" title="Digital Marketing">Digital Marketing</a>
												<ul class="dl-submenu">
													<li><a href="./search-engine-marketing.php" title="Search Engine Marketing">Search Engine Marketing</a></li>
													<li><a href="./search-engine-optimization.php" title="Search Engine Optimization">Search Engine Optimization</a></li>
													<li><a href="./social-media-marketing.php" title="Social Media Marketing">Social Media Marketing</a></li>
													<li><a href="./social-media-optimization.php" title="Social Media Optimization">Social Media Optimization</a></li>
													<li><a href="./email-marketing.php" title="eMail Marketing">eMail Marketing</a></li>


												</ul>
											</li>
											<li>
												<a href="javascript:void(0)" title="Web Services">Web Services</a>
												<ul class="dl-submenu">
													<li><a href="./domain-registration.php" title="Domain Registration">Domain Registration</a></li>
													<li><a href="./web-hosting.php" title="Web Hosting">Web Hosting</a></li>
													<li><a href="./web-maintenance.php" title="Web Maintenance">Web Maintenance</a></li>

												</ul>
											</li>
										</ul>
									</li>
									<li>
										<a href="./our-products.php" title="Our Products">Our Products</a>
									</li>
									<li>
										<a href="./contact-us.php" title="Contact Us">Contact Us</a>
									</li>
								</ul>
							</div>
						</div>
					</div>
				</div>
			</header>

			<!--header_section-->

			<!--Call Popup-->
			<div class="modal fade slow" id="call_popup" tabindex="-1" aria-labelledby="call_popup_label" aria-hidden="true">
				<div class="modal-dialog">
					<div class="modal-content">
						<div class="modal-header">
							<h2 class="modal-title fs-5" id="call_popup_label">Call Now</h2>
							<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
						</div>
						<div class="modal-body">
							<div class="call_popup_align">
								<div class="call_popup_box">
									<a href="tel:+919786699000" title="Call Now" onclick="gtag('event', 'click', {'event_category': 'Mobile +91 97866 99000', 'event_label': 'Phone Call India', 'value': 10});">
										<img class="lazyload" data-src="https://www.blazon.in/assets/images/contactus/india.png" alt="India">
										+91 97866 99000</a>
								</div>
								<div class="call_popup_box">
									<a href="tel:720500-3435" title="Call Now" onclick="gtag('event', 'click', {'event_category': 'Mobile (720) 500-3435', 'event_label': 'Phone Call USA', 'value': 10});">
										<img class="lazyload" data-src="https://www.blazon.in/assets/images/contactus/us.png" alt="US">
										(720) 500-3435</a>
								</div>
								<div class="call_popup_box">
									<a href="tel:+4915168619030" title="Call Now" onclick="gtag('event', 'click', {'event_category': 'Mobile 4915168619030', 'event_label': 'Phone Call Germany', 'value': 10});">
										<img class="lazyload" data-src="https://www.blazon.in/assets/images/contactus/germany.png" alt="Dubai">
										+4915168619030</a>
								</div>

							</div>
						</div>
					</div>
				</div>
			</div>


			<!--Mail Popup-->
			<div class="modal fade slow" id="mail_popup" tabindex="-1" aria-labelledby="mail_popup_label" aria-hidden="true">
				<div class="modal-dialog">
					<div class="modal-content">
						<div class="modal-header">
							<h2 class="modal-title fs-5" id="mail_popup_label">Email Us</h2>
							<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
						</div>
						<div class="modal-body">
							<div class="call_popup_align">
								<div class="call_popup_box">
									<a href="mailto:info@blazon.in" title="Mail to" onclick="gtag('event', 'click', {'event_category': 'Info mail', 'event_label': 'Send mail India', 'value': 10});">
										<img class="lazyload" data-src="https://www.blazon.in/assets/images/contactus/india.png" alt="India">
									</a>
								</div>
								<div class="call_popup_box">
									<a href="mailto:dp@blazon.in" title="Mail to" onclick="gtag('event', 'click', {'event_category': 'Info mail', 'event_label': 'Send mail USA', 'value': 10});">
										<img class="lazyload" data-src="https://www.blazon.in/assets/images/contactus/us.png" alt="US">
									</a>
								</div>
								<div class="call_popup_box">
									<a href="mailto:mb@blazon.in" title="Mail to" onclick="gtag('event', 'click', {'event_category': 'Info mail', 'event_label': 'Send mail Germany', 'value': 10});">
										<img class="lazyload" data-src="https://www.blazon.in/assets/images/contactus/dubai.png" alt="Germany">
									</a>
								</div>

							</div>
						</div>
					</div>
				</div>
			</div>
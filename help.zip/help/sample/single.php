<?php
/**
 * The template for displaying all single posts and attachments
 *
 * @package WordPress
 * @subpackage Twenty_Fifteen
 * @since Twenty Fifteen 1.0
 */

get_header(); 

if(is_home() || is_front_page()){$url = get_site_url();}else{$url = home_url( $wp->request )."/";}

?>

<!--banner_section-->



<div class="banner_section">
	<div class="banner_desk_mob">
		<div class="banner_items">
			<img src="https://www.orisdentalcenter.ae/blog/wp-content/uploads/2021/11/blog_banner.jpg" alt="Our Blog" class="lazyload desk_banner">
		</div>
		
	</div>
</div>



<!--banner_section-->


<!--breadcrumb_section-->

<div class="breadcrumb_section">
	<div class="wrap_grid">
		<ul itemscope itemtype="http://schema.org/BreadcrumbList">
            <li itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem"><a itemprop="item" href="http://www.orisdentalcenter.ae" title="Home"><span itemprop="name">Home</span></a><meta itemprop="position" content="1"></li>

					<li itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem"><a itemprop="item" href="<?php echo get_home_url();?>" title="Blog"><span itemprop="name">Blog</span></a><meta itemprop="position" content="2"></li>                                  
					<?php if(is_single() && have_posts()):?>
					<li itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem"><a itemprop="item" href="<?php echo $url;?>" title="<?php the_title(); ?>"><span itemprop="name"><?php the_title(); ?></span></a><meta itemprop="position" content="3"></li>
					 <?php 	
						elseif(is_category()&& have_posts()):
						$category = get_the_category(); 
					 ?>
					<li itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem"><a itemprop="item" href="<?php echo $$url;?>" title="<?php echo $category[0]->name;?>"><span itemprop="name"><?php echo $category[0]->name;?></span></a><meta itemprop="position" content="3"></li>
					 <?php 	endif; ?>
		</ul>
	</div>
</div>

<!--breadcrumb_section-->


<div class="blog_section blog_single">
   <div class="wrap_grid">
      <div class="blog_section_top">
	  <div class="blog_section_top_left">

                
                <div class="blogdate">
                                
                 <h1><?php the_title();?></h1>

     			 <div class="post-date">
					<span></span>
					<?php the_time('F d,Y'); ?>
				</div>
				
				
				
					</div>
					
					
					<?php if ( has_post_thumbnail() ) { ?>
	
					<a href="<?php the_permalink() ?>" title="<?php the_title() ?>">
             
             			<?php the_post_thumbnail('medium_large');?> 
							
					</a>
					
					<?php }?>
					
				
					
					
					

		<?php
		// Start the loop.
		while ( have_posts() ) : the_post();

			/*
			 * Include the post format-specific template for the content. If you want to
			 * use this in a child theme, then include a file called called content-___.php
			 * (where ___ is the post format) and that will be used instead.
			 */
			the_content();
			
			?>
           
           <a href="http://www.orisdentalcenter.ae/book-an-appointment.html" class="appt" title="Book an Appointment"><button>Book an Appointment</button></a>
           
           					<?php 

				 $catname = "";
				foreach((get_the_category()) as $category){
					$category_link = get_category_link( $category->cat_ID );
					$catname .=  '<a href="'.esc_url( $category_link ).'" title="'.$category->name.'">'.$category->name.'</a> / ';
					}
				
				$catname = trim($catname);

				?>
				<?php if($catname!=""){?>	
				 <div class="post-cat">
					 <span></span>
				 	<?php echo substr($catname,0,-1);?>
     			 </div>
     			 <?php } ?>

            
            <?php

			// If comments are open or we have at least one comment, load up the comment template.
			if ( comments_open() || get_comments_number() ) :
				comments_template();
			endif;

			// Previous/next post navigation.
			setPostViews(get_the_ID());

		// End the loop.
		endwhile;
		?>
                
                    
    <?php the_posts_pagination( array(

								'mid_size' => 2,

								'prev_text' => __( 'Previous', 'textdomain' ),

								'next_text' => __( 'Next', 'textdomain' ),

							) ); ?>

		<?php wp_reset_postdata(); ?>

<?php //comment_form(); ?> 

</div>
<div class="blog_section_top_right">
<?php $uploaddir = wp_upload_dir('2018/12');include('includes/sidebar.php');?>

</div>

</div> 

</div>
</div>

<?php get_footer(); ?>

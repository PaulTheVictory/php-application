<?php 

get_header();

if(is_home() || is_front_page()){$url = get_site_url();}else{$url = home_url( $wp->request )."/";}

?>



  <!--banner_section-->



<div class="banner_section">
	<div class="banner_desk_mob">
		<div class="banner_items">
			<img src="https://www.orisdentalcenter.ae/blog/wp-content/uploads/2021/11/blog_banner.jpg" alt="Our Blog" class="lazyload desk_banner">
		</div>
		
	</div>
</div>



<!--banner_section-->


<!--breadcrumb_section-->

<div class="breadcrumb_section">
	<div class="wrap_grid">
		<ul itemscope itemtype="http://schema.org/BreadcrumbList">
            <li itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem"><a itemprop="item" href="http://www.orisdentalcenter.ae" title="Home"><span itemprop="name">Home</span></a><meta itemprop="position" content="1"></li>

					<li itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem"><a itemprop="item" href="<?php echo get_home_url();?>" title="Blog"><span itemprop="name">Blog</span></a><meta itemprop="position" content="2"></li>                                  
					<?php if(is_single() && have_posts()):?>
					<li itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem"><a itemprop="item" href="<?php echo $url;?>" title="<?php the_title(); ?>"><span itemprop="name"><?php the_title(); ?></span></a><meta itemprop="position" content="3"></li>
					 <?php 	
						elseif(is_category()&& have_posts()):
						$category = get_the_category(); 
					 ?>
					<li itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem"><a itemprop="item" href="<?php echo $$url;?>" title="<?php echo $category[0]->name;?>"><span itemprop="name"><?php echo $category[0]->name;?></span></a><meta itemprop="position" content="3"></li>
					 <?php 	endif; ?>
		</ul>
	</div>
</div>

<!--breadcrumb_section-->
<div class="blog_section">
   <div class="wrap_grid">
    <h1><?php single_cat_title( '', true ); ?></h1>
      <div class="blog_section_top">
	  <div class="blog_section_top_left">
	<article>


<?php  
		
		$uploaddir = wp_upload_dir('2018/12');

		/*$page_object = get_queried_object(); 


		$temp = $wp_query; $wp_query= null;


		$wp_query = new WP_Query(); $wp_query->query('category_name='.$page_object->cat_name.'&showposts=10' . '&paged='.$paged);*/


		if (have_posts() && strlen( trim(get_search_query()) ) != 0) : while (have_posts()) : the_post()
		
		?>

            
             <a href="<?php the_permalink() ?>" title="<?php the_title() ?>">
             
             <?php if ( has_post_thumbnail() ) {the_post_thumbnail('medium_large');}else{?> 
								
					<img src="<?php echo $uploaddir['url'];?>/oris-blog-1-768x402.jpg" alt="Oris Blog" />		
									
				<?php } ?>
			            
			<div class="blogdate">
          
           		<h2><?php the_title(); ?></h2>
           		
           		<div class="clear"></div>
           		
				<div class="post-date">
					<span></span>
					<?php the_time('F d,Y'); ?>
				</div>
          		<!--|
          		<div class="post-comment">
          			<span></span>
					<?php //echo get_comments_number(); ?>
				</div>-->
           
            </div>
               
            <div class="post-desc">               
             
				<p> <?php echo substr(wp_strip_all_tags(get_the_excerpt(''),true),0,130);?>...<a href="<?php the_permalink() ?>" title="<?php the_title() ?>"><span><font style="font-size:15px;color:#017dad;text-decoration:none;font-weight:bold">Read more</font></span></a></p>
            
				<?php 

				 $catname = "";
				foreach((get_the_category()) as $category){
					$category_link = get_category_link( $category->cat_ID );
					$catname .=  '<a href="'.esc_url( $category_link ).'" title="'.$category->name.'">'.$category->name.'</a> / ';
					}
				
				$catname = trim($catname);

				?>
				<?php if($catname!=""){?>	
				 <div class="post-cat">
					 <span></span>
				 	<?php echo substr($catname,0,-1);?>
     			 </div>
     			 <?php } ?>
     			 
			</div>
      
      </a>
      
      <hr>
       

		<?php endwhile; ?>


		
<?php
the_posts_pagination( array(
	'mid_size'  => 2,
	'prev_text' => __( 'Previous', 'textdomain' ),
	'next_text' => __( 'Next', 'textdomain' ),
) );
?>

		<?php wp_reset_postdata(); ?>



    <?php else : ?>

            <h1 class="search-title">No results Found</h1>
               <p class="search-text">
                  It seems we can’t find what you’re looking for.
                  Perhaps you should try again with a different search term.
               </p>
               
         <?php endif; ?>


	</article>


    </div>    

<div class="blog_section_top_right">
    <?php include('includes/sidebar.php');?>
</div>
    

 </div>
</div>
</div>

<?php 

get_footer();

?>
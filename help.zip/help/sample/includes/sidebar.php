<div class="sidebar">
<div class="widget-search">
<?php dynamic_sidebar('sidebar1'); ?>
</div>	

<div class="widget-popular"> 

<h2 class="widgettitle">Popular Posts</h2>
<?php //dynamic_sidebar('sidebar2'); ?>

	<?php
      query_posts('meta_key=post_views_count&posts_per_page=2&orderby=meta_value_num&order=DESC');
	
	$i=1;
      if (have_posts()) : while (have_posts()) : the_post();
	  $url = get_the_post_thumbnail_url( $page->ID, 'full' );
   ?>
    
     <a href="<?php the_permalink() ?>" title="<?php the_title() ?>">
	 
	 <?php if($url) { ?>
					
					<img src="<?php echo $url;?>" alt="<?php the_title() ?>" />
					
					<?php } else { ?> 
								
					<img src="<?php echo $uploaddir['url'];?>/oris-blog-1-768x402.jpg" alt="Oris Blog" />	
									
				<?php } ?>
			            
			<div class="blogdate">
          
           		<?php if(is_home()):?><h2><?php the_title(); ?></h2><?php endif;?>
           		
           		<div class="clear"></div>
           		
				<div class="post-date">
					<span></span>
					<?php the_time('F d,Y'); ?>
				</div>
          		<!--|
          		<div class="post-comment">
          			<span></span>
					<?php //echo get_comments_number(); ?>
				</div>-->
           
            </div>
            
	</a>
           
          <?php if($i<2){?> <hr><?php }?>
            
   <?php
	$i++;
   endwhile; endif;
   wp_reset_query();
   ?>

</div>
<!--<div class="widget-categories"> 
<?php //dynamic_sidebar('sidebar2'); ?>
</div>
<div class="widget-recent">
<?php //dynamic_sidebar('sidebar3'); ?>
</div>-->

</div>
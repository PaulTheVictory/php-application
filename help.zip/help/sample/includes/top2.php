<link href='https://fonts.googleapis.com/css?family=Roboto:400,500,700' rel='stylesheet' type='text/css'>
<link href='https://fonts.googleapis.com/css?family=Roboto+Slab:400,700' rel='stylesheet' type='text/css'>

<link rel="stylesheet" type="text/css" href="css/styles2.css" />
<link rel="stylesheet" type="text/css" href="css/styles-media2.css" />
<link rel="stylesheet" type="text/css" href="css/menu.css" />
<link rel="stylesheet" type="text/css" href="css/mobilemenu.css" />
<link href="css/owl.carousel.css" rel="stylesheet" type="text/css" />
<link href="css/owl.theme.css" rel="stylesheet" type="text/css" />
<link href="css/responsive-tabs.css" rel="stylesheet" type="text/css" />

<script type="text/javascript" src="js/jquery.js"></script>
<script src="js/main.js" type="text/javascript"></script>
<script src="js/menu.js" type="text/javascript"></script>
<script src="js/bgslideshow.js" type="text/javascript"></script>
<script src="js/jquery.responsiveTabs.min.js" type="text/javascript"></script>
<script src="js/modernizr.custom.js" type="text/javascript"></script>


<script>
ddsmoothmenu.init({
mainmenuid: "menu", //menu DIV id
orientation: 'h', //Horizontal or vertical menu: Set to "h" or "v"
classname: 'headermenu', //class added to menu's outer DIV
customtheme: ["#ffffff", "#004080"],
contentsource: "markup" //"markup" or ["container_id", "path_to_menu_file"]
}); 
</script>

</head>

<body>
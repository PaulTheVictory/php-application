<ul class="dl-menu">

    <li><a href="http://www.orisdentalcenter.ae/index.html" title="Home">Home</a></li>



    <li><a href="javascript:void(0)" title="About us">About Us</a>

        <ul class="dl-submenu">

            <li><a href="http://www.orisdentalcenter.ae/aboutus.html" title="About Oris">About Oris</a></li>						
                            
            <li><a href="http://www.orisdentalcenter.ae/our-team.html" title="Our Team">Our Team</a></li>

        </ul>


    </li>



    <li><a href="javascript:void(0)">Services</a>

        <ul class="dl-submenu">

            <li><a href="http://www.orisdentalcenter.ae/general-dentistry.html" title="General Dentistry">General Dentistry</a></li>

            <li><a href="javascript:void(0)" title="Oral Surgery">Oral Surgery</a>

                <ul class="dl-submenu">

                    <li><a href="javascript:void(0)" title="Tooth Extraction">Tooth Extraction</a>


                        <ul class="dl-submenu">

                            <li><a href="http://www.orisdentalcenter.ae/wisdom-tooth-extraction.html" title="Wisdom Tooth Extraction">Wisdom Tooth Extraction</a></li>						
                            
                            <li><a href="http://www.orisdentalcenter.ae/surgical-tooth-extraction.html" title="Surgical Tooth Extraction">Surgical Tooth Extraction</a></li>
                        
                        </ul>

                    </li>

                    <li><a href="http://www.orisdentalcenter.ae/sinus-lift.html" title="Sinus Lift">Sinus Lift</a></li>
                            
                    <li><a href="http://www.orisdentalcenter.ae/socket-preservation.html" title="Socket preservation">Socket preservation</a></li>

					<li><a href="http://www.orisdentalcenter.ae/bone-grafting.html" title="Bone grafting">Bone grafting</a></li>

                </ul>

            </li>
            
    		<li><a href="http://www.orisdentalcenter.ae/dental-hygiene.html" title="Dental Hygiene">Dental Hygiene</a></li>

            <li><a href="http://www.orisdentalcenter.ae/orthodontics.html" title="Orthodontics">Orthodontics</a></li>

			<li><a href="http://www.orisdentalcenter.ae/paedodontics.html" title="Paedodontics">Paedodontics</a></li>

            <li><a href="http://www.orisdentalcenter.ae/cosmetic-dentistry.html" title="Cosmetic Dentistry">Cosmetic Dentistry</a>

                <ul class="dl-submenu">

                    <li><a href="http://www.orisdentalcenter.ae/veneers.html" title="Veneers">Veneers</a></li>

					<li><a href="http://www.orisdentalcenter.ae/teeth-whitening.html" title="Teeth whitening">Teeth whitening</a></li>

					<li><a href="http://www.orisdentalcenter.ae/gum-whitening.html" title="Gum whitening">Gum whitening</a></li>

					<li><a href="http://www.orisdentalcenter.ae/dental-jewellery.html" title="Dental Jewellery">Dental Jewellery</a></li>

					<li><a href="http://www.orisdentalcenter.ae/hollywood-smile.html" title="Hollywood smile">Hollywood smile</a></li>

                </ul>

            </li>

            <li><a href="http://www.orisdentalcenter.ae/dental-implants.html" title="Dental Implants">Dental Implants</a></li>
            
            <li><a href="http://www.orisdentalcenter.ae/single-day-implants.html" title="Single Day Implants</a></li>
            ">Single Day Implants</a></li>
            
            <li><a href="http://www.orisdentalcenter.ae/katana-zirconia-crowns.html" title="Katana Zirconia crown">Katana Zirconia crown</a></li>

			<li><a href="http://www.orisdentalcenter.ae/endodontics.html" title="Endodontics">Endodontics</a></li>

			<li><a href="http://www.orisdentalcenter.ae/inlay-onlay.html" title="Inlay and Onlay">Inlay and Onlay</a></li>

            <li><a href="http://www.orisdentalcenter.ae/full-ceramic-crown.html" title="Full Ceramic Crown">Full Ceramic Crown</a></li>

            <li><a href="http://www.orisdentalcenter.ae/dental-bridges.html" title="Dental Bridges">Dental Bridges</a></li>
            
            <li><a href="http://www.orisdentalcenter.ae/teeth-replacement.html" title="Teeth Replacement">Teeth Replacement</a></li>
                
            <li><a href="http://www.orisdentalcenter.ae/mouth-rehabilitation.html" title="Mouth Rehabilitation">Mouth Rehabilitation</a></li>


        </ul>

    </li>




    <li><a href="http://www.orisdentalcenter.ae/smile-gallery.html" title="Smile Gallery">Gallery</a>
    
    	 <ul class="dl-submenu">

				<li><a href="http://www.orisdentalcenter.ae/veneers-gallery.html" title="Veneers Gallery">Veneers Gallery</a></li>
                
                <li><a href="http://www.orisdentalcenter.ae/implant-gallery.html" title="Implant Gallery">Implant Gallery</a></li>
                
                <li><a href="#" title="Teeth Whitening">Teeth Whitening</a></li>
                
                <li><a href="#" title="Inlay / Onlay">Inlay / Onlay</a></li>

							
		</ul>
                        
    </li>


    <li><a href="http://www.orisdentalcenter.ae/monthly-offers.html" title="Offers">Offers</a></li>
                    
     <li><a href="http://www.orisdentalcenter.ae/medical-insurance.html" title="Insurance">Insurance</a></li>
                     
     <li><a href="http://www.orisdentalcenter.ae/medical-tourism.html" title="Medical Tourism">Medical Tourism</a></li>
                                         
    <li><a href="https://www.orisdentalcenter.ae/smile-gallery.html" title="Smile Gallery">Media</a>
                    
		<ul class="dl-submenu">

			<li><a href="https://www.orisdentalcenter.ae/newsroom.html" title="Newsroom">Newsroom</a></li>
			<li><a href="https://www.orisdentalcenter.ae/videos.html" title="Videos / Interviews">Videos / Interviews</a></li>
			<li><a href="https://www.orisdentalcenter.ae/online.html" title="Online">Online</a></li>

		</ul>
                        
    </li>
    
    <li><a href="http://www.orisdentalcenter.ae/blog/" title="Dental Blog">Blog</a></li>

    <li><a href="http://www.orisdentalcenter.ae/contact-us.html" title="Contact us">Contact</a>
	
				  <ul class="dl-submenu">

					<li><a href="http://www.orisdentalcenter.ae/contact-jumeirah.html" title="Contact Jumeirah">Jumeirah</a></li>

					<li><a href="http://www.orisdentalcenter.ae/contact-mirdif.html" title="Contact Mirdif">Mirdif</a></li>

				 </ul>
	</li>
	
	

</ul>
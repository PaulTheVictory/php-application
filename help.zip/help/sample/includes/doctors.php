<div class="item" itemscope="" itemtype="https://schema.org/Dentist">
  
   <img src="images/hussain-al-saleh.png"/>
        <span style="display:none" itemprop="url" href="http://www.orisdentalcenter.ae/dr-hussain-al-saleh.html"></span>
		
	
    <a itemprop="url">
            <h2 itemprop="name">
			<link itemprop="photo" href="http://www.orisdentalcenter.ae/images/hussain-al-saleh.png">
            
	<h5 itemprop="name">Dr. Hussain Al Saleh</h5>
	<a itemprop="url" href="http://www.orisdentalcenter.ae/dr-hussain-al-saleh.html" ></a>
    <h6>Founder & Owner</h6>
	
    <p itemprop="branchOf" itemscope itemtype="https://schema.org/MedicalOrganization"><a href="dr-hussain-al-saleh.html"><span>View Profile</span></a>
    <a itemprop="url" href="http://www.orisdentalcenter.ae/contact-jumeirah.html" ></a>
	
	 <span itemprop="name" style="display:none">
      Oris Dental Center
     </span>
	</p>
		  
    <p  itemprop="address" itemscope itemtype="https://schema.org/PostalAddress">   
	<a itemprop="url" href="http://www.orisdentalcenter.ae/contact-jumeirah.html"></a> 
	<span itemprop="addressLocality" style="display:none">Umm Sequeim 3, Jumeirah Rd Opposite Burj Al Arab, Villa #1 855 A </span> <span itemprop="addressRegion" style="display:none">dubai</span>                                                                        
    </p>                            
                    
        <span itemprop="geo" style="display:none" itemscope="" itemtype="http://schema.org/GeoCoordinates">
                        
            <meta itemprop="latitude" content="25.219616">
            <meta itemprop="longitude" content="55.419475">
        </span>
  </div>
    
<!--First End-->
	
	<div class="item" itemscope="" itemtype="https://schema.org/Dentist">
  
   <img src="images/farza-al-awadhi.png"/>
        <span style="display:none" itemprop="url" href="http://www.orisdentalcenter.ae/dr-farzad-al-awadhi.html"></span>
		
	
    <a itemprop="url">
            <h2 itemprop="name">
			<link itemprop="photo" href="http://www.orisdentalcenter.ae/images/farza-al-awadhi.png">
            
	<h5 itemprop="name">Dr.Farzad Al Awadhi</h5>
	<a itemprop="url" href="http://www.orisdentalcenter.ae/dr-farzad-al-awadhi.html" ></a>
    <h6>Medical Director - Mirdif</h6>
	
    <p itemprop="branchOf" itemscope itemtype="https://schema.org/MedicalOrganization"><a href="dr-farzad-al-awadhi.html"><span>View Profile</span></a>
    <a itemprop="url" href="http://www.orisdentalcenter.ae/contact-mirdif.html" ></a>
	
	 <span itemprop="name" style="display:none">
      Oris Dental Center
     </span>
	</p>
		  
    <p  itemprop="address" itemscope itemtype="https://schema.org/PostalAddress">   
	<a itemprop="url" href="http://www.orisdentalcenter.ae/contact-mirdif.html"></a> 
	<span itemprop="addressLocality" style="display:none">Street #47, Algeria Street, Uptown Mirdif, Al Barajeel Complex </span> <span itemprop="addressRegion" style="display:none">dubai</span>                                                                        
    </p>                            
                    
                       <span itemprop="geo" style="display:none" itemscope="" itemtype="http://schema.org/GeoCoordinates">
                        
            <meta itemprop="latitude" content="25.204849">
            <meta itemprop="longitude" content="55.270783">
        </span>
  </div>
  
  <!--second end -->

  <!--three start-->

  <div class="item" itemscope="" itemtype="https://schema.org/Dentist">
  
   <img src="images/mahra-al-mutawa.png"/>
        <span style="display:none" itemprop="url" href="http://www.orisdentalcenter.ae/dr-hussain-al-saleh.html"></span>
		
	
    <a itemprop="url">
            <h2 itemprop="name">
			<link itemprop="photo" href="http://www.orisdentalcenter.ae/images/mahra-al-mutawa.png">
            
	<h5 itemprop="name">Dr. Mahra al mutawa</h5>
	<a itemprop="url" href="http://www.orisdentalcenter.ae/dr-mahra-al-mutawa.html" ></a>
    <h6>Medical Director - Jumeirah</h6>
	
    <p itemprop="branchOf" itemscope itemtype="https://schema.org/MedicalOrganization"><a href="dr-mahra-al-mutawa.html"><span>View Profile</span></a>
    <a itemprop="url" href="http://www.orisdentalcenter.ae/dr-mahra-al-mutawa.html"></a>
	
	 <span itemprop="name" style="display:none">
      Oris Dental Center
     </span>
	</p>
		  
    <p  itemprop="address" itemscope itemtype="https://schema.org/PostalAddress">   
	<a itemprop="url" href="http://www.orisdentalcenter.ae/contact-jumeirah.html"></a> 
	<span itemprop="addressLocality" style="display:none">Umm Sequeim 3, Jumeirah Rd Opposite Burj Al Arab, Villa #1 855 A </span> <span itemprop="addressRegion" style="display:none">dubai</span>                                                                        
    </p>                            
                    
                       <span itemprop="geo" style="display:none" itemscope="" itemtype="http://schema.org/GeoCoordinates">
                        
            <meta itemprop="latitude" content="25.219616">
            <meta itemprop="longitude" content="55.419475">
        </span>
  </div>
  
<!--three end -->

<!-- four-->
<!-- 
<div class="item" itemscope="" itemtype="https://schema.org/Dentist">
  
   <img src="images/ahmad-al-jizawi.png"/>
        <span style="display:none" itemprop="url" href="http://www.orisdentalcenter.ae/dr-ahmad-al-jizawi.html"></span>
		
	
    <a itemprop="url">
            <h2 itemprop="name">
			<link itemprop="photo" href="http://www.orisdentalcenter.ae/images/ahmad-al-jizawi.png">
            
	<h5 itemprop="name">Dr. Ahmad Al Jizawi</h5>
	<a itemprop="url" href="http://www.orisdentalcenter.ae/dr-ahmad-al-jizawi.html" ></a>
   
	
    <p itemprop="branchOf" itemscope itemtype="https://schema.org/MedicalOrganization"><a href="dr-ahmad-al-jizawi.html"><span>View Profile</span></a>
    <a itemprop="url" href="http://www.orisdentalcenter.ae/dr-ahmad-al-jizawi.html" ></a>
	
	 <span itemprop="name" style="display:none">
      Oris Dental Center
     </span>
	</p>
		  
    <p  itemprop="address" itemscope itemtype="https://schema.org/PostalAddress">   
	<a itemprop="url" href="http://www.orisdentalcenter.ae/contact-jumeirah.html"></a> 
	<span itemprop="addressLocality" style="display:none">Umm Sequeim 3, Jumeirah Rd Opposite Burj Al Arab, Villa #1 855 A </span> <span itemprop="addressRegion" style="display:none">dubai</span>                                                                        
    </p>                            
                    
                       <span itemprop="geo" style="display:none" itemscope="" itemtype="http://schema.org/GeoCoordinates">
                        
            <meta itemprop="latitude" content="25.219616">
            <meta itemprop="longitude" content="55.419475">
        </span>
  </div> -->
  
<!-- fOUR END-->

<!--FIVE START-->

<div class="item" itemscope="" itemtype="https://schema.org/Dentist">
  
   <img src="images/mirjam-escorche.png"/>
        <span style="display:none" itemprop="url" href="http://www.orisdentalcenter.ae/dr-mirjam-escorche.html"></span>
		
	
    <a itemprop="url">
            <h2 itemprop="name">
			<link itemprop="photo" href="http://www.orisdentalcenter.ae/images/mirjam-escorche.png">
            
	<h5 itemprop="name">Dr.Mirjam Escorche</h5>
	<a itemprop="url" href="http://www.orisdentalcenter.ae/dr-mirjam-escorche.html" ></a>
   
	
    <p itemprop="branchOf" itemscope itemtype="https://schema.org/MedicalOrganization"><a href="dr-mirjam-escorche.html"><span>View Profile</span></a>
    <a itemprop="url" href="http://www.orisdentalcenter.ae/dr-mirjam-escorche.html"></a>
	
	 <span itemprop="name" style="display:none">
      Oris Dental Center
     </span>
	</p>
		  
    <p  itemprop="address" itemscope itemtype="https://schema.org/PostalAddress">   
	<a itemprop="url" href="http://www.orisdentalcenter.ae/contact-jumeirah.html"></a> 
	<span itemprop="addressLocality" style="display:none">Umm Sequeim 3, Jumeirah Rd Opposite Burj Al Arab, Villa #1 855 A </span> <span itemprop="addressRegion" style="display:none">dubai</span>                                                                        
    </p>                            
                    
      <span itemprop="geo" style="display:none" itemscope="" itemtype="http://schema.org/GeoCoordinates">
                        
            <meta itemprop="latitude" content="25.219616">
            <meta itemprop="longitude" content="55.419475">
        </span>
  </div>
  
<!--FIVE END-->

<!--six start-->

<div class="item" itemscope="" itemtype="https://schema.org/Dentist">
  
   <img src="images/leen-al-bounni.png"/>
        <span style="display:none" itemprop="url" href="http://www.orisdentalcenter.ae/dr-leen-al-bounni.html"></span>
		
	
    <a itemprop="url">
            <h2 itemprop="name">
			<link itemprop="photo" href="http://www.orisdentalcenter.ae/images/leen-al-bounni.png">
            
	<h5 itemprop="name">Dr. Leen al bounni</h5>
	<a itemprop="url" href="http://www.orisdentalcenter.ae/dr-leen-al-bounni.html" ></a>
   
	
    <p itemprop="branchOf" itemscope itemtype="https://schema.org/MedicalOrganization"><a href="dr-leen-al-bounni.html"><span>View Profile</span></a>
    <a itemprop="url" href="http://www.orisdentalcenter.ae/dr-leen-al-bounni.html"></a>
	
	 <span itemprop="name" style="display:none">
      Oris Dental Center
     </span>
	</p>
		  
    <p  itemprop="address" itemscope itemtype="https://schema.org/PostalAddress">   
	<a itemprop="url" href="http://www.orisdentalcenter.ae/contact-jumeirah.html"></a> 
	<span itemprop="addressLocality" style="display:none">Umm Sequeim 3, Jumeirah Rd Opposite Burj Al Arab, Villa #1 855 A </span> <span itemprop="addressRegion" style="display:none">dubai</span>                                                                        
    </p>                            
                    
                       <span itemprop="geo" style="display:none" itemscope="" itemtype="http://schema.org/GeoCoordinates">
                        
            <meta itemprop="latitude" content="25.219616">
            <meta itemprop="longitude" content="55.419475">
        </span>
  </div>

<!-- six end-->

<!--seven start-->
<div class="item" itemscope="" itemtype="https://schema.org/Dentist">
  
   <img src="images/george-dominic-adrian.png"/>
        <span style="display:none" itemprop="url" href="http://www.orisdentalcenter.ae/dr-george-dominic-adrian.html"></span>
		
	
    <a itemprop="url">
            <h2 itemprop="name">
			<link itemprop="photo" href="http://www.orisdentalcenter.ae/images/george-dominic-adrian.png">
            
	<h5 itemprop="name">Dr. George Dominic Adrian</h5>
	<a itemprop="url" href="http://www.orisdentalcenter.ae/dr-george-dominic-adrian.html" ></a>
   
	
    <p itemprop="branchOf" itemscope itemtype="https://schema.org/MedicalOrganization"><a href="dr-george-dominic-adrian.html"><span>View Profile</span></a>
    <a itemprop="url" href="http://www.orisdentalcenter.ae/dr-george-dominic-adrian.html"></a>
	
	 <span itemprop="name" style="display:none">
      Oris Dental Center
     </span>
	</p>
		  
    <p  itemprop="address" itemscope itemtype="https://schema.org/PostalAddress">   
	<a itemprop="url" href="http://www.orisdentalcenter.ae/contact-jumeirah.html"></a> 
	<span itemprop="addressLocality" style="display:none">Umm Sequeim 3, Jumeirah Rd Opposite Burj Al Arab, Villa #1 855 A </span> <span itemprop="addressRegion" style="display:none">dubai</span>                                                                        
    </p>                            
                    
                       <span itemprop="geo" style="display:none" itemscope="" itemtype="http://schema.org/GeoCoordinates">
                        
            <meta itemprop="latitude" content="25.219616">
            <meta itemprop="longitude" content="55.419475">
        </span>
  </div>
  
<!--seven end

<div class="item" itemscope="" itemtype="https://schema.org/Dentist">
  
   <img src="images/fetna-al-mutawa.png"/>
        <span style="display:none" itemprop="url" href="http://www.orisdentalcenter.ae/dr-fetna-al-mutawa.html"></span>
		
	
    <a itemprop="url">
            <h2 itemprop="name">
			<link itemprop="photo" href="http://www.orisdentalcenter.ae/images/fetna-al-mutawa.png">
            
	<h5 itemprop="name">Dr. Fetna Al Mutawa</h5>
	<a itemprop="url" href="http://www.orisdentalcenter.ae/dr-fetna-al-mutawa.html" ></a>
   
	 <h6>Orthodontics</h6>
    <p itemprop="branchOf" itemscope itemtype="https://schema.org/MedicalOrganization"><a href="dr-fetna-al-mutawa.html"><span>View Profile</span></a>
    <a itemprop="url" href="http://www.orisdentalcenter.ae/dr-fetna-al-mutawa.html"></a>
	
	 <span itemprop="name" style="display:none">
      Oris Dental Center
     </span>
	</p>
		  
    <p  itemprop="address" itemscope itemtype="https://schema.org/PostalAddress">   
	<a itemprop="url" href="http://www.orisdentalcenter.ae/contact-jumeirah.html"></a> 
	<span itemprop="addressLocality" style="display:none">Umm Sequeim 3, Jumeirah Rd Opposite Burj Al Arab, Villa #1 855 A </span> <span itemprop="addressRegion" style="display:none">dubai</span>                                                                        
    </p>                            
                    
                       <span itemprop="geo" style="display:none" itemscope="" itemtype="http://schema.org/GeoCoordinates">
                        
            <meta itemprop="latitude" content="25.219616">
            <meta itemprop="longitude" content="55.419475">
        </span>
  </div> -->
  
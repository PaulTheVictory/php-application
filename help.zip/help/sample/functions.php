<?php


add_theme_support( 'post-thumbnails' );

function wpforo_search_form( $html ) {

        $html = str_replace( 'name="s"', 'name="s" placeholder="Search"', $html );
		$html = str_replace( 'value="Search"', 'value=""', $html );

        return $html;
}
add_filter( 'get_search_form', 'wpforo_search_form' );

function anbarsanstyle()
	{
    	wp_enqueue_style('style',get_stylesheet_uri());
    }
    add_action('wp_enqueue_scripts','anbarsanstyle');
	
	
	register_nav_menus( array (
	
							'primary' => __('PRIMARY MENU'),
							
					 ));
					 
					 
function anbuwidgetInit() {

	
	register_sidebar( array(
	
	'name' => 'Search',
	'id'   =>  'sidebar1',
	
	
	));
	
	
	register_sidebar( array(
	
	'name' => 'Recent Posts',
	'id'   =>  'sidebar2',
	
	
	));
	
	register_sidebar( array(
	
	'name' => 'Categories',
	'id'   =>  'sidebar3',
	
	
	));
	
	
}
add_action( 'widgets_init', 'anbuwidgetInit' );

function new_excerpt_more($more) {
       global $post;
	return '<a class="moretag" href="'. get_permalink($post->ID) . '"> <span style="float:right"><font style="font-size:12px;color:#0b5a85;text-decoration:none;font-weight:bold">(more)</font></span></a>';
}
add_filter('excerpt_more', 'new_excerpt_more');

/*
 * Set post views count using post meta
 */
function setPostViews($postID) {
    $countKey = 'post_views_count';
    $count = get_post_meta($postID, $countKey, true);
    if($count==''){
        $count = 0;
        delete_post_meta($postID, $countKey);
        add_post_meta($postID, $countKey, '0');
    }else{
        $count++;
        update_post_meta($postID, $countKey, $count);
    }
}

?>
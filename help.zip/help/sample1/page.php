<?php



get_header(); ?>




<?php
$meta = get_post_meta(get_the_ID(), '', true);
$innerdb = $meta['desktop-image'][0];
$innermb = $meta['mobile-image'][0];
$bannertext = $meta['banner-text'][0];
$bannertext1 = $meta['banner-text1'][0];
$bannerbutton = $meta['banner-button'][0];
$bannerlink = $meta['banner-link'][0];

if ($innerdb != "") {
	$innerdb = get_site_url() . '/' . $innerdb;
} else {
	$innerdb =  esc_url(get_template_directory_uri()) . '/images/banners/home.png';
}

if ($innermb != "") {
	$innermb = get_site_url() . '/' . $innermb;
} else {
	$innermb =  esc_url(get_template_directory_uri()) . '/images/banners/mobile.png';
}
?>

<!--slider_section-->

<?php if (get_the_title() != "Cart" && get_the_title() != "Newsletter") { ?>
	<?php if (get_the_title() != "Checkout") { ?>
		<?php if (get_the_title() != "My account") { ?>

			<div class="slide_section">
				<div id="bootstrap-touch-slider" class="carousel bs-slider slide control-round indicators-line" data-ride="carousel" data-pause="hover" data-interval="5000">
					<div class="carousel-inner" role="listbox">
						<div class="item active">
							<img class="desk_banner" data-animation="animated fadeInRight" src="<?php echo $innerdb; ?>" alt="banner">
							<img class="mob_banner" data-animation="animated fadeInRight" src="<?php echo $innermb; ?>" alt="banner">
							<div class="wrap_grid">
								<div class="slide-text slide_style_left">
									<div class="slide_text_left">
										<?php if ($bannertext != "") { ?><h2 data-animation="animated fadeInLeft"><span><?php echo $bannertext; ?> <?php echo $bannertext1; ?></span> </h2><?php } ?>
										<?php if ($bannerlink != "") { ?><a href="<?php echo $bannerlink; ?>" title="Enquire Now"><button data-animation="animated fadeInLeft">Enquire Now</button></a> <?php } else { ?><?php } ?>
									</div>
								</div>
							</div>
						</div>

					</div>
				</div>
			</div>

		<?php } ?>
	<?php } ?>
<?php } ?>
<!--slider_section-->






<?php if (get_the_title() == "About Us") { ?>
	<?php
	while (have_posts()) :



		the_post();



		the_content();



	endwhile;



	?>

<?php } else if (get_the_title() == "Transparency") { ?>

	<?php
	while (have_posts()) :
		the_post();
		the_content();
	endwhile;
	?>

<?php } else if (get_the_title() == "Testimonials") { ?>


	<!--testimonials_section-->


	<div class="testimonials_section">
		<div class="head_text">
			<h4>testimonials</h4>
			<h2>Read what our customers have to say</h2>
		</div>
		<ul class="testimonials_slider owl-carousel owl-theme">
			<li>
				<div class="testi_box">
					<div class="testi_box_top">
						<span>
							<img src="http://jyothispure.com/wp-content/uploads/2022/08/testimonial-1.png" alt="testimonials" title="testimonials" />
						</span>
						<span>
							<img src="<?php echo esc_url(get_template_directory_uri()); ?>/images/rating.png" alt="rating" title="rating" />
							<h4>Mrs.Sherwin Screena</h4>
							<h5>Tamil Nadu</h5>
						</span>
					</div>
					<div class="testi_box_bottom">
						<p>I'm a regular customer of Jyothi’s pure. The aroma, taste and quality of the oil is outstanding. My family is super satisfied with their products. Great service... I strongly recommend their products.</p>
					</div>
				</div>
			</li>
			<li>
				<div class="testi_box">
					<div class="testi_box_top">
						<span>
							<img src="http://jyothispure.com/wp-content/uploads/2022/08/testimonial-2.png" alt="testimonials" title="testimonials" />
						</span>
						<span>
							<img src="<?php echo esc_url(get_template_directory_uri()); ?>/images/rating.png" alt="rating" title="rating" />
							<h4>Mrs.jayanthi mala</h4>
							<h5>Tamil Nadu</h5>
						</span>
					</div>
					<div class="testi_box_bottom">
						<p>In love with Jyothi’s Pure products. The bottle design allows for both ease of cooking and storage. These oils are my everyday companion in making tasty, nutritious meal every day.</p>
					</div>
				</div>
			</li>
			<li>
				<div class="testi_box">
					<div class="testi_box_top">
						<span>
							<img src="http://jyothispure.com/wp-content/uploads/2022/08/testimonial-3.png" alt="testimonials" title="testimonials" />
						</span>
						<span>
							<img src="<?php echo esc_url(get_template_directory_uri()); ?>/images/rating.png" alt="rating" title="rating" />
							<h4>Mrs.Banu Chandra</h4>
							<h5>Tamil Nadu</h5>
						</span>
					</div>
					<div class="testi_box_bottom">
						<p>I will surely recommend Jyothi’s Pure products to my friends. Their Service too is top notch...Very quick delivery. Way to go..</p>
					</div>
				</div>
			</li>
			<li>
				<div class="testi_box">
					<div class="testi_box_top">
						<span>
							<img src="http://jyothispure.com/wp-content/uploads/2022/08/testimonial-4.png" alt="testimonials" title="testimonials" />
						</span>
						<span>
							<img src="<?php echo esc_url(get_template_directory_uri()); ?>/images/rating.png" alt="rating" title="rating" />
							<h4>Ms.Maanasa Narasimhan</h4>
							<h5>Tamil Nadu</h5>
						</span>
					</div>
					<div class="testi_box_bottom">
						<p>I've been using their products for a few years right now. It’s the best!</p>
					</div>
				</div>
			</li>
		</ul>
	</div>


	<!--testimonials_section-->


	<!--video_section-->



	<div class="video_section">
		<div class="wrap_grid">
			<div class="head_text">
				<h4>around our shop</h4>
				<h2>Let see what is happening</h2>
			</div>
		</div>
		<ul class="video_slider owl-carousel owl-theme">
			<li>
				<div class="video_box">
					<img src="<?php echo esc_url(get_template_directory_uri()); ?>/images/video.png" alt="video" title="video" />
					<div class='onq-youtube-player' data-id='WK-qGQT92PA' data-width='640' data-height='360' data-ssv='false' data-spc='false' data-sta='false' data-afs='false' data-dkc='false' data-ecc='false' data-eap='false'><img src='//i.ytimg.com/vi/WK-qGQT92PA/hqdefault.jpg' style='display: block; left: 0; margin: auto; width: 100%; height: 100%; position: absolute; right: 0;'>
						<div style='height: 72px; width: 72px; left: 50%; top: 50%; margin-left: -36px; margin-top: -36px; position: absolute; background: url("https://www.onqmarketing.com.au/wp-content/plugins/onq-youtube-embed-generator/playbutton.png") no-repeat; background-size: 72px;'></div>
					</div>
				</div>
			</li>
			<li>
				<div class="video_box">
					<img src="<?php echo esc_url(get_template_directory_uri()); ?>/images/video.png" alt="video" title="video" />
					<div class='onq-youtube-player' data-id='1Ysq19iQtJM' data-width='640' data-height='360' data-ssv='false' data-spc='false' data-sta='false' data-afs='false' data-dkc='false' data-ecc='false' data-eap='false'><img src='//i.ytimg.com/vi/1Ysq19iQtJM/hqdefault.jpg' style='display: block; left: 0; margin: auto; width: 100%; height: 100%; position: absolute; right: 0;'>
						<div style='height: 72px; width: 72px; left: 50%; top: 50%; margin-left: -36px; margin-top: -36px; position: absolute; background: url("https://www.onqmarketing.com.au/wp-content/plugins/onq-youtube-embed-generator/playbutton.png") no-repeat; background-size: 72px;'></div>
					</div>
				</div>
			</li>
			<li>
				<div class="video_box">
					<img src="<?php echo esc_url(get_template_directory_uri()); ?>/images/video.png" alt="video" title="video" />
					<div class='onq-youtube-player' data-id='GjRpVGc-eZo' data-width='640' data-height='360' data-ssv='false' data-spc='false' data-sta='false' data-afs='false' data-dkc='false' data-ecc='false' data-eap='false'><img src='//i.ytimg.com/vi/GjRpVGc-eZo/hqdefault.jpg' style='display: block; left: 0; margin: auto; width: 100%; height: 100%; position: absolute; right: 0;'>
						<div style='height: 72px; width: 72px; left: 50%; top: 50%; margin-left: -36px; margin-top: -36px; position: absolute; background: url("https://www.onqmarketing.com.au/wp-content/plugins/onq-youtube-embed-generator/playbutton.png") no-repeat; background-size: 72px;'></div>
					</div>
				</div>
			</li>
			<li>
				<div class="video_box">
					<img src="<?php echo esc_url(get_template_directory_uri()); ?>/images/video.png" alt="video" title="video" />
					<div class='onq-youtube-player' data-id='wrGWlVrXY34' data-width='640' data-height='360' data-ssv='false' data-spc='false' data-sta='false' data-afs='false' data-dkc='false' data-ecc='false' data-eap='false'><img src='//i.ytimg.com/vi/wrGWlVrXY34/hqdefault.jpg' style='display: block; left: 0; margin: auto; width: 100%; height: 100%; position: absolute; right: 0;'>
						<div style='height: 72px; width: 72px; left: 50%; top: 50%; margin-left: -36px; margin-top: -36px; position: absolute; background: url("https://www.onqmarketing.com.au/wp-content/plugins/onq-youtube-embed-generator/playbutton.png") no-repeat; background-size: 72px;'></div>
					</div>
				</div>
			</li>
			<li>
				<div class="video_box">
					<img src="<?php echo esc_url(get_template_directory_uri()); ?>/images/video.png" alt="video" title="video" />
					<div class='onq-youtube-player' data-id='vwavLhwNbFo' data-width='640' data-height='360' data-ssv='false' data-spc='false' data-sta='false' data-afs='false' data-dkc='false' data-ecc='false' data-eap='false'><img src='//i.ytimg.com/vi/vwavLhwNbFo/hqdefault.jpg' style='display: block; left: 0; margin: auto; width: 100%; height: 100%; position: absolute; right: 0;'>
						<div style='height: 72px; width: 72px; left: 50%; top: 50%; margin-left: -36px; margin-top: -36px; position: absolute; background: url("https://www.onqmarketing.com.au/wp-content/plugins/onq-youtube-embed-generator/playbutton.png") no-repeat; background-size: 72px;'></div>
					</div>
				</div>
			</li>

		</ul>
	</div>




	<!--video_section-->







<?php } else if (get_the_title() == "Checkout") { ?>

	<div class="pages_text">
		<div class="wrap_grid">
			<div class="head_text">
				<h1><?php the_title(); ?></h1>
			</div>
			<?php
			while (have_posts()) :



				the_post();



				the_content();



			endwhile;



			?>

		</div>

	</div>
	<div class="wrap_grid">
		<div style="display:inline-block;width:100%;margin:0 0 30px 0;">
			<a href="<?php echo get_site_url(); ?>" title="Back to Home"> <button id="back_to_home">Back to Home</button></a>
			<a href="<?php echo get_site_url(); ?>/shop/" title="Back to Shop"> <button id="back_to_home">Back to Shop</button></a>
		</div>
	</div>
<?php } else if (get_the_title() == "My account") { ?>
	<div class="pages_text">
		<div class="wrap_grid">
			<div class="head_text">
				<h1><?php the_title(); ?></h1>
			</div>
			<?php
			while (have_posts()) :



				the_post();



				the_content();



			endwhile;



			?>
		</div>
	</div>

<?php } else if (get_the_title() != "Blog") { ?>
	<div class="pages_text">
		<div class="wrap_grid">
			<div class="head_text">
				<h1><?php the_title(); ?></h1>
			</div>
			<?php
			while (have_posts()) :



				the_post();



				the_content();



			endwhile;



			?>
		</div>
	</div>
<?php } else { ?>


	<!--blog_section-->


	<div class="blog_section">
		<div class="wrap_grid">
			<div class="head_text">
				<h4>blogs</h4>
				<h1>Our latest articles</h1>
			</div>
		</div>
		<div class="blog_section_top">
			<div class="wrap_grid">
				<ul>
					<?php
					$temp = $wp_query;
					$wp_query = null;
					$wp_query = new WP_Query();
					$wp_query->query('showposts=6' . '&paged=' . $paged);
					if ($wp_query->have_posts()) :
						while ($wp_query->have_posts()) : $wp_query->the_post();
							$category = get_the_category();
							$posttags = get_the_tags(); ?>
							<li>
								<div class="blog_items">
									<div class="blog_items_images">
										<a class="feature" href="<?php the_permalink() ?>" title="<?php the_title(); ?>"> <?php if (has_post_thumbnail()) {
																																																				the_post_thumbnail('medium_large');
																																																			} else { ?>
												<img src="<?php echo get_site_url(); ?>/wp-content/uploads/2022/02/Mask-Group.png" alt="<?php the_title(); ?>">
											<?php } ?></a>
										<span>
											Featured
										</span>
									</div>
									<h4>
										<span>
											<?php echo $posttags[0]->name; ?>
										</span>
										<span>
											<?php the_time('F jS,Y'); ?>
										</span>
									</h4>
									<h2><?php the_title(); ?></h2>
									<p><?php echo wp_trim_words(get_the_content(), 20, '...'); ?></p>
									<a href="<?php the_permalink(); ?>" title="Read Now"><button>Read Now</button></a>
								</div>
							</li>
						<?php endwhile; ?>
				</ul>
				<?php the_posts_pagination(array('mid_size' => 2, 'prev_text' => __('Previous', 'textdomain'), 'next_text' => __('Next', 'textdomain'),)); ?>
				<?php wp_reset_postdata(); ?>
			<?php else : ?>
				<p>There is no posts...</p>
			<?php endif; ?>

			</div>
		</div>
		<div class="blog_page_bottom">
			<div class="wrap_grid">
				<div class="head_text">
					<h2>Our Recent Posts</h2>
				</div>
				<div class="blog_page_bottom_align">
					<div class="blog_page_bottom_left">
						<ul>
							<?php
							$temp = $wp_query;
							$wp_query = null;
							$wp_query = new WP_Query();
							$wp_query->query('showposts=3' . '&paged=' . $paged);
							if ($wp_query->have_posts()) :
								while ($wp_query->have_posts()) : $wp_query->the_post();
									$category = get_the_category();
									$posttags = get_the_tags(); ?>
									<li>
										<div class="blog_items_bottom">
											<div class="blog_items_left">
												<a class="feature" href="<?php the_permalink() ?>" title="<?php the_title(); ?>"> <?php if (has_post_thumbnail()) {
																																																						the_post_thumbnail('medium_large');
																																																					} else { ?>
														<img src="<?php echo get_site_url(); ?>/wp-content/uploads/2022/02/Mask-Group.png" alt="<?php the_title(); ?>">
													<?php } ?></a>
											</div>
											<div class="blog_items_right">
												<h4>
													<?php echo $posttags[0]->name; ?>
												</h4>
												<h2><?php the_title(); ?></h2>
												<p><?php echo wp_trim_words(get_the_content(), 20, ''); ?> <a href="<?php the_permalink(); ?>" title="Continue Reading"> Continue Reading...</a></p>
												<h5><?php the_time('F jS,Y'); ?></h5>
											</div>
										</div>
									</li>
								<?php endwhile; ?>

								<?php wp_reset_postdata(); ?>
							<?php else : ?>
								<p>There is no posts...</p>
							<?php endif; ?>
						</ul>
					</div>
					<div class="blog_page_bottom_right">
						<div class="side_bar">
							<?php dynamic_sidebar('sidebar1'); ?>
						</div>
						<div class="side_bar">
							<h2>Tags</h2>
							<?php dynamic_sidebar('tags'); ?>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>



	<!--blog_section-->













<?php } ?>
<?php get_footer(); ?>

<?php if (get_the_title() == "About Us") { ?>

	<script>
		$(".materials_section ul, .our_values_section ul").owlCarousel({
			loop: false,
			center: false,
			nav: false,
			dots: true,
			autoplay: true,
			margin: 25,
			rewind: true,
			autoplayHoverPause: true,
			touchDrag: true,
			mouseDrag: true,
			smartSpeed: 400,
			responsive: {
				0: {
					items: 1
				},
				480: {
					items: 1
				},
				580: {
					items: 1
				},
				768: {
					items: 2
				},
				956: {
					items: 3
				},
				1200: {
					items: 4
				},
				1390: {
					items: 4
				}
			}
		});

		//
	</script>



<?php } ?>
<?php if (get_the_title() == "Testimonials") { ?>
	<script>
		$(".video_slider").owlCarousel({
			loop: true,
			center: true,
			nav: false,
			dots: true,
			autoplay: false,
			rewind: true,
			autoplayHoverPause: true,
			touchDrag: true,
			mouseDrag: true,
			smartSpeed: 400,
			responsive: {
				0: {
					items: 1
				},
				480: {
					items: 1
				},
				580: {
					items: 1
				},
				768: {
					items: 2
				},
				956: {
					items: 3
				},
				1200: {
					items: 2.6
				},
				1390: {
					items: 2.6
				}
			}
		});

		//

		$(".testimonials_slider").owlCarousel({
			loop: true,
			center: true,
			nav: false,
			dots: true,
			autoplay: false,
			rewind: true,
			autoplayHoverPause: true,
			touchDrag: true,
			mouseDrag: true,
			smartSpeed: 400,
			responsive: {
				0: {
					items: 1
				},
				480: {
					items: 1
				},
				580: {
					items: 1
				},
				768: {
					items: 2
				},
				956: {
					items: 2
				},
				1200: {
					items: 2.2
				},
				1390: {
					items: 2.2
				}
			}
		});
	</script>


<?php } ?>

<?php if (get_the_title() == "About Us") { ?>

	<script>
		$(".about_testimonials_slider").owlCarousel({
			loop: true,
			center: true,
			nav: false,
			dots: true,
			autoplay: false,
			rewind: true,
			autoplayHoverPause: true,
			touchDrag: true,
			mouseDrag: true,
			smartSpeed: 400,
			responsive: {
				0: {
					items: 1
				},
				480: {
					items: 1
				},
				580: {
					items: 1
				},
				768: {
					items: 2
				},
				956: {
					items: 2
				},
				1200: {
					items: 1.9
				},
				1390: {
					items: 2.2
				},
				1390: {
					items: 2.2
				}
			}
		});

		//

		$(".about_priority_slider").owlCarousel({
			loop: false,
			center: false,
			nav: false,
			dots: true,
			autoplay: false,
			rewind: true,
			autoplayHoverPause: true,
			touchDrag: true,
			mouseDrag: true,
			smartSpeed: 400,
			responsive: {
				0: {
					items: 1
				},
				480: {
					items: 2
				},
				580: {
					items: 2
				},
				768: {
					items: 3
				},
				956: {
					items: 3
				},
				1200: {
					items: 4
				},
				1390: {
					items: 4
				}
			}
		});

		//

		$(".about_team_slider").owlCarousel({
			loop: false,
			center: false,
			nav: false,
			dots: true,
			autoplay: false,
			rewind: true,
			autoplayHoverPause: true,
			touchDrag: true,
			mouseDrag: true,
			smartSpeed: 400,
			responsive: {
				0: {
					items: 1
				},
				480: {
					items: 1
				},
				580: {
					items: 2
				},
				768: {
					items: 3
				},
				956: {
					items: 3
				},
				1200: {
					items: 4
				},
				1390: {
					items: 4
				}
			}
		});
	</script>


<?php } ?>
<?php
/**
 * The template for displaying all single posts and attachments
 *
 * @package WordPress
 * @subpackage Twenty_Fifteen
 * @since Twenty Fifteen 1.0
 */

get_header(); 



?>

<!--blog_section-->


<div class="blog_section">
	<div class="wrap_grid">
		<div class="head_text">
			<h4>blogs</h4>
			<h1><?php the_title();?></h1>
		</div>
	</div>
		
		<div class="blog_page_bottom">
		<div class="wrap_grid">
			
			<div class="blog_page_bottom_align">
				<div class="blog_page_bottom_left blog_left_single">
					<?php
				// Start the loop.
				while ( have_posts() ) : the_post();
				?>				
				<?php the_content();?>
				<?php
				// If comments are open or we have at least one comment, load up the comment template.
				if ( comments_open() || get_comments_number() ) :
				comments_template();
				endif;
				// End the loop.
				endwhile;
				?>
				</div>
				<div class="blog_page_bottom_right">
					<div class="side_bar">
						<?php dynamic_sidebar('sidebar1'); ?>
					</div>
					<div class="side_bar">
						<h2>Tags</h2>
						<?php dynamic_sidebar('tags'); ?>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>



<!--blog_section-->








<?php get_footer(); ?>

<?php 

get_header();



?>




<!--blog_section-->


<div class="blog_section">
	<div class="wrap_grid">
		<div class="head_text">
			<h4>blogs</h4>
			<h1>Our latest articles</h1>
		</div>
	</div>
		<div class="blog_section_top">
		<div class="wrap_grid">
		<ul>
		<?php 
			$temp = $wp_query; $wp_query= null;
			$wp_query = new WP_Query(); $wp_query->query('showposts=6' . '&paged='.$paged);
			if($wp_query->have_posts()) : 
			while ($wp_query->have_posts()) : $wp_query->the_post();$category = get_the_category(); $posttags = get_the_tags(); ?>
			<li>
				<div class="blog_items">
					<div class="blog_items_images">
						<a class="feature" href="<?php the_permalink() ?>" title="<?php the_title(); ?>"> <?php if ( has_post_thumbnail() ) { the_post_thumbnail('medium_large');}else{?> 
							<img src="<?php echo get_site_url();?>/wp-content/uploads/2022/02/Mask-Group.png" alt="<?php the_title(); ?>">	
						<?php } ?></a>
						<span>
							Featured
						</span>
					</div>
					<h4>
						<span>
							<?php echo $posttags[0]->name;?>
						</span>
						<span>
							<?php the_time('F jS,Y'); ?>
						</span>
					</h4>
					<h2><?php the_title(); ?></h2>
					<p><?php echo wp_trim_words( get_the_content(), 20, '...' ); ?></p>
					<a href="<?php the_permalink(); ?>" title="Read Now"><button>Read Now</button></a>
				</div>
			</li>
			<?php endwhile; ?>
			</ul>
			<?php the_posts_pagination( array('mid_size' => 2,'prev_text' => __( 'Previous', 'textdomain' ),'next_text' => __( 'Next', 'textdomain' ),) ); ?>
			<?php wp_reset_postdata(); ?>
			<?php else : ?>
			<p>There is no posts...</p>
			<?php endif;?>
		
		</div>
		</div>
		<div class="blog_page_bottom">
		<div class="wrap_grid">
			<div class="head_text">
				<h2>Our Recent Posts</h2>
			</div>
			<div class="blog_page_bottom_align">
				<div class="blog_page_bottom_left">
					<ul>
		<?php 
			$temp = $wp_query; $wp_query= null;$category = get_the_tags();
			$wp_query = new WP_Query(); $wp_query->query(''.$category.'='.$page_object->cat_name.'&showposts=6' . '&paged='.$paged);
			
			if($wp_query->have_posts()) : 
			while ($wp_query->have_posts()) : $wp_query->the_post();$category = get_the_tags(); $posttags = get_the_tags(); ?>
			<li>
				<div class="blog_items_bottom">
					<div class="blog_items_left">
						<a class="feature" href="<?php the_permalink() ?>" title="<?php the_title(); ?>"> <?php if ( has_post_thumbnail() ) { the_post_thumbnail('medium_large');}else{?> 
							<img src="<?php echo get_site_url();?>/wp-content/uploads/2022/02/Mask-Group.png" alt="<?php the_title(); ?>">	
						<?php } ?></a>
					</div>
					<div class="blog_items_right">
					<h4>
						<?php echo $posttags[0]->name;?>
					</h4>
					<h2><?php the_title(); ?></h2>
					<p><?php echo wp_trim_words( get_the_content(), 20, '' ); ?> <a href="<?php the_permalink(); ?>" title="Continue Reading"> Continue Reading...</a></p>
					<h5><?php the_time('F jS,Y'); ?></h5>
					</div>
				</div>
			</li>
			<?php endwhile; ?>
			
			<?php wp_reset_postdata(); ?>
			<?php else : ?>
			<p>There is no posts...</p>
			<?php endif;?>
		</ul>
				</div>
				<div class="blog_page_bottom_right">
					<div class="side_bar">
						<?php dynamic_sidebar('sidebar1'); ?>
					</div>
					<div class="side_bar">
						<h2>Tags</h2>
						<?php dynamic_sidebar('tags'); ?>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>



<!--blog_section-->


<?php 

get_footer();

?>


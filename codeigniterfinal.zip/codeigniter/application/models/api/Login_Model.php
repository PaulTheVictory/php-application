<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');

class Login_Model extends CI_Model
{

  public function __construct()
  {
    parent::__construct();
    $this->load->database();
    $this->load->library('email');
  }


  //Create New User

  public function create_newuser($r_name, $r_email, $r_phone, $r_password, $r_company)
  {
    $result = array(0=>"",1=>"");
    $otp = rand(100000, 999999);
    date_default_timezone_set("Asia/Calcutta");
    $user_id = uniqid(true) . "" . uniqid(true);
    $data = array(
      "user_id"   => $user_id,
      "name"  => $r_name,
      "email"     => $r_email,
      "countrycode"=> "+91",
      "phone"     => $r_phone,
      "password"  => $this->hash_password($r_password),
      'otp'      => $otp,
      "otpstatus" => "notverified",
      "verifiedstatus"  => "false",
      'role'      => "user",
      'status'    => 0,
      'company_id' => $r_company,
      'created'   => date('Y-m-j H:i:s'),
    );
    $res = $this->db->insert("ap_users", $data);

    if($res) {
      $query = $this->db->query('select user_id,name,phone,email,otp from ap_users where user_id="'. $user_id.'"');
      if($query) 
      {
        $res1 = $query->result_array();
        $res = $query->result();
        $name = $res[0]->name;
        $votp = $res[0]->otp;
        $email = $res[0]->email;
        
        $result = array(0 => "success", "user" => $res1);
        //$this->create_otp($name, $votp, $email);
          return $result;
      }
      else
      {
        $result = array(0=>"fail");
        return $result;
      }

    }

    
  }

  //Create Otp

  public function create_otp($name, $votp, $email)
  {
    $config['protocol']    = 'smtp';
    $config['smtp_host']    = 'ssl://smtp.gmail.com';
    $config['smtp_port']    = '465';
    $config['smtp_timeout'] = '7';
    $config['smtp_user']    = 'devlopsdemo@gmail.com';
    $config['smtp_pass']    = 'nfyunxrmdsgxmlmp';
    $config['charset']    = 'utf-8';
    $config['newline']    = "\r\n";
    $config['mailtype'] = 'html';
    $config['validation'] = TRUE;

    $this->email->initialize($config);
    $body  = '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.=w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"><html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"></head><body style="background:#F8F8F8; padding:20px;">
			<table style="background:#fff;border:0px solid #E8E8E8; border-radius:5px; border-collapse:collapse; overflow:hidden;padding:10px;margin:0 auto; font-size: 15px; width:600px"><tbody>
			<tr><td style="text-align:center; width:600px; color:#333; padding:20px;"><h1>Blazon</h1></td></tr>
			<tr><td style="text-align:left; line-height:1.4em; padding:10px 20px; width:600px; color:#333;">
				Dear ' . $name . ',<br><br><h2>Your Verification Code</h2><strong><h4>' . $votp . '</h4></strong>
			<tr><td style="text-align:left; padding:10px 20px; width:600px; color:#333;">&nbsp;</td></tr>
			
			<tr style="background:#EEEEEE; font-size: 12px;"><td style="text-align:center; padding:15px 20px; width:600px; color:#999;">Copyright &copy; 2022 Test. All Rights Reserved. <a style="color:#ee8f0a; text-decoration:none;" href="javascript:void(0)">Blazon</a></td></tr>
			</tbody></table></body></html>';
    $subject  = "Verification Code";
    $this->email->from('devlopsdemo@gmail.com', 'Admin');
    $this->email->to($email,);
    $this->email->subject($subject);
    $this->email->message($body);

    $send = $this->email->send();

    if($send) {
      return true;
    } else {
      return false;
    }





  }


  //Otp validate

  public function otp_validate($o_user_id, $o_otp) {
    $result = array(0=>"");
    $query = $this->db->query('select user_id,otp from ap_users where user_id="'. $o_user_id.'"');
    $res = $query->result();
    


    if($res) {
      
      if($res[0]->otp===$o_otp && $res[0]->user_id=== $o_user_id) {
        $query2 = $this->db->query('update ap_users set otp="",otpstatus="verified",verifiedstatus="true" where user_id="' . $o_user_id . '"');
        if($query2) {
          $query1 = $this->db->query('select user_id,name,phone,email,role from ap_users where user_id="' . $o_user_id . '"');
          $res1 = $query1->result();
          $res_user_id = $res1[0]->user_id;
          $res_name = $res1[0]->name;
          $res_phone = $res1[0]->phone;
          $res_email = $res1[0]->email;
          $res_role = $res1[0]->role;
          $result = array(0 => "success", 1 => $res_user_id,2=> $res_name,3=> $res_phone,4=> $res_email,5=> $res_role);
          return $result; 
        }
               
      } else {
        $result = array(0 => "otpfail");
        return $result;
      }
    } else {
      $result = array(0=>"notfound");
      return $result;
    }



  }


  //Login User

  public function user_login($username, $password)
  {
    $result = array(0=>"");
     $this->db->select("password");
    $this->db->from("ap_users");
    $this->db->group_start();
    $this->db->where("phone", $username);
    $this->db->or_where("email", $username);
    $this->db->group_end();
    $hash = $this->db->get()->row("password");
    $res = $this->verify_password_hash($password, $hash);
    $this->db->select("user_id,name,phone,email,role,status");
    $this->db->from("ap_users");
    $this->db->group_start();
    $this->db->where("phone", $username);
    $this->db->or_where("email", $username);
    $this->db->group_end();
    $this->db->limit(1);
    $query = $this->db->get();
    if($res && $query->num_rows() === 1) {
      $res1 = $query->result();
      $res_user_id = $res1[0]->user_id;
      $res_name = $res1[0]->name;
      $res_phone = $res1[0]->phone;
      $res_email = $res1[0]->email;
      $res_role = $res1[0]->role;
      $result = array(0 => "success", 1 => $res_user_id, 2 => $res_name, 3 => $res_phone, 4 => $res_email, 5 => $res_role);
      return $result; 
    } else {
      $result = array(0 => "notfound");
      return $result;
    }

    
  }


  //Session Logs

  public function create_session($s_user_id, $s_username, $s_role, $s_phone, $s_intime, $s_browser, $s_platform, $s_ip)
  {

    $sess_id = uniqid() . '' . uniqid();
    $this->session->set_userdata("session_id", $sess_id);

    $result = $this->db->query('insert into user_logs (`session_id`,`user_id`,`ipaddress`,`browser`,`platform`,`username`,`phone`,`role`,`intime`,`outtime`,`status`) values ("' . $sess_id . '","' . $s_user_id . '","' . $s_ip . '","' . $s_browser . '","' . $s_platform . '","' . $s_username . '","' . $s_phone . '","' . $s_role . '","' . $s_intime . '","","o")');

    if ($result) {
      return $sess_id;
    } else {
      return false;
    }
  }

  public function end_session($session_id)
  {
    $result = array(0 => "");
    date_default_timezone_set("Asia/Calcutta");
    $date = date('Y-m-j H:i:s');
    $query1 = $this->db->query('update user_logs set outtime="' . $date . '",status="c" where session_id="' . $session_id . '" and status<>"c"');

      if ($query1) {
        $result = array(0 => "success");
        return $result;
      } else {
        $result = array(0 => "dbfail");
        return $result;
      }
   
  }


  public function change_password($c_oldpassword, $c_newpassword, $c_user_id)
  {
    $result = array(0 => "");
   
      $this->db->select("password,user_id");
      $this->db->from("ap_users");
    $this->db->group_start();
    $this->db->where("user_id", $c_user_id);
    $this->db->or_where("password", $this->verify_password_hash($c_oldpassword,"password"));
    $this->db->group_end();
    $this->db->limit(1);
    $query = $this->db->get();
      
      if($query->num_rows() === 1)
      {
        $query1 = $this->db->query('update ap_users set password="'.$this->hash_password($c_newpassword).'" where user_id="'. $c_user_id.'"');
        if($query1) {
          $result = array(0=>"success");
          return $result;
        }
        else {
          $result = array(0=>"fail");
          return $result;
        }
      }
   



  }












  //token verification

  private function token_validation($headers)
  {

    $token = explode(' ', $headers["Authorization"])[1];

    $this->db->select("token");
    $this->db->from("app_users");
    $this->db->group_start();
    $this->db->where("token", $token);
    $this->db->group_end();
    $query = $this->db->get();
    if ($query->num_rows() === 1) {
      return true;
    } else {
      return false;
    }
  }




  //hash_password function
  private function hash_password($password)
  {
    return password_hash($password, PASSWORD_BCRYPT);
  }
  //verify_password_hash function
  private function verify_password_hash($password, $hash)
  {
    return password_verify($password, $hash);
  }
}

<?php 
if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class User_Model extends CI_Model {

public function Login($username,$password) {

  $this->db->select("user_id,username,phone,password,role,status");
  $this->db->from("app_users");
  $this->db->where("username",$username);
  $this->db->where("password",sha1($password));
  $this->db->limit(1);

  $query = $this->db->get();

  if($query->num_rows()===1) {
    return $query->result();
  } else {
    return false;
  }

}


public function CreateSession($s_user_id,$s_username,$s_role,$s_phone,$s_intime,$s_browser,$s_platform,$s_ip) {

  $sess_id = uniqid();
  $this->session->set_userdata("session_id",$sess_id);

  $result = $this->db->query('insert into user_logs (`session_id`,`user_id`,`ipaddress`,`browser`,`platform`,`username`,`phone`,`role`,`intime`,`outtime`,`status`) values ("'.$sess_id.'","'.$s_user_id.'","'.$s_ip.'","'.$s_browser.'","'.$s_platform.'","'.$s_username.'","'.$s_phone.'","'.$s_role.'","'.$s_intime.'","","o")');

  if($result) {
    return true;
  } else {
    return false;
  }


}


public function EndSession($s_id,$date) {

  $query = $this->db->query('update user_logs set outtime="'.$date.'", status="c" where session_id="'.$s_id.'"');

  if($query) {
    return true;
  } else {
    return false;
  }

}









}
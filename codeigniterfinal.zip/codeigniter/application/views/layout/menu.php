<aside id="sidebar" class="sidebar">

  <ul class="sidebar-nav" id="sidebar-nav">
    <li class="nav-item">
      <a class="nav-link " href="<?= base_url(); ?>">
        <i class="bi bi-grid"></i>
        <span>Dashboard</span>
      </a>
    </li>
    <li class="nav-item">
      <a class="nav-link collapsed" data-bs-target="#components-nav" data-bs-toggle="collapse" href="#">
        <i class="bi bi-menu-button-wide"></i><span>Users</span><i class="bi bi-chevron-down ms-auto"></i>
      </a>
      <ul id="components-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">
        <li>
          <a href="javascript:void(0)">
            <i class="bi bi-circle"></i><span>Add User</span>
          </a>
        </li>
        <li>
          <a href="javascript:void(0)">
            <i class="bi bi-circle"></i><span>All Users</span>
          </a>
        </li>
        <li>
          <a href="javascript:void(0)">
            <i class="bi bi-circle"></i><span>Delete Users</span>
          </a>
        </li>

      </ul>
    </li>
    <li class="nav-heading">Pages</li>
    <li class="nav-item">
      <a class="nav-link collapsed" href="<?= base_url(); ?>logs/">
        <i class="bi bi-card-checklist"></i>
        <span>Logs</span>
      </a>
    </li>
    <li class="nav-item">
      <a class="nav-link collapsed" href="<?= base_url(); ?>">
        <i class="bi bi-shield-check"></i>
        <span>Change Password</span>
      </a>
    </li>
    <li class="nav-item">
      <a class="nav-link collapsed" href="javascript:void(0)">
        <i class="bi bi-person"></i>
        <span>Profile</span>
      </a>
    </li>
    <li class="nav-item">
      <a class="nav-link collapsed" href="javascript:void(0)">
        <i class="bi bi-gear"></i>
        <span>Settings</span>
      </a>
    </li>
    <li class="nav-item">
      <a class="nav-link collapsed" href="<?= base_url(); ?>login/Logout">
        <i class="bi bi-box-arrow-in-right"></i>
        <span>Logout</span>
      </a>
    </li>
  </ul>

</aside>
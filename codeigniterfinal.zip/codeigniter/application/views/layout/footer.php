</div>
    </section>

  </main>

<footer id="footer" class="footer">
    <div class="copyright">
      &copy; Copyright <strong><span>Blazon</span></strong>. All Rights Reserved
    </div>
    <div class="credits">
      Developed by <a href="https://blazon.in/" title="Blazon" target="_blank">Blazon</a>
    </div>
  </footer>
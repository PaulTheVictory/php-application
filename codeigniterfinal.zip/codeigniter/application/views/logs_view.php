<?php
defined('BASEPATH') or exit('No direct script access allowed');
?>


<!-- Table -->

<table id='logs_table' class='display dataTable'>

<thead>
  <tr>
    <th>User Id</th>
    <th>Email</th>
    <th>Phone</th>
    <th>Role</th>
    <th>In Time</th>
    <th>Out Time</th>
  </tr>
</thead>


</table>

<!-- Script -->
<script type="text/javascript">
$(document).ready(function(){
   $('#logs_table').DataTable({
      'processing': true,
      'serverSide': true,
      'serverMethod': 'post',
      'ajax': {
        'url':'<?=base_url()?>logs/GetUserLogs'
      },
      'columns': [
          { data: 'user_id' },
         { data: 'username' },
         { data: 'phone' },
         { data: 'role' },
         { data: 'intime' },
         { data: 'outtime' },
      ]
   });
});
</script>
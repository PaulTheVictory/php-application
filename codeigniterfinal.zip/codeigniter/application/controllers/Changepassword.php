<?php

defined('BASEPATH') OR exit('No direct script access allowed');


class Changepassword extends CI_Controller  {

public function index() {


  if ($this->session->userdata("adlog_in")) {
    $data["title"] = "Change Password";
    $this->load->view("layout/header_script",$data);
    $this->load->view("layout/header",$data);
    $this->load->view("dashboard_view");
    $this->load->view("layout/footer");
    $this->load->view("layout/footer_script");
  } else {
    redirect(base_url("login"), "refresh");
  }


  


}


















}
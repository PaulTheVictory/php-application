<?php
defined('BASEPATH') or exit('No direct script access allowed');


class Logs extends CI_Controller {

  function __construct()
  {
    parent::__construct();
    $this->load->model('Logs_Model', '', TRUE);
  }

  public function index() {

    

    if ($this->session->userdata("adlog_in")) {
      $data["title"] = "Logs";
      $this->load->view("layout/header_script",$data);
      $this->load->view("layout/header",$data);
      $this->load->view("logs_view",$data);
      $this->load->view("layout/footer");
      $this->load->view("layout/footer_script");
    } else {
      redirect(base_url("login"), "refresh");
    }
  
  }

  public function GetUserLogs() {

    $postData = $this->input->post();

    $data = $this->Logs_Model->GetLogs($postData);

    if($data) {
      echo json_encode($data);
    }


    



  }







}
<?php
defined('BASEPATH') or exit('No direct script access allowed');


class Login extends CI_Controller
{


  function __construct()
  {
    parent::__construct();
    $this->load->model('User_Model', '', TRUE);
  }

  public function index()
  {

    if ($this->session->userdata("adlog_in")) {
      redirect('dashboard', 'refresh');
    } else if ($this->session->userdata("adlog_in")) {
      redirect("login", "refresh");
    } else {

      $this->load->helper('form');
      $this->load->library('form_validation');

      $this->form_validation->set_rules("username", "Username", "trim|required|xss_clean");
      $this->form_validation->set_rules("password", "Password", "trim|required|xss_clean|callback_check_database");
      $this->form_validation->set_error_delimiters('<p class="alert alert-danger alert-dismissible">', '<button type="button" class="btn-close" data-bs-dismiss="alert"></button></p>');
      if ($this->form_validation->run() === false || !$this->session->userdata("logged_in")  || !$this->session->userdata("adlog_in")) {
        $data["title"] = "Login";
        $this->load->view("layout/header_script", $data);
        $this->load->view("login_view");
        $this->load->view("layout/footer_script");
      }
    }
  }

  public function check_database()
  {

    $username = $this->input->post("username", true);
    $password = $this->input->post("password", true);

    $result = $this->User_Model->Login($username, $password);

    if ($result) {

      $sessdata = array();

      $offset=5*60*60 + 30*60;
			$dateformat = 'Y-m-d H:i:s';
			$date = gmdate($dateformat, time()+$offset);
      
      foreach ($result as $row) {
        $sessdata = array(
          "user_id"=>$row->user_id,
          "username"=>$row->username,
          "role"=>$row->role,
          "phone"=>$row->phone,
          "intime"=>$date,
        );
     
        $this->session->set_userdata($sessdata);

        if($sessdata["role"]==="admin") {
          $this->session->unset_userdata("logged_in",false);
          $this->session->set_userdata("adlog_in",true);
        } elseif($sessdata["role"]==="users") {
          $this->session->unset_userdata("adlog_in",false);
          $this->session->set_userdata("logged_in",true);
        } else {
          $this->session->unset_userdata("logged_in",false);
          $this->session->unset_userdata("adlog_in",false);
        }

        $this->load->library("user_agent");
        
        $s_user_id = $this->session->userdata("user_id");
        $s_username = $this->session->userdata("username");
        $s_role = $this->session->userdata("role");
        $s_phone = $this->session->userdata("phone");
        $s_intime = $this->session->userdata("intime");
        $s_browser = $this->agent->browser()." ".$this->agent->version();
        $s_platform = $this->agent->platform();
        $s_ip = $this->input->ip_address();


        $res = $this->User_Model->CreateSession($s_user_id,$s_username,$s_role,$s_phone,$s_intime,$s_browser,$s_platform,$s_ip);

        
        
        if($res) {
          redirect(base_url("dashboard"), "refresh");
        } else {
          $this->form_validation->set_message('check_database', 'Try again!');
        }

      
       
      
    }
        $this->session->unset_userdata('adlog_in');
        $this->session->unset_userdata('logged_in');
        $this->form_validation->set_message('check_database', 'Account Not Active');
        return false;
    } else {
      $this->session->unset_userdata('adlog_in');
        $this->session->unset_userdata('logged_in');
      $this->form_validation->set_message('check_database', 'Invalid username or password');
      return false;
    }
  }

  public function Logout() {
    $this->session->sess_destroy(); 
    $offset=5*60*60 + 30*60;
		$dateformat = 'Y-m-d H:i:s';
		$date = gmdate($dateformat, time()+$offset);

    $s_id = $this->session->userdata("session_id");
    
    $res = $this->User_Model->EndSession($s_id,$date);

    if($res) {
      $this->session->unset_userdata('adlog_in');
      $this->session->unset_userdata('logged_in');
      redirect(base_url('login'), 'refresh');
    }
  
  }




}

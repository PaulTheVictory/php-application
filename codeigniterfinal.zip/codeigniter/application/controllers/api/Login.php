<?php
defined('BASEPATH') or exit('No direct script access allowed');

require(APPPATH . '/libraries/REST_Controller.php');

use Restserver\Libraries\REST_Controller;

class Login extends REST_Controller
{

  public function __construct()
  {
    parent::__construct();
    $this->load->library("Authorization_Token");
    $this->load->model("api/Login_Model", "login_model", TRUE);
    $this->load->library("user_agent");
    header("Access-Control-Allow-Origin: *");
    header("Access-Control-Allow-Methods: GET, OPTIONS, POST, GET, PUT");
    header("Access-Control-Allow-Headers: Content-Type, Content-Length, Accept-Encoding");
  }


  //User Register Api

  public function newregister_post()
  {
    try {
      $headers = $this->input->request_headers();
      $r_company = $headers["company"];
      //FormData Validation
      $this->form_validation->set_rules("name", "Username", 'trim|required|min_length[3]|max_length[20]');
      $this->form_validation->set_rules("email", "Email Id", 'required|valid_email|max_length[25]|is_unique[ap_users.email]');
      $this->form_validation->set_rules("phone", "Phone No", 'required|is_unique[ap_users.phone]|regex_match[/^[0-9]{10}$/]');
      $this->form_validation->set_rules('password', 'Password', 'trim|required|min_length[6]');
      $this->form_validation->set_rules('password_confirm', 'Confirm Password', 'trim|required|min_length[6]|matches[password]');


      if ($this->form_validation->run() === FALSE && $r_company !== "") {
        $error["success"] = false;
        $error["statusCode"] = 400;
        $error["message"] = "Form Validation Fail!";
        $error["error"] = $this->validation_errors();
        $this->response($error, REST_Controller::HTTP_BAD_REQUEST);
      } else {

        $r_name = $this->input->post("name");
        $r_email = $this->input->post("email");
        $r_phone = $this->input->post("phone");
        $r_password = $this->input->post("password");
        $res = $this->login_model->create_newuser($r_name, $r_email, $r_phone, $r_password, $r_company);

        if ($res[0] === "success") {
          $user = $res["user"];
          $arr["message"] = "Register Successfully";
          $arr["success"] = true;
          $arr["statusCode"] = 200;
          $arr["user"] = $user;
          $this->response($arr, REST_Controller::HTTP_OK);
        } else if ($res[0] === "fail") {
          $arr["success"] = false;
          $arr["statusCode"] = 400;
          $arr["message"] = "Register Failed!";
          $this->response($arr, REST_Controller::HTTP_BAD_REQUEST);
        } else if ($res[0] === "otpfail") {
          $arr["success"] = false;
          $arr["statusCode"] = 400;
          $arr["message"] = "otp not sened!. please try again";
          $this->response($arr, REST_Controller::HTTP_BAD_REQUEST);
        } else {
          $arr["success"] = false;
          $arr["statusCode"] = 400;
          $arr["message"] = "Login failed!. Please try again";
          $this->response($arr, REST_Controller::HTTP_BAD_REQUEST);
        }
      }
    } catch (Exception $e) {
      $error["success"] = false;
      $error["statusCode"] = 500;
      $error["message"] = "Internal server error. Please try again later!";
      $error["error"] = $e->getMessage();
      $this->response($error, REST_Controller::HTTP_INTERNAL_SERVER_ERROR);
    }
  }


  //Otp validation

  public function otp_post()
  {
    try {
      $this->form_validation->set_rules("user_id", "User id", "required");
      $this->form_validation->set_rules("otp", "otp", "required");

      if ($this->form_validation->run() === FALSE) {
        $error["success"] = false;
        $error["statusCode"] = 400;
        $error["message"] = "otp & user id is required";
        $error["error"] = $this->validation_errors();
        $this->response($error, REST_Controller::HTTP_BAD_REQUEST);
      } else {
        $o_user_id = $this->input->post("user_id");
        $o_otp = $this->input->post("otp");
        $res = $this->login_model->otp_validate($o_user_id, $o_otp);
        if ($res[0] === "success") {
          $token_data["user_id"] = $res[1];
          $token_data["name"] = $res[2];
          $token_data["phone"] = $res[3];
          $token_data["email"] = $res[4];
          $token_data["role"] = $res[5];
          $token = $this->authorization_token->generateToken($token_data);
          $arr["message"] = "Login Successfully";
          $arr["success"] = true;
          $arr["statusCode"] = 200;
          $arr["token"] = $token;
          $arr["user_id"] = $res[1];
          $arr["name"] = $res[2];
          $arr["phone"] = $res[3];
          $arr["email"] = $res[4];
          $arr["role"] = $res[5];

          $this->session->set_userdata("logged_in", true);
          date_default_timezone_set("Asia/Calcutta");
          $date = date('Y-m-j H:i:s');
          $s_user_id = $res[1];
          $s_username = $res[4];
          $s_role = $res[5];
          $s_phone = $res[3];
          $s_intime = $date;
          $s_browser = $this->agent->browser() . " " . $this->agent->version();
          $s_platform = $this->agent->platform();
          $s_ip = $this->input->ip_address();
          $sess = $this->login_model->create_session($s_user_id, $s_username, $s_role, $s_phone, $s_intime, $s_browser, $s_platform, $s_ip);
          $arr["session_id"] = $sess;

          $this->response($arr, REST_Controller::HTTP_OK);
        } elseif ($res[0] === "otpfail") {
          $arr["success"] = false;
          $arr["statusCode"] = 400;
          $arr["message"] = "invalid otp";
          $this->response($arr, REST_Controller::HTTP_BAD_REQUEST);
        } elseif ($res[0] === "notfound") {
          $arr["success"] = false;
          $arr["statusCode"] = 400;
          $arr["message"] = "account not found";
          $this->response($arr, REST_Controller::HTTP_BAD_REQUEST);
        } else {
          $arr["success"] = false;
          $arr["statusCode"] = 400;
          $arr["message"] = "something went wrong!. please try again";
          $this->response($arr, REST_Controller::HTTP_BAD_REQUEST);
        }
      }
    } catch (Exception $e) {
      $error["success"] = false;
      $error["statusCode"] = 500;
      $error["message"] = "Internal server error. Please try again later!";
      $error["error"] = $e->getMessage();
      $this->response($error, REST_Controller::HTTP_INTERNAL_SERVER_ERROR);
    }
  }


  //User Login Api

  public function login_post()
  {
    try {
      $this->form_validation->set_rules('username', 'Username', 'required');
      $this->form_validation->set_rules('password', 'Password', 'required');


      if ($this->form_validation->run() == false) {
        $error["success"] = false;
        $error["statusCode"] = 400;
        $error["message"] = "username & password field is required";
        $error["error"] = $this->validation_errors();
        $this->response($error, REST_Controller::HTTP_BAD_REQUEST);
      } else {
        $username = $this->input->post('username');
        $password = $this->input->post('password');
        $res = $this->login_model->user_login($username, $password);


        if ($res[0] === "success") {
          $token_data["user_id"] = $res[1];
          $token_data["name"] = $res[2];
          $token_data["phone"] = $res[3];
          $token_data["email"] = $res[4];
          $token_data["role"] = $res[5];
          $token = $this->authorization_token->generateToken($token_data);
          $arr["message"] = "Login Successfully";
          $arr["success"] = true;
          $arr["statusCode"] = 200;
          $arr["token"] = $token;
          $arr["user_id"] = $res[1];
          $arr["name"] = $res[2];
          $arr["phone"] = $res[3];
          $arr["email"] = $res[4];
          $arr["role"] = $res[5];

          $this->session->set_userdata("logged_in", true);
          date_default_timezone_set("Asia/Calcutta");
          $date = date('Y-m-j H:i:s');
          $s_user_id = $res[1];
          $s_username = $res[4];
          $s_role = $res[5];
          $s_phone = $res[3];
          $s_intime = $date;
          $s_browser = $this->agent->browser() . " " . $this->agent->version();
          $s_platform = $this->agent->platform();
          $s_ip = $this->input->ip_address();
          $sess = $this->login_model->create_session($s_user_id, $s_username, $s_role, $s_phone, $s_intime, $s_browser, $s_platform, $s_ip);
          $arr["session_id"] = $sess;

          $this->response($arr, REST_Controller::HTTP_OK);
        } elseif ($res[0] === "notfound") {
          $arr["success"] = false;
          $arr["statusCode"] = 400;
          $arr["message"] = "account not found";
          $this->response($arr, REST_Controller::HTTP_BAD_REQUEST);
        } else {
          $arr["success"] = false;
          $arr["statusCode"] = 400;
          $arr["message"] = "something went wrong!. please try again";
          $this->response($arr, REST_Controller::HTTP_BAD_REQUEST);
        }
      }
    } catch (Exception $e) {
      $error["success"] = false;
      $error["statusCode"] = 500;
      $error["message"] = $e->getMessage();
      $this->response($error, REST_Controller::HTTP_INTERNAL_SERVER_ERROR);
    }
  }


  //Logout

  public function logout_post()
  {
    $this->form_validation->set_rules("session_id", "Session Id", 'required');

    $session_id = $this->input->post("session_id", true);


    if ($this->form_validation->run() == false) {
      $error["success"] = false;
      $error["statusCode"] = 400;
      $error["message"] = "session id & userid field is required";
      $error["error"] = $this->validation_errors();
      $this->response($error, REST_Controller::HTTP_BAD_REQUEST);
    } else {

      $res = $this->login_model->end_session($session_id);

      try {
        if ($res[0] === "success") {
          $result = array();
          $result["message"] = "Logout Successfully";
          $result["success"] = true;
          $result["statusCode"] = 200;
          $this->session->sess_destroy();
          $this->response($result, REST_Controller::HTTP_OK);
        } elseif ($res[0] === "dbfail") {
          $error = array();
          $error["message"] = "already logged out";
          $error["success"] = false;
          $error["statusCode"] = 400;
          $this->response($error, REST_Controller::HTTP_BAD_REQUEST);
        } else {
          $error = array();
          $error["message"] = "Logout failed!";
          $error["success"] = false;
          $error["statusCode"] = 400;
          $this->response($error, REST_Controller::HTTP_BAD_REQUEST);
        }
      } catch (Exception $e) {
        $error = array();
        $error["message"] = $e->getMessage();
        $error["success"] = false;
        $error["statusCode"] = 500;
        $this->response($error, REST_Controller::HTTP_INTERNAL_SERVER_ERROR);
      }
    }
  }


  //Change Password

  public function changepassword_post()
  {
    $headers = $this->input->request_headers();

    $verify_res = $this->verifyheader($headers);

 

    if ($verify_res["success"]===true) {
     



      $this->form_validation->set_rules("old_password", "old password", "trim|required");
      $this->form_validation->set_rules("new_password", "new password", "trim|required|min_length[6]");
      $this->form_validation->set_rules("new_passwordconfirm", "confirm password", "trim|required|min_length[6]|matches[new_password]");

      $c_oldpassword = $this->input->post("old_password", true);
      $c_newpassword = $this->input->post("new_password", true);
      $c_user_id = $verify_res["user_id"];

      if ($this->form_validation->run() == false) {
        $error["success"] = false;
        $error["statusCode"] = 400;
        $error["message"] = "Validation Fail!";
        $error["error"] = $this->validation_errors();
        $this->response($error, REST_Controller::HTTP_BAD_REQUEST);
      } else {

        $res = $this->login_model->change_password($c_oldpassword, $c_newpassword, $c_user_id);

        try {
          if ($res[0] === "success") {
            $result = array();
            $result["message"] = "Password updated Successfully";
            $result["success"] = true;
            $result["statusCode"] = 200;
            $this->session->sess_destroy();
            $this->response($result, REST_Controller::HTTP_OK);
          } elseif ($res[0] === "fail") {
            $error = array();
            $error["message"] = "Please try again";
            $error["success"] = false;
            $error["statusCode"] = 400;
            $this->response($error, REST_Controller::HTTP_BAD_REQUEST);
          } else {
            $error = array();
            $error["message"] = "Failed!";
            $error["success"] = false;
            $error["statusCode"] = 400;
            $this->response($error, REST_Controller::HTTP_BAD_REQUEST);
          }
        } catch (Exception $e) {
          $error = array();
          $error["message"] = $e->getMessage();
          $error["success"] = false;
          $error["statusCode"] = 500;
          $this->response($error, REST_Controller::HTTP_INTERNAL_SERVER_ERROR);
        }
      }
    } else {
      $error = array();
      $error["message"] = "unauthorized request!. please try again";
      $error["success"] = false;
      $error["statusCode"] = 400;
      $this->response($error, REST_Controller::HTTP_BAD_REQUEST);
    }
  }


  // Mail Test
  public function mail_post()
  {

    $this->load->library('email');

    $config['protocol']    = 'smtp';
    $config['smtp_host']    = 'ssl://smtp.gmail.com';
    $config['smtp_port']    = '465';
    $config['smtp_timeout'] = '7';
    $config['smtp_user']    = 'devlopsdemo@gmail.com';
    $config['smtp_pass']    = 'nfyunxrmdsgxmlmp';
    $config['charset']    = 'utf-8';
    $config['newline']    = "\r\n";
    $config['mailtype'] = 'html';
    $config['validation'] = TRUE;

    $this->email->initialize($config);

    $this->email->from('devlopsdemo@gmail.com', 'Admin');
    $this->email->to('paulthevictory@gmail.com');
    $this->email->subject('Email Test');
    $this->email->message('Testing the email class.');

    $this->email->send();

    echo $this->email->print_debugger();

    $this->response($this->email->send(), REST_Controller::HTTP_OK);
  }

  public function tokenGen_post()
  {
    $token_data['user_id'] = 1001;
    $token_data['fullname'] = 'Hello World';
    $token_data['email'] = 'helloworld@gmail.com';

    $tokenData = $this->authorization_token->generateToken($token_data);

    $final = array();
    $final['token'] = $tokenData;
    $final['status'] = 'ok';

    $this->response($final);
  }

  public function verify_post()
  {
    $headers = $this->input->request_headers();

    $res = $this->verifyheader($headers);
    if ($res) {
      $this->response($res, REST_Controller::HTTP_OK);
    } else {
      $this->response("false", REST_Controller::HTTP_OK);
    }
  }






  private function verifyheader($headers)
  {
    if (isset($headers['Authorization'])) {
      $decodedToken = $this->authorization_token->validateToken($headers["Authorization"]);
      $res = $decodedToken["status"] !== false ? $decodedToken["data"]->user_id : "";
      if ($res !== "") {
        $arr["success"] = true;
        $arr["user_id"] = $res;
        $arr["statusCode"] = 200;
        $arr["message"] = "Valid Token";

        return $arr;
      } else {
        $arr["success"] = false;
        $arr["statusCode"] = 400;
        $arr["message"] = "Invalid Token";
        return $this->response($arr, REST_Controller::HTTP_BAD_REQUEST);
      }
    } else {
      $arr["success"] = false;
      $arr["statusCode"] = 400;
      $arr["message"] = "Token Authentication failed";
      return $this->response($arr, REST_Controller::HTTP_BAD_REQUEST);
    }
  }
}

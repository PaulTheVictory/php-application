<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class AuthController extends CI_Controller {

  public function __construct()
  {
    parent::__construct();
    $this->load->model("Auth_Model");
    $this->load->helper("verifyAuthToken");
    header("Access-Control-Allow-Origin: *");
	  header("Access-Control-Allow-Methods: GET, OPTIONS, POST, GET, PUT");
	  header("Access-Control-Allow-Headers: Content-Type, Content-Length, Accept-Encoding");
  }

  
  








}
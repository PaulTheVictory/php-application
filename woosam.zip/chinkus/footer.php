<!--footer_section-->

<footer class="footer_section section_padding m_0">
  <div class="wrapper">
    <div class="footer_top">
      <div class="footer_top_left">
        <p>Located in Thalassery, Kerala, we have progressed with the team of experts who very well understands the changing tastes and needs of our consumers.
          We have cherished our consumers by giving them authentic Kerala sweets that are a best substitute to the junk foods and the chocolates, established by virtue of their quality, nutritional value and availability.</p>
      </div>
      <div class="footer_top_right">
        <ul class="list_1">
          <li>Flexible modes of payments</li>
          <li>Authentic and Native</li>
          <li>All India Delivery</li>
        </ul>
        <div class="list_image">
          <img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/f1.png" alt="payment">
          <img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/f2.png" alt="payment">
          <img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/f3.png" alt="payment">
          <img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/f4.png" alt="payment">
          <img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/f5.png" alt="payment">
        </div>
      </div>
    </div>
    <div class="footer_button col_2_lg gap_30_lg col_1_sm">
      <div class="footer_bottom_1 w_100_lg">
        <h4>Get In Touch with us</h4>
        <p class="f_phone">+91 9876543219</p>
        <p class="f_call">0422 2546978</p>
        <p class="f_address">Door No. 6, 168 A, Choran Tavide House, P.O Pinarayi, Thalassery, Kannur, Kerala - 670741, India</p>
      </div>
      <div class="footer_bottom_2 w_100_lg">
        <h4>Quick links</h4>
        <ul>
          <li><a href="<?= get_site_url(); ?>/about-us/" title="About us">About us</a></li>
          <li><a href="<?= get_site_url(); ?>/shop/" title="Products">Products</a></li>
          <li><a href="<?= get_site_url(); ?>/blog/" title="Blog">Blog</a></li>
          <li><a href="<?= get_site_url(); ?>/testimonials/" title="Testimonials">Testimonials</a></li>
          <li><a href="<?= get_site_url(); ?>/contact-us/" title="Contact Us">Contact Us</a></li>
        </ul>
      </div>
      <div class="footer_bottom_3 w_100_lg">
        <h4>Company</h4>
        <ul>
          <li>Safety Policy</li>
          <li>Shipping Policies</li>
          <li>FAQ</li>
          <li>Terms and Condition</li>
          <li>Privacy Policy</li>
        </ul>
      </div>
      <div class="footer_bottom_4 w_100_lg">
        <form id="contact_form">
          <div class="d_f a_i_c j_c_s_b m_b_30">
            <h4 class="m_0">Enquiry Form</h4>
            <button class="theme_btn" type="submit" name="submit" id="submit">Submit</button>
          </div>
          <div class="col_1 gap_20">
            <div class="col_2 gap_15">
              <input type="text" placeholder="First Name" name="name" id="name">
              <input type="text" placeholder="Last Name" name="lname" id="lname">
            </div>
            <div class="col_2 gap_15">
              <input type="text" placeholder="Mobile Number" name="phone" id="phone">
              <input type="text" placeholder="Email Address" name="email" id="email">
            </div>
            <div class="col_1 gap_15">
              <textarea name="message" id="message" placeholder="Message"></textarea>
            </div>
          </div>
        </form>
      </div>
    </div>
    <div class="footer_logo">
      <a href="<?php echo get_site_url(); ?>" title="Chinkus">
        <img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/footer_logo.png" alt="Chinkus">
      </a>
    </div>
    <div class="footer_list">
      <ul>
        <li>Coconut Balls</li>
        <li>Gingerly Balls</li>
        <li>Peanut Balls Peanut Bar</li>
        <li>Peanut Chikki</li>
        <li>Peanut Stroke</li>
        <li>Protein Peanut Bar</li>
        <li>Peanut Crunch</li>
      </ul>
    </div>
  </div>

</footer>
<div class="copy_text">
  <div class="wrapper">
    <p>All Rights Reserved @ Chinkus sweets</p>
  </div>
</div>
<!--footer_section-->



<?php wp_footer(); ?>

<script type="text/javascript" src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/js/jquery_min.js"></script>
<script type="text/javascript" src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/js/bootstrap_min.js"></script>
<script type="text/javascript" src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/js/swiper_min.js"></script>
<script type="text/javascript" src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/js/modernizr_min.js"></script>
<script type="text/javascript" src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/js/mob_menu_min.js"></script>
<script type="text/javascript" src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/js/desk_menu_min.js"></script>
<script type="text/javascript" src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/js/sweet.js"></script>
<script type="text/javascript" src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/js/aos_min.js"></script>
<script type="text/javascript" src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/js/script.js"></script>

</body>

</html>
<?php

get_header(); ?>


<?php if (get_the_title() == "Cart") { ?>


	<div class="section_margin">
		<div class="wrapper">
			<div class="inner_head_text">
				<h1><?= the_title(); ?></h1>
			</div>
			<?php

			while (have_posts()) :

				the_post();

				the_content();

			endwhile;

			?>
		</div>
	</div>

<?php } elseif (get_the_title() == "Checkout") { ?>
<div class="section_margin">
		<div class="wrapper">
			<div class="inner_head_text">
				<h1><?= the_title(); ?></h1>
			</div>
			<?php

			while (have_posts()) :

				the_post();

				the_content();

			endwhile;

			?>
		</div>
	</div>

<?php } elseif (get_the_title() == "Blog") { ?>

	<div class="blog_section">
   <div class="wrapper">
	<div class="inner_head_text"><h1>Our Blog</h1></div>
	
      <div class="blog_section_top">
	  <div class="blog_section_top_left">
         <?php
            $args = array( 'numberposts' => '1' );
            $recent_posts = wp_get_recent_posts( $args );
            foreach( $recent_posts as $recent ){
            	
            	$url = get_the_post_thumbnail_url( $recent['ID'], 'full' );
            	$uploaddir = wp_upload_dir('2018/12');
            	?>
         <a href="<?php echo get_the_permalink($recent['ID']) ?>" title="<?php echo get_the_title($recent['ID']); ?>">
            <?php if($url) { ?>
					
					<img src="<?php echo $url;?>" alt="<?php echo get_the_title($recent['ID']); ?>" />
					
					<?php } else { ?> 
								
					 <img src="<?php echo esc_url(get_template_directory_uri());?>/assets/images/blog.jpg" alt="Harvee Blog" />	
									
				<?php } ?>
            <div class="blogdate">
               <h2><?php echo get_the_title($recent['ID']); ?></h2>
               <div class="post-date">
                  <span></span>
                  <?php echo get_the_time('F d,Y',$recent['ID']); ?>
               </div>
               <!--|
                  <div class="post-comment">
                  	<span></span>
                  	<?php //echo get_comments_number($recent['ID']); ?>
                  </div>-->
            </div>
         </a>
         <div class="post-desc">
            <p><?php echo substr(wp_strip_all_tags($recent['post_content']),0,200);?>...<a href="<?php echo get_the_permalink($recent['ID']) ?>" title="<?php echo get_the_title($recent['ID']); ?>"><span><font style="font-size:16px;color:#670F09;text-decoration:none;font-weight:bold">Read more</font></span></a></p>
            <?php 
               $catname = "";
               foreach((get_the_category($recent['ID'])) as $category){
               $category_link = get_category_link( $category->cat_ID );
               $catname .=  '<a href="'.esc_url( $category_link ).'" title="'.$category->name.'">'.$category->name.'</a> / ';
               }
               
               $catname = trim($catname);
               
               ?>
            <?php if($catname!=""){?>	
            <div class="post-cat">
               <span></span>
               <?php echo substr($catname,0,-1);?>
            </div>
            <?php } ?>
         </div>
         <?php
            }
            ?>
         <!--<h1><?php //if(is_home()): echo get_bloginfo( 'name' ); else: the_title(); endif;?></h1>-->
      </div>
	  <div class="blog_section_top_right">
      <?php include('sidebar.php');?>
	  </div>
	 </div>
      <div class="blog_section_bottom">
         <?php 
            global $post;
            
            $postsPerPage = 4;
            
            if($paged==0){
            $postOffset = 1;
            }
            else{
            $postOffset = $paged * $postsPerPage;
            }
            
            $myposts = get_posts( array(
            	'posts_per_page' => 4,
            	'offset'         => $postOffset,
             	'paged' 		 => $paged
            ));
            
            $totalposts = get_posts( array(
            	'posts_per_page' => -1,
            	'offset'         => 1
            ));
           
            if($myposts):
            
            foreach ( $myposts as $post ) : setup_postdata( $post );
             $url = get_the_post_thumbnail_url( $page->ID, 'full' );
            
            
            ?>
         <div class="col-2">
		 <div class="col-2-align">
            <a href="<?php the_permalink() ?>" title="<?php the_title() ?>">
                
			<?php if($url) { ?>
					
					<img src="<?php echo $url;?>" alt="<?php echo get_the_title($recent['ID']); ?>" />
					
					<?php } else { ?> 
								
					  <img src="<?php echo esc_url(get_template_directory_uri());?>/assets/images/blog.jpg" alt="Blog" />	
									
				<?php } ?>
               <div class="blogdate">
                  <h2><?php the_title(); ?></h2>
                  <div class="clear"></div>
                  <div class="post-date">
                     <span></span>
                     <?php the_time('F d,Y'); ?>
                  </div>
                  <!--|
                     <div class="post-comment">
                     	<span></span>
                     <?php //echo get_comments_number(); ?>
                     </div>-->
               </div>
            </a>
            <div class="post-desc">
               <p><?php echo substr(wp_strip_all_tags(get_the_excerpt(''),true),0,120);?>...<a href="<?php the_permalink() ?>" title="<?php the_title() ?>"><span><font style="font-size:16px;color:#670F09;text-decoration:none;font-weight:bold">Read more</font></span></a></p>
               <?php 
                  $catname = "";
                  foreach((get_the_category()) as $category){
                  $category_link = get_category_link( $category->cat_ID );
                  $catname .=  '<a href="'.esc_url( $category_link ).'" title="'.$category->name.'">'.$category->name.'</a> / ';
                  }
                  
                  $catname = trim($catname);
                  
                  ?>
               <?php if($catname!=""){?>	
               <div class="post-cat">
                  <span></span>
                  <?php echo substr($catname,0,-1);?>
               </div>
               <?php } ?>
            </div>
         </div>
		 </div>
         <?php endforeach; wp_reset_postdata();
            //endwhile; wp_reset_query();
            ?>
         <?php 
            $GLOBALS['wp_query']->max_num_pages = (count($totalposts) - 1)/$postsPerPage;
            
            the_posts_pagination( array(
            
            							'mid_size' => 2,
            
            							'prev_text' => __( 'Previous', 'textdomain' ),
            
            							'next_text' => __( 'Next', 'textdomain' ),
            
            						) ); ?>
         <?php wp_reset_postdata(); ?>
         <?php			
            else: 
            	echo 'Coming Soon...';
            
            endif; ?>
      </div>
   </div>
</div>

<?php } else { ?>
<div class="section_margin">
		<div class="wrapper">
			<div class="inner_head_text">
				<h1><?= the_title(); ?></h1>
			</div>
			<?php

			while (have_posts()) :

				the_post();

				the_content();

			endwhile;

			?>
		</div>
	</div>



<?php } ?>









<?php get_footer(); ?>
<?php
/*Template Name:Home*/
get_header(); ?>


<?php include get_template_directory() . '/banners.php'; ?>


<!--top_selling-->

<section class="section p_t_b_80 bg bg_img_one m_b_60 p_t_b_60_xl m_b_40_xl">
  <div class="wrapper">
    <div class="head_text two_side">
      <h1 class="white t_a_c">Top Selling Native Taste</h1>
    </div>
    <div class="top_selling o_h">
      <div class="swiper-wrapper">
        <div class="swiper-slide">
          <a href="javascript:void(0)" title="View Product">
            <div class="top_box">
              <div class="top_image">
                <img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/top/1.png" alt="">
              </div>
              <h4>Favourite Sweet Crunch</h4>
            </div>
          </a>
        </div>
        <div class="swiper-slide">
          <a href="javascript:void(0)" title="View Product">
            <div class="top_box">
              <div class="top_image">
                <img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/top/2.png" alt="">
              </div>
              <h4>Indulge In Sweetness</h4>
            </div>
          </a>
        </div>
        <div class="swiper-slide">
          <a href="javascript:void(0)" title="View Product">
            <div class="top_box">
              <div class="top_image">
                <img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/top/3.png" alt="">
              </div>
              <h4>Delicious Snacks</h4>
            </div>
          </a>
        </div>
        <div class="swiper-slide">
          <a href="javascript:void(0)" title="View Product">
            <div class="top_box">
              <div class="top_image">
                <img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/top/4.png" alt="">
              </div>
              <h4>Long Shelf Life</h4>
            </div>
          </a>
        </div>
        <div class="swiper-slide">
          <a href="javascript:void(0)" title="View Product">
            <div class="top_box">
              <div class="top_image">
                <img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/top/5.png" alt="">
              </div>
              <h4>Stringent quality checks</h4>
            </div>
          </a>
        </div>
        <div class="swiper-slide">
          <a href="javascript:void(0)" title="View Product">
            <div class="top_box">
              <div class="top_image">
                <img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/top/6.png" alt="">
              </div>
              <h4>Customized packing</h4>
            </div>
          </a>
        </div>
      </div>
    </div>
    <div class="top_selling_pagination"></div>
  </div>
</section>

<!--top_selling-->


<!--best_selling-->

<section class="best_selling section_margin">
  <div class="wrapper">
    <div class="head_text two_side">
      <h2 class="white t_a_c black">Best Sellers</h2>
    </div>
    <div class="col_4 gap_60_25 col_3_xl col_2_lg gap_40_15_xs col_1_xxs60">

      <?php
      $args = array(
        'posts_per_page' => 8,
        'product_cat' => 'Featured Products',
        'post_type' => 'product',
        'orderby' => 'title',
        'orderby' => 'date',
        'order' => 'DESC',
        'stock_status' => 'instock',
      );
      $products = new WP_Query($args);
      if ($products->have_posts()) {
        while ($products->have_posts()):
          $products->the_post();
          global $product;
          ?>


          <div class="col_1">
            <div class="best_selling_box">
              <div class="best_selling_image">
                <a href="<?= get_permalink($product->get_id()); ?>" title="<?= $product->get_name(); ?>"><?= woocommerce_get_product_thumbnail(); ?>
                  <?php if (!$product->managing_stock() && !$product->is_in_stock()) {
                    echo '<span class="stock out-of-stock"></span>';
                  } else if ($product->stock_status == "onbackorder") {
                    echo '<span class="backorders"></span>';
                  } ?>
                </a>
              </div>
              <div class="best_selling_content">
                <h4>
                  <?= $product->get_name(); ?>
                </h4>
                <h6>
                  <?php if ($product->is_type('variable')) {
                    $variations = $product->get_available_variations();
                    if ($variations) {
                      foreach ($variations as $variation) {
                        $attributes = $variation['attributes'];
                        if (!empty($attributes)) {
                          foreach ($attributes as $attribute_name => $attribute_value) {
                            $taxonomy = 'Gms';
                            $term = get_term_by('slug', $attribute_value, $taxonomy);
                            $attribute_label = isset($term->name) ? $term->name : $attribute_value;
                            echo $attribute_label . ' ' . wc_attribute_label($taxonomy);
                          }
                        }
                        break;
                      }
                    }
                  } ?>
                </h6>
                <h3><span class="price-sale">
                    <?php echo wc_price($product->get_price()); ?>
                  </span>
                  <?php if ($product->is_on_sale()) { ?> <span class="onstrike">
                      <?php if ($product->is_type('simple') && $product->get_price() != $product->get_regular_price()) {
                        echo wc_price($product->get_regular_price());
                      } elseif ($product->is_type('variable') && $product->get_price() != $product->get_variation_regular_price()) {
                        echo wc_price($product->get_variation_regular_price());
                      }
                  } ?>
                  </span>
                </h3>
                <a href="<?= get_permalink($product->get_id()); ?>" title="Add to Cart">
                  <button class="add_to_cart_btn"><img
                      src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/add_to_cart.png"
                      alt="Add to cart">Add to cart</button>
                </a>
              </div>
            </div>
          </div>
          <?php
        endwhile;
        wp_reset_query();
      }
      ?>

    </div>
  </div>
</section>

<!--best_selling-->


<!--promobanner_section-->

<section class="promobanner_section section_margin">
  <div class="promobanner_align d_f j_c_s_b f_d_c_md gap_10_md">
    <div class="promobanner_left bg_hover_black w_100_md">
      <img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/promo1.png"
        alt="Healthy Protein Peanut bar">
      <div class="promobanner_text d_f f_d_c gap_20">
        <h2>Healthy<br /> Protein<br /> Peanut bar</h2>
        <a href="javascript:void(0)" title="Buy Now">
          <button class="theme_btn">Buy Now</button>
        </a>
      </div>
    </div>
    <div class="promobanner_right bg_hover_black w_100_md">
      <img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/promo2.png"
        alt="Legends of Traditional Sweets">
      <div class="promobanner_text d_f f_d_c gap_20">
        <h2>Legends of<br /> Traditional<br /> Sweets</h2>
        <a href="javascript:void(0)" title="Buy Now">
          <button class="theme_btn">Buy Now</button>
        </a>
      </div>
    </div>
  </div>
</section>

<!--promobanner_section-->


<!--aboutus_section-->

<section class="aboutus_section section_margin">
  <div class="wrapper">
    <div class="col_1 gap_120">
      <div class="d_f a_i_c j_c_s_b aboutus_align f_d_c_lg gap_45_lg">
        <div class="d_i_b w_45 aboutus_left w_100_lg">
          <div class="head_text right_side">
            <h2>About Us</h2>
          </div>
          <p>Our Chinku Sweets is the leading trader of premium quality sweets in Thalassery, Kerala. We offer a wide
            range of authentic peanut products and sweet balls with brand name “Chinku’. Our company is renowned for
            their consistently high-quality sweet that includes Coconut Balls, Gingerly Balls, Peanut Balls Peanut Bar,
            Peanut Chikki, Peanut Stroke, Protein Peanut Bar and Peanut Crunch. Our offered delicious sweets and bars
            recipe is made by the best Kerala chefs to ensure the authentic taste for our esteemed customers.
            Established in the year 1990 by the dynamic leadership of Mr. K.C Madhu in Thalassery, Kerala, our company
            scaled reputable position in the market.</p>
        </div>
        <div class="d_i_b w_45 aboutus_right w_100_lg">
          <img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/about1.png" alt="About Us">
        </div>
      </div>
      <div class="d_f a_i_c j_c_s_b f_d_r_r aboutus_align f_d_c_lg gap_45">
        <div class="d_i_b w_45 aboutus_left w_100_lg">
          <div class="head_text right_side">
            <h2>Why Us</h2>
          </div>
          <p>Our manufacturing facility is equipped with food-grade quality state of art modern machinery. We take
            utmost care of the quality of our products, which are checked by our quality team at every stage of product
            flow. Quality being the main concern, we rely on the latest quality control procedures and mechanisms. Every
            product undergoes stringent quality checks before being exported. Our team of experts takes care to preserve
            original taste of the product, longer shelf life, accurate composition and high nutritional values.</p>
          <ul>
            <li>Premium quality raw materials</li>
            <li>Long shelf life</li>
            <li>Qualified experts team</li>
            <li>Customized packing</li>
            <li>Stringent quality checks</li>
            <li>Flexible modes of payments</li>
            <li>Timely delivery</li>
          </ul>
        </div>
        <div class="d_i_b w_45 aboutus_right w_100_lg">
          <img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/about2.png" alt="About Us">
        </div>
      </div>
    </div>
  </div>
</section>

<!--aboutus_section-->


<!--outclients_section-->

<section class="outclients_section section_padding bg_light">
  <div class="wrapper">
    <div class="head_text two_side">
      <h2>Our Clients</h2>
    </div>
  </div>
  <div class="clients_slide">
    <div class="swiper-wrapper">
      <div class="swiper-slide">
        <div class="clients_box">
          <img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/c1.png" alt="clients">
        </div>
      </div>
      <div class="swiper-slide">
        <div class="clients_box">
          <img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/c1.png" alt="clients">
        </div>
      </div>
      <div class="swiper-slide">
        <div class="clients_box">
          <img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/c1.png" alt="clients">
        </div>
      </div>
      <div class="swiper-slide">
        <div class="clients_box">
          <img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/c1.png" alt="clients">
        </div>
      </div>
      <div class="swiper-slide">
        <div class="clients_box">
          <img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/c1.png" alt="clients">
        </div>
      </div>
      <div class="swiper-slide">
        <div class="clients_box">
          <img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/c1.png" alt="clients">
        </div>
      </div>
      <div class="swiper-slide">
        <div class="clients_box">
          <img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/c1.png" alt="clients">
        </div>
      </div>
    </div>
  </div>
</section>

<!--outclients_section-->


<!--testimonials_section-->

<section class="testimonials_section section_margin">
  <div class="wrapper">
    <div class="head_text two_side">
      <h2>Testimonials</h2>
    </div>
  </div>
  <div class="testimonials_slide">
    <div class="swiper-wrapper">
      <div class="swiper-slide">
        <div class="testimonials_box">
          <div class="rating">
            <i class="fa fa-star" aria-hidden="true"></i>
            <i class="fa fa-star" aria-hidden="true"></i>
            <i class="fa fa-star" aria-hidden="true"></i>
            <i class="fa fa-star" aria-hidden="true"></i>
            <i class="fa fa-star" aria-hidden="true"></i>
          </div>
          <p>Received all items yesterday. Everything packed well and tasted good and fresh. Appreciate the quality of
            product very much. Very fresh and tasty exactly like home made. Thank you so much.</p>
          <div class="t_ptofile">
            <div class="t_image">
              <img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/testi.png"
                alt="Mr.Rakesh Sharma">
            </div>
            <div class="t_text">
              <h4>Mr.Rakesh Sharma</h4>
              <h6>Retail Shopper</h6>
            </div>
          </div>
        </div>
      </div>
      <div class="swiper-slide">
        <div class="testimonials_box">
          <div class="rating">
            <i class="fa fa-star" aria-hidden="true"></i>
            <i class="fa fa-star" aria-hidden="true"></i>
            <i class="fa fa-star" aria-hidden="true"></i>
            <i class="fa fa-star" aria-hidden="true"></i>
            <i class="fa fa-star" aria-hidden="true"></i>
          </div>
          <p>Received all items yesterday. Everything packed well and tasted good and fresh. Appreciate the quality of
            product very much. Very fresh and tasty exactly like home made. Thank you so much.</p>
          <div class="t_ptofile">
            <div class="t_image">
              <img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/testi.png"
                alt="Mr.Rakesh Sharma">
            </div>
            <div class="t_text">
              <h4>Mr.Rakesh Sharma</h4>
              <h6>Retail Shopper</h6>
            </div>
          </div>
        </div>
      </div>
      <div class="swiper-slide">
        <div class="testimonials_box">
          <div class="rating">
            <i class="fa fa-star" aria-hidden="true"></i>
            <i class="fa fa-star" aria-hidden="true"></i>
            <i class="fa fa-star" aria-hidden="true"></i>
            <i class="fa fa-star" aria-hidden="true"></i>
            <i class="fa fa-star" aria-hidden="true"></i>
          </div>
          <p>Received all items yesterday. Everything packed well and tasted good and fresh. Appreciate the quality of
            product very much. Very fresh and tasty exactly like home made. Thank you so much.</p>
          <div class="t_ptofile">
            <div class="t_image">
              <img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/testi.png"
                alt="Mr.Rakesh Sharma">
            </div>
            <div class="t_text">
              <h4>Mr.Rakesh Sharma</h4>
              <h6>Retail Shopper</h6>
            </div>
          </div>
        </div>
      </div>
      <div class="swiper-slide">
        <div class="testimonials_box">
          <div class="rating">
            <i class="fa fa-star" aria-hidden="true"></i>
            <i class="fa fa-star" aria-hidden="true"></i>
            <i class="fa fa-star" aria-hidden="true"></i>
            <i class="fa fa-star" aria-hidden="true"></i>
            <i class="fa fa-star" aria-hidden="true"></i>
          </div>
          <p>Received all items yesterday. Everything packed well and tasted good and fresh. Appreciate the quality of
            product very much. Very fresh and tasty exactly like home made. Thank you so much.</p>
          <div class="t_ptofile">
            <div class="t_image">
              <img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/testi.png"
                alt="Mr.Rakesh Sharma">
            </div>
            <div class="t_text">
              <h4>Mr.Rakesh Sharma</h4>
              <h6>Retail Shopper</h6>
            </div>
          </div>
        </div>
      </div>
      <div class="swiper-slide">
        <div class="testimonials_box">
          <div class="rating">
            <i class="fa fa-star" aria-hidden="true"></i>
            <i class="fa fa-star" aria-hidden="true"></i>
            <i class="fa fa-star" aria-hidden="true"></i>
            <i class="fa fa-star" aria-hidden="true"></i>
            <i class="fa fa-star" aria-hidden="true"></i>
          </div>
          <p>Received all items yesterday. Everything packed well and tasted good and fresh. Appreciate the quality of
            product very much. Very fresh and tasty exactly like home made. Thank you so much.</p>
          <div class="t_ptofile">
            <div class="t_image">
              <img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/testi.png"
                alt="Mr.Rakesh Sharma">
            </div>
            <div class="t_text">
              <h4>Mr.Rakesh Sharma</h4>
              <h6>Retail Shopper</h6>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  </div>
  <div class="wrapper">
    <div class="d_f a_i_c j_c_c m_t_35">
      <a href="javascript:void(0)" title="View All">
        <button class="theme_btn">View All</button>
      </a>
    </div>
  </div>
</section>

<!--testimonials_section-->


<!--blog_section-->

<section class="blog_section section_padding m_b_0 bg_light">
  <div class="wrapper">
    <div class="head_text two_side">
      <h2>Blog</h2>
    </div>
    <div class="blog_slide">
      <div class="swiper-wrapper">
        <div class="swiper-slide">
          <div class="blog_box">
            <div class="blod_image">
              <img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/blog.png" alt="Blog">
            </div>
            <div class="blog_content">
              <div class="blog_date"><span>11 Jun 2022</span><span>2min read</span></div>
              <h4>Tales of Peanut bar</h4>
              <p>Peanut Chikki is a traditional Indian sweet that has been enjoyed for generations. It's made by
                roasting peanuts..</p>
              <a href="javascript:void(0)" title="Continue reading" class="read_btn">Continue reading</a>
            </div>
          </div>
        </div>
        <div class="swiper-slide">
          <div class="blog_box">
            <div class="blod_image">
              <img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/blog.png" alt="Blog">
            </div>
            <div class="blog_content">
              <div class="blog_date"><span>11 Jun 2022</span><span>2min read</span></div>
              <h4>Tales of Peanut bar</h4>
              <p>Peanut Chikki is a traditional Indian sweet that has been enjoyed for generations. It's made by
                roasting peanuts..</p>
              <a href="javascript:void(0)" title="Continue reading" class="read_btn">Continue reading</a>
            </div>
          </div>
        </div>
        <div class="swiper-slide">
          <div class="blog_box">
            <div class="blod_image">
              <img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/blog.png" alt="Blog">
            </div>
            <div class="blog_content">
              <div class="blog_date"><span>11 Jun 2022</span><span>2min read</span></div>
              <h4>Tales of Peanut bar</h4>
              <p>Peanut Chikki is a traditional Indian sweet that has been enjoyed for generations. It's made by
                roasting peanuts..</p>
              <a href="javascript:void(0)" title="Continue reading" class="read_btn">Continue reading</a>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="blog_slide_pagination"></div>
  </div>
</section>

<!--blog_section-->





<?php
get_footer();
?>
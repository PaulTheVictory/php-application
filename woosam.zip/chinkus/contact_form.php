<?php
error_reporting(0);
date_default_timezone_set("Asia/Calcutta");
$to = 'paulthevictory@gmail.com'; 

$subject = "Contact Form";
$headers = "From: no-reply@chinkus.com\r\n";
$headers .= "Reply-To:  paulthevictory@gmail.com\r\n";
$headers .= "BCC: paulthevictory@gmail.com \r\n";
$headers .= "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";

$msg = "<table width=70% border=0 cellspacing=0 cellpadding=0>
    <tr>
      <td valign=top>Name</td>
      <td valign=top>:</td>
      <td valign=top>" . $_POST['name'] . " " . $_POST['lname'] . "</td>
    </tr>
    <tr>
      <td valign=top>Phone Number</td>
      <td valign=top>:</td>
      <td valign=top>" . $_POST['phone'] . "</td>
    </tr>		 
     <tr>
      <td valign=top>Email Address</td>
      <td valign=top>:</td>
      <td valign=top>" . $_POST['email'] . "</td>
    </tr>
    <tr>
      <td valign=top>Message</td>
      <td valign=top>:</td>
      <td valign=top>" . $_POST['message'] . "</td>
    </tr>
  </table>";

$result = mail($to, $subject, $msg, $headers);
if (!$result) {
  echo json_encode(array(0=>'success'));
} else {
  echo json_encode(array(0=>'fail'));

}

<?php

/**
 * The template for displaying the header
 *
 * Displays all of the head element and everything up until the "site-content" div.
 *
 * @package WordPress
 * @subpackage Twenty_Sixteen
 * @since Twenty Sixteen 1.0
 */
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?> class="no-js">

<head>
	<meta charset="<?php bloginfo('charset'); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1" />
	<link rel="profile" href="http://gmpg.org/xfn/11">
	<?php if (is_singular() && pings_open(get_queried_object())) : ?>
		<link rel="pingback" href="<?php echo esc_url(get_bloginfo('pingback_url')); ?>">
		<?php endif; ?>
	<?php
	$url = home_url($wp->request);
	$meta = get_post_meta(get_the_ID(), '', true);
	$title = $meta['Title'][0]? $meta['Title'][0]:"";
	$description = $meta['Description'][0]? $meta['Description'][0]:"";
	$keyword = $meta['Keyword'][0]? $meta['Keyword'][0]:"";
	if($title!="") {echo '<title>'.$title.'</title>'.PHP_EOL;}
	else{
	?>
	<title><?php wp_title('|', true, 'right'); ?> <?php bloginfo('name'); ?></title>
	<?php
	}
	if($description!="") echo '<meta name="description" content="'.$description.'" />'.PHP_EOL;
	if($keyword!="") echo '<meta name="keywords" content="'.$keyword.'" />'.PHP_EOL;
	?>

	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta http-equiv="Cache-control" content="public" />
	<link rel="canonical" href="" />
	<!-- <?php echo esc_url(get_template_directory_uri()); ?> -->
	<link rel="stylesheet" type="text/css" href="<?php echo esc_url(get_template_directory_uri()); ?>/assets/css/bootstrap_min.css" />
	<?php wp_head(); ?>
	<link rel="stylesheet" type="text/css" href="<?php echo esc_url(get_template_directory_uri()); ?>/assets/css/fafa_icon_min.css" />
	<link rel="stylesheet" type="text/css" href="<?php echo esc_url(get_template_directory_uri()); ?>/assets/css/animate_min.css" />
	<link rel="stylesheet" type="text/css" href="<?php echo esc_url(get_template_directory_uri()); ?>/assets/css/aos_min.css" />
	<link rel="stylesheet" type="text/css" href="<?php echo esc_url(get_template_directory_uri()); ?>/assets/css/gallery_min.css" />
	<link rel="stylesheet" type="text/css" href="<?php echo esc_url(get_template_directory_uri()); ?>/assets/css/swiper_min.css" />
	<link rel="stylesheet" type="text/css" href="<?php echo esc_url(get_template_directory_uri()); ?>/assets/css/mob_menu_min.css" />
	<link rel="stylesheet" type="text/css" href="<?php echo esc_url(get_template_directory_uri()); ?>/assets/css/sweet.css" />
	<link rel="stylesheet" type="text/css" href="<?php echo esc_url(get_template_directory_uri()); ?>/assets/css/master_css.css" />
	<!-- <link rel="stylesheet" type="text/css" href="<?php echo esc_url(get_template_directory_uri()); ?>/style.css" /> -->
	<link rel="stylesheet" type="text/css" href="<?php echo esc_url(get_template_directory_uri()); ?>/assets/css/style_media.css" />


</head>

<body <?php body_class(); ?>>


	<header class="header">
		<div class="section bg">
			<div class="wrapper">
				<div class="d_f a_i_c f_w_w j_c_s_b d_n_lg">
					<div class="w_f_c d_i_b">
						<ul class="d_f a_i_c gap_20">
							<li class="fa_icon white"><i class="icon h_phone"></i>+91 9876543219</li>
							<li class="fa_icon white"><i class="icon h_call"></i>0422 2546978</li>
						</ul>
					</div>
					<div class="d_f w_f_c m_a_0_a_a ">
						<ul class="d_f a_i_c f_w_w gap_20">
							<li class="fa_icon white"><i class="icon h_delivery"></i>Free Shipping for order above Rs.1500</li>
							<li><button class="theme_btn_box">Click for Bulk Enquiry</button></li>
						</ul>
					</div>
				</div>
			</div>
		</div>
		<div class="section p_t_b_25 p_t_b_15_xs">
			<div id="navbar">
				<div class="wrapper">
					<div class="d_f a_i_c j_c_s_b gap_20 gap_10_xxs">
						<div class="w_f_c">
							<a href="<?php echo get_site_url(); ?>" title="Chinkus">
								<img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/logo.png" alt="Chinkus" class="logo">
							</a>
						</div>
						<div class="w_f_c">
							<div id="cssmenu">
								<?php wp_nav_menu(array('theme_location' => 'primary')); ?>
							</div>
						</div>
						<div class="w_f_c d_f a_i_c gap_15 gap_10_xs mob_padding p_r">
							<a href="javascript:void(0)" title="Search" data-bs-toggle="modal" data-bs-target="#my_search">
								<button class="icon_button search_btn"></button>
							</a>
							<a href="<?php echo get_permalink(get_option('woocommerce_myaccount_page_id')); ?>" title="<?= is_user_logged_in() ? 'My Account' : "Login"; ?>">
								<button class="icon_button user_btn"></button>
							</a>
							<a href="<?= wc_get_cart_url(); ?>" title="Cart" class="cart-btn">
								<button class="btn_round b_icon">
									<div class="cart_count">
										<span class="header-cart-count"><?= WC()->cart->get_cart_contents_count(); ?></span>
									</div>
									<div class="sm_none">Cart</div>
								</button>
							</a>

							<div class="mobile_menu">
								<div id="dl-menu" class="dl-menuwrapper">
									<button class="dl-trigger"></button>
									<?php if (function_exists('wp_nav_menu'))
										wp_nav_menu(
											array(
												'theme_location' => 'primary',
												'container' => '',
												'depth' => 0,
												'menu_id' => '',
												'menu_class' => 'dl-menu',
												'dropdown_class' => '',
											)
										);
									?>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</header>

	<div class="modal fade slow" id="my_search">
		<div class="modal-dialog">
			<div class="modal-content">

				<!-- Modal Header -->
				<div class="modal-header">
					<h4 class="modal-title">Search Product</h4>
					<button type="button" class="btn-close" data-bs-dismiss="modal"></button>
				</div>

				<!-- Modal body -->
				<div class="modal-body min_h_100">
					<?= do_shortcode('[fibosearch]'); ?>
				</div>

				<!-- Modal footer -->
				<div class="modal-footer">
					<button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
				</div>

			</div>
		</div>
	</div>
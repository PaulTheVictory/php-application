<?php
/*Template Name:About Us*/
get_header();
?>

<!--slider_section-->

<?php include get_template_directory() . '/banners.php'; ?>

<!--slider_section-->
<div class="inner_bottom"></div>
<!--aboutus_section-->

<section class="aboutus_section section_margin">
  <div class="wrapper">
    <div class="col_1 gap_120">
      <div class="d_f a_i_c j_c_s_b aboutus_align f_d_c_lg gap_45_lg">
        <div class="d_i_b w_45 aboutus_left w_100_lg">
          <div class="head_text right_side">
            <h2>About Us</h2>
          </div>
          <p>Our Chinku Sweets is the leading trader of premium quality sweets in Thalassery, Kerala. We offer a wide range of authentic peanut products and sweet balls with brand name “Chinku’. Our company is renowned for their consistently high-quality sweet that includes Coconut Balls, Gingerly Balls, Peanut Balls Peanut Bar, Peanut Chikki, Peanut Stroke, Protein Peanut Bar and Peanut Crunch. Our offered delicious sweets and bars recipe is made by the best Kerala chefs to ensure the authentic taste for our esteemed customers. Established in the year 1990 by the dynamic leadership of Mr. K.C Madhu in Thalassery, Kerala, our company scaled reputable position in the market.</p>
        </div>
        <div class="d_i_b w_45 aboutus_right w_100_lg">
          <img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/about1.png" alt="About Us">
        </div>
      </div>
      <div class="d_f a_i_c j_c_s_b f_d_r_r aboutus_align f_d_c_lg gap_45">
        <div class="d_i_b w_45 aboutus_left w_100_lg">
          <div class="head_text right_side">
            <h2>Why Us</h2>
          </div>
          <p>Our manufacturing facility is equipped with food-grade quality state of art modern machinery. We take utmost care of the quality of our products, which are checked by our quality team at every stage of product flow. Quality being the main concern, we rely on the latest quality control procedures and mechanisms. Every product undergoes stringent quality checks before being exported. Our team of experts takes care to preserve original taste of the product, longer shelf life, accurate composition and high nutritional values.</p>
          <ul>
            <li>Premium quality raw materials</li>
            <li>Long shelf life</li>
            <li>Qualified experts team</li>
            <li>Customized packing</li>
            <li>Stringent quality checks</li>
            <li>Flexible modes of payments</li>
            <li>Timely delivery</li>
          </ul>
        </div>
        <div class="d_i_b w_45 aboutus_right w_100_lg">
          <img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/about2.png" alt="About Us">
        </div>
      </div>
    </div>
  </div>
</section>

<!--aboutus_section-->



<!--counter_section-->

<section class="counter_section section_margin">
  <div class="wrapper">
    <div class="d_f a_i_c j_c_s_b aboutus_align f_d_c_lg gap_45_lg">
      <div class="d_i_b w_45 aboutus_left w_100_lg">
        <div class="head_text right_side">
          <h2>About Us</h2>
        </div>
        <p>Located in Thalassery, Kerala, we have progressed with the team of experts who very well understands the changing tastes and needs of our consumers. We have cherished our consumers by giving them authentic Kerala sweets that are a best substitute to the junk foods and the chocolates, established by virtue of their quality, nutritional value and availability. All our products and services are in tune with the international rules, regulations & standards. Leveraging on our seamless operations and client centric approach placed us in the upper echelons of the industry. The delicious authentic taste of our sweets are being appreciated in the market that its demand has been increased phenomenally.</p>
      </div>
      <div class="d_i_b w_45 aboutus_right w_100_lg">
        <ul>
          <li>
            <div class="counter_box">
              <img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/aboutus/c1.png" alt="Kg of Seeds & nuts used">
              <h4 class="plus">200</h4>
              <p>Kg of Seeds&
                nuts used</p>
            </div>
          </li>
          <li>
            <div class="counter_box">
              <img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/aboutus/c2.png" alt="Farmer
community">
              <h4 class="plus">100</h4>
              <p>Farmer
                community</p>
            </div>
          </li>
          <li>
            <div class="counter_box">
              <img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/aboutus/c3.png" alt="Years of
Excellence">
              <h4 class="plus">15</h4>
              <p>Years of
                Excellence</p>
            </div>
          </li>
          <li>
            <div class="counter_box">
              <img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/aboutus/c4.png" alt="Satisfied
Customer">
              <h4 class="plus">500</h4>
              <p>Satisfied
                Customer</p>
            </div>
          </li>
        </ul>
      </div>
    </div>
  </div>
</section>

<!--counter_section-->


<!--milestone_section-->

<section class="milestone_section">
  <div class="wrapper">
    <ul>
      <li>
        <div class="mile_box">
          <div class="mile">1990</div>
          <h4>Year of Establishment</h4>
        </div>
      </li>
      <li>
        <div class="mile_box">
          <div class="mile">2000</div>
          <h4>Year of
            Factory</h4>
        </div>
      </li>
      <li>
        <div class="mile_box">
          <div class="mile">2010</div>
          <h4>Year of
            Selling Retail
            products</h4>
        </div>
      </li>
      <li>
        <div class="mile_box">
          <div class="mile">2020</div>
          <h4>Year of
            Emerging in Digital
            Presence</h4>
        </div>
      </li>
    </ul>
    <div class="y_video">
      <img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/aboutus/video.png" alt="video">
    </div>
  </div>
</section>

<!--milestone_section-->


















<?php
/*Template Name:About Us*/
get_footer(); ?>
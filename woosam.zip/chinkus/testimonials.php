<?php
/*Template Name:Testimonials*/
get_header();
?>
<!--slider_section-->

<?php include get_template_directory() . '/banners.php'; ?>

<!--slider_section-->
<div class="inner_bottom"></div>

<div class="section_margin testimonials_section">
  <div class="wrapper">
    <div class="head_text two_side">
      <h1>Testimonials</h1>
    </div>
    <ul class="col_3 gap_20 col_2_lg col_1_md">
      <li class="col_1">
        <div class="testimonials_box">
          <div class="rating">
            <i class="fa fa-star" aria-hidden="true"></i>
            <i class="fa fa-star" aria-hidden="true"></i>
            <i class="fa fa-star" aria-hidden="true"></i>
            <i class="fa fa-star" aria-hidden="true"></i>
            <i class="fa fa-star" aria-hidden="true"></i>
          </div>
          <p>Received all items yesterday. Everything packed well and tasted good and fresh. Appreciate the quality of product very much. Very fresh and tasty exactly like home made. Thank you so much.</p>
          <div class="t_ptofile">
            <div class="t_image">
              <img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/testi.png" alt="Mr.Rakesh Sharma">
            </div>
            <div class="t_text">
              <h4>Mr.Rakesh Sharma</h4>
              <h6>Retail Shopper</h6>
            </div>
          </div>
        </div>
      </li>
      <li class="col_1">
        <div class="testimonials_box">
          <div class="rating">
            <i class="fa fa-star" aria-hidden="true"></i>
            <i class="fa fa-star" aria-hidden="true"></i>
            <i class="fa fa-star" aria-hidden="true"></i>
            <i class="fa fa-star" aria-hidden="true"></i>
            <i class="fa fa-star" aria-hidden="true"></i>
          </div>
          <p>Received all items yesterday. Everything packed well and tasted good and fresh. Appreciate the quality of product very much. Very fresh and tasty exactly like home made. Thank you so much.</p>
          <div class="t_ptofile">
            <div class="t_image">
              <img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/testi.png" alt="Mr.Rakesh Sharma">
            </div>
            <div class="t_text">
              <h4>Mr.Rakesh Sharma</h4>
              <h6>Retail Shopper</h6>
            </div>
          </div>
        </div>
      </li>
      <li class="col_1">
        <div class="testimonials_box">
          <div class="rating">
            <i class="fa fa-star" aria-hidden="true"></i>
            <i class="fa fa-star" aria-hidden="true"></i>
            <i class="fa fa-star" aria-hidden="true"></i>
            <i class="fa fa-star" aria-hidden="true"></i>
            <i class="fa fa-star" aria-hidden="true"></i>
          </div>
          <p>Received all items yesterday. Everything packed well and tasted good and fresh. Appreciate the quality of product very much. Very fresh and tasty exactly like home made. Thank you so much.</p>
          <div class="t_ptofile">
            <div class="t_image">
              <img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/testi.png" alt="Mr.Rakesh Sharma">
            </div>
            <div class="t_text">
              <h4>Mr.Rakesh Sharma</h4>
              <h6>Retail Shopper</h6>
            </div>
          </div>
        </div>
      </li>
      <li class="col_1">
        <div class="testimonials_box">
          <div class="rating">
            <i class="fa fa-star" aria-hidden="true"></i>
            <i class="fa fa-star" aria-hidden="true"></i>
            <i class="fa fa-star" aria-hidden="true"></i>
            <i class="fa fa-star" aria-hidden="true"></i>
            <i class="fa fa-star" aria-hidden="true"></i>
          </div>
          <p>Received all items yesterday. Everything packed well and tasted good and fresh. Appreciate the quality of product very much. Very fresh and tasty exactly like home made. Thank you so much.</p>
          <div class="t_ptofile">
            <div class="t_image">
              <img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/testi.png" alt="Mr.Rakesh Sharma">
            </div>
            <div class="t_text">
              <h4>Mr.Rakesh Sharma</h4>
              <h6>Retail Shopper</h6>
            </div>
          </div>
        </div>
      </li>
      <li class="col_1">
        <div class="testimonials_box">
          <div class="rating">
            <i class="fa fa-star" aria-hidden="true"></i>
            <i class="fa fa-star" aria-hidden="true"></i>
            <i class="fa fa-star" aria-hidden="true"></i>
            <i class="fa fa-star" aria-hidden="true"></i>
            <i class="fa fa-star" aria-hidden="true"></i>
          </div>
          <p>Received all items yesterday. Everything packed well and tasted good and fresh. Appreciate the quality of product very much. Very fresh and tasty exactly like home made. Thank you so much.</p>
          <div class="t_ptofile">
            <div class="t_image">
              <img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/testi.png" alt="Mr.Rakesh Sharma">
            </div>
            <div class="t_text">
              <h4>Mr.Rakesh Sharma</h4>
              <h6>Retail Shopper</h6>
            </div>
          </div>
        </div>
      </li>
      <li class="col_1">
        <div class="testimonials_box">
          <div class="rating">
            <i class="fa fa-star" aria-hidden="true"></i>
            <i class="fa fa-star" aria-hidden="true"></i>
            <i class="fa fa-star" aria-hidden="true"></i>
            <i class="fa fa-star" aria-hidden="true"></i>
            <i class="fa fa-star" aria-hidden="true"></i>
          </div>
          <p>Received all items yesterday. Everything packed well and tasted good and fresh. Appreciate the quality of product very much. Very fresh and tasty exactly like home made. Thank you so much.</p>
          <div class="t_ptofile">
            <div class="t_image">
              <img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/testi.png" alt="Mr.Rakesh Sharma">
            </div>
            <div class="t_text">
              <h4>Mr.Rakesh Sharma</h4>
              <h6>Retail Shopper</h6>
            </div>
          </div>
        </div>
      </li>
    </ul>
  </div>
</div>








<div class="inner_bottom"></div>







<?php
/*Template Name:Testimonials*/
get_footer(); ?>
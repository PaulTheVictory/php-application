jQuery(document).ready(function ($) {
  // Swiper: Home Banner Slider
  new Swiper(".banner_slider", {
    loop: false,
    speed: 1500,
    slidesPerView: 1,
    effect: "slide", // coverflow cube fade
    paginationClickable: true,
    spaceBetween: 0,
    autoplay: {
      delay: 10000,
      disableOnInteraction: false,
    },
    pagination: {
      el: ".home_slider_pagination",
      clickable: true,
    },
  });
  // Swiper: Home Top Selling
  new Swiper(".top_selling", {
    loop: false,
    speed: 1000,
    slidesPerView: 6,
    effect: "slide", // coverflow cube fade
    paginationClickable: true,
    spaceBetween: 30,
    autoplay: {
      delay: 10000,
      disableOnInteraction: false,
    },
    watchSlidesProgress: true,
    pagination: {
      el: ".top_selling_pagination",
      clickable: true,
    },
    breakpoints: {
      1920: {
        slidesPerView: 6,
        spaceBetween: 30,
      },
      1200: {
        slidesPerView: 6,
        spaceBetween: 30,
      },
      992: {
        slidesPerView: 4,
        spaceBetween: 20,
      },
      768: {
        slidesPerView: 3,
        spaceBetween: 20,
      },
      580: {
        slidesPerView: 3,
        spaceBetween: 20,
      },
      320: {
        slidesPerView: 2,
        spaceBetween: 20,
      },
    },
  });
  // Swiper: Home Top Selling
  new Swiper(".clients_slide", {
    loop: true,
    centeredSlides: true,
    speed: 1000,
    slidesPerView: 7.7,
    effect: "slide", // coverflow cube fade
    paginationClickable: true,
    spaceBetween: 45,
    autoplay: {
      delay: 10000,
      disableOnInteraction: false,
    },
    watchSlidesProgress: true,
    pagination: {
      el: ".home_top_pagination",
      clickable: true,
    },
    breakpoints: {
      1920: {
        slidesPerView: 7.7,
        spaceBetween: 45,
      },
      1200: {
        slidesPerView: 7.7,
        spaceBetween: 45,
      },
      992: {
        slidesPerView: 5.8,
        spaceBetween: 25,
      },
      768: {
        slidesPerView: 4.5,
        spaceBetween: 25,
      },
      580: {
        slidesPerView: 3.5,
        spaceBetween: 25,
      },
      320: {
        slidesPerView: 2.7,
        spaceBetween: 20,
      },
    },
  });

  // Swiper: Home Top Selling
  new Swiper(".testimonials_slide", {
    loop: true,
    centeredSlides: true,
    speed: 1000,
    slidesPerView: 3.7,
    effect: "slide", // coverflow cube fade
    paginationClickable: true,
    spaceBetween: 10,
    autoplay: {
      delay: 10000,
      disableOnInteraction: false,
    },
    watchSlidesProgress: true,
    pagination: {
      el: ".home_top_pagination",
      clickable: true,
    },
    breakpoints: {
      1920: {
        slidesPerView: 3.7,
        spaceBetween: 10,
      },
      1200: {
        slidesPerView: 3.7,
        spaceBetween: 10,
      },
      992: {
        slidesPerView: 2.5,
        spaceBetween: 10,
      },
      768: {
        slidesPerView: 1.5,
        spaceBetween: 10,
      },
      580: {
        slidesPerView: 1.5,
        spaceBetween: 10,
      },
      320: {
        slidesPerView: 1,
        spaceBetween: 10,
      },
    },
  });
  // Swiper: Home Top Selling
  new Swiper(".blog_slide", {
    loop: false,
    speed: 1000,
    slidesPerView: 3,
    effect: "slide", // coverflow cube fade
    paginationClickable: true,
    spaceBetween: 25,
    autoplay: {
      delay: 10000,
      disableOnInteraction: false,
    },
    watchSlidesProgress: true,
    pagination: {
      el: ".blog_slide_pagination",
      clickable: true,
    },
    breakpoints: {
      1920: {
        slidesPerView: 3,
        spaceBetween: 25,
      },
      1200: {
        slidesPerView: 3,
        spaceBetween: 25,
      },
      992: {
        slidesPerView: 2,
        spaceBetween: 25,
      },
      768: {
        slidesPerView: 2,
        spaceBetween: 20,
      },
      320: {
        slidesPerView: 1,
        parallax: false,
        spaceBetween: 0,
      },
    },
  });
  $(function () {
    $("#dl-menu").dlmenu({
      animationClasses: {
        classin: "dl-animate-in-5",
        classout: "dl-animate-out-5",
      },
    });
  });

  //

  $(".dl-menuwrapper li a").click(function (e) {
    $("#dl-menu").dlmenu("closeMenu");
  });

  $(".flex-control-thumbs").addClass("woo_slider");
  $(".woo_slider").wrapInner('<div class="swiper-wrapper"></div>');
  $(".woo_slider li").addClass("swiper-slide");
  // Swiper: Home Top Selling
  new Swiper(".woo_slider", {
    loop: false,
    speed: 1000,
    slidesPerView: 4,
    effect: "slide", // coverflow cube fade
    paginationClickable: true,
    spaceBetween: 15,
    autoplay: {
      delay: 10000,
      disableOnInteraction: false,
    },
    watchSlidesProgress: true,
    // pagination: {
    //   el: ".woo_slider_pagination",
    //   clickable: true,
    // },
    navigation: {
      nextEl: ".woo_slider_next",
      prevEl: ".woo_slider_prev",
    },
    breakpoints: {
      1920: {
        slidesPerView: 4,
        spaceBetween: 15,
      },
      1200: {
        slidesPerView: 4,
        spaceBetween: 15,
      },
      992: {
        slidesPerView: 3,
        spaceBetween: 20,
      },
      768: {
        slidesPerView: 3,
        spaceBetween: 20,
      },
      320: {
        slidesPerView: 3,
        spaceBetween: 20,
      },
    },
  });

  //product tabs
  $(".product_tab_top ul li:nth-child(1)").addClass("active");
  $(".product_tab_bottom .tab_content:nth-child(1)").show();
  $(".product_tab_top ul li").click(function () {
    $(".product_tab_top ul li").removeClass("active");
    $(this).addClass("active");
    $(".tab_content").hide();
    var activeTab = $(this).find("a").attr("href");
    $(activeTab).fadeIn(700);
    return false;
  });

  // Swiper: Home Top Selling
  new Swiper(".related_slide", {
    loop: false,
    speed: 1000,
    slidesPerView: 4,
    effect: "slide", // coverflow cube fade
    paginationClickable: true,
    spaceBetween: 15,
    autoplay: {
      delay: 10000,
      disableOnInteraction: false,
    },
    watchSlidesProgress: true,
    // pagination: {
    //   el: ".woo_slider_pagination",
    //   clickable: true,
    // },
    navigation: {
      nextEl: ".woo_slider1_next",
      prevEl: ".woo_slider1_prev",
    },
    breakpoints: {
      1920: {
        slidesPerView: 4,
        spaceBetween: 15,
      },
      1200: {
        slidesPerView: 4,
        spaceBetween: 15,
      },
      992: {
        slidesPerView: 3,
        spaceBetween: 20,
      },
      768: {
        slidesPerView: 3,
        spaceBetween: 20,
      },
      480: {
        slidesPerView: 2,
        spaceBetween: 20,
      },
      320: {
        slidesPerView: 1,
        spaceBetween: 10,
      },
    },
  });

  (function ($) {
    "use strict";
    var $navbar = $("#navbar"),
      y_pos = $navbar.offset().top,
      height = $navbar.height();
    $(document).scroll(function () {
      var scrollTop = $(this).scrollTop();
      if (scrollTop > y_pos + height) {
        $navbar.addClass("navbar-fixed").animate({
          top: 0
        });
      } else if (scrollTop <= y_pos) {
        $navbar.removeClass("navbar-fixed").clearQueue().animate({
          top: "-48px"
        }, 0);
      }
    });
  })(jQuery, undefined);
  
  $("#contact_form").on('submit', function (e) {
    e.preventDefault();
    let name = $("#name").val();
    let phone = $("#phone").val();
    let email = $("#email").val();
    var regex = "";
    var valid;

    regex = "^[a-zA-Z][a-zA-Z. ]{2,40}$";
    valid = validateInputs(name, regex);

    if (!valid || name == "") {
      alert("Please enter valid name");
      return false;
    }

    regex = "^[0-9 -]{10,20}$";
    valid = validateInputs(phone, regex);

    if (!valid || phone == "") {
      alert("Please enter valid phone number");
      return false;
    }

    regex = "^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+.[a-zA-Z]{2,4}$";
    valid = validateInputs(email, regex);
    if (!valid || email == "") {
      alert("Please enter valid email address");
      return false;
    }

    if ($("#submit").hasClass("process")) {
      alert("Please wait while processing...");
    } else {
      $("#submit").addClass("process").val("Processing...");
      $.ajax({
        url: "wp-content/themes/chinkus/contact_form.php",
        type: "POST",
        data: new FormData(this),
        processData: false,
        contentType: false,
        cache: false,
        success: function (data) {
          var obj1 = $.parseJSON(data);
          if (obj1[0] == "success") {
            $("#contact_form")[0].reset();
            $("#submit").removeClass("process").val("Send Message");
            location.assign("thank-you");
          } else if (obj1[0] == "fail") {
            alert("Fill all mandatory fields");
          } else if (obj1[0] == "") {
            alert("Please try again.");
          }
        },
      });
    }
  }); 

  $("#contact_form1").on("submit", function (e) {
    e.preventDefault();
    let name = $("#name").val();
    let phone = $("#phone").val();
    let email = $("#email").val();
    var regex = "";
    var valid;

    regex = "^[a-zA-Z][a-zA-Z. ]{2,40}$";
    valid = validateInputs(name, regex);

    if (!valid || name == "") {
      alert("Please enter valid name");
      return false;
    }

    regex = "^[0-9 -]{10,20}$";
    valid = validateInputs(phone, regex);

    if (!valid || phone == "") {
      alert("Please enter valid phone number");
      return false;
    }

    regex = "^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+.[a-zA-Z]{2,4}$";
    valid = validateInputs(email, regex);
    if (!valid || email == "") {
      alert("Please enter valid email address");
      return false;
    }

    if ($("#submit1").hasClass("process")) {
      alert("Please wait while processing...");
    } else {
      $("#submit1").addClass("process").val("Processing...");
      $.ajax({
        url: "wp-content/themes/chinkus/contact_form.php",
        type: "POST",
        data: new FormData(this),
        processData: false,
        contentType: false,
        cache: false,
        success: function (data) {
          var obj1 = $.parseJSON(data);
          if (obj1[0] == "success") {
            $("#contact_form1")[0].reset();
            $("#submit1").removeClass("process").val("Send Message");
            location.assign("thank-you");
          } else if (obj1[0] == "fail") {
            alert("Fill all mandatory fields");
          } else if (obj1[0] == "") {
            alert("Please try again.");
          }
        },
      });
    }
  }); 

  
  function validateInputs(value, pattern) {
    var regexppattern;
    regexppattern = new RegExp(pattern);
    var valid = regexppattern.test(value);
    return valid;
  }

});

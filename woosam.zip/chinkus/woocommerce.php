<?php
/*Template Name:Shop*/
get_header();

?>

<?php if (is_shop() || is_product_category()) { ?>
 
    <div class="section_margin shop_page">
      <div class="wrapper">


        <div class="head_text woocommerce">
          <h1><?= woocommerce_page_title(); ?></h1>
      </div>

      <div class="products_listing_bottom_right">
        <div class="s_right">
          <div class="filter_top">


            <?php
            if (function_exists('woocommerce_result_count')) {
              woocommerce_result_count();
            }
            ?>


            <?php do_action('woo_custom_catalog_ordering'); ?>

          </div>
        <?php } ?>


        <?php woocommerce_content(); ?>
        </div>


        <?php if (is_shop() || is_product_category()) { ?>
      </div>

    </div>
  </div>
<?php } ?>





















<?php get_footer(); ?>
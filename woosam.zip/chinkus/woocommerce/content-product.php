<?php

if (!defined('ABSPATH')) {
  exit; // Exit if accessed directly
}

global $product;

if (empty($product) || !$product->is_visible()) {
  return;
}
?>
<div class="col_1">
            <div class="best_selling_box">
              <div class="best_selling_image">
                <a href="<?= get_permalink($product->get_id()); ?>" title="<?= $product->get_name(); ?>"><?= woocommerce_get_product_thumbnail(); ?>
                <?php if (!$product->managing_stock() && !$product->is_in_stock()) { echo '<span class="stock out-of-stock"></span>'; } else if ($product->stock_status == "onbackorder") { echo '<span class="backorders"></span>'; } ?>
                </a>
              </div>
              <div class="best_selling_content">
                <h4><?= $product->get_name(); ?></h4>
                <h6><?php if ($product->is_type('variable')) { $variations = $product->get_available_variations(); if ($variations) { foreach ($variations as $variation) { $attributes = $variation['attributes']; if (!empty($attributes)) { foreach ($attributes as $attribute_name => $attribute_value) { $taxonomy = 'Gms'; $term = get_term_by('slug', $attribute_value, $taxonomy); $attribute_label = isset($term->name) ? $term->name : $attribute_value; echo   $attribute_label.' ' .wc_attribute_label($taxonomy) ;}} break; }}}?></h6>
                <h3><span class="price-sale"><?php echo wc_price($product->get_price()); ?></span><?php if ($product->is_on_sale()) {?> <span class="onstrike"><?php if ($product->is_type('simple') && $product->get_price() != $product->get_regular_price()) { echo wc_price($product->get_regular_price()); } elseif ($product->is_type('variable') && $product->get_price() != $product->get_variation_regular_price()) { echo wc_price($product->get_variation_regular_price()); }} ?></span></h3>
                <a href="<?= get_permalink($product->get_id()); ?>" title="Add to Cart">
                  <button class="add_to_cart_btn"><img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/add_to_cart.png" alt="Add to cart">Add to cart</button>
                </a>
              </div>
            </div>
          </div>
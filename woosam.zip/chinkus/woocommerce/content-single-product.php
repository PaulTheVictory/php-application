<?php
defined('ABSPATH') || exit;
global $product;
do_action('woocommerce_before_single_product');
if (post_password_required()) {
  echo get_the_password_form(); // WPCS: XSS ok.
  return;
}
$meta = get_post_meta(get_the_ID(), '', true);
if (get_post_meta($post->ID, 'highlight_image', true) != "" && get_post_meta($post->ID, 'highlight_text', true) != "") {
  $himages = $meta['highlight_image'][0] ? explode('|', $meta['highlight_image'][0]) : array();
  $htext =  $meta['highlight_text'][0] ? explode('|', $meta['highlight_text'][0]) : array();
}
?>
<div class="woocommerce_breadcrumb">
  <div class="wrapper">
    <?php
    $args = array(
      'delimiter' => '<span></span>',
      'before' => ''
    );
    woocommerce_breadcrumb($args);
    ?>
  </div>
</div>
<div class="section_margin">
  <div id="product-<?= the_ID(); ?>" <?= wc_product_class('', $product); ?>>

    <div class="wrapper">

      <div class="single_product">
        <div class="single_product_left">
          <?= do_action('woocommerce_before_single_product_summary'); ?>
          <?php if (!$product->managing_stock() && !$product->is_in_stock()) {
            echo '<span class="stock out-of-stock"></span>';
          } else if ($product->stock_status == "onbackorder") {
            echo '<span class="backorders"></span>';
          } ?>
          <!-- <div class="woo_slider_next"></div> -->
          <!-- <div class="woo_slider_prev"></div> -->
        </div>
        <div class="single_product_right">
          <h1><?php echo $product->get_name(); ?></h1>
          <div class="rating_product"><?php echo add_star_rating(); ?> Based on <?php echo $product->get_review_count(); ?> Review(s)</div>
          <div class="quantity-price">
            <span class="price-sale" style="<?php if ($product->is_type('variable')) {
                                              // echo "display:none";
                                            } ?>"><?php echo wc_price($product->get_price()); ?></span>
            <span class="price-extra" style="<?php if ($product->is_type('variable')) {
                                                // echo "display:none";
                                              } ?>">
              <?php
              if ($product->is_on_sale()) {
                if ($product->is_type('simple') && $product->get_price() != $product->get_regular_price()) {
                  echo wc_price($product->get_regular_price());
                } elseif ($product->is_type('variable') && $product->get_price() != $product->get_variation_regular_price()) {
                  echo wc_price($product->get_variation_regular_price());
                }
              }
              ?>
            </span>
          </div>
          <div class="product_varient">
            <?php

            $pa_value = array();
            $default_variation_id = "";

            if ($product->is_type('variable')) {

              //$default_attributes = $product->get_default_attributes();var_dump($default_attributes);

              $available_variations = $product->get_available_variations();
              if (count($available_variations) > 0) {
                $output = '<div class="product-variations-dropdown">
										<select id="available-variations" class="" name="available_variations">';
                $output .= '<option value="">' . __('Select Option') . '</option>';
                $variations_data = array();
                $variations_regular_price = array();

                foreach ($available_variations as $variation) {
                  $option_value = array();
                  $is_default_variation = false;

                  $variations_data[$variation['variation_id']] = $variation['display_price'];
                  $variations_regular_price[$variation['variation_id']] = $variation['display_regular_price'];
                  foreach ($variation['attributes'] as $attribute => $term_slug) {
                    $taxonomy = str_replace('attribute_', '', $attribute);
                    $attribute_name = get_taxonomy($taxonomy)->labels->singular_name; // Attribute name
                    $term_name = get_term_by('slug', $term_slug, $taxonomy)->name; // Attribute value term name
                    //$option_value[] = $attribute_name . ': '.$term_name;
                    $option_value[] = $term_name;
                    $pa_value[] = trim($attribute_name);

                    $default_value = $product->get_variation_default_attribute($taxonomy);
                    if ($default_value == $term_slug) {
                      $is_default_variation = true;
                    }
                  }

                  if ($is_default_variation) {
                    $default_variation_id = $variation['variation_id'];
                  }

                  $variation_obj = new WC_Product_variation($variation['variation_id']);
                  $stock = $variation_obj->get_stock_quantity();
                  if ($variation['is_in_stock'] && $stock == 0) $stock_qty = ' - In Stock';
                  else $stock_qty = $stock == 0 ? ' - (Out Of Stock)' : ' - ' . $stock . ' In Stock';


                  $option_value = implode(' - ', $option_value);
                  $output .= '<option value="' . $variation['variation_id'] . '">' . $option_value . $stock_qty . ' </option>';
                }

                $pa_value = array_unique($pa_value);

                $output .= '
										</select>
								</div>';
                echo $output;
              }
            }

            ?>

          </div>

          <div class="quantity_sec">
            <span>
              <?php

              woocommerce_quantity_input(array(
                'min_value'   => apply_filters('woocommerce_quantity_input_min', 1, $product),
                'max_value'   => apply_filters('woocommerce_quantity_input_max', $product->backorders_allowed() ? '' : $product->get_stock_quantity(), $product),
                'input_value' => (isset($_POST['quantity']) ? wc_stock_amount($_POST['quantity']) : 1)
              ));
              ?>
              <input type="hidden" name="product_id" id="product_id" value="<?php echo $product->get_id(); ?>" />

            </span>
            <span>

              <button class="add_to_cart_btn addcart-btn"><img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/add_to_cart.png" alt="Add to cart">Add to cart</button>

              <a href="<?php echo get_site_url(); ?>/cart/?add-to-cart=<?php echo $product->get_id(); ?>" title="Order Now"><button title="Order Now" class="buy_now_btn product_cart_btn">Order Now</button></a>
            </span>

          </div>
          <div class="pro_highlight">
            <?php if (get_post_meta($post->ID, 'highlight_image', true) != "" && get_post_meta($post->ID, 'highlight_text', true) != "") { ?>
              <?php foreach ($himages as $key => $himage) { ?>
                <div class="box">
                  <span>
                    <img src="<?= get_site_url(); ?>/<?= $himage; ?>" alt="<?= $htext[$key]; ?>">
                  </span>
                  <h4><?= $htext[$key]; ?></h4>
                </div>
            <?php }
            } ?>
          </div>
        </div>
      </div>

      <div class="product_tab_section m_t_60 m_t_40_lg">
        <div class="product_tab_top">
          <ul>
            <li><a title="Product Description" href="#tab_1">Product Description</a></li>
            <li><a title="Ingredients" href="#tab_2">Ingredients</a></li>
            <li><a title="Storage Instructions" href="#tab_3">Storage Instructions</a></li>
          </ul>
        </div>
        <div class="product_tab_bottom">
          <div class="tab_content" id="tab_1">
            <?= $product->get_short_description() ? $product->get_short_description() : "Coming soon" ?>
          </div>
          <div class="tab_content" id="tab_2">
            <?php if (get_post_meta($post->ID, 'ingredients', true) != "") { ?>
              <?php echo get_post_meta($post->ID, 'ingredients', true); ?>
            <?php } else { ?><p>Coming soon</p><?php } ?>
          </div>
          <div class="tab_content" id="tab_3">
            <?php if (get_post_meta($post->ID, 'storage_instructions', true) != "") { ?>
              <?php echo get_post_meta($post->ID, 'storage_instructions', true); ?>
            <?php } else { ?><p>Coming soon</p><?php } ?>
          </div>
        </div>
      </div>

    </div>
  </div>
</div>


<div class="section_margin">
  <div class="wrapper">
    <?= woocommerce_output_product_data_tabs(); ?>
  </div>
</div>


<div class="section_margin">
  <div class="wrapper">
    <div class="head_text two_side">
      <h2>Related Products</h2>
    </div>
    <?php
    $cat = get_the_terms($product->id, 'product_cat');
    //echo $cat[0]->name;
    ?>
    <!--related_products-->
    <div class="related_slide">
      <div class="swiper-wrapper">
        <?php
        $args = array(
          'posts_per_page' => 6,
          'product_cat' => $cat[0]->name,
          'post_type' => 'product',
          'orderby' => 'title',
          'orderby' => 'date',
          'order' => 'DESC',
          'stock_status' => 'instock',
          // 'post__not_in'=> 43,
        );
        $products = new WP_Query($args);
        if ($products->have_posts()) {
          while ($products->have_posts()) : $products->the_post();
            global $product;
        ?>




            <div class="col_1 swiper-slide">
              <div class="best_selling_box">
                <div class="best_selling_image">
                  <a href="<?= get_permalink($product->get_id()); ?>" title="<?= $product->get_name(); ?>"><?= woocommerce_get_product_thumbnail(); ?>
                    <?php if (!$product->managing_stock() && !$product->is_in_stock()) {
                      echo '<span class="stock out-of-stock"></span>';
                    } else if ($product->stock_status == "onbackorder") {
                      echo '<span class="backorders"></span>';
                    } ?>
                  </a>
                </div>
                <div class="best_selling_content">
                  <h4><?= $product->get_name(); ?></h4>
                  <h6><?php if ($product->is_type('variable')) {
                        $variations = $product->get_available_variations();
                        if ($variations) {
                          foreach ($variations as $variation) {
                            $attributes = $variation['attributes'];
                            if (!empty($attributes)) {
                              foreach ($attributes as $attribute_name => $attribute_value) {
                                $taxonomy = 'Gms';
                                $term = get_term_by('slug', $attribute_value, $taxonomy);
                                $attribute_label = isset($term->name) ? $term->name : $attribute_value;
                                echo   $attribute_label . ' ' . wc_attribute_label($taxonomy);
                              }
                            }
                            break;
                          }
                        }
                      } ?></h6>
                  <h3><span class="price-sale"><?php echo wc_price($product->get_price()); ?></span><?php if ($product->is_on_sale()) {?> <span class="onstrike"><?php if ($product->is_type('simple') && $product->get_price() != $product->get_regular_price()) { echo wc_price($product->get_regular_price()); } elseif ($product->is_type('variable') && $product->get_price() != $product->get_variation_regular_price()) { echo wc_price($product->get_variation_regular_price()); }} ?></span></h3>
                  <a href="<?= get_permalink($product->get_id()); ?>" title="Add to Cart">
                    <button class="add_to_cart_btn"><img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/add_to_cart.png" alt="Add to cart">Add to cart</button>
                  </a>
                </div>
              </div>
            </div>

        <?php
          endwhile;
          wp_reset_query();
        }
        ?>
      </div>
      <div class="woo_slider1_next"></div>
      <div class="woo_slider1_prev"></div>
    </div>

  </div>
</div>
<!--related_products-->

<div class="inner_bottom"></div>



<script type="application/ld+json">
  {
    "@context": "http://schema.org/",
    "@type": "Product",
    "name": "<?php echo $product->get_name(); ?>",
    "image": "<?php echo wp_get_attachment_url($product->get_image_id()); ?>",
    "description": "<?php echo wp_strip_all_tags($product->get_short_description()); ?>",
    "sku": "<?php echo $product->get_sku(); ?>",
    "mpn": "<?php echo $product->get_sku(); ?>",
    "brand": {
      "@type": "Thing",
      "name": "<?php echo $brand; ?>"
    },
    "review": {
      "@type": "Review",
      "reviewRating": {
        "@type": "Rating",
        "ratingValue": "5",
        "bestRating": "5"
      },
      "author": {
        "@type": "Organization",
        "name": "Chinkus Online Store"
      }
    },
    "aggregateRating": {
      "@type": "AggregateRating",
      "ratingValue": "4.5",
      "reviewCount": "20"
    },
    "offers": {
      "@type": "Offer",
      "url": "<?php echo get_permalink($product->id); ?>",
      "priceCurrency": "<?php echo get_woocommerce_currency(); ?>",
      "price": "<?php echo $product->get_price(); ?>",
      "priceValidUntil": "2040-12-31",
      <?php if ($product->is_in_stock()) { ?> "availability": "http://schema.org/InStock",
      <?php } else { ?> "availability": "http://schema.org/OutofStock",
      <?php } ?> "seller": {
        "@type": "Organization",
        "name": "Chinkus Online Store"
      }

    }
  }
</script>

<script>
  var jsonData = <?php echo json_encode($variations_data); ?>;
  var variations_regular_price = <?php echo json_encode($variations_regular_price); ?>;

  (function($) {

    var variationelem = $("#available-variations").val(<?php echo $default_variation_id; ?>);
    if (variationelem) setvariationvalue(variationelem);

    $("input[name=quantity]").bind('keyup mouseup', function() {

      var regprice = "<?php echo $product->get_price(); ?>";
      var cursymb = "<?php echo get_woocommerce_currency_symbol(); ?>";

      $.each(jsonData, function(index, price) {
        if (index == $("#available-variations option:selected").val()) {
          regprice = price; // The right variation price
        }
      });

      var totalprice = $(this).val() * regprice;



      $(".price-sale").html('<span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">' + cursymb + '</span>' + addCommas(totalprice) + '</bdi></span>');


    });

    $(document).on('click', '.addcart-btn', function(e) {
      e.preventDefault();
      var product_qty = $('input[name=quantity]').val(),
        product_id = $('#product_id').val(),
        variation_id = $('#available-variations option:selected').val();


      if (typeof variation_id == "undefined") {
        variation_id = 0;
      } else if (typeof variation_id != "undefined" && variation_id == "") {

        Swal.fire({
          icon: 'error',
          title: 'Failed',
          timer: 3000,
          text: 'Please choose product!',
        });
        return;
      }
      var cartcount = $(".cart_count span").text();

      cartcount = parseInt(cartcount) + parseInt(product_qty);

      $(this).addClass('loading');

      m_wc_add_to_cart(product_id, variation_id, product_qty, cartcount);


    });
    $(document).on('click', '.buy_now_btn', function(e) {
      e.preventDefault();
      var product_qty = $('input[name=quantity]').val(),
        product_id = $('#product_id').val(),
        variation_id = $('#available-variations option:selected').val();


      if (typeof variation_id == "undefined") {
        variation_id = 0;
      } else if (typeof variation_id != "undefined" && variation_id == "") {
        Swal.fire({
          icon: 'error',
          title: 'Failed',
          timer: 3000,
          text: 'Please choose product!',
        });
        return;
      }



      <?php if ($product->is_type('variable')) {  ?>
        window.location.href = "<?php echo get_site_url() ?>/cart/?add-to-cart=" + variation_id + "&quantity=" + product_qty;
      <?php } else if ($product->is_type('simple')) { ?>

        window.location.href = "<?php echo get_site_url() ?>/cart/?add-to-cart=" + product_id + "&quantity=" + product_qty;

      <?php } ?>



    });



    $('#available-variations').change(function() {

      setvariationvalue($(this));

    });

  })(jQuery);

  function setvariationvalue(variationelem) {

    var cursymb = "<?php echo get_woocommerce_currency_symbol(); ?>";

    if ('' != $(variationelem).val()) {
      var vprice = 0, // Initilizing
        vrprice = 0;
      // Loop through variation IDs / Prices pairs
      $.each(jsonData, function(index, price) {
        if (index == $("#available-variations option:selected").val()) {
          vprice = price; // The right variation price
          vrprice = variations_regular_price[index];
          if (vprice == vrprice) vrprice = 0;
        }
      });



      var price_html = '<span class="price-sale"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">' + cursymb + '</span>' + addCommas(vprice) + '</bdi></span></span>';

      if (vrprice > 0) {


        price_html += '<span class="price-extra"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">' + cursymb + '</span>' + addCommas(vrprice) + '</bdi></span></span>';

        $(".quantity-price").html(price_html);
      } else {
        $(".quantity-price").html(price_html);
      }

      $("input[name=quantity]").val(1);
    }

  }

  function addCommas(x) {
    var parts = x.toString().split(".");
    parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ",");
    return parts.join(".");
  }

  function m_wc_add_to_cart(product_id, variation_id, product_qty, cartcount) {
    if ('undefined' === typeof wc_add_to_cart_params) {
      // The add to cart params are not present.
      return false;
    }

    var variablevalue = $("#available-variations option:selected").text();
    var vvaluearr = variablevalue.split(' - ');
    var vvaluedata = {};
    for (var i = 0; i < vvaluearr.length; i++) {

      var vvalueattrarr = vvaluearr[i].split(': ');
      vvaluedata[vvalueattrarr[0]] = vvalueattrarr[1];

    }


    var data = {
      action: "woocommerce_add_variation_to_cart",
      product_id: product_id,
      variation_id: variation_id,
      quantity: product_qty,
      variation: vvaluedata
    };

    jQuery.post(wc_add_to_cart_params.ajax_url, data, function(response) {
      if (!response) {
        return;
      }
      // This redirects the user to the product url if for example options are needed ( in a variable product ).
      // You can remove this if it's not the case.
      if (response.error && response.product_url) {
        window.location = response.product_url;
        return;
      }
      // Remove this if you never want this action redirect.
      if (wc_add_to_cart_params.cart_redirect_after_add === 'yes') {
        window.location = wc_add_to_cart_params.cart_url;
        return;
      }
      // This is important so your theme gets a chance to update the cart quantity for example, but can be removed if not needed.
      jQuery(document.body).trigger('added_to_cart', [response.fragments, response.cart_hash]);


      Swal.fire({
        icon: 'success',
        title: 'Success',
        timer: 3000,
        text: 'Product successfully added to your cart',
      });

      jQuery(".cart_count span").text(cartcount);
      jQuery(".addcart-btn").removeClass('loading');


    });
  }
</script>
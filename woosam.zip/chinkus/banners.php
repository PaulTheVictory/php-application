<?php
$meta = get_post_meta(get_the_ID(), '', true);
$desktop_image = explode('|', $meta['desktop_banner'][0]);
$mobile_image =  explode('|', $meta['mobile_banner'][0]);
$banner_heading =  explode('|', $meta['banner_heading'][0]);
$banner_content =  explode('|', $meta['banner_content'][0]);
$button_link =  explode('|', $meta['button_link'][0]);
$button_text =  explode('|', $meta['button_text'][0]);
?>

<!--slider_section-->
<?php if($meta['desktop_banner'][0]) { ?>
<section class="section slider_section m_0">
  <div class="banner_slider o_h">
    <div class="swiper-wrapper">
      <?php
        foreach($desktop_image as $key=>$desk) { 
      ?>
        <div class="swiper-slide">
        <div class="section banner_item p_r">
          <img src="<?= get_site_url(); ?>/<?= $desk; ?>" alt="<?= $banner_heading[$key]; ?>" class="desktop_banner" />
          <img src="<?= get_site_url(); ?>/<?= $mobile_image[$key]?$mobile_image[$key]:"wp-content/themes/chinkus/assets/images/banner/mobile.png"; ?>" alt="<?= $banner_heading[$key]; ?>" class="mobile_banner" />
          <div class="banner_wrapper">
            <div class="banner_content d_f f_d_c p_r gap_15">
              <h2><?= $banner_heading[$key]; ?></h2>
              <p><?= $banner_content[$key]; ?></p>
              <?php if($button_link[$key]) { ?>
              <a href="<?= $button_link[$key]; ?>" title="<?= $button_text[$key]; ?>"><button class="theme_btn"><?= $button_text[$key]; ?></button></a>
              <?php } ?>
            </div>
          </div>
        </div>
      </div>
      <?php } ?>
    </div>
    <div class="home_slider_pagination"></div>
  </div>
</section>
<?php } ?>
<!--slider_section-->
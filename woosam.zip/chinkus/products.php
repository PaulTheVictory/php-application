<?php
/*Template Name:Products*/
get_header();
?>
<!--slider_section-->

<?php include get_template_directory() . '/banners.php'; ?>

<!--slider_section-->
<div class="inner_bottom"></div>
<section class="section_margin">
  <div class="wrapper">
    <div class="head_text two_side">
      <h1>Our Products</h1>
    </div>
    <div class="col_4 gap_60_25 col_3_xl col_2_lg gap_40_15_xs col_1_xxs">
      <div class="col_1">
        <div class="best_selling_box">
          <div class="best_selling_image">
            <img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/product.png" alt="Chinku's Coconut Balls">
          </div>
          <div class="best_selling_content">
            <h4>Chinku's Coconut Balls</h4>
            <h6>200 Gms</h6>
            <h3>Rs. 210</h3>
            <a href="javascript:void(0)" title="Add to Cart">
              <button class="add_to_cart_btn"><img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/add_to_cart.png" alt="Add to cart">Add to cart</button>
            </a>
          </div>
        </div>
      </div>
      <div class="col_1">
        <div class="best_selling_box">
          <div class="best_selling_image">
            <img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/product.png" alt="Chinku's Coconut Balls">
          </div>
          <div class="best_selling_content">
            <h4>Chinku's Coconut Balls</h4>
            <h6>200 Gms</h6>
            <h3>Rs. 210</h3>
            <a href="javascript:void(0)" title="Add to Cart">
              <button class="add_to_cart_btn"><img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/add_to_cart.png" alt="Add to cart">Add to cart</button>
            </a>
          </div>
        </div>
      </div>
      <div class="col_1">
        <div class="best_selling_box">
          <div class="best_selling_image">
            <img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/product.png" alt="Chinku's Coconut Balls">
          </div>
          <div class="best_selling_content">
            <h4>Chinku's Coconut Balls</h4>
            <h6>200 Gms</h6>
            <h3>Rs. 210</h3>
            <a href="javascript:void(0)" title="Add to Cart">
              <button class="add_to_cart_btn"><img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/add_to_cart.png" alt="Add to cart">Add to cart</button>
            </a>
          </div>
        </div>
      </div>
      <div class="col_1">
        <div class="best_selling_box">
          <div class="best_selling_image">
            <img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/product.png" alt="Chinku's Coconut Balls">
          </div>
          <div class="best_selling_content">
            <h4>Chinku's Coconut Balls</h4>
            <h6>200 Gms</h6>
            <h3>Rs. 210</h3>
            <a href="javascript:void(0)" title="Add to Cart">
              <button class="add_to_cart_btn"><img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/add_to_cart.png" alt="Add to cart">Add to cart</button>
            </a>
          </div>
        </div>
      </div>
      <div class="col_1">
        <div class="best_selling_box">
          <div class="best_selling_image">
            <img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/product.png" alt="Chinku's Coconut Balls">
          </div>
          <div class="best_selling_content">
            <h4>Chinku's Coconut Balls</h4>
            <h6>200 Gms</h6>
            <h3>Rs. 210</h3>
            <a href="javascript:void(0)" title="Add to Cart">
              <button class="add_to_cart_btn"><img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/add_to_cart.png" alt="Add to cart">Add to cart</button>
            </a>
          </div>
        </div>
      </div>
      <div class="col_1">
        <div class="best_selling_box">
          <div class="best_selling_image">
            <img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/product.png" alt="Chinku's Coconut Balls">
          </div>
          <div class="best_selling_content">
            <h4>Chinku's Coconut Balls</h4>
            <h6>200 Gms</h6>
            <h3>Rs. 210</h3>
            <a href="javascript:void(0)" title="Add to Cart">
              <button class="add_to_cart_btn"><img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/add_to_cart.png" alt="Add to cart">Add to cart</button>
            </a>
          </div>
        </div>
      </div>
      <div class="col_1">
        <div class="best_selling_box">
          <div class="best_selling_image">
            <img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/product.png" alt="Chinku's Coconut Balls">
          </div>
          <div class="best_selling_content">
            <h4>Chinku's Coconut Balls</h4>
            <h6>200 Gms</h6>
            <h3>Rs. 210</h3>
            <a href="javascript:void(0)" title="Add to Cart">
              <button class="add_to_cart_btn"><img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/add_to_cart.png" alt="Add to cart">Add to cart</button>
            </a>
          </div>
        </div>
      </div>
      <div class="col_1">
        <div class="best_selling_box">
          <div class="best_selling_image">
            <img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/product.png" alt="Chinku's Coconut Balls">
          </div>
          <div class="best_selling_content">
            <h4>Chinku's Coconut Balls</h4>
            <h6>200 Gms</h6>
            <h3>Rs. 210</h3>
            <a href="javascript:void(0)" title="Add to Cart">
              <button class="add_to_cart_btn"><img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/add_to_cart.png" alt="Add to cart">Add to cart</button>
            </a>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>


















<div class="inner_bottom"></div>




<?php
/*Template Name:Products*/
get_footer(); ?>
<?php
/*Template Name:Contact Us*/
get_header();
?>

<!--slider_section-->

<?php include get_template_directory() . '/banners.php'; ?>

<!--slider_section-->
<div class="inner_bottom"></div>


<!--contactus_section-->


<section class="contactus_section section_margin">
  <div class="wrapper">
    <div class="d_f a_i_f_s j_c_s_b f_w_w gap_50_md">
      <div class="w_45 contactus_left w_100_md">
        <div class="head_text right_side">
          <h1>Get into touch</h1>
        </div>
        <p class="phone">+91 9876543219</p>
        <p class="call">0422 2546978</p>
        <p class="address">Door No. 6, 168 A, Choran Tavide House, P.O Pinarayi, Thalassery, Kannur, Kerala - 670741, India</p>
        <div class="map">
          <img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/contactus/map.png" alt="map">
        </div>
      </div>
      <div class="w_45 contactus_right w_100_md">
        <div class="head_text right_side">
          <h2>Partner with us</h2>
        </div>
        <form id="contact_form1" class="col_1 gap_15">
          <div class="col_1">
            <label for="name">Name</label>
            <input name="name" id="name" type="text" />
          </div>
          <div class="col_1">
            <label for="lname">Last Name</label>
            <input name="lname" id="lname" type="text" />
          </div>
          <div class="col_1">
            <label for="phone">Phone Number</label>
            <input name="phone" id="phone" type="text" />
          </div>
          <div class="col_1">
            <label for="email">Email Address</label>
            <input name="email" id="email" type="text" />
          </div>
          
          <div class="col_1">
            <label for="message">Any other info you want to share?</label>
            <textarea name="message" id="message"></textarea>
          </div>
          <div class="col_1">
            <button type="submit" name="submit" id="submit1" class="theme_btn w_f_c">Submit</button>
          </div>
        </form>
      </div>
    </div>
  </div>
</section>


<!--contactus_section-->







<div class="inner_bottom"></div>















<?php
/*Template Name:Contact Us*/
get_footer(); ?>
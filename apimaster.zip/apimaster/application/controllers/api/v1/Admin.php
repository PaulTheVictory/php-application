<?php

defined('BASEPATH') or exit ("No direct script access allowed");

require(APPPATH . '/libraries/REST_Controller.php');

use Restserver\Libraries\REST_Controller;

class Admin extends REST_Controller {

  public function __construct()
  {
    parent::__construct();
    $this->load->library("Authorization_Token");
    $this->load->model("api/v1/Admin_Model", "admin_model", TRUE);
    $this->load->library("user_agent");
  }

  public function register_post()
  {
    try 
    {
      $arr["message"] = "Register Successfully";
      $arr["success"] = true;
      $arr["statusCode"] = 200;
      $this->response($arr, REST_Controller::HTTP_OK);
    } 
    catch(Exception $e) 
    {
      $error["success"] = false;
      $error["statusCode"] = 500;
      $error["message"] = "Internal server error. Please try again later!";
      $error["error"] = $e->getMessage();
      $this->response($error, REST_Controller::HTTP_INTERNAL_SERVER_ERROR);
    }
  }




















}
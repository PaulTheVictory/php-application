<?php

class User_model extends CI_Model {


    public function NewUserRegister($name, $email, $phone, $message) 
    {

        $result = array(0=>"");
        
        

        $verifyexistuser = $this->db->select('email')->from('register')->where('email',$email)->get();
        $verifyexistuser1 = $this->db->select('phone')->from('register')->where('phone',$phone)->get(); 

        

        if($verifyexistuser->num_rows() > 0 || $verifyexistuser1->num_rows() > 0)
        {
            $result = array(0=>'exist');
            return $result;
        }
        else
        {
            $uniqid = uniqid();
        $offset=5*60*60 + 30*60;
        $dateformat = 'Y-m-d H:i:s';
        $curtime = gmdate($dateformat, time()+$offset);	
            $data = array 
            (
                'id' => $uniqid,
                'name' => $name,
                'email' => $email,
                'phone' => $phone,
                'message' => $message,
                'created' => $curtime,
                'status' => "a"
            );
    
            $query = $this->db->insert('register',$data);
        if($query) 
        {
           
           
                $result = array(0=>'success');
                return $result;
            
            
        }
        else
        {
            $result = array(0=>'fail');
            return $result; 
        }

    }


    




    }


















    



}
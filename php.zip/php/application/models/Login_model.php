<?php

class Login_model extends CI_Model {


    public function AdminVerify($username,$password)
    {
   
        $result = array(0=>'');
        $encrpassword = md5($password);
        $query = $this->db->query('select id,password,role,status from users where username="'.$username.'"');
        $row = $query->result_array();

        if($row)
        {
            $userid = $row[0]['id'];
            $dbpassword = $row[0]['password'];
            $role = $row[0]['role'];
            $status = $row[0]['status'];

            if($dbpassword==$encrpassword && $role=="ADMIN" && $status==1)
            {
                $session_id = uniqid();
                $session_array = array('id'=>$session_id, 'role'=>$role);
                $this->session->set_userdata('loggedin',$session_array);
                $this->CreatSession($session_id,$userid,$role);
                $result = array(0=>'success');
                return $result;
            }
            else
            {
                $result = array(0=>'mismatch');
                return $result;
            }


        }
        else 
        {
            $result = array(0=>'notfound');
            return $result;
        }
        return $result;
    }



    public function CreatSession($session_id,$userid,$role)
    {
        $user_ip = $this->session->userdata('ip_address');
        $user_agent = $this->session->userdata('user_agent');
        $offset=5*60*60 + 30*60;
        $dateformat = 'Y-m-d H:i:s';
        $curtime = gmdate($dateformat, time()+$offset);	

        $query = $this->db->query('select userid from session where sessionid="'.$session_id.'"');

        $row = $query->result_array();

        if($row)
        {
            $this->session->unset_userdata('loggedin');
            redirect('login', 'refresh');
        }
        else
        {
            $query1 = $this->db->query('insert into session (`sessionid`,`ip`,`userid`,`sessionstart_time`,`sessionend_time`,`agent`,`status`) values ("'.$session_id.'","'.$user_ip.'","'.$userid.'","'.$curtime.'","","'.$user_agent.'","o")');
        }








    }

    public function EndSession()
    {
        $session_id = "";
        $session_data = $this->session->userdata('loggedin');
        $session_id = $session_data['id'];
        $offset=5*60*60 + 30*60;
        $dateformat = 'Y-m-d H:i:s';
        $curtime = gmdate($dateformat, time()+$offset);
        $this->db->query('update session set sessionend_time="'.$curtime.'", status="c" where sessionid="'.$session_id.'" ');
    }



































































}

<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Registerlist extends CI_Controller {

    function __construct()
	{
		parent::__construct();
		$this->load->model('Dashboard_model','member',TRUE);
	}




	public function index()
	{
		
		if($this->session->userdata('loggedin')==TRUE) 
        {
			$data['title'] = "Register Listing";
			$this->load->view('header.php',$data);
            $this->load->view('dashboard_header');
			$this->load->view('registerlist_view');
            $this->load->view('dashboard_footer');
			$this->load->view('footer.php');
        }
        else 
        {
            redirect('login', 'refresh');
        }


	}



	function Registerlist(){
        $data = $row = array();
        
        // Fetch member's records
        $memData = $this->member->getRows($_POST);
        
        $i = $_POST['start'];
        foreach($memData as $member){
            if($member->status!="a"){continue;}
            $i++;
            $created = date( 'jS M Y', strtotime($member->created));
			$action = '
            <button type="button" class="btn btn-sm btn-primary m-2 view_user" data-uid="'.$member->id.'"><i class="fa fa-eye" aria-hidden="true"></i> View</button>
            <button class="btn btn-sm btn-success m-2 user_edit" data-uid="'.$member->id.'"><i class="fa fa-edit"></i> Edit</button>
            <button class="btn btn-sm btn-danger m-2 delete_confirm" type="submit" data-uid="'.$member->id.'"><i class="fa fa-trash"></i> Delete</button>';
           // $status = ($member->status == 1)?'Active':'Inactive';
            $data[] = array($i, $member->name, $member->email, $member->phone, $member->message, $created, $action);
        }
        
        $output = array(
            "draw" => $_POST['draw'],
            "recordsTotal" => $this->member->CountAll(),
            "recordsFiltered" => $this->member->CountFiltered($_POST),
            "data" => $data,
        );
        
        // Output to JSON format
        echo json_encode($output);
    }

	

	public function DeleteByUserId() {
        if($this->session->userdata('loggedin')==TRUE) 
        {
        $userid  = isset($_GET['userid'])?$_GET['userid']:'';               

            $ret = $this->member->DeleteUser($userid);
            echo json_encode($ret);
            
        }else
        {
            
            redirect('login', 'refresh');
        }
        
    }
    


















}


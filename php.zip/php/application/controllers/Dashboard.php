<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller {

    function __construct()
	{
		parent::__construct();
		$this->load->model('Dashboard_model','',TRUE);
	}




	public function index()
	{
		
		if($this->session->userdata('loggedin')==TRUE) 
        {
			$data['title'] = "Admin Dashboard";
			$this->load->view('header.php',$data);
            $this->load->view('dashboard_header');
			$this->load->view('dashboard_view');
            $this->load->view('dashboard_footer');
			$this->load->view('footer.php');
        }
        else 
        {
            redirect('login', 'refresh');
        }


	}

























}

<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Register extends CI_Controller
{

    function __construct()
	{
		parent::__construct();
		$this->load->model('User_model','',TRUE);
	}

    function index()
    {
        $data['title'] = "New User Register";
        $this->load->view('header.php', $data);
        $this->load->view('dashboard_header');
        $this->load->view('register_view.php');
        $this->load->view('dashboard_footer');
        $this->load->view('footer.php');
    }


    public function NewUserRegister()
    {

        if ($_SERVER['REQUEST_METHOD'] == "POST" && $this->input->is_ajax_request()) {
            $name = $this->input->post('name', TRUE);
            $email = $this->input->post('email', TRUE);
            $phone = $this->input->post('phone', TRUE);
            $message = $this->input->post('message', TRUE);

            if ($name && $email && $phone && $message != "") {
                $ret = $this->User_model->NewUserRegister($name, $email, $phone, $message);

                echo json_encode($ret);
            } else {
                echo json_encode('insertfail');
            }
        } else {
            echo json_encode('fail');
        }
    }
}

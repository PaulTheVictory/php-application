<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model('Login_model','',TRUE);
	}




	function index()
	{

		if($this->session->userdata('loggedin')==TRUE) 
        {
			redirect('dashboard', 'refresh');
		}
		else
		{
		
			$data['title'] = "Admin Login";
			$this->load->view('header.php',$data);
			$this->load->view('login_view');
			$this->load->view('footer.php');
		}
	}

	public function AdminLogin()
	{

		if($_SERVER['REQUEST_METHOD']=="POST" && $this->input->is_ajax_request()) 
		{
		
			$username = $this->input->post('loginemail', TRUE);
			$password = $this->input->post('loginpassword', TRUE);
		

			$ret = $this->Login_model->AdminVerify($username,$password);
			
			echo json_encode($ret);
			
			
		}

	else 
	{
		redirect('login','refresh');
	}


	}
	
	public function Logout()
	{
		$session_data = $this->session->userdata('loggedin');
		$this->Login_model->EndSession();
		$this->session->unset_userdata('loggedin');
		$this->session->sess_destroy();
		redirect('login', 'refresh');
		
	}

	






}

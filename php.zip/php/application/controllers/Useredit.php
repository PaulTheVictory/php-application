<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Useredit extends CI_Controller
{

    function __construct()
	{
		parent::__construct();
		$this->load->model('Dashboard_model','member',TRUE);
	}

    function index()
    {
         $id = $this->input->get("id");
            if(!$id) {redirect('registerlist', 'refresh');}
            if($id=="") {redirect('registerlist', 'refresh');}
            $data["userdetails"] = $this->member->GetUserDetailsById($id);
        $data['title'] = "Edit User";
        $this->load->view('header.php', $data);
        $this->load->view('dashboard_header');
        $this->load->view('useredit_view.php');
        $this->load->view('dashboard_footer');
        $this->load->view('footer.php');
    }


    
   


















}

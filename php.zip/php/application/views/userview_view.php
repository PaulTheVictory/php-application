<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>


<section class="container-fluid">
    <div class="container">
        <div class="row">
            <div class="col mt-5">
                <div class="card m-auto mx-auto my-aut p-0 col-xxl-6 col-xl-6 col-lg-8 col-md-10 col-sm-12">
                    <div class="card-header text-center pt-2 pb-2 h5 bg-primary text-white font-bold">
                        <h1>View - <?php echo $userdetails['id'];?></h1>
                    </div>
                    <div class="card-body">
                       <ul class="single_userview">
                           <li>
                               <font>Name</font>
                               <font><?php echo $userdetails['name'];?></font>
                           </li>
                            <li>
                               <font>Email</font>
                               <font><?php echo $userdetails['email'];?></font>
                           </li>
                            <li>
                               <font>Phone</font>
                               <font><?php echo $userdetails['phone'];?></font>
                           </li>
                            <li>
                               <font>Message</font>
                               <font><?php echo $userdetails['message'];?></font>
                           </li>
                            <li>
                               <font>Created</font>
                               <font><?php echo $userdetails['created'];?></font>
                           </li>
                       </ul>
                       <a href="<?php echo base_url();?>registerlist"><button class="btn btn-danger mt-5 btn-sm"><i class="fa fa-arrow-left" aria-hidden="true"></i> Back</button></a>
                    </div>

                </div>
            </div>
        </div>
    </div>
</section>




<nav class="navbar navbar-expand-sm navbar-dark bg-primary">
    <div class="container">
        <a class="navbar-brand" href="javascript:void(0)">
            <img src="<?php echo base_url(); ?>images/logo.png" alt="Logo">
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mynavbar">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="mynavbar">
            <ul class="navbar-nav me-auto">
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo base_url(); ?>register">New Register</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo base_url(); ?>registerlist">All Users</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo base_url(); ?>registerlist">Deleted Users</a>
                </li>
            </ul>

            <div class="">
                <!-- <button class="btn btn-success"><i class="fa fa-plus-circle fa-sm"></i> Add New</button>
        <button class="btn btn-danger"><i class="fa fa-trash fa-sm"></i> Delete</button> -->
                <a href="<?php echo base_url(); ?>Login/Logout" title="Logout"><button class="btn btn-danger"><i class="fa fa-sign-out fa-sm"></i> Logout</button></a>

            </div>
        </div>
    </div>
</nav>

<!DOCTYPE html>

<html>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title><?php echo $title; ?></title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="<?php echo base_url(); ?>css/bootstrap_min.css">
   <link rel="stylesheet" href="<?php echo base_url(); ?>css/fontawesome_min.css">
   <link rel="stylesheet" href="<?php echo base_url(); ?>css/jquery.dataTables.min.css">
   <link rel="stylesheet" href="<?php echo base_url(); ?>css/responsive.dataTables.min.css">

    
    <link rel="stylesheet" href="<?php echo base_url(); ?>css/style.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>css/style_media.css">
    
    <script src="<?php echo base_url(); ?>js/jquery_min.js" type="text/javascript"></script>
    <script src="<?php echo base_url(); ?>js/bootstrap_min.js" type="text/javascript"></script>
    <script src="<?php echo base_url(); ?>js/jquery.dataTables.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url(); ?>js/dataTables.responsive.min.js" type="text/javascript"></script>
    
    
    <script>
		var base_url = "<?php echo base_url(); ?>";
	</script>
</head>

<body>

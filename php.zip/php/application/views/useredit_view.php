<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>


<section class="container-fluid">
    <div class="container">
        <div class="row">
            <div class="col mt-5">
                <div class="card m-auto mx-auto my-aut p-0 col-xxl-6 col-xl-6 col-lg-8 col-md-10 col-sm-12">
                    <div class="card-header text-center pt-2 pb-2 h5 bg-primary text-white font-bold">
                        <h1>User Edit</h1>
                    </div>
                    <div class="card-body">
                        <p class="error_log_text"></p>
                        <form action="" method="post" id="register_form">
                            <div class="mb-3 mt-3">
                                <label for="name" class="form-label">Name:</label>
                                <input type="text" class="form-control reg_name" id="name" placeholder="Enter name" name="name" value="<?php echo $userdetails['name'];?>">
                            </div>
                            <div class="mb-3 mt-3">
                                <label for="email" class="form-label">Email:</label>
                                <input type="text" class="form-control reg_email" id="email" placeholder="Enter email"
                                    name="email" value="<?php echo $userdetails['email'];?>">
                            </div>
                            <div class="mb-3 mt-3">
                                <label for="email" class="form-label">Phone:</label>
                                <input type="text" class="form-control reg_phone" id="phone" placeholder="Phone number"
                                    name="phone" value="<?php echo $userdetails['phone'];?>">
                            </div>
                            
                            <div class="mb-3 mt-3">
                                <label for="comment" class="form-label">Message:</label>
                                <textarea class="form-control reg_message" rows="3" id="comment" name="message"><?php echo $userdetails['message'];?></textarea>
                            </div>
                            <input type="submit" class="btn btn-success" id="register_submit" value="Update">
                        </form>
                    </div>

                </div>
            </div>
        </div>
    </div>
</section>



<script>

$(document).ready(function(){

$('#register_form').on("submit", function(e){
    e.preventDefault();

    var name = $('.reg_name').val();
    var email = $('.reg_email').val();
    var phone = $('.reg_phone').val();
    var message = $('.reg_message').val();

    var regex   = new RegExp('^[a-zA-Z][a-zA-Z\.-/ ]{1,100}$');
	var valid = regex.test(name);

    if(name=="" || !valid)
    {
        $('.reg_name').addClass('error_class');
        $('.error_log_text').text('Invalid Name');
        return;
    }
    regex   = new RegExp('^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$');
    valid = regex.test(email);
    if(email=="" || !valid)
    {
        $('.reg_email').addClass('error_class');
        $('.error_log_text').text('Invalid Email');
        return;
    }

    regex   = new RegExp('^[0-9 \-]{5,20}$');
    valid = regex.test(phone);

    if(phone=="" || !valid)
    {
        $('.reg_phone').addClass('error_class');
        $('.error_log_text').text('Invalid Phone');
        return;
    }
    if(message=="")
    {
        $('.reg_message').addClass('error_class');
        $('.error_log_text').text('Invalid Message');
        return;
    }

    if($("#register_submit").hasClass('process')){
		alert("Please wait while processing...");
	}else{
	
		$("#register_submit").addClass('process').val('Processing...');
	
	$.ajax({
        	url:'Register/NewUserRegister',
			type:'POST',
			data: new FormData(this),
			processData: false,
            contentType: false,
            cache: false,
			success:function(data){
				var obj1 = $.parseJSON(data);
				
				if(obj1[0]=="success"){
					
					setTimeout(function(){
                        $("#register_submit").removeClass('process').val('Register');
						location.assign("<?php echo base_url(); ?>registerlist");
					},2000);
				}
				else if(obj1[0]=="insertfail"){
					$("#register_submit").removeClass('process').val('Register');
					setTimeout(function(){ $(".error_log_text").text("Form error"); }, 500);
				}
				else if(obj1[0]=="fail"){
					$("#register_submit").removeClass('process').val('Register');
					setTimeout(function(){ $(".error_log_text").text("Please try again later"); }, 500);
				}
				else if(obj1[0]=="exist"){
					$("#register_submit").removeClass('process').val('Register');
					setTimeout(function(){ $(".error_log_text").text("User already exists"); }, 500);
				}
				
				else if(obj1[0]==""){
					$("#register_submit").removeClass('process').val('Register');
					setTimeout(function(){ $(".error_log_text").text("Please try Again Later"); }, 500);
				}
				
			}
			
     	}); 
		
	}
	



















});


$('#register_form').find('input,select,textarea').each(function(){

    $("input,select,textarea").click(function(){
        $("input,select,textarea").removeClass('error_class');
        $('.error_log_text').text('');
        return;
    })


})



});




</script>
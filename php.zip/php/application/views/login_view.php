<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<section class="d-flex align-items-center w-100 h-100 min-vh-100">
    <div class="container">

        <div class="row">
            <div class="col mt-5 mb-5">
                <div class="card m-auto mx-auto my-aut p-0 col-xxl-4 col-xl-4 col-lg-6 col-md-8 col-sm-12">
                    <div class="card-header text-center pt-2 pb-2 h5 bg-primary text-white font-bold">Admin Login
                    </div>
                    <div class="card-body">
                        <p class="error_log_text"></p>
                        <form action="" method="post" id="loginform">
                            <div class="mb-3 mt-3">
                                <label for="email" class="form-label">Email:</label>
                                <input type="text" class="form-control login_name" id="loginemail"
                                    placeholder="Enter email" name="loginemail" readonly
                                    onfocus="this.removeAttribute('readonly');">
                            </div>
                            <div class="mb-3">
                                <label for="pwd" class="form-label">Password:</label>
                                <input type="password" class="form-control login_password" id="loginpassword"
                                    placeholder="Enter password" name="loginpassword" readonly
                                    onfocus="this.removeAttribute('readonly');">
                            </div>
                            <div class="form-check mb-3">
                                <label class="form-check-label align-items-center d-flex gap-2">
                                    <input class="form-check-input" type="checkbox" name="loginremember"> Remember me
                                </label>
                            </div>
                            <input type="submit" class="btn btn-primary" id="login_submit" value="Login">
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>



<script>

$(document).ready(function(){

$("#loginform").on("submit",function(e){
	e.preventDefault();
	
	var loginname = $(".login_name").val();
	var loginpassword = $(".login_password").val();
	
	if(loginname==""){ $(".login_name").addClass('error_class');$(".error_log_text").text("Invalid Username");return;}
	if(loginpassword==""){ $(".login_password").addClass('error_class');$(".error_log_text").text("Invalid Password");return;}
	
	if($("#login_submit").hasClass('process')){
		alert("Please wait while processing...");
	}else{
	
		$("#login_submit").addClass('process').val('Processing...');
	
	$.ajax({
        	url:'Login/AdminLogin',
			type:'POST',
			data: new FormData(this),
			processData: false,
            contentType: false,
            cache: false,
			success:function(data){
				var obj1 = $.parseJSON(data);
				
				if(obj1[0]=="success"){
					
					setTimeout(function(){
                        $("#login_submit").removeClass('process').val('Login');
						location.reload();
					},1000);
				}
				else if(obj1[0]=="mismatch"){
					$("#login_submit").removeClass('process').val('Login');
					setTimeout(function(){ $(".error_log_text").text("Username and Password did't match"); }, 500);
				}
				else if(obj1[0]=="notfound"){
					$("#login_submit").removeClass('process').val('Login');
					setTimeout(function(){ $(".error_log_text").text("Username Not Exists"); }, 500);
				}
				else if(obj1[0]=="notactive"){
					$("#login_submit").removeClass('process').val('Login');
					setTimeout(function(){ $(".error_log_text").text("Account is Not Active"); }, 500);
				}
				
				else if(obj1[0]==""){
					$("#login_submit").removeClass('process').val('Login');
					setTimeout(function(){ $(".error_log_text").text("Please try Again Later"); }, 500);
				}
				
			}
			
     	}); 
		
	}
	
})
}); 
$("#loginform").find("input,select,textarea").each(function(){
        $("input,select,textarea").click(function(){
			$("input,select,textarea").removeClass("error_class");$(".error_log_text").text("");
		});
		 

    });
</script>

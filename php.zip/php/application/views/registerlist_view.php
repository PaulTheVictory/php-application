<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>


<section class="container-fluid">
    <div class="container">
        <div class="row">
            <div class="col mt-5">
                <!-- Table -->
	<table id='register_view' class='display dataTable'>

<thead>
  <tr>
    <th>S No</th>
    <th>Name</th>
    <th>Email</th>
    <th>Phone No</th>
    <th>Message</th>
    <th>Created</th>
    <th>Action</th>
  </tr>
</thead>

</table>


<!-- Script -->
<script type="text/javascript">


$(document).ready(function(){
    $('#register_view').DataTable({
        // Processing indicator
        "processing": true,
        'responsive': true,
        // DataTables server-side processing mode
        "serverSide": true,
        // Initial no order.
        "order": [],
        "bInfo": false,
        // Load data from an Ajax source
        "ajax": {
            "url": "<?php echo base_url('Registerlist/Registerlist/'); ?>",
            "type": "POST"
        },
        //Set column definition initialisation properties
        "columnDefs": [{ 
            "targets": [0],
            "orderable": false
        }]
    });
});

    //
  
</script>
            </div>
        </div>
    </div>
</section>


<script type="text/javascript">
    $(document).ready(function(){
    
    $(document).on("click",".delete_confirm",function(e){
        e.preventDefault(0);
        
        var userid = $(this).data("uid");
        
        var r=confirm("Are you sure to delete the user?")
        if (r==true){
               
                 $.get('Registerlist/DeleteByUserId',{
                       'userid':userid             

                 }, function(o) {  
                            
                            setTimeout(function(){ alert('Deleted Successfully');location.reload();}, 100);         
                 }, 'json');
                 
        }
        
    });

    //

    $(document).on("click",".view_user",function(v){
        v.preventDefault();

        var viewid = $(this).data("uid");

       var test = base_url+viewid;

       window.location.assign(base_url+"userview?id="+viewid);
    });

    //

    $(document).on("click",".user_edit",function(v){
        v.preventDefault();

        var editid = $(this).data("uid");

        //alert(editid);



       window.location.assign(base_url+"useredit?id="+editid);
    });

        
        
    }); 
</script>

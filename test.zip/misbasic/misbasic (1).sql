-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 01, 2023 at 07:21 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `misbasic`
--

-- --------------------------------------------------------

--
-- Table structure for table `ap_action`
--

CREATE TABLE `ap_action` (
  `action_id` varchar(100) NOT NULL,
  `action_type` varchar(50) NOT NULL,
  `action_name` varchar(50) NOT NULL,
  `module_id` varchar(100) NOT NULL,
  `done_by` varchar(100) NOT NULL,
  `created` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `ap_action`
--

INSERT INTO `ap_action` (`action_id`, `action_type`, `action_name`, `module_id`, `done_by`, `created`) VALUES
('163b130c39f76d', 'create', 'Create Customer', '163b130c39f768', '63a9739adf7d9', '2023-01-1 12:35:39'),
('163b13b8aa6b2f', 'update', 'Status Update Customer', '163b130c39f768', '63a9739adf7d9', '2023-01-1 13:21:38'),
('163b13ba606469', 'update', 'Status Update Customer', '163b130c39f768', '63a9739adf7d9', '2023-01-1 13:22:06'),
('163b13badb5cc3', 'update', 'Status Update Customer', '163b130c39f768', '63a9739adf7d9', '2023-01-1 13:22:13'),
('163b1431549c18', 'update', 'Status Update Customer', '163b130c39f768', '63a9739adf7d9', '2023-01-1 13:53:49'),
('163b1431960a46', 'update', 'Status Update Customer', '163b130c39f768', '63a9739adf7d9', '2023-01-1 13:53:53'),
('163b1736bd50e7', 'create', 'Create Customer', '163b1736bd50e4', '63a9739adf7d9', '2023-01-1 17:20:03'),
('163b173a1c6e3d', 'update', 'Status Update Customer', '163b1736bd50e4', '63a9739adf7d9', '2023-01-1 17:20:57'),
('163b173b515a13', 'update', 'Status Update Customer', '163b1736bd50e4', '63a9739adf7d9', '2023-01-1 17:21:17'),
('163b174a9dc431', 'update', 'Status Update Customer', '163b130c39f768', '63a9739adf7d9', '2023-01-1 17:25:21'),
('163b174b5bf238', 'update', 'Status Update Customer', '163b130c39f768', '63a9739adf7d9', '2023-01-1 17:25:33'),
('163b17be0e4c3e', 'update', 'Update Customer', '163b130c39f768', '63a9739adf7d9', '2023-01-1 17:56:08'),
('163b17c5d5eff8', 'update', 'Update Customer', '163b130c39f768', '63a9739adf7d9', '2023-01-1 17:58:13'),
('163b17ec374760', 'update', 'Update Customer', '163b130c39f768', '63a9739adf7d9', '2023-01-1 18:08:27'),
('163b17f68a6b43', 'update', 'Update Customer', '163b130c39f768', '63a9739adf7d9', '2023-01-1 18:11:12'),
('163b1811699e5a', 'create', 'Create Customer', '163b1811699e59', '63a9739adf7d9', '2023-01-1 18:18:22'),
('163b1812148ec1', 'update', 'Update Customer', '163b1811699e59', '63a9739adf7d9', '2023-01-1 18:18:33'),
('163b18580c8e42', 'delete', 'Delete Customer', '163b1811699e59', '63a9739adf7d9', '2023-01-1 14:07:12'),
('163b1929f3fd89', 'update', 'Update User', '', '163b130c39f768', '2023-01-1 19:33:11'),
('163b192a96a81e', 'update', 'Update User', '', '163b130c39f768', '2023-01-1 19:33:21'),
('163b192d89c961', 'update', 'Update User', '', '163b130c39f768', '2023-01-1 19:34:08'),
('163b192e33ae8c', 'update', 'Update User', '', '163b130c39f768', '2023-01-1 19:34:19'),
('163b192f148469', 'update', 'Update User', '', '163b130c39f768', '2023-01-1 19:34:33'),
('163b19322bd51c', 'update', 'Status Update User', '163b18bc9029e1', '163b130c39f768', '2023-01-1 19:35:22'),
('163b19322c9cd0', 'update', 'Status Update User', '163b18bc9029e1', '163b130c39f768', '2023-01-1 19:35:22'),
('163b19326ad43c', 'update', 'Status Update User', '163b18bc9029e1', '163b130c39f768', '2023-01-1 19:35:26'),
('163b1932ccaf74', 'update', 'Update User', '', '163b130c39f768', '2023-01-1 19:35:32'),
('163b193af1a9c6', 'update', 'Update User', '163b18bc9029e1', '163b130c39f768', '2023-01-1 19:37:43'),
('163b1940d970b9', 'delete', 'Delete Users', '163b18ba6d3a34', '163b130c39f768', '2023-01-1 19:39:17'),
('163b194123821c', 'update', 'Status Update User', '163b18bc9029e1', '163b130c39f768', '2023-01-1 19:39:22'),
('163b194158c616', 'update', 'Status Update User', '163b18bc9029e1', '163b130c39f768', '2023-01-1 19:39:25'),
('163b1b1a29c40b', 'create', 'Add Enquiry', '163b1b1a29c407', '163b130c39f768', '2023-01-1 21:45:30'),
('163b1b1c38d968', 'create', 'Add Enquiry', '163b1b1c38d964', '163b130c39f768', '2023-01-1 21:46:03'),
('163b1b1e6ee565', 'create', 'Add Enquiry', '163b1b1e6ee558', '163b130c39f768', '2023-01-1 21:46:38'),
('163b1b1e6ee566', 'create', 'Add Follow Up Progress', '163b1b1e6ee55d', '163b130c39f768', '2023-01-1 21:46:38'),
('163b1b2f339738', 'create', 'Add Enquiry', '163b1b2f339736', '163b130c39f768', '2023-01-1 21:51:07'),
('163b1b2f339739', 'create', 'Add Follow Up Progress', '163b1b2f339737', '163b130c39f768', '2023-01-1 21:51:07'),
('163b1b429cbf07', 'delete', 'Delete Enquiry', '163b1b2f339736', '163b130c39f768', '2023-01-1 21:56:17'),
('163b1b4384bb28', 'create', 'Add Enquiry', '163b1b4384bb24', '163b130c39f768', '2023-01-1 21:56:32'),
('163b1b4384bb29', 'create', 'Add Follow Up Progress', '163b1b4384bb26', '163b130c39f768', '2023-01-1 21:56:32'),
('163b1ccf3c2715', 'create', 'Add Enquiry', '163b1ccf3c2710', '163b130c39f768', '2023-01-1 23:42:03'),
('163b1ccf3c2716', 'create', 'Add Follow Up Progress', '163b1ccf3c2713', '163b130c39f768', '2023-01-1 23:42:03');

-- --------------------------------------------------------

--
-- Table structure for table `ap_enquiry`
--

CREATE TABLE `ap_enquiry` (
  `enquiry_id` varchar(100) NOT NULL,
  `admin_id` varchar(100) NOT NULL,
  `superadmin_id` varchar(100) NOT NULL,
  `enq_name` varchar(100) NOT NULL,
  `enq_contact_number` varchar(100) NOT NULL,
  `enq_date` varchar(50) NOT NULL,
  `enq_location` text NOT NULL,
  `enq_msg` varchar(255) NOT NULL,
  `project_id` varchar(100) NOT NULL,
  `enq_status` varchar(100) NOT NULL,
  `done_by` varchar(100) NOT NULL,
  `created` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `ap_enquiry`
--

INSERT INTO `ap_enquiry` (`enquiry_id`, `admin_id`, `superadmin_id`, `enq_name`, `enq_contact_number`, `enq_date`, `enq_location`, `enq_msg`, `project_id`, `enq_status`, `done_by`, `created`) VALUES
('163b1b4384bb24', '163b130c39f768', '63a9739adf7d9', 'Mobile App', '6363636363', '2023/01/01 22:00', 'Coimbatore', 'Test1', '163b1a92f0c3fe|Blazon', '1', '163b130c39f768', '2023-01-1 21:56:32'),
('163b1ccf3c2710', '163b130c39f768', '63a9739adf7d9', 'Mobile App2', '5555555555', '2023/02/04 03:00', 'Coimbatores', 'sadasdas', '163b1a9213d298|ecDigi Technology', '1', '163b130c39f768', '2023-01-1 23:42:03');

-- --------------------------------------------------------

--
-- Table structure for table `ap_followup_progress`
--

CREATE TABLE `ap_followup_progress` (
  `follow_up_id` varchar(100) NOT NULL,
  `enquiry_id` varchar(100) NOT NULL,
  `admin_id` varchar(100) NOT NULL,
  `superadmin_id` varchar(100) NOT NULL,
  `follow_up_msg` varchar(255) NOT NULL,
  `project_id` varchar(100) NOT NULL,
  `follow_up_status` varchar(10) NOT NULL,
  `nxt_follow_up_date` varchar(50) NOT NULL,
  `nxt_follow_up_hint` varchar(255) NOT NULL,
  `done_by` varchar(100) NOT NULL,
  `created` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `ap_followup_progress`
--

INSERT INTO `ap_followup_progress` (`follow_up_id`, `enquiry_id`, `admin_id`, `superadmin_id`, `follow_up_msg`, `project_id`, `follow_up_status`, `nxt_follow_up_date`, `nxt_follow_up_hint`, `done_by`, `created`) VALUES
('163b1b4384bb26', '163b1b4384bb24', '163b130c39f768', '63a9739adf7d9', '', '163b1a92f0c3fe|Blazon', 'pending', '', '', '163b130c39f768', '2023-01-1 21:56:32'),
('163b1ccf3c2713', '163b1ccf3c2710', '163b130c39f768', '63a9739adf7d9', '', '163b1a9213d298|ecDigi Technology', 'pending', '', '', '163b130c39f768', '2023-01-1 23:42:03');

-- --------------------------------------------------------

--
-- Table structure for table `ap_logs`
--

CREATE TABLE `ap_logs` (
  `session_id` varchar(100) NOT NULL,
  `user_id` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `role` varchar(50) NOT NULL,
  `admin_id` varchar(100) DEFAULT NULL,
  `superadmin_id` varchar(100) NOT NULL,
  `intime` varchar(50) NOT NULL,
  `outtime` varchar(50) NOT NULL,
  `status` varchar(10) NOT NULL,
  `ipaddress` varchar(100) NOT NULL,
  `browser` varchar(100) NOT NULL,
  `platform` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `ap_logs`
--

INSERT INTO `ap_logs` (`session_id`, `user_id`, `name`, `phone`, `email`, `role`, `admin_id`, `superadmin_id`, `intime`, `outtime`, `status`, `ipaddress`, `browser`, `platform`) VALUES
('63b13a3e386ea', '63a9739adf7d9', 'Blazon', '7094792554', '0', 'superadmin', '63a9739adf7d9', '63a9739adf7d9', '2023-01-1 13:16:06', '2023-01-1 18:18:46', 'c', '::1', 'Chrome 108.0.0.0', 'Windows 10'),
('63b181435786f', '163b130c39f768', 'Paul Victory', '6369021751', '0', 'admin', '63a9739adf7d9', '63a9739adf7d9', '2023-01-1 18:19:07', '2023-01-1 18:19:21', 'c', '::1', 'Chrome 108.0.0.0', 'Windows 10'),
('63b18165e413a', '163b1811699e59', 'Paul Victory1', '6363636363', '0', 'admin', '63a9739adf7d9', '63a9739adf7d9', '2023-01-1 18:19:41', '2023-01-1 18:20:04', 'c', '::1', 'Chrome 108.0.0.0', 'Windows 10'),
('63b181941afbd', '163b1811699e59', 'Paul Victory1', '6363636363', '0', 'admin', '63a9739adf7d9', '63a9739adf7d9', '2023-01-1 18:20:28', '2023-01-1 18:20:31', 'c', '::1', 'Chrome 108.0.0.0', 'Windows 10'),
('63b1819d8cb77', '163b1811699e59', 'Paul Victory1', '6363636363', '0', 'admin', '63a9739adf7d9', '63a9739adf7d9', '2023-01-1 18:20:37', '2023-01-1 18:21:45', 'c', '::1', 'Chrome 108.0.0.0', 'Windows 10'),
('63b181f49f40d', '163b130c39f768', 'Paul Victory', '6369021751', '0', 'admin', '63a9739adf7d9', '63a9739adf7d9', '2023-01-1 18:22:04', '2023-01-1 18:22:50', 'c', '::1', 'Chrome 108.0.0.0', 'Windows 10'),
('63b1822c6c70f', '163b130c39f768', 'Paul Victory', '6369021751', '0', 'admin', '63a9739adf7d9', '63a9739adf7d9', '2023-01-1 18:23:00', '2023-01-1 18:24:33', 'c', '::1', 'Chrome 108.0.0.0', 'Windows 10'),
('63b182a6b1ae7', '163b130c39f768', 'Paul Victory', '6369021751', '0', 'admin', '63a9739adf7d9', '63a9739adf7d9', '2023-01-1 18:25:02', '2023-01-1 18:25:05', 'c', '::1', 'Chrome 108.0.0.0', 'Windows 10'),
('63b1834a3e4ce', '163b130c39f768', 'Paul Victory', '6369021751', '0', 'admin', '63a9739adf7d9', '63a9739adf7d9', '2023-01-1 18:27:46', '2023-01-1 18:29:14', 'c', '::1', 'Chrome 108.0.0.0', 'Windows 10'),
('63b183bd981b2', '163b130c39f768', 'Paul Victory', '6369021751', '0', 'admin', '63a9739adf7d9', '63a9739adf7d9', '2023-01-1 18:29:41', '2023-01-1 18:29:56', 'c', '::1', 'Chrome 108.0.0.0', 'Windows 10'),
('63b183f5582d6', '163b130c39f768', 'Paul Victory', '6369021751', '0', 'admin', '63a9739adf7d9', '63a9739adf7d9', '2023-01-1 18:30:37', '2023-01-1 18:33:33', 'c', '::1', 'Chrome 108.0.0.0', 'Windows 10'),
('63b184bfb609c', '163b130c39f768', 'Paul Victory', '6369021751', '0', 'admin', '63a9739adf7d9', '63a9739adf7d9', '2023-01-1 18:33:59', '2023-01-1 18:36:06', 'c', '::1', 'Chrome 108.0.0.0', 'Windows 10'),
('63b18549c0612', '63a9739adf7d9', 'Blazon', '7094792554', 'paul@blazon.in', 'superadmin', '63a9739adf7d9', '63a9739adf7d9', '2023-01-1 18:36:17', '2023-01-1 18:37:38', 'c', '::1', 'Chrome 108.0.0.0', 'Windows 10'),
('63b185a0a1e21', '163b130c39f768', 'Paul Victory', '6369021751', 'paulthevictory@gmail.com', 'admin', '63a9739adf7d9', '63a9739adf7d9', '2023-01-1 18:37:44', '', 'o', '::1', 'Chrome 108.0.0.0', 'Windows 10'),
('63b187651ebf8', '63a9739adf7d9', 'Blazon', '7094792554', 'paul@blazon.in', 'superadmin', '63a9739adf7d9', '63a9739adf7d9', '2023-01-1 18:45:17', '', 'o', '::1', 'Chrome 108.0.0.0', 'Windows 10');

-- --------------------------------------------------------

--
-- Table structure for table `ap_projects`
--

CREATE TABLE `ap_projects` (
  `project_id` varchar(100) NOT NULL,
  `admin_id` varchar(100) NOT NULL,
  `superadmin_id` varchar(100) NOT NULL,
  `project_name` varchar(100) NOT NULL,
  `project_status` varchar(10) NOT NULL,
  `done_by` varchar(100) NOT NULL,
  `created` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `ap_projects`
--

INSERT INTO `ap_projects` (`project_id`, `admin_id`, `superadmin_id`, `project_name`, `project_status`, `done_by`, `created`) VALUES
('163b1a9213d298', '163b130c39f768', '63a9739adf7d9', 'ecDigi Technology', '1', '163b130c39f768', '2023-01-1 21:09:13'),
('163b1a92f0c3fe', '163b130c39f768', '63a9739adf7d9', 'Blazon', '1', '163b130c39f768', '2023-01-1 21:09:27'),
('163b1a9723359c', '163b130c39f768', '63a9739adf7d9', 'Event App', '1', '163b130c39f768', '2023-01-1 21:10:34');

-- --------------------------------------------------------

--
-- Table structure for table `ap_users`
--

CREATE TABLE `ap_users` (
  `user_id` varchar(100) NOT NULL,
  `admin_id` varchar(100) NOT NULL,
  `superadmin_id` varchar(100) NOT NULL,
  `username` varchar(50) NOT NULL,
  `c_code` varchar(11) NOT NULL DEFAULT '+91',
  `phone` varchar(100) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `org_password` varchar(50) NOT NULL,
  `status` varchar(20) NOT NULL,
  `role` varchar(20) NOT NULL,
  `done_by` varchar(100) NOT NULL,
  `company_name` varchar(100) NOT NULL,
  `company_logo` varchar(100) NOT NULL,
  `created` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `ap_users`
--

INSERT INTO `ap_users` (`user_id`, `admin_id`, `superadmin_id`, `username`, `c_code`, `phone`, `email`, `password`, `org_password`, `status`, `role`, `done_by`, `company_name`, `company_logo`, `created`) VALUES
('163b130c39f768', '63a9739adf7d9', '63a9739adf7d9', 'Paul Victory', '+91', '6369021751', 'paulthevictory@gmail.com', '1d337a42154ff3e3ad0f6fab6f46dc08c23095c7', 'test123', '1', 'admin', '63a9739adf7d9', 'ecDigi Technology', '63b17ec374467.png', '2023-01-1 12:35:39'),
('163b18bc9029e1', '163b130c39f768', '63a9739adf7d9', 'Third', '+91', '5454545454', 'seconduser@gmail.com', '1d337a42154ff3e3ad0f6fab6f46dc08c23095c7', 'test123', '1', 'user', '163b130c39f768', '', '', '2023-01-1 19:04:01'),
('63a9739adf7d9', '63a9739adf7d9', '63a9739adf7d9', 'Blazon', '+91', '7094792554', 'paul@blazon.in', '19ab12c93c10c2fc65a3d5a7686b682ff7210577', 'super@123', '1', 'superadmin', '63a9739adf7d9', 'Blazon', '63a9aa8e7e9de.png', '2022-12-26 15:50:29');

-- --------------------------------------------------------

--
-- Table structure for table `enquiry`
--

CREATE TABLE `enquiry` (
  `enquiry_id` varchar(100) NOT NULL,
  `customer_id` varchar(100) NOT NULL,
  `enq_name` varchar(50) NOT NULL,
  `enq_contact_number` varchar(100) NOT NULL,
  `enq_date` varchar(50) NOT NULL,
  `enq_location` varchar(100) NOT NULL,
  `enq_msg` varchar(255) NOT NULL,
  `project_id` varchar(100) NOT NULL,
  `enq_status` varchar(50) NOT NULL,
  `created_date` varchar(50) NOT NULL,
  `created_time` varchar(50) NOT NULL,
  `done_by` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `enquiry`
--

INSERT INTO `enquiry` (`enquiry_id`, `customer_id`, `enq_name`, `enq_contact_number`, `enq_date`, `enq_location`, `enq_msg`, `project_id`, `enq_status`, `created_date`, `created_time`, `done_by`) VALUES
('63aaf4fb2b1af', '163a9aa8e7ecb5', 'Software Development', '7094792554', '2022/12/27 20:00', 'Coimbatore', 'Test', '163aadeb5786e8|Blazon', '1', '2022-12-27', '19:06:59', '163a9aa8e7ecb5'),
('63ac39ed75760', '163a9aa8e7ecb5', 'Website Name', '7094792554', '2022/12/26 20:00', 'Coimbatore', 'Test', '163ac39dc61e10|Blazon New', '1', '2022-12-28', '18:13:25', '163a9aa8e7ecb5');

-- --------------------------------------------------------

--
-- Table structure for table `follow_up_progress`
--

CREATE TABLE `follow_up_progress` (
  `follow_up_id` varchar(100) NOT NULL,
  `enquiry_id` varchar(100) NOT NULL,
  `customer_user_id` varchar(100) NOT NULL,
  `follow_up_msg` varchar(255) NOT NULL,
  `project_id` varchar(100) NOT NULL,
  `follow_up_status` varchar(50) NOT NULL,
  `nxt_follow_up_date` varchar(50) NOT NULL,
  `nxt_follow_up_time` varchar(50) NOT NULL,
  `nxt_follow_up_hint` varchar(255) NOT NULL,
  `created_date` varchar(50) NOT NULL,
  `created_time` varchar(50) NOT NULL,
  `done_by` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `follow_up_progress`
--

INSERT INTO `follow_up_progress` (`follow_up_id`, `enquiry_id`, `customer_user_id`, `follow_up_msg`, `project_id`, `follow_up_status`, `nxt_follow_up_date`, `nxt_follow_up_time`, `nxt_follow_up_hint`, `created_date`, `created_time`, `done_by`) VALUES
('63ac0bd89b6ab', '63aaf4fb2b1af|Software Development', '163a9aa8e7ecb5', 'Mobile app development', '163aadeac63060|ecDigi Technology', 'rejected', '2022/12/31 22:00', '', 'Test test', '2022-12-28', '14:56:48', '163a9aa8e7ecb5'),
('63ac0c4022192', '63ac39ed75760|Website Name', '163a9aa8e7ecb5', 'Software process new', '163aadeb5786e8|Blazon', 'completed', '2022/12/30 22:00', '', 'Test test', '2022-12-28', '14:58:32', '163a9aa8e7ecb5'),
('63ac332560255', '63aaf4fb2b1af|Software Development', '163a9aa8e7ecb5', 'Software process new', '163aadeb5786e8|Blazon', 'followup', '2022/12/30 22:00', '', 'Test test', '2022-12-28', '17:44:29', '163a9aa8e7ecb5'),
('63ac3a14d109a', '63ac39ed75760|Website Name', '163a9aa8e7ecb5', 'Software process new', '163ac39dc61e10|Blazon New', 'cancel', '2022/12/30 22:00', '', 'Test', '2022-12-28', '18:14:04', '163a9aa8e7ecb5');

-- --------------------------------------------------------

--
-- Table structure for table `project_details`
--

CREATE TABLE `project_details` (
  `project_id` varchar(100) NOT NULL,
  `customer_id` varchar(100) NOT NULL,
  `project_name` varchar(100) NOT NULL,
  `project_status` varchar(50) NOT NULL,
  `created_date` varchar(50) NOT NULL,
  `created_time` varchar(50) NOT NULL,
  `done_by` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `project_details`
--

INSERT INTO `project_details` (`project_id`, `customer_id`, `project_name`, `project_status`, `created_date`, `created_time`, `done_by`) VALUES
('163aadeac63060', '163a9aa8e7ecb5', 'ecDigi Technology', '1', '2022-12-27', '17:31:48', '163a9aa8e7ecb5'),
('163aadeb5786e8', '163a9aa8e7ecb5', 'Blazon', '1', '2022-12-27', '17:31:57', '163a9aa8e7ecb5'),
('163aae32c1dcff', '163a9aa8e7ecb5', 'Mobile app Company', '1', '2022-12-27', '17:51:00', '163a9aa8e7ecb5'),
('163ac39dc61e10', '163a9aa8e7ecb5', 'Blazon New', '1', '2022-12-28', '18:13:08', '163a9aa8e7ecb5'),
('163ad85b10401f', '163a9aa8e7ecb5', 'blazon New project', '1', '2022-12-29', '17:48:57', '163a9aa8e7ecb5');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ap_action`
--
ALTER TABLE `ap_action`
  ADD UNIQUE KEY `action_id` (`action_id`);

--
-- Indexes for table `ap_enquiry`
--
ALTER TABLE `ap_enquiry`
  ADD UNIQUE KEY `enquiry_id` (`enquiry_id`);

--
-- Indexes for table `ap_followup_progress`
--
ALTER TABLE `ap_followup_progress`
  ADD UNIQUE KEY `follow_up_id` (`follow_up_id`);

--
-- Indexes for table `ap_logs`
--
ALTER TABLE `ap_logs`
  ADD UNIQUE KEY `session_id` (`session_id`);

--
-- Indexes for table `ap_projects`
--
ALTER TABLE `ap_projects`
  ADD UNIQUE KEY `project_id` (`project_id`);

--
-- Indexes for table `ap_users`
--
ALTER TABLE `ap_users`
  ADD UNIQUE KEY `user_id` (`user_id`),
  ADD UNIQUE KEY `phone` (`phone`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `enquiry`
--
ALTER TABLE `enquiry`
  ADD UNIQUE KEY `enquiry_id` (`enquiry_id`);

--
-- Indexes for table `follow_up_progress`
--
ALTER TABLE `follow_up_progress`
  ADD UNIQUE KEY `follow_up_id` (`follow_up_id`);

--
-- Indexes for table `project_details`
--
ALTER TABLE `project_details`
  ADD UNIQUE KEY `project_id` (`project_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

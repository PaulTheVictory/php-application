<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User_Model extends CI_Model {

  public function __construct()
  {
    parent::__construct();
    $this->load->database();
    $this->load->library('email');
    $this->load->library('Datatables');
  }


  //all enquiry

  public function getallenquiry()
  {


    $arr = array();
    $arr['elist'] = '<table id="customer_view" class="display dataTable">';
    $c_user = $this->session->userdata("customer_id");
    $query = $this->db->query('select * from enquiry where enq_status="1" and customer_id="' . $c_user . '" order by created_time DESC');
    $row = $query->result_array();
    $arr['elist_count'] = count($row);
    if ($row) {
      $arr['elist'] .= '
  <thead>
  <tr>
  <th>S No</th>
  <th>Enquiry Name</th>
  <th>Phone Number</th>
  <th>Enquiry Date</th>
  <th>Location</th>
  <th>Message</th>
  <th>Project Name</th>
  
  </thead>';
      $arr['elist'] .= '<tbody>';
      for ($i = 0; $i < count($row); $i++) {

        $cid = $row[$i]['enquiry_id'];
        $cname = $row[$i]['enq_name'];
        $cphone = $row[$i]['enq_contact_number'];
        $cdate = $row[$i]['enq_date'];
        $clocation = $row[$i]['enq_location'];
        $cmsg = $row[$i]['enq_msg'];
        $cprojectname = explode("|", $row[$i]['project_id']);


        $arr['elist'] .= '
    <tr>
    <td>' . $i . '</td>
    <td>' . $cname . '</td>
    <td>' . $cphone . '</td>
    <td>' . $cdate . '</td>
    <td>' . $clocation . '</td>
    <td>' . $cmsg . '</td>
    <td>' . $cprojectname[1] . '</td>
    </tr>';
      }
    } else {
      $arr['elist'] .= '<tbody><tr><td>No Records Found</td></tr>';
    }
    $arr['elist'] .= '</tbody></table>';
    return $arr;
  }




//all enquiry

public function getallfollowup()
{


  $arr = array();
  $arr['flist'] = '<table id="customer_view" class="display dataTable">';
  $c_user = $this->session->userdata("customer_id");
  $query = $this->db->query('select * from follow_up_progress where customer_user_id="' . $c_user . '" order by created_date DESC');
  $row = $query->result_array();
  $arr['flist_count'] = count($row);
  if ($row) {
    $arr['flist'] .= '
<thead>
<tr>
<th>S No</th>
<th>Project Name</th>
<th>Enquiry Name</th>
<th>Follow Message</th>
<th>Status</th>
<th>Date</th>
<th>Follow Hint</th>

</thead>';
    $arr['flist'] .= '<tbody>';
    for ($i = 0; $i < count($row); $i++) {
      $fid = $row[$i]['follow_up_id'];
      $pid = explode("|", $row[$i]['project_id']);
      $eid = explode("|", $row[$i]['enquiry_id']);
      $fmsg = $row[$i]['follow_up_msg'];
      $f_status = $row[$i]['follow_up_status'];
      $fdate = $row[$i]['nxt_follow_up_date'];
      $fhint = $row[$i]['nxt_follow_up_hint'];

      if($f_status==="pending" | $f_status==="followup") {
        $bclass="primary_status";
      } elseif($f_status==="cancel" | $f_status==="rejected" | $f_status==="noresponse") {
        $bclass="danger_status";
      } elseif($f_status==="completed") {
        $bclass="success_status";
      }



      $arr['flist'] .= '
<tr>
<td>' . $i . '</td>
<td>' . $pid[1] . '</td>
<td>' . $eid[1] . '</td>
<td>' . $fmsg . '</td>
<td><button class="'.$bclass.'">'.$f_status.'</button></td>
<td>' . $fdate . '</td>
<td>' . $fhint . '</td>
</tr>';
    }
  } else {
    $arr['flist'] .= '<tbody><tr><td>No Records Found</td></tr>';
  }
  $arr['flist'] .= '</tbody></table>';
  return $arr;
}










}
<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Login_Model extends CI_Model
{


  public function common_admin_login($username, $password)
  {
    $query = $this->db->query('select * from ap_users where (email="'. $username.'" or phone="'.$username.'") and password="'.$password. '" and status="1" and (role="superadmin" or role="admin" or role="user")');


    if ($query->num_rows() === 1) {
      return $query->result();
    } else {
      return false;
    }
  }


  public function CreateSession($s_user_id, $s_username, $s_admin_id, $s_superadmin_id, $s_email, $s_phone, $s_role, $s_intime, $s_browser, $s_platform, $s_ip)
  {
    $sess_id = uniqid();
    $this->session->set_userdata("session_id", $sess_id);

    $data = array(
      "session_id"=> $sess_id,
      "user_id"=> $s_user_id,
      "name"=> $s_username,
      "phone"=> $s_phone,
      "email"=> $s_email,
      "role"=> $s_role,
      "admin_id"=> $s_admin_id,
      "superadmin_id"=> $s_superadmin_id,
      "intime"=> $s_intime,
      "outtime"=>"",
      "status"=>"o",
      "ipaddress"=> $s_ip,
      "browser"=> $s_browser,
      "platform"=> $s_platform,
    );

    $result = $this->db->insert("ap_logs", $data);

    if ($result) {
      return true;
    } else {
      return false;
    }
  }

  public function EndSession($s_id, $date)
  {

    $data = array(
      "outtime"=> $date,
      "status"=>"c",
    );
    $query = $this->db->where("session_id", $s_id)->update("ap_logs",$data);

    if ($query) {
      return true;
    } else {
      return false;
    }
  }

 
}

<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');

class Superadmin_Model extends CI_Model
{
  public function __construct()
  {
    parent::__construct();
    $this->load->database();
    $this->load->library('email');
    $this->load->library('Datatables');
  }


  //add customer


  public function add_customer($c_user_id, $c_admin_id, $c_superadmin_id, $c_date, $c_name, $c_cname, $c_email, $c_phone, $c_password, $c_orgpassword, $c_image)
  {
    $result = array(0 => "");
    $user_id = uniqid(true);
    $action_id = uniqid(true);

    $data = array(
      "user_id" => $user_id,
      "admin_id" => $c_admin_id,
      "superadmin_id" => $c_superadmin_id,
      "username" => $c_name,
      "phone" => $c_phone,
      "email" => $c_email,
      "password" => $c_password,
      "org_password" => $c_orgpassword,
      "status" => 1,
      "role" => "admin",
      "done_by" => $c_user_id,
      "company_name" => $c_cname,
      "company_logo" => $c_image,
      "created" => $c_date,
    );

    $data1 = array(
      "action_id" => $action_id,
      "action_type" => "create",
      "action_name" => "Create Customer",
      "module_id" => $user_id,
      "done_by" => $c_user_id,
      "created" => $c_date,
    );

    $res = $this->db->insert("ap_users", $data);
    $res1 = $this->db->insert("ap_action", $data1);

    if ($res && $res1) {
      $result = array(0 => "success");
      return $result;
    } else {
      $result = array(0 => "fail");
      return $result;
    }
  }


  //get all customer active details

  public function GetCustomerLists()
  {
    $arr = array();
    $arr['clist'] = '<table id="customer_view" class="display dataTable">';
    $arr['clist'] .= '
    <thead>
    <tr>
    <th>S No</th>
    <th>Company Name</th>
    <th>Email</th>
    <th>Phone</th>
    <th>Logo</th>
    <th>Status</th>
    <th>Action</th>
    </thead>';
    $query = $this->db->select("*")
      ->from("ap_users")
      ->group_start()
      ->where("role", "admin")
      ->where("user_id !=", "63a9739adf7d9")
      ->group_end()
      ->get();
    $row = $query->result_array();
    $arr['customer_list_count'] = count($row);
    if ($row) {

      $arr['clist'] .= '<tbody>';
      for ($i = 0; $i < count($row); $i++) {

        $user_id = $row[$i]['user_id'];
        $company_name = $row[$i]['company_name'];
        $email = $row[$i]['email'];
        $phone = $row[$i]['phone'];
        $company_logo = $row[$i]['company_logo'];
        $status = $row[$i]['status'];



        $arr['clist'] .= '
  <tr>
  <td>' . $i . '</td>
  <td>' . $company_name . '</td>
  <td>' . $email . '</td>
  <td>' . $phone . '</td>
  <td><img src="' . base_url() . '/docs/customerlogo/' . $company_logo . '" alt="' . $company_name . '" class="c_logo_style" /></td>
  <td>' . ($status == 1 ? '<button class="a_btn status_update" data-uid="' . $user_id . '" data-sid="' . $status . '">Active</button>' : '<button class="ina_btn status_update" data-uid="' . $user_id . '" data-sid="' . $status . '">In Active</button>') . '</td>
  <td>
  <div class="action_btn">
  <button type="button" class="btn btn-sm btn-primary view_customer_new" data-uid="' . $user_id . '"><i class="fa fa-eye"></i> </button>
    <button type="button" class="btn btn-sm btn-success edit_customer_new" data-uid="' . $user_id . '"><i class="fa fa-edit"></i> </button>
          <button class="btn btn-sm btn-danger delete_customer" type="submit" data-uid="' . $user_id . '"><i class="fa fa-trash"></i> </button></div>
      </td></tr>';
      }
    } else {

      $arr['clist'] .= '<tbody>';
    }
    $arr['clist'] .= '</tbody></table>';
    return $arr;
  }

  //


  public function getsinglecustomerdetails($f_id)
  {

    $this->db->select("*");
    $this->db->from("ap_users");
    $this->db->where("user_id", $f_id);
    $this->db->limit(1);
    $query = $this->db->get();
    $res = $query->result();
    if ($res) {
      return $res;
    }
  }

  //view usetomer

  public function get_customerview_details($view_id) {
    $result="";
    $query = $this->db->select("*")
              ->from("ap_users")
              ->where("user_id",$view_id)
              ->limit(1)
              ->get();

    $row = $query->result_array();
    if($row) {
    $result = '<div class="customer_view_details">
          <h2>Customer Details</h2>
          <ul>
            <li>
              <span>Name:</span>
              <span>'. $row[0]["username"]. '</span>
            </li>
            <li>
              <span>Phone:</span>
              <span>' . $row[0]["phone"] . '</span>
            </li>
            <li>
              <span>Email ID:</span>
              <span>' . $row[0]["email"] . '</span>
            </li>
            <li>
              <span>Password:</span>
              <span>' . $row[0]["org_password"] . '</span>
            </li>
            <li>
              <span>Company Name:</span>
              <span>' . $row[0]["company_name"] . '</span>
            </li>
            <li>
              <span>Role:</span>
              <span>' . $row[0]["role"] . '</span>
            </li>
            <li>
              <span>Company Logo:</span>
              <span><img src="' . base_url('docs/customerlogo/'.$row[0]["company_logo"].'') . '" /></span>
            </li>
          </ul>
        </div>
        <hr />
        <div class="customer_view_addtionaldetails">
          <h2>Addtional Details</h2>
          <ul>
            <li>
              <span>User ID:</span>
              <span>' . $row[0]["user_id"] . '</span>
            </li>
            <li>
              <span>Status:</span>
              <span>' . ($row[0]["status"] == 1 ? '<button class="a_btn status_update" data-uid="' . $row[0]["user_id"] . '" data-sid="' . $row[0]["status"] . '">Active</button>' : '<button class="ina_btn status_update" data-uid="' . $row[0]["user_id"] . '" data-sid="' . $row[0]["status"] . '">In Active</button>') . '</span>
            </li>
            <li>
              <span>Done By:</span>
              <span>' . $row[0]["done_by"] . '</span>
            </li>
            <li>
              <span>Joining Date:</span>
              <span>' . $row[0]["created"] . '</span>
            </li>
           
          </ul>
        </div>';
      return $result;
    } else {
      return $result;
    }
    



  }


  /*Delete Customer*/

  public function DeleteCustomerById($deleteid)
  {
    $result = array(0 => '');
    $query = $this->db->query('update customers set customer_status="0" where customer_id="' . $deleteid . '"');
    if ($query) {
      $result = array(0 => 'success');
      return $result;
    } else {
      $result = array(0 => 'fail');
      return $result;
    }
  }

  /*active*/

  public function UpdateById($deleteid, $sid)
  {
    date_default_timezone_set("Asia/Calcutta");
    $a_status = $sid == 1 ? 0 : 1;
    $result = array(0 => '');
    $action_id = uniqid(true);
    $data1 = array(
      "action_id" => $action_id,
      "action_type" => "update",
      "action_name" => "Status Update Customer",
      "module_id" => $deleteid,
      "done_by" => $this->session->userdata("user_id"),
      "created" => date('Y-m-j H:i:s'),
    );

    $res1 = $this->db->insert("ap_action", $data1);
    $data = array(
      "status"=> $a_status,
    );
    $query = $this->db->where("user_id", $deleteid)->update("ap_users", $data);
    if ($query && $res1) {
      $result = array(0 => 'success');
      return $result;
    } else {
      $result = array(0 => 'fail');
      return $result;
    }
  }


  /*Delete permanently*/

  public function DeleteById($deleteid)
  {
    $result = array(0 => '');
    date_default_timezone_set("Asia/Calcutta");
    $action_id = uniqid(true);
    $data1 = array(
      "action_id" => $action_id,
      "action_type" => "delete",
      "action_name" => "Delete Customer",
      "module_id" => $deleteid,
      "done_by" => $this->session->userdata("user_id"),
      "created" => date('Y-m-j H:i:s'),
    );
    $res1 = $this->db->insert("ap_action", $data1);
    $query = $this->db->where("user_id", $deleteid)->delete("ap_users");
    if ($query && $res1) {
      $result = array(0 => 'success');
      return $result;
    } else {
      $result = array(0 => 'fail');
      return $result;
    }
  }


  /*Recovery user*/

  public function RecoveryById($recoveryid)
  {
    $result = array(0 => '');
    $query = $this->db->query('update customers set customer_status="1" where customer_id="' . $recoveryid . '"');
    if ($query) {
      $result = array(0 => 'success');
      return $result;
    } else {
      $result = array(0 => 'fail');
      return $result;
    }
  }


  /*View Single User Profile*/

  public function ViewSingleUserById($viewid)
  {
    $arr = array();
    $arr['singlecustomer'] = array();
    $query = $this->db->query('select * from customers where customer_id="' . $viewid . '"');
    $row = $query->result_array();


    if ($query->num_rows() > 0) {
      return $row[0];
    } else {
      return $arr;
    }
  }

  //update customer


  public function update_customer($c_name, $c_password, $c_image, $viewid, $c_orgpassword)
  {
    $result = array(0 => "");
    $action_id = uniqid(true);
    date_default_timezone_set("Asia/Calcutta");
    $data = array(
      "username"=> $c_name,
      "password"=> $c_password,
      "org_password"=> $c_orgpassword,
      "company_logo"=> $c_image,
    );
    $data1 = array(
      "action_id" => $action_id,
      "action_type" => "update",
      "action_name" => "Update Customer",
      "module_id" => $viewid,
      "done_by" => $this->session->userdata("user_id"),
      "created" => date('Y-m-j H:i:s'),
    );

    $res1 = $this->db->insert("ap_action", $data1);

    $res = $this->db->where("user_id", $viewid)->update("ap_users",$data);
    if ($res && $res1) {
      $result = array(0 => "success");
      return $result;
    } else {
      $result = array(0 => "fail");
      return $result;
    }
  }

  //update customer
  public function updatenoimage_customer($c_name, $c_password, $viewid, $c_orgpassword)
  {
    $result = array(0 => "");
    $action_id = uniqid(true);
    date_default_timezone_set("Asia/Calcutta");
    $data = array(
      "username" => $c_name,
      "password" => $c_password,
      "org_password" => $c_orgpassword,
    );
    $data1 = array(
      "action_id" => $action_id,
      "action_type" => "update",
      "action_name" => "Update Customer",
      "module_id" => $viewid,
      "done_by" => $this->session->userdata("user_id"),
      "created" => date('Y-m-j H:i:s'),
    );
    $res1 = $this->db->insert("ap_action", $data1);

    $res = $this->db->where("user_id", $viewid)->update("ap_users", $data);
    if ($res && $res1) {
      $result = array(0 => "success");
      return $result;
    } else {
      $result = array(0 => "fail");
      return $result;
    }
  }


  // all logs

  //get all customer active details

  public function GetLogLists()
  {
    $arr = array();
    $arr['llist'] = '<table id="customer_view" class="display dataTable">';

    $query = $this->db->query('select * from ap_logs order by outtime DESC');
    $row = $query->result_array();
    $arr['customer_list_count'] = count($row);
    if ($row) {
      $arr['llist'] .= '
  <thead>
  <tr>
  <th>S No</th>
  <th>Login Id</th>
  <th>Name</th>
  <th>Role</th>
  <th>Intime</th>
  <th>Outtime</th>

  </thead>';
      $arr['llist'] .= '<tbody>';
      for ($i = 0; $i < count($row); $i++) {

        $user_id = $row[$i]['user_id'];
        $name = $row[$i]['name'];
        $role = $row[$i]['role'];
        $intime = $row[$i]['intime'];
        $outtime = $row[$i]['outtime'];




        $arr['llist'] .= '
  <tr>
  <td>' . $i . '</td>
  <td>' . $user_id . '</td>
  <td>' . $name . '</td>
  <td>' . $role . '</td>
  <td>' . $intime . '</td>
  <td>' . $outtime . '</td>
  
  </tr>';
      }
    } else {
      $arr['llist'] .= '<tbody><tr><td>No Records Found</td></tr>';
    }
    $arr['llist'] .= '</tbody></table>';
    return $arr;
  }




  //get all user active details

  public function GetUsersLists()
  {
    $arr = array();
    $arr['clist'] = '<table id="customer_view" class="display dataTable">';
    $c_userid = $this->session->userdata("user_id");
    $query = $this->db->query('select * from customer_login order by created_time DESC');
    $row = $query->result_array();
    $arr['customer_list_count'] = count($row);
    if ($row) {
      $arr['clist'] .= '
<thead>
<tr>
<th>S No</th>
<th>User Id</th>
<th>Customer Id</th>
<th>Name</th>
<th>Email</th>
<th>Role</th>
<th>Status</th>
<th>Joining Date</th>

</thead>';
      $arr['clist'] .= '<tbody>';
      for ($i = 0; $i < count($row); $i++) {

        $cid = $row[$i]['customer_user_id'];
        $cusid = $row[$i]['customer_id'];
        $cname = $row[$i]['customer_user_name'];
        $cemail = $row[$i]['customer_email'];
        $crole = $row[$i]['role'];
        $cstatus = $row[$i]['customer_login_status'];
        $jdate = $row[$i]['created_date'];


        $arr['clist'] .= '
<tr>
<td>' . $i . '</td>
<td>' . $cid . '</td>
<td>' . $cusid . '</td>
<td>' . $cname . '</td>
<td>' . $cemail . '</td>
<td>' . $crole . '</td>
<td>' . ($cstatus == 1 ? '<button class="a_btn status_update" data-uid="' . $cid . '" data-sid="' . $cstatus . '">Active</button>' : '<button class="ina_btn status_update" data-uid="' . $cid . '" data-sid="' . $cstatus . '">In Active</button>') . '</td>
<td>' . $jdate . '</td>
</tr>';
      }
    } else {
      $arr['clist'] .= '<tbody><tr><td>No Records Found</td></tr>';
    }
    $arr['clist'] .= '</tbody></table>';
    return $arr;
  }




  //get all superadmin list

  public function GetSuperAdminLists()
  {
    $arr = array();
    $arr['splist'] = '<table id="customer_view" class="display dataTable">';
    $c_userid = $this->session->userdata("user_id");
    $query = $this->db->query('select * from admin where admin_id<>"63a9739adf7d9" order by created DESC');
    $row = $query->result_array();
    $arr['customer_list_count'] = count($row);
    if ($row) {
      $arr['splist'] .= '
<thead>
<tr>
<th>S No</th>
<th>Admin Id</th>
<th>Username</th>
<th>Role</th>
<th>Status</th>
<th>Joining Date</th>
<th>Action</th>
</thead>';
      $arr['splist'] .= '<tbody>';
      for ($i = 0; $i < count($row); $i++) {


        $cid = $row[$i]['admin_id'];
        $cname = $row[$i]['user_name'];
        $crole = $row[$i]['role'];
        $cstatus = $row[$i]['status'];
        $jdate = date_create($row[$i]['created']);


        $arr['splist'] .= '

<td>' . $i . '</td>
<td>' . $cid . '</td>
<td>' . $cname . '</td>
<td>' . $crole . '</td>
<td>' . ($cstatus == 1 ? '<button class="a_btn status_update" data-uid="' . $cid . '" data-sid="' . $cstatus . '">Active</button>' : '<button class="ina_btn status_update" data-uid="' . $cid . '" data-sid="' . $cstatus . '">In Active</button>') . '</td>
<td>' . date_format($jdate, "d/m/Y") . '</td>
<td>
  <div class="action_btn">
    <button type="button" class="btn btn-sm btn-success edit_superadmin" data-uid="' . $cid . '"><i class="fa fa-edit" aria-hidden="true"></i></button>
    
          <button class="btn btn-sm btn-danger delete_superadmin" type="submit" data-uid="' . $cid . '"><i class="fa fa-trash"></i></button></div>
      </td>
</tr>';
      }
    } else {
      $arr['splist'] .= '<tbody><tr><td>No Records Found</td></tr>';
    }
    $arr['splist'] .= '</tbody></table>';
    return $arr;
  }



  public function add_super_admin($c_email, $c_password, $c_date, $c_doneby, $c_orgpassword)
  {

    $result = array(0 => "");
    $admin_id = uniqid(true);
    $thisid = $this->session->userdata("user_id");
    $data = array(
      "admin_id" => $admin_id,
      "user_name" => $c_email,
      "pass_word" => $c_password,
      "org_password" => $c_orgpassword,
      "status" => 1,
      "org_password" => $c_orgpassword,
      "role" => "superadmin",
      "created" => $c_date,
      "done_by" => $thisid,
    );
    if ($thisid !== "63a9739adf7d9") {
      $result = array(0 => "fail");
      return $result;
    } else {

      $res = $this->db->insert("admin", $data);

      if ($res) {
        $result = array(0 => "success");
        return $result;
      } else {
        $result = array(0 => "fail");
        return $result;
      }
    }
  }

  /*active*/

  public function UpdateSuperadminById($deleteid, $sid)
  {
    $a_status = $sid == 1 ? 0 : 1;
    $result = array(0 => '');
    $query = $this->db->query('update admin set status="' . $a_status . '" where admin_id ="' . $deleteid . '"');
    if ($query) {
      $result = array(0 => 'success');
      return $result;
    } else {
      $result = array(0 => 'fail');
      return $result;
    }
  }


  /*Delete permanently*/

  public function DeleteSuperAdminById($deleteid)
  {
    $result = array(0 => '');
    $query = $this->db->query('delete from admin where admin_id ="' . $deleteid . '"');
    if ($query) {
      $result = array(0 => 'success');
      return $result;
    } else {
      $result = array(0 => 'fail');
      return $result;
    }
  }


  //update superadmin
  public function update_super_admin($c_email, $c_password, $c_orgpassword, $admin_id)
  {
    $result = array(0 => "");
    $thisid = $this->session->userdata("user_id");


    $res = $this->db->query('update admin set 	user_name="' . $c_email . '",pass_word="' . $c_password . '",org_password	="' . $c_orgpassword . '" where admin_id="' . $admin_id . '"');

    if ($thisid !== "63a9739adf7d9") {
      $result = array(0 => "fail");
      return $result;
    } else {
      if ($res) {
        $result = array(0 => "success");
        return $result;
      } else {
        $result = array(0 => "fail");
        return $result;
      }
    }
  }
  //
  public function getsinglesuperdetails($f_id)
  {

    $this->db->select("*");
    $this->db->from("admin");
    $this->db->where("admin_id", $f_id);
    $this->db->limit(1);
    $query = $this->db->get();
    $res = $query->result();
    if ($res) {
      return $res;
    }
  }
}

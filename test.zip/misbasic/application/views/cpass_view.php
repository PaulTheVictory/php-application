<?php
defined('BASEPATH') or exit('No direct script access allowed');
?>

<div class="add_customer">
  <div class="add_customer_form">
    <h2>Change Password</h2>
    <?php echo validation_errors(); ?>
    <?php if ($this->session->flashdata('success')) { ?>
          <?php echo $this->session->flashdata('success'); ?>
        <?php } elseif ($this->session->flashdata('fail')) { ?>
          <?php echo $this->session->flashdata('fail'); ?>
        <?php } ?>
    <?php echo form_open('changepassword/cpass_change', 'method="post" accept-charset="utf-8" name="changepassword" id="changepassword"'); ?>
      <input type="password" placeholder="Old Password" name="old_pass" id="old_pass" value="<?php echo set_value('old_pass'); ?>" />
      <input type="password" placeholder="New Password" name="new_pass" id="new_pass" value="<?php echo set_value('new_pass'); ?>" />
      <input type="password" placeholder="Confirm Password" name="confirm_pass" id="confirm_pass" value="<?php echo set_value('confirm_pass'); ?>"  />
      <button type="submit" name="submit" class="btn btn-success">Update Password</button>
    </form>
  </div>
</div>



<script>

$(document).ready(function(){
  $(".alert").delay(4000).slideUp(200, function() {
    $(this).alert('close');
});
});

</script>
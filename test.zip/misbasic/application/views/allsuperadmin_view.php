<?php
defined('BASEPATH') or exit('No direct script access allowed');
?>

<div class="enqiry_top_view">
  <button class="btn btn-primary add_superadmin_new btn-sm"><i class="fa fa-plus" aria-hidden="true"></i> Add Superadmin</button>

</div>
<div class="enqiry_view">
  <?php echo $allsuperadmin['splist']; ?>
</div>



<div class="modal fade" id="projectmodel" tabindex="-1" aria-labelledby="projectmodeltitle" aria-hidden="true">
  <div class="modal-dialog modal-md">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="projectmodeltitle">Create Superadmin</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <?php echo validation_errors(); ?>
        <?php if ($this->session->flashdata('notadded')) { ?>
          <?php echo $this->session->flashdata('notadded'); ?>
        <?php } elseif ($this->session->flashdata('success')) { ?>
          <?php echo $this->session->flashdata('success'); ?>
        <?php } ?>

        <?php echo form_open('allsuperadmin/newsuperadmin', 'method="post" accept-charset="utf-8" name="addsuperadmin" id="addsuperadmin"'); ?>
        <input type="text" name="user_name" placeholder="User Email" id="" value="<?php echo set_value('user_name'); ?>" />
        <input type="text" name="pass_word" placeholder="User Password" id="" value="<?php echo set_value('pass_word'); ?>" />

        <button type="submit" name="submit" class="btn btn-primary">Create Superadmin</button>
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
       </div>
    </div>
  </div>
</div>


<div class="modal fade" id="customermodeledit" tabindex="-1" aria-labelledby="ecustomermodeltitle" aria-hidden="true">
  <div class="modal-dialog modal-md">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="ecustomermodeltitle">Edit User</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
      <?php echo validation_errors(); ?>
        <?php if ($this->session->flashdata('enotadded')) { ?>
          <?php echo $this->session->flashdata('enotadded'); ?>
        <?php } elseif ($this->session->flashdata('success')) { ?>
          <?php echo $this->session->flashdata('success'); ?>
        <?php } ?>
        <?php echo form_open_multipart('allsuperadmin/update_superadmin', 'method="post" accept-charset="utf-8" name="update_superadmin" id="update_superadmin"'); ?>


        <input type="hidden" name="admin_id" id="admin_id" />
        <input type="text" name="user_name" placeholder="User Name" id="euser_name" />
        <input type="text" name="pass_word" placeholder="Password" id="epass_word" />

        <button type="submit" name="submit" class="btn btn-success">Update User</button>
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <!-- <button type="button" class="btn btn-primary">Save project</button> -->
      </div>
    </div>
  </div>
</div>


<script>
  jQuery(document).ready(function($) {

    /*View User*/
    $('#customer_view').DataTable({
      'responsive': true,
      "processing": true,
      "bInfo": false,
      columnDefs: [{
        width: '20%'
      }],
      fixedColumns: true,
      "fnRowCallback": function(nRow, aData, iDisplayIndex) {
        $("td:first", nRow).html(iDisplayIndex + 1);
        return nRow;
      },
    });

    //

    $(document).on("click", ".add_superadmin_new", function(d) {
      d.preventDefault();
      $('#projectmodel').modal('show');
    });

    //

    //update status

    $(document).on("click", ".status_update", function(d) {
      d.preventDefault();
      var updateid = $(this).data('uid');
      var sid = $(this).data('sid');
      swal({
          title: "Are you sure to update?",
          text: "able to change active & in active this file.",
          type: "warning",
          showCancelButton: true,
          confirmButtonColor: "#157347",
          confirmButtonText: "Update",
          cancelButtonText: "Cancel",
          closeOnConfirm: false,
          closeOnCancel: false
        },
        function(isConfirm) {
          if (isConfirm) {
            $.ajax({
              url: 'allsuperadmin/UpdateSuperadmin',
              type: 'POST',
              data: {
                'updateid': updateid,
                "sid": sid,
              },
              success: function(data) {
                var dlt = $.parseJSON(data);
                if (dlt[0] == 'success') {
                  swal("Updated Successfully", "You clicked the button!", "success");
                  setTimeout(function() {
                    location.reload();
                  }, 1500);
                } else if (dlt[0] == 'fail') {
                  swal("Could Not Updated", "Something went Wrong!", "error");
                }
              }
            });
          } else {
            swal("Cancelled", "Your file is safe :)", "error");
          }
        });

    });

    //

    $(document).on("click", ".delete_superadmin", function(d) {
      d.preventDefault();
      var deleteid = $(this).data('uid');
      swal({
          title: "Are you sure to delete?",
          text: "Not able to retrieve this file.",
          type: "warning",
          showCancelButton: true,
          confirmButtonColor: "#DD6B55",
          confirmButtonText: "Delete",
          cancelButtonText: "Cancel",
          closeOnConfirm: false,
          closeOnCancel: false
        },
        function(isConfirm) {
          if (isConfirm) {
            $.ajax({
              url: 'allsuperadmin/DeleteSuperAdmin',
              type: 'POST',
              data: {
                'deleteid': deleteid
              },
              success: function(data) {
                var dlt = $.parseJSON(data);
                if (dlt[0] == 'success') {
                  swal("Deleted Successfully", "You clicked the button!", "success");
                  setTimeout(function() {
                    location.reload();
                  }, 1500);
                } else if (dlt[0] == 'fail') {
                  swal("Could Not Deleted", "Something went Wrong!", "error");
                }
              }
            });
          } else {
            swal("Cancelled", "Your file is safe :)", "error");
          }
        });

    });

    //

    $(document).on("click", ".edit_superadmin", function(d) {
      d.preventDefault();
      var f_id = $(this).data('uid');
      $.ajax({
        url: "<?php echo base_url("allsuperadmin/getsinglesuperadmin"); ?>",
        type: "POST",
        data: {
          'f_id': f_id,
        },
        cache: false,
        success: function(data) {
          //alert(result);
          var dlt = $.parseJSON(data);
          console.log(dlt["result"][0]);
          // console.log(dlt["result"][0].follow_up_id);
          $("#admin_id").val(dlt["result"][0].admin_id);
          $("#euser_name").val(dlt["result"][0].user_name);
          $("#epass_word").val(dlt["result"][0].org_password);
          


        }
      });
      $('#customermodeledit').modal('show');
    });


  });
</script>

<?php if (validation_errors()) { ?>


<script>
  addEventListener("load", (event) => {
    $('#projectmodel').modal('show');
  });
</script>

<?php } ?>
<?php if ($this->session->flashdata('notadded')) { ?>


<script>
  addEventListener("load", (event) => {
    $('#projectmodel').modal('show');
  });
</script>

<?php } ?>

<?php if ($this->session->flashdata('enotadded')) { ?>


<script>
  addEventListener("load", (event) => {
    $('#customermodeledit').modal('show');
  });
</script>

<?php } ?>
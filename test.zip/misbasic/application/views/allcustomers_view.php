<?php
defined('BASEPATH') or exit('No direct script access allowed');
?>

<div class="enqiry_top_view">
  <button class="btn btn-primary add_customer_new btn-sm"><i class="fa fa-plus" aria-hidden="true"></i> Add New</button>
</div>
<div class="enqiry_view">
  <?php echo $customerlist['clist']; ?>
</div>

<div class="modal fade" id="customermodel" tabindex="-1" aria-labelledby="customermodeltitle" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="customermodeltitle">Create Customer</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <?php echo validation_errors(); ?>
        <?php if ($this->session->flashdata('validation')) { ?>
          <?php echo $this->session->flashdata('validation'); ?>
        <?php } elseif ($this->session->flashdata('large')) { ?>
          <?php echo $this->session->flashdata('large'); ?>
        <?php } elseif ($this->session->flashdata('success')) { ?>
          <?php echo $this->session->flashdata('success'); ?>
        <?php } elseif ($this->session->flashdata('finalexit')) { ?>
          <?php echo $this->session->flashdata('finalexit'); ?>
        <?php } elseif ($this->session->flashdata('notadded')) { ?>
          <?php echo $this->session->flashdata('notadded'); ?>
        <?php } ?>

        <?php echo form_open_multipart('allcustomers/newcustomer', 'method="post" accept-charset="utf-8" name="addcustomer" id="addcustomer"'); ?>
        <div class="row_2">
          <input type="text" name="username" placeholder="Name" id="username" value="<?php echo set_value('username'); ?>" />
          <input type="text" name="company_name" placeholder="Company Name" id="company_name" value="<?php echo set_value('company_name'); ?>" />

        </div>
        <div class="row_2">
          <input type="text" name="email" placeholder="Email" id="email" value="<?php echo set_value('email'); ?>" />
          <input type="text" name="phone" placeholder="Phone" id="phone" value="<?php echo set_value('phone'); ?>" />

        </div>
        <div class="row_1">
          <input type="text" name="password" placeholder="Password" id="" value="<?php echo set_value('password'); ?>" />
          <div>
            <div id='img_contain'>
              <img id="customer_preview" src="<?= base_url("assets/images/logo_default.png") ?>" alt="your image" title='logo' />
            </div>
            <div class="image_design">
              <span>Upload your logo</span>
              <input type="file" name="company_logo" placeholder="" id="company_logo" />
            </div>
          </div>
        </div>
        <button type="submit" name="submit" class="btn btn-primary">Create Customer</button>
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <!-- <button type="button" class="btn btn-primary">Save project</button> -->
      </div>
    </div>
  </div>
</div>


<div class="modal fade" id="customermodeledit" tabindex="-1" aria-labelledby="ecustomermodeltitle" aria-hidden="true">
  <div class="modal-dialog modal-md">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="ecustomermodeltitle">Edit Customer</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <?php echo validation_errors(); ?>
        <?php if ($this->session->flashdata('efinalexit')) { ?>
          <?php echo $this->session->flashdata('efinalexit'); ?>
        <?php } elseif ($this->session->flashdata('elarge')) { ?>
          <?php echo $this->session->flashdata('elarge'); ?>
        <?php } elseif ($this->session->flashdata('evalidation')) { ?>
          <?php echo $this->session->flashdata('evalidation'); ?>
        <?php } elseif ($this->session->flashdata('esuccess')) { ?>
          <?php echo $this->session->flashdata('esuccess'); ?>
        <?php } elseif ($this->session->flashdata('enotadded')) { ?>
          <?php echo $this->session->flashdata('enotadded'); ?>
        <?php } ?>

        <?php echo form_open_multipart('allcustomers/editcustomerbyid', 'method="post" accept-charset="utf-8" name="addcustomer" id="addcustomer"'); ?>
        <input type="hidden" name="user_id" id="customerid" value="<?php echo set_value('user_id'); ?>" />
        <input type="text" name="username" placeholder="Customer Email" id="ecustomer_name" value="<?php echo set_value('username'); ?>" />
        <input type="text" name="password" placeholder="Customer Password" id="ecustomer_password" value="<?php echo set_value('password'); ?>" />
        <div id='img_contain'>
          <img id="ecustomer_preview" src="<?= base_url("assets/images/logo_default.png") ?>" alt="your image" title='' />
        </div>
        <div class="image_design">
          <span>Upload your logo</span>
          <input type="file" name="company_logo" placeholder="" id="ecustomer_logo" />
        </div>
        <button type="submit" name="submit" class="btn btn-success">Update Customer</button>
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>

      </div>
    </div>
  </div>
</div>

<div class="modal fade" id="customerview" tabindex="-1" aria-labelledby="customerviewtitle" aria-hidden="true">
  <div class="modal-dialog modal-xl">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="customerviewtitle">View Customer</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <div id="result"></div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <!-- <button type="button" class="btn btn-primary">Save project</button> -->
      </div>
    </div>
  </div>
</div>


<script>
  jQuery(document).ready(function($) {

    /*View User*/
    $('#customer_view').DataTable({
      'responsive': true,
      "processing": true,
      "bInfo": false,
      columnDefs: [{
        width: '20%'
      }],
      fixedColumns: true,
      "fnRowCallback": function(nRow, aData, iDisplayIndex) {
        $("td:first", nRow).html(iDisplayIndex + 1);
        return nRow;
      },
    });

    //
    $(document).on("click", ".add_customer_new", function(d) {
      d.preventDefault();
      $('#customermodel').modal('show');
    });


    //

    $(document).on("click", ".view_customer_new", function(d) {
      d.preventDefault();
      let view_id = $(this).data("uid");
      $.ajax({
        url: "<?php echo base_url("allcustomers/get_customerview"); ?>",
        type: "POST",
        data: {
          'view_id': view_id,
        },
        cache: false,
        success: function(data) {
          var dlt = $.parseJSON(data);
          $("#result").html(dlt);
        }
      });
      $('#customerview').modal('show');
    });

    //

    $(document).on("click", ".edit_customer_new", function(d) {
      d.preventDefault();
      let f_id = $(this).data("uid");
      $.ajax({
        url: "<?php echo base_url("allcustomers/getsinglecustomer"); ?>",
        type: "POST",
        data: {
          'f_id': f_id,
        },
        cache: false,
        success: function(data) {
          //alert(result);
          var dlt = $.parseJSON(data);
          console.log(dlt["result"][0]);
          // console.log(dlt["result"][0].follow_up_id);
          $("#ecustomer_name").val(dlt["result"][0].username);
          $("#ecustomer_email").val(dlt["result"][0].email);
          $("#ecustomer_password").val(dlt["result"][0].org_password);
          $("#ecustomer_phone").val(dlt["result"][0].phone);
          $('#ecustomer_preview').attr('src', base_url + "docs/customerlogo/" + dlt["result"][0].company_logo);
          $("#customerid").val(dlt["result"][0].user_id);


        }
      });
      $('#customermodeledit').modal('show');
    });



    //

    function readURL(input) {
      if (input.files && input.files[0]) {
        var reader = new FileReader();
        reader.onload = function(e) {
          $('#customer_preview').attr('src', e.target.result);
          $('#customer_preview').hide();
          $('#customer_preview').fadeIn(650);
        }
        reader.readAsDataURL(input.files[0]);
      }
    }

    $("#company_logo").change(function() {
      readURL(this);
    });
    //

    function readURL1(input) {
      if (input.files && input.files[0]) {
        var reader = new FileReader();
        reader.onload = function(e) {
          $('#ecustomer_preview').attr('src', e.target.result);
          $('#ecustomer_preview').hide();
          $('#ecustomer_preview').fadeIn(650);
        }
        reader.readAsDataURL(input.files[0]);
      }
    }

    $("#ecustomer_logo").change(function() {
      readURL1(this);
    });



    $(".alert").delay(4000).slideUp(200, function() {
      $(this).alert('close');
    });

    //

    $(document).on("click", ".delete_customer", function(d) {
      d.preventDefault();
      var deleteid = $(this).data('uid');
      swal({
          title: "Are you sure to delete?",
          text: "Not able to retrieve this file.",
          type: "warning",
          showCancelButton: true,
          confirmButtonColor: "#DD6B55",
          confirmButtonText: "Delete",
          cancelButtonText: "Cancel",
          closeOnConfirm: false,
          closeOnCancel: false
        },
        function(isConfirm) {
          if (isConfirm) {
            $.ajax({
              url: 'allcustomers/delete_customer',
              type: 'POST',
              data: {
                'deleteid': deleteid
              },
              success: function(data) {
                var dlt = $.parseJSON(data);
                if (dlt[0] == 'success') {
                  swal("Deleted Successfully", "You clicked the button!", "success");
                  setTimeout(function() {
                    location.reload();
                  }, 1500);
                } else if (dlt[0] == 'fail') {
                  swal("Could Not Deleted", "Something went Wrong!", "error");
                }
              }
            });
          } else {
            swal("Cancelled", "Your file is safe :)", "error");
          }
        });

    });

    //update status

    $(document).on("click", ".status_update", function(d) {
      d.preventDefault();
      var updateid = $(this).data('uid');
      var sid = $(this).data('sid');
      swal({
          title: "Are you sure to update?",
          text: "able to change active & in active this file.",
          type: "warning",
          showCancelButton: true,
          confirmButtonColor: "#157347",
          confirmButtonText: "Update",
          cancelButtonText: "Cancel",
          closeOnConfirm: false,
          closeOnCancel: false
        },
        function(isConfirm) {
          if (isConfirm) {
            $.ajax({
              url: 'allcustomers/status_update_customer',
              type: 'POST',
              data: {
                'updateid': updateid,
                "sid": sid,
              },
              success: function(data) {
                var dlt = $.parseJSON(data);
                if (dlt[0] == 'success') {
                  swal("Updated Successfully", "You clicked the button!", "success");
                  setTimeout(function() {
                    location.reload();
                  }, 1500);
                } else if (dlt[0] == 'fail') {
                  swal("Could Not Updated", "Something went Wrong!", "error");
                }
              }
            });
          } else {
            swal("Cancelled", "Your file is safe :)", "error");
          }
        });

    });


  });
</script>

<?php if ($this->session->flashdata('validation')) { ?>

  <script>
    addEventListener("load", (event) => {
      $('#customermodel').modal('show');
    });
  </script>
<?php } ?>
<?php if ($this->session->flashdata('evalidation')) { ?>

  <script>
    addEventListener("load", (event) => {
      $('#customermodeledit').modal('show');
    });
  </script>
<?php } ?>


<?php if ($this->session->flashdata('large')) { ?>


  <script>
    addEventListener("load", (event) => {
      $('#customermodel').modal('show');
    });
  </script>

<?php }  ?>
<?php if ($this->session->flashdata('notadded')) { ?>
  <script>
    addEventListener("load", (event) => {
      $('#customermodel').modal('show');
    });
  </script>

<?php }  ?>

<?php if ($this->session->flashdata('finalexit')) { ?>
  <script>
    addEventListener("load", (event) => {
      $('#customermodel').modal('show');
    });
  </script>




<?php } ?>


<?php if ($this->session->flashdata('elarge')) { ?>


  <script>
    addEventListener("load", (event) => {
      $('#customermodeledit').modal('show');
    });
  </script>

<?php }  ?>
<?php if ($this->session->flashdata('enotadded')) { ?>
  <script>
    addEventListener("load", (event) => {
      $('#customermodeledit').modal('show');
    });
  </script>

<?php }  ?>

<?php if ($this->session->flashdata('efinalexit')) { ?>
  <script>
    addEventListener("load", (event) => {
      $('#customermodeledit').modal('show');
    });
  </script>




<?php } ?>
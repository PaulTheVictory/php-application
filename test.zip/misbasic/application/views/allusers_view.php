<?php
defined('BASEPATH') or exit('No direct script access allowed');
?>

<div class="enqiry_top_view">
  <button class="btn btn-primary add_project_new btn-sm"><i class="fa fa-plus" aria-hidden="true"></i> Add User</button>

</div>
<div class="enqiry_view">
  <?php echo $customerlist['clist']; ?>
</div>


<div class="modal fade" id="projectmodel" tabindex="-1" aria-labelledby="projectmodeltitle" aria-hidden="true">
  <div class="modal-dialog modal-md">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="projectmodeltitle">Create User</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <?php echo validation_errors(); ?>
        <?php if ($this->session->flashdata('notadded')) { ?>
          <?php echo $this->session->flashdata('notadded'); ?>
        <?php } elseif ($this->session->flashdata('large')) { ?>
          <?php echo $this->session->flashdata('large'); ?>
        <?php } elseif ($this->session->flashdata('success')) { ?>
          <?php echo $this->session->flashdata('success'); ?>
        <?php } ?>

        <?php echo form_open('allusers/newuser', 'method="post" accept-charset="utf-8" name="adduser" id="adduser"'); ?>
        <input type="text" name="username" placeholder="Name" id="" value="<?php echo set_value('username'); ?>" />
        <input type="text" name="email" placeholder="Email" id="" value="<?php echo set_value('email'); ?>" />
        <input type="text" name="phone" placeholder="Phone" id="" value="<?php echo set_value('phone'); ?>" />
        <input type="text" name="password" placeholder="Password" id="" value="<?php echo set_value('customer_password'); ?>" />

        <button type="submit" name="submit" class="btn btn-primary">Create User</button>
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <!-- <button type="button" class="btn btn-primary">Save project</button> -->
      </div>
    </div>
  </div>
</div>


<div class="modal fade" id="customermodeledit" tabindex="-1" aria-labelledby="ecustomermodeltitle" aria-hidden="true">
  <div class="modal-dialog modal-md">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="ecustomermodeltitle">Edit User</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <?php echo validation_errors(); ?>
        <?php if ($this->session->flashdata('efinalexit')) { ?>
          <?php echo $this->session->flashdata('efinalexit'); ?>
        <?php } elseif ($this->session->flashdata('elarge')) { ?>
          <?php echo $this->session->flashdata('elarge'); ?>
        <?php } elseif ($this->session->flashdata('esuccess')) { ?>
          <?php echo $this->session->flashdata('esuccess'); ?>
        <?php } elseif ($this->session->flashdata('enotadded')) { ?>
          <?php echo $this->session->flashdata('enotadded'); ?>
        <?php } ?>

        <?php echo form_open_multipart('allusers/editcustomerbyid', 'method="post" accept-charset="utf-8" name="addcustomer" id="addcustomer"'); ?>


        <input type="hidden" name="user_id" id="user_id" value="<?php echo set_value('user_id'); ?>" />
        <input type="text" name="username" placeholder="Name" id="ecustomer_user_name" value="<?php echo set_value('username'); ?>" />
        <input type="text" name="password" placeholder="Password" id="ecustomer_password" value="<?php echo set_value('password'); ?>" />

        <button type="submit" name="submit" class="btn btn-success">Update User</button>
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <!-- <button type="button" class="btn btn-primary">Save project</button> -->
      </div>
    </div>
  </div>
</div>

<script>
  jQuery(document).ready(function($) {

    /*View User*/
    $('#customer_view').DataTable({
      'responsive': true,
      "processing": true,
      "bInfo": false,
      columnDefs: [{
        width: '20%'
      }],
      fixedColumns: true,
      "fnRowCallback": function(nRow, aData, iDisplayIndex) {
        $("td:first", nRow).html(iDisplayIndex + 1);
        return nRow;
      },
    });

    /**/

    // $(document).on("click",".view_customer",function(){
    //   alert("test");
    // });  

    $(document).on("click", ".edit_customer", function(d) {
      d.preventDefault();
      var f_id = $(this).data('uid');
      $.ajax({
        url: "<?php echo base_url("allusers/getsinglecustomer"); ?>",
        type: "POST",
        data: {
          'f_id': f_id,
        },
        cache: false,
        success: function(data) {
          //alert(result);
          var dlt = $.parseJSON(data);
          //console.log(dlt["result"][0]);
          // console.log(dlt["result"][0].follow_up_id);
          $("#ecustomer_user_name").val(dlt["result"][0].username);
          $("#ecustomer_password").val(dlt["result"][0].org_password);
          $("#user_id").val(dlt["result"][0].user_id);


        }
      });
      $('#customermodeledit').modal('show');
    });

    $(document).on("click", ".delete_customer", function(d) {
      d.preventDefault();
      var deleteid = $(this).data('uid');
      swal({
          title: "Are you sure to delete?",
          text: "Not able to retrieve this file.",
          type: "warning",
          showCancelButton: true,
          confirmButtonColor: "#DD6B55",
          confirmButtonText: "Delete",
          cancelButtonText: "Cancel",
          closeOnConfirm: false,
          closeOnCancel: false
        },
        function(isConfirm) {
          if (isConfirm) {
            $.ajax({
              url: 'allusers/DeleteUser',
              type: 'POST',
              data: {
                'deleteid': deleteid
              },
              success: function(data) {
                var dlt = $.parseJSON(data);
                if (dlt[0] == 'success') {
                  swal("Deleted Successfully", "You clicked the button!", "success");
                  setTimeout(function() {
                    location.reload();
                  }, 1500);
                } else if (dlt[0] == 'fail') {
                  swal("Could Not Deleted", "Something went Wrong!", "error");
                }
              }
            });
          } else {
            swal("Cancelled", "Your file is safe :)", "error");
          }
        });

    });


    //

    $(document).on("click", ".add_project_new", function(d) {
      d.preventDefault();
      $('#projectmodel').modal('show');
    });

    //update status

    $(document).on("click", ".status_update", function(d) {
      d.preventDefault();
      var updateid = $(this).data('uid');
      var sid = $(this).data('sid');
      swal({
          title: "Are you sure to update?",
          text: "able to change active & in active this file.",
          type: "warning",
          showCancelButton: true,
          confirmButtonColor: "#157347",
          confirmButtonText: "Update",
          cancelButtonText: "Cancel",
          closeOnConfirm: false,
          closeOnCancel: false
        },
        function(isConfirm) {
          if (isConfirm) {
            $.ajax({
              url: 'allusers/UpdateUser',
              type: 'POST',
              data: {
                'updateid': updateid,
                "sid": sid,
              },
              success: function(data) {
                var dlt = $.parseJSON(data);
                if (dlt[0] == 'success') {
                  swal("Updated Successfully", "You clicked the button!", "success");
                  setTimeout(function() {
                    location.reload();
                  }, 1500);
                } else if (dlt[0] == 'fail') {
                  swal("Could Not Updated", "Something went Wrong!", "error");
                }
              }
            });
          } else {
            swal("Cancelled", "Your file is safe :)", "error");
          }
        });

    });






  });
</script>
<?php if ($this->session->flashdata('validation')) { ?>


  <script>
    addEventListener("load", (event) => {
      $('#projectmodel').modal('show');
    });
  </script>

<?php } ?>

<?php if ($this->session->flashdata('notadded')) { ?>


  <script>
    addEventListener("load", (event) => {
      $('#projectmodel').modal('show');
    });
  </script>

<?php } ?>

<?php if ($this->session->flashdata('evalidation')) { ?>


  <script>
    addEventListener("load", (event) => {
      $('#customermodeledit').modal('show');
    });
  </script>

<?php } ?>
<?php if ($this->session->flashdata('enotadded')) { ?>


  <script>
    addEventListener("load", (event) => {
      $('#customermodeledit').modal('show');
    });
  </script>

<?php } ?>
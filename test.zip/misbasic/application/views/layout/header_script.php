<?php
defined('BASEPATH') or exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <title><?php echo $title ? $title : "Blazon" ?> | Blazon</title>
  <meta content="" name="description">
  <meta content="" name="keywords">
  <!-- Favicons -->
  <link href="<?php echo base_url(); ?>assets/images/favicon.png" rel="icon">
  <link href="<?php echo base_url(); ?>assets/images/favicon.png" rel="apple-touch-icon">
  <!-- Google Fonts -->
  <!-- CSS Files -->
  <link href="<?php echo base_url(); ?>assets/css/bootstrap.min.css" rel="stylesheet">
  <link href="<?php echo base_url(); ?>assets/css/bootstrap-icons.css" rel="stylesheet">
  <link href="<?php echo base_url(); ?>assets/css/boxicons.min.css" rel="stylesheet">
  <link href="<?php echo base_url(); ?>assets/css/quill.snow.css" rel="stylesheet">
  <link href="<?php echo base_url(); ?>assets/css/quill.bubble.css" rel="stylesheet">
  <link href="<?php echo base_url(); ?>assets/css/remixicon.css" rel="stylesheet">
  <!-- Template Main CSS File -->
  <link href="<?php echo base_url(); ?>assets/css/dataTables.min.css" rel="stylesheet">
  <link href="<?php echo base_url(); ?>assets/css/font-awesome.min.css" rel="stylesheet">
  <!-- <link href="<?php echo base_url(); ?>assets/css/responsive.dataTables.min.css" rel="stylesheet"> -->
  <link href="<?php echo base_url(); ?>assets/css/sweetalert.min.css" rel="stylesheet">
  <link href="<?php echo base_url(); ?>assets/css/date.css" rel="stylesheet">
  <link href="<?php echo base_url(); ?>assets/css/dashboard.css" rel="stylesheet">
  <link href="<?php echo base_url(); ?>assets/css/styles.css" rel="stylesheet">

  <script src="<?php echo base_url(); ?>assets/js/jquery.js"></script>

  <script>
    var base_url = "http://localhost/misbasic/";
  </script>
</head>

<body>
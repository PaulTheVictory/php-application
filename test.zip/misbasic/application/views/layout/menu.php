<aside id="sidebar" class="sidebar">

  <ul class="sidebar-nav" id="sidebar-nav">
    <li class="nav-item">
      <a class="nav-link " href="<?= base_url(); ?>">
        <i class="bi bi-grid"></i>
        <span>Dashboard</span>
      </a>
    </li>
    <?php if ($this->session->userdata("super_in")) { ?>




      <li class="nav-item">
        <a class="nav-link collapsed" href="<?= base_url("allcustomers"); ?>">
          <i class="bi bi-person"></i>
          <span>All Customers</span>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link collapsed" href="<?= base_url("allusers"); ?>">
          <i class="bi bi-shield-check"></i>
          <span>All Users</span>
        </a>
      </li>
      <?php if ($this->session->userdata("user_id")==="63a9739adf7d9" && $this->session->userdata("super_in")) { ?>
      <li class="nav-item">
        <a class="nav-link collapsed" href="<?= base_url("allsuperadmin"); ?>">
          <i class="bi bi-card-checklist"></i>
          <span>Add Superadmin</span>
        </a>
      </li>
      <?php } ?>
      <li class="nav-heading">Pages</li>
      <li class="nav-item">
        <a class="nav-link collapsed" href="<?= base_url("alllogs"); ?>">
          <i class="bi bi-card-checklist"></i>
          <span>All Logs</span>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link collapsed" href="<?= base_url("changepassword"); ?>">
        <i class="bi bi-bookmark-plus"></i>
          <span>Change Password</span>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link collapsed" href="<?= base_url("login/Logout"); ?>">
          <i class="bi bi-box-arrow-in-right"></i>
          <span>Logout</span>
        </a>
      </li>
    <?php } ?>
    <?php if ($this->session->userdata("admin_in")) { ?>
      <li class="nav-item">
        <a class="nav-link collapsed" href="<?= base_url("allusers"); ?>">
          <i class="bi bi-person"></i>
          <span>All Users</span>
        </a>
      </li>
      <li class="nav-heading">Projects</li>
      <li class="nav-item">
        <a class="nav-link collapsed" href="<?= base_url("enquiry"); ?>">
          <i class="bi bi-card-checklist"></i>
          <span>Enquiry</span>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link collapsed" href="<?= base_url("followupprogress"); ?>">
          <i class="bi bi-card-checklist"></i>
          <span>Follow Up Progress</span>
        </a>
      </li>


      <li class="nav-heading">Pages</li>
      <li class="nav-item">
        <a class="nav-link collapsed" href="<?= base_url("logs"); ?>">
          <i class="bi bi-card-checklist"></i>
          <span>Logs</span>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link collapsed" href="<?= base_url("changepassword"); ?>">
        <i class="bi bi-bookmark-plus"></i>
          <span>Change Password</span>
        </a>
      </li>


      <li class="nav-item">
        <a class="nav-link collapsed" href="<?= base_url("login/Logout"); ?>">
          <i class="bi bi-box-arrow-in-right"></i>
          <span>Logout</span>
        </a>
      </li>

    <?php  } ?>

    <?php if ($this->session->userdata("user_in")) { ?>
      <li class="nav-heading">Projects</li>
      <li class="nav-item">
        <a class="nav-link collapsed" href="<?= base_url("enquiryuser"); ?>">
          <i class="bi bi-card-checklist"></i>
          <span>Enquiry</span>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link collapsed" href="<?= base_url("followupprogressuser"); ?>">
          <i class="bi bi-card-checklist"></i>
          <span>Follow Up Progress</span>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link collapsed" href="<?= base_url("changepassword"); ?>">
        <i class="bi bi-bookmark-plus"></i>
          <span>Change Password</span>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link collapsed" href="<?= base_url("login/Logout"); ?>">
          <i class="bi bi-box-arrow-in-right"></i>
          <span>Logout</span>
        </a>
      </li>

    <?php } ?>
  </ul>

</aside>
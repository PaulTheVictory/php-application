<?php
defined('BASEPATH') or exit('No direct script access allowed');
?>


<div class="enqiry_view">
  <?php echo $userslist['clist']; ?>
</div>



<script>
  jQuery(document).ready(function($) {

    /*View User*/
    $('#customer_view').DataTable({
      'responsive': true,
      "processing": true,
      "bInfo": false,
      columnDefs: [{
        width: '20%'
      }],
      fixedColumns: true,
      "fnRowCallback": function(nRow, aData, iDisplayIndex) {
        $("td:first", nRow).html(iDisplayIndex + 1);
        return nRow;
      },
    });

  });

   
</script>

<?php
defined('BASEPATH') or exit('No direct script access allowed');
?>

<div class="enqiry_view">
  <?php echo $enquirylist['elist']; ?>
</div>


<script>
  $(document).ready(function() {
   

    //

    $(".alert").delay(4000).slideUp(200, function() {
      $(this).alert('close');
    });

    //

    $('#customer_view').DataTable({
      'responsive': true,
      "processing": true,
      "bInfo": false,
      columnDefs: [{
        width: '20%'
      }],
      fixedColumns: true,
      "fnRowCallback": function(nRow, aData, iDisplayIndex) {
        $("td:first", nRow).html(iDisplayIndex + 1);
        return nRow;
      },
    });

  });

  </script>
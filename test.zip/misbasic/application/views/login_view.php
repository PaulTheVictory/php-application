<?php
defined('BASEPATH') or exit('No direct script access allowed');
?>

<!--login_screen-->


<section class="login_screen">
  <div class="login_screen_align">
    <div class="login_screen_left">
      <!-- <img src="<?php echo base_url() ?>assets/images/login.png" alt="Login"> -->
    </div>
    <div class="login_screen_right">
    
    <?php echo form_open('login','method="post" accept-charset="utf-8" name="login_form" id="login_form"'); ?>
    <h1>Welcome Back</h1>
    <?php echo validation_errors(); ?>
      <div class="form_row">
          <input type="text" class="form_input" id="user_name" placeholder="Mobile Number or Email Id" name="user_name" value="<?php echo set_value('user_name'); ?>">
        </div>
        <div class="form_row">
          <input type="password" class="form_input" id="pass_word" placeholder="Password" name="pass_word" value="<?php echo set_value('pass_word'); ?>">
        </div>
        <div class="form_row check">
          <label class="form-check-label">
            <input class="form_input_check" type="checkbox" name="remember" <?php echo set_checkbox('checkbox',true); ?>> Remember me
          </label>
          <span></span>
          <a href="javascript:void(0)" title="Forgot Password">Forgot Password</a>
        </div>
        <button type="submit" class="form_buttom">Login</button>
      </form>
    </div>
  </div>

</section>


<!--login_screen-->



<script>

$(document).ready(function(){
  $(".alert").delay(4000).slideUp(200, function() {
    $(this).alert('close');
});
});

</script>
<?php
defined('BASEPATH') or exit('No direct script access allowed');
?>
<div class="enqiry_top_view">
  <button class="btn btn-primary add_project_new btn-sm"><i class="fa fa-plus" aria-hidden="true"></i> Add New</button>
  <!-- <button class="btn btn-success add_enquiry_new btn-sm"><i class="fa fa-plus" aria-hidden="true"></i> Add Enquiry</button> -->
</div>
<div class="enqiry_view">
  <?php echo $followuplist['flist']; ?>
</div>

<div class="modal fade" id="projectmodel" tabindex="-1" aria-labelledby="projectmodeltitle" aria-hidden="true">
  <div class="modal-dialog modal-md">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="projectmodeltitle">Create Followup</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <?php echo form_open('followupprogress/add_followup_process', 'method="post" accept-charset="utf-8" name="followup" id="followup"'); ?>
        <input type="text" name="follow_up_msg" id="follow_up_msg" placeholder="Follow up Message" />
        <select name="follow_up_status" id="follow_up_status">
          <option value="" selected hidden>Follow up Status</option>
          <option value="pending">Pending</option>
          <option value="followup">Followup</option>
          <option value="cancel">Cancel</option>
          <option value="rejected">Rejected</option>
          <option value="noresponse">Noresponse</option>
          <option value="completed">Completed</option>
        </select>
        <select name="project_id" id="project_id">
          <option value="" selected hidden>Select Project</option>
          <?php
          foreach ($plist as $row) {
          ?>
            <option value="<?php echo $row->project_id; ?>|<?php echo $row->project_name; ?>"><?php echo $row->project_name; ?></option>
          <?php } ?>
        </select>
        <select name="enquiry_id" id="enquiry_id">
          <option value="" selected hidden>Select Enquiry</option>
          <?php
          foreach ($enlist as $row) {
          ?>
            <option value="<?php echo $row->enquiry_id; ?>|<?php echo $row->enq_name; ?>"><?php echo $row->enq_name; ?></option>
          <?php } ?>
        </select>
        <input type="text" name="nxt_follow_up_date" id="datetimepicker" placeholder="Next Follow up" />
        <textarea name="nxt_follow_up_hint" id="nxt_follow_up_hint" placeholder="Follow up Hint"></textarea>
        <button type="submit" class="btn btn-primary btn-md">Save Follow Up</button>
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <!-- <button type="button" class="btn btn-primary">Save project</button> -->
      </div>
    </div>
  </div>
</div>


<div class="modal fade" id="followupmodeledit" tabindex="-1" aria-labelledby="followupmodeledittitle" aria-hidden="true">
  <div class="modal-dialog modal-md">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="followupmodeledittitle">Update Followup</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
      <?php echo form_open('followupprogress/add_followup_process_update', 'method="post" accept-charset="utf-8" name="followup" id="followup"'); ?>
      <input type="hidden" name="this_id" id="this_id" />
        <input type="text" name="follow_up_msg" id="efollow_up_msg" placeholder="Follow up Message" />
        <select name="follow_up_status" id="efollow_up_status">
        <option value="" selected hidden>Follow up Status</option>
          <option value="pending">Pending</option>
          <option value="followup">Followup</option>
          <option value="cancel">Cancel</option>
          <option value="rejected">Rejected</option>
          <option value="noresponse">Noresponse</option>
          <option value="completed">Completed</option>
        </select>
        <select name="project_id" id="eproject_id">
          <option value="" selected hidden>Select Project</option>
          <?php
          foreach ($plist as $row) {
          ?>
            <option value="<?php echo $row->project_id; ?>|<?php echo $row->project_name; ?>"><?php echo $row->project_name; ?></option>
          <?php } ?>
        </select>
        <select name="enquiry_id" id="eenquiry_id">
          <option value="" selected hidden>Select Enquiry</option>
          <?php
          foreach ($enlist as $row) {
          ?>
            <option value="<?php echo $row->enquiry_id; ?>|<?php echo $row->enq_name; ?>"><?php echo $row->enq_name; ?></option>
          <?php } ?>
        </select>
        <input type="text" name="nxt_follow_up_date" id="edatetimepicker" placeholder="Next Follow up" />
        <textarea name="nxt_follow_up_hint" id="enxt_follow_up_hint" placeholder="Follow up Hint"></textarea>
        <button type="submit" class="btn btn-success btn-md">Update Follow Up</button>
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <!-- <button type="button" class="btn btn-primary">Save project</button> -->
      </div>
    </div>
  </div>
</div>

<?php if ($this->session->flashdata('success')) { ?>

<script>
  $(document).ready(function() {
   swal("Updated Successfully", "You clicked the button!", "success");
  });
</script>
<?php } ?>

<script>
  $(document).ready(function() {

   

    $.datetimepicker.setLocale('en');
    $('#datetimepicker').datetimepicker();
    $('#edatetimepicker').datetimepicker();
    
    //

    $(".alert").delay(4000).slideUp(200, function() {
      $(this).alert('close');
    });

    //

    $('#customer_view').DataTable({
      'responsive': true,
      "processing": true,
      "bInfo": false,
      columnDefs: [{
        width: '20%'
      }],
      fixedColumns: true,
      "fnRowCallback": function(nRow, aData, iDisplayIndex) {
        $("td:first", nRow).html(iDisplayIndex + 1);
        return nRow;
      },
    });

  });


  $(document).on("click", ".delete_followup", function(d) {
    d.preventDefault();
    var deleteid = $(this).data('uid');
    swal({
        title: "Are you sure to delete?",
        text: "Not able to retrieve this file.",
        type: "warning",
        showCancelButton: true,
        confirmButtonColor: "#DD6B55",
        confirmButtonText: "Delete",
        cancelButtonText: "Cancel",
        closeOnConfirm: false,
        closeOnCancel: false
      },
      function(isConfirm) {
        if (isConfirm) {
          $.ajax({
            url: 'followupprogress/DeleteFollowup',
            type: 'POST',
            data: {
              'deleteid': deleteid
            },
            success: function(data) {
              var dlt = $.parseJSON(data);
              if (dlt[0] == 'success') {
                swal("Deleted Successfully", "You clicked the button!", "success");
                setTimeout(function() {
                  location.reload();
                }, 1500);
              } else if (dlt[0] == 'fail') {
                swal("Could Not Deleted", "Something went Wrong!", "error");
              }
            }
          });
        } else {
          swal("Cancelled", "Your file is safe :)", "error");
        }
      });

  });

  //

  $(document).on("click", ".add_project_new", function(d) {
    d.preventDefault();
    $('#projectmodel').modal('show');
  });
    //

  $(document).on("click", ".edit_followup", function(d) {
    d.preventDefault();
    let f_id = $(this).data("uid");
    $.ajax({
		url: "<?php echo base_url("followupprogress/getsinglefprocess");?>",
		type: "POST",
    data: {
      'f_id': f_id,
    },
		cache: false,
		success: function(data){
      //alert(result);
      var dlt = $.parseJSON(data);
      // console.log(dlt["result"][0]);
      // console.log(dlt["result"][0].follow_up_id);
      $("#efollow_up_msg").val(dlt["result"][0].follow_up_msg);
      $("#enxt_follow_up_hint").val(dlt["result"][0].nxt_follow_up_hint);
      $("#edatetimepicker").val(dlt["result"][0].nxt_follow_up_date);
      $("#efollow_up_status").val(dlt["result"][0].follow_up_status);
      $("#eproject_id").val(dlt["result"][0].project_id);
      $("#eenquiry_id").val(dlt["result"][0].enquiry_id);
      $("#this_id").val(dlt["result"][0].follow_up_id);
		}
	  });
    $('#followupmodeledit').modal('show');
  });

  $(document).on("click", ".add_enquiry_new", function(d) {
    d.preventDefault();
    $('#enquirymodel').modal('show');
  });
</script>

<?php if ($this->session->flashdata('validation')) { ?>


  <script>
    addEventListener("load", (event) => {
      $('#projectmodel').modal('show');
    });
  </script>

<?php } ?>

<?php if ($this->session->flashdata('notadded')) { ?>


  <script>
    addEventListener("load", (event) => {
      $('#projectmodel').modal('show');
    });
  </script>

<?php } ?>


<?php if ($this->session->flashdata('envalid')) { ?>


  <script>
    addEventListener("load", (event) => {
      $('#enquirymodel').modal('show');
    });
  </script>

<?php } ?>

<?php if ($this->session->flashdata('ennotadded')) { ?>


  <script>
    addEventListener("load", (event) => {
      $('#projectmodel').modal('show');
    });
  </script>

<?php } ?>
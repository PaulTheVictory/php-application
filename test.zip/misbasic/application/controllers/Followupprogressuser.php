<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Followupprogressuser extends CI_Controller {
  function __construct()
  {
    parent::__construct();
    $this->load->model('Admin_Model', 'admin_model', TRUE);
    $this->load->model('Superadmin_Model', 'superadmin_model', TRUE);
    $this->load->model('User_Model', 'user_model', TRUE);
    $this->load->helper('form');
    $this->load->library('form_validation');
    $this->load->library("user_agent");
  }

public function index()
{
  if ($this->session->userdata("super_in")) {
    $data['customerlist'] = $this->superadmin_model->GetCustomerLists();
    $data["title"] = "All Customers";
    $this->load->view("layout/header_script",$data);
    $this->load->view("layout/header",$data);
    $this->load->view("allcustomers_view",$data);
    $this->load->view("layout/footer");
    $this->load->view("layout/footer_script");
  } elseif ($this->session->userdata("admin_in")) {
    $data['enlist'] = $this->admin_model->getproenquiry(); 
    $data['plist'] = $this->admin_model->getprojects(); 
    $data['followuplist'] = $this->admin_model->getallfollowup(); 
    $data["title"] = "Follow Up Progress";
    $this->load->view("layout/header_script",$data);
    $this->load->view("layout/header",$data);
    $this->load->view("followupprogress_view",$data);
    $this->load->view("layout/footer");
    $this->load->view("layout/footer_script");
  } elseif ($this->session->userdata("user_in")) {
    $data["title"] = "Follow Up Progress";
    $data['followuplist'] = $this->user_model->getallfollowup(); 
    $this->load->view("layout/header_script",$data);
    $this->load->view("layout/header",$data);
    $this->load->view("followupprogressuser_view");
    $this->load->view("layout/footer");
    $this->load->view("layout/footer_script");
  } else {
    $data["title"] = "Login";
    $this->load->view("layout/header_script", $data);
    $this->load->view("login_view");
    $this->load->view("layout/footer_script");
  }
  
}
















}
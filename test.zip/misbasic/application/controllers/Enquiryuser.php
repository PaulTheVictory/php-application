<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Enquiryuser extends CI_Controller
{
  function __construct()
  {
    parent::__construct();
    $this->load->model('Superadmin_Model', 'superadmin_model', TRUE);
    $this->load->model('User_Model', 'user_model', TRUE);
     $this->load->model('Admin_Model', 'admin_model', TRUE);
    $this->load->helper('form');
    $this->load->library('form_validation');
    $this->load->library("user_agent");
  }

  public function index()
  {
    if ($this->session->userdata("super_in")) {
      $data["title"] = "Dashboard";
      $this->load->view("layout/header_script", $data);
      $this->load->view("layout/header", $data);
      $this->load->view("dashboard_view");
      $this->load->view("layout/footer");
      $this->load->view("layout/footer_script");
    } elseif ($this->session->userdata("admin_in")) {
      $data['enquirylist'] = $this->admin_model->getallenquiry(); 
      $data['plist'] = $this->admin_model->getprojects(); 
      $data["title"] = "Enquiry";
      $this->load->view("layout/header_script", $data);
      $this->load->view("layout/header", $data);
      $this->load->view("enquiry_view",$data);
      $this->load->view("layout/footer");
      $this->load->view("layout/footer_script");
    } elseif ($this->session->userdata("user_in")) {
      $data["title"] = "Enquiry";
      $data['enquirylist'] = $this->user_model->getallenquiry(); 
      $this->load->view("layout/header_script", $data);
      $this->load->view("layout/header", $data);
      $this->load->view("enquiryuser_view");
      $this->load->view("layout/footer");
      $this->load->view("layout/footer_script");
    } else {
      $data["title"] = "Login";
      $this->load->view("layout/header_script", $data);
      $this->load->view("login_view");
      $this->load->view("layout/footer_script");
    }

  }









}
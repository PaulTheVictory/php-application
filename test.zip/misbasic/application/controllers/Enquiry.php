<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Enquiry extends CI_Controller
{
  function __construct()
  {
    parent::__construct();
    $this->load->model('Superadmin_Model', 'superadmin_model', TRUE);
    $this->load->model('Admin_Model', 'admin_model', TRUE);
    $this->load->helper('form');
    $this->load->library('form_validation');
    $this->load->library("user_agent");
  }

  public function index()
  {
    if ($this->session->userdata("admin_in")) {
      $data['enquirylist'] = $this->admin_model->getallenquiry();
      $data['plist'] = $this->admin_model->getprojects();
      $data["title"] = "Enquiry";
      $this->load->view("layout/header_script", $data);
      $this->load->view("layout/header", $data);
      $this->load->view("enquiry_view", $data);
      $this->load->view("layout/footer");
      $this->load->view("layout/footer_script");
    } else {
      $data["title"] = "Login";
      $this->load->view("layout/header_script", $data);
      $this->load->view("login_view");
      $this->load->view("layout/footer_script");
    }
  }

  public function addproject()
  {
    $data['plist'] = $this->admin_model->getprojects();
    $this->form_validation->set_rules("project_name", "Project name", "trim|required|max_length[35]");
    if ($this->form_validation->run() === FALSE) {
      $data['enquirylist'] = $this->admin_model->getallenquiry();
      $data['plist'] = $this->admin_model->getprojects();
      $this->session->set_flashdata('validation', '<p class="alert alert-danger alert-dismissible">Please enter project name<button type="button" class="btn-close" data-bs-dismiss="alert"></button></p>');
      $data["title"] = "Enquiry";
      $this->load->view("layout/header_script", $data);
      $this->load->view("layout/header", $data);
      $this->load->view("enquiry_view");
      $this->load->view("layout/footer");
      $this->load->view("layout/footer_script");
    } else {
      date_default_timezone_set("Asia/Calcutta");
      $c_user_id = $this->session->userdata("user_id");
      $c_superadmin_id = $this->session->userdata("superadmin_id");
      $c_date = date('Y-m-j H:i:s');
      $c_name = $this->input->post("project_name", true);
      $res = $this->admin_model->add_newproject($c_user_id, $c_superadmin_id, $c_date, $c_name);


      if ($res[0] === "success") {
        redirect(base_url("enquiry"), "refresh");
      } else {
        $this->session->set_flashdata('notadded', '<p class="alert alert-danger alert-dismissible">Not Added !<button type="button" class="btn-close" data-bs-dismiss="alert"></button></p>');
        redirect(base_url("enquiry"), "refresh");
      }
    }
  }


  public function addenquiry()
  {

    $this->form_validation->set_rules("enq_name", "Enquiry Name", "trim|required|min_length[3]|max_length[40]");
    $this->form_validation->set_rules("enq_contact_number", "Enquiry contact number", "trim|required|min_length[10]|max_length[10]");
    $this->form_validation->set_rules("enq_date", "Enquiry date", "trim|required");
    $this->form_validation->set_rules("project_id", "Project name", "trim|required");
    $this->form_validation->set_error_delimiters('<p class="alert alert-danger alert-dismissible">', '<button type="button" class="btn-close" data-bs-dismiss="alert"></button></p>');
    if ($this->form_validation->run() === FALSE) {
      $this->session->set_flashdata('envalid', '<p class="alert alert-danger alert-dismissible">Validation Failed!<button type="button" class="btn-close" data-bs-dismiss="alert"></button></p>');
      $data['enquirylist'] = $this->admin_model->getallenquiry();
      $data['plist'] = $this->admin_model->getprojects();
      $data["title"] = "Enquiry";
      $this->load->view("layout/header_script", $data);
      $this->load->view("layout/header", $data);
      $this->load->view("enquiry_view", $data);
      $this->load->view("layout/footer");
      $this->load->view("layout/footer_script");
    } else {
      date_default_timezone_set("Asia/Calcutta");
      $j_date = date('Y-m-j H:i:s');
      $e_admin_id = $this->session->userdata("user_id");
      $e_superadmin_id = $this->session->userdata("superadmin_id");
      $e_name = $this->input->post("enq_name", true);
      $e_phone = $this->input->post("enq_contact_number", true);
      $e_date = $this->input->post("enq_date", true);
      $e_location = $this->input->post("enq_location", true);
      $e_project = $this->input->post("project_id", true);
      $e_projectmsg = $this->input->post("enq_msg", true);

      $res = $this->admin_model->add_newenquiry($e_admin_id, $e_superadmin_id, $e_name, $e_phone, $e_date, $e_project, $e_projectmsg, $j_date, $e_location);

      if ($res[0] === "success") {
        redirect(base_url("enquiry"), "refresh");
      } else {
        $this->session->set_flashdata('ennotadded', '<p class="alert alert-danger alert-dismissible">Not Added!<button type="button" class="btn-close" data-bs-dismiss="alert"></button></p>');
        redirect(base_url("enquiry"), "refresh");
      }
    }
  }


  public function DeleteEnquiry()
  {
    $deleteid = isset($_POST['deleteid']) ? $_POST['deleteid'] : '';
    $result = $this->admin_model->DeleteEnquiryById($deleteid);
    echo json_encode($result);
  }
}

<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Followupprogress extends CI_Controller {
  function __construct()
  {
    parent::__construct();
    $this->load->model('Admin_Model', 'admin_model', TRUE);
    $this->load->model('Superadmin_Model', 'superadmin_model', TRUE);
    $this->load->helper('form');
    $this->load->library('form_validation');
    $this->load->library("user_agent");
  }

public function index()
{
  if ($this->session->userdata("admin_in")) {
    $data['followuplist'] = $this->admin_model->getallfollowup(); 
    $data["title"] = "Follow Up Progress";
    $this->load->view("layout/header_script",$data);
    $this->load->view("layout/header",$data);
    $this->load->view("followupprogress_view",$data);
    $this->load->view("layout/footer");
    $this->load->view("layout/footer_script");
  }else {
    $data["title"] = "Login";
    $this->load->view("layout/header_script", $data);
    $this->load->view("login_view");
    $this->load->view("layout/footer_script");
  }
  
}


public function add_followup_process()
{
    $this->form_validation->set_rules("follow_up_msg", "Follow up message", "trim|required|min_length[3]|max_length[200]");
    $this->form_validation->set_rules("follow_up_status", "Follow up status", "trim|required");
    $this->form_validation->set_rules("nxt_follow_up_date", "Follow up date", "trim|required");
    $this->form_validation->set_rules("nxt_follow_up_hint", "Follow up date", "max_length[200]");
    $this->form_validation->set_error_delimiters('<p class="alert alert-danger alert-dismissible">', '<button type="button" class="btn-close" data-bs-dismiss="alert"></button></p>');
    if ($this->form_validation->run() === FALSE) {
      $data['enlist'] = $this->admin_model->getproenquiry(); 
      $data['plist'] = $this->admin_model->getprojects(); 
    $data['followuplist'] = $this->admin_model->getallfollowup(); 
      $data["title"] = "Follow Up Progress";
      $this->load->view("layout/header_script", $data);
      $this->load->view("layout/header", $data);
      $this->load->view("followupprogress_view", $data);
      $this->load->view("layout/footer");
      $this->load->view("layout/footer_script");
    } else {
      date_default_timezone_set("Asia/Calcutta");
      $f_msg = $this->input->post("follow_up_msg",true);
      $f_status = $this->input->post("follow_up_status",true);
      $f_date = $this->input->post("nxt_follow_up_date",true);
      $f_msghint = $this->input->post("nxt_follow_up_hint",true);
      $f_projectid = $this->input->post("project_id",true);
      $f_enquiryid = $this->input->post("enquiry_id",true);
      $j_date = date('Y-m-j');
      $j_time = date('H:i:s');

      $res = $this->admin_model->addnew_followup($f_msg,$f_status,$f_date,$f_msghint,$j_date,$j_time,$f_projectid,$f_enquiryid);

      if($res[0]==="success") {
        redirect(base_url("followupprogress"), "refresh");
      } else {
    $data['followuplist'] = $this->admin_model->getallfollowup(); 
        $data['enlist'] = $this->admin_model->getproenquiry(); 
        $data['plist'] = $this->admin_model->getprojects(); 
        $data["title"] = "Follow Up Progress";
        $this->load->view("layout/header_script", $data);
        $this->load->view("layout/header", $data);
        $this->load->view("followupprogress_view", $data);
        $this->load->view("layout/footer");
        $this->load->view("layout/footer_script");
      }




    }






}


public function getsinglefprocess()
{
  $f_id = isset($_POST['f_id'])?$_POST['f_id']:'';
  $res = $this->admin_model->getprocessdetails($f_id);
  $arr["result"] = $res;
  echo json_encode($arr);

  
}



public function add_followup_process_update()
{
    $this->form_validation->set_rules("follow_up_msg", "Follow up message", "trim|required|min_length[3]|max_length[200]");
    $this->form_validation->set_rules("follow_up_status", "Follow up status", "trim|required");
    $this->form_validation->set_rules("nxt_follow_up_date", "Follow up date", "trim|required");
    $this->form_validation->set_rules("nxt_follow_up_hint", "Follow up date", "max_length[200]");
    $this->form_validation->set_error_delimiters('<p class="alert alert-danger alert-dismissible">', '<button type="button" class="btn-close" data-bs-dismiss="alert"></button></p>');
    if ($this->form_validation->run() === FALSE) {
      $data['enlist'] = $this->admin_model->getproenquiry(); 
      $data['plist'] = $this->admin_model->getprojects(); 
    $data['followuplist'] = $this->admin_model->getallfollowup(); 
      $data["title"] = "Follow Up Progress";
      $this->load->view("layout/header_script", $data);
      $this->load->view("layout/header", $data);
      $this->load->view("followupprogress_view", $data);
      $this->load->view("layout/footer");
      $this->load->view("layout/footer_script");
    } else {
      $f_msg = $this->input->post("follow_up_msg",true);
      $f_status = $this->input->post("follow_up_status",true);
      $f_date = $this->input->post("nxt_follow_up_date",true);
      $f_msghint = $this->input->post("nxt_follow_up_hint",true);
      $f_projectid = $this->input->post("project_id",true);
      $f_enquiryid = $this->input->post("enquiry_id",true);
      $this_id = $this->input->post("this_id");

      $res = $this->admin_model->updatenew_followup($f_msg,$f_status,$f_date,$f_msghint,$f_projectid,$f_enquiryid,$this_id);

      if($res[0]==="success") {
        redirect(base_url("followupprogress"), "refresh");
      } else {
    $data['followuplist'] = $this->admin_model->getallfollowup(); 
        $data['enlist'] = $this->admin_model->getproenquiry(); 
        $data['plist'] = $this->admin_model->getprojects(); 
        $data["title"] = "Follow Up Progress";
        $this->load->view("layout/header_script", $data);
        $this->load->view("layout/header", $data);
        $this->load->view("followupprogress_view", $data);
        $this->load->view("layout/footer");
        $this->load->view("layout/footer_script");
      }




    }






}


public function DeleteFollowup()
{
  $deleteid = isset($_POST['deleteid'])?$_POST['deleteid']:'';
	$result = $this->admin_model->DeleteFollowupById($deleteid);
	echo json_encode($result);


}





}
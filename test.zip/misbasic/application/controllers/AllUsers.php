<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Allusers extends CI_Controller {
  function __construct()
  {
    parent::__construct();
    $this->load->model('Admin_Model', 'admin_model', TRUE);
    $this->load->helper('form');
    $this->load->library('form_validation');
    $this->load->library("user_agent");
  }

public function index()
{
  if ($this->session->userdata("admin_in")) {
    $data['customerlist'] = $this->admin_model->GetCustomerLists();
    $data["title"] = "All Users";
    $this->load->view("layout/header_script",$data);
    $this->load->view("layout/header",$data);
    $this->load->view("allusers_view",$data);
    $this->load->view("layout/footer");
    $this->load->view("layout/footer_script");
  }else {
    $data["title"] = "Login";
    $this->load->view("layout/header_script", $data);
    $this->load->view("login_view");
    $this->load->view("layout/footer_script");
  }
  
}


  public function getsinglecustomer()
  {
    $f_id = isset($_POST['f_id']) ? $_POST['f_id'] : '';
    $res = $this->admin_model->getsinglecustomerdetails($f_id);
    $arr["result"] = $res;
    echo json_encode($arr);
  }



public function DeleteUser()
	{
		$deleteid = isset($_POST['deleteid'])?$_POST['deleteid']:'';
		$result = $this->admin_model->DeleteById($deleteid);
		echo json_encode($result);
	}


  public function UpdateUser()
  {
    $deleteid = isset($_POST['updateid']) ? $_POST['updateid'] : '';
    $sid = isset($_POST['sid']) ? $_POST['sid'] : '';
    $result = $this->admin_model->UpdateById($deleteid, $sid);
    echo json_encode($result);
  }



  public function newuser()
  {
    $this->form_validation->set_rules("username", "User Name", "trim|required|min_length[3]|max_length[20]");
    $this->form_validation->set_rules("email", "Customer Email", "trim|required|valid_email|max_length[25]|is_unique[ap_users.email]");
    $this->form_validation->set_rules("phone", "Customer Password", "trim|required|min_length[10]|max_length[15]|is_unique[ap_users.phone]");
    $this->form_validation->set_rules("password", "User Password", "trim|required|min_length[6]|max_length[25]");
    $this->form_validation->set_error_delimiters('<p class="alert alert-danger alert-dismissible">', '<button type="button" class="btn-close" data-bs-dismiss="alert"></button></p>');
    if ($this->form_validation->run() === FALSE) {
      $this->session->set_flashdata('validation', '<p class="alert alert-danger alert-dismissible">Validation Failed!<button type="button" class="btn-close" data-bs-dismiss="alert"></button></p>');
      $data['customerlist'] = $this->admin_model->GetCustomerLists();
      $data["title"] = "Add User";
      $this->load->view("layout/header_script", $data);
      $this->load->view("layout/header", $data);
      $this->load->view("allusers_view");
      $this->load->view("layout/footer");
      $this->load->view("layout/footer_script");
    } else {
      $passkey = $this->config->item('passkey');
      date_default_timezone_set("Asia/Calcutta");
      $c_user_id = $this->session->userdata("user_id");
      $c_admin_id = $this->session->userdata("admin_id");
      $c_superadmin_id = $this->session->userdata("superadmin_id");
      $c_date = date('Y-m-j H:i:s');
      $c_name = $this->input->post("username", true);
      $c_email = $this->input->post("email", true);
      $c_phone = $this->input->post("phone", true);
      $c_password = sha1($passkey . $this->input->post("password", true));
      $c_orgpassword = $this->input->post("password", true);
      $res = $this->admin_model->add_user($c_user_id, $c_admin_id, $c_superadmin_id, $c_date, $c_name, $c_email, $c_phone, $c_password, $c_orgpassword);


      if ($res[0] === "success") {
        redirect(base_url("allusers"), "refresh");
      } else {
    $data['customerlist'] = $this->admin_model->GetCustomerLists();
        $this->session->set_flashdata('notadded', '<p class="alert alert-danger alert-dismissible">Not Added !<button type="button" class="btn-close" data-bs-dismiss="alert"></button></p>');
        redirect(base_url("allusers"), "refresh");
      }
    }
  }


  public function editcustomerbyid()
  {
    $viewid = isset($_POST['user_id']) ? $_POST['user_id'] : '';
    $this->form_validation->set_rules("username", "Customer Name", "trim|required|min_length[3]|max_length[20]");
    
    $this->form_validation->set_rules("password", "Customer Password", "trim|required|min_length[6]|max_length[25]");
    $this->form_validation->set_error_delimiters('<p class="alert alert-danger alert-dismissible">', '<button type="button" class="btn-close" data-bs-dismiss="alert"></button></p>');
    if ($this->form_validation->run() === FALSE) {
      $this->session->set_flashdata('evalidation', '<p class="alert alert-danger alert-dismissible">Validation Failed!<button type="button" class="btn-close" data-bs-dismiss="alert"></button></p>');
    $data['customerlist'] = $this->admin_model->GetCustomerLists();
      $data["title"] = "Edit User";
      $this->load->view("layout/header_script", $data);
      $this->load->view("layout/header", $data);
      $this->load->view("allusers_view", $data);
      $this->load->view("layout/footer");
      $this->load->view("layout/footer_script");
    } else {
      $viewid = isset($_POST['user_id']) ? $_POST['user_id'] : '';
      $passkey = $this->config->item('passkey');
      $c_name = $this->input->post("username", true);
      $c_password = sha1($passkey . $this->input->post("password", true));
      $c_orgpassword = $this->input->post("password", true);
      $res = $this->admin_model->update_user($c_name, $c_password, $viewid, $c_orgpassword);
      if ($res[0] === "success") {
        redirect(base_url("allusers"), "refresh");
      } else {
        $this->session->set_flashdata('enotadded', '<p class="alert alert-danger alert-dismissible">Not Added !<button type="button" class="btn-close" data-bs-dismiss="alert"></button></p>');
        redirect(base_url("allusers"), "");
      }
    }
  }



}
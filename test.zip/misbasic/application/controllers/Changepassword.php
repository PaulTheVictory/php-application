<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Changepassword extends CI_Controller
{

  function __construct()
  {
    parent::__construct();
    $this->load->model('Login_Model', 'login_model', TRUE);
    $this->load->helper('form');
    $this->load->library('form_validation');
    $this->load->library("user_agent");
  }

  public function index()
  {

    if ($this->session->userdata("super_in")) {
      $data["title"] = "Change Password";
      $this->load->view("layout/header_script", $data);
      $this->load->view("layout/header", $data);
      $this->load->view("cpass_view", $data);
      $this->load->view("layout/footer");
      $this->load->view("layout/footer_script");
    } elseif ($this->session->userdata("admin_in")) {
      $data["title"] = "Change Password";
      $this->load->view("layout/header_script", $data);
      $this->load->view("layout/header", $data);
      $this->load->view("acpass_view");
      $this->load->view("layout/footer");
      $this->load->view("layout/footer_script");
    } elseif ($this->session->userdata("user_in")) {
      $data["title"] = "Change Password";
      $this->load->view("layout/header_script", $data);
      $this->load->view("layout/header", $data);
      $this->load->view("ucpass_view");
      $this->load->view("layout/footer");
      $this->load->view("layout/footer_script");
    }
  }

  public function cpass_change()
  {

    $this->form_validation->set_rules("old_pass", "Old Name", "trim|required|min_length[3]");
    $this->form_validation->set_rules("new_pass", "New Password", "trim|required|min_length[6]|max_length[25]");
    $this->form_validation->set_rules("confirm_pass", "Confirm Password", "trim|required|min_length[6]|max_length[25]|matches[new_pass]");
    $this->form_validation->set_error_delimiters('<p class="alert alert-danger alert-dismissible">', '<button type="button" class="btn-close" data-bs-dismiss="alert"></button></p>');
    if ($this->form_validation->run() === FALSE) {
      $data["title"] = "Change Password";
      $this->load->view("layout/header_script", $data);
      $this->load->view("layout/header", $data);
      $this->load->view("cpass_view");
      $this->load->view("layout/footer");
      $this->load->view("layout/footer_script");
    } else {
      $passkey = $this->config->item('passkey');
      $c_id = $this->session->userdata("user_id");
      $c_oldpass = sha1($passkey . $this->input->post("old_pass", true));
      $c_newpass = sha1($passkey . $this->input->post("new_pass", true));
      $c_orgpass = $this->input->post("new_pass", true);
      $res = $this->login_model->s_change_password($c_id, $c_oldpass, $c_newpass, $c_orgpass);
      if ($res[0] === "success") {
        $this->session->set_flashdata('success', '<p class="alert alert-success alert-dismissible">Successfully Updated<button type="button" class="btn-close" data-bs-dismiss="alert"></button></p>');
        redirect("changepassword", "refresh");
      } else {
        $this->session->set_flashdata('fail', '<p class="alert alert-danger alert-dismissible">Not Updated<button type="button" class="btn-close" data-bs-dismiss="alert"></button></p>');
        redirect("changepassword", "refresh");
      }
    }
  }

  public function ucpass_change()
  {

    $this->form_validation->set_rules("old_pass", "Old Name", "trim|required|min_length[3]");
    $this->form_validation->set_rules("new_pass", "New Password", "trim|required|min_length[6]|max_length[25]");
    $this->form_validation->set_rules("confirm_pass", "Confirm Password", "trim|required|min_length[6]|max_length[25]|matches[new_pass]");
    $this->form_validation->set_error_delimiters('<p class="alert alert-danger alert-dismissible">', '<button type="button" class="btn-close" data-bs-dismiss="alert"></button></p>');
    if ($this->form_validation->run() === FALSE) {
      $data["title"] = "Change Password";
      $this->load->view("layout/header_script", $data);
      $this->load->view("layout/header", $data);
      $this->load->view("ucpass_view");
      $this->load->view("layout/footer");
      $this->load->view("layout/footer_script");
    } else {
      $passkey = $this->config->item('passkey');
      $c_id = $this->session->userdata("user_id");
      $c_oldpass = sha1($passkey . $this->input->post("old_pass", true));
      $c_newpass = sha1($passkey . $this->input->post("new_pass", true));
      $c_orgpass = $this->input->post("new_pass", true);
      $res = $this->login_model->u_change_password($c_id, $c_oldpass, $c_newpass, $c_orgpass);
      if ($res[0] === "success") {
        $this->session->set_flashdata('success', '<p class="alert alert-success alert-dismissible">Successfully Updated<button type="button" class="btn-close" data-bs-dismiss="alert"></button></p>');
        redirect("changepassword", "refresh");
      } else {
        $this->session->set_flashdata('fail', '<p class="alert alert-danger alert-dismissible">Not Updated<button type="button" class="btn-close" data-bs-dismiss="alert"></button></p>');
        redirect("changepassword", "refresh");
      }
    }
  }


  public function acpass_change()
  {

    $this->form_validation->set_rules("old_pass", "Old Name", "trim|required|min_length[3]");
    $this->form_validation->set_rules("new_pass", "New Password", "trim|required|min_length[6]|max_length[25]");
    $this->form_validation->set_rules("confirm_pass", "Confirm Password", "trim|required|min_length[6]|max_length[25]|matches[new_pass]");
    $this->form_validation->set_error_delimiters('<p class="alert alert-danger alert-dismissible">', '<button type="button" class="btn-close" data-bs-dismiss="alert"></button></p>');
    if ($this->form_validation->run() === FALSE) {
      $data["title"] = "Change Password";
      $this->load->view("layout/header_script", $data);
      $this->load->view("layout/header", $data);
      $this->load->view("acpass_view");
      $this->load->view("layout/footer");
      $this->load->view("layout/footer_script");
    } else {
      $passkey = $this->config->item('passkey');
      $c_id = $this->session->userdata("user_id");
      $c_oldpass = sha1($passkey . $this->input->post("old_pass", true));
      $c_newpass = sha1($passkey . $this->input->post("new_pass", true));
      $c_orgpass = $this->input->post("new_pass", true);
      $res = $this->login_model->a_change_password($c_id, $c_oldpass, $c_newpass, $c_orgpass);
      if ($res[0] === "success") {
        $this->session->set_flashdata('success', '<p class="alert alert-success alert-dismissible">Successfully Updated<button type="button" class="btn-close" data-bs-dismiss="alert"></button></p>');
        redirect("changepassword", "refresh");
      } else {
        $this->session->set_flashdata('fail', '<p class="alert alert-danger alert-dismissible">Not Updated<button type="button" class="btn-close" data-bs-dismiss="alert"></button></p>');
        redirect("changepassword", "refresh");
      }
    }
  }




}

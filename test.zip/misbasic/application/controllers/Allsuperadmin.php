<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Allsuperadmin extends CI_Controller
{
  function __construct()
  {
    parent::__construct();
    $this->load->model('Superadmin_Model', 'superadmin_model', TRUE);
    $this->load->helper('form');
    $this->load->library('form_validation');
    $this->load->library("user_agent");
  }

  public function index()
  {
    if ($this->session->userdata("super_in")) {
      $data["title"] = "All Superadmin";
      $data['allsuperadmin'] = $this->superadmin_model->GetSuperAdminLists();
      $this->load->view("layout/header_script", $data);
      $this->load->view("layout/header", $data);
      $this->load->view("allsuperadmin_view", $data);
      $this->load->view("layout/footer");
      $this->load->view("layout/footer_script");
    } elseif ($this->session->userdata("admin_in")) {
      $data["title"] = "Dashboard";
      $this->load->view("layout/header_script", $data);
      $this->load->view("layout/header", $data);
      $this->load->view("adminhome_view");
      $this->load->view("layout/footer");
      $this->load->view("layout/footer_script");
    } elseif ($this->session->userdata("user_in")) {
      $data["title"] = "Dashboard";
      $this->load->view("layout/header_script", $data);
      $this->load->view("layout/header", $data);
      $this->load->view("userhome_view");
      $this->load->view("layout/footer");
      $this->load->view("layout/footer_script");
    } else {
      $data["title"] = "Login";
      $this->load->view("layout/header_script", $data);
      $this->load->view("login_view");
      $this->load->view("layout/footer_script");
    }
  }

public function newsuperadmin()
{
  $this->form_validation->set_rules("user_name", "User Name", "trim|required|min_length[3]|max_length[20]|is_unique[admin.user_name]");
  $this->form_validation->set_rules("pass_word", "User Password", "trim|required|min_length[6]|max_length[25]");
  $this->form_validation->set_error_delimiters('<p class="alert alert-danger alert-dismissible">', '<button type="button" class="btn-close" data-bs-dismiss="alert"></button></p>');
  if ($this->form_validation->run() === FALSE) {
    $data['allsuperadmin'] = $this->superadmin_model->GetSuperAdminLists();

    $data["title"] = "Add Superadmin";
    $this->load->view("layout/header_script", $data);
    $this->load->view("layout/header", $data);
    $this->load->view("allsuperadmin_view");
    $this->load->view("layout/footer");
    $this->load->view("layout/footer_script");
  } else {
    $passkey = $this->config->item('passkey');
    date_default_timezone_set("Asia/Calcutta");
    $c_doneby = $this->session->userdata("user_id");
    $c_date = date('Y-m-j H:i:s');
    $c_email = $this->input->post("user_name", true);
    $c_password = sha1($passkey . $this->input->post("pass_word", true));
    $c_orgpassword = $this->input->post("pass_word", true);
    $res = $this->superadmin_model->add_super_admin($c_email, $c_password, $c_date, $c_doneby, $c_orgpassword);


    if ($res[0] === "success") {
      redirect(base_url("allsuperadmin"), "refresh");
    } else {
      $data['allsuperadmin'] = $this->superadmin_model->GetSuperAdminLists();
      $this->session->set_flashdata('notadded', '<p class="alert alert-danger alert-dismissible">you are not authorized this action!<button type="button" class="btn-close" data-bs-dismiss="alert"></button></p>');
      $data["title"] = "Add Superadmin";
      $this->load->view("layout/header_script", $data);
      $this->load->view("layout/header", $data);
      $this->load->view("allsuperadmin_view");
      $this->load->view("layout/footer");
      $this->load->view("layout/footer_script");
      exit(0);
    }
  }



}

//

public function UpdateSuperadmin()
{
  $deleteid = isset($_POST['updateid']) ? $_POST['updateid'] : '';
  $sid = isset($_POST['sid']) ? $_POST['sid'] : '';
  $result = $this->superadmin_model->UpdateSuperadminById($deleteid, $sid);
  echo json_encode($result);
}


//

public function DeleteSuperAdmin()
	{
		$deleteid = isset($_POST['deleteid'])?$_POST['deleteid']:'';
		$result = $this->superadmin_model->DeleteSuperAdminById($deleteid);
		echo json_encode($result);
	}

  public function getsinglesuperadmin()
  {
    $f_id = isset($_POST['f_id']) ? $_POST['f_id'] : '';
    $res = $this->superadmin_model->getsinglesuperdetails($f_id);
    $arr["result"] = $res;
    echo json_encode($arr);
  }

  //

  public function update_superadmin()
  {

$this->form_validation->set_rules("user_name", "User Name", "trim|required|min_length[3]|max_length[20]|is_unique[admin.user_name]");
  $this->form_validation->set_rules("pass_word", "User Password", "trim|required|min_length[6]|max_length[25]");
  $this->form_validation->set_error_delimiters('<p class="alert alert-danger alert-dismissible">', '<button type="button" class="btn-close" data-bs-dismiss="alert"></button></p>');
  if ($this->form_validation->run() === FALSE) {
    $data['allsuperadmin'] = $this->superadmin_model->GetSuperAdminLists();

    $data["title"] = "Add Superadmin";
    $this->load->view("layout/header_script", $data);
    $this->load->view("layout/header", $data);
    $this->load->view("allsuperadmin_view");
    $this->load->view("layout/footer");
    $this->load->view("layout/footer_script");
  } else {
    $passkey = $this->config->item('passkey');
    $c_email = $this->input->post("user_name", true);
    $c_password = sha1($passkey . $this->input->post("pass_word", true));
    $c_orgpassword = $this->input->post("pass_word", true);
    $admin_id = $this->input->post("admin_id", true);
    $res = $this->superadmin_model->update_super_admin($c_email, $c_password, $c_orgpassword,$admin_id);


    if ($res[0] === "success") {
      redirect(base_url("allsuperadmin"), "refresh");
    } else {
      $data['allsuperadmin'] = $this->superadmin_model->GetSuperAdminLists();
      $this->session->set_flashdata('notadded', '<p class="alert alert-danger alert-dismissible">you are not authorized this action!<button type="button" class="btn-close" data-bs-dismiss="alert"></button></p>');
      $data["title"] = "Add Superadmin";
      $this->load->view("layout/header_script", $data);
      $this->load->view("layout/header", $data);
      $this->load->view("allsuperadmin_view");
      $this->load->view("layout/footer");
      $this->load->view("layout/footer_script");
      exit(0);
    }
  }



  }















}

<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Allcustomers extends CI_Controller
{
  function __construct()
  {
    parent::__construct();
    $this->load->model('Superadmin_Model', 'superadmin_model', TRUE);
    $this->load->helper('form');
    $this->load->library('form_validation');
    $this->load->library("user_agent");
  }

  public function index()
  {
    if ($this->session->userdata("super_in")) {
      $data['customerlist'] = $this->superadmin_model->GetCustomerLists();
      $data["title"] = "All Customers";
      $this->load->view("layout/header_script", $data);
      $this->load->view("layout/header", $data);
      $this->load->view("allcustomers_view", $data);
      $this->load->view("layout/footer");
      $this->load->view("layout/footer_script");
    }else {
      $data["title"] = "Login";
      $this->load->view("layout/header_script", $data);
      $this->load->view("login_view");
      $this->load->view("layout/footer_script");
    }
  }

  public function get_customerview()
  {
    $view_id = isset($_POST['view_id']) ? $_POST['view_id'] : '';
    $res = $this->superadmin_model->get_customerview_details($view_id);
    echo json_encode($res);
    
    
  }


  public function delete_customer()
  {
    $deleteid = isset($_POST['deleteid']) ? $_POST['deleteid'] : '';
    $result = $this->superadmin_model->DeleteById($deleteid);
    echo json_encode($result);
  }

  public function status_update_customer()
  {
    $deleteid = isset($_POST['updateid']) ? $_POST['updateid'] : '';
    $sid = isset($_POST['sid']) ? $_POST['sid'] : '';
    $result = $this->superadmin_model->UpdateById($deleteid, $sid);
    echo json_encode($result);
  }



  public function newcustomer()
  {
    $this->form_validation->set_rules("username", "Customer Name", "trim|required|min_length[3]|max_length[20]");
    $this->form_validation->set_rules("company_name", "Customer Name", "trim|required|min_length[3]|max_length[20]");
    $this->form_validation->set_rules("email", "Customer Email", "trim|required|valid_email|max_length[25]|is_unique[ap_users.email]");
    $this->form_validation->set_rules("phone", "Customer Password", "trim|required|min_length[10]|max_length[15]|is_unique[ap_users.phone]");
    $this->form_validation->set_rules("password", "Customer Password", "trim|required|min_length[6]|max_length[25]");
    $this->form_validation->set_error_delimiters('<p class="alert alert-danger alert-dismissible">', '<button type="button" class="btn-close" data-bs-dismiss="alert"></button></p>');
    if ($this->form_validation->run() === FALSE) {
      $this->session->set_flashdata('validation', '<p class="alert alert-danger alert-dismissible">Form Validation failed!<button type="button" class="btn-close" data-bs-dismiss="alert"></button></p>');
      $data['customerlist'] = $this->superadmin_model->GetCustomerLists();
      $data["title"] = "All Customers";
      $this->load->view("layout/header_script", $data);
      $this->load->view("layout/header", $data);
      $this->load->view("allcustomers_view", $data);
      $this->load->view("layout/footer");
      $this->load->view("layout/footer_script");
    } else {
      $id = uniqid();
      $fileName = "";
      if (isset($_FILES["company_logo"]) && !empty($_FILES["company_logo"]['name'])) {
        $imageExtensions = array('.jpg', '.jpeg', '.png', '.pdf');

        $file_size = $_FILES['company_logo']['size'];
        if ((number_format($file_size / 1048576, 2) > 5)) {
          $this->session->set_flashdata('large', '<p class="alert alert-danger alert-dismissible">Customer logo file size please add below 2MB<button type="button" class="btn-close" data-bs-dismiss="alert"></button></p>');
          redirect(base_url("allcustomers"), "");
        }
        $fileExtension = strrchr($_FILES['company_logo']['name'], ".");
        $fileName = $id . "" . $fileExtension;
        $dirname = './docs/customerlogo/';
        $destinationfull = $dirname . $fileName;
        if (in_array(strtolower($fileExtension), $imageExtensions)) {

          $resultfull = move_uploaded_file($_FILES['company_logo']['tmp_name'], $destinationfull);

          if ($resultfull) {
            $passkey = $this->config->item('passkey');
            date_default_timezone_set("Asia/Calcutta");
            $c_user_id = $this->session->userdata("user_id");
            $c_admin_id = $this->session->userdata("admin_id");
            $c_superadmin_id = $this->session->userdata("superadmin_id");
            $c_date = date('Y-m-j H:i:s');
            $c_name = $this->input->post("username", true);
            $c_cname = $this->input->post("company_name", true);
            $c_email = $this->input->post("email", true);
            $c_phone = $this->input->post("phone", true);
            $c_password = sha1($passkey . $this->input->post("password", true));
            $c_orgpassword = $this->input->post("password", true);
            $c_image = $fileName;
            $res = $this->superadmin_model->add_customer($c_user_id, $c_admin_id, $c_superadmin_id, $c_date, $c_name, $c_cname, $c_email, $c_phone, $c_password, $c_orgpassword, $c_image);


            if ($res[0] === "success") {
              redirect(base_url("allcustomers"), "refresh");
            } else {
              $this->session->set_flashdata('notadded', '<p class="alert alert-danger alert-dismissible">Not Added !<button type="button" class="btn-close" data-bs-dismiss="alert"></button></p>');
              redirect(base_url("allcustomers"), "");
            }
          } else {
            $this->session->set_flashdata('finalexit', '<p class="alert alert-danger alert-dismissible">Image Upload failed<button type="button" class="btn-close" data-bs-dismiss="alert"></button></p>');
            redirect(base_url("allcustomers"), "");
          }
        } else {
          $this->session->set_flashdata('finalexit', '<p class="alert alert-danger alert-dismissible">Image Upload failed<button type="button" class="btn-close" data-bs-dismiss="alert"></button></p>');
          redirect(base_url("allcustomers"), "");
        }
      } else {
        $this->session->set_flashdata('finalexit', '<p class="alert alert-danger alert-dismissible">Image Upload failed<button type="button" class="btn-close" data-bs-dismiss="alert"></button></p>');
        redirect(base_url("allcustomers"), "");
      }
    }
  }

  public function getsinglecustomer()
  {
    $f_id = isset($_POST['f_id']) ? $_POST['f_id'] : '';
    $res = $this->superadmin_model->getsinglecustomerdetails($f_id);
    $arr["result"] = $res;
    echo json_encode($arr);
  }



  public function editcustomerbyid()
  {
    $viewid = isset($_POST['user_id']) ? $_POST['user_id'] : '';
    $this->form_validation->set_rules("username", "Customer Name", "trim|required|min_length[3]|max_length[20]");
    $this->form_validation->set_rules("password", "Customer Password", "trim|required|min_length[6]|max_length[25]");
    $this->form_validation->set_error_delimiters('<p class="alert alert-danger alert-dismissible">', '<button type="button" class="btn-close" data-bs-dismiss="alert"></button></p>');
    if ($this->form_validation->run() === FALSE) {
      $this->session->set_flashdata('evalidation', '<p class="alert alert-danger alert-dismissible">Form Validation failed!<button type="button" class="btn-close" data-bs-dismiss="alert"></button></p>');
      $data['customerlist'] = $this->superadmin_model->GetCustomerLists();
      $data["title"] = "All Customers";
      $this->load->view("layout/header_script", $data);
      $this->load->view("layout/header", $data);
      $this->load->view("allcustomers_view", $data);
      $this->load->view("layout/footer");
      $this->load->view("layout/footer_script");
    } else {
      $id = uniqid();
      $fileName = "";
      if (isset($_FILES["company_logo"]) && !empty($_FILES["company_logo"]['name'])) {
        $imageExtensions = array('.jpg', '.jpeg', '.png', '.pdf');

        $file_size = $_FILES['company_logo']['size'];
        if ((number_format($file_size / 1048576, 2) > 5)) {
          $this->session->set_flashdata('elarge', '<p class="alert alert-danger alert-dismissible">Customer logo file size please add below 2MB<button type="button" class="btn-close" data-bs-dismiss="alert"></button></p>');
          redirect(base_url("allcustomers"), "");
        }
        $fileExtension = strrchr($_FILES['company_logo']['name'], ".");
        $fileName = $id . "" . $fileExtension;
        $dirname = './docs/customerlogo/';
        $destinationfull = $dirname . $fileName;
        if (in_array(strtolower($fileExtension), $imageExtensions)) {

          $resultfull = move_uploaded_file($_FILES['company_logo']['tmp_name'], $destinationfull);

          if ($resultfull) {
            $passkey = $this->config->item('passkey');
            $c_name = $this->input->post("username", true);
             $c_password = sha1($passkey . $this->input->post("password", true));
            $c_orgpassword = $this->input->post("password", true);
            $c_image = $fileName;
            $res = $this->superadmin_model->update_customer($c_name, $c_password, $c_image, $viewid, $c_orgpassword);


            if ($res[0] === "success") {
              redirect(base_url("allcustomers"), "refresh");
            } else {
              $this->session->set_flashdata('enotadded', '<p class="alert alert-danger alert-dismissible">Not Added !<button type="button" class="btn-close" data-bs-dismiss="alert"></button></p>');
              redirect(base_url("allcustomers"), "");
            }
          } else {
            $this->session->set_flashdata('efinalexit', '<p class="alert alert-danger alert-dismissible">Image Upload failed<button type="button" class="btn-close" data-bs-dismiss="alert"></button></p>');
            redirect(base_url("allcustomers"), "");
          }
        } else {
          $this->session->set_flashdata('efinalexit', '<p class="alert alert-danger alert-dismissible">Image Upload failed<button type="button" class="btn-close" data-bs-dismiss="alert"></button></p>');
          redirect(base_url("allcustomers"), "");
        }
      } else {
        $viewid = isset($_POST['user_id']) ? $_POST['user_id'] : '';
        $passkey = $this->config->item('passkey');
        $c_name = $this->input->post("username", true);
        $c_password = sha1($passkey . $this->input->post("password", true));
        $c_orgpassword = $this->input->post("password", true);
        $res = $this->superadmin_model->updatenoimage_customer($c_name, $c_password, $viewid, $c_orgpassword);
        if ($res[0] === "success") {
          redirect(base_url("allcustomers"), "refresh");
        } else {
          $this->session->set_flashdata('enotadded', '<p class="alert alert-danger alert-dismissible">Not Added !<button type="button" class="btn-close" data-bs-dismiss="alert"></button></p>');
          redirect(base_url("allcustomers"), "");
        }
      }
    }
  }
}

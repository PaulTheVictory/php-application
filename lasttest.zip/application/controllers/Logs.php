<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Logs extends CI_Controller
{
  function __construct()
  {
    parent::__construct();
    $this->load->model('admin_Model', 'admin_model', TRUE);
    $this->load->library('table');
  }

  public function index()
  {
    if ($this->session->userdata("admin_in")) {
      $data["title"] = "All Logs";
      // $data['alllogs'] = $this->admin_model->GetLogLists();
      $tmpl = array('table_open' => '<table class="sortable sorting disabled" id="customer_view" style="margin-top:0px;">');
      $this->table->set_template($tmpl);
      $this->table->set_heading('S No', 'Email Address', 'Name', 'Role', 'Intime', 'Outtime');
      $this->load->view("layout/header_script", $data);
      $this->load->view("layout/header", $data);
      $this->load->view("logs_view",$data);
      $this->load->view("layout/footer");
      $this->load->view("layout/footer_script");
    } elseif ($this->session->userdata("super_in") || $this->session->userdata("user_in")) {
      redirect(base_url()); 
   } else {
      $data["title"] = "Login";
      $this->load->view("layout/header_script", $data);
      $this->load->view("login_view");
      $this->load->view("layout/footer_script");
    }
  }

  public function alladminreportlog()
  {
    $ret =  $this->admin_model->alladminreportlog();
    echo $ret;
  }


}

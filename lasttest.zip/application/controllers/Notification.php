<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Notification extends CI_Controller {
  function __construct()
  {
    parent::__construct();
    $this->load->model('Notification_Model', 'notification_model', TRUE);
    $this->load->helper('form');
    $this->load->library('form_validation');
    $this->load->library("user_agent");
  }

public function index()
{

  if ($this->session->userdata("admin_in")) {
    //redirect(base_url()); 
  } elseif ($this->session->userdata("super_in") || $this->session->userdata("user_in")) {
    redirect(base_url()); 
 }else {
    $data["title"] = "Login";
    $this->load->view("layout/header_script", $data);
    $this->load->view("login_view");
    $this->load->view("layout/footer_script");
  }


}


public function create_notification()
{
  $follow_up_id = isset($_POST['follow_up_id']) ? $_POST['follow_up_id'] : '';
  $admin_id = isset($_POST['admin_id']) ? $_POST['admin_id'] : '';
  $enquiry_id = isset($_POST['enquiry_id']) ? $_POST['enquiry_id'] : '';
  $status = isset($_POST['status']) ? $_POST['status'] : '';
  $this->session->set_flashdata('notification', '');
  $res = $this->notification_model->send_notification($follow_up_id,$admin_id,$enquiry_id,$status);
  echo json_encode($res);

}


public function create_notification_super()
{
  $follow_up_id = isset($_POST['follow_up_id']) ? $_POST['follow_up_id'] : '';
  $admin_id = isset($_POST['admin_id']) ? $_POST['admin_id'] : '';
  $enquiry_id = isset($_POST['enquiry_id']) ? $_POST['enquiry_id'] : '';
  $status = isset($_POST['status']) ? $_POST['status'] : '';
  $this->session->set_flashdata('notification', '');
  $res = $this->notification_model->send_notification_super($follow_up_id,$admin_id,$enquiry_id,$status);
  echo json_encode($res);

}


public function get_currentuser_notification()
{
  $res = $this->notification_model->get_singleuser_notification();
  echo json_encode($res);
}


public function remove_notify()
{
  $notify_id = isset($_POST['notify_id']) ? $_POST['notify_id'] : '';
  $user_id = isset($_POST['user_id']) ? $_POST['user_id'] : '';
  $res = $this->notification_model->remove_current_notify($notify_id,$user_id);
  echo json_encode($res);
}


public function view_notify_message()
{

  $notify_id = isset($_POST['notify_id']) ? $_POST['notify_id'] : '';
  $user_id = isset($_POST['user_id']) ? $_POST['user_id'] : '';
  $res = $this->notification_model->show_notify_message($notify_id,$user_id);
  echo json_encode($res);



}


public function view_notify_message_all()
{

  $notify_id = isset($_POST['notify_id']) ? $_POST['notify_id'] : '';
  $user_id = isset($_POST['user_id']) ? $_POST['user_id'] : '';
  $res = $this->notification_model->show_notify_message_all($notify_id,$user_id);
  echo json_encode($res);



}














}
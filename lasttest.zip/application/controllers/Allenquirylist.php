<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Allenquirylist extends CI_Controller
{
  function __construct()
  {
    parent::__construct();
    $this->load->model('Superadmin_Model', 'superadmin_model', TRUE);
    $this->load->model('Admin_Model', 'admin_model', TRUE);
    $this->load->helper('form');
    $this->load->library('form_validation');
    $this->load->library("user_agent");
  }

  public function index()
  {
    if ($this->session->userdata("super_in")) {
      $data['enquirylist'] = $this->superadmin_model->getallenquiry();
      $data["title"] = "Enquiry";
      $this->load->view("layout/header_script", $data);
      $this->load->view("layout/header", $data);
      $this->load->view("allenquirylist_view", $data);
      $this->load->view("layout/footer");
      $this->load->view("layout/footer_script");
    } elseif ($this->session->userdata("admin_in") || $this->session->userdata("user_in")) {
       redirect(base_url()); 
    } else {
      $data["title"] = "Login";
      $this->load->view("layout/header_script", $data);
      $this->load->view("login_view");
      $this->load->view("layout/footer_script");
    }
  }

  
}

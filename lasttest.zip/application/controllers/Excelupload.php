<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Excelupload extends CI_Controller
{

	public function __construct()
	{
		parent::__construct();
		$this->load->model('Excel_model', 'excel_model', TRUE);
		$this->load->library('excel');
	}

	public function index()
	{

		if ($this->session->userdata("admin_in")) {
			//redirect(base_url()); 
		} elseif ($this->session->userdata("super_in") || $this->session->userdata("user_in")) {
			redirect(base_url());
		} else {
			$data["title"] = "Login";
			$this->load->view("layout/header_script", $data);
			$this->load->view("login_view");
			$this->load->view("layout/footer_script");
		}
	}



	public function import()
	{

		if(isset($_FILES["bulk_upload"]["name"]))
			{

		$inputFileName = $_FILES["bulk_upload"]["tmp_name"];
		try {
			$inputFileType = PHPExcel_IOFactory::identify($inputFileName);
			$objReader = PHPExcel_IOFactory::createReader($inputFileType);
			$objPHPExcel = $objReader->load($inputFileName);
		} catch (Exception $e) {
			die('Error loading file "' . pathinfo($inputFileName, PATHINFO_BASENAME)
				. '": ' . $e->getMessage());
		}
		$allDataInSheet = $objPHPExcel->getActiveSheet()->toArray(null, true, true, true);

		$arrayCount = count($allDataInSheet);
		$flag = 0;
		$createArray = array(
			'Enquiryname', 
			'Enquirycontactnumber', 
			'EnquiryDate', 
			'Enquirylocation', 
			'Enquirymessage',
			'Projectname',
			
		);
		$makeArray = array(
			'Enquiryname' => 'Enquiryname', 
			'Enquirycontactnumber' => 'Enquirycontactnumber', 
			'EnquiryDate' => 'EnquiryDate', 
			'Enquirylocation' => 'Enquirylocation', 
			'Enquirymessage' => 'Enquirymessage',
			'Projectname' => 'Projectname',
			
		);
		$SheetDataKey = array();
		foreach ($allDataInSheet as $dataInSheet) {
			foreach ($dataInSheet as $key => $value) {
				if (in_array(trim($value), $createArray)) {
					$value = preg_replace('/\s+/', '', $value);
					$SheetDataKey[trim($value)] = $key;
				} else {
				}
			}
		}
		$data = array_diff_key($makeArray, $SheetDataKey);

		if (empty($data)) {
			$flag = 1;
		}
		if ($flag == 1) {
			for ($i = 2; $i <= $arrayCount; $i++) {
				
				$enq_name = $SheetDataKey['Enquiryname'];
				$enq_contact_number = $SheetDataKey['Enquirycontactnumber'];
				$enq_date = $SheetDataKey['EnquiryDate'];
				$enq_location = $SheetDataKey['Enquirylocation'];
				$enq_msg = $SheetDataKey['Enquirymessage'];
				$project_id = $SheetDataKey['Projectname'];
				$enq_name = trim($allDataInSheet[$i][$enq_name]);
				$enq_contact_number = trim($allDataInSheet[$i][$enq_contact_number]);
				$enq_date = trim($allDataInSheet[$i][$enq_date]);
				$enq_location = trim($allDataInSheet[$i][$enq_location]);
				$enq_msg = trim($allDataInSheet[$i][$enq_msg]);
				$project_id = trim($allDataInSheet[$i][$project_id]);
				$eid = uniqid(true);
				$pid = uniqid(true);
				$fid = uniqid(true);
				$aid1 = uniqid(true);
				$aid2 = uniqid(true);
				date_default_timezone_set("Asia/Calcutta");

				if($enq_name=="" && $enq_contact_number=="" && $enq_date=="" && $enq_location=="" && $enq_msg=="" && $project_id=="") {continue;}


				$fetchData[] = array(
					"enquiry_id" => $eid,
					"admin_id" => $this->session->userdata("user_id"),
					"superadmin_id" => $this->session->userdata("superadmin_id"),
					"enq_name" => $enq_name,
					'enq_contact_number' => $enq_contact_number, 
					'enq_date' => $enq_date, 
					'enq_location' => $enq_location, 
					'enq_msg' => $enq_msg, 
					'project_id' => $pid."|".$project_id,
					'enq_status' => 1,
					'done_by' => $this->session->userdata("user_id"),
					'created' => date('Y-m-j H:i:s'),
				);

				$data4[] = array(
					"project_id" => $pid,
					"admin_id" => $this->session->userdata("user_id"),
					"superadmin_id" => $this->session->userdata("superadmin_id"),
					"project_name" => $project_id,
					"project_status" => 1,
					"done_by" => $this->session->userdata("user_id"),
					"created" => date('Y-m-j H:i:s'),
				);

				$data2[] = array(
					"follow_up_id"=> $fid,
					"enquiry_id"=> $eid,
					"admin_id"=> $this->session->userdata("user_id"),
					"superadmin_id"=> $this->session->userdata("superadmin_id"),
					"follow_up_msg"=>"",
					"project_id"=> $project_id."|".$project_id,
					"follow_up_status"=> "pending",
					"nxt_follow_up_date"=>"",
					"nxt_follow_up_hint"=>"",
					"done_by"=> $this->session->userdata("user_id"),
					"created"=> date('Y-m-j H:i:s'),
				);

				$data1[] = array(
					"action_id" => $aid1,
					"action_type" => "create",
					"action_name" => "Add Enquiry",
					"module_id" => $eid,
					"deleted_by"=> "Enquiry Name: ".$enq_name,
					"done_by" => $this->session->userdata("user_id"),
					"created" => date('Y-m-j H:i:s'),
				);

				$data3[] = array(
					"action_id" => $aid2,
					"action_type" => "create",
					"action_name" => "Add Follow Up Progress",
					"module_id" => $fid,
					"deleted_by"=>"Enquiry name: ".$enq_name.", Project Name: ".$project_id,
					"done_by" => $this->session->userdata("user_id"),
					"created" => date('Y-m-j H:i:s'),
				);
			
			}
			$ress = $this->excel_model->insert($fetchData,$data2,$data1,$data3,$data4);
			if($ress) {
				$result = array(0=>"success");
				echo json_encode($result);
			} else {
				$result = array(0=>"failed");
				echo json_encode($result);
			}
			
		} else {
			$result = array(0=>"failed");
				echo json_encode($result);
		}
	}
}

}

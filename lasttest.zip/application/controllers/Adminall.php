<?php

defined('BASEPATH') OR exit('No direct script access allowed');


class Adminall extends CI_Controller  {
  function __construct()
  {
    parent::__construct();
    $this->load->model('Test_Model', 'test_model', TRUE);
    $this->load->library('table');
  }
  


  public function index()
  {
    if ($this->session->userdata("admin_in")) {
      $tmpl = array('table_open' => '<table class="sortable sorting disabled" id="customer_view" style="margin-top:0px;">');
                $this->table->set_template($tmpl);
                $this->table->set_heading('S No', 'Done By','Project Name','Enquiry Name','Contact Number','Status','Next Follow Up','Action');
      $data["companyuser"] = $this->test_model->get_company_user_one();
      $data["title"] = "Admin Report";
      $this->load->view("layout/header_script",$data);
      $this->load->view("layout/header",$data);
      $this->load->view("adminall_view",$data);
      $this->load->view("layout/footer");
      $this->load->view("layout/footer_script");
    } elseif ($this->session->userdata("super_in") || $this->session->userdata("user_in")) {
      redirect(base_url());
    } else {
      $data["title"] = "Login";
      $this->load->view("layout/header_script", $data);
      $this->load->view("login_view");
      $this->load->view("layout/footer_script");
    }
    
  }


  public function alladminreport() {
    $postData = $this->input->post();
    $ret =  $this->test_model->alladminreport($postData);
    echo $ret;


  }


















}
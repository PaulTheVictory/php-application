<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Followupprogress extends CI_Controller {
  function __construct()
  {
    parent::__construct();
    $this->load->model('Admin_Model', 'admin_model', TRUE);
    $this->load->library('table');
    $this->load->helper('form');
    $this->load->library('form_validation');
  }

public function index()
{
  if ($this->session->userdata("admin_in")) {
      $data["companyuser"] = $this->admin_model->get_company_user_one();
    $data['plist'] = $this->admin_model->getprojects();
      $tmpl = array('table_open' => '<table class="sortable sorting disabled" id="customer_view" style="margin-top:0px;">');
      $this->table->set_template($tmpl);
      $this->table->set_heading('S No', 'Done By', 'Project Name', 'Enquiry Name', 'Contact Number', 'Status', 'Next Follow Up', 'Action');
    // $data['followuplist'] = $this->admin_model->getallfollowup($type); 
    $data["title"] = "Follow Up Progress";
    $this->load->view("layout/header_script",$data);
    $this->load->view("layout/header",$data);
    $this->load->view("followupprogress_view",$data);
    $this->load->view("layout/footer");
    $this->load->view("layout/footer_script");
  } elseif ($this->session->userdata("super_in") || $this->session->userdata("user_in")) {
    redirect(base_url()); 
 }else {
    $data["title"] = "Login";
    $this->load->view("layout/header_script", $data);
    $this->load->view("login_view");
    $this->load->view("layout/footer_script");
  }
  
}


  public function alladminreport()
  {
    $postData = $this->input->post();
    $ret =  $this->admin_model->alladminreport($postData);
    echo $ret;
  }
  
public function getcustomerview()
  {
    $view_id = isset($_POST['view_id']) ? $_POST['view_id'] : '';
    $res = $this->admin_model->get_customerview_details($view_id);
    echo json_encode($res);
    
    
  }



public function getsinglefprocess()
{
  $f_id = isset($_POST['f_id'])?$_POST['f_id']:'';
  $res = $this->admin_model->getprocessdetails($f_id);
  $arr["result"] = $res;
  echo json_encode($arr);

  
}

public function edit_customer_enquiry()
{
  $f_id = isset($_POST['f_id'])?$_POST['f_id']:'';
  $res = $this->admin_model->edit_customer_enquiry_details($f_id);
  $arr["result"] = $res;
  echo json_encode($arr);

  
}



public function add_followup_process_update()
{
    $this->form_validation->set_rules("follow_up_msg", "Follow up message", "trim|required|min_length[3]|max_length[200]");
    $this->form_validation->set_rules("follow_up_status", "Follow up status", "trim|required");
    $this->form_validation->set_rules("nxt_follow_up_date", "Follow up date", "trim|required");
    $this->form_validation->set_rules("nxt_follow_up_hint", "Follow up date", "max_length[200]");
    $this->form_validation->set_error_delimiters('<p class="alert alert-danger alert-dismissible">', '<button type="button" class="btn-close" data-bs-dismiss="alert"></button></p>');
    if ($this->form_validation->run() === FALSE) {
      $errors = validation_errors();
      $this->session->set_flashdata('fo_form_error', $errors);
      $this->session->set_flashdata('follow_up_msg', $this->input->post('follow_up_msg', true));
      $this->session->set_flashdata('follow_up_status', $this->input->post('follow_up_status', true));
      $this->session->set_flashdata('nxt_follow_up_date', $this->input->post('nxt_follow_up_date', true));
      $this->session->set_flashdata('nxt_follow_up_hint', $this->input->post('nxt_follow_up_hint', true));
      $this->session->set_flashdata('this_id', $this->input->post('this_id', true));
      redirect(base_url("followupprogress"));
    } else {
      $f_msg = $this->input->post("follow_up_msg",true);
      $f_status = $this->input->post("follow_up_status",true);
      $f_date = $this->input->post("nxt_follow_up_date",true);
      $f_msghint = $this->input->post("nxt_follow_up_hint",true);
      $this_id = $this->input->post("this_id");

      $res = $this->admin_model->updatenew_followup($f_msg,$f_status,$f_date,$f_msghint,$this_id);

      if($res[0]==="success") {
        $this->session->set_flashdata('fosuccess', '<p class="alert alert-success alert-dismissible">Added Successfully<button type="button" class="btn-close" data-bs-dismiss="alert"></button></p>');
        redirect(base_url("followupprogress"));
      } else {
    $this->session->set_flashdata('fonotupdated', '<p class="alert alert-danger alert-dismissible">Not Updated!<button type="button" class="btn-close" data-bs-dismiss="alert"></button></p>');
    redirect(base_url("followupprogress"));
      }




    }






}

public function DeleteEnquiry()
  {
    $deleteid = isset($_POST['deleteid']) ? $_POST['deleteid'] : '';
    $result = $this->admin_model->DeleteEnquiryById($deleteid);
    echo json_encode($result);
  }



public function DeleteFollowup()
{
  $deleteid = isset($_POST['deleteid'])?$_POST['deleteid']:'';
	$result = $this->admin_model->DeleteFollowupById($deleteid);
	echo json_encode($result);


}


public function DeleteFollowupLogs()
{
  $deleteid = isset($_POST['deleteid'])?$_POST['deleteid']:'';
	$result = $this->admin_model->DeleteFollowupByIdLog($deleteid);
	echo json_encode($result);


}


public function getsingleflogs()
{
  $f_id = isset($_POST['f_id'])?$_POST['f_id']:'';
  $res = $this->admin_model->getprocessdetailslogs($f_id);
  $arr["result"] = $res;
  echo json_encode($arr);

  
}



public function add_followup_process_update_log()
{
    $this->form_validation->set_rules("follow_up_msg", "Follow up message", "trim|required|min_length[3]|max_length[200]");
    $this->form_validation->set_rules("follow_up_status", "Follow up status", "trim|required");
    $this->form_validation->set_rules("nxt_follow_up_date", "Follow up date", "trim|required");
    $this->form_validation->set_rules("nxt_follow_up_hint", "Follow up date", "max_length[200]");
    $this->form_validation->set_error_delimiters('<p class="alert alert-danger alert-dismissible">', '<button type="button" class="btn-close" data-bs-dismiss="alert"></button></p>');
    if ($this->form_validation->run() === FALSE) {
      $errors = validation_errors();
      $this->session->set_flashdata('la_form_error', $errors);
      $this->session->set_flashdata('follow_up_msg', $this->input->post('follow_up_msg', true));
      $this->session->set_flashdata('follow_up_status', $this->input->post('follow_up_status', true));
      $this->session->set_flashdata('nxt_follow_up_date', $this->input->post('nxt_follow_up_date', true));
      $this->session->set_flashdata('nxt_follow_up_hint', $this->input->post('nxt_follow_up_hint', true));
      $this->session->set_flashdata('follow_up_id', $this->input->post('follow_up_id', true));
      $this->session->set_flashdata('follow_up_log_id', $this->input->post('follow_up_log_id', true));

      redirect(base_url("followupprogress"));
    } else {
      $f_msg = $this->input->post("follow_up_msg",true);
      $f_status = $this->input->post("follow_up_status",true);
      $f_date = $this->input->post("nxt_follow_up_date",true);
      $f_msghint = $this->input->post("nxt_follow_up_hint",true);
      $follow_up_id = $this->input->post("follow_up_id");
      $follow_up_log_id = $this->input->post("follow_up_log_id");

      $res = $this->admin_model->updatenew_followup_log($f_msg,$f_status,$f_date,$f_msghint,$follow_up_id,$follow_up_log_id);

      if($res[0]==="success") {
        $this->session->set_flashdata('lasuccess', '<p class="alert alert-success alert-dismissible">Added Successfully<button type="button" class="btn-close" data-bs-dismiss="alert"></button></p>');
        redirect(base_url("followupprogress"));
      } else {
   $this->session->set_flashdata('lanotupdated', '<p class="alert alert-danger alert-dismissible">Not Updated!<button type="button" class="btn-close" data-bs-dismiss="alert"></button></p>');
   redirect(base_url("followupprogress"));
      }




    }






}



public function addproject()
{
  $data['plist'] = $this->admin_model->getprojects();
  $this->form_validation->set_rules("project_name", "Project name", "trim|required|max_length[55]");
  $this->form_validation->set_error_delimiters('<p class="alert alert-danger alert-dismissible">', '<button type="button" class="btn-close" data-bs-dismiss="alert"></button></p>');
  if ($this->form_validation->run() === FALSE) {
    $errors = validation_errors();
    $this->session->set_flashdata('project_name', $this->input->post('project_name', true));
    $this->session->set_flashdata('p_form_error', $errors);
    redirect(base_url("followupprogress"));
  } else {
    date_default_timezone_set("Asia/Calcutta");
    $c_user_id = $this->session->userdata("user_id");
    $c_superadmin_id = $this->session->userdata("superadmin_id");
    $c_date = date('Y-m-j H:i:s');
    $c_name = $this->input->post("project_name", true);
    $res = $this->admin_model->add_newproject($c_user_id, $c_superadmin_id, $c_date, $c_name);


    if ($res[0] === "success") {
      $this->session->set_flashdata('psuccess', '<p class="alert alert-success alert-dismissible">Added Successfully<button type="button" class="btn-close" data-bs-dismiss="alert"></button></p>');
      redirect(base_url("followupprogress"));
    } else {
      $this->session->set_flashdata('pnotadded', '<p class="alert alert-danger alert-dismissible">Not Added !<button type="button" class="btn-close" data-bs-dismiss="alert"></button></p>');
      redirect(base_url("followupprogress"));
    }
  }
}


public function addenquiry()
  {

    $this->form_validation->set_rules("enq_name", "Enquiry Name", "trim|required|min_length[3]|max_length[40]");
    $this->form_validation->set_rules("enq_contact_number", "Enquiry contact number", "trim|required|numeric|min_length[10]|max_length[10]");
    $this->form_validation->set_rules("enq_date", "Enquiry date", "trim|required");
    $this->form_validation->set_rules("project_id", "Project name", "trim|required");
    $this->form_validation->set_error_delimiters('<p class="alert alert-danger alert-dismissible">', '<button type="button" class="btn-close" data-bs-dismiss="alert"></button></p>');
    if ($this->form_validation->run() === FALSE) {
       $errors = validation_errors();
      $this->session->set_flashdata('e_form_error', $errors);
      $this->session->set_flashdata('enq_name', $this->input->post('enq_name', true));
      $this->session->set_flashdata('enq_contact_number', $this->input->post('enq_contact_number', true));
      $this->session->set_flashdata('enq_date', $this->input->post('enq_date', true));
      $this->session->set_flashdata('project_id', $this->input->post('project_id', true));
      $this->session->set_flashdata('enq_location', $this->input->post('enq_location', true));
      $this->session->set_flashdata('enq_msg', $this->input->post('enq_msg', true));

      redirect(base_url("followupprogress"));
    } else {
      date_default_timezone_set("Asia/Calcutta");
      $j_date = date('Y-m-j H:i:s');
      $e_admin_id = $this->session->userdata("user_id");
      $e_superadmin_id = $this->session->userdata("superadmin_id");
      $e_name = $this->input->post("enq_name", true);
      $e_phone = $this->input->post("enq_contact_number", true);
      $e_date = $this->input->post("enq_date", true);
      $e_location = $this->input->post("enq_location", true);
      $e_project = $this->input->post("project_id", true);
      $e_projectmsg = $this->input->post("enq_msg", true);

      $res = $this->admin_model->add_newenquiry($e_admin_id, $e_superadmin_id, $e_name, $e_phone, $e_date, $e_project, $e_projectmsg, $j_date, $e_location);

      if ($res[0] === "success") {
        $this->session->set_flashdata('esuccess', '<p class="alert alert-success alert-dismissible">Added Successfully<button type="button" class="btn-close" data-bs-dismiss="alert"></button></p>');
        redirect(base_url("followupprogress"));
      } else {
        $this->session->set_flashdata('ennotadded', '<p class="alert alert-danger alert-dismissible">Not Added!<button type="button" class="btn-close" data-bs-dismiss="alert"></button></p>');
        redirect(base_url("followupprogress"), "refresh");
      }
    }
  }



  
public function editenquiry()
{

  $this->form_validation->set_rules("enq_name", "Enquiry Name", "trim|required|min_length[3]|max_length[40]");
  $this->form_validation->set_rules("enq_contact_number", "Enquiry contact number", "trim|required|numeric|min_length[10]|max_length[10]");
  $this->form_validation->set_rules("enq_date", "Enquiry date", "trim|required");
  $this->form_validation->set_rules("project_id", "Project name", "trim|required");
  $this->form_validation->set_error_delimiters('<p class="alert alert-danger alert-dismissible">', '<button type="button" class="btn-close" data-bs-dismiss="alert"></button></p>');
  if ($this->form_validation->run() === FALSE) {
     $errors = validation_errors();
    $this->session->set_flashdata('ee_form_error', $errors);
    $this->session->set_flashdata('eenq_name', $this->input->post('enq_name', true));
    $this->session->set_flashdata('eenq_contact_number', $this->input->post('enq_contact_number', true));
    $this->session->set_flashdata('eenq_date', $this->input->post('enq_date', true));
    $this->session->set_flashdata('eproject_id', $this->input->post('project_id', true));
    $this->session->set_flashdata('eenq_location', $this->input->post('enq_location', true));
    $this->session->set_flashdata('eenq_msg', $this->input->post('enq_msg', true));
    $this->session->set_flashdata('ee_id', $this->input->post('ee_id', true));
    
    redirect(base_url("followupprogress"));
  } else {
    date_default_timezone_set("Asia/Calcutta");
    $j_date = date('Y-m-j H:i:s');
    $e_admin_id = $this->session->userdata("user_id");
    $e_superadmin_id = $this->session->userdata("superadmin_id");
    $e_name = $this->input->post("enq_name", true);
    $e_phone = $this->input->post("enq_contact_number", true);
    $e_date = $this->input->post("enq_date", true);
    $e_location = $this->input->post("enq_location", true);
    $e_project = $this->input->post("project_id", true);
    $e_projectmsg = $this->input->post("enq_msg", true);
    $e_eid = $this->input->post("ee_id", true);

    $res = $this->admin_model->update_newenquiry($e_admin_id, $e_superadmin_id, $e_name, $e_phone, $e_date, $e_project, $e_projectmsg, $j_date, $e_location,$e_eid);

    if ($res[0] === "success") {
      $this->session->set_flashdata('eesuccess', '<p class="alert alert-success alert-dismissible">Updated Successfully<button type="button" class="btn-close" data-bs-dismiss="alert"></button></p>');
      redirect(base_url("followupprogress"));
    } else {
      $this->session->set_flashdata('eennotadded', '<p class="alert alert-danger alert-dismissible">Not Added!<button type="button" class="btn-close" data-bs-dismiss="alert"></button></p>');
      redirect(base_url("followupprogress"), "refresh");
    }
  }
}




}
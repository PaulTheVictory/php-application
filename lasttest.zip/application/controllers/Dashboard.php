<?php

defined('BASEPATH') or exit('No direct script access allowed');


class Dashboard extends CI_Controller
{
  function __construct()
  {
    parent::__construct();
    $this->load->model('Superadmin_Model', 'superadmin_model', TRUE);
    $this->load->model('Admin_Model', 'admin_model', TRUE);
    $this->load->model('User_Model', 'user_model', TRUE);
    $this->load->helper('form');
    $this->load->library('form_validation');
    $this->load->library("user_agent");
  }

  public function index()
  {
    if ($this->session->userdata("super_in") || $this->session->userdata("admin_in") || $this->session->userdata("user_in")) {
      $data["title"] = "Dashboard";
      $this->load->view("layout/header_script", $data);
      $this->load->view("layout/header", $data);
      if ($this->session->userdata("super_in")) {
        $this->load->view("superadminhome_view", $data);
      } elseif ($this->session->userdata("admin_in")) {
        // $data['recentfollowup'] = $this->admin_model->recent_report_admin();
        $this->load->view("adminhome_view", $data);
      } elseif ($this->session->userdata("user_in")) {
        $this->load->view("userhome_view", $data);
      }
      $this->load->view("layout/footer");
      $this->load->view("layout/footer_script");
    } else {
      $data["title"] = "Login";
      $this->load->view("layout/header_script", $data);
      $this->load->view("login_view");
      $this->load->view("layout/footer_script");
    }
  }

  public function data_all() {
    $res = $this->admin_model->con_report_admin();
        echo json_encode($res);
  }
  public function data_all_new() {
    $res = $this->admin_model->recent_report_admin();
        echo json_encode($res);
  }


  public function data_all_super() {
    $res = $this->superadmin_model->con_report_admin();
        echo json_encode($res);
  }


  public function data_all_user() {
    $res = $this->user_model->con_report_admin();
        echo json_encode($res);
  }

  
}

<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Allusers extends CI_Controller {
  function __construct()
  {
    parent::__construct();
    $this->load->model('Admin_Model', 'admin_model', TRUE);
    $this->load->helper('form');
    $this->load->library('form_validation');
    $this->load->library('table');
  }

public function index()
{
  if ($this->session->userdata("admin_in")) {
    // $data['customerlist'] = $this->admin_model->GetCustomerLists();
    $data["title"] = "All Users";
      $tmpl = array('table_open' => '<table class="sortable sorting disabled" id="customer_view" style="margin-top:0px;">');
      $this->table->set_template($tmpl);
      $this->table->set_heading('S No', 'Name', 'Email Address', 'Phone Number', 'Status', 'Joining Date', 'Action');
    $this->load->view("layout/header_script",$data);
    $this->load->view("layout/header",$data);
    $this->load->view("allusers_view",$data);
    $this->load->view("layout/footer");
    $this->load->view("layout/footer_script");
  } elseif($this->session->userdata("super_in") || $this->session->userdata("super_in")) {
    redirect(base_url());
  } else {
    $data["title"] = "Login";
    $this->load->view("layout/header_script", $data);
    $this->load->view("login_view");
    $this->load->view("layout/footer_script");
  }
  
}

  public function alladminuserlist()
  {
    $postData = $this->input->post();
    $ret =  $this->admin_model->alladminuserlist($postData);
    echo $ret;
  }
  



  public function getsinglecustomer()
  {
    $f_id = isset($_POST['f_id']) ? $_POST['f_id'] : '';
    $res = $this->admin_model->getsinglecustomerdetails($f_id);
    $arr["result"] = $res;
    echo json_encode($arr);
  }



public function DeleteUser()
	{
		$deleteid = isset($_POST['deleteid'])?$_POST['deleteid']:'';
		$result = $this->admin_model->DeleteById($deleteid);
		echo json_encode($result);
	}


  public function UpdateUser()
  {
    $deleteid = isset($_POST['updateid']) ? $_POST['updateid'] : '';
    $sid = isset($_POST['sid']) ? $_POST['sid'] : '';
    $result = $this->admin_model->UpdateById($deleteid, $sid);
    echo json_encode($result);
  }


  public function get_customerview()
  {
    $view_id = isset($_POST['view_id']) ? $_POST['view_id'] : '';
    $res = $this->admin_model->get_customerview_details($view_id);
    echo json_encode($res);
    
    
  }


  public function newuser()
  {
    $this->form_validation->set_rules("username", "User Name", "trim|required|min_length[3]|max_length[20]");
    $this->form_validation->set_rules("c_email", "User Email", "trim|required|valid_email|max_length[25]|is_unique[ap_users.email]");
    $this->form_validation->set_rules("c_phone", "User Phone", "trim|required|numeric|min_length[10]|max_length[15]|is_unique[ap_users.phone]");
    $this->form_validation->set_rules("password", "User Password", "trim|required|min_length[6]|max_length[25]");
    $this->form_validation->set_error_delimiters('<p class="alert alert-danger alert-dismissible">', '<button type="button" class="btn-close" data-bs-dismiss="alert"></button></p>');
    if ($this->form_validation->run() === FALSE) {
     $errors = validation_errors();
      $this->session->set_flashdata('form_error', $errors);
      $this->session->set_flashdata('username', $this->input->post('username', true));
      $this->session->set_flashdata('c_email', $this->input->post('c_email', true));
      $this->session->set_flashdata('c_phone', $this->input->post('c_phone', true));
      $this->session->set_flashdata('password', $this->input->post('password', true));

      redirect(base_url("allusers"));
    } else {
      $passkey = $this->config->item('passkey');
      date_default_timezone_set("Asia/Calcutta");
      $c_user_id = $this->session->userdata("user_id");
      $c_admin_id = $this->session->userdata("admin_id");
      $c_superadmin_id = $this->session->userdata("superadmin_id");
      $c_date = date('Y-m-j H:i:s');
      $c_name = $this->input->post("username", true);
      $c_email = $this->input->post("c_email", true);
      $c_phone = $this->input->post("c_phone", true);
      $c_password = sha1($passkey . $this->input->post("password", true));
      $c_orgpassword = $this->input->post("password", true);
      $res = $this->admin_model->add_user($c_user_id, $c_admin_id, $c_superadmin_id, $c_date, $c_name, $c_email, $c_phone, $c_password, $c_orgpassword);


      if ($res[0] === "success") {
        $this->session->set_flashdata('success', '<p class="alert alert-success alert-dismissible">Added Successfully<button type="button" class="btn-close" data-bs-dismiss="alert"></button></p>');
        redirect(base_url("allusers"));
      } else {
    $this->session->set_flashdata('notadded', '<p class="alert alert-danger alert-dismissible">Not Added !<button type="button" class="btn-close" data-bs-dismiss="alert"></button></p>');
        redirect(base_url("allusers"));
      }
    }
  }


  public function editcustomerbyid()
  {
    $viewid = isset($_POST['u_id']) ? $_POST['u_id'] : '';
    $this->form_validation->set_rules("u_username", "User Name", "trim|required|min_length[3]|max_length[20]");
    
    $this->form_validation->set_rules("u_password", "User Password", "trim|required|min_length[6]|max_length[25]");
    $this->form_validation->set_error_delimiters('<p class="alert alert-danger alert-dismissible">', '<button type="button" class="btn-close" data-bs-dismiss="alert"></button></p>');
    if ($this->form_validation->run() === FALSE) {
     $errors = validation_errors();
      $this->session->set_flashdata('e_form_error', $errors);
      $this->session->set_flashdata('u_username', $this->input->post('u_username', true));
      $this->session->set_flashdata('u_password', $this->input->post('u_password', true));
      $this->session->set_flashdata('u_id', $this->input->post('u_id', true));

      redirect(base_url("allusers"));
    } else {
      $viewid = isset($_POST['u_id']) ? $_POST['u_id'] : '';
      $passkey = $this->config->item('passkey');
      $c_name = $this->input->post("u_username", true);
      $c_password = sha1($passkey . $this->input->post("u_password", true));
      $c_orgpassword = $this->input->post("u_password", true);
      $res = $this->admin_model->update_user($c_name, $c_password, $viewid, $c_orgpassword);
      if ($res[0] === "success") {
        $this->session->set_flashdata('esuccess', '<p class="alert alert-success alert-dismissible">Added Successfully<button type="button" class="btn-close" data-bs-dismiss="alert"></button></p>');
        redirect(base_url("allusers"));
      } else {
        $this->session->set_flashdata('enotadded', '<p class="alert alert-danger alert-dismissible">Not Added !<button type="button" class="btn-close" data-bs-dismiss="alert"></button></p>');
        redirect(base_url("allusers"));
      }
    }
  }



}
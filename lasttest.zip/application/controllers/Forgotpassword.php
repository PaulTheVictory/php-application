<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Forgotpassword extends CI_Controller
{

  function __construct()
  {
    parent::__construct();
    $this->load->model('Login_Model', 'login_model', TRUE);
    $this->load->helper('form');
    $this->load->library('form_validation');
    $this->load->library("user_agent");
  }



  public function index()
  {
    
      $data["title"] = "Forgot Password";
      $this->load->view("layout/header_script", $data);
      $this->load->view("forgotpassword_view", $data);
      $this->load->view("layout/footer_script");
    
  }


  public function resetpassword() {

    $deleteid = isset($_POST['email_id']) ? $_POST['email_id'] : '';

    if($deleteid) {
      $result = $this->login_model->forgot_pass($deleteid);
      echo json_encode($result);
    }

  }


  

  
}

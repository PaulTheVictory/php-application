<?php

defined('BASEPATH') OR exit('No direct script access allowed');


class Adminreport extends CI_Controller  {
  function __construct()
  {
    parent::__construct();
    $this->load->model('Admin_Model', 'admin_model', TRUE);
    $this->load->model('Superadmin_Model', 'superadmin_model', TRUE);
    $this->load->model('Report_Model', 'report_model', TRUE);
    $this->load->helper('form');
    $this->load->library('form_validation');
    $this->load->library("user_agent");
  }
  


  public function index()
  {
    if ($this->session->userdata("admin_in")) {
      $data["title"] = "Admin Report";
      $data["companyuser"] = $this->report_model->get_company_user_one();
      $this->load->view("layout/report-header",$data);
      $this->load->view("layout/header",$data);
      $this->load->view("adminreport_view",$data);
      $this->load->view("layout/footer");
      $this->load->view("layout/report-footer");
    } elseif ($this->session->userdata("super_in") || $this->session->userdata("user_in")) {
      redirect(base_url());
    } else {
      $data["title"] = "Login";
      $this->load->view("layout/header_script", $data);
      $this->load->view("login_view");
      $this->load->view("layout/footer_script");
    }
    
  }


  public function admin_report_view() {
    $postData = $this->input->post();
    
    $res = $this->report_model->admin_report_list($postData);
    if($res) {
    echo json_encode($res);
    }
  }


















}
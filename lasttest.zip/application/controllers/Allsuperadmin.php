<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Allsuperadmin extends CI_Controller
{
  function __construct()
  {
    parent::__construct();
    $this->load->model('Superadmin_Model', 'superadmin_model', TRUE);
    $this->load->helper('form');
    $this->load->library('table');
    $this->load->library('form_validation');
  }

  public function index()
  {
    if ($this->session->userdata("super_in")) {
      $data["title"] = "All Superadmin";
      // $data['allsuperadmin'] = $this->superadmin_model->GetSuperAdminLists();
      $tmpl = array('table_open' => '<table class="sortable sorting disabled" id="customer_view" style="margin-top:0px;">');
      $this->table->set_template($tmpl);
      $this->table->set_heading('S No', 'Username', 'Email Address', 'Phone Number', 'Status','Joining Date', 'Action');
      $this->load->view("layout/header_script", $data);
      $this->load->view("layout/header", $data);
      $this->load->view("allsuperadmin_view", $data);
      $this->load->view("layout/footer");
      $this->load->view("layout/footer_script");
    } elseif ($this->session->userdata("admin_in") || $this->session->userdata("user_in")) {
      redirect(base_url());
    } else {
      $data["title"] = "Login";
      $this->load->view("layout/header_script", $data);
      $this->load->view("login_view");
      $this->load->view("layout/footer_script");
    }
  }


  public function allsuperadminlistname()
  {
    $ret =  $this->superadmin_model->allsuperadminlistname();
    echo $ret;
  }



public function newsuperadmin()
{
  $this->form_validation->set_rules("username", "User Name", "trim|required|min_length[3]|max_length[20]");
  $this->form_validation->set_rules("s_email", "Email Address", "trim|required|valid_email|max_length[25]|is_unique[ap_users.email]");
    $this->form_validation->set_rules("s_phone", "Phone Number", "trim|required|min_length[10]|max_length[15]|is_unique[ap_users.phone]");
  $this->form_validation->set_rules("password", "Password", "trim|required|min_length[6]|max_length[25]");
  $this->form_validation->set_error_delimiters('<p class="alert alert-danger alert-dismissible">', '<button type="button" class="btn-close" data-bs-dismiss="alert"></button></p>');
  if ($this->form_validation->run() === FALSE) {
     $errors = validation_errors();
     $this->session->set_flashdata('username', $this->input->post('username', true));
     $this->session->set_flashdata('s_email', $this->input->post('s_email', true));
     $this->session->set_flashdata('s_phone', $this->input->post('s_phone', true));
     $this->session->set_flashdata('password', $this->input->post('password', true));
      $this->session->set_flashdata('form_error', $errors);

      redirect(base_url("allsuperadmin"));
  } else {
    $passkey = $this->config->item('passkey');
    date_default_timezone_set("Asia/Calcutta");
    $c_doneby = $this->session->userdata("user_id");
    $c_date = date('Y-m-j H:i:s');
    $c_name = $this->input->post("username", true);
    $c_phone = $this->input->post("s_phone", true);
    $c_email = $this->input->post("s_email", true);
    $c_password = sha1($passkey . $this->input->post("password", true));
    $c_orgpassword = $this->input->post("password", true);
    $res = $this->superadmin_model->add_super_admin($c_doneby,$c_date,$c_name,$c_phone,$c_email,$c_password,$c_orgpassword);


    if ($res[0] === "success") {
      $this->session->set_flashdata('success', '<p class="alert alert-success alert-dismissible">Added Successfully<button type="button" class="btn-close" data-bs-dismiss="alert"></button></p>');
      redirect(base_url("allsuperadmin"));
    } else {
      $this->session->set_flashdata('notadded', '<p class="alert alert-danger alert-dismissible">you are not authorized this action!<button type="button" class="btn-close" data-bs-dismiss="alert"></button></p>');
      $this->session->set_flashdata('username', $this->input->post('username', true));
     $this->session->set_flashdata('s_email', $this->input->post('s_email', true));
     $this->session->set_flashdata('s_phone', $this->input->post('s_phone', true));
     $this->session->set_flashdata('password', $this->input->post('password', true));
      redirect(base_url("allsuperadmin"));
    }
  }



}

//

public function UpdateSuperadmin()
{
  $deleteid = isset($_POST['updateid']) ? $_POST['updateid'] : '';
  $sid = isset($_POST['sid']) ? $_POST['sid'] : '';
  $result = $this->superadmin_model->UpdateSuperadminById($deleteid, $sid);
  echo json_encode($result);
}


//

public function DeleteSuperAdmin()
	{
		$deleteid = isset($_POST['deleteid'])?$_POST['deleteid']:'';
		$result = $this->superadmin_model->DeleteSuperAdminById($deleteid);
		echo json_encode($result);
	}

  public function getsinglesuperadmin()
  {
    $f_id = isset($_POST['f_id']) ? $_POST['f_id'] : '';
    $res = $this->superadmin_model->getsinglesuperdetails($f_id);
    $arr["result"] = $res;
    echo json_encode($arr);
  }

  //

  public function update_superadmin()
  {

$this->form_validation->set_rules("se_username", "User Name", "trim|required|min_length[3]|max_length[20]");
  $this->form_validation->set_rules("se_password", "User Password", "trim|required|min_length[6]|max_length[25]");
  $this->form_validation->set_error_delimiters('<p class="alert alert-danger alert-dismissible">', '<button type="button" class="btn-close" data-bs-dismiss="alert"></button></p>');
  if ($this->form_validation->run() === FALSE) {
    $errors = validation_errors();
      $this->session->set_flashdata('e_form_error', $errors);
      $this->session->set_flashdata('se_username', $this->input->post('se_username', true));
      $this->session->set_flashdata('se_password', $this->input->post('se_password', true));
      $this->session->set_flashdata('s_id', $this->input->post('s_id', true));

      redirect(base_url("allsuperadmin"));
  } else {
    $passkey = $this->config->item('passkey');
    $c_email = $this->input->post("se_username", true);
    $c_password = sha1($passkey . $this->input->post("se_password", true));
    $c_orgpassword = $this->input->post("se_password", true);
    $admin_id = $this->input->post("s_id", true);
    $res = $this->superadmin_model->update_super_admin($c_email, $c_password, $c_orgpassword,$admin_id);


    if ($res[0] === "success") {
      $this->session->set_flashdata('esuccess', '<p class="alert alert-success alert-dismissible">Updated Successfully<button type="button" class="btn-close" data-bs-dismiss="alert"></button></p>');
      redirect(base_url("allsuperadmin"));
    } else {
      $this->session->set_flashdata('enotadded', '<p class="alert alert-danger alert-dismissible">you are not authorized this action!<button type="button" class="btn-close" data-bs-dismiss="alert"></button></p>');
      $this->session->set_flashdata('se_username', $this->input->post('se_username', true));
      $this->session->set_flashdata('se_password', $this->input->post('se_password', true));
      $this->session->set_flashdata('s_id', $this->input->post('s_id', true));
      redirect(base_url("allsuperadmin"));
    }
  }



  }















}

<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Allfollowuplist extends CI_Controller {
  function __construct()
  {
    parent::__construct();
    $this->load->model('Admin_Model', 'admin_model', TRUE);
    $this->load->model('Superadmin_Model', 'superadmin_model', TRUE);
    $this->load->helper('form');
    $this->load->library('table');
    $this->load->library('form_validation');
  }

public function index()
{
  if ($this->session->userdata("super_in")) {
      // $data['followuplist'] = $this->superadmin_model->getallfollowup(); 
      $data["companyuser"] = $this->superadmin_model->get_company_user();
      $tmpl = array('table_open' => '<table class="sortable sorting disabled" id="customer_view" style="margin-top:0px;">');
      $this->table->set_template($tmpl);
      $this->table->set_heading('S No', 'Company Name', 'Logo', 'Project Name', 'Enquiry Name', 'Status', 'Next Follow Up','Action');
    $data["title"] = "Follow Up Progress";
    $this->load->view("layout/header_script",$data);
    $this->load->view("layout/header",$data);
    $this->load->view("allfollowuplist_view",$data);
    $this->load->view("layout/footer");
    $this->load->view("layout/footer_script");

  } elseif ($this->session->userdata("admin_in") || $this->session->userdata("user_in")) {
    redirect(base_url());

  }else {
    $data["title"] = "Login";
    $this->load->view("layout/header_script", $data);
    $this->load->view("login_view");
    $this->load->view("layout/footer_script");
  }
  
}

  public function alladminfollowuplist()
  {
    $postData = $this->input->post();
    $ret =  $this->superadmin_model->alladminfollowuplist($postData);
    echo $ret;
  }





public function getcustomerview_super()
  {
    $view_id = isset($_POST['view_id']) ? $_POST['view_id'] : '';
    $res = $this->superadmin_model->get_customerview_details_super($view_id);
    echo json_encode($res);
    
    
  }

public function getsinglefprocess()
{
  $f_id = isset($_POST['f_id'])?$_POST['f_id']:'';
  $res = $this->admin_model->getprocessdetails($f_id);
  $arr["result"] = $res;
  echo json_encode($arr);

  
}



}
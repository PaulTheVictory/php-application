<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Allcustomers extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('Superadmin_Model', 'superadmin_model', true);
        $this->load->helper('form');
        $this->load->library('table');
        $this->load->library('form_validation');
    }

    public function index()
    {
        if ($this->session->userdata('super_in')) {
            // $data['customerlist'] = $this->superadmin_model->GetCustomerLists();
            $tmpl = array('table_open' => '<table class="sortable sorting disabled" id="customer_view" style="margin-top:0px;">');
            $this->table->set_template($tmpl);
            $this->table->set_heading('S No', 'Company Name', 'Email Address', 'Phone Number', 'Logo', 'Status','Action');
            $data['title'] = 'All Customers';
            $this->load->view('layout/header_script', $data);
            $this->load->view('layout/header', $data);
            $this->load->view('allcustomers_view', $data);
            $this->load->view('layout/footer');
            $this->load->view('layout/footer_script');
        } elseif ($this->session->userdata('admin_in') || $this->session->userdata('user_in')) {
            redirect(base_url());
        } else {
            $data['title'] = 'Login';
            $this->load->view('layout/header_script', $data);
            $this->load->view('login_view');
            $this->load->view('layout/footer_script');
        }
    }


    public function alladminlistname()
    {
       $ret =  $this->superadmin_model->alladminlistname();
        echo $ret;
    }



    public function get_customer_table()
    {
        if ($this->session->userdata('super_in')) {
            $ret = $this->superadmin_model->GetCustomerTable();
            echo $ret;
        } else {
            redirect('login', 'refresh');
        }
    }

    public function get_customerview()
    {
        $view_id = isset($_POST['view_id']) ? $_POST['view_id'] : '';
        $res = $this->superadmin_model->get_customerview_details($view_id);
        echo json_encode($res);
    }

    public function delete_customer()
    {
        $deleteid = isset($_POST['deleteid']) ? $_POST['deleteid'] : '';
        $result = $this->superadmin_model->DeleteById($deleteid);
        echo json_encode($result);
    }

    public function status_update_customer()
    {
        $deleteid = isset($_POST['updateid']) ? $_POST['updateid'] : '';
        $sid = isset($_POST['sid']) ? $_POST['sid'] : '';
        $result = $this->superadmin_model->UpdateById($deleteid, $sid);
        echo json_encode($result);
    }

    public function newcustomer()
    {
        $this->form_validation->set_rules('username', 'Customer Name', 'trim|required|min_length[3]|max_length[20]');
        $this->form_validation->set_rules('company_name', 'Company Name', 'trim|required|min_length[3]|max_length[20]');
        $this->form_validation->set_rules('c_email', 'Customer Email Address', 'trim|required|valid_email|max_length[25]|is_unique[ap_users.email]');
        $this->form_validation->set_rules('c_phone', 'Customer Phone Number', 'trim|numeric|required|min_length[10]|max_length[15]|is_unique[ap_users.phone]');
        $this->form_validation->set_rules('password', 'Customer Password', 'trim|required|min_length[6]|max_length[25]');
        $this->form_validation->set_error_delimiters('<p class="alert alert-danger alert-dismissible">', '<button type="button" class="btn-close" data-bs-dismiss="alert"></button></p>');
        if ($this->form_validation->run() === false) {
            $errors = validation_errors();
            $this->session->set_flashdata('form_error', $errors);
            $this->session->set_flashdata('username', $this->input->post('username', true));
            $this->session->set_flashdata('company_name', $this->input->post('company_name', true));
            $this->session->set_flashdata('c_email', $this->input->post('c_email', true));
            $this->session->set_flashdata('c_phone', $this->input->post('c_phone', true));
            $this->session->set_flashdata('password', $this->input->post('password', true));
            redirect(base_url('allcustomers'));
        } else {
            $id = uniqid();
            $fileName = '';
            if (isset($_FILES['company_logo']) && !empty($_FILES['company_logo']['name'])) {
                $imageExtensions = ['.jpg', '.jpeg', '.png', '.pdf'];

                $file_size = $_FILES['company_logo']['size'];
                if ((number_format($file_size / 1048576, 2) > 5)) {
                    $this->session->set_flashdata('large', '<p class="alert alert-danger alert-dismissible">Customer logo file size please add below 2MB<button type="button" class="btn-close" data-bs-dismiss="alert"></button></p>');
                    $this->session->set_flashdata('username', $this->input->post('username', true));
                    $this->session->set_flashdata('company_name', $this->input->post('company_name', true));
                    $this->session->set_flashdata('c_email', $this->input->post('c_email', true));
                    $this->session->set_flashdata('c_phone', $this->input->post('c_phone', true));
                    $this->session->set_flashdata('password', $this->input->post('password', true));
                    redirect(base_url('allcustomers'), '');
                }
                $fileExtension = strrchr($_FILES['company_logo']['name'], '.');
                $fileName = $id . '' . $fileExtension;
                $dirname = './docs/customerlogo/';
                $destinationfull = $dirname . $fileName;
                if (in_array(strtolower($fileExtension), $imageExtensions)) {
                    $resultfull = move_uploaded_file($_FILES['company_logo']['tmp_name'], $destinationfull);

                    if ($resultfull) {
                        $passkey = $this->config->item('passkey');
                        date_default_timezone_set('Asia/Calcutta');
                        $c_user_id = $this->session->userdata('user_id');
                        $c_admin_id = $this->session->userdata('admin_id');
                        $c_superadmin_id = $this->session->userdata('superadmin_id');
                        $c_date = date('Y-m-j H:i:s');
                        $c_name = $this->input->post('username', true);
                        $c_cname = $this->input->post('company_name', true);
                        $c_email = $this->input->post('c_email', true);
                        $c_phone = $this->input->post('c_phone', true);
                        $c_password = sha1($passkey . $this->input->post('password', true));
                        $c_orgpassword = $this->input->post('password', true);
                        $c_image = $fileName;
                        $res = $this->superadmin_model->add_customer($c_user_id, $c_admin_id, $c_superadmin_id, $c_date, $c_name, $c_cname, $c_email, $c_phone, $c_password, $c_orgpassword, $c_image);

                        if ($res[0] === 'success') {
                            $this->session->set_flashdata('success', '<p class="alert alert-success alert-dismissible">Added Successfully<button type="button" class="btn-close" data-bs-dismiss="alert"></button></p>');

                            redirect(base_url('allcustomers'));
                        } else {
                            $this->session->set_flashdata('notadded', '<p class="alert alert-danger alert-dismissible">Not Added !<button type="button" class="btn-close" data-bs-dismiss="alert"></button></p>');
                            $this->session->set_flashdata('username', $this->input->post('username', true));
                            $this->session->set_flashdata('company_name', $this->input->post('company_name', true));
                            $this->session->set_flashdata('c_email', $this->input->post('c_email', true));
                            $this->session->set_flashdata('c_phone', $this->input->post('c_phone', true));
                            $this->session->set_flashdata('password', $this->input->post('password', true));
                            redirect(base_url('allcustomers'));
                        }
                    } else {
                        $this->session->set_flashdata('finalexit', '<p class="alert alert-danger alert-dismissible">Logo is required<button type="button" class="btn-close" data-bs-dismiss="alert"></button></p>');
                        $this->session->set_flashdata('username', $this->input->post('username', true));
                        $this->session->set_flashdata('company_name', $this->input->post('company_name', true));
                        $this->session->set_flashdata('c_email', $this->input->post('c_email', true));
                        $this->session->set_flashdata('c_phone', $this->input->post('c_phone', true));
                        $this->session->set_flashdata('password', $this->input->post('password', true));
                        redirect(base_url('allcustomers'));
                    }
                } else {
                    $this->session->set_flashdata('finalexit', '<p class="alert alert-danger alert-dismissible">Image Upload failed<button type="button" class="btn-close" data-bs-dismiss="alert"></button></p>');
                    $this->session->set_flashdata('username', $this->input->post('username', true));
                    $this->session->set_flashdata('company_name', $this->input->post('company_name', true));
                    $this->session->set_flashdata('c_email', $this->input->post('c_email', true));
                    $this->session->set_flashdata('c_phone', $this->input->post('c_phone', true));
                    $this->session->set_flashdata('password', $this->input->post('password', true));
                    redirect(base_url('allcustomers'));
                }
            } else {
                $this->session->set_flashdata('username', $this->input->post('username', true));
                $this->session->set_flashdata('company_name', $this->input->post('company_name', true));
                $this->session->set_flashdata('c_email', $this->input->post('c_email', true));
                $this->session->set_flashdata('c_phone', $this->input->post('c_phone', true));
                $this->session->set_flashdata('password', $this->input->post('password', true));
                $this->session->set_flashdata('finalexit', '<p class="alert alert-danger alert-dismissible">Image Upload failed<button type="button" class="btn-close" data-bs-dismiss="alert"></button></p>');
                redirect(base_url('allcustomers'));
            }
        }
    }

    public function getsinglecustomer()
    {
        $f_id = isset($_POST['f_id']) ? $_POST['f_id'] : '';
        $res = $this->superadmin_model->getsinglecustomerdetails($f_id);
        $arr['result'] = $res;
        echo json_encode($arr);
    }

    public function editcustomerbyid()
    {
        $viewid = isset($_POST['u_id']) ? $_POST['u_id'] : '';
        $this->form_validation->set_rules('e_username', 'Customer Name', 'trim|required|min_length[3]|max_length[20]');
        $this->form_validation->set_rules('e_password', 'Customer Password', 'trim|required|min_length[6]|max_length[25]');
        $this->form_validation->set_error_delimiters('<p class="alert alert-danger alert-dismissible">', '<button type="button" class="btn-close" data-bs-dismiss="alert"></button></p>');
        if ($this->form_validation->run() === false) {
            $errors = validation_errors();
            $this->session->set_flashdata('e_username', $this->input->post('e_username', true));
            $this->session->set_flashdata('e_password', $this->input->post('e_password', true));
            $this->session->set_flashdata('u_id', $this->input->post('u_id', true));
            $this->session->set_flashdata('e_form_error', $errors);

            redirect(base_url('allcustomers'));
        } else {
            $id = uniqid();
            $fileName = '';
            if (isset($_FILES['company_logo']) && !empty($_FILES['company_logo']['name'])) {
                $imageExtensions = ['.jpg', '.jpeg', '.png', '.pdf'];

                $file_size = $_FILES['company_logo']['size'];
                if ((number_format($file_size / 1048576, 2) > 5)) {
                    $this->session->set_flashdata('elarge', '<p class="alert alert-danger alert-dismissible">Customer logo file size please add below 2MB<button type="button" class="btn-close" data-bs-dismiss="alert"></button></p>');
                    redirect(base_url('allcustomers'));
                }
                $fileExtension = strrchr($_FILES['company_logo']['name'], '.');
                $fileName = $id . '' . $fileExtension;
                $dirname = './docs/customerlogo/';
                $destinationfull = $dirname . $fileName;
                if (in_array(strtolower($fileExtension), $imageExtensions)) {
                    $resultfull = move_uploaded_file($_FILES['company_logo']['tmp_name'], $destinationfull);

                    if ($resultfull) {
                        $passkey = $this->config->item('passkey');
                        $c_name = $this->input->post('e_username', true);
                        $c_password = sha1($passkey . $this->input->post('e_password', true));
                        $c_orgpassword = $this->input->post('e_password', true);
                        $c_image = $fileName;
                        $res = $this->superadmin_model->update_customer($c_name, $c_password, $c_image, $viewid, $c_orgpassword);

                        if ($res[0] === 'success') {
                            $this->session->set_flashdata('esuccess', '<p class="alert alert-success alert-dismissible">Updated Successfully<button type="button" class="btn-close" data-bs-dismiss="alert"></button></p>');
                            redirect(base_url('allcustomers'));
                        } else {
                            $this->session->set_flashdata('enotadded', '<p class="alert alert-danger alert-dismissible">Not Updated !<button type="button" class="btn-close" data-bs-dismiss="alert"></button></p>');
                            $this->session->set_flashdata('e_username', $this->input->post('e_username', true));
                            $this->session->set_flashdata('e_password', $this->input->post('e_password', true));
                            $this->session->set_flashdata('u_id', $this->input->post('u_id', true));
                            redirect(base_url('allcustomers'), '');
                        }
                    } else {
                        $this->session->set_flashdata('efinalexit', '<p class="alert alert-danger alert-dismissible">Image Upload failed<button type="button" class="btn-close" data-bs-dismiss="alert"></button></p>');
                        $this->session->set_flashdata('e_username', $this->input->post('e_username', true));
                        $this->session->set_flashdata('e_password', $this->input->post('e_password', true));
                        $this->session->set_flashdata('u_id', $this->input->post('u_id', true));
                        redirect(base_url('allcustomers'), '');
                    }
                } else {
                    $this->session->set_flashdata('efinalexit', '<p class="alert alert-danger alert-dismissible">Image Upload failed<button type="button" class="btn-close" data-bs-dismiss="alert"></button></p>');
                    $this->session->set_flashdata('e_username', $this->input->post('e_username', true));
                    $this->session->set_flashdata('e_password', $this->input->post('e_password', true));
                    $this->session->set_flashdata('u_id', $this->input->post('u_id', true));
                    redirect(base_url('allcustomers'), '');
                }
            } else {
                $viewid = isset($_POST['u_id']) ? $_POST['u_id'] : '';
                $passkey = $this->config->item('passkey');
                $c_name = $this->input->post('e_username', true);
                $c_password = sha1($passkey . $this->input->post('e_password', true));
                $c_orgpassword = $this->input->post('e_password', true);
                $res = $this->superadmin_model->updatenoimage_customer($c_name, $c_password, $viewid, $c_orgpassword);
                if ($res[0] === 'success') {
                    $this->session->set_flashdata('esuccess', '<p class="alert alert-success alert-dismissible">Updated Successfully<button type="button" class="btn-close" data-bs-dismiss="alert"></button></p>');
                    redirect(base_url('allcustomers'));
                } else {
                    $this->session->set_flashdata('enotadded', '<p class="alert alert-danger alert-dismissible">Not Added !<button type="button" class="btn-close" data-bs-dismiss="alert"></button></p>');
                    $this->session->set_flashdata('e_username', $this->input->post('e_username', true));
                    $this->session->set_flashdata('e_password', $this->input->post('e_password', true));
                    $this->session->set_flashdata('u_id', $this->input->post('u_id', true));
                    redirect(base_url('allcustomers'));
                }
            }
        }
    }
}

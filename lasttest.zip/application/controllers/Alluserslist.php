<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Alluserslist extends CI_Controller {
  function __construct()
  {
    parent::__construct();
    $this->load->model('Superadmin_Model', 'superadmin_model', TRUE);
    $this->load->helper('form');
    $this->load->library('table');
    $this->load->library('form_validation');
  }

public function index()
{
  if ($this->session->userdata("super_in")) {
      // $data['customerlist'] = $this->superadmin_model->GetCustomerListsSuper();
      $tmpl = array('table_open' => '<table class="sortable sorting disabled" id="customer_view" style="margin-top:0px;">');
      $this->table->set_template($tmpl);
      $this->table->set_heading('S No', 'Company Name', 'Logo', 'Done By', 'Username', 'Email Address', 'Phone Number', 'Status', 'Joining Date');
    $data["title"] = "All Users";
    $this->load->view("layout/header_script",$data);
    $this->load->view("layout/header",$data);
    $this->load->view("alluserslist_view",$data);
    $this->load->view("layout/footer");
    $this->load->view("layout/footer_script");
  } elseif($this->session->userdata("admin_in") || $this->session->userdata("super_in")) {
    redirect(base_url());
  } else {
    $data["title"] = "Login";
    $this->load->view("layout/header_script", $data);
    $this->load->view("login_view");
    $this->load->view("layout/footer_script");
  }
  
}

  public function alladminuserlistname()
  {
    $ret =  $this->superadmin_model->alladminuserlistname();
    echo $ret;
  }



}
<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Allactions extends CI_Controller
{
  function __construct()
  {
    parent::__construct();
    $this->load->model('Superadmin_Model', 'superadmin_model', TRUE);
    $this->load->library('table');
  }

  public function index()
  {
    if ($this->session->userdata("super_in")) {
      $data["title"] = "All Logs";
      // $data['alllogs'] = $this->superadmin_model->GetActionLogLists();
      $tmpl = array('table_open' => '<table class="sortable sorting disabled" id="customer_view" style="margin-top:0px;">');
      $this->table->set_template($tmpl);
      $this->table->set_heading('S No', 'Done By', 'Action Type', 'Module Id', 'Module Name', 'Created');
      $this->load->view("layout/header_script", $data);
      $this->load->view("layout/header", $data);
      $this->load->view("allaction_view", $data);
      $this->load->view("layout/footer");
      $this->load->view("layout/footer_script");
    } elseif ($this->session->userdata("admin_in") || $this->session->userdata("user_in")) {
      redirect(base_url());
    } else {
      $data["title"] = "Login";
      $this->load->view("layout/header_script", $data);
      $this->load->view("login_view");
      $this->load->view("layout/footer_script");
    }
  }


  public function alladminreportaction()
  {
    $ret =  $this->superadmin_model->alladminreportaction();
    echo $ret;
  }


}

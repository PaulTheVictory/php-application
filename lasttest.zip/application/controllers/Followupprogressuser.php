<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Followupprogressuser extends CI_Controller {
  function __construct()
  {
    parent::__construct();
    $this->load->model('Admin_Model', 'admin_model', TRUE);
    $this->load->model('Superadmin_Model', 'superadmin_model', TRUE);
    $this->load->model('User_Model', 'user_model', TRUE);
    $this->load->helper('form');
    $this->load->library('form_validation');
    $this->load->library("user_agent");
  }

public function index()
{
  if ($this->session->userdata("user_in")) {
    $data['followuplist'] = $this->user_model->getallfollowup(); 
    $data["title"] = "Follow Up Progress";
    $this->load->view("layout/header_script",$data);
    $this->load->view("layout/header",$data);
    $this->load->view("followupprogressuser_view",$data);
    $this->load->view("layout/footer");
    $this->load->view("layout/footer_script");
  } elseif ($this->session->userdata("admin_in") || $this->session->userdata("super_in")) {
    redirect(base_url()); 
 }else {
    $data["title"] = "Login";
    $this->load->view("layout/header_script", $data);
    $this->load->view("login_view");
    $this->load->view("layout/footer_script");
  }
  
}




public function add_followup_process_update()
{
    $this->form_validation->set_rules("follow_up_msg", "Follow up message", "trim|required|min_length[3]|max_length[200]");
    $this->form_validation->set_rules("follow_up_status", "Follow up status", "trim|required");
    $this->form_validation->set_rules("nxt_follow_up_date", "Follow up date", "trim|required");
    $this->form_validation->set_rules("nxt_follow_up_hint", "Follow up date", "max_length[200]");
    $this->form_validation->set_error_delimiters('<p class="alert alert-danger alert-dismissible">', '<button type="button" class="btn-close" data-bs-dismiss="alert"></button></p>');
    if ($this->form_validation->run() === FALSE) {
      $errors = validation_errors();
      $this->session->set_flashdata('fo_form_error', $errors);
      $this->session->set_flashdata('follow_up_msg', $this->input->post('follow_up_msg', true));
      $this->session->set_flashdata('follow_up_status', $this->input->post('follow_up_status', true));
      $this->session->set_flashdata('nxt_follow_up_date', $this->input->post('nxt_follow_up_date', true));
      $this->session->set_flashdata('nxt_follow_up_hint', $this->input->post('nxt_follow_up_hint', true));
      $this->session->set_flashdata('this_id', $this->input->post('this_id', true));
      redirect(base_url("followupprogressuser"));
    } else {
      $f_msg = $this->input->post("follow_up_msg",true);
      $f_status = $this->input->post("follow_up_status",true);
      $f_date = $this->input->post("nxt_follow_up_date",true);
      $f_msghint = $this->input->post("nxt_follow_up_hint",true);
      $this_id = $this->input->post("this_id");

      $res = $this->user_model->updatenew_followup($f_msg,$f_status,$f_date,$f_msghint,$this_id);

      if($res[0]==="success") {
        $this->session->set_flashdata('fosuccess', '<p class="alert alert-success alert-dismissible">Added Successfully<button type="button" class="btn-close" data-bs-dismiss="alert"></button></p>');
        redirect(base_url("followupprogressuser"));
      } else {
       $this->session->set_flashdata('fonotupdated', '<p class="alert alert-danger alert-dismissible">Not Updated!<button type="button" class="btn-close" data-bs-dismiss="alert"></button></p>');
       $this->session->set_flashdata('follow_up_msg', $this->input->post('follow_up_msg', true));
      $this->session->set_flashdata('follow_up_status', $this->input->post('follow_up_status', true));
      $this->session->set_flashdata('nxt_follow_up_date', $this->input->post('nxt_follow_up_date', true));
      $this->session->set_flashdata('nxt_follow_up_hint', $this->input->post('nxt_follow_up_hint', true));
      $this->session->set_flashdata('this_id', $this->input->post('this_id', true));
       redirect(base_url("followupprogressuser"));
      }




    }






}



public function getcustomerview()
  {
    $view_id = isset($_POST['view_id']) ? $_POST['view_id'] : '';
    $res = $this->user_model->get_customerview_details($view_id);
    echo json_encode($res);
    
    
  }



public function getsinglefprocess()
{
  $f_id = isset($_POST['f_id'])?$_POST['f_id']:'';
  $res = $this->user_model->getprocessdetails($f_id);
  $arr["result"] = $res;
  echo json_encode($arr);

  
}


public function getsingleflogs()
{
  $f_id = isset($_POST['f_id'])?$_POST['f_id']:'';
  $res = $this->user_model->getprocessdetailslogs($f_id);
  $arr["result"] = $res;
  echo json_encode($arr);

  
}



public function add_followup_process_update_log()
{
    $this->form_validation->set_rules("follow_up_msg", "Follow up message", "trim|required|min_length[3]|max_length[200]");
    $this->form_validation->set_rules("follow_up_status", "Follow up status", "trim|required");
    $this->form_validation->set_rules("nxt_follow_up_date", "Follow up date", "trim|required");
    $this->form_validation->set_rules("nxt_follow_up_hint", "Follow up date", "max_length[200]");
    $this->form_validation->set_error_delimiters('<p class="alert alert-danger alert-dismissible">', '<button type="button" class="btn-close" data-bs-dismiss="alert"></button></p>');
    if ($this->form_validation->run() === FALSE) {
      $errors = validation_errors();
      $this->session->set_flashdata('la_form_error', $errors);
      $this->session->set_flashdata('follow_up_msg', $this->input->post('follow_up_msg', true));
      $this->session->set_flashdata('follow_up_status', $this->input->post('follow_up_status', true));
      $this->session->set_flashdata('nxt_follow_up_date', $this->input->post('nxt_follow_up_date', true));
      $this->session->set_flashdata('nxt_follow_up_hint', $this->input->post('nxt_follow_up_hint', true));
      $this->session->set_flashdata('follow_up_id', $this->input->post('follow_up_id', true));
      $this->session->set_flashdata('follow_up_log_id', $this->input->post('follow_up_log_id', true));
      redirect(base_url("followupprogressuser"));
    } else {
      $f_msg = $this->input->post("follow_up_msg",true);
      $f_status = $this->input->post("follow_up_status",true);
      $f_date = $this->input->post("nxt_follow_up_date",true);
      $f_msghint = $this->input->post("nxt_follow_up_hint",true);
      $follow_up_id = $this->input->post("follow_up_id");
      $follow_up_log_id = $this->input->post("follow_up_log_id");

      $res = $this->user_model->updatenew_followup_log($f_msg,$f_status,$f_date,$f_msghint,$follow_up_id,$follow_up_log_id);

      if($res[0]==="success") {
        $this->session->set_flashdata('lasuccess', '<p class="alert alert-success alert-dismissible">Added Successfully<button type="button" class="btn-close" data-bs-dismiss="alert"></button></p>');
        redirect(base_url("followupprogressuser"));
      } else {
        $this->session->set_flashdata('lanotupdated', '<p class="alert alert-danger alert-dismissible">Not Updated!<button type="button" class="btn-close" data-bs-dismiss="alert"></button></p>');
        $this->session->set_flashdata('follow_up_msg', $this->input->post('follow_up_msg', true));
      $this->session->set_flashdata('follow_up_status', $this->input->post('follow_up_status', true));
      $this->session->set_flashdata('nxt_follow_up_date', $this->input->post('nxt_follow_up_date', true));
      $this->session->set_flashdata('nxt_follow_up_hint', $this->input->post('nxt_follow_up_hint', true));
      $this->session->set_flashdata('follow_up_id', $this->input->post('follow_up_id', true));
      $this->session->set_flashdata('follow_up_log_id', $this->input->post('follow_up_log_id', true));
         redirect(base_url("followupprogressuser"));
      }




    }






}



























}
<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Excel_Model extends CI_Model {

  function insert($fetchData,$data2,$data1,$data3,$data4)
	{
    // print_r($data);
    // exit;
		$res = $this->db->insert_batch('ap_enquiry', $fetchData);
		$res1 = $this->db->insert_batch('ap_followup_progress', $data2);
		$res2 = $this->db->insert_batch('ap_action', $data1);
		$res3 = $this->db->insert_batch('ap_action', $data3);
		$res4 = $this->db->insert_batch('ap_projects', $data4);
    if($res && $res1 && $res2 && $res3 && $res4) {
      return true;
    } else {
      return false;
    }

	}













}
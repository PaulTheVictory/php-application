<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Test_Model extends CI_Model
{
  public function __construct()
  {
    parent::__construct();
    $this->load->database();
    $this->load->library('email');
    $this->load->library('Datatables');
    date_default_timezone_set("Asia/Calcutta");
  }

  
  public function alladminreport($postData = null)
  {
    if($postData['statusFilter']=="pending") {
    $statusFilter = "pending";
    } elseif($postData['statusFilter'] == "followup") {
      $statusFilter = "followup";
    } elseif ($postData['statusFilter'] == "cancel") {
      $statusFilter = "cancel";
    } elseif ($postData['statusFilter'] == "rejected") {
      $statusFilter = "rejected";
    } elseif ($postData['statusFilter'] == "noresponse") {
      $statusFilter = "noresponse";
    } elseif ($postData['statusFilter'] == "completed") {
      $statusFilter = "completed";
    } else {
      $statusFilter = "";
    }
    if($doneBy = $postData['doneBy']!="") {
      $doneBy = $postData['doneBy'];
    } else {
      $doneBy = "";
    }
    $startDate = $postData['startDate'];
    $endDate = $postData['endDate'];
    if($startDate!="" && $endDate!="") {
      $startDate = $startDate;
      $endDate   = $endDate;
    } else {
      $startDate= "";
      $endDate="";
    }
    

    $table = $this->datatables->select('f.follow_up_id as f_follow_up_id,f.enquiry_id as f_enquiry_id,f.admin_id as f_admin_id,f.superadmin_id as f_superadmin_id,f.follow_up_msg as f_follow_up_msg,f.project_id as f_project_id,f.follow_up_status as f_follow_up_status,f.nxt_follow_up_date as f_nxt_follow_up_date,f.nxt_follow_up_hint as f_nxt_follow_up_hint,f.done_by as f_done_by,f.created as f_created')
      ->from('ap_followup_progress as f')
      ->select('e.enquiry_id as e_enquiry_id,e.enq_name as e_enq_name,e.enq_contact_number as e_enq_contact_number,e.enq_date as e_enq_date,e.enq_location as e_enq_location,e.enq_msg as e_enq_msg,e.project_id as e_project_id,e.enq_status as e_enq_status')
      ->join("ap_enquiry as e","e.enquiry_id=f.enquiry_id")
      ->select('u.username as u_username,u.user_id as u_user_id,u.admin_id as u_admin_id')
      ->join("ap_users as u",'u.user_id=f.done_by')
      ->where("f.follow_up_status ".($statusFilter!="" ? "" : "<>")."", $statusFilter)
      ->where("f.done_by " . ($doneBy != "" ? "" : "<>") . "", $doneBy)
      ->where("DATE(f.created) " . ($startDate != "" ? ">=" : "<>") . "", $startDate)
      ->where("DATE(f.created) " . ($endDate != "" ? "<=" : "<>") . "", $endDate)
      ->where("f.done_by",$this->session->userdata("user_id"))
      ->edit_column('pro_name','$1','f_project_id')
      ->edit_column('action', '<div class="action_btn new_btn">
      <button class="view_followup $1" type="button" data-uid="$1"><i class="fa fa-eye text-primary"></i>  </button>
      <button class="edit_followup" type="button" data-uid="$2"><i class="fa fa-edit text-success"></i>  </button>
      <button class="notify_followup" type="button" data-fid="$2" data-aid="'.$this->session->userdata("user_id").'" data-eid="$1" data-status="$3"><i class="fa fa-bell text-danger"></i>  </button>
       </div>', 'e_enquiry_id,f_follow_up_id,f_follow_up_status')
      ->generate();
    
    return $table;





  }

  public function get_company_user_one()
  {

    $query = $this->db->query('select user_id,username from ap_users where (role="user" or role="admin" and status=1 and admin_id="' . $this->session->userdata('user_id') . '") or user_id="'. $this->session->userdata('user_id').'"');
    return $query->result();
  }















}
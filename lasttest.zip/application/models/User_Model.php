<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User_Model extends CI_Model {

  public function __construct()
  {
    parent::__construct();
    $this->load->database();
    $this->load->library('email');
    $this->load->library('Datatables');
  }


  //all enquiry

  public function getallfollowup()
  {


    $arr = array();
    $arr['flist'] = '<table id="customer_view" class="display dataTable">';
    $c_user = $this->session->userdata("admin_id");
    $this->db->select("*");
    $this->db->from("ap_enquiry as e");
    $this->db->join("ap_followup_progress as f", 'f.enquiry_id=e.enquiry_id');
    $this->db->join("ap_users as u","u.user_id=e.done_by");
    $this->db->where('e.admin_id="'. $c_user.'"');
    // $this->db->order_by("f.created","DESC");
    $query = $this->db->get();
    $row = $query->result_array();

   $arr['flist'] .= '
<thead>
<tr>
<th>S No</th>
<th>Created By</th>
<th>Project Name</th>
<th>Enquiry Name</th>
<th>Contact Number</th>
<th>Status</th>
<th>Next Follow Up</th>
<th>Action</th>
</thead>';
    $arr['flist_count'] = count($row);
    if ($row) {
     
      $arr['flist'] .= '<tbody>';
      for ($i = 0; $i < count($row); $i++) {
        $fid = $row[$i]['follow_up_id'];
        $enid = $row[$i]['enquiry_id'];
        $username = $row[$i]['username'];
        $f_proname = explode("|", $row[$i]['project_id'])[1];
        $f_enqname = $row[$i]['enq_name'];
        $f_contact = $row[$i]['enq_contact_number'];
        $f_status = $row[$i]['follow_up_status'];
        $fdate = date_create($row[$i]['nxt_follow_up_date']);
       

        if ($f_status === "pending" | $f_status === "followup") {
          $bclass = "primary_status";
        } elseif ($f_status === "cancel" | $f_status === "rejected" | $f_status === "noresponse") {
          $bclass = "danger_status";
        } elseif ($f_status === "completed") {
          $bclass = "success_status";
        }



        $arr['flist'] .= '
  <tr>
  <td>' . ($i+1) . '</td>
  <td>' . $username . '</td>
  <td>' . $f_proname . '</td>
  <td>' . $f_enqname . '</td>
  <td>' . $f_contact . '</td>
  <td><button class="' . $bclass . '">' . $f_status . '</button></td>
  <td>' . date_format($fdate,"d-M-Y h:i:s") . '</td>
  
  <td>
  <div class="action_btn">
  <button class="btn btn-sm btn-primary view_followup ' . $enid . '" type="submit" data-uid="' . $enid . '"><i class="fa fa-eye"></i>  </button>
  <button class="btn btn-sm btn-success edit_followup" type="submit" data-uid="' . $fid . '"><i class="fa fa-edit"></i>  </button>
  </div>
      </td></tr>';
      }
    } else {
      $arr['flist'] .= '<tbody>';
    }
    $arr['flist'] .= '</tbody></table>';
    return $arr;
  }

  





//view usetomer

public function get_customerview_details($view_id) {

  // return printf("163b2e34e0930c");
  
  $result="";
  $this->db->select("*");
  $this->db->from("ap_followup_progress");
  $this->db->join("ap_enquiry", 'ap_followup_progress.enquiry_id=ap_enquiry.enquiry_id');
  $this->db->where('ap_enquiry.enquiry_id="'.$view_id.'"');
  $query = $this->db->get();

  $row = $query->result_array();

  $this->db->select("*");
    $this->db->from("ap_followup_logs as l");
    $this->db->select("user_id,username")->join("ap_users as u","u.user_id=l.done_by_log");
    $this->db->where("l.follow_up_id",$row[0]["follow_up_id"])->where("l.status",1);
    // $this->db->order_by("l.lcreated", "DESC");
    $queryall = $this->db->get();
    $res7 = $queryall->result_array();

    $query1 = $this->db->select('n.notification_id as n_notification_id,n.notification_name as n_notification_name,n.admin_id as n_admin_id,n.enquiry_id as n_enquiry_id,n.follow_up_id as n_follow_up_id,n.follow_up_status as n_follow_up_status,n.user_id as n_user_id,n.status as n_status,n.created as n_created')
      ->from('ap_notification as n')
       ->select('e.enq_name,e.enquiry_id')
       ->join('ap_enquiry as e', 'e.enquiry_id=n.enquiry_id', "LEFT")
      ->where('n.user_id="' . $this->session->userdata("user_id") . '" and n.follow_up_id="'.$row[0]["follow_up_id"].'"')
      // ->order_by('n.created','DESC')
      ->get()
      ->num_rows();

  
  $arr["clist"] ='';
  $arr1["clistnew"]="";
  for($i=0; $i<count($res7); $i++) {
    $follow_up_msg = $res7[$i]['follow_up_msg'];
    $follow_up_status = $res7[$i]['follow_up_status'];
    $follow_up_id = $res7[$i]['follow_up_id'];
    $username = $res7[$i]['username'];
    $log_done_by = $res7[$i]['done_by_log'];
    $nxt_follow_up_date = date_create($res7[$i]['nxt_follow_up_date']);
    $nxt_follow_up_hint = $res7[$i]['nxt_follow_up_hint'];
    $ap_followuplog_id = $res7[$i]['ap_followuplog_id'];
    $created = date_create($res7[$i]['lcreated']);

    if ($follow_up_status === "pending" | $follow_up_status === "followup") {
      $bclass = "primary_status";
    } elseif ($follow_up_status === "cancel" | $follow_up_status === "rejected" | $follow_up_status === "noresponse") {
      $bclass = "danger_status";
    } elseif ($follow_up_status === "completed") {
      $bclass = "success_status";
    }


    $arr["clist"] .= '
    <hr style="border-style: dashed;" />
    <div class="f_delete_id">
      <h2>'.date_format($created,"d-M-Y h:i:s").'</h2>
      <div class="e_gap">
      '.
      ($i==0 ? '<button class="btn btn-sm btn-success edit_last_logs" type="submit" data-uid="' . $ap_followuplog_id . '" data-fid="' . $follow_up_id . '"><i class="fa fa-edit"></i></button>' : "")
        
      .'
      
      </div>
      </div>
    <ul>
        <li>
          <span>Message:</span>
          <span>'.$follow_up_msg.'</span>
        </li>
        <li>
          <span>Status:</span>
          <span><button class="'.$bclass.'">'.$follow_up_status.'</button></span>
        </li>
        <li>
          <span>Next Follow up:</span>
          <span>'.date_format($nxt_follow_up_date,"d-M-Y h:i:s").'</span>
        </li>
        <li>
          <span>Hint:</span>
          <span>'.$nxt_follow_up_hint.'</span>
        </li>
        <li>
        <span>Done By:</span>
        <span>'.$username.'</span>
      </li>
        
      </ul>
      
    ';

    
    $arr["clist"] .="";
}
  if($row) {
  $result = '<div class="customer_view_details">
        <h2>Enquiry Details</h2>
        <ul>
          <li>
            <span>Enquiry Name:</span>
            <span>'. $row[0]["enq_name"]. '</span>
          </li>
          <li>
            <span>Enquiry Contact Number:</span>
            <span>' . $row[0]["enq_contact_number"] . '</span>
          </li>
          <li>
            <span>Enquiry Location:</span>
            <span>' . $row[0]["enq_location"] . '</span>
          </li>
          <li>
            <span>Enquiry Message:</span>
            <span>' . $row[0]["enq_msg"] . '</span>
          </li>
          <li>
            <span>Project Name:</span>
            <span>' . explode("|",$row[0]["project_id"])[1] . '</span>
          </li>
          
        </ul>
      </div>
      
      <hr />
        <div class="customer_view_details log_list">
        
          <div class="a_test">
          <h2>Previous Follow up Progress('.count($res7).')</h2>
          <div class="n_add_new_btn">
          <button class="btn btn-sm btn-danger view_notify_message_all" data-fid="'. $row[0]["follow_up_id"].'" data-uid="'.$this->session->userdata("user_id").'"><i class="bi bi-chat-left-text"></i> Total Message('.$query1.')</button>
            <button  class="btn btn-sm btn-primary edit_followup_new" data-uid="'. $row[0]["follow_up_id"].'"><i class="fa fa-plus" aria-hidden="true"></i> Add New Followup</button>
            </div></div>
         
          '.
          $arr["clist"]
          .
          '
          
   
    
        </div>
     ';
    return $result;
  } else {
    return $result;
  }
  



}



public function updatenew_followup($f_msg,$f_status,$f_date,$f_msghint,$this_id)
{

  $result = array(0 => "");
  date_default_timezone_set("Asia/Calcutta");
  $action_id = uniqid(true);
  $action_id1 = uniqid(true);
  $ap_followuplog_id = uniqid(true);
  $check = $this->db->query('select * from ap_followup_progress where follow_up_id="'.$this_id.'"')->result();

    $check_res = $this->db->query('select * from ap_enquiry where enquiry_id="'.$check[0]->enquiry_id.'"')->result();
  $data = array(
    "follow_up_msg"=>$f_msg,
    "follow_up_status"=>$f_status,
    "nxt_follow_up_date"=>$f_date,
    "nxt_follow_up_hint"=>$f_msghint,
  );
  $data1 = array(
    "action_id" => $action_id,
    "action_type" => "update",
    "action_name" => "Update Follow up progress",
    "module_id" => $this_id,
    "deleted_by" => "Enquiry Name: ".$check_res[0]->enq_name.", Project Name: ".explode("|",$check_res[0]->project_id)[1],
    "done_by" => $this->session->userdata("user_id"),
    "created" => date('Y-m-j H:i:s'),
  );
  $data2 = array(
    "ap_followuplog_id"=>$ap_followuplog_id,
    "follow_up_id"=>$this_id,
    "admin_id"=>$this->session->userdata("user_id"),
    "superadmin_id"=>$this->session->userdata("superadmin_id"),
    "follow_up_msg"=>$f_msg,
    "follow_up_status"=>$f_status,
    "nxt_follow_up_date"=>$f_date,
    "nxt_follow_up_hint"=>$f_msghint,
    "done_by_log"=>$this->session->userdata("user_id"),
    "lcreated"=>date('Y-m-j H:i:s'),
  );
  $data3 = array(
    "action_id" => $action_id1,
    "action_type" => "update",
    "action_name" => "Update Follow up progress logs",
    "module_id" => $this_id,
    "deleted_by" => "Enquiry Name: ".$check_res[0]->enq_name.", Project Name: ".explode("|",$check_res[0]->project_id)[1],
    "done_by" => $this->session->userdata("user_id"),
    "created" => date('Y-m-j H:i:s'),
  );

  $res = $this->db->where("follow_up_id",$this_id)->update("ap_followup_progress",$data);
  $res1 = $this->db->insert("ap_action", $data1);
  $res3 = $this->db->insert("ap_action", $data3);
  $res2 = $this->db->insert("ap_followup_logs", $data2);

  if ($res && $res1 && $res2 && $res3) {
    $result = array(0 => "success");
    return $result;
  } else {
    $result = array(0 => "fail");
    return $result;
  }
}

public function getprocessdetails($f_id)
{

  $this->db->select("*");
  $this->db->from("ap_followup_progress");
  $this->db->where("follow_up_id", $f_id);
  $this->db->limit(1);
  $query = $this->db->get();
  $res = $query->result();
  if ($res) {
    return $res;
  }
}


public function getprocessdetailslogs($f_id)
{

  $this->db->select("*");
  $this->db->from("ap_followup_logs");
  $this->db->where("ap_followuplog_id", $f_id);
  $this->db->limit(1);
  $query = $this->db->get();
  $res = $query->result();
  if ($res) {
    return $res;
  }
}




public function updatenew_followup_log($f_msg,$f_status,$f_date,$f_msghint,$follow_up_id,$follow_up_log_id)
{

  $result = array(0 => "");
  date_default_timezone_set("Asia/Calcutta");
  $action_id = uniqid(true);
  $action_id1 = uniqid(true);
  $check = $this->db->query('select * from ap_followup_progress where follow_up_id="'.$follow_up_id.'"')->result();

  $check_res = $this->db->query('select * from ap_enquiry where enquiry_id="'.$check[0]->enquiry_id.'"')->result();

  $data = array(
    "follow_up_msg"=>$f_msg,
    "follow_up_status"=>$f_status,
    "nxt_follow_up_date"=>$f_date,
    "nxt_follow_up_hint"=>$f_msghint,
  );
  $data1 = array(
    "action_id" => $action_id,
    "action_type" => "update",
    "action_name" => "Update Follow up progress",
    "module_id" => $follow_up_id,
    "deleted_by" => "Enquiry Name: ".$check_res[0]->enq_name.", Project Name: ".explode("|",$check_res[0]->project_id)[1],
    "done_by" => $this->session->userdata("user_id"),
    "created" => date('Y-m-j H:i:s'),
  );
  $data2 = array(
    "follow_up_msg"=>$f_msg,
    "follow_up_status"=>$f_status,
    "nxt_follow_up_date"=>$f_date,
    "nxt_follow_up_hint"=>$f_msghint,
    "done_by_log"=>$this->session->userdata("user_id"),
  );
  $data3 = array(
    "action_id" => $action_id1,
    "action_type" => "update",
    "action_name" => "Update Follow up progress logs",
    "module_id" => $follow_up_log_id,
    "deleted_by" => "Enquiry Name: ".$check_res[0]->enq_name.", Project Name: ".explode("|",$check_res[0]->project_id)[1],
    "done_by" => $this->session->userdata("user_id"),
    "created" => date('Y-m-j H:i:s'),
  );

  $res = $this->db->where("follow_up_id",$follow_up_id)->update("ap_followup_progress",$data);
  $res1 = $this->db->insert("ap_action", $data1);
  $res3 = $this->db->insert("ap_action", $data3);
  $res2 = $this->db->where("ap_followuplog_id",$follow_up_log_id)->update("ap_followup_logs", $data2);

  if ($res && $res1 && $res2 && $res3) {
    $result = array(0 => "success");
    return $result;
  } else {
    $result = array(0 => "fail");
    return $result;
  }
}



//enquiry

//all enquiry

public function getallenquiry()
{


  $arr = array();
  $arr['elist'] = '<table id="customer_view" class="display dataTable">';
  $c_user = $this->session->userdata("user_id");
  $a_user = $this->session->userdata("admin_id");
  $query = $this->db->query('select * from ap_enquiry where enq_status="1" and (admin_id="' . $c_user . '" or admin_id="'.$a_user.'")');
  $row = $query->result_array();
  $arr['elist'] .= '
<thead>
<tr>
<th>S No</th>
<th>Enquiry Name</th>
<th>Phone Number</th>
<th>Enquiry Date</th>
<th>Location</th>
<th>Message</th>
<th>Project Name</th>

</thead>';
  $arr['elist_count'] = count($row);
  if ($row) {
   
    $arr['elist'] .= '<tbody>';
    for ($i = 0; $i < count($row); $i++) {

      $cid = $row[$i]['enquiry_id'];
      $cname = $row[$i]['enq_name'];
      $cphone = $row[$i]['enq_contact_number'];
      $cdate = $row[$i]['enq_date'];
      $clocation = $row[$i]['enq_location'];
      $cmsg = $row[$i]['enq_msg'];
      $cprojectname = explode("|", $row[$i]['project_id']);


      $arr['elist'] .= '
  <tr>
  <td>' . ($i+1) . '</td>
  <td>' . $cname . '</td>
  <td>' . $cphone . '</td>
  <td>' . $cdate . '</td>
  <td>' . $clocation . '</td>
  <td>' . $cmsg . '</td>
  <td>' . $cprojectname[1] . '</td>
  </tr>';
    }
  } else {
    $arr['elist'] .= '<tbody>';
  }
  $arr['elist'] .= '</tbody></table>';
  return $arr;
}






public function getprojects()
{
  $this->db->select("project_id,project_name");
  $this->db->from("ap_projects");
  $this->db->where("project_status", 1);
  $this->db->where("admin_id", $this->session->userdata("user_id"))->or_where("admin_id",$this->session->userdata("admin_id"));
  $query = $this->db->get();
  return $query->result();
}



//add project

public function add_newproject($c_user_id, $c_superadmin_id, $c_date, $c_name)
{
  $result = array(0 => "");
  $project_id = uniqid(true);

  $data = array(
    "project_id" => $project_id,
    "admin_id" => $this->session->userdata("admin_id"),
    "superadmin_id" => $c_superadmin_id,
    "project_name" => $c_name,
    "project_status" => 1,
    "done_by" => $c_user_id,
    "created" => $c_date,
  );
  date_default_timezone_set("Asia/Calcutta");
  $action_id = uniqid(true);
  $data1 = array(
    "action_id" => $action_id,
    "action_type" => "create",
    "action_name" => "Create Project",
    "module_id" => $project_id,
    "deleted_by"=> "Project Name: ".$c_name,
    "done_by" => $this->session->userdata("user_id"),
    "created" => date('Y-m-j H:i:s'),
  );
  $res1 = $this->db->insert("ap_action", $data1);

  $res = $this->db->insert("ap_projects", $data);

  if ($res && $res1) {
    $result = array(0 => "success");
    return $result;
  } else {
    $result = array(0 => "fail");
    return $result;
  }
}




  //add enquiry 
  public function add_newenquiry($e_admin_id, $e_superadmin_id, $e_name, $e_phone, $e_date, $e_project, $e_projectmsg, $j_date, $e_location)
  {

    $result = array(0 => "");
    $enquiry_id = uniqid(true);
    $follow_up_id = uniqid(true);
    date_default_timezone_set("Asia/Calcutta");
    $action_id = uniqid(true);
    $action_id1 = uniqid(true);
    $data = array(
      "enquiry_id " => $enquiry_id,
      "admin_id" => $this->session->userdata("admin_id"),
      "superadmin_id" => $e_superadmin_id,
      "enq_name" => $e_name,
      "enq_contact_number" => $e_phone,
      "enq_date" => $e_date,
      "enq_location" => $e_location,
      "enq_msg" => $e_projectmsg,
      "project_id" => $e_project,
      "enq_status" => 1,
      "done_by" => $e_admin_id,
      "created" => $j_date,
    );

    
    $data1 = array(
      "action_id" => $action_id,
      "action_type" => "create",
      "action_name" => "Add Enquiry",
      "module_id" => $enquiry_id,
      "deleted_by"=> "Enquiry Name: ".$e_name,
      "done_by" => $this->session->userdata("user_id"),
      "created" => date('Y-m-j H:i:s'),
    );

    $data2 = array(
      "follow_up_id"=> $follow_up_id,
      "enquiry_id"=> $enquiry_id,
      "admin_id"=> $this->session->userdata("admin_id"),
      "superadmin_id"=> $e_superadmin_id,
      "follow_up_msg"=>"",
      "project_id"=> $e_project,
      "follow_up_status"=> "pending",
      "nxt_follow_up_date"=>"",
      "nxt_follow_up_hint"=>"",
      "done_by"=> $e_admin_id,
      "created"=> $j_date,
    );

    $data3 = array(
      "action_id" => $action_id1,
      "action_type" => "create",
      "action_name" => "Add Follow Up Progress",
      "module_id" => $follow_up_id,
      "deleted_by"=>"Enquiry name: ".$e_name.", Project Name: ".explode("|",$e_project)[1],
      "done_by" => $this->session->userdata("user_id"),
      "created" => date('Y-m-j H:i:s'),
    );
    $res1 = $this->db->insert("ap_action", $data1);
    $res = $this->db->insert("ap_enquiry", $data);
    $res3 = $this->db->insert("ap_action", $data3);
    $res2 = $this->db->insert("ap_followup_progress", $data2);

    if ($res && $res1 && $res2 && $res3) {
      $result = array(0 => "success");
      return $result;
    } else {
      $result = array(0 => "fail");
      return $result;
    }
  }



  public function DeleteEnquiryById($deleteid)
  {
    $result = array(0 => '');
    $query = $this->db->query('delete from ap_enquiry where enquiry_id="' . $deleteid . '"');
    date_default_timezone_set("Asia/Calcutta");
    $action_id = uniqid(true);
    $data1 = array(
      "action_id" => $action_id,
      "action_type" => "delete",
      "action_name" => "Delete Enquiry",
      "module_id" => $deleteid,
      "done_by" => $this->session->userdata("user_id"),
      "created" => date('Y-m-j H:i:s'),
    );
    $res1 = $this->db->insert("ap_action", $data1);
    if ($query && $res1) {
      $result = array(0 => 'success');
      return $result;
    } else {
      $result = array(0 => 'fail');
      return $result;
    }
  }




  public function con_report_admin() {

    $this_id = $this->session->userdata("user_id");
    $this_id1 = $this->session->userdata("admin_id");
    $query = $this->db->query('select * from ap_users where (role="user" and admin_id="'.$this_id.'") order by created DESC');
    $query1 = $this->db->query('select * from ap_enquiry where enq_status="1" and (admin_id="' . $this_id . '" or admin_id="'.$this_id1.'") order by created DESC');
  
    $this->db->select("*");
      $this->db->from("ap_enquiry as e");
      $this->db->join("ap_followup_progress as f", 'f.enquiry_id=e.enquiry_id');
      $this->db->where('e.admin_id="'. $this_id.'"')->or_where('e.admin_id="'.$this_id1.'"');
      $query3 = $this->db->get();
      $res3 = $query3->result_array();
    
  
    $res = $query->result_array();
    $res1 = $query1->result_array();
  
    $result = '<div class="report_overview">
    <h2>Reports</h2>
    <ul>
      
      </a>
      <a href="'.base_url("enquiryuser").'" title="Total Enquiry">
      <li>
      <i class="fa fa-question-circle" aria-hidden="true"></i>
        
        <h4>'.count($res1).'</h4>
        <p>Total Enquiry</p>
      </li>
      </a>
      <a href="'.base_url("followupprogressuser").'" title="Total Follow Up">
      <li>
        <i class="fa fa-thumbs-up" aria-hidden="true"></i>
        
        <h4>'.count($res3).'</h4>
        <p>Total Follow Up</p>
      </li>
      </a>
    </ul>
  </div>';
  
  return $result;
  
  
  
  
  
  
  }
  
  





















}
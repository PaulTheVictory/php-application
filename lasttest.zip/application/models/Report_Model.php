<?php
if (!defined('BASEPATH'))
  exit('No direct script access allowed');

class Report_Model extends CI_Model
{
  public function __construct()
  {
    parent::__construct();
    $this->load->database();
    $this->load->library('email');
    $this->load->library('Datatables');
  }

public function get_company_user_one() {

    $query = $this->db->query('select user_id,username from ap_users where (role="user" and status=1 and admin_id="'.$this->session->userdata('user_id').'")');
    return $query->result();

  }

  public function get_company_user() {

    $query = $this->db->query('select user_id,username from ap_users where (role="admin" and status=1)');
    return $query->result();

  }


  public function Getcompanyuserlistall($s_companyid) {

    $query = $this->db->query('select user_id,username from ap_users where (role="user" and admin_id="'.$s_companyid.'")')->result();

    if($query) {

    $arr = array();

    $arr["ulistall"] ='<select class="form-control" id="s_companyuser" name="s_companyuser" style="height: 40px;"><option value="">- Please select -</option>';

    for($i=0; $i<count($query); $i++) {
      $arr["ulistall"] .='<option value="'.$query[$i]->user_id.'">'.$query[$i]->username.'</option>';
    }

    $arr["ulistall"] .='</select>';

    $result = $arr["ulistall"];

    return $result;

  } else {
    $result = '<select class="form-control" id="s_companyuser" name="s_companyuser" style="height: 40px;"><option value="">- Please select -</option></select>';
    return $result;
  }

  }



  public function admin_report_list($postData = null)
  {

    ## Read value
    $draw = $postData['draw'];
    $start = $postData['start'];
    $rowperpage = $postData['length'];
    $columnIndex = $postData['order'][0]['column'];
    $columnName = $postData['columns'][$columnIndex]['data'];
    $columnSortOrder = $postData['order'][0]['dir'];
    $searchValue = $postData['search']['value'];

    // Custom search filter 
    $statusFilter = $postData['statusFilter'];
    $startDate = $postData['startDate'];
    $endDate = $postData['endDate'];
    $doneBy = $postData['doneBy'];

    $search_arr = array();
    ## Search 
    $searchQuery = "";
    if ($searchValue != '') {
      $search_arr[] = " (
          follow_up_id like '%" . $searchValue . "%' or 
          enquiry_id like '%" . $searchValue . "%' or 
          follow_up_msg like '%" . $searchValue . "%' or 
          follow_up_status like '%" . $searchValue . "%' or 
          nxt_follow_up_date like '%" . $searchValue . "%' or 
          nxt_follow_up_hint like '%" . $searchValue . "%' or 
          created like'%" . $searchValue . "%' 
        ) ";
    }

    if ($statusFilter != '') {
      $search_arr[] = " follow_up_status like '%" . $statusFilter . "%' ";
    }

  



    if (count($search_arr) > 0) {
      $searchQuery = implode(" and ", $search_arr);
    }

    ## Total number of records without filtering
    $this->db->select('count(*) as allcount');
    $this->db->from('ap_followup_progress');
    $this->db->join("ap_users","ap_users.user_id=ap_followup_progress.done_by");
    $this->db->join("ap_enquiry","ap_enquiry.enquiry_id=ap_followup_progress.enquiry_id");
    $this->db->where("ap_followup_progress.admin_id", $this->session->userdata("user_id"));
    if($doneBy != '') {
      $this->db->where("ap_followup_progress.done_by", $doneBy);
    }
    if ($startDate != '' && $endDate) {
      $this->db->where('DATE_FORMAT(ap_followup_progress.created, "%d/%m/%Y") >=', $startDate);
      $this->db->where('DATE_FORMAT(ap_followup_progress.created, "%d/%m/%Y") <=', $endDate);
    }
    $records = $this->db->get()->result();
    $totalRecords = $records[0]->allcount;

    ## Total number of record with filtering
    $this->db->select('count(*) as allcount');
    $this->db->from('ap_followup_progress');
    $this->db->join("ap_users","ap_users.user_id=ap_followup_progress.done_by");
    $this->db->join("ap_enquiry","ap_enquiry.enquiry_id=ap_followup_progress.enquiry_id");
    $this->db->where("ap_followup_progress.admin_id", $this->session->userdata("user_id"));
    if($doneBy != '') {
      $this->db->where("ap_followup_progress.done_by", $doneBy);
    }
    if ($startDate != '' && $endDate) {
      $this->db->where('DATE_FORMAT(ap_followup_progress.created, "%d/%m/%Y") >=', $startDate);
      $this->db->where('DATE_FORMAT(ap_followup_progress.created, "%d/%m/%Y") <=', $endDate);
    }
    if ($searchQuery != '')
      $this->db->where($searchQuery);
    $records = $this->db->get()->result();
    $totalRecordwithFilter = $records[0]->allcount;

    ## Fetch records
    $this->db->select('*');
    $this->db->from('ap_followup_progress');
    $this->db->join("ap_users","ap_users.user_id=ap_followup_progress.done_by");
    $this->db->join("ap_enquiry","ap_enquiry.enquiry_id=ap_followup_progress.enquiry_id");
    $this->db->where("ap_followup_progress.admin_id", $this->session->userdata("user_id"));
    if($doneBy != '') {
      $this->db->where("ap_followup_progress.done_by", $doneBy);
    }
    if ($startDate != '' && $endDate) {
      $this->db->where('DATE_FORMAT(ap_followup_progress.created, "%d/%m/%Y") >=', $startDate);
      $this->db->where('DATE_FORMAT(ap_followup_progress.created, "%d/%m/%Y") <=', $endDate);
    }
    if ($searchQuery != '')
      $this->db->where($searchQuery);
    $this->db->order_by($columnName, $columnSortOrder);
    $this->db->limit($rowperpage, $start);
    $records = $this->db->get()->result();

    $data = array();

    foreach ($records as $key => $record) {

      $data[] = array(
        "enq_name" => $record->enq_name,
        "username" => $record->username,
        "follow_up_msg" => $record->follow_up_msg,
        "follow_up_status" => $record->follow_up_status,
        "nxt_follow_up_date" => $record->nxt_follow_up_date,
        "nxt_follow_up_hint" => $record->nxt_follow_up_hint,
        "created" => $record->created,
      );
    }


    ## Response
    $response = array(
      "draw" => intval($draw),
      "iTotalRecords" => $totalRecords,
      "iTotalDisplayRecords" => $totalRecordwithFilter,
      "aaData" => $data
    );

    return $response;
  }







  //Super admin report


  public function superadmin_report_list($postData = null)
  {

     ## Read value
     $draw = $postData['draw'];
     $start = $postData['start'];
     $rowperpage = $postData['length'];
     $columnIndex = $postData['order'][0]['column'];
     $columnName = $postData['columns'][$columnIndex]['data'];
     $columnSortOrder = $postData['order'][0]['dir'];
     $searchValue = $postData['search']['value'];
 
     // Custom search filter 
     $statusFilter = $postData['statusFilter'];
     $startDate = $postData['startDate'];
     $endDate = $postData['endDate'];
     $doneBy = $postData['doneBy'];
 
     $search_arr = array();
     ## Search 
     $searchQuery = "";
     if ($searchValue != '') {
       $search_arr[] = " (
           follow_up_id like '%" . $searchValue . "%' or 
           enquiry_id like '%" . $searchValue . "%' or 
           follow_up_msg like '%" . $searchValue . "%' or 
           follow_up_status like '%" . $searchValue . "%' or 
           nxt_follow_up_date like '%" . $searchValue . "%' or 
           nxt_follow_up_hint like '%" . $searchValue . "%' or 
           created like'%" . $searchValue . "%' 
         ) ";
     }
 
     if ($statusFilter != '') {
       $search_arr[] = " follow_up_status like '%" . $statusFilter . "%' ";
     }
 
   
 
 
 
     if (count($search_arr) > 0) {
       $searchQuery = implode(" and ", $search_arr);
     }
 
     ## Total number of records without filtering
     $this->db->select('count(*) as allcount');
     $this->db->from('ap_followup_progress');
     $this->db->join("ap_users","ap_users.user_id=ap_followup_progress.done_by","LEFT");
     $this->db->join("ap_enquiry","ap_enquiry.enquiry_id=ap_followup_progress.enquiry_id","LEFT");
     $this->db->where("ap_enquiry.enquiry_id<>","");
     if($doneBy != '') {
       $this->db->where("ap_followup_progress.done_by", $doneBy);
     }
     if ($startDate != '' && $endDate) {
       $this->db->where('DATE_FORMAT(ap_followup_progress.created, "%d/%m/%Y") >=', $startDate);
       $this->db->where('DATE_FORMAT(ap_followup_progress.created, "%d/%m/%Y") <=', $endDate);
     }
     $records = $this->db->get()->result();
     $totalRecords = $records[0]->allcount;
 
     ## Total number of record with filtering
     $this->db->select('count(*) as allcount');
     $this->db->from('ap_followup_progress');
     $this->db->join("ap_users","ap_users.user_id=ap_followup_progress.done_by","LEFT");
     $this->db->join("ap_enquiry","ap_enquiry.enquiry_id=ap_followup_progress.enquiry_id","LEFT");
     $this->db->where("ap_enquiry.enquiry_id<>","");
     if($doneBy != '') {
       $this->db->where("ap_followup_progress.done_by", $doneBy);
     }
     if ($startDate != '' && $endDate) {
       $this->db->where('DATE_FORMAT(ap_followup_progress.created, "%d/%m/%Y") >=', $startDate);
       $this->db->where('DATE_FORMAT(ap_followup_progress.created, "%d/%m/%Y") <=', $endDate);
     }
     if ($searchQuery != '')
       $this->db->where($searchQuery);
     $records = $this->db->get()->result();
     $totalRecordwithFilter = $records[0]->allcount;
 
     ## Fetch records
     $this->db->select('*');
     $this->db->from('ap_followup_progress');
     $this->db->join("ap_users","ap_users.user_id=ap_followup_progress.done_by","LEFT");
     $this->db->join("ap_enquiry","ap_enquiry.enquiry_id=ap_followup_progress.enquiry_id","LEFT");
     $this->db->where("ap_enquiry.enquiry_id<>","");

     if($doneBy != '') {
       $this->db->where("ap_followup_progress.done_by", $doneBy);
     }
     if ($startDate != '' && $endDate) {
       $this->db->where('DATE_FORMAT(ap_followup_progress.created, "%d/%m/%Y") >=', $startDate);
       $this->db->where('DATE_FORMAT(ap_followup_progress.created, "%d/%m/%Y") <=', $endDate);
     }
     if ($searchQuery != '')
       $this->db->where($searchQuery);
     $this->db->order_by($columnName, $columnSortOrder);
     $this->db->limit($rowperpage, $start);
     $records = $this->db->get()->result();
 
     $data = array();
 
     foreach ($records as $key => $record) {
 
       $data[] = array(
         "enq_name" => $record->enq_name,
         "username" => $record->username,
         "follow_up_msg" => $record->follow_up_msg,
         "follow_up_status" => $record->follow_up_status,
         "nxt_follow_up_date" => $record->nxt_follow_up_date,
         "nxt_follow_up_hint" => $record->nxt_follow_up_hint,
         "created" => $record->created,
       );
     }
 
 
     ## Response
     $response = array(
       "draw" => intval($draw),
       "iTotalRecords" => $totalRecords,
       "iTotalDisplayRecords" => $totalRecordwithFilter,
       "aaData" => $data
     );
 
     return $response;
  }









}

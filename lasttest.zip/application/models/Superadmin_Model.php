<?php

if (!defined('BASEPATH')) {
  exit('No direct script access allowed');
}

class Superadmin_Model extends CI_Model
{
  public function __construct()
  {
    parent::__construct();
    $this->load->database();
    $this->load->library('email');
    $this->load->library('Datatables');
  }



  //add customer

  public function add_customer($c_user_id, $c_admin_id, $c_superadmin_id, $c_date, $c_name, $c_cname, $c_email, $c_phone, $c_password, $c_orgpassword, $c_image)
  {
    $result = [0 => ''];
    $user_id = uniqid(true);
    $action_id = uniqid(true);

    $data = [
      'user_id' => $user_id,
      'admin_id' => $c_admin_id,
      'superadmin_id' => $c_superadmin_id,
      'username' => $c_name,
      'phone' => $c_phone,
      'email' => $c_email,
      'password' => $c_password,
      'org_password' => $c_orgpassword,
      'status' => 1,
      'role' => 'admin',
      'done_by' => $c_user_id,
      'company_name' => $c_cname,
      'company_logo' => $c_image,
      'created' => $c_date,
    ];

    $data1 = [
      'action_id' => $action_id,
      'action_type' => 'create',
      'action_name' => 'Create Customer',
      'module_id' => $user_id,
      'deleted_by' => $c_name,
      'done_by' => $c_user_id,
      'created' => $c_date,
    ];

    $res = $this->db->insert('ap_users', $data);
    $res1 = $this->db->insert('ap_action', $data1);

    if ($res && $res1) {
      $result = [0 => 'success'];

      return $result;
    } else {
      $result = [0 => 'fail'];

      return $result;
    }
  }

  //get all customer active details

  public function alladminlistname()
  {

    $table = $this->datatables->select("user_id,admin_id,superadmin_id,username,c_code,phone,email,password,org_password,status,role,done_by,company_name,company_logo,created")
      ->from("ap_users")
      ->where("role", "admin")
      ->where('user_id !=', '63a9739adf7d9')
      ->add_column('action', '<div class="action_btn new_btn">
  <button type="button" class="view_customer_new" data-uid="$1"><img src="' . base_url() . 'assets/images/view.png" /> </button>
    <button type="button" class="edit_customer_new" data-uid="$1"><img src="' . base_url() . 'assets/images/edit.png" /> </button>
          <button class="delete_customer" type="submit" data-uid="$1"><img src="' . base_url() . 'assets/images/delete.png" /> </button></div>', 'user_id')
      ->add_column("custom_logo", '<img src="' . base_url() . '/docs/customerlogo/$1" alt="$2" class="c_logo_style" />', "company_logo,company_name")
      ->generate();
    return $table;
  }


  //   public function GetCustomerLists()
  //   {
  //       $arr = [];
  //       $arr['clist'] = '<table id="customer_view" class="display dataTable">';
  //       $arr['clist'] .= '
  //   <thead>
  //   <tr>
  //   <th>S No</th>
  //   <th>Company Name</th>
  //   <th>Email Address</th>
  //   <th>Phone Number</th>
  //   <th>Logo</th>
  //   <th>Status</th>
  //   <th>Action</th>
  //   </thead>';
  //       $query = $this->db->select('*')
  //     ->from('ap_users')
  //     ->group_start()
  //     ->where('role', 'admin')
  //     ->where('user_id !=', '63a9739adf7d9')
  //     ->group_end()
  //     // ->order_by('created','>=',"ASC")
  //     ->get();
  //       $row = $query->result_array();
  //       $arr['customer_list_count'] = count($row);
  //       if ($row) {
  //           $arr['clist'] .= '<tbody>';
  //           for ($i = 0; $i < count($row); ++$i) {
  //               $user_id = $row[$i]['user_id'];
  //               $company_name = $row[$i]['company_name'];
  //               $email = $row[$i]['email'];
  //               $phone = $row[$i]['phone'];
  //               $company_logo = $row[$i]['company_logo'];
  //               $status = $row[$i]['status'];

  //               $arr['clist'] .= '
  // <tr>
  // <td>'.($i + 1).'</td>
  // <td>'.$company_name.'</td>
  // <td>'.$email.'</td>
  // <td>'.$phone.'</td>
  // <td><img src="'.base_url().'/docs/customerlogo/'.$company_logo.'" alt="'.$company_name.'" class="c_logo_style" /></td>
  // <td>'.($status == 1 ? '<button class="a_btn status_update" data-uid="'.$user_id.'" data-sid="'.$status.'">Active</button>' : '<button class="ina_btn status_update" data-uid="'.$user_id.'" data-sid="'.$status.'">Inactive</button>').'</td>
  // <td>
  // <div class="action_btn">
  // <button type="button" class="btn btn-sm btn-primary view_customer_new" data-uid="'.$user_id.'"><i class="fa fa-eye"></i> </button>
  //   <button type="button" class="btn btn-sm btn-success edit_customer_new" data-uid="'.$user_id.'"><i class="fa fa-edit"></i> </button>
  //         <button class="btn btn-sm btn-danger delete_customer" type="submit" data-uid="'.$user_id.'"><i class="fa fa-trash"></i> </button></div>
  //     </td></tr>';
  //           }
  //       } else {
  //           $arr['clist'] .= '<tbody>';
  //       }
  //       $arr['clist'] .= '</tbody></table>';

  //       return $arr;
  //   }

  public function getsinglecustomerdetails($f_id)
  {
    $this->db->select('*');
    $this->db->from('ap_users');
    $this->db->where('user_id', $f_id);
    $this->db->limit(1);
    $query = $this->db->get();
    $res = $query->result();
    if ($res) {
      return $res;
    }
  }

  //view usetomer

  public function get_customerview_details($view_id)
  {
    $result = '';
    $query = $this->db->select('*')
      ->from('ap_users')
      ->where('user_id', $view_id)
      ->limit(1)
      ->get();

    $row = $query->result_array();
    if ($row) {
      $result = '<div class="customer_view_details">
          <h2>Customer Details</h2>
          <ul>
            <li>
              <span>Name:</span>
              <span>' . $row[0]['username'] . '</span>
            </li>
            <li>
              <span>Phone:</span>
              <span>' . $row[0]['phone'] . '</span>
            </li>
            <li>
              <span>Email ID:</span>
              <span>' . $row[0]['email'] . '</span>
            </li>
            <li>
              <span>Password:</span>
              <span>' . $row[0]['org_password'] . '</span>
            </li>
            <li>
              <span>Company Name:</span>
              <span>' . $row[0]['company_name'] . '</span>
            </li>
            <li>
              <span>Role:</span>
              <span>' . $row[0]['role'] . '</span>
            </li>
            <li>
              <span>Company Logo:</span>
              <span><img src="' . base_url('docs/customerlogo/' . $row[0]['company_logo'] . '') . '" /></span>
            </li>
          </ul>
        </div>
        <hr />
        <div class="customer_view_addtionaldetails">
          <h2>Additional Details</h2>
          <ul>
            <li>
              <span>User ID:</span>
              <span>' . $row[0]['user_id'] . '</span>
            </li>
            <li>
              <span>Status:</span>
              <span>' . ($row[0]['status'] == 1 ? '<button class="a_btn status_update" data-uid="' . $row[0]['user_id'] . '" data-sid="' . $row[0]['status'] . '">Active</button>' : '<button class="ina_btn status_update" data-uid="' . $row[0]['user_id'] . '" data-sid="' . $row[0]['status'] . '">Inactive</button>') . '</span>
            </li>
            <li>
              <span>Done By:</span>
              <span>' . $row[0]['done_by'] . '</span>
            </li>
            <li>
              <span>Joining Date:</span>
              <span>' . $row[0]['created'] . '</span>
            </li>
           
          </ul>
        </div>';

      return $result;
    } else {
      return $result;
    }
  }

  /*Delete Customer*/

  public function DeleteCustomerById($deleteid)
  {
    $result = [0 => ''];
    $query = $this->db->query('update customers set customer_status="0" where customer_id="' . $deleteid . '"');
    if ($query) {
      $result = [0 => 'success'];

      return $result;
    } else {
      $result = [0 => 'fail'];

      return $result;
    }
  }

  /*active*/

  public function UpdateById($deleteid, $sid)
  {
    date_default_timezone_set('Asia/Calcutta');
    $name_res = $this->db->query('select username from ap_users where user_id="' . $deleteid . '"')->result();
    $a_status = $sid == 1 ? 0 : 1;
    $result = [0 => ''];
    $action_id = uniqid(true);
    $data1 = [
      'action_id' => $action_id,
      'action_type' => 'update',
      'action_name' => 'Status Update Customer',
      'module_id' => $deleteid,
      'deleted_by' => $name_res[0]->username,
      'done_by' => $this->session->userdata('user_id'),
      'created' => date('Y-m-j H:i:s'),
    ];

    $res1 = $this->db->insert('ap_action', $data1);
    $data = [
      'status' => $a_status,
    ];
    $query = $this->db->where('user_id', $deleteid)->update('ap_users', $data);
    if ($query && $res1) {
      $result = [0 => 'success'];

      return $result;
    } else {
      $result = [0 => 'fail'];

      return $result;
    }
  }

  /*Delete permanently*/

  public function DeleteById($deleteid)
  {
    $result = [0 => ''];
    date_default_timezone_set('Asia/Calcutta');
    $name_res = $this->db->query('select username from ap_users where user_id="' . $deleteid . '"')->result();
    $action_id = uniqid(true);
    $data1 = [
      'action_id' => $action_id,
      'action_type' => 'delete',
      'action_name' => 'Delete Customer',
      'module_id' => $deleteid,
      'deleted_by' => $name_res[0]->username,
      'done_by' => $this->session->userdata('user_id'),
      'created' => date('Y-m-j H:i:s'),
    ];
    $res1 = $this->db->insert('ap_action', $data1);
    $query = $this->db->where('user_id', $deleteid)->delete('ap_users');
    if ($query && $res1) {
      $result = [0 => 'success'];

      return $result;
    } else {
      $result = [0 => 'fail'];

      return $result;
    }
  }

  /*Recovery user*/

  public function RecoveryById($recoveryid)
  {
    $result = [0 => ''];
    $query = $this->db->query('update customers set customer_status="1" where customer_id="' . $recoveryid . '"');
    if ($query) {
      $result = [0 => 'success'];

      return $result;
    } else {
      $result = [0 => 'fail'];

      return $result;
    }
  }

  /*View Single User Profile*/

  public function ViewSingleUserById($viewid)
  {
    $arr = [];
    $arr['singlecustomer'] = [];
    $query = $this->db->query('select * from customers where customer_id="' . $viewid . '"');
    $row = $query->result_array();

    if ($query->num_rows() > 0) {
      return $row[0];
    } else {
      return $arr;
    }
  }

  //update customer

  public function update_customer($c_name, $c_password, $c_image, $viewid, $c_orgpassword)
  {
    $result = [0 => ''];
    $action_id = uniqid(true);
    date_default_timezone_set('Asia/Calcutta');

    $name_res = $this->db->query('select username from ap_users where user_id="' . $viewid . '"')->result();

    $data = [
      'username' => $c_name,
      'password' => $c_password,
      'org_password' => $c_orgpassword,
      'company_logo' => $c_image,
    ];
    $data1 = [
      'action_id' => $action_id,
      'action_type' => 'update',
      'action_name' => 'Update Customer',
      'module_id' => $viewid,
      'deleted_by' => $viewid,
      'done_by' => $this->session->userdata('user_id'),
      'created' => date('Y-m-j H:i:s'),
    ];

    $res1 = $this->db->insert('ap_action', $data1);

    $res = $this->db->where('user_id', $viewid)->update('ap_users', $data);
    if ($res && $res1) {
      $result = [0 => 'success'];

      return $result;
    } else {
      $result = [0 => 'fail'];

      return $result;
    }
  }

  //update customer
  public function updatenoimage_customer($c_name, $c_password, $viewid, $c_orgpassword)
  {
    $result = [0 => ''];
    $action_id = uniqid(true);
    date_default_timezone_set('Asia/Calcutta');
    $name_res = $this->db->query('select username from ap_users where user_id="' . $viewid . '"')->result();
    $data = [
      'username' => $c_name,
      'password' => $c_password,
      'org_password' => $c_orgpassword,
    ];
    $data1 = [
      'action_id' => $action_id,
      'action_type' => 'update',
      'action_name' => 'Update Customer',
      'module_id' => $viewid,
      'deleted_by' => $name_res[0]->username,
      'done_by' => $this->session->userdata('user_id'),
      'created' => date('Y-m-j H:i:s'),
    ];
    $res1 = $this->db->insert('ap_action', $data1);

    $res = $this->db->where('user_id', $viewid)->update('ap_users', $data);
    if ($res && $res1) {
      $result = [0 => 'success'];

      return $result;
    } else {
      $result = [0 => 'fail'];

      return $result;
    }
  }

  // all logs

  //get all customer active details


  public function allsuperadminreportlog() {

    $table = $this->datatables->select('log.admin_id as log_admin_id,log.name as log_name,log.role as log_role,log.intime as log_intime,log.outtime as log_outtime, log.status as log_status')
      ->from('ap_logs as log')
      ->select('u.user_id as u_user_id,u.role as u_role,u.status as u_status,u.company_name as u_company_name,u.company_logo as u_company_logo')
      ->join('ap_users as u', 'u.user_id=log.user_id')
      ->select('d.user_id as d_user_id,d.role as d_role,d.status as d_status,d.company_name as d_company_name,d.company_logo as d_company_logo')
      ->join('ap_users as d', 'd.user_id=log.admin_id')
      ->generate();
    return $table;

  }

  // public function GetLogLists()
  // {
  //   $arr = [];
  //   $arr['llist'] = '<table id="customer_view" class="display dataTable">';
  //   $this->db->select('log.admin_id as log_admin_id,log.name as log_name,log.role as log_role,log.intime as log_intime,log.outtime as log_outtime, log.status as log_status');
  //   $this->db->from('ap_logs as log');
  //   $this->db->select('u.user_id as u_user_id,u.role as u_role,u.status as u_status,u.company_name as u_company_name,u.company_logo as u_company_logo')->join('ap_users as u', 'u.user_id=log.user_id');
  //   $this->db->select('d.user_id as d_user_id,d.role as d_role,d.status as d_status,d.company_name as d_company_name,d.company_logo as d_company_logo')->join('ap_users as d', 'd.user_id=log.admin_id');
  //   // $this->db->order_by("log.outtime",">=","DESC");
  //   $query = $this->db->get();

  //   $row = $query->result_array();
  //   $arr['llist'] .= '
  // <thead>
  // <tr>
  // <th>S No</th>
  // <th>Company Name</th>
  // <th>Name</th>
  // <th>Role</th>
  // <th>Intime</th>
  // <th>Outtime</th>
  // <th>Status</th>

  // </thead>';
  //   $arr['customer_list_count'] = count($row);
  //   if ($row) {
  //     $arr['llist'] .= '<tbody>';
  //     for ($i = 0; $i < count($row); ++$i) {
  //       $name = $row[$i]['log_name'];
  //       $role = $row[$i]['log_role'];
  //       $intime = $row[$i]['log_intime'];
  //       $outtime = $row[$i]['log_outtime'];
  //       $status = $row[$i]['log_status'];

  //       $u_company_name = $row[$i]['u_company_name'] ? $row[$i]['u_company_name'] : $row[$i]['d_company_name'];

  //       $arr['llist'] .= '
  // <tr>
  // <td>' . ($i + 1) . '</td>
  // <td>' . $u_company_name . '</td>
  // <td>' . $name . '</td>
  // <td>' . $role . '</td>
  // <td>' . $intime . '</td>
  // <td>' . $outtime . '</td>
  // <td>' . $status . '</td>
  
  // </tr>';
  //     }
  //   } else {
  //     $arr['llist'] .= '<tbody>';
  //   }
  //   $arr['llist'] .= '</tbody></table>';

  //   return $arr;
  // }

  //get all user active details

  //get all superadmin list

public function allsuperadminlistname() {

  $table = $this->datatables->select('user_id,username,phone,email,password,org_password,status,role,created')
            ->from("ap_users")
            ->where("role","superadmin")
            ->where("user_id <>", "63a9739adf7d9")
            ->add_column("action", '<div class="action_btn new_btn">
    <button type="button" class="edit_superadmin" data-uid="$1"><img src="' . base_url() . 'assets/images/edit.png" /></button>
    
         <button class="delete_superadmin" type="submit" data-uid="$1"><img src="' . base_url() . 'assets/images/delete.png" /></button></div>','user_id,username')
            ->generate();

  return $table;


}



//   public function GetSuperAdminLists()
//   {
//     $arr = [];
//     $arr['splist'] = '<table id="customer_view" class="display dataTable">';
//     $c_userid = $this->session->userdata('user_id');
//     $query = $this->db->query('select * from ap_users where (user_id<>"63a9739adf7d9" and role="superadmin") order by created DESC');
//     $row = $query->result_array();
//     $arr['splist'] .= '
// <thead>
// <tr>
// <th>S No</th>
// <th>Username</th>
// <th>Phone Number</th>
// <th>Email Address</th>
// <th>Status</th>
// <th>Joining Date</th>
// <th>Action</th>
// </thead>';
//     $arr['customer_list_count'] = count($row);
//     if ($row) {
//       $arr['splist'] .= '<tbody>';
//       for ($i = 0; $i < count($row); ++$i) {
//         $cid = $row[$i]['user_id'];
//         $cname = $row[$i]['username'];
//         $cphone = $row[$i]['phone'];
//         $email = $row[$i]['email'];
//         $cstatus = $row[$i]['status'];
//         $jdate = date_create($row[$i]['created']);

//         $arr['splist'] .= '

// <td>' . ($i + 1) . '</td>
// <td>' . $cname . '</td>
// <td>' . $cphone . '</td>
// <td>' . $email . '</td>
// <td>' . ($cstatus == 1 ? '<button class="a_btn status_update" data-uid="' . $cid . '" data-sid="' . $cstatus . '">Active</button>' : '<button class="ina_btn status_update" data-uid="' . $cid . '" data-sid="' . $cstatus . '">Inactive</button>') . '</td>
// <td>' . date_format($jdate, 'd/M/Y') . '</td>
// <td>
//   <div class="action_btn">
//     <button type="button" class="btn btn-sm btn-success edit_superadmin" data-uid="' . $cid . '"><i class="fa fa-edit" aria-hidden="true"></i></button>
    
//           <button class="btn btn-sm btn-danger delete_superadmin" type="submit" data-uid="' . $cid . '"><i class="fa fa-trash"></i></button></div>
//       </td>
// </tr>';
//       }
//     } else {
//       $arr['splist'] .= '<tbody>';
//     }
//     $arr['splist'] .= '</tbody></table>';

//     return $arr;
//   }

  public function add_super_admin($c_doneby, $c_date, $c_name, $c_phone, $c_email, $c_password, $c_orgpassword)
  {
    date_default_timezone_set('Asia/Calcutta');

    $result = [0 => ''];
    $admin_id = uniqid(true);
    $thisid = $this->session->userdata('user_id');
    $data = [
      'user_id' => $admin_id,
      'admin_id' => $c_doneby,
      'superadmin_id' => $c_doneby,
      'username' => $c_name,
      'phone' => $c_phone,
      'email' => $c_email,
      'password' => $c_password,
      'org_password' => $c_orgpassword,
      'status' => 1,
      'role' => 'superadmin',
      'done_by' => $c_doneby,
      'company_name' => '',
      'company_logo' => '',
      'created' => $c_date,
    ];
    $action_id = uniqid(true);
    $data1 = [
      'action_id' => $action_id,
      'action_type' => 'create',
      'action_name' => 'Create Super Admin',
      'module_id' => $admin_id,
      'deleted_by' => $c_name,
      'done_by' => $this->session->userdata('user_id'),
      'created' => date('Y-m-j H:i:s'),
    ];

    if ($thisid !== '63a9739adf7d9') {
      $result = [0 => 'fail'];

      return $result;
    } else {
      $res = $this->db->insert('ap_users', $data);
      $res1 = $this->db->insert('ap_action', $data1);
      if ($res && $res1) {
        $result = [0 => 'success'];

        return $result;
      } else {
        $result = [0 => 'fail'];

        return $result;
      }
    }
  }

  /*active*/

  public function UpdateSuperadminById($deleteid, $sid)
  {
    $a_status = $sid == 1 ? 0 : 1;
    $result = [0 => ''];
    $query = $this->db->query('update ap_users set status="' . $a_status . '" where user_id ="' . $deleteid . '"');
    if ($query) {
      $result = [0 => 'success'];

      return $result;
    } else {
      $result = [0 => 'fail'];

      return $result;
    }
  }

  /*Delete permanently*/

  public function DeleteSuperAdminById($deleteid)
  {
    $result = [0 => ''];
    date_default_timezone_set('Asia/Calcutta');
    $action_id = uniqid(true);
    $name_res = $this->db->query('select username from ap_users where user_id="' . $deleteid . '"')->result();
    $data1 = [
      'action_id' => $action_id,
      'action_type' => 'delete',
      'action_name' => 'Delete Superadmin',
      'module_id' => $deleteid,
      'deleted_by' => $name_res[0]->username,
      'done_by' => $this->session->userdata('user_id'),
      'created' => date('Y-m-j H:i:s'),
    ];
    $res1 = $this->db->insert('ap_action', $data1);
    $query = $this->db->query('delete from ap_users where user_id ="' . $deleteid . '"');
    if ($query && $res1) {
      $result = [0 => 'success'];

      return $result;
    } else {
      $result = [0 => 'fail'];

      return $result;
    }
  }

  //update superadmin
  public function update_super_admin($c_email, $c_password, $c_orgpassword, $admin_id)
  {
    date_default_timezone_set('Asia/Calcutta');
    $result = [0 => ''];
    $thisid = $this->session->userdata('user_id');
    $action_id = uniqid(true);
    $name_res = $this->db->query('select username from ap_users where user_id="' . $admin_id . '"')->result();

    $res = $this->db->query('update ap_users set username="' . $c_email . '",password="' . $c_password . '",org_password	="' . $c_orgpassword . '" where user_id="' . $admin_id . '"');

    $data1 = [
      'action_id' => $action_id,
      'action_type' => 'update',
      'action_name' => 'Update Superadmin',
      'module_id' => $admin_id,
      'deleted_by' => $name_res[0]->username,
      'done_by' => $this->session->userdata('user_id'),
      'created' => date('Y-m-j H:i:s'),
    ];
    $res1 = $this->db->insert('ap_action', $data1);

    if ($thisid !== '63a9739adf7d9') {
      $result = [0 => 'fail'];

      return $result;
    } else {
      if ($res && $res1) {
        $result = [0 => 'success'];

        return $result;
      } else {
        $result = [0 => 'fail'];

        return $result;
      }
    }
  }

  public function getsinglesuperdetails($f_id)
  {
    $this->db->select('*');
    $this->db->from('ap_users');
    $this->db->where('user_id', $f_id);
    $this->db->limit(1);
    $query = $this->db->get();
    $res = $query->result();
    if ($res) {
      return $res;
    }
  }

  //get all user active details

  public function alladminuserlistname() {

    $table = $this->datatables->select('u.username as u_username,u.email as u_email,u.phone as u_phone,u.status as u_status,u.created as u_created,u.done_by as u_done_by,u.role as u_role')
            ->from("ap_users as u")
            ->select("a.user_id as a_user_id,a.company_name as a_company_name,a.company_logo as a_company_logo,a.username as a_username")
            ->join("ap_users as a","u.done_by=a.user_id")
            ->where("u.role","user")
            ->add_column("custom_logo", '<img src="' . base_url() . '/docs/customerlogo/$1" alt="$2" class="c_logo_style" />', "a_company_logo,a_company_name")
            ->generate();
    return $table;


  }



//   public function GetCustomerListsSuper()
//   {
//     $arr = [];
//     $arr['clist'] = '<table id="customer_view" class="display dataTable">';
//     $this->db->select('u.user_id,u.username as a_username,u.company_name as a_company_name,u.company_logo as a_company_logo, a.*');
//     $this->db->from('ap_users as u');
//     $this->db->join('ap_users as a', 'a.user_id=u.done_by');
//     $this->db->where('u.role', 'user');
//     $query = $this->db->get();

//     $row = $query->result_array();
//     $arr['customer_list_count'] = count($row);
//     $arr['clist'] .= '
//  <thead>
//  <tr>
//  <th>S No</th>
//   <th>Company Name</th>
//   <th>Logo</th>
//   <th>Done By</th>
//   <th>Username</th>
//  <th>Email Address</th>
//  <th>Phone Number</th>
//  <th>Status</th>
//  <th>Joining Date</th>
 
//  </thead>';
//     if ($row) {
//       $arr['clist'] .= '<tbody>';
//       for ($i = 0; $i < count($row); ++$i) {
//         $cid = $row[$i]['user_id'];
//         $comname = $row[$i]['company_name'];
//         $cname = $row[$i]['a_username'];
//         $caname = $row[$i]['username'];
//         $logo = $row[$i]['company_logo'];
//         $cemail = $row[$i]['email'];
//         $cphone = $row[$i]['phone'];
//         $cstatus = $row[$i]['status'];
//         $jdate = date_create($row[$i]['created']);

//         $arr['clist'] .= '
//  <tr>
//  <td>' . ($i + 1) . '</td>

//  <td>' . $comname . '</td>
//  <td><img src="' . base_url('docs/customerlogo/' . $logo . '') . '" class="overall_logo" /></td>
//  <td>' . $caname . '</td>
//  <td>' . $cname . '</td>
//  <td>' . $cemail . '</td>
//  <td>' . $cphone . '</td>
//  <td>' . ($cstatus == 1 ? '<button class="a_btn status_update" data-uid="' . $cid . '" data-sid="' . $cstatus . '">Active</button>' : '<button class="ina_btn status_update" data-uid="' . $cid . '" data-sid="' . $cstatus . '">Inactive</button>') . '</td>
//  <td>' . date_format($jdate, 'd-M-Y') . '</td>
//  </tr>';
//       }
//     } else {
//       $arr['clist'] .= '<tbody>';
//     }
//     $arr['clist'] .= '</tbody></table>';

//     return $arr;
//   }

  /*active*/

  //all enquiry

//   public function getallenquiry()
//   {
//     $arr = [];
//     $arr['elist'] = '<table id="customer_view" class="display dataTable">';
//     $c_user = $this->session->userdata('user_id');

//     $this->db->select('*');
//     $this->db->from('ap_enquiry as en');
//     $this->db->select('us.user_id as us_user_id,us.company_name as us_company_name,us.company_logo as us_company_logo')->join('ap_users as us', 'us.user_id=en.admin_id');
//     $this->db->select('d.user_id as d_user_id,d.username as d_username,d.company_name as d_company_name,d.company_logo as d_company_logo')->join('ap_users as d', 'd.user_id=en.done_by');
//     $this->db->where('en.enq_status', 1);
//     $this->db->order_by('en.created', 'DESC');
//     $query = $this->db->get();

//     $row = $query->result_array();
//     $arr['elist'] .= '
// <thead>
// <tr>
// <th>S No</th>
// <th>Company Name</th>
// <th>Logo</th>
// <th>Done by</th>
// <th>Enquiry Name</th>
// <th>Phone Number</th>
// <th>Enquiry Date</th>

// <th>Project</th>
// </thead>';
//     $arr['elist_count'] = count($row);
//     if ($row) {
//       $arr['elist'] .= '<tbody>';
//       for ($i = 0; $i < count($row); ++$i) {
//         $cid = $row[$i]['enquiry_id'];
//         $cname = $row[$i]['enq_name'];
//         $cphone = $row[$i]['enq_contact_number'];
//         $cdate = date_create($row[$i]['enq_date']);

//         $cprojectname = explode('|', $row[$i]['project_id']);

//         $u_company_name = $row[$i]['us_company_name'];
//         $u_company_logo = $row[$i]['us_company_logo'];
//         $d_done_by = $row[$i]['d_username'];

//         $arr['elist'] .= '
//   <tr>
//   <td>' . ($i + 1) . '</td>
//   <td>' . $u_company_name . '</td>
//   <td><img src="' . base_url('docs/customerlogo/' . $u_company_logo . '') . '" class="overall_logo" /></td>
//   <td>' . $d_done_by . '</td>
//   <td>' . $cname . '</td>
//   <td>' . $cphone . '</td>
//   <td>' . date_format($cdate, 'd-M-Y') . '</td>

//   <td>' . $cprojectname[1] . '</td>
//   </tr>';
//       }
//     } else {
//       $arr['elist'] .= '<tbody>';
//     }
//     $arr['elist'] .= '</tbody></table>';

//     return $arr;
//   }

  //all enquiry


public function alladminfollowuplist($postData=null) {

    $statusFilter = $postData['statusFilter'];
    $doneBy = $postData['doneBy'];
    $startDate = $postData['startDate'];
    $endDate = $postData['endDate'];
    // $typePage = $postData['typePage'];

    $this->datatables->select('f.follow_up_id as f_follow_up_id,f.enquiry_id as f_enquiry_id,f.admin_id as f_admin_id,f.superadmin_id as f_superadmin_id,f.follow_up_msg as f_follow_up_msg,f.project_id as f_project_id,f.follow_up_status as f_follow_up_status,f.nxt_follow_up_date as f_nxt_follow_up_date,f.nxt_follow_up_hint as f_nxt_follow_up_hint,f.done_by as f_done_by,f.created as f_created');
    $this->datatables->from('ap_followup_progress as f');
    $this->datatables->select('e.enquiry_id as e_enquiry_id,e.enq_name as e_enq_name,e.enq_contact_number as e_enq_contact_number,e.enq_date as e_enq_date,e.enq_location as e_enq_location,e.enq_msg as e_enq_msg,e.project_id as e_project_id,e.enq_status as e_enq_status');
    $this->datatables->join("ap_enquiry as e", "e.enquiry_id=f.enquiry_id");
    $this->datatables->select('u.username as u_username,u.user_id as u_user_id,u.admin_id as u_admin_id,u.company_name as u_company_name,u.company_logo as u_company_logo');
    $this->datatables->join("ap_users as u", 'u.user_id=f.done_by');
    $this->datatables->add_column('custom_logo', '<img src="' . base_url('docs/customerlogo/$1') . '" class="overall_logo" />', 'u_company_logo');
    // if ($typePage == "pending") {
    //   $this->datatables->where("f.follow_up_status", "pending");
    // } elseif ($typePage == "followup") {
    //   $this->datatables->where("f.follow_up_status", 'followup');
    // } elseif ($typePage == "cancel") {
    //   $this->datatables->where("f.follow_up_status", "cancel");
    // } elseif ($typePage == "rejected") {
    //   $this->datatables->where("f.follow_up_status", "rejected");
    // } elseif ($typePage == "noresponse") {
    //   $this->datatables->where("f.follow_up_status", "noresponse");
    // } elseif ($typePage == "completed") {
    //   $this->datatables->where("f.follow_up_status", "completed");
    // }
    if ($statusFilter == "pending") {
      $this->datatables->where("f.follow_up_status", "pending");
    } elseif ($statusFilter == "followup") {
      $this->datatables->where("f.follow_up_status", 'followup');
    } elseif ($statusFilter == "cancel") {
      $this->datatables->where("f.follow_up_status", "cancel");
    } elseif ($statusFilter == "rejected") {
      $this->datatables->where("f.follow_up_status", "rejected");
    } elseif ($statusFilter == "noresponse") {
      $this->datatables->where("f.follow_up_status", "noresponse");
    } elseif ($statusFilter == "completed") {
      $this->datatables->where("f.follow_up_status", "completed");
    }
    if ($doneBy != "") {
      $this->datatables->where("f.done_by", $doneBy);
    }
    if ($startDate != "" && $endDate != "") {
      $this->datatables->where("DATE(f.created) >=", $startDate);
      $this->datatables->where("DATE(f.created) <=", $endDate);
    }
    // if ($typePage == "recent") {
    //   $startDate = date('Y-m-j H:i:s', strtotime("-30 days"));
    //   $endDate   = date('Y-m-j H:i:s', strtotime("now"));
    //   $this->datatables->where("DATE(f.created) >=", $startDate);
    //   $this->datatables->where("DATE(f.created) <=", $endDate);
    // } elseif ($typePage == "next") {
    //   $endDate   = date('Y-m-j H:i:s', strtotime("now"));
    //   $this->datatables->where("DATE(f.nxt_follow_up_date) >=", $endDate);
    // }
    $this->datatables->add_column('action', '<div class="action_btn new_btn">
      <button class="view_followup $2" type="submit" data-fid="$1"> <img src="' . base_url() . 'assets/images/view.png" />  </button>
      <button class="notify_followup" type="submit" data-fid="$2" data-eid="$1" data-status="$3" data-aid="$4"> <img src="' . base_url() . 'assets/images/bell.png" />  </button>

      
       </div>', 'f_enquiry_id,f_follow_up_id,f_follow_up_status,u_user_id');
    $table = $this->datatables->generate();

    return $table;

}


  public function get_company_user()
  {

    $query = $this->db->query('select user_id,username from ap_users where (role="admin" and status=1)');
    return $query->result();
  }


//   public function getallfollowup()
//   {
//     $arr = [];
//     $arr['flist'] = '<table id="customer_view" class="display dataTable">';
//     $c_user = $this->session->userdata('admin_id');
//     $this->db->select('*');
//     $this->db->from('ap_enquiry as e');
//     $this->db->join('ap_followup_progress as f', 'f.enquiry_id=e.enquiry_id');
//     $this->db->select('us.user_id as us_user_id,us.company_name as us_company_name,us.company_logo as us_company_logo')->join('ap_users as us', 'us.user_id=f.admin_id');
//     $this->db->select('d.user_id as d_user_id,d.username as d_username,d.company_name as d_company_name,d.company_logo as d_company_logo')->join('ap_users as d', 'd.user_id=f.done_by');
//     // $this->db->order_by("f.created","DESC");
//     $query = $this->db->get();
//     $row = $query->result_array();

//     $arr['flist'] .= '
// <thead>
// <tr>
// <th>S No</th>
// <th>Company Name</th>
// <th>Logo</th>
// <th>Done By</th>
// <th>Project Name</th>
// <th>Enquiry Name</th>
// <th>Status</th>
// <th>Next Follow Up</th>
// <th>Action</th>
// </thead>';
//     $arr['flist_count'] = count($row);
//     if ($row) {
//       $arr['flist'] .= '<tbody>';
//       for ($i = 0; $i < count($row); ++$i) {
//         $fid = $row[$i]['follow_up_id'];
//         $f_proname = explode('|', $row[$i]['project_id'])[1];
//         $f_enqname = $row[$i]['enq_name'];

//         $f_status = $row[$i]['follow_up_status'];
//         $fdate = $row[$i]['nxt_follow_up_date'];
//         $u_company_name = $row[$i]['us_company_name'];
//         $u_company_logo = $row[$i]['us_company_logo'];
//         $follow_up_id = $row[$i]['follow_up_id'];
//         $enquiry_id = $row[$i]['enquiry_id'];
//         $follow_up_status = $row[$i]['follow_up_status'];
//         $d_done_by = $row[$i]['d_username'];
//         $us_user_id = $row[$i]['us_user_id'];

//         if ($f_status === 'pending' | $f_status === 'followup') {
//           $bclass = 'primary_status';
//         } elseif ($f_status === 'cancel' | $f_status === 'rejected' | $f_status === 'noresponse') {
//           $bclass = 'danger_status';
//         } elseif ($f_status === 'completed') {
//           $bclass = 'success_status';
//         }

//         $arr['flist'] .= '
// <tr>
// <td>' . ($i + 1) . '</td>
// <td>' . $u_company_name . '</td>
// <td><img src="' . base_url('docs/customerlogo/' . $u_company_logo . '') . '" class="overall_logo" /></td>
// <td>' . $d_done_by . '</td>
// <td>' . $f_proname . '</td>
// <td>' . $f_enqname . '</td>

// <td><button class="' . $bclass . '">' . $f_status . '</button></td>
// <td>' . $fdate . '</td>
// <td>

// <div class="action_btn">
//   <button class="btn btn-sm btn-primary view_followup ' . $follow_up_id . '" type="submit" data-fid="' . $enquiry_id . '"><i class="fa fa-eye"></i>  </button>
  
//   <button class="btn btn-sm btn-danger notify_followup" type="submit" data-fid="' . $follow_up_id . '" data-eid="' . $enquiry_id . '" data-status="' . $follow_up_status . '" data-aid="' . $us_user_id . '"><i class="fa fa-bell"></i>  </button>
//    </div>

// </td>
// </tr>';
//       }
//     } else {
//       $arr['flist'] .= '<tbody>';
//     }
//     $arr['flist'] .= '</tbody></table>';

//     return $arr;
//   }

  public function con_report_admin()
  {
    $query = $this->db->query('select * from ap_users where (role="user") order by created DESC');
    $query4 = $this->db->query('select * from ap_users where (role="admin") order by created DESC');
    $query5 = $this->db->query('select * from ap_users where (role="superadmin" and user_id<>"63a9739adf7d9") order by created DESC');
    $query1 = $this->db->query('select * from ap_enquiry where enq_status="1" order by created DESC');

    $this->db->select('*');
    $this->db->from('ap_enquiry as e');
    $this->db->join('ap_followup_progress as f', 'f.enquiry_id=e.enquiry_id');
    $query3 = $this->db->get();
    $res3 = $query3->result_array();

    $res = $query->result_array();
    $res1 = $query1->result_array();
    $res4 = $query4->result_array();
    $res5 = $query5->result_array();

    $result = '<div class="report_overview">
  <h2>Reports</h2>
  <ul>
    <a href="' . base_url('allcustomers') . '" title="Total Customers">
    <li>
      <i class="fa fa-user" aria-hidden="true"></i>
      <h4>' . count($res4) . '</h4>
      <p>Total Customers</p>
    </li>
    </a>
    <a href="' . base_url('allsuperadmin') . '" title="Total Superadmin">
    <li>
      <i class="fa fa-user" aria-hidden="true"></i>
      <h4>' . count($res5) . '</h4>
      <p>Total Superadmin</p>
    </li>
    </a>
    <a href="' . base_url('alluserslist') . '" title="All Users">
    <li>
      <i class="fa fa-user" aria-hidden="true"></i>
      <h4>' . count($res) . '</h4>
      <p>Total Users</p>
    </li>
    </a>
    <a href="' . base_url('allenquirylist') . '" title="All Enquiry">
    <li>
    <i class="fa fa-question-circle" aria-hidden="true"></i>
      <h4>' . count($res1) . '</h4>
      <p>Total Enquiry</p>
    </li>
    </a>
    <a href="' . base_url('allfollowuplist') . '" title="All Follow Up">
    <li>
      <i class="fa fa-thumbs-up" aria-hidden="true"></i>
      <h4>' . count($res3) . '</h4>
      <p>Total Follow Up</p>
    </li>
    </a>
  </ul>
</div>';

    return $result;
  }

  //get all customer active details

public function alladminreportaction() {

  $table = $this->datatables->select('ac.done_by as ac_done_by,ac.module_id as ac_module_id,ac.deleted_by as ac_deleted_by,ac.action_type as ac_action_type,ac.action_name as ac_action_name,ac.created as ac_created')
          ->from('ap_action as ac')
          ->select('d.username as d_username,d.user_id as d_user_id,d.role as d_role,d.status as d_status,d.company_name as d_company_name,d.company_logo as d_company_logo')
          ->join('ap_users as d', 'd.user_id=ac.done_by')
          ->generate();

    return $table;

}


//   public function GetActionLogLists()
//   {
//     $arr = [];
//     $arr['llist'] = '<table id="customer_view" class="display dataTable">';

//     // $query = $this->db->query('select * from ap_action order by created DESC');

//     $this->db->select('ac.done_by as ac_done_by,ac.module_id as ac_module_id,ac.deleted_by as ac_deleted_by,ac.action_type as ac_action_type,ac.action_name as ac_action_name,ac.created as ac_created')->from('ap_action as ac');
//     // $this->db->select("u.user_id as u_user_id,u.role as u_role,u.status as u_status,u.company_name as u_company_name,u.company_logo as u_company_logo")->join("ap_users as u","u.admin_id=ac.done_by");
//     $this->db->select('d.username as d_username,d.user_id as d_user_id,d.role as d_role,d.status as d_status,d.company_name as d_company_name,d.company_logo as d_company_logo')->join('ap_users as d', 'd.user_id=ac.done_by');
//     // $this->db->order_by("ac.created","DESC");
//     $query = $this->db->get();

//     $arr['llist'] .= '
//     <thead>
//     <tr>
//     <th>S No</th>
//     <th>Done By</th>
//     <th>Action Type</th>
//     <th>Action Name</th>
//     <th>Module Id</th>
//     <th>Module Name</th>
    
//     <th>Created</th>
   
//     </thead>';

//     $row = $query->result_array();
//     $arr['customer_list_count'] = count($row);
//     if ($row) {
//       $arr['llist'] .= '<tbody>';
//       for ($i = 0; $i < count($row); ++$i) {
//         $action_type = $row[$i]['ac_action_type'];
//         $action_name = $row[$i]['ac_action_name'];
//         $module_id = $row[$i]['ac_module_id'];
//         $ac_deleted_by = $row[$i]['ac_deleted_by'];
//         $done_by = $row[$i]['ac_done_by'];
//         $created = date_create($row[$i]['ac_created']);

//         if ($action_type === 'create') {
//           $bclass = 'primary_status';
//         } elseif ($action_type === 'delete') {
//           $bclass = 'danger_status';
//         } elseif ($action_type === 'update') {
//           $bclass = 'success_status';
//         }
//         $d_username = $row[$i]['d_username'];

//         $arr['llist'] .= '
//  <tr>
//  <td>' . ($i + 1) . '</td>

//  <td>' . $d_username . '</td>
//  <td><button class="' . $bclass . '">' . $action_type . '</button></td>
//  <td>' . $action_name . '</td>
//  <td>' . $module_id . '</td>
//  <td>' . $ac_deleted_by . '</td>

//  <td>' . date_format($created, 'd-M-Y h:i:s') . '</td>
 
//  </tr>';
//       }
//     } else {
//       $arr['llist'] .= '<tbody>';
//     }
//     $arr['llist'] .= '</tbody></table>';

//     return $arr;
//   }

  //view usetomer

  public function get_customerview_details_super($view_id)
  {
    $arr = [];
    $result = '';
    $this->db->select('*');
    $this->db->from('ap_followup_progress');
    $this->db->join('ap_enquiry', 'ap_followup_progress.enquiry_id=ap_enquiry.enquiry_id');
    $this->db->where('ap_enquiry.enquiry_id="' . $view_id . '"');
    $query = $this->db->get();

    $row = $query->result_array();

    // return $row;
    // $queryall = $this->db->query('select * from ap_followup_logs where (follow_up_id="'.$row[0]["follow_up_id"].'" and status=1) order by created DESC');
    $this->db->select('*');
    $this->db->from('ap_followup_logs as l');
    $this->db->select('user_id,username')->join('ap_users as u', 'u.user_id=l.done_by_log');
    $this->db->where('l.follow_up_id', $row[0]['follow_up_id'])->where('l.status', 1);
    $this->db->order_by('l.lcreated', 'DESC');
    $queryall = $this->db->get();
    $res7 = $queryall->result_array();
    $arr['clist'] = '';
    date_default_timezone_set('Asia/Calcutta');
    for ($i = 0; $i < count($res7); ++$i) {
      $follow_up_msg = $res7[$i]['follow_up_msg'];
      $username = $res7[$i]['username'];
      $follow_up_id = $res7[$i]['follow_up_id'];
      $follow_up_status = $res7[$i]['follow_up_status'];
      $nxt_follow_up_date = date_create($res7[$i]['nxt_follow_up_date']);
      $nxt_follow_up_hint = $res7[$i]['nxt_follow_up_hint'];
      $ap_followuplog_id = $res7[$i]['ap_followuplog_id'];
      $created = date_create($res7[$i]['lcreated']);

      if ($follow_up_status === 'pending' | $follow_up_status === 'followup') {
        $bclass = 'primary_status';
      } elseif ($follow_up_status === 'cancel' | $follow_up_status === 'rejected' | $follow_up_status === 'noresponse') {
        $bclass = 'danger_status';
      } elseif ($follow_up_status === 'completed') {
        $bclass = 'success_status';
      }

      $arr['clist'] .= '<hr style="border-style: dashed;" />
      <div class="f_delete_id">
      <h2>' . date_format($created, 'd-M-Y h:i:s') . '</h2>
     
      </div>
      <ul>
          <li>
            <span>Message:</span>
            <span>' . $follow_up_msg . '</span>
          </li>
          <li>
            <span>Status:</span>
            <span><button class="' . $bclass . '">' . $follow_up_status . '</button></span>
          </li>
          <li>
            <span>Next Follow Up:</span>
            <span>' . date_format($nxt_follow_up_date, 'd-M-Y h:i:s') . '</span>
          </li>
          <li>
            <span>Hint:</span>
            <span>' . $nxt_follow_up_hint . '</span>
          </li>
          <li>
            <span>Done By:</span>
            <span>' . $username . '</span>
          </li>
          
        </ul>
        
      ';
      $arr['clist'] .= '';
    }
    if ($row) {
      $result = '<div class="customer_view_details">
          <h2>Enquiry Details</h2>
          <ul>
            <li>
              <span>Enquiry Name:</span>
              <span>' . $row[0]['enq_name'] . '</span>
            </li>
            <li>
              <span>Enquiry Contact Number:</span>
              <span>' . $row[0]['enq_contact_number'] . '</span>
            </li>
            <li>
              <span>Enquiry Location:</span>
              <span>' . $row[0]['enq_location'] . '</span>
            </li>
            <li>
              <span>Enquiry Message:</span>
              <span>' . $row[0]['enq_msg'] . '</span>
            </li>
            <li>
              <span>Project Name:</span>
              <span>' . explode('|', $row[0]['project_id'])[1] . '</span>
            </li>
            
          </ul>
        </div>
        <hr />
        <div class="customer_view_details log_list">
        <div class="a_test">
          <h2>Total Follow up Progress(' . count($res7) . ')</h2>
          
          </div>
          ' .
        $arr['clist']
        .
        '
        </div>
       ';

      return $result;
    } else {
      return $result;
    }
  }
}

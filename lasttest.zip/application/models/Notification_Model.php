<?php
if (!defined('BASEPATH'))
  exit('No direct script access allowed');

class Notification_Model extends CI_Model
{
  public function __construct()
  {
    parent::__construct();
    $this->load->database();
    $this->load->library('email');
    $this->load->library('Datatables');
  }


  public function send_notification($follow_up_id, $admin_id, $enquiry_id, $status)
  {

   
    $result = array(0 => "");

    $query = $this->db->query('select * from ap_users where admin_id="' . $this->session->userdata("user_id") . '"')->result();

    // return $query;

    for ($j = 0; $j < count($query); $j++) {
      date_default_timezone_set("Asia/Calcutta");
      $notification_id = uniqid(true);
      $data = array(
        "notification_id" => $notification_id,
        "notification_name" => "Create Followup Notification",
        "admin_id" => $this->session->userdata("user_id"),
        "enquiry_id" => $enquiry_id,
        "follow_up_id" => $follow_up_id,
        "follow_up_status" => $status,
        "user_id" => $query[$j]->user_id,
        "status" => 1,
        "done_by" => $this->session->userdata("user_id"),
        "created" => date('Y-m-j H:i:s'),
      );

      $res = $this->db->insert("ap_notification", $data);
    }

    if ($res) {
      $result = array(0 => "success");
      return $result;
    } else {
      $result = array(0 => "fail");
      return $result;
    }
  }


  public function send_notification_super($follow_up_id, $admin_id, $enquiry_id, $status)
  {

   
    $result = array(0 => "");

    $query = $this->db->query('select * from ap_users where (admin_id="' . $admin_id. '" or user_id="'.$admin_id.'")')->result();

     //return $query;

    for ($j = 0; $j < count($query); $j++) {
      date_default_timezone_set("Asia/Calcutta");
      $notification_id = uniqid(true);
      $data = array(
        "notification_id" => $notification_id,
        "notification_name" => "Create Followup Notification",
        "admin_id" => $admin_id,
        "enquiry_id" => $enquiry_id,
        "follow_up_id" => $follow_up_id,
        "follow_up_status" => $status,
        "user_id" => $query[$j]->user_id,
        "status" => 1,
        "done_by" => $this->session->userdata("user_id"),
        "created" => date('Y-m-j H:i:s'),
      );

      $res = $this->db->insert("ap_notification", $data);
    }

    if ($res) {
      $result = array(0 => "success");
      return $result;
    } else {
      $result = array(0 => "fail");
      return $result;
    }
  }


  public function get_singleuser_notification()
  {
    $arr = array();


    $query = $this->db->select('n.notification_id as n_notification_id,n.notification_name as n_notification_name,n.admin_id as n_admin_id,n.enquiry_id as n_enquiry_id,n.follow_up_id as n_follow_up_id,n.user_id as n_user_id,n.status as n_status,n.created as n_created,count(n.user_id) as total')
      ->from('ap_notification as n')
      ->select('e.enq_name,e.enquiry_id')
      ->join('ap_enquiry as e', 'e.enquiry_id=n.enquiry_id', "LEFT")
      ->where('n.user_id="' . $this->session->userdata("user_id") . '" and n.status=1')
      ->select('u.user_id as u_user_id,u.username as u_username')
      ->join('ap_users as u','u.user_id=n.done_by')
      ->group_by('n.follow_up_id,n.user_id')
      ->where("e.enquiry_id<>",null)
      ->order_by('n.created',"DESC")
      ->get();

    $query1 = $this->db->select('n.notification_id as n_notification_id,n.notification_name as n_notification_name,n.admin_id as n_admin_id,n.enquiry_id as n_enquiry_id,n.follow_up_id as n_follow_up_id,n.user_id as n_user_id,n.status as n_status,n.created as n_created,count(n.user_id) as total,n.done_by as n_done_by')
      ->from('ap_notification as n')
      ->select('e.enq_name,e.enquiry_id')
      ->join('ap_enquiry as e', 'e.enquiry_id=n.enquiry_id', "LEFT")
      ->where('n.user_id="' . $this->session->userdata("user_id") . '" and n.status=1')
      ->group_by('n.user_id')
      ->where("e.enquiry_id<>",null)
      ->get();

    $row = $query->result_array();
    $row1 = $query1->result_array();

     // return $row;

    //  return $row;
    if ($row) {
      $arr["clist"] = "";
      for ($i = 0; $i < count($row); $i++) {
        // if($row[$i]["enq_name"]!="null" && $row[$i]["enquiry_id"]!="null") { continue;}
        $enq_name = $row[$i]["enq_name"];
        $enquiry_id = $row[$i]["enquiry_id"];
        $n_admin_id = $row[$i]["n_admin_id"];
        $n_created = $row[$i]["n_created"];
        $n_enquiry_id = $row[$i]["n_enquiry_id"];
        $n_follow_up_id = $row[$i]["n_follow_up_id"];
        $n_notification_id = $row[$i]["n_notification_id"];
        $n_notification_name = $row[$i]["n_notification_name"];
        $u_username = $row[$i]["u_username"];
        $n_status = $row[$i]["n_status"];
        $n_user_id = $row[$i]["n_user_id"];
        $total = $row[$i]["total"];
        $arr["clist"] .= '
        <div class="notification_boxs">
        <i class="fa fa-info-circle info_notification success" aria-hidden="true"></i>
        <a href="' . ($this->session->userdata("user_in") ? base_url("followupprogressuser?enq_id='.$enquiry_id.'") : base_url("followupprogress?enq_id='.$enquiry_id.'")) . '" title="' . $enq_name . '"><p>' . $enq_name . ' <span> -by '.$u_username.'</span></p></a>
        <div class="n_btn_align">
          <button class="btn btn-sm btn-danger n_btn view_notify_message" data-fid="' . $n_follow_up_id . '" data-uid="' . $n_user_id . '"><i class="bi bi-chat-left-text"></i>View Message(' . $total . ')</button>
          <a href="' .($this->session->userdata("user_in") ? base_url("followupprogressuser?enq_id='.$enquiry_id.'") : base_url("followupprogress?enq_id='.$enquiry_id.'")). '" title="' . $enq_name . '"><button class="btn btn-sm btn-primary n_btn"><i class="bi bi-eye"></i>View Details</button></a>
        </div>
       
        <i class="fa fa-close close_notification" aria-hidden="true" data-fid="' . $n_follow_up_id . '" data-uid="' . $n_user_id . '" title="Close"></i>
       
        </div>
      <hr style="border-style: dashed;margin:0.7em 0;" />
      ';
        $arr["clist"] .= "";
      
}



      if ($this->session->userdata("user_in") || $this->session->userdata("admin_in")) {
        $result = '<a class="nav-link nav-icon" href="javascript:void(0)" data-bs-toggle="dropdown">
    <i class="bi bi-bell"></i>
    <span class="badge bg-danger badge-number notify_count">' . $row1[0]['total'] . '</span>
  </a>

  <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow notifications" style="width:320px;">
    <li class="dropdown-header">
      You have ' . $row1[0]['total'] . ' new notifications
    </li>
    <li>
      <hr class="dropdown-divider">
    </li>
      ' . $arr["clist"] . '

  </ul>';
      }

      return $result;
    }

    $result = '<a class="nav-link nav-icon" href="javascript:void(0)" data-bs-toggle="dropdown">
  <i class="bi bi-bell"></i>
  <span class="badge bg-danger badge-number notify_count">0</span>
</a>

<ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow notifications" style="width:320px;">
  <li class="dropdown-header">
    You have 0 new notifications
  </li>
  

</ul>';


    return $result;
  }


  public function remove_current_notify($notify_id, $user_id)
  {

    $query = $this->db->query('update ap_notification set status="0" where (follow_up_id="' . $notify_id . '" and user_id="' . $user_id . '")');

    if ($query) {
      $result = array(0 => "success");
      return $result;
    } else {
      $result = array(0 => "fail");
      return $result;
    }
  }


  public function show_notify_message($notify_id,$user_id)
  {
    $arr = array();
    $query = $this->db->select('n.notification_id as n_notification_id,n.notification_name as n_notification_name,n.admin_id as n_admin_id,n.enquiry_id as n_enquiry_id,n.follow_up_id as n_follow_up_id,n.follow_up_status as n_follow_up_status,n.user_id as n_user_id,n.status as n_status,n.created as n_created')
      ->from('ap_notification as n')
       ->select('e.enq_name,e.enquiry_id')
       ->join('ap_enquiry as e', 'e.enquiry_id=n.enquiry_id', "LEFT")
      ->where('n.user_id="' . $this->session->userdata("user_id") . '" and n.follow_up_id="'.$notify_id.'" and n.status=1')
      ->order_by('n.created','DESC')
      ->get()
      ->result_array();

    //  return count($query);
    if($query) {
      $arr["n_list"] = "";
    for($i=0; $i<count($query); $i++) {
      
      $enq_name = $query[$i]["enq_name"];
      $enquiry_id = $query[$i]["enquiry_id"];
      $n_admin_id = $query[$i]["n_admin_id"];
      $n_created = date_create($query[$i]["n_created"]);
      $n_enquiry_id = $query[$i]["n_enquiry_id"];
      $n_follow_up_id = $query[$i]["n_follow_up_id"];
      $n_follow_up_status = $query[$i]["n_follow_up_status"];
      $n_notification_id = $query[$i]["n_notification_id"];
      $n_notification_name = $query[$i]["n_notification_name"];
      $n_status = $query[$i]["n_status"];
      $n_user_id = $query[$i]["n_user_id"];

      if ($n_follow_up_status === "pending" | $n_follow_up_status === "followup") {
        $bclass = "primary_status";
      } elseif ($n_follow_up_status === "cancel" | $n_follow_up_status === "rejected" | $n_follow_up_status === "noresponse") {
        $bclass = "danger_status";
      } elseif ($n_follow_up_status === "completed") {
        $bclass = "success_status";
      }
      
      
      $arr["n_list"] .= '

      <div class="n_notify_box">
        <div class="top_row_3">
          <p><b>Date: </b>'.date_format($n_created,"d-M-Y h:i:s").'</p>
          
          <p class="read_status">'.($n_status==1 ? "Un Read" : "Read").'</p>
        </div>
        <p><b>Enquiry Name: </b>'.$enq_name.'</p>
        <div class="top_row_3">
        <p><b>Status: </b><button class="' . $bclass . '">' . $n_follow_up_status . '</button></p>
        <p><a href="' . ($this->session->userdata("admin_in") ? base_url("followupprogress?enq_id='.$n_enquiry_id.'") : base_url("followupprogressuser?enq_id='.$n_enquiry_id.'") ). '" title="' . $enq_name . '"><button class="btn btn-sm btn-primary"><i class="bi bi-eye"></i> View Details</button></a></p>
        </div>
      </div>
        <hr style="border-style: dashed;" />
      
      ';
      

      $arr["n_list"] .= "";
      
      $result = $arr["n_list"];
    }

    

    return $result;

  }



  }




  
  public function show_notify_message_all($notify_id,$user_id)
  {
    $arr = array();
    $query = $this->db->select('n.notification_id as n_notification_id,n.notification_name as n_notification_name,n.admin_id as n_admin_id,n.enquiry_id as n_enquiry_id,n.follow_up_id as n_follow_up_id,n.follow_up_status as n_follow_up_status,n.user_id as n_user_id,n.status as n_status,n.created as n_created')
      ->from('ap_notification as n')
       ->select('e.enq_name,e.enquiry_id')
       ->join('ap_enquiry as e', 'e.enquiry_id=n.enquiry_id', "LEFT")
       ->select('u.user_id as u_user_id,u.username as u_username')
      ->join('ap_users as u','u.user_id=n.done_by')
      ->where('n.user_id="' . $this->session->userdata("user_id") . '" and n.follow_up_id="'.$notify_id.'"')
      // ->order_by('n.created')
      ->order_by('n.created', "asc")
      ->get()
      ->result_array();


      //return $query;
      

    //  return count($query);
    if($query) {
      $arr["n_list"] = "";
    for($i=0; $i<count($query); $i++) {
      
      $enq_name = $query[$i]["enq_name"];
      $enquiry_id = $query[$i]["enquiry_id"];
      $n_admin_id = $query[$i]["n_admin_id"];
      $n_created = date_create($query[$i]["n_created"]);
      $n_enquiry_id = $query[$i]["n_enquiry_id"];
      $n_follow_up_id = $query[$i]["n_follow_up_id"];
      $n_follow_up_status = $query[$i]["n_follow_up_status"];
      $n_notification_id = $query[$i]["n_notification_id"];
      $n_notification_name = $query[$i]["n_notification_name"];
      $u_username = $query[$i]["u_username"];
      $n_status = $query[$i]["n_status"];
      $n_user_id = $query[$i]["n_user_id"];

      if ($n_follow_up_status === "pending" | $n_follow_up_status === "followup") {
        $bclass = "primary_status";
      } elseif ($n_follow_up_status === "cancel" | $n_follow_up_status === "rejected" | $n_follow_up_status === "noresponse") {
        $bclass = "danger_status";
      } elseif ($n_follow_up_status === "completed") {
        $bclass = "success_status";
      }
      
      $arr["n_list"] .= '

      <div class="n_notify_box">
        <div class="top_row_3">
          <p><b>Date: </b>'.date_format($n_created,"d-M-Y h:i:s").'<span class="n_by"> -by '.$u_username.'</span></p>
          
          <p class="read_status">'.($n_status==1 ? "Un Read" : "Read").'</p>
        </div>
        <p><b>Enquiry Name: </b>'.$enq_name.'</p>
        <div class="top_row_3">
        <p><b>Status: </b><button class="' . $bclass . '">' . $n_follow_up_status . '</button></p>
        <p><a href="' . ($this->session->userdata("admin_in") ? base_url("followupprogress?enq_id='.$n_enquiry_id.'") : base_url("followupprogressuser?enq_id='.$n_enquiry_id.'") ) . '" title="' . $enq_name . '"><button class="btn btn-sm btn-primary"><i class="bi bi-eye"></i> View Details</button></a></p>
        </div>
      </div>
        <hr style="border-style: dashed;" />
      
      ';
      

      $arr["n_list"] .= "";
      
      $result = $arr["n_list"];
    }

    

    return $result;

  }



  }


















}

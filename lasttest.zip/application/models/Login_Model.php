<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Login_Model extends CI_Model
{

  public function __construct()
  {
    parent::__construct();
    $this->load->database();
    $this->load->library('email');
  }

  public function common_admin_login($username, $password)
  {
    $query = $this->db->query('select * from ap_users where (email="'. $username.'" or phone="'.$username.'") and password="'.$password. '" and status="1" and (role="superadmin" or role="admin" or role="user")');


    if ($query->num_rows() === 1) {
      return $query->result();
    } else {
      return false;
    }
  }


  public function CreateSession($s_user_id, $s_username, $s_admin_id, $s_superadmin_id, $s_email, $s_phone, $s_role, $s_intime, $s_browser, $s_platform, $s_ip)
  {
    $sess_id = uniqid();
    $this->session->set_userdata("session_id", $sess_id);

    $data = array(
      "session_id"=> $sess_id,
      "user_id"=> $s_user_id,
      "name"=> $s_username,
      "phone"=> $s_phone,
      "email"=> $s_email,
      "role"=> $s_role,
      "admin_id"=> $s_admin_id,
      "superadmin_id"=> $s_superadmin_id,
      "intime"=> $s_intime,
      "outtime"=>"",
      "status"=>"o",
      "ipaddress"=> $s_ip,
      "browser"=> $s_browser,
      "platform"=> $s_platform,
    );

    $result = $this->db->insert("ap_logs", $data);

    if ($result) {
      return true;
    } else {
      return false;
    }
  }

  public function EndSession()
  {
    date_default_timezone_set("Asia/Calcutta");
    $data = array(
      "outtime"=> date('Y-m-j H:i:s'),
      "status"=>"c",
    );
    $query = $this->db->where("session_id",$this->session->userdata("session_id"))->update("ap_logs",$data);

    if ($query) {
      return true;
    } else {
      return false;
    }
  }

  public function s_change_password($c_id, $c_newpass, $c_orgpass)
  {
    $result = array(0 => "");


    $query = $this->db->query('update ap_users set password="' . $c_newpass . '",org_password="' . $c_orgpass . '" where user_id="' . $c_id . '"');

    if ($query) {
      $result = array(0 => "success");
      return $result;
    } else {
      $result = array(0 => "fail");
      return $result;
    }
  }


  public function forgot_pass($deleteid) {

  $result = array(0=>"");
    $query = $this->db->query('select email,username,phone,user_id from ap_users where email="'.$deleteid.'"');

  
  
   

    

    if($query->num_rows()===1) {
      $res = $query->result();

      $u_email = $res[0]->email;
      $u_id = $res[0]->user_id;
      $u_name = $res[0]->username;
      $u_phone = $res[0]->phone;
      $email = $this->reset_email($u_email,$u_name,$u_phone,$u_id);
      if($email) {
        $result = array(0=>"success");
        return $result;
      } else {
        $result = array(0=>"efail");
      return $result;
      }
      
    } else {
      $result = array(0=>"failed");
      return $result;
    }

}


public function reset_email($u_email,$u_name,$u_phone,$u_id) {
  $passkey = $this->config->item('passkey');
      $length = 6;

$randompassword = substr(str_shuffle("0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"), 0, $length);

// $c_password = sha1($passkey . $randompassword);
// $org_password = $randompassword;


  $update = $this->db->query('update ap_users set password="'.sha1($passkey . $randompassword).'",org_password="'.$randompassword.'" where user_id="'.$u_id.'"');

  if($update) {
  $config['protocol']    = 'smtp';
  $config['smtp_host']    = 'ssl://smtp.gmail.com';
  $config['smtp_port']    = '465';
  $config['smtp_timeout'] = '7';
  $config['smtp_user']    = 'devlopsdemo@gmail.com';
  $config['smtp_pass']    = 'nfyunxrmdsgxmlmp';
  $config['charset']    = 'utf-8';
  $config['newline']    = "\r\n";
  $config['mailtype'] = 'html';
  $config['validation'] = TRUE;

  $this->email->initialize($config);
  $body  = '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.=w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"><html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"></head><body style="background:#F8F8F8; padding:20px;">
    <table style="background:#fff;border:0px solid #E8E8E8; border-radius:5px; border-collapse:collapse; overflow:hidden;padding:10px;margin:0 auto; font-size: 15px; width:600px"><tbody>
    <tr><td style="text-align:center; width:600px; color:#333; padding:20px;"><h1>Reset Password</h1></td></tr>
    <tr><td style="text-align:left; line-height:1.4em; padding:10px 20px; width:600px; color:#333;">
      Dear ' . $u_name . ',<br><br><h2>Login Details</h2><br /><p><b>Username: </b>' . $u_phone." (or) ".$u_email . '</p>
      <p><b>Password: </b> '.$randompassword.'</p>
    <tr><td style="text-align:left; padding:10px 20px; width:600px; color:#333;">&nbsp;</td></tr>
    
    <tr style="background:#EEEEEE; font-size: 12px;"><td style="text-align:center; padding:15px 20px; width:600px; color:#999;">Copyright &copy; 2023. All Rights Reserved. <a style="color:#ee8f0a; text-decoration:none;" href="javascript:void(0)">Blazon</a></td></tr>
    </tbody></table></body></html>';
  $subject  = "Reset Password - LMS";
  $this->email->from('devlopsdemo@gmail.com', 'Blazon');
  $this->email->to($u_email);
  $this->email->subject($subject);
  $this->email->message($body);

  $send = $this->email->send();

  if($send) {
    return true;
  } else {
    return false;
  }

} else {
  return false;
}

}




 
}

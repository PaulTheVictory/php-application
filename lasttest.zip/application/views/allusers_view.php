<?php
defined('BASEPATH') or exit('No direct script access allowed');
?>

<div class="enqiry_top_view">
  <button class="btn btn-primary add_project_new btn-sm"><i class="fa fa-plus" aria-hidden="true"></i> Add User</button>

</div>
<div class="enqiry_view">
  <div class="table_loading1">
    <div class="d-flex justify-content-center">
      <div class="spinner-border" role="status">
        <span class="visually-hidden">Loading...</span>
      </div>
    </div>
  </div>
  <div class="table_loading">

    <?php echo $this->table->generate();  ?>


  </div>
</div>


<div class="modal fade" id="projectmodel" tabindex="-1" aria-labelledby="projectmodeltitle" aria-hidden="true">
  <div class="modal-dialog modal-md">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="projectmodeltitle">Create User</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <?php if ($this->session->flashdata('notadded')) { ?>
          <?php echo $this->session->flashdata('notadded'); ?>
        <?php } ?>
        <?php if ($this->session->flashdata('form_error')) : ?>
          <?php echo $this->session->flashdata('form_error'); ?>
        <?php endif; ?>
        <?php echo form_open('allusers/newuser', 'method="post" accept-charset="utf-8" name="adduser" id="adduser"'); ?>
        <input type="text" name="username" placeholder="Name*" id="" value="<?php echo set_value('username', $this->session->userdata('username')); ?>" />
        <input type="text" name="c_email" placeholder="Email Address*" id="" value="<?php echo set_value('c_email', $this->session->userdata('c_email')); ?>" />
        <input type="text" name="c_phone" placeholder="Phone Number*" id="" value="<?php echo set_value('c_phone', $this->session->userdata('c_phone')); ?>" />
        <div class="password_group">
          <input type="password" name="password" placeholder="Password*" id="" value="<?php echo set_value('password', $this->session->userdata('password')); ?>" />
          <div class="toggle-password">
            <i class="fa fa-eye-slash" aria-hidden="true"></i>
          </div>
        </div>
        <button type="submit" name="submit" class="btn btn-primary">Create User</button>
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <!-- <button type="button" class="btn btn-primary">Save project</button> -->
      </div>
    </div>
  </div>
</div>


<div class="modal fade" id="customermodeledit" tabindex="-1" aria-labelledby="ecustomermodeltitle" aria-hidden="true">
  <div class="modal-dialog modal-md">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="ecustomermodeltitle">Edit User</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <?php echo validation_errors(); ?>
        <?php if ($this->session->flashdata('enotadded')) { ?>
          <?php echo $this->session->flashdata('enotadded'); ?>
        <?php } ?>
        <?php if ($this->session->flashdata('e_form_error')) : ?>
          <?php echo $this->session->flashdata('e_form_error'); ?>
        <?php endif; ?>
        <?php echo form_open_multipart('allusers/editcustomerbyid', 'method="post" accept-charset="utf-8" name="addcustomer" id="addcustomer"'); ?>


        <input type="hidden" name="u_id" id="u_id" value="<?php echo set_value('u_id', $this->session->userdata('u_id')); ?>" />
        <input type="text" name="u_username" placeholder="Name*" id="ecustomer_user_name" value="<?php echo set_value('u_username', $this->session->userdata('u_username')); ?>" />
        <div class="password_group">
          <input type="password" name="u_password" placeholder="Password*" id="ecustomer_password" value="<?php echo set_value('u_password', $this->session->userdata('u_password')); ?>" />
          <div class="toggle-password">
            <i class="fa fa-eye-slash" aria-hidden="true"></i>
          </div>
        </div>
        <button type="submit" name="submit" class="btn btn-success">Update User</button>
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <!-- <button type="button" class="btn btn-primary">Save project</button> -->
      </div>
    </div>
  </div>
</div>

<script>
  jQuery(document).ready(function($) {

    $('.toggle-password').click(function() {
      let input = $(this).prev();
      if (input.attr('type') === 'password') {
        $(this).children().removeClass('fa-eye-slash');
        $(this).children().addClass('fa-eye');
      } else {
        $(this).children().removeClass('fa-eye');
        $(this).children().addClass('fa-eye-slash');

      }
      input.attr('type', input.attr('type') === 'password' ? 'text' : 'password');
    });


    $(".table_loading").fadeOut();
    /*View User*/

    var DataTable = $('#customer_view').DataTable({
      'responsive': true,
      'language': {
        'loadingRecords': '&nbsp;',
        'processing': '<div class="d-flex justify-content-center"><img src="<?= base_url(); ?>assets/images/loader.gif" /></div>',

      },

      dom: 'Blfrtip',
      buttons: [

      ],
      'processing': true,
      'serverSide': true,
      "stateSave": true,
      "searching": true,
      'serverMethod': 'post',
      'ajax': {
        'url': '<?= base_url() ?>allusers/alladminuserlist',
        "dataType": "json",
        "type": "POST",
        "data": {}
      },
      initComplete: function() {
        $(".table_loading").fadeIn("100");
        $(".table_loading1").fadeOut();

      },
      "rowCallback": function(nRow, aData, iDisplayIndex) {
        var oSettings = this.fnSettings();
        $("td:first", nRow).html(oSettings._iDisplayStart + iDisplayIndex + 1);
        return nRow;
      },

      'columns': [{


        },
        {
          data: '3'
        },
        {
          data: '5'
        },
        {
          data: '4'
        },
        {
          data: '14',
          render: function(data, type, row, meta) {
            if (row[14] == 1) {
              return '<button class="a_btn status_update" data-uid="' + row[15] + '" data-sid="' + row[14] + '"> ' + 'active</button>';
            } else {
              return '<button class="ina_btn status_update" data-uid="' + row[15] + '" data-sid="' + row[14] + '"> ' + 'inactive</button>';
            }

          }
        },
        {
          data: '13'
        },
        {
          data: '0'
        },


      ],
      "columnDefs": [{
          "width": "4%",
          "targets": 0
        },
        {
          "width": "9%",
          "targets": 1
        },
        {
          "width": "10%",
          "targets": 2
        },
        {
          "width": "10%",
          "targets": 3
        },
        {
          "width": "7%",
          "targets": 4
        },
        {
          "width": "8%",
          "targets": 5
        },
        {
          "width": "4%",
          "targets": 6
        }

      ],

    });



    // $('#customer_view').DataTable({
    //   'responsive': true,
    //   "processing": true,
    //   "bInfo": false,
    //   "dom": 'Blfrtip',
    //   "bFilter": false,
    //   "deferRender": true,
    //   "autoWidth": false,
    //   "fixedHeader": {
    //     "header": false,
    //     "footer": false
    //   },
    //   initComplete: function() {
    //     $(".table_loading").fadeIn();
    //   },
    //   "destroy": true,
    //   searching: true,
    //   info: false,
    //   "columnDefs": [{
    //       "width": "4%",
    //       "targets": 0
    //     },
    //     {
    //       "width": "9%",
    //       "targets": 1
    //     },
    //     {
    //       "width": "10%",
    //       "targets": 2
    //     },
    //     {
    //       "width": "10%",
    //       "targets": 3
    //     },
    //     {
    //       "width": "7%",
    //       "targets": 4
    //     },
    //     {
    //       "width": "8%",
    //       "targets": 5
    //     },
    //     {
    //       "width": "4%",
    //       "targets": 6
    //     }

    //   ],
    // });




    /**/

    // $(document).on("click",".view_customer",function(){
    //   alert("test");
    // });  

    $(document).on("click", ".edit_customer", function(d) {
      d.preventDefault();
      var f_id = $(this).data('uid');
      $.ajax({
        url: "<?php echo base_url("allusers/getsinglecustomer"); ?>",
        type: "POST",
        data: {
          'f_id': f_id,
        },
        cache: false,
        success: function(data) {
          //alert(result);
          var dlt = $.parseJSON(data);
          //console.log(dlt["result"][0]);
          // console.log(dlt["result"][0].follow_up_id);
          $("#ecustomer_user_name").val(dlt["result"][0].username);
          $("#ecustomer_password").val(dlt["result"][0].org_password);
          $("#u_id").val(dlt["result"][0].user_id);


        }
      });
      $('#customermodeledit').modal('show');
    });

    $(document).on("click", ".delete_customer", function(d) {
      d.preventDefault();
      var deleteid = $(this).data('uid');
      swal({
          title: "Are you sure to delete?",
          text: "Not able to retrieve this file.",
          type: "warning",
          showCancelButton: true,
          confirmButtonColor: "#DD6B55",
          confirmButtonText: "Delete",
          cancelButtonText: "Cancel",
          closeOnConfirm: false,
          closeOnCancel: false
        },
        function(isConfirm) {
          if (isConfirm) {
            $.ajax({
              url: 'allusers/DeleteUser',
              type: 'POST',
              data: {
                'deleteid': deleteid
              },
              success: function(data) {
                var dlt = $.parseJSON(data);
                if (dlt[0] == 'success') {
                  swal("Deleted Successfully", "You clicked the button!", "success");
                  setTimeout(function() {
                    location.reload();
                  }, 500);
                } else if (dlt[0] == 'fail') {
                  swal("Could Not Deleted", "Something went Wrong!", "error");
                }
              }
            });
          } else {
            swal("Cancelled", "Your file is safe :)", "error");
          }
        });

    });


    //

    $(document).on("click", ".add_project_new", function(d) {
      d.preventDefault();
      $('#projectmodel').modal('show');
    });

    //update status

    $(document).on("click", ".status_update", function(d) {
      d.preventDefault();
      var updateid = $(this).data('uid');
      var sid = $(this).data('sid');
      swal({
          title: "Are you sure to update?",
          text: "able to change active & in active this file.",
          type: "warning",
          showCancelButton: true,
          confirmButtonColor: "#157347",
          confirmButtonText: "Update",
          cancelButtonText: "Cancel",
          closeOnConfirm: false,
          closeOnCancel: false
        },
        function(isConfirm) {
          if (isConfirm) {
            $.ajax({
              url: 'allusers/UpdateUser',
              type: 'POST',
              data: {
                'updateid': updateid,
                "sid": sid,
              },
              success: function(data) {
                var dlt = $.parseJSON(data);
                if (dlt[0] == 'success') {
                  swal("Updated Successfully", "You clicked the button!", "success");
                  setTimeout(function() {
                    location.reload();
                  }, 500);
                } else if (dlt[0] == 'fail') {
                  swal("Could Not Updated", "Something went Wrong!", "error");
                }
              }
            });
          } else {
            swal("Cancelled", "Your file is safe :)", "error");
          }
        });

    });



    //

    $(".alert").delay(4000).slideUp(200, function() {
      $(this).alert('close');
    });


  });
</script>


<?php if ($this->session->flashdata('notadded') || $this->session->flashdata('form_error')) { ?>
  <script>
    addEventListener("load", (event) => {
      $('#projectmodel').modal('show');
    });
  </script>

<?php } elseif ($this->session->flashdata("success")) { ?>
  <script type="text/javascript">
    addEventListener("load", (event) => {
      swal("Added Successfully", "You clicked the button!", "success");
    });
  </script>
<?php } ?>


<?php if ($this->session->flashdata('e_form_error') || $this->session->flashdata('enotadded')) { ?>


  <script>
    addEventListener("load", (event) => {
      $('#customermodeledit').modal('show');
    });
  </script>

<?php } elseif ($this->session->flashdata("esuccess")) { ?>
  <script type="text/javascript">
    addEventListener("load", (event) => {
      swal("Updated Successfully", "You clicked the button!", "success");
    });
  </script>
<?php } ?>
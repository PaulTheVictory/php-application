<?php
defined('BASEPATH') or exit('No direct script access allowed');
?>

<div class="enqiry_top_view">
  <button class="btn btn-primary add_customer_new btn-sm"><i class="fa fa-plus" aria-hidden="true"></i> Add New</button>
</div>
<div class="enqiry_view">


  <div class="table_loading1">
    <div class="d-flex justify-content-center">
      <div class="spinner-border" role="status">
        <span class="visually-hidden">Loading...</span>
      </div>
    </div>
  </div>
  <div class="table_loading">

    <?php echo $this->table->generate();  ?>


  </div>


</div>

<div class="modal fade" id="customermodel" tabindex="-1" aria-labelledby="customermodeltitle" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="customermodeltitle">Create Customer</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">


        <?php if ($this->session->flashdata('large')) { ?>
          <?php echo $this->session->flashdata('large'); ?>
        <?php } elseif ($this->session->flashdata('finalexit')) { ?>
          <?php echo $this->session->flashdata('finalexit'); ?>
        <?php } elseif ($this->session->flashdata('notadded')) { ?>
          <?php echo $this->session->flashdata('notadded'); ?>
        <?php } ?>
        <?php if ($this->session->flashdata('form_error')) : ?>
          <?php echo $this->session->flashdata('form_error'); ?>
        <?php endif; ?>
        <?php echo form_open_multipart('allcustomers/newcustomer', 'method="post" accept-charset="utf-8" name="addcustomer" id="addcustomer"'); ?>
        <div class="row_2">
          <input type="text" name="username" placeholder="Name*" id="username" value="<?php echo set_value('username', $this->session->userdata('username')); ?>" />
          <input type="text" name="company_name" placeholder="Company Name*" id="company_name" value="<?php echo set_value('company_name', $this->session->userdata('company_name')); ?>" />

        </div>
        <div class="row_2">
          <input type="text" name="c_email" placeholder="Email Address*" id="email" value="<?php echo set_value('c_email', $this->session->userdata('c_email')); ?>" />
          <input type="text" name="c_phone" placeholder="Phone Number*" id="phone" value="<?php echo set_value('c_phone', $this->session->userdata('c_phone')); ?>" />

        </div>
        <div class="row_1">
          <div class="password_group">
            <input type="password" name="password" placeholder="Password*" id="" value="<?php echo set_value('password', $this->session->userdata('password')); ?>" />
            <div class="toggle-password">
              <i class="fa fa-eye-slash" aria-hidden="true"></i>
            </div>
          </div>
          <div>
            <div id='img_contain'>
              <img id="customer_preview" src="<?= base_url("assets/images/logo_default.png") ?>" alt="your image" title='logo' />
            </div>
            <div class="image_design">
              <span>Upload your logo*</span>
              <input type="file" name="company_logo" placeholder="" id="company_logo" />
            </div>
          </div>
        </div>
        <button type="submit" name="submit" class="btn btn-primary">Create Customer</button>
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <!-- <button type="button" class="btn btn-primary">Save project</button> -->
      </div>
    </div>
  </div>
</div>


<div class="modal fade" id="customermodeledit" tabindex="-1" aria-labelledby="ecustomermodeltitle" aria-hidden="true">
  <div class="modal-dialog modal-md">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="ecustomermodeltitle">Edit Customer</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">

        <?php if ($this->session->flashdata('efinalexit')) { ?>
          <?php echo $this->session->flashdata('efinalexit'); ?>
        <?php } elseif ($this->session->flashdata('elarge')) { ?>
          <?php echo $this->session->flashdata('elarge'); ?>
        <?php } elseif ($this->session->flashdata('esuccess')) { ?>
          <?php echo $this->session->flashdata('esuccess'); ?>
        <?php } elseif ($this->session->flashdata('enotadded')) { ?>
          <?php echo $this->session->flashdata('enotadded'); ?>
        <?php } ?>
        <?php if ($this->session->flashdata('e_form_error')) : ?>
          <?php echo $this->session->flashdata('e_form_error'); ?>
        <?php endif; ?>
        <?php echo form_open_multipart('allcustomers/editcustomerbyid', 'method="post" accept-charset="utf-8" name="addcustomer" id="addcustomer"'); ?>
        <input type="hidden" name="u_id" id="customerid" value="<?php echo set_value('u_id', $this->session->userdata('u_id')); ?>" />
        <input type="text" name="e_username" placeholder="Name*" id="ecustomer_name" value="<?php echo set_value('e_username', $this->session->userdata('e_username')); ?>" />
        <div class="password_group">
          <input type="password" name="e_password" placeholder="Customer Password*" id="ecustomer_password" value="<?php echo set_value('e_password', $this->session->userdata('e_password')); ?>" />
          <div class="toggle-password">
            <i class="fa fa-eye-slash" aria-hidden="true"></i>
          </div>
        </div>
        <div id='img_contain'>
          <img id="ecustomer_preview" src="<?= base_url("assets/images/logo_default.png") ?>" alt="your image" title='' />
        </div>
        <div class="image_design">
          <span>Upload your logo*</span>
          <input type="file" name="company_logo" placeholder="" id="ecustomer_logo" />
        </div>
        <button type="submit" name="submit" class="btn btn-success">Update Customer</button>
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>

      </div>
    </div>
  </div>
</div>

<div class="modal fade" id="customerview" tabindex="-1" aria-labelledby="customerviewtitle" aria-hidden="true">
  <div class="modal-dialog modal-xl">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="customerviewtitle">View Customer</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <div id="result"></div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <!-- <button type="button" class="btn btn-primary">Save project</button> -->
      </div>
    </div>
  </div>
</div>


<script>
  jQuery(document).ready(function($) {

    $('.toggle-password').click(function() {
      let input = $(this).prev();
      if (input.attr('type') === 'password') {
        $(this).children().removeClass('fa-eye-slash');
        $(this).children().addClass('fa-eye');
      } else {
        $(this).children().removeClass('fa-eye');
        $(this).children().addClass('fa-eye-slash');

      }
      input.attr('type', input.attr('type') === 'password' ? 'text' : 'password');
    });

    /*View User*/

    $(".table_loading").fadeOut();
    /*View User*/

    var DataTable = $('#customer_view').DataTable({
      'responsive': true,
      'language': {
        'loadingRecords': '&nbsp;',
        'processing': '<div class="d-flex justify-content-center"><img src="<?= base_url(); ?>assets/images/loader.gif" /></div>',

      },

      dom: 'Blfrtip',
      buttons: [

      ],
      'processing': true,
      'serverSide': true,
      "stateSave": true,
      "searching": true,
      'serverMethod': 'post',
      'ajax': {
        'url': '<?= base_url() ?>allcustomers/alladminlistname',
        "dataType": "json",
        "type": "POST",
        "data": {}
      },
      initComplete: function() {
        $(".table_loading").fadeIn("100");
        $(".table_loading1").fadeOut();

      },
      "rowCallback": function(nRow, aData, iDisplayIndex) {
        var oSettings = this.fnSettings();
        $("td:first", nRow).html(oSettings._iDisplayStart + iDisplayIndex + 1);
        return nRow;
      },

      'columns': [{


        },
        {
          data: '3'
        },
        {
          data: '6'
        },
        {
          data: '5'
        },
        {
          data: '16'
        },
        {
          data: '9',
          render: function(data, type, row, meta) {
            if (row[9] == 1) {
              return '<button class="a_btn status_update" data-uid="' + row[0] + '" data-sid="' + row[9] + '"> ' + 'active</button>';
            } else {
              return '<button class="ina_btn status_update" data-uid="' + row[0] + '" data-sid="' + row[9] + '"> ' + 'inactive</button>';
            }

          }
        },
        {
          data: '15'
        },


      ],
      "columnDefs": [{
          "width": "6%",
          "targets": 0
        },
        {
          "width": "15%",
          "targets": 1
        },
        {
          "width": "15%",
          "targets": 2
        },
        {
          "width": "12%",
          "targets": 3
        },
        {
          "width": "10%",
          "targets": 4
        },
        {
          "width": "9%",
          "targets": 5
        },
        {
          "width": "6%",
          "targets": 6
        }
      ],

    });

    // $('#customer_view').DataTable({
    //   'responsive': true,
    //   "processing": true,
    //   "bInfo": false,
    //   "bFilter": false,
    //   "autoWidth": false,
    //   "fixedHeader": {
    //     "header": false,
    //     "footer": false
    //   },
    //   searching: true,
    //   info: false,
    //   "columnDefs": [{
    //       "width": "6%",
    //       "targets": 0
    //     },
    //     {
    //       "width": "15%",
    //       "targets": 1
    //     },
    //     {
    //       "width": "15%",
    //       "targets": 2
    //     },
    //     {
    //       "width": "12%",
    //       "targets": 3
    //     },
    //     {
    //       "width": "10%",
    //       "targets": 4
    //     },
    //     {
    //       "width": "9%",
    //       "targets": 5
    //     },
    //     {
    //       "width": "6%",
    //       "targets": 6
    //     }
    //   ],
    // });

    //
    $(document).on("click", ".add_customer_new", function(d) {
      d.preventDefault();
      $('#customermodel').modal('show');
    });


    //

    $(document).on("click", ".view_customer_new", function(d) {
      d.preventDefault();
      let view_id = $(this).data("uid");
      $.ajax({
        url: "<?php echo base_url("allcustomers/get_customerview"); ?>",
        type: "POST",
        data: {
          'view_id': view_id,
        },
        cache: false,
        success: function(data) {
          var dlt = $.parseJSON(data);
          $("#result").html(dlt);
        }
      });
      $('#customerview').modal('show');
    });

    //

    $(document).on("click", ".edit_customer_new", function(d) {
      d.preventDefault();
      let f_id = $(this).data("uid");
      $.ajax({
        url: "<?php echo base_url("allcustomers/getsinglecustomer"); ?>",
        type: "POST",
        data: {
          'f_id': f_id,
        },
        cache: false,
        success: function(data) {
          //alert(result);
          var dlt = $.parseJSON(data);
          console.log(dlt["result"][0]);
          // console.log(dlt["result"][0].follow_up_id);
          $("#ecustomer_name").val(dlt["result"][0].username);
          $("#ecustomer_email").val(dlt["result"][0].email);
          $("#ecustomer_password").val(dlt["result"][0].org_password);
          $("#ecustomer_phone").val(dlt["result"][0].phone);
          $('#ecustomer_preview').attr('src', base_url + "docs/customerlogo/" + dlt["result"][0].company_logo);
          $("#customerid").val(dlt["result"][0].user_id);


        }
      });
      $('#customermodeledit').modal('show');
    });



    //

    function readURL(input) {
      if (input.files && input.files[0]) {
        var reader = new FileReader();
        reader.onload = function(e) {
          $('#customer_preview').attr('src', e.target.result);
          $('#customer_preview').hide();
          $('#customer_preview').fadeIn(650);
        }
        reader.readAsDataURL(input.files[0]);
      }
    }

    $("#company_logo").change(function() {
      readURL(this);
    });
    //

    function readURL1(input) {
      if (input.files && input.files[0]) {
        var reader = new FileReader();
        reader.onload = function(e) {
          $('#ecustomer_preview').attr('src', e.target.result);
          $('#ecustomer_preview').hide();
          $('#ecustomer_preview').fadeIn(650);
        }
        reader.readAsDataURL(input.files[0]);
      }
    }

    $("#ecustomer_logo").change(function() {
      readURL1(this);
    });



    $(".alert").delay(4000).slideUp(200, function() {
      $(this).alert('close');
    });

    //

    $(document).on("click", ".delete_customer", function(d) {
      d.preventDefault();
      var deleteid = $(this).data('uid');
      swal({
          title: "Are you sure to delete?",
          text: "Not able to retrieve this file.",
          type: "warning",
          showCancelButton: true,
          confirmButtonColor: "#DD6B55",
          confirmButtonText: "Delete",
          cancelButtonText: "Cancel",
          closeOnConfirm: false,
          closeOnCancel: false
        },
        function(isConfirm) {
          if (isConfirm) {
            $.ajax({
              url: 'allcustomers/delete_customer',
              type: 'POST',
              data: {
                'deleteid': deleteid
              },
              success: function(data) {
                var dlt = $.parseJSON(data);
                if (dlt[0] == 'success') {
                  swal("Deleted Successfully", "You clicked the button!", "success");
                  setTimeout(function() {
                    location.reload();
                  }, 500);
                } else if (dlt[0] == 'fail') {
                  swal("Could Not Deleted", "Something went Wrong!", "error");
                }
              }
            });
          } else {
            swal("Cancelled", "Your file is safe :)", "error");
          }
        });

    });

    //update status

    $(document).on("click", ".status_update", function(d) {
      d.preventDefault();
      var updateid = $(this).data('uid');
      var sid = $(this).data('sid');
      swal({
          title: "Are you sure to update?",
          text: "able to change active & in active this file.",
          type: "warning",
          showCancelButton: true,
          confirmButtonColor: "#157347",
          confirmButtonText: "Update",
          cancelButtonText: "Cancel",
          closeOnConfirm: false,
          closeOnCancel: false
        },
        function(isConfirm) {
          if (isConfirm) {
            $.ajax({
              url: 'allcustomers/status_update_customer',
              type: 'POST',
              data: {
                'updateid': updateid,
                "sid": sid,
              },
              success: function(data) {
                var dlt = $.parseJSON(data);
                if (dlt[0] == 'success') {
                  swal("Updated Successfully", "You clicked the button!", "success");
                  setTimeout(function() {
                    location.reload();
                  }, 1500);
                } else if (dlt[0] == 'fail') {
                  swal("Could Not Updated", "Something went Wrong!", "error");
                }
              }
            });
          } else {
            swal("Cancelled", "Your file is safe :)", "error");
          }
        });

    });


  });
</script>

<?php if ($this->session->flashdata('form_error') || $this->session->flashdata('large') || $this->session->flashdata('notadded') || $this->session->flashdata('finalexit')) { ?>

  <script>
    addEventListener("load", (event) => {
      $('#customermodel').modal('show');
    });
  </script>
<?php } elseif ($this->session->flashdata("success")) { ?>
  <script type="text/javascript">
    addEventListener("load", (event) => {
      swal("Added Successfully", "You clicked the button!", "success");
    });
  </script>
<?php } ?>


<?php if ($this->session->flashdata('e_form_error') || $this->session->flashdata('elarge') || $this->session->flashdata('enotadded') || $this->session->flashdata('efinalexit')) { ?>

  <script>
    addEventListener("load", (event) => {
      $('#customermodeledit').modal('show');
    });
  </script>
<?php } elseif ($this->session->flashdata("esuccess")) { ?>
  <script type="text/javascript">
    addEventListener("load", (event) => {
      swal("Updated Successfully", "You clicked the button!", "success");
    });
  </script>
<?php } ?>
<?php
defined('BASEPATH') or exit('No direct script access allowed');
?>

<div class="enqiry_view">
<div class="table_load">
  <?php echo $enquirylist['elist']; ?>
</div>
</div>


<script>
  $(document).ready(function(){
    $(".table_load").fadeIn(400);
  });
</script>

<script>
  $(document).ready(function() {
  
    //

    $(".alert").delay(4000).slideUp(200, function() {
      $(this).alert('close');
    });

    //

    $('#customer_view').DataTable({
      'responsive': true,
      "processing": true,
      "bInfo": false,
      "bFilter": false,
      "autoWidth": false,
      "fixedHeader": {
        "header": false,
        "footer": false
    },
    searching: true,
    info: false,
      "columnDefs": [
      { "width": "5%", "targets": 0 },
      { "width": "12%", "targets": 1 },
      { "width": "7%", "targets": 2 },
      { "width": "8%", "targets": 3 },
      { "width": "13%", "targets": 4 },
      { "width": "10%", "targets": 5 },
      { "width": "9%", "targets": 6 },
      { "width": "9%", "targets": 7 }
    ],
    
    });

  });


</script>
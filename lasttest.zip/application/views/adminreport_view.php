 <?php
  defined('BASEPATH') or exit('No direct script access allowed');
  ?>

 <link href="<?php echo base_url(); ?>assets/report/css/bootstrap-datepicker.css" rel="stylesheet">
 <link href="<?php echo base_url(); ?>assets/report/css/buttons.dataTables.min.css" rel="stylesheet">
 <link href="<?php echo base_url(); ?>assets/report/css/dataTables.bootstrap.min.css" rel="stylesheet">


 <div class="container">
  <div class="table_load">
   <div class="row">
     <div class="col-sm-12">

    <div class="row well input-daterange">
         <div class="col-sm-3">
           <label class="control-label">Followup Status</label>
           <select class="form-control" name="status" id="status" style="height: 40px;">
             <option value="">- Please select -</option>

             <option value="pending">Pending</option>
             <option value="followup">Followup</option>
             <option value="cancel">Cancel</option>
             <option value="rejected">Rejected</option>
             <option value="noresponse">Noresponse</option>
             <option value="completed">Completed</option>
           </select>
         </div>
         <div class="col-sm-3">
         <label class="control-label">Users</label>
         <select class="form-control" name="username" id="username" style="height: 40px;">
          <option value="">- Please select -</option>
          <?php
          foreach ($companyuser as $row) {
          ?>
            <option value="<?php echo $row->user_id; ?>"><?php echo $row->username; ?></option>
          <?php } ?>
        </select>
        </div>
         <div class="col-sm-2">
           <label class="control-label">Start Date</label>
           <input class="form-control datepicker" type="text" name="start_date" id="start_date" placeholder="DD-MM-YYYY" style="height: 40px;text-align:left;padding:0 17px;border-radius:6px;" />
         </div>

         <div class="col-sm-2">
           <label class="control-label">End Date</label>
           <input class="form-control datepicker1" type="text" name="end_date" id="end_date" placeholder="DD-MM-YYYY" style="height: 40px;text-align:left;padding:0 17px;border-radius:6px;" />
         </div>

         <div class="col-sm-2">
           <button class="btn btn-success btn-block" type="submit" name="filter" id="filter" style="margin-top: 24px">
             <i class="fa fa-filter"></i> Filter
           </button>
         </div>

         <div class="col-sm-12 text-danger" id="error_log"></div>
       </div>

       <br /><br />



       <table id='report_table' class='table table-hover table-striped table-bordered' cellspacing="0" width="100%">

         <thead>
           <tr>
             <th>Enquiry Name</th>
             <th>Name</th>
             <th>Followup Message</th>
             <th>Followup Status</th>
             <th>Next Followup</th>
             <th>Next Followup Hint</th>
             <th>Created</th>
           </tr>
         </thead>


       </table>
       </div>
     </div>
   </div>
 </div>
 <script>
  $(document).ready(function(){
    $(".table_load").fadeIn(400);
  });
</script>
 <!-- <script src="<?php echo base_url(); ?>assets/report/js/bootstrap-datepicker.js"></script>
<script src="<?php echo base_url(); ?>assets/report/js/buttons.html5.min.js"></script>
<script src="<?php echo base_url(); ?>assets/report/js/buttons.print.min.js"></script>
<script src="<?php echo base_url(); ?>assets/report/js/dataTables.bootstrap.min.js"></script>
<script src="<?php echo base_url(); ?>assets/report/js/dataTables.buttons.min.js"></script>
<script src="<?php echo base_url(); ?>assets/report/js/jquery.dataTables.min.js"></script>
<script src="<?php echo base_url(); ?>assets/report/js/jszip.min.js"></script>
<script src="<?php echo base_url(); ?>assets/report/js/pdfmake.min.js"></script>
<script src="<?php echo base_url(); ?>assets/report/js/vfs_fonts.js"></script> -->

 <!-- <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script> -->

 <script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
 <script src="https://cdn.datatables.net/buttons/1.6.5/js/dataTables.buttons.min.js"></script>
 <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
 <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
 <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
 <script src="https://cdn.datatables.net/buttons/1.6.5/js/buttons.html5.min.js"></script>
 <script src="https://cdn.datatables.net/buttons/1.6.5/js/buttons.print.min.js"></script>
 <script src="https://cdn.datatables.net/1.10.20/js/dataTables.bootstrap.min.js"></script>

 <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.6.4/js/bootstrap-datepicker.js"></script>

 <script type="text/javascript">
 $(document).ready(function(){
  var userDataTable = $('#report_table').DataTable({
       "order": [
         [0, "desc"]
       ],
       dom: 'Blfrtip',
       buttons: [
         'csv', 'excel', 'pdf', 'print'
       ],
       'processing': true,
       'serverSide': true,
       "stateSave": true,
      "searching": false,
       'serverMethod': 'post',
       "lengthMenu": [
         [10, 25, 50, 100],
         [10, 25, 50, 100]
       ],
       'ajax': {
         'url': '<?= base_url() ?>adminreport/admin_report_view',
         "dataType": "json",
         "type": "POST",
         "data" : function(data){
	          		data.statusFilter = $("#status").val();
	          		data.startDate = $("#start_date").val();
                data.endDate = $("#end_date").val();
                data.doneBy = $("#username").val();
	          },
         "dataSrc": "aaData",
       },

       'columns': [{
           data: 'enq_name'
         },
         {
           data: 'username'
         },
         {
           data: 'follow_up_msg'
         },
         {
           data: 'follow_up_status'
         },
         {
           data: 'nxt_follow_up_date'
         },
         {
           data: 'nxt_follow_up_hint'
         },
         {
           data: 'created'
         },

       ]
     });



      $("#filter").on("click",function(){
        const status = $("#status").val();
        const start_date = $("#start_date").val();
        const end_date = $("#end_date").val();
        const done_by = $("#username").val();
      //  if(start_date > end_date) {
      //     alert("please select start and end date");
      //     return;
      //   }
        userDataTable.draw();
      });

      $('.datepicker, .datepicker1').datepicker({
     todayBtn: 'linked',
     format: "dd-mm-yyyy",
     autoclose: true
   });
  
    });


   
 </script>
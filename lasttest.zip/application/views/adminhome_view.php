<?php
defined('BASEPATH') or exit('No direct script access allowed');
?>

<div id="result"></div>
<div id="result_1">
</div>
<!--recent_follow_up-->




<script>
  $(document).ready(function() {
    $.ajax({
      url: 'dashboard/data_all',
      success: function(data) {
        var dlt = $.parseJSON(data);
        $("#result").html(dlt);
      }
    });
    $.ajax({
      url: 'dashboard/data_all_new',
      success: function(data) {
        console.log(data)
        var dlt = $.parseJSON(data);
        $("#result_1").html(dlt);
      }
    });
  });
</script>
 <div class="col-sm-12">

   <div class="row well input-daterange">
     <div class="col-sm-3">
       <label class="control-label">Followup Status</label>
       <select class="form-control" name="status" id="status">
         <option value="">- Please select -</option>
         <option value="pending">Pending</option>
         <option value="followup">Followup</option>
         <option value="cancel">Cancel</option>
         <option value="rejected">Rejected</option>
         <option value="noresponse">Noresponse</option>
         <option value="completed">Completed</option>
       </select>
     </div>
     <div class="col-sm-3">
       <label class="control-label">Users</label>
       <select class="form-control" name="username" id="username">
         <option value="">- Please select -</option>
         <?php
          foreach ($companyuser as $row) {
          ?>
           <option value="<?php echo $row->user_id; ?>"><?php echo $row->username; ?></option>
         <?php } ?>
       </select>
     </div>
     <div class="col-sm-2">
       <label class="control-label">Start Date</label>
       <input class="form-control datepicker" type="text" name="start_date" id="start_date" placeholder="DD-MM-YYYY" />
     </div>

     <div class="col-sm-2">
       <label class="control-label">End Date</label>
       <input class="form-control datepicker1" type="text" name="end_date" id="end_date" placeholder="DD-MM-YYYY" style="height: 40px;text-align:left;padding:0 17px;border-radius:6px;" />
     </div>

     <div class="col-sm-2">
       <button class="btn btn-success btn-md" type="submit" name="filter" id="filter" style="margin-top: 24px;height: 40px;">
         <i class="fa fa-filter"></i> Filter
       </button>
     </div>

     <div class="col-sm-12 text-danger" id="error_log"></div>
   </div>
   <br>
   <?php echo $this->table->generate();  ?>

  


   <script type="text/javascript">
     jQuery(document).ready(function($) {

       $.extend($.fn.dataTable.defaults, {
         buttons: ['copy', 'csv', 'excel']
       });

       var DataTable = $('#customer_view').DataTable({
         'responsive': true,
         'language': {
           'loadingRecords': '&nbsp;',
           'processing': '<div class="d-flex justify-content-center"><img src="<?= base_url(); ?>assets/images/loader.gif" /></div>',

         },

         dom: 'Blfrtip',
         buttons: [
           'csv', 'excel', 'pdf', 'print'
         ],
         'processing': true,
         'serverSide': true,
         "stateSave": true,
         "searching": true,
         'serverMethod': 'post',
         'ajax': {
           'url': '<?= base_url() ?>adminall/alladminreport',
           "dataType": "json",
           "type": "POST",
           "data": function(data) {
             data.statusFilter = $("#status").val();
             data.startDate = $("#start_date").val();
             data.endDate = $("#end_date").val();
             data.doneBy = $("#username").val();
           },
           "dataSrc": "data",
         },
         "rowCallback": function(nRow, aData, iDisplayIndex) {
           var oSettings = this.fnSettings();
           $("td:first", nRow).html(oSettings._iDisplayStart + iDisplayIndex + 1);
           return nRow;
         },

         'columns': [{


           },
           {
             data: '19'
           },
           {
             data: '5',
             render: function(data) {
               if (data != null) {
                 var ip = data.split('|')[1];
                 return ip;
               } else {
                 return data;
               }
             }
           },
           {
             data: '12'
           },
           {
             data: '13'
           },
           {
             data: '6'
           },
           {
             data: '7'
           },
           {
             data: "0"
           },

         ],
         "columnDefs": [{
             "width": "3%",
             "targets": 0
           },
           {
             "width": "6%",
             "targets": 1
           },
           {
             "width": "10%",
             "targets": 2
           },
           {
             "width": "10%",
             "targets": 3
           },
           {
             "width": "7%",
             "targets": 4
           },
           {
             "width": "4%",
             "targets": 5
           },
           {
             "width": "10%",
             "targets": 6
           },
           {
             "width": "3%",
             "targets": 7
           }

         ],

       });

       $("#filter").on("click", function() {
         const status = $("#status").val();
         const start_date = $("#start_date").val();
         const end_date = $("#end_date").val();
         const done_by = $("#username").val();
         DataTable.draw();
       });


       $.datetimepicker.setLocale('en');
       $('#start_date').datetimepicker();
       $('#end_date').datetimepicker();


       $('.buttons-csv').addClass('btn btn-primary btn-sm');
       $('.buttons-excel').addClass('btn btn-success btn-sm');
       $('.buttons-pdf').addClass('btn btn-danger btn-sm');
       $('.buttons-print').addClass('btn btn-info btn-sm');

     });
   </script>
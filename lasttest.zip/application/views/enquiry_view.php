<?php
defined('BASEPATH') or exit('No direct script access allowed');
?>
<div class="enqiry_top_view">
  <button class="btn btn-primary add_project_new btn-sm"><i class="fa fa-plus" aria-hidden="true"></i> Add Project</button>
  <button class="btn btn-success add_enquiry_new btn-sm"><i class="fa fa-plus" aria-hidden="true"></i> Add Enquiry</button>
</div>
<div class="enqiry_view">
  <div class="bulk_upload">
    <h2>Bulk Upload</h2>
    <div class="error_msg"></div>
    <div class="bulk_align">
      <div class="bulk_left">
        <form method="post" accept-charset="utf-8" name="bulkupload" id="bulkupload">
          <input type="file" name="bulk_upload" id="bulk_upload" required accept=".xls, .xlsx">
          <button type="submit" class="btn btn-danger btn-sm b_submit"><i class="fa fa-upload" aria-hidden="true"></i> Upload</button>
          </from>
      </div>
      <div class="bulk_right">
        <a title="Download Now" href="<?= base_url(); ?>assets/images/upload_excel.xlsx" download><button type="button" class="btn btn-info btn-sm"><i class="fa fa-download" aria-hidden="true"></i> Sample File</button></a>
      </div>
    </div>
  </div>
  <div class="table_loading">
  <div class="table_load">
    <?php echo $enquirylist['elist']; ?>
  </div>
  </div>
</div>


<style type="text/css">
.dataTables_wrapper .dataTables_processing {
  left: 50%;
    transform: translate(-50%, -50%);
    height: 100%;
    width: 100%;
    top: 50%;
    margin: 0;
    padding: 0;
    background: #fff;
}   
</style>

<script>
  $(document).ready(function() {
    $(".table_load").fadeIn(400);
  });

  


</script>


<div class="modal fade" id="projectmodel" tabindex="-1" aria-labelledby="projectmodeltitle" aria-hidden="true">
  <div class="modal-dialog modal-md">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="projectmodeltitle">Create Project</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <?php if ($this->session->flashdata('p_form_error')) { ?>
          <?php echo $this->session->flashdata('p_form_error'); ?>
        <?php } elseif ($this->session->flashdata('pnotadded')) { ?>
          <?php echo $this->session->flashdata('pnotadded'); ?>
        <?php } ?>
        <?php echo form_open('enquiry/addproject', 'method="post" accept-charset="utf-8" name="project" id="project"'); ?>
        <input type="text" name="project_name" id="project_name" placeholder="Project Name*" value="<?php echo set_value('project_name', $this->session->userdata('project_name')); ?>" />
        <button type="submit" class="btn btn-primary btn-md">Save Project</button>
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>

<div class="modal fade" id="enquirymodel" tabindex="-1" aria-labelledby="enquirymodeltitle" aria-hidden="true">
  <div class="modal-dialog modal-md">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="enquirymodeltitle">Create Enquiry</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <?php if ($this->session->flashdata('e_form_error')) { ?>
          <?php echo $this->session->flashdata('e_form_error'); ?>
        <?php } elseif ($this->session->flashdata('ennotadded')) { ?>
          <?php echo $this->session->flashdata('ennotadded'); ?>
        <?php } ?>
        <?php echo form_open('enquiry/addenquiry', 'method="post" accept-charset="utf-8" name="enquiry" id="enquiry"'); ?>
        <input type="text" name="enq_name" id="enq_name" placeholder="Enquiry Name*" value="<?php echo set_value('enq_name', $this->session->userdata('enq_name')); ?>" />
        <input type="text" name="enq_contact_number" id="enq_contact_number" placeholder="Phone Number*" value="<?php echo set_value('enq_contact_number', $this->session->userdata('enq_contact_number')); ?>" />
        <input type="text" name="enq_date" id="datetimepicker" placeholder="Enquiry Date*" value="<?php echo set_value('enq_date', $this->session->userdata('enq_date')); ?>" />
        <select name="project_id" id="project_id">
          <?php if ($this->session->userdata('project_id')) { ?>
            <option value="<?= $this->session->userdata('project_id') ?>" selected hidden><?= explode("|", $this->session->userdata('project_id'))[1] ?></option>
          <?php } else { ?>
            <option value="" selected hidden>Select Project*</option>
          <?php } ?>
          <?php
          foreach ($plist as $row) {
          ?>
            <option value="<?php echo $row->project_id; ?>|<?php echo $row->project_name; ?>"><?php echo $row->project_name; ?></option>
          <?php } ?>
        </select>
        <input type="text" name="enq_location" id="enq_location" placeholder="Enquiry location" value="<?php echo set_value('enq_location', $this->session->userdata('enq_location')); ?>" />
        <textarea name="enq_msg" id="enq_msg" placeholder="Enquiry Message" value="<?php echo set_value('enq_msg', $this->session->userdata('enq_msg')); ?>"><?php echo set_value('enq_msg', $this->session->userdata('enq_msg')); ?></textarea>
        <button type="submit" class="btn btn-primary btn-md">Save Enquiry</button>
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <!-- <button type="button" class="btn btn-primary">Save project</button> -->
      </div>
    </div>
  </div>
</div>


<div class="modal fade" id="viewenquiry" tabindex="-1" aria-labelledby="viewenquirytitle" aria-hidden="true">
  <div class="modal-dialog modal-xl">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="viewenquirytitle">View Project</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <div class="veiw_year_design">
          <ul>
            <li>
              <span>Enquiry Name:</span>
              <span>Software Development</span>
            </li>
            <li>
              <span>Enquiry Name:</span>
              <span>Software Development</span>
            </li>
            <li>
              <span>Enquiry Name:</span>
              <span>Software Development</span>
            </li>
            <li>
              <span>Enquiry Name:</span>
              <span>Software Development</span>
            </li>
            <li>
              <span>Enquiry Name:</span>
              <span>Software Development</span>
            </li>
            <li>
              <span>Enquiry Name:</span>
              <span>Software Development</span>
            </li>
            <li>
              <span>Enquiry Name:</span>
              <span>Software Development</span>
            </li>
          </ul>
        </div>


      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <!-- <button type="button" class="btn btn-primary">Save project</button> -->
      </div>
    </div>
  </div>
</div>





<script>
  $(document).ready(function() {

    //
    
    $('#bulkupload').on('submit', function(event) {
      event.preventDefault();
      if ($(".b_submit").hasClass("process")) {
      alert("Please wait while processing...");
    } else {
      $('.b_submit').html('<i class="fa fa-upload" aria-hidden="true"></i> Processing...').addClass("process");
      
      $.ajax({
        url: "<?php echo base_url(); ?>excelupload/import",
        method: "POST",
        data: new FormData(this),
        contentType: false,
        cache: false,
        processData: false,
        success: function(data) {
          console.log(data)
          var obj1 = $.parseJSON(data);
          if (obj1[0] === "success") {
            $("#bulkupload")[0].reset();
            $(".error_msg").html('<p class="alert alert-success alert-dismissible">Data Imported successfully.<button type="button" class="btn-close" data-bs-dismiss="alert"></button></p>');
            $('.b_submit').html('<i class="fa fa-upload" aria-hidden="true"></i> Upload').removeClass("process");
            
            test();
          setInterval(function(){
              window.location.reload();
            },1000);
          } else if (obj1[0] === "failed") {
            $(".error_msg").html('<p class="alert alert-danger alert-dismissible">Please try again later!.<button type="button" class="btn-close" data-bs-dismiss="alert"></button></p>');
            $('.b_submit').html('<i class="fa fa-upload" aria-hidden="true"></i> Upload').removeClass("process");
            test();
          }
          
        }
      })
    }
    });


    //

    const test = () => {
  $(".alert").delay(4000).slideUp(200, function() {
    $(this).alert('close');
});
}



    //

    $.datetimepicker.setLocale('en');
    $('#datetimepicker').datetimepicker();

    //

    $(".alert").delay(4000).slideUp(200, function() {
      $(this).alert('close');
    });

    //
    //$(".table_loading").fadeOut();
    
    const tload = () => {
    $('#customer_view').DataTable({
      
      "processing": true,
      "bInfo": false,
      "dom": 'Blfrtip',
      "bFilter": false,
      "deferRender": true,
      "autoWidth": false,
      "fixedHeader": {
        "header": false,
        "footer": false
      },
      initComplete: function () {
        
            $(".table_loading").fadeIn("300");
        },
        'responsive': true,
    "destroy": true,
      searching: true,
      info: false,
      "columnDefs": [{
          "width": "3%",
          "targets": 0
        },
        {
          "width": "9%",
          "targets": 1
        },
        {
          "width": "10%",
          "targets": 2
        },
        {
          "width": "10%",
          "targets": 3
        },
        {
          "width": "7%",
          "targets": 4
        },
        {
          "width": "8%",
          "targets": 5
        },
        {
          "width": "6%",
          "targets": 6
        },
        {
          "width": "3%",
          "targets": 7
        }

      ],
    });
  }

  tload();
  });

 


  $(document).on("click", ".delete_customer", function(d) {
    d.preventDefault();
    var deleteid = $(this).data('uid');
    swal({
        title: "Are you sure to delete?",
        text: "Not able to retrieve this file.",
        type: "warning",
        showCancelButton: true,
        confirmButtonColor: "#DD6B55",
        confirmButtonText: "Delete",
        cancelButtonText: "Cancel",
        closeOnConfirm: false,
        closeOnCancel: false
      },
      function(isConfirm) {
        if (isConfirm) {
          $.ajax({
            url: 'enquiry/DeleteEnquiry',
            type: 'POST',
            data: {
              'deleteid': deleteid
            },
            success: function(data) {
              var dlt = $.parseJSON(data);
              if (dlt[0] == 'success') {
                swal("Deleted Successfully", "You clicked the button!", "success");
                setTimeout(function() {
                  location.reload();
                }, 500);
              } else if (dlt[0] == 'fail') {
                swal("Could Not Deleted", "Something went Wrong!", "error");
              }
            }
          });
        } else {
          swal("Cancelled", "Your file is safe :)", "error");
        }
      });

  });

  $(document).on("click", ".add_project_new", function(d) {
    d.preventDefault();
    $('#projectmodel').modal('show');
  });

  $(document).on("click", ".add_enquiry_new", function(d) {
    d.preventDefault();
    $('#enquirymodel').modal('show');
  });

  $(document).on("click", ".view_customer_enquiry", function(d) {
    d.preventDefault();
    $('#viewenquiry').modal('show');
  });
</script>

<?php if ($this->session->flashdata('p_form_error') || $this->session->flashdata('pnotadded')) { ?>
  <script>
    addEventListener("load", (event) => {
      $('#projectmodel').modal('show');
    });
  </script>
<?php } elseif ($this->session->flashdata("psuccess")) { ?>
  <script type="text/javascript">
    addEventListener("load", (event) => {
      swal("Added Successfully", "You clicked the button!", "success");
    });
  </script>
<?php } ?>




<?php if ($this->session->flashdata('e_form_error') || $this->session->flashdata('ennotadded')) { ?>
  <script>
    addEventListener("load", (event) => {
      $('#enquirymodel').modal('show');
    });
  </script>

<?php } elseif ($this->session->flashdata("esuccess")) { ?>
  <script type="text/javascript">
    addEventListener("load", (event) => {
      swal("Added Successfully", "You clicked the button!", "success");
    });
  </script>
<?php } ?>
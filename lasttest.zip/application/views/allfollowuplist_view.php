<?php

$enq_id = isset($_GET['enq_id']) ? $_GET['enq_id'] : '';
$type = isset($_GET['type']) ? $_GET['type'] : '';
$page = isset($_GET['page']) ? $_GET['page'] : '';

?>
<?php
defined('BASEPATH') or exit('No direct script access allowed');
?>

<div class="enqiry_view">
  <div class="table_loading1">
    <div class="d-flex justify-content-center">
      <div class="spinner-border" role="status">
        <span class="visually-hidden">Loading...</span>
      </div>
    </div>
  </div>

  <div class="table_loading">

    <form name="new_form" id="new_form">
      <div class="col-sm-12">

        <div class="row well input-daterange">
          <div class="col-sm-3">
            <label class="control-label">Company Name</label>
            <select class="form-control" name="username" id="username">
              <option value="">- Please select -</option>
              <?php
              foreach ($companyuser as $row) {
              ?>
                <option value="<?php echo $row->user_id; ?>"><?php echo $row->username; ?></option>
              <?php } ?>
            </select>
          </div>
          <div class="col-sm-3">

            <label class="control-label">Followup Status</label>
            <select class="form-control" name="status" id="status">
              <option value="">- Please select -</option>
              <option value="pending">Pending</option>
              <option value="followup">Followup</option>
              <option value="cancel">Cancel</option>
              <option value="rejected">Rejected</option>
              <option value="noresponse">Noresponse</option>
              <option value="completed">Completed</option>
            </select>
          </div>
          <div class="col-sm-2">
            <label class="control-label">Start Date</label>
            <input class="form-control datepicker" type="text" name="start_date" id="start_date" placeholder="DD-MM-YYYY" />
          </div>

          <div class="col-sm-2">
            <label class="control-label">End Date</label>
            <input class="form-control datepicker1" type="text" name="end_date" id="end_date" placeholder="DD-MM-YYYY" style="height: 40px;text-align:left;padding:0 17px;border-radius:6px;" />
          </div>

          <div class="col-sm-2">
            <button class="btn btn-success btn-md" type="button" name="filter" id="filter" style="margin-top: 24px;height: 40px;">
              <i class="fa fa-filter"></i> Filter
            </button>
          </div>

          <div class="col-sm-12 text-danger" id="error_log"></div>
        </div>
        <br>
        <?php echo $this->table->generate();  ?>
      </div>
    </form>



  </div>






















  <div class="modal fade" id="followupmodeledit" tabindex="-1" aria-labelledby="followupmodeledittitle" aria-hidden="true">
    <div class="modal-dialog modal-md">
      <div class="modal-content">
        <div class="modal-header">
          <h1 class="modal-title fs-5" id="followupmodeledittitle">Update Followup</h1>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <?php echo form_open('followupprogress/add_followup_process_update', 'method="post" accept-charset="utf-8" name="followup" id="followup"'); ?>
          <input type="hidden" name="this_id" id="this_id" />
          <input type="text" name="follow_up_msg" id="efollow_up_msg" placeholder="Follow up Message" />
          <select name="follow_up_status" id="efollow_up_status">
            <option value="" selected hidden>Follow up Status</option>
            <option value="pending">Pending</option>
            <option value="followup">Followup</option>
            <option value="cancel">Cancel</option>
            <option value="rejected">Rejected</option>
            <option value="noresponse">Noresponse</option>
            <option value="completed">Completed</option>
          </select>

          <input type="text" name="nxt_follow_up_date" id="edatetimepicker" placeholder="Next Follow up" />
          <textarea name="nxt_follow_up_hint" id="enxt_follow_up_hint" placeholder="Follow up Hint"></textarea>
          <button type="submit" class="btn btn-success btn-md">Update Follow Up</button>
          </form>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
          <!-- <button type="button" class="btn btn-primary">Save project</button> -->
        </div>
      </div>
    </div>
  </div>


  <div class="modal fade" id="customerview" tabindex="-1" aria-labelledby="customerviewtitle" aria-hidden="true">
    <div class="modal-dialog modal-xl">
      <div class="modal-content">
        <div class="modal-header">
          <h1 class="modal-title fs-5" id="customerviewtitle">View Customer</h1>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <div id="result"></div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
          <!-- <button type="button" class="btn btn-primary">Save project</button> -->
        </div>
      </div>
    </div>
  </div>



  <?php if ($this->session->flashdata('success')) { ?>

    <script>
      $(document).ready(function() {
        swal("Updated Successfully", "You clicked the button!", "success");
      });
    </script>
  <?php } ?>

  <script>
    $(document).ready(function() {



      $.datetimepicker.setLocale('en');
      $('#datetimepicker').datetimepicker();
      $('#edatetimepicker').datetimepicker();

      //

      $(".alert").delay(4000).slideUp(200, function() {
        $(this).alert('close');
      });

      //

      // $('#customer_view').DataTable({
      //   'responsive': true,
      //   "processing": true,
      //   "bInfo": false,
      //   "bFilter": false,
      //   "autoWidth": false,
      //   "fixedHeader": {
      //     "header": false,
      //     "footer": false
      //   },
      //   searching: true,
      //   info: false,
      //   "columnDefs": [{
      //       "width": "4%",
      //       "targets": 0
      //     },
      //     {
      //       "width": "10%",
      //       "targets": 1
      //     },
      //     {
      //       "width": "6%",
      //       "targets": 2
      //     },
      //     {
      //       "width": "7%",
      //       "targets": 3
      //     },
      //     {
      //       "width": "9%",
      //       "targets": 4
      //     },
      //     {
      //       "width": "9%",
      //       "targets": 5
      //     },
      //     {
      //       "width": "4%",
      //       "targets": 6
      //     },
      //     {
      //       "width": "9%",
      //       "targets": 7
      //     },
      //     {
      //       "width": "4%",
      //       "targets": 8
      //     }

      //   ],

      //   fixedColumns: true,

      // });


      $(".table_loading").fadeOut();

      //
      var DataTable = $('#customer_view').DataTable({
        'responsive': true,
        'language': {
          'loadingRecords': '&nbsp;',
          'processing': '<div class="d-flex justify-content-center"><img src="<?= base_url(); ?>assets/images/loader.gif" /></div>',

        },

        dom: 'Blfrtip',
        buttons: [
          'csv', 'excel', 'pdf', 'print'
        ],
        'processing': true,
        'serverSide': true,
        "stateSave": true,
        "searching": true,
        'serverMethod': 'post',
        'ajax': {
          'url': '<?= base_url() ?>allfollowuplist/alladminfollowuplist',
          "dataType": "json",
          "type": "POST",
          "data": function(data) {
            data.statusFilter = $("#status").val();
            data.startDate = $("#start_date").val();
            data.endDate = $("#end_date").val();
            data.doneBy = $("#username").val();

          },
          "dataSrc": "data",
        },
        initComplete: function() {
          $(".table_loading").fadeIn("100");
          $(".table_loading1").fadeOut();

        },
        "rowCallback": function(nRow, aData, iDisplayIndex) {
          var oSettings = this.fnSettings();
          $("td:first", nRow).html(oSettings._iDisplayStart + iDisplayIndex + 1);
          return nRow;
        },

        'columns': [{


          },
          {
            data: '19'
          },
          {
            data: '24',

          },
          {
            data: '5',
            render: function(data) {
              if (data != null) {
                var ip = data.split('|')[1];
                return ip;
              } else {
                return data;
              }
            }
          },
          {
            data: '12'
          },
          {
            data: '6',
            render: function(data, type, row, meta) {
              if (row[6] == "pending" || row[6] == "followup") {
                return '<button class="primary_status" type="button">' + row[6] + '</button>';
              } else if (row[6] == "cancel" || row[6] == "rejected" || row[6] == "noresponse") {
                return '<button class="danger_status" type="button">' + row[6] + '</button>';
              } else {
                return '<button class="success_status" type="button">' + row[6] + '</button>';
              }

            }
          },
          {
            data: '7'
          },
          {
            data: "25"
          },

        ],
        "columnDefs": [{
            "width": "3%",
            "targets": 0
          },
          {
            "width": "6%",
            "targets": 1
          },
          {
            "width": "6%",
            "targets": 2
          },
          {
            "width": "10%",
            "targets": 3
          },
          {
            "width": "10%",
            "targets": 4
          },
          {
            "width": "4%",
            "targets": 5
          },
          {
            "width": "10%",
            "targets": 6
          },
          {
            "width": "3%",
            "targets": 7
          }

        ],

      });

      $("#filter").on("click", function(e) {
        e.preventDefault();
        const status = $("#status").val();
        const start_date = $("#start_date").val();
        const end_date = $("#end_date").val();
        const done_by = $("#username").val();
        console.log(done_by);
        DataTable.draw();
      });


      $.datetimepicker.setLocale('en');
      $('#start_date').datetimepicker();
      $('#end_date').datetimepicker();


      $('.buttons-csv').addClass('btn btn-primary btn-sm');
      $('.buttons-excel').addClass('btn btn-success btn-sm');
      $('.buttons-pdf').addClass('btn btn-danger btn-sm');
      $('.buttons-print').addClass('btn btn-info btn-sm');






    });


    $(document).on("click", ".delete_followup", function(d) {
      d.preventDefault();
      var deleteid = $(this).data('uid');
      swal({
          title: "Are you sure to delete?",
          text: "Not able to retrieve this file.",
          type: "warning",
          showCancelButton: true,
          confirmButtonColor: "#DD6B55",
          confirmButtonText: "Delete",
          cancelButtonText: "Cancel",
          closeOnConfirm: false,
          closeOnCancel: false
        },
        function(isConfirm) {
          if (isConfirm) {
            $.ajax({
              url: 'followupprogress/DeleteFollowup',
              type: 'POST',
              data: {
                'deleteid': deleteid
              },
              success: function(data) {
                var dlt = $.parseJSON(data);
                if (dlt[0] == 'success') {
                  swal("Deleted Successfully", "You clicked the button!", "success");
                  setTimeout(function() {
                    location.reload();
                  }, 1500);
                } else if (dlt[0] == 'fail') {
                  swal("Could Not Deleted", "Something went Wrong!", "error");
                }
              }
            });
          } else {
            swal("Cancelled", "Your file is safe :)", "error");
          }
        });

    });

    //view_followup
    $(document).on("click", ".view_followup", function(d) {
      d.preventDefault();
      let view_id = $(this).data("fid");

      $.ajax({
        url: "<?php echo base_url("allfollowuplist/getcustomerview_super"); ?>",
        type: "POST",
        data: {
          'view_id': view_id,
        },
        cache: false,
        success: function(data) {
          var dlt = $.parseJSON(data);
          $("#result").html(dlt);
          // console.log(data)
        }
      });
      $('#customerview').modal('show');
    });

    //

    $(document).on("click", ".edit_followup", function(d) {
      d.preventDefault();
      let f_id = $(this).data("uid");
      $.ajax({
        url: "<?php echo base_url("followupprogress/getsinglefprocess"); ?>",
        type: "POST",
        data: {
          'f_id': f_id,
        },
        cache: false,
        success: function(data) {
          //alert(result);
          var dlt = $.parseJSON(data);
          // console.log(dlt["result"][0]);
          // console.log(dlt["result"][0].follow_up_id);
          $("#efollow_up_msg").val(dlt["result"][0].follow_up_msg);
          $("#enxt_follow_up_hint").val(dlt["result"][0].nxt_follow_up_hint);
          $("#edatetimepicker").val(dlt["result"][0].nxt_follow_up_date);
          $("#efollow_up_status").val(dlt["result"][0].follow_up_status);
          $("#eproject_id").val(dlt["result"][0].project_id);
          $("#eenquiry_id").val(dlt["result"][0].enquiry_id);
          $("#this_id").val(dlt["result"][0].follow_up_id);
        }
      });
      $('#followupmodeledit').modal('show');
    });

    $(document).on("click", ".add_enquiry_new", function(d) {
      d.preventDefault();
      $('#enquirymodel').modal('show');
    });


    //

    //send push notification


    $(document).on("click", ".notify_followup", function(d) {
      d.preventDefault();
      let follow_up_id = $(this).data("fid");
      let admin_id = $(this).data("aid");
      let enquiry_id = $(this).data("eid");
      let status = $(this).data("status");
      swal({
          title: "Are you sure to send notification?",
          text: "able to send all users.",
          type: "info",
          showCancelButton: true,
          confirmButtonColor: "#157347",
          confirmButtonText: "Send",
          cancelButtonText: "Cancel",
          closeOnConfirm: false,
          closeOnCancel: false
        },
        function(isConfirm) {
          if (isConfirm) {
            $.ajax({
              url: "<?php echo base_url("notification/create_notification_super"); ?>",
              type: "POST",
              data: {
                'follow_up_id': follow_up_id,
                'admin_id': admin_id,
                'enquiry_id': enquiry_id,
                'status': status,
              },
              cache: false,
              success: function(data) {
                var dlt = $.parseJSON(data);
                //console.log(dlt)
                if (dlt[0] == 'success') {

                  swal("Sended Successfully", "You clicked the button!", "success");
                  setTimeout(function() {
                    location.reload();
                  }, 2500);

                } else if (dlt[0] == 'fail') {
                  swal("Could Not Sended", "Something went Wrong!", "error");
                }
              }
            });
          } else {
            swal("Cancelled", "Could Not Sended :)", "error");
          }
        });
    });
  </script>






  <?php if ($this->session->flashdata('ennotadded')) { ?>


    <script>
      addEventListener("load", (event) => {
        $('#projectmodel').modal('show');
      });
    </script>

  <?php } ?>
<?php
defined('BASEPATH') or exit('No direct script access allowed');
?>




<div class="enqiry_view">

  <div class="table_loading1">
    <div class="d-flex justify-content-center">
      <div class="spinner-border" role="status">
        <span class="visually-hidden">Loading...</span>
      </div>
    </div>
  </div>
  <div class="table_loading">

    <?php echo $this->table->generate();  ?>


  </div>



  <script>
    jQuery(document).ready(function($) {

      /*View User*/
      $(".table_loading").fadeOut();
      /*View User*/

      var DataTable = $('#customer_view').DataTable({
        'responsive': true,
        'language': {
          'loadingRecords': '&nbsp;',
          'processing': '<div class="d-flex justify-content-center"><img src="<?= base_url(); ?>assets/images/loader.gif" /></div>',

        },

        dom: 'Blfrtip',
        buttons: [

        ],
        'processing': true,
        'serverSide': true,
        "stateSave": true,
        "searching": true,
        'serverMethod': 'post',
        'ajax': {
          'url': '<?= base_url() ?>alllogs/allsuperadminreportlog',
          "dataType": "json",
          "type": "POST",

        },
        initComplete: function() {
          $(".table_loading").fadeIn("100");
          $(".table_loading1").fadeOut();

        },
        "rowCallback": function(nRow, aData, iDisplayIndex) {
          var oSettings = this.fnSettings();
          $("td:first", nRow).html(oSettings._iDisplayStart + iDisplayIndex + 1);
          return nRow;
        },

        'columns': [{


          },
          {
            data: '14'
          },
          {
            data: '1'
          },
          {
            data: '2'
          },
          {
            data: '3',
          },
          {
            data: '4'
          },
          {
            data: '5'
          },


        ],
        "columnDefs": [{
            "width": "4%",
            "targets": 0
          },
          {
            "width": "11%",
            "targets": 1
          },
          {
            "width": "8%",
            "targets": 2
          },
          {
            "width": "6%",
            "targets": 3
          },
          {
            "width": "10%",
            "targets": 4
          },
          {
            "width": "10%",
            "targets": 5
          },
          {
            "width": "4%",
            "targets": 6
          }

        ],

      });

      // $('#customer_view').DataTable({
      //   'responsive': true,
      //   "processing": true,
      //   "bInfo": false,
      //   "bFilter": false,
      //   "autoWidth": false,
      //   "fixedHeader": {
      //     "header": false,
      //     "footer": false
      //   },
      //   searching: true,
      //   info: false,
      //   "columnDefs": [{
      //       "width": "4%",
      //       "targets": 0
      //     },
      //     {
      //       "width": "11%",
      //       "targets": 1
      //     },
      //     {
      //       "width": "8%",
      //       "targets": 2
      //     },
      //     {
      //       "width": "6%",
      //       "targets": 3
      //     },
      //     {
      //       "width": "10%",
      //       "targets": 4
      //     },
      //     {
      //       "width": "10%",
      //       "targets": 5
      //     },
      //     {
      //       "width": "4%",
      //       "targets": 6
      //     }

      //   ],
      // });
    });
  </script>
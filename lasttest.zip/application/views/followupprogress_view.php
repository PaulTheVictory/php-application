<?php

$enq_id = isset($_GET['enq_id']) ? $_GET['enq_id'] : '';
$type = isset($_GET['type']) ? $_GET['type'] : '';
$page = isset($_GET['page']) ? $_GET['page'] : '';

?>
<?php
defined('BASEPATH') or exit('No direct script access allowed');
?>
<div class="enqiry_top_view">
  <button class="btn btn-primary add_project_new btn-sm"><i class="fa fa-plus" aria-hidden="true"></i> Add Project</button>
  <button class="btn btn-success add_enquiry_new btn-sm"><i class="fa fa-plus" aria-hidden="true"></i> Add Enquiry</button>
</div>
<div class="enqiry_view">
  <div class="table_loading1">
    <div class="d-flex justify-content-center">
      <div class="spinner-border" role="status">
        <span class="visually-hidden">Loading...</span>
      </div>
    </div>
  </div>
  <div class="table_loading">
    <div class="bulk_upload">
      <h2>Bulk Upload</h2>
      <div class="error_msg"></div>
      <div class="bulk_align">
        <div class="bulk_left">
          <form method="post" accept-charset="utf-8" name="bulkupload" id="bulkupload">
            <input type="file" name="bulk_upload" id="bulk_upload" accept=".xls, .xlsx">
            <button type="submit" class="btn btn-danger btn-sm b_submit"><i class="fa fa-upload" aria-hidden="true"></i> Upload</button>
            </from>
        </div>
        <div class="bulk_right">
          <a title="Download Now" href="<?= base_url(); ?>assets/images/upload_excel.xlsx" download><button type="button" class="btn btn-info btn-sm"><i class="fa fa-download" aria-hidden="true"></i> Sample File</button></a>
        </div>
      </div>
    </div>


    <div class="table_load">


    </div>
    <form name="new_form" id="new_form">
      <div class="col-sm-12">

        <div class="row well input-daterange">
          <div class="col-sm-3">
            <label class="control-label">Followup Status</label>
            <select class="form-control" name="status" id="status">
              <option value="">- Please select -</option>
              <option value="pending">Pending</option>
              <option value="followup">Followup</option>
              <option value="cancel">Cancel</option>
              <option value="rejected">Rejected</option>
              <option value="noresponse">Noresponse</option>
              <option value="completed">Completed</option>
            </select>
          </div>
          <div class="col-sm-3">
            <label class="control-label">Users</label>
            <select class="form-control" name="username" id="username">
              <option value="">- Please select -</option>
              <?php
              foreach ($companyuser as $row) {
              ?>
                <option value="<?php echo $row->user_id; ?>"><?php echo $row->username; ?></option>
              <?php } ?>
            </select>
          </div>
          <div class="col-sm-2">
            <label class="control-label">Start Date</label>
            <input class="form-control datepicker" type="text" name="start_date" id="start_date" placeholder="DD-MM-YYYY" />
          </div>

          <div class="col-sm-2">
            <label class="control-label">End Date</label>
            <input class="form-control datepicker1" type="text" name="end_date" id="end_date" placeholder="DD-MM-YYYY" style="height: 40px;text-align:left;padding:0 17px;border-radius:6px;" />
          </div>

          <div class="col-sm-2">
            <button class="btn btn-success btn-md" type="button" name="filter" id="filter" style="margin-top: 24px;height: 40px;">
              <i class="fa fa-filter"></i> Filter
            </button>
          </div>

          <div class="col-sm-12 text-danger" id="error_log"></div>
        </div>
        <br>
        <?php echo $this->table->generate();  ?>
      </div>
    </form>
  </div>
</div>

<div class="modal fade" id="projectmodel" tabindex="-1" aria-labelledby="projectmodeltitle" aria-hidden="true">
  <div class="modal-dialog modal-md">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="projectmodeltitle">Create Project</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <?php if ($this->session->flashdata('p_form_error')) { ?>
          <?php echo $this->session->flashdata('p_form_error'); ?>
        <?php } elseif ($this->session->flashdata('pnotadded')) { ?>
          <?php echo $this->session->flashdata('pnotadded'); ?>
        <?php } ?>
        <?php echo form_open('followupprogress/addproject', 'method="post" accept-charset="utf-8" name="project" id="project"'); ?>
        <input type="text" name="project_name" id="project_name" placeholder="Project Name*" value="<?php echo set_value('project_name', $this->session->userdata('project_name')); ?>" />
        <button type="submit" class="btn btn-primary btn-md">Save Project</button>
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>

<div class="modal fade" id="enquirymodeledit" tabindex="-1" aria-labelledby="enquirymodeltitleedit" aria-hidden="true">
  <div class="modal-dialog modal-md">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="enquirymodeltitleedit">Edit Enquiry</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <?php if ($this->session->flashdata('ee_form_error')) { ?>
          <?php echo $this->session->flashdata('ee_form_error'); ?>
        <?php } elseif ($this->session->flashdata('eennotadded')) { ?>
          <?php echo $this->session->flashdata('eennotadded'); ?>
        <?php } ?>
        <?php echo form_open('followupprogress/editenquiry', 'method="post" accept-charset="utf-8" name="enquiry" id="enquiry"'); ?>
        <input type="hidden" name="ee_id" class="enquiry_id_this" value="<?php echo set_value('ee_id', $this->session->userdata('ee_id')); ?>" />
        <input type="text" name="enq_name" id="eenq_name" placeholder="Enquiry Name*" value="<?php echo set_value('eenq_name', $this->session->userdata('eenq_name')); ?>" />
        <input type="text" name="enq_contact_number" id="eenq_contact_number" placeholder="Phone Number*" value="<?php echo set_value('eenq_contact_number', $this->session->userdata('eenq_contact_number')); ?>" />
        <input type="text" name="enq_date" id="datetimepicker" class="eeenq_date" placeholder="Enquiry Date*" value="<?php echo set_value('eenq_date', $this->session->userdata('eenq_date')); ?>" />
        <select name="project_id" id="eproject_id">
          <?php if ($this->session->userdata('eproject_id')) { ?>
            <option value="<?= $this->session->userdata('eproject_id') ?>" selected hidden><?= explode("|", $this->session->userdata('eproject_id'))[1] ?></option>
          <?php } else { ?>
            <option value="" selected hidden>Select Project*</option>
          <?php } ?>
          <?php
          foreach ($plist as $row) {
          ?>
            <option value="<?php echo $row->project_id; ?>|<?php echo $row->project_name; ?>"><?php echo $row->project_name; ?></option>
          <?php } ?>
        </select>
        <input type="text" name="enq_location" id="eenq_location" placeholder="Enquiry location" value="<?php echo set_value('eenq_location', $this->session->userdata('eenq_location')); ?>" />
        <textarea name="enq_msg" id="eenq_msg" placeholder="Enquiry Message"><?php echo set_value('eenq_msg', $this->session->userdata('eenq_msg')); ?></textarea>
        <button type="submit" class="btn btn-primary btn-md">Save Enquiry</button>
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <!-- <button type="button" class="btn btn-primary">Save project</button> -->
      </div>
    </div>
  </div>
</div>



<div class="modal fade" id="enquirymodel" tabindex="-1" aria-labelledby="enquirymodeltitle" aria-hidden="true">
  <div class="modal-dialog modal-md">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="enquirymodeltitle">Create Enquiry</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <?php if ($this->session->flashdata('e_form_error')) { ?>
          <?php echo $this->session->flashdata('e_form_error'); ?>
        <?php } elseif ($this->session->flashdata('ennotadded')) { ?>
          <?php echo $this->session->flashdata('ennotadded'); ?>
        <?php } ?>
        <?php echo form_open('followupprogress/addenquiry', 'method="post" accept-charset="utf-8" name="enquiry" id="enquiry"'); ?>
        <input type="text" name="enq_name" id="enq_name" placeholder="Enquiry Name*" value="<?php echo set_value('enq_name', $this->session->userdata('enq_name')); ?>" />
        <input type="text" name="enq_contact_number" id="enq_contact_number" placeholder="Phone Number*" value="<?php echo set_value('enq_contact_number', $this->session->userdata('enq_contact_number')); ?>" />
        <input type="text" name="enq_date" id="newdatetimepicker" placeholder="Enquiry Date*" value="<?php echo set_value('enq_date', $this->session->userdata('enq_date')); ?>" />
        <select name="project_id" id="project_id">
          <?php if ($this->session->userdata('project_id')) { ?>
            <option value="<?= $this->session->userdata('project_id') ?>" selected hidden><?= explode("|", $this->session->userdata('project_id'))[1] ?></option>
          <?php } else { ?>
            <option value="" selected hidden>Select Project*</option>
          <?php } ?>
          <?php
          foreach ($plist as $row) {
          ?>
            <option value="<?php echo $row->project_id; ?>|<?php echo $row->project_name; ?>"><?php echo $row->project_name; ?></option>
          <?php } ?>
        </select>
        <input type="text" name="enq_location" id="enq_location" placeholder="Enquiry location" value="<?php echo set_value('enq_location', $this->session->userdata('enq_location')); ?>" />
        <textarea name="enq_msg" id="enq_msg" placeholder="Enquiry Message" value="<?php echo set_value('enq_msg', $this->session->userdata('enq_msg')); ?>"><?php echo set_value('enq_msg', $this->session->userdata('enq_msg')); ?></textarea>
        <button type="submit" class="btn btn-primary btn-md">Save Enquiry</button>
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <!-- <button type="button" class="btn btn-primary">Save project</button> -->
      </div>
    </div>
  </div>
</div>




<div class="modal fade" id="followupmodeledit" tabindex="-1" aria-labelledby="followupmodeledittitle" aria-hidden="true">
  <div class="modal-dialog modal-md">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="followupmodeledittitle">Update Followup</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">

        <?php if ($this->session->flashdata('fo_form_error')) { ?>
          <?php echo $this->session->flashdata('fo_form_error'); ?>
        <?php } elseif ($this->session->flashdata('fonotupdated')) { ?>
          <?php echo $this->session->flashdata('fonotupdated'); ?>
        <?php } ?>
        <?php echo form_open('followupprogress/add_followup_process_update', 'method="post" accept-charset="utf-8" name="followup" id="followup"'); ?>
        <input type="hidden" name="this_id" id="this_id" class="this_id_new" value="<?php echo set_value('this_id', $this->session->userdata('this_id')); ?>" />
        <input type="text" name="follow_up_msg" id="efollow_up_msg" placeholder="Follow up Message*" value="<?php echo set_value('follow_up_msg', $this->session->userdata('follow_up_msg')); ?>" />
        <select name="follow_up_status" id="efollow_up_status">


          <option value="" selected hidden>Follow up Status*</option>


          <option value="pending" <?= ($this->session->userdata('follow_up_status') === "pending") ? "selected" : "" ?>>Pending</option>
          <option value="followup" <?= ($this->session->userdata('follow_up_status') === "followup") ? "selected" : "" ?>>Followup</option>
          <option value="cancel" <?= ($this->session->userdata('follow_up_status') === "cancel") ? "selected" : "" ?>>Cancel</option>
          <option value="rejected" <?= ($this->session->userdata('follow_up_status') === "rejected") ? "selected" : "" ?>>Rejected</option>
          <option value="noresponse" <?= ($this->session->userdata('follow_up_status') === "noresponse") ? "selected" : "" ?>>Noresponse</option>
          <option value="completed" <?= ($this->session->userdata('follow_up_status') === "completed") ? "selected" : "" ?>>Completed</option>
        </select>

        <input type="text" name="nxt_follow_up_date" id="edatetimepicker" placeholder="Next Follow up*" value="<?php echo set_value('nxt_follow_up_date', $this->session->userdata('nxt_follow_up_date')); ?>" />
        <textarea name="nxt_follow_up_hint" id="enxt_follow_up_hint" placeholder="Follow up Hint"><?php echo set_value('nxt_follow_up_hint', $this->session->userdata('nxt_follow_up_hint')); ?></textarea>
        <button type="submit" class="btn btn-success btn-md">Update Follow Up</button>
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <!-- <button type="button" class="btn btn-primary">Save project</button> -->
      </div>
    </div>
  </div>
</div>


<div class="modal fade" id="customerview" tabindex="-1" aria-labelledby="customerviewtitle" aria-hidden="true">
  <div class="modal-dialog modal-xl">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="customerviewtitle">View Follow Up Progress</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <div id="result"></div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <!-- <button type="button" class="btn btn-primary">Save project</button> -->
      </div>
    </div>
  </div>
</div>

<div class="modal fade" id="followupmodeleditlog" tabindex="-1" aria-labelledby="followupmodeleditlogtitle" aria-hidden="true">
  <div class="modal-dialog modal-md">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="followupmodeleditlogtitle">Update Followup</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">

        <?php if ($this->session->flashdata('la_form_error')) { ?>
          <?php echo $this->session->flashdata('la_form_error'); ?>
        <?php } elseif ($this->session->flashdata('lanotupdated')) { ?>
          <?php echo $this->session->flashdata('lanotupdated'); ?>
        <?php } ?>
        <?php echo form_open('followupprogress/add_followup_process_update_log', 'method="post" accept-charset="utf-8" name="followup" id="followup"'); ?>
        <input type="hidden" name="follow_up_id" id="l_follow_up_id" value="<?php echo set_value('follow_up_id', $this->session->userdata('follow_up_id')); ?>" />
        <input type="hidden" name="follow_up_log_id" id="l_follow_up_log_id" value="<?php echo set_value('follow_up_log_id', $this->session->userdata('follow_up_log_id')); ?>" />
        <input type="text" name="follow_up_msg" id="l_follow_up_msg" placeholder="Follow up Message*" value="<?php echo set_value('follow_up_msg', $this->session->userdata('follow_up_msg')); ?>" />
        <select name="follow_up_status" id="l_follow_up_status">
          <option value="" selected hidden>Follow up Status*</option>
          <option value="pending" <?= ($this->session->userdata('follow_up_status') === "pending") ? "selected" : "" ?>>Pending</option>
          <option value="followup" <?= ($this->session->userdata('follow_up_status') === "followup") ? "selected" : "" ?>>Followup</option>
          <option value="cancel" <?= ($this->session->userdata('follow_up_status') === "cancel") ? "selected" : "" ?>>Cancel</option>
          <option value="rejected" <?= ($this->session->userdata('follow_up_status') === "rejected") ? "selected" : "" ?>>Rejected</option>
          <option value="noresponse" <?= ($this->session->userdata('follow_up_status') === "noresponse") ? "selected" : "" ?>>Noresponse</option>
          <option value="completed" <?= ($this->session->userdata('follow_up_status') === "completed") ? "selected" : "" ?>>Completed</option>
        </select>

        <input type="text" name="nxt_follow_up_date" id="l_datetimepicker" placeholder="Next Follow up*" value="<?php echo set_value('nxt_follow_up_date', $this->session->userdata('nxt_follow_up_date')); ?>" />
        <textarea name="nxt_follow_up_hint" id="l_nxt_follow_up_hint" placeholder="Follow up Hint"><?php echo set_value('nxt_follow_up_hint', $this->session->userdata('nxt_follow_up_hint')); ?></textarea>
        <button type="submit" class="btn btn-success btn-md">Update Follow Up</button>
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <!-- <button type="button" class="btn btn-primary">Save project</button> -->
      </div>
    </div>
  </div>
</div>

<script>
  // $(document).ready(function() {
  //   $(".table_load").fadeIn(400);
  // });
</script>

<script>
  $(document).on("click", ".delete_customer_enquiry", function(d) {
    d.preventDefault();
    var deleteid = $(this).data('uid');
    swal({
        title: "Are you sure to delete?",
        text: "Not able to retrieve this file.",
        type: "warning",
        showCancelButton: true,
        confirmButtonColor: "#DD6B55",
        confirmButtonText: "Delete",
        cancelButtonText: "Cancel",
        closeOnConfirm: false,
        closeOnCancel: false
      },
      function(isConfirm) {
        if (isConfirm) {
          $.ajax({
            url: 'followupprogress/DeleteEnquiry',
            type: 'POST',
            data: {
              'deleteid': deleteid
            },
            success: function(data) {
              var dlt = $.parseJSON(data);
              if (dlt[0] == 'success') {
                swal("Deleted Successfully", "You clicked the button!", "success");
                setTimeout(function() {
                  location.reload();
                }, 500);
              } else if (dlt[0] == 'fail') {
                swal("Could Not Deleted", "Something went Wrong!", "error");
              }
            }
          });
        } else {
          swal("Cancelled", "Your file is safe :)", "error");
        }
      });

  });


  $(document).on("click", ".add_project_new", function(d) {
    d.preventDefault();
    $('#projectmodel').modal('show');
  });


  $(document).on("click", ".add_enquiry_new", function(d) {
    d.preventDefault();
    $('#enquirymodel').modal('show');
  });

  $(document).on("click", ".edit_customer_enquiry", function(d) {
    d.preventDefault();
    let f_id = $(this).data("uid");
    $.ajax({
      url: "<?php echo base_url("followupprogress/edit_customer_enquiry"); ?>",
      type: "POST",
      data: {
        'f_id': f_id,
      },
      cache: false,
      success: function(data) {
        var dlt = $.parseJSON(data);
        console.log(data)
        $(".enquiry_id_this").val(dlt["result"][0].enquiry_id);
        $("#eenq_name").val(dlt["result"][0].enq_name);
        $("#eenq_contact_number").val(dlt["result"][0].enq_contact_number);
        $(".eeenq_date").val(dlt["result"][0].enq_date);
        $("#eproject_id").val(dlt["result"][0].project_id);
        $("#eenq_location").val(dlt["result"][0].enq_location);
        $("#eenq_msg").val(dlt["result"][0].enq_msg);
      }
    });
    $('#enquirymodeledit').modal('show');
    $('#customerview').modal('hide');
  });


  $(document).on("click", ".edit_followup_new", function(d) {
    // $(".edit_followup").trigger("click");
    d.preventDefault();
    let f_id = $(this).data("uid");
    $.ajax({
      url: "<?php echo base_url("followupprogress/getsinglefprocess"); ?>",
      type: "POST",
      data: {
        'f_id': f_id,
      },
      cache: false,
      success: function(data) {
        //alert(result);
        var dlt = $.parseJSON(data);
        console.log(data)
        $(".eproject_id_new").val(dlt["result"][0].project_id);
        $("#eenquiry_id").val(dlt["result"][0].enquiry_id);
        $(".this_id_new").val(dlt["result"][0].follow_up_id);
      }
    });
    $('#followupmodeledit').modal('show');
    $('#customerview').modal('hide');
  })
</script>



<?php if ($this->session->flashdata('success')) { ?>

  <script>
    $(document).ready(function() {
      swal("Updated Successfully", "You clicked the button!", "success");
    });
  </script>
<?php } ?>



<script>
  $(document).ready(function() {
    //
    $('#bulkupload').on('submit', function(event) {
      event.preventDefault();
      let b_upload = $("#bulk_upload").val();
      console.log(b_upload);
      if (b_upload == null || b_upload == "") {
        alert("Please choose upload file");
        return;
      }

      if ($(".b_submit").hasClass("process")) {
        alert("Please wait while processing...");
      } else {
        $('.b_submit').html('<i class="fa fa-upload" aria-hidden="true"></i> Processing...').addClass("process");

        $.ajax({
          url: "<?php echo base_url(); ?>excelupload/import",
          method: "POST",
          data: new FormData(this),
          contentType: false,
          cache: false,
          processData: false,
          success: function(data) {
            console.log(data)
            var obj1 = $.parseJSON(data);
            if (obj1[0] === "success") {
              $("#bulkupload")[0].reset();
              $(".error_msg").html('<p class="alert alert-success alert-dismissible">Data Imported successfully.<button type="button" class="btn-close" data-bs-dismiss="alert"></button></p>');
              $('.b_submit').html('<i class="fa fa-upload" aria-hidden="true"></i> Upload').removeClass("process");

              test();
              DataTable.draw();
              // setInterval(function() {
              //   window.location.reload();
              // }, 500);
            } else if (obj1[0] === "failed") {
              $(".error_msg").html('<p class="alert alert-danger alert-dismissible">Please try again later!.<button type="button" class="btn-close" data-bs-dismiss="alert"></button></p>');
              $('.b_submit').html('<i class="fa fa-upload" aria-hidden="true"></i> Upload').removeClass("process");
              test();
            }

          }
        })
      }
    });

    //
    const test = () => {
      $(".alert").delay(4000).slideUp(200, function() {
        $(this).alert('close');
      });
    }
    //
    $.datetimepicker.setLocale('en');
    $('#datetimepicker').datetimepicker();
    $('#newdatetimepicker').datetimepicker();
    $('#edatetimepicker').datetimepicker();
    $('#l_datetimepicker').datetimepicker();

    //

    $(".alert").delay(4000).slideUp(200, function() {
      $(this).alert('close');
    });

    //


    $(".table_loading").fadeOut();

    //
    var DataTable = $('#customer_view').DataTable({
      'responsive': true,
      'language': {
        'loadingRecords': '&nbsp;',
        'processing': '<div class="d-flex justify-content-center"><img src="<?= base_url(); ?>assets/images/loader.gif" /></div>',

      },

      dom: 'Blfrtip',
      buttons: [
        'csv', 'excel', 'pdf', 'print'
      ],
      'processing': true,
      'serverSide': true,
      "stateSave": true,
      "searching": true,
      'serverMethod': 'post',
      'ajax': {
        'url': '<?= base_url() ?>followupprogress/alladminreport',
        "dataType": "json",
        "type": "POST",
        "data": function(data) {
          data.statusFilter = $("#status").val();
          data.startDate = $("#start_date").val();
          data.endDate = $("#end_date").val();
          data.doneBy = $("#username").val();
          data.typePage = "<?= $type; ?>";
          data.typeAll = "<?= $page; ?>";
          data.enquiryId = "<?= trim($enq_id, "'."); ?>";
        },
        "dataSrc": "data",
      },
      initComplete: function() {
        $(".table_loading").fadeIn("100");
        $(".table_loading1").fadeOut();

      },
      "rowCallback": function(nRow, aData, iDisplayIndex) {
        var oSettings = this.fnSettings();
        $("td:first", nRow).html(oSettings._iDisplayStart + iDisplayIndex + 1);
        return nRow;
      },

      'columns': [{


        },
        {
          data: '19'
        },
        {
          data: '5',
          render: function(data) {
            if (data != null) {
              var ip = data.split('|')[1];
              return ip;
            } else {
              return data;
            }
          }
        },
        {
          data: '12'
        },
        {
          data: '13'
        },
        {
          data: '6'
        },
        {
          data: '7'
        },
        {
          data: "0"
        },

      ],
      "columnDefs": [{
          "width": "3%",
          "targets": 0
        },
        {
          "width": "6%",
          "targets": 1
        },
        {
          "width": "10%",
          "targets": 2
        },
        {
          "width": "10%",
          "targets": 3
        },
        {
          "width": "7%",
          "targets": 4
        },
        {
          "width": "4%",
          "targets": 5
        },
        {
          "width": "10%",
          "targets": 6
        },
        {
          "width": "3%",
          "targets": 7
        }

      ],

    });

    $("#filter").on("click", function(e) {
      e.preventDefault();
      const status = $("#status").val();
      const start_date = $("#start_date").val();
      const end_date = $("#end_date").val();
      const done_by = $("#username").val();
      console.log(done_by);
      DataTable.draw();
    });


    $.datetimepicker.setLocale('en');
    $('#start_date').datetimepicker();
    $('#end_date').datetimepicker();


    $('.buttons-csv').addClass('btn btn-primary btn-sm');
    $('.buttons-excel').addClass('btn btn-success btn-sm');
    $('.buttons-pdf').addClass('btn btn-danger btn-sm');
    $('.buttons-print').addClass('btn btn-info btn-sm');

  });


  $(document).on("click", ".delete_followup", function(d) {
    d.preventDefault();
    var deleteid = $(this).data('uid');
    swal({
        title: "Are you sure to delete?",
        text: "Not able to retrieve this file.",
        type: "warning",
        showCancelButton: true,
        confirmButtonColor: "#DD6B55",
        confirmButtonText: "Delete",
        cancelButtonText: "Cancel",
        closeOnConfirm: false,
        closeOnCancel: false
      },
      function(isConfirm) {
        if (isConfirm) {
          $.ajax({
            url: 'followupprogress/DeleteFollowup',
            type: 'POST',
            data: {
              'deleteid': deleteid
            },
            success: function(data) {
              var dlt = $.parseJSON(data);
              if (dlt[0] == 'success') {
                swal("Deleted Successfully", "You clicked the button!", "success");
                setTimeout(function() {
                  location.reload();
                }, 500);
              } else if (dlt[0] == 'fail') {
                swal("Could Not Deleted", "Something went Wrong!", "error");
              }
            }
          });
        } else {
          swal("Cancelled", "Your file is safe :)", "error");
        }
      });

  });

  //view_followup
  $(document).on("click", ".view_followup", function(d) {
    d.preventDefault();
    let view_id = $(this).data("uid");
    $.ajax({
      url: "<?php echo base_url("followupprogress/getcustomerview"); ?>",
      type: "POST",
      data: {
        'view_id': view_id,
      },
      cache: false,
      success: function(data) {

        var dlt = $.parseJSON(data);
        $("#result").html(dlt);
        // console.log(dlt);
      }
    });
    $('#customerview').modal('show');
  });

  //

  $(document).on("click", ".edit_followup", function(d) {
    d.preventDefault();
    let f_id = $(this).data("uid");
    $.ajax({
      url: "<?php echo base_url("followupprogress/getsinglefprocess"); ?>",
      type: "POST",
      data: {
        'f_id': f_id,
      },
      cache: false,
      success: function(data) {
        //alert(result);
        var dlt = $.parseJSON(data);
        console.log(data);
        // console.log(dlt["result"][0].follow_up_id);
        // $("#efollow_up_msg").val(dlt["result"][0].follow_up_msg);
        // $("#enxt_follow_up_hint").val(dlt["result"][0].nxt_follow_up_hint);
        // $("#edatetimepicker").val(dlt["result"][0].nxt_follow_up_date);
        // $("#efollow_up_status").val(dlt["result"][0].follow_up_status);
        $("#eproject_id").val(dlt["result"][0].project_id);
        $("#eenquiry_id").val(dlt["result"][0].enquiry_id);
        $("#this_id").val(dlt["result"][0].follow_up_id);
      }
    });
    $('#followupmodeledit').modal('show');
  });

  $(document).on("click", ".add_enquiry_new", function(d) {
    d.preventDefault();
    $('#enquirymodel').modal('show');
  });


  //delete log

  $(document).on("click", ".delete_logs", function(d) {
    d.preventDefault();
    var deleteid = $(this).data('uid');
    swal({
        title: "Are you sure to delete?",
        text: "Not able to retrieve this file.",
        type: "warning",
        showCancelButton: true,
        confirmButtonColor: "#DD6B55",
        confirmButtonText: "Delete",
        cancelButtonText: "Cancel",
        closeOnConfirm: false,
        closeOnCancel: false
      },
      function(isConfirm) {
        if (isConfirm) {
          $.ajax({
            url: 'followupprogress/DeleteFollowupLogs',
            type: 'POST',
            data: {
              'deleteid': deleteid
            },
            success: function(data) {
              var dlt = $.parseJSON(data);
              if (dlt[0] == 'success') {
                swal("Deleted Successfully", "You clicked the button!", "success");
                setTimeout(function() {
                  location.reload();
                }, 500);

              } else if (dlt[0] == 'fail') {
                swal("Could Not Deleted", "Something went Wrong!", "error");
              }
              $('#customerview').modal('show');
            }
          });
        } else {
          swal("Cancelled", "Your file is safe :)", "error");
        }
      });

  });


  $(document).on("click", ".edit_last_logs", function(d) {
    //alert("test");
    d.preventDefault();
    let f_id = $(this).data("uid");
    $.ajax({
      url: "<?php echo base_url("followupprogress/getsingleflogs"); ?>",
      type: "POST",
      data: {
        'f_id': f_id,
      },
      cache: false,
      success: function(data) {
        //alert(result);
        var dlt = $.parseJSON(data);
        //console.log(dlt)
        $("#l_follow_up_log_id").val(dlt["result"][0].ap_followuplog_id);
        $("#l_follow_up_id").val(dlt["result"][0].follow_up_id);
        $("#l_follow_up_msg").val(dlt["result"][0].follow_up_msg);
        $("#l_follow_up_status").val(dlt["result"][0].follow_up_status);
        $("#l_datetimepicker").val(dlt["result"][0].nxt_follow_up_date);
        $("#l_nxt_follow_up_hint").val(dlt["result"][0].nxt_follow_up_hint);
      }
    });
    $('#customerview').modal('hide');
    $('#followupmodeleditlog').modal('show');
  });



  //send push notification


  $(document).on("click", ".notify_followup", function(d) {
    d.preventDefault();
    let follow_up_id = $(this).data("fid");
    let admin_id = $(this).data("aid");
    let enquiry_id = $(this).data("eid");
    let status = $(this).data("status");
    swal({
        title: "Are you sure to send notification?",
        text: "able to send all users.",
        type: "info",
        showCancelButton: true,
        confirmButtonColor: "#157347",
        confirmButtonText: "Send",
        cancelButtonText: "Cancel",
        closeOnConfirm: false,
        closeOnCancel: false
      },
      function(isConfirm) {
        if (isConfirm) {
          $.ajax({
            url: "<?php echo base_url("notification/create_notification"); ?>",
            type: "POST",
            data: {
              'follow_up_id': follow_up_id,
              'admin_id': admin_id,
              'enquiry_id': enquiry_id,
              'status': status,
            },
            cache: false,
            success: function(data) {
              var dlt = $.parseJSON(data);
              //console.log(dlt)
              if (dlt[0] == 'success') {

                swal("Sended Successfully", "You clicked the button!", "success");
                setTimeout(function() {
                  location.reload();
                }, 2500);

              } else if (dlt[0] == 'fail') {
                swal("Could Not Sended", "Something went Wrong!", "error");
              }
            }
          });
        } else {
          swal("Cancelled", "Could Not Sended :)", "error");
        }
      });
  });
</script>


<?php if ($this->session->flashdata('fsuccess')) { ?>


  <script>
    addEventListener("load", (event) => {
      $('#customerview').modal('show');
    });
  </script>

<?php } ?>


<?php if ($this->session->flashdata('la_form_error') || $this->session->flashdata('lanotupdated')) { ?>


  <script type="text/javascript">
    // addEventListener("load", (event) => {
    //  swal("Please fill all required fields", "You clicked the button!", "error");
    //   });
    addEventListener("load", (event) => {
      $('#followupmodeleditlog').modal('show');
    });
  </script>

<?php } elseif ($this->session->flashdata("lasuccess")) { ?>
  <script type="text/javascript">
    addEventListener("load", (event) => {
      swal("Updated Successfully", "You clicked the button!", "success");
    });
  </script>
<?php } ?>




<?php if ($this->session->flashdata('fo_form_error') || $this->session->flashdata('fonotupdated')) { ?>


  <script type="text/javascript">
    // addEventListener("load", (event) => {
    //  swal("Please fill all required fields", "You clicked the button!", "error");
    //   });
    addEventListener("load", (event) => {
      $('#followupmodeledit').modal('show');
    });
  </script>

<?php } elseif ($this->session->flashdata("fosuccess")) { ?>
  <script type="text/javascript">
    addEventListener("load", (event) => {
      swal("Updated Successfully", "You clicked the button!", "success");
    });
  </script>
<?php } ?>







<?php if ($enq_id !== "") { ?>
  <script>
    const load_page = () => {


      var test = "<?php echo trim($enq_id, "'."); ?>";
      $("." + test).trigger("click");
    }
  </script>

<?php } ?>

<?php if ($this->session->flashdata('p_form_error') || $this->session->flashdata('pnotadded')) { ?>
  <script>
    addEventListener("load", (event) => {
      $('#projectmodel').modal('show');
    });
  </script>
<?php } elseif ($this->session->flashdata("psuccess")) { ?>
  <script type="text/javascript">
    addEventListener("load", (event) => {
      swal("Added Successfully", "You clicked the button!", "success");
    });
  </script>
<?php } ?>


<?php if ($this->session->flashdata('e_form_error') || $this->session->flashdata('ennotadded')) { ?>
  <script>
    addEventListener("load", (event) => {
      $('#enquirymodel').modal('show');
    });
  </script>

<?php } elseif ($this->session->flashdata("esuccess")) { ?>
  <script type="text/javascript">
    addEventListener("load", (event) => {
      swal("Added Successfully", "You clicked the button!", "success");
    });
  </script>
<?php } ?>

<?php if ($this->session->flashdata('ee_form_error') || $this->session->flashdata('eennotadded')) { ?>
  <script>
    addEventListener("load", (event) => {
      $('#enquirymodeledit').modal('show');
    });
  </script>

<?php } elseif ($this->session->flashdata("eesuccess")) { ?>
  <script type="text/javascript">
    addEventListener("load", (event) => {
      swal("Updated Successfully", "You clicked the button!", "success");
    });
  </script>
<?php } ?>
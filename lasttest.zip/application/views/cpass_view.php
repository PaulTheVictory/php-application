<?php
defined('BASEPATH') or exit('No direct script access allowed');
?>

<div class="add_customer">
  <div class="add_customer_form">
    <h2>Change Password</h2>
   
      <?php if ($this->session->flashdata('fail')) { ?>
          <?php echo $this->session->flashdata('fail'); ?>
        <?php } if ($this->session->flashdata('success')) { ?>
          <?php echo $this->session->flashdata('success'); ?> 
         <?php } ?>
         <?php if($this->session->flashdata('form_error')): ?>
          <?php echo $this->session->flashdata('form_error');?>
        <?php endif; ?>
    <?php echo form_open('changepassword/cpass_change', 'method="post" accept-charset="utf-8" name="changepassword" id="changepassword"'); ?>
    <div class="password_group">
      <input type="password" placeholder="New Password" name="new_pass" id="new_pass" value="<?php echo set_value('new_pass', $this->session->userdata('new_pass')); ?>" />
      <div class="toggle-password">
<i class="fa fa-eye-slash" aria-hidden="true"></i>
</div>
</div>
<div class="password_group">
      <input type="password" placeholder="Confirm Password" name="confirm_pass" id="confirm_pass" value="<?php echo set_value('confirm_pass', $this->session->userdata('confirm_pass')); ?>"  />
      <div class="toggle-password">
<i class="fa fa-eye-slash" aria-hidden="true"></i>
</div>
</div>
      <button type="submit" name="submit" class="btn btn-success">Update Password</button>
    </form>
  </div>
</div>



<script>

$(document).ready(function(){

  $('.toggle-password').click(function(){
    let input = $(this).prev();
    if(input.attr('type') === 'password') {
      $(this).children().removeClass('fa-eye-slash');
      $(this).children().addClass('fa-eye');
    } else {
      $(this).children().removeClass('fa-eye');
      $(this).children().addClass('fa-eye-slash');
      
    }
    input.attr('type', input.attr('type') === 'password' ? 'text' : 'password');
    });


  $(".alert").delay(4000).slideUp(200, function() {
    $(this).alert('close');
});
});

</script>
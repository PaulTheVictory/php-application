<?php
defined('BASEPATH') or exit('No direct script access allowed');
?>




<div class="enqiry_view">
  <div class="table_loading1">
    <div class="d-flex justify-content-center">
      <div class="spinner-border" role="status">
        <span class="visually-hidden">Loading...</span>
      </div>
    </div>
  </div>
  <div class="table_loading">

    <?php echo $this->table->generate();  ?>


  </div>
</div>



<script>
  jQuery(document).ready(function($) {
    $(".table_loading").fadeOut();
    /*View User*/

    var DataTable = $('#customer_view').DataTable({
      'responsive': true,
      'language': {
        'loadingRecords': '&nbsp;',
        'processing': '<div class="d-flex justify-content-center"><img src="<?= base_url(); ?>assets/images/loader.gif" /></div>',

      },

      dom: 'Blfrtip',
      buttons: [

      ],
      'processing': true,
      'serverSide': true,
      "stateSave": true,
      "searching": true,
      'serverMethod': 'post',
      'ajax': {
        'url': '<?= base_url() ?>allactions/alladminreportaction',
        "dataType": "json",
        "type": "POST",

      },
      initComplete: function() {
        $(".table_loading").fadeIn("100");
        $(".table_loading1").fadeOut();

      },
      "rowCallback": function(nRow, aData, iDisplayIndex) {
        var oSettings = this.fnSettings();
        $("td:first", nRow).html(oSettings._iDisplayStart + iDisplayIndex + 1);
        return nRow;
      },

      'columns': [{


        },
        {
          data: '6'
        },
        {
          data: '3',
          render: function(data, type, row, meta) {
            if (row[3] == "create") {
              return '<button class="primary_status" type="button">' + row[3] + '</button>';
            } else if (row[3] == "delete") {
              return '<button class="danger_status" type="button">' + row[3] + '</button>';
            } else {
              return '<button class="success_status" type="button">' + row[3] + '</button>';
            }

          }
        },
        {
          data: '1'
        },
        {
          data: '2',
        },
        {
          data: '5'
        },



      ],
      "columnDefs": [{
          "width": "3%",
          "targets": 0
        },
        {
          "width": "10%",
          "targets": 1
        },
        {
          "width": "8%",
          "targets": 2
        },
        {
          "width": "5%",
          "targets": 3
        },
        {
          "width": "15%",
          "targets": 4
        },
        {
          "width": "8%",
          "targets": 5
        },


      ],

    });


    // $('#customer_view').DataTable({
    //   'responsive': true,
    //   "processing": true,
    //   "bInfo": false,
    //   "dom": 'Blfrtip',
    //   "bFilter": false,
    //   "deferRender": true,
    //   "autoWidth": false,
    //   "fixedHeader": {
    //     "header": false,
    //     "footer": false
    //   },
    //   initComplete: function() {
    //     $(".table_loading").fadeIn("300");
    //   },
    //   "destroy": true,
    //   searching: true,
    //   info: false,
    //   "columnDefs": [{
    //       "width": "3%",
    //       "targets": 0
    //     },
    //     {
    //       "width": "10%",
    //       "targets": 1
    //     },
    //     {
    //       "width": "8%",
    //       "targets": 2
    //     },
    //     {
    //       "width": "5%",
    //       "targets": 3
    //     },
    //     {
    //       "width": "12%",
    //       "targets": 4
    //     },
    //     {
    //       "width": "12%",
    //       "targets": 5
    //     },


    //   ],
    // });
  });
</script>
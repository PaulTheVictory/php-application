const menumaster = require('../../models/menuMaster');
const asyncHandler = require("express-async-handler");
const { success } = require("../../utils/response");
const validateId = require("../../utils/validateId");
//create menu
const createMenu = asyncHandler(async (req, res) => {
  const check = await menumaster.findOne({ menu_name: req.body?.menu_name });
  if (check) throw new Error("Menu name already exists");
  try {
    const newMenu = await menumaster.create(req.body);
    if (newMenu) {
      success(res, 201, true, "Created Successfully", newMenu);
    } else {
      throw new Error('Please try again later')
    }
  } catch (error) {
    throw new Error(error);
  }
});
//update menu
const updateMenu = asyncHandler(async (req, res) => {
  const { id } = req.params;
  validateId(id);
  const check = await menumaster.findOne({menu_name: req.body?.menu_name});
  const checkup = await menumaster.findOne({ id });
  if (check) throw new Error("Menu name already exists");
  if (!checkup) throw new Error("Data not found");
  try {
    const updateMenu = await menumaster.findByIdAndUpdate(id, req.body, { new: true });
    if (updateMenu) {
      success(res, 200, true, "Update Successfully");
    } else {
      throw new Error("Please try again later!");
    }
  } catch (error) {
    throw new Error("Please try again later");
  }
});
//delete menu
const deleteMenu = asyncHandler(async (req, res) => {
  const { id } = req.params;
  validateId(id);
  const check = await menumaster.findOne({ _id: id });
  if (!check) throw new Error("Data not found");
  try {
    const deleteMenu = await menumaster.findByIdAndDelete(id);
    if (deleteMenu) {
      success(res, 200, true, "Deleted Successfully");
    } else {
      throw new Error("Please try again later!");
    }
  } catch (error) {
    throw new Error(error);
  }
});
//getsingle menu
const getsingleMenu = asyncHandler(async (req, res) => {
  const { id } = req.params;
  validateId(id);
  const check = await menumaster.findOne({ _id: id });
  if (!check) throw new Error("Data not found");
  try {
    const getsingleMenu = await menumaster.findOne({ _id: id });
    if (getsingleMenu) {
      success(res, 200, true, "Get data successfully", getsingleMenu);
    } else {
      throw new Error('Get Failed!');
    }
  } catch (error) {
    throw new Error(error);
  }
});
//getall menu
const getallMenu = asyncHandler(async (req, res) => {
  const check = await menumaster.find().countDocuments();
  if (check===0) throw new Error("Data not found");
  try {
    const getallMenu = await menumaster.find();
    if (getallMenu) {
      success(res, 200, true, "Get data successfully", getallMenu);
    } else {
      throw new Error("Get Failed!");
    }
  } catch (error) {
    throw new Error(error);
  }
});

module.exports = {
  createMenu,
  updateMenu,
  deleteMenu,
  getsingleMenu,
  getallMenu,
};
const sendToken = (user, statusCode, res) => {
  const token = user.getJwtToken();

  //Option for Cookies

  const options = {
    expires: new Date(Date.now() + 1 * 24 * 60 * 60 * 1000),
    httpOnly: true,
  };

  res.status(statusCode).cookie("token", token, options).json({
    status: 200,
    success: true,
    user,
    token,
  });
};

module.exports = sendToken;

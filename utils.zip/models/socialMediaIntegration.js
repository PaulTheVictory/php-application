const mongoose = require("mongoose");

var socialMediaIntegration = new mongoose.Schema(
  {
    social_media_name: {
      type: String,
      required: true,
    },
    social_media_icon: {
      type: String,
      required: true,
    },
    social_media_link: {
      type: String,
      required: true,
    },
    company_code: {
      type: String,
      required: true,
    },
    status: {
      type: Boolean,
      required: true,
    },
    created_date_time: {
      type: Date,
      required: true,
      default: Date.now(),
    },
  },
  {
    timestamps: true,
    versionKey: false,
  }
);

module.exports = mongoose.model(
  "socialmediaintegration",
  socialMediaIntegration
);

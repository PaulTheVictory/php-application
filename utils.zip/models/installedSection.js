const mongoose = require("mongoose");

var installedSection = new mongoose.Schema(
  {
    template_id: {
      type: String,
      required: true,
    },
    author_id: {
      type: String,
      required: true,
    },
    buyer_id: {
      type: String,
      required: true,
    },
    company_code: {
      type: String,
      required: true,
    },
    installed_datetime: {
      type: Date,
      required: true,
    },
    section_id: {
      type: String,
      required: true,
    },
    section_details: {
      type: String,
      required: true,
    },
    section_installed_datetime: {
      type: String,
      required: true,
    },
    status: {
      type: Boolean,
      required: true,
    },
    created_date_time: {
      type: Date,
      required: true,
      default: Date.now(),
    },
  },
  {
    timestamps: true,
    versionKey: false,
  }
);

module.exports = mongoose.model("installedsection", installedSection);

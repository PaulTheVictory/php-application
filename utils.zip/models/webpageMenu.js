const mongoose = require("mongoose");

var webpageMenu = new mongoose.Schema(
  {
    name: {
      type: String,
      required: true,
    },
    tool_tip: {
      type: String,
      required: true,
    },
    brief: {
      type: String,
      required: true,
    },
    company_code: {
      type: String,
      required: true,
    },
    description: {
      type: String,
      required: true,
    },
    pagetitle: {
      type: String,
      required: true,
    },
    metatag: {
      type: String,
      required: true,
    },
    meta_keyword: {
      type: String,
      required: true,
    },
    meta_description: {
      type: String,
      required: true,
    },
    othermetas: {
      type: String,
      required: true,
    },
    order_no: {
      type: String,
      required: true,
    },
    status: {
      type: Boolean,
      required: true,
    },
    created_date_time: {
      type: Date,
      required: true,
      default: Date.now(),
    },
  },
  {
    timestamps: true,
    versionKey: false,
  }
);

module.exports = mongoose.model("webpagemenu", webpageMenu);

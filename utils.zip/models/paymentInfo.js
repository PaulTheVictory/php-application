const mongoose = require("mongoose");

var paymentInfo = new mongoose.Schema(
  {
    order_id: {
      type: String,
    },
    company_code: {
      type: String,
      required: true,
    },
    company_gst: {
      type: String,
    },
    buyer_id: {
      type: String,
      required: true,
    },
    order_no: {
      type: String,
      required: true,
    },
    product_id: {
      type: String,
      required: true,
    },
    product_name: {
      type: String,
      required: true,
    },
    product_spec: {
      type: String,
      required: true,
    },
    product_qty: {
      type: String,
    },
    payment_status: {
      type: String,
      required: true,
    },
    transaction_id: {
      type: String,
      required: true,
    },
    bank_ref: {
      type: String,
      required: true,
    },
    mode_of_payment: {
      type: String,
      required: true,
    },
    total_paid_amount: {
      type: Number,
      required: true,
    },
    payment_date_time: {
      type: Date,
      required: true,
    },
    created_date_time: {
      type: Date,
      required: true,
      default: Date.now(),
    },
  },
  {
    timestamps: true,
    versionKey: false,
  }
);

module.exports = mongoose.model("paymentinfo", paymentInfo);

const mongoose = require("mongoose");

var discountsRules = new mongoose.Schema(
  {
    discount_id: {
      type: String,
      required: true,
    },
    applicable_to: {
      type: String,
      required: true,
    },
    buying_value_minimum: {
      type: String,
      required: true,
    },
    transaction_value: {
      type: String,
      required: true,
    },
    status: {
      type: Boolean,
      required: true,
    },
    created_date_time: {
      type: Date,
      required: true,
      default: Date.now(),
    },
  },
  {
    timestamps: true,
    versionKey: false,
  }
);

module.exports = mongoose.model("discountsrules", discountsRules);

const mongoose = require('mongoose');

// importing schemas to create model
const importedusersSchema = require('../schemas/users');





//Creating schema
const UsersSchema = mongoose.Schema(importedusersSchema, {
  timestamps: true,
  versionKey: false,
});





//Creating models
const UsersModel = mongoose.model('users', UsersSchema);





module.exports = {
  users:UsersModel
};

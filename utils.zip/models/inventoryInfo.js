const mongoose = require("mongoose");

var inventoryInfo = new mongoose.Schema(
  {
    financial_year: {
      type: String,
      required: true,
    },
    product_id: {
      type: String,
      required: true,
    },
    product_name: {
      type: String,
      required: true,
    },
    product_spec: {
      type: String,
      required: true,
    },
    qty: {
      type: String,
      required: true,
    },
    cost: {
      type: String,
      required: true,
    },
    inventory_status: {
      type: String,
      required: true,
    },
    inventory_ref: {
      type: String,
    },
    inventory_ref_detail: {
      type: String,
    },
    created_by: {
      type: Date,
      required: true,
      default: Date.now(),
    },
    created_date_time: {
      type: Date,
      required: true,
      default: Date.now(),
    },
  },
  {
    timestamps: true,
    versionKey: false,
  }
);

module.exports = mongoose.model("inventoryinfo", inventoryInfo);

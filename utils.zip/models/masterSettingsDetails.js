const mongoose = require("mongoose");

var masterSettingsDetails = new mongoose.Schema(
  {
    master_id: {
      type: String,
      required: true,
    },
    image: {
      type: String,
      required: true,
    },
    description: {
      type: String,
      required: true,
      trim: true,
    },
    status: {
      type: Boolean,
      required: true,
    }
  },
  {
    timestamps: true,
    versionKey: false,
  }
);

module.exports = mongoose.model("mastersettingsdetails", masterSettingsDetails);

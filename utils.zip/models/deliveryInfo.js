const mongoose = require("mongoose");

var deliveryInfo = new mongoose.Schema(
  {
    order_id: {
      type: String,
    },
    company_code: {
      type: String,
      required: true,
    },
    company_gst: {
      type: String,
    },
    buyer_id: {
      type: String,
      required: true,
    },
    order_no: {
      type: String,
      required: true,
    },
    product_id: {
      type: String,
      required: true,
    },
    product_name: {
      type: String,
      required: true,
    },
    product_spec: {
      type: String,
      required: true,
    },
    product_qty: {
      type: String,
      required: true,
    },
    packing_info: {
      type: Date,
      required: true,
    },
    packed_date: {
      type: Date,
      required: true,
    },
    batch_no: {
      type: String,
    },
    dispatch_through: {
      type: String,
    },
    dispatch_date_time: {
      type: Date,
    },
    dispatch_pod: {
      type: String,
    },
    dispatch_vehicle_no: {
      type: String,
    },
    dispatch_info: {
      type: String,
    },
    dispatch_by: {
      type: String,
    },
    dispatch_detail_created_date: {
      type: Date,
    },
    delivery_id: {
      type: String,
    },
    delivered_date_time: {
      type: String,
    },
    delivered_by: {
      type: String,
    },
    delivery_info: {
      type: String,
    },
  },
  {
    timestamps: true,
    versionKey: false,
  }
);

module.exports = mongoose.model("deliveryinfo", deliveryInfo);

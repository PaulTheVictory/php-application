const mongoose = require("mongoose");

var buyerRegistration = new mongoose.Schema(
  {
    company_code: {
      type: String,
      required: true,
    },
    buyer_code: {
      type: String,
      required: true,
    },
    buyer_name: {
      type: String,
      required: true,
      trim: true,
    },
    buyer_number: {
      type: Number,
      required: true,
      unique: true,
      trim: true,
      minlength: 10,
      maxlength: 15,
    },
    buyer_emailid: {
      type: String,
      required: true,
      unique: true,
      trim: true,
    },
    buyer_password: {
      type: String,
      required: true,
    },
    status: {
      type: Boolean,
      required: true,
    },
    created_date_time: {
      type: Date,
      required: true,
      default: Date.now(),
    },
  },
  {
    timestamps: true,
    versionKey: false,
  }
);

module.exports = mongoose.model("buyerregistration", buyerRegistration);

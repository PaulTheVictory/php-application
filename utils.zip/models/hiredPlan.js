const mongoose = require("mongoose");

var hiredPlan = new mongoose.Schema(
  {
    plan_id: {
      type: String,
      required: true,
    },
    user_id: {
      type: String,
      required: true,
    },
    amount: {
      type: Number.toFixed(2),
      maxlength:10,
      required: true,
    },
    mode_of_transaction: {
      type: String,
      required: true,
    },
    transaction_status: {
      type: String,
      required: true,
    },
    transaction_date_time: {
      type: String,
      required: true,
    },
    transaction_id: {
      type: String,
      required: true,
    },
    src_number: {
      type: String,
      required: true,
    },
    end_of_license: {
      type: String,
      required: true,
    },
  },
  {
    timestamps: true,
    versionKey: false,
  }
);

module.exports = mongoose.model("hiredplan", hiredPlan);

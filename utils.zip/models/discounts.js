const mongoose = require("mongoose");

var discounts = new mongoose.Schema(
  {
    company_code: {
      type: String,
      required: true,
    },
    discount_title: {
      type: String,
      required: true,
    },
    discount_valid_from: {
      type: Date,
      required: true,
    },
    discount_valid_to: {
      type: Date,
      required: true,
    },
    discount: {
      type: String,
      required: true,
    },
    discount_rules: {
      type: Boolean,
      required: true,
    },
    status: {
      type: Boolean,
      required: true,
    },
    created_date_time: {
      type: Date,
      required: true,
      default: Date.now(),
    },
  },
  {
    timestamps: true,
    versionKey: false,
  }
);

module.exports = mongoose.model("discounts", discounts);

const mongoose = require("mongoose");

var offerApplicableProducts = new mongoose.Schema(
  {
    offer_id: {
      type: String,
      required: true,
    },
    product_id: {
      type: String,
      required: true,
    },
    status: {
      type: Boolean,
      required: true,
    },
    created_date_time: {
      type: Date,
      required: true,
      default: Date.now(),
    },
  },
  {
    timestamps: true,
    versionKey: false,
  }
);

module.exports = mongoose.model(
  "offerapplicableproducts",
  offerApplicableProducts
);

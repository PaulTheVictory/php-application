const mongoose = require("mongoose");

var returnInfo = new mongoose.Schema(
  {
    order_id: {
      type: String,
    },
    company_code: {
      type: String,
      required: true,
    },
    company_gst: {
      type: String,
    },
    buyer_id: {
      type: String,
      required: true,
    },
    order_no: {
      type: String,
      required: true,
    },
    product_id: {
      type: String,
      required: true,
    },
    product_name: {
      type: String,
      required: true,
    },
    product_spec: {
      type: String,
      required: true,
    },
    product_qty: {
      type: String,
    },
    return_reason: {
      type: String,
    },
    mode_of_return: {
      type: String,
    },
    return_charges: {
      type: String,
    },
    replacement_yes_or_no: {
      type: Boolean,
    },
    return_date: {
      type: Date,
    },
    received_by: {
      type: String,
    },
    created_date_time: {
      type: Date,
      required: true,
      default: Date.now(),
    },
  },
  {
    timestamps: true,
    versionKey: false,
  }
);

module.exports = mongoose.model("returninfo", returnInfo);

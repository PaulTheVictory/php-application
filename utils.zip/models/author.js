const mongoose = require("mongoose");

var author = new mongoose.Schema(
  {
    author_name: {
      type: String,
      required: true,
    },
    author_lastname: {
      type: String,
    },
    author_code: {
      type: String,
    },
    author_mobile: {
      type: String,
    },
    author_email: {
      type: String,
    },
    author_password: {
      type: String,
    },
    author_bankname: {
      type: String,
    },
    author_account_number: {
      type: String,
    },
    author_bank_branch: {
      type: String,
    },
    author_bank_ifsc: {
      type: String,
    },
    author_bank_verified: {
      type: String,
    },
    author_bank_verified_datetime: {
      type: String,
    },
    author_referedby: {
      type: String,
    },
    author_bankverification_status: {
      type: String,
    },
    author_bankverification_refid: {
      type: String,
    },
    author_bankverification_msg: {
      type: String,
    },
    author_bankverification_msg: {
      type: String,
    },
    author_bankverification_details: {
      type: String,
    },
    created_by: {
      type: Date,
      required: true,
      default: Date.now(),
    },
    created_date_time: {
      type: Date,
      required: true,
      default: Date.now(),
    },
  },
  {
    timestamps: true,
    versionKey: false,
  }
);

module.exports = mongoose.model("author", author);

const mongoose = require("mongoose");

var accessSettings = new mongoose.Schema(
  {
    user_id: {
      type: String,
      required: true,
      unique: true,
    },
    menu_id: {
      type: String,
      required: true,
    },
    access_permission: {
      type: String,
      required: true,
    },
  },
  {
    timestamps: true,
    versionKey: false,
  }
);

module.exports = mongoose.model("accesssettings", accessSettings);

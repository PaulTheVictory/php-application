const mongoose = require("mongoose");

var themeCategory = new mongoose.Schema(
  {
    template_category: {
      type: String,
      required: true,
    },
    status: {
      type: Boolean,
      required: true,
    },
    created_date_time: {
      type: Date,
      required: true,
      default: Date.now(),
    },
  },
  {
    timestamps: true,
    versionKey: false,
  }
);

module.exports = mongoose.model("themecategory", themeCategory);

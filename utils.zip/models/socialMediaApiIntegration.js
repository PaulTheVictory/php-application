const mongoose = require("mongoose");

var socialMediaApiIntegration = new mongoose.Schema(
  {
    social_media_id: {
      type: String,
      required: true,
    },
    api_key: {
      type: String,
      required: true,
    },
    api_details: {
      type: String,
      required: true,
    },
    company_code: {
      type: String,
      required: true,
    },
    status: {
      type: Boolean,
      required: true,
    },
    created_date_time: {
      type: Date,
      required: true,
      default: Date.now(),
    },
  },
  {
    timestamps: true,
    versionKey: false,
  }
);

module.exports = mongoose.model(
  "socialmediaapiintegration",
  socialMediaApiIntegration
);

const mongoose = require("mongoose");

var section = new mongoose.Schema(
  {
    section_category: {
      type: String,
      required: true,
    },
    section_object: {
      type: String,
      required: true,
    },
    section_key: {
      type: String,
      required: true,
    },
    section_value: {
      type: String,
      required: true,
    },
    status: {
      type: Boolean,
      required: true,
    },
    created_date_time: {
      type: Date,
      required: true,
      default: Date.now(),
    },
  },
  {
    timestamps: true,
    versionKey: false,
  }
);

module.exports = mongoose.model("section", section);

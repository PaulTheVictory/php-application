const mongoose = require("mongoose");

var tax = new mongoose.Schema(
  {
    company_code: {
      type: String,
      required: true,
    },
    hsn_code: {
      type: String,
      required: true,
    },
    tax_percentage: {
      type: Number.toFixed(2),
      maxlength:5,
      required: true,
    },
    status: {
      type: Boolean,
      required: true,
    },
    created_date_time: {
      type: Date,
      required: true,
      default: Date.now(),
    },
  },
  {
    timestamps: true,
    versionKey: false,
  }
);

module.exports = mongoose.model("tax", tax);

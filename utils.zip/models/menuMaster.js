const mongoose = require("mongoose");
let Schema = mongoose.Schema;
var menuMaster = new mongoose.Schema(
  {
    menu_name: {
      type: String,
      required: true,
      unique: true,
      trim: true,
    },
    url: {
      type: String,
      required: true,
    },
    menu_icon: {
      type: String,
    },
    menu_type: {
      type: String,
    },
    parent_id: [{
      type: String,
    }],
    status: {
      type: Boolean,
      required: true,
      default: true,
    },
  },
  {
    timestamps: true,
    versionKey: false,
  }
);

module.exports = mongoose.model("menumaster", menuMaster);

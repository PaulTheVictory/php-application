const mongoose = require("mongoose");

var packingInfo = new mongoose.Schema(
  {
    order_id: {
      type: String,
    },
    company_code: {
      type: String,
      required: true,
    },
    company_gst: {
      type: String,
    },
    buyer_id: {
      type: String,
      required: true,
    },
    order_no: {
      type: String,
      required: true,
    },
    product_id: {
      type: String,
      required: true,
    },
    product_name: {
      type: String,
      required: true,
    },
    product_spec: {
      type: String,
      required: true,
    },
    product_qty: {
      type: String,
      required: true,
    },
    packing_info: {
      type: Date,
      required: true,
    },
    packed_date: {
      type: Date,
      required: true,
    },
    batch_no: {
      type: String,
    },
    status: {
      type: String,
      required: true,
      default: "open",
      enum:['open','close'],
    },
    created_date_time: {
      type: Date,
      required: true,
      default: Date.now(),
    },
  },
  {
    timestamps: true,
    versionKey: false,
  }
);

module.exports = mongoose.model("packinginfo", packingInfo);

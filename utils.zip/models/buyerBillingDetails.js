const mongoose = require("mongoose");

var buyerBillingDetails = new mongoose.Schema(
  {
    buyer_id: {
      type: String,
      required: true,
    },
    buyer_address: {
      type: String,
      required: true,
    },
    buyer_city: {
      type: String,
      required: true,
    },
    buyer_state: {
      type: String,
      required: true,
    },
    buyer_pincode: {
      type: Number,
      required: true,
      minlength: 6,
      maxlength: 12,
      trim: true,
    },
    buyer_delivery_contact_number: {
      type: Number,
      required: true,
      minlength: 10,
      maxlength: 15,
    },
    status: {
      type: Boolean,
      required: true,
    },
    created_date_time: {
      type: Date,
      required: true,
      default: Date.now(),
    },
  },
  {
    timestamps: true,
    versionKey: false,
  }
);

module.exports = mongoose.model("buyerbillingdetails", buyerBillingDetails);

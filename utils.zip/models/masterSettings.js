const mongoose = require("mongoose");

var masterSettings = new mongoose.Schema(
  {
    company_code: {
      type: String,
      required: true,
    },
    user_id: {
      type: String,
      required: true,
    },
    name: {
      type: String,
      required: true,
      unique: true,
      trim: true,
    },
    details_available: {
      type: Boolean,
      required: true,
    },
    mode: {
      type: String,
      required: true,
    },
    parent_id: {
      type: String,
      required: true,
    },
    status: {
      type: Boolean,
      required: true,
    },
    created_date_time: {
      type: Date,
      default:Date.now(),
      required: true,
    }
  },
  {
    timestamps: true,
    versionKey: false,
  }
);

module.exports = mongoose.model("mastersettings", masterSettings);

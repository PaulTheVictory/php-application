const mongoose = require("mongoose");

var production = new mongoose.Schema(
  {
    financial_year: {
      type: String,
      required: true,
    },
    production_date: {
      type: String,
      required: true,
    },
    production_no: {
      type: String,
      required: true,
    },
    product_id: {
      type: String,
      required: true,
    },
    product_name: {
      type: String,
      required: true,
    },
    product_spec: {
      type: String,
      required: true,
    },
    qty: {
      type: String,
      required: true,
    },
    cost: {
      type: String,
      required: true,
    },
    production_charges: {
      type: String,
      required: true,
    },
    other_expense: {
      type: String,
    },
    total_amount: {
      type: String,
      required: true,
    },
    grand_total: {
      type: String,
      required: true,
    },
    production_status: {
      type: String,
      required: true,
    },
    status_date_time: {
      type: String,
      required: true,
    },
    created_by: {
      type: Date,
      required: true,
      default: Date.now(),
    },
    created_date_time: {
      type: Date,
      required: true,
      default: Date.now(),
    },
  },
  {
    timestamps: true,
    versionKey: false,
  }
);

module.exports = mongoose.model("production", production);

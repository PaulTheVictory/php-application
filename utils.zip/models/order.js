const mongoose = require("mongoose");

var order = new mongoose.Schema(
  {
    company_code: {
      type: String,
      required: true,
    },
    company_gst: {
      type: String,
    },
    buyer_id: {
      type: String,
      required: true,
      trim: true,
    },
    order_no: {
      type: String,
      required: true,
    },
    product_id: {
      type: String,
      required: true,
    },
    product_name: {
      type: String,
    },
    product_spec: {
      type: String,
      required: true,
    },
    qty: {
      type: String,
      required: true,
    },
    cost: {
      type: String,
      required: true,
    },
    tax_percentage: {
      type: String,
      required: true,
    },
    hsncode: {
      type: String,
      required: true,
    },
    taxable_amount: {
      type: Number,
    },
    tax_amount: {
      type: Number,
    },
    sgst: {
      type: String,
    },
    cgst: {
      type: String,
    },
    igst: {
      type: String,
    },
    total_amount: {
      type: Number,
    },
    delivery_charges: {
      type: String,
    },
    delivery_tax: {
      type: String,
    },
    grand_total: {
      type: Number,
    },
    mode_of_delivery: {
      type: String,
    },
    delivery_date_time: {
      type: Date,
    },
    buyer_address: {
      type: String,
      required: true,
    },
    buyer_delivery_address: {
      type: String,
      required: true,
    },
    buyer_district: {
      type: String,
      required: true,
    },
    buyer_state: {
      type: String,
      required: true,
    },
    buyer_pincode: {
      type: Number,
      required: true,
    },
    buyer_landmark: {
      type: String,
      required: true,
    },
    buyer_contact_number: {
      type: String,
      required: true,
    },
    payment_status: {
      type: String,
      required: true,
    },
    transaction_id: {
      type: String,
      required: true,
    },
    bank_ref: {
      type: String,
      required: true,
    },
    mode_of_payment: {
      type: String,
      required: true,
    },
    total_paid_amount: {
      type: String,
      required: true,
    },
    payment_date_time: {
      type: String,
      required: true,
    },
    buyer_system: {
      type: String,
      required: true,
    },
    buyer_ip: {
      type: String,
      required: true,
    },
    buyer_outtime: {
      type: Date,
      required: true,
    },
    buyer_related_views: {
      type: String,
      required: true,
    },
    created_date_time: {
      type: Date,
      required: true,
      default: Date.now(),
    },
  },
  {
    timestamps: true,
    versionKey: false,
  }
);

module.exports = mongoose.model("order", order);

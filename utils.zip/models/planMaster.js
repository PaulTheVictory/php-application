const mongoose = require("mongoose");


var planMaster = new mongoose.Schema(
  {
    plan_name: {
      type: String,
      required: true,
    },
    plan_amount: {
      type: Date,
      required: true,
    },
    plan_description: {
      type: String,
      default: "",
    },
    plan_status: {
      type: Boolean,
      default: true,
      required: true,
    },
    plan_created_date: {
      type: Date,
      default: Date.now(),
      required: true,
    },
    license_validaty_in_days: {
      type: Date,
      required: true,
    },
  },
  {
    timestamps: true,
    versionKey:false,
  }
);

module.exports = mongoose.model("planmaster", planMaster);

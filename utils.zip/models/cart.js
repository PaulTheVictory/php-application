const mongoose = require("mongoose");

var cart = new mongoose.Schema(
  {
    company_code: {
      type: String,
      required: true,
    },
    buyer_id: {
      type: String,
      required: true,
    },
    product_id: {
      type: String,
      required: true,
      trim: true,
    },
    product_spec: {
      type: String,
      required: true,
    },
    oty: {
      type: String,
      required: true,
    },
    cost: {
      type: String,
      required: true,
    },
    tax_percentage: {
      type: Date,
      required: true,
    },
    buyer_system: {
      type: Boolean,
      required: true,
    },
    buyer_ip: {
      type: Boolean,
      required: true,
    },
    buyer_outtime: {
      type: Boolean,
      required: true,
    },
    buyer_related_views: {
      type: Boolean,
      required: true,
    },
    created_date_time: {
      type: Date,
      required: true,
      default: Date.now(),
    },
  },
  {
    timestamps: true,
    versionKey: false,
  }
);

module.exports = mongoose.model("cart", cart);

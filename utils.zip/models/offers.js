const mongoose = require("mongoose");

var offers = new mongoose.Schema(
  {
    company_code: {
      type: String,
      required: true,
    },
    offer_title: {
      type: String,
      required: true,
    },
    offer_valid_from: {
      type: Date,
      required: true,
    },
    offer_valid_to: {
      type: Date,
      required: true,
    },
    offer: {
      type: String,
      required: true,
    },
    offer_rules: {
      type: Boolean,
      required: true,
    },
    status: {
      type: Boolean,
      required: true,
    },
    created_date_time: {
      type: Date,
      required: true,
      default: Date.now(),
    },
  },
  {
    timestamps: true,
    versionKey: false,
  }
);

module.exports = mongoose.model("offers", offers);

const mongoose = require("mongoose");

var installedTemplates = new mongoose.Schema(
  {
    template_id: {
      type: String,
      required: true,
    },
    author_id: {
      type: String,
      required: true,
    },
    buyer_id: {
      type: String,
      required: true,
    },
    company_code: {
      type: String,
      required: true,
    },
    installed_datetime: {
      type: Date,
      required: true,
    },
    payment_status: {
      type: String,
      required: true,
    },
    paid_date: {
      type: Date,
      required: true,
    },
    payment_details: {
      type: String,
      required: true,
    },
    free_paid: {
      type: String,
      required: true,
    },
    template_cost: {
      type: Number,
      required: true,
    },
    license_type: {
      type: String,
      required: true,
    },
    status: {
      type: Boolean,
      required: true,
    },
    created_date_time: {
      type: Date,
      required: true,
      default: Date.now(),
    },
  },
  {
    timestamps: true,
    versionKey: false,
  }
);

module.exports = mongoose.model("installedtemplates", installedTemplates);

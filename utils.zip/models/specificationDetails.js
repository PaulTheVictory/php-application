const mongoose = require("mongoose");

var specificationDetails = new mongoose.Schema(
  {
    company_code: {
      type: String,
      required: true,
    },
    specification_id: {
      type: String,
      required: true,
    },
    specification_details: {
      type: String,
      required: true,
    },
    status: {
      type: Boolean,
      required: true,
    },
    created_date_time: {
      type: Date,
      required: true,
      default: Date.now(),
    },
  },
  {
    timestamps: true,
    versionKey: false,
  }
);

module.exports = mongoose.model("specificationdetails", specificationDetails);

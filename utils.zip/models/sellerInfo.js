const mongoose = require("mongoose");

var sellerInfo = new mongoose.Schema(
  {
    user_id: {
      type: String,
      required: true,
    },
    company_name: {
      type: String,
      required: true,
    },
    gstin: {
      type: String,
      required: true,
    },
    company_pan: {
      type: String,
      required: true,
    },
    mobile_number: {
      type: Number,
      minlength: 10,
      maxlength: 15,
      required: true,
      unique: true,
      trim: true,
    },
    contact_number: {
      type: Number,
      required: true,
      minlength: 10,
      maxlength: 15,
      trim: true,
    },
    email_id: {
      type: String,
      required: true,
      unique: true,
      trim: true,
    },
    company_code: {
      type: String,
      required: true,
    },
    company_addresss: {
      type: String,
      required: true,
    },
    city: {
      type: String,
      required: true,
    },
    state: {
      type: String,
      required: true,
    },
    pin_code: {
      type: String,
      required: true,
    },
    status: {
      type: Boolean,
      required: true,
    },
  },
  {
    timestamps: true,
    versionKey: false,
  }
);

module.exports = mongoose.model("sellerinfo", sellerInfo);

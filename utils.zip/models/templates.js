const mongoose = require("mongoose");

var template = new mongoose.Schema(
  {
    template_category: {
      type: String,
      required: true,
    },
    template_object: {
      type: String,
      required: true,
    },
    template_key: {
      type: String,
      required: true,
    },
    template_value: {
      type: String,
      required: true,
    },
    author_id: {
      type: String,
      required: true,
    },
    free_paid: {
      type: String,
      required: true,
    },
    template_cost: {
      type: String,
      required: true,
    },
    license_type: {
      type: String,
      required: true,
    },
    status: {
      type: Boolean,
      required: true,
    },
    created_date_time: {
      type: Date,
      required: true,
      default: Date.now(),
    },
  },
  {
    timestamps: true,
    versionKey: false,
  }
);

module.exports = mongoose.model("template", template);

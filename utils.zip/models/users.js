const mongoose = require("mongoose");

var users = new mongoose.Schema(
  {
    company_code: {
      type: String,
      required: true,
    },
    display_name: {
      type: String,
      required: true,
    },
    username: {
      type: String,
      required: true,
    },
    password: {
      type: String,
      required: true,
      unique: true,
      trim: true,
      minlength: 6,
      maxlength: 15,
    },
    mobile_number: {
      type: Number,
      required: true,
    },
    email_id: {
      type: String,
      required: true,
      unique: true,
      trim: true,
    },
    status: {
      type: Boolean,
      required: true,
    },
    pin_code: {
      type: String,
      required: true,
    }
  },
  {
    timestamps: true,
    versionKey: false,
  }
);

module.exports = mongoose.model("users", users);

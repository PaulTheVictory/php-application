const mongoose = require("mongoose");

var bill = new mongoose.Schema(
  {
    order_id: {
      type: String,
    },
    company_code: {
      type: String,
      required: true,
    },
    company_gst: {
      type: String,
    },
    buyer_id: {
      type: String,
      required: true,
    },
    buyer_address: {
      type: String,
    },
    buyer_district: {
      type: String,
    },
    buyer_state: {
      type: String,
    },
    buyer_pincode: {
      type: String,
    },
    buyer_state_code: {
      type: String,
    },
    buyer_gst: {
      type: String,
    },
    order_no: {
      type: String,
      required: true,
    },
    financial_year: {
      type: String,
      required: true,
    },
    bill_date: {
      type: String,
      required: true,
    },
    bill_no: {
      type: String,
      required: true,
    },
    bill_prefix: {
      type: String,
      required: true,
    },
    product_id: {
      type: String,
      required: true,
    },
    product_name: {
      type: String,
      required: true,
    },
    product_spec: {
      type: String,
      required: true,
    },
    qty: {
      type: String,
      required: true,
    },
    cost: {
      type: String,
      required: true,
    },
    tax_percentage: {
      type: String,
      required: true,
    },
    hsncode: {
      type: String,
      required: true,
    },
    taxable_amount: {
      type: String,
      required: true,
    },
    tax_amount: {
      type: String,
      required: true,
    },
    sgst: {
      type: String,
      required: true,
    },
    cgst: {
      type: String,
      required: true,
    },
    igst: {
      type: String,
      required: true,
    },
    total_amount: {
      type: String,
      required: true,
    },
    delivery_charges: {
      type: String,
      required: true,
    },
    delivery_tax: {
      type: String,
      required: true,
    },
    grand_total: {
      type: String,
      required: true,
    },
    mode_of_delivery: {
      type: String,
      required: true,
    },
    created_by: {
      type: Date,
      required: true,
    },
    created_date_time: {
      type: Date,
      required: true,
      default: Date.now(),
    },
  },
  {
    timestamps: true,
    versionKey: false,
  }
);

module.exports = mongoose.model("bill", bill);

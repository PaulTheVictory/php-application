const SiteBaseUrl = "/api/v1/";

module.exports = function (app) {
  app.use(SiteBaseUrl + "users", require("../controllers/users"));
};



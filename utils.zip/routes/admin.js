const express = require('express');
const { createAdmin,loginAdmin,logoutAdmin } = require('../controller/sample/adminCtrl');
const {
  createMenu,
  updateMenu,
  deleteMenu,
  getsingleMenu,
  getallMenu,
} = require("../controller/admin/menuMaster");
const router = express.Router();
const { authAdmin } = require('../middlewares/authMiddlewares');
router
  .post("/register", createAdmin)
  .post("/login", loginAdmin)
  .put("/logout", authAdmin, logoutAdmin)
  .post("/menumaster/", createMenu)
  .put("/menumaster/:id", updateMenu)
  .delete("/menumaster/:id", deleteMenu)
  .get("/menumaster/:id", getsingleMenu)
  .get("/menumaster/", getallMenu);





module.exports = router;

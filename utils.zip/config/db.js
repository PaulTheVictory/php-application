const mongoose = require("mongoose");

const connectDatabase = () => {
  const server = "127.0.0.1:27017";
  const database = "ecom";

  mongoose
    .connect(`mongodb://${server}/${database}`, {
      useNewUrlParser: true,
      useUnifiedTopology: true,
    })
    .then(() => {
      console.log("MongoDB connected!!");
    })
    .catch((err) => {
      console.log("Failed to connect to MongoDB", err);
    });
};

module.exports = connectDatabase;

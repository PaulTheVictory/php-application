const express = require("express");
const Router = express.Router();
const DB = require("../models/db.js");
const db = require("../models/schemaconnection");
const catchasyncerrors = require('../utils/catchasyncerrors');
const sendtoken = require('../utils/jwttoken');
const bcrypt = require("bcrypt");

const project = {
  createdAt: 0,
  updatedAt: 0,
};
//Get All List
Router.get("/list", catchasyncerrors, function (req, res) {
  try {
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message,
    });
  }
});
//Create New
// Router.post('/create', catchasyncerrors(async function (req, res) {
//   try {
//     const { name, email, phone, password, company } = req.body;
//     console.log("test", req.body);
//     let email_check = await db.users.findOne({ email });
//     let phone_check = await db.users.findOne({ email });
    
//     if (email_check || phone_check) {
//       return res
//         .status(400)
//         .json({ success: false, message: "Email Address or Phone Number already Taken" });
//     }
//     user = await db.users.create(req.body);
//     const result = await db.users
//       .findOne({ email })
//       .select(["email", "role", "name", "status", "phone", "company"]);
    
//     return res.status(201).json({ result }).end();
    
    
//   } catch (error) {
//     res.status(500).json({
//       success: false,
//       message: error.message,
//     });
//   }
// }));

Router.post("/create", function (req, res) {
  let name = req.body.name;
  const formData = {
    name: name,
  };
  if (!name) {
    return res.status(400).json({ error: "name is required" });
  }
  console.log("Name", formData);
  DB.InsertDocument("users", formData, function (err, result) {
     console.log("res", result);
     console.log("err", err);
     if (err) {
       res.status(400).end();
     } else {
       res.status(200).end();
     }
   });
  // const result = await db.users.create(formData);
  // if (result) {
  //   res
  //     .status(200)
  //     .json({
  //       success: true,
  //       message: "Register Successfully",
  //       status: 200,
  //     })
  //     .end();
  // } else {
  //   res.status(400).end();
  // }
});

module.exports = Router;

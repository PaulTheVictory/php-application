<?php

/**

 * The template for displaying all single posts and attachments

 *

 * @package WordPress

 * @subpackage Twenty_Fifteen

 * @since Twenty Fifteen 1.0

 */



get_header(); 



if(is_home() || is_front_page()){$url = get_site_url();}else{$url = home_url( $wp->request )."/";}



?>





<div class="blog_section blog_single">
   <div class="wrap_grid">
      <div class="blog_section_top">
	  <div class="blog_section_top_left">

                
                <div class="blogdate">
                                
                 <h1><?php the_title();?></h1>

     			 <div class="post-date">
					<span></span>
					<?php the_time('F d,Y'); ?>
				</div>
				
				
				
					</div>
					
					
					 <?php if ( has_post_thumbnail() ) {the_post_thumbnail('medium_large');}else{?> 
								
					<img src="<?php echo esc_url(get_template_directory_uri());?>/images/harvee-blog.jpg" alt="Harvee Blog" style="margin:0 0 20px 0;"/>	
									
				<?php } ?>
					
					
					
				
					
					
					

		<?php
		// Start the loop.
		while ( have_posts() ) : the_post();

			/*
			 * Include the post format-specific template for the content. If you want to
			 * use this in a child theme, then include a file called called content-___.php
			 * (where ___ is the post format) and that will be used instead.
			 */
			the_content();
			
			?>
           
           
           
           					<?php 

				 $catname = "";
				foreach((get_the_category()) as $category){
					$category_link = get_category_link( $category->cat_ID );
					$catname .=  '<a href="'.esc_url( $category_link ).'" title="'.$category->name.'">'.$category->name.'</a> / ';
					}
				
				$catname = trim($catname);

				?>
				<?php if($catname!=""){?>	
				 <div class="post-cat">
					 <span></span>
				 	<?php echo substr($catname,0,-1);?>
     			 </div>
     			 <?php } ?>

            
            <?php

			// If comments are open or we have at least one comment, load up the comment template.
			if ( comments_open() || get_comments_number() ) :
				comments_template();
			endif;

			// Previous/next post navigation.
			setPostViews(get_the_ID());

		// End the loop.
		endwhile;
		?>
                
                    
    <?php the_posts_pagination( array(

								'mid_size' => 2,

								'prev_text' => __( 'Previous', 'textdomain' ),

								'next_text' => __( 'Next', 'textdomain' ),

							) ); ?>

		<?php wp_reset_postdata(); ?>

<?php //comment_form(); ?> 

</div>
<div class="blog_section_top_right">
<?php $uploaddir = wp_upload_dir('2018/12');include('includes/sidebar.php');?>

</div>

</div> 

</div>
</div>


<?php get_footer(); ?>


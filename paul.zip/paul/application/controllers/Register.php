 <?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Register extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model('user_model','usermodel',TRUE);
	}
	
	public function index()
	{
		

	if($this->session->userdata('adlog_in')==TRUE)
	{
		
		$data['title'] = 'New Register';
		$this->load->view('header.php',$data);
		$this->load->view('register_view.php');
		$this->load->view('footer.php');
		
	}
	else
	{
		redirect('signin', 'refresh');
	}


	}

	public function NewRegister()
	{

		$this->load->helper('form');
		$this->load->library('form_validation');
		$this->form_validation->set_rules('r_name','Name','trim|required|xss_clean|alpha');
		$this->form_validation->set_rules('r_phone','Mobile Number','trim|required|xss_clean|regex_match[/^[0-9]{10}$/]');
		$this->form_validation->set_rules('r_email', 'Email ID', 'trim|required|xss_clean|valid_email|is_unique[users.email]');
		$this->form_validation->set_rules('r_pass1', 'Password', 'trim|required|min_length[5]');
		$this->form_validation->set_rules('r_pass2', 'Password Confirmation', 'trim|required|matches[r_pass1]');

		// $this->form_validation->set_error_delimiters('<p class="alert alert-danger alert-dismissible fade show btn-block"><button type="button" class="close" data-dismiss="alert">&times;</button>', '</p>');
		if($this->form_validation->run()==FALSE)
		{
			$this->index();
		}
		else
		{
			$uniq_id = uniqid();
			$profile_id = uniqid();
			$name = $this->input->post('r_name',TRUE)." ".$this->input->post('r_lname',TRUE);
			$password = $this->input->post('r_pass1',TRUE);
			$encryptpass = SHA1($password);
			
			$data = array(
				'id' => $uniq_id,
				'name' => $name,
				'country' => '+91',
				'phone' => $this->input->post('r_phone',TRUE),
				'email' => $this->input->post('r_email',TRUE),
				'password' => $encryptpass,
				'role' => 'USER',
				'status' => 'SUCCESS'
			);
			$pdata = array(
				'profileid' =>$profile_id,
				'userid' => $uniq_id,
				'pname' => $name,
				'pcountrycode' => '+91',
				'pphone' => $this->input->post('r_phone',TRUE),
				'pemail' => $this->input->post('r_email',TRUE),
				'prole' => 'USER',
				'pviewstatus' => 'a',
				'pstatus' => 'SUCCESS'
			);
			$new_register = new user_model;
			$result = $new_register->NewUser($data);
			$presult = $new_register->NewUserProfile($pdata);

			if($result && $presult)
			{
				redirect('viewuser','refresh');
			}
			else
			{
				$this->session->flashdata('status','Something Went Wrong!');
				redirect('register','refresh');
			}
		}
	}


	











}

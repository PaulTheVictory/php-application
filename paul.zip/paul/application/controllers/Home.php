<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

	
	
	public function index()
	{
		

	if($this->session->userdata('adlog_in')==TRUE)
	{
		$data['title'] = "My Admin Dashboard";
		$this->load->view('header.php',$data);
		$this->load->view('dashboard_view.php');
		$this->load->view('footer.php');
		
	}
	elseif($this->session->userdata('logged_in')==TRUE)
	{
		$data['title'] = "My Dashboard";
		$this->load->view('header.php',$data);
		$this->load->view('home_view.php');
		$this->load->view('footer.php');
	}
	else
	{
		redirect('signin', 'refresh');
	}


	}
}

<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model('login_model','login',TRUE);
		$this->load->library('form_validation');
	}
	
	public function index()
	{
		
	if(!$this->session->userdata('logged_in') && !$this->session->userdata('adlog_in'))
	{
		$data['title'] = 'Login';
		$this->load->view('signinheader.php',$data);
		$this->load->view('login_view.php');
		$this->load->view('signinfooter.php');
		
	}
	else
	{
		if($this->session->userdata('logged_in')==TRUE)
		{
			redirect('home', 'refresh');
		}
		elseif($this->session->userdata('adlog_in')==TRUE)
		{
			redirect('dashboard', 'refresh');
		}
		
	}


	}


public function UserVerifycation()
{
	$result = array(0=>'');
	
	$this->form_validation->set_rules('username','Username','trim|required|xss_clean');
	$this->form_validation->set_rules('password','Password','trim|required|xss_clean');

	if($this->form_validation->run()==FALSE)
	{
		$result = array(0=>'validate fail');
		echo json_encode($result);
	}
	else
	{
		
		$username = $this->input->post('username',TRUE);
		$password = $this->input->post('password',TRUE);
		$verifystatus = 'open';
		

		$result = $this->login->LoginVerification($username,$password,$verifystatus);
		// echo json_encode($result);

		if($result[0]=='success')
		{
			$res_id = $result[1];
			$result = array(0=>'success',1=>$res_id);
			echo json_encode($result);
		}
		else
		{
			$result = array(0=>'email');
			echo json_encode($result);
		}



	}
}

public function SubmitOtp()
{
	$where_id = $this->input->post('where_id',TRUE);
	$otp = $this->input->post('otpnumber',TRUE);

	$result = $this->login->SubmitOtp($where_id);

	if(count($result)>0)
	{
		$db_otp = $result[0]['verifyid'];
		
		if($otp==$db_otp)
		{
			$result1 = array(0=>'success');
			echo json_encode($result1);
		}
		else
		{
			$result = array(0=>'otp fail');
			echo json_encode($result1);
		}
	}






	

	
}









}





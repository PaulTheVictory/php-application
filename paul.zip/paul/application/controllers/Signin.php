<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Signin extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model('signin_model','signin',TRUE);
	}
	
	public function index()
	{
		$this->load->library('form_validation');
	$this->form_validation->set_rules('username','Username','trim|required|xss_clean');
	$this->form_validation->set_rules('password','Password','trim|required|xss_clean|callback_validate_success');
	$this->form_validation->set_error_delimiters('<p class="alert alert-danger btn-block text-center">', '</p>');
	

	if($this->form_validation->run() == FALSE && !$this->session->userdata('logged_in') && !$this->session->userdata('adlog_in'))
	{
		$this->load->helper(array('form'));
		$this->load->view('signinheader.php');
		$this->load->view('signin_view.php');
		$this->load->view('signinfooter.php');
		
	}
	else
	{
		if($this->session->userdata('logged_in')==TRUE)
		{
			redirect('home', 'refresh');
		}
		elseif($this->session->userdata('adlog_in')==TRUE)
		{
			redirect('dashboard', 'refresh');
		}
		
	}


	}




function validate_success($password)
{
	$username = $this->input->post('username');

	$result = $this->signin->VerifySignin($username,$password);
	
	if(count($result) > 0)
	{
		
		$dbid = $result[0]['id'];
		$dbname = $result[0]['name'];
		$dbrole = $result[0]['role'];
		$dbstatus = $result[0]['status'];
		$offset=5*60*60 + 30*60;
		$dateformat = 'Y-m-d H:i:s';
		$created = gmdate($dateformat, time()+$offset);

		if($dbrole=='ADMIN')
		{
			$sess_data = array(
			'id'=>$dbid,
			'username'=>$dbname,
			'role'=>$dbrole,
			'status'=>$dbstatus,
			'adlog_in'=>TRUE,
			'sessionstart_time'=>$created
		);
		}
		else
		{
		$sess_data = array(
			'id'=>$dbid,
			'username'=>$dbname,
			'role'=>$dbrole,
			'status'=>$dbstatus,
			'logged_in'=>TRUE,
			'sessionstart_time'=>$created
		);
		}

		

		$this->session->set_userdata($sess_data);

		if($this->session->userdata['status']=="SUCCESS" && $this->session->userdata('adlog_in')==TRUE || $this->session->userdata('logged_in')==TRUE)
		{
			$ses_uid = uniqid();
			$this->load->library('user_agent');
			$sessid = $this->session->userdata('id');
			$sess_agent = $this->agent->browser()." ".$this->agent->version();
			$sess_user = $this->session->userdata('username');
			$sess_login = $this->session->userdata('sessionstart_time');
			$sess_ip = $this->input->ip_address();
			$sess_role = $this->session->userdata('role');

		}

		
		$this->signin->CreatSession($ses_uid,$sessid,$sess_login,$sess_agent,$sess_user,$sess_ip,$sess_role);

		
		return TRUE;
	}
	else
	{
		$this->form_validation->set_message('validate_success', 'Invalid Username or Password');
		return FALSE;
	}



}

public function Logout()
{
	$offset=5*60*60 + 30*60;
	$dateformat = 'Y-m-d H:i:s';
	$end = gmdate($dateformat, time()+$offset);

	$sessionid = $this->session->userdata('id');

		$this->signin->EndSession($sessionid,$end);

   		$this->session->unset_userdata('logged_in');

		$this->session->sess_destroy();

   		redirect('signin', 'refresh');

}





















}





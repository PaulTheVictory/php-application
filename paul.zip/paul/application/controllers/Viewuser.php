<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Viewuser extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model('user_model','',TRUE);
	}

public function index()
	{


if($this->session->userdata('adlog_in')==TRUE)
	{
		$data['userlist'] = $this->user_model->GetUserLists();
		$data['title'] = "User Lists";
		$this->load->view('header.php',$data);
		$this->load->view('viewuser_view.php');
		$this->load->view('footer.php');
	}
	else
	{
		redirect('signin', 'refresh');
	}

}

	public function DeleteUser()
	{
		$deleteid = isset($_POST['deleteid'])?$_POST['deleteid']:'';
		$result = $this->user_model->DeleteUserById($deleteid);
		echo json_encode($result);
	}









































}
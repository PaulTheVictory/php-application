<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Userview extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model('user_model','',TRUE);
	}
	
	public function index()
	{
		

	if($this->session->userdata('adlog_in')==TRUE)
	{
			$viewid = isset($_GET['id'])?$_GET['id']:'';
			$data['singleuser'] = $this->user_model->ViewSingleUserById($viewid);
			$data['title'] = "View User Profile";
			$this->load->view('header.php',$data);
			$this->load->view('userview_view.php');
			$this->load->view('footer.php');
		
	}
	else
	{
		redirect('signin', 'refresh');
	}


	}

	
	






















}

<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Profile extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model('signin_model','signin',TRUE);
		$this->load->model('user_model','usermodel',TRUE);
	}
	
	public function index()
	{
		

	if($this->session->userdata('adlog_in')==TRUE || $this->session->userdata('logged_in')==TRUE)
	{
		$userid = $this->session->userdata('id');
		if($userid!="")
		{
			$userid_get = $userid;
			$new_getdetails = new user_model;
			$data['userdetails'] = $new_getdetails->GetUserDetails($userid_get);
			$data['title'] = "My Profile";
			$this->load->view('header.php',$data);
			$this->load->view('profile_view.php');
			$this->load->view('footer.php');
		}
		else
		{
			redirect('signin', 'refresh');	
		}
	}
	else
	{
		redirect('signin', 'refresh');
	}


	}


	






















}

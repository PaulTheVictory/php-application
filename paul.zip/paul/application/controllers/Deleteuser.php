<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Deleteuser extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model('user_model','',TRUE);
	}

public function index()
	{


if($this->session->userdata('adlog_in')==TRUE)
	{
		$data['ruserlist'] = $this->user_model->GetUserListsRecovery();
		$data['title'] = "Deleted User Lists";
		$this->load->view('header.php',$data);
		$this->load->view('deleteuser_view.php');
		$this->load->view('footer.php');
	}
	else
	{
		redirect('signin', 'refresh');
	}

}

	public function DeleteRecoveryUser()
	{
		$deleteid = isset($_POST['deleteid'])?$_POST['deleteid']:'';
		$result = $this->user_model->DeleteRecoveryById($deleteid);
		echo json_encode($result);
	}









































}
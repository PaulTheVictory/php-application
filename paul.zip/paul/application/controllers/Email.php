<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Email extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model('user_model','',TRUE);
	}
	
	public function index()
	{
		

	if($this->session->userdata('adlog_in')==TRUE)
	{
		$data['title'] = "My Admin Dashboard";
		$this->load->view('header.php',$data);
		$this->load->view('email_view.php');
		$this->load->view('footer.php');
		
	}
	
	else
	{
		redirect('signin', 'refresh');
	}


	}

    public function SendEmail()
    {
        $email = isset($_POST['email'])?$_POST['email']:'';

        $result = $this->user_model->SendEmail($email);

            if($result)
            {
		        echo json_encode($result);
            }
        

    }









}

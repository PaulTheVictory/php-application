 <?php

 Class user_model extends CI_Model

{
	public function __construct() {
		$this->load->library('Datatables');
	}


	/*new user register*/
	public function NewUser($data)
	{
		return $this->db->insert('users',$data);
	}


	/*new user register profile*/
	public function NewUserProfile($pdata)
	{
		return $this->db->insert('userprofile',$pdata);
	}

	/*get single user details*/
	public function GetUserDetails($userid_get)
	{
		$arr = array();
		$arr['userdetails'] = array();
		$query = $this->db->query('select * from userprofile where userid="'.$userid_get.'"');
		$row = $query->result_array();

		if($query->num_rows()>0)
		{
			return $row[0];
		}
		else
		{
			return $arr;
		}

	}

	/*get all users details*/

	public function GetUserLists()
	{
		$arr = array();
		$arr['ulist'] = '<table id="register_view" class="display dataTable">';

		$query = $this->db->query('select * from userprofile order by created asc');
		$row = $query->result_array();
		$arr['user_list_count'] = count($row);
		if($row)
		{
		$arr['ulist'] .= '<thead><tr><th>S No</th><th>Name</th><th>Phone No</th><th>Email ID</th><th>Join Date</th><th>Action</th></thead>';
		$arr['ulist'] .= '<tbody>';
		for($i=0; $i<count($row); $i++)
		{
		$id = $row[$i]['userid'];
		$name = $row[$i]['pname'];
		$phone = $row[$i]['pphone'];
		$email = $row[$i]['pemail'];
		$created = $row[$i]['created'];
		$viewstatus = $row[$i]['pviewstatus'];
		$created = date("d M, Y h:i A",strtotime($created));
		if($viewstatus!='a'){continue;}
		$arr['ulist'] .= '<tr><td>'.$i.'</td><td>'.$name.'</td><td>'.$phone.'</td><td>'.$email.'</td><td>'.$created.'</td>
		<td>
		<div class="action_btn">
			<button type="button" class="btn btn-sm btn-success view_user" data-uid="'.$id.'"><i class="fa fa-eye" aria-hidden="true"></i> View</button>
            <button class="btn btn-sm btn-danger delete_confirm" type="submit" data-uid="'.$id.'"><i class="fa fa-trash"></i> Delete</button></div>
        </td></tr>';
		}
		}
		else
		{
			$arr['ulist'] .= '<tbody><tr><td>No Records Found</td></tr>';
		}
		$arr['ulist'] .= '</tbody></table>';
		return $arr;

	}

	/*Delete Single User*/

	public function DeleteUserById($deleteid)
	{
		$result = array(0=>'');
		$query = $this->db->query('update userprofile set pviewstatus="d" where userid="'.$deleteid.'"');
		if($query)
		{
			$result = array(0=>'success');
			return $result;
		}
		else
		{
			$result = array(0=>'fail');
			return $result;
		}

	}

	/*View Single User Profile*/

	public function ViewSingleUserById($viewid)
	{
		$arr = array();
		$arr['singleuser'] = array();
		$query = $this->db->query('select * from userprofile where userid="'.$viewid.'"');
		$row = $query->result_array();


		if($query->num_rows()>0)
		{
			return $row[0];
		}
		else
		{
			return $arr;
		}
	}

	/*get all users details recovery*/

	public function GetUserListsRecovery()
	{
		$arr = array();
		$arr['rulist'] = '<table id="register_view" class="display dataTable">';

		$query = $this->db->query('select * from userprofile order by created asc');
		$row = $query->result_array();
		$arr['ruser_list_count'] = count($row);
		if($row)
		{
		$arr['rulist'] .= '<thead><tr><th>S No</th><th>Name</th><th>Phone No</th><th>Email ID</th><th>Join Date</th><th>Action</th></thead>';
		$arr['rulist'] .= '<tbody>';
		for($i=0; $i<count($row); $i++)
		{
		$id = $row[$i]['userid'];
		$name = $row[$i]['pname'];
		$phone = $row[$i]['pphone'];
		$email = $row[$i]['pemail'];
		$created = $row[$i]['created'];
		$viewstatus = $row[$i]['pviewstatus'];
		$created = date("d M, Y h:i A",strtotime($created));
		if($viewstatus!='d'){continue;}
		$arr['rulist'] .= '<tr><td>'.$i.'</td><td>'.$name.'</td><td>'.$phone.'</td><td>'.$email.'</td><td>'.$created.'</td>
		<td>
		<div class="action_btn">
			<button class="btn btn-sm btn-success delete_confirm" type="submit" data-uid="'.$id.'"><i class="fa fa-trash"></i> Recovery User</button></div>
        </td></tr>';
		}
		}
		else
		{
			$arr['rulist'] .= '<tbody><tr><td>No Records Found</td></tr>';
		}
		$arr['rulist'] .= '</tbody></table>';
		return $arr;

	}


	/*Delete Recovery User*/

	public function DeleteRecoveryById($deleteid)
	{
		$result = array(0=>'');
		$query = $this->db->query('update userprofile set pviewstatus="a" where userid="'.$deleteid.'"');
		if($query)
		{
			$result = array(0=>'success');
			return $result;
		}
		else
		{
			$result = array(0=>'fail');
			return $result;
		}

	}

	/*Email Test*/
	public function SendEmail($email)
	{
		$result = array(0=>'');


		$body  = '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.=w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"><html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"></head><body style="background:#F8F8F8; padding:20px;">
			<table style="background:#fff;border:0px solid #E8E8E8; border-radius:5px; border-collapse:collapse; overflow:hidden;padding:10px;margin:0 auto; font-size: 15px; width:600px"><tbody>
			<tr><td style="text-align:center; width:600px; color:#333; padding:20px;"><h1>Paul Victory</h1></td></tr>
			<tr><td style="text-align:left; line-height:1.4em; padding:10px 20px; width:600px; color:#333;">Dear ".$name.",<br><br><strong>Userid</strong>: ".$userid."<br><br><strong>Message</strong>: Your registration has been successfully.<br>
			<tr><td style="text-align:left; padding:10px 20px; width:600px; color:#333;">&nbsp;</td></tr>
			<tr><td style="text-align:left; padding:10px 20px; width:600px; color:#333;">Regards,<br>Develops Demo Account</td></tr>
			<tr style="background:#EEEEEE; font-size: 12px;"><td style="text-align:center; padding:15px 20px; width:600px; color:#999;">Copyright &copy; 2022 Paul. All Rights Reserved. <a style="color:#0986C5; text-decoration:none;" href="javascript:void(0)">Develops Demo Account</a></td></tr>
			</tbody></table></body></html>';
		$subject  = "Test Subject";

		$config = $this->config->item('gmail');
		$this->load->library('email', $config);
		$this->email->set_newline("\r\n");

		$this->email->from('paulthevictory@gmail.com', 'Paul');
		$this->email->to($email);
        // $this->email->bcc('');
		$this->email->subject($subject);
		$this->email->message($body);
        // if($this->email->send()){ echo ''; }else{ /*show_error($this->email->print_debugger());*/ }
		$result = $this->email->send();
		if($result)
		{
			$result = array(0=>'success');
			return $result;
		}
		else
		{
			$result = array(0=>'fail');
			return $result;
		}
	}




















}

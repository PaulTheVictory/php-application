<?php

Class login_model extends CI_Model

{


public function LoginVerification($username,$password)
{

	$result = array(0=>'');
	$query = $this->db->query('select * from users where (name="'.$username.'" or phone="'.$username.'" or email="'.$username.'") and password="'.SHA1($password).'" order by `id` DESC');
	$row = $query->result_array();

	if($row)
	{
		$verify = $row[0]['id'];
		$e_mail = $row[0]['email'];
		$e_verifyid = rand(100000,999999);
		$e_verifystatus = 'open';
		$e_name = $row[0]['name'];
		$query1 = $this->db->query('update users set otpstatus="'.$e_verifystatus.'", verifyid="'.$e_verifyid.'" where id="'.$verify.'"');
		if($query1)
		{
			$s_email = $this->SendEmailOtp($e_mail,$e_verifyid,$e_name);
			if($s_email==TRUE)
			{
				$result = array(0=>'success',1=>$verify);
				return $result;
			}
			else
			{
				$result = array(0=>'email');
				return $result;
			}
		}
		else
		{
			$result = array(0=>'not found');
			return $result;
		}
	}
	else
	{
		$result = array(0=>'fail');
		return $result;
	}
	
	 



}


public function SendEmailOtp($e_mail,$e_verifyid,$e_name)
{
	$result = '';


		$body  = '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.=w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"><html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"></head><body style="background:#F8F8F8; padding:20px;">
			<table style="background:#fff;border:0px solid #E8E8E8; border-radius:5px; border-collapse:collapse; overflow:hidden;padding:10px;margin:0 auto; font-size: 15px; width:600px"><tbody>
			<tr><td style="text-align:center; width:600px; color:#333; padding:20px;"><h1>Paul Victory</h1></td></tr>
			<tr><td style="text-align:left; line-height:1.4em; padding:10px 20px; width:600px; color:#333;">
				Dear '.$e_name.',<br><br><h2>Your Verification Code</h2><strong><h4>'.$e_verifyid.'</h4></strong>
			<tr><td style="text-align:left; padding:10px 20px; width:600px; color:#333;">&nbsp;</td></tr>
			<tr><td style="text-align:left; padding:10px 20px; width:600px; color:#333;">Regards,<br>Develops Demo Account</td></tr>
			<tr style="background:#EEEEEE; font-size: 12px;"><td style="text-align:center; padding:15px 20px; width:600px; color:#999;">Copyright &copy; 2022 Paul. All Rights Reserved. <a style="color:#0986C5; text-decoration:none;" href="javascript:void(0)">Develops Demo Account</a></td></tr>
			</tbody></table></body></html>';
		$subject  = "Verification Code";

		$config = $this->config->item('gmail');
		$this->load->library('email', $config);
		$this->email->set_newline("\r\n");

		$this->email->from('paulthevictory@gmail.com', 'Paul');
		$this->email->to($e_mail);
        // $this->email->bcc('');
		$this->email->subject($subject);
		$this->email->message($body);
        // if($this->email->send()){ echo ''; }else{ /*show_error($this->email->print_debugger());*/ }
		$result = $this->email->send();
		if($result)
		{
			return TRUE;
		}
		else
		{
			return FALSE;
		}
}


public function SubmitOtp($where_id)
{
	$query = $this->db->query('select * from users where id="'.$where_id.'"');
	$row = $query->result_array();

	return $row;
}


public function UpdateOtpStatus($db_id)
{
	$this->db->query('update users set otpstatus="close" where id="'.$db_id.'"');
}

public function CreatSession($ses_uid,$sessid,$sess_login,$sess_agent,$sess_user,$sess_ip,$sess_role,$sess_verifyid)
{

	
	$this->db->query('insert into session (`sessionid`,`role`,`userid`,`ip`,`verifyid`,`sessionstart_time`,`sessionend_time`,`agent`,`status`) values ("'.$ses_uid.'","'.$sess_role.'","'.$sessid.'","'.$sess_ip.'","'.$sess_verifyid.'","'.$sess_login.'","","'.$sess_agent.'","o")');
   
}


















}



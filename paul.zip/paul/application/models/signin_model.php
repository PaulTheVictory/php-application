<?php

Class signin_model extends CI_Model

{


public function VerifySignin($username,$password)
{


	$query = $this->db->query('select * from users where (name="'.$username.'" or email="'.$username.'") and password="'.SHA1($password).'" order by `id` DESC');
	$row = $query->result_array();
	return $row;


}

public function CreatSession($ses_uid,$sessid,$sess_login,$sess_agent,$sess_user,$sess_ip,$sess_role)
{

	
	$this->db->query('insert into session (`sessionid`,`role`,`userid`,`ip`,`sessionstart_time`,`sessionend_time`,`agent`,`status`) values ("'.$ses_uid.'","'.$sess_role.'","'.$sessid.'","'.$sess_ip.'","'.$sess_login.'","","'.$sess_agent.'","o")');
   
}

public function EndSession($sessionid,$end)
{
	$this->db->query('update session set sessionend_time="'.$end.'", status="c" where userid="'.$sessionid.'"');
}



























}



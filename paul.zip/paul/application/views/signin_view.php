<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>




<div class="sign_view">
   <div class="wrapper">
      <div class="sign_align">
         <div class="sign_left">
            <img src="<?php echo base_url(); ?>assets/images/login1.png" alt="Login Page">
         </div>
         <div class="sign_right">
           <?php echo validation_errors(); ?>
            <h1>Sign In</h1>
            <?php echo form_open('Signin'); ?>
            <div class="form-group input-group m-0">
               
            </div>
            <div class="form-group">
               <input id="username" name="username" type="text" placeholder="Username" value="<?php echo set_value('username'); ?>"/>
            </div>
            <div class="form-group">
               <input id="password" name="password" type="text" placeholder="Password" value="<?php echo set_value('password'); ?>"/>
               <small class="float-right"><a href="javascript:void(0)" title="Forgot Password">Forgot Password?</a></small>
            </div>
            <div class="form-group">
               <button class="sign_in_btn" type="submit">Sign up</button>
                <small class="mar_top">Don't have an account? <a href="javascript:void(0)" title="Create New Account">Create New Account</a></small>
            </div>
          
            </form>
         </div>
      </div>
   </div>
</div>


<script type="text/javascript">
  

</script>
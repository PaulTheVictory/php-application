<aside id="left-panel" class="left-panel">
   <nav class="navbar navbar-expand-sm navbar-default">
      <div id="main-menu" class="main-menu collapse navbar-collapse">
         <ul class="nav navbar-nav">
            <li>
               <a href="<?php echo base_url(); ?>"><i class="menu-icon fa fa-home"></i>Dashboard </a>
            </li>
             <?php  if($this->session->userdata('adlog_in')==TRUE) { ?>
             <li>
               <a href="<?php echo base_url(); ?>register"><i class="menu-icon fa fa-plus-square"></i>Register </a>
            </li>
            <?php } ?>
             <?php  if($this->session->userdata('logged_in')==TRUE) { ?>
            <li>
               <a href="<?php echo base_url(); ?>profile"><i class="menu-icon fa fa-user-circle-o"></i>My Profile </a>
            </li>
            <?php } ?>
             <?php  if($this->session->userdata('adlog_in')==TRUE) { ?>
             <li>
               <a href="<?php echo base_url(); ?>viewuser"><i class="menu-icon fa fa-user"></i>User List</a>
            </li>
            <?php } ?>
            <?php  if($this->session->userdata('adlog_in')==TRUE) { ?>
             <li>
               <a href="<?php echo base_url(); ?>deleteuser"><i class="menu-icon fa fa-trash"></i>Delete User List</a>
            </li>
           
            <?php } ?>
            <li>
               <a href="<?php echo base_url(); ?>Signin/Logout/"><i class="menu-icon fa fa-sign-out"></i>Logout</a>
            </li>
           <!--  <li class="menu-item-has-children dropdown">
               <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="menu-icon fa fa-cogs"></i>Components</a>
               <ul class="sub-menu children dropdown-menu">
                  <li><i class="fa fa-puzzle-piece"></i><a href="ui-buttons.html">Buttons</a></li>
                  <li><i class="fa fa-id-badge"></i><a href="ui-badges.html">Badges</a></li>
                  <li><i class="fa fa-bars"></i><a href="ui-tabs.html">Tabs</a></li>
               </ul>
            </li> -->
            
         </ul>
      </div>
   </nav>
</aside>
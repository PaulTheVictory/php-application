<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>




<div class="sign_view">
   <div class="wrapper">
      <div class="sign_align">
         <div class="sign_left">
            <img src="<?php echo base_url(); ?>assets/images/login1.png" alt="Login Page">
         </div>
         <div class="sign_right">
           <?php// echo validation_errors(); ?>
           <div class="step_1">
            <h1>Sign In</h1>
            <?php// echo form_open('Login'); ?>
            <form method="post" id="sign_form" accept-charset="utf-8">
            <div class="form-group">
               <input id="username" name="username" type="text" placeholder="Username" value="<?php echo set_value('username'); ?>"/>
            </div>
            <div class="form-group">
               <input id="password" name="password" type="password" placeholder="Password" value="<?php echo set_value('password'); ?>" readonly onfocus="this.removeAttribute('readonly');"/>
               <small class="float-right"><a href="javascript:void(0)" title="Forgot Password">Forgot Password?</a></small>
            </div>
            <div class="form-group">
               <button class="sign_in_btn" type="submit" id="sign_in">Sign in</button>
                <small class="mar_top">Don't have an account? <a href="javascript:void(0)" title="Create New Account">Create New Account</a></small>
            </div>
            </form>
            <!-- <button id="test_button">Test</button> -->
           </div>
           <div class="step_2">
            <h2>OTP Verification</h2>
            <form method="post" id="sign_otpform" accept-charset="utf-8">
            <div class="form-group">
               <input id="otpnumber" name="otpnumber" type="text" placeholder="OTP Number"/>
               <input type="hidden" name="where_id" id="where_id" />
            </div>
            <div class="form-group">
               <button class="sign_in_btn" type="submit" id="submit_otp">Submit Otp</button>
                
            </div>
            </form>
           </div>
           <div class="error_text"></div>
         </div>
      </div>
   </div>
</div>


<script type="text/javascript">

jQuery(document).ready(function($){

$('.step_2').fadeOut();
$('.step_1').fadeIn();


$('#sign_form').on('submit',function(e){

   e.preventDefault();
   var username = $('#username').val();
   var password = $('#password').val();

   if(username=='')
   {
      $('#username').addClass('error_feild').css('border','1px solid red');
      swal({
            title: 'Username is required',
            timer: 3000,
            type: 'error',
         });
      return;
   }
   if(password=='')
   {
      $('#password').addClass('error_feild').css('border','1px solid red');
      swal({
            title: 'Password is required',
            timer: 3000,
            type: 'error',
         });
      return;
   }
   if($('#sign_in').hasClass('process'))
   {
      swal({
            title: 'Please wait while processing...',
            timer: 3000,
            type: 'info',
         });
   }
   else{
      $('#sign_in').addClass('process').text('Processing...');

      $.ajax({
         url:'Login/UserVerifycation',
         type:'POST',
         data: new FormData(this),
         contentType:false,
         processData:false,
         cache:false,
         success:function(data)
         {
            var res = $.parseJSON(data);
            if(res[0]=='success')
            {
               // swal({
               //    title: 'Login Successfully',
               //    timer: 5000,
               //    type: 'success',
               // });
               $('#where_id').val(res[1]);
               $('#sign_in').removeClass('process').text('Sign in');
               $('.step_1').fadeOut();
               $('.step_2').fadeIn();
            }
            else if(res[0]=='validate fail')
            {
                swal({
                  title: 'Username and Password required!',
                  timer: 5000,
                  type: 'error',
               });
               $('#sign_in').removeClass('process').text('Sign in');
            }
            else if(res[0]=='not found')
            {
                swal({
                  title: 'Username or Password Wrong!',
                  timer: 5000,
                  type: 'error',
               });
                $('#sign_in').removeClass('process').text('Sign in');
            }
            else if(res[0]=='exit')
            {
                swal({
                  title: 'Something went Wrong!',
                  timer: 5000,
                  type: 'error',
               });
                $('#sign_in').removeClass('process').text('Sign in');
            }
            else if(res[0]=='email')
            {
                swal({
                  title: 'Verification not Sended!',
                  timer: 5000,
                  type: 'error',
               });
                $('#sign_in').removeClass('process').text('Sign in');
            }
            else if(res[0]=='fail')
            {
                swal({
                  title: 'User not Exist!',
                  timer: 5000,
                  type: 'error',
               });
                $('#sign_in').removeClass('process').text('Sign in');
            }
         }
      });
   }
});


$('input,textarea,select').click(function(){
   $(this).removeClass('error_feild').css('border','1px solid #767676');
});


//OTP Verifycation

$('#sign_otpform').on('submit',function(e){
   e.preventDefault();

   var otpnumber = $('#otpnumber').val();

   if(otpnumber=='')
   {
      swal({
            title: 'Enter OTP Number',
            timer: 3000,
            type: 'error',
         });
      return;
   }
   if($('#submit_otp').hasClass('process'))
   {
      swal({
         title: 'Please wait while processing...',
         timer: 3000,
         type: 'info',
      });
   }
   else
   {
      $('#submit_otp').addClass('process').text('Processing...');

      $.ajax({
         url:'Login/SubmitOtp',
         type:'POST',
         data: new FormData(this),
         contentType:false,
         processData:false,
         cache:false,
         success:function(data)
         {
            var res = $.parseJSON(data);
            if(res[0]=='success')
            {
               // $("#sign_otpform")[0].reset();
               swal({
                  title: 'Login Successfully',
                  timer: 5000,
                  type: 'success',
               });
               
               // $('#submit_otp').removeClass('process').text('Submit Otp');
               // location.reload();
               // $('.step_2').fadeOut();
               // $('.step_1').fadeIn();
            }
            else if(res[0]=='otp fail')
            {
              swal({
                  title: 'Verification Failed! Wrong OTP',
                  timer: 5000,
                  type: 'error',
               });
                $('#submit_otp').removeClass('process').text('Submit Otp'); 
            }
         }
      });
   }

});






















$('#test_button').click(function(){
   swal({
      title: "Enter OTP Number",
      showCancelButton: true,
      html:true,
      confirmButtonColor: "#28a745",
  confirmButtonText: "Enter OTP",
  cancelButtonText: "Cancel",
  closeOnConfirm: false,
  closeOnCancel: false,
      text: '<input id="otp_number" name="otp_number" type="text" placeholder="OTP Number" style="display:block !important;">',
   },
   function(isConfirm){
  if (isConfirm) {
      var otpnumber = $('#otp_numbet').val();
      if(otpnumber!="")
      {
         alert('Please enter OTP Number');
      }
   //   swal("Login Successfully", "You clicked the button!", "success");
   //  $.ajax({
   //  	url:'Viewuser/DeleteUser',
   //  	type:'POST',
   //  	data:{
   //  		'deleteid':deleteid
   //  	},
   //  	success:function(data){
   //  		var dlt = $.parseJSON(data);
   //  		if(dlt[0]=='success')
   //  		{
   //  			swal("Deleted Successfully", "You clicked the button!", "success");
   //  			setTimeout(function(){
   //  			location.reload();
   //  			}, 1500);
   //  		}
   //  		else if(dlt[0]=='fail')
   //  		{
   //  			swal("Could Not Deleted", "Something went Wrong!", "error");
   //  		}
   //  	}
   //  });
  } else {
    swal("Login Cancelled", "Something went Wrong!", "error");
  }

   });


});

});
</script>

<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>


<form method="post" id="test_mmail">
    <input type="email" class="email" name="email" placeholder="Enter Email"/>
<button type="submit" class="send_email">Send Email</button>
</form>

















<script>
	jQuery(document).ready(function($){

        $('#test_mmail').on('submit',function(e){
             e.preventDefault();
            var email = $('.email').val();
            // alert(email);
            $.ajax({
                url:'Email/SendEmail',
                type:'POST',
			data: new FormData(this),
			processData: false,
            contentType: false,
            cache: false,

                success: function(data){
                    var res = $.parseJSON(data);
                    if(res[0]=="success")
                    {
                        alert('Email Send Successfully');
                    }
                    else if(res[0]=="fail")
                    {
                        alert('Emaail Not Sended');
                    }
                }
            });




        });





	});
</script>

<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>




<div class="new_register">
	<div class="head_text">
		<h1>New Register</h1>
	</div>
	<?php echo form_open('Register/NewRegister', 'id="r_newregister" accept-charset="utf-8"'); ?>
	<ul>
			<li class="full_width">
				<div class="li_items">
					<div class="form-group input-group">
   					<span class="has-float-label">
      					<input class="form-control" id="r_name" class="r_name" name="r_name" type="text" placeholder=" "  value="<?php echo set_value('r_name'); ?>" />
      					<label for="r_name">First Name</label>
    				</span>
    			</div>

				</div>
				<small><?php echo form_error('r_name'); ?></small>
			</li>
			<li class="full_width">
				<div class="li_items">
					<div class="form-group input-group">
   					<span class="has-float-label">
      					<input class="form-control" id="r_lname" class="r_lname" name="r_lname" type="text" placeholder=" "  value="<?php echo set_value('r_lname'); ?>" />
      					<label for="r_lname">Last Name</label>
    				</span>
  					</div>
				</div>
				<small><?php echo form_error('r_lname'); ?></small>
			</li>
			<li class="full_width">
					<div class="li_items">
				<div class="form-group input-group">
   					<span class="has-float-label">
      					<input class="form-control" id="r_phone" class="r_phone" name="r_phone" type="text" placeholder=" " value="<?php echo set_value('r_phone'); ?>" />
      					<label for="r_phone">Phone Number</label>
    				</span>
  				</div>
  			</div>
  				<small><?php echo form_error('r_phone'); ?></small>
			</li>
			<li class="full_width">
					<div class="li_items">
				<div class="form-group input-group">
   					<span class="has-float-label">
      					<input class="form-control" id="r_email" class="r_email" name="r_email" type="text" placeholder=" " value="<?php echo set_value('r_email'); ?>" readonly onfocus="this.removeAttribute('readonly');"/>
      					<label for="r_email">Email Address</label>
    				</span>
  				</div>
  			</div>
  				<small><?php echo form_error('r_email'); ?></small>
			</li>
			<li class="full_width">
				<div class="li_items">
					<div class="form-group input-group">
   					<span class="has-float-label">
      					<input class="form-control" id="r_pass1" class="r_pass1" name="r_pass1" type="password" placeholder=" " value="<?php echo set_value('r_pass1'); ?>" readonly onfocus="this.removeAttribute('readonly');" />
      					<label for="r_pass1">New Passwoed</label>
    				</span>
  					</div>
				</div>
				<small><?php echo form_error('r_pass1'); ?></small>
			</li>
			<li class="full_width">
				<div class="li_items">
					<div class="form-group input-group">
   					<span class="has-float-label">
      					<input class="form-control" id="r_pass2" class="r_pass2" name="r_pass2" type="password" placeholder=" " value="<?php echo set_value('r_pass2'); ?>" />
      					<label for="r_pass2">Confirm Password</label>
    				</span>
  					</div>
				</div>
				<small><?php echo form_error('r_pass2'); ?></small>
			</li>
			
		
			
			<p class="error_text"></p>
			<li class="full_width">

				<input type="submit" name="submit" value="submit" id="r_submit" />
			</li>
		</ul>
	</form>
</div>




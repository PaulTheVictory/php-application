<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>



<?php echo $ruserlist['rulist']; ?>











<!-- Script -->
<script type="text/javascript">

 jQuery(document).ready(function($){

 	/*View User*/
     $('#register_view').DataTable({
        'responsive': true,
        "processing": true,
        "bInfo" : false,
        columnDefs: [
            { width: '20%'}
        ],
        fixedColumns: true,
        "fnRowCallback" : function(nRow, aData, iDisplayIndex){
                $("td:first", nRow).html(iDisplayIndex +1);
               return nRow;
            },
     });

     /*Delete User*/
     $(document).on('click','.delete_confirm',function(d){
     	d.preventDefault();
     	var deleteid = $(this).data('uid');
     	swal({
  title: "Are you sure?",
  text: "retrieve this user.",
  type: "warning",
  showCancelButton: true,
  confirmButtonColor: "#DD6B55",
  confirmButtonText: "Recovery",
  cancelButtonText: "Cancel",
  closeOnConfirm: false,
  closeOnCancel: false
},
function(isConfirm){
  if (isConfirm) {
    // swal("Deleted Successfully", "You clicked the button!", "success");
    $.ajax({
    	url:'Deleteuser/DeleteRecoveryUser',
    	type:'POST',
    	data:{
    		'deleteid':deleteid
    	},
    	success:function(data){
    		var dlt = $.parseJSON(data);
    		if(dlt[0]=='success')
    		{
    			swal("Recover Successfully", "You clicked the button!", "success");
    			setTimeout(function(){
    			location.reload();
    			}, 1500);
    		}
    		else if(dlt[0]=='fail')
    		{
    			swal("Could Not Recover", "Something went Wrong!", "error");
    		}
    	}
    });
  } else {
    swal("Recovery Cancelled", "Your file still in delete status", "error");
  }
});

     });

     /*View User*/

     $(document).on('click','.view_user',function(v){
     	v.preventDefault();

     	var viewid = $(this).data('uid');
     	window.location.assign(base_url+"userview?id="+viewid);
     	

     });





 });


  




</script>
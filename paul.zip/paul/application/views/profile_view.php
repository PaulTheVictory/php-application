<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
 <script src="https://cdnjs.cloudflare.com/ajax/libs/croppie/2.6.5/croppie.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/croppie/2.6.5/croppie.min.css">
<h1>Welcome Back - <?php echo $this->session->userdata('username'); ?></h1>


       
 <?php// echo $userdetails['pimage'];?>
    



    <button class="send_email" data-email="paulthevictory@gmail.com">Send Email</button>            

       
    
<!-- <div class="container">
  <div class="row">
    <div class="col">
      <form id="form1" runat="server">
        <input type='file' id="imgInp" />
        <img id="my-image" src="#" />
      </form>
      <button id="use">Upload</button>
      <img id="result" src="">
    </div>
  </div>
</div> -->



<script type="text/javascript">
    jQuery(document).ready(function($){
    function readURL(input) {
  if (input.files && input.files[0]) {
    var reader = new FileReader();
    reader.onload = function(e) {
      $('#my-image').attr('src', e.target.result);
      var resize = new Croppie($('#my-image')[0], {
        viewport: { 
          width: 200, 
          height: 250,
          // type: 'circle'
        },
        boundary: { 
          width: 300, 
          height: 300 
        },
         showZoomer: false,
        // enableResize: true,
        enableOrientation: true
      });
      $('#use').fadeIn();
      $('#use').on('click', function() {
        resize.result('base64').then(function(dataImg) {
          var data = [{ image: dataImg }, { name: 'myimgage.jpg' }];
          // use ajax to send data to php
          $('#result').attr('src', dataImg);
          // $('#imgInp').attr('value', dataImg);
        })
      })
    }
    reader.readAsDataURL(input.files[0]);
  }
}

$("#imgInp").change(function() {
  readURL(this);
});
});
</script>
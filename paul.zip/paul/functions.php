<?php


defined('ABSPATH') || exit;
if(wp_get_theme()!='paul'):
echo '<h1>Website Access Denied</h1>';
exit(0);
endif;
/*Custom Function Theme*/


/*Website Meta Tags*/

if(!function_exists('website_metatag')) 
{
function website_metatag()
{

}
add_action('wp_head', 'website_metatag', 0);
}

/*Website Css Loader*/

if(!function_exists('website_css')) {
function website_css()
{
    wp_enqueue_style( 'bootstrap_min' , get_template_directory_uri() . '/assets/css/web_bootstrap_min.css', false, '5.2', 'all' );
    wp_enqueue_style('style_min', get_stylesheet_uri());
}
add_action('wp_head', 'website_css', 1);
}

/*Website Script Loader*/

if(!function_exists('website_js')) {
function website_js()
{
    wp_enqueue_script('jquery_min', get_template_directory_uri() . '/assets/js/web_jquery_min.js', array() , '3.6');
    wp_enqueue_script('bootstrap_min', get_template_directory_uri() . '/assets/js/web_bootstrap_min.js', array() , '5.2');
}
add_action('wp_footer', 'website_js', 0);
}


/*Dynamic Menu Bar*/
register_nav_menus(array(
'primary' => __('Primary Menu', '') ,
));


/*Website Url ShortCode*/
function Template_Path_Url()
{
    $directory = get_template_directory_uri();
    return $directory;
}
add_shortcode('template_path', 'Template_Path_Url');

function Custom_Site_Url()
{
    $directory = get_site_url();
    return $directory;
}
add_shortcode('url', 'Custom_Site_Url');

/*Custom Widget*/

function Custom_Widget()
{
register_sidebar(array(
    'name' => 'Search',
    'id' => 'search_bar',
)); 
}
add_action('widgets_init', 'Custom_Widget');

/*Woocommerce*/

add_action("after_setup_theme", "setup_woocommerce_support");
function setup_woocommerce_support()
{
add_theme_support("woocommerce");
add_theme_support("wc-product-gallery-zoom");
add_theme_support("wc-product-gallery-lightbox");
add_theme_support("wc-product-gallery-slider");
}
//Disable Default Styling for WooCommerce
if (class_exists('Woocommerce')){
    add_filter( 'woocommerce_enqueue_styles', '__return_empty_array' );
}
//Both Image Size and Product Grid
function mytheme_add_woocommerce_support() {
add_theme_support( 'woocommerce', array(
'thumbnail_image_width' => 150,
'single_image_width'    => 300,
        'product_grid'          => array(
            'default_rows'    => 3,
            'min_rows'        => 2,
            'max_rows'        => 8,
            'default_columns' => 4,
            'min_columns'     => 2,
            'max_columns'     => 5,
        ),
) );
}
add_action( 'after_setup_theme', 'mytheme_add_woocommerce_support' );

import React from 'react'
import Dashboard from './Component/Dashboard';
// import Login from './Component/Login';

const App = () => {
  return (
    <>
      {/* <Login /> */}
      <Dashboard />
    </>
  )
}

export default App;
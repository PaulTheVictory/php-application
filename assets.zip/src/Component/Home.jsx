import React from 'react'
import { Breadcrumb } from "antd";
import TotalCount from './TotalCount';
const Home = () => {
  const item = [
    {
      title: "Home",
    },
    {
      title: "Dashboard",
    },
  ];
  return (
    <>
      <Breadcrumb items={item} />
      <div className="col_1 gap_25 m_t_25">
        <TotalCount />
      </div>
    </>
  );
}

export default Home
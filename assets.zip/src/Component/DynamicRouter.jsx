import React from 'react';
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Home from './Home';

const DynamicRouter = () => {
  return (
    <>
      <BrowserRouter basename={"/websites/paul/"}>
        <Routes>
          <Route index exact element={<Home />} />
        </Routes>
      </BrowserRouter>
    </>
  );
}

export default DynamicRouter
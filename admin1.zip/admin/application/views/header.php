<!DOCTYPE HTML>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<title>FORM</title>
	
	



	
	<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>css/bootstrap_min.css">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>css/fontawesome_min.css">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>css/jquery_ui_min.css">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>css/datatables.css">
	
	<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>/css/style.css" media="all">
	
	<script src="<?php echo base_url();?>js/jquery_min.js"></script>
	<script src="<?php echo base_url();?>js/jquery_ui_min.js"></script>
	<script src="<?php echo base_url();?>js/bootstrap_min.js"></script>	
	<script src="<?php echo base_url();?>js/dobpicker.js"></script>
	<script src="<?php echo base_url();?>js/datatables_min.js"></script>
	
	
	

	<script>
		var baseurl = "<?php echo base_url(); ?>";
	</script>
</head>
<body>





<div class="page_heading">
	<h1>Register List</h1>
</div>              
			   

<div class="register_listing_all">
 <?php echo $this->table->generate();  ?>   
</div>

























<script>

$(document).ready(function() {

var columnData = [
{
"data": "userid"
},
{
"data": "name"
},
{
"data": "email"
},
{
"data": "phone"
},
{
"data": "gender"
},
{
"data": "role"
},
{
"data": "created"
}
];
/*
columnData.push({
   data: "id",
   "visible": true
});*/
var oTable = $('#coursetable').dataTable({
"bProcessing": true,
"bServerSide": true,
"sPaginationType": "full_numbers",
"ajax": {
"url": 'Registerlist/GetRegisterList',
"type": "POST"
},
"oLanguage": {
"sProcessing": "<img src='<?php echo base_url(); ?>images/loader.gif'>"
},
'iDisplayLength': 25,
"columns": columnData,
"fnDrawCallback": function(oSettings) {
/*$("#coursetable").find(".del").each(function() {
$(this).click(function() {
if (confirm("Are you sure to delete this course ?")) {
var ide = $(this).attr("id");
$.get('dashboard/delCourse', {
'ide': ide
}, function(o) {
var obj1 = $.parseJSON(o);
if (obj1[0] === 'success') {
oTable.fnDraw();
} else if (obj1[0] === 'fail') {
alert("Error!!! please try again");
}
});
}
});
});*/
}
});
});
</script>
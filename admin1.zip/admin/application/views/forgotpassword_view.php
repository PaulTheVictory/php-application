



<div class="login_form">
	<div class="wrap_grid_full">
		<div class="login_form_content">
			<div class="login_form_left">
				<img src="<?php echo base_url();?>images/login.png" alt="Login" />
			</div>
			<div class="login_form_right forgot-form">
			<h1>Forgot Password</h1>
			<form id="forgot_form" method="post" novalidate>
				<h4>Enter Your Email ID</h4>
				
				<input type="text" class="femailid" name="femailid" tabindex="1" placeholder="Email ID"/>
				<div class="forgot_pass">
					
					<a href="<?php echo base_url();?>" title="Back to Login">Back to Login</a>
				</div>
				<h6 class="error_log_text"></h6>
				<span>
				<input name="submit" type="submit" id="reset_submit" value="RESET" />
				
				</span>
				
			</form>
			</div>
		</div>
	</div>
</div>

<script type="text/javascript">

$(document).ready(function(){



$("#forgot_form").on("submit",function(e){
	e.preventDefault();
	
	var femailid = $(".femailid").val();
	
	regex   = new RegExp('^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$');
    valid = regex.test(femailid);
	
	if(!valid){ $(".femailid").addClass('error_class');$(".error_log_text").text("Invalid Email");return;}
	
	
	if($("#reset_submit").hasClass('process')){
		alert("Please wait while processing...");
	}else{
	
		$("#reset_submit").addClass('process').val('Processing...');
	
	$.ajax({
        	url:'Forgotpassword/ForgotPass',
			type:'POST',
			data: new FormData(this),
			processData: false,
            contentType: false,
            cache: false,
			success:function(data){
				var obj1 = $.parseJSON(data);
				
				if(obj1[0]=="success"){
					
					setTimeout(function(){
						$("#reset_submit").removeClass('process').val('RESET');
						//location.reload("login");
						alert('success');
					},2000);
				}
				else if(obj1[0]=="notfound"){
					$("#reset_submit").removeClass('process').val('RESET');
					setTimeout(function(){ $(".error_log_text").text("User Not Exists"); }, 500);
				}
				else if(obj1[0]=="failed"){
					$("#reset_submit").removeClass('process').val('RESET');
					setTimeout(function(){ $(".error_log_text").text("Please try Again Later"); }, 500);
				}
				
				else if(obj1[0]==""){
					$("#reset_submit").removeClass('process').val('RESET');
					setTimeout(function(){ $(".error_log_text").text("Please try Again Later"); }, 500);
				}
				
			}
			
     	}); 
		
	}
	
})
}); 

$(".login_form").find("input,select,textarea").each(function(){
        $("input,select,textarea").click(function(){
			$("input,select,textarea").removeClass("error_class");$(".error_log_text").text("");
			if($("input,select,textarea").is('.reg_dobday','.reg_dobmonth','.reg_dobyear')){
				$('.reg_dobday','.reg_dobmonth','.reg_dobyear').removeClass("error_class");
			}
		});
		 

    });



</script>
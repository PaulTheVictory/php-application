
<div class="page_heading">
	<h1>View Profile - <?php echo $userdetails['name'];?> - <?php echo $userdetails['userid'];?></h1>
</div>              
			   

<div class="register_listing_all view_profile">
	
	<div class="view_profile_align">
		<div class="view_profile_left">
			<ul class="single_userview">
				<li><font>Name: </font><font><?php echo $userdetails['name'];?></font></li>
				<li><font>Email ID: </font><font><?php echo $userdetails['email'];?></font></li>
				<li><font>Phone No: </font><font><?php echo $userdetails['phone'];?></font></li>
				<li><font>Role: </font><font><?php echo $userdetails['role'];?></font></li>
				<li><font>Gender: </font><font><?php echo $userdetails['gender'];?></font></li>
				<li><font>Date of Birth: </font><font><?php echo $userdetails['dob'];?></font></li>
				<li><font>Address: </font><font><?php echo $userdetails['address'];?></font></li>
				<li><font>State: </font><font><?php echo $userdetails['state'];?></font></li>
				<li><font>City: </font><font><?php echo $userdetails['city'];?></font></li>
				<li><font>Pincode: </font><font><?php echo $userdetails['pincode'];?></font></li>
				<li><font>Date of Join: </font><font><?php echo $userdetails['doj'];?></font></li>
				
			</ul>
		</div>
		<div class="view_profile_right">
			<ul>
				<li>
					<h4>Profile Picture</h4>
					<img src="<?php echo base_url(); ?>uploads/<?php echo $userdetails['userid'];?>/<?php echo $userdetails['photo'];?>" alt="<?php echo $userdetails['name'];?>" />
				</li>
				<li>
					<h4>Certificate</h4>
					<a href="<?php echo base_url(); ?>uploads/<?php echo $userdetails['userid'];?>/<?php echo $userdetails['certificate'];?>" title="View Certificate" target="_blank">View Certificate</a>
				</li>
				<li>
					<h4>Resume</h4>
					<a href="<?php echo base_url(); ?>uploads/<?php echo $userdetails['userid'];?>/<?php echo $userdetails['resume'];?>" title="View Resume" target="_blank">View Resume</a>
				</li>
			</ul>
		</div>
	</div>
	
</div>








































</body>
</html>


<script>
$("#menu-toggle").click(function(e) {
   e.preventDefault();
   $("#wrapper").toggleClass("toggled");
});
$("#menu-toggle-2").click(function(e) {
   e.preventDefault();
   $("#wrapper").toggleClass("toggled-2");
   $('#menu ul').hide();
});

function initMenu() {
   $('#menu ul').hide();
   $('#menu ul').children('.current').parent().show();
   //$('#menu ul:first').show();
   $('#menu li a').click(
      function() {
         var checkElement = $(this).next();
         if ((checkElement.is('ul')) && (checkElement.is(':visible'))) {
            return false;
         }
         if ((checkElement.is('ul')) && (!checkElement.is(':visible'))) {
            $('#menu ul:visible').slideUp('normal');
            checkElement.slideDown('normal');
            return false;
         }
      }
   );
}
$(document).ready(function() {
   initMenu();
});


</script>


<style>
	
		
		#preloder{position:fixed;width:100%;height:100%;top:0;left:0;z-index:999999;background:#fff;}.loader{width:40px;height:40px;position:absolute;top:50%;left:50%;margin-top:-13px;margin-left:-13px;border-radius:60px;animation:loader .8s linear infinite;-webkit-animation:loader .8s linear infinite}@keyframes loader{0%{-webkit-transform:rotate(0deg);transform:rotate(0deg);border:4px solid #305ab1;border-left-color:transparent}50%{-webkit-transform:rotate(180deg);transform:rotate(180deg);border:4px solid #305ab1;border-left-color:transparent}100%{-webkit-transform:rotate(360deg);transform:rotate(360deg);border:4px solid #305ab1;border-left-color:transparent}}@-webkit-keyframes loader{0%{-webkit-transform:rotate(0deg);border:4px solid #305ab1;border-left-color:transparent}50%{-webkit-transform:rotate(180deg);border:4px solid #305ab1;border-left-color:transparent}100%{-webkit-transform:rotate(360deg);border:4px solid #305ab1;border-left-color:transparent}}
	
	</style>
	
	<div id="preloder">
 <div class="loader"></div>
</div>


<script>
'use strict';
(function($) {
    $(window).on('load', function() {
        $(".loader").fadeOut();
        $("#preloder").delay(200).fadeOut("slow");
    });
})(jQuery);

</script>


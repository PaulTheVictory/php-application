<nav class="navbar navbar-default no-margin">
	<div class="navbar-header fixed-brand">
        <a class="navbar-brand" href="<?php echo base_url(); ?>">Dashboard</a>
    </div>
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
        <ul class="nav navbar-nav">
           <li class="active">
              <img src="<?php echo base_url(); ?>images/menu-icon.png" alt="Menu" data-toggle="collapse" id="menu-toggle-2" />
           </li>
        </ul>
		<div class="notification_bar">
			<a href="<?php echo base_url(); ?>login/logout" title="Log out"><button class="log_out">Log out</button></a>
		</div>
	</div>
</nav>
   <div id="wrapper">
      <div id="sidebar-wrapper" class="sticky">
         <ul class="sidebar-nav nav-pills nav-stacked" id="menu">
           <!-- <li class="active">
               <a href="javascript:void(0)"><span class="fa-stack fa-lg pull-left"><i class="fa fa-dashboard fa-stack-1x "></i></span> Dashboard</a>
            </li>-->
            <li class="active">
               <a href="<?php echo base_url(); ?>registerlist"><span class="fa-stack fa-lg pull-left"><i class="fa fa-user fa-stack-1x "></i></span>Register List</a>
            </li>
            <li>
               <a href="javascript:void(0)"><span class="fa-stack fa-lg pull-left"><i class="fa fa-plus fa-stack-1x "></i></span>Add New</a>
            </li>
            <li>
               <a href="javascript:void(0)"> <span class="fa-stack fa-lg pull-left"><i class="fa fa-cart-plus fa-stack-1x "></i></span>Events</a>
            </li>
            <li>
               <a href="javascript:void(0)"><span class="fa-stack fa-lg pull-left"><i class="fa fa-youtube-play fa-stack-1x "></i></span>About</a>
            </li>
            <li>
               <a href="javascript:void(0)"><span class="fa-stack fa-lg pull-left"><i class="fa fa-wrench fa-stack-1x "></i></span>Services</a>
            </li>
            <li>
               <a href="javascript:void(0)"><span class="fa-stack fa-lg pull-left"><i class="fa fa-server fa-stack-1x "></i></span>Contact</a>
            </li>
         </ul>
      </div>
      <div id="page-content-wrapper">
         <div class="container-fluid xyz">
            <div class="row">
               <div class="col-lg-12">
			   <div class="col-lg-12_padding">
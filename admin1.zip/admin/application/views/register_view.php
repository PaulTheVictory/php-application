<?php
	$operand1 = mt_rand(1,9);
	$operand2 = mt_rand(1,9);			
	$capqns = $operand1." + ".$operand2." = ";
	$capans = $operand1+$operand2;
?>

 <div class="free-consection">
	<div class="free-consectionalign">	
		<form method="post" action="#" id="register_form" enctype="multipart/form-data" autocomplete='off'>
			<h1>Register Form</h1>
			<ul class="register">
				<li>
					
					<label>Name :</label>
					<span><input type="text" name="regname" class="register_text_box reg_name" placeholder="" ></span>
				</li>
				<li>
					<label>Email :</label>
					<span><input type="text" name="regemail" class="register_text_box reg_email" placeholder="" ></span>
				</li>
				<li>
					<label>Password :</label>
					<span><input type="password" name="regpassword" class="register_text_box reg_password" placeholder="" readonly onfocus="this.removeAttribute('readonly');"></span>
				</li>
				<li>
					<label>Confirm Password :</label>
					<span><input type="password" name="regconpassword" class="register_text_box reg_conpassword" placeholder="" readonly onfocus="this.removeAttribute('readonly');"></span>
				</li>
				<li>
					<label>Phone :</label>
					<span><input type="text" name="regphone" class="register_text_box reg_phone" placeholder="" ></span>
				</li>
				<li>
					<label>Gender :</label>
					<span><select name="reggender" class="register_select_box reg_gender">
						<option value="">Select Gender</option>
						<option value="male">Male</option>
						<option value="female">Female</option>
					</select></span>
				</li>
				<li>
					<label>Date of birth :</label>
					<span class="dob_sel"><select name="regdobday" class="register_select_box reg_dobday"></select>
					<select name="regdobmonth" class="register_select_box reg_dobmonth"></select>
					<select name="regdobyear" class="register_select_box reg_dobyear"></select></span>
				</li>
				<li>
					<label>Address :</label>
					<span><textarea name="regaddress" class="reg_address" placeholder="" ></textarea></span>
				</li>
				<li>
					<label>State :</label>
					<span><select name="regstate" class="register_select_box reg_state">
						<option value="">Select Your State</option>
						<option value="Andhra Pradesh">Andhra Pradesh</option>
						<option value="Andaman and Nicobar Islands">Andaman and Nicobar Islands</option>
						<option value="Arunachal Pradesh">Arunachal Pradesh</option>
						<option value="Assam">Assam</option>
						<option value="Bihar">Bihar</option>
						<option value="Chandigarh">Chandigarh</option>
						<option value="Chhattisgarh">Chhattisgarh</option>
						<option value="Dadar and Nagar Haveli">Dadar and Nagar Haveli</option>
						<option value="Daman and Diu">Daman and Diu</option>
						<option value="Delhi">Delhi</option>
						<option value="Lakshadweep">Lakshadweep</option>
						<option value="Puducherry">Puducherry</option>
						<option value="Goa">Goa</option>
						<option value="Gujarat">Gujarat</option>
						<option value="Haryana">Haryana</option>
						<option value="Himachal Pradesh">Himachal Pradesh</option>
						<option value="Jammu and Kashmir">Jammu and Kashmir</option>
						<option value="Jharkhand">Jharkhand</option>
						<option value="Karnataka">Karnataka</option>
						<option value="Kerala">Kerala</option>
						<option value="Madhya Pradesh">Madhya Pradesh</option>
						<option value="Maharashtra">Maharashtra</option>
						<option value="Manipur">Manipur</option>
						<option value="Meghalaya">Meghalaya</option>
						<option value="Mizoram">Mizoram</option>
						<option value="Nagaland">Nagaland</option>
						<option value="Odisha">Odisha</option>
						<option value="Punjab">Punjab</option>
						<option value="Rajasthan">Rajasthan</option>
						<option value="Sikkim">Sikkim</option>
						<option value="Tamil Nadu">Tamil Nadu</option>
						<option value="Telangana">Telangana</option>
						<option value="Tripura">Tripura</option>
						<option value="Uttar Pradesh">Uttar Pradesh</option>
						<option value="Uttarakhand">Uttarakhand</option>
						<option value="West Bengal">West Bengal</option>
					</select></span>
				</li>
				<li>
					<label>City :</label>
					<span>
					<input type="text" name="regcity" class="register_select_box reg_city" placeholder="">
					</span>
				</li>
				<li>
					<label>Pincode :</label>
					<span><input type="text" name="regpincode" class="reg_pincode" placeholder=""></span>
				</li>
				<li>
					<label>Photo :</label>
					<span><input type='file' name='regphoto' class="reg_file_box reg_photo"></span>
				</li>
				<li>
					<label>Degree Certificate :</label>
					<span><input type='file' name='regcertificate' class="reg_file_box1 reg_certificate"></span>
				</li>
				<li>
					<label>Curriculum Vitae :</label>
					<span><input type='file' name='regresume' class="reg_file_box2 reg_resume"></span>
				</li>
				<li>
					<label class="capcha"><?php echo $capqns; ?></label>
					<span><input type="text" name="capthaans" class="register_text_box reg_capcha"></span>
					<input name="correctans" type="hidden" class="register_text_box reg_capchaverify" value="<?php echo $capans; ?>" />
				</li>
				
				<li class="sub">
				<h6 class="error_log_text"></h6><h6 class="finish"></h6>
					<input type="submit" class="submit" name="submit" value="Submit" id="submit_form">
				</li>
				
			</ul>	
		</form>
	</div>
</div>
 


	

<script>

$('input[type="text"], input[type="password"]').val("");
$('input[type="text"], input[type="password"]').attr('autocomplete', 'off');

$("#register_form").find("input,select,textarea,input[type='text'],input[type='password']").each(function(){
        $("input,select,textarea").click(function(){
			$("input,select,textarea").removeClass("error_class");$(".error_log_text").text("");
		});
		 

    });

$(document).ready(function(){

$.dobPicker({
	daySelector: '.reg_dobday', /* Required */
	monthSelector: '.reg_dobmonth', /* Required */
	yearSelector: '.reg_dobyear', /* Required */
	dayDefault: 'Day', /* Optional */
	monthDefault: 'Month', /* Optional */
	yearDefault: 'Year', /* Optional */
	minimumAge: 18, /* Optional */
	maximumAge: 80 /* Optional */
});

$("#register_form").on("submit",function(e){
	e.preventDefault();
	
	var regname = $(".reg_name").val();
	var regemail = $(".reg_email").val();
	var regpassword = $(".reg_password").val();
	var regconpassword = $(".reg_conpassword").val();
	var regphone = $(".reg_phone").val();
	var reggender = $(".reg_gender").val();
	var regdobday = $(".reg_dobday").val();
	var regdobmonth = $(".reg_dobmonth").val();
	var regdobyear = $(".reg_dobyear").val();
	var regaddress = $(".reg_address").val();
	var regstate = $(".reg_state").val();
	var regcity = $(".reg_city").val();
	var regpincode = $(".reg_pincode").val();
	var regphoto = $(".reg_photo").val();
	var regcertificate = $(".reg_certificate").val();
	var regresume = $(".reg_resume").val();
	var capthaans = $(".reg_capcha").val();
	var correctans = $(".reg_capchaverify").val();
	
	
	var regex   = new RegExp('^[a-zA-Z][a-zA-Z\.-/ ]{1,100}$');
	var valid = regex.test(regname);
	
	if(!valid){ $(".reg_name").addClass('error_class');$(".error_log_text").text("Invalid Name");return;}
	
	
	regex   = new RegExp('^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$');
    valid = regex.test(regemail);
	
	if(!valid){ $(".reg_email").addClass('error_class');$(".error_log_text").text("Invalid Email");return;}
	
	
	if(regpassword == "") {  
     $(".reg_password").addClass('error_class');$(".error_log_text").text("Invalid Password");return;}  
	else if (regpassword.length < 8) {
		 $(".reg_password").addClass('error_class');$(".error_log_text").text("Password length must be atleast 8 characters");return;} 
	else if (regpassword.length > 15) {
		 $(".reg_password").addClass('error_class');$(".error_log_text").text("Password length must not exceed 15 characters");return;} 
		 
	if(regconpassword != regpassword)  
  { 
	$(".reg_password").addClass('error_class');$(".error_log_text");
	$(".reg_conpassword").addClass('error_class');$(".error_log_text").text("Passwords did not match");
	return;} 
   
	
	regex   = new RegExp('^[0-9 \-]{5,20}$');
    valid = regex.test(regphone);

    if(!valid){ $(".reg_phone").addClass('error_class');$(".error_log_text").text("Invalid Phone Number");return;}
	
	
	var regex   = new RegExp('^[a-zA-Z][a-zA-Z\.-/ ]{3,100}$');
    valid = regex.test(reggender);

	if(!valid){ $(".reg_gender").addClass('error_class');$(".error_log_text").text("Invalid Gender");return;}
	
	if(regdobday=="" || regdobmonth=="" || regdobyear==""){ $(".reg_dobday,.reg_dobmonth,.reg_dobyear").addClass('error_class');$(".error_log_text").text("Invalid Date of Birth");return;}
	
	var dobdate = regdobyear+'/'+regdobmonth+'/'+regdobday;
		var datevalid = isDate(dobdate);

		if(!datevalid) {
		  $(".reg_dobday,.reg_dobmonth,.reg_dobyear").addClass('error_class');
		  $(".error_log_text").text("Invalid Date of Birth");
		  return;
		}
	
	var regdobdayofbirth = regdobday+'-'+regdobmonth+'-'+regdobyear;
	
	regex   = new RegExp('^[a-zA-Z0-9#][a-zA-Z0-9\n\.,-_/#:& ]{3,250}$');
    valid = regex.test(regaddress);

    if(regaddress==""){ $(".reg_address").addClass('error_class');$(".error_log_text").text("Invalid Address");return;}

	
	var regex   = new RegExp('^[a-zA-Z][a-zA-Z\.-/ ]{3,100}$');
    valid = regex.test(regstate);

	if(!valid){ $(".reg_state").addClass('error_class');$(".error_log_text").text("Invalid State");return;}
	
	
	var regex   = new RegExp('^[a-zA-Z][a-zA-Z\.-/ ]{3,100}$');
    valid = regex.test(regcity);

	if(!valid){ $(".reg_city").addClass('error_class');$(".error_log_text").text("Invalid City");return;}


	regex   = new RegExp('^[0-9 \-]{4,10}$');
    valid = regex.test(regpincode);

    if(!valid || regpincode==""){ $(".reg_pincode").addClass('error_class');$(".error_log_text").text("Invalid Pincode Number");return;}
	
	regex   = new RegExp(/\.(gif|jpg|jpeg|tiff|png)$/i);
    valid = regex.test(regphoto);

    if(!valid || regphoto==""){ $(".reg_photo").addClass('error_class');$(".error_log_text").text("Invalid Photo Format");return;}
	
	regex   = new RegExp(/\.(gif|jpg|jpeg|tiff|png|pdf|docx|doc|pptx|ppt)$/i);
    valid = regex.test(regcertificate);

    if(!valid || regcertificate==""){ $(".reg_certificate").addClass('error_class');$(".error_log_text").text("Invalid Certificate Format");return;}
	
	regex   = new RegExp(/\.(gif|jpg|jpeg|tiff|png|pdf|docx|doc|pptx|ppt)$/i);
    valid = regex.test(regresume);

    if(!valid || regresume==""){ $(".reg_capcha").addClass('error_class');$(".error_log_text").text("Invalid Curriculum Vitae Format");return;}
	
	if(capthaans != correctans) {$(".reg_capcha").addClass('error_class');$(".error_log_text").text("Invalid Capthca Code");return;}

      
	
	
	if($("#submit_form").hasClass('process')){
		alert("Please wait while processing...");
	}else{
	
		$("#submit_form").addClass('process').val('Processing...');
	
	$.ajax({
        	url:'Register/NewRegister',
			type:'POST',
			data: new FormData(this),
			processData: false,
            contentType: false,
            cache: false,
			success:function(data){
				var obj1 = $.parseJSON(data);
				
				if(obj1[0]=="success"){
					setTimeout(function(){
					$("#register_form")[0].reset();
					$(".finish").text('Register Successfully');
					$("#submit_form").removeClass('process').val('Submit');
					location.reload();
					},3000);
				}
				else if(obj1[0]=="EmailExit"){
					alert("Email ID Already Exists");
					$("#submit_form").removeClass('process').val('Submit');
				}
				else if(obj1[0]=="PhoneExit"){
					alert("Phone No Already Exists");
					$("#submit_form").removeClass('process').val('Submit');
				}
				else if(obj1[0]=="upfail"){
					alert("Upload Failed.");
					$("#submit_form").removeClass('process').val('Submit');
				}
				else if(obj1[0]=="filenotuploaded"){
					alert("Please upload valid format photo.");
					$("#submit_form").removeClass('process').val('Submit');
				}
				else if(obj1[0]=="fail"){
					alert("Please try again.");
					$("#submit_form").removeClass('process').val('Submit');
				}
				else if(obj1[0]=="passwordfail"){
					alert("Password Mismatch.");
					$("#submit_form").removeClass('process').val('Submit');
				}
				else if(obj1[0]=="PhotoEmpty"){
					alert("Photo Empty.");
					$("#submit_form").removeClass('process').val('Submit');
				}
				else if(obj1[0]==""){
					alert("Please try again.");
					$("#submit_form").removeClass('process').val('Submit');
				}
				
			}
			
     	}); 
		
	}	
	

});


	var regdobday = '<option value="">Day</option>';
	var regdobmonth = '<option value="">Month</option>';
	var regdobyear = '<option value="">Year</option>';
	
	for(var d=1;d<32;d++){
		
		var day = (d < 10 ? '0' : '') + d;
		regdobday += '<option value="'+day+'">'+day+'</option>';
		
	}
	$(".reg_dobday").html(regdobday);
	
	var monthNames = ["","January","February","March","April","May","June","July","August","September","October","November","December"];
	for(var m=1;m<monthNames.length;m++){
		
		var mon = (m < 10 ? '0' : '') + m;
		regdobmonth += '<option value="'+mon+'">'+monthNames[m]+'</option>';
		
	}
	$(".reg_dobmonth").html(regdobmonth);
	
	var currentTime = new Date();
	var curyear = currentTime.getFullYear();
	var firstYear = curyear - 80;
	var lastYear = firstYear + 63;
	for(var y=firstYear;y<lastYear;y++){
		
		regdobyear += '<option value="'+y+'">'+y+'</option>';
		
	}
	$(".reg_dobyear").html(regdobyear);
	
	
});	

	
	
	


	
	$("ul.register").find("input,select,textarea").each(function(){
        $("input,select,textarea").click(function(){
			$("input,select,textarea").removeClass("error_class");$(".error_log_text").text("");
			if($("input,select,textarea").is('.reg_dobday','.reg_dobmonth','.reg_dobyear')){
				$('.reg_dobday','.reg_dobmonth','.reg_dobyear').removeClass("error_class");
			}
		});
		 

    });

	 
function isDate(txtDate)
{
    var currVal = txtDate;
    if(currVal == '')
        return false;
    
    var rxDatePattern = /^(\d{4})(\/|-)(\d{1,2})(\/|-)(\d{1,2})$/; //Declare Regex
    var dtArray = currVal.match(rxDatePattern); // is format OK?
    
    if (dtArray == null) 
        return false;
    
    //Checks for mm/dd/yyyy format.
    dtMonth = dtArray[3];
    dtDay= dtArray[5];
    dtYear = dtArray[1];        	
   
	if (dtMonth < 1 || dtMonth > 12) 
        return false;
    else if (dtDay < 1 || dtDay> 31) 
        return false;
    else if ((dtMonth==4 || dtMonth==6 || dtMonth==9 || dtMonth==11) && dtDay ==31) 
        return false;
    else if (dtMonth == 2) 
    {
        var isleap = (dtYear % 4 == 0 && (dtYear % 100 != 0 || dtYear % 400 == 0));
        if (dtDay> 29 || (dtDay ==29 && !isleap)) 
                return false;
    }
	
    return true;
}	 
	
	 




</script>
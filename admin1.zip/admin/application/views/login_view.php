



<div class="login_form">
	<div class="wrap_grid_full">
		<div class="login_form_content">
			<div class="login_form_left">
				<img src="<?php echo base_url();?>images/login.png" alt="Login" />
			</div>
			<div class="login_form_right">
			<h1>Welcome Back</h1>
			<form action="" method="post" id="login" autocomplete='off'>
				<h4>Login with your user ID</h4>
				
				<input type="text" name="username" class="login_name" placeholder="Username" readonly onfocus="this.removeAttribute('readonly');"/>
				<input type="password" name="password" class="login_password" placeholder="Password" readonly onfocus="this.removeAttribute('readonly');"/>
				
				<div class="forgot_pass">
					<div class="remember">	
						<label class="b-contain">
						<span>Remember Me</span>
						<input type="checkbox">
						<div class="b-input"></div>
					</label>
					</div>
					<a href="<?php echo base_url();?>forgotpassword" title="Forgot Password">Forgot Password</a>
				</div>
				<h6 class="error_log_text"></h6>
				<span>
				<input name="submit" type="submit" id="login_submit" value="LOGIN" />
				
				</span>
				
			</form>
			</div>
		</div>
	</div>
</div>

<script type="text/javascript">

$(document).ready(function(){

$('input[type="text"], input[type="password"]').val("");
$('input[type="text"], input[type="password"]').attr('autocomplete', 'off');

$("#login").on("submit",function(e){
	e.preventDefault();
	
	var loginname = $(".login_name").val();
	var loginpassword = $(".login_password").val();
	
	if(loginname==""){ $(".login_name").addClass('error_class');$(".error_log_text").text("Invalid Username");return;}
	if(loginpassword==""){ $(".login_password").addClass('error_class');$(".error_log_text").text("Invalid Password");return;}
	
	if($("#login_submit").hasClass('process')){
		alert("Please wait while processing...");
	}else{
	
		$("#login_submit").addClass('process').val('Processing...');
	
	$.ajax({
        	url:'Login/verifyLogin',
			type:'POST',
			data: new FormData(this),
			processData: false,
            contentType: false,
            cache: false,
			success:function(data){
				var obj1 = $.parseJSON(data);
				
				if(obj1[0]=="success"){
					
					setTimeout(function(){
						$("#login_submit").removeClass('process').val('LOGIN');
						//location.assign("dashboard.html");
						location.reload("dashboard");
						//alert('success');
					},2000);
				}
				else if(obj1[0]=="fail"){
					//alert("Login Failed.");
					$("#login_submit").removeClass('process').val('LOGIN');
					setTimeout(function(){ $(".error_log_text").text("Username and Password did't match"); }, 500);
				}
				else if(obj1[0]=="notfound"){
					//alert("Please try again.");
					$("#login_submit").removeClass('process').val('LOGIN');
					setTimeout(function(){ $(".error_log_text").text("Username Not Exists"); }, 500);
				}
				else if(obj1[0]=="notactive"){
					//alert("Please try again.");
					$("#login_submit").removeClass('process').val('LOGIN');
					setTimeout(function(){ $(".error_log_text").text("Account is Not Active"); }, 500);
				}
				
				else if(obj1[0]==""){
					//alert("Please try again.");
					$("#login_submit").removeClass('process').val('LOGIN');
					setTimeout(function(){ $(".error_log_text").text("Please try Again Later"); }, 500);
				}
				
			}
			
     	}); 
		
	}
	
})
}); 
$("#login").find("input,select,textarea").each(function(){
        $("input,select,textarea").click(function(){
			$("input,select,textarea").removeClass("error_class");$(".error_log_text").text("");
		});
		 

    });


</script>



<!--header_section-->


<div class="header_section">
	<div class="wrap_grid">
		<div class="header_align">
			<div class="header_left">
				<a href="javascript:void(0)" title="PHP FORM"><h2>PHP FORM</h2></a>
			</div>
			<div class="header_right">
				
				<!--<ul class="menu">
					<li><a href="register-view.html" title="REGISTER LIST">REGISTER LIST</a></li>
					<li><a href="edit.html" title="EDIT">EDIT</a></li>
					<li><a href="" title="DELETE">DELETE</a></li>
					<li><a href="" title="ADD">ADD</a></li>
				</ul>-->
				
				<ul>
				
					<!--<li><a href="logout.php" title="LOGOUT"><button>LOGOUT</button></a></li>-->
				
				
					<li><a href="javascript:void(0)" title="Register"><button>Register</button></a></li>
				
				</ul>
			</div>
		</div>
	</div>
</div>


<!--header_section-->
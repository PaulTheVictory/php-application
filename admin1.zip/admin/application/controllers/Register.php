<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');




class Register extends CI_Controller {

function __construct()
{
parent::__construct();
$this->load->model('user_model','',TRUE);
}

function index()
{
$this->load->view('header');
$this->load->view('user_header');
$this->load->view('register_view');
$this->load->view('user_footer');
$this->load->view('footer');		

}

public function NewRegister() {
	

$regname = isset($_POST['regname'])?$_POST['regname']:'';
$regemail = isset($_POST['regemail'])?$_POST['regemail']:'';
$pass1 = isset($_POST['regpassword'])?$_POST['regpassword']:'';
$pass2 = isset($_POST['regconpassword'])?$_POST['regconpassword']:'';
$regphone = isset($_POST['regphone'])?$_POST['regphone']:'';
$reggender = isset($_POST['reggender'])?$_POST['reggender']:'';
$regdobday = isset($_POST['regdobday'])?$_POST['regdobday']:'';
$regdobmonth = isset($_POST['regdobmonth'])?$_POST['regdobmonth']:'';
$regdobyear = isset($_POST['regdobyear'])?$_POST['regdobyear']:'';
$regaddress = isset($_POST['regaddress'])?$_POST['regaddress']:'';
$regstate = isset($_POST['regstate'])?$_POST['regstate']:'';
$regcity = isset($_POST['regcity'])?$_POST['regcity']:'';
$regpincode = isset($_POST['regpincode'])?$_POST['regpincode']:'';
$dob = $regdobday.'-'.$regdobmonth.'-'.$regdobyear;
$role = 'user';

$attachment_path_1 = $_FILES["regphoto"]["tmp_name"];
$attachment_name_1 = basename($_FILES['regphoto']['name']);
$attachment_size_1 = $_FILES["regphoto"]["size"];




$attachment_path_2 = $_FILES["regcertificate"]["tmp_name"];
$attachment_name_2 = basename($_FILES['regcertificate']['name']);
$attachment_size_2 = $_FILES["regcertificate"]["size"];

$attachment_path_3 = $_FILES["regresume"]["tmp_name"];
$attachment_name_3 = basename($_FILES['regresume']['name']);
$attachment_size_3 = $_FILES["regresume"]["size"];





$ret = $this->user_model->NewRegister($regname,$regemail,$pass1,$pass2,$regphone,$reggender,$dob,$regaddress,$regstate,$regcity,$regpincode,$attachment_path_1,$attachment_name_1,$attachment_size_1,$attachment_path_2,$attachment_name_2,$attachment_size_2,$attachment_path_3,$attachment_name_3,$attachment_size_3,$role);
echo json_encode($ret);
	
	
	
}







}





?>
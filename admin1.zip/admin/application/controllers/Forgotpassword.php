<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

//session_start(); //we need to call PHP's session object to access it through CI

class Forgotpassword extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model('login_model','',TRUE);
	}
	
	function index()
	{
					
			$this->load->view('header');
			$this->load->view('forgotpassword_view');
			$this->load->view('footer');
			

	}
	
	public function ForgotPass()
	{
		$emailid  = isset($_POST['femailid'])?$_POST['femailid']:'';
		
		$ret = $this->login_model->SendForgetPassword($emailid);
		echo json_encode($ret);
	}
	
	
}
?>

<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');




class Viewprofile extends CI_Controller {

function __construct()
{
parent::__construct();
$this->load->model('login_model','',TRUE);
$this->load->model('admin_model','',TRUE);
}

function index()
{
if($this->session->userdata('loggedin')){			
$session_data = $this->session->userdata('loggedin');
$session_id = $session_data['id'];
$session_role = $session_data['role'];
$data['user'] = $this->login_model->GetUserId();
$userid = $this->input->get('userid');
if(!$userid){ redirect('registerlist', 'refresh'); }
if($userid==""){ redirect('registerlist', 'refresh'); }
$data['userdetails'] = $this->admin_model->GetUserDetails($userid);
$this->load->view('header',$data);
$this->load->view('dashboard_header',$data);
$this->load->view('viewprofile_view',$data);
$this->load->view('dashboard_footer');
$this->load->view('footer');		
}else{
redirect('login', 'refresh');
}
}


public function GetRegisterList() {
if($this->session->userdata('loggedin')){
$ret =  $this->admin_model->GetAllRegister();
echo $ret;
}else{
redirect('login', 'refresh');
}
}
}





?>
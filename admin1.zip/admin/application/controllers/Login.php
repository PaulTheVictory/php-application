<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Login extends CI_Controller {

function __construct()
{
parent::__construct();
$this->load->model('login_model','',TRUE);
}

function index()
{
if($this->session->userdata('loggedin')){			
$session_data = $this->session->userdata('loggedin');
$session_id = $session_data['id'];
$session_role = $session_data['role'];
$data['user'] = $this->login_model->GetUserId();
redirect('dashboard', 'refresh');			
}else{
$this->session->unset_userdata('loggedin');
//$data['menu'] = $this->load->view('headermenu', NULL, TRUE);
//$this->load->view('header', $data);
$this->load->view('header');
$this->load->view('login_view');
$this->load->view('footer');
}
}

public function verifyLogin() {
$emailid  = isset($_POST['username'])?$_POST['username']:'';
$password  = isset($_POST['password'])?$_POST['password']:'';
$ret = $this->login_model->VerifyLogin($emailid,$password);
echo json_encode($ret);
}
public function logout(){		
$this->login_model->endSession();
$this->session->unset_userdata('loggedin');		
$this->session->sess_destroy();
redirect(base_url(), 'refresh');
}

public function checkLogin() {
$ret = $this->login_model->CheckLogin();
echo json_encode($ret);
}


}


?>
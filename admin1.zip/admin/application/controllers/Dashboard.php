<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');




class Dashboard extends CI_Controller {

function __construct()
{
parent::__construct();
$this->load->model('login_model','',TRUE);
}

function index()
{
if($this->session->userdata('loggedin')){			
$session_data = $this->session->userdata('loggedin');
$session_id = $session_data['id'];
$session_role = $session_data['role'];
$data['user'] = $this->login_model->GetUserId();
$this->load->view('header');
$this->load->view('dashboard_header');
$this->load->view('dashboard_view');
$this->load->view('dashboard_footer');
$this->load->view('footer');		
}else{
redirect('login', 'refresh');
}
}








}





?>
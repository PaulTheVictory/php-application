<?php

Class Admin_Model extends CI_Model
{		

public function __construct() {
	$this->load->library('Datatables');
}

public function GetAllRegister() {

$arr = Array();
$arr['list'] = "";

$this->datatables->select('userid,name,email,phone,gender,role,created') 
	->edit_column('userid', '<a href="'.base_url().'viewprofile?userid=$1">$1</a>', 'userid') 
	//->add_column('image', '<img src="'.base_url().'docs/courses/$1"  style="width: 100px;"/>', 'image')
	//->edit_column('id', '<a class="del" id="$1" href="javascript:void(0)">x</a>', 'id')
	->from('register_form') ;

$table =  $this->datatables->generate();
return $table;
}


public function GetUserDetails($userid) {
       	
$arr = array();
$arr['userdetails'] = array();
$query = $this-> db -> query('select * from register_form where userid="'.$userid.'"');
$row = $query->result_array();
if($query->num_rows()>0){
	return $row[0];
}
return $arr;
}











	
	
	
}


?>
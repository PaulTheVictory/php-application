<?php

Class User_Model extends CI_Model
{		

public function __construct() {
	$this->load->library('Datatables');
}


public function NewRegister($regname,$regemail,$pass1,$pass2,$regphone,$reggender,$dob,$regaddress,$regstate,$regcity,$regpincode,$attachment_path_1,$attachment_name_1,$attachment_size_1,$attachment_path_2,$attachment_name_2,$attachment_size_2,$attachment_path_3,$attachment_name_3,$attachment_size_3,$role) {
	
$result = array(0 => "");


$emailquery = $this->db->query('SELECT email FROM register_form WHERE email="'.$regemail.'"');
$phonequery = $this->db->query('SELECT phone FROM register_form WHERE phone="'.$regphone.'"');
	
if($emailquery->num_rows()>0) {
	$result = array(0 => "EmailExit");
	return $result;
} else if ($phonequery->num_rows()>0) {
	$result = array(0 => "PhoneExit");
	return $result;
} else {

	$offset=5*60*60 + 30*60;
	$dateformat = 'Y-m-d H:i:s';
	$curtime = gmdate($dateformat, time()+$offset);
	$id = uniqid();
	
	$iduser = uniqid();

if ($pass1 != $pass2) {
	$result = array(0 => "passwordfail");
	return $result;
} else {
	$regpassword = md5($pass1);
}

	
	$attach = "";
	$newnameurl = "";
	
$allowed_extensions = array("pdf", "doc", "docx", "jpg", "xml", "ppt", "pptx", "bmp", "rtf", "jpeg", "png", "JPG", "JPEG", "PNG","txt");
$type_of_uploaded_file1 = substr($attachment_name_1,  strrpos($attachment_name_1, '.') + 1);
$type_of_uploaded_file2 = substr($attachment_name_2,  strrpos($attachment_name_2, '.') + 1);
$type_of_uploaded_file3 = substr($attachment_name_3,  strrpos($attachment_name_3, '.') + 1);

$allowed_ext = false;

if(!in_array($type_of_uploaded_file1,$allowed_extensions) || !in_array($type_of_uploaded_file2,$allowed_extensions) || !in_array($type_of_uploaded_file3,$allowed_extensions))
	{
		$allowed_ext = true;
	}


if($allowed_ext)
{
	$result = array(0 => "photoempty");
	return $result;
}	

date_default_timezone_set("Asia/Kolkata");

$newname1 = "reg_photo.".$type_of_uploaded_file1;
$newname2 = "reg_cerficate.".$type_of_uploaded_file2;
$newname3 = "reg_resume.".$type_of_uploaded_file3;

$pathurl = "uploads/";

if(!file_exists($pathurl)) {                                    
	mkdir($pathurl, 0777);                                  
}


$dirName = 'uploads/'.$iduser.'/';



if(!file_exists($dirName)) {                                    
	mkdir($dirName, 0777);                                  
}


$destination1 = $dirName.$newname1;

if(move_uploaded_file($attachment_path_1,$destination1))
	{
		$fileurl1 = $newname1;
		
	}else {
		$result = array(0 => "upfail");
	return $result;
	}
	
$destination2 = $dirName.$newname2;

if(move_uploaded_file($attachment_path_2,$destination2))
	{
		$fileurl2 = $newname2;
		
	}else {
		$result = array(0 => "upfail");
	return $result;
	}

$destination3 = $dirName.$newname3;

if(move_uploaded_file($attachment_path_3,$destination3))
	{
		$fileurl3 = $newname3;
		
	}else {
		$result = array(0 => "upfail");
	return $result;
	}
	
	
	
	$query = $this->db->query('INSERT INTO register_form (`id`,`userid`,`name`,`email`,`password`,`phone`,`role`,`gender`,`dob`,`address`,`state`,`city`,`pincode`,`photo`,`certificate`,`resume`,`doj`,`created`) VALUES ("'.$id.'","'.$iduser.'","'.$regname.'","'.$regemail.'","'.$regpassword.'","'.$regphone.'","'.$role.'","'.$reggender.'","'.$dob.'","'.$regaddress.'","'.$regstate.'","'.$regcity.'","'.$regpincode.'","'.$fileurl1.'","'.$fileurl2.'","'.$fileurl3.'","'.$curtime.'","'.$curtime.'")');
	
	
	
	if($query) {
		$result = array(0 => "success");
        return $result;
	} else {
		$result = array(0 => "fail");
        return $result;
	}
	return $result;
	
	
	
	
	
	
	
	

}



}	
	
	
	
	
	
	
	
	
	
	
}











	
	
	



?>
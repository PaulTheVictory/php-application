-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Feb 06, 2021 at 08:33 AM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `serverside_dt`
--

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `first_name` varchar(45) NOT NULL,
  `last_name` varchar(45) NOT NULL,
  `email` varchar(75) NOT NULL,
  `gender` enum('Male','Female') NOT NULL,
  `date_of_birth` date NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `gender`, `date_of_birth`, `created_at`) VALUES
(1, 'Allen', 'Carlson', 'allen@example.com', 'Male', '1992-12-06', '2021-02-01 07:14:39'),
(2, 'Evette', 'Parker', 'evette@example.com', 'Female', '1973-10-14', '2021-02-05 07:14:39'),
(3, 'Savanna', 'Johnson', 'savanna@example.com', 'Female', '1982-03-19', '2021-02-01 07:14:39'),
(4, 'Gloria', 'Rosalez', 'gloria@example.com', 'Female', '1992-06-12', '2021-02-01 07:14:39'),
(5, 'Paul', 'Fredrickson', 'paul@example.com', 'Male', '1990-06-07', '2021-02-02 07:14:39'),
(6, 'Charlotte', 'Winston', 'charlotte@example.com', 'Female', '1962-12-06', '2021-02-02 07:14:39'),
(7, 'Ivan', 'Payne', 'ivan@example.com', 'Male', '1959-01-17', '2021-02-02 07:14:39'),
(8, 'Philip', 'Andrade', 'philip@example.com', 'Male', '1964-03-24', '2021-02-03 07:14:39'),
(9, 'Rick', 'Davenport', 'rick@example.com', 'Male', '1955-03-18', '2021-02-03 07:14:39'),
(10, 'Pearl', 'Demmer', 'pearl@example.com', 'Female', '1988-09-09', '2021-02-04 07:14:39'),
(11, 'Michael', 'Brooks', 'michael@example.com', 'Male', '1993-09-21', '2021-02-05 07:14:39'),
(12, 'Vivian', 'Zoller', 'vivian@example.com', 'Female', '1986-12-09', '2021-02-04 07:14:39'),
(13, 'Jamie', 'Garcia', 'jamie@example.com', 'Male', '2001-03-12', '2021-02-05 07:14:39'),
(14, 'Natalie', 'Ray', 'natalie@example.com', 'Female', '1981-01-13', '2021-02-05 07:14:39'),
(15, 'Charlie', 'Harpster', 'charlie@example.com', 'Male', '1990-09-05', '2021-02-06 07:14:39'),
(16, 'Mae', 'Heaton', 'mae@example.com', 'Female', '1974-03-24', '2021-02-06 07:14:39');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

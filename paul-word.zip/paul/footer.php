


<script type="text/javascript" src="<?php echo esc_url(get_template_directory_uri());?>/js/jquery_min.js"></script>
<script type="text/javascript" src="<?php echo esc_url(get_template_directory_uri());?>/js/bootstrap_min.js"></script>
<script type="text/javascript" src="<?php echo esc_url(get_template_directory_uri());?>/js/desk_menu_min.js"></script>
<script type="text/javascript" src="<?php echo esc_url(get_template_directory_uri());?>/js/date.js"></script>
<script type="text/javascript" src="<?php echo esc_url(get_template_directory_uri());?>/js/slider_min.js"></script>
<script type="text/javascript" src="<?php echo esc_url(get_template_directory_uri());?>/js/swiper_slider.js"></script>
<script type="text/javascript" src="<?php echo esc_url(get_template_directory_uri());?>/js/modernizr_min.js"></script>
<script type="text/javascript" src="<?php echo esc_url(get_template_directory_uri());?>/js/gallery_min.js"></script>
<script type="text/javascript" src="<?php echo esc_url(get_template_directory_uri());?>/js/mob_menu_min.js"></script>
<?php if(get_the_title()=="Gallery"){ ?>
	<script type="text/javascript" src="<?php echo esc_url(get_template_directory_uri());?>/js/mixitup_min.js"></script>
	<?php } ?>

	
<?php wp_footer(); ?>
</body>
</html>

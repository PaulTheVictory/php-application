<?php
/**
* The template for displaying the header
*
* Displays all of the head element and everything up until the "site-content" div.
*
* @package WordPress
* @subpackage Twenty_Sixteen
* @since Twenty Sixteen 1.0
*/
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?> class="no-js" >
	<head>
		<meta charset="<?php bloginfo( 'charset' ); ?>">
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<link rel="profile" href="http://gmpg.org/xfn/11">
		<?php if ( is_singular() && pings_open( get_queried_object() ) ) : ?>
		<link rel="pingback" href="<?php echo esc_url( get_bloginfo( 'pingback_url' ) ); ?>">
		<?php endif; ?>
		<?php
		$url = home_url($wp->request);
		$meta = get_post_meta(get_the_ID(), '', true);
		$title = $meta['Title'][0];
		$description = $meta['Description'][0];
		$keyword = $meta['Keyword'][0];
		if($title!="") {echo '<title>'.$title.'</title>'.PHP_EOL;}
		else{?>
		<title><?php wp_title('|',true,'right'); ?> <?php bloginfo('name'); ?></title>
		<?php
		}
		if($description!="") echo '<meta name="description" content="'.$description.'" />'.PHP_EOL;
		if($keyword!="") echo '<meta name="keywords" content="'.$keyword.'" />'.PHP_EOL;
		?>
		
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
		<meta http-equiv="Cache-control" content="public"/>
		<link rel="canonical" href="" />
		<link rel="stylesheet" type="text/css" href="<?php echo esc_url(get_template_directory_uri());?>/css/bootstrap_min.css"/>
		<?php wp_head(); ?>
		<link rel="stylesheet" type="text/css" href="<?php echo esc_url(get_template_directory_uri());?>/css/swiper_slider.css"/>
		<link rel="stylesheet" type="text/css" href="<?php echo esc_url(get_template_directory_uri());?>/css/animate_min.css"/>
		<link rel="stylesheet" type="text/css" href="<?php echo esc_url(get_template_directory_uri());?>/css/date.css" />
		<link rel="stylesheet" type="text/css" href="<?php echo esc_url(get_template_directory_uri());?>/css/mob_menu_min.css" />
		<link rel="stylesheet" type="text/css" href="<?php echo esc_url(get_template_directory_uri());?>/css/gallery_min.css" />
		 <!-- <link rel="stylesheet" type="text/css" href="<?php echo esc_url(get_template_directory_uri());?>/style.css"/> -->
		<link rel="stylesheet" type="text/css" href="<?php echo esc_url(get_template_directory_uri());?>/css/style_media.css"/>
		<link rel="stylesheet" type="text/css" href="<?php echo esc_url(get_template_directory_uri());?>/css/gallery.css" />
		
	</head>
	<body <?php body_class(); ?>>
		
		  
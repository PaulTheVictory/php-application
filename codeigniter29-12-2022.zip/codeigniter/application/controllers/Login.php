<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Login extends CI_Controller
{

  function __construct()
  {
    parent::__construct();
    $this->load->model('Login_Model', '', TRUE);
    $this->load->helper('form');
    $this->load->library('form_validation');
    $this->load->library("user_agent");
  }



  public function index()
  {
    if ($this->session->userdata("super_in")) {
      $data["title"] = "All Customers";
      $this->load->view("layout/header_script", $data);
      $this->load->view("layout/header", $data);
      $this->load->view("allcustomers_view", $data);
      $this->load->view("layout/footer");
      $this->load->view("layout/footer_script");
    } elseif ($this->session->userdata("admin_in")) {
      $data["title"] = "Dashboard";
      $this->load->view("layout/header_script", $data);
      $this->load->view("layout/header", $data);
      $this->load->view("adminhome_view");
      $this->load->view("layout/footer");
      $this->load->view("layout/footer_script");
    } elseif ($this->session->userdata("user_in")) {
      $data["title"] = "Dashboard";
      $this->load->view("layout/header_script", $data);
      $this->load->view("layout/header", $data);
      $this->load->view("userhome_view");
      $this->load->view("layout/footer");
      $this->load->view("layout/footer_script");
    } else {

      $this->form_validation->set_rules("user_name", "Username", "trim|required|xss_clean");
      $this->form_validation->set_rules("pass_word", "Password", "trim|required|xss_clean|callback_check_database");
      $this->form_validation->set_error_delimiters('<p class="alert alert-danger alert-dismissible">', '<button type="button" class="btn-close" data-bs-dismiss="alert"></button></p>');
      if ($this->form_validation->run() === false || !$this->session->userdata("user_in")) {
        $data["title"] = "Login";
        $this->load->view("layout/header_script", $data);
        $this->load->view("adminlogin_view");
        $this->load->view("layout/footer_script");
      }
    }
  }


  public function check_database()
  {
    $passkey = $this->config->item('passkey');
    $username = $this->input->post("user_name", true);
    $password = sha1($passkey . $this->input->post("pass_word", true));

    $result = $this->Login_Model->user_login($username, $password);
    if ($result) {
      date_default_timezone_set("Asia/Calcutta");
      $sessdata = array();
      $date = date('Y-m-j H:i:s');
      foreach ($result as $row) {
        $sessdata = array(
          "user_id" => $row->customer_user_id,
          "customer_id"=>$row->customer_id,
          "name" => $row->customer_email,
          "role" => $row->role,
          "intime" => $date,
          "status" => "o",
        );
      };
      $this->session->set_userdata($sessdata);
      if ($sessdata["role"] === "superadmin") {
        $this->session->unset_userdata("user_in", false);
        $this->session->unset_userdata("admin_in", false);
        $this->session->set_userdata("super_in", true);
      } elseif ($sessdata["role"] === "customer") {
        $this->session->unset_userdata("super_in", false);
        $this->session->unset_userdata("user_in", false);
        $this->session->set_userdata("admin_in", true);
      } else {
        $this->session->unset_userdata("super_in", false);
        $this->session->unset_userdata("admin_in", false);
        $this->session->set_userdata("user_in", true);
      }

      $s_user_id = $this->session->userdata("user_id");
      $s_username = $this->session->userdata("name");
      $s_role = $this->session->userdata("role");
      $s_intime = $this->session->userdata("intime");
      $s_browser = $this->agent->browser() . " " . $this->agent->version();
      $s_platform = $this->agent->platform();
      $s_ip = $this->input->ip_address();

      $res = $this->Login_Model->CreateSession($s_user_id, $s_username, $s_role, $s_intime, $s_browser, $s_platform, $s_ip);

      if ($res) {
        redirect(base_url("dashboard"), "refresh");
      } else {
        $this->form_validation->set_message('check_database', 'Please Try again later!');
      }
    } else {
      $this->session->unset_userdata('user_in');
      $this->form_validation->set_message('check_database', 'User not exists!');
      return false;
    }
  }

  public function Logout()
  {
    $this->session->sess_destroy();
    date_default_timezone_set("Asia/Calcutta");
    $date = date('Y-m-j H:i:s');
    $s_id = $this->session->userdata("session_id");

    $res = $this->Login_Model->EndSession($s_id, $date);

    if ($res) {
      $this->session->unset_userdata('super_in');
      $this->session->unset_userdata('admin_in');
      $this->session->unset_userdata('user_in');
      redirect(base_url('admin'), 'refresh');
    }
  }
}

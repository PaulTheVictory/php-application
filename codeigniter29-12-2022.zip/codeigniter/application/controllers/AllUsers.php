<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Allusers extends CI_Controller {
  function __construct()
  {
    parent::__construct();
    $this->load->model('Admin_Model', 'admin_model', TRUE);
    $this->load->model('Superadmin_Model', 'superadmin_model', TRUE);
    $this->load->helper('form');
    $this->load->library('form_validation');
    $this->load->library("user_agent");
  }

public function index()
{
  if ($this->session->userdata("super_in")) {
    $data['customerlist'] = $this->superadmin_model->GetCustomerLists();
    $data["title"] = "All Customers";
    $this->load->view("layout/header_script",$data);
    $this->load->view("layout/header",$data);
    $this->load->view("allcustomers_view",$data);
    $this->load->view("layout/footer");
    $this->load->view("layout/footer_script");
  } elseif ($this->session->userdata("admin_in")) {
    $data["title"] = "Dashboard";
    $data['customerlist'] = $this->admin_model->GetCustomerLists();
    $this->load->view("layout/header_script",$data);
    $this->load->view("layout/header",$data);
    $this->load->view("allusers_view",$data);
    $this->load->view("layout/footer");
    $this->load->view("layout/footer_script");
  } elseif ($this->session->userdata("user_in")) {
    $data["title"] = "Dashboard";
    $this->load->view("layout/header_script",$data);
    $this->load->view("layout/header",$data);
    $this->load->view("userhome_view");
    $this->load->view("layout/footer");
    $this->load->view("layout/footer_script");
  } else {
    $data["title"] = "Login";
    $this->load->view("layout/header_script", $data);
    $this->load->view("login_view");
    $this->load->view("layout/footer_script");
  }
  
}


  public function getsinglecustomer()
  {
    $f_id = isset($_POST['f_id']) ? $_POST['f_id'] : '';
    $res = $this->admin_model->getsinglecustomerdetails($f_id);
    $arr["result"] = $res;
    echo json_encode($arr);
  }



public function DeleteUser()
	{
		$deleteid = isset($_POST['deleteid'])?$_POST['deleteid']:'';
		$result = $this->admin_model->DeleteById($deleteid);
		echo json_encode($result);
	}


  public function UpdateUser()
  {
    $deleteid = isset($_POST['updateid']) ? $_POST['updateid'] : '';
    $sid = isset($_POST['sid']) ? $_POST['sid'] : '';
    $result = $this->admin_model->UpdateById($deleteid, $sid);
    echo json_encode($result);
  }



  public function newuser()
  {
    $this->form_validation->set_rules("customer_user_name", "User Name", "trim|required|min_length[3]|max_length[20]");
    $this->form_validation->set_rules("customer_email", "User Email", "trim|required|valid_email|max_length[25]|is_unique[customer_login.customer_email]");
    $this->form_validation->set_rules("customer_password", "User Password", "trim|required|min_length[6]|max_length[25]");
    $this->form_validation->set_error_delimiters('<p class="alert alert-danger alert-dismissible">', '<button type="button" class="btn-close" data-bs-dismiss="alert"></button></p>');
    if ($this->form_validation->run() === FALSE) {
    $data['customerlist'] = $this->admin_model->GetCustomerLists();

      $data["title"] = "Add User";
      $this->load->view("layout/header_script", $data);
      $this->load->view("layout/header", $data);
      $this->load->view("allusers_view");
      $this->load->view("layout/footer");
      $this->load->view("layout/footer_script");
    } else {
      $passkey = $this->config->item('passkey');
      date_default_timezone_set("Asia/Calcutta");
      $c_doneby = $this->session->userdata("user_id");
      $c_date = date('Y-m-j');
      $c_time = date('H:i:s');
      $c_name = $this->input->post("customer_user_name", true);
      $c_email = $this->input->post("customer_email", true);
      $c_password = sha1($passkey . $this->input->post("customer_password", true));
      $c_orgpassword = $this->input->post("customer_password", true);
      $res = $this->admin_model->add_user($c_name, $c_email, $c_password, $c_date, $c_time, $c_doneby, $c_orgpassword);


      if ($res[0] === "success") {
        redirect(base_url("allusers"), "refresh");
      } else {
    $data['customerlist'] = $this->admin_model->GetCustomerLists();
        $this->session->set_flashdata('notadded', '<p class="alert alert-danger alert-dismissible">Not Added !<button type="button" class="btn-close" data-bs-dismiss="alert"></button></p>');
        $data["title"] = "Add User";
        $this->load->view("layout/header_script", $data);
        $this->load->view("layout/header", $data);
        $this->load->view("allusers_view");
        $this->load->view("layout/footer");
        $this->load->view("layout/footer_script");
        exit(0);
      }
    }
  }


  public function editcustomerbyid()
  {
    $viewid = isset($_POST['customerid']) ? $_POST['customerid'] : '';
    $this->form_validation->set_rules("customer_user_name", "Customer Name", "trim|required|min_length[3]|max_length[20]");
    $this->form_validation->set_rules("customer_email", "Customer Email", "trim|required|valid_email|max_length[25]");
    $this->form_validation->set_rules("customer_password", "Customer Password", "trim|required|min_length[6]|max_length[25]");
    $this->form_validation->set_error_delimiters('<p class="alert alert-danger alert-dismissible">', '<button type="button" class="btn-close" data-bs-dismiss="alert"></button></p>');
    if ($this->form_validation->run() === FALSE) {
    $data['customerlist'] = $this->admin_model->GetCustomerLists();
      $data["title"] = "Edit User";
      $this->load->view("layout/header_script", $data);
      $this->load->view("layout/header", $data);
      $this->load->view("edituser_view");
      $this->load->view("layout/footer");
      $this->load->view("layout/footer_script");
    } else {
      $viewid = isset($_POST['customerid']) ? $_POST['customerid'] : '';
      $passkey = $this->config->item('passkey');
      $c_name = $this->input->post("customer_user_name", true);
      $c_email = $this->input->post("customer_email", true);
      $c_password = sha1($passkey . $this->input->post("customer_password", true));
      $c_orgpassword = $this->input->post("customer_password", true);
      $res = $this->admin_model->update_user($c_name, $c_email, $c_password, $viewid, $c_orgpassword);
      if ($res[0] === "success") {
        redirect(base_url("allusers"), "refresh");
      } else {
        $this->session->set_flashdata('enotadded', '<p class="alert alert-danger alert-dismissible">Not Added !<button type="button" class="btn-close" data-bs-dismiss="alert"></button></p>');
        $data["title"] = "Edit Customer";
        $data['customerlist'] = $this->admin_model->GetCustomerLists();

        $this->load->view("layout/header_script", $data);
        $this->load->view("layout/header", $data);
        $this->load->view("edituser_view");
        $this->load->view("layout/footer");
        $this->load->view("layout/footer_script");
        exit(0);
      }
    }
  }



}
<?php

defined('BASEPATH') OR exit('No direct script access allowed');


class Dashboard extends CI_Controller  {

  public function index()
  {
    if ($this->session->userdata("super_in")) {
      $data["title"] = "All Customers";
      $this->load->view("layout/header_script",$data);
      $this->load->view("layout/header",$data);
      $this->load->view("dashboard_view",$data);
      $this->load->view("layout/footer");
      $this->load->view("layout/footer_script");
    } elseif ($this->session->userdata("admin_in")) {
      $data["title"] = "Dashboard";
      $this->load->view("layout/header_script",$data);
      $this->load->view("layout/header",$data);
      $this->load->view("adminhome_view");
      $this->load->view("layout/footer");
      $this->load->view("layout/footer_script");
    } elseif ($this->session->userdata("user_in")) {
      $data["title"] = "Dashboard";
      $this->load->view("layout/header_script",$data);
      $this->load->view("layout/header",$data);
      $this->load->view("userhome_view");
      $this->load->view("layout/footer");
      $this->load->view("layout/footer_script");
    } else {
      $data["title"] = "Login";
      $this->load->view("layout/header_script", $data);
      $this->load->view("login_view");
      $this->load->view("layout/footer_script");
    }
    
  }


















}
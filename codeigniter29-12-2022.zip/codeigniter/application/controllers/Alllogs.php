<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Alllogs extends CI_Controller
{
  function __construct()
  {
    parent::__construct();
    $this->load->model('Superadmin_Model', 'superadmin_model', TRUE);
    $this->load->helper('form');
    $this->load->library('form_validation');
    $this->load->library("user_agent");
  }

  public function index()
  {
    if ($this->session->userdata("super_in")) {
      $data["title"] = "All Logs";
      $data['alllogs'] = $this->superadmin_model->GetLogLists();
      $this->load->view("layout/header_script", $data);
      $this->load->view("layout/header", $data);
      $this->load->view("alllogs_view", $data);
      $this->load->view("layout/footer");
      $this->load->view("layout/footer_script");
    } elseif ($this->session->userdata("admin_in")) {
      $data["title"] = "Dashboard";
      $this->load->view("layout/header_script", $data);
      $this->load->view("layout/header", $data);
      $this->load->view("adminhome_view");
      $this->load->view("layout/footer");
      $this->load->view("layout/footer_script");
    } elseif ($this->session->userdata("user_in")) {
      $data["title"] = "Dashboard";
      $this->load->view("layout/header_script", $data);
      $this->load->view("layout/header", $data);
      $this->load->view("userhome_view");
      $this->load->view("layout/footer");
      $this->load->view("layout/footer_script");
    } else {
      $data["title"] = "Login";
      $this->load->view("layout/header_script", $data);
      $this->load->view("login_view");
      $this->load->view("layout/footer_script");
    }
  }


}

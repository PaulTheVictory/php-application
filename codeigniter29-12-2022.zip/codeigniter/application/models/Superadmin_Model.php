<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');

class Superadmin_Model extends CI_Model
{
  public function __construct()
  {
    parent::__construct();
    $this->load->database();
    $this->load->library('email');
    $this->load->library('Datatables');
  }


  //add customer


  public function add_customer($c_name, $c_email, $c_password, $c_image, $c_date, $c_time, $c_doneby, $c_orgpassword)
  {
    $result = array(0 => "");
    $customer_id = uniqid(true);

    $data = array(
      "customer_id" => $customer_id,
      "customer_name" => $c_name,
      "customer_logo" => $c_image,
      "customer_email" => $c_email,
      "customer_password" => $c_password,
      "org_password" => $c_orgpassword,
      "customer_status" => 1,
      "role" => "customer",
      "created_date" => $c_date,
      "created_time" => $c_time,
      "done_by" => $c_doneby,
    );

    $res = $this->db->insert("customers", $data);

    if ($res) {
      $result = array(0 => "success");
      return $result;
    } else {
      $result = array(0 => "fail");
      return $result;
    }
  }


  //get all customer active details

  public function GetCustomerLists()
  {
    $arr = array();
    $arr['clist'] = '<table id="customer_view" class="display dataTable">';

    $query = $this->db->query('select * from customers order by created_time DESC');
    $row = $query->result_array();
    $arr['customer_list_count'] = count($row);
    if ($row) {
      $arr['clist'] .= '
  <thead>
  <tr>
  <th>S No</th>
  <th>Customer Id</th>
  <th>Name</th>
  <th>Email</th>
  <th>Logo</th>
  <th>Status</th>
  <th>Joining Date</th>
  <th>Action</th>
  </thead>';
      $arr['clist'] .= '<tbody>';
      for ($i = 0; $i < count($row); $i++) {

        $cid = $row[$i]['customer_id'];
        $cname = $row[$i]['customer_name'];
        $cemail = $row[$i]['customer_email'];
        $cstatus = $row[$i]['customer_status'];
        $clogo = $row[$i]['customer_logo'];
        $jdate = $row[$i]['created_date'];

       

        $arr['clist'] .= '
  <tr>
  <td>' . $i . '</td>
  <td>' . $cid . '</td>
  <td>' . $cname . '</td>
  <td>' . $cemail . '</td>
  <td><img src="' . base_url() . '/docs/customerlogo/' . $clogo . '" alt="' . $cname . '" class="c_logo_style" /></td>
  <td>' . ($cstatus==1? '<button class="a_btn status_update" data-uid="' . $cid . '" data-sid="' . $cstatus . '">Active</button>': '<button class="ina_btn status_update" data-uid="' . $cid . '" data-sid="' . $cstatus . '">In Active</button>'). '</td>
  <td>' . $jdate . '</td>
  <td>
  <div class="action_btn">
    
    <button type="button" class="btn btn-sm btn-success edit_customer_new" data-uid="' . $cid . '"><i class="fa fa-edit"></i> </button>
          <button class="btn btn-sm btn-danger delete_customer" type="submit" data-uid="' . $cid . '"><i class="fa fa-trash"></i> </button></div>
      </td></tr>';
      }
    } else {
      $arr['clist'] .= '<tbody><tr><td>No Records Found</td></tr>';
    }
    $arr['clist'] .= '</tbody></table>';
    return $arr;
  }

  //


  public function getsinglecustomerdetails($f_id)
  {

    $this->db->select("*");
    $this->db->from("customers");
    $this->db->where("customer_id", $f_id);
    $this->db->limit(1);
    $query = $this->db->get();
    $res = $query->result();
    if ($res) {
      return $res;
    }
  }



  //get all customer delete details

  public function GetCustomerListsDelete()
  {
    $arr = array();
    $arr['clist'] = '<table id="customer_view" class="display dataTable">';

    $query = $this->db->query('select * from customers where customer_status="0" order by created_time DESC');
    $row = $query->result_array();
    $arr['customer_list_count'] = count($row);
    if ($row) {
      $arr['clist'] .= '
  <thead>
  <tr>
  <th>S No</th>
  <th>Customer Id</th>
  <th>Name</th>
  <th>Email</th>
  <th>Logo</th>
  <th>Joining Date</th>
  <th>Action</th>
  </thead>';
      $arr['clist'] .= '<tbody>';
      for ($i = 0; $i < count($row); $i++) {

        $cid = $row[$i]['customer_id'];
        $cname = $row[$i]['customer_name'];
        $cemail = $row[$i]['customer_email'];
        $clogo = $row[$i]['customer_logo'];
        $jdate = $row[$i]['created_date'];


        $arr['clist'] .= '
  <tr>
  <td>' . $i . '</td>
  <td>' . $cid . '</td>
  <td>' . $cname . '</td>
  <td>' . $cemail . '</td>
  <td><img src="./docs/customerlogo/' . $clogo . '" alt="' . $cname . '" class="c_logo_style" /></td>
  <td>' . $jdate . '</td>
  <td>
  <div class="action_btn">
    <button type="button" class="btn btn-sm btn-success recovery_customer" data-uid="' . $cid . '"><i class="fa fa-undo" aria-hidden="true"></i> Recovery</button>
    
          <button class="btn btn-sm btn-danger delete_customer" type="submit" data-uid="' . $cid . '"><i class="fa fa-trash"></i> Delete Permanently</button></div>
      </td></tr>';
      }
    } else {
      $arr['clist'] .= '<tbody><tr><td>No Records Found</td></tr>';
    }
    $arr['clist'] .= '</tbody></table>';
    return $arr;
  }



  /*Delete Customer*/

  public function DeleteCustomerById($deleteid)
  {
    $result = array(0 => '');
    $query = $this->db->query('update customers set customer_status="0" where customer_id="' . $deleteid . '"');
    if ($query) {
      $result = array(0 => 'success');
      return $result;
    } else {
      $result = array(0 => 'fail');
      return $result;
    }
  }

  /*active*/

  public function UpdateById($deleteid, $sid)
  {
    $a_status= $sid==1?0:1;
    $result = array(0 => '');
    $query = $this->db->query('update customers set customer_status="'. $a_status.'" where customer_id="' . $deleteid . '"');
    if ($query) {
      $result = array(0 => 'success');
      return $result;
    } else {
      $result = array(0 => 'fail');
      return $result;
    }
  }


  /*Delete permanently*/

  public function DeleteById($deleteid)
  {
    $result = array(0 => '');
    $query = $this->db->query('delete from customers where customer_id="' . $deleteid . '"');
    if ($query) {
      $result = array(0 => 'success');
      return $result;
    } else {
      $result = array(0 => 'fail');
      return $result;
    }
  }


  /*Recovery user*/

  public function RecoveryById($recoveryid)
  {
    $result = array(0 => '');
    $query = $this->db->query('update customers set customer_status="1" where customer_id="' . $recoveryid . '"');
    if ($query) {
      $result = array(0 => 'success');
      return $result;
    } else {
      $result = array(0 => 'fail');
      return $result;
    }
  }


  /*View Single User Profile*/

  public function ViewSingleUserById($viewid)
  {
    $arr = array();
    $arr['singlecustomer'] = array();
    $query = $this->db->query('select * from customers where customer_id="' . $viewid . '"');
    $row = $query->result_array();


    if ($query->num_rows() > 0) {
      return $row[0];
    } else {
      return $arr;
    }
  }

  //update customer


  public function update_customer($c_name, $c_email, $c_password, $c_image, $viewid, $c_orgpassword)
  {
    $result = array(0 => "");



    $res = $this->db->query('update customers set customer_name="' . $c_name . '",customer_logo="' . $c_image . '",customer_email="' . $c_email . '",customer_password="' . $c_password . '",org_password="' . $c_orgpassword . '" where customer_id="' . $viewid . '"');
    if ($res) {
      $result = array(0 => "success");
      return $result;
    } else {
      $result = array(0 => "fail");
      return $result;
    }
  }

  //update customer
  public function updatenoimage_customer($c_name, $c_email, $c_password, $viewid, $c_orgpassword)
  {
    $result = array(0 => "");



    $res = $this->db->query('update customers set customer_name="' . $c_name . '",customer_email="' . $c_email . '",customer_password="' . $c_password . '",org_password="' . $c_orgpassword . '" where customer_id="' . $viewid . '"');
    if ($res) {
      $result = array(0 => "success");
      return $result;
    } else {
      $result = array(0 => "fail");
      return $result;
    }
  }


  // all logs

  //get all customer active details

  public function GetLogLists()
  {
    $arr = array();
    $arr['llist'] = '<table id="customer_view" class="display dataTable">';

    $query = $this->db->query('select * from ap_logs order by outtime DESC');
    $row = $query->result_array();
    $arr['customer_list_count'] = count($row);
    if ($row) {
      $arr['llist'] .= '
  <thead>
  <tr>
  <th>S No</th>
  <th>Login Id</th>
  <th>Name</th>
  <th>Role</th>
  <th>Intime</th>
  <th>Outtime</th>

  </thead>';
      $arr['llist'] .= '<tbody>';
      for ($i = 0; $i < count($row); $i++) {

        $user_id = $row[$i]['user_id'];
        $name = $row[$i]['name'];
        $role = $row[$i]['role'];
        $intime = $row[$i]['intime'];
        $outtime = $row[$i]['outtime'];
       



        $arr['llist'] .= '
  <tr>
  <td>' . $i . '</td>
  <td>' . $user_id . '</td>
  <td>' . $name . '</td>
  <td>' . $role . '</td>
  <td>' . $intime . '</td>
  <td>' . $outtime . '</td>
  
  </tr>';
      }
    } else {
      $arr['llist'] .= '<tbody><tr><td>No Records Found</td></tr>';
    }
    $arr['llist'] .= '</tbody></table>';
    return $arr;
  }























}

<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login_Model extends CI_Model {


  public function common_admin_login($username,$password)
  {
    $this->db->select("admin_id,user_name,pass_word,role");
    $this->db->from("admin");
    $this->db->where("user_name",$username);
    $this->db->where("pass_word",$password);
    $this->db->limit(1);
  
    $query = $this->db->get();
    //verify super admin
    if($query->num_rows()===1) {
      return $query->result();
    } else {
      //verify admin
      $this->db->select("customer_id,customer_email,customer_password,role");
    $this->db->from("customers");
    $this->db->where("customer_email",$username);
    $this->db->where("customer_password",$password);
    $this->db->limit(1);
  
    $query = $this->db->get();
  
    if($query->num_rows()===1) {
      return $query->result();
    } else {
      return false;
    }
    }
  }


  public function super_admin_login($username,$password)
  {
    $passkey = $this->config->item('passkey');
    $this->db->select("admin_id,user_name,pass_word,role");
    $this->db->from("admin");
    $this->db->where("user_name",$username);
    $this->db->where("pass_word",$password);
    $this->db->where("role", "superadmin");
    $this->db->limit(1);
  
    $query = $this->db->get();
  
    if($query->num_rows()===1) {
      return $query->result();
    } else {
      return false;
    }
  }



  public function admin_login($username,$password)
  {
    $this->db->select("customer_id,customer_email,customer_password,role");
    $this->db->from("customers");
    $this->db->where("customer_email",$username);
    $this->db->where("customer_password",$password);
    $this->db->where("customer_status", 1);
    $this->db->where("role", "customer");
    $this->db->limit(1);
  
    $query = $this->db->get();
  
    if($query->num_rows()===1) {
      return $query->result();
    } else {
      return false;
    }
  }



  public function user_login($username, $password)
  {
    $this->db->select("customer_user_id,customer_user_name,customer_id,customer_email,customer_password,role");
    $this->db->from("customer_login");
    $this->db->where("customer_email", $username);
    $this->db->where("customer_password", $password);
    $this->db->where("customer_login_status", 1);
    $this->db->where("role", "user");
    $this->db->limit(1);

    $query = $this->db->get();

    if ($query->num_rows() === 1) {
      return $query->result();
    } else {
      return false;
    }
  }





  public function CreateSession($s_user_id,$s_username,$s_role,$s_intime,$s_browser,$s_platform,$s_ip) {

    $sess_id = uniqid();
    $this->session->set_userdata("session_id",$sess_id);
  
    $result = $this->db->query('insert into ap_logs (`session_id`,`user_id`,`ipaddress`,`browser`,`platform`,`name`,`role`,`intime`,`outtime`,`status`) values ("'.$sess_id.'","'.$s_user_id.'","'.$s_ip.'","'.$s_browser.'","'.$s_platform.'","'.$s_username.'","'.$s_role.'","'.$s_intime.'","","o")');
  
    if($result) {
      return true;
    } else {
      return false;
    }
  
  
  }

  public function EndSession($s_id,$date) {

    $query = $this->db->query('update ap_logs set outtime="'.$date.'", status="c" where session_id="'.$s_id.'"');
  
    if($query) {
      return true;
    } else {
      return false;
    }
  
  }










}
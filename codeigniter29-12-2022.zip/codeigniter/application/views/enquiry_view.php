<?php
defined('BASEPATH') or exit('No direct script access allowed');
?>
<div class="enqiry_top_view">
  <button class="btn btn-primary add_project_new btn-sm"><i class="fa fa-plus" aria-hidden="true"></i> Add Project</button>
  <button class="btn btn-success add_enquiry_new btn-sm"><i class="fa fa-plus" aria-hidden="true"></i> Add Enquiry</button>
</div>
<div class="enqiry_view">
  <?php echo $enquirylist['elist']; ?>
</div>

<div class="modal fade" id="projectmodel" tabindex="-1" aria-labelledby="projectmodeltitle" aria-hidden="true">
  <div class="modal-dialog modal-md">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="projectmodeltitle">Create Project</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <?php if ($this->session->flashdata('validation')) { ?>
          <?php echo $this->session->flashdata('validation'); ?>
        <?php } elseif ($this->session->flashdata('notadded')) { ?>
          <?php echo $this->session->flashdata('notadded'); ?>
        <?php } ?>
        <?php echo form_open('enquiry/addproject', 'method="post" accept-charset="utf-8" name="project" id="project"'); ?>
        <input type="text" name="project_name" id="project_name" placeholder="Project Name" />
        <button type="submit" class="btn btn-primary btn-md">Save Project</button>
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <!-- <button type="button" class="btn btn-primary">Save project</button> -->
      </div>
    </div>
  </div>
</div>

<div class="modal fade" id="enquirymodel" tabindex="-1" aria-labelledby="enquirymodeltitle" aria-hidden="true">
  <div class="modal-dialog modal-md">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="enquirymodeltitle">Create Enquiry</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <?php echo validation_errors(); ?>
        <?php echo form_open('enquiry/addenquiry', 'method="post" accept-charset="utf-8" name="enquiry" id="enquiry"'); ?>
        <input type="text" name="enq_name" id="enq_name" placeholder="Enquiry Name" />
        <input type="text" name="enq_contact_number" id="enq_contact_number" placeholder="Phone Number" />
        <input type="text" name="enq_date" id="datetimepicker" placeholder="Enquiry Date" />
        <select name="project_id" id="project_id">
          <option value="" selected hidden>Select Project</option>
          <?php
          foreach ($plist as $row) {
          ?>
            <option value="<?php echo $row->project_id; ?>|<?php echo $row->project_name; ?>"><?php echo $row->project_name; ?></option>
          <?php } ?>
        </select>
        <input type="text" name="enq_location" id="enq_location" placeholder="Enquiry location" />
        <textarea name="enq_msg" id="enq_msg" placeholder="Enquiry Message"></textarea>
        <button type="submit" class="btn btn-primary btn-md">Save Enquiry</button>
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <!-- <button type="button" class="btn btn-primary">Save project</button> -->
      </div>
    </div>
  </div>
</div>
<script>
  $(document).ready(function() {
    $.datetimepicker.setLocale('en');
    $('#datetimepicker').datetimepicker();

    //

    $(".alert").delay(4000).slideUp(200, function() {
      $(this).alert('close');
    });

    //

    $('#customer_view').DataTable({
      'responsive': true,
      "processing": true,
      "bInfo": false,
      columnDefs: [{
        width: '20%'
      }],
      fixedColumns: true,
      "fnRowCallback": function(nRow, aData, iDisplayIndex) {
        $("td:first", nRow).html(iDisplayIndex + 1);
        return nRow;
      },
    });

  });


  $(document).on("click", ".delete_customer", function(d) {
    d.preventDefault();
    var deleteid = $(this).data('uid');
    swal({
        title: "Are you sure to delete?",
        text: "Not able to retrieve this file.",
        type: "warning",
        showCancelButton: true,
        confirmButtonColor: "#DD6B55",
        confirmButtonText: "Delete",
        cancelButtonText: "Cancel",
        closeOnConfirm: false,
        closeOnCancel: false
      },
      function(isConfirm) {
        if (isConfirm) {
          $.ajax({
            url: 'enquiry/DeleteEnquiry',
            type: 'POST',
            data: {
              'deleteid': deleteid
            },
            success: function(data) {
              var dlt = $.parseJSON(data);
              if (dlt[0] == 'success') {
                swal("Deleted Successfully", "You clicked the button!", "success");
                setTimeout(function() {
                  location.reload();
                }, 1500);
              } else if (dlt[0] == 'fail') {
                swal("Could Not Deleted", "Something went Wrong!", "error");
              }
            }
          });
        } else {
          swal("Cancelled", "Your file is safe :)", "error");
        }
      });

  });

  $(document).on("click", ".add_project_new", function(d) {
    d.preventDefault();
    $('#projectmodel').modal('show');
  });

  $(document).on("click", ".add_enquiry_new", function(d) {
    d.preventDefault();
    $('#enquirymodel').modal('show');
  });
</script>

<?php if ($this->session->flashdata('validation')) { ?>


  <script>
    addEventListener("load", (event) => {
      $('#projectmodel').modal('show');
    });
  </script>

<?php } ?>

<?php if ($this->session->flashdata('notadded')) { ?>


  <script>
    addEventListener("load", (event) => {
      $('#projectmodel').modal('show');
    });
  </script>

<?php } ?>


<?php if ($this->session->flashdata('envalid')) { ?>


  <script>
    addEventListener("load", (event) => {
      $('#enquirymodel').modal('show');
    });
  </script>

<?php } ?>

<?php if ($this->session->flashdata('ennotadded')) { ?>


  <script>
    addEventListener("load", (event) => {
      $('#projectmodel').modal('show');
    });
  </script>

<?php } ?>
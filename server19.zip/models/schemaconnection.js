const mongoose = require('mongoose');

// importing schemas to create model
const importedadminSchema = require('../schemas/admin');
const importedadminlogsSchema = require("../schemas/adminlogs");





//Creating schema
const AdminSchema = mongoose.Schema(importedadminSchema, {timestamps: true,versionKey: false,});
const AdminLogsSchema = mongoose.Schema(importedadminlogsSchema, {timestamps: true,versionKey: false,});





//Creating models
const AdminModel = mongoose.model("admins", AdminSchema);
const AdminLoginModel = mongoose.model("adminlogs", AdminLogsSchema);





module.exports = {
  admins: AdminModel,
  adminlogs: AdminLoginModel,
};

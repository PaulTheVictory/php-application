
function SuccessToken(res,status, success, message, result,token,cookie) {
  res.statusMessage = message;
  res
    .status(status)
    .cookie('token',token,cookie)
    .json({
      status: status,
      success: success,
      message: message,
      result: result,
      token: token,
    })
    .end();
}
function Success(res, status, success, message, result, token) {
  res.statusMessage = message;
  res
    .status(status)
    .json({
      status: status,
      success: success,
      message: message,
      result: result,
      token: token,
    })
    .end();
}
function Error(res,status, success, message, error) {
  res.statusMessage = message;
  res
    .status(status)
    .json({
      status: status,
      success: success,
      message: message,
      error: error,
    })
    .end();
}


module.exports = {
  SuccessToken: SuccessToken,
  Success: Success,
  Error: Error,
};
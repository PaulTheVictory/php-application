const db = require('../models/schemaconnection');
const jwt = require("jsonwebtoken");
const Response = require('../utils/response');

async function verifyAdmin(req, res, next) {
  const tokenHeader = req.headers["authorization"];
  if (!tokenHeader) {
    return Response.Error(res, 400, false, "Token Missing!");
  }
  const verifyToken = jwt.verify(tokenHeader, process.env.JWT_SECRET_TOKEN);
  if (!verifyToken) {
    return Response.Error(res, 400, false, "Invalid Token!");
  }
  const find = await db.admins.findById(verifyToken._id);
  if (!find) {
    return Response.Error(res, 400, false, "Invalid Token!");
  } else {
    req.admin = find;
    next();
  }
  
}






module.exports = {
  verifyAdmin:verifyAdmin,
}
var ADMINLOGS = {
  name: String,
  email: String,
  phone: Number,
  role: String,
  intime: {
    type: Date,
    default: Date.now(),
  },
  outtime: {
    type: Date,
    default: "",
  },
  status: {
    type: Number,
    default: 1,
  },
};

module.exports = ADMINLOGS;
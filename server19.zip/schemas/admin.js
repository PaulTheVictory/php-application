var ADMINSHEMA = {
  name: {
    type: String,
    required: [true, "Please your Name"],
    minlength: [3, "Please enter a name atleast 3 characters"],
    maxlength: [40, "Name can not big than 40 characters"],
  },
  email: {
    type: String,
    required: [true, "Please enter your email"],
    unique: true,
  },
  phone: {
    type: String,
    unique: true,
    required: [true, "Please enter your phone number"],
    minlength: [10, "Please enter valid phone number"],
    maxlength: [20, "Please enter valid phone number"],
  },
  password: {
    type: String,
    required: [true, "Please enter your password!"],
    minlength: [6, "Password should be greater than 6 characters"],
    select: false,
  },
  role: {
    type: String,
    required: true,
    default: "admin",
  },
  status: {
    type: String,
    required: true,
    default: 1,
  },
  plan: {
    type: String,
    required: true,
    minlength: 4,
  },
  joindate: {
    type: Date,
    default: Date.now(),
  },
};

module.exports = ADMINSHEMA;

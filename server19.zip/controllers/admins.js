const express = require("express");
const Router = express.Router();
const DB = require("../models/db.js");
const catchasyncerrors = require("../utils/catchasyncerrors");
const jwt = require("jsonwebtoken");
const bcrypt = require("bcrypt");
const Reponse = require('../utils/response');
const db = require('../models/schemaconnection');
const token = require('../utils/verifytoken');

const project = {
  createdAt: 0,
  updatedAt: 0,
  role: 0,
  plan: 0,
  status:0,
};


//Register New
Router.post("/register", catchasyncerrors(function (req, res) {
    let name = req.body.name;
    let email = req.body.email;
    let phone = req.body.phone;
    let password = bcrypt.hashSync(process.env.JWT_SECRET_KEY+req.body.password,bcrypt.genSaltSync(8),null);
    let plan = req.body.plan;
    const formData = {
      name: name,
      email: email,
      phone: phone,
      password: password,
      plan: plan,
    };
  
    DB.GetOneDocument("admins",{ phone: formData.phone,email:formData.email },{},{},function (err, result) {
        if (!result) {
          DB.InsertDocument("admins", formData, function (err, result) {
            if (err) {
              return Reponse.Error(res,400,false,"Register Failed",err.name?err.name:"Validation Failed")
            } else {
              const logsGenerate = {
                name: result?.name,
                email: result?.email,
                phone: result?.phone,
                role: result?.role,
              }; 
              DB.InsertDocument("adminlogs", logsGenerate, function (err, session) {
                if (session) {
                  const tokenGenerate = {
                    name: result?.name,
                    email: result?.email,
                    phone: result?.phone,
                    _id: result?._id,
                    role: result?.role,
                    session_id: session?._id,
                  };
                  const token = jwt.sign(tokenGenerate, process.env.JWT_SECRET_TOKEN, { expiresIn: Date.now() + 1 * 24 * 60 * 60 * 1000});
                  const cookie = {
                    expires: new Date(
                    Date.now() + 1 * 24 * 60 * 60 * 1000),
                    httpOnly:true,
                  };
                  return Reponse.SuccessToken(res,201, true,"Register Successfully", tokenGenerate,token,cookie);
                } else {
                  return Reponse.Error(res, 400, false, "Please try again later!");
                }
              });
              
            }
          });
        } else {
          return Reponse.Error(res, 409, false, "User Already Exsits");
        }
      }
    );
  })
);

//Login
Router.post('/login', catchasyncerrors(async function (req, res) {
  
  let username = req.body.username;
  let password = process.env.JWT_SECRET_KEY + req.body.password;
  const formData = {
    phone: username,
    role: "admin",
    status: 1,
  };
  if (!username || !password) {
    return Reponse.Error(res, 400, false, "Username & Password Required");
  }

  const find = await db.admins.findOne(formData).select("+password");
  const passwrordcompare = bcrypt.compareSync(password, find?.password);
  
  if (!find) {
    return Reponse.Error(res, 400, false, "User not Found", find);
  } else {
    if (!passwrordcompare) {
      return Reponse.Error(res, 400, true, "Invalid Password");
    } else {
      const logsGenerate = {
        name: find?.name,
        email: find?.email,
        phone: find?.phone,
        role: find?.role,
      }; 
      DB.InsertDocument("adminlogs", logsGenerate, function (err, session) {
        if (session) {
          const tokenGenerate = {
            name: find?.name,
            email: find?.email,
            phone: find?.phone,
            _id: find?._id,
            role: find?.role,
            session_id: session?._id,
          };
          const token = jwt.sign(tokenGenerate, process.env.JWT_SECRET_TOKEN, { expiresIn: Date.now() + 1 * 24 * 60 * 60 * 1000});
          const cookie = {
            expires: new Date(
              Date.now() + 1 * 24 * 60 * 60 * 1000),
                httpOnly:true,
              };
            return Reponse.SuccessToken(res,200, true,"Login Successfully", tokenGenerate,token,cookie);
          } else {
            return Reponse.Error(res, 400, false, "Please try again later!");
          }
    });
    }
    
 }
}));


//Logout
Router.put("/logout", catchasyncerrors(async function (req, res) {
  const session_id = req.body.session_id;
  const formData = {
    status: 0,
    outtime:Date.now(),
  }
  const find = await db.adminlogs.findOne({ _id: session_id });
  if (session_id) {
    if (find?.status == 0) {
      return Reponse.Error(res, 400, false, "Session ID Already Logout");
    } else {
    DB.FindUpdateDocument("adminlogs", { _id: session_id }, formData, function (err, result) {
      if (result) {
        return Reponse.Success(res, 200, true, "Logout Successfully");
      } else {
        return Reponse.Error(res, 400, false, "Invalid Session ID");
      }
    });
      }
  } else {
    return Reponse.Error(res, 400, false, "Session ID Missing");
  }
}));
 
//Change Password
Router.put('/changepassword', token.verifyAdmin, catchasyncerrors(async function (req, res) {
  const oldpassword = process.env.JWT_SECRET_KEY + req.body.oldpassword;
  const newpassword = bcrypt.hashSync(process.env.JWT_SECRET_KEY+req.body.newpassword,bcrypt.genSaltSync(8),null);
  if (!oldpassword || !newpassword) {
    return Reponse.Error(res, 400, false, "Password Field Required");
  }
  const find = await db.admins.findOne(req.admin?._id).select("+password");
  const passwrordcompare = bcrypt.compareSync(oldpassword, find?.password);
  if (passwrordcompare) {
    DB.FindUpdateDocument('admins', { _id: req.admin?._id }, { password: newpassword }, function (err, result) {
      if (result) {
        return Reponse.Success(res, 200, true, "Password Update Successfully");
      } else {
        return Reponse.Error(res, 400, false, "Password Update Failed");
      }
    });
  } else {
     return Reponse.Error(res, 400, false, "Invalid Old Password");
  }
   
}));

//Get single details by id
Router.get('/:id', token.verifyAdmin, catchasyncerrors(async function (req, res) {
  DB.GetDocument("admins", { _id: req.params.id }, project, {}, function (err, result) {
    if (result) {
      return Reponse.Success(res, 200, true, "Get Details Successfully",result);
    } else {
      return Reponse.Error(res, 400, false, "User not Found", err);
    }
  })
}));



module.exports = Router;

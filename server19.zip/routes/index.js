const SiteBaseUrl = "/api/v1/";

module.exports = function (app) {
  app.use(SiteBaseUrl + "admin", require("../controllers/admins"));
};



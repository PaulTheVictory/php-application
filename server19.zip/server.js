const express = require('express');
const bodyparser = require('body-parser');
const cookieParser = require("cookie-parser");
const cors = require('cors');
const app = express();
const dbconfig = require('./config/db');
const errorhandler = require('./utils/error')
const path = require('path');
global.healperfunctions = require('./utils/helperfunctions');
app.use(cors());
app.use(express.json());
app.use(cookieParser());



// parse application/x-www-form-urlencoded
app.use(bodyparser.json({ limit: "50mb" }));
app.use(bodyparser.urlencoded({ extended: false }));


// parse application/json
app.use(bodyparser.json());

//config
require("dotenv").config();


// connecting to the database
dbconfig();
app.use("/public", express.static(path.join(__dirname, "public")));
app.use("/uploads", express.static(path.join(__dirname, "uploads")));
app.use(express.static(path.join(__dirname, "build")));
app.use(bodyparser.json());

const arr = [];
app.post("/", (req, res) => {
  arr.push(req.body);
  res.send(arr);
});

//routing files
require("./routes")(app);

//create server
const server = app.listen(process.env.PORT, () => {
  console.log(`Server is working on http://localhost:${process.env.PORT}`);
});

// it's for errorHandeling
app.use(errorhandler);

// Unhandled promise rejection
process.on("unhandledRejection", (err) =>{
    console.log(`Shutting down server for ${err.message}`);
    console.log(`Shutting down the server due to Unhandled promise rejection`);
    server.close(() =>{
        process.exit(1);
    });
});

// Handling uncaught Exception
process.on("uncaughtException",(err) =>{
    console.log(`Error: ${err.message}`);
    console.log(`Shutting down the server for Handling uncaught Exception`);
});

app.use((req, res, next) => {
  // Error goes via `next()` method
  setImmediate(() => {
    next(new Error("Unauthorized Method"));
  });
});
app.use(function (err, req, res, next) {
  console.error(err.message);
  if (!err.statusCode) err.statusCode = 500;
  res.status(err.statusCode).json({
    status:err.statusCode,
    success:false,
    message: err.message,
  });
});



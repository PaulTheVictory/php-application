const ErrorHandler = require("../Utils/ErrorHandler");
const catchAsyncErrors = require("./catchAsyncErrors");
const jwt = require("jsonwebtoken");
const User = require("../Model/UserModel");
const Admin = require("../Model/AdminModel");


exports.isAuthenticatedCompany = catchAsyncErrors(async (req, res, next) => {
  const company = req.headers.company;
  const authCompany = await Admin.findOne({ company });

  if (!authCompany) {
    return next(new ErrorHandler("Unauthorized Request", 401));
  }
  next();
})




exports.isAuthenticatedAdmin = catchAsyncErrors(async (req, res, next) => {
  const authHeader = req.headers.token;
  const token = authHeader.split(" ")[1];
  if (!token) {
    return next(new ErrorHandler("Please Login for access this resource", 401));
  }

  const decodedData = jwt.verify(token, process.env.JWT_SECRET_KEY);

  req.user = await Admin.findById(decodedData.id);

  next();
});

exports.isAuthenticatedUser = catchAsyncErrors(async (req, res, next) => {
  const authHeader = req.headers.token;
  const token = authHeader.split(" ")[1];
  if (!token) {
    return next(new ErrorHandler("Please Login for access this resource", 401));
  }

  const decodedData = jwt.verify(token, process.env.JWT_SECRET_KEY);

  req.user = await User.findById(decodedData.id);

  next();
});

// Admin Roles
exports.authorizeRoles = (...roles) => {
  return (req, res, next) => {
    if (!roles.includes(req.user.role)) {
      return next(
        new ErrorHandler(`${req.user.role} can not access this resources`)
      );
  
    }
    next();
  };
};

const mongoose = require("mongoose");

const productSchema = new mongoose.Schema(
  {
    title: {
      type: String,
      required: [true, "Please enter product name"],
      trim: true,
      unique: true,
      maxLength: [75, "Product name not exceed than 70 characters"],
    },
    slug: {
      type: String,
      required: [true, "Slug error"],
      trim: true,
      unique: true,
      maxLength: [100, "Slug error"],
    },
    description: {
      type: String,
      maxlength: [4000, "Description is can not exceed than 4000 characters"],
    },
    producttype: {
      type: String,
      required: [true, "Please choose product type"],
      default: "Simple Product",
    },
    mrp: {
      type: Number,
      maxLength: [8, "Price can not exceed than 8 characters"],
      default: 0,
    },
    sp: {
      type: Number,
      maxLength: [8, "Price can not exceed than 8 characters"],
      default: 0,
    },
    sku: {
      type: String,
      unique: [true, "Please enter unique SKU id"],
      maxlength: [20, "SKU can not exceed than 20 characters"],
      required: [true, "SKU id is required"],
    },
    specification: [
      {
        sname: {
          type: String,
        },
        svalue: {
          type: String,
        },
      },
    ],
    highlights: [
      {
        hname: {
          type: String,
        },
        hvalue: {
          type: String,
        },
      },
    ],
    managestock: {
      type: String,
      default: "instock",
    },
    stockquantity: {
      type: Number,
      maxlength: [8, "Stock can not exceed than 8 characters"],
      default: 0,
    },
    soldindividually: {
      type: String,
      default: false,
    },
    weighttype: {
      type: String,
      default: "kg",
    },
    weightvalue: {
      type: Number,
      default: 0,
    },
    dimensionstype: {
      type: String,
      default: "cm",
    },
    dimensionslength: {
      type: String,
      default: 0,
    },
    dimensionswidth: {
      type: String,
      default: 0,
    },
    dimensionsheight: {
      type: String,
      default: 0,
    },
    shippingclass: {
      type: String,
      default: null,
    },
    brandname: {
      type: String,
      default: null,
    },
    model: {
      type: String,
      default: null,
    },
    texpersentage: {
      type: String,
      default: null,
    },
    hsncode: {
      type: String,
      default: null,
    },
    deliverydate: {
      type: String,
      default: 7,
    },
    purchasenote: {
      type: String,
      maxlength: [550, "Purchase note can not exceed than 550 characters"],
      default: null,
    },
    company: {
      type: String,
      required: [true, "Id Verification failed!"],
    },
    addedby: {
      type: String,
      required: [true, "Login verification failed!"],
      default: null,
    },
    updatedby: {
      type: String,
      default: null,
    },
    visible: {
      type: Boolean,
      default: true,
    },
    publish: {
      type: Boolean,
      default: true,
    },
    ratings: {
      type: Number,
      default: 0,
    },
    category: [
      {
        categoryid: {
          type: String,
        },
        categoryname: {
          type: String,
        },
        categoryimage: {
          type: String,
        },
        categoryurl: {
          type: String,
        },
      },
    ],
    numofreviews: {
      type: Number,
      default: 0,
    },
    images: [
      {
        url: {
          type: String,
        },
      },
    ],
  },
  {
    timestamps: true,
  }
);

module.exports = mongoose.model("Products", productSchema);

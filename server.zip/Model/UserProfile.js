const mongoose = require("mongoose");


const userProfileSchema = new mongoose.Schema(
  {
    uname: {
      type: String,
    },
    uemail: {
      type: String,
    },
    uphone: {
      type: String,
    },
    udob: {
      type: String,
      default: null,
    },
    ugender: {
      type: String,
      default: null,
    },
    userid: {
      type: String,
    },
    company: {
      type: String,
    },
    role: {
      type: String,
      default: "user",
    },
    uprofileimage: {
      url: {
        type: String,
        default: null,
      },
    },
    unotification: {
      type: String,
      default: "no",
    },
  },
  {
    timestamps: true,
  }
);

module.exports = mongoose.model("UserProfile",userProfileSchema)
const mongoose = require("mongoose");

const categorySchema = new mongoose.Schema(
  {
    categoryname: {
      type: String,
      required: [true, "Please enter category name"],
      trim: true,
      unique: true,
      maxLength: [35, "Category name not exceed than 35 characters"],
    },
    categoryslug: {
      type: String,
      required: [true, "Category Slug error"],
      trim: true,
      unique: true,
      maxLength: [35, "Category Slug error"],
    },
    parentcategory: {
      type: String,
      default: null,
    },
    categorydescription: {
      type: String,
      maxLength: [255, "Category description not exceed than 255 characters"],
    },
    type: {
      type: String,
      default: "product",
    },
    company: {
      type: String,
      required: [true, "Id Verification failed!"],
    },
    addedby: {
      type: String,
      required: [true, "Login verification failed!"],
      default: null,
    },
    updatedby: {
      type: String,
      default: null,
    },
    visible: {
      type: Boolean,
      default: true,
    },
    publish: {
      type: Boolean,
      default: true,
    },
    categoryimage: [
      {
        url: {
          type: String,
          default: null,
        },
      },
    ],
  },
  {
    timestamps: true,
  }
);

module.exports = mongoose.model("Category", categorySchema);
const mongoose = require("mongoose");
const validator = require("validator");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");

const adminSchema = new mongoose.Schema({
  name: {
    type: String,
    required: [true, "Please your Name"],
    minlength: [3, "Please enter a name atleast 3 characters"],
    maxlength: [15, "Name can not big than 15 characters"],
  },
  email: {
    type: String,
    required: [true, "Please enter your email"],
    validate: [validator.isEmail, "Please enter a valid email"],
    unique: true,
  },
  phone: {
    type: String,
    required: [true, "Please enter your phone number"],
    minlength: [10, "Please enter valid phone number"],
    maxlength: [10, "Please enter valid phone number"],
  },
  password: {
    type: String,
    required: [true, "Please enter your password!"],
    minlength: [6, "Password should be greater than 6 characters"],
    select: false,
  },
  role: {
    type: String,
    required: true,
    default: "user",
  },
  status: {
    type: String,
    required: true,
    default: "active",
  },
  company: {
    type: String,
    required: true,
    minlength: 7,
  },
  createdAt: {
    type: Date,
    default: Date.now(),
  },
});

//Hash Password

adminSchema.pre("save", async function (next) {
  if (!this.isModified("password")) {
    next();
  }
  this.password = await bcrypt.hash(this.password, 10);
});

//jwt Token

adminSchema.methods.getJwtToken = function () {
  return jwt.sign({ id: this._id }, process.env.JWT_SECRET_KEY, {
    expiresIn: Date.now() + 1 * 24 * 60 * 60 * 1000,
  });
};

// compare password
adminSchema.methods.comparePassword = async function (enteredPassword) {
  return await bcrypt.compare(enteredPassword, this.password);
};

module.exports = mongoose.model("Admin", adminSchema);

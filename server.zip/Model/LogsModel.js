const mongoose = require("mongoose");

const logsSchema = new mongoose.Schema(
  {
    sessionid: {
      type: String,
      required: true,
      unique: true,
    },
    userid: {
      type: String,
      required: true,
    },
    role: {
      type: String,
      required: true,
    },
    lname: {
      type: String,
      required: true,
    },
    lemail: {
      type: String,
      required: true,
    },
    lphone: {
      type: String,
      required: true,
    },
    lcompany: {
      type: String,
      required: true,
    },
    intime: {
      type: Date,
      default: Date.now,
    },
    outtime: {
      type: Date,
      default: null,
    },
  },
  {
    timestamps: true,
  }
);

module.exports = mongoose.model("LoginLogs", logsSchema);
const express = require("express");
const router = express.Router();
const {
  createUser,
  loginUser,
  loginAdmin,
  logoutUser,
  getAllUsers,
} = require("../Controller/UserController");
const {
  isAuthenticatedUser,
  authorizeRoles,
  isAuthenticatedAdmin,
  isAuthenticatedCompany,
} = require("../MiddleWare/auth");


//Frontend API
router.route("/register").post(createUser);
router.route("/login").post(loginUser);
router
  .route("/logout")
  .put(isAuthenticatedUser, isAuthenticatedCompany, logoutUser);


//Admin API
router.route("/admin/login").post(isAuthenticatedCompany,loginAdmin);
router
  .route("/admin/users")
  .get(isAuthenticatedAdmin,isAuthenticatedCompany, authorizeRoles("admin"), getAllUsers);

module.exports = router;

const express = require("express");
const router = express.Router();
const { addNewCategory } = require("../Controller/CategoryController")
const {
  isAuthenticatedUser,
  authorizeRoles,
  isAuthenticatedAdmin,
  isAuthenticatedCompany,
} = require("../MiddleWare/auth");

//Admin Api



router
  .route("/admin/category/add")
  .post(
    isAuthenticatedAdmin,
    isAuthenticatedCompany,
    authorizeRoles("admin"),
    addNewCategory
  );


module.exports = router;
const mongoose = require("mongoose");

const connectDatabase = () => {
  mongoose.connect(process.env.DATABASE_ACCESS, {
    useNewUrlParser: true,
    useUnifiedTopology:true,
  }).then((res) => {
    console.log("Mongoose is connected with server"+res.connection.host)
  })
};

module.exports = connectDatabase;
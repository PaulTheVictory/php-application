const User = require("../Model/UserModel");
const Admin = require("../Model/AdminModel");
const LogsModel = require("../Model/LogsModel")
const UserProfile = require("../Model/UserProfile")
const ErrorHandler = require("../Utils/ErrorHandler");
const catchAsyncErrors = require("../MiddleWare/catchAsyncErrors");
const sendToken = require("../Utils/jwtToken");


//Register User

exports.createUser = catchAsyncErrors(async (req, res, next) => {
  try {
    const { name, email, phone, password, company } = req.body;
    let user = await User.findOne({ email })
    
    if (user) {
      return res
        .status(400)
        .json({ success: false, message: "User already exists" });
    }
    user = await User.create({
      name,
      email,
      phone,
      password,
      company,
    });
    const result = await User.findOne({ email }).select([
      "email",
      "role",
      "name",
      "status",
      "phone",
      "company",
    ]);

    const userid = result?._id;
    const role = result?.role;
    const uname = result?.name;
    const uphone = result?.phone;
    const uemail = result?.email;

    const profileAdd = await UserProfile.create({
      uname,
      uemail,
      uphone,
      company,
      role,
      userid,
    });

    if (profileAdd) {
      sendToken(result, 201, res);
    } else {
      return res
        .status(400)
        .json({ success: false, message: "Please try again later!" });
    }
  }
  catch (error) {
    res.status(500).json({
      success: false,
      message:error.message,
    })
  }
});

//Login User

exports.loginUser = catchAsyncErrors(async (req, res, next) => {
  const { email, company, password } = req.body;
 
  if (!email || !password) {
    return next(new ErrorHandler("Please enter the email & password", 400));
  }

  const user = await User.findOne({ email }).select("+password").select("company").select("role");

  if (user.company !== company) {
    return next(
      new ErrorHandler("Invalid broswer request", 401)
    );
  }

  if (user.role === "admin") {
    return next(new ErrorHandler("Your role con't access this resources", 401));
  }

  const result = await User.findOne({ email }).select([
    "email",
    "role",
    "name",
    "status",
    "phone",
    "company",
  ]);

  if (!user) {
    return next(
      new ErrorHandler("User is not find with this email & password", 401)
    );
  }

  const isPasswordMatch = await user.comparePassword(password);

  if (!isPasswordMatch) {
   return next(
     new ErrorHandler("User is not find with this email & password", 401)
   );
  }

sendToken(result, 201, res);


});


//Login Admin

exports.loginAdmin = catchAsyncErrors(async (req, res, next) => {
  const { email, company, password } = req.body;
 
  if (!email || !password) {
    return next(new ErrorHandler("Please enter the email & password", 400));
  }

  const user = await Admin.findOne({ email })
    .select("+password")
    .select("+company")
    .select("+role");

  if (user.company !== company) {
    return next(
      new ErrorHandler("Invalid broswer request", 401)
    );
  }

  if (user.role === "user") {
    return next(new ErrorHandler("Your role con't access this resources", 401));
  }

  class GUID {
    Generate() {
      const hex = "0123456789ABCDEF";
      const model = "xxxxxxxxxxxxxxxxxxxxxxxx";
      var str = "";
      for (var i = 0; i < model.length; i++) {
        var rnd = Math.floor(Math.random() * hex.length);
        str += model[i] == "x" ? hex[rnd] : model[i];
      }
      return str.toLowerCase();
    }
  }

  const sessionid = new GUID().Generate();
  const result = await Admin.findOne({ email })
    .select(["email", "role", "name", "status", "phone", "company"])
    .select({
      sessionid: sessionid,
    });

  



  if (!user) {
    return next(
      new ErrorHandler("User is not find with this email & password", 401)
    );
  }

  const isPasswordMatch = await user.comparePassword(password);

  if (!isPasswordMatch) {
   return next(
     new ErrorHandler("User is not find with this email & password", 401)
   );
  }


  const userid = result?._id;
  const role = result?.role;
  const lname = result?.name;
  const lphone = result?.phone;
  const lemail = result?.email;
  const lcompany = result?.company;

  const logs = await LogsModel.create({
    userid,
    sessionid,
    role,
    lname,
    lphone,
    lemail,
    lcompany,
  });

  if (logs) {
    sendToken(result, 201, res, sessionid);
  } else {
    return res
      .status(400)
      .json({ success: false, message: "Session verification failed" });
  }


});


//Logout User

exports.logoutUser = catchAsyncErrors(async (req, res, next) => {

  const sessionid = req.body;
  
  const updateTime = new Date();

  const outUpdate = {
    outtime: updateTime,
  };




  const outTime = await LogsModel.findOneAndUpdate(sessionid, outUpdate, {
    new: true,
    runValidators: true,
    useFindAndModify: false,
  });

  // res.cookie("token", null, {
  //   expires: new Date(Date.now()),
  //   httpOnly: true,
  // });

  if (outTime) {
 res.status(200).json({
   success: true,
   message: "Logout Successfully",
 });
  } else
  {
     return res
       .status(400)
       .json({ success: false, message: "Session timeout" });
    }
   

})


//Get All Users

exports.getAllUsers = catchAsyncErrors(async (req, res, next) => {

  const company = req.headers.company;

  const users = await User.find().select(["email","role","name","status","phone","company","createdAt"]);
  
  const result = users?.filter((user) => {
    return user.role === "user" && user.company === company;
  })

  res.status(200).json({
    success: true,
    status: 200,
    result,
  });


})
const Category = require("../Model/CategoryModel");
const path = require("path");
const catchAsyncErrors = require("../MiddleWare/catchAsyncErrors");
const fs = require("fs");
if (!fs.existsSync("public/category")) {
  fs.mkdirSync("public/category");
}

//add new category

exports.addNewCategory = catchAsyncErrors(async (req, res, next) => {
  try {

    const data = req.body;
    const catImage = req.body.categoryimage;

   

    const path = "public/category/" + Date.now() + ".png";
    const base64Data = catImage.replace(/^data:([A-Za-z-+/]+);base64,/, "");
    fs.writeFileSync(path, base64Data, { encoding: "base64" });

    req.body.categoryimage = [
      {
        url: path,
      },
    ];

    const verify = await Category.findOne({ categoryname: data.categoryname });
    const slug = await Category.findOne({ categoryslug: data.categoryslug });
    
    if (verify) {
      return res
        .status(400)
        .json({ success: false, message: "Category already exists" });
    } else if (slug) {
      return res
        .status(400)
        .json({ success: false, message: "Category slug already exists" });
    }

   


    const category = await Category.create(req.body);

    if (category) {
      res.status(201).json({
        status: 200,
        success: true,
        message: "Category Added Successfully",
      });
    }



  } 
  catch (error) {
     res.status(500).json({
       success: false,
       message: error.message,
     });
  }


});
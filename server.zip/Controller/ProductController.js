const Products = require("../Model/ProductModel");
const ErrorHandler = require("../Utils/ErrorHandler");
const catchAsyncErrors = require("../MiddleWare/catchAsyncErrors");
const path = require("path");
const fs = require("fs");
if (!fs.existsSync("public/products")) {
  fs.mkdirSync("public/products");
}





//add new product
exports.addNewProduct = catchAsyncErrors(async (req, res, next) => {
  try {
    const data = req.body;
    const imgdata = req.body.image;
    const imgUrl = imgdata.map((item) => {
      return item.thumbUrl;
    });
    const imageLinks = [];
    for (let i = 0; i < imgUrl.length; i++) {
      const path = "public/products/" + Date.now() + ".webp";
      const base64Data = imgUrl[i].replace(/^data:([A-Za-z-+/]+);base64,/, "");
      fs.writeFileSync(path, base64Data, { encoding: "base64" });
      imageLinks.push({
        url: path,
      });
    }

    
    
    const verify = await Products.findOne({ title: data.title });
    const sku = await Products.findOne({ sku: data.sku });
   
    req.body.images = imageLinks;
    
    if (verify) {
      return res
        .status(400)
        .json({ success: false, message: "Product already exists" });
    } else if (sku) {
      return res
        .status(400)
        .json({ success: false, message: "SKU ID already exists" });
    }
   

    const product = await Products.create(req.body);

    if (product) {
      res.status(201).json({
        status: 200,
        success: true,
        message: "Product Added Successfully",
      });
    }
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message,
    });
  }
});

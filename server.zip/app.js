const express = require("express");
const app = express();
const path = require("path");
const cors = require("cors");
const cookieParser = require("cookie-parser");
const bodyParser = require("body-parser");
const ErrorHandler = require("./MiddleWare/error");
const fs = require("fs");
app.use(express.json());
app.use(cookieParser());
app.use(
  cors({
    origin: "*",
  })
);
app.use(bodyParser.json({ limit: "50mb" }));
// app.use(bodyParser.urlencoded({ extended: true, limit: "50mb" }));
// app.use(express.urlencoded({ limit: "50mb", extended: true }));

if (!fs.existsSync("public/products")) {
  fs.mkdirSync("public/products");
}
if (!fs.existsSync("public/category")) {
  fs.mkdirSync("public/category");
}
if (!fs.existsSync("public/banners")) {
  fs.mkdirSync("public/banners");
}
if (!fs.existsSync("public/profile")) {
  fs.mkdirSync("public/profile");
}
app.use("/public/products", express.static(__dirname + "/public/products"));
app.use("/public/profile", express.static(__dirname + "/public/profile"));
app.use("/public/banners", express.static(__dirname + "/public/banners"));
app.use("/public/category", express.static(__dirname + "/public/category"));




app.use(express.json());
app.use(express.urlencoded({ extended: true }));
//Config

require("dotenv").config();


//Router Import

const user = require("./Routes/UserRoutes")
const product = require("./Routes/ProductRoutes");
const category = require("./Routes/CategoryRoutes");


app.use("/api", user)
app.use("/api", product);
app.use("/api", category);


// it's for errorHandeling
app.use(ErrorHandler);

module.exports = app; 
import {
  FileOutlined,
  PieChartOutlined,
  UserOutlined,
  DesktopOutlined,
  TeamOutlined,
  MoreOutlined,
  KeyOutlined,
  LoginOutlined,
} from "@ant-design/icons";
import {
  BrowserRouter as Router,
  Routes,
  Route,
  useLocation,
  Link,
  Navigate,
} from "react-router-dom";
import {
  Breadcrumb,
  Layout,
  Menu,
  theme,
  Space,
  Badge,
  Dropdown,
  Avatar,
  Input,
} from "antd";
import { useState, useLayoutEffect } from "react";
import bell from "../Assets/Images/bell.png";
import message from "../Assets/Images/message.png";
import styled from "styled-components";
import MobileMenu from "../Component/MobileMenu";
const { Header, Content, Footer, Sider } = Layout;
const { Search } = Input;
const Dashboard = () => {
   const Wrapper = ({ children }) => {
     const location = useLocation();
     useLayoutEffect(() => {
       document.documentElement.scrollTo(500, 0);
     }, [location.pathname]);
     return children;
   };
  function getItem(label, key, icon, children) {
    return {
      key,
      icon,
      children,
      label,
    };
  }
  const d = new Date();
  const itemsOne = [
    getItem("Option 1", "1", <PieChartOutlined />),
    getItem("Option 2", "2", <DesktopOutlined />),
    getItem("User", "sub1", <UserOutlined />, [
      getItem("Tom", "3"),
      getItem("Bill", "4"),
      getItem("Alex", "5"),
    ]),
    getItem("Team", "sub2", <TeamOutlined />, [
      getItem("Team 1", "6"),
      getItem("Team 2", "8"),
    ]),
    getItem("Files", "9", <FileOutlined />),
  ];

  const items = [
    {
      label: (
        <>
          <UserOutlined /> My Profile
        </>
      ),
      key: "0",
    },
    {
      label: (
        <>
          <KeyOutlined /> Change Password
        </>
      ),
      key: "1",
    },
    {
      label: (
        <>
          <LoginOutlined /> Logout
        </>
      ),
      key: "2",
    },
  ];
  const [collapsed, setCollapsed] = useState(false);
  const {
    token: { colorBgContainer },
  } = theme.useToken();
  return (
    <>
      <Router basename="/">
        <Wrapper>
          <DashboardSection>
            <Layout
              style={{
                minHeight: "100vh",
              }}
            >
              <Sider
                collapsible
                collapsed={collapsed}
                onCollapse={(value) => setCollapsed(value)}
              >
                <div
                  style={{
                    height: 32,
                    margin: 16,
                    background: "rgba(255, 255, 255, 0.2)",
                  }}
                />
                <Menu
                  theme="light"
                  defaultSelectedKeys={["1"]}
                  mode="inline"
                  items={itemsOne}
                />
              </Sider>
              <Layout className="site-layout">
                <Header
                  style={{
                    padding: 0,
                    background: colorBgContainer,
                    position: "fixed",
                    top: 0,
                    left: 0,
                    width: "100%",
                    zIndex: 1000,
                  }}
                >
                  <div className="header_align">
                    <div className="header_left">
                      <div className="header_left_menu">
                        <MobileMenu />
                      </div>
                      <Link to="/">
                        <h4>PAUL</h4>
                      </Link>
                    </div>
                    <div className="header_right">
                      <Search
                        placeholder="Search"
                        size="middle"
                        className="serach_head_btn"
                      />
                      <div className="right_side_bar">
                        <div className="batch_align">
                          <Badge count={0} showZero size="small">
                            <img src={bell} alt="Notification" />
                          </Badge>
                          <Badge count={0} showZero size="small">
                            <img src={message} alt="Message" />
                          </Badge>
                        </div>
                        <Dropdown
                          menu={{
                            items,
                          }}
                          trigger={["click"]}
                        >
                          <a
                            onClick={(e) => e.preventDefault()}
                            className="account_name"
                          >
                            <Space>
                              <Avatar
                                className="avator_profile"
                                size="small"
                                style={{ backgroundColor: "#87d068" }}
                                icon={<UserOutlined />}
                              />
                              <MoreOutlined />
                            </Space>
                          </a>
                        </Dropdown>
                      </div>
                    </div>
                  </div>
                </Header>
                <Content
                  style={{
                    margin: "0 16px",
                    padding: "80px 0px 50px 0px",
                  }}
                >
                  <Breadcrumb
                    style={{
                      margin: "16px 0",
                    }}
                  >
                    <Breadcrumb.Item>User</Breadcrumb.Item>
                    <Breadcrumb.Item>Bill</Breadcrumb.Item>
                  </Breadcrumb>
                  <div
                    style={{
                      padding: 24,
                      minHeight: 360,
                      background: colorBgContainer,
                    }}
                  >
                    Bill is a cat.
                  </div>
                  <div
                    style={{
                      padding: 24,
                      minHeight: 360,
                      background: colorBgContainer,
                    }}
                  >
                    Bill is a cat.
                  </div>
                  <div
                    style={{
                      padding: 24,
                      minHeight: 360,
                      background: colorBgContainer,
                    }}
                  >
                    Bill is a cat.
                  </div>
                  <div
                    style={{
                      padding: 24,
                      minHeight: 360,
                      background: colorBgContainer,
                    }}
                  >
                    Bill is a cat.
                  </div>
                </Content>
                <Footer
                  style={{
                    textAlign: "center",
                    fontFamily: "q_bold",
                    fontSize: "13px",
                  }}
                >
                  ©{d.getFullYear()} Developed by{" "}
                  <a
                    href="https://ecdigi.com/"
                    title="ecDigi Technologies"
                    target="_blank"
                    rel="noreferrer"
                    style={{ color: "var(--bg)", fontWeight: 600 }}
                  >
                    Paul
                  </a>
                </Footer>
              </Layout>
            </Layout>
          </DashboardSection>
        </Wrapper>
      </Router>
    </>
  );
};

export default Dashboard;


const DashboardSection = styled.section`
  #components-layout-demo-side .logo {
    height: 25px;
    margin: 16px;
    background: rgba(255, 255, 255, 0.3);
  }
  .D_Header {
    position: sticky;
    top: 0;
    left: 0px;
    width: 100%;
    z-index: 100;
  }
  .site-layout .site-layout-background,
  .ant-layout-sider,
  .ant-menu-dark .ant-menu-sub,
  .ant-menu.ant-menu-dark,
  .ant-menu.ant-menu-dark .ant-menu-sub,
  .ant-layout-sider-trigger {
    background: #fff;
  }
  .logo {
    height: 55px;
    border-bottom: 1px solid #f5f5f5;
    border-right: 1px solid #f5f5f5;
    text-align: center;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 23px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 0.2px;
  }

  .LayoutSection {
    min-height: 100vh;
  }
  .ant-layout-header {
    background: #fff;
    padding: 10px 20px 10px 20px;
    display: flex;
    align-items: center;
    flex-wrap: wrap;
    justify-content: space-between;
    line-height: normal;
    border-bottom: 1px solid #f5f5f5;
    height: 55px;
  }
  .ant-layout,
  body {
    background: #f6f9ff;
  }
  .ant-layout-sider-trigger {
    color: #f6f9ff;
    border-top: 1px solid #f2f2f2;
    background: #000;
    z-index: 120;
    height: 40px;
    line-height: 40px;
  }

  .ant-menu-dark .ant-menu-sub,
  .ant-menu.ant-menu-dark,
  .ant-menu.ant-menu-dark .ant-menu-sub,
  .ant-menu-dark .ant-menu-item,
  .ant-menu-dark .ant-menu-item-group-title,
  .ant-menu-dark .ant-menu-item > a,
  .ant-menu-dark .ant-menu-item > span > a {
    color: #000;
  }

  .ant-layout-footer {
    padding: 12px 15px;
    background: #f6f9ff;
    color: #000;
    text-align: center;
    border-top: 1px solid #f5f5f5;
  }
  .Contents {
    width: 100%;
    display: inline-block;
    position: relative;
    padding: 24px;
    margin: 0px 0 0 0;
  }
  .BreadCrumb {
    margin: 0 0 30px;
  }
  .ant-layout-sider-children {
    position: fixed;
    width: 200px;
    z-index: 101;
    top: 0;
  }
  ul.ant-menu.ant-menu-root.ant-menu-inline.ant-menu-light,
  .ant-layout-sider-children .ant-menu.ant-menu-inline-collapsed {
    border-right: 1px solid #f0f0f0;
    height: 85vh;
    min-height: 85vh;
    max-height: 85vh;
    overflow: hidden;
    overflow-y: auto;
    padding: 0 0 20px;
  }

  /* width */
  ul.ant-menu.ant-menu-root.ant-menu-inline.ant-menu-light::-webkit-scrollbar,
  .ant-layout-sider-children
    .ant-menu.ant-menu-inline-collapsed::-webkit-scrollbar {
    width: 5px;
  }

  /* Track */
  ul.ant-menu.ant-menu-root.ant-menu-inline.ant-menu-light::-webkit-scrollbar-track,
  .ant-layout-sider-children
    .ant-menu.ant-menu-inline-collapsed::-webkit-scrollbar-track {
    background: #f1f1f1;
  }

  /* Handle */
  ul.ant-menu.ant-menu-root.ant-menu-inline.ant-menu-light::-webkit-scrollbar-thumb,
  .ant-layout-sider-children
    .ant-menu.ant-menu-inline-collapsed::-webkit-scrollbar-thumb {
    background: #888;
    border-radius: 5px;
  }

  /* Handle on hover */
  ul.ant-menu.ant-menu-root.ant-menu-inline.ant-menu-light::-webkit-scrollbar-thumb:hover,
  .ant-layout-sider-children
    .ant-menu.ant-menu-inline-collapsed::-webkit-scrollbar-thumb:hover {
    background: #555;
  }

  .ant-layout-sider.ant-layout-sider-dark.ant-layout-sider-collapsed.ant-layout-sider-has-trigger
    .ant-layout-sider-children {
    width: 60px;
  }
  .ant-menu-item-selected {
    background-color: rgb(245 146 9 / 10%);
    margin: 0 !important;
    width: 100% !important;
    border-radius: 0;
  }

  .ant-menu-item-selected .ant-menu-item-icon svg {
    color: var(--bg);
  }
  .ant-menu-title-content {
    font-size: 13px;
    font-family: "q_bold";
  }
  .ant-menu-item-selected .ant-menu-title-content {
    color: var(--bg);
  }
  .ant-menu-item {
    height: 37px;
    line-height: 37px;
    width: 100% !important;
    border-radius: 0;
    margin: 5px 0 !important;
  }
  .ant-menu-submenu-title {
    margin: 5px 0;
    height: 37px !important;
    line-height: 37px !important;
    width: 100% !important;
    border-radius: 0;
  }
  .ant-layout-sider.ant-layout-sider-dark.ant-layout-sider-collapsed.ant-layout-sider-has-trigger {
    flex: 0 0 60px !important;
    max-width: 60px !important;
    min-width: 60px !important;
    width: 60px !important;
  }
  .ant-layout-sider.ant-layout-sider-dark.ant-layout-sider-collapsed.ant-layout-sider-has-trigger
    .ant-layout-sider-trigger {
    width: 60px !important;
  }
  .ant-menu-sub .ant-menu-title-content {
    font-family: "q_medium" !important;
  }

  .header_align {
    display: flex;
    align-items: center;
    height: 55px;
    padding: 5px 17px;
    justify-content: space-between;
    width: 100%;
    z-index: 1000;
    box-shadow: 0 0 5px rgb(0 0 0 / 12%);
  }
  .header_align .header_left {
    width: 235px;
    display: flex;
    align-items: center;
    gap: 15px;
  }
  .header_left_menu {
    display: none;
  }
  .header_left h4 {
    margin: 0;
    font-size: 18px;
    font-family: "q_bold";
    color: var(--bg);
  }
  .header_align .header_left svg {
    font-size: 20px;
    cursor: pointer;
  }
  .header_align .header_right {
    width: 100%;
    display: flex;
    gap: 20px;
    justify-content: space-between;
    align-items: center;
    flex-direction: row;
  }
  .serach_head_btn {
    width: 220px;
  }
  .header_align .header_left img {
    height: 35px;
  }
  /* .header_align .header_right button {
  padding: 2px 8px;
  height: auto;
  font-family: 'q_medium';
  background: var(--bg);
  span {
  font-family: 'q_medium';
  }
}
.header_align .header_right button:hover {
  background: #000;
} */
  .account_name .ant-space-item {
    font-size: 13px;
    font-family: "q_bold";
    color: #000;
    width: max-content;
    display: inline-block;
  }

  .header_align .header_right .ant-input {
    padding: 2px 11px;
  }
  .header_align .header_right .ant-input-group-addon button {
    height: 28px;
  }

  .avator_profile {
    width: 28px;
    height: 28px;
    line-height: 25px;
  }

  .right_side_bar {
    display: flex;
    align-items: center;
    gap: 20px;
  }
  .right_side_bar .batch_align {
    display: flex;
    gap: 20px;
  }

  .right_side_bar .batch_align img {
    height: 20px;
  }
  .ant-badge .ant-badge-count-sm {
    min-width: 12px;
    height: 12px;
    font-size: 9px;
    line-height: 11px;
    border-radius: 7px;
  }

  @media screen and (max-width: 1200px) {
    .header_left_menu {
      display: block;
    }
  }

  @media screen and (max-width: 768px) {
    .header_align {
      position: relative;
      height: 100px;
      padding: 0 20px 45px 20px;
      background: #fff;
    }

    .serach_head_btn {
      width: 100%;
      position: absolute;
      bottom: 12px;
      left: 0;
      margin: auto;
      padding: 0 16px;
    }

    .right_side_bar {
      margin: auto 0 auto auto;
    }

    main.ant-layout-content {
      padding: 120px 0px 50px !important  ;
    }

    .header_align .header_left img {
      height: 25px;
    }
    .account_name .ant-space-item {
      font-size: 12px;
    }
    .avator_profile {
      width: 23px;
      height: 23px;
      line-height: 21px;
      font-size: 11px;
      gap: 4px;
    }

    .right_side_bar {
      gap: 18px;
    }
    .right_side_bar .batch_align {
      gap: 15px;
    }
    .right_side_bar .batch_align img {
      height: 17px;
    }
    .ant-badge .ant-badge-count-sm {
      min-width: 11px;
      height: 11px;
      font-size: 9px;
      line-height: 10px;
      border-radius: 7px;
    }

    .header_align .header_left {
      width: fit-content;
      gap: 9px;
    }
    .header_align .header_left svg {
      font-size: 18px;
    }

    /* .account_name .ant-space-item { 

  display: none;
} */
  }

  @media screen and (max-width: 380px) {
    .account_name .ant-space-item {
      font-size: 10px;
    }
  }
`;

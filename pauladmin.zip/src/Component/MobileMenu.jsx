import React, { useState } from "react";
import {
  DesktopOutlined,
  SettingOutlined,
  BarChartOutlined,
  UserOutlined,
  MenuUnfoldOutlined,
  PieChartOutlined,
  GiftOutlined,
  ShoppingCartOutlined,
  FileProtectOutlined,
  FileOutlined,
  TeamOutlined,
} from "@ant-design/icons";
import { Menu, Drawer, Spin } from "antd";
import { Link } from "react-router-dom";
import styled from "styled-components";

const MobileMenu = () => {
   const [open, setOpen] = useState(false);
   const showDrawer = () => {
     setOpen(true);
   };
   const onClose = () => {
     setOpen(false);
   };
  function getItem(label, key, icon, children) {
    return {
      key,
      icon,
      children,
      label,
    };
  }
  const items = [
    getItem("Option 1", "1", <PieChartOutlined />),
    getItem("Option 2", "2", <DesktopOutlined />),
    getItem("User", "sub1", <UserOutlined />, [
      getItem("Tom", "3"),
      getItem("Bill", "4"),
      getItem("Alex", "5"),
    ]),
    getItem("Team", "sub2", <TeamOutlined />, [
      getItem("Team 1", "6"),
      getItem("Team 2", "8"),
    ]),
    getItem("Files", "9", <FileOutlined />),
  ];
  const [loading, setLoading] = useState(false);
  return (
    <>
      <MobileSection>
        <div className="mobile_menu">
          <div onClick={showDrawer} className="menu_icon">
            <MenuUnfoldOutlined />
          </div>
          <Drawer
            title="Menubar"
            placement="left"
            onClose={onClose}
            open={open}
            style={{ padding: 0 }}
            width={260}
          >
            {loading === true ? (
              <div className="spin_center">
                <Spin />
              </div>
            ) : (
              <Menu
                theme="light"
                defaultSelectedKeys={["1"]}
                mode="inline"
                items={items}
              />
            )}
          </Drawer>
        </div>
      </MobileSection>
    </>
  );
};

export default MobileMenu;


const MobileSection = styled.section`
  .menu_icon {
  }
`;
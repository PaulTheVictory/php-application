import React, { useState } from "react";
import styled from "styled-components";
import bg from "../Assets/Images/login-bg.png";
import { Button, Form, Input } from "antd";
import { LockOutlined, UserOutlined, LoginOutlined } from "@ant-design/icons";
const Login = () => {
  const [form] = Form.useForm();
  const [saving, setSaving] = useState(false);
  const onFinish = (values) => {
    setSaving(true);
    console.log("Success:", values);
  };
  return (
    <>
      <LoginSection>
        <div className="login_header">
          <div className="login_header_align">
            <div className="login_header_left">
              <h4>Paul</h4>
            </div>
            <div className="login_header_right">
              <span>Don't have an account? </span>
              <Button>Sign up</Button>
            </div>
          </div>
        </div>
        <div className="login_section">
          <h1>Welcome back!</h1>
          <Form
            form={form}
            name="admin_login"
            layout="vertical"
            onFinish={onFinish}
            autoComplete="off"
          >
            <Form.Item
              label="Email Address"
              name="email"
              rules={[
                {
                  required: true,
                  message: "Please enter valid email address",
                },
              ]}
            >
              <Input
                prefix={<UserOutlined className="site-form-item-icon" />}
                placeholder="Email Address"
              />
            </Form.Item>

            <Form.Item
              label="Password"
              name="password"
              rules={[
                {
                  required: true,
                  message: "Please enter valid password!",
                },
              ]}
            >
              <Input.Password
                prefix={<LockOutlined className="site-form-item-icon" />}
                placeholder="Password"
              />
            </Form.Item>

            <Button type="primary" htmlType="submit" loading={saving}>
              <LoginOutlined /> Sign In
            </Button>
          </Form>
          <div className="login_with_otp">
            <span>or</span>
            <p>Login with OTP?</p>
          </div>
        </div>
      </LoginSection>
    </>
  );
};

export default Login;

const LoginSection = styled.section`
  display: flex;
  align-items: center;
  justify-content: center;
  width: 100%;
  min-height: 100vh;
  overflow: hidden;
  position: relative;
  background: #fafbfc;

  ::after {
    content: "";
    position: absolute;
    width: calc(100%);
    height: calc(100% - 25vh);
    width: 100%;
    top: 25vh;
    background: url("${bg}");
    background-repeat: no-repeat;
    background-size: 100%;
    background-position: center top;
    z-index: 5;
  }

  ::before {
    content: "";
    background: var(--bg);
    position: absolute;
    height: 100%;
    width: 100%;
    top: 25vh;
    z-index: 3;
  }

  .login_section {
    width: 400px;
    background: #fff;
    box-shadow: 0 24px 64px #26214a1a;
    border-radius: 12px;
    padding: 25px 30px;
    position: relative;
    z-index: 10;
    margin: 130px 0 50px 0;
  }

  h1 {
    font-family: "q_bold";
    margin: 0 0 20px;
    text-align: center;
    font-size: 23px;
  }
  label {
    color: #292d34 !important;
    font-family: "q_medium";
  }
  .ant-form-item-label {
    padding: 0 0 7px !important;
  }
  svg {
    color: #d9d9d9 !important;
  }

  span.ant-input-affix-wrapper {
    padding: 6px 11px !important;
  }
  span.ant-input-affix-wrapper:hover,
  span.ant-input-affix-wrapper:focus {
    border-color: var(--bg) !important;
  }

  .ant-form-item {
    margin-bottom: 10px !important;
  }

  button {
    background: var(--bg);
    margin: 11px 0 0 0;
    width: 100%;
    padding: 6px 15px;
    height: auto;
    span {
      font-family: "q_bold";
      color: #fff;
      svg {
        color: #fff !important;
      }
    }
  }
  button:hover {
    background: #000 !important;
  }

  .login_with_otp {
    width: 100%;
    display: inline-block;
    margin: 10px 0 0 0;
  }
  .login_with_otp span {
    color: #292d34;
    font-family: "q_bold";
    text-align: center;
    width: 100%;
    display: inline-block;
    font-style: italic;
    font-size: 14px;
  }
  .login_with_otp p {
    font-size: 12px;
    font-family: "q_bold";

    color: var(--bg) !important;
    text-align: center;
    margin: 5px 0 0 0;
    cursor: pointer;
  }
  .login_with_otp p:hover {
    color: #000 !important;
  }

  .login_header {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    z-index: 11;
    padding: 20px 30px 12px 30px;
    background: #fafbfc;
  }
  .login_header_align {
    display: flex;
    align-items: center;
    justify-content: space-between;
  }

  .login_header_left {
    width: fit-content;
    img {
      height: 40px;
    }
  }
  .login_header_right {
    width: fit-content;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 15px;
    span {
      display: inline-block;
      font-family: "q_medium";
      font-size: 14px;
    }
    button {
      width: fit-content;
      margin: 0;
      box-shadow: var(--shadow);
      border-color: var(--bg);
      padding: 5px 13px;
    }
  }
  .login_header_left h4 {
    margin: 0;
    font-size: 25px;
    text-transform: uppercase;
    font-family: "q_bold";
    letter-spacing: 0.1px;
  }
  @media screen and (max-width: 580px) {
    ::before {
      background: #f9fafb;
    }
    .login_header_right span {
      display: none;
    }
    .login_header_right button span {
      display: block;
    }

    .login_header {
      padding: 13px 15px 0 15px;
    }
    .login_header_left img {
      height: 40px;
    }
    .login_section {
      width: 90%;
      padding: 30px 25px;
      margin: auto;
      display: flex;
      flex-direction: column;
    }
  }
`;

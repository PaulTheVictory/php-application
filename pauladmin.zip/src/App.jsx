import React from 'react';
import './Assets/Css/Style.css';
import Login from './Component/Login';
import Dashboard from './Pages/Dashboard';
const App = () => {
  return (
    <React.Fragment>
      {/* <Login /> */}
      <Dashboard />
    </React.Fragment>
  )
}

export default App;
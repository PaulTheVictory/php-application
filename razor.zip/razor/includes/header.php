<!DOCTYPE HTML>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<title>FORM</title>
	<script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
	<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
	<script src="js/bootstrap.min.js"></script>	
	<script src="js/dobpicker.js"></script>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
	<link rel="stylesheet" type="text/css" href="style.css" media="all">
</head>
<body>



<!--header_section-->


<div class="header_section">
	<div class="wrap_grid">
		<div class="header_align">
			<div class="header_left">
				<a href="./" title="PHP FORM"><h2>PHP FORM</h2></a>
			</div>
			<div class="header_right">
				<?php
					if(isset($_SESSION["username"])){
				?>
				<ul class="menu">
					<li><a href="register-view.html" title="REGISTER LIST">REGISTER LIST</a></li>
					<li><a href="edit.html" title="EDIT">EDIT</a></li>
					<li><a href="" title="DELETE">DELETE</a></li>
					<li><a href="" title="ADD">ADD</a></li>
				</ul>
				<?php } ?>
				<ul>
				<?php
					if(isset($_SESSION["username"])){
				?>
					<li><a href="logout.php" title="LOGOUT"><button>LOGOUT</button></a></li>
				<?php } ?>
				<?php
					if(!isset($_SESSION["username"])){
				?>
					<li><a href="./" title="NEW MEMBER"><button>NEW MEMBER</button></a></li>
				<?php } ?>
				</ul>
			</div>
		</div>
	</div>
</div>


<!--header_section-->
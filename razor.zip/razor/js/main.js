   var viewportwidth = 0;
    
    function UpdateTableHeaders() {
        
       $(".content-class").each(function() {
       
           var el             = $(this),
           offset         = el.offset(),
           scrollTop      = $(window).scrollTop(),
           floatingHeader = $(".floatingHeader")
           //alert(floatingHeader.width());
           
              // Here the variables are updated from the screen object
    if ((window.innerWidth)&&(window.innerHeight)) {
        viewportwidth = window.innerWidth;
      
    }else if (document.documentElement) {
        if (document.documentElement.clientWidth) {
            viewportwidth = document.documentElement.clientWidth;
           
            }
    }
    
    var calsize;
           if(viewportwidth >= 960) {
            
                calsize  = viewportwidth - 975;
                calsize = calsize/2;
                floatingHeader.children().css("margin-left",calsize);
                    
             } else {
                 
                floatingHeader.children().css("margin-left","0");
             }
             
           var calHeight = 0;
           calHeight = ($(".header-class").css("height"));
           calHeight =calHeight.replace("px", "");
           calHeight = parseInt(calHeight);
               
           if(scrollTop < calHeight) {
               floatingHeader.css({
                    "visibility": "hidden"
               }); 
           } else if ((scrollTop > offset.top) && (scrollTop < offset.top + el.height())) {
               floatingHeader.css({
                "visibility": "visible"
               });
           } else {
               floatingHeader.css({
                "visibility": "visible"
               });      
           }
       });
    }
    

function datePick(id)
{
    var id2 = "#"+id;
    $(id2).datepick();
}

function init() {

 $("#subscribe_name").focus(function(){
                    
                   var name = $(this).val();
$(this).css("color","#3d3d3d");
                   if(name == 'Name') {
                       
                      $("#subscribe_name").attr("value",""); 
                   }
               });
               
               $("#subscribe_name").blur(function(){
                   
                   var name = $(this).val();
                   if(name == '') {
                       
                      $("#subscribe_name").attr("value","Name"); 
                   }
               });
               
               $("#subscribe_email").focus(function(){
                   
                   var name = $(this).val();
                  $(this).css("color","#3d3d3d");
                   if(name == 'Email Address') {
                       
                      $("#subscribe_email").attr("value",""); 
                   }
               });
               
               $("#subscribe_email").blur(function(){
                   var name = $(this).val();
                   if(name == '') {
                       
                      $("#subscribe_email").attr("value","Email Address"); 
                   }
               });
               
                $("#addSubscribe").click(function(){
                   
                   addPatient();
                });

}

function addPatient() {
    
   var name = $("#subscribe_name").val();
   var email  = $("#subscribe_email").val();
   var regex = '';
   var regexppattern = '';
   var valid = '';
    
    
   regex   = '^[A-Za-z][A-Za-z0-9_ ]{3,40}$';
   regexppattern = new RegExp(regex);
   valid     = regexppattern.test(name);
   
   if((!valid) || (name == 'Name')) {
    
       location.href = "newsletter-sorry.html";
return;
   }
   
  
   regex   = '^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$';
   regexppattern = new RegExp(regex);
   valid     = regexppattern.test(email);
   
   if(!valid) {
       
       location.href = "newsletter-sorry.html";
return;
   }
    
   
       var addurl = "./addPatient.php?&email="+email+"&name="+name+"&opr=add";
    
    
    $.ajax({
        url:addurl,
        data:{},
        success:function(data, textStatus, XMLHttpRequest) {
            var o = typeof XMLHttpRequest == 'object' ? XMLHttpRequest : '';
            if (o.status == 200) {
             
               if(data == 'fail') {
                                  
                  location.href = "newsletter-sorry.html";
return;

               } else {
               
                   location.href = "newsletter-thankyou.html";
return;
               }
                                
            }
         }
    });
    
}

function unsubscribePatient() {
    
  var addurl = "./addPatient.php?&email="+email+"&name="+name+"&opr=del";
    
  $.ajax({
        url:addurl,
        data:{},
        success:function(data, textStatus, XMLHttpRequest) {
            var o = typeof XMLHttpRequest == 'object' ? XMLHttpRequest : '';
            if (o.status == 200) {
             
               if(data == 'fail') {                                  
                  return;
               } else {
                  return;
               }
                                
            }
        }
  });
    
}


function checkValue (input) {
	if(input.value==input.defaultValue)
		input.value="";
	else if(input.value=="")
		input.value=input.defaultValue;
}

function checkForm(form, className)
{
	if(!className)
		className = "compulsory";
	var i;
	for (i=0; i < form.length; i++)
	{
		if (form[i].className == className)
		{
			var type = form[i].type.toLowerCase();
			if (type == "textarea" || type == "text" || type == "password"){
				if (form[i].value == form[i].defaultValue || form[i].value == "")
					return false;
			}
			else {
				if (type == "checkbox" && !form[i].checked)
				return false;
			}
		}
	}
	return true;
}


function appForm(form) {
 
   var name = document.getElementById("app_name").value;
   var mobile = document.getElementById("app_mobile").value;
   var email= document.getElementById("app_email").value;  
   var date= document.getElementById("app_date").value;
   
    var regex='';
    var valid;

    regex   = '^[a-zA-Z][a-zA-Z\. ]{2,40}$';
    valid = validateInputs(name,regex);
     
     if( (!valid) || (name  == "")) {
         alert('Please Enter Valid Name');
         return false;
     }
     
    regex   = '^[0-9 \-]{5,20}$';
    valid = validateInputs(mobile,regex);
    if( (!valid) || (mobile == "") ) {
         alert('Please Enter Valid Mobile Number');
         return false;
    }

    regex   = '^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$';
    valid = validateInputs(email,regex);
    if((!valid) || (email == "") ) {
         alert('Please Enter Valid Email Address');
         return false;
    } 
	
    if(date == "") {

      alert("Please Select Valid Date & Time");
      return false;
    }

form.submit;

}

function askForm(form) {

 
   var ask_name = document.getElementById("ask_name").value;
   var ask_phone = document.getElementById("ask_phone").value;
   var ask_email= document.getElementById("ask_email").value;
   var ask_comment= document.getElementById("ask_comment").value;
   
    var regex='';
    var valid;

    regex   = '^[a-zA-Z][a-zA-Z\. ]{2,40}$';
    valid = validateInputs(ask_name,regex);
     
     if( (!valid) || (ask_name  == "")) {
         alert('Please Enter Valid Name');
         return false;
     }
     
    regex   = '^[0-9 \-]{5,20}$';
    valid = validateInputs(ask_phone,regex);
    if( (!valid) || (ask_phone == "") ) {
         alert('Please Enter Valid Phone Number');
         return false;
    }

    regex   = '^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$';
    valid = validateInputs(ask_email,regex);
    if((!valid) || (ask_email == "") ) {
         alert('Please Enter Valid Email Address');
         return false;
    }
    
    if(ask_comment == '') {

      alert("Please Enter Some Valid Comment");
      return false;
    }

form.submit;

}

function callbackForm(form) {

 
   var callback_name = document.getElementById("callback_name").value;
   var callback_phone = document.getElementById("callback_phone").value;
   var callback_email= document.getElementById("callback_email").value;
   var callback_contact_time= document.getElementById("callback_contact_time").value;
   var callback_comment= document.getElementById("callback_comment").value;
   
    var regex='';
    var valid;

    regex   = '^[a-zA-Z][a-zA-Z\. ]{2,40}$';
    valid = validateInputs(callback_name,regex);
     
     if( (!valid) || (callback_name  == "")) {
         alert('Please Enter Valid Name');
         return false;
     }
     
    regex   = '^[0-9 \-]{5,20}$';
    valid = validateInputs(callback_phone,regex);
    if( (!valid) || (callback_phone == "") ) {
         alert('Please Enter Valid Phone Number');
         return false;
    }

    regex   = '^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$';
    valid = validateInputs(callback_email,regex);
    if((!valid) || (callback_email == "") ) {
         alert('Please Enter Valid Email Address');
         return false;
    }
	
	 if(callback_contact_time == '') {

      alert("Please Enter Time to contact");
      return false;
    }
    
    if(callback_comment == '') {

      alert("Please Enter Some Valid Comment");
      return false;
    }

form.submit;

}


function validateInputs(value,pattern) {
    
    var regexppattern;
    regexppattern = new RegExp(pattern);
    var valid     = regexppattern.test(value);
    
    return valid;
}

$(document).ready(function() {
	
$("#webPackiframe").removeAttr("style");
	$("#webPackiframe").css("box-shadow","0 0 2px #333");
	$("#webPackiframe").css("background-image","url('images/clicktoplay.png')").css("background-repeat","no-repeat").css("background-position","center");
	$('#searchText').keyup(function(){ $("#videoleft li").each(function(){ $(this).css("display","none"); }); var searchString = $('#searchText').val(); searchString = searchString.toLowerCase().replace(/\b[a-z]/g, function(letter) { return letter.toUpperCase(); }); var foundLi = $('#videoleft li:contains("' + searchString + '")'); $(foundLi).each(function(){ $(this).css("display","block"); }); });
            
	$("#videoleft li").each(function(){
	
	   $(this).click(function(){
		   var ide = $(this).attr("data-id");
		   $("#webPackiframe").attr("src", "http://www.medivision.co.uk/Dental/webpakonline.php?id="+ide);
	   });
	
	});
	
});
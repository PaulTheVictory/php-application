
<div class="footer_section">
	<div class="wrap_grid">
		<div class="footer_align">
			<div class="footer_left">
				<h2>PHP FORM</h2>
			</div>
			<div class="footer_right">
				<p>PHP FORM © 2021 All Rights Reserved</p>
			</div>
		</div>
	</div>
</div>

</body>
</html>

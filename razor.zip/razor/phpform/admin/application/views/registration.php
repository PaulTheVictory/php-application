


<div class="free-consection">
	<div class="free-consectionalign">	
		<form method="post" action="#" id="register_form" enctype="multipart/form-data">
			<h1>Register Form</h1>
			<ul class="register">
				<li>
					
					<label>Name :</label>
					<span><input type="text" name="regname" class="register_text_box reg_name" placeholder="" ></span>
				</li>
				<li>
					<label>Email :</label>
					<span><input type="text" name="regemail" class="register_text_box reg_email" placeholder="" ></span>
				</li>
				<li>
					<label>Phone :</label>
					<span><input type="text" name="regphone" class="register_text_box reg_phone" placeholder="" ></span>
				</li>
				<li>
					<label>Gender :</label>
					<span><select name="reggender" class="register_select_box reg_gender">
						<option value="">Select Gender</option>
						<option value="male">Male</option>
						<option value="female">Female</option>
					</select></span>
				</li>
				<li>
					<label>Date of birth :</label>
					<span class="dob_sel"><select name="regdobday" class="register_select_box reg_dobday"></select>
					<select name="regdobmonth" class="register_select_box reg_dobmonth"></select>
					<select name="regdobyear" class="register_select_box reg_dobyear"></select></span>
				</li>
				<li>
					<label>Address :</label>
					<span><textarea name="regaddress" class="reg_address" placeholder="" ></textarea></span>
				</li>
				<li>
					<label>State :</label>
					<span><select name="regstate" class="register_select_box reg_state">
						<option value="">Select Your State</option>
						<option value="Tamil nadu">Tamil nadu</option>
						<option value="Tamil nadu">Tamil nadu</option>
						<option value="Tamil nadu">Tamil nadu</option>
					</select></span>
				</li>
				<li>
					<label>City :</label>
					<span><select name="regcity" class="register_select_box reg_city">
						<option value="">Select Your City</option>
						<option value="Coimbatore">Coimbatore</option>
						<option value="Coimbatore">Coimbatore</option>
						<option value="Coimbatore">Coimbatore</option>
					</select></span>
				</li>
				<li>
					<label>Pincode :</label>
					<span><input type="text" name="regpincode" class="reg_pincode" placeholder=""></span>
				</li>
				<li>
					<label>Photo :</label>
					<span><input type='file' name='regphoto' class="reg_file_box reg_photo"></span>
				</li>
				<li class="sub">
				<h6 class="error_log_text"></h6><h6 class="finish"></h6>
					<input type="submit" class="submit" name="submit" value="Submit" id="submit_form">
				</li>
				
			</ul>	
		</form>
	</div>
</div>
 


	

<script>


$(document).ready(function(){

$.dobPicker({
	daySelector: '.reg_dobday', /* Required */
	monthSelector: '.reg_dobmonth', /* Required */
	yearSelector: '.reg_dobyear', /* Required */
	dayDefault: 'Day', /* Optional */
	monthDefault: 'Month', /* Optional */
	yearDefault: 'Year', /* Optional */
	minimumAge: 18, /* Optional */
	maximumAge: 80 /* Optional */
});

$("#register_form").on("submit",function(e){
	e.preventDefault();
	
	var regname = $(".reg_name").val();
	var regemail = $(".reg_email").val();
	var regphone = $(".reg_phone").val();
	var reggender = $(".reg_gender").val();
	var regdobday = $(".reg_dobday").val();
	var regdobmonth = $(".reg_dobmonth").val();
	var regdobyear = $(".reg_dobyear").val();
	var regaddress = $(".reg_address").val();
	var regstate = $(".reg_state").val();
	var regcity = $(".reg_city").val();
	var regpincode = $(".reg_pincode").val();
	var regphoto = $(".reg_photo").val();
	
	
	var regex   = new RegExp('^[a-zA-Z][a-zA-Z\.-/ ]{1,100}$');
	var valid = regex.test(regname);
	
	if(!valid){ $(".reg_name").addClass('error_class');$(".error_log_text").text("Invalid Name");return;}
	
	
	regex   = new RegExp('^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$');
    valid = regex.test(regemail);
	
	if(!valid){ $(".reg_email").addClass('error_class');$(".error_log_text").text("Invalid Email");return;}
	
	
	regex   = new RegExp('^[0-9 \-]{5,20}$');
    valid = regex.test(regphone);

    if(!valid){ $(".reg_phone").addClass('error_class');$(".error_log_text").text("Invalid Phone Number");return;}
	
	
	var regex   = new RegExp('^[a-zA-Z][a-zA-Z\.-/ ]{3,100}$');
    valid = regex.test(reggender);

	if(!valid){ $(".reg_gender").addClass('error_class');$(".error_log_text").text("Invalid Gender");return;}
	
	if(regdobday=="" || regdobmonth=="" || regdobyear==""){ $(".reg_dobday,.reg_dobmonth,.reg_dobyear").addClass('error_class');$(".error_log_text").text("Invalid Date of Birth");return;}
	
	var dobdate = regdobyear+'/'+regdobmonth+'/'+regdobday;
		var datevalid = isDate(dobdate);

		if(!datevalid) {
		  $(".reg_dobday,.reg_dobmonth,.reg_dobyear").addClass('error_class');
		  $(".error_log_text").text("Invalid Date of Birth");
		  return;
		}
	
	var regdobdayofbirth = regdobday+'-'+regdobmonth+'-'+regdobyear;
	
	regex   = new RegExp('^[a-zA-Z0-9#][a-zA-Z0-9\n\.,-_/#:& ]{3,250}$');
    valid = regex.test(regaddress);

    if(regaddress==""){ $(".reg_address").addClass('error_class');$(".error_log_text").text("Invalid Address");return;}

	
	var regex   = new RegExp('^[a-zA-Z][a-zA-Z\.-/ ]{3,100}$');
    valid = regex.test(regstate);

	if(!valid){ $(".reg_state").addClass('error_class');$(".error_log_text").text("Invalid State");return;}
	
	
	var regex   = new RegExp('^[a-zA-Z][a-zA-Z\.-/ ]{3,100}$');
    valid = regex.test(regcity);

	if(!valid){ $(".reg_city").addClass('error_class');$(".error_log_text").text("Invalid City");return;}


	regex   = new RegExp('^[0-9 \-]{4,10}$');
    valid = regex.test(regpincode);

    if(!valid || regpincode==""){ $(".reg_pincode").addClass('error_class');$(".error_log_text").text("Invalid Pincode Number");return;}
	
	regex   = new RegExp(/\.(gif|jpg|jpeg|tiff|png)$/i);
    valid = regex.test(regphoto);

    if(!valid || regphoto==""){ $(".reg_photo").addClass('error_class');$(".error_log_text").text("Invalid Photo Format");return;}
	
	
	if($("#submit_form").hasClass('process')){
		alert("Please wait while processing...");
	}else{
	
		$("#submit_form").addClass('process').val('Processing...');
	
	$.ajax({
        	url:'register.php',
			type:'POST',
			data: new FormData(this),
			processData: false,
            contentType: false,
            cache: false,
			success:function(data){
				var obj1 = $.parseJSON(data);
				
				if(obj1[0]=="success"){
					$(".finish").text('Form Saved');
					$("#register_form")[0].reset();
					//alert("Form submitted successfully.");
					$("#submit_form").removeClass('process').val('Submit');
					//$(".finish").text('Form Saved');
					setTimeout(function(){location.assign("thankyou.html");},3000);
				}
				else if(obj1[0]=="feildempty"){
					alert("Fill all mandatory fields");
					$("#submit_form").removeClass('process').val('Submit');
				}
				else if(obj1[0]=="photoempty"){
					alert("Please upload your photo.");
					$("#submit_form").removeClass('process').val('Submit');
				}
				else if(obj1[0]=="upfail"){
					alert("Please upload valid format photo.");
					$("#submit_form").removeClass('process').val('Submit');
				}
				else if(obj1[0]=="filenotuploaded"){
					alert("Please upload valid format photo.");
					$("#submit_form").removeClass('process').val('Submit');
				}
				else if(obj1[0]=="fail"){
					alert("Please try again.");
					$("#submit_form").removeClass('process').val('Submit');
				}
				else if(obj1[0]=="dbfail"){
					alert("DB Fail.");
					$("#submit_form").removeClass('process').val('Submit');
				}
				else if(obj1[0]==""){
					alert("Please try again.");
					$("#submit_form").removeClass('process').val('Submit');
				}
				
			}
			
     	}); 
		
	}	
	

});


	var regdobday = '<option value="">Day</option>';
	var regdobmonth = '<option value="">Month</option>';
	var regdobyear = '<option value="">Year</option>';
	
	for(var d=1;d<32;d++){
		
		var day = (d < 10 ? '0' : '') + d;
		regdobday += '<option value="'+day+'">'+day+'</option>';
		
	}
	$(".reg_dobday").html(regdobday);
	
	var monthNames = ["","January","February","March","April","May","June","July","August","September","October","November","December"];
	for(var m=1;m<monthNames.length;m++){
		
		var mon = (m < 10 ? '0' : '') + m;
		regdobmonth += '<option value="'+mon+'">'+monthNames[m]+'</option>';
		
	}
	$(".reg_dobmonth").html(regdobmonth);
	
	var currentTime = new Date();
	var curyear = currentTime.getFullYear();
	var firstYear = curyear - 80;
	var lastYear = firstYear + 63;
	for(var y=firstYear;y<lastYear;y++){
		
		regdobyear += '<option value="'+y+'">'+y+'</option>';
		
	}
	$(".reg_dobyear").html(regdobyear);
	
	
});	

	
	
	


	
	$("ul.register").find("input,select,textarea").each(function(){
        $("input,select,textarea").click(function(){
			$("input,select,textarea").removeClass("error_class");$(".error_log_text").text("");
			if($("input,select,textarea").is('.reg_dobday','.reg_dobmonth','.reg_dobyear')){
				$('.reg_dobday','.reg_dobmonth','.reg_dobyear').removeClass("error_class");
			}
		});
		 

    });

	 
function isDate(txtDate)
{
    var currVal = txtDate;
    if(currVal == '')
        return false;
    
    var rxDatePattern = /^(\d{4})(\/|-)(\d{1,2})(\/|-)(\d{1,2})$/; //Declare Regex
    var dtArray = currVal.match(rxDatePattern); // is format OK?
    
    if (dtArray == null) 
        return false;
    
    //Checks for mm/dd/yyyy format.
    dtMonth = dtArray[3];
    dtDay= dtArray[5];
    dtYear = dtArray[1];        	
   
	if (dtMonth < 1 || dtMonth > 12) 
        return false;
    else if (dtDay < 1 || dtDay> 31) 
        return false;
    else if ((dtMonth==4 || dtMonth==6 || dtMonth==9 || dtMonth==11) && dtDay ==31) 
        return false;
    else if (dtMonth == 2) 
    {
        var isleap = (dtYear % 4 == 0 && (dtYear % 100 != 0 || dtYear % 400 == 0));
        if (dtDay> 29 || (dtDay ==29 && !isleap)) 
                return false;
    }
	
    return true;
}	 
	
	 




</script>


<!DOCTYPE HTML>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<title>FORM</title>
	<script src="<?php echo base_url();?>js/jquery_min.js"></script>
	<script src="<?php echo base_url();?>js/jquery_ui_min.js"></script>
	<script src="<?php echo base_url();?>js/bootstrap_min.js"></script>	
	<script src="<?php echo base_url();?>js/dobpicker.js"></script>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>css/bootstrap_min.css">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>css/jquery_ui_min.css">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>/css/style.css" media="all">
</head>
<body>



<!--header_section-->


<div class="header_section">
	<div class="wrap_grid">
		<div class="header_align">
			<div class="header_left">
				<a href="./" title="PHP FORM"><h2>PHP FORM</h2></a>
			</div>
			<div class="header_right">
				
				<!--<ul class="menu">
					<li><a href="register-view.html" title="REGISTER LIST">REGISTER LIST</a></li>
					<li><a href="" title="EDIT">EDIT</a></li>
					<li><a href="" title="DELETE">DELETE</a></li>
					<li><a href="" title="ADD">ADD</a></li>
				</ul>-->
				
				<ul>
					<!--<li><a href="logout.php" title="LOGOUT"><button>LOGOUT</button></a></li>
					<li><a href="register.html" title="REGISTER"><button>REGISTER</button></a></li>-->
					<li><a href="" title="Home"><button>Home</button></a></li>
				</ul>
			</div>
		</div>
	</div>
</div>


<!--header_section-->
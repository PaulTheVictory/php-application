<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>



<div class="login_form">
	<div class="wrap_grid">
		<div class="login_form_content">
			<form action="" method="post" name="login" id="login" autocomplete='off'>
				<h1>ADMIN LOGIN</h1>
				
				<input type="text" name="username" class="login_name" placeholder="Username" readonly onfocus="this.removeAttribute('readonly');"/>
				<input type="password" name="password" class="login_password" placeholder="Password" readonly onfocus="this.removeAttribute('readonly');"/>
				<span>
				<input name="submit" type="submit" id="login_submit" value="LOGIN" />
				<h6 class="error_log_text"></h6>
				</span>
			</form>
		</div>
	</div>
</div>

<script>

$(document).ready(function(){

$('input[type="text"], input[type="password"]').val("");
$('input[type="text"], input[type="password"]').attr('autocomplete', 'off');

$("#login").on("submit",function(e){
	e.preventDefault();
	
	var loginname = $(".login_name").val();
	var loginpassword = $(".login_password").val();
	
	if(loginname==""){ $(".login_name").addClass('error_class');$(".error_log_text").text("Invalid Username");return;}
	if(loginpassword==""){ $(".login_password").addClass('error_class');$(".error_log_text").text("Invalid Password");return;}
	
	if($("#login_submit").hasClass('process')){
		alert("Please wait while processing...");
	}else{
	
		$("#login_submit").addClass('process').val('Processing...');
	
	$.ajax({
        	url:'Login/verifyLogin',
			type:'GET',
			data: new FormData(this),
			processData: false,
            contentType: false,
            cache: false,
			success:function(data){
				var obj1 = $.parseJSON(data);
				
				if(obj1[0]=="success"){
					
					setTimeout(function(){
						$("#login_submit").removeClass('process').val('LOGIN');
						//location.assign("dashboard.html");
						alert('success');
					},2000);
				}
				else if(obj1[0]=="fail"){
					alert("Login Failed.");
					$("#login_submit").removeClass('process').val('LOGIN');
				}
				else if(obj1[0]=="failall"){
					alert("Please try again.");
					$("#login_submit").removeClass('process').val('LOGIN');
				}
				
				else if(obj1[0]==""){
					alert("Please try again.");
					$("#login_submit").removeClass('process').val('LOGIN');
				}
				
			}
			
     	}); 
		
	}
	
})
}); 
$("#login").find("input,select,textarea").each(function(){
        $("input,select,textarea").click(function(){
			$("input,select,textarea").removeClass("error_class");$(".error_log_text").text("");
		});
		 

    });

</script>
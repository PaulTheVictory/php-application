import React from 'react'
import { Table} from "antd";
const TableDynamic = ({rowSelection, columns, data}) => {
  return (
    <Table
      rowSelection={rowSelection}
      columns={columns}
      dataSource={data}
      size="small"
      bordered
      scroll={{
        x: 1200,
      }}
    />
  );
};

export default TableDynamic;
import React from 'react'

const CrudService = () => {
  return (
    <div>CrudService</div>
  )
}

export default CrudService
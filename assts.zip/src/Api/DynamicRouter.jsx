import React from 'react'
import Country from './../Component/Country';
import Home from '../Component/Home';

const authRoute = [
  {
    index:true,
    exact: true,
    path: "/",
    element: <Home title="Dashboard" />,
  },
  {
    exact: true,
    path: "/country",
    element: <Country title="Country" />,
  },
];






export { authRoute };
import React from "react";
import { DualAxes } from "@ant-design/plots";
import { Button } from "antd";
import { StockOutlined } from "@ant-design/icons";
const HomeChartThree = () => {
  const data = [
    {
      year: "1991",
      value: 3,
      count: 10,
    },
    {
      year: "1992",
      value: 4,
      count: 4,
    },
    {
      year: "1993",
      value: 3.5,
      count: 5,
    },
    {
      year: "1994",
      value: 5,
      count: 5,
    },
    {
      year: "1995",
      value: 4.9,
      count: 4.9,
    },
    {
      year: "1996",
      value: 6,
      count: 35,
    },
    {
      year: "1997",
      value: 7,
      count: 7,
    },
    {
      year: "1998",
      value: 9,
      count: 1,
    },
    {
      year: "1999",
      value: 13,
      count: 20,
    },
  ];
  const config = {
    data: [data, data],
    xField: "year",
    yField: ["value", "count"],
    geometryOptions: [
      {
        geometry: "line",
        color: "#004d4d",
      },
      {
        geometry: "line",
        color: "#f88c24",
      },
    ],
  };

  return (
    <>
      <div className="cart_box">
        <div className="cart_head">
          <h4>Buy / Sell</h4>
          <Button>
            <StockOutlined />
            View
          </Button>
        </div>
        <DualAxes {...config} />
      </div>
    </>
  );
};

export default HomeChartThree;

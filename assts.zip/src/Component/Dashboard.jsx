import {
  DesktopOutlined,
  SettingOutlined,
  UserOutlined,
  PushpinOutlined,
  ReadOutlined,
  BellOutlined,
  MailOutlined,
  PoweroffOutlined,
  MoreOutlined,
  SafetyCertificateOutlined,
  ShoppingOutlined,
  GiftOutlined,
  HistoryOutlined,
} from "@ant-design/icons";
import { Layout, Menu, Input, Dropdown, Avatar } from "antd";
import {
  BrowserRouter as Router,
} from "react-router-dom";
import { useState } from "react";
import {Link} from 'react-router-dom'
import DynamicRouter from "./DynamicRouter";
import MobileMenu from './MobileMenu'
const { Header, Content, Footer, Sider } = Layout;
const { Search } = Input;
const Dashboard = () => {
  const [collapsed, setCollapsed] = useState(false);
  const getItem = (label, key, icon, children) => {
    return {
      key,
      icon,
      children,
      label,
    };
  };
  const menu = [
    getItem(<Link to='/'>DashBoard</Link>, "1", <DesktopOutlined />),
    getItem("Pre-Requisites", "2", <SettingOutlined />, [
      getItem(<Link to="/country">Country</Link>, "2a"),
      getItem("State", "2b"),
      getItem("City", "2c"),
      getItem("Company", "2d"),
      getItem("Users", "2e"),
      getItem("Staff", "2f"),
    ]),
    getItem("Blogs", "3", <PushpinOutlined />, [
      getItem("All Blogs", "3a"),
      getItem("Category", "3b"),
      getItem("Tags", "3c"),
    ]),
    getItem("CMS", "4", <ReadOutlined />, [
      getItem("Pages", "4a"),
      getItem("Menus", "4b"),
      getItem("Header & Footer", "4c"),
    ]),
    getItem("Products", "5", <ShoppingOutlined />, [
      getItem("Products", "5a"),
      getItem("Specification", "5b"),
      getItem("Brand", "5c"),
      getItem("Category", "5d"),
      getItem("Tax", "5f"),
      getItem("Delivery Charge", "5g"),
    ]),
    getItem("Process", "6", <HistoryOutlined />, [
      getItem("Orders", "6a"),
      getItem("Enquiry", "6b"),
      getItem("Reports", "6c"),
    ]),
    getItem("Offers", "7", <GiftOutlined />, [
      getItem("Discounts", "7a"),
      getItem("Offers", "7b"),
      getItem("Coupons", "7c"),
      getItem("Buyer Category", "7d"),
    ]),
    getItem("Logout", "8", <PoweroffOutlined />),
  ];
  const items = [
    {
      label: "My Profile",
      key: "0",
      icon: <UserOutlined />,
    },
    {
      label: "Change Password",
      key: "1",
      icon: <SafetyCertificateOutlined />,
    },
    {
      label: "Logout",
      key: "3",
      icon: <PoweroffOutlined />,
    },
  ];
  return (
    <Router>
      <Layout>
        <Sider
          collapsible
          collapsed={collapsed}
          onCollapse={(value) => setCollapsed(value)}
          className="desktop_menu"
        >
          <div className="demo-logo-vertical" />
          <Menu
            theme="light"
            defaultSelectedKeys={["1"]}
            mode="inline"
            items={menu}
          />
        </Sider>
        <Layout>
          <Header className="header_section">
            <div className="header_align">
              <div className="header_left">
                <div className="header_left_menu">
                  <MobileMenu />
                </div>
                <h4>PAUL</h4>
              </div>
              <div className="header_right">
                <div className="search_head">
                  <Search
                    placeholder="search anything"
                    className="width_300px"
                  />
                </div>
                <div className="menu_list">
                  <div className="items_badges">
                    <BellOutlined />
                    <span className="badge_count blue">5</span>
                  </div>
                  <div className="items_badges">
                    <MailOutlined />
                    <span className="badge_count red">5</span>
                  </div>
                  <div className="my_details">
                    <Dropdown
                      menu={{
                        items,
                      }}
                    >
                      <a onClick={(e) => e.preventDefault()}>
                        <Avatar size={30} icon={<UserOutlined />} />{" "}
                        <MoreOutlined />
                      </a>
                    </Dropdown>
                  </div>
                </div>
              </div>
            </div>
          </Header>
          <Content className="p_25 dynamic_content">
            <DynamicRouter />
          </Content>
          <Footer>©2023 Develop by Paul</Footer>
        </Layout>
      </Layout>
    </Router>
  );
};
export default Dashboard;

import React, { useState } from "react";
import { Button, Popconfirm } from "antd";
import { TableService } from '../Api/TableService'
import TableDynamic from "../Api/TableDynamic";
import BreadcrumbDynamic from "../Api/BreadcrumbDynamic";
import {
  PlusCircleOutlined,
  EditOutlined,
  DeleteOutlined,
} from "@ant-design/icons";
const Country = () => {
  
 const [deleteLoading, setDeleteLoading] = useState(false);
  const [selectedRowKeys, setSelectedRowKeys] = useState([]);
  const [loading, setLoading] = useState(false);

  const onSelectChange = (newSelectedRowKeys) => {
    setSelectedRowKeys(newSelectedRowKeys);
  };
  const rowSelection = {
    selectedRowKeys,
    onChange: onSelectChange,
  };
  
 

  const columns = [
    {
      title: "Name",
      dataIndex: "name",
      ...TableService("name"),
    },
    {
      title: "Age",
      dataIndex: "age",
    },
    {
      title: "Address",
      dataIndex: "address",
    },
    {
      title: "Action",
      dataIndex: "action",
      render: (action) => (
        <div className="action_btn_table">
          <p className=" edit" onClick={() => editAction(action)}>
            <EditOutlined />
          </p>
          <Popconfirm
            title=" Are you Sure to delete?"
            onConfirm={() => deleteAction(action)}
            okButtonProps={{
              loading: deleteLoading,
            }}
          >
            <DeleteOutlined />
          </Popconfirm>
        </div>
      ),
    },
  ];
  const data = [];
for (let i = 0; i < 110; i++) {
  data.push({
    key: i,
    name: `Edward King ${i}`,
    age: 32,
    address: `London, Park Lane no. ${i}`,
  });
  }
  
  const editAction = () => {

  }
  const deleteAction = () => {};

  return (
    <>
      <BreadcrumbDynamic />
      <div className="action_head">
        <Button type="primary" className="action_btn">
          <PlusCircleOutlined /> Add
        </Button>
      </div>
      <TableDynamic rowSelection={rowSelection} columns={columns} data={data} />
    </>
  );
}

export default Country
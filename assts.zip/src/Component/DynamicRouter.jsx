import React, { useLayoutEffect } from "react";
import {
  Routes,
  Route,
  useLocation,
} from "react-router-dom";
import { authRoute } from "../Api/DynamicRouter";
const DynamicRouter = () => {
  const Wrapper = ({ children }) => {
    const location = useLocation();
    useLayoutEffect(() => {
      document.documentElement.scrollTo(500, 0);
    }, [location.pathname]);
    return children;
  };
  return (
    <>
      <Wrapper>
          <Routes>
            {authRoute?.map((e, i) => {
              return (
                <Route exact element={e?.element} path={e?.path} key={i} />
              );
            })}
          </Routes>
        </Wrapper>
      
    </>
  );
};

export default DynamicRouter;

<?php

$title = isset($title) ? $title : '';
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="assets/css/bootstrap_min.css">
  <link rel="stylesheet" href="assets/css/aos_min.css">
  <link rel="stylesheet" href="assets/css/swiper_min.css">
  <link rel="stylesheet" href="assets/css/fafa_icon_min.css">
  <link rel="stylesheet" href="assets/css/animate_min.css">
  <link rel="stylesheet" href="assets/css/mob_menu_min.css">
  <link rel="stylesheet" href="assets/css/gallery_min.css">
  <link rel="stylesheet" href="assets/css/style.css">
  <link rel="stylesheet" href="assets/css/style_media.css">
  <title><?php echo $title; ?></title>
</head>

<body>



  <!--header_section-->

  <header class="header_section">
    <div class="header_top">
      <div class="wrapper">
        <div class="header_top_align">
          <div class="header_top_left">
            <p><a href="tel:+91 9876543210" title="Call Now">+91 9876543210</a>, <a href="tel:+91 987456123" title="Call Now">+91 987456123</a></p>
          </div>
          <div class="header_top_right">
            <ul>
              <li><a href="javascript:void(0)" title="Facebook" target="_blakn">
                  <img src="./assets/images/facebook.png" alt="facebook">
                </a></li>
              <li><a href="javascript:void(0)" title="Twitter" target="_blakn">
                  <img src="./assets/images/twitter.png" alt="twitter">
                </a></li>
              <li><a href="javascript:void(0)" title="Youtube" target="_blakn">
                  <img src="./assets/images/youtube.png" alt="youtube">
                </a></li>
            </ul>
          </div>
        </div>
      </div>
    </div>
    <div class="header_bottom">
      <div id="navbar">
        <div class="wrapper">
          <div class="header_bottom_align">
            <div class="header_bottom_left">
              <a href="./" title="Greaterdhan"><img src="./assets/images/logo.png" alt="Greaterdhan"></a>
            </div>
            <div class="header_bottom_right">
              <div id="cssmenu">
                <ul>
                  <li>
                    <a href="./" title="Home">Home</a>
                  </li>
                  <li>
                    <a href="javascript:void(0)" title="About Us">About Us</a>
                  </li>
                  <li>
                    <a href="javascript:void(0)" title="Services">Services</a>
                  </li>
                  <li>
                    <a href="javascript:void(0)" title="Portfolio">Portfolio</a>
                  </li>
                  <li>
                    <a href="javascript:void(0)" title="Testimonials">Testimonials</a>
                  </li>
                  <li>
                    <a href="javascript:void(0)" title="Blog">Blog</a>
                  </li>
                  <li>
                    <a href="javascript:void(0)" title="Contact us">Contact us</a>
                  </li>
                </ul>
              </div>
              <div class="header_btn">
                <a href="javascript:void(0)" title="Enquiry Now">
                  <button>Enquiry Now</button>
                </a>
              </div>
              <div class="mobile_menu">
                <div id="dl-menu" class="dl-menuwrapper">
                  <button class="dl-trigger"></button>
                  <ul class="dl-menu">
                    <li>
                      <a href="./" title="Home">Home</a>
                    </li>
                    <li>
                      <a href="javascript:void(0)" title="About Us">About Us</a>
                    </li>
                    <li>
                      <a href="javascript:void(0)" title="Services">Services</a>
                    </li>
                    <li>
                      <a href="javascript:void(0)" title="Portfolio">Portfolio</a>
                    </li>
                    <li>
                      <a href="javascript:void(0)" title="Testimonials">Testimonials</a>
                    </li>
                    <li>
                      <a href="javascript:void(0)" title="Blog">Blog</a>
                    </li>
                    <li>
                      <a href="javascript:void(0)" title="Contact us">Contact us</a>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </header>



  <!--header_section-->
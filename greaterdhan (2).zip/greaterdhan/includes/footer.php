 <!--footer_section-->

 <footer class="footer_section">
   <div class="wrapper">
     <div class="footer_align">
       <div class="footer_1">
         <img src="./assets/images/logo.png" alt="Greaterdhan" data-aos="fade-up">
         <p data-aos="fade-up">We provide cost-effective digital marketing services for startups and businesses ranging from web development and search engine optimization to pay per click advertising and social media optimization. For the best digital marketing services</p>
         <div class="footer_right">
           <div data-aos="fade-up">
             <img src="./assets/images/f1.png" alt="facebook">
           </div>
           <div data-aos="fade-up">
             <img src="./assets/images/f2.png" alt="twitter">
           </div>
           <div data-aos="fade-up">
             <img src="./assets/images/f3.png" alt="youtube">
           </div>
         </div>
       </div>
       <div class="footer_2">
         <h4 data-aos="fade-up">Quick Links</h4>
         <ul>
           <li data-aos="fade-up"><a href="javascript:void(0)" title="About Us">About Us</a></li>
           <li data-aos="fade-up"><a href="javascript:void(0)" title="Services">Services</a></li>
           <li data-aos="fade-up"><a href="javascript:void(0)" title="Portfolio">Portfolio</a></li>
           <li data-aos="fade-up"><a href="javascript:void(0)" title="Testimonials">Testimonials</a></li>
           <li data-aos="fade-up"><a href="javascript:void(0)" title="Blog">Blog</a></li>
           <li data-aos="fade-up"><a href="javascript:void(0)" title="Contact us">Contact us</a></li>
         </ul>
       </div>
       <div class="footer_3">
         <h4 data-aos="fade-up">Services</h4>
         <ul>
           <li data-aos="fade-up"><a href="javascript:void(0)" title="Website Design">Website Design</a></li>
           <li data-aos="fade-up"><a href="javascript:void(0)" title="Digital Marketing">Digital Marketing</a></li>
           <li data-aos="fade-up"><a href="javascript:void(0)" title="Search Engine Optimization">Search Engine Optimization</a></li>
           <li data-aos="fade-up"><a href="javascript:void(0)" title="Social Media Marketing">Social Media Marketing</a></li>
           <li data-aos="fade-up"><a href="javascript:void(0)" title="Google Ads">Google Ads</a></li>
           <li data-aos="fade-up"><a href="javascript:void(0)" title="Content Writing">Content Writing</a></li>
         </ul>
       </div>
       <div class="footer_4">
         <h4 data-aos="fade-up">Industry We Serve</h4>
         <ul>
           <li data-aos="fade-up"><a href="javascript:void(0)" title="Retail">Retail</a></li>
           <li data-aos="fade-up"><a href="javascript:void(0)" title="Manufacturing">Manufacturing</a></li>
           <li data-aos="fade-up"><a href="javascript:void(0)" title="E Commerce">E Commerce</a></li>
           <li data-aos="fade-up"><a href="javascript:void(0)" title="Technology">Technology</a></li>
           <li data-aos="fade-up"><a href="javascript:void(0)" title="Banking">Banking</a></li>
           <li data-aos="fade-up"><a href="javascript:void(0)" title="Healthcare">Healthcare</a></li>
         </ul>
       </div>
     </div>

   </div>
   <div class="copy_text">
     <p>Copyrights@greaterdhan2023</p>
   </div>
 </footer>


 <!--footer_section-->

 <script src="assets/js/jquery_min.js"></script>
 <script src="assets/js/bootstrap_min.js"></script>
 <script src="assets/js/desk_menu_min.js"></script>
 <script src="assets/js/aos_min.js"></script>
 <script src="assets/js/swiper_min.js"></script>
 <script src="assets/js/modernizr_min.js"></script>
 <script src="assets/js/mob_menu_min.js"></script>
 <script src="assets/js/gallery_min.js"></script>
 <script src="assets/js/website_script.js"></script>
 </body>

 </html>
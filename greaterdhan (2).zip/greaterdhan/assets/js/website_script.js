

(function($) {
  'use strict';
    $(window).on('load', function() {
        //$(".loader").fadeOut();
        //$("#preloder").delay(200).fadeOut("slow");
		$(".loader_img").fadeOut();
        $(".loading-bar").fadeOut();
        $("#preloder").delay(200).fadeOut("slow");
    });
})(jQuery);




  //OnScroll Animation
  window.addEventListener('load', () => {
    AOS.init({
      duration: 1000,
      easing: "ease-in-out",
      once: true,
      mirror: false, 
      disable: function() {
        var maxWidth = 800;
        return window.innerWidth < maxWidth;
      }
    });
  });
  
  // Swiper: Home Banner Slider
new Swiper(".slider_section", {
  loop: false,
  speed: 1000,
  slidesPerView: 1,
  effect: "fade", // coverflow cube fade
  //  parallax: true,
  paginationClickable: true,
  spaceBetween: 0,
  autoplay: {
    delay: 5000,
    disableOnInteraction: false,
  },
  watchSlidesProgress: true,
  // navigation: {
  //     nextEl: '.h_banner_slider_next',
  //     prevEl: '.h_banner_slider_prev',
  // },
  pagination: {
    el: ".home_slider_pagination",
    clickable: true,
  },
  breakpoints: {
    1920: {
      slidesPerView: 1,
      spaceBetween: 0,
    },
    1028: {
      slidesPerView: 1,
      spaceBetween: 0,
    },
    768: {
      slidesPerView: 1,
      parallax: false,
      spaceBetween: 0,
    },
  },
});


//

 // Swiper: Home Banner Slider
new Swiper(".tech_slider", {
  loop: false,
  speed: 1000,
  slidesPerView: 6,
  effect: "slide", // coverflow cube fade
  //  parallax: true,
  paginationClickable: true,
  spaceBetween: 55,
  autoplay: {
    delay: 3000,
    disableOnInteraction: false,
  },
  watchSlidesProgress: true,
  // navigation: {
  //     nextEl: '.h_banner_slider_next',
  //     prevEl: '.h_banner_slider_prev',
  // },
  pagination: {
    el: ".brands_slider_pagination",
    clickable: true,
  },
  breakpoints: {
    1920: {
      slidesPerView: 6,
      spaceBetween: 55,
    },
    1028: {
      slidesPerView: 6,
      spaceBetween: 35,
    },
    768: {
      slidesPerView: 4,
      parallax: false,
      spaceBetween: 15,
    },
    580: {
      slidesPerView: 3,
      parallax: false,
      spaceBetween: 15,
    },
    320: {
      slidesPerView: 2,
      parallax: false,
      spaceBetween: 15,
    },
  },
});

//
 // Swiper: Home Banner Slider
new Swiper(".gerstarted_slider", {
  loop: false,
  speed: 1000,
  slidesPerView: 4,
  effect: "slide", // coverflow cube fade
  //  parallax: true,
  paginationClickable: true,
  spaceBetween: 30,
  autoplay: {
    delay: 3500,
    disableOnInteraction: false,
  },
  watchSlidesProgress: true,
  // navigation: {
  //     nextEl: '.h_banner_slider_next',
  //     prevEl: '.h_banner_slider_prev',
  // },
  pagination: {
    el: ".gerstarted_slider_pagination",
    clickable: true,
  },
  breakpoints: {
    1920: {
      slidesPerView: 4,
      spaceBetween: 30,
    },
    1028: {
      slidesPerView: 4,
      spaceBetween: 30,
    },
    768: {
      slidesPerView: 3,
      parallax: false,
      spaceBetween: 30,
    },
    480: {
      slidesPerView: 2,
      parallax: false,
      spaceBetween: 30,
    },
    320: {
      slidesPerView: 1,
      parallax: false,
      spaceBetween: 30,
    },
  },
});


//

 // Swiper: Home Banner Slider
new Swiper(".portfolio_slider", {
  loop: false,
  speed: 1000,
  slidesPerView: 3,
  effect: "slide", // coverflow cube fade
  //  parallax: true,
  paginationClickable: true,
  spaceBetween: 30,
  autoplay: {
    delay: 3000,
    disableOnInteraction: false,
  },
  watchSlidesProgress: true,
  // navigation: {
  //     nextEl: '.h_banner_slider_next',
  //     prevEl: '.h_banner_slider_prev',
  // },
  pagination: {
    el: ".porfolio_slider_pagination",
    clickable: true,
  },
  breakpoints: {
    1920: {
      slidesPerView: 3,
      spaceBetween: 30,
    },
    1028: {
      slidesPerView: 3,
      spaceBetween: 30,
    },
    768: {
      slidesPerView: 2,
      parallax: false,
      spaceBetween: 30,
    },
    580: {
      slidesPerView: 2,
      parallax: false,
      spaceBetween: 30,
    },
    320: {
      slidesPerView: 1,
      parallax: false,
      spaceBetween: 30,
    },
  },
});

//

// Swiper: Home Banner Slider
new Swiper(".testi_slider", {
  loop: false,
  speed: 1000,
  slidesPerView: 3,
  effect: "slide", // coverflow cube fade
  //  parallax: true,
  paginationClickable: true,
  spaceBetween: 30,
  autoplay: {
    delay: 3000,
    disableOnInteraction: false,
  },
  watchSlidesProgress: true,
  // navigation: {
  //     nextEl: '.h_banner_slider_next',
  //     prevEl: '.h_banner_slider_prev',
  // },
  pagination: {
    el: ".testi_slider_pagination",
    clickable: true,
  },
  breakpoints: {
    1920: {
      slidesPerView: 3,
      spaceBetween: 30,
    },
    1028: {
      slidesPerView: 3,
      spaceBetween: 30,
    },
    768: {
      slidesPerView: 2,
      parallax: false,
      spaceBetween: 20,
    },
    580: {
      slidesPerView: 2,
      parallax: false,
      spaceBetween: 20,
    },
    320: {
      slidesPerView: 1,
      parallax: false,
      spaceBetween: 30,
    },
  },
});


  //

 


// $(document).ready(function(){

// $(function() {
//   var Accordion = function(el, multiple) {
//       this.el = el || {};
//       this.multiple = multiple || false;

//       var links = this.el.find('.faq_question');
//       links.on('click', {
//           el: this.el,
//           multiple: this.multiple
//       }, this.dropdown)
//   }

//   Accordion.prototype.dropdown = function(e) {
//       var $el = e.data.el;
//       $this = $(this),
//           $next = $this.next();

//       $next.slideToggle();
//       $this.parent().toggleClass('faq_open');

//       if (!e.data.multiple) {
//           $el.find('.faq_answer').not($next).slideUp().parent().removeClass('faq_open');
//       };
//   }
//   var accordion = new Accordion($('.faq_section_page'), false);
// });
// });
// //

// //Sticky Navbar

(function($) {
  "use strict";
  var $navbar = $("#navbar"),
  y_pos = $navbar.offset().top,
  height = $navbar.height();
  $(document).scroll(function() {
  var scrollTop = $(this).scrollTop();
  if (scrollTop > y_pos + height) {
  $navbar.addClass("navbar-fixed").animate({
  top: 0
  });
  } else if (scrollTop <= y_pos) {
  $navbar.removeClass("navbar-fixed").clearQueue().animate({
  top: "-48px"
  }, 0);
  }
  });
  })(jQuery, undefined);

  //






// //Mob Menu

$(function() {
	$( '#dl-menu' ).dlmenu({
		animationClasses : { classin : 'dl-animate-in-5', classout : 'dl-animate-out-5' }
	});
});

// //

$('.dl-menuwrapper li a').click(function(e) {
       $('#dl-menu').dlmenu('closeMenu');
   });
  




//

// Swiper: Home Banner Slider
new Swiper(".pro_slider", {
  loop: true,
  speed: 1000,
  slidesPerView: 2,
  effect: "slide", // coverflow cube fade
  //  parallax: true,
  paginationClickable: true,
  spaceBetween: 40,
  autoplay: {
    delay: 10000,
    disableOnInteraction: false,
  },
  watchSlidesProgress: true,
  // navigation: {
  //     nextEl: '.h_banner_slider_next',
  //     prevEl: '.h_banner_slider_prev',
  // },
  pagination: {
    el: ".pro_slider_pagination",
    clickable: true,
  },
  breakpoints: {
    1920: {
      slidesPerView: 2,
      spaceBetween: 40,
    },
    1028: {
      slidesPerView: 2,
      spaceBetween: 40,
    },
    768: {
      slidesPerView: 1,
      parallax: false,
      spaceBetween: 20,
    },
    480: {
      slidesPerView: 1,
      parallax: false,
      spaceBetween: 20,
    },
    320: {
      slidesPerView: 1,
      parallax: false,
      spaceBetween: 20,
    },
  },
});

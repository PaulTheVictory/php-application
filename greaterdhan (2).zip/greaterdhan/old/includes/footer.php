 <!--footer_section-->

 <footer class="footer_section">
   <div class="wrapper">
     <div class="footer_align">
       <div class="footer_top">
         <div class="footer_left">
           <img src="./assets/images/logo.png" alt="Greaterdhan">
         </div>
         <div class="footer_right">
           <div>
             <img src="./assets/images/f1.png" alt="facebook">
           </div>
           <div>
             <img src="./assets/images/f2.png" alt="twitter">
           </div>
           <div>
             <img src="./assets/images/f3.png" alt="youtube">
           </div>
         </div>
       </div>

     </div>
     <div class="footer_bottom">
       <ul>
         <li><a href="javascript:void(0)" title="About us">About us</a></li>
         <li><a href="javascript:void(0)" title="Services">Services</a></li>
         <li><a href="javascript:void(0)" title="Portfolio">Portfolio</a></li>
         <li><a href="javascript:void(0)" title="Testimonials">Testimonials</a></li>
         <li><a href="javascript:void(0)" title="Blog">Blog</a></li>
         <li><a href="javascript:void(0)" title="Contact us">Contact us</a></li>
       </ul>
     </div>
   </div>
 </footer>


 <!--footer_section-->

 <script src="assets/js/jquery_min.js"></script>
 <script src="assets/js/bootstrap_min.js"></script>
 <script src="assets/js/desk_menu_min.js"></script>
 <script src="assets/js/aos_min.js"></script>
 <script src="assets/js/swiper_min.js"></script>
 <script src="assets/js/modernizr_min.js"></script>
 <script src="assets/js/mob_menu_min.js"></script>
 <script src="assets/js/gallery_min.js"></script>
 <script src="assets/js/website_script.js"></script>
 </body>

 </html>
<?php
$title = 'Greaterdhan';
include('includes/header.php');
?>

<!--slider_section-->


<section class="slider_section">
  <div class="swiper-wrapper">
    <div class="swiper-slide">
      <div class="slider_box">
        <div class="slider_box_left">
          <h2>We create exceptional<br />
            apps & websites for business that</h2>
          <h4>translate into business growth</h4>
          <div class="slide_btn">
            <a href="javascipt:void(0)" title="Book an Appointment">
              <button>Book an Appointment</button>
            </a>
            <a href="javascipt:void(0)" title="Our Work">
              <button>Our Work</button>
            </a>
          </div>
          <span>Maximum Responce time is 30 min</span>
        </div>
        <div class="slider_box_right">
          <img src="./assets/images/banner.png" alt="translate into business growth" class="desktop">
          <img src="./assets/images/mobile.png" alt="translate into business growth" class="mobile">
        </div>
      </div>
    </div>
  </div>
</section>


<!--slider_section-->


<!--webservice_section-->

<section class="webservice_section">
  <div class="wrapper">
    <div class="webservice_align">
      <div class="webservice_left">
        <ul>
          <li>
            <img src="./assets//images/w1.png" alt="webservice">
          </li>
          <li>
            <img src="./assets//images/w2.png" alt="webservice">
          </li>
          <li>
            <img src="./assets//images/w3.png" alt="webservice">
          </li>
          <li>
            <img src="./assets//images/w4.png" alt="webservice">
          </li>
        </ul>
      </div>
      <div class="webservice_right">
        <p>Delivering Excellence in every way possible with extensive partnerships across different verticals of Digital Marketing.</p>
      </div>
    </div>
  </div>
</section>

<!--webservice_section-->



<!--aboutus_section-->


<section class="aboutus_section">
  <div class="wrapper">
    <div class="aboutus_align">
      <div class="aboutus_left">
        <div class="head_text">
          <h4>ABOUT US</h4>
          <h1>Beautifully designed,<br>
            <span>user-centered</span> experiences<br>
            <span>that</span> achieve business goals
          </h1>
        </div>
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum</p>
      </div>
      <div class="aboutus_right">
        <img src="./assets/images/about.png" alt="ABOUT US">
      </div>
    </div>
  </div>
</section>


<!--aboutus_section-->



<!--service_offer-->


<section class="service_offer">
  <div class="wrapper">
    <div class="head_text">
      <h4>SERVICES</h4>
      <h2>Services We <span>Offer</span></h2>
    </div>
    <div class="service_align">
      <div class="service_box">
        <img src="./assets/images/s1.png" alt="">
        <h4>WEBSITE DEVELOPMENT</h4>
        <p>It involves building and maintaining the websites; it makes the website look great, works quickly with firm user experience.</p>
        <a href="javascript:void(0)" title="Learn More">
          <button>Learn More</button>
        </a>
      </div>
      <div class="service_box">
        <img src="./assets/images/s2.png" alt="">
        <h4>DIGITAL MARKETING</h4>
        <p>It involves building and maintaining the websites; it makes the website look great, works quickly with firm user experience.</p>
        <a href="javascript:void(0)" title="Learn More">
          <button>Learn More</button>
        </a>
      </div>
      <div class="service_box">
        <img src="./assets/images/s3.png" alt="">
        <h4>BRANDING</h4>
        <p>It involves building and maintaining the websites; it makes the website look great, works quickly with firm user experience.</p>
        <a href="javascript:void(0)" title="Learn More">
          <button>Learn More</button>
        </a>
      </div>
      <div class="service_box">
        <img src="./assets/images/s1.png" alt="">
        <h4>WEBSITE DEVELOPMENT</h4>
        <p>It involves building and maintaining the websites; it makes the website look great, works quickly with firm user experience.</p>
        <a href="javascript:void(0)" title="Learn More">
          <button>Learn More</button>
        </a>
      </div>
      <div class="service_box">
        <img src="./assets/images/s2.png" alt="">
        <h4>DIGITAL MARKETING</h4>
        <p>It involves building and maintaining the websites; it makes the website look great, works quickly with firm user experience.</p>
        <a href="javascript:void(0)" title="Learn More">
          <button>Learn More</button>
        </a>
      </div>
      <div class="service_box">
        <img src="./assets/images/s3.png" alt="">
        <h4>BRANDING</h4>
        <p>It involves building and maintaining the websites; it makes the website look great, works quickly with firm user experience.</p>
        <a href="javascript:void(0)" title="Learn More">
          <button>Learn More</button>
        </a>
      </div>
    </div>
  </div>
</section>


<!--service_offer-->


<!--weserve_section-->

<section class="weserve_section">
  <div class="wrapper">
    <div class="head_text">
      <h4>WIDE RANGE</h4>
      <h2><span>Industries</span> We Serve</h2>
    </div>
    <div class="weserve_align">
      <div class="weserve_box">
        <img src="./assets/images/we1.png" alt="E Commerce">
        <h4>E Commerce</h4>
      </div>
      <div class="weserve_box">
        <img src="./assets/images/we2.png" alt="Technology">
        <h4>Technology</h4>
      </div>
      <div class="weserve_box">
        <img src="./assets/images/we3.png" alt="Education">
        <h4>Education</h4>
      </div>
      <div class="weserve_box">
        <img src="./assets/images/we4.png" alt="Healthcare">
        <h4>Healthcare</h4>
      </div>
      <div class="weserve_box">
        <img src="./assets/images/we5.png" alt="Banking">
        <h4>Banking</h4>
      </div>
      <div class="weserve_box">
        <img src="./assets/images/we6.png" alt="Logistics">
        <h4>Logistics</h4>
      </div>
      <div class="weserve_box">
        <img src="./assets/images/we7.png" alt="Travel">
        <h4>Travel</h4>
      </div>
      <div class="weserve_box">
        <img src="./assets/images/we8.png" alt="Manufacturing">
        <h4>Manufacturing</h4>
      </div>
    </div>

    <div class="technologies">
      <div class="technologies_left">
        <div class="head_text">
          <h2><span>Technologies</span><br>
            We Use </h2>
        </div>
      </div>
      <div class="technologies_right">
        <div class="tech_slider">
          <div class="swiper-wrapper">
            <div class="w_item swiper-slide">
              <img src="./assets/images/i1.png" alt="Technologies">
            </div>
            <div class="w_item swiper-slide">
              <img src="./assets/images/i2.png" alt="Technologies">
            </div>
            <div class="w_item swiper-slide">
              <img src="./assets/images/i3.png" alt="Technologies">
            </div>
            <div class="w_item swiper-slide">
              <img src="./assets/images/i4.png" alt="Technologies">
            </div>
            <div class="w_item swiper-slide">
              <img src="./assets/images/i5.png" alt="Technologies">
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<!--weserve_section-->


<!--portfolio_section-->


<section class="portfolio_section">
  <div class="wrapper">
    <div class="head_text">
      <h4>PORTFOLIO</h4>
      <h2>Projects <span>We Cherish</span></h2>
    </div>
    <div class="portfolio_align">
      <div class="portfolio_slider">
        <div class="swiper-wrapper">


          <div class="portfolio_box swiper-slide">
            <div class="portfolio_box_top">
              <div class="portfolio_box_left">
                <h4>Jyothis Food</h4>
                <p>Corporate Identity, Webdeisgn, SEO</p>
              </div>
              <div class="portfolio_box_right">
                <img src="./assets/images/ps1.png" alt="Jyothis Food">
              </div>

            </div>
            <img src="./assets/images/pm1.png" alt="Jyothis Food">
          </div>
          <div class="portfolio_box swiper-slide">
            <div class="portfolio_box_top">
              <div class="portfolio_box_left">
                <h4>GB Pack</h4>
                <p>Webdeisgn, SEO</p>
              </div>
              <div class="portfolio_box_right">
                <img src="./assets/images/ps2.png" alt="GB Pack" class="height">
              </div>

            </div>
            <img src="./assets/images/pm2.png" alt="GB Pack">
          </div>
          <div class="portfolio_box swiper-slide">
            <div class="portfolio_box_top">
              <div class="portfolio_box_left">
                <h4>Naatu Sakkarai</h4>
                <p>Webdeisgn, SEO</p>
              </div>
              <div class="portfolio_box_right">
                <img src="./assets/images/ps3.png" alt="Naatu Sakkarai">
              </div>

            </div>
            <img src="./assets/images/pm3.png" alt="Naatu Sakkarai">
          </div>
        </div>
      </div>
    </div>
  </div>
</section>


<!--portfolio_section-->



<!--projects_section-->

<section class="projects_section">
  <div class="wrapper">
    <div class="projects_align">
      <div class="projects_box">
        <h4 class="plus">5</h4>
        <p>Years Experience</p>
      </div>
      <div class="projects_box">
        <h4 class="plus">100</h4>
        <p>Completed Projects </p>
      </div>
      <div class="projects_box">
        <h4 class="plus">10</h4>
        <p>Techies</p>
      </div>
      <div class="projects_box">
        <h4>200</h4>
        <p>Happy Clients</p>
      </div>
    </div>
  </div>
</section>

<!--projects_section-->



<!--clients_section-->


<section class="clients_section">
  <div class="wrapper">
    <div class="head_text">
      <h4>Clients</h4>
      <h2><span>Our</span> Happy Clients</h2>
    </div>
    <div class="clients_align">
      <div class="clients_box">
        <img src="./assets/images/ps1.png" alt="Happy Clients">
      </div>
      <div class="clients_box">
        <img src="./assets/images/ps2.png" alt="Happy Clients">
      </div>
      <div class="clients_box">
        <img src="./assets/images/ps3.png" alt="Happy Clients">
      </div>
      <div class="clients_box">
        <img src="./assets/images/ps1.png" alt="Happy Clients">
      </div>
      <div class="clients_box">
        <img src="./assets/images/ps1.png" alt="Happy Clients">
      </div>
      <div class="clients_box">
        <img src="./assets/images/ps2.png" alt="Happy Clients">
      </div>
      <div class="clients_box">
        <img src="./assets/images/ps3.png" alt="Happy Clients">
      </div>
      <div class="clients_box">
        <img src="./assets/images/ps1.png" alt="Happy Clients">
      </div>
      <div class="clients_box">
        <img src="./assets/images/ps1.png" alt="Happy Clients">
      </div>
      <div class="clients_box">
        <img src="./assets/images/ps2.png" alt="Happy Clients">
      </div>
      <div class="clients_box">
        <img src="./assets/images/ps3.png" alt="Happy Clients">
      </div>
      <div class="clients_box">
        <img src="./assets/images/ps1.png" alt="Happy Clients">
      </div>
    </div>
  </div>
</section>


<!--clients_section-->




<!--testimonials_section-->

<section class="testimonials_section">
  <div class="wrapper">
    <div class="head_text">
      <h4>Clients</h4>
      <h2><span>Our</span> Happy Clients</h2>
    </div>
    <div class="testimonials_align">
      <div class="testi_slider">
        <div class="swiper-wrapper">
          <div class="swiper-slide">
            <div class="testimonials_box">
              <div class="profile">
                <div class="profile_left">
                  <img src="./assets/images/t1.png" alt="profile">
                </div>
                <div class="profile_right">
                  <h4>Mr.Rakesh Walas</h4>
                  <img src="./assets/images/star.png" alt="star">
                </div>
              </div>
              <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. D</p>
            </div>
          </div>
          <div class="swiper-slide">
            <div class="testimonials_box">
              <div class="profile">
                <div class="profile_left">
                  <img src="./assets/images/t2.png" alt="profile">
                </div>
                <div class="profile_right">
                  <h4>Mr.Rakesh Walas</h4>
                  <img src="./assets/images/star.png" alt="star">
                </div>
              </div>
              <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. D</p>
            </div>
          </div>
          <div class="swiper-slide">
            <div class="testimonials_box">
              <div class="profile">
                <div class="profile_left">
                  <img src="./assets/images/t3.png" alt="profile">
                </div>
                <div class="profile_right">
                  <h4>Mr.Rakesh Walas</h4>
                  <img src="./assets/images/star.png" alt="star">
                </div>
              </div>
              <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. D</p>
            </div>
          </div>
          <div class="swiper-slide">
            <div class="testimonials_box">
              <div class="profile">
                <div class="profile_left">
                  <img src="./assets/images/t3.png" alt="profile">
                </div>
                <div class="profile_right">
                  <h4>Mr.Rakesh Walas</h4>
                  <img src="./assets/images/star.png" alt="star">
                </div>
              </div>
              <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. D</p>
            </div>
          </div>
          <div class="swiper-slide">
            <div class="testimonials_box">
              <div class="profile">
                <div class="profile_left">
                  <img src="./assets/images/t3.png" alt="profile">
                </div>
                <div class="profile_right">
                  <h4>Mr.Rakesh Walas</h4>
                  <img src="./assets/images/star.png" alt="star">
                </div>
              </div>
              <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. D</p>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="testi_slider_pagination"></div>
  </div>
</section>

<!--testimonials_section-->


<!--contact_form_section-->

<section class="contact_form_section">
  <div class="contact_bg">
    <img src="./assets/images/form.png" alt="Contact Form">
  </div>
  <div class="wrapper">
    <div class="head_text">
      <h4>Contact Form</h4>
      <h2><span>Share</span> Your Queries</h2>
    </div>
    <div class="contactform_align">
      <div class="contactform_left">
        <form action="">
          <input type="text" placeholder="Name" name="" id="">
          <input type="text" placeholder="Email" name="" id="">
          <input type="text" placeholder="Phone Number" name="" id="">
          <textarea name="" id="" placeholder="Message"></textarea>
          <button type="submit">Submit</button>
        </form>
      </div>
    </div>
  </div>
</section>

<!--contact_form_section-->




<!--getintouch_section-->


<section class="getintouch_section">
  <div class="wrapper">
    <div class="head">
      <h2>Be <span>Greaterdhan</span></h2>
      <h3>Any one Else</h3>
    </div>
    <div class="getintouch_align">
      <div class="getintouch_left">
        <h4>Get in touch With Us</h4>
        <p class="address">
          No 2/9, Nehru Street, RK Pudhur,<br>
          Coimbatore, Tamil Nadu 600100</p>
        <p class="phone">+91-9876543210<br> +91-9876543210</p>
        <p class="mail">contact@greaterdhan.com</p>
      </div>
      <div class="getintouch_right">
        <img src="./assets/images/maps.png" alt="Our Location">
      </div>
    </div>
  </div>
</section>


<!--getintouch_section-->

































<?php

include('includes/footer.php');
?>
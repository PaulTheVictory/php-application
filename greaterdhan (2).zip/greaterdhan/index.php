<?php
$title = 'Greaterdhan';
include('includes/header.php');
?>

<!--slider_section-->


<section class="slider_section">
  <div class="swiper-wrapper">
    <div class="swiper-slide">
      <div class="slider_box">
        <div class="slider_box_left">
          <h2>We create exceptional<br />
            apps & websites for business that</h2>
          <h4>translate into business growth</h4>
          <div class="slide_btn">
            <a href="javascipt:void(0)" title="Book an Appointment">
              <button>Book an Appointment</button>
            </a>
            <a href="javascipt:void(0)" title="Our Work">
              <button>Our Work</button>
            </a>
          </div>
          <span>Maximum Responce time is 30 min</span>
        </div>
        <div class="slider_box_right">
          <img src="./assets/images/banner.png" alt="translate into business growth" class="desktop">
          <img src="./assets/images/mobile.png" alt="translate into business growth" class="mobile">
        </div>
      </div>
    </div>
    <div class="swiper-slide">
      <div class="slider_box">
        <div class="slider_box_left">
          <h2>Premium Websites<br />
            Starting @ <text>Rs.20000</text> Only</h2>
          <div class="slide_btn">
            <a href="javascipt:void(0)" title="Book an Appointment">
              <button>Book an Appointment</button>
            </a>
            <a href="javascipt:void(0)" title="Our Work">
              <button>Our Work</button>
            </a>
          </div>
          <span>Maximum Responce time is 30 min</span>
        </div>
        <div class="slider_box_right">
          <img src="./assets/images/banner1.png" alt="translate into business growth" class="desktop">
          <img src="./assets/images/banner1.png" alt="translate into business growth" class="mobile">
        </div>
      </div>
    </div>
  </div>
</section>


<!--slider_section-->


<!--webservice_section-->

<section class="webservice_section">
  <div class="wrapper">
    <div class="webservice_align">
      <div class="webservice_left">
        <ul>
          <li data-aos="fade-right">
            <img src="./assets/images/w1.png" alt="webservice">
          </li>
          <li data-aos="fade-right">
            <img src="./assets/images/w2.png" alt="webservice">
          </li>
          <li data-aos="fade-right">
            <img src="./assets/images/w3.png" alt="webservice">
          </li>
          <li data-aos="fade-right">
            <img src="./assets/images/w4.png" alt="webservice">
          </li>
        </ul>
      </div>
      <div class="webservice_right">
        <p data-aos="fade-left">Delivering Excellence in every way possible with extensive partnerships across different verticals of Digital Marketing.</p>
      </div>
    </div>
  </div>
</section>

<!--webservice_section-->



<!--aboutus_section-->


<section class="aboutus_section">
  <div class="wrapper">
    <div class="aboutus_align">
      <div class="aboutus_left">
        <div class="head_text">
          <h4 data-aos="fade-right">ABOUT US</h4>
          <h1 data-aos="fade-right">Beautifully designed,<br>
            <span>user-centered</span> experiences<br>
            <span>that</span> achieve business goals
          </h1>
        </div>
        <p data-aos="fade-right">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum</p>
      </div>
      <div class="aboutus_right">
        <img src="./assets/images/about.png" alt="ABOUT US" data-aos="fade-left">
      </div>
    </div>
  </div>
</section>


<!--aboutus_section-->



<!--service_offer-->


<section class="service_offer">
  <div class="wrapper">
    <div class="head_text">
      <h4 data-aos="fade-up">SERVICES</h4>
      <h2 data-aos="fade-up">Services We <span>Offer</span></h2>
    </div>
    <div class="service_align">
      <div class="service_box" data-aos="fade-up" data-aos-duration="1000">
        <img src="./assets/images/s1.png" alt="WEBSITE DEVELOPMENT">
        <h4>WEBSITE DEVELOPMENT</h4>
        <p>It involves building and maintaining the websites; it makes the website look great, works quickly with firm user experience.</p>
        <a href="javascript:void(0)" title="Learn More">
          <button>Learn More</button>
        </a>
      </div>
      <div class="service_box" data-aos="fade-up" data-aos-duration="1000">
        <img src="./assets/images/s2.png" alt="SEO">
        <h4>SEO</h4>
        <p>It is a strategy that uses multiple channels to attract engage and convert customers online.</p>
        <a href="javascript:void(0)" title="Learn More">
          <button>Learn More</button>
        </a>
      </div>
      <div class="service_box" data-aos="fade-up" data-aos-duration="1000">
        <img src="./assets/images/s3.png" alt="SOCIAL MEDIA MARKETING">
        <h4>SOCIAL MEDIA
          MARKETING</h4>
        <p>It increases the user experience and customer satisfaction, which ultimately increases the number of customers, resulting in the growth of the business.</p>
        <a href="javascript:void(0)" title="Learn More">
          <button>Learn More</button>
        </a>
      </div>
      <div class="service_box" data-aos="fade-up" data-aos-duration="1000">
        <img src="./assets/images/s4.png" alt="GOOGLE ADS">
        <h4>GOOGLE ADS</h4>
        <p>
          It involves building and maintaining the websites; it makes the website look great, works quickly with firm user experience.</p>
        <a href="javascript:void(0)" title="Learn More">
          <button>Learn More</button>
        </a>
      </div>
      <div class="service_box" data-aos="fade-up" data-aos-duration="1000">
        <img src="./assets/images/s5.png" alt="YOUTUBE ADS">
        <h4>YOUTUBE ADS</h4>
        <p>
          It is a strategy that uses multiple channels to attract engage and convert customers online.</p>
        <a href="javascript:void(0)" title="Learn More">
          <button>Learn More</button>
        </a>
      </div>
      <div class="service_box" data-aos="fade-up" data-aos-duration="1000">
        <img src="./assets/images/s6.png" alt="BRANDING">
        <h4>BRANDING</h4>
        <p>
          It increases the user experience and customer satisfaction, which ultimately increases the number of customers, resulting in the growth of the business.</p>
        <a href="javascript:void(0)" title="Learn More">
          <button>Learn More</button>
        </a>
      </div>
    </div>
  </div>
</section>


<!--service_offer-->


<!--weserve_section-->

<section class="weserve_section">
  <div class="wrapper">
    <div class="head_text">
      <h4 data-aos="fade-up">WIDE RANGE</h4>
      <h2 data-aos="fade-up"><span>Industries</span> We Serve</h2>
    </div>
    <div class="weserve_align">
      <div class="weserve_box" data-aos="fade-up">
        <img src="./assets/images/we1.png" alt="E Commerce">
        <h4>E Commerce</h4>
      </div>
      <div class="weserve_box" data-aos="fade-up">
        <img src="./assets/images/we2.png" alt="Technology">
        <h4>Technology</h4>
      </div>
      <div class="weserve_box" data-aos="fade-up">
        <img src="./assets/images/we3.png" alt="Education">
        <h4>Education</h4>
      </div>

      <div class="weserve_box" data-aos="fade-up">
        <img src="./assets/images/we4.png" alt="Healthcare">
        <h4>Healthcare</h4>
      </div>
      <div class="weserve_box" data-aos="fade-up">
        <img src="./assets/images/we9.png" alt="Food and Catering">
        <h4>Food and Catering</h4>
      </div>
      <div class="weserve_box" data-aos="fade-up">
        <img src="./assets/images/we5.png" alt="Banking">
        <h4>Banking</h4>
      </div>
      <div class="weserve_box" data-aos="fade-up">
        <img src="./assets/images/we6.png" alt="Logistics">
        <h4>Logistics</h4>
      </div>
      <div class="weserve_box" data-aos="fade-up">
        <img src="./assets/images/we7.png" alt="Travel">
        <h4>Travel</h4>
      </div>
      <div class="weserve_box" data-aos="fade-up">
        <img src="./assets/images/we8.png" alt="Manufacturing">
        <h4>Manufacturing</h4>
      </div>
      <div class="weserve_box" data-aos="fade-up">
        <img src="./assets/images/we10.png" alt="Construction &
Real estate">
        <h4>Construction &
          Real estate</h4>
      </div>
    </div>


  </div>
</section>

<!--weserve_section-->


<!--technology_section-->

<section class="technology_section">
  <div class="wrapper">
    <div class="head_text">
      <h4 data-aos="fade-up">Technologies</h4>
      <h2 data-aos="fade-up">Technologies <span>we use</span></h2>
    </div>
    <ul class="tech_slider">
      <div class="swiper-wrapper">
        <li class="swiper-slide" data-aos="fade-up">
          <img src="./assets/images/tech/react.png" alt="Our Tech">
          <h4>REACT JS</h4>
        </li>
        <li class="swiper-slide" data-aos="fade-up">
          <img src="./assets/images/tech/html.png" alt="Our Tech">
          <h4>HTML</h4>
        </li>
        <li class="swiper-slide" data-aos="fade-up">
          <img src="./assets/images/tech/css.png" alt="Our Tech">
          <h4>CSS</h4>
        </li>
        <li class="swiper-slide" data-aos="fade-up">
          <img src="./assets/images/tech/js.png" alt="Our Tech">
          <h4>JAVASCRIPT</h4>
        </li>
        <li class="swiper-slide" data-aos="fade-up">
          <img src="./assets/images/tech/jquery.png" alt="Our Tech">
          <h4>JQUERY</h4>
        </li>
        <li class="swiper-slide" data-aos="fade-up">
          <img src="./assets/images/tech/bootstrap.png" alt="Our Tech">
          <h4>BOOTSTRAP</h4>
        </li>
        <li class="swiper-slide" data-aos="fade-up">
          <img src="./assets/images/tech/php.png" alt="Our Tech">
          <h4>PHP</h4>
        </li>
        <li class="swiper-slide" data-aos="fade-up">
          <img src="./assets/images/tech/mysql.png" alt="Our Tech">
          <h4>MYSQL</h4>
        </li>
      </div>
    </ul>
  </div>
</section>

<!--technology_section-->


<!--getstarted_section-->

<section class="getstarted_section">
  <div class="wrapper">
    <div class="head_text">
      <h4 data-aos="fade-up">GET STARTED TO</h4>
      <h2 data-aos="fade-up">Grow your Business like <span>Never Before</span></h2>
    </div>
    <div class="wrapper_slide">
      <div class="get_started_row gerstarted_slider">
        <div class="swiper-wrapper">
          <div class="swiper-slide" data-aos="fade-up">
            <div class="get_started_box">
              <div class="get_started_content">
                <img src="./assets/images/getstarted/1.png" alt="I am Looking to
            Generate Traffic">
                <h4>I am Looking to
                  Generate Traffic</h4>
                <p>Start With</p>
                <ul>
                  <li>SEO</li>
                  <li>Google Adwords</li>
                  <li> Social Media Ads</li>
                </ul>
                <a href="javascript:void(0)" title="Ger Started">
                  <button>Get Started</button>
                </a>
              </div>
            </div>
          </div>
          <div class="swiper-slide" data-aos="fade-up">
            <div class="get_started_box">
              <div class="get_started_content">
                <img src="./assets/images/getstarted/2.png" alt="I’d Like More
            Conversion">
                <h4>I’d Like More
                  Conversion</h4>
                <p>Start With</p>
                <ul>
                  <li>Google Adwords</li>
                  <li>Social Media Ads</li>
                  <li>landing Page</li>
                </ul>
                <a href="javascript:void(0)" title="Ger Started">
                  <button>Get Started</button>
                </a>
              </div>
            </div>
          </div>
          <div class="swiper-slide" data-aos="fade-up">
            <div class="get_started_box">
              <div class="get_started_content">
                <img src="./assets/images/getstarted/3.png" alt="I Want to Build a
            Loyalty">
                <h4>I Want to Build a
                  Loyalty</h4>
                <p>Start With</p>
                <ul>
                  <li>Email Marketing</li>
                  <li>WhatsApp Status Post</li>
                  <li>Social Media Posts</li>
                </ul>
                <a href="javascript:void(0)" title="Ger Started">
                  <button>Get Started</button>
                </a>
              </div>
            </div>
          </div>
          <div class="swiper-slide" data-aos="fade-up">
            <div class="get_started_box">
              <div class="get_started_content">
                <img src="./assets/images/getstarted/4.png" alt="I'd Like More Leads">
                <h4>I'd Like More Leads</h4>
                <p>Start With</p>
                <ul>
                  <li>Google Adwords</li>
                  <li>Social Media Ads</li>
                  <li>landing Page</li>
                </ul>
                <a href="javascript:void(0)" title="Ger Started">
                  <button>Get Started</button>
                </a>
              </div>
            </div>
          </div>
          <div class="swiper-slide" data-aos="fade-up">
            <div class="get_started_box">
              <div class="get_started_content">
                <img src="./assets/images/getstarted/5.png" alt="I want to build a
            brand">
                <h4>I want to build a
                  brand</h4>
                <p>Start With</p>
                <ul>
                  <li>Website </li>
                  <li>Social Media Promotion</li>
                  <li>SEO</li>
                </ul>
                <a href="javascript:void(0)" title="Ger Started">
                  <button>Get Started</button>
                </a>
              </div>
            </div>
          </div>
          <div class="swiper-slide" data-aos="fade-up">
            <div class="get_started_box">
              <div class="get_started_content">
                <img src="./assets/images/getstarted/6.png" alt="I'd Like More Leads">
                <h4>I'd Like More Leads</h4>
                <p>Start With</p>
                <ul>
                  <li>SEO </li>
                  <li>Google Adwords</li>
                  <li>Social Media Ads</li>
                </ul>
                <a href="javascript:void(0)" title="Ger Started">
                  <button>Get Started</button>
                </a>
              </div>
            </div>
          </div>

        </div>
      </div>
    </div>
    <div class="gerstarted_slider_pagination"></div>
  </div>
</section>

<!--getstarted_section-->


<!--portfolio_section-->


<section class="portfolio_section_new">
  <div class="wrapper">
    <div class="head_text">
      <h4 data-aos="fade-up">PORTFOLIO</h4>
      <h2 data-aos="fade-up">Projects <span>We Cherish</span></h2>
    </div>
    <div class="portfolio_wrap">
      <div class="portfolio_align">
        <div class="portfolio_slider">
          <div class="swiper-wrapper">


            <div class="portfolio_box swiper-slide" data-aos="fade-up">
              <div class="portfolio_box_top">
                <div class="portfolio_box_left">
                  <h4>Jyothis Food</h4>
                </div>
              </div>
              <div class="portfolio_box_bottom">
                <img src="./assets/images/portfolio/1.jpg" alt="Jyothis Food">
                <div class="hover_portfolio">
                  <a href="javascript:void(0)" title="View More" target="_blank">View More</a>
                </div>
              </div>
            </div>

            <div class="portfolio_box swiper-slide" data-aos="fade-up">
              <div class="portfolio_box_top">
                <div class="portfolio_box_left">
                  <h4>GB Pack</h4>
                </div>
              </div>
              <div class="portfolio_box_bottom">
                <img src="./assets/images/portfolio/2.jpg" alt="GB Pack">
                <div class="hover_portfolio">
                  <a href="javascript:void(0)" title="View More" target="_blank">View More</a>
                </div>
              </div>
            </div>

            <div class="portfolio_box swiper-slide" data-aos="fade-up">
              <div class="portfolio_box_top">
                <div class="portfolio_box_left">
                  <h4>Naatu Sakkarai</h4>
                </div>
              </div>
              <div class="portfolio_box_bottom">
                <img src="./assets/images/portfolio/3.jpg" alt="Naatu Sakkarai">
                <div class="hover_portfolio">
                  <a href="javascript:void(0)" title="View More" target="_blank">View More</a>
                </div>
              </div>
            </div>

            <div class="portfolio_box swiper-slide" data-aos="fade-up">
              <div class="portfolio_box_top">
                <div class="portfolio_box_left">
                  <h4>Dr. Charu Dental Clinic</h4>
                </div>
              </div>
              <div class="portfolio_box_bottom">
                <img src="./assets/images/portfolio/4.png" alt="Dr. Charu Dental Clinic">
                <div class="hover_portfolio">
                  <a href="javascript:void(0)" title="View More" target="_blank">View More</a>
                </div>
              </div>
            </div>

            <div class="portfolio_box swiper-slide" data-aos="fade-up">
              <div class="portfolio_box_top">
                <div class="portfolio_box_left">
                  <h4>Monster Fitness Studio</h4>
                </div>
              </div>
              <div class="portfolio_box_bottom">
                <img src="./assets/images/portfolio/5.png" alt="Monster Fitness Studio">
                <div class="hover_portfolio">
                  <a href="javascript:void(0)" title="View More" target="_blank">View More</a>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="porfolio_slider_pagination"></div>
      </div>
    </div>
  </div>
</section>


<!--portfolio_section-->



<!--projects_section-->

<section class="projects_section">
  <div class="wrapper">
    <div class="projects_align">
      <div class="projects_box" data-aos="fade-up">
        <img src="./assets/images/c1.png" alt="Years Experience">
        <h4 class="plus">5</h4>
        <p>Years Experience</p>
      </div>
      <div class="projects_box" data-aos="fade-up">
        <img src="./assets/images/c2.png" alt="Completed Projects">
        <h4 class="plus">100</h4>
        <p>Completed Projects </p>
      </div>
      <div class="projects_box" data-aos="fade-up">
        <img src="./assets/images/c3.png" alt="Techies">
        <h4 class="plus">10</h4>
        <p>Techies</p>
      </div>
      <div class="projects_box" data-aos="fade-up">
        <img src="./assets/images/c4.png" alt="Happy Clients">
        <h4>200</h4>
        <p>Happy Clients</p>
      </div>
    </div>
  </div>
</section>

<!--projects_section-->







<!--testimonials_section-->

<section class="testimonials_section">
  <div class="wrapper">
    <div class="head_text">
      <h4 data-aos="fade-up">Clients</h4>
      <h2 data-aos="fade-up"><span>Our</span> Happy Clients</h2>
    </div>
    <div class="testi_wrap">
      <div class="testimonials_align">
        <div class="testi_slider">
          <div class="swiper-wrapper">
            <div class="swiper-slide" data-aos="fade-up">
              <div class="testimonials_box">
                <div class="profile">
                  <div class="profile_left">
                    <img src="./assets/images/t1.png" alt="profile">
                  </div>
                  <div class="profile_right">
                    <h4>Mr.Rakesh Walas</h4>
                    <img src="./assets/images/star.png" alt="star">
                  </div>
                </div>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. D</p>
              </div>
            </div>
            <div class="swiper-slide" data-aos="fade-up">
              <div class="testimonials_box">
                <div class="profile">
                  <div class="profile_left">
                    <img src="./assets/images/t2.png" alt="profile">
                  </div>
                  <div class="profile_right">
                    <h4>Mr.Rakesh Walas</h4>
                    <img src="./assets/images/star.png" alt="star">
                  </div>
                </div>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. D</p>
              </div>
            </div>
            <div class="swiper-slide" data-aos="fade-up">
              <div class="testimonials_box">
                <div class="profile">
                  <div class="profile_left">
                    <img src="./assets/images/t3.png" alt="profile">
                  </div>
                  <div class="profile_right">
                    <h4>Mr.Rakesh Walas</h4>
                    <img src="./assets/images/star.png" alt="star">
                  </div>
                </div>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. D</p>
              </div>
            </div>
            <div class="swiper-slide" data-aos="fade-up">
              <div class="testimonials_box">
                <div class="profile">
                  <div class="profile_left">
                    <img src="./assets/images/t3.png" alt="profile">
                  </div>
                  <div class="profile_right">
                    <h4>Mr.Rakesh Walas</h4>
                    <img src="./assets/images/star.png" alt="star">
                  </div>
                </div>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. D</p>
              </div>
            </div>
            <div class="swiper-slide" data-aos="fade-up">
              <div class="testimonials_box">
                <div class="profile">
                  <div class="profile_left">
                    <img src="./assets/images/t3.png" alt="profile">
                  </div>
                  <div class="profile_right">
                    <h4>Mr.Rakesh Walas</h4>
                    <img src="./assets/images/star.png" alt="star">
                  </div>
                </div>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. D</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="testi_slider_pagination"></div>
  </div>
</section>

<!--testimonials_section-->


<!--contact_form_section-->

<section class="contact_form_section">
  <!-- <div class="contact_bg">
    <img src="./assets/images/form.png" alt="Contact Form">
  </div> -->
  <div class="wrapper">

    <div class="contactform_align">
      <div class="contactform_left">
        <div class="head_text">
          <h4 data-aos="fade-right">Contact Form</h4>
          <h2 data-aos="fade-right"><span>Share</span> Your Queries</h2>
        </div>
        <form action="">
          <input type="text" placeholder="Name" name="" id="" data-aos="fade-right">
          <input type="text" placeholder="Email" name="" id="" data-aos="fade-right">
          <input type="text" placeholder="Phone Number" name="" id="" data-aos="fade-right">
          <textarea name="" id="" placeholder="Message" data-aos="fade-right"></textarea>
          <button type="submit" data-aos="fade-right">Submit</button>
        </form>
      </div>
      <div class="contactform_right">
        <img src="./assets/images/faq.png" alt="FAQ" data-aos="fade-left">
      </div>
    </div>
  </div>
</section>

<!--contact_form_section-->




<!--getintouch_section-->


<section class="getintouch_section">
  <div class="wrapper">
    <div class="head">
      <h2 data-aos="fade-up">Be <span>Greaterdhan</span></h2>
      <h3 data-aos="fade-up">Any one Else</h3>
    </div>
    <div class="getintouch_align">
      <div class="getintouch_left">
        <h4 data-aos="fade-right">Get in touch With Us</h4>
        <p class="address" data-aos="fade-right">
          No 2/9, Nehru Street, RK Pudhur,<br>
          Coimbatore, Tamil Nadu 600100</p>
        <p class="phone" data-aos="fade-right">+91-9876543210<br> +91-9876543210</p>
        <p class="mail" data-aos="fade-right">contact@greaterdhan.com</p>
      </div>
      <div class="getintouch_right">
        <img src="./assets/images/maps.png" alt="Our Location" data-aos="fade-left">
      </div>
    </div>
  </div>
</section>


<!--getintouch_section-->

































<?php

include('includes/footer.php');
?>
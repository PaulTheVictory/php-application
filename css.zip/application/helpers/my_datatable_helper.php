<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/** 
*  edit_column callback function in Codeigniter (Ignited Datatables)
*
* Grabs a value from the edit_column field for the specified field so you can
* return the desired value.  
*
* @access   public
* @return   mixed
*/

if ( ! function_exists('check_qualifyedit'))
{
    function check_qualifyedit($id,$status,$xii_status,$approved,$entrance_name,$base_url,$web_url)
    {
			
		$action = "";
		if($status=="WFR" || $xii_status=="WFR"){
			
			$action = '<a class="noedit" id="'.$id.'" href="'.$base_url.'stuqualifyupdate?ide='.$id.'&type=edit&wfr=y"><img style="padding:5px 10px" src="'.$web_url.'images/edit.png"></a>';
                }else if(($approved=="w" || $approved=="n") && $entrance_name=="" && $xii_status=="P"){
                    	$action = '<a class="noedit" id="'.$id.'" href="'.$base_url.'stuqualifyupdate?ide='.$id.'&type=edit&wfr=y"><img style="padding:5px 10px" src="'.$web_url.'images/edit.png"></a>';
        
                }
		
		$action .= '<a class="noedit" id="'.$id.'" href="'.$base_url.'stuqualifyupdate?ide='.$id.'"><img style="padding:5px" src="'.$web_url.'images/view.png"></a>';
		
        return $action;
    }  
	
	function check_qualifynameedit($id,$name,$status,$xii_status,$approved,$entrance_name,$base_url,$web_url)
    {
			
		$action = "";
		if($status=="WFR" || $xii_status=="WFR" ){
			
			$action = '<a data-id="'.$id.'" class="noedit idValue" style="float:left;padding:0px;font-weight:bold;font-size:15px;text-align:left;line-height:20px" href="'.$base_url.'stuqualifyupdate?ide='.$id.'&type=edit&wfr=y">'.$name.'</a>';
			
		}else if(($approved=="w" || $approved=="n") && $entrance_name=="" && $xii_status=="P"){
                        $action = '<a data-id="'.$id.'" class="noedit idValue" style="float:left;padding:0px;font-weight:bold;font-size:15px;text-align:left;line-height:20px" href="'.$base_url.'stuqualifyupdate?ide='.$id.'&type=edit&wfr=y">'.$name.'</a>';
			
                }else{
			
			$action = '<a data-id="'.$id.'" class="noedit idValue" style="float:left;padding:0px;font-weight:bold;font-size:15px;text-align:left;line-height:20px" href="#" onclick="return false;">'.$name.'</a>';
			
		}
		
		
        return $action;
    }
	
	function check_admissioncoursename1($id,$name,$role,$web_url,$base_url)
    {
			
		$action = "";

		if($role=="y"){
			$action = '<a href="coursedetails?id='.$id.'" data-id="'.$id.'" class="noedit idValue" style="float:left;padding:0px;font-size:15px;text-align:left;line-height:20px" href="javascript:void(0)">'.$name.'</a>';
		}else{
			$action = '<a href="javascript:void(0);" data-id="'.$id.'" class="noedit idValue" style="float:left;padding:0px;font-size:15px;text-align:left;line-height:20px" href="javascript:void(0)">'.$name.'</a>';
		}
		
						
        return $action;
    }
	
	function check_admissioncoursename2($id,$name,$role,$web_url,$base_url)
    {
			
		$action = "";

		if($role=="y"){
			$action = '<p data-id="'.$id.'"><input type="checkbox" name="check-1" value="'.$name.'" class="lcs_check" autocomplete="off" /></p>';
		}else{
			$action = '<p data-id="'.$id.'">-</p>';
		}
	
						
        return $action;
		
    }
	
    	function check_admissioncoursename4($id,$name,$role,$web_url,$base_url)
    {
			
		$action = "";

		if($role=="y"){
			$action = '<p data-id="'.$id.'"><input type="checkbox" name="check-1" value="'.$name.'" class="lcs_check1" autocomplete="off" /></p>';
		}else{
			$action = '<p data-id="'.$id.'">-</p>';
		}
	
						
        return $action;
		
    }
	
	function check_admissioncoursename3($id,$name,$role,$web_url,$base_url)
    {
			
		$action = "";
		
		if($role=="y"){
			$action .= '<a class="noedit" id="'.$id.'" href="editcourse?id='.$id.'"><img style="padding:5px 10px" src="images/edit.png"></a>'
				. '<!--a class="del noedit" id="'.$id.'" href="javascript:void(0)"><img style="padding:5px 10px" src="images/delete.png"></a-->';
		}

		if($name=="y"){
			$action .= '<a class=" noedit" id="'.$id.'" href="coursedetails?id='.$id.'"><img style="padding:5px" src="images/view.png"></a>';
		}
		
				
        return $action;
    }
	
	function check_courseeditfees($active,$role)
    {
			
		$action = "<p>-</p>";
		
		if($role=="y"){
			$action = '<p><input type="checkbox" name="check-1" value="'.$active.'" class="lcs_check" autocomplete="off" /></p>';
		}		
				
        return $action;
    }
	
	function check_qlisteditname($id,$name,$role)
    {
			
		$action = "<p>-</p>";
		
		if($role=="y"){
			$action = '<a href="qualification?id='.$id.'" data-id="'.$id.'" class="noedit idValue" style="float:left;padding:0px;font-size:15px;text-align:left;line-height:20px" href="javascript:void(0)">'.$name.'</a>';
		}else{
			$action = '<a href="javascript:void(0);" class="noedit idValue" style="float:left;padding:0px;font-size:15px;text-align:left;line-height:20px">'.$name.'</a>';
		}	
				
        return $action;
    }
	
	function check_qlisteditstatus($id,$status,$role)
    {
			
		$action = "<p>-</p>";
		
		if($role=="y"){
			$action = '<p data-id="'.$id.'"><input type="checkbox" name="check-1" value="'.$status.'" class="lcs_check" autocomplete="off" /></p>';
		}		
				
        return $action;
    }
	
	function check_qlisteditaction($id,$role)
    {
			
		$action = "<p>-</p>";
		
		if($role=="y"){
			$action = '<a class="noedit" id="'.$id.'" href="qualification?id='.$id.'"><img style="padding:5px 10px" src="images/edit.png"></a>'
                    . '<!--a class="del noedit" id="'.$id.'" href="javascript:void(0)"><img style="padding:5px 10px" src="images/delete.png"></a-->'
                    . '<a class=" noedit" id="'.$id.'" href="qualification?id='.$id.'"><img style="padding:5px" src="images/view.png"></a>';
		}		
				
        return $action;
    }
	
	function check_locationdelete($id,$role)
    {
			
		$action = "<p>-</p>";
		
		if($role=="y"){
			$action = '<a class="del noedit" data-id="'.$id.'" href="javascript:void(0)"><img style="padding:5px 10px" src="images/delete.png"></a>';
		}		
				
        return $action;
    }
	
	function check_cityeditdel($id,$name,$batchqty,$rollnostarts,$rollnoends,$roleedit,$roledelete)
    {
			
		$action = "<p>-</p>";
		
		if($roleedit=="y"){
			$action = '<a class="edit noedit" data-id="'.$id.'" data-name="'.$name.'" data-batchqty="'.$batchqty.'" data-rollnostarts="'.$rollnostarts.'" data-rollnoends="'.$rollnoends.'" href="javascript:void(0)"><img style="padding:5px 10px" src="images/edit.png"></a>';
		}
		
		if($roledelete=="y"){
			$action .= '<a class="del noedit" data-id="'.$id.'" href="javascript:void(0)"><img style="padding:5px 10px" src="images/delete.png"></a>';
		}
				
        return $action;
    }
	
	function check_centerseditdel($id,$roleedit,$roledelete)
    {
			
		$action = "<p>-</p>";
		
		if($roleedit=="y"){
			$action = '<a class="edit noedit" data-id="'.$id.'" href="javascript:void(0)"><img style="padding:5px 10px" src="images/edit.png"></a>';
		}
		
		if($roledelete=="y"){
			$action .= '<a class="del noedit" data-id="'.$id.'" href="javascript:void(0)"><img style="padding:5px 10px" src="images/delete.png"></a>';
		}
				
        return $action;
    }
	
	function check_classdel($id,$role)
    {
			
		$action = "<p>-</p>";
		
		if($role=="y"){
			$action = '<a class="del noedit" data-id="'.$id.'" href="javascript:void(0)"><img style="padding:5px 10px" src="images/delete.png"></a>';
		}
				
        return $action;
    }
	
	function check_ahdel($id,$role)
    {
			
		$action = "<p>-</p>";
		
		if($role=="y"){
			$action = '<a class="del noedit" data-id="'.$id.'" href="javascript:void(0)"><img style="padding:5px 10px" src="images/delete.png"></a>';
		}
				
        return $action;
    }
	
	function check_usersedit($id,$uname,$role)
    {
			
		$action = "<p>-</p>";
		
		if($role=="y"){
			$action = '<a href="useredit?id='.$id.'" data-id="'.$id.'" class="noedit idValue" style="float:left;padding:0px;font-size:15px;text-align:left;line-height:20px" href="javascript:void(0)">'.$uname.'</a>';
		}else{
			$action = '<a href="javascript:void(0);" class="noedit idValue" style="float:left;padding:0px;font-size:15px;text-align:left;line-height:20px">'.$uname.'</a>';
		}	
				
        return $action;
    }
	
	function check_usersactive($id,$active,$role)
    {
			
		$action = "<p>-</p>";
		
		if($role=="y"){
			$action = '<p data-id="'.$id.'"><input type="checkbox" name="check-1" value="'.$active.'" class="lcs_check" autocomplete="off" /></p>';
		}
				
        return $action;
    }
	
	function check_userseditdelete($id,$roleedit,$roledelete)
    {
			
		$action = "<p>-</p>";
		
		if($roleedit=="y"){
			$action = '<a class="noedit" id="'.$id.'" href="useredit?id='.$id.'"><img style="padding:5px 10px" src="images/edit.png"></a>';
		}
		
		if($roledelete=="y"){
			$action .= '<a class="del noedit" id="'.$id.'" href="javascript:void(0)"><img style="padding:5px 10px" src="images/delete.png"></a>';
		}
		
		if($roleedit=="y"){
			$action .= '<a class=" noedit" id="'.$id.'" href="useredit?id='.$id.'"><img style="padding:5px" src="images/view.png"></a>';
		}
				
        return $action;
    }
	
	function check_usergroupedit($id,$name,$roleedit)
    {
			
		$action = "<p>-</p>";
		
		if($roleedit=="y"){
			$action = '<a href="usereditgroup?id='.$id.'" data-id="'.$id.'" class="noedit idValue" style="float:left;padding:0px;font-size:15px;text-align:left;line-height:20px" href="javascript:void(0)">'.$name.'</a>';
		}else{
			$action = '<a href="javascript:void(0);" class="noedit idValue" style="float:left;padding:0px;font-size:15px;text-align:left;line-height:20px">'.$name.'</a>';
		}
		
				
        return $action;
    }
	
	function check_usergroupactions($id,$roleedit,$roledelete)
    {
			
		$action = "<p>-</p>";
		
		if($roleedit=="y"){
			$action = '<a class="noedit" id="'.$id.'" href="usereditgroup?id='.$id.'"><img style="padding:5px 10px" src="images/edit.png"></a>';
		}
		
		if($roledelete=="y"){
			$action .= '<a class="del noedit" id="'.$id.'" href="javascript:void(0)"><img style="padding:5px 10px" src="images/delete.png"></a>';
		}
		
		if($roleedit=="y"){
			$action .= '<a class=" noedit" id="'.$id.'" href="usereditgroup?id='.$id.'"><img style="padding:5px" src="images/view.png"></a>';
		}
				
        return $action;
    }
	
	function check_useractiveedit($id,$name,$roleedit)
    {
			
		$action = "<p>-</p>";
		
		if($roleedit=="y"){
			$action = '<a href="useredit?id='.$id.'" data-id="'.$id.'" class="noedit idValue" style="float:left;padding:0px;font-size:15px;text-align:left;line-height:20px" href="javascript:void(0)">'.$name.'</a>';
		}else{
			$action = '<a href="javascript:void(0);" class="noedit idValue" style="float:left;padding:0px;font-size:15px;text-align:left;line-height:20px">'.$name.'</a>';
		}
		
				
        return $action;
    }
	
	function check_usersactivestatus($id,$active,$role)
    {
			
		$action = "<p>-</p>";
		
		if($role=="y"){
			$action = '<p data-id="'.$id.'"><input type="checkbox" name="check-1" value="'.$active.'" class="lcs_check" autocomplete="off" /></p>';
		}
				
        return $action;
    }
	
	
	function check_useractiveactions($id,$roleedit,$roledelete)
    {
			
		$action = "<p>-</p>";
		
		if($roleedit=="y"){
			$action = '<a class="noedit" id="'.$id.'" href="useredit?id='.$id.'"><img style="padding:5px 10px" src="images/edit.png"></a>';
		}
		
		if($roledelete=="y"){
			$action .= '<a class="del noedit" id="'.$id.'" href="javascript:void(0)"><img style="padding:5px 10px" src="images/delete.png"></a>';
		}
		
		if($roleedit=="y"){
			$action .= '<a class=" noedit" id="'.$id.'" href="useredit?id='.$id.'"><img style="padding:5px" src="images/view.png"></a>';
		}
				
        return $action;
    }
	
	
	
	function check_userbrancheditdelete($id,$name,$roleedit,$roledelete)
    {
			
		$action = "<p>-</p>";
		
		if($roleedit=="y"){
			$action = '<a class="edit noedit" data-id="'.$id.'" data-name="'.$name.'" href="javascript:void(0)"><img style="padding:5px 10px" src="images/edit.png"></a>';
		}
		
		if($roledelete=="y"){
			$action .= '<a class="del noedit" data-id="'.$id.'" href="javascript:void(0)"><img style="padding:5px 10px" src="images/delete.png"></a>';
		}
				
        return $action;
    }
		
	
	function check_csmastereditdel($id,$name,$roleedit,$roledelete)
    {
			
		$action = "<p>-</p>";
		
		if($roleedit=="y"){
			$action = '<a class="edit noedit" data-id="'.$id.'" data-csname="'.$name.'"  href="javascript:void(0)"><img style="padding:5px 10px" src="images/edit.png"></a>';
		}
		
		if($roledelete=="y"){
			$action .= '<a class="del noedit" data-id="'.$id.'" href="javascript:void(0)"><img style="padding:5px 10px" src="images/delete.png"></a>';
		}
				
        return $action;
    }
	
	
	function check_bookedit($id,$uname,$role)
    {
			
		$action = "<p>-</p>";
		
		if($role=="y"){
			$action = '<a href="bookdetails?bid='.$id.'" data-id="'.$id.'" class="noedit idValue" style="float:left;padding:0px;font-size:15px;text-align:left;line-height:20px" href="javascript:void(0)">'.$uname.'</a>';
		}else{
			$action = '<a href="javascript:void(0);" class="noedit idValue" style="float:left;padding:0px;font-size:15px;text-align:left;line-height:20px">'.$uname.'</a>';
		}	
				
        return $action;
    }
	
	
	function check_bookview($id,$roleview,$roleedit,$roledelete)
    {
			
		$action = "";
				
		/*if($roledelete=="y"){
			$action .= '<a class="del noedit" id="'.$id.'" href="javascript:void(0)"><img style="padding:5px 10px" src="images/delete.png"></a>';
		}*/
		
		if($roleedit=="y"){
			$action .= '<a class=" noedit" id="'.$id.'" href="addbook?bid='.$id.'"><img style="padding:5px" src="images/edit.png"></a>';
		}
		
		if($roleview=="y"){
			$action .= '<a class=" noedit" id="'.$id.'" href="bookdetails?bid='.$id.'"><img style="padding:5px" src="images/view.png"> </a>';
		}
				
        return $action;
    }
	
	function check_bookstock($id)
	{
		//$stock = "0/0";
		
		$ci =& get_instance();
		$ci->load->database();
		
		$tstock = 0;
		$sql0 = "SELECT id FROM `bscp_bookstock` where bookid = '".$id."' ";
		$q0 = $ci->db->query($sql0);
		if($q0->num_rows() > 0)
		{
			$tstock = $q0->num_rows();
		}
		
		$sql = "SELECT bs.id FROM `bscp_bookstock` as bs, bscp_issuebook as ib where bs.barcode=ib.barcode and bs.bookid = '".$id."' and ib.issued = 'y' ";
		$q = $ci->db->query($sql);
		if($q->num_rows() > 0)
		{
			$issuedstock = $q->num_rows();
		}
		
		$totalstock = $tstock - $issuedstock;
		$stock = $totalstock."/".$tstock;
		
		return $stock;
	}
	
	function check_bookstockview($id,$center,$btype,$roleedit,$roledelete)
    {
			
		$action = "";
				
		/*if($roledelete=="y"){
			$action .= '<a class="del noedit" id="'.$id.'" href="javascript:void(0)"><img style="padding:5px 10px" src="images/delete.png"></a>';
		}*/
		
		if($roleedit=="y"){
			$action .= '<a class=" noedit" data-id="'.$id.'" href="addbookstock?bid='.$id.'&center='.$center.'&btype='.$btype.'"><img style="padding:5px" src="images/view.png"> View</a>';
		}
				
        return $action;
    }
	
	function check_bookcenterstock($id,$center)
	{
		//$stock = $tstock."/".$tstock;
		
		$issuedstock = 0;
		
		$ci =& get_instance();
		$ci->load->database();
		
		$tstock = 0;
		$sql0 = "SELECT bs.id FROM `bscp_bookstock` as bs where bs.bookid = '".$id."' and bs.center = '".$center."' ";
		$q0 = $ci->db->query($sql0);
		if($q0->num_rows() > 0)
		{
			$tstock = $q0->num_rows();
		}
		
		$sql = "SELECT bs.id FROM `bscp_bookstock` as bs, bscp_issuebook as ib where bs.barcode=ib.barcode and bs.bookid = '".$id."' and bs.center = '".$center."' and ib.issued = 'y' ";
		$q = $ci->db->query($sql);
		if($q->num_rows() > 0)
		{
			$issuedstock = $q->num_rows();
		}
		
		$totalstock = $tstock - $issuedstock;
		
		$stock = $totalstock."/".$tstock;
		
		return $stock;
	}
	
	
	function check_booktypestock($id,$center)
	{
		//$stock = "0/0";
		
		$ci =& get_instance();
		$ci->load->database();
		
		$tstock = 0;
		$sql0 = "SELECT id FROM `bscp_bookstock` where bookid = '".$id."' and center = '".$center."' and booktype='Library' ";
		$q0 = $ci->db->query($sql0);
		if($q0->num_rows() > 0)
		{
			$tstock = $q0->num_rows();
		}
		
		
		$sql = "SELECT bs.id FROM `bscp_bookstock` as bs, bscp_issuebook as ib where bs.barcode=ib.barcode and ib.issued = 'y' and bs.bookid = '".$id."' and bs.center = '".$center."' and bs.booktype='Library' ";
		$q = $ci->db->query($sql);
		if($q->num_rows() > 0)
		{
			$issuedstock = $q->num_rows();
		}
		
		$totalstock = $tstock - $issuedstock;
		$stock = $totalstock."/".$tstock;
		
		return $stock;
	}
	
	function check_booktypestock2($id,$center)
	{
		//$stock = "0/0";
		
		$ci =& get_instance();
		$ci->load->database();
		
		$tstock = 0;
		$sql0 = "SELECT id FROM `bscp_bookstock` where bookid = '".$id."' and center = '".$center."' and booktype='Reference' ";
		$q0 = $ci->db->query($sql0);
		if($q0->num_rows() > 0)
		{
			$tstock = $q0->num_rows();
		}
		
		$sql = "SELECT bs.id FROM `bscp_bookstock` as bs, bscp_issuebook as ib where bs.barcode=ib.barcode and ib.issued = 'y' and bs.bookid = '".$id."' and bs.center = '".$center."' and bs.booktype='Reference' ";
		$q = $ci->db->query($sql);
		if($q->num_rows() > 0)
		{
			$issuedstock = $q->num_rows();
		}
		
		$totalstock = $tstock - $issuedstock;
		$stock = $totalstock."/".$tstock;
		
		return $stock;
	}
	
	
	function check_bookstockcenterview($id,$bookid,$price,$roleedit,$roledelete)
    {
			
		$action = "";
		
		if($roleedit=="y"){
			$action .= '<a class="edit noedit" data-id="'.$id.'" data-price="'.$price.'" href="javascript:void(0);"><img style="padding:5px" src="images/edit.png"></a>';
		}
				
		if($roledelete=="y"){
			$action .= '<a class="del noedit" data-id="'.$id.'" data-bid="'.$bookid.'" href="javascript:void(0)"><img style="padding:5px 10px" src="images/delete.png"></a>';
		}
				
        return $action;
    }
	
	function check_librarycentereditdelete($id,$name,$roleedit,$roledelete)
    {
			
		$action = "";
		
		if($roleedit=="y"){
			$action = '<a class="edit noedit" data-id="'.$id.'" data-name="'.$name.'" href="javascript:void(0)"><img style="padding:5px 10px" src="images/edit.png"></a>';
		}
		
		if($roledelete=="y"){
			$action .= '<a class="del noedit" data-id="'.$id.'" href="javascript:void(0)"><img style="padding:5px 10px" src="images/delete.png"></a>';
		}
				
        return $action;
    }
    
      function check_smstemplateeditdel($id,$roleedit,$roledelete)
    {
			
		$action = "<p>-</p>";
		
		if($roleedit=="y"){
			$action = '<a class="edit noedit" data-id="'.$id.'" href="templateedit?id='.$id.'"><img style="padding:5px 10px" src="images/edit.png"></a>';
		}
		
		if($roledelete=="y"){
			$action .= '<a class="del noedit" data-id="'.$id.'" href="javascript:void(0)"><img style="padding:5px 10px" src="images/delete.png"></a>';
		}
				
        return $action;
    }
    
    
	function check_smstemplateactive($id,$active,$role)
    {
			
		$action = "<p>-</p>";
		
		if($role=="y"){
			$action = '<p data-id="'.$id.'"><input type="checkbox" name="check-1" value="'.$active.'" class="lcs_check" autocomplete="off" /></p>';
		}
				
        return $action;
    }
	
	
	function check_booktype($booktype)
	{
		$type = "No";
		
		if($booktype=="Reference")
		{
			$type = "Yes";
		}
		
		return $type;
	}
	
	function change_DateFormat($duedate)
	{
		
		$duedate = date("d-m-Y",strtotime($duedate));
		
		return $duedate;
	}
	
	function get_bookremaindue($duedate)
	{
		
		$start_date = strtotime(date("Y-m-d"));
		$end_date = strtotime(date("Y-m-d",strtotime($duedate)));
		
		$days = ($end_date - $start_date)/60/60/24;
		
		//if($days < 0) $days = 0;
		
		return $days;
	}
	
	function check_staffedit($id,$staffname,$role)
    {
			
		$action = "<p>-</p>";
		
		if($role=="y"){
			$action = '<a href="staffedit?id='.$id.'" data-id="'.$id.'" class="noedit idValue" style="float:left;padding:0px;font-size:15px;text-align:left;line-height:20px" href="javascript:void(0)">'.$staffname.'</a>';
		}else{
			$action = '<a href="javascript:void(0);" class="noedit idValue" style="float:left;padding:0px;font-size:15px;text-align:left;line-height:20px">'.$staffname.'</a>';
		}	
				
        return $action;
    }
	
	function check_staffeditdelete($id,$roleedit,$roledelete)
    {
			
		$action = "<p>-</p>";
		
		if($roleedit=="y"){
			$action = '<a class="noedit" id="'.$id.'" href="staffedit?id='.$id.'"><img style="padding:5px 10px" src="images/edit.png"></a>';
		}
		
		if($roledelete=="y"){
			$action .= '<a class="del noedit" id="'.$id.'" href="javascript:void(0)"><img style="padding:5px 10px" src="images/delete.png"></a>';
		}
		
		if($roleedit=="y"){
			$action .= '<a class=" noedit" id="'.$id.'" href="staffedit?id='.$id.'"><img style="padding:5px" src="images/view.png"></a>';
		}
				
        return $action;
    }
	
	function check_issuestuname($sname,$staffname)
	{
		
		$name = "";
		
		if($sname!="") $name = $sname;
		else if($staffname!="") $name = $staffname;
		
		return $name;
	}
	
	function check_issuestuid($studid,$staffmobile)
	{
		
		$stuid = "";
		
		if($studid!="") $stuid = $studid;
		else if($staffmobile!="") $stuid = $staffmobile;
		
		return $stuid;
	}
        
            function check_examdisticteditdel($id,$roleedit,$roledelete)
    {
			
		$action = "<p>-</p>";
		
		if($roleedit=="y"){
			$action = '<a class="edit noedit" data-id="'.$id.'" href="javascript:void(0)"><img style="padding:5px 10px" src="images/edit.png"></a>';
		}
		
		if($roledelete=="y"){
			$action .= '<a class="del noedit" data-id="'.$id.'" href="javascript:void(0)"><img style="padding:5px 10px" src="images/delete.png"></a>';
		}
				
        return $action;
    }
    
    function check_examcentereditdel($id,$roleedit,$roledelete)
    {
			
		$action = "<p>-</p>";
		
		if($roleedit=="y"){
			$action = '<a class="edit noedit" data-id="'.$id.'" href="javascript:void(0)"><img style="padding:5px 10px" src="images/edit.png"></a>';
		}
		
		if($roledelete=="y"){
			$action .= '<a class="del noedit" data-id="'.$id.'" href="javascript:void(0)"><img style="padding:5px 10px" src="images/delete.png"></a>';
		}
				
        return $action;
    }
    
    
     function check_exammastereditdel($id,$roleedit,$roledelete)
    {
			
		$action = "<p>-</p>";
		
		if($roleedit=="y"){
			$action = '<a class="edit noedit" data-id="'.$id.'" href="examedit?id='.$id.'"><img style="padding:5px 10px" src="images/edit.png"></a>';
		}
		
		if($roledelete=="y"){
			$action .= '<a class="del noedit" data-id="'.$id.'" href="javascript:void(0)"><img style="padding:5px 10px" src="images/delete.png"></a>';
		}
				
        return $action;
    }
    
    	function check_exammastereditdel1($id,$name,$role)
    {
			
		$action = "";

		if($role=="y"){
			$action = '<p data-id="'.$id.'"><input type="checkbox" name="check-1" value="'.$name.'" class="lcs_check" autocomplete="off" /></p>';
		}else{
			$action = '<p data-id="'.$id.'">-</p>';
		}
	
						
        return $action;
		
    }
	
	
	function get_issuehistoryremaindue($issuedate,$receiveddate)
	{
		
		//$start_date = strtotime(date("Y-m-d"));
		$start_date = strtotime(date("Y-m-d",strtotime($issuedate)));
		$end_date = strtotime(date("Y-m-d",strtotime($receiveddate)));
		
		$days = ($end_date - $start_date)/60/60/24;
		
		//if($days < 0) $days = 0;
		
		return $days;
	}
	
	function check_printtotalcount($printbatchid)
	{
		
		$ci =& get_instance();
		$ci->load->database();
		
		$printed = 0;
		$sql0 = "SELECT status FROM `bscp_idcardprint` where printbatchid = '".$printbatchid."'";
		$q0 = $ci->db->query($sql0);
		if($q0->num_rows() > 0)
		{
			$printed = $q0->num_rows();
		}
		
		return $printed;
	}
	
	function check_printcount($printbatchid)
	{
		
		$ci =& get_instance();
		$ci->load->database();
		
		$printed = 0;
		$sql0 = "SELECT status FROM `bscp_idcardprint` where printbatchid = '".$printbatchid."' and status='y' ";
		$q0 = $ci->db->query($sql0);
		if($q0->num_rows() > 0)
		{
			$printed = $q0->num_rows();
		}
		
		return $printed;
	}
	
	function check_notprintcount($printbatchid)
	{
		
		$ci =& get_instance();
		$ci->load->database();
		
		$notprinted = 0;

		$sql = "SELECT status FROM `bscp_idcardprint` where printbatchid = '".$printbatchid."' and status<>'y'";
		$q = $ci->db->query($sql);
		if($q->num_rows() > 0)
		{
			$notprinted = $q->num_rows();
		}	
		
		return $notprinted;
	}
        
         function check_refundstatus($status)
    {
			
		$action = "<p>-</p>";
		
		if($status=="c"){
			$action = '<p class="rstatus" style="cursor:pointer;margin:0px auto;background:#3CAF92;padding:5px;color:#fff;width: 70px;border-radius: 5px;font-size:11px">Completed</p>';
		}
		
		if($status=="cf"){
			$action = '<p class="rstatus" style="cursor:pointer;margin:0px auto;background:#29806A;padding:5px;color:#fff;width: 70px;border-radius: 5px;font-size:11px">Confirmed</p>';
		}
                
                if($status=="n"){
			$action = '<p class="rstatus" style="cursor:pointer;margin:0px auto;background:#db4d4d;padding:5px;color:#fff;width: 70px;border-radius: 5px;font-size:11px">Not Eligible</p>';
		}
                
                if($status=="cd"){
			$action = '<p class="rstatus" style="cursor:pointer;margin:0px auto;background:#db4d4d;padding:5px;color:#fff;width: 70px;border-radius: 5px;font-size:11px">Cancelled</p>';
		}
				
        return $action;
    }
	
	function check_st_status($id,$status)
    {
			
		$action = "";

		$action = '<p data-id="'.$id.'"><input type="checkbox" name="check-1" value="'.$status.'" class="lcs_check" autocomplete="off" /></p>';
						
        return $action;
		
    }
    
    function check_seatavailability($id,$total)
	{
		//$stock = "0/0";
		/*$tstock = 0;
		$ci =& get_instance();
		$ci->load->database();
                $sql0 = "SELECT totalseats FROM `bscp_schoolsallocation` where yearid = '".$id."' ";
		$q0 = $ci->db->query($sql0);
		if($q0->num_rows() > 0)
		{
			$tstock = $q0[0]['totalseats'];
		}
		
		
		$sql = "SELECT bs.id FROM `bscp_bookstock` as bs, bscp_issuebook as ib where bs.barcode=ib.barcode and bs.bookid = '".$id."' and ib.issued = 'y' ";
		$q = $ci->db->query($sql);
		if($q->num_rows() > 0)
		{
			$issuedstock = $q->num_rows();
		}
		
		$totalstock = $tstock - $issuedstock;*/
		$stock = $total."/".$total;
		
		return $stock;
	}
	
}


/* End of file MY_datatable_helper.php */
/* Location: ./application/helpers/MY_datatable_helper.php */  
<?php


class ResMsgDTO {  

	private $pgMeTrnRefNo;
	private $orderId;
	private $authNStatus;
	private $authZStatus;
	private $captureStatus;
	private $rrn;
	private $authZCode;
	private $responseCode;
	private $trnReqDate;
	private $statusCode;
	private $statusDesc;
	private $addField1;
	private $addField2;
	private $addField3;
	private $addField4;
	private $addField5;
	private $addField6;
	private $addField7;
	private $addField8;
	private $addField9;
	private $addField10;
	private $pgRefCancelReqId;
	private $trnAmt;
	private $refundAmt;
	
	
	
public function getPgMeTrnRefNo() {
	return $this->pgMeTrnRefNo;
}

public function setPgMeTrnRefNo($pgMeTrnRefNo) {
	$this->pgMeTrnRefNo = $pgMeTrnRefNo;
}

public function getOrderId() {
	return $this->orderId;
}

public function setOrderId($orderId) {
	$this->orderId = $orderId;
}

public function getAuthNStatus() {
	return $this->authNStatus;
}

public function setAuthNStatus($authNStatus) {
	$this->authNStatus = $authNStatus;
}

public function getAuthZStatus() {
	return $this->authZStatus;
}

public function setAuthZStatus($authZStatus) {
	$this->authZStatus = $authZStatus;
}

public function getCaptureStatus() {
	return $this->captureStatus;
}

public function setCaptureStatus($captureStatus) {
	$this->captureStatus = $captureStatus;
}

public function getRrn() {
	return $this->rrn;
}

public function setRrn($rrn) {
	$this->rrn = $rrn;
}

public function getAuthZCode() {
	return $this->authZCode;
}

public function setAuthZCode($authZCode) {
	$this->authZCode = $authZCode;
}

public function getResponseCode() {
	return $this->responseCode;
}

public function setResponseCode($responseCode) {
	$this->responseCode = $responseCode;
}

public function getTrnReqDate() {
	return $this->trnReqDate;
}

public function setTrnReqDate($trnReqDate) {
	$this->trnReqDate = $trnReqDate;
}

public function getStatusCode() {
	return $this->statusCode;
}

public function setStatusCode($statusCode) {
	$this->statusCode = $statusCode;
}

public function getStatusDesc() {
	return $this->statusDesc;
}

public function setStatusDesc($statusDesc) {
	$this->statusDesc = $statusDesc;
}

public function getAddField1() {
	return $this->addField1;
}

public function setAddField1($addField1) {
	$this->addField1 = $addField1;
}

public function getAddField2() {
	return $this->addField2;
}

public function setAddField2($addField2) {
	$this->addField2 = $addField2;
}

public function getAddField3() {
	return $this->addField3;
}

public function setAddField3($addField3) {
	$this->addField3 = $addField3;
}

public function getAddField4() {
	return $this->addField4;
}

public function setAddField4($addField4) {
	$this->addField4 = $addField4; 
}

public function getAddField5() {
	return $this->addField5;
}

public function setAddField5($addField5) {
	$this->addField5 = $addField5;
}

public function getAddField6() {
	return $this->addField6;
}

public function setAddField6($addField6) {
	$this->addField6 = $addField6;
}

public function getAddField7() {
	return $this->addField7;
}

public function setAddField7($addField7) {
	$this->addField7 = $addField7;
}

public function getAddField8() {
	return $this->addField8;
}

public function setAddField8($addField8) {
	$this->addField8 = $addField8;
}

public function getAddField9() {
	return $this->addField9;
}

public function setAddField9($addField9) {
	$this->addField9 = $addField9;
}

public function getAddField10() {
	return $this->addField10;
}

public function setAddField10($addField10) {
	$this->addField10 = $addField10;
}

public function getPgRefCancelReqId() {
	return $this->pgRefCancelReqId;
}

public function setPgRefCancelReqId($pgRefCancelReqId) {
	$this->pgRefCancelReqId = $pgRefCancelReqId;
}

public function getTrnAmt(){
	return $this->trnAmt;
}
public function setTrnAmt($trnAmt){
	$this->trnAmt = $trnAmt;
}
public function getRefundAmt(){
	return $this->refundAmt;
}
public function setRefundAmt($refundAmt){
	$this->refundAmt = $refundAmt;
}
}
?>

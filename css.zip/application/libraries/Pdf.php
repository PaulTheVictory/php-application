<?php
defined('BASEPATH') OR exit('No direct script access allowed');

use Dompdf\Dompdf;

include APPPATH.'third_party/dompdf/vendor/autoload.php';

class Pdf
{
    function createPDF($html, $filename='', $download=TRUE, $paper='A4', $orientation='portrait'){
        $dompdf = new DOMPDF();
        $dompdf->load_html($html);
		$dompdf->set_option('isRemoteEnabled', true);
		$dompdf->set_option('setIsHtml5ParserEnabled', true);
		$customPaper = array(34,0,278,384.3);
		$dompdf->setPaper($customPaper);
        //$dompdf->set_paper($paper, $orientation);
        $dompdf->render();
        if($download)
            $dompdf->stream($filename.'.pdf', array('Attachment' => 1));
        else
            $dompdf->stream($filename.'.pdf', array('Attachment' => 0));
    }
}
?>
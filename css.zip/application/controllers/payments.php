<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Payments extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model('login_model','',TRUE);
                $this->load->model('course_model','',TRUE);
                $this->load->model('payment_model','',TRUE);
                $this->load->model('users_model','',TRUE);
                $this->load->library('table'); 
                 

	}
	
	function index()
	{
		if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in'))
   		{
                    $session_data = $this->session->userdata('loggedin');
                    $session_id = $session_data['id'];
                    $session_role = $session_data['role'];
			
			
					$data['roleaccess'] = $this->config->item('roleaccess');

					if($data['roleaccess']['uview']!="y"){
						redirect($data['roleaccess']['defaultpage'], 'refresh');
					}
			
                    
                    $data['user'] = $this->login_model->GetUserId();		
		
                        
                    $type = isset($_GET['type']) ? $_GET['type'] : '';
                    $data['menu'] = $this->load->view('headermenu', $data, TRUE);
                    $data['type'] = $type;
			
			
						$data['branch'] = $this->users_model->GetAllCenters("","option");
			
                        if($type ==='unpaid') {
                        $data['units'] = $this->course_model->GetAllCenters("",'option');
                         /*$tmpl = array('table_open' => '<table class="sortable" id="unpaidtable" style="margin-top:0px;">');
                                    $this->table->set_template($tmpl);
                                    $this->table->set_heading('SNO','STD ID','CHL ID', 'STUDENT NAME', 'COURSE NAME','CENTER','UNPAID','ACTION');*/


                        $this->load->view('header_view', $data);
                        $this->load->view('payments_view', $data);
                        $this->load->view('footer_view');

                        } else if($type ==='paid') {
                        
							$data['units'] = $this->course_model->GetAllCenters("",'option');
							
                         /*$tmpl = array('table_open' => '<table class="sortable" id="unpaidtable" style="margin-top:0px;">');
                                    $this->table->set_template($tmpl);
                                    $this->table->set_heading('SNO','STD ID','CHL ID','DATE','BILL NO', 'STUDENT NAME', 'COURSE NAME','CENTER','PAID','PAYMENT MODE','ACTION');*/


                        $this->load->view('header_view', $data);
                        $this->load->view('payments_view', $data);
                        $this->load->view('footer_view');

                        }else{
     		
                            redirect('courses', 'refresh');
                        }
                        
                }
   		else
   		{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
   		}
		
	}
      
	
	/*public function getPaymentLists() {
            
            if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')){
                
                $type = $this->input->post('type', true);
                
                if($type === "unpaid") {
					
                    $ret =  $this->payment_model->GetUnpaidLists();
					
                } else if($type === "paid"){
					
                    $ret =  $this->payment_model->GetPaidLists();
					
                }
                //echo $ret;
                
            }else{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
            }
            
        }*/
	
        public function getPaymentLists() {
            
            if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')){
                
                $type = $this->input->post('type', true);
				$searchcol = $this->input->post('searchcol', true);
                
               $this->getPaidUnpaidLists($type,$searchcol);
                
            }else{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
            }
            
        }
	
	
	
public function getPaidUnpaidLists($type,$searchcol)
{
		
	if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')){
			
		
		$roleaccess = $this->config->item('roleaccess');
		
		$user = $this->login_model->GetUserId();
		$batches = $user['batches'];
		
		
		if($type=="paid"){ 
			
			$columns = array( 
                            0 =>'created_at', 
                            1 =>'studid',
                            2=> 'challanno',
                            3=> 'paydate',
                            4=> 'receiptno',
                            5=> 'sname',
                            6=> 'coursename',
                            7=> 'center',
                            8=> 'unpaid',
                            9=> 'paymode',
                            10=> 'ide',
                        );
			
		}
		else {
			
			$columns = array( 
                            0 =>'created_at', 
                            1 =>'studid',
                            2=> 'challanno',
                            3=> 'sname',
                            4=> 'coursename',
                            5=> 'center',
                            6=> 'unpaid',
                            7=> 'ide',
                        );
			
		}
		

		$limit = $this->input->post('length');
        $start = $this->input->post('start');
        $order = $columns[$this->input->post('order')[0]['column']];
        $dir = $this->input->post('order')[0]['dir'];
  
        $totalData = $this->payment_model->allpaidunpaidlists_count($type,$batches);
            
        $totalFiltered = $totalData; 
            
        if(empty($this->input->post('search')['value']))
        {            
            $posts = $this->payment_model->allpaidunpaidlists($limit,$start,$order,$dir,$type,$batches);
        }
        else {
            $search = $this->input->post('search')['value']; 

            $posts =  $this->payment_model->paidunpaidlists_search($limit,$start,$search,$order,$dir,$type,$searchcol,$batches);

            $totalFiltered = $this->payment_model->paidunpaidlists_search_count($search,$type,$searchcol,$batches);
        }

        $data = array();
        if(!empty($posts))
        {
            foreach ($posts as $post)
            {

                $nestedData['created_at'] = '<span class="sno">'.$post->created_at.'</span>';
                $nestedData['studid'] = '<a target="_blank" href="studentprofile?sid='.$post->studentid.'">'.$post->studid.'</a>';                
                $nestedData['sname'] = strtoupper($post->sname);;
				$nestedData['coursename'] = '<a target="_blank" href="coursedetails?id='.$post->cid.'">'.$post->coursename.'</a>';
                $nestedData['center'] = $post->center;
				$nestedData['unpaid'] = $post->unpaid;
				
				if($type=="paid"){
				
					$nestedData['challanno'] = '<span style="color:#0332AA">'.$post->challanno.'</span>';
					$nestedData['paydate'] = '<span>'.$post->paydate.'</span>';
					$nestedData['receiptno'] = $post->receiptno;
					
					if(strcmp($post->paymode,"online")===0 && $post->referenceid==""){
						$nestedData['paymode'] = "conline";
					}else{
						$nestedData['paymode'] = $post->paymode;
					}
					
					date_default_timezone_set('Asia/Kolkata');
					$paydate = date("Y-m-d", strtotime($post->paydate));
					//$oldDate = strtotime($paydate)+86400;
					$oldDate = strtotime($paydate);
					$cDate = strtotime(date("Y-m-d"));
						
					$editpaybtn = "";
					if($cDate == $oldDate && strcmp($post->paymode,"Online")!==0 && isset($roleaccess['Bill List'][1]) && $roleaccess['Bill List'][1]=="y"){
						$editpaybtn = '<a href="javascript:void(0);" title="Edit Payment" data-cid="'.$post->courseid.'" data-sid="'.$post->studentid.'" data-chno="'.$post->challanno.'" data-crid="'.$post->cride.'" data-billno="'.$post->receiptno.'" class="editpay" style="color:#0332AA;padding-left: 20px;margin: 0px 10px;background:url('.base_url().'images/edit.png) no-repeat;background-position-y: 4px;cursor:pointer" ></a>';
					}
					
					$nestedData['ide'] = $editpaybtn.'<a href="stufeebill?crid='.$post->cride.'&cno='.$post->challanno.'&userid='.$post->studentid.'" target="_blank"  title="View Payment" style="color:#0332AA;padding-left: 20px;background:url('.base_url().'images/view.png) no-repeat;background-position-y: 4px;cursor:pointer" ></a>';
					
				}else{
										
					$nestedData['challanno'] = '<a target="_blank" href="stumyprofile/downloadChallan?id='.$post->requestid.'&challan=unpaid&userid='.$post->studentid.'" style="color:#0332AA">'.$post->challanno.'</a>';
					
					$addpayment = "-";
					if(isset($roleaccess['Unpaid List'][0]) && $roleaccess['Unpaid List'][0]=="y"){
						$addpayment  = '<span data-cid="'.$post->courseid.'" data-sid="'.$post->studentid.'" data-chno="'.$post->challanno.'" data-crid="'.$post->requestid.'" class="addpay" style="color:#0332AA;padding-left: 20px;background:url('.base_url().'images/addpay.png) no-repeat;background-position-y: 4px;cursor:pointer" >Add Payment</span>';
					}
					
					$nestedData['ide'] = $addpayment;
					
				}
                
                $data[] = $nestedData;

            }
        }
          
        $json_data = array(
                    "draw"            => intval($this->input->post('draw')),  
                    "recordsTotal"    => intval($totalData),  
                    "recordsFiltered" => intval($totalFiltered), 
                    "data"            => $data   
                    );
            
        echo json_encode($json_data); 
			
	}else{
			
		//If no session, redirect to login page
		redirect('login', 'refresh');
			
	}
		
}
        
         
	
}
?>

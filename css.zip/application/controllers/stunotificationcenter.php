<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Stunotificationcenter extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model('login_model','',TRUE);
				$this->load->model('exams_model','',TRUE);
		$this->load->model('notification_model','',TRUE);
                $this->load->library('table');                  

	}
	
	function index()
	{
		if($this->session->userdata('loggedin'))
   		{
                    $session_data = $this->session->userdata('loggedin');
                    $session_id = $session_data['id'];
                    $session_role = $session_data['role'];
                    
                    $data['user'] = $this->login_model->GetUserId();		
		
		    	if($session_role === 'student') {
					           
					$data['notifydetails'] = $this->notification_model->GetStudentNotifications($data['user']['id']);
					                  
					$this->load->view('header', $data);
					$this->load->view('stunotificationcenter_view', $data);
					$this->load->view('footer');
                        
                }
         }
   		else
   		{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
   		}
		
	}
	
	 public function GetStudentSingleNotifications() {
		
	   if($this->session->userdata('loggedin')){

		   $session_data = $this->session->userdata('loggedin');
			$session_id = $session_data['id'];
			$session_role = $session_data['role'];

			$data['user'] = $this->login_model->GetUserId();		
		   
			$nid  = $this->input->post('nid', true);

			$ret = $this->notification_model->GetStudentSingleNotifications($data['user']['id'],$nid);
			echo json_encode($ret);
		}
		 
	}
	
	
}
?>

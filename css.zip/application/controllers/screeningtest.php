<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Screeningtest extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model('login_model','',TRUE);
                $this->load->model('course_model','',TRUE);
                 $this->load->model('notification_model','',TRUE);
                $this->load->library('table'); 
                 $this->load->helper('download');
                 

	}
	
	function index()
	{
		if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in'))
   		{
                    $session_data = $this->session->userdata('loggedin');
                    $session_id = $session_data['id'];
                    $session_role = $session_data['role'];
                    
			
					$data['roleaccess'] = $this->config->item('roleaccess');

					if($data['roleaccess']['uview']!="y"){
						redirect($data['roleaccess']['defaultpage'], 'refresh');
					}
			
                    $data['user'] = $this->login_model->GetUserId();		
		
                        
                    $ide = isset($_GET['id']) ? $_GET['id'] : '';
                    $type = isset($_GET['type']) ? $_GET['type'] : '';
                    $data['menu'] = $this->load->view('headermenu', $data, TRUE);
                        if(($ide === '')&&($type === '')) {
                        
                         $tmpl = array('table_open' => '<table class="sortable" id="studenttable" style="margin-top:0px;">');
                                    $this->table->set_template($tmpl);
                                    $this->table->set_heading('SNO','COURSE ID','SCREEN TEST NAME','TEST DATE', 'APPLIED','REMITTED','ACTUAL REMITTED','PENDING','HT ISSUED','HT DOWNLOADED', 'STATUS');


                        $this->load->view('header_view', $data);
                        $this->load->view('st_view', $data);
                        $this->load->view('footer_view');

                        } else if(($ide !== '')&&($type === '')) {
                            $type = isset($_GET['type']) ? $_GET['type'] : '';
                            $data['courseid'] = $ide;                          
                            $data['coursename'] = $this->course_model->GetCourseName($ide);
                             $tmpl = array('table_open' => '<table class="sortable" id="studenttable" style="margin-top:0px;">');
                                    $this->table->set_template($tmpl);
                                      $this->table->set_heading('CITY','TOTAL SEATS','APPLIED','REMITTED','ACTUAL REMITTED','PENDING','HT ISSUED','HT_DOWNLOADED');
                                    $this->load->view('header_view', $data);
                        $this->load->view('st_center_view', $data);
                        $this->load->view('footer_view');
                        } else if(($ide !== '')&&($type === 'slist')) {
                            $data['type'] = isset($_GET['type']) ? $_GET['type'] : '';
                            $data['mode'] = isset($_GET['mode']) ? $_GET['mode'] : '';
                            $data['courseid'] = $ide;                          
                            $data['coursename'] = $this->course_model->GetCourseName($ide);
                             $tmpl = array('table_open' => '<table class="sortable" id="studenttable" style="margin-top:0px;">');
                                    $this->table->set_template($tmpl);
                                      $this->table->set_heading('STD ID', 'STUDENT NAME','PHONE','EMAIL','ROLL NO','CITY','CENTER','STATUS','HT DOWNLOADED');
                                    $this->load->view('header_view', $data);
                        $this->load->view('st_stu_view', $data);
                        $this->load->view('footer_view');
                        }else if(($ide !== '')&&($type === 'cenlist')) {
                            $data['type'] = isset($_GET['type']) ? $_GET['type'] : '';
                            $data['mode'] = isset($_GET['mode']) ? $_GET['mode'] : '';
                            $data['center'] = isset($_GET['center']) ? $_GET['center'] : '';
                            $data['courseid'] = $ide;                          
                            $data['coursename'] = $this->course_model->GetCourseName($ide);
                            $data['centers'] = $this->course_model->GetCityWiseCenters($data['center']);
                            $data['cities'] = $this->course_model->GetAllCities("");
                             $tmpl = array('table_open' => '<table class="sortable" id="studenttable" style="margin-top:0px;">');
                                    $this->table->set_template($tmpl);
                                      $this->table->set_heading('','STD ID', 'STUDENT NAME','PHONE','EMAIL','CENTER','ROLL NO','STATUS','HT ISSUED','HT DOWNLOADED');
                                    $this->load->view('header_view', $data);
                        $this->load->view('st_stucenter_view', $data);
                        $this->load->view('footer_view');
                        }
                        
                }
   		else
   		{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
   		}
		
	}
        
        public function GetAdmissionCenterLists() {
            
            if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')){
                
				$roleaccess = $this->config->item('roleaccess');
		
				$user = $this->login_model->GetUserId();
				$batches = $user['batches'];
				
				
                $cid = isset($_POST['courseid']) ? $_POST['courseid'] : '';
                $ret =  $this->course_model->GetRequestedCenterSTCourses($cid,$batches);
                echo $ret;
                
            }else{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
            }
            
        }
        
         public function GetAdmissionLists() {
            
            if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')){
                
				$roleaccess = $this->config->item('roleaccess');
		
				$user = $this->login_model->GetUserId();
				$batches = $user['batches'];
				
				
                  $ret =  $this->course_model->GetRequestedSTCourses($batches);  
                
                echo ($ret);
                
            }else{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
            }
            
        }
	
	
	public function ChangeSTStatus(){
            
            if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')){

                $ide = isset($_GET['ide']) ? $_GET['ide'] : '';
                $status = isset($_GET['status']) ? $_GET['status'] : '';

                if($ide != ""){
                     $ret = $this->course_model->ChangeSTStatus($ide,$status);
                } else {
                    $ret = array(0 => "fail");
                }

                echo json_encode($ret);
            
            }else {
                //If no session, redirect to login page
                redirect('login', 'refresh');
            }
            
        }
	
        
       /* public function GetAdmissionStuLists() {
            
            if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')){
                
                $cid = isset($_POST['courseid']) ? $_POST['courseid'] : '';
                $type = isset($_POST['type']) ? $_POST['type'] : '';
                $ret =  $this->course_model->GetRequestedSTSTUCourses($cid,$type);
                echo $ret;
                
            }else{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
            }
            
        }*/
	
	
public function GetAdmissionStuLists()
{
		
	if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')){
			
		$roleaccess = $this->config->item('roleaccess');
		
		$user = $this->login_model->GetUserId();
		$batches = $user['batches'];
		
		
		$cid = isset($_POST['courseid']) ? $_POST['courseid'] : '';
        $type = isset($_POST['type']) ? $_POST['type'] : '';
		$searchcol = isset($_POST['searchcol']) ? $_POST['searchcol'] : '';
		
			$columns = array( 
                            0 =>'studid', 
                            1 =>'sname',
                            2=> 'mobile',
                            3=> 'email',
                            4=> 'roll_number',
                            5=> 'city',
                            6=> 'center',
                            7=> 'remitted',
                            8=> 'download_ht',
                        );
				

		$limit = $this->input->post('length');
        $start = $this->input->post('start');
        $order = $columns[$this->input->post('order')[0]['column']];
        $dir = $this->input->post('order')[0]['dir'];
  
        $totalData = $this->course_model->GetRequestedSTSTUCourses_count($cid,$type,$batches);
            
        $totalFiltered = $totalData; 
            
        if(empty($this->input->post('search')['value']))
        {            
            $posts = $this->course_model->GetRequestedSTSTUCourses($limit,$start,$order,$dir,$cid,$type,$batches);
        }
        else {
            $search = $this->input->post('search')['value']; 

            $posts =  $this->course_model->GetRequestedSTSTUCourses_search($limit,$start,$search,$order,$dir,$cid,$type,$searchcol,$batches);

            $totalFiltered = $this->course_model->GetRequestedSTSTUCourses_search_count($search,$cid,$type,$searchcol,$batches);
        }

        $data = array();
        if(!empty($posts))
        {
            foreach ($posts as $post)
            {

                $nestedData['studid'] = '<a target="_blank" href="studentprofile?sid='.$post->sid.'">'.$post->studid.'</a>';  
                $nestedData['sname'] =  strtoupper($post->sname);
                $nestedData['mobile'] = $post->mobile;
				$nestedData['email'] = $post->email;
				$nestedData['roll_number'] = $post->roll_number;
				$nestedData['city'] = $post->city;
                                $nestedData['center'] = $post->center;
				$nestedData['remitted'] = '<span data-rid="'.$post->remitted.'" data-pid="'.$post->remitted.'" class="status" style="display: inline-block;"></span>';
				$nestedData['download_ht'] = $post->download_ht;
                
                $data[] = $nestedData;

            }
        }
          
        $json_data = array(
                    "draw"            => intval($this->input->post('draw')),  
                    "recordsTotal"    => intval($totalData),  
                    "recordsFiltered" => intval($totalFiltered), 
                    "data"            => $data   
                    );
            
        echo json_encode($json_data); 
			
	}else{
			
		//If no session, redirect to login page
		redirect('login', 'refresh');
			
	}
		
}
        
       /* public function GetAdmissionCenterStuLists() {
            
            if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')){
                
                $cid = isset($_POST['courseid']) ? $_POST['courseid'] : '';
                $type = isset($_POST['type']) ? $_POST['type'] : '';
                $center = isset($_POST['center']) ? $_POST['center'] : '';
                $ret =  $this->course_model->GetRequestedCenterSTSTUCourses($cid,$type,$center);
                echo $ret;
                
            }else{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
            }
            
        }*/
        
	
public function GetAdmissionCenterStuLists()
{
		
	if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')){
			
		$roleaccess = $this->config->item('roleaccess');
		
		$user = $this->login_model->GetUserId();
		$batches = $user['batches'];
		
		
		$cid = isset($_POST['courseid']) ? $_POST['courseid'] : '';
		$type = isset($_POST['type']) ? $_POST['type'] : '';
		$center = isset($_POST['center']) ? $_POST['center'] : '';
		$searchcol = isset($_POST['searchcol']) ? $_POST['searchcol'] : '';
		
			$columns = array( 
                            0 =>'ide', 
                            1 =>'studid', 
                            2 =>'sname',
                            3=> 'mobile',
                            4=> 'email',
                            5=> 'scenter',
                            6=> 'roll_number',
                            7=> 'remitted',
                            8=> 'issue_ht',
                            9=> 'download_ht',
                        );
				

		$limit = $this->input->post('length');
        $start = $this->input->post('start');
        $order = $columns[$this->input->post('order')[0]['column']];
        $dir = $this->input->post('order')[0]['dir'];
  
        $totalData = $this->course_model->GetRequestedCenterSTSTUCourses_count($cid,$type,$center,$batches);
            
        $totalFiltered = $totalData; 
            
        if(empty($this->input->post('search')['value']))
        {            
            $posts = $this->course_model->GetRequestedCenterSTSTUCourses($limit,$start,$order,$dir,$cid,$type,$center,$batches);
        }
        else {
            $search = $this->input->post('search')['value']; 

            $posts =  $this->course_model->GetRequestedCenterSTSTUCourses_search($limit,$start,$search,$order,$dir,$cid,$type,$center,$searchcol,$batches);

            $totalFiltered = $this->course_model->GetRequestedCenterSTSTUCourses_search_count($search,$cid,$type,$center,$searchcol,$batches);
        }

        $data = array();
        if(!empty($posts))
        {
            foreach ($posts as $post)
            {

				$nestedData['ide'] = '<a style="padding-left:10px;float:left;color:#0332AA;" class="noedit" href="javascript:void(0)"><input class="crequest" type="checkbox" value="'.$post->ide.'"></a>';
                $nestedData['studid'] = '<a target="_blank" href="studentprofile?sid='.$post->sid.'">'.$post->studid.'</a>';  
                $nestedData['sname'] =  strtoupper($post->sname);
                $nestedData['mobile'] = $post->mobile;
				$nestedData['email'] = $post->email;
                                $nestedData['scenter'] = $post->scenter;
				$nestedData['roll_number'] = $post->roll_number;
				$nestedData['remitted'] = '<span data-rid="'.$post->remitted.'" data-pid="'.$post->pending.'" class="status" style="display: inline-block;"></span>';
				$nestedData['issue_ht'] = '<span class="cstatus">'.$post->issue_ht.'</span>';
				
				$download_ht = "";
				if($post->issue_ht=="Y"){
					
					if($post->download_ht!="") $downloadht = $post->download_ht; else $downloadht = "N";
					
					$download_ht = '<a target="_blank" href="stufeepayments/downloadHallticket?userid='.$post->sid.'&crid='.$post->ide.'&type=preview">'.$downloadht.'</a>';
					
				}
				
				$nestedData['download_ht'] = $download_ht;
                
                $data[] = $nestedData;

            }
        }
          
        $json_data = array(
                    "draw"            => intval($this->input->post('draw')),  
                    "recordsTotal"    => intval($totalData),  
                    "recordsFiltered" => intval($totalFiltered), 
                    "data"            => $data   
                    );
            
        echo json_encode($json_data); 
			
	}else{
			
		//If no session, redirect to login page
		redirect('login', 'refresh');
			
	}
		
}
        
      public function IssueHallticket(){
            
            if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')){

                $ide = isset($_GET['ide']) ? $_GET['ide'] : '';
                $type = isset($_GET['type']) ? $_GET['type'] : '';
                $center = isset($_GET['center']) ? $_GET['center'] : '';
                $city = isset($_GET['city']) ? $_GET['city'] : '';
                $courseid = isset($_GET['courseid']) ? $_GET['courseid'] : '';

				$ret = array(0 => "");
				
                if($ide != ""){
                    			
						if($center!=""){
							$noofseats = $this->course_model->GetNoOfSeats($center,$city);
						}
					
                       $cname= $this->course_model->GetCourseName($courseid);
                          $ide = explode("|",$ide);
        
                            foreach($ide as $key=>$val) {
								
                                 if($val === '') { continue;}
								
								$scenter = "";
								if($center==""){
									$scenter = $this->course_model->GetStudentCourseCenter($val);
									if($scenter==""){ continue;}
									
									$noofseats = $this->course_model->GetNoOfSeats($scenter,$city);
								}
								
								if($scenter!="" && $center==""){
									$ret = $this->course_model->IssueHallTicket($val,$type,$scenter,$city,$courseid,$noofseats);
                                	$this->notification_model->SendHallticket($val,$cname);
								}else if($scenter=="" && $center!=""){
									$ret = $this->course_model->IssueHallTicket($val,$type,$center,$city,$courseid,$noofseats);
                                	$this->notification_model->SendHallticket($val,$cname);
								}
                               
                            }
					                            
                     
                } else {
                    $ret = array(0 => "fail");
                }

                echo json_encode($ret);
            
            }else {
                //If no session, redirect to login page
                redirect('login', 'refresh');
            }
            
        }
        
        public function uploadTempalte(){
            
		if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')){

			//print_r($_FILES);exit;
			
			if(isset($_FILES["file"]) && !empty($_FILES["file"]['name']) && !empty($_POST['center'])&& !empty($_POST['courseid'])){
				
				$center = $_POST['center'];$cid = $_POST['courseid'];				
				$validExtensions = array('.pdf');
				                            				
				$dirname = FCPATH.'docs/screentest/'.$cid."/".$center."/";
								
				$fileExtension = strrchr($_FILES['file']['name'][0], ".");
				$fileName = "screeningtest".$fileExtension;
									
				$destinationfull = $dirname . $fileName;
					
                                if(!file_exists($dirname)) { if(!mkdir($dirname,0777,true)){ $st ="error ".$dirname; }  }
							
				if (in_array(strtolower($fileExtension), $validExtensions)) {
					
					$resultfull = move_uploaded_file($_FILES['file']['tmp_name'][0],$destinationfull);
					
					if(!$resultfull){
				    
						$ret = array('status' => "ufail".$st);
						echo json_encode($ret);
						exit(0);
						
					}else{
												
						$ret = array('status' => "success","message"=>'Template Uploaded Successfully');
						echo json_encode($ret);
						exit(0);
						
					}
								
				}else{
					
					$ret = array('status' => "exfail");
					echo json_encode($ret);
					exit(0);
					
				}
					
								
			}else{
				
				$ret = array('status' => "empty");
				echo json_encode($ret);
				exit(0);
				
			}
			
			
		}
	  
  }
  
  
   public function export(){
            
            if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')){

				
				$roleaccess = $this->config->item('roleaccess');
		
				$user = $this->login_model->GetUserId();
				$batches = $user['batches'];
				
				if(isset($roleaccess['Export ST'][3]) && $roleaccess['Export ST'][3]=="y"){
				
               $ide = $this->input->get('courseid', true);
               $type = $this->input->get('type', true);
               $center = isset($_GET['center']) ? $_GET['center'] : '';
               
               $html .= '<tr><td>S.no</td><td>Name</td><td>Student ID</td><td>Email</td><td>Country Code</td><td>Mobile Number</td><td>Date of Birth:</td><td>Gender</td><td>Nationality</td><td>Category</td><td>Aadhar Number</td><td>Fathers Name</td><td>Country Code</td><td>Fathers Phone</td><td>Fathers Email</td><td>Fathers Occupation</td><td>Mothers Name</td><td>Country Code</td><td>Mothers Phone</td><td>Mothers Email</td><td>Mothers Occupation</td><td>Communication Contact</td><td>Blood Group</td><td>Class Studying / Complete</td><td>Stream</td><td>Name of School Last Studied / Studying</td><td>Address Line</td><td>Country</td><td>House / Appartment Name</td><td>Place / Street</td><td>Post Office</td><td>District</td><td>State</td><td>Country</td><td>Pincode</td><td>Country Code</td><td>Whatsapp Number</td><td>Guardian Name</td><td>Account Holder Name</td><td>Bank Name</td><td>Branch</td><td>IFSC Code</td><td>Bank Account Number</td><td>Test City</td><td>Test Center</td><td>Roll Number</td><td>Issue HT</td><td>Download HT</td><td>Total Fee (Active Fee)</td><td>Discount</td><td>Given By</td><td>Reason</td><td>Remarks</td><td>To be paid</td><td>Paid</td><td>Net Due</td><td>GST+KF</td><td>Total due</td></tr>';

                if($ide != ""){
                     $ret = $this->course_model->ExportSTRequest($ide,$center,$type,$batches);
                       
                      $i = 1;
                     foreach ($ret as $key=>$val){
                        $html .= '<tr><td>'.$i.'</td><td>'.$val['sname'].'</td><td>'.$val['studid'].'</td><td>'.$val['email'].'</td><td>'.$val['mcode'].'</td><td>'.$val['contact'].'</td><td>'.$val['dob'].'</td><td>'.$val['gender'].'</td><td>'.$val['nationality'].'</td><td>'.$val['category'].'</td><td>'.$val['aadharnumber'].'</td><td>'.$val['fathername'].'</td><td>'.$val['fathercode'].'</td><td>'.$val['fatherphone'].'</td><td>'.$val['fatheremail'].'</td><td>'.$val['fatheroccupation'].'</td><td>'.$val['mothername'].'</td><td>'.$val['mothercode'].'</td><td>'.$val['motherphone'].'</td><td>'.$val['motheremail'].'</td><td>'.$val['motheroccupation'].'</td><td>'.$val['communicationcontact'].'</td><td>'.$val['bloodgroup'].'</td><td>'.$val['classstudy'].'</td><td>'.$val['stream'].'</td><td>'.$val['schoolcollegename'].'</td><td>'.$val['eduaddress'].",".$val['edulandmark'].",".$val['edudistrict'].",".$val['edustate'].",".$val['edupost'].",".$val['edupincode'].'</td><td>'.$val['educountry'].'</td><td>'.$val['housenameno'].'</td><td>'.$val['landmark'].",".$val['contactaddress'].'</td><td>'.$val['contactpost'].'</td><td>'.$val['contactdistrict'].'</td><td>'.$val['contactstate'].'</td><td>'.$val['contactcountry'].'</td><td>'.$val['contactpincode'].'</td><td>'.$val['wacode'].'</td><td>'.$val['whatsappno'].'</td><td>'.$val['guardianname'].'</td><td>'.$val['accountholdername'].'</td><td>'.$val['bankname'].'</td><td>'.$val['branch'].'</td><td>'.$val['ifsccode'].'</td><td>'.$val['bankaccountno'].'</td><td>'.$val['center'].'</td><td>'.$val['scenter'].'</td><td>'.$val['roll_number'].'</td><td>'.$val['issue_ht'].'</td><td>'.$val['download_ht'].'</td><td>'.$val['total'].'</td><td>'.$val['discount'].'</td><td>'.$val['givenby'].'</td><td>'.$val['reason'].'</td><td>'.$val['remarks'].'</td><td>'.$val['tobepaid'].'</td><td>'.$val['paid'].'</td><td>'.$val['netdue'].'</td><td>'.$val['gst'].'</td><td>'.$val['totaldue'].'</td></tr>';
                        $i++;
                    }
                } 
                
                $savename = "Screening Test Student Profile Export".date('d-m-Y-H_i_s');
                $html = str_replace('<tr>',"\n",$html);
                     $html = str_replace('</tr>',"",$html);

                     $html = str_replace('</th>',"\t",$html);
                     $html = str_replace('<th>',"",$html);

                     $html = str_replace('</td>',"\t",$html);
                     $html = str_replace('<td>',"",$html);


                     $html = strip_tags($html);

                     $filename = $savename .".xls";

                     force_download($filename, $html);
					
					
				}

                
            
            }else {
                //If no session, redirect to login page
                redirect('login', 'refresh');
            }
            
        }
	
	
	// Change City
	
	public function STChangeCity(){
            
            if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')){

                $ide = isset($_GET['ide']) ? $_GET['ide'] : '';
                $city = isset($_GET['city']) ? $_GET['city'] : '';
                $courseid = isset($_GET['courseid']) ? $_GET['courseid'] : '';

                if($ide != ""){
                    
				  	$ide = explode("|",$ide);

					foreach($ide as $key=>$val) {
						 if($val === '') { continue;}
						$ret = $this->course_model->STChangeCity($val,$city,$courseid);
					}
                            
                     
                }else {
                    $ret = array(0 => "fail");
                }

                echo json_encode($ret);
            
            }else {
                //If no session, redirect to login page
                redirect('login', 'refresh');
            }
            
        }
	
}
?>

<<<<<<< .mine
<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Reports extends CI_Controller {

	function __construct() {
            
		parent::__construct();
                $this->load->model('login_model','',TRUE);
		$this->load->model('reports_model','',TRUE);
                $this->load->model('course_model','',TRUE);
                  $this->load->model('student_model','',TRUE);
                $this->load->helper('download');

	}
	
	function index() {
            
           if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')) {

                $session_data = $this->session->userdata('loggedin');
                $session_id = $session_data['id'];
                $session_role = $session_data['role'];
                $data['user'] = $this->login_model->GetUserId();

                $data['menu'] = $this->load->view('headermenu', $data, TRUE);
                
                $sdate = isset($_GET['sdate']) ? $_GET['sdate'] : '';
                $edate = isset($_GET['edate']) ? $_GET['edate'] : '';
                $type = isset($_GET['rtype']) ? $_GET['rtype'] : '';
                $center = isset($_GET['center']) ? $_GET['center'] : 'All';
                
                $sdate = ($sdate ==="")?(date('Y-m-d H:i:s',strtotime("-1 days"))):$sdate;
                $edate = ($edate ==="")?(date('Y-m-d H:i:s')):$edate;
                $type = ($type ==="")?'cr':$type;
               
               $data['sdate'] = $sdate;$data['edate'] = $edate;$data['center'] = $center;
               $data['units'] = $this->course_model->GetAllCenters($center,'option');
               $data['type'] = $type;
                if($type === 'cr') {                    
                    $data['reports'] = $this->reports_model->BillGeneratonSummary($sdate,$edate,$center);
                    $data['savename'] = "Accounts_Report_".date('d-m-Y-H_i_s');
                } else if($type === 'cwd'){
                    $data['reports'] = $this->reports_model->CourseWiseAdmittedList($sdate,$edate,$center);
                    $data['savename'] = "Course_Admitted__Report_".date('d-m-Y-H_i_s');
                } else if($type === 'dca'){
                    $data['reports'] = $this->reports_model->DailyCourseAppliedList($sdate,$edate,$center);
                    $data['savename'] = "Course_Applied_Report_".date('d-m-Y-H_i_s');
                } else if($type === 'sl'){
                    $data['reports'] = $this->reports_model->DailySignupList($sdate,$edate);
                    $data['savename'] = "Signup_Report_".date('d-m-Y-H_i_s');
                } else if($type === 'bl'){
                    $data['reports'] = $this->reports_model->DailyBillList($sdate,$edate,$center);
                    $data['savename'] = "Bill_Report_".date('d-m-Y-H_i_s');
                }  else if($type === 'ul'){
                    $data['reports'] = $this->reports_model->UnpaidList($sdate,$edate,$center);
                    $data['savename'] = "Unpaid_Report_".date('d-m-Y-H_i_s');
                } else if($type === 'stunpl'){
                    $data['reports'] = $this->reports_model->FirstTimeStudentPaidList($sdate,$edate,$center);
                    $data['savename'] = "First_Time_Paid_Report_".date('d-m-Y-H_i_s');
                } else if($type === 'rfl'){
                    $data['reports'] = $this->reports_model->RefundBillList($sdate,$edate,$center);
                    $data['savename'] = "Refund_Paid_Report_".date('d-m-Y-H_i_s');
                }else if($type === 'wll'){
                    $data['reports'] = $this->reports_model->WorldlineBillList($sdate,$edate,$center);
                    $data['savename'] = "Worldline_Report_".date('d-m-Y-H_i_s');
                } else if($type === 'bulkprint'){
                    $reports = $this->reports_model->BulkPrintList($sdate,$edate,$center);
                   // var_dump($reports);exit();
                    $feesmaster = $this->student_model->getFeesMaster();
                    foreach($reports as $key=> $val) {
                       $feepaybill = $this->student_model->GetFeePaymentBill($val['studentid'],$val['requestid'],$val['challanno']);
                       $data['feepaybill'] .= $this->reports_model->BulkPrintView($feesmaster,$feepaybill,$val['studid'],$val['sname']);
                    }
                    
                    $this->load->view('bulk_print_view', $data);
                } 
                 if($type !== 'bulkprint'){
                 $this->load->view('header_view', $data);
                 $this->load->view('reports_view', $data);
                 $this->load->view('footer_view');
                 }
                
            } else {
                //If no session, redirect to login page
                redirect('login', 'refresh');
            }
            
        }
        
        function export() {
            
           if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')) {
               
               $sdate = isset($_GET['sdate']) ? $_GET['sdate'] : '';
                $edate = isset($_GET['edate']) ? $_GET['edate'] : '';
                $type = isset($_GET['rtype']) ? $_GET['rtype'] : '';
                $center = isset($_GET['center']) ? $_GET['center'] : 'All';
                
                $sdate = ($sdate ==="")?(date('Y-m-d H:i:s',strtotime("-1 days"))):$sdate;
                $edate = ($edate ==="")?(date('Y-m-d H:i:s')):$edate;
                $type = ($type ==="")?'cr':$type;
               
              if($type === 'cr') { 
                          
                  $reports = $this->reports_model->BillGeneratonSummary($sdate,$edate,$center);
                  $savename = "Accounts_Report_".date('d-m-Y-H_i_s');
                    
                  
                    $html = '<thead><tr><th>S.nO</th><th>Counter Id</th><th>Counter name</th><th>Description</th><th>Reg Fee</th><th>Tuition Fee</th><th>S.Tax / <br>CGST</th><th>SB <br>CESS/<br>SGST</th><th>KK <br>CESS/<br>IGST/<br>KFC</th><th>CD</th><th>Other</th><th>Total</th><th>Cash</th><th>Card</th><th>Cheque</th><th>DD</th><th>SIB <br>Challan</th><th>Transfer</th><th>Online</th><th>Total</th><th>TDS</th></tr></thead>';
                    $i = 1; $mregFee = 0;$mtutionFee = 0;$mcgst = 0;$msgst = 0;
                    $mkf = 0;$mcd = 0;$mother = 0;$mtotal = 0;$mcash = 0;$mcard = 0;
                    $mcheque = 0;$mdd = 0;$mchallan = 0;$mtransfer = 0;$monline = 0;$mother1 = 0;$mpaid = 0;
                    foreach ($reports as $key=>$val){
                        if(($key === "count")||($key === "billno")) {continue;}
                        $coursename = array_key_exists('cname', $val)?$val['cname']:"";
                        $coursename = preg_replace("/\s+/", " ", $coursename);
                        $regFee = array_key_exists('Reg Fee', $val)?$val['Reg Fee']:0;
                        $tutionFee = array_key_exists('Tuition Fee', $val)?$val['Tuition Fee']:0;
                        $cd = array_key_exists('CD', $val)?$val['CD']:0;
                        $total = array_key_exists('total', $val)?$val['total']:0;
                        $paid = array_key_exists('paid', $val)?$val['paid']:0;
                        $tutionFee = round($tutionFee);

                        $cash = array_key_exists('cash', $val)?$val['cash']:0;
                        $dd = array_key_exists('dd', $val)?$val['dd']:0;
                        $challan = array_key_exists('challan', $val)?$val['challan']:0;
                        if($challan === 0 ) {$challan = array_key_exists('chellan', $val)?$val['chellan']:0;}
                        $transfer = array_key_exists('net', $val)?$val['net']:0;
                        $online = array_key_exists('online', $val)?$val['online']:0;
                        $card = array_key_exists('card', $val)?$val['card']:0;
                        $cheque = array_key_exists('cheque', $val)?$val['cheque']:0;

                        $calamount = floatval($regFee)+floatval($tutionFee);
                        $cgst = floatval($calamount)*.09;
                        $sgst = floatval($calamount)*.09;
                        $kf   = floatval($calamount)*.01;

                        $other = floatval($total) - (floatval($calamount)+floatval($cgst)+floatval($sgst)+floatval($kf)+floatval($cd));
                        $other1 = (floatval($cash)+floatval($dd)+floatval($challan)+floatval($transfer)+floatval($online)+floatval($card)+floatval($cheque))-floatval($paid);
                        $other = round($other,2);
                        $other1 = round($other1,2);
                        $cgst = round($cgst,2);
                        $sgst = round($sgst,2);
                        $kf = round($kf,2);

                        $html .= '<tr><td>'.$i.'</td><td>ALL</td><td>'.$center.'</td><td>'.$coursename.'</td><td>'.$regFee.'</td><td>'.$tutionFee.'</td><td>'.$cgst.'</td><td>'.$sgst.'</td><td>'.$kf.'</td><td>'.$cd.'</td><td>'.$other.'</td><td>'.$total.'</td><td>'.$cash.'</td><td>'.$card.'</td><td>'.$cheque.'</td><td>'.$dd.'</td><td>'.$challan.'</td><td>'.$transfer.'</td><td>'.$online.'</td><td>'.$paid.'</td><td>0</td></tr>';
                        $i++;
                        $mregFee = floatval($mregFee)+floatval($regFee);$mtutionFee = floatval($mtutionFee)+floatval($tutionFee);
                        $mcgst = floatval($mcgst)+floatval($cgst);$msgst = floatval($msgst)+floatval($sgst);$mkf = floatval($mkf)+floatval($kf);
                        $mcd = floatval($mcd)+floatval($cd);$mother = floatval($mother)+floatval($other);$mtotal = floatval($mtotal)+floatval($total);
                        $mcash = floatval($mcash)+floatval($cash);$mcard = floatval($mcard)+floatval($card); $mcheque = floatval($mcheque)+floatval($cheque);
                        $mdd = floatval($mdd)+floatval($dd);$mchallan = floatval($mchallan)+floatval($challan);$mtransfer = floatval($mtransfer)+floatval($transfer);
                        $monline = floatval($monline)+floatval($online);$mother1 = 0;$mpaid = floatval($mpaid)+floatval($paid);
                    }
                    if($i === 1) { } else{
                        
                        
                    $html .= '<tr><td></td><td></td><td></td><td></td><td>'.$mregFee.'</td><td>'.$mtutionFee.'</td><td>'.$mcgst.'</td><td>'.$msgst.'</td><td>'.$mkf.'</td><td>'.$mcd.'</td><td>'.$mother.'</td><td>'.$mtotal.'</td><td>'.$mcash.'</td><td>'.$mcard.'</td><td>'.$mcheque.'</td><td>'.$mdd.'</td><td>'.$mchallan.'</td><td>'.$mtransfer.'</td><td>'.$monline.'</td><td>'.$mpaid.'</td><td>0</td></tr>';
                    }

       
           } else if($type === 'cwd'){ 
               
                    $reports = $this->reports_model->CourseWiseAdmittedList($sdate,$edate,$center);
                    $savename = "Course_Admitted__Report_".date('d-m-Y-H_i_s');               
              
                    $html = '<thead><tr><th>S.no</th><th style="width: 30%">Course Name</th><th>Center</th><th>Student ID</th><th style="width: 10%">Student Name</th><th>Country Code</th><th>Mobile Number</th><th>Whats App No.</th><th>Email ID</th><th style="width: 20%">Qualification</th><th>Stream</th><th>Course Fee</th><th>Remitted</th><th>Initial Payment Date</th></tr></thead>';
                    $i = 1;
                    foreach ($reports as $key=>$val){
                        $html .= '<tr><td>'.$i.'</td><td>'.$val['coursename'].'</td><td>'.$val['center'].'</td><td>'.$val['studid'].'</td><td>'.$val['sname'].'</td><td>'.$val['mcode'].'</td><td>'.$val['contact'].'</td><td>'.$val['whatsappno'].'</td><td>'.$val['email'].'</td><td>'.$val['name'].'</td><td>'.$val['stream'].'</td><td>'.$val['total'].'</td><td>'.$val['remitted'].'</td><td>'.$val['pdate'].'</td> </tr>';
                        $i++;
                    }
                           
                 } else if($type === 'dca'){ 
                     
                    $reports = $this->reports_model->DailyCourseAppliedList($sdate,$edate,$center);
                    $savename = "Course_Applied_Report_".date('d-m-Y-H_i_s');
                    
                    $html = '<thead><tr><th>S.no</th><th>Student ID</th><th style="width: 20%">Student Name</th><th>Country Code</th><th>Mobile Number</th><th>Email ID</th><th style="width: 20%">Qualification</th><th>Stream</th><th style="width: 20%">Applied Course</th><th>Center</th><th>Present Status</th><th>Date of Registration</th></tr></thead>';
                    $i = 1;
                    foreach ($reports as $key=>$val){
                        $html .= '<tr><td>'.$i.'</td><td>'.$val['studid'].'</td><td>'.$val['sname'].'</td><td>'.$val['mcode'].'</td><td>'.$val['contact'].'</td><td>'.$val['email'].'</td><td>'.$val['qualification'].'</td><td>'.$val['stream'].'</td><td>'.$val['coursename'].'</td><td>'.$val['center'].'</td><td>'.$val['status'].'</td><td>'.$val['rdate'].'</td></tr>';
                        $i++;
                    }
                 
                  }else if($type === 'sl'){
                      
                    $reports = $this->reports_model->DailySignupList($sdate,$edate);
                    $savename = "Signup_Report_".date('d-m-Y-H_i_s');
                 
                    $html = '<thead><tr><th style="width: 5%">S.no</th><th >Student ID</th><th style="width: 20%">Student Name</th><th>Country Code</th><th>Mobile Number</th><th>Email ID</th><th style="width: 20%">Qualification</th></tr></thead>';
                    $i = 1;
                    foreach ($reports as $key=>$val){
                        $html .= '<tr><td>'.$i.'</td><td>'.$val['studid'].'</td><td>'.$val['sname'].'</td><td>'.$val['mcode'].'</td><td>'.$val['contact'].'</td><td>'.$val['email'].'</td><td>'.$val['qualification'].'</td></tr>';
                        $i++;
                    }
                    
                    
                  } else if($type === 'bl'){
                      
                    $reports = $this->reports_model->DailyBillList($sdate,$edate,$center);
                    $savename = "Bill_Report_".date('d-m-Y-H_i_s');
                 
                    $html = '<thead><tr><th style="width: 5%">S.no</th><th >Student ID</th><th >CHL ID</th><th >Date</th><th >Bill No</th><th style="width: 20%">Student Name</th><th style="width: 20%">Course Name</th><th>Center</th><th>Paid</th><th>Payment Mode</th></tr></thead>';
                    $i = 1;
                    foreach ($reports as $key=>$val){
                        $html .= '<tr><td>'.$i.'</td><td>'.$val['studid'].'</td><td>'.$val['challanno'].'</td><td>'.$val['paydate'].'</td><td>'.$val['receiptno'].'</td><td>'.$val['sname'].'</td><td>'.$val['coursename'].'</td><td>'.$val['center'].'</td><td>'.$val['paid'].'</td><td>'.$val['paymentmode'].'</td></tr>';
                        $i++;
                    }
                    
                    
                  } else if($type === 'ul'){
                      
                    $reports = $this->reports_model->UnpaidList($sdate,$edate,$center);
                    $savename = "Unpaid_Report_".date('d-m-Y-H_i_s');
                 
                    $html = '<thead><tr><th style="width: 5%">S.no</th><th >Student ID</th><th >CHL ID</th><th style="width: 20%">Student Name</th><th style="width: 20%">Course Name</th><th>Center</th><th>Unpaid</th></tr></thead>';
                    $i = 1;
                    foreach ($reports as $key=>$val){
                        $html .= '<tr><td>'.$i.'</td><td>'.$val['studid'].'</td><td>'.$val['challanno'].'</td><td>'.$val['sname'].'</td><td>'.$val['coursename'].'</td><td>'.$val['center'].'</td><td>'.$val['unpaid'].'</td></tr>';
                        $i++;
                    }
                    
                    
                  } else if($type === 'stunpl'){
                      
                    $reports = $this->reports_model->FirstTimeStudentPaidList($sdate,$edate,$center);
                    $savename = "First_Time_Paid_Report_".date('d-m-Y-H_i_s');
                      
                        $html = '<thead><tr><th >S.no</th><th >Student ID</th><th >Student Name</th><th>Country Code</th><th>Mobile No</th><th>Email</th><th>City</th><th>Date of Birth:</th><th>Gender</th><th>Nationality</th><th>Category</th><th>Aadhar Number</th><th>Fathers Name</th><th>Country Code</th><th>Fathers Phone</th><th>Fathers Email</th><th>Fathers Occupation</th><th>Mothers Name</th><th>Country Code</th><th>Mothers Phone</th><th>Mothers Email</th><th>Mothers Occupation</th><th>Communication Contact</th><th>Blood Group</th><th>Class Studying / Complete</th><th>Stream</th><th>Name of School Last Studied / Studying</th><th>Address Line</th><th>Country</th><th>House / Appartment Name</th><th>Place / Street</th><th>Post Office</th><th>District</th><th>State</th><th>Country</th><th>Pincode</th><th>Country Code</th><th>Whatsapp Number</th><th>Guardian Name</th><th>Account Holder Name</th><th>Bank Name</th><th>Branch</th><th>IFSC Code</th><th>Bank Account Number</th><th>profile Percentage</th><th>Course Name</th><th>Center</th><th>Payment Date</th><th>Bill No</th><th>Paid</th><th>Payment Mode</th></tr></thead>';
                    $i = 1;
                    foreach ($reports as $key=>$val){
                        $landmark = ($val['landmark'] === "0")?"":$val['landmark'].",";
                        $html .= '<tr><td>'.$i.'</td><td>'.$val['studid'].'</td><td>'.$val['sname'].'</td><td>'.$val['mcode'].'</td><td>'.$val['contact'].'</td><td>'.$val['email'].'</td><td>'.$val['city'].'</td><td>'.$val['dob'].'</td><td>'.$val['gender'].'</td><td>'.$val['nationality'].'</td><td>'.$val['category'].'</td><td>'.$val['aadharnumber'].'</td><td>'.$val['fathername'].'</td><td>'.$val['fathercode'].'</td><td>'.$val['fatherphone'].'</td><td>'.$val['fatheremail'].'</td><td>'.$val['fatheroccupation'].'</td><td>'.$val['mothername'].'</td><td>'.$val['mothercode'].'</td><td>'.$val['motherphone'].'</td><td>'.$val['motheremail'].'</td><td>'.$val['motheroccupation'].'</td><td>'.$val['communicationcontact'].'</td><td>'.$val['bloodgroup'].'</td><td>'.$val['classstudy'].'</td><td>'.$val['stream'].'</td><td>'.$val['schoolcollegename'].'</td><td>'.$val['eduaddress'].",".$val['edulandmark'].",".$val['edudistrict'].",".$val['edustate'].",".$val['edupost'].",".$val['edupincode'].'</td><td>'.$val['educountry'].'</td><td>'.$val['housenameno'].'</td><td>'.$landmark.$val['contactaddress'].'</td><td>'.$val['contactpost'].'</td><td>'.$val['contactdistrict'].'</td><td>'.$val['contactstate'].'</td><td>'.$val['contactcountry'].'</td><td>'.$val['contactpincode'].'</td><td>'.$val['wacode'].'</td><td>'.$val['whatsappno'].'</td><td>'.$val['guardianname'].'</td><td>'.$val['accountholdername'].'</td><td>'.$val['bankname'].'</td><td>'.$val['branch'].'</td><td>'.$val['ifsccode'].'</td><td>'.$val['bankaccountno'].'</td><td>'.$val['profilepercent'].'</td><td>'.$val['coursename'].'</td><td>'.$val['center'].'</td><td>'.$val['paydate'].'</td><td>'.$val['receiptno'].'</td><td>'.$val['paid'].'</td><td>'.$val['paymentmode'].'</td></tr>';
                        $i++;
                    }
                    
                    
                  } else if($type === 'rfl'){
                      
                    $reports = $this->reports_model->RefundBillList($sdate,$edate,$center);
                    $savename = "Refund_Paid_Report_".date('d-m-Y-H_i_s');
                      
                    $html = '<thead><tr><th >S.no</th><th >App Date</th><th >App No</th><th >Student ID</th><th>Student Name</th><th>Course Nmae</th><th>Center</th><th>Refund Bill No</th><th>Remitted(without GST)</th><th>Refund Amount(without GST)</th><th>Trans Details</th><th>Reason For Refund</th></tr></thead>';
                    $i = 1;
                    foreach ($reports as $key=>$val){
                        
                        $html .= '<tr><td>'.$i.'</td><td>'.$val['appdate'].'</td><td>'.$val['appno'].'</td><td style="width:5% !important">'.$val['studid'].'</td><td>'.$val['sname'].'</td><td style="width:15% !important">'.$val['coursename'].'</td><td>'.$val['center'].'</td><td>'.$val['receiptno'].'</td><td style="width:5% !important">'.$val['remitted'].'</td><td style="width:5% !important">'.$val['refundamount'].'</td><td>'.$val['paydescription'].'</td><td>'.$val['reason'].'</td></tr>';
                        $i++;
                    }
                    
                    
                  } else if($type === 'wll'){
                      
                    $reports = $this->reports_model->WorldlineBillList($sdate,$edate,$center);
                    $savename = "Worldline_Report_".date('d-m-Y-H_i_s');
                      
                        $html = '<thead><tr><th >S.no</th><th >Student Name</th><th >Student ID</th><th >Course ID</th><th>Center</th><th>Order ID</th><th>Reference No</th><th>Amount</th><th>Date & Time</th><th>Status</th><th>Bill Number</th></tr></thead>';
                    $i = 1;
                    foreach ($reports as $key=>$val){
                        
                        $html .= '<tr><td>'.$i.'</td><td>'.$val['sname'].'</td><td>'.$val['studid'].'</td><td style="width:5% !important">'.$val['courseid'].'</td><td>'.$val['center'].'</td><td>'.$val['referenceid'].'</td><td style="width:15% !important">'.$val['referenceNo'].'</td><td>'.$val['paymentamount'].'</td><td style="width:5% !important">'.$val['paymentdate'].'</td><td style="width:5% !important">'.$val['statuscode'].'</td><td>'.$val['receiptno'].'</td></tr>';
                        $i++;
                    }
                  
                  } 
                  
                                   
                  $html = "<tr>Reports From ".date("d/m/Y H:i",strtotime($sdate))." to ". date("d/m/Y H:i",strtotime($edate))." </tr>".$html;       
                    $html = str_replace('<tr>',"\n",$html);
                     $html = str_replace('</tr>',"",$html);

                     $html = str_replace('</th>',"\t",$html);
                     $html = str_replace('<th>',"",$html);

                     $html = str_replace('</td>',"\t",$html);
                     $html = str_replace('<td>',"",$html);


                     $html = strip_tags($html);

                     $filename = $savename .".xls";

                     force_download($filename, $html);
            
               
           }else {
                //If no session, redirect to login page
                redirect('login', 'refresh');
            }
        }
        
     
}
||||||| .r336
<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Reports extends CI_Controller {

	function __construct() {
            
		parent::__construct();
                $this->load->model('login_model','',TRUE);
		$this->load->model('reports_model','',TRUE);
                $this->load->model('course_model','',TRUE);
                  $this->load->model('student_model','',TRUE);
                $this->load->helper('download');

	}
	
	function index() {
            
           if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')) {

                $session_data = $this->session->userdata('loggedin');
                $session_id = $session_data['id'];
                $session_role = $session_data['role'];
                $data['user'] = $this->login_model->GetUserId();

                $data['menu'] = $this->load->view('headermenu', $data, TRUE);
                
                $sdate = isset($_GET['sdate']) ? $_GET['sdate'] : '';
                $edate = isset($_GET['edate']) ? $_GET['edate'] : '';
                $type = isset($_GET['rtype']) ? $_GET['rtype'] : '';
                $center = isset($_GET['center']) ? $_GET['center'] : 'All';
                
                $sdate = ($sdate ==="")?(date('Y-m-d H:i:s',strtotime("-1 days"))):$sdate;
                $edate = ($edate ==="")?(date('Y-m-d H:i:s')):$edate;
                $type = ($type ==="")?'cr':$type;
               
               $data['sdate'] = $sdate;$data['edate'] = $edate;$data['center'] = $center;
               $data['units'] = $this->course_model->GetAllCenters($center,'option');
               $data['type'] = $type;
                if($type === 'cr') {                    
                    $data['reports'] = $this->reports_model->BillGeneratonSummary($sdate,$edate,$center);
                    $data['savename'] = "Accounts_Report_".date('d-m-Y-H_i_s');
                } else if($type === 'cwd'){
                    $data['reports'] = $this->reports_model->CourseWiseAdmittedList($sdate,$edate,$center);
                    $data['savename'] = "Course_Admitted__Report_".date('d-m-Y-H_i_s');
                } else if($type === 'dca'){
                    $data['reports'] = $this->reports_model->DailyCourseAppliedList($sdate,$edate,$center);
                    $data['savename'] = "Course_Applied_Report_".date('d-m-Y-H_i_s');
                } else if($type === 'sl'){
                    $data['reports'] = $this->reports_model->DailySignupList($sdate,$edate);
                    $data['savename'] = "Signup_Report_".date('d-m-Y-H_i_s');
                } else if($type === 'bl'){
                    $data['reports'] = $this->reports_model->DailyBillList($sdate,$edate,$center);
                    $data['savename'] = "Bill_Report_".date('d-m-Y-H_i_s');
                }  else if($type === 'ul'){
                    $data['reports'] = $this->reports_model->UnpaidList($sdate,$edate,$center);
                    $data['savename'] = "Unpaid_Report_".date('d-m-Y-H_i_s');
                } else if($type === 'stunpl'){
                    $data['reports'] = $this->reports_model->FirstTimeStudentPaidList($sdate,$edate,$center);
                    $data['savename'] = "First_Time_Paid_Report_".date('d-m-Y-H_i_s');
                } else if($type === 'rfl'){
                    $data['reports'] = $this->reports_model->RefundBillList($sdate,$edate,$center);
                    $data['savename'] = "Refund_Paid_Report_".date('d-m-Y-H_i_s');
                } else if($type === 'bulkprint'){
                    $reports = $this->reports_model->BulkPrintList($sdate,$edate,$center);
                   // var_dump($reports);exit();
                    $feesmaster = $this->student_model->getFeesMaster();
                    foreach($reports as $key=> $val) {
                       $feepaybill = $this->student_model->GetFeePaymentBill($val['studentid'],$val['requestid'],$val['challanno']);
                       $data['feepaybill'] .= $this->reports_model->BulkPrintView($feesmaster,$feepaybill,$val['studid'],$val['sname']);
                    }
                    
                    $this->load->view('bulk_print_view', $data);
                } 
                 if($type !== 'bulkprint'){
                 $this->load->view('header_view', $data);
                 $this->load->view('reports_view', $data);
                 $this->load->view('footer_view');
                 }
                
            } else {
                //If no session, redirect to login page
                redirect('login', 'refresh');
            }
            
        }
        
        function export() {
            
           if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')) {
               
               $sdate = isset($_GET['sdate']) ? $_GET['sdate'] : '';
                $edate = isset($_GET['edate']) ? $_GET['edate'] : '';
                $type = isset($_GET['rtype']) ? $_GET['rtype'] : '';
                $center = isset($_GET['center']) ? $_GET['center'] : 'All';
                
                $sdate = ($sdate ==="")?(date('Y-m-d H:i:s',strtotime("-1 days"))):$sdate;
                $edate = ($edate ==="")?(date('Y-m-d H:i:s')):$edate;
                $type = ($type ==="")?'cr':$type;
               
              if($type === 'cr') { 
                          
                  $reports = $this->reports_model->BillGeneratonSummary($sdate,$edate,$center);
                  $savename = "Accounts_Report_".date('d-m-Y-H_i_s');
                    
                  
                    $html = '<thead><tr><th>S.nO</th><th>Counter Id</th><th>Counter name</th><th>Description</th><th>Reg Fee</th><th>Tuition Fee</th><th>S.Tax / <br>CGST</th><th>SB <br>CESS/<br>SGST</th><th>KK <br>CESS/<br>IGST/<br>KFC</th><th>CD</th><th>Other</th><th>Total</th><th>Cash</th><th>Card</th><th>Cheque</th><th>DD</th><th>SIB <br>Challan</th><th>Transfer</th><th>Online</th><th>Total</th><th>TDS</th></tr></thead>';
                    $i = 1; $mregFee = 0;$mtutionFee = 0;$mcgst = 0;$msgst = 0;
                    $mkf = 0;$mcd = 0;$mother = 0;$mtotal = 0;$mcash = 0;$mcard = 0;
                    $mcheque = 0;$mdd = 0;$mchallan = 0;$mtransfer = 0;$monline = 0;$mother1 = 0;$mpaid = 0;
                    foreach ($reports as $key=>$val){
                        if(($key === "count")||($key === "billno")) {continue;}
                        $coursename = array_key_exists('cname', $val)?$val['cname']:"";
                        $coursename = preg_replace("/\s+/", " ", $coursename);
                        $regFee = array_key_exists('Reg Fee', $val)?$val['Reg Fee']:0;
                        $tutionFee = array_key_exists('Tuition Fee', $val)?$val['Tuition Fee']:0;
                        $cd = array_key_exists('CD', $val)?$val['CD']:0;
                        $total = array_key_exists('total', $val)?$val['total']:0;
                        $paid = array_key_exists('paid', $val)?$val['paid']:0;
                        $tutionFee = round($tutionFee);

                        $cash = array_key_exists('cash', $val)?$val['cash']:0;
                        $dd = array_key_exists('dd', $val)?$val['dd']:0;
                        $challan = array_key_exists('challan', $val)?$val['challan']:0;
                        if($challan === 0 ) {$challan = array_key_exists('chellan', $val)?$val['chellan']:0;}
                        $transfer = array_key_exists('net', $val)?$val['net']:0;
                        $online = array_key_exists('online', $val)?$val['online']:0;
                        $card = array_key_exists('card', $val)?$val['card']:0;
                        $cheque = array_key_exists('cheque', $val)?$val['cheque']:0;

                        $calamount = floatval($regFee)+floatval($tutionFee);
                        $cgst = floatval($calamount)*.09;
                        $sgst = floatval($calamount)*.09;
                        $kf   = floatval($calamount)*.01;

                        $other = floatval($total) - (floatval($calamount)+floatval($cgst)+floatval($sgst)+floatval($kf)+floatval($cd));
                        $other1 = (floatval($cash)+floatval($dd)+floatval($challan)+floatval($transfer)+floatval($online)+floatval($card)+floatval($cheque))-floatval($paid);
                        $other = round($other,2);
                        $other1 = round($other1,2);
                        $cgst = round($cgst,2);
                        $sgst = round($sgst,2);
                        $kf = round($kf,2);

                        $html .= '<tr><td>'.$i.'</td><td>ALL</td><td>'.$center.'</td><td>'.$coursename.'</td><td>'.$regFee.'</td><td>'.$tutionFee.'</td><td>'.$cgst.'</td><td>'.$sgst.'</td><td>'.$kf.'</td><td>'.$cd.'</td><td>'.$other.'</td><td>'.$total.'</td><td>'.$cash.'</td><td>'.$card.'</td><td>'.$cheque.'</td><td>'.$dd.'</td><td>'.$challan.'</td><td>'.$transfer.'</td><td>'.$online.'</td><td>'.$paid.'</td><td>0</td></tr>';
                        $i++;
                        $mregFee = floatval($mregFee)+floatval($regFee);$mtutionFee = floatval($mtutionFee)+floatval($tutionFee);
                        $mcgst = floatval($mcgst)+floatval($cgst);$msgst = floatval($msgst)+floatval($sgst);$mkf = floatval($mkf)+floatval($kf);
                        $mcd = floatval($mcd)+floatval($cd);$mother = floatval($mother)+floatval($other);$mtotal = floatval($mtotal)+floatval($total);
                        $mcash = floatval($mcash)+floatval($cash);$mcard = floatval($mcard)+floatval($card); $mcheque = floatval($mcheque)+floatval($cheque);
                        $mdd = floatval($mdd)+floatval($dd);$mchallan = floatval($mchallan)+floatval($challan);$mtransfer = floatval($mtransfer)+floatval($transfer);
                        $monline = floatval($monline)+floatval($online);$mother1 = 0;$mpaid = floatval($mpaid)+floatval($paid);
                    }
                    if($i === 1) { } else{
                        
                        
                    $html .= '<tr><td></td><td></td><td></td><td></td><td>'.$mregFee.'</td><td>'.$mtutionFee.'</td><td>'.$mcgst.'</td><td>'.$msgst.'</td><td>'.$mkf.'</td><td>'.$mcd.'</td><td>'.$mother.'</td><td>'.$mtotal.'</td><td>'.$mcash.'</td><td>'.$mcard.'</td><td>'.$mcheque.'</td><td>'.$mdd.'</td><td>'.$mchallan.'</td><td>'.$mtransfer.'</td><td>'.$monline.'</td><td>'.$mpaid.'</td><td>0</td></tr>';
                    }

       
           } else if($type === 'cwd'){ 
               
                    $reports = $this->reports_model->CourseWiseAdmittedList($sdate,$edate,$center);
                    $savename = "Course_Admitted__Report_".date('d-m-Y-H_i_s');               
              
                    $html = '<thead><tr><th>S.no</th><th style="width: 30%">Course Name</th><th>Center</th><th>Student ID</th><th style="width: 10%">Student Name</th><th>Country Code</th><th>Mobile Number</th><th>Whats App No.</th><th>Email ID</th><th style="width: 20%">Qualification</th><th>Stream</th><th>Course Fee</th><th>Remitted</th><th>Initial Payment Date</th></tr></thead>';
                    $i = 1;
                    foreach ($reports as $key=>$val){
                        $html .= '<tr><td>'.$i.'</td><td>'.$val['coursename'].'</td><td>'.$val['center'].'</td><td>'.$val['studid'].'</td><td>'.$val['sname'].'</td><td>'.$val['mcode'].'</td><td>'.$val['contact'].'</td><td>'.$val['whatsappno'].'</td><td>'.$val['email'].'</td><td>'.$val['name'].'</td><td>'.$val['stream'].'</td><td>'.$val['total'].'</td><td>'.$val['remitted'].'</td><td>'.$val['pdate'].'</td> </tr>';
                        $i++;
                    }
                           
                 } else if($type === 'dca'){ 
                     
                    $reports = $this->reports_model->DailyCourseAppliedList($sdate,$edate,$center);
                    $savename = "Course_Applied_Report_".date('d-m-Y-H_i_s');
                    
                    $html = '<thead><tr><th>S.no</th><th>Student ID</th><th style="width: 20%">Student Name</th><th>Country Code</th><th>Mobile Number</th><th>Email ID</th><th style="width: 20%">Qualification</th><th>Stream</th><th style="width: 20%">Applied Course</th><th>Center</th><th>Present Status</th><th>Date of Registration</th></tr></thead>';
                    $i = 1;
                    foreach ($reports as $key=>$val){
                        $html .= '<tr><td>'.$i.'</td><td>'.$val['studid'].'</td><td>'.$val['sname'].'</td><td>'.$val['mcode'].'</td><td>'.$val['contact'].'</td><td>'.$val['email'].'</td><td>'.$val['qualification'].'</td><td>'.$val['stream'].'</td><td>'.$val['coursename'].'</td><td>'.$val['center'].'</td><td>'.$val['status'].'</td><td>'.$val['rdate'].'</td></tr>';
                        $i++;
                    }
                 
                  }else if($type === 'sl'){
                      
                    $reports = $this->reports_model->DailySignupList($sdate,$edate);
                    $savename = "Signup_Report_".date('d-m-Y-H_i_s');
                 
                    $html = '<thead><tr><th style="width: 5%">S.no</th><th >Student ID</th><th style="width: 20%">Student Name</th><th>Country Code</th><th>Mobile Number</th><th>Email ID</th><th style="width: 20%">Qualification</th></tr></thead>';
                    $i = 1;
                    foreach ($reports as $key=>$val){
                        $html .= '<tr><td>'.$i.'</td><td>'.$val['studid'].'</td><td>'.$val['sname'].'</td><td>'.$val['mcode'].'</td><td>'.$val['contact'].'</td><td>'.$val['email'].'</td><td>'.$val['qualification'].'</td></tr>';
                        $i++;
                    }
                    
                    
                  } else if($type === 'bl'){
                      
                    $reports = $this->reports_model->DailyBillList($sdate,$edate,$center);
                    $savename = "Bill_Report_".date('d-m-Y-H_i_s');
                 
                    $html = '<thead><tr><th style="width: 5%">S.no</th><th >Student ID</th><th >CHL ID</th><th >Date</th><th >Bill No</th><th style="width: 20%">Student Name</th><th style="width: 20%">Course Name</th><th>Center</th><th>Paid</th><th>Payment Mode</th></tr></thead>';
                    $i = 1;
                    foreach ($reports as $key=>$val){
                        $html .= '<tr><td>'.$i.'</td><td>'.$val['studid'].'</td><td>'.$val['challanno'].'</td><td>'.$val['paydate'].'</td><td>'.$val['receiptno'].'</td><td>'.$val['sname'].'</td><td>'.$val['coursename'].'</td><td>'.$val['center'].'</td><td>'.$val['paid'].'</td><td>'.$val['paymentmode'].'</td></tr>';
                        $i++;
                    }
                    
                    
                  } else if($type === 'ul'){
                      
                    $reports = $this->reports_model->UnpaidList($sdate,$edate,$center);
                    $savename = "Unpaid_Report_".date('d-m-Y-H_i_s');
                 
                    $html = '<thead><tr><th style="width: 5%">S.no</th><th >Student ID</th><th >CHL ID</th><th style="width: 20%">Student Name</th><th style="width: 20%">Course Name</th><th>Center</th><th>Unpaid</th></tr></thead>';
                    $i = 1;
                    foreach ($reports as $key=>$val){
                        $html .= '<tr><td>'.$i.'</td><td>'.$val['studid'].'</td><td>'.$val['challanno'].'</td><td>'.$val['sname'].'</td><td>'.$val['coursename'].'</td><td>'.$val['center'].'</td><td>'.$val['unpaid'].'</td></tr>';
                        $i++;
                    }
                    
                    
                  } else if($type === 'stunpl'){
                      
                    $reports = $this->reports_model->FirstTimeStudentPaidList($sdate,$edate,$center);
                    $savename = "First_Time_Paid_Report_".date('d-m-Y-H_i_s');
                      
                        $html = '<thead><tr><th >S.no</th><th >Student ID</th><th >Student Name</th><th>Country Code</th><th>Mobile No</th><th>Email</th><th>City</th><th>Date of Birth:</th><th>Gender</th><th>Nationality</th><th>Category</th><th>Aadhar Number</th><th>Fathers Name</th><th>Country Code</th><th>Fathers Phone</th><th>Fathers Email</th><th>Fathers Occupation</th><th>Mothers Name</th><th>Country Code</th><th>Mothers Phone</th><th>Mothers Email</th><th>Mothers Occupation</th><th>Communication Contact</th><th>Blood Group</th><th>Class Studying / Complete</th><th>Stream</th><th>Name of School Last Studied / Studying</th><th>Address Line</th><th>Country</th><th>House / Appartment Name</th><th>Place / Street</th><th>Post Office</th><th>District</th><th>State</th><th>Country</th><th>Pincode</th><th>Country Code</th><th>Whatsapp Number</th><th>Guardian Name</th><th>Account Holder Name</th><th>Bank Name</th><th>Branch</th><th>IFSC Code</th><th>Bank Account Number</th><th>profile Percentage</th><th>Course Name</th><th>Center</th><th>Payment Date</th><th>Bill No</th><th>Paid</th><th>Payment Mode</th></tr></thead>';
                    $i = 1;
                    foreach ($reports as $key=>$val){
                        $landmark = ($val['landmark'] === "0")?"":$val['landmark'].",";
                        $html .= '<tr><td>'.$i.'</td><td>'.$val['studid'].'</td><td>'.$val['sname'].'</td><td>'.$val['mcode'].'</td><td>'.$val['contact'].'</td><td>'.$val['email'].'</td><td>'.$val['city'].'</td><td>'.$val['dob'].'</td><td>'.$val['gender'].'</td><td>'.$val['nationality'].'</td><td>'.$val['category'].'</td><td>'.$val['aadharnumber'].'</td><td>'.$val['fathername'].'</td><td>'.$val['fathercode'].'</td><td>'.$val['fatherphone'].'</td><td>'.$val['fatheremail'].'</td><td>'.$val['fatheroccupation'].'</td><td>'.$val['mothername'].'</td><td>'.$val['mothercode'].'</td><td>'.$val['motherphone'].'</td><td>'.$val['motheremail'].'</td><td>'.$val['motheroccupation'].'</td><td>'.$val['communicationcontact'].'</td><td>'.$val['bloodgroup'].'</td><td>'.$val['classstudy'].'</td><td>'.$val['stream'].'</td><td>'.$val['schoolcollegename'].'</td><td>'.$val['eduaddress'].",".$val['edulandmark'].",".$val['edudistrict'].",".$val['edustate'].",".$val['edupost'].",".$val['edupincode'].'</td><td>'.$val['educountry'].'</td><td>'.$val['housenameno'].'</td><td>'.$landmark.$val['contactaddress'].'</td><td>'.$val['contactpost'].'</td><td>'.$val['contactdistrict'].'</td><td>'.$val['contactstate'].'</td><td>'.$val['contactcountry'].'</td><td>'.$val['contactpincode'].'</td><td>'.$val['wacode'].'</td><td>'.$val['whatsappno'].'</td><td>'.$val['guardianname'].'</td><td>'.$val['accountholdername'].'</td><td>'.$val['bankname'].'</td><td>'.$val['branch'].'</td><td>'.$val['ifsccode'].'</td><td>'.$val['bankaccountno'].'</td><td>'.$val['profilepercent'].'</td><td>'.$val['coursename'].'</td><td>'.$val['center'].'</td><td>'.$val['paydate'].'</td><td>'.$val['receiptno'].'</td><td>'.$val['paid'].'</td><td>'.$val['paymentmode'].'</td></tr>';
                        $i++;
                    }
                    
                    
                  } else if($type === 'rfl'){
                      
                    $reports = $this->reports_model->RefundBillList($sdate,$edate,$center);
                    $savename = "Refund_Paid_Report_".date('d-m-Y-H_i_s');
                      
                    $html = '<thead><tr><th >S.no</th><th >App Date</th><th >App No</th><th >Student ID</th><th>Student Name</th><th>Course Nmae</th><th>Center</th><th>Refund Bill No</th><th>Remitted(without GST)</th><th>Refund Amount(without GST)</th><th>Trans Details</th><th>Reason For Refund</th></tr></thead>';
                    $i = 1;
                    foreach ($reports as $key=>$val){
                        
                        $html .= '<tr><td>'.$i.'</td><td>'.$val['appdate'].'</td><td>'.$val['appno'].'</td><td style="width:5% !important">'.$val['studid'].'</td><td>'.$val['sname'].'</td><td style="width:15% !important">'.$val['coursename'].'</td><td>'.$val['center'].'</td><td>'.$val['receiptno'].'</td><td style="width:5% !important">'.$val['remitted'].'</td><td style="width:5% !important">'.$val['refundamount'].'</td><td>'.$val['paydescription'].'</td><td>'.$val['reason'].'</td></tr>';
                        $i++;
                    }
                    
                    
                  } 
                  
                                   
                  $html = "<tr>Reports From ".date("d/m/Y H:i",strtotime($sdate))." to ". date("d/m/Y H:i",strtotime($edate))." </tr>".$html;       
                    $html = str_replace('<tr>',"\n",$html);
                     $html = str_replace('</tr>',"",$html);

                     $html = str_replace('</th>',"\t",$html);
                     $html = str_replace('<th>',"",$html);

                     $html = str_replace('</td>',"\t",$html);
                     $html = str_replace('<td>',"",$html);


                     $html = strip_tags($html);

                     $filename = $savename .".xls";

                     force_download($filename, $html);
            
               
           }else {
                //If no session, redirect to login page
                redirect('login', 'refresh');
            }
        }
        
     
}
=======
<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Reports extends CI_Controller {

	function __construct() {
            
		parent::__construct();
                $this->load->model('login_model','',TRUE);
		$this->load->model('reports_model','',TRUE);
                $this->load->model('course_model','',TRUE);
                  $this->load->model('student_model','',TRUE);
                $this->load->helper('download');

	}
	
	function index() {
            
           if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')) {

                $session_data = $this->session->userdata('loggedin');
                $session_id = $session_data['id'];
                $session_role = $session_data['role'];
                $data['user'] = $this->login_model->GetUserId();

                $data['menu'] = $this->load->view('headermenu', $data, TRUE);
                
                $sdate = isset($_GET['sdate']) ? $_GET['sdate'] : '';
                $edate = isset($_GET['edate']) ? $_GET['edate'] : '';
                $type = isset($_GET['rtype']) ? $_GET['rtype'] : '';
                $center = isset($_GET['center']) ? $_GET['center'] : 'All';
                
                $sdate = ($sdate ==="")?(date('Y-m-d H:i:s',strtotime("-1 days"))):$sdate;
                $edate = ($edate ==="")?(date('Y-m-d H:i:s')):$edate;
                $type = ($type ==="")?'cr':$type;
               
               $data['sdate'] = $sdate;$data['edate'] = $edate;$data['center'] = $center;
               $data['units'] = $this->course_model->GetAllCenters($center,'option');
               $data['type'] = $type;
                if($type === 'cr') {                    
                    $data['reports'] = $this->reports_model->BillGeneratonSummary($sdate,$edate,$center);
                    $data['savename'] = "Accounts_Report_".date('d-m-Y-H_i_s');
                } else if($type === 'cwd'){
                    $data['reports'] = $this->reports_model->CourseWiseAdmittedList($sdate,$edate,$center);
                    $data['savename'] = "Course_Admitted__Report_".date('d-m-Y-H_i_s');
                } else if($type === 'dca'){
                    $data['reports'] = $this->reports_model->DailyCourseAppliedList($sdate,$edate,$center);
                    $data['savename'] = "Course_Applied_Report_".date('d-m-Y-H_i_s');
                } else if($type === 'sl'){
                    $data['reports'] = $this->reports_model->DailySignupList($sdate,$edate);
                    $data['savename'] = "Signup_Report_".date('d-m-Y-H_i_s');
                } else if($type === 'bl'){
                    $data['reports'] = $this->reports_model->DailyBillList($sdate,$edate,$center);
                    $data['savename'] = "Bill_Report_".date('d-m-Y-H_i_s');
                }  else if($type === 'ul'){
                    $data['reports'] = $this->reports_model->UnpaidList($sdate,$edate,$center);
                    $data['savename'] = "Unpaid_Report_".date('d-m-Y-H_i_s');
                } else if($type === 'stunpl'){
                    $data['reports'] = $this->reports_model->FirstTimeStudentPaidList($sdate,$edate,$center);
                    $data['savename'] = "First_Time_Paid_Report_".date('d-m-Y-H_i_s');
                } else if($type === 'rfl'){
                    $data['reports'] = $this->reports_model->RefundBillList($sdate,$edate,$center);
                    $data['savename'] = "Refund_Paid_Report_".date('d-m-Y-H_i_s');
                }else if($type === 'ccl'){
                    $data['reports'] = $this->reports_model->CourseChangeList($sdate,$edate,$center);
                    $data['savename'] = "Course_Change_Report_".date('d-m-Y-H_i_s');
                } else if($type === 'bulkprint'){
                    $reports = $this->reports_model->BulkPrintList($sdate,$edate,$center);
                   // var_dump($reports);exit();
                    $feesmaster = $this->student_model->getFeesMaster();
                    foreach($reports as $key=> $val) {
                       $feepaybill = $this->student_model->GetFeePaymentBill($val['studentid'],$val['requestid'],$val['challanno']);
                       $data['feepaybill'] .= $this->reports_model->BulkPrintView($feesmaster,$feepaybill,$val['studid'],$val['sname']);
                    }
                    
                    $this->load->view('bulk_print_view', $data);
                } 
                 if($type !== 'bulkprint'){
                 $this->load->view('header_view', $data);
                 $this->load->view('reports_view', $data);
                 $this->load->view('footer_view');
                 }
                
            } else {
                //If no session, redirect to login page
                redirect('login', 'refresh');
            }
            
        }
        
        function export() {
            
           if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')) {
               
               $sdate = isset($_GET['sdate']) ? $_GET['sdate'] : '';
                $edate = isset($_GET['edate']) ? $_GET['edate'] : '';
                $type = isset($_GET['rtype']) ? $_GET['rtype'] : '';
                $center = isset($_GET['center']) ? $_GET['center'] : 'All';
                
                $sdate = ($sdate ==="")?(date('Y-m-d H:i:s',strtotime("-1 days"))):$sdate;
                $edate = ($edate ==="")?(date('Y-m-d H:i:s')):$edate;
                $type = ($type ==="")?'cr':$type;
               
              if($type === 'cr') { 
                          
                  $reports = $this->reports_model->BillGeneratonSummary($sdate,$edate,$center);
                  $savename = "Accounts_Report_".date('d-m-Y-H_i_s');
                    
                  
                    $html = '<thead><tr><th>S.nO</th><th>Counter Id</th><th>Counter name</th><th>Description</th><th>Reg Fee</th><th>Tuition Fee</th><th>S.Tax / <br>CGST</th><th>SB <br>CESS/<br>SGST</th><th>KK <br>CESS/<br>IGST/<br>KFC</th><th>CD</th><th>Other</th><th>Total</th><th>Cash</th><th>Card</th><th>Cheque</th><th>DD</th><th>SIB <br>Challan</th><th>Transfer</th><th>Online</th><th>Total</th><th>TDS</th></tr></thead>';
                    $i = 1; $mregFee = 0;$mtutionFee = 0;$mcgst = 0;$msgst = 0;
                    $mkf = 0;$mcd = 0;$mother = 0;$mtotal = 0;$mcash = 0;$mcard = 0;
                    $mcheque = 0;$mdd = 0;$mchallan = 0;$mtransfer = 0;$monline = 0;$mother1 = 0;$mpaid = 0;
                    foreach ($reports as $key=>$val){
                        if(($key === "count")||($key === "billno")) {continue;}
                        $coursename = array_key_exists('cname', $val)?$val['cname']:"";
                        $coursename = preg_replace("/\s+/", " ", $coursename);
                        $regFee = array_key_exists('Reg Fee', $val)?$val['Reg Fee']:0;
                        $tutionFee = array_key_exists('Tuition Fee', $val)?$val['Tuition Fee']:0;
                        $cd = array_key_exists('CD', $val)?$val['CD']:0;
                        $total = array_key_exists('total', $val)?$val['total']:0;
                        $paid = array_key_exists('paid', $val)?$val['paid']:0;
                        $tutionFee = round($tutionFee);

                        $cash = array_key_exists('cash', $val)?$val['cash']:0;
                        $dd = array_key_exists('dd', $val)?$val['dd']:0;
                        $challan = array_key_exists('challan', $val)?$val['challan']:0;
                        if($challan === 0 ) {$challan = array_key_exists('chellan', $val)?$val['chellan']:0;}
                        $transfer = array_key_exists('net', $val)?$val['net']:0;
                        $online = array_key_exists('online', $val)?$val['online']:0;
                        $card = array_key_exists('card', $val)?$val['card']:0;
                        $cheque = array_key_exists('cheque', $val)?$val['cheque']:0;

                        $calamount = floatval($regFee)+floatval($tutionFee);
                        $cgst = floatval($calamount)*.09;
                        $sgst = floatval($calamount)*.09;
                        $kf   = floatval($calamount)*.01;

                        $other = floatval($total) - (floatval($calamount)+floatval($cgst)+floatval($sgst)+floatval($kf)+floatval($cd));
                        $other1 = (floatval($cash)+floatval($dd)+floatval($challan)+floatval($transfer)+floatval($online)+floatval($card)+floatval($cheque))-floatval($paid);
                        $other = round($other,2);
                        $other1 = round($other1,2);
                        $cgst = round($cgst,2);
                        $sgst = round($sgst,2);
                        $kf = round($kf,2);

                        $html .= '<tr><td>'.$i.'</td><td>ALL</td><td>'.$center.'</td><td>'.$coursename.'</td><td>'.$regFee.'</td><td>'.$tutionFee.'</td><td>'.$cgst.'</td><td>'.$sgst.'</td><td>'.$kf.'</td><td>'.$cd.'</td><td>'.$other.'</td><td>'.$total.'</td><td>'.$cash.'</td><td>'.$card.'</td><td>'.$cheque.'</td><td>'.$dd.'</td><td>'.$challan.'</td><td>'.$transfer.'</td><td>'.$online.'</td><td>'.$paid.'</td><td>0</td></tr>';
                        $i++;
                        $mregFee = floatval($mregFee)+floatval($regFee);$mtutionFee = floatval($mtutionFee)+floatval($tutionFee);
                        $mcgst = floatval($mcgst)+floatval($cgst);$msgst = floatval($msgst)+floatval($sgst);$mkf = floatval($mkf)+floatval($kf);
                        $mcd = floatval($mcd)+floatval($cd);$mother = floatval($mother)+floatval($other);$mtotal = floatval($mtotal)+floatval($total);
                        $mcash = floatval($mcash)+floatval($cash);$mcard = floatval($mcard)+floatval($card); $mcheque = floatval($mcheque)+floatval($cheque);
                        $mdd = floatval($mdd)+floatval($dd);$mchallan = floatval($mchallan)+floatval($challan);$mtransfer = floatval($mtransfer)+floatval($transfer);
                        $monline = floatval($monline)+floatval($online);$mother1 = 0;$mpaid = floatval($mpaid)+floatval($paid);
                    }
                    if($i === 1) { } else{
                        
                        
                    $html .= '<tr><td></td><td></td><td></td><td></td><td>'.$mregFee.'</td><td>'.$mtutionFee.'</td><td>'.$mcgst.'</td><td>'.$msgst.'</td><td>'.$mkf.'</td><td>'.$mcd.'</td><td>'.$mother.'</td><td>'.$mtotal.'</td><td>'.$mcash.'</td><td>'.$mcard.'</td><td>'.$mcheque.'</td><td>'.$mdd.'</td><td>'.$mchallan.'</td><td>'.$mtransfer.'</td><td>'.$monline.'</td><td>'.$mpaid.'</td><td>0</td></tr>';
                    }

       
           } else if($type === 'cwd'){ 
               
                    $reports = $this->reports_model->CourseWiseAdmittedList($sdate,$edate,$center);
                    $savename = "Course_Admitted__Report_".date('d-m-Y-H_i_s');               
              
                    $html = '<thead><tr><th>S.no</th><th style="width: 30%">Course Name</th><th>Center</th><th>Student ID</th><th style="width: 10%">Student Name</th><th>Country Code</th><th>Mobile Number</th><th>Whats App No.</th><th>Email ID</th><th style="width: 20%">Qualification</th><th>Stream</th><th>Course Fee</th><th>Remitted</th><th>Initial Payment Date</th></tr></thead>';
                    $i = 1;
                    foreach ($reports as $key=>$val){
                        $html .= '<tr><td>'.$i.'</td><td>'.$val['coursename'].'</td><td>'.$val['center'].'</td><td>'.$val['studid'].'</td><td>'.$val['sname'].'</td><td>'.$val['mcode'].'</td><td>'.$val['contact'].'</td><td>'.$val['whatsappno'].'</td><td>'.$val['email'].'</td><td>'.$val['name'].'</td><td>'.$val['stream'].'</td><td>'.$val['total'].'</td><td>'.$val['remitted'].'</td><td>'.$val['pdate'].'</td> </tr>';
                        $i++;
                    }
                           
                 } else if($type === 'dca'){ 
                     
                    $reports = $this->reports_model->DailyCourseAppliedList($sdate,$edate,$center);
                    $savename = "Course_Applied_Report_".date('d-m-Y-H_i_s');
                    
                    $html = '<thead><tr><th>S.no</th><th>Student ID</th><th style="width: 20%">Student Name</th><th>Country Code</th><th>Mobile Number</th><th>Email ID</th><th style="width: 20%">Qualification</th><th>Stream</th><th style="width: 20%">Applied Course</th><th>Center</th><th>Present Status</th><th>Date of Registration</th></tr></thead>';
                    $i = 1;
                    foreach ($reports as $key=>$val){
                        $html .= '<tr><td>'.$i.'</td><td>'.$val['studid'].'</td><td>'.$val['sname'].'</td><td>'.$val['mcode'].'</td><td>'.$val['contact'].'</td><td>'.$val['email'].'</td><td>'.$val['qualification'].'</td><td>'.$val['stream'].'</td><td>'.$val['coursename'].'</td><td>'.$val['center'].'</td><td>'.$val['status'].'</td><td>'.$val['rdate'].'</td></tr>';
                        $i++;
                    }
                 
                  }else if($type === 'sl'){
                      
                    $reports = $this->reports_model->DailySignupList($sdate,$edate);
                    $savename = "Signup_Report_".date('d-m-Y-H_i_s');
                 
                    $html = '<thead><tr><th style="width: 5%">S.no</th><th >Student ID</th><th style="width: 20%">Student Name</th><th>Country Code</th><th>Mobile Number</th><th>Email ID</th><th style="width: 20%">Qualification</th></tr></thead>';
                    $i = 1;
                    foreach ($reports as $key=>$val){
                        $html .= '<tr><td>'.$i.'</td><td>'.$val['studid'].'</td><td>'.$val['sname'].'</td><td>'.$val['mcode'].'</td><td>'.$val['contact'].'</td><td>'.$val['email'].'</td><td>'.$val['qualification'].'</td></tr>';
                        $i++;
                    }
                    
                    
                  } else if($type === 'bl'){
                      
                    $reports = $this->reports_model->DailyBillList($sdate,$edate,$center);
                    $savename = "Bill_Report_".date('d-m-Y-H_i_s');
                 
                    $html = '<thead><tr><th style="width: 5%">S.no</th><th >Student ID</th><th >CHL ID</th><th >Date</th><th >Bill No</th><th style="width: 20%">Student Name</th><th style="width: 20%">Course Name</th><th>Center</th><th>Paid</th><th>Payment Mode</th></tr></thead>';
                    $i = 1;
                    foreach ($reports as $key=>$val){
                        $html .= '<tr><td>'.$i.'</td><td>'.$val['studid'].'</td><td>'.$val['challanno'].'</td><td>'.$val['paydate'].'</td><td>'.$val['receiptno'].'</td><td>'.$val['sname'].'</td><td>'.$val['coursename'].'</td><td>'.$val['center'].'</td><td>'.$val['paid'].'</td><td>'.$val['paymentmode'].'</td></tr>';
                        $i++;
                    }
                    
                    
                  } else if($type === 'ul'){
                      
                    $reports = $this->reports_model->UnpaidList($sdate,$edate,$center);
                    $savename = "Unpaid_Report_".date('d-m-Y-H_i_s');
                 
                    $html = '<thead><tr><th style="width: 5%">S.no</th><th >Student ID</th><th >CHL ID</th><th style="width: 20%">Student Name</th><th style="width: 20%">Course Name</th><th>Center</th><th>Unpaid</th></tr></thead>';
                    $i = 1;
                    foreach ($reports as $key=>$val){
                        $html .= '<tr><td>'.$i.'</td><td>'.$val['studid'].'</td><td>'.$val['challanno'].'</td><td>'.$val['sname'].'</td><td>'.$val['coursename'].'</td><td>'.$val['center'].'</td><td>'.$val['unpaid'].'</td></tr>';
                        $i++;
                    }
                    
                    
                  } else if($type === 'stunpl'){
                      
                    $reports = $this->reports_model->FirstTimeStudentPaidList($sdate,$edate,$center);
                    $savename = "First_Time_Paid_Report_".date('d-m-Y-H_i_s');
                      
                        $html = '<thead><tr><th >S.no</th><th >Student ID</th><th >Student Name</th><th>Country Code</th><th>Mobile No</th><th>Email</th><th>City</th><th>Date of Birth:</th><th>Gender</th><th>Nationality</th><th>Category</th><th>Aadhar Number</th><th>Fathers Name</th><th>Country Code</th><th>Fathers Phone</th><th>Fathers Email</th><th>Fathers Occupation</th><th>Mothers Name</th><th>Country Code</th><th>Mothers Phone</th><th>Mothers Email</th><th>Mothers Occupation</th><th>Communication Contact</th><th>Blood Group</th><th>Class Studying / Complete</th><th>Stream</th><th>Name of School Last Studied / Studying</th><th>Address Line</th><th>Country</th><th>House / Appartment Name</th><th>Place / Street</th><th>Post Office</th><th>District</th><th>State</th><th>Country</th><th>Pincode</th><th>Country Code</th><th>Whatsapp Number</th><th>Guardian Name</th><th>Account Holder Name</th><th>Bank Name</th><th>Branch</th><th>IFSC Code</th><th>Bank Account Number</th><th>profile Percentage</th><th>Course Name</th><th>Center</th><th>Payment Date</th><th>Bill No</th><th>Paid</th><th>Payment Mode</th></tr></thead>';
                    $i = 1;
                    foreach ($reports as $key=>$val){
                        $landmark = ($val['landmark'] === "0")?"":$val['landmark'].",";
                        $html .= '<tr><td>'.$i.'</td><td>'.$val['studid'].'</td><td>'.$val['sname'].'</td><td>'.$val['mcode'].'</td><td>'.$val['contact'].'</td><td>'.$val['email'].'</td><td>'.$val['city'].'</td><td>'.$val['dob'].'</td><td>'.$val['gender'].'</td><td>'.$val['nationality'].'</td><td>'.$val['category'].'</td><td>'.$val['aadharnumber'].'</td><td>'.$val['fathername'].'</td><td>'.$val['fathercode'].'</td><td>'.$val['fatherphone'].'</td><td>'.$val['fatheremail'].'</td><td>'.$val['fatheroccupation'].'</td><td>'.$val['mothername'].'</td><td>'.$val['mothercode'].'</td><td>'.$val['motherphone'].'</td><td>'.$val['motheremail'].'</td><td>'.$val['motheroccupation'].'</td><td>'.$val['communicationcontact'].'</td><td>'.$val['bloodgroup'].'</td><td>'.$val['classstudy'].'</td><td>'.$val['stream'].'</td><td>'.$val['schoolcollegename'].'</td><td>'.$val['eduaddress'].",".$val['edulandmark'].",".$val['edudistrict'].",".$val['edustate'].",".$val['edupost'].",".$val['edupincode'].'</td><td>'.$val['educountry'].'</td><td>'.$val['housenameno'].'</td><td>'.$landmark.$val['contactaddress'].'</td><td>'.$val['contactpost'].'</td><td>'.$val['contactdistrict'].'</td><td>'.$val['contactstate'].'</td><td>'.$val['contactcountry'].'</td><td>'.$val['contactpincode'].'</td><td>'.$val['wacode'].'</td><td>'.$val['whatsappno'].'</td><td>'.$val['guardianname'].'</td><td>'.$val['accountholdername'].'</td><td>'.$val['bankname'].'</td><td>'.$val['branch'].'</td><td>'.$val['ifsccode'].'</td><td>'.$val['bankaccountno'].'</td><td>'.$val['profilepercent'].'</td><td>'.$val['coursename'].'</td><td>'.$val['center'].'</td><td>'.$val['paydate'].'</td><td>'.$val['receiptno'].'</td><td>'.$val['paid'].'</td><td>'.$val['paymentmode'].'</td></tr>';
                        $i++;
                    }
                    
                    
                  } else if($type === 'rfl'){
                      
                    $reports = $this->reports_model->RefundBillList($sdate,$edate,$center);
                    $savename = "Refund_Paid_Report_".date('d-m-Y-H_i_s');
                      
                    $html = '<thead><tr><th >S.no</th><th >App Date</th><th >App No</th><th >Student ID</th><th>Student Name</th><th>Course Nmae</th><th>Center</th><th>Refund Bill No</th><th>Remitted(without GST)</th><th>Refund Amount(without GST)</th><th>Trans Details</th><th>Reason For Refund</th></tr></thead>';
                    $i = 1;
                    foreach ($reports as $key=>$val){
                        
                        $html .= '<tr><td>'.$i.'</td><td>'.$val['appdate'].'</td><td>'.$val['appno'].'</td><td style="width:5% !important">'.$val['studid'].'</td><td>'.$val['sname'].'</td><td style="width:15% !important">'.$val['coursename'].'</td><td>'.$val['center'].'</td><td>'.$val['receiptno'].'</td><td style="width:5% !important">'.$val['remitted'].'</td><td style="width:5% !important">'.$val['refundamount'].'</td><td>'.$val['paydescription'].'</td><td>'.$val['reason'].'</td></tr>';
                        $i++;
                    }
                    
                    
                  } else if($type === 'ccl'){
                    $reports = $this->reports_model->CourseChangeList($sdate,$edate,$center);
                    $savename = "Course_Change_Report_".date('d-m-Y-H_i_s');
                    
                    $html = '<thead><tr><th >S.no</th><th >App Date</th><th >App No</th><th >Student ID</th><th>Student Name</th><th>From - Course Nmae</th><th>From - Center</th><th>To - Course Name</th><th>To - Center</th><th>Remitted(without GST)</th><th>Refund Amount(without GST)</th></tr></thead>';
                    $i = 1;
                    foreach ($reports as $key=>$val){
                        
                        $html .= '<tr><td>'.$i.'</td><td>'.$val['created_at'].'</td><td>'.$val['receiptno'].'</td><td style="width:5% !important">'.$val['studid'].'</td><td>'.$val['sname'].'</td><td style="width:15% !important">'.$val['fcoursename'].'</td><td>'.$val['center'].'</td><td>'.$val['tcoursename'].'</td><td style="width:5% !important">'.$val['new_center'].'</td><td style="width:5% !important">'.$val['remitted'].'</td><td>'.$val['refundamount'].'</td></tr>';
                        $i++;
                    }
                }
                  
                                   
                  $html = "<tr>Reports From ".date("d/m/Y H:i",strtotime($sdate))." to ". date("d/m/Y H:i",strtotime($edate))." </tr>".$html;       
                    $html = str_replace('<tr>',"\n",$html);
                     $html = str_replace('</tr>',"",$html);

                     $html = str_replace('</th>',"\t",$html);
                     $html = str_replace('<th>',"",$html);

                     $html = str_replace('</td>',"\t",$html);
                     $html = str_replace('<td>',"",$html);


                     $html = strip_tags($html);

                     $filename = $savename .".xls";

                     force_download($filename, $html);
            
               
           }else {
                //If no session, redirect to login page
                redirect('login', 'refresh');
            }
        }
        
     
}
>>>>>>> .r338
?>
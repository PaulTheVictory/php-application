<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

use \setasign\Fpdi;

class Downloadidcard extends CI_Controller {

	function __construct() {
            
		parent::__construct();
		
                $this->load->model('login_model','',TRUE);
                $this->load->model('student_model','',TRUE);
				$this->load->helper('form');
				$this->load->library('table');

	}
	
	function index() {
            
            if($this->session->userdata('loggedin')) {

                $session_data = $this->session->userdata('loggedin');
                $session_id = $session_data['id'];
                $session_role = $session_data['role'];
                $data['user'] = $this->login_model->GetUserId();

				/*$data['roleaccess'] = $this->config->item('roleaccess');
			
				if($data['roleaccess']['Transfer Books'][3]!="y"){
					redirect($data['roleaccess']['defaultpage'], 'refresh');
				}*/
				
                //$this->load->view('downloadidcard_view', $data);
				
				$ptype = $this->input->get('ptype');
				
				if($session_role === 'student') {
			
					$data['user'] = $this->login_model->GetUserId();

				}else{

					$userid = $this->input->get('userid');
					$data['user'] = $this->login_model->GetUserDetails($userid);

				}
				
				$studentid = $data['user']['id'];
				
				$data['studentid'] = $studentid;
				$data['ptype'] = $ptype;
		
				$data['coursepay'] =  $this->student_model->GetFeePayments($studentid,'','');
				$data['stuprofile'] =  $this->student_model->GetStudentProfile($studentid);
				
				if($data['user']['profilepic']!="" && $data['user']['profilepic']!="0"){
					$this->generate_barcode($data['user']['stuid'],$studentid);
				}
				
				if($ptype!="preview"){
				
					$this->load->library('pdf');
					$html = $this->load->view('downloadIDcardpdf_view', $data, true);
					$this->pdf->createPDF($html, 'mypdf', false);
					
				}else{
					
					if($data['stuprofile']['profilepercent']=="100"){
					
						$html = $this->load->view('downloadIDcardpdf_view', $data, true);
						echo $html;
						
					}else {
						echo "Complete Profile";
					}
				}
				
				
            } else {
                //If no session, redirect to login page
                redirect('login', 'refresh');
            }
            
        }
	
	public function generate_barcode($barcode,$studentid){
		
		if($this->session->userdata('loggedin'))
   		{
			
			// Load library
			$this->load->library('zend');
			// Load in folder Zend
			$this->zend->load('Zend/Barcode');

			$dirname = './docs/profilepic/'.$studentid.'/';

			// Generate barcode
			$imageResource = Zend_Barcode::factory('code128', 'image', array('text'=>"$barcode",'stretchText'=>true,'withBorder'=>false,'font'=>2,'fontSize'=>18,'barHeight'=>45,'barThickWidth'=>3,'barThinWidth'=>2,'withQuietZones'=>false,'drawText'=>true), array('imageType'=>'png'))->draw();

			imagepng($imageResource, $dirname.$barcode.'.png');
						
		}
   		else
   		{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
   		}		
		
	}
	
	public function viewIDcard() {
	
	
	if($this->session->userdata('loggedin')) {
			
		$session_data = $this->session->userdata('loggedin');
		$session_id = $session_data['id'];
		$session_role = $session_data['role'];

		if($session_role === 'student') {
			
			$data['user'] = $this->login_model->GetUserId();
			
		}else{
		
			$userid = $this->input->get('userid');
			$data['user'] = $this->login_model->GetUserDetails($userid);
		
		}
		
		$studentid = $data['user']['id'];
		
		$coursepay =  $this->student_model->GetCoursePayment($data['user']['id'],'','');
		$stuprofile =  $this->student_model->GetStudentProfile($data['user']['id']);
						
		//print_r($stuprofile);exit;
		
		//$feepayments = $this->student_model->GetFeePayments($data['user']['id'],'',$requestid);
		
		$courseid = $coursepay[0]['courseid'];
		$photocopy_ht = $coursepay[0]['photocopy_ht'];
		
		$coursename = $coursepay[0]['coursename'];
		$roll_number = $coursepay[0]['roll_number'];
		$stuid = $data['user']['stuid'];
		$stuname = $data['user']['pname'];
		$dob = date("d M Y",strtotime($stuprofile['dob']));
		$classstudy = $stuprofile['classstudy'];
		$mobile = $stuprofile['smobile'];
		$smcode = $stuprofile['smcode'];
		$email = $stuprofile['semail'];
		$profilepic = $data['user']['profilepic'];
		
		$examtime = $coursepay[0]['examtime'];
		$reportingtime = $coursepay[0]['reportingtime'];
		$cooloftime = $coursepay[0]['cooloftime'];
		$modeofexam = $coursepay[0]['modeofexam'];
		$duration = $coursepay[0]['duration'];
		                
				
		$guardianname = "";
		if($stuprofile['fathername']!="" && $stuprofile['fathername']!="0") $guardianname = $stuprofile['fathername'];
		else if($stuprofile['guardianname']!="" && $stuprofile['guardianname']!="0") $guardianname = $stuprofile['guardianname'];
		
		$fulladdress = $addressline1 = $addressline2 = $addressline3 = "";
		$addressline1 .= $stuprofile['housenameno'].", ";
		$addressline1 .= $stuprofile['contactaddress'].", ";
		
		if($stuprofile['contactaddress']!="" && $stuprofile['contactaddress']!="0") $fulladdress .= $stuprofile['landmark'].", ";
		
		$fulladdress .= $stuprofile['contactstate'].", ";
		$addressline2 .= $stuprofile['contactpost'].", ";
		//$fulladdress .= $stuprofile['contactcountry']." - ";
		$addressline3 .= $stuprofile['contactdistrict'].", ";
		$addressline3 .= $stuprofile['contactpincode'].".";
		
		$mobile = "Mob +".$smcode." ".$mobile;
		
		ob_start();
		
		require_once(FCPATH.'/fpdf/fpdf.php');
		//require_once(FCPATH.'/rpdf/rpdf.php');
		require_once(FCPATH.'/FPDI/src/autoload.php');
				
		// initiate FPDI
		$pdf = new Fpdi\Fpdi();
		
		//$pdf = new RPDF();

		// get the page count
		$pageCount = $pdf->setSourceFile(FCPATH.'/docs/idcard.pdf');
		// iterate through all pages
		for ($pageNo = 1; $pageNo <= $pageCount; $pageNo++) {
			// import a page
			$templateId = $pdf->importPage($pageNo);

			$pdf->AddFont('segoeuib','','segoeuib.php');

			$pdf->AddPage();
			// use the imported page and adjust the page size
			$pdf->useTemplate($templateId, ['adjustPageSize' => true]);
			
			$pdf->AddFont('segoeuib','','segoeuib.php');
			$pdf->SetFont('segoeuib','','10');
			$pdf->SetTextColor('58' ,'58' ,'58');
			
			$pdf->SetAutoPageBreak(false);
			
			$pdf->SetXY(3, 10);
			//$pdf->TextWithDirection(110,50,$coursename,'D');
			$pdf->MultiCell(140, 6, $coursename, 0, 'L', false);
			
			// Student Details
			
			$pdf->AddFont('segoeuib','','segoeuib.php');
			$pdf->SetFont('segoeuib','','10');
			$pdf->SetTextColor('0' ,'0' ,'0');
			
			$pdf->SetXY(3,44);
			$pdf->MultiCell(49, 3, strtoupper($stuname), 0, 'C', false);
			
			$pdf->SetXY(3, 48);
			$pdf->MultiCell(49, 3, $stuid, 0, 'C', false);
			
			/*$pdf->SetXY(64, 225);
			$pdf->MultiCell(60, 4.5, $email, 0, 'L', false);
			
			$pdf->SetXY(155, 224.5);
			$pdf->MultiCell(140, 6, $dob, 0, 'L', false);*/
						
			$pdf->SetXY(3, 53);
			$pdf->MultiCell(49, 3, $mobile, 0, 'C', false);
			
			/*$pdf->SetXY(178.5, 236);
			$pdf->MultiCell(140, 6, $guardianname, 0, 'L', false);*/
			
			$pdf->SetXY(2, 57);
			$pdf->MultiCell(49, 4.5, $addressline1, 0, 'L', false);
			
			$pdf->SetXY(2, 61);
			$pdf->MultiCell(49, 4.5, $addressline2, 0, 'L', false);
			
			$pdf->SetXY(2, 65);
			$pdf->MultiCell(49, 4.5, $addressline3, 0, 'L', false);
			
			//$pdf->SetXY(64, 261);
			//$pdf->MultiCell(140, 6, $classstudy, 0, 'L', false);
					
			$photo_ht = 'docs/profilepic/'.$studentid.'/'.$profilepic;
			if(file_exists($photo_ht)) $pdf->Image($photo_ht, 16.3, 17.8, 22.4, 24.3);
						
			//$pdf->Write(8, 'Hall Ticket');
		}	
		
			// Output the new PDF
			//I, D, F, S
			
			//$pdfoutput = "D";
			$pdfoutput = "I";
	
			$pdf->Output($pdfoutput,"IDcard_".$stuid.".pdf"); 
		
		ob_end_flush(); 
		
				
	}else {
		//If no session, redirect to login page
		redirect('login', 'refresh');
	}
	
	
}  
        
	public function downloadStudentIDcard() {
	
	
	if($this->session->userdata('loggedin')) {
			
		$session_data = $this->session->userdata('loggedin');
		$session_id = $session_data['id'];
		$session_role = $session_data['role'];

		if($session_role === 'student') {
			
			$data['user'] = $this->login_model->GetUserId();
			
		}else{
		
			$userid = $this->input->get('userid');
			$data['user'] = $this->login_model->GetUserDetails($userid);
		
		}
		
		$studentid = $data['user']['id'];
		
		$coursepay =  $this->student_model->GetCoursePayment($data['user']['id'],'','');
		$stuprofile =  $this->student_model->GetStudentProfile($data['user']['id']);
						
		//print_r($stuprofile);exit;
		
		//$feepayments = $this->student_model->GetFeePayments($data['user']['id'],'',$requestid);
		
		$courseid = $coursepay[0]['courseid'];
		$photocopy_ht = $coursepay[0]['photocopy_ht'];
		
		$coursename = $coursepay[0]['coursename'];
		$roll_number = $coursepay[0]['roll_number'];
		$stuid = $data['user']['stuid'];
		$stuname = $data['user']['pname'];
		$dob = date("d M Y",strtotime($stuprofile['dob']));
		$classstudy = $stuprofile['classstudy'];
		$mobile = $stuprofile['smobile'];
		$smcode = $stuprofile['smcode'];
		$email = $stuprofile['semail'];
		$profilepic = $data['user']['profilepic'];
		
		$examtime = $coursepay[0]['examtime'];
		$reportingtime = $coursepay[0]['reportingtime'];
		$cooloftime = $coursepay[0]['cooloftime'];
		$modeofexam = $coursepay[0]['modeofexam'];
		$duration = $coursepay[0]['duration'];
		                
				
		$guardianname = "";
		if($stuprofile['fathername']!="" && $stuprofile['fathername']!="0") $guardianname = $stuprofile['fathername'];
		else if($stuprofile['guardianname']!="" && $stuprofile['guardianname']!="0") $guardianname = $stuprofile['guardianname'];
		
		$fulladdress = $addressline1 = $addressline2 = $addressline3 = "";
		$addressline1 .= $stuprofile['housenameno'].", ";
		$addressline1 .= $stuprofile['contactaddress'].", ";
		
		if($stuprofile['contactaddress']!="" && $stuprofile['contactaddress']!="0") $fulladdress .= $stuprofile['landmark'].", ";
		
		$fulladdress .= $stuprofile['contactstate'].", ";
		$addressline2 .= $stuprofile['contactpost'].", ";
		//$fulladdress .= $stuprofile['contactcountry']." - ";
		$addressline3 .= $stuprofile['contactdistrict'].", ";
		$addressline3 .= $stuprofile['contactpincode'].".";
		
		$mobile = "Mob +".$smcode." ".$mobile;
		
		
		// Set the content-type
	   //header('Content-Type: image/png');

		$src_path = "docs/idcard.jpg"; 
		if ( is_readable($src_path)) {
		$info = getimagesize($src_path);
		if ($info !== FALSE) {

			$im = @imagecreatefromjpeg($src_path);

		  }
		}
		
        $src_path1 = "docs/profilepic/".$studentid."/".$profilepic;
		
		$info = getimagesize($src_path1);
		if ($info !== FALSE) {

			$type1   = strstr($profilepic, '.');
			if($type1 ==".png" || $type1 == ".PNG") {
				$dst = @imagecreatefrompng($src_path1);
			} else {
				$dst = @imagecreatefromjpeg($src_path1);
			}



		  }
		
		// Create some colors
	   $black = imagecolorallocate($im, 0, 0, 0);

		$fontbold = "css/fonts/segoeuib.ttf"; 
		$fontsemibold = "css/fonts/seguisb.ttf"; 


	  // Add the text
	   imagettftext($im, 18, 0, 5, 100, $black, $fontbold, strtoupper($stuname));

	   /*imagettftext($im, 12, 0, 51, 425, $black, $fontsemibold, $stuid);

	   imagettftext($im, 12, 0, 338, 425, $black, $fontsemibold, $mobile);

	   imagettftext($im, 12, 0, 52, 510, $black, $fontsemibold, $coursename);

	   imagettftext($im, 12, 0, 338, 510, $black, $fontsemibold, $addressline1);
		
	   imagettftext($im, 12, 0, 338, 510, $black, $fontsemibold, $addressline2);
		
	   imagettftext($im, 12, 0, 338, 510, $black, $fontsemibold, $addressline3);*/

		if ( is_readable($src_path1)) {

			$newwidth = 135;
			$newheight = 145;

			$image_s = imagecreatefromstring(file_get_contents($src_path1));
			$width = imagesx($image_s);
			$height = imagesy($image_s);
			$image = imagecreatetruecolor($newwidth, $newheight);
			imagealphablending($image, true);
			imagecopyresampled($image, $image_s, 0, 0, 0, 0, $newwidth, $newheight, $width, $height);
			//create masking
			/*$mask = imagecreatetruecolor($newwidth, $newheight);
			$transparent = imagecolorallocate($mask, 255, 0, 0);
			imagecolortransparent($mask,$transparent);
			imagefilledellipse($mask, $newwidth/2, $newheight/2, $newwidth, $newheight, $transparent);
			$red = imagecolorallocate($mask, 0, 0, 0);
			imagecopymerge($image, $mask, 0, 0, 0, 0, $newwidth, $newheight, 100);
			imagecolortransparent($image,$red);
			imagefill($image, 0, 0, $red);*/

		}

	   imagecopymerge($im, $image, 95, 105, 0, 0, 135, 145, 100);

	   //imagecopymerge($im, $im_second, 0, 640, 0, 0, 1028, 638, 100);

	   imagepng($im);
	   imagedestroy($im);
	   imagedestroy($image);
	   imagedestroy($mask);
		
				
	}else {
		//If no session, redirect to login page
		redirect('login', 'refresh');
	}
	
	
}  
	
	
}
?>
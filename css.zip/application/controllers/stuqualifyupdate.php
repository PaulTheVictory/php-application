<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Stuqualifyupdate extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model('login_model','',TRUE);
                $this->load->model('qualification_model','',TRUE);
                $this->load->model('course_model','',TRUE);
                 $this->load->library('table'); $this->load->helper('form');

	}
	
	function index()
	{
		if($this->session->userdata('loggedin')&& $this->session->userdata('studlog_in'))
   		{
                    $session_data = $this->session->userdata('loggedin');
                    $session_id = $session_data['id'];
                    $session_role = $session_data['role'];
                    
                    	
		    		$ide = isset($_GET['ide']) ? $_GET['ide'] : '';
                    $type = isset($_GET['type']) ? $_GET['type'] : '';
					$wfr = isset($_GET['wfr']) ? $_GET['wfr'] : '';
			
			
					$data['sid'] = "";
					$data['qwfr'] = $wfr;
                    
                    if($ide === '') {
	             $data['user'] = $this->login_model->GetUserId();       
                     $tmpl = array('table_open' => '<table class="sortable" id="qtable" style="margin-top:0px;">');
                                $this->table->set_template($tmpl);
                                $this->table->set_heading('QUALIFICATION NAME','COURSE NAME','ACTIONS');
						
                    $this->load->view('header',$data);
                    $this->load->view('stu_qualificationlist_view');
                    $this->load->view('footer');
						
                    } else if($ide !== '' && $type === ''){
                    
						$data['user'] = $this->login_model->GetUserId();
						
                    	$arr= $this->qualification_model->ViewStudentQualification($ide);
                    
                    if($arr === '') {
                        redirect('login', 'refresh');
                    } else{
                        $data['qualification'] = $arr[0];
                       
                    }
                    

                                 
                    $this->load->view('header',$data);
                    $this->load->view('stu_qualifyupdate_view', $data);
                    $this->load->view('footer'); 
                    
                    }else if($ide !== '' && $type === 'edit'){
                        $data['user'] = $this->login_model->GetUserId();
                          
                        $arr = $this->qualification_model->ViewStudentQualification($ide); 
                         if($arr === '') {
                        redirect('login', 'refresh');
                    } else{
                        $data['qualification1'] = $arr[0];
                       
                    }
						
						$data['qualification'] = $this->qualification_model->StudentViewQualification($data['qualification1']['qualificationid'],$data['user']['qualificationid']);
						
						
						if($wfr!="y" && $data['qualification1']['status']!="WFR" && $data['qualification1']['xii_status']!="WFR" && $data['qualification1']['approved'] !==""){
							redirect('stuqualifyupdate?ide='.$data['qualification1']['ide'], 'refresh');
						}
						
						
					$data['courseno'] = $this->qualification_model->GetCoursenoQualification($data['qualification1']['courseid']);	
						
                    $data['gradeX'] = $this->qualification_model->GetGradesX();
                    $data['gradeXII'] = $this->qualification_model->GetGradesXII();
                    $data['classes'] = $this->qualification_model->GetAllClasses();
                    $this->load->view('header',$data);
                    $this->load->view('stu_editqualify_view', $data);
                    $this->load->view('footer'); 
                    }
                    
                 
                    
		} else if($this->session->userdata('loggedin')&& $this->session->userdata('adlog_in')) {
                    
                    $ide = isset($_GET['ide']) ? $_GET['ide'] : '';
                    $cride = isset($_GET['cride']) ? $_GET['cride'] : '';
                    $qid = isset($_GET['qid']) ? $_GET['qid'] : '';
                    $data['user'] = $this->login_model->GetUserId();
			
					$data['roleaccess'] = $this->config->item('roleaccess');

					if($data['roleaccess']['Qualification Edit'][1]!="y"){
						redirect($data['roleaccess']['defaultpage'], 'refresh');
					}
			
					$data['sid'] = $ide;
					$data['qid'] = $qid;
			
                        $arr = $this->qualification_model->ViewStudentQualification($cride); 
                         if($arr === '') {
                        redirect('login', 'refresh');
                    } else{
                        $data['qualification1'] = $arr[0];
                       
                    }
			
					$data['qualification'] = $this->qualification_model->StudentViewQualification($data['qualification1']['qualificationid'],$qid);  
		
                    $data['gradeX'] = $this->qualification_model->GetGradesX();
                    $data['gradeXII'] = $this->qualification_model->GetGradesXII();
                    $data['classes'] = $this->qualification_model->GetAllClasses();
                    $data['menu'] = $this->load->view('headermenu', $data, TRUE);
                    $data['stuprofile'] =  $this->student_model->GetStudentProfile($ide); 
                    $this->load->view('header_view',$data);
                    $this->load->view('editqualify_view', $data);
                    $this->load->view('footer_view'); 
                    
                    
                } else {
                    //If no session, redirect to login page
                    redirect('login', 'refresh');
   		}
		
	}
        
         public function GetQualificationists() {
            
            if($this->session->userdata('loggedin') && $this->session->userdata('studlog_in')){
                
                $user = $this->login_model->GetUserId();	
                $ret =  $this->qualification_model->GetStudentQualificationLsts($user['id']);
                echo $ret;
                
            }else{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
            }
            
        }
        
     

        public function DelCourse(){
            
            if($this->session->userdata('loggedin') && $this->session->userdata('studlog_in')){

                $ide = isset($_GET['ide']) ? $_GET['ide'] : '';

                if($ide != ""){
                     $ret = $this->course_model->DeleteRequest($ide);
                } else {
                    $ret = array(0 => "fail");
                }

                echo json_encode($ret);
            
            }else {
                //If no session, redirect to login page
                redirect('login', 'refresh');
            }
            
        }
        
        
           public function qualificationSubmit() {
             
            if($this->session->userdata('loggedin') && ( $this->session->userdata('studlog_in') || $this->session->userdata('adlog_in') )){
               $this->load->library('form_validation');
             $this->form_validation->set_rules('cid', 'Course ID', 'trim|required|xss_clean|alpha_numeric|max_length[20]');
				
			$qwfr = isset($_POST['qwfr']) ? $_POST['qwfr'] : '';
			$checkaq = $this->qualification_model->ViewStudentQualification($this->input->post('cid', true));

			if(!($checkaq!="" && ($checkaq[0]['approved']=="w" || $checkaq[0]['approved']=="n") && ($checkaq[0]['entrance_name']=="" || $qwfr=="y") && $checkaq[0]['xii_status']=="P" && $this->session->userdata('studlog_in'))){
			
               $this->form_validation->set_rules('x_qid', 'Qualification ID', 'trim|required|xss_clean|alpha_numeric|max_length[20]');
               $this->form_validation->set_rules('stream', 'Stream', 'trim|required|xss_clean|max_length[15]');
                $this->form_validation->set_rules('yearofpassing', 'Year Of Passing', 'trim|required|xss_clean|numeric|max_length[4]');
                $this->form_validation->set_rules('status', 'Result Status', 'trim|required|xss_clean|regex_match[/P|WFR|C/]|max_length[3]');
                $this->form_validation->set_rules('proll', 'Roll No Master', 'trim|required|xss_clean|regex_match[/1|0/]|max_length[1]');
                $this->form_validation->set_rules('xout', 'Grade Master', 'trim|required|xss_clean|regex_match[/1|0/]|max_length[1]');
                $this->form_validation->set_rules('qclass', 'Class Name', 'trim|required|xss_clean|callback_alpha_numeric_spaces|max_length[20]');
                //$this->form_validation->set_rules('center', 'Center', 'trim|required|xss_clean|alpha|max_length[50]');
				
			}
				
                $this->form_validation->set_rules('hexam_name', 'Entrance Exam Name', 'trim|xss_clean|callback_alpha_numeric_spaces|max_length[100]');
                $this->form_validation->set_rules('hexam_mark', 'Entrance Exam Mark', 'trim|xss_clean|callback_alpha_numeric_spaces|max_length[100]');
                $this->form_validation->set_rules('hexam_regno','Entrance Exam Regno', 'trim|xss_clean|callback_alpha_numeric_spaces|max_length[100]');
                
                
			if(!($checkaq!="" && ($checkaq[0]['approved']=="w" || $checkaq[0]['approved']=="n") && ($checkaq[0]['entrance_name']=="" || $qwfr=="y") && $checkaq[0]['xii_status']=="P" && $this->session->userdata('studlog_in'))){
                
                if(($_POST['proll'] === "1") && ($_POST['status'] !="WFR") && ($_POST['status'] !="C") ) {
                    $this->form_validation->set_rules('rollno', 'Roll No', 'trim|required|xss_clean|callback_alpha_numeric_spaces|max_length[20]');
                }

                if(($_POST['xout']=="1") && ($_POST['status'] !="WFR") && ($_POST['status'] !="C")) {
                     $this->form_validation->set_rules('gradelist[]', 'Grade', 'trim|required|xss_clean|callback_alpha_numeric_spaces|max_length[5]');

                }else if(($_POST['xout']=="0") && ($_POST['status'] !="WFR") && ($_POST['status'] !="C")) {
                     $this->form_validation->set_rules('marklist[]', 'Mark', 'trim|required|xss_clean|numeric|max_length[3]');

                }
                
                if(isset($_POST['gmark']) ) {
                    $this->form_validation->set_rules('gmark', 'Grace Mark', 'trim|required|xss_clean|regex_match[/y|n/]|max_length[1]');
                }

                $xii_flag = isset($_POST['xii_flag']) ? $_POST['xii_flag'] : '';	
                if($xii_flag === 'on') {

                    $this->form_validation->set_rules('xii_stream', 'XII Stream', 'trim|required|xss_clean|alpha|max_length[10]');
                    $this->form_validation->set_rules('xii_yearofpassing', 'Year Of Passing', 'trim|required|xss_clean|numeric|max_length[4]');
                    $this->form_validation->set_rules('xii_status', 'Result Status', 'trim|required|xss_clean|regex_match[/P|WFR|C/]|max_length[3]');
                    $this->form_validation->set_rules('xii_qid', 'Qualification ID', 'trim|required|xss_clean|alpha_numeric|max_length[20]');
                    $this->form_validation->set_rules('hclassname','Higher Secondary Class Name', 'trim|xss_clean|required|max_length[100]');
                    $this->form_validation->set_rules('hroll', 'Roll No Master', 'trim|required|xss_clean|regex_match[/1|0/]|max_length[1]');
                    $this->form_validation->set_rules('xiiout', 'Grade Master', 'trim|required|xss_clean|regex_match[/1|0/]|max_length[1]');
					
                    if(($_POST['hroll'] === "1") && ($_POST['xii_status'] !== "WFR") && ($_POST['xii_status'] !== "C") ) {
                        $this->form_validation->set_rules('xii_rollno', 'XII - Roll No', 'trim|required|xss_clean|callback_alpha_numeric_spaces|max_length[20]');
                    }

                    if(($_POST['xiiout'] === "1") && ($_POST['xii_status'] !== "WFR") && ($_POST['xii_status'] !== "C")) {
                     $this->form_validation->set_rules('xii_gradelist[]', 'Grade', 'trim|required|xss_clean|callback_alpha_numeric_spaces|max_length[5]');

                    }else if(($_POST['xiiout'] === "0") && ($_POST['xii_status'] !== "WFR") && ($_POST['xii_status'] !== "C")) {
                     $this->form_validation->set_rules('xii_marklist[]', 'Mark', 'trim|required|xss_clean|numeric|max_length[3]');

                    }
                    
                    if(isset($_POST['xii_gmark']) ) {
                        $this->form_validation->set_rules('xii_gmark', 'Grace Mark', 'trim|required|xss_clean|regex_match[/y|n/]|max_length[1]');
                    }


                }
				
			}
				
				$marksheet_flag = isset($_POST['marksheet_flag']) ? $_POST['marksheet_flag'] : '';
				
				if($marksheet_flag=="1"){
					if((!isset($_FILES["file"]) || empty($_FILES["file"]['name'])) && $_POST['marksheets']=="" ) $this->form_validation->set_rules('file', 'Upload Marksheet', 'trim|required|xss_clean');
				}
                
                if ($this->form_validation->run() == false) {
                    $response = array(
                        'status' => 'error',
                        'message' => validation_errors()
                    );
                } else {
                    
                   $response = $this->updateQ($xii_flag);
                }
                
                echo  json_encode($response);
        
            }else{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
            }
            
         }
         
  public function updateQ($xii_flag){
      
   	   $sid = isset($_POST['sid']) ? $_POST['sid'] : '';
	   if($sid==""){
		   $data['user'] = $this->login_model->GetUserId();
		   $userid = $data['user']['id'];
	   }else{
		   $userid = $sid;
	   }
	  
        $ide = uniqid();
        $rollno = isset($_POST['rollno']) ? $_POST['rollno'] : '';
        $gmark = isset($_POST['gmark']) ? $_POST['gmark'] : '';
        
        $gradeVal['A+'] = 9;$gradeVal['A'] = 8;$gradeVal['B+'] = 7;$gradeVal['B'] = 6;
        $gradeVal['C+'] = 5;$gradeVal['C'] = 4;$gradeVal['D+'] = 3;$gradeVal['D'] = 2;
        
        $grade = '';$mark_total = 0;
        if(isset($_POST['gradelist']) ) {
            $gradelist = $this->input->post('gradelist', true);
            foreach ($gradelist as $key=> $val) {
                $grade .=  '|'.$val;
                $mark_total = intval($mark_total)+intval($gradeVal[$val]);
            }
        }
        
        $mark = '';
        if(isset($_POST['marklist']) ) {
            $gradelist = $this->input->post('marklist', true);
            foreach ($gradelist as $key=> $val) {
                $mark .=  '|'.$val;
                $mark_total = intval($mark_total)+intval($val);
            }
        }
        
        $xii_rollno = isset($_POST['xii_rollno']) ? $_POST['xii_rollno'] : '';
        $xii_gmark = isset($_POST['xii_gmark']) ? $_POST['xii_gmark'] : '';
        $xii_grade = '';$xii_mark_total = 0;
        if(isset($_POST['xii_gradelist']) ) {
            $gradelist = $this->input->post('xii_gradelist', true);
            foreach ($gradelist as $key=> $val) {
                $xii_grade .=  '|'.$val;
                $xii_mark_total = intval($xii_mark_total)+intval($gradeVal[$val]);
            }
        }
        
        $xii_mark = '';
        if(isset($_POST['xii_marklist']) ) {
            $gradelist = $this->input->post('xii_marklist', true);
            foreach ($gradelist as $key=> $val) {
                $xii_mark .=  '|'.$val;
                $xii_mark_total = intval($xii_mark_total)+intval($val);
            }
        }
        
           $subArr = $this->qualification_model->GetSelectedSubject($this->input->post('x_qid', true),$this->input->post('xii_qid', true));
           $user = $this->login_model->GetUserId();
           
            $aq0 = $aq1 = $aq2 = "";$aq = array();
            if(isset($_POST['hexam_mark']) ) {
                $emark = explode("|",$_POST['hexam_mark']); $cnt = 0;
                    foreach($emark as $key=>$val){
                        if($val !== "") { 
                        $aq[$cnt] = $val;
                        $cnt++;                        
                        }
                    }
            }
	  
	  		if(isset($aq[0])) $aq0 = $aq[0];
		    if(isset($aq[1])) $aq1 = $aq[1];
		    if(isset($aq[2])) $aq2 = $aq[2];
            $xii_class= "";
            if($xii_flag === 'on') { $xii_class = $this->input->post('hclassname', true); }
	  
	  
	  
	  		$qwfr = isset($_POST['qwfr']) ? $_POST['qwfr'] : '';
	  		$checkaq = $this->qualification_model->ViewStudentQualification($this->input->post('cid', true));
	  
	  		$marksheetsold = $checkaq[0]['marksheets'];
	  
	  		// Upload marksheets
	  
	  
	  		$marksheets = array();
			
			if(isset($_FILES["file"]) && !empty($_FILES["file"]['name'])){
				
				$total = count($_FILES['file']['name']);
				
				$validExtensions = array('.pdf', '.doc', '.docx');
				$imageExtensions = array('.jpg', '.jpeg', '.png', '.pdf');
				
				for( $i=0 ; $i < $total ; $i++ ) {
			
				$file_size = $_FILES['file']['size'][$i];
			
				if ((number_format($file_size / 1048576, 2) > 1)){      
					$ret = array('status'=>'ularge','message' => "Maximum each file size upto 1MB");
					echo json_encode($ret);
					exit(0);
				}
					
				}
				
				
				$dirname = FCPATH.'docs/courserequest/marksheets/'.$userid.'/';
				
				$filecount = 0;
				$unlinkfiles = glob($dirname."*"); 
				foreach ($unlinkfiles as $unlinkfile) {
				  if(file_exists($unlinkfile)) 
				  {
					  $filecount++;
					  //unlink($unlinkfile);
				  }
				}
				
				for( $i=0 ; $i < $total ; $i++ ) {
				
				$fileExtension = strrchr($_FILES['file']['name'][$i], ".");
				$fileName = "marksheet_".($filecount + $i + 1)."_".time().$fileExtension;
					
				$marksheets[$i] = $fileName;	
				
				$destinationfull = $dirname . $fileName;
					
				if(!file_exists($dirname)) mkdir($dirname,0777);
																	
				if (in_array(strtolower($fileExtension), $imageExtensions)) {
					
					$resultfull = move_uploaded_file($_FILES['file']['tmp_name'][$i],$destinationfull);
					
					if(!$resultfull){
				    
						$ret = array('status' => "ufail",'message' => "Marksheet Upload Failed");
						echo json_encode($ret);
						exit(0);
					}
								
				}else{
					
					$ret = array('status' => "exfail",'message' => "File format JPG, JPEG, PNG and PDF only");
					echo json_encode($ret);
					exit(0);
					
				}
					
				}
								
			} 
	  
	  		$allmarksheets = "";
	  		$message = "";
			
			if(!empty($marksheets)){
				
				$allmarksheets = implode("|",$marksheets);
				
				if($marksheetsold!="") $allmarksheets = $marksheetsold."|".$allmarksheets;
				
				$message = " and Marksheet";
				
			}else{
				$allmarksheets = $marksheetsold;
			}
	  
	  
	  	if($checkaq!="" && ($checkaq[0]['approved']=="w" || $checkaq[0]['approved']=="n") && ($checkaq[0]['entrance_name']=="" || $qwfr=="y") && $checkaq[0]['xii_status']=="P" && $this->session->userdata('studlog_in')){
			
			$qData = array(
                            'ide' => $this->input->post('cid', true),
                            'entrance_name'=>$this->input->post('hexam_name', true),
                            'entrance_mark'=>$this->input->post('hexam_mark', true),
                            'aq1'=>$aq0,
                            'aq2'=>$aq1,
                            'aq3'=>$aq2,
                            'entrance_regno'=>$this->input->post('hexam_regno', true),
                            'marksheets'=>$allmarksheets
                        );
			
		}else{
	  
	  
            $qData = array(
                'ide' => $this->input->post('cid', true),
                'yearofpassing' => $this->input->post('yearofpassing', true),
                'class' => $this->input->post('qclass', true),
                'stream' => $this->input->post('stream', true),
                'status' => $this->input->post('status', true),
                'rollno' => $rollno,
                'gracemark' => $gmark,
                'grade' => $grade,
                'mark' => $mark,
                'mark_total' => $mark_total,
                'subject'=>$subArr['subject'],
                'xii_yearofpassing' => $this->input->post('xii_yearofpassing', true),
                'xii_class' => $xii_class,
                'xii_status' => $this->input->post('xii_status', true),
                'xii_stream' => $this->input->post('xii_stream', true),
                'xii_gracemark' => $xii_gmark,
                'xii_rollno' => $xii_rollno,
                'xii_grade' => $xii_grade,
                'xii_mark' => $xii_mark,
                'xii_mark_total' => $xii_mark_total,
                'xii_subject'=>$subArr['xii_subject'],
                'x_qid'=>$this->input->post('x_qid', true),
                'xii_qid'=>$this->input->post('xii_qid', true),
                'entrance_name'=>$this->input->post('hexam_name', true),
                'entrance_mark'=>$this->input->post('hexam_mark', true),
                'aq1'=>$aq0,
                'aq2'=>$aq1,
                'aq3'=>$aq2,
                'entrance_regno'=>$this->input->post('hexam_regno', true),
                'marksheets'=>$allmarksheets
            );
			
		}
            
            

            $id = $this->course_model->updateCourseRequest($qData);
            
          

            $response = array(
                'status' => 'success',
                'message' => "Qualification ".$message." Updated Successfully.",
                'id' => $ide
            );

          return $response;
    }
         
      
	
	public function deleteQMarksheet() {
             
        if($this->session->userdata('loggedin') && ( $this->session->userdata('studlog_in') || $this->session->userdata('adlog_in') )){
			
		   $sid = isset($_POST['sid']) ? $_POST['sid'] : '';
		   if($sid==""){
			   $data['user'] = $this->login_model->GetUserId();
			   $userid = $data['user']['id'];
		   }else{
			   $userid = $sid;
		   }
			
			$crid = $this->input->post('crid', true);
			$qfilename = $this->input->post('qfilename', true);
			
			$response = $this->course_model->DeleteQMarksheet($crid,$userid,$qfilename);
			echo json_encode($response);
			
		}
		
	}
	
	
}
?>

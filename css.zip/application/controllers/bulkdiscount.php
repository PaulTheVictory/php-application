<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Bulkdiscount extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model('login_model','',TRUE);
                $this->load->model('course_model','',TRUE);
                $this->load->library('table'); 
                $this->load->helper('download');
                 

	}
	
	function index()
	{
		if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in'))
   		{
                    $session_data = $this->session->userdata('loggedin');
                    $session_id = $session_data['id'];
                    $session_role = $session_data['role'];
                    
                    $data['user'] = $this->login_model->GetUserId();		
		
			
                    $data['roleaccess'] = $this->config->item('roleaccess');
			
					if(isset($data['roleaccess']['Bulk Discount'][3]) && $data['roleaccess']['Bulk Discount'][3]!="y"){
						redirect($data['roleaccess']['defaultpage'], 'refresh');
					}
			
                    $ide = isset($_GET['id']) ? $_GET['id'] : '';
                    $center = isset($_GET['center']) ? $_GET['center'] : '';
                    $data['menu'] = $this->load->view('headermenu', $data, TRUE);
                  
					$this->load->view('header_view', $data);
					$this->load->view('bulkdiscount_view', $data);
					$this->load->view('footer_view');
                        
         }
   		else
   		{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
   		}
		
	}
        
       
        
  public function uploadNewDiscount(){
            
		if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')){

			//print_r($_FILES);exit;
			
			if(isset($_FILES["file"]) && !empty($_FILES["file"]['name'])){
				
				$total = count($_FILES['file']['name']);
				
				$validExtensions = array('.xls');
				
				$dirname = FCPATH.'docs/bulkdiscount/';
								
				$fileExtension = strrchr($_FILES['file']['name'][0], ".");
				$fileName = "bulkdiscount".$fileExtension;
									
				$destinationfull = $dirname . $fileName;
					
				if(!file_exists($dirname)) mkdir($dirname,0777);
							
				if (in_array(strtolower($fileExtension), $validExtensions)) {
					
					$resultfull = move_uploaded_file($_FILES['file']['tmp_name'][0],$destinationfull);
					
					if(!$resultfull){
				    
						$ret = array('status' => "ufail");
						echo json_encode($ret);
						exit(0);
						
					}else{
						
						$result = $this->NewDiscountImport($fileName);
						
						$ret = array('status' => "success","message"=>$result['message'],"tabledata"=>$result['tabledata']);
						echo json_encode($ret);
						exit(0);
						
					}
								
				}else{
					
					$ret = array('status' => "exfail");
					echo json_encode($ret);
					exit(0);
					
				}
					
								
			}else{
				
				$ret = array('status' => "empty");
				echo json_encode($ret);
				exit(0);
				
			}
			
			
		}
	  
  }
	
	
function NewDiscountImport($fileName){
	
	include './import/excel_reader.php';     // include the class

	// creates an object instance of the class, and read the excel file data
	$excel = new PhpExcelReader;
	$excel->read(FCPATH.'docs/bulkdiscount/'.$fileName);
	
	/*while (@ob_end_flush());      
	ob_implicit_flush(true);

	echo "Data Upload Initiated";
	echo str_pad("",1024," ");
	echo "<br />";

	sleep(2);

	echo "Start uploading...";
	echo "<br />";*/

	//exit;
	
	$sheet = $excel->sheets[0];
	
	$tb = 0;
	$x = 2;
 //if($dcount=="")$x = 2;else $x = $dcount;

//echo $sheet['numRows'];exit;
	
	$arr = array();
	
	$arr["message"] = "";
	$arr["tabledata"] = array();
	$tabledata = array('','','','','','','','','','','');
	
 $myfile = fopen(FCPATH."docs/bulkdiscount/bulkdiscount_".date('d-m-Y-H_i_s').".txt", "w");

  while($x <= $sheet['numRows']) {
	  
	  //sleep(1);
	  
	  
	  $sno = isset($sheet['cells'][$x][1]) ? $sheet['cells'][$x][1] : '';
          $studentno = isset($sheet['cells'][$x][2]) ? $sheet['cells'][$x][2] : '';	
	  $courseno = isset($sheet['cells'][$x][3]) ? $sheet['cells'][$x][3] : '';
          $centerid = isset($sheet['cells'][$x][4]) ? $sheet['cells'][$x][4] : '';
          $tdiscount = isset($sheet['cells'][$x][5]) ? $sheet['cells'][$x][5] : '';      
	  $t1discount = isset($sheet['cells'][$x][6]) ? $sheet['cells'][$x][6] : '';         
	  $t2discount = isset($sheet['cells'][$x][7]) ? $sheet['cells'][$x][7] : '';
          $reason = isset($sheet['cells'][$x][8]) ? $sheet['cells'][$x][8] : '';
	   
          //Remove alpha charcters
          
          $studentno  = preg_replace( '/[^0-9]/i', '', $studentno);
          $courseno   = preg_replace( '/[^0-9]/i', '', $courseno);
          $centerid   = preg_replace( '/[^0-9]/i', '', $centerid);
          $tdiscount  = preg_replace( '/[^0-9]/i', '', $tdiscount);
          $t1discount = preg_replace( '/[^0-9]/i', '', $t1discount);
          $t2discount = preg_replace( '/[^0-9]/i', '', $t2discount);
          
          $tdiscount = ($tdiscount ==="")?0:$tdiscount;
	  $t1discount = ($t1discount ==="")?0:$t1discount;
          $t2discount = ($t2discount ==="")?0:$t2discount;
	  	  
	  if($studentno=="" || $courseno == "" || $centerid == ""){
		  
		  $arr["message"] .= "<p class='fail'>".($x-1).". No Student No: ".$studentno." or No Course No: ".$studentno." or No Center: ".$centerid."</p><hr>";
		  
		  $tabledata[0] = $studentno;
		  $tabledata[2] = $courseno;
		  $tabledata[4] = $centerid;
		
		  $tabledata[10] = "<p class='fail'> No Student ID or No Course ID or No Center ID</p>";
		  $arr["tabledata"][$tb] = $tabledata;
		  
		  $txt = ($x-1).". SNO:".$studentno."-CNO:".$courseno."-CID:".$centerid."\n";
		  fwrite($myfile, $txt);
		  
		  $x++;$tb++;continue;
		  
	  }
	  	  
	  $this->load->model('import_model','',TRUE);
	  
	  $studdetails = $this->import_model->getStudentno($studentno);
	  
	  $studarr = explode("-",$studdetails);
	  
	  $studid = $studarr[0];
	  $studentname = $studarr[1];
	  	  
	  if($studid == ""){
		  
		  $arr["message"] .= "<p class='fail'>".($x-1).". No Student No.: ".$studentno."</p><hr>";
		  
		  $tabledata[0] = '<a target="_blank" href="studentprofile?sid='.$studid.'">'.$studentno.'</a>';
		  $tabledata[2] = $courseno;
		  $tabledata[4] = $centerid;		
		  $tabledata[10] = "<p class='fail'> No Student ID</p>";
		  $arr["tabledata"][$tb] = $tabledata;
		  
		  $txt = ($x-1).". SNO:".$studentno."-NF \n";
		  fwrite($myfile, $txt);
		  
		  $x++;$tb++;continue;
	  }
	  
	 
			  
		  $courseresult = $this->import_model->getcourseid($courseno,'');

		  $carr = explode("-",$courseresult);
		  $courseid = $carr[0];
	  	  $coursename = $carr[3];
	  
	  	 
	  	  if($courseid==""){
			  
			   $arr["message"] .= "<p class='fail'> ".($x-1).". No Course No: ".$courseno." Student ID: ".$studentno."</p><hr>";
			  
			  $tabledata[0] = '<a target="_blank" href="studentprofile?sid='.$studid.'">'.$studentno.'</a>';
                          $tabledata[1] = $studentname;
			  $tabledata[2] = $courseno;
			  $tabledata[4] = $centerid;
			
			  $tabledata[10] = "<p class='fail'> No Course ID</p>";
			  $arr["tabledata"][$tb] = $tabledata;
			  
			  $txt = ($x-1).". SNO:".$studentno."-CNO:".$courseno."-NF \n";
		  	  fwrite($myfile, $txt);
			  
			  $x++;$tb++;continue;
		  }
	  
	  
	   	  $centername = $this->import_model->getcentername($centerid);
	  
		  if($centername==""){
			  
			   $arr["message"] .= "<p class='fail'>".($x-1).". No Center Name ".$centerid." Student ID:".$studentno." Course No: ".$courseno."</p><hr>";
		  
			  $tabledata[0] = '<a target="_blank" href="studentprofile?sid='.$studid.'">'.$studentno.'</a>';	 
                          $tabledata[1] = $studentname;
			  $tabledata[2] = $courseno;$tabledata[3] = $coursename;
			  $tabledata[4] = $centerid;
			  $tabledata[10] = "<p class='fail'> No Center Name</p>";
			  $arr["tabledata"][$tb] = $tabledata;
			  
			  $txt = ($x-1).". SNO:".$studentno."-CNO:".$courseno."-CID:".$centerid."-NF \n";
		  	  fwrite($myfile, $txt);
			  
			  $x++;$tb++;continue;
			  
		  }
	  
	  	  $basecenter = $centername;
			  		
	  
	  	 $arr["message"] .= '<div class="row"><div class="col-6"><h3>'.($x-1).'. Student No: <span>'.$studentno.'</span></h3></div><div class="col-6"><h3>Course No: <span>'.$courseno.'</span></h3></div></div>';
	  
		  
		   // Course Request
		  
		  $requestid = $this->import_model->getcridfordiscount($studid,$courseid,$basecenter);
		  
		  	
	  
	  if($requestid!=""){
		  
		  // Admin Group
		  
		  $isValid = $this->import_model->checkdiscountisvalid($requestid,$tdiscount,$t1discount,$t2discount);
		  		  
		  if($isValid)
		  {
			   $cgmessage = $this->import_model->insertbulkdiscount($requestid,$tdiscount,$t1discount,$t2discount,$reason);
			  
			   $arr["message"] .= $cgmessage['message'];
				  	
			  $arr["message"] .= "<hr>";
			  
			   $tabledata[0] = '<a target="_blank" href="studentprofile?sid='.$studid.'">'.$studentno.'</a>';
                           $tabledata[1] = $studentname;
			  $tabledata[2] = $courseno;$tabledata[3] = $coursename;
			  $tabledata[4] = $centerid;$tabledata[5] = $basecenter;
			  $tabledata[6] = $tdiscount;$tabledata[7] = $t1discount;
                          $tabledata[8] = $t2discount;$tabledata[9] = $reason;
                          
			  $arr["tabledata"][$tb] = $tabledata;
			  			  
		 }else{
			  
			  $arr["message"] .= "<p class='fail'>".($x-1).". discount is greater than the unpaid</p><hr>";
			  
			   $tabledata[0] = '<a target="_blank" href="studentprofile?sid='.$studid.'">'.$studentno.'</a>';
                           $tabledata[1] = $studentname;
			  $tabledata[2] = $courseno;$tabledata[3] = $coursename;
			  $tabledata[4] = $centerid;$tabledata[5] = $basecenter;
			  $tabledata[6] = $tdiscount;$tabledata[7] = $t1discount;
                          $tabledata[8] = $t2discount;$tabledata[9] = $reason;
			  $tabledata[10] = "<p class='fail'> Failed!! Discount is greater than the unpaid</p>";
			  $arr["tabledata"][$tb] = $tabledata;
			  
			  $txt = ($x-1).". SNO:".$studentno."-CNO:".$courseno."-CID:".$centerid."-RID:".$requestid."-NFS \n";
		  	  fwrite($myfile, $txt); 	
			  
			  $x++;$tb++;continue;
		  }
		  
	  }else{
			  
			  $arr["message"] .= "<p class='fail'> ".($x-1).". Course Request Not Found or Insert Failed </p><hr>";
		  
		  	   $tabledata[0] = '<a target="_blank" href="studentprofile?sid='.$studid.'">'.$studentno.'</a>';
                           $tabledata[1] = $studentname;
			  $tabledata[2] = $courseno;$tabledata[3] = $coursename;
			  $tabledata[4] = $centerid;$tabledata[5] = $basecenter;
			  $tabledata[6] = $tdiscount;$tabledata[7] = $t1discount;
                          $tabledata[8] = $t2discount;$tabledata[9] = $reason;
			  $tabledata[10] = "<p class='fail'>Not Found or Insert Failed </p>";
			  $arr["tabledata"][$tb] = $tabledata;
		  
		      $txt = ($x-1).". SNO:".$studentno."-CNO:".$courseno."-CID:".$centerid."-NCR \n";
		  	  fwrite($myfile, $txt);
		  
		  	  $x++;$tb++;continue;
			  			  
		  }
			  
		  		  
		  //exit;
	  	  
		  $x++;$tb++;
		  		  			  
  }
	
	fclose($myfile);
	
	return $arr;

	
}
	
	
}
?>

<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Sturefund extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model('login_model','',TRUE);
                $this->load->model('payment_model','',TRUE);
                $this->load->library('table'); $this->load->helper('form');

	}
	
	function index()
	{
		if($this->session->userdata('loggedin')&& $this->session->userdata('studlog_in'))
   		{
                    $session_data = $this->session->userdata('loggedin');
                    $session_id = $session_data['id'];
                    $session_role = $session_data['role'];
                    
                     $data['user'] = $this->login_model->GetUserId();       
                     $tmpl = array('table_open' => '<table class="sortable" id="qtable" style="margin-top:0px;">');
                                $this->table->set_template($tmpl);
                                $this->table->set_heading('APP NO','COURSE NAME','CENTER','REMITTED','DEDUCTION','REFUND NET','GST REFUND','TOTAL REFUND','STATUS','REMARKS');
						
                    $this->load->view('header',$data);
                    $this->load->view('stu_refund_view');
                    $this->load->view('footer');
		
            }
        }
        
         public function GetStudentReundLists() {
            
            if($this->session->userdata('loggedin') && $this->session->userdata('studlog_in')){
                
                $user = $this->login_model->GetUserId();	
                $ret =  $this->payment_model->GetStudentRefundLists($user['id']);
                echo $ret;
                
            }else{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
            }
            
        }
        
     

	
}
?>

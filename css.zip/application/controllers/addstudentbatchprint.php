<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Addstudentbatchprint extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model('login_model','',TRUE);
                $this->load->model('student_model','',TRUE);
                $this->load->library('table');
				$this->load->helper('form');
	
	}
	
	function index()
	{
		if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in'))
   		{
                    $session_data = $this->session->userdata('loggedin');
                    $session_id = $session_data['id'];
                    $session_role = $session_data['role'];
                    
                    $data['user'] = $this->login_model->GetUserId();		
		
					$data['roleaccess'] = $this->config->item('roleaccess');

					if($data['roleaccess']['ID Card Batch Print'][3]!="y"){
						redirect($data['roleaccess']['defaultpage'], 'refresh');
					}
			
					$bid = $this->input->get('bid', true);
									
					$data['printbatchid'] = $bid;
						
					$data['pbdetails'] = $this->student_model->GetPrintBatchdetails($bid);
			
					if($data['pbdetails']['batchname']==""){
						redirect('idcardprint', 'refresh');
					}
																	
					$data['menu'] = $this->load->view('headermenu', $data, TRUE);
						
					$this->load->view('header',$data);
					$this->load->view('addstudentbatchprint_view', $data);
					$this->load->view('footer');
						
                    
		}
   		else
   		{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
   		}
		
	}
	
	public function batchSearch() {
		
	   if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')){

		$inword  = isset($_GET['term'])?$_GET['term']:'';

		$ret = $this->student_model->BatchNameSearch($inword);
		echo json_encode($ret);
		}
	}
			
	
	public function batchdatatable(){
		
		if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in'))
   		{
			$batchname = $this->input->post('batchname', true);
			$showphoto = $this->input->post('showphoto', true);
				
			$result =  $this->student_model->GetBatchWiseStudentList($batchname);
			
			$row = array();
			
			$sno = 1;
			
			foreach($result as $key=>$col){
				
				$profilepic = $col->profilepic;
				
				if($profilepic!="0" && $profilepic!=""){ 
					$profilepic = '<img src="docs/profilepic/'.$col->studentid.'/'.$profilepic.'" alt="" class="profileimg">';
				}
				else{ 
					
					if($showphoto=="y") continue;
					
					$profilepic = '<img src="img/myprofile.png" alt="" class="profileimg">';
				}
																		
				$row[] = array('<a style="padding-left:10px;float:left;color:#0332AA;" class="noedit" href="javascript:void(0)"><input class="bccheckbox" type="checkbox" value="'.$col->studentid.'" data-stuno="'.$col->studid.'"></a>',$sno,$profilepic,$col->studid,$col->sname,$col->contact);
									
				$sno++;
																						
			}
			
			$ret = array("tabledata"=>$row);
			echo json_encode($ret);
			
		}
   		else
   		{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
   		}
		
		
	}
	
	public function createbatch() {
		
	   if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')){

			$batchname = $this->input->post('batchname', true);
		    $printbatchid = $this->input->post('printbatchid', true);
		    $printbatchname = $this->input->post('printbatchname', true);
		    $stuid = $this->input->post('ide', true);
		   
		   $stuarr = explode("|",$stuid);
		   
		    /*$printbatchid = $this->student_model->GetPrintBatchID();
		   	$checkbatchid = $this->student_model->CheckPrintBatchID($printbatchid);
		   	$checkbatchname = $this->student_model->CheckPrintBatchName($printbatchname);
		   
		   if(!$checkbatchid){
				echo json_encode(array(0=>"error",1=>"Batch ID Already Exists"));exit;
		   }
		   
		  if(!$checkbatchname){
				echo json_encode(array(0=>"error",1=>"Batch Name Already Exists"));exit;
		   }*/
		   
		   if(!empty($stuarr) && $printbatchid!=""){
		   
		   for($i=0;$i<count($stuarr);$i++){
			   
			   $batchidcount = $this->student_model->GetPrintBatchIDCount($printbatchid);
			   
			   if($batchidcount==120){
				   echo json_encode(array(0=>"full",1=>"Batch list exceeded"));exit;
			   }
			   
			   $studetails = $this->student_model->GetStudentProfile($stuarr[$i]);
			   
			   if(!empty($studetails)){
			   
				   $ide = uniqid();
				   
				   $qData = array(
						'id' => $ide,
						'printbatchid' => $printbatchid,
						'printbatchname' => $printbatchname,
						'studentid' => $stuarr[$i],
						'studid' => $studetails['studid'],
						'batchname' => $batchname,
						'studentname' => $studetails['stuname'],
						'phone' => $studetails['smobile'],
						'status' => "n",
						'created' => date('Y-m-d H:i:s')
					);

				   $ret = $this->student_model->CreatePrintBatch($qData);
				   
			   }
			   
		   }
			   echo json_encode(array(0=>"success"));
			   
		   }else{
			   echo json_encode(array(0=>"empty",1=>"Batch list empty"));
		   }
		   		   
			
		   
		}
		
	}
	
}
?>

<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Refund extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model('login_model','',TRUE);
		$this->load->model('payment_model','',TRUE);
		$this->load->library('table'); $this->load->helper('form');
                 

	}
	
	function index()
	{
		if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in'))
   		{
                    $session_data = $this->session->userdata('loggedin');
                    $session_id = $session_data['id'];
                    $session_role = $session_data['role'];
                    
					$data['roleaccess'] = $this->config->item('roleaccess');

					if($data['roleaccess']['uview']!="y"){
						redirect($data['roleaccess']['defaultpage'], 'refresh');
					}
			
                    $data['user'] = $this->login_model->GetUserId();

                    $data['menu'] = $this->load->view('headermenu', $data, TRUE);
			
                   
                    
                    $refundid =  $ide = isset($_GET['print']) ? $_GET['print'] : '';
                    
                    if($refundid !== ""){
                        $data = $this->payment_model->GetRefundDataForPrint($refundid);
                        $this->load->view('refundapp_view', $data);
                    } else {
                         $this->load->view('header_view', $data);
                        $this->load->view('refund_view', $data);
                         $this->load->view('footer_view');
                    }
                    
                    
                }else{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
   		}
		
	}
	
    public function refundList()
    {

		
	if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')){
			
		
		$roleaccess = $this->config->item('roleaccess');
		
		$user = $this->login_model->GetUserId();
		$batches = $user['batches'];
		
		$columns = array( 
                            0 =>'appno', 
                            1 =>'studid',
                            2=> 'sname',
                            3=> 'cname',
			    4=> 'center',
                            5=> 'type',
                            6=> 'requestedrefundamt',
                            7=> 'status',
                            8=> 'print',
                            9=> ''
                        );

		$limit = $this->input->post('length');
        $start = $this->input->post('start');
        $order = $columns[$this->input->post('order')[0]['column']];
        $dir = $this->input->post('order')[0]['dir'];
		
		$searchcol = $this->input->post('searchcol', true);
  
        $totalData = $this->payment_model->refund_count($batches);
            
        $totalFiltered = $totalData; 
            
        if(empty($this->input->post('search')['value']))
        {            
            $posts = $this->payment_model->refundlist($limit,$start,$order,$dir,$batches);
        }
        else {
            $search = $this->input->post('search')['value']; 

            $posts =  $this->payment_model->refundlist_search($limit,$start,$search,$order,$dir,$searchcol,$batches);

            $totalFiltered = $this->payment_model->refundlist_search_count($search,$searchcol,$batches);
        }

        $data = array();
        if(!empty($posts))
        {
            foreach ($posts as $post)
            {

                $nestedData['appno'] = $post->appno;
                $nestedData['sname'] = '<a class="noedit" target="_blank" href="'.base_url().'studentprofile?sid='.$post->studentid.'">'.strtoupper($post->sname).'</a>';                
                $nestedData['studid'] ='<a class="noedit" target="_blank" href="'.base_url().'studentprofile?sid='.$post->studentid.'">'.$post->studid.'</a>';  
                $nestedData['cname'] ='<a class="noedit" target="_blank" href="'.base_url().'coursedetails?id='.$post->courseid.'">'.$post->cname.'</a>'; 
		$nestedData['center'] = $post->center;
                $nestedData['type'] = $post->type;
                $nestedData['requestedrefundamt'] = $post->requestedrefundamt;
                $nestedData['status'] = "";
                
				$action1 = "-";
                if($post->status === 'w'){
					
					if(isset($roleaccess['Refund Add'][3]) && $roleaccess['Refund Add'][3]=="y"){
						$action1 = '<span data-student="'.$post->sname.'" data-studid="'.$post->studid.'" data-refund="'.$post->requestedrefundamt.'" data-cride="'.$post->requestid.'" data-center="'.$post->center.'" data-cid="'.$post->courseid.'" data-sid="'.$post->studentid.'" data-id="'.$post->id.'" class="addrefund" style="color:#0332AA;padding-left: 20px;background:url('.base_url().'images/addpay.png) no-repeat;background-position-y: 4px;cursor:pointer" >Add Refund</span>';
					}
					
                    $nestedData['status'] = '<p class="rstatus" data-cride="'.$post->requestid.'" data-id="'.$post->id.'" style="cursor:pointer;margin:0px auto;background:#F48D25;padding:5px;color:#fff;width: 70px;border-radius: 5px;;font-size:11px">Waiting list</p>';
										
                } else if($post->status === 'c'){
					
                    $nestedData['status'] = '<p class="rstatus" data-cride="'.$post->requestid.'" data-id="'.$post->id.'" style="cursor:pointer;margin:0px auto;background:#3CAF92;padding:5px;color:#fff;width: 70px;border-radius: 5px;font-size:11px">Completed</p>';
                    $action1 = '<span data-student="'.$post->sname.'" data-studid="'.$post->studid.'" data-cride="'.$post->requestid.'" data-center="'.$post->center.'" data-cid="'.$post->courseid.'" data-sid="'.$post->studentid.'" data-id="'.$post->id.'" class="refundview" style="color:#0332AA;padding-left: 20px;background:url('.base_url().'images/view.png) no-repeat;background-position-y: 4px;cursor:pointer" >View</span>';
					
                }else if($post->status === 'cf'){
					
                    $nestedData['status'] = '<p class="rstatus" data-cride="'.$post->requestid.'" data-id="'.$post->id.'" style="cursor:pointer;margin:0px auto;background:#29806A;padding:5px;color:#fff;width: 70px;border-radius: 5px;font-size:11px">Confirmed</p>';
                    $action1 = '<span data-student="'.$post->sname.'" data-studid="'.$post->studid.'" data-cride="'.$post->requestid.'" data-center="'.$post->center.'" data-cid="'.$post->courseid.'" data-sid="'.$post->studentid.'" data-id="'.$post->id.'" class="refundview" style="color:#0332AA;padding-left: 20px;background:url('.base_url().'images/view.png) no-repeat;background-position-y: 4px;cursor:pointer" >View</span>';
					
                }else if($post->status === 'n'){
					
                    $nestedData['status'] = '<p class="rstatus" data-cride="'.$post->requestid.'" data-id="'.$post->id.'" style="cursor:pointer;margin:0px auto;background:#db4d4d;padding:5px;color:#fff;width: 70px;border-radius: 5px;font-size:11px">Not Eligible</p>';
                    $action1 = '<span data-student="'.$post->sname.'" data-studid="'.$post->studid.'" data-cride="'.$post->requestid.'" data-center="'.$post->center.'" data-cid="'.$post->courseid.'" data-sid="'.$post->studentid.'" data-id="'.$post->id.'" class="refundview" style="color:#0332AA;padding-left: 20px;background:url('.base_url().'images/view.png) no-repeat;background-position-y: 4px;cursor:pointer" >View</span>';
					
                } else if($post->status === 'cd'){
					
                    $nestedData['status'] = '<p class="rstatus" data-cride="'.$post->requestid.'" data-id="'.$post->id.'" style="cursor:pointer;margin:0px auto;background:#db4d4d;padding:5px;color:#fff;width: 70px;border-radius: 5px;font-size:11px">Cancelled</p>';
                    $action1 = '<span data-student="'.$post->sname.'" data-studid="'.$post->studid.'" data-cride="'.$post->requestid.'" data-center="'.$post->center.'" data-cid="'.$post->courseid.'" data-sid="'.$post->studentid.'" data-id="'.$post->id.'" class="refundview" style="color:#0332AA;padding-left: 20px;background:url('.base_url().'images/view.png) no-repeat;background-position-y: 4px;cursor:pointer" >View</span>';
					
                } else if($post->status === 'p'){
					
                    $nestedData['status'] = '<p class="rstatus" data-cride="'.$post->requestid.'" data-id="'.$post->id.'" style="cursor:pointer;margin:0px auto;background:#B06315;padding:5px;color:#fff;width: 70px;border-radius: 5px;;font-size:11px">Progress</p>';
					
					if(isset($roleaccess['Refund Add'][3]) && $roleaccess['Refund Add'][3]=="y"){
						$action1 = '<span data-student="'.$post->sname.'" data-studid="'.$post->studid.'" data-refund="'.$post->requestedrefundamt.'" data-cride="'.$post->requestid.'" data-center="'.$post->center.'" data-cid="'.$post->courseid.'" data-sid="'.$post->studentid.'" data-id="'.$post->id.'" class="addrefund" style="color:#0332AA;padding-left: 20px;background:url('.base_url().'images/addpay.png) no-repeat;background-position-y: 4px;cursor:pointer" >Add Refund</span>';
					}
                    
                } 
		
                $nestedData['print'] = '<a  data-bankname="'.$post->bankname.'"  data-branch="'.$post->branch.'"  data-ifsccode="'.$post->ifsccode.'"  data-bankaccountno="'.$post->bankaccountno.'" data-status="'.$post->status.'" data-id="'.$post->id.'" data-type="'.$post->type.'" class="printrefund" id="'.$post->id.'" href="javascript:void(0)">Print</a>';
        	$action = '';
		
		
                $nestedData['actions'] = $action.$action1;
            
                
                $data[] = $nestedData;

            }
        }
          
        $json_data = array(
                    "draw"            => intval($this->input->post('draw')),  
                    "recordsTotal"    => intval($totalData),  
                    "recordsFiltered" => intval($totalFiltered), 
                    "data"            => $data   
                    );
            
        echo json_encode($json_data); 
			
	}else{
			
		//If no session, redirect to login page
		redirect('login', 'refresh');
			
	}
		
    }
    
    
    public function getRefundPaymentLists() {
            
            if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in') || $this->session->userdata('studlog_in')){
                $cid = isset($_POST['cid']) ? $_POST['cid'] : '';
                $sid = isset($_POST['sid']) ? $_POST['sid'] : '';
                $center = isset($_POST['center']) ? $_POST['center'] : '';
               
                
                $ret =  $this->payment_model->GetRefundPaymentLists($cid,$sid,$center);
                echo $ret;
                
            }else{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
            }
            
        }
        
         public function getNewCoursePaymentLists() {
            
            if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in') || $this->session->userdata('studlog_in')){
                $cid = isset($_POST['cid']) ? $_POST['cid'] : '';
                $center = isset($_POST['center']) ? $_POST['center'] : '';
               
                
                $ret =  $this->payment_model->GetNewCoursePaymentLists($cid,$center);
                echo $ret;
                
            }else{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
            }
            
        }
        
         public function addRefund(){
            
            if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')){

               
                $paymode = isset($_GET['paymode']) ? $_GET['paymode'] : '';
                $pdescription = isset($_GET['pdescription']) ? $_GET['pdescription'] : '';
                $paydate = isset($_GET['paydate']) ? $_GET['paydate'] : '';
                $reason = isset($_GET['reason']) ? $_GET['reason'] : '';
                $ide = isset($_GET['ide']) ? $_GET['ide'] : '';
                $studid = isset($_GET['studid']) ? $_GET['studid'] : '';
                $refundid = isset($_GET['refundid']) ? $_GET['refundid'] : '';
                $stupayid = isset($_GET['stupayid']) ? $_GET['stupayid'] : '';
                $amount = isset($_GET['amount']) ? $_GET['amount'] : '';
                $remit = isset($_GET['remit']) ? $_GET['remit'] : '';
                $refund = isset($_GET['refund']) ? $_GET['refund'] : '';
                $gstrefund = isset($_GET['gstrefund']) ? $_GET['gstrefund'] : '';
                $refundtotal = isset($_GET['refundtotal']) ? $_GET['refundtotal'] : '';
                $center = isset($_GET['center']) ? $_GET['center'] : '';
                $remarks = isset($_GET['remarks']) ? $_GET['remarks'] : '';
                $rid = isset($_GET['rid']) ? $_GET['rid'] : '';
                             
               

                if($ide != ""){
                     $this->payment_model->AddRefund($remarks,$paymode,$pdescription,$reason,$ide,$studid,$refundid,$center,$stupayid,$amount,$remit,$refund,$gstrefund,$refundtotal,$rid,$paydate);
					
					$this->load->model('notification_model','',TRUE);
				 	$this->notification_model->RefundNotification($studid);
					
                     $ret = array(0 => "success");
                } else {
                    $ret = array(0 => "fail");
                }

                echo json_encode($ret);
            
            }else {
                //If no session, redirect to login page
                redirect('login', 'refresh');
            }
            
        }
        
        public function viewRefundPaymnets() {
            
            if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in') || $this->session->userdata('studlog_in')){
  
                $id = isset($_GET['id']) ? $_GET['id'] : '';
                $ret = array(0 => "success",1=>"");
        
            
                $html = $this->payment_model->ViewRefundPaymentLists($id);
                $ret[1]= $html;
                echo json_encode($ret);
            }
        }
        
        
        public function ChangeStatus(){
            
            if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')){

                $ide = isset($_GET['ide']) ? $_GET['ide'] : '';
                $status = isset($_GET['status']) ? $_GET['status'] : '';
                $cride = isset($_GET['cride']) ? $_GET['cride'] : '';
                 $remarks = isset($_GET['remarks']) ? $_GET['remarks'] : '';

                if($ide != ""){
                     $ret = $this->payment_model->ChangeRefundStatus($ide,$status,$cride,$remarks);
                } else {
                    $ret = array(0 => "fail");
                }

                echo json_encode($ret);
            
            }else {
                //If no session, redirect to login page
                redirect('login', 'refresh');
            }
            
        }
        
          public function editRefund(){
            
            if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')){

               
                $paymode = isset($_GET['paymode']) ? $_GET['paymode'] : '';
                $pdescription = isset($_GET['pdescription']) ? $_GET['pdescription'] : '';
                $paydate = isset($_GET['paydate']) ? $_GET['paydate'] : '';
                $paycheque = isset($_GET['paycheque']) ? $_GET['paycheque'] : '';
                $reason = isset($_GET['reason']) ? $_GET['reason'] : '';       
                $refundid = isset($_GET['refundid']) ? $_GET['refundid'] : '';
                $stupayid = isset($_GET['stupayid']) ? $_GET['stupayid'] : '';
                $amount = isset($_GET['amount']) ? $_GET['amount'] : '';
                $remit = isset($_GET['remit']) ? $_GET['remit'] : '';
                $refund = isset($_GET['refund']) ? $_GET['refund'] : '';
                $gstrefund = isset($_GET['gstrefund']) ? $_GET['gstrefund'] : '';
                $refundtotal = isset($_GET['refundtotal']) ? $_GET['refundtotal'] : '';
                $status = isset($_GET['status']) ? $_GET['status'] : '';
                $ide = isset($_GET['sid']) ? $_GET['sid'] : '';
                   

                if($ide != ""){
                     $this->payment_model->EditRefund($status,$paymode,$pdescription,$reason,$refundid,$stupayid,$amount,$remit,$refund,$gstrefund,$refundtotal,$paydate,$paycheque);
                     
                     if($status === "cf") {
                         $this->load->model('notification_model','',TRUE);
			 $this->notification_model->RefundConfirmatiion($ide);
                     }
                     
		     $ret = array(0 => "success");
                } else {
                    $ret = array(0 => "fail");
                }

                echo json_encode($ret);
            
            }else {
                //If no session, redirect to login page
                redirect('login', 'refresh');
            }
            
        }
        
        public function refundprint(){
            
            if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')){

               
                $ide = isset($_GET['ide']) ? $_GET['ide'] : '';
                if($ide != ""){
                   $data['refundbill'] =  $this->payment_model->GetRefundBill($ide);
                   $this->load->view('refund_bill_view', $data);
					
		 }
                
                
            
            }else {
                //If no session, redirect to login page
                redirect('login', 'refresh');
            }
            
        }
        
                public function addBankDetails(){
            
            if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')){

                $bankname = isset($_GET['bankname']) ? $_GET['bankname'] : '';
                $branch = isset($_GET['branch']) ? $_GET['branch'] : '';
                $ifsccode = isset($_GET['ifsccode']) ? $_GET['ifsccode'] : '';
                $ide = isset($_GET['ide']) ? $_GET['ide'] : '';
                $bankaccountno = isset($_GET['bankaccountno']) ? $_GET['bankaccountno'] : '';
                
                if($ide != ""){
                     $this->payment_model->AddBankDetails($ide,$bankname,$branch,$ifsccode,$bankaccountno);
					
                     $ret = array(0 => "success");
                } else {
                    $ret = array(0 => "fail");
                }

                echo json_encode($ret);
            
            }else {
                //If no session, redirect to login page
                redirect('login', 'refresh');
            }
            
        }
	
}
?>

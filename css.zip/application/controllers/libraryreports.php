<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Libraryreports extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model('login_model','',TRUE);
                $this->load->model('library_model','',TRUE);     
                $this->load->library('table'); 
                 $this->load->helper('download');
                 

	}
	
	function index()
	{
		if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in'))
   		{
                    $session_data = $this->session->userdata('loggedin');
                    $session_id = $session_data['id'];
                    $session_role = $session_data['role'];
                    
			
					$data['roleaccess'] = $this->config->item('roleaccess');

					if($data['roleaccess']['uview']!="y"){
						redirect($data['roleaccess']['defaultpage'], 'refresh');
					}
			
                    $data['user'] = $this->login_model->GetUserId();		
		
                        
                    $ide = isset($_GET['id']) ? $_GET['id'] : '';
                    $location = isset($_GET['location']) ? $_GET['location'] : '';
                    $data['menu'] = $this->load->view('headermenu', $data, TRUE);
                        if(($ide == '')&&($location === '')) {
                        
                         $tmpl = array('table_open' => '<table class="sortable" id="librarytable" style="margin-top:0px;">');
                                    $this->table->set_template($tmpl);
                                    $this->table->set_heading('SNO', 'LOCATION', 'TOTAL STOCK');
             
                        $this->load->view('header_view', $data);
                        $this->load->view('libraryreports_location_view', $data);
                        $this->load->view('footer_view');

                        } else if(($ide === '')&&($location !== '')) {
                            
                            $data['location'] = $location;     
                            $tmpl = array('table_open' => '<table class="sortable" id="librarytable" style="margin-top:0px;">');
                                    $this->table->set_template($tmpl);
                                      $this->table->set_heading('SNO','BOOK NAME','ISBN NUMBER','LIBRARY','REFERENCE');
                                    $this->load->view('header_view', $data);
                        $this->load->view('libraryreports_stock_view', $data);
                        $this->load->view('footer_view');
                        }else if(($ide !== '')&&($location !== '')) {
                            
                            $data['bookid'] = $ide;     
                            $data['location'] = $location;     
                            $data['bname']  = $this->library_model->BookDetails($ide);
                            $tmpl = array('table_open' => '<table class="sortable" id="librarytable" style="margin-top:0px;">');
                           $this->table->set_template($tmpl);
                            $this->table->set_heading('S.NO','BARCODE','ISSUED');
                           $this->load->view('header_view', $data);
                        $this->load->view('libraryreports_issue_view', $data);
                        $this->load->view('footer_view');
                        } else{
                            redirect('login', 'libraryreports');
                        }
                        
                }
   		else
   		{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
   		}
		
	}
        
         public function GetLocationStocks() {
            
            if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')){
                
		$roleaccess = $this->config->item('roleaccess');
			
                $ret =  $this->library_model->GetLocationStocks();  
                
                echo ($ret);
                
            }else{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
            }
            
        }
        
        public function GetLocationBookStocks() {
            
            if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')){
                
		$roleaccess = $this->config->item('roleaccess');
                $data['user'] = $this->login_model->GetUserId();		
				
                $location = isset($_POST['center']) ? $_POST['center'] : '';
                $ret =  $this->library_model->GetLocationBookStocks($location,$data['user']['lcenters']);
                echo $ret;
                
            }else{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
            }
            
        }
        
	
        public function GetIssuedStocks()
        {

                if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')){

                        $roleaccess = $this->config->item('roleaccess');

                        $data['user'] = $this->login_model->GetUserId();

                        $bookid = isset($_POST['bookid']) ? $_POST['bookid'] : '';
                        $location = isset($_POST['center']) ? $_POST['center'] : '';
                        $ret =  $this->library_model->GetIssuedStockReports($bookid,$location,$data['user']['lcenters']);
                        echo $ret;

                }else{

                        //If no session, redirect to login page
                        redirect('login', 'refresh');

                }

        }
        
      
  
   public function export(){
            
            if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')){

				
				$roleaccess = $this->config->item('roleaccess');
		
				if(isset($roleaccess['Library Reports'][3]) && $roleaccess['Library Reports'][3]=="y"){
				
                                    $bookid = isset($_GET['bookid']) ? $_GET['bookid'] : '';
                                    $center = isset($_GET['center']) ? $_GET['center'] : '';

                                    $html .= '<tr><td>S.no</td><td>Book Name</td><td>Bar Code</td><td>Book Type</td><td>Center</td><td>Name</td><td>Student ID</td><td>Country Code</td><td>Mobile Number</td><td>Email</td></tr>';

                                      $ret = $this->library_model->ExportLibraryBooks($center,$bookid);

                                       $i = 1;
                                      foreach ($ret as $key=>$val){
                                         $html .= '<tr><td>'.$i.'</td><td>'.$val['bookname'].'</td><td>'.$val['barcode'].'</td><td>'.$val['booktype'].'</td><td>'.$val['center'].'</td><td>'.$val['sname'].'</td><td>'.$val['studid'].'</td><td>'.$val['mcode'].'</td><td>'.$val['contact'].'</td><td>'.$val['email'].'</td></tr>';
                                         $i++;
                                     }
                                
                
                                    $savename = "Library Book Student Profile Export".date('d-m-Y-H_i_s');
                                    $html = str_replace('<tr>',"\n",$html);
                                         $html = str_replace('</tr>',"",$html);

                                         $html = str_replace('</th>',"\t",$html);
                                         $html = str_replace('<th>',"",$html);

                                         $html = str_replace('</td>',"\t",$html);
                                         $html = str_replace('<td>',"",$html);


                                    $html = strip_tags($html);

                                    $filename = $savename .".xls";

                                    force_download($filename, $html);
                                }	
            
            }else {
                //If no session, redirect to login page
                redirect('login', 'refresh');
            }
            
        }

	
}
?>

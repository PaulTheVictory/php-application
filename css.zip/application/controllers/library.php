<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Library extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model('login_model','',TRUE);
                $this->load->model('library_model','',TRUE);
                $this->load->library('table');
				$this->load->helper('form');
	
	}
	
	function index()
	{
		if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in'))
   		{
                    $session_data = $this->session->userdata('loggedin');
                    $session_id = $session_data['id'];
                    $session_role = $session_data['role'];
                    
                    $data['user'] = $this->login_model->GetUserId();		
		
					$data['roleaccess'] = $this->config->item('roleaccess');

					if($data['roleaccess']['uview']!="y"){
						redirect($data['roleaccess']['defaultpage'], 'refresh');
					}
			
			
					$tmpl = array('table_open' => '<table class="sortable sorting disabled table" id="usertable" style="margin-top:0px;">');
					$this->table->set_template($tmpl);
					$this->table->set_heading('S.NO', 'BOOK NAME', 'ISBN NUMBER','STOCK','EDITION','AUTHOR','PUBLISHER','ACTIONS');
			
					$data['menu'] = $this->load->view('headermenu', $data, TRUE);
																		
					$this->load->view('header',$data);
					$this->load->view('library_view', $data);
					$this->load->view('footer');
                    
		}
   		else
   		{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
   		}
		
	}
        
    
	 public function GetBooks() {
            
		if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in') ){

			$ret =  $this->library_model->GetBooks();
			echo $ret;

		}else{
		//If no session, redirect to login page
		redirect('login', 'refresh');
		}

	}
	
	
}
?>

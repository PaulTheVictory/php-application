<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Allocation extends CI_Controller {

	function __construct() {
            
		parent::__construct();
                $this->load->model('login_model','',TRUE);
                 $this->load->model('allocation_model','',TRUE);
                 $this->load->library('table'); $this->load->helper('form');

	}
	
	function index() {
            
            if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')) {

                $session_data = $this->session->userdata('loggedin');
                $session_id = $session_data['id'];
                $session_role = $session_data['role'];
               


				$data['roleaccess'] = $this->config->item('roleaccess');

				if($data['roleaccess']['uview']!="y"){
					redirect($data['roleaccess']['defaultpage'], 'refresh');
				}
                                
                                 $data['user'] = $this->login_model->GetUserId();
				
                $data['menu'] = $this->load->view('headermenu', $data, TRUE);
                $ide = isset($_GET['id']) ? $_GET['id'] : '';
                if($ide === "") {
                    $tmpl = array('table_open' => '<table class="sortable sorting disabled" id="templatetable" style="margin-top:0px;">');
                    $this->table->set_template($tmpl);
                    $this->table->set_heading('S.NO', 'ACADEMIC YEAR','ACTIONS');

                    $this->load->view('header_view', $data);
                    $this->load->view('allocationyear_view', $data);
                    $this->load->view('footer_view');
                
                } elseif($ide !== ""){
                    $data['ide'] = $ide;
                    $data['year'] = $this->allocation_model->GetYearDetails($ide);
                    $tmpl = array('table_open' => '<table class="sortable sorting disabled" id="templatetable" style="margin-top:0px;">');
                    $this->table->set_template($tmpl);
                    $this->table->set_heading('S.NO', 'SCHOOL NAME','LOCATION','TYPE','2nd LANGUAGE','HOSTEL','STREAMS','SYALLABUS','SUBJECTS','ALLOCATED/AVAILABLE','TOTAL SEATS','ACTIONS');

                    $this->load->view('header_view', $data);
                    $this->load->view('allocationschools_view', $data);                 
                    $this->load->view('footer_view');
                }
                
            } else {
                //If no session, redirect to login page
                redirect('login', 'refresh');
            }
            
        }
        
        
       
          public function GetAcademicYears() {
            
            if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in') ){
     
                $ret =  $this->allocation_model->GetAcademicYears();
                echo $ret;
                
            }else{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
            }
            
        }
        
        public function addYear(){
		
            if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in'))
            {

                $yname = $this->input->post('yname');

                $this->load->library('form_validation');
                $this->form_validation->set_rules('yname', 'Academic Year', 'trim|required|xss_clean|callback_alpha_numeric_spaces|max_length[100]');

                if ($this->form_validation->run() == false) {
                    $response = array(
                        'status' => 'error',
                        'message' => validation_errors()
                    );
                } else {

                    $this->allocation_model->AddYear($yname);
                    $response = array(
                        'status' => 'success',
                        'message' => 'Year Added Successfully'
                    );

                }
                echo json_encode($response);

            }else{
                //If no session, redirect to login page
                redirect('login', 'refresh');
            }
		
	}
        
         public function GetAllocatedSchools() {
            
            if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in') ){
                $ide = $this->input->post('ide');
                $ret =  $this->allocation_model->GetAllocatedSchools($ide);
                echo $ret;
                
            }else{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
            }
            
        }
        
        

}
?>
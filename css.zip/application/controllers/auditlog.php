<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Auditlog extends CI_Controller {

	function __construct() {
            
		parent::__construct();
                $this->load->model('login_model','',TRUE);
		$this->load->model('audit_model','',TRUE);
              

	}
	
	function index() {
            
           if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')) {

                $session_data = $this->session->userdata('loggedin');
                $session_id = $session_data['id'];
                $session_role = $session_data['role'];
			   
		$data['roleaccess'] = $this->config->item('roleaccess');
		if($data['roleaccess']['uview']!="y"){
        		redirect($data['roleaccess']['defaultpage'], 'refresh');
		}
			   
                $data['user'] = $this->login_model->GetUserId();
                $data['menu'] = $this->load->view('headermenu', $data, TRUE);
                
                $sdate = isset($_GET['sdate']) ? $_GET['sdate'] : '';
                $edate = isset($_GET['edate']) ? $_GET['edate'] : '';
                $type = isset($_GET['type']) ? $_GET['type'] : '';
                $user = isset($_GET['user']) ? $_GET['user'] : 'All';
                
                $sdate = ($sdate ==="")?(date('Y-m-d H:i:s',strtotime("-1 days"))):$sdate;
                $edate = ($edate ==="")?(date('Y-m-d H:i:s')):$edate;
                
               
               $data['sdate'] = $sdate;$data['edate'] = $edate;
               $data['users'] = $this->audit_model->GetAllUsers($user,'option');
               $data['stype'] = $type;
                
                $data['reports'] = $this->audit_model->GetLogs($sdate,$edate,$user,$type);
                 
                 $this->load->view('header_view', $data);
                 $this->load->view('auditlog_view', $data);
                 $this->load->view('footer_view');
                 
                
            } else {
                //If no session, redirect to login page
                redirect('login', 'refresh');
            }
            
        }
        

     
}
?>
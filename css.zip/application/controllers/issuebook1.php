<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Issuebook extends CI_Controller {

	function __construct() {
            
		parent::__construct();
		
                $this->load->model('login_model','',TRUE);
                $this->load->model('library_model','',TRUE);
				$this->load->helper('form');

	}
	
	function index() {
            
            if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')) {

                $session_data = $this->session->userdata('loggedin');
                $session_id = $session_data['id'];
                $session_role = $session_data['role'];
                $data['user'] = $this->login_model->GetUserId();

				$data['roleaccess'] = $this->config->item('roleaccess');
			
				if($data['roleaccess']['Issue Books'][3]!="y"){
					redirect($data['roleaccess']['defaultpage'], 'refresh');
				}
												
				$data['units'] = $this->library_model->GetAllCenters("",'option',$data['user']['lcenters']);               

				$data['menu'] = $this->load->view('headermenu', $data, TRUE);
                $this->load->view('header', $data);
                $this->load->view('issuebook_view', $data);
                $this->load->view('footer');
				
            } else {
                //If no session, redirect to login page
                redirect('login', 'refresh');
            }
            
        }
        
    
	 public function issuebookSubmit() {
            
        if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')) {
			
			$roleaccess = $this->config->item('roleaccess');
			
			if(isset($roleaccess['Issue Books'][3]) && $roleaccess['Issue Books'][3]=="y"){
			         
				$studentid = $this->input->post("studentid",true);
			
				$studentdetails = $this->library_model->GetStudentProfile($studentid); //print_r($studentdetails);exit;       
			
			if(empty($studentdetails)){
				
				$response = array(
					'status' => 'error',
					'message' => 'Student details not found'
				);
				
				echo json_encode($response);
				
			}else{
				
				$response = array(
					'status' => 'success',
					'data' => $studentdetails
				);
				
				echo json_encode($response);
			}
                

			 } else {

 					$response = array(
                            'status' => 'error',
                            'message' => 'User Permission Denied'
                        );
                        echo json_encode($response);
                }
              
               
            }else{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
            }
            
    }
    
       
	public function generate_barcode(){
		
		if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in'))
   		{
			
			$barcode = $this->input->get('bcode');
			
			// Load library
			$this->load->library('zend');
			// Load in folder Zend
			$this->zend->load('Zend/Barcode');
				
			// Generate barcode
			
			$imageResource = Zend_Barcode::factory('code128', 'image', array('text'=>"$barcode",'stretchText'=>true,'withBorder'=>false,'font'=>3,'fontSize'=>18,'barHeight'=>40,'barThickWidth'=>3,'barThinWidth'=>2,'withQuietZones'=>false,'drawText'=>true), array('imageType'=>'png'))->render();

			//imagepng($imageResource, $dirname.$bccode.'.png');
						
			
	}
   		else
   		{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
   		}		
		
	}
	

}
?>
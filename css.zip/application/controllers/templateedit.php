<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Templateedit extends CI_Controller {

	function __construct() {
            
		parent::__construct();
		$this->load->model('notification_model','',TRUE);
                $this->load->model('login_model','',TRUE);
                 $this->load->helper('form');

	}
	
	function index() {
            
            if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')) {

                $session_data = $this->session->userdata('loggedin');
                $session_id = $session_data['id'];
                $session_role = $session_data['role'];
                $id = isset($_GET['id']) ? $_GET['id'] : '';
                $data['user'] = $this->login_model->GetUserId();
				
				$data['roleaccess'] = $this->config->item('roleaccess');

				if($data['roleaccess']['SMS Templates'][1]!="y"){
					redirect($data['roleaccess']['defaultpage'], 'refresh');
				}
				
                $data['edit'] = $this->notification_model->EditTemplate($id);


                $data['menu'] = $this->load->view('headermenu', $data, TRUE);
                
                $this->load->view('header_view', $data);
                $this->load->view('templateedit_view', $data);
                $this->load->view('footer_view');
                
            } else {
                //If no session, redirect to login page
                redirect('login', 'refresh');
            }
            
        }
        
        
             
        
       public function userSubmit() {
            
        if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')) {
                  $this->load->library('form_validation');
                
			$roleaccess = $this->config->item('roleaccess');
			
			if(isset($roleaccess['SMS Templates'][1]) && $roleaccess['SMS Templates'][1]=="y"){
			
                $this->form_validation->set_rules('tname', 'Template Name', 'trim|required|xss_clean|callback_alpha_numeric_spaces|max_length[100]');
                $this->form_validation->set_rules('tid', 'Template ID', 'trim|required|xss_clean|callback_alpha_numeric_spaces|max_length[100]');
                $this->form_validation->set_rules('message', 'Message', 'trim|required|xss_clean|callback_alpha_numeric_spaces|max_length[1000]');
                

             
                if ($this->form_validation->run() == false) {
                        $response = array(
                            'status' => 'error',
                            'message' => validation_errors()
                        );
                        echo json_encode($response);

                } else {

                    
                    
                     $response = $this->notification_model->UpdateTemplate($this->input->post('uide', true),$this->input->post('tname', true),$this->input->post('tid', true),$this->input->post('message', true));
                     echo  json_encode($response);
                }
				
			}else {

			  $response = array(
					'status' => 'error',
					'message' => 'User Permission denied'
				);
				echo json_encode($response);
			}
              
               
            }else{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
            }
            
    }
            

}
?>
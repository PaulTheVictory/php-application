<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

use \setasign\Fpdi;

class Stufeepayments extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model('login_model','',TRUE);
                $this->load->model('course_model','',TRUE);
				$this->load->model('student_model','',TRUE);
		$this->load->model('payment_model','',TRUE);
                 $this->load->library('table'); 

	}
	
	function index()
	{
		if($this->session->userdata('loggedin'))
   		{
                    $session_data = $this->session->userdata('loggedin');
                    $session_id = $session_data['id'];
                    $session_role = $session_data['role'];
                    
                    $data['user'] = $this->login_model->GetUserId();		
		
					if($session_role === 'student') {
						
						$feepayid = $this->input->get('id');
						$data['paystatus'] = $this->input->get('status');
						$refno = $this->input->get('refno');
						
						$data['crid'] = $feepayid;
												
						$qid = $this->student_model->GetQualificationID($data['user']['id']);
												
						$data['feepayments'] = $this->student_model->GetFeePayments($data['user']['id'],$data['user']['qualificationid'],$feepayid);
						
						$this->load->view('header', $data);
						
						$data['stuprofile'] =  $this->student_model->GetStudentProfile($data['user']['id']);
						
						if($feepayid==""){
														
							$this->load->view('student_feepayments_view', $data);
							
						}else{
							
							$data['coursepay'] =  $this->student_model->GetCoursePayment($data['user']['id'],$data['user']['qualificationid'],$feepayid);
							$data['studentcoursepay'] =  $this->student_model->GetCourseStudentPayment($data['user']['id'],$data['user']['qualificationid'],$feepayid);
							
							$data['paydetails'] = $this->student_model->GetPayDetails($data['user']['id'],$refno);
							
							$data['feesmaster'] = $this->student_model->getFeesMaster();
							
							$data['partialpaydetails'] = $this->payment_model->GetPartialPayment($feepayid,$data['user']['id'],$data['feepayments']['courseid'][0]);
							
							$this->load->view('student_feepaydetails_view', $data);
						}
						$this->load->view('footer');
                            
                     }else{
						//If no session, redirect to login page
     					redirect('dashboard', 'refresh');
					}
		}
   		else
   		{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
   		}
		
	}
	
	
	public function onlinepayment(){
		
		if($this->session->userdata('loggedin'))
   		{
                    $session_data = $this->session->userdata('loggedin');
                    $session_id = $session_data['id'];
                    $session_role = $session_data['role'];
                    
                    $data['user'] = $this->login_model->GetUserId();		
		
					if($session_role === 'student') {
						
						$feepayid = $this->input->get('id');
												
						$qid = $this->student_model->GetQualificationID($data['user']['id']);
												
						$data['feepayments'] =  $this->student_model->GetFeePayments($data['user']['id'],$data['user']['qualificationid'],$feepayid);
												
						$this->load->view('header', $data);
						
						if($feepayid!=""){
							
							//$coursepay =  $this->student_model->GetCoursePayment($data['user']['id'],$data['user']['qualificationid']);
							$studentcoursepay =  $this->student_model->GetCourseFeePayment($data['user']['id'],$data['user']['qualificationid'],$feepayid);
							
							//$feesmaster = $this->student_model->getFeesMaster();
							$partialpaydetails = $this->payment_model->GetPartialPayment($feepayid,$data['user']['id'],$data['feepayments']['courseid'][0]);
							
							$userid = $data['user']['id'];
							$courseid = $data['feepayments']['courseid'][0];
							
							$coursename = "";
							$grandtotalnow = 0;
							
							$referenceid = uniqid();
							
							$partialamt = $partialpaydetails['partialamt'];
							$partialstatus = $partialpaydetails['status'];
							$partialbalance = $partialamt;
							
							$feepayquery = false;
							
							//foreach($feesmaster as $key=>$feemaster){

							foreach($studentcoursepay as $stupaylist){
						
									$coursename = $stupaylist['coursename'];
									$center = $stupaylist['centers'];
								
									//$coursename = $coursename ."|".$center;
								
								$amount = $stupaylist['amount'];
								$total = $stupaylist['totalamt'];

								$grandtotalnow += $total;

								$this-> db -> query('update bscp_feepayments set referenceid="'.$referenceid.'" where id="'.$stupaylist['fid'].'" and studentid="'.$stupaylist['studentid'].'"');
								
								if($this->db->affected_rows() > 0){ $feepayquery = true;}
								
								/*if($feemaster['description'] == $stupaylist['description'] && $partialstatus=="a"){

									$amount = $stupaylist['amount'];
									$total = $stupaylist['totalamt'];
									
									if($partialbalance>0 ){
							
										if($partialamt>$total){ 
											$partialamt = $partialamt - $total;
											$partialbalance = $partialamt;
										}
										else{ 
											$total = $partialamt;
											$partialbalance = 0;
										}

										$grandtotalnow += $total;
																	
									}
									
									
									$this-> db -> query('update bscp_feepayments set referenceid="'.$referenceid.'" where id="'.$stupaylist['fid'].'" and studentid="'.$stupaylist['studentid'].'"');
									
									
								}else if($feemaster['description'] == $stupaylist['description'] && $partialstatus==""){
							
							
									$amount = $stupaylist['amount'];
									$total = $stupaylist['totalamt'];

									$grandtotalnow += $total;
									
									$this-> db -> query('update bscp_feepayments set referenceid="'.$referenceid.'" where id="'.$stupaylist['fid'].'" and studentid="'.$stupaylist['studentid'].'"');

								}*/
									

								}
								
							//}
							
							
							if($partialpaydetails['status']=="a"){
								$grandtotalnow = $partialpaydetails['partialamt'];
								$this-> db -> query('update bscp_partialpayments set referenceid="'.$referenceid.'" where requestid="'.$feepayid.'" and studentid="'.$data['user']['id'].'" and courseid="'.$data['feepayments']['courseid'][0].'" and status="a"');
							}
							
							$grandtotalnow = $grandtotalnow*100;
							
							
							if($feepayquery){
								
								$id = uniqid();
								
								date_default_timezone_set('Asia/Kolkata');
								$TrnReqDate = date("Y-m-d H:i:s");
								
								$this-> db -> query('INSERT INTO `bscp_worldlinepg`(`id`, `referenceNo`, `orderid`, `amount`, `statuscode`, `statusdesc`, `rrn`, `authxcode`, `responsecode`, `transactiondatetime`, `studentid`, `courseid`) VALUES ("'.$id.'","","'.$referenceid.'","'.$grandtotalnow.'","F","Processing","","","","'.$TrnReqDate.'","'.$userid.'","'.$courseid.'")');
								
							
							$responseUrl = base_url()."stufeepayments/responsepayment";
							
							include APPPATH.'third_party/worldline/Kit/AWLMEAPI.php';
	
							//create an Object of the above included class
							$obj = new AWLMEAPI();

							//create an object of Request Message
							$reqMsgDTO = new ReqMsgDTO();

							/* Populate the above DTO Object On the Basis Of The Received Values */
							// PG MID
							$reqMsgDTO->setMid($this->config->item('Merchant_ID'));
							// Merchant Unique order id
							$reqMsgDTO->setOrderId($referenceid);
							//Transaction amount in paisa format
							$reqMsgDTO->setTrnAmt($grandtotalnow);
							//Transaction remarks
							$reqMsgDTO->setTrnRemarks($coursename);
							// Merchant transaction type (S/P/R)
							$reqMsgDTO->setMeTransReqType("S");
							// Merchant encryption key
							$reqMsgDTO->setEnckey($this->config->item('Merchant_Key'));
							// Merchant transaction currency
							$reqMsgDTO->setTrnCurrency("INR");
							// Recurring period, if merchant transaction type is R
							$reqMsgDTO->setRecurrPeriod("");
							// Recurring day, if merchant transaction type is R
							$reqMsgDTO->setRecurrDay("");
							// No of recurring, if merchant transaction type is R
							$reqMsgDTO->setNoOfRecurring("");
							// Merchant response URl
							$reqMsgDTO->setResponseUrl($responseUrl);
							
							// Optional additional fields for merchant
							$reqMsgDTO->setAddField1($userid);
							$reqMsgDTO->setAddField2($courseid);
							$reqMsgDTO->setAddField3($feepayid);
							$reqMsgDTO->setAddField4($data['user']['stuid']);
							$reqMsgDTO->setAddField5("");
							$reqMsgDTO->setAddField6("");
							$reqMsgDTO->setAddField7("");
							$reqMsgDTO->setAddField8("");

							/* 
							 * After Making Request Message Send It To Generate Request 
							 * The variable `$urlParameter` contains encrypted request message
							 */
							 //Generate transaction request message
							$merchantRequest = "";

							$reqMsgDTO = $obj->generateTrnReqMsg($reqMsgDTO);

							if ($reqMsgDTO->getStatusDesc() == "Success"){
								$merchantRequest = $reqMsgDTO->getReqMsg();
							}
							
							echo '<!DOCTYPE html>
									<html>
									<head>
									
									<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
									<title>Brilliant Study Centre, Pala</title>
									
									
									<style>
									
									@font-face {font-family: "Segoe UI";src: url("../fonts/segoeui.eot");
									  src: url("../fonts/segoeui.eot?#iefix") format("embedded-opentype"), url("../fonts/segoeui.woff") format("woff"), url("../fonts/segoeui.ttf") format("truetype"), url("../fonts/segoeui.svg#ralewaythin") format("svg");font-weight: 400;font-style: normal;}
									@font-face {font-family: "Segoe UI";src: url("../fonts/segoeuib.eot");
									  src: url("../fonts/segoeuib.eot?#iefix") format("embedded-opentype"), url("../fonts/segoeuib.woff") format("woff"), url("../fonts/segoeuib.ttf") format("truetype"), url("../fonts/segoeuib.svg#ralewaythin") format("svg");font-weight: 700;font-style: normal;}
									@font-face {font-family: "Segoe UI";src: url("../fonts/seguisb.eot");
									  src: url("../fonts/seguisb.eot?#iefix") format("embedded-opentype"), url("../fonts/seguisb.woff") format("woff"), url("../fonts/seguisb.ttf") format("truetype"), url("../fonts/seguisb.svg#ralewaythin") format("svg");font-weight: 600;font-style: normal;}
									
										html,body{background: #ffffff;}
										h4{font-family: "Segoe UI";;font-size:1.15rem;font-weight:bold;color: #222B39;}
									
									</style>
									
									</head>
									
									<body>
									
									<form action="https://ipg.in.worldline.com/doMEPayRequest" method="post" name="txnSubmitFrm">
								<h4 align="center">Redirecting To Payment Please Wait...</h4>
								<img src="'.base_url().'images/loader.gif" alt="" style="display:block;margin:auto" /> 
								<h4 align="center">Please Do Not Press Back Button OR Refresh Page</h4>
								<input type="hidden" size="200" name="merchantRequest" id="merchantRequest" value="'.$merchantRequest.'"  />
								<input type="hidden" name="MID" id="MID" value="'.$reqMsgDTO->getMid().'"/>
							</form>
							<script  type="text/javascript">
								//submit the form to the worldline
								document.txnSubmitFrm.submit();
							</script>
							</body>
							</html>';
							exit;
								
							}else{
								redirect('stufeepayments?id='.$feepayid, 'refresh');
							}
							
						}else{
							
							redirect('stufeepayments', 'refresh');
						}
                            
                     }else{
						//If no session, redirect to login page
     					redirect('dashboard', 'refresh');
					}
		}
   		else
   		{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
   		}
		
	}
	
	
	
	public function responsepayment(){
		
		/*if($this->session->userdata('loggedin'))
   		{
			$session_data = $this->session->userdata('loggedin');
			$session_id = $session_data['id'];
			$session_role = $session_data['role'];

			$data['user'] = $this->login_model->GetUserId();		

			//$feepayid = $this->input->get('id');
			
			if($session_role === 'student') {*/

					/**
					 * This Is the Kit File To Be included For Transaction Request/Response
					 */
					include APPPATH.'third_party/worldline/Kit/AWLMEAPI.php';

					//create an Object of the above included class
					$obj = new AWLMEAPI();

					// This is the response Object 
					$resMsgDTO = new ResMsgDTO();

					// This is the request Object 
					$reqMsgDTO = new ReqMsgDTO();

					//This is the Merchant Key that is used for decryption also
					$enc_key = $this->config->item('Merchant_Key');

					// Get the Response from the WorldLine
					$responseMerchant = $_REQUEST['merchantResponse'];

					$response = $obj->parseTrnResMsg( $responseMerchant , $enc_key );

					$RefNo = $response->getPgMeTrnRefNo();
					$OrderId = $response->getOrderId();
					$TrnAmt = $response->getTrnAmt();
					$StatusCode = $response->getStatusCode();
					$StatusDesc = $response->getStatusDesc();
					$TrnReqDate = $response->getTrnReqDate();
					$ResponseCode = $response->getResponseCode();
					$Rrn = $response->getRrn();
					$AuthZCode = $response->getAuthZCode();
		
					$userid = $response->getAddField1();
					$courseid = $response->getAddField2();
					$requestid = $response->getAddField3();

					$paystatus = $this->student_model->UpdateOnlineFeePayment($userid,$RefNo,$OrderId,$TrnAmt,$StatusCode,$StatusDesc,$TrnReqDate,$ResponseCode,$Rrn,$AuthZCode,$courseid,$requestid);
		
					// Test Code Don't change 
		
					/*$StatusCode = "S";$OrderId = "606eed62277d9";
					$paystatus = $this->student_model->UpdateOnlineFeePayment('','12213124','606eed62277d9',100000,'S','Transaction authorised successfully ','2021-04-08 17:06:06','00','000000011221','001200');*/

					//print_r($response);exit;
				
					if($paystatus[0]=="success"){
						redirect('stufeepayments?id='.$paystatus[1].'&status='.$StatusCode.'&refno='.$OrderId, 'refresh');
					}else{
						redirect('stufeepayments?id='.$paystatus[1].'&status='.$StatusCode.'&refno='.$OrderId, 'refresh');
					}
						
					exit;
			/*}else{
				//If no session, redirect to login page
				redirect('dashboard', 'refresh');
			}
			
		}else
   		{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
   		}*/
		
	}
	
	
	// Upload Profile Picture
	
	public function uploadHallticketPhoto() {
		
		if($this->session->userdata('loggedin')) {
			
			$session_data = $this->session->userdata('loggedin');
			$session_id = $session_data['id'];
			$session_role = $session_data['role'];

			$data['user'] = $this->login_model->GetUserId();
			
			//$post = isset($_POST) ? $_POST: array();
			$maxWidth = "350"; 
			$requestid = $this->input->post('requestid', true);
			$studentid = $this->input->post('studentid', true);
			$courseid = $this->input->post('courseid', true);
			$center = $this->input->post('center', true);
			
			$path = 'docs/screentest/'.$courseid.'/'.$center.'/';
			$validFormats = array("jpg", "png", "jpeg");
			$picName = $_FILES['profileImage']['name'];
			$size = $_FILES['profileImage']['size'];
			if(strlen($picName)) {
				list($txt, $ext) = explode(".", $picName);
				$ext = strtolower($ext);
				if(in_array($ext,$validFormats)) {
					if($size<(1024*1024)) {
						
						if(!is_dir($path)) mkdir($path,0777, TRUE);
						
						$actualImageName = $studentid.'_tmp.'.$ext;
						$filePath = $path.$actualImageName;
						$tmp = $_FILES['profileImage']['tmp_name'];
						if(move_uploaded_file($tmp, $filePath)) {
							$width = $this->getWidth($filePath);
							$height = $this->getHeight($filePath);						
							if ($width > $maxWidth){
								$scale = $maxWidth/$width;
								$uploaded = $this->resizeImage($filePath,$width,$height,$scale, $ext);
							} else {
								$scale = 1;
								$uploaded = $this->resizeImage($filePath,$width,$height,$scale, $ext);
							}
							
							//$result = $this->student_model->UpdateHallticketPhoto($requestid,$studentid,$actualImageName);
							
							if(file_exists($filePath)){
								echo "<img id='photo' file-name='".$actualImageName."' src='".$filePath.'?'.time()."' class='preview mw-100'/>";
							}
							else{ echo "<p class='alert alert-danger mt-4'>Upload failed</p>";}
						}
						else
						echo "<p class='alert alert-danger mt-4'>Upload failed</p>";
					}
					else
					echo "<p class='alert alert-danger mt-4'>Image file size max 1 MB</p>"; 
				}
				else
				echo "<p class='alert alert-danger mt-4'>Invalid file format accepts only JPG, PNG, JPEG</p>"; 
			}
			else
			echo "<p class='alert alert-danger mt-4'>Please select image..!</p>";
			exit;
			
		}else {
			//If no session, redirect to login page
			redirect('login', 'refresh');
		}
		
	}
	
	/* Function to update image */
public function uploadCropHallticketPhoto() {
	
	
	if($this->session->userdata('loggedin')) {
			
		$session_data = $this->session->userdata('loggedin');
		$session_id = $session_data['id'];
		$session_role = $session_data['role'];

		$data['user'] = $this->login_model->GetUserId();

		$requestid = $this->input->post('requestid', true);
		$studentid = $this->input->post('studentid', true);
		$courseid = $this->input->post('courseid', true);
		$center = $this->input->post('center', true);

		$t_width = 300; // Maximum thumbnail width
		$t_height = 300;    // Maximum thumbnail height	
		if(isset($_POST['action']) and $_POST['action'] == "crop") {
			extract($_POST);
			
			list($txt, $ext) = explode(".", $_POST['imageName']);
			$ext = strtolower($ext);
			
			$photohttmp = $studentid.'_tmp.'.$ext;
			$photoht = $studentid.'.'.$ext;
			
			$imgPath = 'docs/screentest/'.$courseid.'/'.$center.'/';
			
			$imagePath = $imgPath.$photohttmp;			
			$imagecropPath = $imgPath.$photoht;
			
			if(!file_exists($imagePath)){
				$imagePath = $imagecropPath;
			}
			
			$ratio = ($t_width/$w); 
			$nw = ceil($w * $ratio);
			$nh = ceil($h * $ratio);
			$nimg = imagecreatetruecolor($w,$h);
			$im_src = imagecreatefromjpeg($imagePath);
			imagecopyresampled($nimg,$im_src,0,0,$x,$y,$w,$h,$w,$h);
			
			switch ($ext) {
				case 'jpg':
				case 'jpeg':
					//$source = imagecreatefromjpeg($imagePath);
					imagejpeg($nimg,$imagecropPath,90);
					break;
				case 'png':
					//$source = imagecreatefrompng($imagePath);
					imagepng($nimg,$imagecropPath);
					break;
				default:
					//$source = false;
					imagejpeg($nimg,$imagecropPath,90);
					break;
			}
			
		}
		
		$result = $this->student_model->UpdateHallticketPhoto($requestid,$studentid,$photohttmp,$photoht,$imgPath);
		
		if($result){
			echo $imagecropPath.'?'.time();
			exit(0);
		}
		
		echo "";
		exit(0);
		
}else {
	//If no session, redirect to login page
	redirect('login', 'refresh');
}
	
}  
	
	
public function downloadHallticket() {
	
	
	if($this->session->userdata('loggedin')) {
			
		$session_data = $this->session->userdata('loggedin');
		$session_id = $session_data['id'];
		$session_role = $session_data['role'];

		if($session_role === 'student') {
			
			$data['user'] = $this->login_model->GetUserId();
			
		}else{
		
			$userid = $this->input->get('userid');
			$data['user'] = $this->login_model->GetUserDetails($userid);
		
		}
		
		$requestid = $this->input->get('crid', true);
		$type = $this->input->get('type', true);
		$studentid = $data['user']['id'];
		
		$coursepay =  $this->student_model->GetCoursePayment($data['user']['id'],'',$requestid);
		$stuprofile =  $this->student_model->GetStudentProfile($data['user']['id']);
		
		$center = $coursepay[0]['center'];
		$scenter = $coursepay[0]['scenter'];
		
		$centerdetails =  $this->student_model->GetScreentestCenterDetails($scenter,$center);
		
		//print_r($stuprofile);exit;
		
		//$feepayments = $this->student_model->GetFeePayments($data['user']['id'],'',$requestid);
		
		$courseid = $coursepay[0]['courseid'];
		$photocopy_ht = $coursepay[0]['photocopy_ht'];
		
		$coursename = $coursepay[0]['coursename'];
		$roll_number = $coursepay[0]['roll_number'];
		$stuid = $data['user']['stuid'];
		$stuname = $data['user']['pname'];
		$dob = date("d M Y",strtotime($stuprofile['dob']));
		$classstudy = $stuprofile['classstudy'];
		$mobile = $stuprofile['smobile'];
		$email = $stuprofile['semail'];
		
		$examtime = $coursepay[0]['examtime'];
		$reportingtime = $coursepay[0]['reportingtime'];
		$cooloftime = $coursepay[0]['cooloftime'];
		$modeofexam = $coursepay[0]['modeofexam'];
		$duration = $coursepay[0]['duration'];
		
		
		$saddress1 = $centerdetails['address1'];
		$saddress2 = $centerdetails['address2'];
		$sarea = $centerdetails['area'];
		$spincode = $centerdetails['pincode'];
		$coname = $centerdetails['coname'];
		$cophone = $centerdetails['cophone'];
                
		$testcenter = "";
			
		if($saddress1 !="") { $saddress1= ", ".$saddress1;}
		if($saddress2 !="") { $saddress2= ", ".$saddress2;}
		if($sarea !="") { $sarea= ", ".$sarea;}
		if(($center !="")&&($sarea !="")) { $testcenter= ", ".$center;}
		if($spincode !="") { $spincode= ", ".$spincode;}
                
		
		$testcentreaddress = $scenter.$saddress1.$saddress2.$sarea.$testcenter.$spincode.".";		
		
		$guardianname = "";
		if($stuprofile['fathername']!="" && $stuprofile['fathername']!="0") $guardianname = $stuprofile['fathername'];
		else if($stuprofile['guardianname']!="" && $stuprofile['guardianname']!="0") $guardianname = $stuprofile['guardianname'];
		
		$fulladdress = "";
		$fulladdress .= $stuprofile['housenameno'].", ";
		$fulladdress .= $stuprofile['contactaddress'].", ";
		
		if($stuprofile['contactaddress']!="" && $stuprofile['contactaddress']!="0") $fulladdress .= $stuprofile['landmark'].", ";
		
		$fulladdress .= $stuprofile['contactdistrict'].", ";
		$fulladdress .= $stuprofile['contactstate'].", ";
		$fulladdress .= $stuprofile['contactpost'].", ";
		$fulladdress .= $stuprofile['contactcountry']." - ";
		$fulladdress .= $stuprofile['contactpincode'].".";
		
		$starton = date('d-M-Y h:i A',strtotime($coursepay[0]['starts_on']));
		$endon = date('d-M-Y h:i A',strtotime($coursepay[0]['ends_on']));
		
		$examdate = date('d-M-Y, l',strtotime($coursepay[0]['commenceson']));
		
		$reportingtime = date('d-M-Y h:i A',strtotime($reportingtime));
		
		require_once(FCPATH.'/fpdf/fpdf.php');
		require_once(FCPATH.'/FPDI/src/autoload.php');
		
		// initiate FPDI
		$pdf = new Fpdi\Fpdi();

		// get the page count
		$pageCount = $pdf->setSourceFile(FCPATH.'/docs/screentest/hallticket.pdf');
		// iterate through all pages
		for ($pageNo = 1; $pageNo <= $pageCount; $pageNo++) {
			// import a page
			$templateId = $pdf->importPage($pageNo);

			$pdf->AddFont('segoeuib','','segoeuib.php');

			$pdf->AddPage();
			// use the imported page and adjust the page size
			$pdf->useTemplate($templateId, ['adjustPageSize' => true]);

			/*$pdf->SetFont('segoeuib','','15');
			$pdf->SetTextColor('58' ,'58' ,'58');
			
			
			$pdf->SetXY(10, 56);
			$pdf->MultiCell(260, 7, "Hall Ticket - ".$coursename, 0, 'C', false);*/
			
			/*$pdf->AddFont('seguisb','','seguisb.php');
			$pdf->SetFont('seguisb','','14');*/
			
			// Examination Details
			
			$pdf->AddFont('segoeui','','segoeui.php');
			$pdf->SetFont('segoeui','','14');
			
			$pdf->SetXY(64, 86.5);
			$pdf->MultiCell(140, 6, $coursename, 0, 'L', false);
			
			/*$pdf->AddFont('segoeuib','','segoeuib.php');
			$pdf->SetFont('segoeuib','','14');*/
			
			$pdf->SetXY(64, 98);
			$pdf->MultiCell(140, 6, $examdate, 0, 'L', false);
			
			$pdf->SetXY(154, 98);
			$pdf->MultiCell(140, 6, $examtime, 0, 'L', false);
			
			$pdf->AddFont('segoeui','','segoeui.php');
			$pdf->SetFont('segoeui','','14');
			
			$pdf->SetXY(64, 110);
			$pdf->MultiCell(140, 6, $reportingtime, 0, 'L', false);
			
			$pdf->SetXY(155, 110);
			$pdf->MultiCell(140, 6, $cooloftime." Minutes", 0, 'L', false);
			
			$pdf->SetXY(64, 121);
			$pdf->MultiCell(140, 6, $duration, 0, 'L', false);
			
			$pdf->SetXY(159, 121);
			$pdf->MultiCell(140, 6, $modeofexam, 0, 'L', false);
			
			// Centre Details
			
			$pdf->SetXY(64, 149);
			$pdf->MultiCell(180, 6, $testcentreaddress, 0, 'L', false);
			
			$pdf->SetXY(64, 162);
			$pdf->MultiCell(62, 5, $coname, 0, 'L', false);
			
			$pdf->SetXY(162, 162);
			$pdf->MultiCell(110, 6, $cophone, 0, 'L', false);
			
			// Student Details
				
			/*$pdf->AddFont('segoeuib','','segoeuib.php');
			$pdf->SetFont('segoeuib','','14');*/
			
			$pdf->SetXY(64, 190);
			$pdf->MultiCell(140, 6, $roll_number, 0, 'L', false);
			
			$pdf->AddFont('segoeui','','segoeui.php');
			$pdf->SetFont('segoeui','','14');
			
			$pdf->SetXY(64, 201.5);
			$pdf->MultiCell(140, 6, $stuid, 0, 'L', false);
			
			$pdf->SetXY(64, 212.5);
			$pdf->MultiCell(140, 6, $stuname, 0, 'L', false);
			
			$pdf->SetXY(64, 225);
			$pdf->MultiCell(60, 4.5, $email, 0, 'L', false);
			
			$pdf->SetXY(155, 224.5);
			$pdf->MultiCell(140, 6, $dob, 0, 'L', false);
						
			$pdf->SetXY(64, 236.5);
			$pdf->MultiCell(140, 6, $mobile, 0, 'L', false);
			
			$pdf->SetXY(178.5, 236);
			$pdf->MultiCell(140, 6, $guardianname, 0, 'L', false);
			
			$pdf->SetXY(64, 249);
			$pdf->MultiCell(140, 6, $fulladdress, 0, 'L', false);
			
			//$pdf->SetXY(64, 261);
			//$pdf->MultiCell(140, 6, $classstudy, 0, 'L', false);
			
			
			/*$pdf->SetXY(20, -142);
			$pdf->MultiCell(62, 5, $center, 0, 'L', false);
			
			$pdf->SetXY(83, -142);
			$pdf->MultiCell(62, 5, "General", 0, 'L', false);
			
			$pdf->SetXY(146, -142);
			$pdf->MultiCell(65, 5, $starton, 0, 'L', false);
			
			$pdf->SetXY(209, -142);
			$pdf->MultiCell(65, 5, $endon, 0, 'L', false);*/
			
			
			$photo_ht = 'docs/screentest/'.$courseid.'/'.$center.'/'.$photocopy_ht;
			if(file_exists($photo_ht)) $pdf->Image($photo_ht, 211, 74, 60);
						
			//$pdf->Write(8, 'Hall Ticket');
		}
		
		$mergefile = 'docs/screentest/'.$courseid.'/'.$center.'/screeningtest.pdf'; 
		
		if(file_exists($mergefile)){
		
			$mergepageCount = $pdf->setSourceFile($mergefile);
			for ($mi = 0; $mi < $mergepageCount; $mi++) {
				$tpl = $pdf->importPage($mi + 1);
				$pdf->addPage();
				$pdf->useTemplate($tpl, ['adjustPageSize' => true]);
			}
			
		}
		
		if($type!="preview"){
			
			$result = $this->student_model->UpdateDownloadHallticket($requestid,$studentid);
			
		}else{
			$result = true;
		}
		

		if($result){
			// Output the new PDF
			//I, D, F, S
			
			if($type!="preview") $pdfoutput = "D"; else  $pdfoutput = "I";
	
			$pdf->Output($pdfoutput,"Hallticket_".$stuid.".pdf"); 
		}
		
				
	}else {
		//If no session, redirect to login page
		redirect('login', 'refresh');
	}
	
	
}  
	
	
	/* Function  to resize image */
function resizeImage($image,$width,$height,$scale, $ext) {
	$newImageWidth = ceil($width * $scale);
	$newImageHeight = ceil($height * $scale);
	$newImage = imagecreatetruecolor($newImageWidth,$newImageHeight);
	switch ($ext) {
        case 'jpg':
        case 'jpeg':
            $source = imagecreatefromjpeg($image);
            break;
        case 'gif':
            $source = imagecreatefromgif($image);
            break;
        case 'png':
            $source = imagecreatefrompng($image);
            break;
        default:
            $source = false;
            break;
    }	
	imagecopyresampled($newImage,$source,0,0,0,0,$newImageWidth,$newImageHeight,$width,$height);
	imagejpeg($newImage,$image,90);
	chmod($image, 0777);
	return $image;
}
/*  Function to get image height. */
function getHeight($image) {
    $sizes = getimagesize($image);
    $height = $sizes[1];
    return $height;
}
/* Function to get image width */
function getWidth($image) {
    $sizes = getimagesize($image);
    $width = $sizes[0];
    return $width;
}
	
	
}
?>

<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Center extends CI_Controller {

	function __construct() {
            
		parent::__construct();
		$this->load->model('course_model','',TRUE);
                $this->load->model('login_model','',TRUE);
                 $this->load->library('table'); $this->load->helper('form');

	}
	
	function index() {
            
            if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')) {

                $session_data = $this->session->userdata('loggedin');
                $session_id = $session_data['id'];
                $session_role = $session_data['role'];
                $data['user'] = $this->login_model->GetUserId();


				$data['roleaccess'] = $this->config->item('roleaccess');

				if($data['roleaccess']['uview']!="y"){
					redirect($data['roleaccess']['defaultpage'], 'refresh');
				}
				
                $data['menu'] = $this->load->view('headermenu', $data, TRUE);
                
                $tmpl = array('table_open' => '<table class="sortable sorting disabled" id="locationtable" style="margin-top:0px;">');
                $this->table->set_template($tmpl);
                $this->table->set_heading('S.NO', 'CENTER NAME','CITY NAME','ADDRESS 1','ADDRESS 2','AREA NAME','PINCODE','ROLL NO STARTS','NO OF SEATS','CO-NAME','CO-PHONE','GURL','ACTIONS');
                
              
                $data['cities'] = $this->course_model->GetAllCities("");
                $this->load->view('header_view', $data);
                $this->load->view('centers_view', $data);
                $this->load->view('footer_view');
                
            } else {
                //If no session, redirect to login page
                redirect('login', 'refresh');
            }
            
        }
        
        
       
          public function GetCenters() {
            
            if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in') ){
                
                $ret =  $this->course_model->GetCenters();
                echo $ret;
                
            }else{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
            }
            
        }
        
        
       public function centerSubmit() {
            
        if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')) {
                $this->load->library('form_validation');
			
			$roleaccess = $this->config->item('roleaccess');
			
			if(isset($roleaccess['Centers'][0]) && $roleaccess['Centers'][0]=="y"){
				
                $ide = isset($_POST['eide']) ? $_POST['eide'] : '';
                $validatation["cname"] = "trim|required|xss_clean|callback_alpha_numeric_spaces|max_length[100]";
                $validatation["city"] = "trim|required|xss_clean|callback_alpha_numeric_spaces|max_length[100]";
                $validatation["address1"] = "trim|xss_clean|callback_alpha_numeric_spaces|max_length[100]";
                $validatation["address2"] = "trim|xss_clean|callback_alpha_numeric_spaces|max_length[100]";
                $validatation["aname"] = "trim|xss_clean|callback_alpha_numeric_spaces|max_length[100]";
                $validatation["pincode"] = "trim|xss_clean|callback_alpha_numeric_spaces|max_length[10]";
                $validatation["gurl"] = "trim|xss_clean|callback_alpha_numeric_spaces|max_length[100]";
                $validatation["coname"] = "trim|required|xss_clean|callback_alpha_numeric_spaces|max_length[100]";
                $validatation["cophone"] = "trim|required|xss_clean|callback_alpha_numeric_spaces|max_length[100]";
                $validatation["rollnostarts"] = "trim|xss_clean|callback_alpha_numeric_spaces|max_length[10]";
                $validatation["rollnoends"] = "trim|xss_clean|callback_alpha_numeric_spaces|max_length[10]";
               


                    foreach ($validatation as $key=>$val) {
                        $this->form_validation->set_rules($key, $key, $val);
                    }


                if ($this->form_validation->run() == false) {
                        $response = array(
                            'status' => 'error',
                            'message' => validation_errors()
                        );
                        echo json_encode($response);

                } else {


                     if($ide === "") {
                     $response = $this->insertQ();
                         } else {
                             $response = $this->updateQ($ide);
                         }
                     echo  json_encode($response);
                }
				
			 } else {

 					$response = array(
                            'status' => 'error',
                            'message' => 'User Permission Denied'
                        );
                        echo json_encode($response);
                }
              
               
            }else{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
            }
            
    }
    
        
    public function insertQ(){
        
		$roleaccess = $this->config->item('roleaccess');
			
			if(isset($roleaccess['Centers'][0]) && $roleaccess['Centers'][0]=="y"){
				
        $ide = uniqid();
            $qData = array(
                'id' => $ide,
                'name' => $this->input->post('cname', true),
                'cityname' => $this->input->post('city', true),
                'address1' => $this->input->post('address1', true),
                'address2' => $this->input->post('address2', true),
                'area' => $this->input->post('aname', true),
                'pincode' => $this->input->post('pincode', true),
                'gurl' => $this->input->post('gurl', true),
                 'rollnostarts' => $this->input->post('rollnostarts', true),
                'rollnoends' => $this->input->post('rollnoends', true),
                'coname ' => $this->input->post('coname', true),
                'cophone ' => $this->input->post('cophone', true),              
                'created_at' => date('Y-m-d H:i:s')
            );
                       

            $id = $this->course_model->InsertCenter($qData);
                       
            $response = array(
                'status' => 'success',
                'message' => "Center Created Successfully."
            );
				
		 } else {

 					$response = array(
                            'status' => 'error',
                            'message' => 'User Permission Denied'
                        );
                        echo json_encode($response);
                }

          return $response;
    }
    
       public function updateQ($ide){
        
		   $roleaccess = $this->config->item('roleaccess');
			
			if(isset($roleaccess['Centers'][1]) && $roleaccess['Centers'][1]=="y"){
				
            $qData = array(
                'id' => $ide,
                'name' => $this->input->post('cname', true),
                'cityname' => $this->input->post('city', true),
                'address1' => $this->input->post('address1', true),
                'address2' => $this->input->post('address2', true),
                'area' => $this->input->post('aname', true),
                'pincode' => $this->input->post('pincode', true),
                'gurl' => $this->input->post('gurl', true),
                 'rollnostarts' => $this->input->post('rollnostarts', true),
                'rollnoends' => $this->input->post('rollnoends', true),
                'coname ' => $this->input->post('coname', true),
                'cophone ' => $this->input->post('cophone', true),              
                'created_at' => date('Y-m-d H:i:s')
            );
                       

            $id = $this->course_model->UpdateCenter($qData);
                       
            $response = array(
                'status' => 'success',
                'message' => "Center Updated Successfully."
            );
				
		 } else {

			$response = array(
					'status' => 'error',
					'message' => 'User Permission Denied'
				);
				echo json_encode($response);
		}

          return $response;
    }
        
        public function DelCenter() {
            
            if ($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')) {

				
			$roleaccess = $this->config->item('roleaccess');
			
			if(isset($roleaccess['Centers'][2]) && $roleaccess['Centers'][2]=="y"){
				
                $ide = isset($_GET['ide']) ? $_GET['ide'] : '';

                if($ide != ""){
                     $ret = $this->course_model->DelCenters($ide);
                } else {
                    $ret = array(0 => "fail");
                }

                echo json_encode($ret);
				
			} else {
				$ret = array(0 => "fail");
				echo json_encode($ret);
			}
            
            }else {
                //If no session, redirect to login page
                redirect('login', 'refresh');
            }
                
        }
        

}
?>
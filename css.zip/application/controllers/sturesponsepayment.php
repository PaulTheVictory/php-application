<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Sturesponsepayment extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model('login_model','',TRUE);
		$this->load->model('course_model','',TRUE);
		$this->load->model('student_model','',TRUE);
		$this->load->library('table'); 

	}
	
	function index()
	{
		
		if($this->session->userdata('loggedin'))
   		{
			$session_data = $this->session->userdata('loggedin');
			$session_id = $session_data['id'];
			$session_role = $session_data['role'];

			$data['user'] = $this->login_model->GetUserId();		

			$feepayid = $this->input->get('id');
			
			if($session_role === 'student') {

					/**
					 * This Is the Kit File To Be included For Transaction Request/Response
					 */
					include APPPATH.'third_party/worldline/Kit/AWLMEAPI.php';

					//create an Object of the above included class
					$obj = new AWLMEAPI();

					/* This is the response Object */
					$resMsgDTO = new ResMsgDTO();

					/* This is the request Object */
					$reqMsgDTO = new ReqMsgDTO();

					//This is the Merchant Key that is used for decryption also
					$enc_key = $this->config->item('Merchant_Key');

					/* Get the Response from the WorldLine */
					$responseMerchant = $_REQUEST['merchantResponse'];

					$response = $obj->parseTrnResMsg( $responseMerchant , $enc_key );

					$RefNo = $response->getPgMeTrnRefNo();
					$OrderId = $response->getOrderId();
					$TrnAmt = $response->getTrnAmt();
					$StatusCode = $response->getStatusCode();
					$StatusDesc = $response->getStatusDesc();
					$TrnReqDate = $response->getTrnReqDate();
					$ResponseCode = $response->getResponseCode();
					$Rrn = $response->getRrn();
					$AuthZCode = $response->getAuthZCode();

					$paystatus = $this->student_model->UpdateOnlineFeePayment($data['user']['id'],$RefNo,$OrderId,$TrnAmt,$StatusCode,$StatusDesc,$TrnReqDate,$ResponseCode,$Rrn,$AuthZCode);

					//print_r($paystatus);exit;
				
					if($paystatus==="success"){
						redirect('stufeepayments?id='.$feepayid.'&status='.$StatusCode.'&refno='.$OrderId, 'refresh');
					}else{
						redirect('stufeepayments?id='.$feepayid.'&status='.$StatusCode.'&refno='.$OrderId, 'refresh');
					}
						

			}else{
				//If no session, redirect to login page
				redirect('dashboard', 'refresh');
			}
			
		}else
   		{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
   		}
		
		
	}
	
}
?>

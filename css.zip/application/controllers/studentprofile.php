<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

use Dompdf\Dompdf;

class Studentprofile extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model('login_model','',TRUE);
                $this->load->model('course_model','',TRUE);
				$this->load->model('student_model','',TRUE);
		$this->load->model('qualification_model','',TRUE);
		$this->load->model('exams_model','',TRUE);
		$this->load->model('payment_model','',TRUE);
                 $this->load->library('table'); 

				
	}
	
	function index()
	{
		if($this->session->userdata('loggedin'))
   		{
                    $session_data = $this->session->userdata('loggedin');
                    $session_id = $session_data['id'];
                    $session_role = $session_data['role'];
                    
                    $data['user'] = $this->login_model->GetUserId();	
			
					$data['roleaccess'] = $this->config->item('roleaccess');
			
					if($data['roleaccess']['uview']!="y"){
						redirect($data['roleaccess']['defaultpage'], 'refresh');
					}
		
					//if(($session_role === 'admin')||($session_role === 'teacher')) {
						
						//$data['action'] = $this->input->get('action');
						
                        $sid = $this->input->get('sid');
						$data['sid'] = $sid;
						 												
						$qid = $this->student_model->GetQualificationID($sid);
						$data['qid'] = $qid;
						//$data['qualification'] = $this->qualification_model->GetAllQualifications('');
						
						$data['qualification'] = $this->student_model->ViewStudentQualification($sid,$qid);
						
						$data['countrylist'] = $this->student_model->getCountryList();
						$data['statelist'] = $this->student_model->GetStateList();
						
						$data['stuprofile'] =  $this->student_model->GetStudentProfile($sid);
						
						$data['coursepay'] =  $this->student_model->GetCoursePayment($sid,$data['stuprofile']['qualification']);
						//$data['studentcoursepay'] =  $this->student_model->GetCourseStudentPayment($sid,$data['stuprofile']['qualification'],$cride);
						
						$data['menu'] = $this->load->view('headermenu', $data, TRUE);	
						$this->load->view('header_view', $data);
						
						/*if($data['action']=="profileedit" || $data['action']=="register"){
							$this->load->view('stu_profiledit_view', $data);
						}else{*/
							$data['qualname'] = $this->student_model->GetQualificationname($data['stuprofile']['medium']);
						
							$data['feepayments'] = $this->student_model->GetAllFeePayments($sid,'','');
						
						
							$data['results'] = $this->exams_model->GetStudentResult($sid);
						
							$data['courseoptions'] = $this->student_model->GetAllCourseSPOptions($sid);
						
							$data['allpartialpaydetails'] = $this->payment_model->GetAllPartialPayment($sid);
												
						
							$this->load->view('stu_profile_view', $data);
						//}
						
						$this->load->view('footer_view');
                            
                    /* }else{
						//If no session, redirect to login page
     					redirect('dashboard', 'refresh');
					}*/
		}
   		else
   		{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
   		}
		
	}
	
	
	public function myprofileSubmit() {
          
        if($this->session->userdata('loggedin')) {
			
			$session_data = $this->session->userdata('loggedin');
			$session_id = $session_data['id'];
			$session_role = $session_data['role'];

			$data['user'] = $this->login_model->GetUserId();
			
			$sid = $this->input->post('sid');
			
			$roleaccess = $this->config->item('roleaccess');
			
			if($roleaccess['uedit'] === 'y') {
			
			//print_r($_FILES);print_r($_POST);exit;
			
        	$checkmyprofile = $this->student_model->CheckMyprofile($sid);
			
			$data['stuprofile'] =  $this->student_model->GetStudentProfile($sid);
			
			if($this->input->post('profilepercent', true)>$data['stuprofile']['profilepercent'])
			{
				$profilepercent = $this->input->post('profilepercent', true);
			}else{
				$profilepercent = $data['stuprofile']['profilepercent'];
			}
			  
            $id = uniqid();
			
			$dob = $this->input->post('mpdob', true);
			$dob = date("Y-m-d",strtotime($dob));
			
			$pincode = $this->input->post('mppincode', true);
			$contactpincode = $this->input->post('mpcontactpincode', true);
			
			if($pincode=="") $pincode = 0;
			if($contactpincode=="") $contactpincode = 0;
			
			$comments = $this->input->post('comments', true);
			if(trim($comments)=="") $comments = " ";
			
            $mpData = array(
                'stuid' => $sid,
                'name' => $this->input->post('mpname', true),
				'mcode' => $this->input->post('mpmcode', true),
				'mobile' => $this->input->post('mpmobile', true),
				'email' => $this->input->post('mpemail', true),
                'gender' => $this->input->post('mpgender', true),
                'dob' => $dob,
                'fathername' => $this->input->post('mpfathername', true),
                'fatheroccupation' => $this->input->post('mpfatheroccupation', true),
                'fatheremail' => $this->input->post('mpfatheremail', true),
                'fathercode' => $this->input->post('mpfathercode', true),
                'fatherphone' => $this->input->post('mpfathermobile', true),
                'mothername' => $this->input->post('mpmothername', true),
                'motheroccupation' => $this->input->post('mpmotheroccupation', true),
                'motheremail' => $this->input->post('mpmotheremail', true),
                'mothercode' => $this->input->post('mpmothercode', true),
                'motherphone' => $this->input->post('mpmothermobile', true),
                'communicationcontact' => $this->input->post('mpcomcontact', true),
                'nationality' => $this->input->post('mpnationality', true),
                'category' => $this->input->post('mpcategory', true),
                'bloodgroup' => $this->input->post('mpbloodgroup', true),
                'classstudy' => $this->input->post('mpclassstudy', true),
                'stream' => $this->input->post('mpstream', true),
                'schoolcollegename' => $this->input->post('mpcollegename', true),
                'eduaddress' => $this->input->post('mpaddressline', true),
                'edulandmark' => $this->input->post('mplandmark', true),
                'edudistrict' => $this->input->post('mpdistrict', true),
                'edustate' => $this->input->post('mpstate', true),
                'edupost' => $this->input->post('mppost', true),
                'edupincode' => $pincode,
                'educountry' => $this->input->post('mpcountry', true),
                'examboard' => $this->input->post('mpexamboard', true),
                'examclass' => $this->input->post('mpexamclass', true),
                'gradepercent' => $this->input->post('mpgradepercent', true),
                'preferredsubject' => $this->input->post('mpprefersubject', true),
                'eligiblescholar' => $this->input->post('mpscholarship', true),
                'medium' => $this->input->post('mpmedium', true),
                'mocktype' => $this->input->post('mpmocktype', true),
                'rollno' => $this->input->post('mprollno', true),
                'housenameno' => $this->input->post('mpcontacthouseno', true),
                'landmark' => $this->input->post('mpcontactlandmark', true),
                'contactaddress' => $this->input->post('mpcontactaddressline', true),
                'contactcountry' => $this->input->post('mpcontactcountry', true),
                'contactstate ' => $this->input->post('mpcontactstate', true),
                'contactdistrict' => $this->input->post('mpcontactdistrict', true),
                'contactpost' => $this->input->post('mpcontactpost', true),
                'contactpincode' => $contactpincode,
				'guardianname' => $this->input->post('mpguardianname', true),
                'wacode' => $this->input->post('mpwacode', true),
                'whatsappno' => $this->input->post('mpwhatsappno', true),
                'accountholdername' => $this->input->post('mpaccholdername', true),
                'bankname' => $this->input->post('mpbankname', true),
                'branch' => $this->input->post('mpbranch', true),
                'ifsccode' => $this->input->post('mpifsccode', true),
                'bankaccountno' => $this->input->post('mpaccountnumber', true),
                'aadharnumber' => $this->input->post('mpaadharnumber', true),
                'profilepercent' => $profilepercent,
                'status' => 'a',
                'comments' => $comments
            );
            
			$marksheets = array();
			
			if(isset($_FILES["file"]) && !empty($_FILES["file"]['name'])){
				
				$total = count($_FILES['file']['name']);
				
				$validExtensions = array('.pdf', '.doc', '.docx');
				$imageExtensions = array('.jpg', '.jpeg', '.png', '.pdf');
				
				for( $i=0 ; $i < $total ; $i++ ) {
			
				$file_size = $_FILES['file']['size'][$i];
			
				if ((number_format($file_size / 1048576, 2) > 1)){      
					$ret = array('status'=>'ularge');
					echo json_encode($ret);
					exit(0);
				}
					
				}
				
				$dirname = FCPATH.'docs/marksheets/'.$sid.'/';
				
				for( $i=0 ; $i < $total ; $i++ ) {
				
				$fileExtension = strrchr($_FILES['file']['name'][$i], ".");
				$fileName = "marksheet".($i+1).$fileExtension;
					
				$marksheets[$i] = $fileName;	
				
				$destinationfull = $dirname . $fileName;
					
				if(!file_exists($dirname)) mkdir($dirname,0777);
			
				if(file_exists($dirname.$prefileName)) unlink($dirname.$prefileName);
				
				if (in_array(strtolower($fileExtension), $imageExtensions)) {
					
					$resultfull = move_uploaded_file($_FILES['file']['tmp_name'][$i],$destinationfull);
					
					if(!$resultfull){
				    
						$ret = array('status' => "ufail");
						echo json_encode($ret);
						exit(0);
					}
								
				}else{
					
					$ret = array('status' => "exfail");
					echo json_encode($ret);
					exit(0);
					
				}
					
				}
								
			} 
			
			if(!empty($marksheets)){
				
				$mpData['marksheets'] = implode("|",$marksheets);
				
			}else{
				$mpData['marksheets'] = "0";
			}
			
			if(empty($mpData)){
				$response = array('status' => 'empty');
				echo  json_encode($response);
			}
			
			date_default_timezone_set('Asia/Kolkata');
			
			$mpData['updated_at'] = date('Y-m-d H:i:s');
			
			if(!$checkmyprofile){
				
				$mpData['id'] = $id;
				$mpData['profilepic'] = "0";
				$mpData['created_at'] = date('Y-m-d H:i:s');
				
				//$mpData = array_filter($mpData);
				
				$id = $this->student_model->SubmitMyprofile($mpData);
				$response = array(
					'status' => 'success',
					'id' => $id
				);
				echo  json_encode($response);
				
			}else{
								
				$mpData = array_filter($mpData);
				
				$id = $this->student_model->UpdateMyprofile($mpData);
				$response = array(
					'status' => 'success',
					'id' => $sid
				);
				echo  json_encode($response);
				
			}
				
			}else{
												
				$response = array(
					'status' => 'empty',
				);
				echo  json_encode($response);
				
			}
			
          
        }else {
                //If no session, redirect to login page
                redirect('login', 'refresh');
            }
    }
	
	
	public function getDistrictList() {
          
        if($this->session->userdata('loggedin')) {
			
			$state = $this->input->post('state');
			
			$result = $this->student_model->GetDistrictList($state);
			echo json_encode($result);
			
		}
	}
	
	public function getCountryStateList() {
          
        if($this->session->userdata('loggedin')) {
			
			$country = $this->input->post('country');
			
			$result = $this->student_model->GetCountryStateList($country);
			echo json_encode($result);
			
		}
	}
	
	
	// Upload Profile Picture
	
	public function changeProfilePhoto() {
		
		if($this->session->userdata('loggedin')) {
			
			//$post = isset($_POST) ? $_POST: array();
			$maxWidth = "500"; 
			$studentid = $this->input->post('studentid', true);
			$path = 'docs/profilepic/'.$studentid.'/';
			$validFormats = array("2", "3");
			$picName = $_FILES['profileImage']['name'];
			$size = $_FILES['profileImage']['size'];
			if(strlen($picName)) {
				//list($txt, $ext) = explode(".", $picName);
                                $extCode = exif_imagetype($_FILES['profileImage']['tmp_name']);
				$extArray = array();
                                $extArray["2"] ="jpeg";$extArray["3"] ="png";
				if(in_array($extCode,$validFormats)) {
					if($size<(1024*500)) {
						
						if(!file_exists($path)) mkdir($path,0777);
						$ext = $extArray[$extCode];
						$actualImageName = 'main.'.$ext;
						$filePath = $path.$actualImageName;
						$tmp = $_FILES['profileImage']['tmp_name'];
						if(move_uploaded_file($tmp, $filePath)) {
							$width = $this->getWidth($filePath);
							$height = $this->getHeight($filePath);						
							if ($width > $maxWidth){
								$scale = $maxWidth/$width;
								$uploaded = $this->resizeImage($filePath,$width,$height,$scale, $ext);
							} else {
								$scale = 1;
								$uploaded = $this->resizeImage($filePath,$width,$height,$scale, $ext);
							}
							
							$result = $this->student_model->UpdateProfilePic($studentid,$actualImageName);
							
							if($result){
								echo "<img id='photo' class='mw-100' file-name='".$actualImageName."' class='' src='".$filePath.'?'.time()."' class='preview'/>";}
							else{ echo "Upload failed";}
						}
						else
						echo "<p class='alert alert-danger mt-4'>Upload failed</p>";
					}
					else
					echo "<p class='alert alert-danger mt-4'>Image file size max 500 KB</p>"; 
				}
				else
				echo "<p class='alert alert-danger mt-4'>Invalid file format..</p>"; 
			}
			else
			echo "<p class='alert alert-danger mt-4'>Please select image..!</p>";
			exit;
			
		}else {
			//If no session, redirect to login page
			redirect('login', 'refresh');
		}
		
	}
	
	public function saveProfilePhoto() {
		
		if($this->session->userdata('loggedin')) {
			
			$post = isset($_POST) ? $_POST: array();
			$userId = isset($post['id']) ? intval($post['id']) : 0;		
			$path = 'images/tmp/'.$_POST['imageName'];
			$tmpWidth = 300; 
			$tmpHeight = 300; 
			if(isset($_POST['t']) and $_POST['t'] == "ajax") {
				extract($_POST);		
				$imagePath = 'images/'.$_POST['imageName'];
				$ratio = ($tmpWidth/$w1); 
				$nw = ceil($w1 * $ratio);
				$nh = ceil($h1 * $ratio);
				$nimg = imagecreatetruecolor($nw,$nh);			
				$imgSrc = imagecreatefromjpeg($path);
				imagecopyresampled($nimg,$imgSrc,0,0,$x1,$y1,$nw,$nh,$w1,$h1);
				imagejpeg($nimg,$imagePath,90);		
			}
			$updateQuery = "
				UPDATE ".$this->userTable." 
				SET photo = '".$_POST['imageName']."'
				WHERE id = '$userId'";
			mysqli_query($this->dbConnect, $updateQuery);
			$saveImagePath = $imagePath.'?'.time();
			echo $saveImagePath;
			exit(0); 
			
	 }else {
		//If no session, redirect to login page
		redirect('login', 'refresh');
	}
		
	}    	
	public function resizeImage($image,$width,$height,$scale, $ext) {
		$newImageWidth = ceil($width * $scale);
		$newImageHeight = ceil($height * $scale);
		$newImage = imagecreatetruecolor($newImageWidth,$newImageHeight);
		switch ($ext) {
			case 'jpg':
			case 'jpeg':
				$source = imagecreatefromjpeg($image);
				break;
			case 'gif':
				$source = imagecreatefromgif($image);
				break;
			case 'png':
				$source = imagecreatefrompng($image);
				break;
			default:
				$source = false;
				break;
		}	
		imagecopyresampled($newImage,$source,0,0,0,0,$newImageWidth,$newImageHeight,$width,$height);
		imagejpeg($newImage,$image,90);
		chmod($image, 0777);
		return $image;
	}	
	public function getHeight($image) {
		$sizes = getimagesize($image);
		$height = $sizes[1];
		return $height;
	}	
	public function getWidth($image) {
		$sizes = getimagesize($image);
		$width = $sizes[0];
		return $width;
	}
	
	public function downloadChallan() {
		
		if($this->session->userdata('loggedin')) {
			
			$session_data = $this->session->userdata('loggedin');
			$session_id = $session_data['id'];
			$session_role = $session_data['role'];

			$data['user'] = $this->login_model->GetUserId();		
		
			$crid = $this->input->get('id');								
			
			$qid = $this->student_model->GetQualificationID($data['user']['id']);

			$stuprofile =  $this->student_model->GetStudentProfile($data['user']['id']);
			//$coursepay =  $this->student_model->GetCoursePayment($data['user']['id'],$qid);
			$studentcoursepay =  $this->student_model->GetCourseStudentPayment($data['user']['id'],$qid,$crid);
			
			$challan = $this->student_model->CreateChallan($data['user']['id'],$studentcoursepay);
			
			$bankaccno = $stuprofile['bankaccountno'];
			
			$virtualaccno = "";
			$accno = substr($bankaccno, 0, 6);
			$accno = "A".$accno;
			
			$virtualaccno = $accno.$challan['stuid'].$challan['challanno'];
			
			
			
			
	$html = '<html>
              <title>Challan</title>
              <head>
			  <script type="text/javascript" src="'.base_url().'js/jquery-3.5.1.min.js"></script>
			  <script>
                    $(document).ready(function(){
                        window.print();
                    });
              </script>
			  <style>

				@font-face {font-family: "Segoe UI";src: url("'.base_url().'css/fonts/segoeui.eot");
				  src: url("'.base_url().'css/fonts/segoeui.eot?#iefix") format("embedded-opentype"), url("'.base_url().'css/fonts/segoeui.woff") format("woff"), url("'.base_url().'css/fonts/segoeui.ttf") format("truetype"), url("'.base_url().'css/fonts/segoeui.svg#ralewaythin") format("svg");font-weight: 400;font-style: normal;}
				@font-face {font-family: "Segoe UI";src: url("'.base_url().'css/fonts/segoeuil.eot");
				  src: url("'.base_url().'css/fonts/segoeuil.eot?#iefix") format("embedded-opentype"), url("'.base_url().'css/fonts/segoeuil.woff") format("woff"), url("'.base_url().'css/fonts/segoeuil.ttf") format("truetype"), url("'.base_url().'css/fonts/segoeuil.svg#ralewaythin") format("svg");font-weight: 300;font-style: normal;}
				@font-face {font-family: "Segoe UI";src: url("'.base_url().'css/fonts/segoeuib.eot");
				  src: url("'.base_url().'css/fonts/segoeuib.eot?#iefix") format("embedded-opentype"), url("'.base_url().'css/fonts/segoeuib.woff") format("woff"), url("'.base_url().'css/fonts/segoeuib.ttf") format("truetype"), url("'.base_url().'css/fonts/segoeuib.svg#ralewaythin") format("svg");font-weight: 700;font-style: normal;}
				@font-face {font-family: "Segoe UI";src: url("'.base_url().'css/fonts/seguisb.eot");
				  src: url("'.base_url().'css/fonts/seguisb.eot?#iefix") format("embedded-opentype"), url("'.base_url().'css/fonts/seguisb.woff") format("woff"), url("'.base_url().'css/fonts/seguisb.ttf") format("truetype"), url("'.base_url().'css/fonts/seguisb.svg#ralewaythin") format("svg");font-weight: 600;font-style: normal;}

			.challanrow{font-family: Segoe UI;border-collapse: collapse;max-width: 734px;margin: auto;font-size: 12px;background: #ffffff;padding: 0rem}
			.challan{font-family: Segoe UI;border: 0.75px solid #BCCAE8;border-collapse: collapse;max-width: 100%;margin: auto;font-size: 12px;background: #ffffff;}
			.challan th{text-align: left}
			.challan th,.challan td{border: 0.75px solid #BCCAE8;padding: 0.5rem 1rem;width: 50%}
			.challan p{display: flex}
			.challan p span{font-size: 12px;color: #181E29;}
			.challan p span:first-child{width: 35%;font-weight: normal;}
			.challan p span:last-child{width: 65%;font-weight: bold;}
			table.challan tr.lastrow td{padding: 2.5rem 1rem;border: none}
			.challan td.totalamt{padding: 1.5rem 1rem;}
			.challan td.totalamt strong{margin-left: 3rem;color: #D63333;font-size: 14px;}

			.copy{max-width: 100%;margin: auto;color: #181E29;font-size: 12px;font-style: italic;font-family: Segoe UI;font-weight: 600;margin-bottom: 1rem}

			.challan td table{font-family: Segoe UI;border: 1px solid #D7DFF0;border-collapse: collapse;width: 80%;margin: 1rem 0 1rem 0.8rem;border-style: hidden;border-radius: 5px; box-shadow: 0 0 0 1px #D7DFF0;font-size:12px;}

			.challan td th{font-weight: 600;color: #536485;background: #E6EBF7;border: 1px solid #D7DFF0;border-width: 0px 0px 1px 0px;text-align: center}
			.challan td td{border: 1px solid #D7DFF0;border-width: 0px 0px 1px 0px;text-align: center;width: 50%}

			.barcode{margin: 4.5rem auto 1rem;width: 45%}
			.upi{margin: auto;display: block}

			.challan td table tr:last-child td:first-child {border-bottom-left-radius: 10px;}
			.challan td table tr:last-child td:last-child {border-bottom-right-radius: 10px;}

			.v-bottom{vertical-align: bottom}

		</style>
</head>
   <body>
	
	<div class="challanrow">

	<table width="100%" border="0" cellspacing="0" cellpadding="0" class="challan">
	  <tbody>
		<tr>
		  <th scope="col"><img src="'.base_url().'img/challan-logo.png" alt="" /></th>
		  <th scope="col"><img src="'.base_url().'img/southindian.png" alt="" /></th>
		</tr>
		<tr>
		  <td><strong>Remittance through Other Banks</strong></td>
		  <td><strong>Remittance through SIB FEE Module</strong></td>
		</tr>
		<tr>
		  <td>&nbsp;</td>
		  <td>Institution Code: <strong>1 (456.7)</strong></td>
		</tr>
		<tr valign="top">
			<td>
				<p><span>Name:</span> <span>Brilliant Study Center</span></p>
				<p><span>Virtual A/C No:</span> <span>'.$virtualaccno.'</span></p>
				<p><span>IFSC Code:</span> <span>SIBL00000453</span></p>
				<p><span>Branch:</span> <span>SIB, Arunapuram</span></p>
			</td>
			
		 	 <td>
				<p><span>Name:</span> <span>'.$stuprofile['name'].'</span></p>
				<p><span>ID:</span> <span>'.$challan['stuid'].'</span></p>
				<p><span>Course:</span> <span>'.$studentcoursepay[0]['coursename'].'</span></p>
				<p><span>Chellan No:</span> <span>'.$challan['challanno'].'</span></p>
				<p><span>Date:</span> <span>'.date("d-m-Y",strtotime($challan['created_at'])).'</span></p>
				<p><span>Phone:</span> <span>'.$stuprofile['fatherphone'].'</span></p>
			</td>
		</tr>
		<tr>
		  <td colspan="2" class="totalamt">Amount: <strong>Rs.'.number_format($challan['totalamt'],0).'/- ('.$this->getIndianCurrency($challan['totalamt']).' Only)</strong></td>
		</tr>
		<tr class="lastrow">
		  <td>Entered by:</td>
		  <td>Authorized Signature:</td>
		</tr>
	  </tbody>
	</table>

	<p class="copy">Student Copy</p>

	<table width="100%" border="0" cellspacing="0" cellpadding="0" class="challan">
	  <tbody>
		<tr>
		  <th scope="col"><img src="'.base_url().'img/challan-logo.png" alt="" /></th>
		  <th scope="col"><img src="'.base_url().'img/southindian.png" alt="" /></th>
		</tr>
		<tr>
		  <td><strong>Remittance through Other Banks</strong></td>
		  <td><strong>Remittance through SIB FEE Module</strong></td>
		</tr>
		<tr>
		  <td>&nbsp;</td>
		  <td>Institution Code: <strong>1 (456.7)</strong></td>
		</tr>
		<tr valign="top">
			<td>
				<p><span>Name:</span> <span>Brilliant Study Center</span></p>
				<p><span>Virtual A/C No:</span> <span>'.$virtualaccno.'</span></p>
				<p><span>IFSC Code:</span> <span>SIBL00000453</span></p>
				<p><span>Branch:</span> <span>SIB, Arunapuram</span></p>
			</td>
			
		 	 <td>
				<p><span>Name:</span> <span>'.$stuprofile['name'].'</span></p>
				<p><span>ID:</span> <span>'.$challan['stuid'].'</span></p>
				<p><span>Course:</span> <span>'.$studentcoursepay[0]['coursename'].'</span></p>
				<p><span>Chellan No:</span> <span>'.$challan['challanno'].'</span></p>
				<p><span>Date:</span> <span>'.date("d-m-Y",strtotime($challan['created_at'])).'</span></p>
				<p><span>Phone:</span> <span>'.$stuprofile['fatherphone'].'</span></p>
			</td>
		</tr>
		<tr>
		  <td colspan="2" class="totalamt">Amount: <strong>Rs.'.number_format($challan['totalamt'],0).'/- ('.$this->getIndianCurrency($challan['totalamt']).' Only)</strong></td>
		</tr>
		<tr>
		  <td>
		  
		  	<table width="100%" border="0" cellspacing="0" cellpadding="0">
			  <tbody>
				<tr>
				  <th scope="col">Values</th>
				  <th scope="col">Count</th>
				</tr>
				<tr>
				  <td>2000 x</td>
				  <td>&nbsp;</td>
				</tr>
				<tr>
				  <td>500 x</td>
				  <td>&nbsp;</td>
				</tr>
				<tr>
				  <td>100 x</td>
				  <td>&nbsp;</td>
				</tr>
				<tr>
				  <td>50 x</td>
				  <td>&nbsp;</td>
				</tr>
				<tr>
				  <td>20 x</td>
				  <td>&nbsp;</td>
				</tr>
				<tr>
				  <td>10 x</td>
				  <td>&nbsp;</td>
				</tr>
				<tr>
				  <td>5 x</td>
				  <td>&nbsp;</td>
				</tr>
				<tr>
				  <td>Coins</td>
				  <td>&nbsp;</td>
				</tr>
				<tr>
				  <td>Total Amount :</td>
				  <td>&nbsp;</td>
				</tr>
			  </tbody>
			</table>
			
		  </td>
		  <td style="padding-top: 18rem">Authorized Signature:</td>
		</tr>
				
	  </tbody>
	</table>
	
	<img src="'.base_url().'img/barcode.png" alt="" class="barcode" />
		
	<img src="'.base_url().'img/upi.png" alt="" class="upi" />

</div></body></html>';
			
			echo $html;
			
			/*$this->load->library('pdf');
		    $this->pdf->load_view($html);
			$this->pdf->set_paper("a4", "portrait");
		    $this->pdf->render();
		    $this->pdf->stream("challan.pdf");*/
			
		/*require_once("./dompdf/autoload.inc.php");
        $dompdf = new DOMPDF();
        $dompdf->load_html($html);
        $dompdf->set_paper("a4", "portrait");
        $dompdf->render();
        $dompdf->stream("challan.pdf");*/
			
		}
		
	}
	
public function getIndianCurrency(float $number)
{
    $decimal = round($number - ($no = floor($number)), 2) * 100;
    $hundred = null;
    $digits_length = strlen($no);
    $i = 0;
    $str = array();
    $words = array(0 => '', 1 => 'one', 2 => 'two',
        3 => 'three', 4 => 'four', 5 => 'five', 6 => 'six',
        7 => 'seven', 8 => 'eight', 9 => 'nine',
        10 => 'ten', 11 => 'eleven', 12 => 'twelve',
        13 => 'thirteen', 14 => 'fourteen', 15 => 'fifteen',
        16 => 'sixteen', 17 => 'seventeen', 18 => 'eighteen',
        19 => 'nineteen', 20 => 'twenty', 30 => 'thirty',
        40 => 'forty', 50 => 'fifty', 60 => 'sixty',
        70 => 'seventy', 80 => 'eighty', 90 => 'ninety');
    $digits = array('', 'hundred','thousand','lakh', 'crore');
    while( $i < $digits_length ) {
        $divider = ($i == 2) ? 10 : 100;
        $number = floor($no % $divider);
        $no = floor($no / $divider);
        $i += $divider == 10 ? 1 : 2;
        if ($number) {
            $plural = (($counter = count($str)) && $number > 9) ? 's' : null;
            $hundred = ($counter == 1 && $str[0]) ? ' and ' : null;
            $str [] = ($number < 21) ? $words[$number].' '. $digits[$counter]. $plural.' '.$hundred:$words[floor($number / 10) * 10].' '.$words[$number % 10]. ' '.$digits[$counter].$plural.' '.$hundred;
        } else $str[] = null;
    }
    $Rupees = implode('', array_reverse($str));
    $paise = ($decimal > 0) ? "." . ($words[$decimal / 10] . " " . $words[$decimal % 10]) . ' Paise' : '';
    //return ($Rupees ? $Rupees . 'Rupees ' : '') . $paise;
	return (ucwords($Rupees) ? ucwords($Rupees) : '') . ucwords($paise);
}


public function ChangeStatus(){
            
            if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')){

                $ide = isset($_GET['ide']) ? $_GET['ide'] : '';
                $status = isset($_GET['status']) ? $_GET['status'] : '';

                if($ide != ""){
                     $ret = $this->course_model->ChangeRefundStatus($ide,$status);
                } else {
                    $ret = array(0 => "fail");
                }

                echo json_encode($ret);
            
            }else {
                //If no session, redirect to login page
                redirect('login', 'refresh');
            }
            
        }
	
	
	// Change Password
	
	public function changePassword() {
          
        if($this->session->userdata('loggedin')) {
			
			$userid = $this->input->post('userid');
			$supassword = $this->input->post('cppassword');
			$suconfpassword = $this->input->post('cpconfpassword');
			$adminpassword = $this->input->post('adminpassword');
			
			$result = $this->student_model->changeStuprofilePassword($userid,$supassword,$suconfpassword,$adminpassword);
			echo json_encode($result);
			
		}
	}
	
	
	// Add Admission
	
	public function getCoursewisecenterOptions(){
	
		if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')){
		
			$userid = $this->input->post('userid');
			$courseid = $this->input->post('courseid');

			$user = $this->login_model->GetUserDetails($userid);
			
			$data = $this->student_model->GetCourseSearchOptions("",$courseid,"");
			echo json_encode($data);
			
		 }else {
			//If no session, redirect to login page
			redirect('login', 'refresh');
		}
		
	}
	
	public function addAdmission(){
      
   		if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')){
				
			$userid = $this->input->post('userid');
			$courseid = $this->input->post('coursename');
			$center = $this->input->post('coursecenter');
			$adminpassword = $this->input->post('courseadminpassword');
			
			//$checkadminpass = $this->student_model->checkAdminPassword($adminpassword);
			if($this->config->item('super_pass') !== $adminpassword){
				$result = array(0 => "fail");
				echo json_encode($result);exit;
			}
			
			
		
		if($userid!="" && $courseid!="" && $center!=""){
       
            $user = $this->login_model->GetUserDetails($userid);
        
			$coursecenterfee =  $this->student_model->GetCenterFee($courseid,$center);
			//print_r($coursecenterfee);		
			$total = number_format($coursecenterfee['totalfee'],2);
			
			$coursedetails = $this->course_model->GetCourseDetails($courseid);
							
			$ide = uniqid();
			
            $qData = array(
                'ide' => $ide,
                'courseid' => $courseid,
                'qualificationid' => $coursedetails['qualification'],
                'studentid' => $user['id'],
                'yearofpassing' => '',
                'class' => '',
                'stream' => '',
                'status' => '',
                'rollno' => '',
                'gracemark' => '',
                'grade' => '',
                'mark' => '',
                'mark_total' => '',
                'subject'=>'',
                'xii_yearofpassing' => '',
                'xii_status' => '',
                'xii_stream' => '',
                'xii_gracemark' => '',
                'xii_rollno' => '',
                'xii_grade' => '',
                'xii_mark' => '',
                'xii_mark_total' => '',
                'xii_subject'=>'',
                'approved'=>'n',
                'center'=>$center,
                'total'=>$total,
                'x_qid'=>'',
                'xii_qid'=>'',                
                'approved_date'=>date('Y-m-d H:i:s'),
                'requested_at' => date('Y-m-d H:i:s'),
                'entrance_name'=>'',
                'entrance_mark'=>'',
                'aq1'=>'',
                'aq2'=>'',
                'aq3'=>'',
                'entrance_regno'=>''
            );
            
            
         $id = $this->course_model->insertAdmissionCourseRequest($qData);
		
		if($id=="success"){
			$result = $this->course_model->ApproveRequest($ide."|");
			echo json_encode($result);
		}else{
			$result = array(0 => "exists");
			echo json_encode($result);
		}
		
			
		}else{
			$result = array(0 => "fail");
			echo json_encode($result);
		}
			
	 }else {
		//If no session, redirect to login page
		redirect('login', 'refresh');
	}		
			
            
    }
	
	
	public function studentprofilecard(){
      
   		if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')){
				
			$sid = $this->input->get('sid');
			$data['sid'] = $sid;
			
			$qid = $this->student_model->GetQualificationID($sid);
			$data['qualification'] = $this->student_model->ViewStudentQualification($sid,$qid);

			$data['stuprofile'] =  $this->student_model->GetStudentProfile($sid);
			
			$data['feepayments'] = $this->student_model->GetAllFeePayments($sid,'','');
			
			
			$this->load->view('student_profilecard_view', $data);
		
			
	 }else {
		//If no session, redirect to login page
		redirect('login', 'refresh');
	 }		
			
            
    }
	
	
	public function studentreportcard(){
      
   		if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')){
				
			$data['roleaccess'] = $this->config->item('roleaccess');

			if(isset($data['roleaccess']['Results Tab'][3]) && $data['roleaccess']['Results Tab'][3]!="y"){
				redirect($data['roleaccess']['defaultpage'], 'refresh');
			}
			
			$sid = $this->input->get('sid');
			$sdate = $this->input->get('sdate');
			$edate = $this->input->get('edate');
			
			if($sid!=""){
			
				$data['sid'] = $sid;
				$data['sdate'] = $sdate;
				$data['edate'] = $edate;

				$data['user'] = $this->login_model->GetUserDetails($sid);
				
				if($data['user']['id']==""){
					redirect($data['roleaccess']['defaultpage'], 'refresh');
				}
				
				$data['results'] = $this->exams_model->GetStudentResult($sid,$sdate,$edate);

				$this->load->view('student_reportcard_view', $data);
				
			}else{
				redirect($data['roleaccess']['defaultpage'], 'refresh');
			}
		
			
	 }else {
		//If no session, redirect to login page
		redirect('login', 'refresh');
	 }		
			
            
    }
	
	
	public function sendEmailStudentReportcard(){
      
   		if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')){
				
			$data['roleaccess'] = $this->config->item('roleaccess');

			if(isset($data['roleaccess']['Results Tab'][3]) && $data['roleaccess']['Results Tab'][3]!="y"){
				redirect($data['roleaccess']['defaultpage'], 'refresh');
			}
			
			$sid = $this->input->post('sid');
			$sdate = $this->input->post('sdate');
			$edate = $this->input->post('edate');
			
			if($sid!=""){
			
				$data['sid'] = $sid;
				$data['sdate'] = $sdate;
				$data['edate'] = $edate;

				$data['user'] = $this->login_model->GetUserDetails($sid);
				
				if($data['user']['id']==""){
					redirect($data['roleaccess']['defaultpage'], 'refresh');
				}
				
				$this->load->model('notification_model','',TRUE);
				
				$this->notification_model->sendEmailStudentReportcard($sid,$sdate,$edate);
				
			}else{
				redirect($data['roleaccess']['defaultpage'], 'refresh');
			}
		
			
	 }else {
		//If no session, redirect to login page
		redirect('login', 'refresh');
	 }		
			
            
    }
    
    public function updateFromWebcam() {
        
        if($this->session->userdata('loggedin')) {
			
			//$post = isset($_POST) ? $_POST: array();
			$maxWidth = "500"; 
			$studentid = $this->input->post('studentid', true);
			$path = 'docs/profilepic/'.$studentid.'/';
                        if(!file_exists($path)) mkdir($path,0777);
                        $ext =".jpeg";
                        $actualImageName = 'main.jpeg';
                        $filePath = $path.$actualImageName;
                        $tmp = $_FILES['simage']['tmp_name'];
                        if(move_uploaded_file($tmp, $filePath)) {
                                $width = $this->getWidth($filePath);
                                $height = $this->getHeight($filePath);						
                                if ($width > $maxWidth){
                                        $scale = $maxWidth/$width;
                                        $uploaded = $this->resizeImage($filePath,$width,$height,$scale, $ext);
                                } else {
                                        $scale = 1;
                                        $uploaded = $this->resizeImage($filePath,$width,$height,$scale, $ext);
                                }

                                $result = $this->student_model->UpdateProfilePic($studentid,$actualImageName);

                                if($result){
                                        echo "<img id='photo' class='mw-100' file-name='".$actualImageName."' class='' src='".$filePath.'?'.time()."' class='preview'/>";}
                                else{ echo "Upload failed";}
                        }
                        else
                        echo "<p class='alert alert-danger mt-4'>Upload failed</p>";
					
			
			
		}else {
			//If no session, redirect to login page
			redirect('login', 'refresh');
		}
    
    }
	
	
}
?>

<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Examresults extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model('login_model','',TRUE);
				$this->load->model('exams_model','',TRUE);
                $this->load->library('table');                  

	}
	
	function index()
	{
		if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in'))
   		{
                    $session_data = $this->session->userdata('loggedin');
                    $session_id = $session_data['id'];
                    $session_role = $session_data['role'];
                    
					$data['roleaccess'] = $this->config->item('roleaccess');

					if($data['roleaccess']['Results'][3]!="y"){
						redirect($data['roleaccess']['defaultpage'], 'refresh');
					}
			
                    $data['user'] = $this->login_model->GetUserId();		
		
					                        
                    $examid = $this->input->get('id', true);
					
					if($examid==""){
						redirect('exams', 'refresh');
					}
					
					$data['exam'] = $this->exams_model->GetExamdetails($examid);
					
                    $data['menu'] = $this->load->view('headermenu', $data, TRUE);
                  
					$this->load->view('header_view', $data);
					$this->load->view('examresults_view', $data);
					$this->load->view('footer_view');
                        
         }
   		else
   		{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
   		}
		
	}
	
	
	public function getExamResults(){
            
		if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')){
			
			$examid = $this->input->post('examid', true);
			$status = $this->input->post('status', true);
			$type = $this->input->post('type', true);
			
			$result = $this->exams_model->GetExamResults($examid,$status);
			
			$row = array();
			
			$sno = 1;
			
			foreach($result as $key=>$col){
								
				if($type=="Screening Test"){
					
					$row[] = array($sno,$col->studentno,$col->studentname,$col->rollno,$col->physics,$col->chemistry,$col->biology,$col->maths,$col->p1,$col->p2,$col->totalmarks,$col->maxmarks,$col->highestmarks,$col->percent,$col->grade,$col->rank,$col->outof,$col->estatus,$col->scholarearn,$col->remarks,$col->studentid);
					
				}else{
					
					$row[] = array($sno,$col->studentno,$col->studentname,$col->physics,$col->chemistry,$col->biology,$col->maths,$col->p1,$col->p2,$col->totalmarks,$col->maxmarks,$col->highestmarks,$col->percent,$col->grade,$col->rank,$col->studentid);
					
				}
				
				
				$sno++;
				
			}
									
			$ret = array("tabledata"=>$row);
			echo json_encode($ret);
						
		}
	}
        
        
  public function uploadExamresults(){
            
		if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')){

			
			$roleaccess = $this->config->item('roleaccess');
			 if(isset($roleaccess['Upload Results'][3]) && $roleaccess['Upload Results'][3]=="y"){
			 
			//print_r($_FILES);exit;
			
			$examid = $this->input->post('examid', true);
			$type = $this->input->post('type', true);	 
			
			if(isset($_FILES["file"]) && !empty($_FILES["file"]['name'])){
				
				$total = count($_FILES['file']['name']);
				
				$validExtensions = array('.xls');
								
				$dirname = FCPATH.'docs/examresults/';
								
				$fileExtension = strrchr($_FILES['file']['name'][0], ".");
				$fileName = "examresults_".$examid.$fileExtension;
									
				$destinationfull = $dirname . $fileName;
					
				if(!file_exists($dirname)) mkdir($dirname,0777);
							
				if (in_array(strtolower($fileExtension), $validExtensions)) {
					
					$resultfull = move_uploaded_file($_FILES['file']['tmp_name'][0],$destinationfull);
					
					if(!$resultfull){
				    
						$ret = array('status' => "ufail");
						echo json_encode($ret);
						exit(0);
						
					}else{
						
						$result = $this->addExamresults($fileName,$examid,$type);
						
						$ret = array('status' => "success","message"=>$result['message']);
						echo json_encode($ret);
						exit(0);
						
					}
								
				}else{
					
					$ret = array('status' => "exfail");
					echo json_encode($ret);
					exit(0);
					
				}
					
								
			}else{
				
				$ret = array('status' => "empty");
				echo json_encode($ret);
				exit(0);
				
			}
			
			}else{
				
				$ret = array('status' => "empty");
				echo json_encode($ret);
				exit(0);
				
			}
			
			
		}
	  
  }
	
	
function addExamresults($fileName,$examid,$type){
	
	ini_set('memory_limit', '-1');	
	ini_set('max_execution_time', 86400);
	
	include './import/excel_reader.php';     // include the class

	// creates an object instance of the class, and read the excel file data
	$excel = new PhpExcelReader;
	$excel->read(FCPATH.'docs/examresults/'.$fileName);
		
	$sheet = $excel->sheets[0];
	
	$x = 2;

	//echo $sheet['numRows'];exit;
	
	$arr = array();
	
	$arr["message"] = "";
	
  while($x <= $sheet['numRows']) {
	  	  
	  $sno = isset($sheet['cells'][$x][1]) ? $sheet['cells'][$x][1] : '';
	  $studentno = isset($sheet['cells'][$x][2]) ? $sheet['cells'][$x][2] : '';
	  $physics = isset($sheet['cells'][$x][3]) ? $sheet['cells'][$x][3] : '-';
	  $chemistry = isset($sheet['cells'][$x][4]) ? $sheet['cells'][$x][4] : '-';
	  $biology = isset($sheet['cells'][$x][5]) ? $sheet['cells'][$x][5] : '-';
	  $maths = isset($sheet['cells'][$x][6]) ? $sheet['cells'][$x][6] : '-';
	  $p1 = isset($sheet['cells'][$x][7]) ? $sheet['cells'][$x][7] : '-';
	  $p2 = isset($sheet['cells'][$x][8]) ? $sheet['cells'][$x][8] : '-';
	  $totalmarks = isset($sheet['cells'][$x][9]) ? $sheet['cells'][$x][9] : '-';
	  $maxmarks = isset($sheet['cells'][$x][10]) ? $sheet['cells'][$x][10] : '-';
	  $highestmarks = isset($sheet['cells'][$x][11]) ? $sheet['cells'][$x][11] : '-';
	  $percent = isset($sheet['cells'][$x][12]) ? $sheet['cells'][$x][12] : '-';
	  $grade = isset($sheet['cells'][$x][13]) ? $sheet['cells'][$x][13] : '-';
	  $rank = isset($sheet['cells'][$x][14]) ? $sheet['cells'][$x][14] : '-';
	  
	  $rollno = isset($sheet['cells'][$x][15]) ? $sheet['cells'][$x][15] : '-';
	  $outof = isset($sheet['cells'][$x][16]) ? $sheet['cells'][$x][16] : '-';
	  $status = isset($sheet['cells'][$x][17]) ? $sheet['cells'][$x][17] : '-';
	  $scholarearn = isset($sheet['cells'][$x][18]) ? $sheet['cells'][$x][18] : '-';
	  $remarks = isset($sheet['cells'][$x][19]) ? $sheet['cells'][$x][19] : '-';
	  
	  //echo $x.". ".$studentno."<br />";$x++;continue;
		  		  
	  // Add results

	  $result = $this->exams_model->AddExamResults($examid,$studentno,$physics,$chemistry,$biology,$maths,$p1,$p2,$totalmarks,$maxmarks,$highestmarks,$percent,$grade,$rank,$rollno,$outof,$status,$scholarearn,$remarks);
	  
	  
	  if($result['response']=="nostudent" && trim($studentno)!="" && is_numeric($studentno)){
		  $arr["message"] .= "<p><font color='orange'>".$sno.". ".$studentno." - Not found</font></p>";
	  }else if($result['response']=="fail" && trim($studentno)!="" && is_numeric($studentno)){
		  $arr["message"] .= "<p><font color='red'>".$sno.". ".$studentno." - Failed</font></p>";
	  }

	  //exit;

	  $x++;
		  		  			  
  }
		
	return $arr;

}
	
	public function approveExamResults(){
            
		if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')){
			
			$examid = $this->input->post('examid', true);
			
			$result = $this->exams_model->ApproveExamResults($examid);			
			echo $result;
						
		}
	}
	
	
	public function deleteExamResults(){
            
		if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')){
			
			$examid = $this->input->post('examid', true);
			
			$result = $this->exams_model->DeleteExamResults($examid);			
			echo $result;
						
		}
	}
	
}
?>

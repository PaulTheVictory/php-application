<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Location extends CI_Controller {

	function __construct() {
            
		parent::__construct();
		$this->load->model('course_model','',TRUE);
                $this->load->model('login_model','',TRUE);
                 $this->load->library('table'); $this->load->helper('form');

	}
	
	function index() {
            
            if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')) {

                $session_data = $this->session->userdata('loggedin');
                $session_id = $session_data['id'];
                $session_role = $session_data['role'];
                $data['user'] = $this->login_model->GetUserId();


				$data['roleaccess'] = $this->config->item('roleaccess');

				if($data['roleaccess']['uview']!="y"){
					redirect($data['roleaccess']['defaultpage'], 'refresh');
				}
				
                $data['menu'] = $this->load->view('headermenu', $data, TRUE);
                
                $tmpl = array('table_open' => '<table class="sortable sorting disabled" id="locationtable" style="margin-top:0px;">');
                $this->table->set_template($tmpl);
                $this->table->set_heading('S.NO', 'LOCATION NAME','DISTRICT','STATE','ACTIONS');
                
              

                $this->load->view('header_view', $data);
                $this->load->view('location_view', $data);
                $this->load->view('footer_view');
                
            } else {
                //If no session, redirect to login page
                redirect('login', 'refresh');
            }
            
        }
        
        
        public function GetDistricts() {
            
            if ($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')) {

                $state = isset($_GET['state']) ? $_GET['state'] : '';
                $ret = $this->course_model->GetDistricts($state);
                echo $ret;
            
            }else {
                //If no session, redirect to login page
                redirect('login', 'refresh');
            }
        
        
        }
        
          public function GetLocations() {
            
            if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in') ){
                
                $ret =  $this->course_model->GetLocations();
                echo $ret;
                
            }else{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
            }
            
        }
        
        
       public function locationSubmit() {
            
        if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')) {
                $this->load->library('form_validation');

                $validatation["cname"] = "trim|required|xss_clean|callback_alpha_numeric_spaces|max_length[100]|is_unique[typo_unit.unit]";
                $validatation["gurl"] = "trim|xss_clean|callback_alpha_numeric_spaces|max_length[200]";
                $validatation["state"] = "trim|required|xss_clean|callback_alpha_numeric_spaces|max_length[100]";
                $validatation["District"] = "trim|xss_clean|required|callback_alpha_numeric_spaces|max_length[100]";
                $validatation["pincode"] = "trim|xss_clean|numeric|max_length[6]";
   
                    foreach ($validatation as $key=>$val) {
                        $this->form_validation->set_rules($key, $key, $val);
                    }


                if ($this->form_validation->run() == false) {
                        $response = array(
                            'status' => 'error',
                            'message' => validation_errors()
                        );
                        echo json_encode($response);

                } else {


                     $response = $this->insertQ();
                     echo  json_encode($response);
                }
              
               
            }else{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
            }
            
    }
    
        
    public function insertQ(){
        
        $ide = uniqid();
            $qData = array(
                'ide' => $ide,
                'unit' => $this->input->post('cname', true),
                'state' => $this->input->post('state', true),
                'district' => $this->input->post('District', true),
                'gurl' => $this->input->post('gurl', true),  
                'screentest' => '',  
                'batchqty' => '',  
                'rollnostarts' => '',  
                'rollnoends' => '', 
                'created_at' => date('Y-m-d H:i:s')
            );
                       

            $id = $this->course_model->InsertLocation($qData);
                       
            $response = array(
                'status' => 'success',
                'message' => "location Created Successfully."
            );

          return $response;
    }
        
        public function DelLocation() {
            
            if ($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')) {

                $ide = isset($_GET['ide']) ? $_GET['ide'] : '';

                if($ide != ""){
                     $ret = $this->course_model->DelLocation($ide);
                } else {
                    $ret = array(0 => "fail");
                }

                echo json_encode($ret);
            
            }else {
                //If no session, redirect to login page
                redirect('login', 'refresh');
            }
                
        }

}
?>
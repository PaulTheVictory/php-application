<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Examcenter extends CI_Controller {

	function __construct() {
            
		parent::__construct();
                $this->load->model('login_model','',TRUE);
                 $this->load->model('exams_model','',TRUE);
                 $this->load->library('table'); $this->load->helper('form');

	}
	
	function index() {
            
            if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')) {

                $session_data = $this->session->userdata('loggedin');
                $session_id = $session_data['id'];
                $session_role = $session_data['role'];
               


				$data['roleaccess'] = $this->config->item('roleaccess');

				if($data['roleaccess']['uview']!="y"){
					redirect($data['roleaccess']['defaultpage'], 'refresh');
				}
                                
                                 $data['user'] = $this->login_model->GetUserId();
				
                $data['menu'] = $this->load->view('headermenu', $data, TRUE);
                $ide =  $this->input->get('id', true);
                $name =  $this->input->get('name', true);
                $data['ide'] = $ide;$data['name'] = $name;
                $tmpl = array('table_open' => '<table class="sortable sorting disabled" id="templatetable" style="margin-top:0px;">');
                $this->table->set_template($tmpl);
                $this->table->set_heading('S.NO', 'CENTERS','ADDRESS 1','ADDRESS 2','PHONE','PINCODE','ACTIONS');
                
              
                
                $this->load->view('header_view', $data);
                $this->load->view('examcenter_view', $data);
                $this->load->view('footer_view');
                
            } else {
                //If no session, redirect to login page
                redirect('login', 'refresh');
            }
            
        }
        
        
       
          public function GetCenters() {
            
            if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in') ){
                $ide =  $this->input->post('id', true);
                $ret =  $this->exams_model->GetCenters($ide);
                echo $ret;
                
            }else{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
            }
            
        }
        
        
         public function AddCenter() {
            
            if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in') ){
                
                  $this->load->library('form_validation');
			
			$roleaccess = $this->config->item('roleaccess');
			
			if(isset($roleaccess['uadd']) && $roleaccess['uadd']=="y"){
				

                            $ide = isset($_POST['eide']) ? $_POST['eide'] : '';	
                            $validatation["cname"] = "trim|required|xss_clean|callback_alpha_numeric_spaces|max_length[100]";
                            $validatation["address1"] = "trim|required|xss_clean|callback_alpha_numeric_spaces|max_length[100]";
                            $validatation["address2"] = "trim|required|xss_clean|callback_alpha_numeric_spaces|max_length[100]";
                            $validatation["phonenumber"] = "trim|required|xss_clean|callback_alpha_numeric_spaces|max_length[100]";
                            $validatation["district"] = "trim|required|xss_clean|callback_alpha_numeric_spaces|max_length[100]";
                            $validatation["pincode"] = "trim|required|xss_clean|numeric|max_length[6]";
                            $validatation["districtid"] = "trim|required|xss_clean|callback_alpha_numeric_spaces|max_length[100]";

                               foreach ($validatation as $key=>$val) {
                                   $this->form_validation->set_rules($key, $key, $val);
                               }


                           if ($this->form_validation->run() == false) {
                                   $response = array(
                                       'status' => 'error',
                                       'message' => validation_errors()
                                   );
                                   echo json_encode($response);

                           } else {

                                    if($ide === "") {
                                $response = $this->insertQ();
                                    } else {
                                        $response = $this->updateQ();
                                    }
                                echo  json_encode($response);
                           }
              
			}else {

			  $response = array(
					'status' => 'error',
					'message' => 'User Permission denied'
				);
				echo json_encode($response);
			}
			
                
            }else{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
            }
            
        }
        
           public function insertQ(){
        
		$roleaccess = $this->config->item('roleaccess');
			
		if(isset($roleaccess['uadd']) && $roleaccess['uadd']=="y"){
				
                $ide = uniqid();
                    $qData = array(
                        'id' => $ide,
                        'name' => $this->input->post('cname', true),
                        'address1' => $this->input->post('address1', true),
                        'address2' => $this->input->post('address2', true),
                        'phone' => $this->input->post('phonenumber', true),
                        'pincode' => $this->input->post('pincode', true),
                        'districtname' => $this->input->post('district', true),
                        'districtid' => $this->input->post('districtid', true),
                        'created_at' => date('Y-m-d H:i:s')
                    );


                    $id = $this->exams_model->AddCenter($qData);

                    $response = array(
                        'status' => 'success',
                        'message' => "District Created Successfully."
                    );
			
		}else {

		  $response = array(
				'status' => 'error',
				'message' => 'User Permission denied'
			);
		}

          return $response;
    }
    
    
    public function updateQ(){
        
		$roleaccess = $this->config->item('roleaccess');
			
		if(isset($roleaccess['uedit']) && $roleaccess['uedit']=="y"){
			
                           
                     $qData = array(
                        'id' => $this->input->post('eide', true),
                        'name' => $this->input->post('cname', true),
                        'address1' => $this->input->post('address1', true),
                        'address2' => $this->input->post('address2', true),
                        'phone' => $this->input->post('phonenumber', true),
                        'pincode' => $this->input->post('pincode', true),
                        'districtname' => $this->input->post('district', true),
                        'districtid' => $this->input->post('districtid', true),
                        'created_at' => date('Y-m-d H:i:s')
                    );


                    $this->exams_model->UpdateCenter($qData);

                    $response = array(
                        'status' => 'success',
                        'message' => "Center Updated Successfully."
                    );
			
		}else {

                        $response = array(
				'status' => 'error',
				'message' => 'User Permission denied'
			);
		}
		

          return $response;
    }
   
        
        public function Delcenter() {
            
            if ($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')) {

				
			$roleaccess = $this->config->item('roleaccess');
			
			if(isset($roleaccess['Exam District Center'][2]) && $roleaccess['Exam District Center'][2]=="y"){
				
                $ide = isset($_GET['ide']) ? $_GET['ide'] : '';

                if($ide != ""){
                     $ret = $this->exams_model->DeleteCenter($ide);
                } else {
                    $ret = array(0 => "fail");
                }

                echo json_encode($ret);
				
			} else {
				$ret = array(0 => "fail");
				echo json_encode($ret);
			}
            
            }else {
                //If no session, redirect to login page
                redirect('login', 'refresh');
            }
                
        }
        
        
        

}
?>
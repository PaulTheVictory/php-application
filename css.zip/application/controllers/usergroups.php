<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Usergroups extends CI_Controller {

	function __construct() {
            
		parent::__construct();
		$this->load->model('users_model','',TRUE);
                $this->load->model('login_model','',TRUE);
                 $this->load->library('table'); $this->load->helper('form');

	}
	
	function index() {
            
            if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')) {

                $session_data = $this->session->userdata('loggedin');
                $session_id = $session_data['id'];
                $session_role = $session_data['role'];
                $data['user'] = $this->login_model->GetUserId();

				$data['roleaccess'] = $this->config->item('roleaccess');

				if($data['roleaccess']['uview']!="y"){
					redirect($data['roleaccess']['defaultpage'], 'refresh');
				}
				

                $data['menu'] = $this->load->view('headermenu', $data, TRUE);
                
                $tmpl = array('table_open' => '<table class="sortable sorting disabled" id="usertable" style="margin-top:0px;">');
                $this->table->set_template($tmpl);
                $this->table->set_heading('S.NO', 'GROUP NAME','USER TYPE','ACTIONS');
                
              
                $this->load->view('header_view', $data);
                $this->load->view('usergroups_view', $data);
                $this->load->view('footer_view');
                
            } else {
                //If no session, redirect to login page
                redirect('login', 'refresh');
            }
            
        }
        
        
       
          public function GetGroups() {
            
            if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in') ){
                
                $ret =  $this->users_model->GetGroups();
                echo $ret;
                
            }else{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
            }
            
        }
        
      
        
        public function Delgroups() {
            
            if ($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')) {

			$roleaccess = $this->config->item('roleaccess');
			
			if(isset($roleaccess['udelete']) && $roleaccess['udelete']=="y"){
				
                $ide = isset($_GET['ide']) ? $_GET['ide'] : '';

                if($ide != ""){
                     $ret = $this->users_model->DeleteGroup($ide);
                } else {
                    $ret = array(0 => "fail");
                }

                echo json_encode($ret);
				
			} else {
                 $ret = array(0 => "fail");
				echo json_encode($ret);
            }
            
            }else {
                //If no session, redirect to login page
                redirect('login', 'refresh');
            }
                
        }
        

}
?>
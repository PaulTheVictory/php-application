<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Templateadd extends CI_Controller {

	function __construct() {
            
		parent::__construct();
		$this->load->model('notification_model','',TRUE);
                $this->load->model('login_model','',TRUE);
                $this->load->helper('form');

	}
	
	function index() {
            
            if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')) {

                $session_data = $this->session->userdata('loggedin');
                $session_id = $session_data['id'];
                $session_role = $session_data['role'];
                $data['user'] = $this->login_model->GetUserId();
				
				$data['roleaccess'] = $this->config->item('roleaccess');

				if($data['roleaccess']['SMS Templates'][0]!="y"){
					redirect($data['roleaccess']['defaultpage'], 'refresh');
				}
				



                $data['menu'] = $this->load->view('headermenu', $data, TRUE);
                
                $this->load->view('header_view', $data);
                $this->load->view('templateadd_view', $data);
                $this->load->view('footer_view');
                
            } else {
                //If no session, redirect to login page
                redirect('login', 'refresh');
            }
            
        }
        
        
             
        
       public function userSubmit() {
            
        if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')) {
                $this->load->library('form_validation');
                
			$roleaccess = $this->config->item('roleaccess');
			
			if(isset($roleaccess['SMS Templates'][0]) && $roleaccess['SMS Templates'][0]=="y"){
			
                $this->form_validation->set_rules('tname', 'Template Name', 'trim|required|xss_clean|callback_alpha_numeric_spaces|max_length[100]');
                $this->form_validation->set_rules('tid', 'Template ID', 'trim|required|xss_clean|callback_alpha_numeric_spaces|max_length[100]');
                $this->form_validation->set_rules('message', 'Message', 'trim|required|xss_clean|callback_alpha_numeric_spaces|max_length[1000]');
                

                if ($this->form_validation->run() == false) {
                        $response = array(
                            'status' => 'error',
                            'message' => validation_errors()
                        );
                        echo json_encode($response);

                } else {

                     $response = $this->insertQ();
                     echo  json_encode($response);
                }
				
			}else {

				  $response = array(
						'status' => 'error',
						'message' => 'User Permission denied'
					);
					echo json_encode($response);
                }
              
               
            }else{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
            }
            
    }
    
        
    public function insertQ(){
        
		$roleaccess = $this->config->item('roleaccess');
			
		if(isset($roleaccess['SMS Templates'][0]) && $roleaccess['SMS Templates'][0]=="y"){
                    
        $ide = uniqid();
            $qData = array(
                'id' => $ide,
                'name' => $this->input->post('tname', true),
                'templateid' => $this->input->post('tid', true),
                'message' => $this->input->post('message', true),  
                'active ' => 'a',   
                'created_at' => date('Y-m-d H:i:s')
            );
                       

            $id = $this->notification_model->AddTemplate($qData);
                       
            $response = array(
                'status' => 'success',
                'message' => "SMS Template Created Successfully."
            );
			
		}else {

		  $response = array(
				'status' => 'error',
				'message' => 'User Permission denied'
			);
			echo json_encode($response);
		}
		

          return $response;
    }
    
        
        

}
?>
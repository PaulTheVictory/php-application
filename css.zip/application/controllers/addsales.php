<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Addsales extends CI_Controller {

	function __construct() {
            
		parent::__construct();
		$this->load->model('course_model','',TRUE);
                $this->load->model('login_model','',TRUE);

	}
	
	function index() {
            
            if ($this->session->userdata('loggedin')) {

                $session_data = $this->session->userdata('loggedin');
                $session_id = $session_data['id'];
                $session_role = $session_data['role'];
                $data['user'] = $this->login_model->GetUserId();


                $data['menu'] = $this->load->view('headermenu', $data, TRUE);
                $data['units'] = $this->course_model->GetAllUnits("");

                $this->load->view('header', $data);
                $this->load->view('addsales_view', $data);
                $this->load->view('footer');
            } else {
                //If no session, redirect to login page
                redirect('login', 'refresh');
            }
            
        }
        
        
         public function itemSearch() {
		
            $session_data = $this->session->userdata('logged_in');
            $session_id = $session_data['id'];
            $session_role = $session_data['role'];
            $user_id = $this->login_model->GetUserId($session_id,$session_role);
        
            $ide  = isset($_GET['term'])?$_GET['term']:'';
            $type  = isset($_GET['type'])?$_GET['type']:'';
             $test  = isset($_GET['test'])?$_GET['test']:'';
		
            $ret = $this->course_model->ItemSearch($ide,$type,$test);
            echo json_encode($ret);
        }
        
        
        public function insertEstimate() {
		
            $session_data = $this->session->userdata('logged_in');
            $session_id = $session_data['id'];
            $session_role = $session_data['role'];
            $user_id = $this->login_model->GetUserId($session_id,$session_role);
        
            $sitem  =  $this->input->post('sitem');
            $name  = $this->input->post('sname');
            $mobile  = $this->input->post('smobile');
            $email  = $this->input->post('semail');           
            $srate  = $this->input->post('srate');
            $sqty  = $this->input->post('sqty');
            $sunits  = $this->input->post('sunits');
          /*  $stax  = isset($_POST['stax'])?$_POST['stax']:'';*/
            $samount  = $this->input->post('samount');
            $payments = $this->input->post('spayments');
             $grand = $this->input->post('sgrand');
            
          	
            $ret = $this->course_model->InsertEstimate($name,$mobile,$email,$sitem,$srate,$sqty,$sunits,$samount,$payments,$grand);
            echo json_encode($ret);
        }
        
        
        public function insertBill() {
		
            $session_data = $this->session->userdata('logged_in');
            $session_id = $session_data['id'];
            $session_role = $session_data['role'];
            $user_id = $this->login_model->GetUserId($session_id,$session_role);
        
            $sitem  =  $this->input->post('sitem');
            $name  = $this->input->post('sname');
            $mobile  = $this->input->post('smobile');
            $email  = $this->input->post('semail');           
            $srate  = $this->input->post('srate');
            $sqty  = $this->input->post('sqty');
            $sunits  = $this->input->post('sunits');
            $stax  = $this->input->post('stax');
            $samount  = $this->input->post('samount');
            $payments = $this->input->post('spayments');
             $grand = $this->input->post('sgrand');
            
          	
            $ret = $this->course_model->InsertBill($name,$mobile,$email,$sitem,$srate,$sqty,$sunits,$samount,$payments,$grand,$stax);
            echo json_encode($ret);
        }
        
        
        public function printSalesDetails(){
            
             date_default_timezone_set('Asia/Kolkata');
        $session_data = $this->session->userdata('logged_in');
            $session_id = $session_data['id'];
            $session_role = $session_data['role'];
            $user_id = $this->login_model->GetUserId($session_id,$session_role);
            
             $billno       = $_GET['ide'];
             $type  = isset($_GET['type'])?$_GET['type']:'';
             
             if($type == "bill") {
                 
                 $presEle = $this->course_model->GetbillDetailsForPrint($billno,$user_id["id"]);
                 $this->BillPrint($presEle);
                 
             } else {
                 
                  $presEle = $this->course_model->GetestimateDetailsForPrint($billno,$user_id["id"]);
                  $this->EstimatePrint($presEle);
             }
        
       
    }
    
    public function BillPrint($presEle){
        
         
		if(!$presEle){  $url = base_url()."dashboard";
            echo "<html><head><title>Print Bill Receipt</title><style type=\"text/css\">

                    ::selection{ background-color: #E13300; color: white; }
                    ::moz-selection{ background-color: #E13300; color: white; }
                    ::webkit-selection{ background-color: #E13300; color: white; }

                    body {
                        background-color: #fff;
                        margin: 40px;
                        font: 13px/20px normal Helvetica, Arial, sans-serif;
                        color: #4F5155;
                    }

                    a {
                       color: #003399;
                       background-color: transparent;
                       font-weight: normal;
                    }

                    h1 {
                       color: #444;
                       background-color: transparent;
                       border-bottom: 1px solid #D0D0D0;
                       font-size: 19px;
                       font-weight: normal;
                       margin: 0 0 14px 0;
                       padding: 14px 15px 10px 15px;
                    }

                    #container {
                       margin: 10px;
                       border: 1px solid #D0D0D0;
                       -webkit-box-shadow: 0 0 8px #D0D0D0;
                    }

                    p { 
                        margin: 12px 15px 12px 15px;
                    }
                    </style>
                    
        </head>
        <body>
	<div id=\"container\">
		<h1>Not Found</h1>
		<p>Bill Not Available</p>	</div>
                <a href=\"$url\">Back</a>	</div>
       </body></html>"; exit(0);}
		
		$date = $presEle['date'];
		
		$tname = $presEle["estelements"]['item'];
		$tprice = $presEle["estelements"]['rate'];
		$tqty = $presEle["estelements"]['qty'];
                $tunit = $presEle["estelements"]['unit'];
                $ttax = $presEle["estelements"]['tax'];
		
		$tname = substr($tname, 0,-1);
		$tprice = substr($tprice, 0,-1);
		$tqty = substr($tqty, 0,-1);
                $tunit = substr($tunit, 0,-1);
                $ttax = substr($ttax, 0,-1);
		
		$treatArr = explode("|",$tname);
		$priceArr = explode("|",$tprice);
		$qtyArr = explode("|",$tqty);
                $unitArr = explode("|",$tunit);   
                $taxArr = explode("|",$ttax);   
                $date = $presEle["estelements"]['date'];
                
                $cnt = 0;
            			
		
        $paper_size = "a4";
        $includeheader = 'Test';
        $footerheader = '';

	$offestwidth = 0;	
        if($paper_size == "a4") {
            $SizeW = "650px";
            $remainW = 650;
        } else if($paper_size == "a5") {
            $SizeW = "592px";
            $remainW = 592 - $offestwidth;
        } else {
            $SizeW = "840px";
            $remainW = 840 - $offestwidth;
        }
        
        
          if($includeheader != "") {
               $offestHeight = 'auto';
            $includeheader = "<div class=\"printTop\" style=\"float:left;width:103px;height:100px;margin:0px auto;padding-top:7px;\">
                              <img width=\"102\" height=\"102\" src=\"".base_url()."images/surya.jpeg\">
                              </div>";
            
             $footerheader = "<div style=\"float:left;width:500px;height:auto;padding-bottom:1px;margin-left:0px\">
                                <h2 style=\"text-align: left; margin: 10px auto; font-size: 30px;margin-bottom:0px\">".$presEle["cllists"]['name']."</h2>
                               <p style=\"padding: 2px; margin: 0px; font-size: 14px; text-align: left;line-height:1.5em\">".$presEle["cllists"]['address'].", ".$presEle["cllists"]['address1'].", ".$presEle["cllists"]['place']." - ".$presEle["cllists"]['pincode']."</p>
                               <p style=\"padding: 2px; margin: 0px; font-size: 14px; text-align: left;\"><b>Mobile</b> : ".$presEle["cllists"]['mobile']."&nbsp;&nbsp;&nbsp;<b>TIN</b> : 33626447917</p>";
             if($presEle["cllists"]['email']!=''){
                 $footerheader  .= "<p style=\"line-height:1.5em;padding: 2px; margin: 0px; font-size: 14px; text-align: left;\"><b>Email</b> : ".$presEle["cllists"]['email'];
             } 
             
             if($presEle["cllists"]['website']!=''){
                 $footerheader  .= "&nbsp;&nbsp;&nbsp;<b>Website</b>:".$presEle["cllists"]['website']."</p>";
             }
                $footerheader  .= "</div><div style=\"width: 650px; float: left; background: none repeat scroll 0% 0% transparent; height: 0px; border: 1px solid rgb(0, 0, 0);\"></div>";
            
       } else {
            
            $includeheader = "<div class=\"printTop\" style=\"float:left;width:".$SizeW.";height:".$offestHeight.";margin:0px auto\"></div>";
        }
                
        echo "<html>
              <title>Print Bill Receipt</title>
              <head>
               <link href=\"".base_url()."css/font-awesome/css/font-awesome.min.css\" media=\"all\" type=\"text/css\" rel=\"stylesheet\">
              <script type=\"text/javascript\" src=\"".base_url()."js/jquery.js\"></script>
              <script>
                    $(document).ready(function(){
                        window.print();
                    });
              </script>
              <style>
			    				    	 html, body, div, span, applet, object, iframe,
 h3,h2,h4,h5, h6,blockquote, pre,
a, abbr, acronym, address, big, cite, code,
del, dfn, em, font, img, ins, kbd, q, s, samp,
small, strike,sub, sup, tt, var,
dl, dt, dd, ol, ul, li,
fieldset, form, label, legend,
table, caption, tbody, tfoot, thead, tr, th, td {
   margin: 0;
   padding: 0;
   border: 0;
   outline: 0;
   font-weight: inherit;
   font-style: inherit;
   font-size: 100%;
   font-family:helvetica;
   vertical-align: baseline;

}
                     .presTitle{
                        width:95%;
                        height:auto;
                        margin:0px auto;                        
                      }
                     .presTitle tr{
                        width:100%;
                        height:auto;
                        font-size:90%;
                        padding:5px;
                        line-height:1.5em;
                      }
                      
                     .presTitle td{
                        width:25%;
                        height:auto;
                        padding:5px;
                        font-weight:bold
                     }      
					 .presHeader{
                       
                        width:95%;
                        height:auto;
                        margin:0px auto;
                        margin-top:15px;
                        border:1px solid #000;
                        font-family:Arial;
						border-collapse:collapse;
                      }
                     .presHeader tr{
                        width:100%;
                        height:auto;
                        font-size:90%;  line-height:2em;                     
                      }                      
                     .presHeader td{
                        width:25%;
                        height:auto;
                        padding:0px;padding-left:5px;
                        text-align:center;
                        border-right:1px solid #000;font-size:12px
                     }   
					.presHeader td:first-child{ width:8%;}
                    .presHeader td:nth-child(2){ width:42%; text-align: left;padding-left:10px}
					.presHeader td:nth-child(3){ width:12%; text-align: center;}
					.presHeader td:nth-child(4){ width:12%; text-align: center;}
                                        .presHeader td:nth-child(5){ width:12%; text-align: center;}
                    .presHeader td:last-child{ width:12%; text-align: center;}     
					.totalTable{
						width:95%;						
                        height:auto;
                        margin:0px auto;
                        margin-top:10px;                        
                        font-family:Arial;
						border-collapse:collapse;
						text-align:right;
						font-size:90%;
					}
					.totalTable td:first-child{ width:80%;font-weight:bold}
					.totalTable td:last-child{ width:20%; padding:2px 5px;}
              </style>
              </head>
              <body>
              <div class=\"printLayout\" style=\"width:".$SizeW.";height:842px;\">
              $includeheader$footerheader
              <div class=\"printLeft\" style=\"min-height:1px;height:auto;float:left;width:".$offestwidth."px;\"></div>
              <div class=\"printRight\" style=\"height:auto;float:left;width:".$remainW."px;margin-top:10px\">
                <table class=\"presTitle \">
		    <tr><td colspan=\"4\" style=\"text-align: center; width: 100%; font-size: 20px; font-weight: bold;\">Bill Receipt</td></tr>
                    <tr><td colspan=\"2\" style=\"text-align: left; padding: 0px; line-height:25px;\">Name&nbsp;&nbsp;: ".$presEle["patlists"]["pname"]."</td><td colspan=\"2\" style=\"text-align: right; padding: 0px; line-height:25px;\">Bill No&nbsp;: ".$presEle["estelements"]["bill_no"]."</td></tr>
		    <tr><td colspan=\"2\" style=\"text-align: left; padding: 0px;\">Mobile&nbsp;: ".$presEle["patlists"]["mobile"]."</td><td colspan=\"2\" style=\"text-align: right; padding: 0px;\">Date: $date</td></tr>
                ";
        
               if($presEle["patlists"]["email"] == ''){
                   //echo "<tr style=\" line-height: 20px;\"><td colspan=\"2\" style=\"text-align: left; padding: 0px;\"></td><td colspan=\"2\" style=\"text-align: right; padding: 0px;\">Amount Due (Rs) : ".$presEle["amtdue"]." </td></tr>";
               }else{
                  // echo "<tr style=\" line-height: 20px;\"><td colspan=\"2\" style=\"text-align: left; padding: 0px;\">Email&nbsp;: ".$presEle["patlists"]["email"]."</td><td colspan=\"2\" style=\"text-align: right; padding: 0px;\">Amount Due (Rs) : ".$presEle["amtdue"]." </td></tr>";
               }
	
                 
                 echo "</table><table class=\"presHeader\">
				 	<tr>
                        <td style=\" border-bottom:1px solid #000;font-weight: bold;\">No</td>
                        <td style=\" border-bottom:1px solid #000;font-weight: bold;\">Particulars</td>
                        <td style=\" border-bottom:1px solid #000;font-weight: bold;\">Price (Rs)</td>
                        <td style=\" border-bottom:1px solid #000;font-weight: bold;\">Qty</td>
                        <td style=\" border-bottom:1px solid #000;font-weight: bold;\">Tax (%)</td>
			<td style=\" border-bottom:1px solid #000;font-weight: bold;\">Value (Rs)</td>
                    </tr>";
              
 	    $taxArray = Array();$subtotal = 0;	$taxtotalArray = Array();			
            for ($i = 0; $i < count($treatArr); $i++) {

                 $j = $i + 1;
                 $amount = abs($priceArr[$i]) * abs($qtyArr[$i]);
                 echo "<tr><td >$j</td><td>$treatArr[$i]</td><td>$priceArr[$i]</td><td>$qtyArr[$i] $unitArr[$i]</td><td>$taxArr[$i]</td><td>".number_format($amount,2)."</td></tr>";
                  $famount = number_format($amount,2);
                   $subtotal = $subtotal + $famount;
                 if(array_key_exists($taxArr[$i], $taxArray)){
                     $taxamt = abs($famount) * ( abs($taxArr[$i]) / 100);
                     $taxArray[$taxArr[$i]] += abs($taxamt);
                     $taxtotalArray[$taxArr[$i]] += abs($famount);
                 } else {
                      $taxamt = abs($famount) * ( abs($taxArr[$i]) / 100);
                     $taxArray[$taxArr[$i]] = abs($taxamt);
                     $taxtotalArray[$taxArr[$i]] = abs($famount);
                 }
                  
             }
             
             $taxHTML = "";
             foreach($taxArray as $key=>$val) {
                 
                 $taxHTML .= '<tr ><td style="font-weight:normal;font-size:12px">VAT '.$key.'% on : '.number_format($taxtotalArray[$key],2).'<span ></span></td><td style="font-weight:normal;font-size:12px">'.number_format($val,2).'</td></tr>';
                 
             }

             echo "</table><table class=\"totalTable\" style=\"line-height:2em\">";
                if ($presEle["estelements"]['discount'] != 0) {

                        echo "<tr><td>Discount: </td><td> ". $presEle["estelements"]['discount'] . "</td></tr>";
                }
                
                $roundoff = "";$grandtotal = 0.0;
                $gtotal = floatval($presEle["estelements"]['grand']);
                $ceiltotal = ceil($gtotal);
                $difftotal = floatval($ceiltotal) - floatval($gtotal);
                $difftotal = number_format($difftotal,2);
                $difftotal = number_format($difftotal , 2);
                if($difftotal > 0.5) {
                    $grandtotal = round($gtotal);
                    $rfgtotal = floatval($grandtotal) - floatval($gtotal);
                    $roundoff = number_format($rfgtotal,2);
                } else {
                    $grandtotal = $ceiltotal;
                    $rfgtotal = floatval($ceiltotal) - floatval($gtotal);
                    $roundoff = number_format($rfgtotal,2);
                }
                
                echo "<tr><td style=\"font-size:18px;line-height:40px;font-weight:normal\">Sub Total (Rs) :</td><td style=\"font-size:18px;line-height:40px;font-weight:normal\">".$subtotal."</td></tr>";
		echo $taxHTML;	
                echo "<tr><td style=\"font-size:12px;line-height:20px;font-weight:normal\">Total :</td><td style=\"font-size:12px;line-height:20px;font-weight:normal\">".$presEle["estelements"]['grand']."</td></tr>";
                 echo "<tr><td style=\"font-size:12px;line-height:20px;font-weight:normal\">Roundoff :</td><td style=\"font-size:12px;line-height:20px;font-weight:normal\">".$roundoff."</td></tr>";
                 echo "<tr><td style=\"font-size:20px;line-height:40px\">Grand Total (Rs) :</td><td style=\"font-size:20px;line-height:40px\">".number_format($grandtotal,2)."</td></tr>";
                
                 if($presEle["payments"] != '') {
                 //echo "<tr><td style=\"font-size:20px;line-height:40px\">Payments:</td><td></td></tr>".$presEle["payments"]."</tr>";
                }
                
                if($presEle["amtdue"] != '0'){
                    //echo "<tr><td style=\"font-weight:normal;font-size:16px;line-height:30px\">Amount Due (Rs) :</td><td style=\"font-weight:normal;font-size:16px;line-height:40px\">".$presEle["amtdue"]."</td></tr>"; 
                }
                
                echo "</table></div>
                      </div></body></html>";
        
    }
    
    
    
    public function EstimatePrint($presEle){
        
                 $norate  = isset($_GET['norate'])?$_GET['norate']:'';
                 
		if(!$presEle){  $url = base_url()."dashboard";
            echo "<html><head><title>Print Invoice Receipt</title><style type=\"text/css\">

                    ::selection{ background-color: #E13300; color: white; }
                    ::moz-selection{ background-color: #E13300; color: white; }
                    ::webkit-selection{ background-color: #E13300; color: white; }

                    body {
                        background-color: #fff;
                        margin: 40px;
                        font: 13px/20px normal Helvetica, Arial, sans-serif;
                        color: #4F5155;
                    }

                    a {
                       color: #003399;
                       background-color: transparent;
                       font-weight: normal;
                    }

                    h1 {
                       color: #444;
                       background-color: transparent;
                       border-bottom: 1px solid #D0D0D0;
                       font-size: 19px;
                       font-weight: normal;
                       margin: 0 0 14px 0;
                       padding: 14px 15px 10px 15px;
                    }

                    #container {
                       margin: 10px;
                       border: 1px solid #D0D0D0;
                       -webkit-box-shadow: 0 0 8px #D0D0D0;
                    }



                    p { 
                        margin: 12px 15px 12px 15px;
                    }
                    </style>
                    
        </head>
        <body>
	<div id=\"container\">
		<h1>Not Found</h1>
		<p>Bill Not Available</p>	</div>
                <a href=\"$url\">Back</a>	</div>
       </body></html>"; exit(0);}
		
		$date = $presEle['date'];
		
		$tname = $presEle["estelements"]['item'];
		$tprice = $presEle["estelements"]['rate'];
		$tqty = $presEle["estelements"]['qty'];
                $tunit = $presEle["estelements"]['unit'];
		
		$tname = substr($tname, 0,-1);
		$tprice = substr($tprice, 0,-1);
		$tqty = substr($tqty, 0,-1);
                $tunit = substr($tunit, 0,-1);
		
		$treatArr = explode("|",$tname);
		$priceArr = explode("|",$tprice);
		$qtyArr = explode("|",$tqty);
                $unitArr = explode("|",$tunit);      
                $date = $presEle["estelements"]['date'];
                
                $cnt = 0;
            			
		
        $paper_size = "a4";
        $includeheader = 'Test';
        $footerheader = '';

	$offestwidth = 0;	
        if($paper_size == "a4") {
            $SizeW = "732px";
            $remainW = 732;
        } else if($paper_size == "a5") {
            $SizeW = "592px";
            $remainW = 592 - $offestwidth;
        } else {
            $SizeW = "840px";
            $remainW = 840 - $offestwidth;
        }
        
        
        /*  if($includeheader != "") {
               $offestHeight = 'auto';
            $includeheader = "<div class=\"printTop\" style=\"float:left;width:103px;height:100px;margin:0px auto;padding-top:18px;\">
                              <img width=\"102\" height=\"102\" src=\"".base_url()."images/raja.png\">
                              </div>";
            
             $footerheader = "<div style=\"float:left;width:600px;height:auto;padding-bottom:0px;margin-left:10px\">
                                <h2 style=\"text-align: left; margin: 10px auto; font-size: 36px;margin-bottom:0px\">".$presEle["cllists"]['name']."</h2>
                               <p style=\"padding: 2px; margin: 0px; font-size: 14px; text-align: left;line-height:2em\">".$presEle["cllists"]['address'].",".$presEle["cllists"]['address1'].",".$presEle["cllists"]['place'].",".$presEle["cllists"]['city'].",".$presEle["cllists"]['pincode']."</p>
                               <p style=\"padding: 2px; margin: 0px; font-size: 14px; text-align: left;\"><b>Mobile</b> : ".$presEle["cllists"]['mobile']."&nbsp;&nbsp;&nbsp;<b>Phone</b>:".$presEle["cllists"]['landline']."</p>";
             if($presEle["cllists"]['email']!=''){
                 $footerheader  .= "<p style=\"line-height:2em;padding: 2px; margin: 0px; font-size: 14px; text-align: left;\"><b>Email</b> : ".$presEle["cllists"]['email'];
             } 
             
             if($presEle["cllists"]['website']!=''){
                 $footerheader  .= "&nbsp;&nbsp;&nbsp;<b>Website</b>:".$presEle["cllists"]['website']."</p>";
             }
                $footerheader  .= "</div><div style=\"width: 842px; float: left; background: none repeat scroll 0% 0% transparent; height: 0px; border: 1px solid rgb(0, 0, 0);\"></div>";
            
       } else {
            
            $includeheader = "<div class=\"printTop\" style=\"float:left;width:".$SizeW.";height:".$offestHeight.";margin:0px auto\"></div>";
        }*/
                
        echo "<html>
              <title>Print Bill Receipt</title>
              <head>
               <link href=\"".base_url()."css/font-awesome/css/font-awesome.min.css\" media=\"all\" type=\"text/css\" rel=\"stylesheet\">
              <script type=\"text/javascript\" src=\"".base_url()."js/jquery.js\"></script>
              <script>
                    $(document).ready(function(){
                        window.print();
                    });
              </script>
              <style>
			    				    	 html, body, div, span, applet, object, iframe,
 h3,h2,h4,h5, h6,blockquote, pre,
a, abbr, acronym, address, big, cite, code,
del, dfn, em, font, img, ins, kbd, q, s, samp,
small, strike,sub, sup, tt, var,
dl, dt, dd, ol, ul, li,
fieldset, form, label, legend,
table, caption, tbody, tfoot, thead, tr, th, td {
   margin: 0;
   padding: 0;
   border: 0;
   outline: 0;
   font-weight: inherit;
   font-style: inherit;
   font-size: 100%;
   font-family:times new roman;
   vertical-align: baseline;

}

@media print {
  body {
    width: 6in;
    height: auto;
  }
  /* etc */
}

body {
    width: 6in;
    height: auto;
  }
                     .presTitle{
                        width:100%;
                        height:auto;
                        margin:0px auto;                        
                      }
                     .presTitle tr{
                        width:100%;
                        height:auto;
                        font-size:90%;
                        padding:5px;
                        line-height:2.5em;
                      }
                      
                     .presTitle td{
                        width:25%;
                        height:auto;
                        padding:5px;
                        font-weight:bold
                     }      
					 .presHeader{
                       
                        width:100%;
                        height:auto;
                        margin:0px auto;
                        margin-top:5px;
                        border:1px solid #000;
                        font-family:Arial;
						border-collapse:collapse;
                      }
                     .presHeader tr{
                        width:100%;
                        height:auto;
                        font-size:90%;  line-height:18px;                     
                      }                      
                     .presHeader td{
                        width:25%;
                        height:auto;padding:0px;
                        padding-left:5px;
                        text-align:center;
                        border-right:0px solid #000;font-size:11px;font-weight:bold;
                     }   
					.presHeader td:first-child{ width:5%;}
                    .presHeader td:nth-child(2){ width:65%; text-align: left;}
					.presHeader td:nth-child(3){ width:10%; text-align: center;}
					.presHeader td:nth-child(4){ width:10%; text-align: center;}
                    .presHeader td:last-child{ width:25%; text-align: center;}     
					.totalTable{
						width:100%;						
                        height:auto;
                        margin:0px auto;
                        margin-top:10px;                        
                        font-family:Arial;
						border-collapse:collapse;
						text-align:right;
						font-size:90%;
					}
					.totalTable td:first-child{ width:80%;font-weight:bold}
					.totalTable td:last-child{ width:20%; padding:2px 5px;}
              </style>
              </head>
              <body>
              <div class=\"printLayout\" style=\"width:".$SizeW.";height:auto;\">
              <h1  style=\"text-align: center; font-size: 25px; margin-top: 0px;margin-bottom:0px;font-size:20px;\">Estimated Bill</h1>
              <div class=\"printLeft\" style=\"min-height:1px;height:auto;float:left;width:".$offestwidth."px;\"></div>
              <div class=\"printRight\" style=\"height:auto;float:left;width:".$remainW."px;margin-top:5px\">
                <table class=\"presTitle \">
		    <tr><td colspan=\"2\" style=\"text-align: left; padding: 0px; line-height:25px;\">Name&nbsp;&nbsp;: <span style=\"font-size:12px\">".$presEle["patlists"]["pname"]."</span></td><td colspan=\"2\" style=\"text-align: right; padding: 0px; line-height:25px;\">Invoice No&nbsp;: ".$presEle["estelements"]["bill_no"]."</td></tr>
		    <tr><td colspan=\"2\" style=\"text-align: left; padding: 0px;\">Mobile&nbsp;: ".$presEle["patlists"]["mobile"]."</td><td colspan=\"2\" style=\"text-align: right; padding: 0px;\">Date: $date</td></tr>
                ";
        
               
             	
               
               if($norate === ""){
                   
                   echo "</table><table class=\"presHeader\">
				 	<tr>
                        <td style=\" border-bottom:1px solid #000;font-weight: bold;\">No</td>
                        <td style=\" border-bottom:1px solid #000;font-weight: bold;\">Particulars</td>
                        <td style=\" border-bottom:1px solid #000;font-weight: bold;\">Rate (Rs)</td>
                        <td style=\" border-bottom:1px solid #000;font-weight: bold;\">Qty</td>
                        <td style=\" border-bottom:1px solid #000;font-weight: bold;\">Value (Rs)</td>
                    </tr>";
                   
               } else {
                   
                   echo "</table><table class=\"presHeader\">
				 	<tr>
                        <td style=\" border-bottom:1px solid #000;font-weight: bold;\">No</td>
                        <td style=\" border-bottom:1px solid #000;font-weight: bold;\">Particulars</td>                     
                        <td style=\" border-bottom:1px solid #000;font-weight: bold;\">Qty</td>
   
                    </tr>";
               }
			
		
					
                for ($i = 0; $i < count($treatArr); $i++) {

                 $j = $i + 1;
                 if ($cnt == 0) {
                     $amount = floatval($priceArr[$i]) * floatval($qtyArr[$i]);
                     
                     if($norate === "") {
                          echo "<tr><td >$j</td><td>".strtoupper($treatArr[$i])."</td><td>$priceArr[$i]</td><td>$qtyArr[$i] $unitArr[$i]</td><td>$amount</td></tr>";
                     } else {
                         echo "<tr><td >$j</td><td>".strtoupper($treatArr[$i])."</td><td>$qtyArr[$i] $unitArr[$i]</td></tr>";
                     }
                    

                 } 
             }

             echo "<tr><td>&nbsp;</td><td></td><td></td><td></td><td></td></tr><tr><td>&nbsp;</td><td></td><td></td><td></td><td></td></tr><tr><td>&nbsp;</td><td></td><td></td><td></td><td></td></tr><tr><td>&nbsp;</td><td></td><td></td><td></td><td></td></tr></table><table class=\"totalTable\" style=\"line-height:2em\">";
                if ($presEle["estelements"]['discount'] != 0) {

                        echo "<tr><td>Discount: </td><td> ". $presEle["estelements"]['discount'] . "</td></tr>";
                }
		
                if($norate === "") {
                 echo "<tr><td style=\"font-size:20px;line-height:40px\">Grand Total (Rs) :</td><td style=\"font-size:20px;line-height:40px\">".number_format($presEle["estelements"]['grand'],2)."</td></tr>";
                // echo "<tr><td style=\"font-size:16px;line-height:40px\">Total Paid (Rs) :</td><td style=\"font-size:16px;line-height:40px\">".number_format($presEle["totpaid"],2)."</td></tr>";
                }
                
                 if(($presEle["payments"] != '') && ($norate === "")) {
                 echo "<tr><td style=\"font-size:20px;line-height:40px\">Payments:</td><td></td></tr>".$presEle["payments"]."</tr>";
                }
                
                if(($presEle["amtdue"] != '0') && ($norate === "")){
                    //echo "<tr><td style=\"font-size:16px;line-height:30px\">Amount Due (Rs) :</td><td style=\"font-size:16px;line-height:40px\">".$presEle["amtdue"]."</td></tr>"; 
                }
                
                echo "</table></body></html>";
        
    }

    

    public function nameSearch() {
		
            $session_data = $this->session->userdata('logged_in');
            $session_id = $session_data['id'];
            $session_role = $session_data['role'];
            $user_id = $this->login_model->GetUserId($session_id,$session_role);
        
            $inword  = isset($_GET['term'])?$_GET['term']:'';
		
            $ret = $this->course_model->NameSearch($inword);
            echo json_encode($ret);
        }
        
        
         public function mobileSearch() {
		
            $session_data = $this->session->userdata('logged_in');
            $session_id = $session_data['id'];
            $session_role = $session_data['role'];
            $user_id = $this->login_model->GetUserId($session_id,$session_role);
        
            $inword  = isset($_GET['term'])?$_GET['term']:'';
		
            $ret = $this->course_model->MobileSearch($inword);
            echo json_encode($ret);
        }
        
        public function checkDue(){
            
             $session_data = $this->session->userdata('logged_in');
            $session_id = $session_data['id'];
            $session_role = $session_data['role'];
            $user_id = $this->login_model->GetUserId($session_id,$session_role);
        
            $ide  = isset($_GET['ide'])?$_GET['ide']:'';
            
             $ret = $this->course_model->CheckDue($ide);
            echo json_encode($ret);
            
            
        }
      

}
?>
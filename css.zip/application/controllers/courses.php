<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Courses extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model('login_model','',TRUE);
                $this->load->model('course_model','',TRUE);
                $this->load->model('payment_model','',TRUE);
                $this->load->model('student_model','',TRUE);
                 $this->load->library('table'); 

	}
	
	function index()
	{
		if($this->session->userdata('loggedin'))
   		{
                    $session_data = $this->session->userdata('loggedin');
                    $session_id = $session_data['id'];
                    $session_role = $session_data['role'];
                    $data['type'] = isset($_GET['type']) ? $_GET['type'] : '';
                    $data['mode'] = isset($_GET['mode']) ? $_GET['mode'] : '';
                    
                    $data['user'] = $this->login_model->GetUserId();
			
					$data['roleaccess'] = $this->config->item('roleaccess');
			
					$current = $this->uri->segment(1);
					if($data['roleaccess']['uview']!="y" && $data['roleaccess']['defaultpage']!=$current){
						redirect($data['roleaccess']['defaultpage'], 'refresh');
					}
		
                    $data['menu'] = $this->load->view('headermenu', $data, TRUE);
                    
                     $tmpl = array('table_open' => '<table class="sortable" id="coursetable" style="margin-top:0px;">');
                                $this->table->set_template($tmpl);
                                $this->table->set_heading('SNO','COURSE ID','COURSE NAME','REFUND','STATUS', 'ACTIONS');
						
                    $this->load->view('header_view', $data);
                    $this->load->view('courses_view', $data);
                    $this->load->view('footer_view');
		}
   		else
   		{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
   		}
		
	}
        
         public function getItemLists() {
            
            if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')){
                
                $type = isset($_POST['type']) ? $_POST['type'] : '';
                
                $ret =  $this->course_model->GetAllItems($type);
                echo $ret;
                
            }else{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
            }
            
        }
        
     
        public function DelCourse(){
            
            if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')){

                $ide = isset($_GET['ide']) ? $_GET['ide'] : '';

                if($ide != ""){
                     $ret = $this->course_model->DeleteCourse($ide);
                } else {
                    $ret = array(0 => "fail");
                }

                echo json_encode($ret);
            
            }else {
                //If no session, redirect to login page
                redirect('login', 'refresh');
            }
            
        }
	
	   public function ChangeStatus(){
            
            if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')){

                $ide = isset($_GET['ide']) ? $_GET['ide'] : '';
                $status = isset($_GET['status']) ? $_GET['status'] : '';

                if($ide != ""){
                     $ret = $this->course_model->ChangeCourseStatus($ide,$status);
                } else {
                    $ret = array(0 => "fail");
                }

                echo json_encode($ret);
            
            }else {
                //If no session, redirect to login page
                redirect('login', 'refresh');
            }
            
        }
        
        public function RefundStatus(){
            
            if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')){

                $ide = isset($_GET['ide']) ? $_GET['ide'] : '';
                $status = isset($_GET['status']) ? $_GET['status'] : '';

                if($ide != ""){
                     $ret = $this->course_model->BulkRefundStatus($ide,$status);
                } else {
                    $ret = array(0 => "fail");
                }

                echo json_encode($ret);
            
            }else {
                //If no session, redirect to login page
                redirect('login', 'refresh');
            }
            
        }
        
        public function courseSearch() {
		
           if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')){
        
            $inword  = isset($_GET['term'])?$_GET['term']:'';
		
            $ret = $this->course_model->CourseNameSearch($inword);
            echo json_encode($ret);
            }
        }
        
        public function GetCourseCenterList() {
		
           if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')){
        
            $ide  = isset($_POST['ide'])?$_POST['ide']:'';
		
            $ret = $this->course_model->GetCourseCenterList($ide);
            echo json_encode($ret);
            }
        }
        
        public function CourseChange(){
            
            if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')){

               
                $sid = isset($_GET['sid']) ? $_GET['sid'] : '';
                $cid = isset($_GET['cid']) ? $_GET['cid'] : '';
                $center = isset($_GET['center']) ? $_GET['center'] : '';
                $ncenter = isset($_GET['ncenter']) ? $_GET['ncenter'] : '';
                $ncid = isset($_GET['ncid']) ? $_GET['ncid'] : '';
                $stupayid = isset($_GET['stupayid']) ? $_GET['stupayid'] : '';
                $amount = isset($_GET['amount']) ? $_GET['amount'] : '';
                $remit = isset($_GET['remit']) ? $_GET['remit'] : '';
                $refund = isset($_GET['refund']) ? $_GET['refund'] : '';
                $rid = isset($_GET['rid']) ? $_GET['rid'] : '';
                $totalrefund = isset($_GET['totalr']) ? $_GET['totalr'] : '';      
                $refundapp = isset($_GET['refundapp']) ? $_GET['refundapp'] : '';
               
                $aleady_paid = $this->course_model->CheckCoursePaid($ncid,$sid,$ncenter);
                if( ($cid != "") && ($aleady_paid === false)){
                    
                     $crcptno = $this->course_model->AddCourseChange($sid,$cid,$center,$ncenter,$ncid,$stupayid,$amount,$remit,$refund,$rid);
                     $nrequestid = '';
                     $ischeck = $this->course_model->CheckCourseChangeCourseRequest($ncid,$sid,$ncenter);
                     if($ischeck === "") {
                        $nrequestid = $this->insertNewCourseRequest($ncid,$ncenter,'',$sid);
                        $ret1 = $nrequestid."|";
                        $ret2 = $this->course_model->ApproveRequest($ret1,"cchange");
                     } else {
                        
                         $retArr = $this->course_model->GetCourseRequestid($ncid,$sid);
                         $nrequestid = $retArr['ide'];
                         if($retArr['approved'] !== 'y') { 
                             
                            $ret1 = $nrequestid."|";
                            $ret2 = $this->course_model->ApproveRequest($ret1,"cchange");
                         }
                     }
                     
                    $this->course_model->NewCourseFeeAdjustments($nrequestid,$totalrefund);
                    
                    $this->course_model->UpdateNewCourseRequestid($crcptno,$nrequestid);
                    
                    //Add refund application
                    if($refundapp !== ""){
                        $stuprofile =  $this->student_model->GetStudentProfile($sid);
                        $refundid = uniqid();
                         $qData = array(
                                        'id' => $refundid,
                                        'studentid' => $sid,
                                        'studid' =>$stuprofile['studid'],
                                        'courseid' => $cid,
                                        'requestid' => $rid,
                                        'center' => $center,
                                        'reason' => "Fee excess on course change",
                                        'doj' => '',
                                        'batch' => '',
                                        'housenameno' => $stuprofile['housenameno'],
                                        'contactaddress' => $stuprofile['contactaddress'],
                                        'contactpost' => $stuprofile['contactpost'],
                                        'contactcountry' => $stuprofile['contactcountry'],
                                        'contactstate' => $stuprofile['contactstate'],
                                        'contactdistrict' => $stuprofile['contactdistrict'],
                                        'contactpincode' => $stuprofile['contactpincode'],
                                        'accountholdername' => '',
                                        'bankname' => $stuprofile['bankname'],
                                        'branch' => $stuprofile['branch'],
                                        'ifsccode' => $stuprofile['ifsccode'],
                                        'bankaccountno' => $stuprofile['bankaccountno'],
                                        'status' => 'w',
                                        'type' => "Course Change",
                                        'requestedrefundamt' => $refundapp,
                                        'created_at' => date('Y-m-d H:i:s')
                                    );
                                     $type = 'init';
                                    $this->payment_model->AddRefundApplication($qData,$type);
                    }
                        
                    $this->load->model('notification_model','',TRUE);
                    $this->notification_model->CourseChangeNotification($sid);
					
                     $ret = array(0 => "success");
                     
                } else {
                    $ret = array(0 => "fail",1=>'Could not change the course');
                }

                echo json_encode($ret);
            
            }else {
                //If no session, redirect to login page
                redirect('login', 'refresh');
            }
            
        }
        
        public function CenterChange(){
            
            if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')){

               
                
                $cid = isset($_GET['cid']) ? $_GET['cid'] : '';
                $center = isset($_GET['center']) ? $_GET['center'] : '';
                $ncenter = isset($_GET['ncenter']) ? $_GET['ncenter'] : '';
                $rid = isset($_GET['rid']) ? $_GET['rid'] : '';
                if($rid != ""){
                    
                     $this->course_model->AddCenterChange($center,$ncenter,$rid);
					
                     $ret = array(0 => "success");
                     
                } else {
                    $ret = array(0 => "fail",1=>'Could not change the course');
                }

                echo json_encode($ret);
            
            }else {
                //If no session, redirect to login page
                redirect('login', 'refresh');
            }
            
        }
        
        public function insertNewCourseRequest($cid,$center,$total,$sid){
      
   
        $ide = uniqid();
       
           $user = $this->login_model->GetUserDetails($sid); 
		   $coursedetails = $this->course_model->GetCourseDetails($cid);
        
            $qData = array(
                'ide' => $ide,
                'courseid' => $cid,
                'qualificationid' => $coursedetails['qualification'],
                'studentid' => $user['id'],
                'yearofpassing' => '',
                'class' => '',
                'stream' => '',
                'status' => '',
                'rollno' => '',
                'gracemark' => '',
                'grade' => '',
                'mark' => '',
                'mark_total' => '',
                'subject'=>'',
                'xii_yearofpassing' => '',
                'xii_status' => '',
                'xii_stream' => '',
                'xii_gracemark' => '',
                'xii_rollno' => '',
                'xii_grade' => '',
                'xii_mark' => '',
                'xii_mark_total' => '',
                'xii_subject'=>'',
                'approved'=>'n',
                'center'=>$center,
                'total'=>$total,
                'x_qid'=>'',
                'xii_qid'=>'',                
                'approved_date'=>date('Y-m-d H:i:s'),
                'requested_at' => date('Y-m-d H:i:s'),
                'entrance_name'=>'',
                'entrance_mark'=>'',
                'aq1'=>'',
                'aq2'=>'',
                'aq3'=>'',
                'entrance_regno'=>'','photocopy_ht'=>''
            );
            
            
         $id = $this->course_model->insertCourseChangeRequest($qData);
            
          return $ide;
    }
	
	
}
?>

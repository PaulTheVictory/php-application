<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');



class VerifyLogin extends CI_Controller {



	function __construct()

	{

		parent::__construct();

		$this->load->model('login_model','',TRUE);

		//$this->load->model('profile_model','',TRUE);
		

 	}

	

	function index()
 	{

   		//This method will have the credentials validation

   		$this->load->library('form_validation');
 

   		$this->form_validation->set_rules('username', 'Username', 'trim|required');

   		$this->form_validation->set_rules('password', 'Password', 'trim|required|callback_check_database');

 		$this->form_validation->set_error_delimiters('<p class="alert alert-danger">', '</p>');

   		if($this->form_validation->run() == FALSE && !$this->session->userdata('loggedin'))

   		{

     		//Field validation failed.  User redirected to login page

     		$this->load->helper(array('form'));

			$this->load->view('header');

			$this->load->view('login_view');	

			$this->load->view('footer');

   		}

   		else

   		{
                    $session_data = $this->session->userdata('loggedin');
                    $session_id = $session_data['id'];
                    $session_role = $session_data['role'];
			
					$roleaccess = $this->login_model->GetRoleAccess($session_data['role']);
			
                    if($session_role === 'student') {
                    	redirect('stucourses', 'refresh');
                    }else{
						
						if($roleaccess['defaultpage']!=""){
							redirect($roleaccess['defaultpage'], 'refresh');
							//echo $roleaccess['defaultpage'];
						}else{
							redirect('students', 'refresh');
						}
					} 
						
					/*if($session_role === 'admin'){
                        redirect('students', 'refresh');
                    }else if($session_role === 'teacher'){
                        redirect('students', 'refresh');
                    }*/


   		}

 

 	}

	

	function check_database($password)
 	{

   		//Field validation succeeded.  Validate against database

   		$username = $this->input->post('username');

			if($username === "admissions1@brilliantpala.org"){

				//$allowIps = array("117.239.157.82","117.232.72.234");
				$allowIps = $this->login_model->Whitelistip();
				$currentUserIp = $this->input->ip_address();

				if(!in_array($currentUserIp, $allowIps)){

				   $this->form_validation->set_message('check_database', 'Not allowed from external network. Your IP : '.$currentUserIp);

					return false;

				} 
			}

   		//query the database

   		$result = $this->login_model->VerifyLogin($username, $password);

 

   		if($result)

   		{
                    $this->login_model->LogoutExistingSessions($username);
                    

     		/*$sess_array = array();

     		foreach($result as $row)

     		{

       			$sess_array = array(

         			'id' => $row->emailid,

         			'username' => $row->emailid,

					'type' => $row->type

       			);

				

				if($sess_array['type']=="Parent"){

					$this->session->unset_userdata('studlog_in');

       				$this->session->set_userdata('adlog_in', $sess_array);

				}

				else{

					$this->session->unset_userdata('adlog_in');

       				$this->session->set_userdata('studlog_in', $sess_array);

				}

				

				$this->user_model->createSession($username);

     		}*/

			

     		return TRUE;

   		}

   		else

   		{

     		$this->form_validation->set_message('check_database', 'Invalid username or password');

			return false;

   		}

 	}
        
        
        function checkSession()
 	{
            
            $status = $this->login_model->CheckSessionsStatus();
            if($status === "o"){
                echo "active";
            }else if($status === "c"){
                echo "inactive";
            }
            
            
        }

	

}

?>
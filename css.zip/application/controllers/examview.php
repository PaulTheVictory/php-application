<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Examview extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model('login_model','',TRUE);
                $this->load->model('exams_model','',TRUE);
                $this->load->library('table'); 
                $this->load->helper('download');
                 

	}
	
	function index()
	{
		if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in'))
   		{
                    $session_data = $this->session->userdata('loggedin');
                    $session_id = $session_data['id'];
                    $session_role = $session_data['role'];
                    
			
					$data['roleaccess'] = $this->config->item('roleaccess');

					if($data['roleaccess']['uview']!="y"){
						redirect($data['roleaccess']['defaultpage'], 'refresh');
					}
			
                    $data['user'] = $this->login_model->GetUserId();		
		
                        
                    $ide = isset($_GET['id']) ? $_GET['id'] : '';
                    $type = isset($_GET['type']) ? $_GET['type'] : '';
                    $center = isset($_GET['center']) ? $_GET['center'] : '';
                    $data['menu'] = $this->load->view('headermenu', $data, TRUE);
                        if(($ide !== '')&&($type === '')) {
                        
                         $tmpl = array('table_open' => '<table class="sortable" id="studenttable" style="margin-top:0px;">');
                                    $this->table->set_template($tmpl);
                                    $this->table->set_heading('DISTRICT', 'APPLIED');

                       $data['examid'] = $ide;                          
                       $data['examname'] = $this->exams_model->GetEventName($ide);               
                        $this->load->view('header_view', $data);
                        $this->load->view('exam_district_view', $data);
                        $this->load->view('footer_view');

                        } else if(($ide !== '')&&($type !== '')&&($center === '')) {
                            
                            $data['examid'] = $ide;     
                            $data['district'] = $type;     
                            $data['examname'] = $this->exams_model->GetEventName($ide);
                            $tmpl = array('table_open' => '<table class="sortable" id="studenttable" style="margin-top:0px;">');
                                    $this->table->set_template($tmpl);
                                      $this->table->set_heading('LOCATION','APPLIED');
                                    $this->load->view('header_view', $data);
                        $this->load->view('exam_center_view', $data);
                        $this->load->view('footer_view');
                        }else if(($ide !== '')&&($type !== '')&&($center !== '')) {
                            
                            $data['examid'] = $ide;     
                            $data['type'] = $type; 
                            $data['center'] = $center;     
                            $data['examname'] = $this->exams_model->GetEventName($ide);
                            $tmpl = array('table_open' => '<table class="sortable" id="studenttable" style="margin-top:0px;">');
                           $this->table->set_template($tmpl);
                            $this->table->set_heading('S.NO','STUDENT ID','STUDENT NAME','MOBILE','EMAIL');
                           $this->load->view('header_view', $data);
                        $this->load->view('exam_stu_view', $data);
                        $this->load->view('footer_view');
                        } else{
                            redirect('login', 'exammaster');
                        }
                        
                }
   		else
   		{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
   		}
		
	}
         
        
         public function GetRegisteredLists() {
            
            if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')){
                
		$roleaccess = $this->config->item('roleaccess');
		
		$eid = isset($_POST['ide']) ? $_POST['ide'] : '';		
                $ret =  $this->exams_model->GetRegisteredEvents($eid);  
                
                echo ($ret);
                
            }else{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
            }
            
        }
        
        public function GetRegisteredCenterLists() {
            
            if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')){
                
		$roleaccess = $this->config->item('roleaccess');
				
                $eid = isset($_POST['ide']) ? $_POST['ide'] : '';
                $district = isset($_POST['district']) ? $_POST['district'] : '';
                $ret =  $this->exams_model->GetRegisteredCenterEvents($eid,$district);
                echo $ret;
                
            }else{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
            }
            
        }
        
	
public function GetRegisteredStuLists()
{
		
	if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')){
			
		$roleaccess = $this->config->item('roleaccess');
		
		$user = $this->login_model->GetUserId();
		
                $examid = isset($_POST['examid']) ? $_POST['examid'] : '';
                $type = isset($_POST['type']) ? $_POST['type'] : '';
                $center = isset($_POST['center']) ? $_POST['center'] : '';
		$searchcol = isset($_POST['searchcol']) ? $_POST['searchcol'] : '';
		
			$columns = array( 
                            0 =>'studid', 
                            1 =>'sname',
                            2=> 'mobile',
                            3=> 'email'
                        );
				

		$limit = $this->input->post('length');
        $start = $this->input->post('start');
        $order = $columns[$this->input->post('order')[0]['column']];
        $dir = $this->input->post('order')[0]['dir'];
  
        $totalData = $this->exams_model->GetRegisterdEvents_count($examid,$type,$center);
            
        $totalFiltered = $totalData; 
            
        if(empty($this->input->post('search')['value']))
        {            
            $posts = $this->exams_model->GetAllRegisterdEvents($limit,$start,$order,$dir,$examid,$type,$center);
        }
        else {
            $search = $this->input->post('search')['value']; 

            $posts =  $this->exams_model->GetRegisteredEvents_search($limit,$start,$search,$order,$dir,$examid,$type,$searchcol,$center);

            $totalFiltered = $this->exams_model->GetRegisteredEvents_search_count($search,$examid,$type,$searchcol,$center);
        }

        $data = array();$i=1;
        if(!empty($posts))
        {
            foreach ($posts as $post)
            {

                 $nestedData['ide'] =$i;
                $nestedData['studid'] = '<a target="_blank" href="studentprofile?sid='.$post->sid.'">'.$post->studid.'</a>';  
                $nestedData['sname'] =  strtoupper($post->sname);
                $nestedData['mobile'] = $post->mobile;
		$nestedData['email'] = $post->email;

                
                $data[] = $nestedData;
                $i++;

            }
        }
          
        $json_data = array(
                    "draw"            => intval($this->input->post('draw')),  
                    "recordsTotal"    => intval($totalData),  
                    "recordsFiltered" => intval($totalFiltered), 
                    "data"            => $data   
                    );
            
        echo json_encode($json_data); 
			
	}else{
			
		//If no session, redirect to login page
		redirect('login', 'refresh');
			
	}
		
}
        
      
  
   public function export(){
            
            if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')){

				
				$roleaccess = $this->config->item('roleaccess');
		
				if(isset($roleaccess['Exam Master'][3]) && $roleaccess['Exam Master'][3]=="y"){
				
                                    $ide = $this->input->get('examid', true);
                                    $type = isset($_GET['type']) ? $_GET['type'] : '';
                                    $center = isset($_GET['center']) ? $_GET['center'] : '';

                                    $html .= '<tr><td>S.no</td><td>Event Name</td><td>Course Name</td><td>Event District</td><td>Event Location</td><td>Name</td><td>Student ID</td><td>Email</td><td>Country Code</td><td>Mobile Number</td><td>Date of Birth:</td><td>Gender</td><td>Nationality</td><td>Category</td><td>Aadhar Number</td><td>Fathers Name</td><td>Country Code</td><td>Fathers Phone</td><td>Fathers Email</td><td>Fathers Occupation</td><td>Mothers Name</td><td>Country Code</td><td>Mothers Phone</td><td>Mothers Email</td><td>Mothers Occupation</td><td>Communication Contact</td><td>Blood Group</td><td>Class Studying / Complete</td><td>Stream</td><td>Name of School Last Studied / Studying</td><td>Address Line</td><td>Country</td><td>House / Appartment Name</td><td>Place / Street</td><td>Post Office</td><td>District</td><td>State</td><td>Country</td><td>Pincode</td><td>Country Code</td><td>Whatsapp Number</td><td>Guardian Name</td><td>Account Holder Name</td><td>Bank Name</td><td>Branch</td><td>IFSC Code</td><td>Bank Account Number</td></tr>';

                                     if($ide != ""){
                                          $ret = $this->exams_model->ExportEventRegistrations($ide,$type,$center);

                                           $i = 1;
                                          foreach ($ret as $key=>$val){
                                             $html .= '<tr><td>'.$i.'</td><td>'.$val['examname'].'</td><td>'.$val['coursename'].'</td><td>'.$val['district'].'</td><td>'.$val['location'].'</td><td>'.$val['sname'].'</td><td>'.$val['sname'].'</td><td>'.$val['studid'].'</td><td>'.$val['email'].'</td><td>'.$val['mcode'].'</td><td>'.$val['contact'].'</td><td>'.$val['dob'].'</td><td>'.$val['gender'].'</td><td>'.$val['nationality'].'</td><td>'.$val['category'].'</td><td>'.$val['aadharnumber'].'</td><td>'.$val['fathername'].'</td><td>'.$val['fathercode'].'</td><td>'.$val['fatherphone'].'</td><td>'.$val['fatheremail'].'</td><td>'.$val['fatheroccupation'].'</td><td>'.$val['mothername'].'</td><td>'.$val['mothercode'].'</td><td>'.$val['motherphone'].'</td><td>'.$val['motheremail'].'</td><td>'.$val['motheroccupation'].'</td><td>'.$val['communicationcontact'].'</td><td>'.$val['bloodgroup'].'</td><td>'.$val['classstudy'].'</td><td>'.$val['stream'].'</td><td>'.$val['schoolcollegename'].'</td><td>'.$val['eduaddress'].",".$val['edulandmark'].",".$val['edudistrict'].",".$val['edustate'].",".$val['edupost'].",".$val['edupincode'].'</td><td>'.$val['educountry'].'</td><td>'.$val['housenameno'].'</td><td>'.$val['landmark'].",".$val['contactaddress'].'</td><td>'.$val['contactpost'].'</td><td>'.$val['contactdistrict'].'</td><td>'.$val['contactstate'].'</td><td>'.$val['contactcountry'].'</td><td>'.$val['contactpincode'].'</td><td>'.$val['wacode'].'</td><td>'.$val['whatsappno'].'</td><td>'.$val['guardianname'].'</td><td>'.$val['accountholdername'].'</td><td>'.$val['bankname'].'</td><td>'.$val['branch'].'</td><td>'.$val['ifsccode'].'</td><td>'.$val['bankaccountno'].'</td></tr>';
                                             $i++;
                                         }
                                     } 
                
                                    $savename = "Event Registrations Student Profile Export".date('d-m-Y-H_i_s');
                                    $html = str_replace('<tr>',"\n",$html);
                                         $html = str_replace('</tr>',"",$html);

                                         $html = str_replace('</th>',"\t",$html);
                                         $html = str_replace('<th>',"",$html);

                                         $html = str_replace('</td>',"\t",$html);
                                         $html = str_replace('<td>',"",$html);


                                    $html = strip_tags($html);

                                    $filename = $savename .".xls";

                                    force_download($filename, $html);
                                }	
            
            }else {
                //If no session, redirect to login page
                redirect('login', 'refresh');
            }
            
        }

}
?>

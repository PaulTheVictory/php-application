<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Addschools extends CI_Controller {

	function __construct() {
            
		parent::__construct();
		$this->load->model('login_model','',TRUE);
                $this->load->model('allocation_model','',TRUE);$this->load->helper('form');

	}
	
	function index() {
            
            if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')) {

                $session_data = $this->session->userdata('loggedin');
                $session_id = $session_data['id'];
                $session_role = $session_data['role'];
                $data['user'] = $this->login_model->GetUserId();

				$data['roleaccess'] = $this->config->item('roleaccess');
			
				if($data['roleaccess']['Schools Add'][3]!="y"){
					redirect($data['roleaccess']['defaultpage'], 'refresh');
				}
				

                $data['menu'] = $this->load->view('headermenu', $data, TRUE);

                $this->load->view('header_view', $data);
                $this->load->view('addschools_view', $data);
                $this->load->view('footer_view');
            } else {
                //If no session, redirect to login page
                redirect('login', 'refresh');
            }
            
        }
        
      public function schoolSubmit() {
          
          if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')) {
        $this->load->library('form_validation');
			  
		$roleaccess = $this->config->item('roleaccess');
		if(isset($roleaccess['Schools Add'][0]) && $roleaccess['Schools Add'][0]=="y"){
			
        $this->form_validation->set_rules('sname', 'School Name', 'trim|required|xss_clean|callback_alpha_numeric_spaces|max_length[100]|is_unique[bscp_schools.sname]');
        $this->form_validation->set_rules('hostel', 'Hostel', 'trim|required|xss_clean|regex_match[/Yes|No/]|max_length[3]');
        $this->form_validation->set_rules('coname', 'Co-Ordinator Name', 'trim|required|xss_clean|callback_alpha_numeric_spaces|max_length[10]');
        $this->form_validation->set_rules('cophone', 'Co-Ordinator Phone', 'trim|required|xss_clean|callback_alpha_numeric_spaces|max_length[50]');
        $this->form_validation->set_rules('address', 'Address', 'trim|required|xss_clean|callback_alpha_numeric_spaces|max_length[100]');
        $this->form_validation->set_rules('district', 'District', 'trim|xss_clean|required|callback_alpha_numeric_spaces|max_length[100]');
        $this->form_validation->set_rules('secondlang', 'Second Language', 'trim|xss_clean|required|callback_alpha_numeric_spaces|max_length[100]');

        if ($this->form_validation->run() == false) {
            $response = array(
                'status' => 'error',
                'message' => validation_errors()
            );
        }
        else {
            $ide = uniqid();
           
            
            $qData = array(
                'id' => $ide,
                'sname' => $this->input->post('sname', true),
                'hostel' => $this->input->post('hostel', true),
                'coname' => $this->input->post('coname', true),
                'cophone' => $this->input->post('cophone', true),
                'address' => $this->input->post('address', true),
                'district' => $this->input->post('district', true),
                'secondlang ' => $this->input->post('secondlang', true),
                'del' => 'n',
                'created_at' => date('Y-m-d H:i:s'),
            );
            
            

            $id = $this->allocation_model->AddSchool($qData);
          

            $response = array(
                'status' => 'success',
                'message' => "Schools Created Successfully.",
                'ide' => $ide
            );
        }

          echo  json_encode($response);
			
		}else {

		  $response = array(
				'status' => 'error',
				'message' => 'User Permission denied'
			);
			echo  json_encode($response);
		}
			  
          
        }else {
                //If no session, redirect to login page
                redirect('login', 'refresh');
            }
    }
    
        
       

}
?>
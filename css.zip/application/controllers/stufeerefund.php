<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Stufeerefund extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model('login_model','',TRUE);
                $this->load->model('student_model','',TRUE);
		$this->load->model('payment_model','',TRUE);
                 $this->load->helper('form');

	}
	
	function index()
	{
		if($this->session->userdata('loggedin'))
   		{
                    $session_data = $this->session->userdata('loggedin');
                    $session_id = $session_data['id'];
                    $session_role = $session_data['role'];
                    
                    $data['user'] = $this->login_model->GetUserId();		
		
					if($session_role === 'student') {
						
						$feepayid = $this->input->get('id');
                                                $data['type'] = $this->input->get('type');
                                               // $ischkrefund = $this->payment_model->isCheckRefundStatus($feepayid);
                                              // if($ischkrefund === 'c') { redirect('stufeepayments', 'refresh'); }
						
						$data['crid'] = $feepayid;
												
						$data['feepayments'] = $this->student_model->GetFeePayments($data['user']['id'],$data['user']['qualificationid'],$feepayid);
						
						$this->load->view('header', $data);
						$refundid = $this->payment_model->isCheckRefund($feepayid);
                                                if($refundid === "") {
						$data['stuprofile'] =  $this->student_model->GetStudentProfile($data['user']['id']);
                                                } else {
                                                 $data['stuprofile'] =  $this->payment_model->GetRefund($refundid);       
                                                }
						$this->load->view('student_feerefund_view', $data);
						$this->load->view('footer');
                            
                     }else{
						//If no session, redirect to login page
     					redirect('dashboard', 'refresh');
					}
		}
   		else
   		{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
   		}
		
	}
        
        public function addRefund(){
		
		if($this->session->userdata('loggedin'))
   		{
			
                    $session_data = $this->session->userdata('loggedin');
                    $session_id = $session_data['id'];
                    $session_role = $session_data['role'];
                    	
		
			if(($session_role === 'student') || ($this->session->userdata('loggedin')&& $this->session->userdata('adlog_in')) ) {
     

                                $this->load->library('form_validation');
                                $this->form_validation->set_rules('cid', 'Course ID', 'trim|required|xss_clean|callback_alpha_numeric|max_length[100]');
                                $this->form_validation->set_rules('crid', 'Request ID', 'trim|required|xss_clean|callback_alpha_numeric|max_length[100]');
                                $this->form_validation->set_rules('center', 'Center', 'trim|xss_clean|required|callback_alpha_numeric_spaces|max_length[100]');
                                $this->form_validation->set_rules('sid', 'Student ID ', 'trim|required|xss_clean|numeric|max_length[50]');
                                $this->form_validation->set_rules('reason', 'Reason For Refund', 'trim|required|xss_clean|max_length[500]');
                                $this->form_validation->set_rules('housenameno', 'House / Appartment no', 'trim|required|xss_clean|max_length[100]');
                                $this->form_validation->set_rules('contactaddress', 'Place / Street', 'trim|required|xss_clean|max_length[100]');
                                $this->form_validation->set_rules('contactpost', 'Post office', 'trim|required|xss_clean|max_length[100]');
                                $this->form_validation->set_rules('contactcountry', 'Country', 'trim|required|xss_clean|max_length[100]');
                                $this->form_validation->set_rules('contactstate', 'State', 'trim|required|xss_clean|max_length[50]');
                                $this->form_validation->set_rules('contactdistrict', 'District', 'trim|required|xss_clean|max_length[50]');
                                $this->form_validation->set_rules('contactpincode', 'Pincode', 'trim|required|xss_clean|number|max_length[10]');
                                $this->form_validation->set_rules('accountholdername', 'Account Holder Name', 'trim|xss_clean|max_length[50]');
                                $this->form_validation->set_rules('bankname', 'Bank Name', 'trim|required|xss_clean|max_length[50]');
                                $this->form_validation->set_rules('branch', 'Branch', 'trim|required|xss_clean|max_length[50]');
                                $this->form_validation->set_rules('ifsccode', 'IFSC Code', 'trim|required|xss_clean|max_length[50]');
                                $this->form_validation->set_rules('bankaccountno', 'Bank Account Number', 'trim|numeric|xss_clean|max_length[50]');
                                $this->form_validation->set_rules('doj', 'Date Of Joining', 'trim|xss_clean|max_length[50]');
                                $this->form_validation->set_rules('batch', 'Batch Name', 'trim|xss_clean|max_length[50]');
                                
                                if($session_role === 'student') {
                                    if(!isset($_FILES["file"]) || empty($_FILES["file"]['name'])) $this->form_validation->set_rules('file', 'Upload Image Of Bank Passbook', 'trim|required|xss_clean');
                                }
                                
                                if ($this->form_validation->run() === false) {
                                    $response = array(
                                        'status' => 'error',
                                        'message' => validation_errors()
                                    );
                                } else {
                                    
                                    $stat = $this->payment_model->CourseRequestRefundStatus($this->input->post('crid'));
                                    if($stat !=="1"){
                                        
                                        $response = array(
                                        'status' => 'error',
                                        'message' => 'Duplicate Refund Request Found'
                                        );
                                    }else{
                                        
                                          $stuid =  isset($_POST['stuid']) ? $_POST['stuid'] : '';
                                            if($stuid === "") {
                                                $user = $this->login_model->GetUserId();
                                            } else {
                                                $user['id'] = $stuid;  
                                            }
                                            
                                         $ide = uniqid();
                                         
                                        // Upload Bank Passbook
	  
                                        $marksheets = array();

                                        if(isset($_FILES["file"]) && !empty($_FILES["file"]['name'])){
                                            
                                                $total = count($_FILES['file']['name']);

                                                $imageExtensions = array('.jpg', '.jpeg', '.png', '.pdf');

                                                for( $i=0 ; $i < $total ; $i++ ) {

                                                $file_size = $_FILES['file']['size'][$i];

                                                if ((number_format($file_size / 1048576, 2) > 1)){      
                                                    
                                                    $response = array(
                                                        'status' => 'error',
                                                        'message' => 'Maximum each file size upto 1MB'
                                                        );
                            
                                                        echo json_encode($response);
                                                        exit(0);
                                                }

                                                }
                                                
                                              

                                                $dirname = FCPATH.'docs/refund/'.$user['id'].'/';

                                                for( $i=0 ; $i < $total ; $i++ ) {

                                                $fileExtension = strrchr($_FILES['file']['name'][$i], ".");
                                                $fileName = $ide.$fileExtension;

                                                $marksheets[$i] = $fileName;	

                                                $destinationfull = $dirname . $fileName;

                                                if(!file_exists($dirname)) mkdir($dirname,0777);

                                                //if(file_exists($dirname.$prefileName)) unlink($dirname.$prefileName);

                                                if (in_array(strtolower($fileExtension), $imageExtensions)) {

                                                        $resultfull = move_uploaded_file($_FILES['file']['tmp_name'][$i],$destinationfull);

                                                        if(!$resultfull){
                                                            
                                                                $response = array(
                                                                'status' => 'error',
                                                                'message' => 'Upload Image Upload Failed'
                                                                );
                            
                                                                echo json_encode($response);
                                                                exit(0);

                                                        }

                                                }else{

                                                         $response = array(
                                                                'status' => 'error',
                                                                'message' => 'File format JPG, JPEG and PNG only'
                                                                );
                            
                                                                echo json_encode($response);
                                                                exit(0);

                                                }

                                                }

                                        } 
                                    
                                  
                                   
                                    
                                    $qData = array(
                                        'id' => $ide,
                                        'studentid' => $user['id'],
                                        'studid' => $this->input->post('sid'),
                                        'courseid' => $this->input->post('cid'),
                                        'requestid' => $this->input->post('crid'),
                                        'center' => $this->input->post('center'),
                                        'reason' => $this->input->post('reason'),
                                        'doj' => $this->input->post('doj'),
                                        'batch' => $this->input->post('batch'),
                                        'housenameno' => $this->input->post('housenameno'),
                                        'contactaddress' => $this->input->post('contactaddress'),
                                        'contactpost' => $this->input->post('contactpost'),
                                        'contactcountry' => $this->input->post('contactcountry'),
                                        'contactstate' => $this->input->post('contactstate'),
                                        'contactdistrict' => $this->input->post('contactdistrict'),
                                        'contactpincode' => $this->input->post('contactpincode'),
                                        'accountholdername' => '',
                                        'bankname' => $this->input->post('bankname'),
                                        'branch' => $this->input->post('branch'),
                                        'ifsccode' => $this->input->post('ifsccode'),
                                        'bankaccountno' => $this->input->post('bankaccountno'),
                                        'status' => 'w',
                                        'type' => ($session_role === 'student')?"Student":"Admin",
                                        'requestedrefundamt' => '0',
                                        'created_at' => date('Y-m-d H:i:s')
                                    );
                                     $type = $this->input->post('type');
                                    $this->payment_model->AddRefundApplication($qData,$type);
                                    $response = array(
                                        'status' => 'success',
                                        'message' => 'Refund Added Successfully'
                                    );


                                }
                        }
                           echo json_encode($response);
			
                    }else{
                        //If no session, redirect to login page
                        redirect('login', 'refresh');
                    }
		
                }else{
                            //If no session, redirect to login page
                            redirect('login', 'refresh');
                    }
        }
	
	
}
?>

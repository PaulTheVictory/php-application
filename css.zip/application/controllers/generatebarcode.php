<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Generatebarcode extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model('login_model','',TRUE);
                $this->load->model('library_model','',TRUE);
                $this->load->library('table');
				$this->load->helper('form');
	
	}
	
	function index()
	{
		if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in'))
   		{
                    $session_data = $this->session->userdata('loggedin');
                    $session_id = $session_data['id'];
                    $session_role = $session_data['role'];
                    
                    $data['user'] = $this->login_model->GetUserId();		
		
					$data['roleaccess'] = $this->config->item('roleaccess');

					if($data['roleaccess']['Generate Barcodes'][3]!="y"){
						redirect($data['roleaccess']['defaultpage'], 'refresh');
					}
			
					//$string = '2342347';
					//$genbarcode = $this->set_barcode($string);
					//if($genbarcode)$data['barcode'] = $string.'.png'; else $data['barcode'] = "";
			
			
					$tmpl = array('table_open' => '<table class="sortable sorting disabled table" id="usertable" style="margin-top:0px;">');
					$this->table->set_template($tmpl);
					$this->table->set_heading('S.NO', 'TOTAL COUNT', 'BARCODE FROM','BARCODE TO','CREATED','ACTIONS');
			
					$data['bcfromto'] = $this->library_model->GetBarcodefromto();

						
					$data['menu'] = $this->load->view('headermenu', $data, TRUE);
																		
					$this->load->view('header',$data);
					$this->load->view('generatebarcode_view', $data);
					$this->load->view('footer');
                    
		}
   		else
   		{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
   		}
		
	}
      
	
	public function GetBarcodes() {
            
		if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in') ){

			$ret =  $this->library_model->GetBarcodes();
			echo $ret;

		}else{
		//If no session, redirect to login page
		redirect('login', 'refresh');
		}

	}
	
	
	public function barcodegenerate()
	{
		
		if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in'))
   		{
			
			$bccount = $this->input->post("bccount",true);
			$bcto = $this->input->post("bcto",true);
			
			$ret =  $this->library_model->GenerateBarcode($bccount,$bcto);
			echo json_encode($ret);
							
		}else{
			//If no session, redirect to login page
			redirect('login', 'refresh');
		}
		
	}	
	
	
}
?>

<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Students extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model('login_model','',TRUE);
                $this->load->model('student_model','',TRUE);
                 $this->load->library('table'); 
        

	}
	
	function index()
	{
		if($this->session->userdata('loggedin') && ($this->session->userdata('adlog_in') || $this->session->userdata('teachlog_in')))
   		{
			
                    $session_data = $this->session->userdata('loggedin');
                    $session_id = $session_data['id'];
                    $session_role = $session_data['role'];
                    
                    $data['user'] = $this->login_model->GetUserId();	
			
			
					$data['roleaccess'] = $this->config->item('roleaccess');
			
					$current = $this->uri->segment(1);
					if($data['roleaccess']['uview']!="y" && $data['roleaccess']['defaultpage']!=$current){
						redirect($data['roleaccess']['defaultpage'], 'refresh');
					}
			
		
		    //if(($session_role === 'admin')||($session_role === 'teacher')||($session_role === 'CLASS TEACHER')) {	
                    $data['menu'] = $this->load->view('headermenu', $data, TRUE);
                    
                     $tmpl = array('table_open' => '<table class="sortable" id="studenttable" style="margin-top:0px;">');
                                $this->table->set_template($tmpl);
                                $this->table->set_heading('STUDENT ID','STUDENT NAME','EMAIL', 'CONTACT INFO', 'QUALIFICATION', 'ACTIONS');
						
                    $this->load->view('header_view', $data);
                    $this->load->view('students_view', $data);
                    $this->load->view('footer_view');
                        //}
		}
   		else
   		{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
   		}
		
	}
        
        public function GetStudentLists() {
            
            if($this->session->userdata('loggedin') && ($this->session->userdata('adlog_in') || $this->session->userdata('teachlog_in'))){
                
                $ret =  $this->student_model->GetAllStudents();
                echo $ret;
                
            }else{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
            }
            
        }
        
        
           public function DelStudent(){
            
            if($this->session->userdata('loggedin') && ($this->session->userdata('adlog_in') || $this->session->userdata('teachlog_in'))){

                $ide = isset($_GET['ide']) ? $_GET['ide'] : '';

                if($ide != ""){
                     $ret = $this->student_model->DelStudent($ide);
                } else {
                    $ret = array(0 => "fail");
                }

                echo json_encode($ret);
            
            }else {
                //If no session, redirect to login page
                redirect('login', 'refresh');
            }
            
        }
	
	
	public function allstudentsList()
{

		
	if($this->session->userdata('loggedin') && ($this->session->userdata('adlog_in')|| $this->session->userdata('teachlog_in'))){
			
		$user = $this->login_model->GetUserId();
		$batches = $user['batches'];
		$roleaccess = $this->config->item('roleaccess');
		
		
		$columns = array( 
                            0 =>'studid', 
                            1 =>'sname',
                            2=> 'email',
                            3=> 'contact',
							4=> 'name',
                        );

		$limit = $this->input->post('length');
        $start = $this->input->post('start');
        $order = $columns[$this->input->post('order')[0]['column']];
        $dir = $this->input->post('order')[0]['dir'];
		
		$searchcol = $this->input->post('searchcol', true);
  
        $totalData = $this->student_model->allstudents_count($batches);
            
        $totalFiltered = $totalData; 
            
        if(empty($this->input->post('search')['value']))
        {            
            $posts = $this->student_model->allstudents($limit,$start,$order,$dir,$batches);
        }
        else {
            $search = $this->input->post('search')['value']; 

            $posts =  $this->student_model->allstudents_search($limit,$start,$search,$order,$dir,$searchcol,$batches);

            $totalFiltered = $this->student_model->allstudents_search_count($search,$searchcol,$batches);
        }

        $data = array();
        if(!empty($posts))
        {
            foreach ($posts as $post)
            {
				if($roleaccess['uview']=="y") $sname = '<a data-id="'.$post->id.'" class="noedit idValue" style="float:left;padding:0px;font-size:15px;text-align:left;line-height:20px" href="'.base_url().'studentprofile?sid='.$post->id.'">'.$post->sname.'</a>';
				else $sname = '<a class="noedit idValue" style="float:left;padding:0px;font-size:15px;text-align:left;line-height:20px" href="javascript:void(0);">'.$post->sname.'</a>';
					
                $nestedData['sname'] = $sname;
                $nestedData['studid'] = $post->studid;
                $nestedData['email'] = $post->email;
                $nestedData['contact'] = $post->contact;
                $nestedData['city'] = $post->city;
				
				$actions = "";
				
				if($roleaccess['uview']=="y") $actions = '<a class="noedit" id="'.$post->id.'" href="'.base_url().'studentprofile?sid='.$post->id.'"><img style="padding:5px 10px" src="'.$this->config->item('web_url')."images/edit.png".'"></a>';
				
				if($roleaccess['udelete']=="y") $actions .= '<a class="del noedit" id="'.$post->id.'" href="javascript:void(0)"><img style="padding:5px 10px" src="'.$this->config->item('web_url')."images/delete.png".'"></a>';
				
				if($roleaccess['uview']=="y") $actions .= '<a class=" noedit" id="'.$post->id.'" href="'.base_url().'studentprofile?sid='.$post->id.'"><img style="padding:5px" src="'.$this->config->item('web_url')."images/view.png".'"></a>';
				
				if($actions=="") $actions .= "-";
				
				
				$nestedData['id'] = $actions;
				
				$paymentmode = $post->paymentmode;
				
				if((strcmp($paymentmode,"online")===0 && strcmp($paymentmode,"Online")!==0) || (strcmp($paymentmode,"online")!==0 && strcmp($paymentmode,"Online")!==0)) $receiptno = ""; else $receiptno = $post->receiptno;
				
				if($post->referenceNo=="1") $nestedData['referenceNo'] = ""; else $nestedData['referenceNo'] = $post->referenceNo;
				
                $nestedData['paymentamount'] = $post->paymentamount;
				                
				$paymentdate = date('j M Y h:i a',strtotime($post->paymentdate));
				
				if($post->statuscode=="F"){
					$statuscode = "Failed - ". $post->statusdesc;$receiptno = "";
				}else if($post->statuscode=="S"){
					$statuscode = "Success";
				}else{
					$statuscode = "Failed";$receiptno = "";
				}
				
				$nestedData['statuscode'] = $statuscode;
								
                $nestedData['receiptno'] = $receiptno;
				
				$action = "";
				if($post->statuscode=="" || $post->statuscode=="1"){
					
					$action = '<a href="javascript:void(0);" class="fetchwordlinepg" data-orderid="'.$post->referenceid.'" data-studentid="'.$post->studentid.'" data-courseid="'.$post->cid.'"><button>Fetch</button></a>';
					$paymentdate = "";				
				}
				
				$nestedData['paymentdate'] = $paymentdate;
								
				$nestedData['action'] = $action;
                //$nestedData['body'] = substr(strip_tags($post->body),0,50)."...";
                
                $data[] = $nestedData;

            }
        }
          
        $json_data = array(
                    "draw"            => intval($this->input->post('draw')),  
                    "recordsTotal"    => intval($totalData),  
                    "recordsFiltered" => intval($totalFiltered), 
                    "data"            => $data   
                    );
            
        echo json_encode($json_data); 
			
		
			
	}else{
			
		//If no session, redirect to login page
		redirect('login', 'refresh');
			
	}
		
}
    	
	
	
}
?>

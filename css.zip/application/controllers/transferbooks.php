<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Transferbooks extends CI_Controller {

	function __construct() {
            
		parent::__construct();
		
                $this->load->model('login_model','',TRUE);
                $this->load->model('library_model','',TRUE);
				$this->load->helper('form');
				$this->load->library('table');
				$this->load->helper('My_datatable_helper');

	}
	
	function index() {
            
            if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')) {

                $session_data = $this->session->userdata('loggedin');
                $session_id = $session_data['id'];
                $session_role = $session_data['role'];
                $data['user'] = $this->login_model->GetUserId();

				$data['roleaccess'] = $this->config->item('roleaccess');
			
				if($data['roleaccess']['Transfer Books'][3]!="y"){
					redirect($data['roleaccess']['defaultpage'], 'refresh');
				}
				
				$center = $this->input->get("center",true);
				
				$data['center'] = $center;
				
				$data['issueddetails'] = $this->library_model->GetIssuedBookDetails($studentid);
				
				$data['units'] = $this->library_model->GetAllCenters("",'option',$data['user']['lcenters']);               

				$data['menu'] = $this->load->view('headermenu', $data, TRUE);
                $this->load->view('header', $data);
                $this->load->view('transferbooks_view', $data);
                $this->load->view('footer');
				
            } else {
                //If no session, redirect to login page
                redirect('login', 'refresh');
            }
            
        }
        
	public function GetIssuedBookList() {
            
		if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in') ){
			
			$data['user'] = $this->login_model->GetUserId();
			
			$stuid = $this->input->post('stuid');
			
			$result =  $this->library_model->GetIssuedBookList($stuid);

			$row = array();
			
			$sno = 1;
			
			foreach($result as $key=>$col){			
				
				$booktype = check_booktype($col->booktype);
				$duedate = change_DateFormat($col->duedate);
				$remaindue = get_bookremaindue($col->duedate);
					
				$row[] = array($sno,$col->barcode,$col->bookname,$col->price,$booktype,$duedate,$remaindue);
									
				$sno++;
				
			}
									
			$ret = array("tabledata"=>$row);
			echo json_encode($ret);
			
		}else{
		//If no session, redirect to login page
		redirect('login', 'refresh');
		}

	}	

	
	public function getstudentdetails() {
            
        if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')) {
			
			$roleaccess = $this->config->item('roleaccess');
			
			if(isset($roleaccess['Issue Books'][3]) && $roleaccess['Issue Books'][3]=="y"){
			         
				$barcode = $this->input->post("barcode",true);
				$type = $this->input->post("type",true);
			
				if($type!="staff"){
					$studentdetails = $this->library_model->GetStudentProfile($barcode); //print_r($studentdetails);exit;
				}else{
					$studentdetails = $this->library_model->GetStaffProfile($barcode);
				}
			
			if(empty($studentdetails)){
				
				if($type!="staff"){$uname = "Student";}else{$uname = "Staff";}
				
					$response = array(
						'status' => 'error',
						'message' => $uname.' not found'
					);
				
				echo json_encode($response);
				
			}else{
				
				$response = array(
					'status' => 'success',
					'data' => $studentdetails
				);
				
				echo json_encode($response);
			}
                

			 } else {

 					$response = array(
						'status' => 'error',
						'message' => 'User Permission Denied'
					);
                    echo json_encode($response);
				
                }
              
               
            }else{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
            }
            
    }
	
	public function GetIssueBookDetails() {
            
		if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in') ){
			
			$data['user'] = $this->login_model->GetUserId();
			
			$stuid = $this->input->post('stuid');
			
			$result =  $this->library_model->GetIssueBookDetails($stuid);

			$row = array();
			
			$sno = 1;
			
			foreach($result as $key=>$col){			
				
				$booktype = check_booktype($col->booktype);
				$duedate = change_DateFormat($col->duedate);
				$remaindue = get_bookremaindue($col->duedate);
					
				$row[] = array($sno,$col->barcode,$col->bookname,$col->price,$booktype,$duedate,$remaindue);
									
				$sno++;
				
			}
									
			$ret = array("tabledata"=>$row);
			echo json_encode($ret);
			
		}else{
		//If no session, redirect to login page
		redirect('login', 'refresh');
		}

	}
	
	
	public function transferbarcodelistpreview(){
        
		$roleaccess = $this->config->item('roleaccess');
			
			if(isset($roleaccess['Transfer Books'][3]) && $roleaccess['Transfer Books'][3]=="y"){
				
			
				//$stuid = $this->input->post('stuid', true);
				$barcode = $this->input->post('barcode', true);
                $center = $this->input->post('center', true);
                //$totalbooks = $this->input->post('totalbooks', true);
                //$type = $this->input->post('type', true);
				
				$row = $qData = array();
				
				$sno = 1;
				
				//print_r($barcodes);exit;
			
				$barcodedetails = $this->library_model->CheckBarcodeExists($barcode,$center);
												
				if(empty($barcodedetails)){
					$response = array(
						'status' => 'error',
						'message' => "Book not found.",
						'tabledata' => $row,
						'tablerow' => $qData
						);
					echo json_encode($response);
					exit(0);
				}
				
				if($center==$barcodedetails['center']){
					$response = array(
						'status' => 'error',
						'message' => "Book center is same as destination",
						'tabledata' => $row,
						'tablerow' => $qData
						);
					echo json_encode($response);
					exit(0);
				}
			
					
			$bookname = $barcodedetails['bookname'];
				
			$centerfrom = $barcodedetails['centerfrom'];
			$transferon = $barcodedetails['transferon'];	
				
			if($centerfrom!="") $centerfrom = $centerfrom."|".$barcodedetails['center']; else $centerfrom = $barcodedetails['center'];	
			if($transferon!="") $transferon = $transferon."|".date('Y-m-d H:i:s'); else $transferon = date('Y-m-d H:i:s');

				
			$qData = array(
				'center' => $center,
				'barcode' => $barcode,
				'centerfrom' => $centerfrom,
				'transferon' => $transferon,
			);
								
			$row = array('<p class="sno"></p>',$barcode,$bookname,$barcodedetails['center'],$center,'<a class="del noedit" barcode="'.$barcode.'" href="javascript:void(0)"><img style="padding:5px 10px" src="images/delete.png"></a>');				

			$response = array(
			'status' => 'success',
			'message' => "Book Added.",
				'tabledata' => $row,
				'tablerow' => $qData
			);	
									
		 	echo json_encode($response);	
				
				
		 } else {

			$response = array(
				'status' => 'error',
				'message' => 'User Permission Denied'
			);
			echo json_encode($response);
		}

          //return $response;
    }
	
	public function UpdateTransferBooks(){
        
		$roleaccess = $this->config->item('roleaccess');
			
			if(isset($roleaccess['Transfer Books'][3]) && $roleaccess['Transfer Books'][3]=="y"){
								
            $qData = $this->input->post('qData', true);

			if(empty($qData)){
				$response = array(
                'status' => 'fail',
                'message' => "No Books Added."
            	);
				echo json_encode($response);
				exit(0);
			}	
				
            $result = $this->library_model->UpdateTransferBooks($qData);
              
			if($result=="success"){
				$response = array(
                'status' => 'success',
                'message' => "Books Transfered Successfully."
            	);
			}else if($result=="fail"){
				$response = array(
                'status' => 'fail',
                'message' => "Books Transfer Failed."
            	);
			}
            
				echo json_encode($response);
				
		 } else {

			$response = array(
				'status' => 'error',
				'message' => 'User Permission Denied'
			);
			echo json_encode($response);
		}

    }
	
	
}
?>
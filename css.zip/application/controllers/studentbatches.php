<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Studentbatches extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model('login_model','',TRUE);
		$this->load->model('exams_model','',TRUE);
		$this->load->library('table'); $this->load->helper('form');
                 

	}
	
	function index()
	{
		if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in'))
   		{
                    $session_data = $this->session->userdata('loggedin');
                    $session_id = $session_data['id'];
                    $session_role = $session_data['role'];
                    
                    $data['user'] = $this->login_model->GetUserId();
			
					$currentpage = $this->uri->segment(1);
					$data['roleaccess'] = $this->config->item('roleaccess');
			

                    $data['menu'] = $this->load->view('headermenu', $data, TRUE);
			
			 		$batchname = $this->input->get('bname', true);
					
					$data['allcourses'] = $this->exams_model->GetAllCourses('');
			
			
					$this->load->view('header_view', $data);
			
					if($batchname==""){
						 
						if($data['roleaccess']['Batches'][3]!="y" && $data['roleaccess']['defaultpage']!=$currentpage){
							redirect($data['roleaccess']['defaultpage'], 'refresh');
						}
						
						 $this->load->view('studentbatches_view', $data);
						
					}else{
						
						if($data['roleaccess']['Batches'][1]!="y"){
							redirect($data['roleaccess']['defaultpage'], 'refresh');
						}
						
						$data['batch'] = $this->exams_model->GetBatchdetails($batchname);
						$this->load->view('studentbatchesview_view', $data);
					}
								
			 		$this->load->view('footer_view');
			                   

                        
                }else{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
   		}
		
	}
	
    public function batchesList()
    {

		
	if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')){
			
		
		$roleaccess = $this->config->item('roleaccess');
		
		$user = $this->login_model->GetUserId();
		$batches = $user['batches'];
		
		$columns = array( 
                            0 =>'id',
							1 =>'batchno',
                            2 =>'coursename',
                            3=> 'batchname',
			    			4=> 'coordinatoname',
                        );

		$limit = $this->input->post('length');
        $start = $this->input->post('start');
        $order = $columns[$this->input->post('order')[0]['column']];
        $dir = $this->input->post('order')[0]['dir'];
		
		$searchcol = $this->input->post('searchcol', true);
  
        $totalData = $this->exams_model->batches_count($batches);
            
        $totalFiltered = $totalData; 
            
        if(empty($this->input->post('search')['value']))
        {            
            $posts = $this->exams_model->batcheslist($limit,$start,$order,$dir,$batches);
        }
        else {
            $search = $this->input->post('search')['value']; 

            $posts =  $this->exams_model->batcheslist_search($limit,$start,$search,$order,$dir,$searchcol,$batches);

            $totalFiltered = $this->exams_model->batcheslist_search_count($search,$searchcol,$batches);
        }

        $data = array();
        if(!empty($posts))
        {
            foreach ($posts as $post)
            {

                $nestedData['sno'] = '<p class="sno"></p>';
				$nestedData['batchno'] = $post->batchno;  
				
				if($roleaccess['uedit']=="y") $batchname = '<a href="'.base_url().'studentbatches?bname='.$post->batchname.'">'.ucwords($post->batchname).'</a>';
				else $batchname = '<a class="noedit" href="javascript:void(0);">'.ucwords($post->batchname).'</a>';
				
                $nestedData['batchname'] = $batchname;                
                $nestedData['coname'] = $post->coordinatoname;
                $nestedData['coursenames'] = str_replace("|",", ",$post->coursename);
				//$examdate = date('j M Y',strtotime($post->date));
                //$nestedData['examdate'] = $examdate;
								
				$action = "";
				
        		if($roleaccess['uedit']=="y") $action = '<a class="noedit" href="'.base_url().'studentbatches?bname='.$post->batchname.'"><img style="padding:5px" src="images/view.png"> </a>';
				if($roleaccess['udelete']=="y") $action .= '<a class="del" id="'.$post->batchname.'" href="javascript:void(0)"><img style="padding:5px 10px" src="'.$this->config->item('web_url')."images/delete.png".'"></a>';
		
				if($action=="") $action .= "-";
				
                $nestedData['actions'] = $action;
            
                
                $data[] = $nestedData;

            }
        }
          
        $json_data = array(
                    "draw"            => intval($this->input->post('draw')),  
                    "recordsTotal"    => intval($totalData),  
                    "recordsFiltered" => intval($totalFiltered), 
                    "data"            => $data   
                    );
            
        echo json_encode($json_data); 
			
	}else{
			
		//If no session, redirect to login page
		redirect('login', 'refresh');
			
	}
		
    }
	
	public function addBatch(){
		
		if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in'))
   		{
			

			$bname = $this->input->post('bname');
			$coursenames = $this->input->post('selcnames');
			$courseids = $this->input->post('bcourses');
			$coname = $this->input->post('coname');
			
			//print_r($courseids);exit;
			
				$this->load->library('form_validation');

				if(empty($courseids)){
					$this->form_validation->set_rules('bcourses', 'Courses', 'trim|xss_clean|required');
				}
				$this->form_validation->set_rules('coname', 'Co-ordinator Name', 'trim|xss_clean|required');
				$this->form_validation->set_rules('bname', 'Batch Name', 'trim|required|xss_clean|callback_alpha_numeric_spaces|max_length[300]|is_unique[bscp_batches.batchname]');

				if ($this->form_validation->run() == false) {
					$response = array(
						'status' => 'error',
						'message' => validation_errors()
					);
				} else {
					
					//$courseids = implode("|",$courseids);
					$this->exams_model->AddBatch($courseids,$coursenames,$bname,$coname);
					$response = array(
						'status' => 'success',
						'message' => 'Batch Added Successfully'
					);


				}
		   echo json_encode($response);
			
		}else{
                    //If no session, redirect to login page
                    redirect('login', 'refresh');
   		}
		
	}
         
    public function DelBatch(){
            
            if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')){

                $ide = isset($_GET['ide']) ? $_GET['ide'] : '';

                if($ide != ""){
                     $ret = $this->exams_model->DeleteBatch($ide);
                } else {
                    $ret = array(0 => "fail");
                }

                echo json_encode($ret);
            
            }else {
                //If no session, redirect to login page
                redirect('login', 'refresh');
            }
            
        }
	
	
	// Upload Batches
	
	
	public function getBatchResults(){
            
		if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')){
			
			$bname = $this->input->post('bname', true);
			$status = $this->input->post('status', true);
			
			$result = $this->exams_model->GetBatchResults($bname,$status);
			
			$row = array();
			
			$sno = 1;
			
			foreach($result as $key=>$col){
								
				$action = '<a class="del" data-stuid="'.$col->id.'" data-cid="'.$col->ide.'" href="javascript:void(0)"><img style="padding:5px 10px" src="'.$this->config->item('web_url')."images/delete.png".'"></a>';
				
				$row[] = array($sno,$col->studid,$col->sname,$col->coursename,$action);
				
				$sno++;
				
			}
									
			$ret = array("tabledata"=>$row);
			echo json_encode($ret);
						
		}
	}
        
        
  public function uploadBatchresults(){
            
		if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')){

			//print_r($_FILES);exit;
			
			$bname = $this->input->post('bname', true);
			
			if(isset($_FILES["file"]) && !empty($_FILES["file"]['name'])){
				
				$total = count($_FILES['file']['name']);
				
				$validExtensions = array('.xls');
								
				$dirname = FCPATH.'docs/batches/';
								
				$fileExtension = strrchr($_FILES['file']['name'][0], ".");
				$fileName = "batches_".$bname.$fileExtension;
									
				$destinationfull = $dirname . $fileName;
					
				if(!file_exists($dirname)) mkdir($dirname,0777);
							
				if (in_array(strtolower($fileExtension), $validExtensions)) {
					
					$resultfull = move_uploaded_file($_FILES['file']['tmp_name'][0],$destinationfull);
					
					if(!$resultfull){
				    
						$ret = array('status' => "ufail");
						echo json_encode($ret);
						exit(0);
						
					}else{
						
						$result = $this->addBatchresults($fileName,$bname);
						
						$ret = array('status' => "success","message"=>$result['message']);
						echo json_encode($ret);
						exit(0);
						
					}
								
				}else{
					
					$ret = array('status' => "exfail");
					echo json_encode($ret);
					exit(0);
					
				}
					
								
			}else{
				
				$ret = array('status' => "empty");
				echo json_encode($ret);
				exit(0);
				
			}
			
			
		}
	  
  }
	
	
function addBatchresults($fileName,$bname){
	
	ini_set('memory_limit', '-1');	
	ini_set('max_execution_time', 86400);
	
	include './import/excel_reader.php';     // include the class

	// creates an object instance of the class, and read the excel file data
	$excel = new PhpExcelReader;
	$excel->read(FCPATH.'docs/batches/'.$fileName);
		
	$sheet = $excel->sheets[0];
	
	$x = 2;

	//echo $sheet['numRows'];exit;
	
	$arr = array();
	
	$arr["message"] = "";
	
  while($x <= $sheet['numRows']) {
	  	  
	  $sno = isset($sheet['cells'][$x][1]) ? $sheet['cells'][$x][1] : '';
	  $batchno = isset($sheet['cells'][$x][2]) ? $sheet['cells'][$x][2] : '';
	  $studentno = isset($sheet['cells'][$x][3]) ? $sheet['cells'][$x][3] : '';
	  $courseno = isset($sheet['cells'][$x][4]) ? $sheet['cells'][$x][4] : '-';
	  
	  //echo $x.". ".$studentno."<br />";$x++;continue;
		  		  
	  // Add results

	  $result = $this->exams_model->AddBatchResults($bname,$batchno,$studentno,$courseno);
	  
	  
	  if($result['response']=="nostudent" && trim($studentno)!="" && is_numeric($studentno)){
		  $arr["message"] .= "<p><font color='orange'>".$sno.". ".$studentno." - Not found</font></p>";
	  }else if($result['response']=="nocourse" && trim($studentno)!="" && is_numeric($studentno)){
		  $arr["message"] .= "<p><font color='red'>".$sno.". ".$studentno." - Course Not found</font></p>";
	  }else if($result['response']=="nomatch" && trim($studentno)!="" && is_numeric($studentno)){
		  $arr["message"] .= "<p><font color='red'>".$sno.". ".$studentno." - Course or Batch Mismatch</font></p>";
	  }else if($result['response']=="norequest" && trim($studentno)!="" && is_numeric($studentno)){
		  $arr["message"] .= "<p><font color='red'>".$sno.". ".$studentno." - Course Not Applied </font></p>";
	  }else if($result['response']=="nobatchno" && trim($studentno)!="" && is_numeric($studentno)){
		  $arr["message"] .= "<p><font color='red'>".$sno.". ".$studentno." - Batch Not Found </font></p>";
	  }else if($result['response']=="fail" && trim($studentno)!="" && is_numeric($studentno)){
		  $arr["message"] .= "<p><font color='red'>".$sno.". ".$studentno." - Failed</font></p>";
	  }

	  //exit;

	  $x++;
		  		  			  
  }
		
	return $arr;

}
	
	
public function deleteBatchResults(){

	if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')){

		$bname = $this->input->post('bname', true);
		$studentid = $this->input->post('studentid', true);
		$courseid = $this->input->post('courseid', true);

		$result = $this->exams_model->DeleteBatchResults($bname,$studentid,$courseid);			
		echo json_encode($result);

	}
}
	
}
?>

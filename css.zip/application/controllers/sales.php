<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Sales extends CI_Controller {

	function __construct() {
            
		parent::__construct();
		$this->load->model('course_model','',TRUE);
                $this->load->model('login_model','',TRUE);
                 $this->load->library('table'); 

	}
	
	function index() {
            
            if ($this->session->userdata('loggedin')) {

                $session_data = $this->session->userdata('loggedin');
                $session_id = $session_data['id'];
                $session_role = $session_data['role'];
                $data['user'] = $this->login_model->GetUserId();


                $data['menu'] = $this->load->view('headermenu', $data, TRUE);
                
                $type= isset($_GET['type'])?$_GET['type']:'';
                
                if($type == "bill") {
                $tmpl = array('table_open' => '<table class="sortable" id="assettable" style="margin-top:80px">');
                                $this->table->set_template($tmpl);
                                $this->table->set_heading('Bill No','Date','Name','Mobile','Total Amount','Paid', '');
                } else {
                     $tmpl = array('table_open' => '<table class="sortable" id="assettable" style="margin-top:80px">');
                                $this->table->set_template($tmpl);
                                $this->table->set_heading('Est No','Date','Name','Mobile','Total Amount','Paid', '');
                }

                $this->load->view('header', $data);
                $this->load->view('sales_view', $data);
                $this->load->view('footer');
                
            } else {
                //If no session, redirect to login page
                redirect('login', 'refresh');
            }
            
        }
        
        
        public function getSales() {
            
            if ($this->session->userdata('loggedin')) {

                $type= isset($_POST['type'])?$_POST['type']:'';
                if($type == "") { $type = "est"; }
                $ret = $this->course_model->GetSales($type);  
                echo $ret;
            
            }else {
                //If no session, redirect to login page
                redirect('login', 'refresh');
            }
        
        
        }

        public function delSales() {
            
            if ($this->session->userdata('loggedin')) {

                $ide= isset($_GET['ide'])?$_GET['ide']:'';
                $ret = $this->course_model->DeleteSales($ide);  
                echo json_encode($ret);
            
            }else {
                //If no session, redirect to login page
                redirect('login', 'refresh');
            }
        
        
        }
        
        
      
        
        

}
?>
<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Stucourses extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model('login_model','',TRUE);
                $this->load->model('course_model','',TRUE);
				$this->load->model('student_model','',TRUE);
		$this->load->model('qualification_model','',TRUE);
                 $this->load->library('table'); 

	}
	
	function index()
	{
		if($this->session->userdata('loggedin'))
   		{
                    $session_data = $this->session->userdata('loggedin');
                    $session_id = $session_data['id'];
                    $session_role = $session_data['role'];
                    
                    $data['user'] = $this->login_model->GetUserId();		
		
					if($session_role === 'student') {
						                            
						/*$type = $this->input->get('type');
						$schedule = $this->input->get('schedule');
						$center = $this->input->get('center');
						$duration = $this->input->get('duration');*/
						$qualifyid = $this->input->get('qid');
                                                //$qualifyid= mysqli_real_escape_string($qualifyid);
						
						/*$data['type'] = $type;
						$data['schedule'] = $schedule;
						$data['center'] = $center;
						$data['duration'] = $duration;*/
						$data['qualifyid'] = $qualifyid;
						
						//$qid = $this->student_model->GetQualificationID($data['user']['id']);
						
						$data['qualification'] = $this->qualification_model->GetAllQualifications('');
						
						$data['searchoptions'] = $this->student_model->GetCourseSearchOptions($data['user']['qualificationid']);
						
						if($qualifyid!="") $screentest = "all"; else $screentest = "n";
						
						$data['courses'] =  $this->student_model->GetAllCourses($type,$schedule,$center,$duration,$data['user']['qualificationid'],$qualifyid,$data['user']['id'],$screentest);
						
						$data['studentcoursepay'] =  $this->student_model->GetCourseStudentPayment($data['user']['id'],$data['user']['qualificationid'],"");
						
						$data['classstudymaster'] = $this->qualification_model->GetAllActiveClassstudyMaster("");
						
						$this->load->view('header', $data);
						$this->load->view('student_courses_view', $data);
						$this->load->view('footer');
                            
                     }else{
						//If no session, redirect to login page
     					redirect('dashboard', 'refresh');
					}
		}
   		else
   		{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
   		}
		
	}
	
	
}
?>

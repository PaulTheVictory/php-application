<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Stuexam extends CI_Controller {

	function __construct() {
            
		parent::__construct();
		
                $this->load->model('login_model','',TRUE);
                $this->load->model('library_model','',TRUE);
				$this->load->helper('form');
				$this->load->library('table');
				$this->load->helper('My_datatable_helper');

	}
	
	function index() {
            
            if($this->session->userdata('loggedin')) {

                $session_data = $this->session->userdata('loggedin');
                $session_id = $session_data['id'];
                $session_role = $session_data['role'];
                $data['user'] = $this->login_model->GetUserId();
				
                $this->load->view('header', $data);
                $this->load->view('stuexam_view', $data);
                $this->load->view('footer');
				
            } else {
                //If no session, redirect to login page
                redirect('login', 'refresh');
            }
            
        }
        
	public function GetExamCenters() {
            
		if($this->session->userdata('loggedin') ){
			
			$data['user'] = $this->login_model->GetUserId();
						
			$result =  $this->library_model->GetExamCenters($data['user']['id']);

			$row = array();
			
			$sno = 1;
			
			foreach($result as $key=>$col){			
				
				$examdate = ($col->date ===null)?"-":date("d-M-Y h:i A",strtotime($col->date));
				$rtime = ($col->rtime ===null)?"-":date("h:i A",strtotime($col->rtime));
				
				$location = $col->location;
				
				if($location==""){
					$location = '<button class="btn btn-primary ecenterbtn" data-eid="'.$col->ide.'">Select Center</button>';
				}
					
				$row[] = array($sno,$col->name,$col->displaycname,$examdate,$rtime,$col->duration,$location);
									
				$sno++;
				
			}
									
			$ret = array("tabledata"=>$row);
			echo json_encode($ret);
			
		}else{
		//If no session, redirect to login page
		redirect('login', 'refresh');
		}

	}
	
	
	public function GetExamCenterDetails() {
            
		if($this->session->userdata('loggedin') ){
			
			$data['user'] = $this->login_model->GetUserId();
				
			$exid = $this->input->post('exid',true);
			
			$result =  $this->library_model->GetExamCenterDetails($data['user']['id'],$exid);
			
			if(!empty($result)){
				$ret = array("status"=>"success","examdata"=>$result);
				echo json_encode($ret);
			}else{
				$ret = array("status"=>"empty","message"=>"Exam center not found");
				echo json_encode($ret);
			}
			
			
		}else{
		//If no session, redirect to login page
		redirect('login', 'refresh');
		}

	}
	
	public function ExamCenterOptions() {
            
		if($this->session->userdata('loggedin') ){
			
			$data['user'] = $this->login_model->GetUserId();
				
			$examid = $this->input->post('examid',true);
			$district = $this->input->post('district',true);
			
			if($district==""){
				$ret = array("status"=>"fail","message"=>"District Not Found.");
				echo json_encode($ret);
				exit(0);
			}
			
			
			$result = $this->library_model->ExamCenterOptions($examid,$district);
			
			if(!empty($result)){
				$ret = array("status"=>"success","examdata"=>$result);
				echo json_encode($ret);
			}else{
				$ret = array("status"=>"empty","message"=>"Exam center not found");
				echo json_encode($ret);
			}
			
			
		}else{
		//If no session, redirect to login page
		redirect('login', 'refresh');
		}

	}
	
	public function examPrintSubmit() {
            
		if($this->session->userdata('loggedin') ){
			
			$data['user'] = $this->login_model->GetUserId();
				
			$examid = $this->input->post('examid',true);
			$district = $this->input->post('examdistrict',true);
			$center = $this->input->post('examcenter',true);
			
			$examdetails =  $this->library_model->GetExamCenterDetails($data['user']['id'],$examid);
			
			$ide = uniqid();
			
			$qData = array(
                'ide' => $ide,
                'studentid' => $data['user']['id'],
                'examid' => $examid,
                'examname' => $examdetails['examname'],
                'courseid' => $examdetails['courseid'],
                'coursename' => $examdetails['coursename'],
                'district' => $district,
                'location' => $center,
                'created_at' => date('Y-m-d H:i:s')
            );
			
			$result =  $this->library_model->ExamMasterSubmit($qData,$data['user']['id'],$examid,$district,$center);
			
			if($result=="success"){
				$response = array(
                'status' => 'success',
                'message' => "Event Center Applied Successfully."
            	);
			}else if($result=="fail"){
				$response = array(
                'status' => 'fail',
                'message' => "Event Center apply failed."
            	);
			}else if($result=="exists"){
				$response = array(
                'status' => 'exists',
                'message' => "Event Center Already Applied."
            	);
			}
			
			echo json_encode($response);
			
		}else{
		//If no session, redirect to login page
		redirect('login', 'refresh');
		}

	}
	
	public function ExamCenterPrint() {
            
		if($this->session->userdata('loggedin') ){
			
			$data['user'] = $this->login_model->GetUserId();
				
			$examid = $this->input->get('examid',true);
			
			$data['examprintdetails'] =  $this->library_model->GetExamCenterPrintDetails($data['user']['id'],$examid);
			
			$this->load->view('student_examprint_view', $data);
			
			
		}else{
		//If no session, redirect to login page
		redirect('login', 'refresh');
		}

	}
	
}
?>
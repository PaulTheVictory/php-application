<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Results extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model('login_model','',TRUE);
				$this->load->model('exams_model','',TRUE);
                $this->load->library('table');                  

	}
	
	function index()
	{
		if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in'))
   		{
                    $session_data = $this->session->userdata('loggedin');
                    $session_id = $session_data['id'];
                    $session_role = $session_data['role'];
                    
					$data['roleaccess'] = $this->config->item('roleaccess');

					if($data['roleaccess']['Results'][3]!="y"){
						redirect($data['roleaccess']['defaultpage'], 'refresh');
					}
			
                    $data['user'] = $this->login_model->GetUserId();		
		
					                        
                    $examid = $this->input->get('id', true);
					
					if($examid==""){
						redirect('exams', 'refresh');
					}
					
					$data['exam'] = $this->exams_model->GetExamdetails($examid);
					
                    $data['menu'] = $this->load->view('headermenu', $data, TRUE);
                  
					$this->load->view('header_view', $data);
					$this->load->view('results_view', $data);
					$this->load->view('footer_view');
                        
         }
   		else
   		{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
   		}
		
	}
	
	
}
?>

<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Barcodeprint extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model('login_model','',TRUE);
                $this->load->model('library_model','',TRUE);
                $this->load->library('table');
				$this->load->helper('form');
	
	}
	
	function index()
	{
		if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in'))
   		{
                    $session_data = $this->session->userdata('loggedin');
                    $session_id = $session_data['id'];
                    $session_role = $session_data['role'];
                    
                    $data['user'] = $this->login_model->GetUserId();		
		
					$data['roleaccess'] = $this->config->item('roleaccess');

					if($data['roleaccess']['Generate Barcodes'][3]!="y"){
						redirect($data['roleaccess']['defaultpage'], 'refresh');
					}
			
					$id = $this->input->get("id",true);
			
					if($id==""){
						
						redirect("generatebarcode","refresh");
					}
			
					$data['batchid'] = $id;
						
					$data['bcdetails'] = $this->library_model->GetBarcodeBatchdetails($id);
			
					if(!empty($data['bcdetails'])) $this->generate_barcode($data['bcdetails']);
														
					$data['menu'] = $this->load->view('headermenu', $data, TRUE);
																		
					//$this->load->view('header',$data);
					$html = $this->load->view('barcodeprintpdf_view', $data, TRUE);
					//$this->load->view('footer');
			
					$this->load->helper('Dompdf_helper');
					$filename = 'Generated Barcodes ('.$data['bcdetails']['barcodefrom'].' - '. $data['bcdetails']['barcodeto'].')';
					pdf_create($html, $filename, TRUE);
                    
		}
   		else
   		{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
   		}
		
	}
		
	
	public function generate_barcode($bcdetails){
		
		if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in'))
   		{
			
		// Load library
		$this->load->library('zend');
		// Load in folder Zend
		$this->zend->load('Zend/Barcode');
		
		$bcto = $bcdetails['barcodefrom'] - 1;
		
		$dirname = './docs/barcode/'.$bcdetails['id'].'/';
		
		if(!file_exists($dirname)) { if(!mkdir($dirname,0777,true)){ $result = array(0=>"error",1=>"error ".$dirname); return $result; }  }
		
		for($i=1;$i<=$bcdetails['totalcount'];$i++){
			
		$bccode = intval($bcto) + intval($i);
			
		if(!file_exists($dirname.$bccode.'.png')){
			
			// Generate barcode
			$imageResource = Zend_Barcode::factory('code128', 'image', array('text'=>"$bccode",'stretchText'=>true,'withBorder'=>false,'font'=>3,'fontSize'=>18,'barHeight'=>40,'barThickWidth'=>3,'barThinWidth'=>2,'withQuietZones'=>false,'drawText'=>true), array('imageType'=>'png'))->draw();

			imagepng($imageResource, $dirname.$bccode.'.png');
			
		}
			
		}
			
	}
   		else
   		{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
   		}		
		
	}
	
}
?>

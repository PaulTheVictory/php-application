<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Confirmrequest extends CI_Controller {
    
        
	function __construct()
	{
		parent::__construct();
		$this->load->model('course_model','',TRUE);
                $this->load->model('login_model','',TRUE);
                $this->load->model('qualification_model','',TRUE);
                $this->load->model('student_model','',TRUE);
                $this->load->library('table');$this->load->helper('form');
                

	}
	
	function index()
	{
		if($this->session->userdata('loggedin') && $this->session->userdata('studlog_in'))
   		{
                    
     		    $session_data = $this->session->userdata('loggedin');
		    $session_id = $session_data['id'];
     		    $session_role = $session_data['role'];
		    $data['user'] = $this->login_model->GetUserId();
                    $ide = isset($_GET['id']) ? $_GET['id'] : '';
					$wfr = isset($_GET['wfr']) ? $_GET['wfr'] : '';
			
					$data['qwfr'] = $wfr;
                    $data['qid'] = '';
                    $arr= $this->qualification_model->ViewCourseRequest($ide);
                    
                    if($arr === '') {
                        redirect('login', 'refresh');
                    } else{
                        $data['qualification'] = $arr[0];
                       
                    }
                    
                    if($session_role === 'student'){
                        
                        if($wfr!="y" && $data['qualification']['status']!="WFR" && $data['qualification']['xii_status']!="WFR" && $data['qualification']['approved'] !== ""){
                             redirect('sturegcourses', 'refresh');
                        }
                        
                    }
                    
					$data['courseno'] = $this->qualification_model->GetCoursenoQualification($data['qualification']['courseid']);
			
                    $data['course'] = $this->course_model->EditCourse($data['qualification']['courseid'],'');
                                 
                    $this->load->view('header', $data);
                    $this->load->view('confirmrequest_view', $data);
                    $this->load->view('footer'); 
                    
                }
                else if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')){
                    
                     $ide = isset($_GET['id']) ? $_GET['id'] : '';
                     $data['sid'] = isset($_GET['sid']) ? $_GET['sid'] : '';
                     $data['qid'] = isset($_GET['qid']) ? $_GET['qid'] : '';
                    
                     $data['user'] = $this->login_model->GetUserId();
					
					$data['roleaccess'] = $this->config->item('roleaccess');

					if($data['roleaccess']['Qualification'][3]!="y"){
						redirect($data['roleaccess']['defaultpage'], 'refresh');
					}
					
                    $arr= $this->qualification_model->ViewCourseRequest($ide);
                    $data['menu'] = $this->load->view('headermenu', $data, TRUE);
                    if($arr === '') {
                        redirect('login', 'refresh');
                    } else{
                        $data['qualification'] = $arr[0];
                       
                    }
                    
                    $data['courseno'] = $this->qualification_model->GetCoursenoQualification($data['qualification']['courseid']);      
                    $data['course'] = $this->course_model->EditCourse($data['qualification']['courseid'],'');
                    $data['stuprofile'] =  $this->student_model->GetStudentProfile($data['sid']);            
                    $this->load->view('header_view', $data);
                    $this->load->view('confirmrequest_view', $data);
                    $this->load->view('footer_view'); 
                    
                }else	{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
   		}
		
	}
        
              
         
  
      
	     public function QualificationCheck() {
             
            if($this->session->userdata('loggedin') && ($this->session->userdata('studlog_in') || $this->session->userdata('adlog_in')) ){
               $this->load->library('form_validation');
               $this->form_validation->set_rules('id', 'Request ID', 'trim|required|xss_clean|alpha_numeric|max_length[20]');
                
                
                if ($this->form_validation->run() == false) {
                    $response = array(
                        'status' => 'error',
                        'message' => validation_errors()
                    );
                } else {
                    
                                 $response = array(
                                'status' => 'success',
                                'message' => 'Qualification Matched'
                                );
                    
                            $requestarr= $this->qualification_model->ViewCourseRequest($this->input->post('id', true));
                            $qualification = $this->qualification_model->VerifyQualification($requestarr[0]['qualificationid'],$requestarr[0]['x_qid'],$requestarr[0]['xii_qid']);
                    
                            if($requestarr[0]['xii_yearofpassing'] === '') {
                                
                                $response = $this->FirstQualification($requestarr, $qualification);   
                                
                            } else if(($requestarr[0]['xii_yearofpassing'] !== '')&&(($requestarr[0]['xii_status'] === 'WFR') || ($requestarr[0]['xii_status'] === 'C'))){
                                
                                $response = $this->FirstQualification($requestarr, $qualification); 
                                
                                if(($response['status'] !== 'success') && ($requestarr[0]['entrance_name'] !== '')) { 
                                    $response = $this->AdditionalQualification($requestarr, $qualification);
                                }
                                
                            }else {
                                
                                $response = $this->SecondQualification($requestarr, $qualification); 
                                
                                if(($response['status'] !== 'success') && ($requestarr[0]['entrance_name'] !== '')) { 
                                    
                                    $response = $this->AdditionalQualification($requestarr, $qualification);
                                    
                                }
                            }
                          
                            if($response['status'] === 'success') {  
                                
                                    $session_data = $this->session->userdata('loggedin');
                                    $session_id = $session_data['id'];
                                    $session_role = $session_data['role'];
								
									$utype = $this->input->post('utype', true);
								
                                    if($session_role === "admin" && $utype!="student"){
                                         $this->course_model->ActivateAppliedList($this->input->post('id', true),"y"); 
                                    } else{
                                         $this->course_model->ActivateAppliedList($this->input->post('id', true),"q"); 
                                    }

                                   
                                    $this->load->model('notification_model','',TRUE);
                                    $this->notification_model->CourseRegisterNotification($requestarr[0]['studentid'],$requestarr[0]['courseid']);

                            }else{

                                    $this->course_model->ActivateAppliedList($this->input->post('id', true),"n"); 
                            }
                   
                }
                
                echo  json_encode($response);
        
            }else{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
            }
            
         }
         
         public function VerifyYearOfPassing($ryear,$qyear,$rule){
             
             if($rule === 'LTE') {
                 
                 return (intval($ryear) <= intval($qyear))?true:false;
                 
             } else if ($rule === 'GTE') {
                 
                 return (intval($ryear) >= intval($qyear))?true:false;
             }
             
         }
         
         
         public function VerifySubjectWiseMark($rsubject,$rmark,$qsubject,$qmark,$rule){
             
              $response = array(
                        'status' => 'success',
                        'message' => 'Qualification matched'
                        );
             
             $rsubject = explode("|",$rsubject);
             $rmark = explode("|",$rmark);
             $rFinalArr = Array();
             
             foreach($rsubject as $key=>$val){
                 
                 if($val === '') { continue;}
                 
                 $rFinalArr[$val] = $rmark[$key];
                 
             }
             
             $qsubject = explode("|",$qsubject);
             $qmark = explode("|",$qmark);
             $rule = explode("|",$rule);
             $qFinalArr = Array();$ruleFinalArr = Array();
             
             foreach($qsubject as $key=>$val){
                 
                 if($val === '') { continue;}
                 
                 $qFinalArr[$val] = $qmark[$key];
                 $ruleFinalArr[$val] = $rule[$key];
                 
             }
             
             
             
             foreach($rFinalArr as $key=>$val){
                 
                 if($val === '') { continue;}
                 
                 if($ruleFinalArr[$key] === 'GTE') {
                     
                     if(intval($val) >= intval($qFinalArr[$key])){
                         
                     } else {
                         $response['status'] = 'error';
                         $response['message'] = $key." Value Mismatch with the qualification";
                        break;
                     }
                     
                 }else if($ruleFinalArr[$key] === 'LTE'){
                     
                     if(intval($val) <= intval($qFinalArr[$key])){
                         
                     } else {
                         
                          $response['status'] = 'error';
                          $response['message'] = $key." Value Mismatch with the qualification";
                           break;
                     }
                 }
                               
             }
             
            
                        
             return $response;
             
         }
         
         
         public function VerifySubjectWiseGrade($rsubject,$rmark,$qsubject,$qmark,$rule,$gradeVal){
             
             $response = array(
                        'status' => 'success',
                        'message' => 'Qualification matched'
                        );
             
             $rsubject = explode("|",$rsubject);
             $rmark = explode("|",$rmark);
             $rFinalArr = Array();
             
             foreach($rsubject as $key=>$val){
                 
                 if($val === '') { continue;}
                 
                 $rFinalArr[$val] = $gradeVal[$rmark[$key]];
                 
             }
             
             $qsubject = explode("|",$qsubject);
             $qmark = explode("|",$qmark);
             $rule = explode("|",$rule);
             $qFinalArr = Array();$ruleFinalArr = Array();
             
             foreach($qsubject as $key=>$val){
                 
                 if($val === '') { continue;}
                 
                 $qFinalArr[$val] = $gradeVal[$qmark[$key]];
                 $ruleFinalArr[$val] = $rule[$key];
                 
             }
             
             
             foreach($rFinalArr as $key=>$val){
                 
                 if($val === '') { continue;}
                 
                 if($ruleFinalArr[$key] === 'GTE') {
                     
                     if(intval($val) >= intval($qFinalArr[$key])){
                         
                     } else {
                         $response['status'] = 'error';
                         $response['message'] = $key." Value Mismatch with the qualification";
                        break;
                     }
                     
                 }else if($ruleFinalArr[$key] === 'LTE'){
                     
                     if(intval($val) <= intval($qFinalArr[$key])){
                         
                     } else {
                         
                          $response['status'] = 'error';
                          $response['message'] = $key." Value Mismatch with the qualification";
                           break;
                     }
                 }
                               
             }
             
                        
             return $response;
            
         }
	
	
         
          public function VerifyTotalGrade($rmark,$totmark,$rule,$gradeVal){
             
             $response = array(
                        'status' => 'success',
                        'message' => 'Qualification matched'
                        );
             
            
             $rmarkArr = explode("|",$rmark);
             $totCalAmt = 0;
             
             foreach($rmarkArr as $key=>$val){
                 
                 if($val === '') { continue;}
                 
                 $totCalAmt += intval($gradeVal[$rmarkArr[$key]]);
                 
             }
             
            if($rule === 'GTE') {
                     
                     if(intval($totCalAmt) >= intval($totmark)){
                         
                     } else {
                         $response['status'] = 'error';
                         $response['message'] = "Value Mismatch with the qualification";
                        
                     }
                     
                 }else if($rule === 'LTE'){
                     
                     if(intval($totCalAmt) <= intval($totmark)){
                         
                     } else {
                         
                          $response['status'] = 'error';
                          $response['message'] = "Value Mismatch with the qualification";
                          
                     }
                 }
             
                                 
             return $response;
            
         }
         
          public function VerifyTotalMarks($rmark,$totmark,$rule){
             
             $response = array(
                        'status' => 'success',
                        'message' => 'Qualification matched'
                        );
             
            
             $rmarkArr = explode("|",$rmark);
             $totCalAmt = 0;
             
             foreach($rmarkArr as $key=>$val){
                 
                 if($val === '') { continue;}
                 
                 $totCalAmt += intval($rmarkArr[$key]);
                 
             }
             
            if($rule === 'GTE') {
                     
                     if(intval($totCalAmt) >= intval($totmark)){
                         
                     } else {
                         $response['status'] = 'error';
                         $response['message'] = "Value Mismatch with the qualification total mark";
                        
                     }
                     
                 }else if($rule === 'LTE'){
                     
                     if(intval($totCalAmt) <= intval($totmark)){
                         
                     } else {
                         
                          $response['status'] = 'error';
                          $response['message'] = "Value Mismatch with the qualification total mark";
                          
                     }
                 }
             
                                 
             return $response;
            
         }
         
         public function FirstQualification($requestarr,$qualification){
             
            $response = array(
                        'status' => 'success',
                        'message' => 'Qualification Matched'
                        );

                    if(!$this->VerifyYearOfPassing($requestarr[0]['yearofpassing'],$qualification['general_x']['year'],$qualification['general_x']['qrule'])){

                        $response['status'] = 'error';
                        $response['message'] = 'Year of passing is not eligibale';

                    } 


                    if(($requestarr[0]['status'] !== 'WFR') &&($requestarr[0]['status'] !== 'C') && ($response['status'] !== 'error')){


                        $rmark = ($requestarr[0]['mark'] !== '')?$requestarr[0]['mark']:$requestarr[0]['grade'];
                        $qmark = ($qualification['general_x']['mark'] !== '')?$qualification['general_x']['mark']:$qualification['general_x']['grade'];

                        if($qualification['general_x']['mark'] === '') {

                            $gradeVal = $this->qualification_model->GetGradeValue('X',$requestarr[0]['stream']);

                            $response = $this->VerifySubjectWiseGrade($requestarr[0]['subject'], $rmark, $qualification['general_x']['subject'], $qmark, $qualification['general_x']['rule'],$gradeVal);

                            if($response['status'] !== 'success') {  

                                 $response = $this->VerifyTotalGrade($rmark,$qualification['general_x']['total'], $qualification['general_x']['trule'],$gradeVal);

                            }

                        } else {

                            $response = $this->VerifySubjectWiseMark($requestarr[0]['subject'], $rmark, $qualification['general_x']['subject'], $qmark, $qualification['general_x']['rule']);

                            if($response['status'] !== 'success') {  

                                $response = $this->VerifyTotalMarks($rmark,$qualification['general_x']['total'], $qualification['general_x']['trule']);

                            }
                        }
                    }

            return $response;
             
         }
         
         
         public function SecondQualification($requestarr,$qualification) {
             
             $response = array(
                                'status' => 'success',
                                'message' => 'Qualification Matched'
                                );
             
            if(!$this->VerifyYearOfPassing($requestarr[0]['xii_yearofpassing'],$qualification['general_xii']['year'],$qualification['general_xii']['qrule'])){

                $response['status'] = 'error';
                $response['message'] = 'XII Year of passing is not eligibale';

            } 

             if(($requestarr[0]['xii_status'] !== 'WFR') &&($requestarr[0]['status'] !== 'C') && ($response['xii_status'] !== 'error')){


            $rmark = ($requestarr[0]['xii_mark'] !== '')?$requestarr[0]['xii_mark']:$requestarr[0]['xii_grade'];
            $qmark = ($qualification['general_xii']['mark'] !== '')?$qualification['general_xii']['mark']:$qualification['general_xii']['grade'];

            if($qualification['general_xii']['mark'] === '') {

                $gradeVal = $this->qualification_model->GetGradeValue('XII',$requestarr[0]['xii_stream']);

                $response = $this->VerifySubjectWiseGrade($requestarr[0]['xii_subject'], $rmark, $qualification['general_xii']['subject'], $qmark, $qualification['general_xii']['rule'],$gradeVal);

                if($response['status'] !== 'success') {  

                    $response = $this->VerifyTotalGrade($rmark,$qualification['general_xii']['total'], $qualification['general_xii']['trule'],$gradeVal);

                }

            } else {

                $response = $this->VerifySubjectWiseMark($requestarr[0]['xii_subject'], $rmark, $qualification['general_xii']['subject'], $qmark, $qualification['general_xii']['rule']);

                    if($response['status'] !== 'success') {  

                        $response = $this->VerifyTotalMarks($rmark,$qualification['general_xii']['total'], $qualification['general_xii']['trule']);

                    }
                }
            }
            
           return $response;  
           
         }
         
         public function AdditionalQualification($requestarr,$qualification) {
             
             
              $response = array(
                                'status' => 'success',
                                'message' => 'Qualification Matched'
                                );
              
              
              $qename = $qualification['general']['entrance'];
              $qeval = $qualification['general']['entrance_value'];
              $qerule = $qualification['general']['entrance_rule'];
              
              $cename = $requestarr[0]['entrance_name'];
              $cemark = $requestarr[0]['entrance_mark'];
              
              $entranceValArr = Array(); $entranceRuleArr = Array();
              
              $enteredValArr = Array();
              
              $qenameArr = explode("|", $qename);
              $qenameArr = array_filter($qenameArr, 'strlen');
              
              $qevalArr = explode("|", $qeval);
              $qevalArr = array_filter($qevalArr, 'strlen');
              
              $qeruleArr = explode("|", $qerule);
              $qeruleArr = array_filter($qeruleArr, 'strlen');
              
              $cenameArr = explode("|", $cename);
              $cenameArr = array_filter($cenameArr, 'strlen');
              
              $cemarkArr = explode("|", $cemark);
              $cemarkArr = array_filter($cemarkArr, 'strlen');
              
              
              foreach($qenameArr as $key=>$val){
                  $entranceValArr[$val] = $qevalArr[$key];
                  $entranceRuleArr[$val] = $qeruleArr[$key];
              }
              
              foreach($cenameArr as $key=>$val){
                  $enteredValArr[$val] = $cemarkArr[$key];
              }
              
              
              foreach($entranceValArr as $key => $val){
                  
                  if($entranceRuleArr[$key] === "GTE"){
                      
                      if(array_key_exists($key,$enteredValArr)){
                          
                          if(intval($enteredValArr[$key]) < intval($val)){
                               $response['status'] = 'error';
                               $response['message'] = 'Additional Qualification not eligibale';
                               break;
                          }
                      }
                      
                  }
                  
                  if($entranceRuleArr[$key] === "LTE"){
                      
                      if(array_key_exists($key,$enteredValArr)){
                          
                          if(intval($enteredValArr[$key]) > intval($val)){
                               $response['status'] = 'error';
                               $response['message'] = 'Additional Qualification not eligibale';
                               break;
                          }
                      }
                      
                  }
                  
              }
             
              return $response;
         }
}
?>
<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Admissions extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model('login_model','',TRUE);
                $this->load->model('course_model','',TRUE);
                $this->load->library('table'); 
                $this->load->helper('download');
                 

	}
	
	function index()
	{
		if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in'))
   		{
                    $session_data = $this->session->userdata('loggedin');
                    $session_id = $session_data['id'];
                    $session_role = $session_data['role'];
                    
                    $data['user'] = $this->login_model->GetUserId();		
		
					$data['roleaccess'] = $this->config->item('roleaccess');

					if($data['roleaccess']['uview']!="y"){
						redirect($data['roleaccess']['defaultpage'], 'refresh');
					}
                        
                    $ide = isset($_GET['id']) ? $_GET['id'] : '';
                    $center = isset($_GET['center']) ? $_GET['center'] : '';
                    $data['menu'] = $this->load->view('headermenu', $data, TRUE);
                        if(($ide === '')&&($center==='')) {
                        
                         $tmpl = array('table_open' => '<table class="sortable" id="studenttable" style="margin-top:0px;">');
                                    $this->table->set_template($tmpl);
                                    $this->table->set_heading('COURSE ID','COURSE NAME', 'LOCATION', 'ADMITTED','APPLIED','WL','SL','REJECT','TOTAL','ACTIONS');


                        $this->load->view('header_view', $data);
                        $this->load->view('admissions_center_view', $data);
                        $this->load->view('footer_view');

                        } else if(($ide !== '')&&($center !=='')) {
                            $type = isset($_GET['type']) ? $_GET['type'] : '';
                            $data['courseid'] = $ide;
                            $data['center'] = $center;
                            $data['type'] = $type;
                            $data['coursename'] = $this->course_model->GetCourseName($ide);
                             $tmpl = array('table_open' => '<table class="sortable" id="studenttable" style="margin-top:0px;">');
                                    $this->table->set_template($tmpl);
                                    $this->table->set_heading('','STUDENT ID','STUDENT NAME','MOBILE','STREAM','YOP','CLASS','SUB CRITERIA', 'TOTAL','GM','AQ1','AQ2','AQ3','STATUS','ACTIONS');
                                    $this->load->view('header_view', $data);
                        $this->load->view('admissions_view', $data);
                        $this->load->view('footer_view');
                        }
                        
                }
   		else
   		{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
   		}
		
	}
        
        public function GetAdmissionCenterLists() {
            
            if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')){
                
                $ret =  $this->course_model->GetRequestedCenterCourses();
                echo $ret;
                
            }else{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
            }
            
        }
        
         public function GetAdmissionLists() {
            
            if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')){
                $ide = $this->input->post('courseid', true);
                $center = $this->input->post('center', true);
                $type = $this->input->post('type', true);
                
                $cflag = $this->input->post('cflag', true);
                $search = $this->input->post('sval', true);
                $mtotal = $this->input->post('mtotal', true);
                
                if($cflag !== "0" && $search !== "") {
                  $ret =  $this->course_model->GetStreamFilteredCourses($ide,$center,$cflag,$search,$mtotal,$type);  
                    
                } else if($cflag !== "0" && $mtotal !== "") {
                  $ret =  $this->course_model->GetMarkFilteredCourses($ide,$center,$cflag,$mtotal,$type);  
                    
                } else {
                
                    $ret =  $this->course_model->GetRequestedCourses($ide,$center,$type);
                }
                
               //var_dump($val);
                echo ($ret);
                
            }else{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
            }
            
        }
        
         public function ApproveRequest(){
            
            if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')){

                $ide = isset($_GET['ide']) ? $_GET['ide'] : '';
                $type = isset($_GET['type']) ? $_GET['type'] : '';

                if($ide != ""){
                    
                      if($type !== "y") {
                          $ide = explode("|",$ide);
        
                            foreach($ide as $key=>$val) {
                                 if($val === '') { continue;}
                                $ret = $this->course_model->UpdateCourseStatus($val,$type);
                            }
                            
                      } else {
                          
                            $ret = $this->course_model->ApproveRequest($ide);
                      }
                } else {
                    $ret = array(0 => "fail");
                }

                echo json_encode($ret);
            
            }else {
                //If no session, redirect to login page
                redirect('login', 'refresh');
            }
            
        }
        
        
        public function DeleteRequest(){
            
            if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')){

                $ide = isset($_GET['ide']) ? $_GET['ide'] : '';

                if($ide != ""){
                     $ret = $this->course_model->DeleteRequest($ide);
                } else {
                    $ret = array(0 => "fail");
                }

                echo json_encode($ret);
            
            }else {
                //If no session, redirect to login page
                redirect('login', 'refresh');
            }
            
        }
        
         public function export(){
            
            if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')){
                
                ini_set('memory_limit', '-1');	
                ini_set('max_execution_time', 86400);

               $ide = $this->input->get('courseid', true);
               $center = $this->input->get('center', true);
               $type = $this->input->get('type', true);
               
               $html .= '<tr><td>S.no</td><td>Name</td><td>Student ID</td><td>Course ID</td><td>Course Name</td><td>Center</td><td>Email</td><td>Country Code</td><td>Mobile Number</td><td>Date of Birth:</td><td>Gender</td><td>Nationality</td><td>Category</td><td>Aadhar Number</td><td>Fathers Name</td><td>Country Code</td><td>Fathers Phone</td><td>Fathers Email</td><td>Fathers Occupation</td><td>Mothers Name</td><td>Country Code</td><td>Mothers Phone</td><td>Mothers Email</td><td>Mothers Occupation</td><td>Communication Contact</td><td>Blood Group</td><td>Class Studying / Complete</td><td>Stream</td><td>Name of School Last Studied / Studying</td><td>Address Line</td><td>Country</td><td>House / Appartment Name</td><td>Place / Street</td><td>Post Office</td><td>District</td><td>State</td><td>Country</td><td>Pincode</td><td>Country Code</td><td>Whatsapp Number</td><td>Guardian Name</td><td>Account Holder Name</td><td>Bank Name</td><td>Branch</td><td>IFSC Code</td><td>Bank Account Number</td><td>YOP</td><td>Class</td><td>Stream</td><td>Grace Mark</td><td>Subject</td><td>Grade</td><td>Mark</td><td>Total Mark</td><td>XII YOP</td><td>Status</td><td>XII Stream</td><td>XII Grace Mark</td><td>XII Subject</td><td>XII Grade</td><td>XII Mark</td><td>XII Total Mark</td><td>Entrance name</td><td>Entrance Mark</td><td>AQ1</td><td>AQ2</td><td>AQ3</td><td>Entrance Reg no</td><th>Batch</th><th>Total Fee (With GST)</th><th>Total Fee (without GST)</th><th>Active Fee (without GST)</th><th>Active Discount</th><th>Given By</th><th>Reason</th><th>Remarks</th><th>To be paid (wihtout GST)</th><th>Paid (wihtout GST)</th><th>Net Due</th><th>GST+KF</th><th>KF Adjust</th><th>Total due</th><td>Course Changed From</td><th>Course due date</th><th>Final due date</th></tr>';

                if($ide != ""){
                     $ret = $this->course_model->ExportAdmissionRequest($ide,$center,$type);
                       
                      $i = 1;
                     foreach ($ret as $key=>$val){
                        $html .= '<tr><td>'.$i.'</td><td>'.$val['sname'].'</td><td>'.$val['studid'].'</td><td>'.$val['courseid'].'</td><td>'.$val['coursename'].'</td><td>'.$val['center'].'</td><td>'.$val['email'].'</td><td>'.$val['mcode'].'</td><td>'.$val['contact'].'</td><td>'.$val['dob'].'</td><td>'.$val['gender'].'</td><td>'.$val['nationality'].'</td><td>'.$val['category'].'</td><td>'.$val['aadharnumber'].'</td><td>'.$val['fathername'].'</td><td>'.$val['fathercode'].'</td><td>'.$val['fatherphone'].'</td><td>'.$val['fatheremail'].'</td><td>'.$val['fatheroccupation'].'</td><td>'.$val['mothername'].'</td><td>'.$val['mothercode'].'</td><td>'.$val['motherphone'].'</td><td>'.$val['motheremail'].'</td><td>'.$val['motheroccupation'].'</td><td>'.$val['communicationcontact'].'</td><td>'.$val['bloodgroup'].'</td><td>'.$val['classstudy'].'</td><td>'.$val['stream'].'</td><td>'.$val['schoolcollegename'].'</td><td>'.$val['eduaddress'].",".$val['edulandmark'].",".$val['edudistrict'].",".$val['edustate'].",".$val['edupost'].",".$val['edupincode'].'</td><td>'.$val['educountry'].'</td><td>'.$val['housenameno'].'</td><td>'.$val['landmark'].",".$val['contactaddress'].'</td><td>'.$val['contactpost'].'</td><td>'.$val['contactdistrict'].'</td><td>'.$val['contactstate'].'</td><td>'.$val['contactcountry'].'</td><td>'.$val['contactpincode'].'</td><td>'.$val['wacode'].'</td><td>'.$val['whatsappno'].'</td><td>'.$val['guardianname'].'</td><td>'.$val['accountholdername'].'</td><td>'.$val['bankname'].'</td><td>'.$val['branch'].'</td><td>'.$val['ifsccode'].'</td><td>'.$val['bankaccountno'].'</td><td>'.$val['yearofpassing'].'</td><td>'.$val['class'].'</td><td>'.$val['stream'].'</td><td>'.$val['gracemark'].'</td><td>'.ltrim($val['subject'],",").'</td><td>'.ltrim($val['grade'],",").'</td><td>'.ltrim($val['mark'],",").'</td><td>'.$val['mark_total'].'</td><td>'.$val['xii_yearofpassing'].'</td><td>'.$val['xii_status'].'</td><td>'.$val['xii_stream'].'</td><td>'.$val['xii_gracemark'].'</td><td>'.ltrim($val['xii_subject'],",").'</td><td>'.ltrim($val['xii_grade'],",").'</td><td>'.ltrim($val['xii_mark'],",").'</td><td>'.$val['xii_mark_total'].'</td><td>'.ltrim($val['entrance_name'],",").'</td><td>'.ltrim($val['entrance_mark'],",").'</td><td>'.$val['aq1'].'</td><td>'.$val['aq2'].'</td><td>'.$val['aq3'].'</td><td>'.ltrim($val['entrance_regno'],",").'</td><td></td><td>'.$val['total'].'</td><td>'.$val['totalw'].'</td><td>'.$val['atotal'].'</td><td>'.$val['discount'].'</td><td>'.$val['givenby'].'</td><td>'.$val['reason'].'</td><td>'.$val['remarks'].'</td><td>'.$val['tobepaid'].'</td><td>'.$val['paid'].'</td><td>'.$val['netdue'].'</td><td>'.$val['gst'].'</td><td>'.$val['kfadjust'].'</td><td>'.$val['totaldue'].'</td><td>'.$val['coursenamefrom'].'</td><td></td><td></td></tr>';
                        $i++;
                    }
                } 
                
                $savename = "Student Profile Export".date('d-m-Y-H_i_s');
                $html = str_replace('<tr>',"\n",$html);
                     $html = str_replace('</tr>',"",$html);

                     $html = str_replace('</th>',"\t",$html);
                     $html = str_replace('<th>',"",$html);

                     $html = str_replace('</td>',"\t",$html);
                     $html = str_replace('<td>',"",$html);


                     $html = strip_tags($html);

                     $filename = $savename .".xls";

                     force_download($filename, $html);

                
            
            }else {
                //If no session, redirect to login page
                redirect('login', 'refresh');
            }
            
        }
	
	
}
?>

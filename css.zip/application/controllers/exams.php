<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Exams extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model('login_model','',TRUE);
		$this->load->model('exams_model','',TRUE);
		$this->load->library('table'); $this->load->helper('form');
                 

	}
	
	function index()
	{
		if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in'))
   		{
                    $session_data = $this->session->userdata('loggedin');
                    $session_id = $session_data['id'];
                    $session_role = $session_data['role'];
                    
					$data['roleaccess'] = $this->config->item('roleaccess');

					if($data['roleaccess']['uview']!="y"){
						redirect($data['roleaccess']['defaultpage'], 'refresh');
					}
			
                    $data['user'] = $this->login_model->GetUserId();

                    $data['menu'] = $this->load->view('headermenu', $data, TRUE);
			
                    $this->load->view('header_view', $data);
                    $this->load->view('exams_view', $data);
                    $this->load->view('footer_view');

                        
                }else{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
   		}
		
	}
	
    public function examsList()
    {

		
	if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')){
			
		
		$roleaccess = $this->config->item('roleaccess');
		
		$user = $this->login_model->GetUserId();
		$batches = $user['batches'];
		
		$columns = array( 
                            0 =>'sno', 
                            1 =>'examname',
                            2=> 'date',
                            3=> 'type',
			    4=> 'stu_appreadred',
                            5=> ''
                        );

		$limit = $this->input->post('length');
        $start = $this->input->post('start');
        $order = $columns[$this->input->post('order')[0]['column']];
        $dir = $this->input->post('order')[0]['dir'];
		
		$searchcol = $this->input->post('searchcol', true);
  
        $totalData = $this->exams_model->exams_count();
            
        $totalFiltered = $totalData; 
            
        if(empty($this->input->post('search')['value']))
        {            
            $posts = $this->exams_model->examslist($limit,$start,$order,$dir);
        }
        else {
            $search = $this->input->post('search')['value']; 

            $posts =  $this->exams_model->examslist_search($limit,$start,$search,$order,$dir,$searchcol);

            $totalFiltered = $this->exams_model->examslist_search_count($search,$searchcol);
        }

        $data = array();
        if(!empty($posts))
        {
            foreach ($posts as $post)
            {

                $nestedData['sno'] = $post->sno;
                $nestedData['examname'] = '<a class="noedit" href="'.base_url().'results?id='.$post->id.'">'.$post->examname.'</a>';                
                $nestedData['type'] = $post->type;
                $nestedData['stuapp'] = $post->stu_appeared;
		$examdate = date('j M Y',strtotime($post->date));
                $nestedData['examdate'] = $examdate;
								
        	$action = '<a class="noedit" href="'.base_url().'results?id='.$post->id.'"><img style="padding:5px" src="images/view.png"> </a>';
				
				$action1 = "";
				if($roleaccess['udelete']=="y"){
					$action1 = '<a class="del" id="'.$post->id.'" href="javascript:void(0)"><img style="padding:5px 10px" src="'.$this->config->item('web_url')."images/delete.png".'"></a>';
				}
                $nestedData['actions'] = $action.$action1;
            
                
                $data[] = $nestedData;

            }
        }
          
        $json_data = array(
                    "draw"            => intval($this->input->post('draw')),  
                    "recordsTotal"    => intval($totalData),  
                    "recordsFiltered" => intval($totalFiltered), 
                    "data"            => $data   
                    );
            
        echo json_encode($json_data); 
			
	}else{
			
		//If no session, redirect to login page
		redirect('login', 'refresh');
			
	}
		
    }
	
	public function addExam(){
		
		if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in'))
   		{
			

			$ename = $this->input->post('ename');
			$edate = $this->input->post('edate');
			$etype = $this->input->post('etype');
                        $stuapp = $this->input->post('stuapp');
			
						 
			
                            $this->load->library('form_validation');
                            $this->form_validation->set_rules('ename', 'Exam Name', 'trim|required|xss_clean|callback_alpha_numeric_spaces|max_length[2000]');
                            $this->form_validation->set_rules('etype', 'Exam Type', 'trim|xss_clean|required|callback_alpha_numeric_spaces|max_length[10000]');
                            $this->form_validation->set_rules('edate', 'Exam Date', 'trim|xss_clean|required');
                            $this->form_validation->set_rules('stuapp', 'Students Appeared', 'trim|required|xss_clean|numeric');
        

                            if ($this->form_validation->run() == false) {
                                $response = array(
                                    'status' => 'error',
                                    'message' => validation_errors()
                                );
                            } else {

                                $this->exams_model->AddExam($ename,$edate,$etype,$stuapp);
                                $response = array(
                                    'status' => 'success',
                                    'message' => 'Exam Added Successfully'
                                );
                                

                            }
                       echo json_encode($response);
			
		}else{
                    //If no session, redirect to login page
                    redirect('login', 'refresh');
   		}
		
	}
         
    public function DelExam(){
            
            if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')){

                $ide = isset($_GET['ide']) ? $_GET['ide'] : '';

                if($ide != ""){
                     $ret = $this->exams_model->DeleteExam($ide);
                } else {
                    $ret = array(0 => "fail");
                }

                echo json_encode($ret);
            
            }else {
                //If no session, redirect to login page
                redirect('login', 'refresh');
            }
            
        }
}
?>

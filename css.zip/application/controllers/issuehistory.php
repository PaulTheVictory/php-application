<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Issuehistory extends CI_Controller {

	function __construct() {
            
		parent::__construct();
		
                $this->load->model('login_model','',TRUE);
                $this->load->model('library_model','',TRUE);
				$this->load->helper('form');
				$this->load->library('table');
				$this->load->helper('My_datatable_helper');

	}
	
	function index() {
            
            if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')) {

                $session_data = $this->session->userdata('loggedin');
                $session_id = $session_data['id'];
                $session_role = $session_data['role'];
                $data['user'] = $this->login_model->GetUserId();

				$data['roleaccess'] = $this->config->item('roleaccess');
			
				if($data['roleaccess']['Issue Books'][3]!="y"){
					redirect($data['roleaccess']['defaultpage'], 'refresh');
				}
				
				$studentid = $this->input->get("stuid",true);
				$center = $this->input->get("center",true);
				$type = $this->input->get("type",true);
				
				/*if($studentid=="" || $center==""){
					redirect('issuebook', 'refresh');
				}*/
				
				$data['stuid'] = $studentid;
				$data['center'] = $center;
				$data['type'] = $type;
					
				if($type!="staff"){
					$data['studentdetails'] = $this->library_model->GetStudentProfile($studentid);
				}else{
					$data['studentdetails'] = $this->library_model->GetStaffProfile($studentid);
				}
				
				$data['issueddetails'] = $this->library_model->GetIssuedBookDetails($studentid);
				
				/*$tmpl = array('table_open' => '<table class="sortable sorting disabled table" id="issuehistorytable" style="margin-top:0px;">');
					$this->table->set_template($tmpl);
					$this->table->set_heading('S.NO', 'BARCODE','BOOK NAME','PRICE','REFERENCE','DUE DATE','DUE');*/
				
				$data['units'] = $this->library_model->GetAllCenters("",'option',$data['user']['lcenters']);               

				$data['menu'] = $this->load->view('headermenu', $data, TRUE);
                $this->load->view('header', $data);
                $this->load->view('issuehistory_view', $data);
                $this->load->view('footer');
				
            } else {
                //If no session, redirect to login page
                redirect('login', 'refresh');
            }
            
        }
        
	public function GetIssuedHistoryList() {
            
		if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in') ){
			
			$data['user'] = $this->login_model->GetUserId();
			
			$stuid = $this->input->post('stuid');
			
			$result =  $this->library_model->GetIssuedHistoryList($stuid);

			$row = array();
			
			$sno = 1;
			
			foreach($result as $key=>$col){			
				
				$booktype = check_booktype($col->booktype);
				$duedate = change_DateFormat($col->duedate);
				
				$created = date("d-M-Y h:i A",strtotime($col->created));
				$recieveddate = date("d-M-Y h:i A",strtotime($col->recieveddate)); 
				$recieved = $col->receivedstatus;
				$dueperiod = $col->dueperiod;
				
				if($recieved=="y"){
					$recieveddate = date("d-M-Y h:i A",strtotime($col->recieveddate)); 
					//$remaindue = get_issuehistoryremaindue($col->created,$col->recieveddate);
					$remaindue = "0";
					
				}else {
					$recieveddate = "-";
					$remaindue = get_bookremaindue($col->duedate);
				}
					
				$row[] = array($sno,$col->barcode,$col->bookname,$col->price,$booktype,$created,$duedate,$recieveddate,$remaindue);
									
				$sno++;
				
			}
									
			$ret = array("tabledata"=>$row);
			echo json_encode($ret);
			
		}else{
		//If no session, redirect to login page
		redirect('login', 'refresh');
		}

	}	

	
	public function getstudentdetails() {
            
        if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')) {
			
			$roleaccess = $this->config->item('roleaccess');
			
			if(isset($roleaccess['Issue Books'][3]) && $roleaccess['Issue Books'][3]=="y"){
			         
				$barcode = $this->input->post("barcode",true);
				$type = $this->input->post("type",true);
			
				if($type!="staff"){
					$studentdetails = $this->library_model->GetStudentProfile($barcode); //print_r($studentdetails);exit;
				}else{
					$studentdetails = $this->library_model->GetStaffProfile($barcode);
				}
			
			if(empty($studentdetails)){
				
				if($type!="staff"){$uname = "Student";}else{$uname = "Staff";}
				
					$response = array(
						'status' => 'error',
						'message' => $uname.' not found'
					);
				
				echo json_encode($response);
				
			}else{
				
				$response = array(
					'status' => 'success',
					'data' => $studentdetails
				);
				
				echo json_encode($response);
			}
                

			 } else {

 					$response = array(
						'status' => 'error',
						'message' => 'User Permission Denied'
					);
                    echo json_encode($response);
				
                }
              
               
            }else{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
            }
            
    }
	
	public function GetIssueBookDetails() {
            
		if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in') ){
			
			$data['user'] = $this->login_model->GetUserId();
			
			$stuid = $this->input->post('stuid');
			
			$result =  $this->library_model->GetIssueBookDetails($stuid);

			$row = array();
			
			$sno = 1;
			
			foreach($result as $key=>$col){			
				
				$booktype = check_booktype($col->booktype);
				$duedate = change_DateFormat($col->duedate);
				$remaindue = get_bookremaindue($col->duedate);
					
				$row[] = array($sno,$col->barcode,$col->bookname,$col->price,$booktype,$duedate,$remaindue);
									
				$sno++;
				
			}
									
			$ret = array("tabledata"=>$row);
			echo json_encode($ret);
			
		}else{
		//If no session, redirect to login page
		redirect('login', 'refresh');
		}

	}
	
	
	public function addissuebookSubmit() {
            
        if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')) {
                $this->load->library('form_validation');
			
			$roleaccess = $this->config->item('roleaccess');
			
			if(isset($roleaccess['Issue Books'][3]) && $roleaccess['Issue Books'][3]=="y"){
				
               				
				$stuid = $this->input->post('stuid', true);
				$barcode = $this->input->post('barcode', true);
                $center = $this->input->post('center', true);
				$action = $this->input->post('action', true);
			
				$studentdetails = $this->library_model->GetStudentProfile($stuid);
				$barcodedetails = $this->library_model->GetBarcodeDetails($barcode,$center);
				$issueddetails = $this->library_model->GetIssuedBookDetails($stuid);
			
				if(empty($studentdetails)){
					$response = array(
						'status' => 'error',
						'message' => "Student ID not found."
						);
					echo json_encode($response);
					exit(0);
				}
			
				if(empty($barcodedetails)){
					$response = array(
						'status' => 'error',
						'message' => "Book not found."
						);
					echo json_encode($response);
					exit(0);
				}
			
				if(intval($studentdetails['booklimit']) == $issueddetails['totalissued']){
					$response = array(
						'status' => 'error',
						'message' => "Book lending limit exceeded."
						);
					echo json_encode($response);
					exit(0);
				}
			
				//if($ibdid === "") {
			
					if($center==$barcodedetails['center']){
														
						$response = $this->insertQ($stuid,$barcode,$center,$studentdetails['id'],$barcodedetails['bookname'],$barcodedetails['price'],$barcodedetails['duedate'],$barcodedetails['dueperiod'],$barcodedetails['booktype'],$studentdetails['booklimit']);
						
					}else{
						$response = array(
						'status' => 'error',
						'message' => "Book center mismatch."
						);
					}
					
				/*}else {
					 $response = $this->updateQ($bsid);
				 }*/
				
				 echo json_encode($response);	
				
			 } else {

 					$response = array(
                            'status' => 'error',
                            'message' => 'User Permission Denied'
                        );
                        echo json_encode($response);
                }
              
               
            }else{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
            }
            
    }
    
        
    public function insertQ($stuid,$barcode,$center,$studentid,$bookname,$price,$duedate,$dueperiod,$booktype,$booklimit){
        
		$roleaccess = $this->config->item('roleaccess');
			
			if(isset($roleaccess['Issue Books'][3]) && $roleaccess['Issue Books'][3]=="y"){
				
        	$ide = uniqid();
				
			if($booktype=="Reference"){
				
				$duedate = date("Y-m-d",strtotime(date("Y-m-d")." + 1 days"));
				
			}
				
            $qData = array(
                'id' => $ide,
                'studentid' => $studentid,
                'studid' => $stuid,
                'center' => $center,
                'barcode' => $barcode,
                'bookname' => $bookname,
                'price' => $price,
                'quantity' => "1",
                'duedate' => $duedate,
                'issued' => "y",
                'received' => "",
                'created' => date('Y-m-d H:i:s')
            );
                       

            $result = $this->library_model->InsertIssueBook($qData,$booklimit);
              
			if($result=="success"){
				$response = array(
                'status' => 'success',
                'message' => "Book issued Successfully."
            	);
			}else if($result=="fail"){
				$response = array(
                'status' => 'fail',
                'message' => "Book issue failed."
            	);
			}else if($result=="exists"){
				$response = array(
                'status' => 'exists',
                'message' => "Book already issued."
            	);
			}
            
				
		 } else {

 					$response = array(
                            'status' => 'error',
                            'message' => 'User Permission Denied'
                        );
                        echo json_encode($response);
                }

          return $response;
    }
	
	public function addbarcodelistpreview(){
        
		$roleaccess = $this->config->item('roleaccess');
			
			if(isset($roleaccess['Issue Books'][3]) && $roleaccess['Issue Books'][3]=="y"){
				
			
				$stuid = $this->input->post('stuid', true);
				$barcode = $this->input->post('barcode', true);
                $center = $this->input->post('center', true);
                $totalbooks = $this->input->post('totalbooks', true);
                $type = $this->input->post('type', true);
				
				$row = $qData = array();
				
				$sno = 1;
				
				//print_r($barcodes);exit;
				
				//for($i=0;$i<count($barcodes);$i++){
				//$barcode = $barcodes[$i];
				
				if($type!="staff"){
					$studentdetails = $this->library_model->GetStudentProfile($stuid);
				}else{
					$studentdetails = $this->library_model->GetStaffProfile($stuid);
				}
				
				$barcodedetails = $this->library_model->GetBarcodeDetails($barcode,$center);
				$issueddetails = $this->library_model->GetIssuedBookDetails($stuid);
				
				$totalbooks = $totalbooks + $issueddetails['totalissued'];
								
				if(empty($studentdetails)){
					
					if($type!="staff"){$uname = "Student";}else{$uname = "Staff";}
					
					$response = array(
						'status' => 'error',
						'message' => $uname." not found.",
						'tabledata' => $row,
						'tablerow' => $qData
						);
					echo json_encode($response);
					exit(0);
				}
			
				if(empty($barcodedetails)){
					$response = array(
						'status' => 'error',
						'message' => "Book not found.",
						'tabledata' => $row,
						'tablerow' => $qData
						);
					echo json_encode($response);
					exit(0);
				}
			
				if(intval($studentdetails['booklimit']) == $totalbooks){
					$response = array(
						'status' => 'error',
						'message' => "Book lending limit exceeded.",
						'tabledata' => $row,
						'tablerow' => $qData
						);
					echo json_encode($response);
					exit(0);
				}
					
			$studentid = $studentdetails['id'];
			$bookname = $barcodedetails['bookname'];
			$duedate = $barcodedetails['duedate'];
			$booktype = $barcodedetails['booktype'];
			$price = $barcodedetails['price'];		
				
			if($booktype=="Reference"){
				
				$duedate = date("Y-m-d",strtotime(date("Y-m-d")." + 1 days"));
				
			}
			                       

            $result = $this->library_model->InsertIssueBookPreview($barcode);
					
              
			if($result=="success"){
				
				$ide = uniqid();
				
				$qData = array(
					'id' => $ide,
					'studentid' => $studentid,
					'studid' => $stuid,
					'center' => $center,
					'barcode' => $barcode,
					'bookname' => $bookname,
					'price' => $price,
					'quantity' => "1",
					'duedate' => $duedate,
					'issued' => "y",
					'received' => "n",
					'created' => date('Y-m-d H:i:s')
				);
				
				$booktype = check_booktype($booktype);
				$duedate = change_DateFormat($duedate);
				$remaindue = get_bookremaindue($duedate);
				
				$row = array('<p class="sno"></p>',$barcode,$bookname,$price,$booktype,$duedate,$remaindue,'<a class="del noedit" barcode="'.$barcode.'" href="javascript:void(0)"><img style="padding:5px 10px" src="images/delete.png"></a>');				
				
				$response = array(
                'status' => 'success',
                'message' => "Book Added.",
					'tabledata' => $row,
					'tablerow' => $qData
            	);
								
			}else if($result=="exists"){
				$response = array(
                'status' => 'exists',
                'message' => "Book Already Issued.",
					'tabledata' => $row,
					'tablerow' => $qData
            	);
			}
					
			//}
				
		 echo json_encode($response);	
				
		 } else {

			$response = array(
				'status' => 'error',
				'message' => 'User Permission Denied'
			);
			echo json_encode($response);
		}

          //return $response;
    }
	
	public function InsertIssueBook(){
        
		$roleaccess = $this->config->item('roleaccess');
			
			if(isset($roleaccess['Issue Books'][3]) && $roleaccess['Issue Books'][3]=="y"){
								
            $qData = $this->input->post('qData', true);

			if(empty($qData)){
				$response = array(
                'status' => 'success',
                'message' => "No Books Added."
            	);
				echo json_encode($response);
				exit(0);
			}	
				
            $result = $this->library_model->InsertIssueBook($qData);
              
			if($result=="success"){
				$response = array(
                'status' => 'success',
                'message' => "Books Issued Successfully."
            	);
			}else if($result=="fail"){
				$response = array(
                'status' => 'fail',
                'message' => "Books Issue Failed."
            	);
			}
            
				echo json_encode($response);
				
		 } else {

			$response = array(
				'status' => 'error',
				'message' => 'User Permission Denied'
			);
			echo json_encode($response);
		}

    }
    	
/*	public function updateQ($bsid){
        
		$roleaccess = $this->config->item('roleaccess');
			
			if(isset($roleaccess['Add Stock'][1]) && $roleaccess['Add Stock'][1]=="y"){
								
            $qData = array(
                'id' => $ide,
                'studentid' => $this->input->post('studentid', true),
                'studid' => $this->input->post('studid', true),
                'center' => $this->input->post('center', true),
                'barcode' => $this->input->post('barcode', true),
                'bookname' => $this->input->post('bookname', true),
                'price' => $this->input->post('price', true),
                'quantity' => "1",
                'duedate' => $this->input->post('duedate', true),
            );
                       

            $result = $this->library_model->UpdateBookStock($qData);
              
				$response = array(
                'status' => 'success',
                'message' => "Book stock updated Successfully."
            	);
            
				
		 } else {

			$response = array(
					'status' => 'error',
					'message' => 'User Permission Denied'
				);
			echo json_encode($response);
		}

          return $response;
    }
	
	 public function DelBookStock() {
            
            if ($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')) {
				
				$roleaccess = $this->config->item('roleaccess');
			
				if(isset($roleaccess['Add Stock'][2]) && $roleaccess['Add Stock'][2]=="y"){
			
					$ide = isset($_POST['ide']) ? $_POST['ide'] : '';
					$bid = isset($_POST['bid']) ? $_POST['bid'] : '';

					if($ide != ""){
						 $ret = $this->library_model->DelBookStock($ide,$bid);
					} else {
						$ret = array(0 => "fail");
					}

					echo json_encode($ret);
					
				} else {
                    $ret = array(0 => "fail");
					echo json_encode($ret);
                }
            
            }else {
                //If no session, redirect to login page
                redirect('login', 'refresh');
            }
                
        }*/
	
	
	public function issuebooklimitSubmit() {
            
        if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')) {
			
                $this->load->library('form_validation');

                $validatation["booklimit"] = "trim|required|xss_clean|callback_numeric|max_length[6]";
			
				foreach ($validatation as $key=>$val) {
					$this->form_validation->set_rules($key, "Book ", $val);
				}


                if ($this->form_validation->run() == false) {
					
                        $response = array(
                            'status' => 'error',
                            'message' => validation_errors()
                        );
                        echo json_encode($response);

                } else {
						
                     $response = $this->updateQ();					
                     
                     echo  json_encode($response);
                }
			
			
               
            }else{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
            }
            
    }
	
	
	 public function updateQ(){
        
		
		$roleaccess = $this->config->item('roleaccess');
			
			if(isset($roleaccess['Issue Books'][3]) && $roleaccess['Issue Books'][3]=="y"){
				
            $qData = array(
                'id' => $this->input->post('studentid', true),
                'booklimit' => $this->input->post('booklimit', true),
            );
                       

            $this->library_model->UpdateBookLimit($qData,$this->input->post('type', true));
                       
            $response = array(
                'status' => 'success',
                'message' => "Book Limit Updated Successfully."
            );
				
		}else {

		  $response = array(
				'status' => 'error',
				'message' => 'User Permission denied'
			);
			echo json_encode($response);
		}

          return $response;
    }
	
}
?>
<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Bookdetails extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model('login_model','',TRUE);
                $this->load->model('library_model','',TRUE);
                $this->load->library('table');
				$this->load->helper('form');
	
	}
	
	function index()
	{
		if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in'))
   		{
                    $session_data = $this->session->userdata('loggedin');
                    $session_id = $session_data['id'];
                    $session_role = $session_data['role'];
                    
                    $data['user'] = $this->login_model->GetUserId();		
		
					$data['roleaccess'] = $this->config->item('roleaccess');

					if($data['roleaccess']['Library Books'][3]!="y"){
						redirect($data['roleaccess']['defaultpage'], 'refresh');
					}
			
			
					$bid = $this->input->get('bid');
				
					$data['bid'] = $bid;
			
					$data['bookdetails'] = $this->library_model->BookDetails($bid);
			
					
					$data['units'] = $this->library_model->GetAllCenters("",'option',$data['user']['lcenters']);
					$data['menu'] = $this->load->view('headermenu', $data, TRUE);
																		
					$this->load->view('header',$data);
					$this->load->view('bookdetails_view', $data);
					$this->load->view('footer');
                    
		}
   		else
   		{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
   		}
		
	}
        
    
	 public function GetBookStock() {
            
		if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in') ){

			$data['user'] = $this->login_model->GetUserId();
			
			$bid = $this->input->post('bid');
			
			$ret =  $this->library_model->GetBookStock($bid,$data['user']['lcenters']);
			echo $ret;

		}else{
		//If no session, redirect to login page
		redirect('login', 'refresh');
		}

	}
	
	public function GetIssuedStockBookDetails() {
            
		if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in') ){

			$data['user'] = $this->login_model->GetUserId();
			
			$bid = $this->input->post('bid');
			
			$ret =  $this->library_model->GetIssuedStockBookDetails($bid);
			echo $ret;

		}else{
		//If no session, redirect to login page
		redirect('login', 'refresh');
		}
		
	}
	
	
}
?>

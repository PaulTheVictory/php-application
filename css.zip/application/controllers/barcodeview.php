<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Barcodeview extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model('login_model','',TRUE);
                $this->load->model('library_model','',TRUE);
                $this->load->library('table');
				$this->load->helper('form');
	
	}
	
	function index()
	{
		if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in'))
   		{
                    $session_data = $this->session->userdata('loggedin');
                    $session_id = $session_data['id'];
                    $session_role = $session_data['role'];
                    
                    $data['user'] = $this->login_model->GetUserId();		
		
					$data['roleaccess'] = $this->config->item('roleaccess');

					if($data['roleaccess']['Generate Barcodes'][3]!="y"){
						redirect($data['roleaccess']['defaultpage'], 'refresh');
					}
			
					$id = $this->input->get("id",true);
					$bcno = $this->input->get("bcno",true);
			
					if($id==""){
						
						redirect("generatebarcode","refresh");
					}
			
			
					$data['batchid'] = $id;
					$data['bcno'] = $bcno;
						
					$data['bcdetails'] = $this->library_model->GetBarcodeBatchdetails($id);
																	
					$data['menu'] = $this->load->view('headermenu', $data, TRUE);
						
					if($bcno!=""){
						
						$html = $this->load->view('barcodeviewprintpdf_view', $data, TRUE);
						
						$this->load->helper('Dompdf_helper');
						$filename = 'Generated Barcodes ('.$data['bcdetails']['barcodefrom'].' - '. $data['bcdetails']['barcodeto'].')';
						pdf_create($html, $filename, TRUE);
						
					}else{

						$this->load->view('header',$data);
						$this->load->view('barcodeview_view', $data);
						$this->load->view('footer');
						
					}
                    
		}
   		else
   		{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
   		}
		
	}
			
	
	public function barcodedatatable(){
		
		if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in'))
   		{
			$batchid = $this->input->post('batchid', true);
				
				
			$row = array();
			
			$sno = 1;
			
			$dirname = './docs/barcode/'.$batchid.'/';

			$fileList = glob($dirname.'*');
			foreach($fileList as $filelink){
				if(is_file($filelink)){
					//echo $filename, '<br>';
				$fname = pathinfo($filelink, PATHINFO_FILENAME);	
													
				$row[] = array('<a style="padding-left:10px;float:left;color:#0332AA;" class="noedit" href="javascript:void(0)"><input class="bccheckbox" type="checkbox" value="'.$fname.'"></a>',$sno,$fname,'<img src="'.$filelink.'" alt="'.$fname.'" />');
									
				$sno++;
																		
				}
				
			}
			
			$ret = array("tabledata"=>$row);
			echo json_encode($ret);
			
		}
   		else
   		{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
   		}
		
		
	}
	
}
?>

<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Notification extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model('login_model','',TRUE);
		$this->load->model('users_model','',TRUE);$this->load->model('course_model','',TRUE);
                $this->load->model('notification_model','',TRUE);
                $this->load->library('table');
				$this->load->helper('form');
	
	}
	
	function index()
	{
		if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in'))
   		{
                    $session_data = $this->session->userdata('loggedin');
                    $session_id = $session_data['id'];
                    $session_role = $session_data['role'];
                    
                    $data['user'] = $this->login_model->GetUserId();		
		
                    $data['roleaccess'] = $this->config->item('roleaccess');

                    if($data['roleaccess']['uview']!="y"){
                            redirect($data['roleaccess']['defaultpage'], 'refresh');
                    }


                    $data['batches'] = $this->users_model->GetAllBatches('');
                    $data['templates'] = $this->notification_model->GetAllTemplates('');

                    $data['menu'] = $this->load->view('headermenu', $data, TRUE);

					$this->load->view('header',$data);
                    $this->load->view('notification_view', $data);
                    $this->load->view('footer');
                    
		}
   		else
   		{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
   		}
		
	}
        
   
        public function emailSend() {
            
            $this->load->library('form_validation');
            
            $this->form_validation->set_rules('emailtext', 'Email Description', 'trim|required|xss_clean|max_length[5000]');
            $this->form_validation->set_rules('subject', 'Email Subject', 'trim|required|xss_clean|max_length[100]');
            
            
            if ($this->form_validation->run() == false) {
                $response = array(
                    'status' => 'error',
                    'message' => validation_errors()
                );
            }
            else {
                $subject = $this->input->post('subject', true);
                $emailtext = $this->input->post('emailtext', true);
                $type = $this->input->post('emsntype', true);
                $batch ="";$cid ="";$center ="";$sid ="";
                if($type === "batches"){
                    $batch = $this->input->post('embatches', true);
                    
                }else if($type === "coursewise"){
                     $cid = $this->input->post('emcourseid', true);
                     $center = $this->input->post('emcenter', true);
                    
                }else if($type === "individual"){
                    $sid = $this->input->post('emstudentid', true);
                }
                
                
               $this->notification_model->SendEmailNotification($type,$batch,$cid,$center,$sid,$subject,$emailtext);
                               
                
                $response = array(
                    'status' => 'success',
                    'message' => "Notification Sent Successfully."
                );

            }
            
            echo  json_encode($response);
            
        }
        
         public function studentSearch() {
		
           if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')){
        
            $inword  = isset($_GET['term'])?$_GET['term']:'';
		
            $ret = $this->notification_model->StudentNameSearch($inword);
            echo json_encode($ret);
            }
        }
        
         public function smsSend() {
            
            $this->load->library('form_validation');
            
            $this->form_validation->set_rules('templates', 'SMS Templates', 'trim|required|xss_clean|max_length[5000]');
            
            if ($this->form_validation->run() == false) {
                $response = array(
                    'status' => 'error',
                    'message' => validation_errors()
                );
            }
            else {
                $tid      = $this->input->post('templates', true);
                $tmessage = $this->input->post('tmessage', true);
                $smsdetails = $this->notification_model->GetSelectedTemplates($tid);
                $type = $this->input->post('smssntype', true);
                $batch ="";$cid ="";$center ="";$sid ="";
                if($type === "batches"){
                    $batch = $this->input->post('smsbatches', true);
                    
                }else if($type === "coursewise"){
                     $cid = $this->input->post('smscourseid', true);
                     $center = $this->input->post('smscenter', true);
                    
                }else if($type === "individual"){
                    $sid = $this->input->post('smsstudentid', true);
                }
                
                $smsdetails[0] = $tmessage;
                $this->notification_model->SendSMSNotification($type,$batch,$cid,$center,$sid,$smsdetails);
                               
                
                $response = array(
                    'status' => 'success',
                    'message' => "Notification Sent Successfully."
                );

            }
            
            echo  json_encode($response);
            
        }
        
        public function getTemplateMessages() {
            
            $id = $this->input->post('ide', true);
            if($id !== ""){
            $ret = $this->notification_model->GetSelectedTemplates($id);
            }else{
                $ret[0]="";
            }
             $response = array(
                    'status' => 'success',
                    'message' => $ret[0]
                );
            echo  json_encode($response);
        }
	
	
}
?>

<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Bulkimport extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model('login_model','',TRUE);
                $this->load->model('course_model','',TRUE);
                $this->load->library('table'); 
                $this->load->helper('download');
                 

	}
	
	function index()
	{
		if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in'))
   		{
                    $session_data = $this->session->userdata('loggedin');
                    $session_id = $session_data['id'];
                    $session_role = $session_data['role'];
                    
                    $data['user'] = $this->login_model->GetUserId();		
		
			
                    $data['roleaccess'] = $this->config->item('roleaccess');
			
					if(isset($data['roleaccess']['Bulk Admission'][3]) && $data['roleaccess']['Bulk Admission'][3]!="y"){
						redirect($data['roleaccess']['defaultpage'], 'refresh');
					}
			
                    $ide = isset($_GET['id']) ? $_GET['id'] : '';
                    $center = isset($_GET['center']) ? $_GET['center'] : '';
                    $data['menu'] = $this->load->view('headermenu', $data, TRUE);
                  
					$this->load->view('header_view', $data);
					$this->load->view('bulkimport_view', $data);
					$this->load->view('footer_view');
                        
         }
   		else
   		{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
   		}
		
	}
        
       
        
  public function uploadNewAdmission(){
            
		if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')){

			//print_r($_FILES);exit;
			
			if(isset($_FILES["file"]) && !empty($_FILES["file"]['name'])){
				
				$total = count($_FILES['file']['name']);
				
				$validExtensions = array('.xls');
				$imageExtensions = array('.jpg', '.jpeg', '.png', '.pdf');
				
				/*for( $i=0 ; $i < $total ; $i++ ) {
			
				$file_size = $_FILES['file']['size'][$i];
			
				if ((number_format($file_size / 1048576, 2) > 1)){      
					$ret = array('status'=>'ularge');
					echo json_encode($ret);
					exit(0);
				}
					
				}*/
				
				$dirname = FCPATH.'docs/newadmission/';
								
				$fileExtension = strrchr($_FILES['file']['name'][0], ".");
				$fileName = "newadmission".$fileExtension;
									
				$destinationfull = $dirname . $fileName;
					
				if(!file_exists($dirname)) mkdir($dirname,0777);
							
				if (in_array(strtolower($fileExtension), $validExtensions)) {
					
					$resultfull = move_uploaded_file($_FILES['file']['tmp_name'][0],$destinationfull);
					
					if(!$resultfull){
				    
						$ret = array('status' => "ufail");
						echo json_encode($ret);
						exit(0);
						
					}else{
						
						$result = $this->NewAdmissionImport($fileName);
						
						$ret = array('status' => "success","message"=>$result['message'],"tabledata"=>$result['tabledata']);
						echo json_encode($ret);
						exit(0);
						
					}
								
				}else{
					
					$ret = array('status' => "exfail");
					echo json_encode($ret);
					exit(0);
					
				}
					
								
			}else{
				
				$ret = array('status' => "empty");
				echo json_encode($ret);
				exit(0);
				
			}
			
			
		}
	  
  }
	
	
function NewAdmissionImport($fileName){
	
	include './import/excel_reader.php';     // include the class

	// creates an object instance of the class, and read the excel file data
	$excel = new PhpExcelReader;
	$excel->read(FCPATH.'docs/newadmission/'.$fileName);
	
	/*while (@ob_end_flush());      
	ob_implicit_flush(true);

	echo "Data Upload Initiated";
	echo str_pad("",1024," ");
	echo "<br />";

	sleep(2);

	echo "Start uploading...";
	echo "<br />";*/

	//exit;
	
	$sheet = $excel->sheets[0];
	
	$tb = 0;
	$x = 2;
 //if($dcount=="")$x = 2;else $x = $dcount;

//echo $sheet['numRows'];exit;
	
	$arr = array();
	
	$arr["message"] = "";
	$arr["tabledata"] = array();
	$tabledata = array('','','','','','','','');
	
 $myfile = fopen(FCPATH."docs/newadmission/newadmission_".date('d-m-Y-H_i_s').".txt", "w");

  while($x <= $sheet['numRows']) {
	  
	  //sleep(1);
	  
	  
	  $sno = isset($sheet['cells'][$x][1]) ? $sheet['cells'][$x][1] : '';
	  $studentno = isset($sheet['cells'][$x][2]) ? $sheet['cells'][$x][2] : '';
	  $courseno = isset($sheet['cells'][$x][3]) ? $sheet['cells'][$x][3] : '';
	  $centerid = isset($sheet['cells'][$x][4]) ? $sheet['cells'][$x][4] : '';
	  $partialamt = isset($sheet['cells'][$x][5]) ? $sheet['cells'][$x][5] : '';
	  
	  
	  //echo $x.". ".$studentno."<br />";$x++;continue;
	  
	 if($partialamt!="") $partialamt = intval($partialamt); else $partialamt = "";
	  
	  	  
	  if($studentno=="" || $courseno == "" || $centerid == ""){
		  
		  $arr["message"] .= "<p class='fail'>".($x-1).". No Student No: ".$studentno." or No Course No: ".$studentno." or No Center ID: ".$studentno."</p><hr>";
		  
		  $tabledata[0] = $studentno;
		  $tabledata[2] = $courseno;
		  $tabledata[4] = $centerid;
		  $tabledata[6] = $partialamt;
		  $tabledata[7] = "<p class='fail'> No Student ID or No Course ID or No Center ID</p>";
		  $arr["tabledata"][$tb] = $tabledata;
		  
		  $txt = ($x-1).". SNO:".$studentno."-CNO:".$courseno."-CID:".$centerid."\n";
		  fwrite($myfile, $txt);
		  
		  $x++;$tb++;continue;
		  
	  }
	  	  
	  $this->load->model('import_model','',TRUE);
	  
	  $studdetails = $this->import_model->getStudentno($studentno);
	  
	  $studarr = explode("-",$studdetails);
	  
	  $studid = $studarr[0];
	  $studentname = $studarr[1];
	  	  
	  if($studid == ""){
		  
		  $arr["message"] .= "<p class='fail'>".($x-1).". No Student No.: ".$studentno."</p><hr>";
		  
		  $tabledata[0] = $studentno;
		  $tabledata[2] = $courseno;
		  $tabledata[4] = $centerid;
		  $tabledata[6] = $partialamt;
		  $tabledata[7] = "<p class='fail'> No Student ID</p>";
		  $arr["tabledata"][$tb] = $tabledata;
		  
		  $txt = ($x-1).". SNO:".$studentno."-NF \n";
		  fwrite($myfile, $txt);
		  
		  $x++;$tb++;continue;
	  }
	  
	  $tabledata[1] = $studentno;
		  		  
		//echo $x.". ".$studid." - ".$studentname."<br />";$x++;continue;
			  
		  $courseresult = $this->import_model->getcourseid($courseno,'');

		  $carr = explode("-",$courseresult);
		  $courseid = $carr[0];
	  	  $qid = $carr[2];
	  	  $coursename = $carr[3];
	  
	  	 
	  	  if($courseid==""){
			  
			   $arr["message"] .= "<p class='fail'> ".($x-1).". No Course No: ".$courseno." Student ID: ".$studentno."</p><hr>";
			  
			  $tabledata[0] = $studentno; $tabledata[1] = $studentname;
			  $tabledata[2] = $courseno;
			  $tabledata[4] = $centerid;
			  $tabledata[6] = $partialamt;
			  $tabledata[7] = "<p class='fail'> No Course ID</p>";
			  $arr["tabledata"][$tb] = $tabledata;
			  
			  $txt = ($x-1).". SNO:".$studentno."-CNO:".$courseno."-NF \n";
		  	  fwrite($myfile, $txt);
			  
			  $x++;$tb++;continue;
		  }
	  
	  
	   	  $centername = $this->import_model->getcentername($centerid);
	  
		  if($centername==""){
			  
			   $arr["message"] .= "<p class='fail'>".($x-1).". No Center Name ".$centerid." Student ID:".$studentno." Course No: ".$courseno."</p><hr>";
			  
			  $tabledata[0] = $studentno; $tabledata[1] = $studentname;
			  $tabledata[2] = $courseno;$tabledata[3] = $coursename;
			  $tabledata[4] = $centerid;
			  $tabledata[6] = $partialamt;
			  $tabledata[7] = "<p class='fail'> No Center Name</p>";
			  $arr["tabledata"][$tb] = $tabledata;
			  
			  $txt = ($x-1).". SNO:".$studentno."-CNO:".$courseno."-CID:".$centerid."-NF \n";
		  	  fwrite($myfile, $txt);
			  
			  $x++;$tb++;continue;
			  
		  }
	  
	  	  $basecenter = $centername;
			  		
	  	  //echo $x.". ".$courseid." - ".$basecenter."<br />";$x++;continue;
	  
	  
	  	 $arr["message"] .= '<div class="row"><div class="col-6"><h3>'.($x-1).'. Student No: <span>'.$studentno.'</span></h3></div><div class="col-6"><h3>Course No: <span>'.$courseno.'</span></h3></div></div>';
	  
		  
		   // Course Request
		  
		  $requestid = $this->import_model->getcourserequestid($studentno,$courseno,$studid,$courseid,$basecenter,$qid);
		  
		  //$stupayid = getstudentpaymentid($LConnect,$studesc,$requestid,$courseid,$studid);
		  	
	  
	  if($requestid!=""){
		  
		  // Admin Group
		  
		  $checkcoursegroup = $this->import_model->checkcoursegroupimport($courseid,$basecenter);
		  		  
		  if($checkcoursegroup)
		  {
			   $cgmessage = $this->import_model->insertcoursegroupimport($studentno,$courseno,$courseid,$basecenter,$studid,$requestid);
			  
			   $arr["message"] .= $cgmessage['message'];
				  			  
			  
			  if(!$cgmessage['checkexists']){
				  
				$arr["message"] .= "<p class='success'> Admission done.</p>";
				  
				  $tabledata[7] = "<p class='success'>done</p>";
				  
			  	$txt = ($x-1).". SNO:".$studentno."-CNO:".$courseno."-CID:".$centerid."-RID:".$requestid."-DONE \n";
		  	  	fwrite($myfile, $txt);
				  
			  }else{
				  
				  $arr["message"] .= "<p class='exists'> Admission already done.</p>";
				  
				  $tabledata[7] = "<p class='exists'>Exists</p>";
				  
				  $txt = ($x-1).". SNO:".$studentno."-CNO:".$courseno."-CID:".$centerid."-RID:".$requestid."-EXISTS \n";
		  	  	  fwrite($myfile, $txt);
			  }
			  
			  if($partialamt!="" && $partialamt!=0){
			  	$arr["message"] .= $this->import_model->insertpartialpaymentimport($studentno,$courseno,$requestid,$studid,$courseid,$partialamt);
			  }
			  
			  $arr["message"] .= "<hr>";
			  
			  $tabledata[0] = $studentno; $tabledata[1] = $studentname;
			  $tabledata[2] = $courseno;$tabledata[3] = $coursename;
			  $tabledata[4] = $centerid;$tabledata[5] = $basecenter;
			  $tabledata[6] = $partialamt;
			  $arr["tabledata"][$tb] = $tabledata;
			  			  
		 }else{
			  
			  $arr["message"] .= "<p class='fail'>".($x-1).". No Fee structure</p><hr>";
			  
			  $tabledata[0] = $studentno; $tabledata[1] = $studentname;
			  $tabledata[2] = $courseno;$tabledata[3] = $coursename;
			  $tabledata[4] = $centerid;$tabledata[5] = $basecenter;
			  $tabledata[6] = $partialamt;
			  $tabledata[7] = "<p class='fail'> No Fee structure</p>";
			  $arr["tabledata"][$tb] = $tabledata;
			  
			  $txt = ($x-1).". SNO:".$studentno."-CNO:".$courseno."-CID:".$centerid."-RID:".$requestid."-NFS \n";
		  	  fwrite($myfile, $txt); 	
			  
			  $x++;$tb++;continue;
		  }
		  
	  }else{
			  
			  $arr["message"] .= "<p class='fail'> ".($x-1).". Admission Not Found or Insert Failed </p><hr>";
		  
		  	  $tabledata[0] = $studentno; $tabledata[1] = $studentname;
			  $tabledata[2] = $courseno;$tabledata[3] = $coursename;
			  $tabledata[4] = $centerid;$tabledata[5] = $basecenter;
			  $tabledata[6] = $partialamt;
			  $tabledata[7] = "<p class='fail'>Not Found or Insert Failed </p>";
			  $arr["tabledata"][$tb] = $tabledata;
		  
		      $txt = ($x-1).". SNO:".$studentno."-CNO:".$courseno."-CID:".$centerid."-NCR \n";
		  	  fwrite($myfile, $txt);
		  
		  	  $x++;$tb++;continue;
			  			  
		  }
			  
		  		  
		  //exit;
	  	  
		  $x++;$tb++;
		  		  			  
  }
	
	fclose($myfile);
	
	return $arr;

	
}
	
	
}
?>

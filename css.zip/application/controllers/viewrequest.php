<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Viewrequest extends CI_Controller {
    
        
	function __construct()
	{
		parent::__construct();
		$this->load->model('course_model','',TRUE);
                $this->load->model('login_model','',TRUE);
                $this->load->model('qualification_model','',TRUE);
                $this->load->model('payment_model','',TRUE);
                 $this->load->model('student_model','',TRUE);
                 $this->load->model('users_model','',TRUE);
                $this->load->library('table');$this->load->helper('form');
                

	}
	
	function index()
	{
		if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in') )
   		{
                    
     		    $session_data = $this->session->userdata('loggedin');
		    $session_id = $session_data['id'];
     		    $session_role = $session_data['role'];
		    $data['user'] = $this->login_model->GetUserId();
			
					$data['roleaccess'] = $this->config->item('roleaccess');

					if(isset($data['roleaccess']['Admission Request'][3]) && $data['roleaccess']['Admission Request'][3]!="y"){
						redirect($data['roleaccess']['defaultpage'], 'refresh');
					}
			
                     $data['menu'] = $this->load->view('headermenu', $data, TRUE);
                    $ide = isset($_GET['id']) ? $_GET['id'] : '';
                    $data['rid'] = $ide;
                    $arr= $this->qualification_model->ViewCourseRequest($ide);
                      $tmpl = array('table_open' => '<table class="sortable sorting disabled" id="paymenttable" style="margin-top:0px;">');
                                $this->table->set_template($tmpl);
                                $this->table->set_heading('S.NO', 'DESCRIPTION','STATUS','SAC','AMOUNT', 'DISCOUNT','GST(%)','KF(%)','COV(%)','TOTAL','PAID','DUE (Without GST)');
                    
                    if($arr === '') {
                        redirect('login', 'refresh');
                    } else{
                        $data['qualification'] = $arr[0];
                       
                    }
                    
                    $data['course'] = $this->course_model->EditCourse($data['qualification']['courseid'],'');
                    $data['student'] = $this->qualification_model->GetStudentName($data['qualification']['studentid'],'');
                    $data['units'] = $this->course_model->GetAllCenters("",'option');
					$data['branch'] = $this->users_model->GetAllCenters("","option");
			
					$data['partialpaydetails'] = $this->payment_model->GetPartialPayment($ide,$data['qualification']['studentid'],$data['qualification']['courseid']);
                    
                    $this->load->view('header_view', $data);
                    $this->load->view('courseviewrequest_view', $data);
                    $this->load->view('footer_view'); 
                    
                }
   		else
   		{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
   		}
		
	}
        
        
         public function getPaymentLists() {
            
            if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in') || $this->session->userdata('studlog_in')){
                $ide = isset($_POST['ide']) ? $_POST['ide'] : '';
                $center = isset($_POST['center']) ? $_POST['center'] : '';
                $user = isset($_POST['studid']) ? $_POST['studid'] : '';
                $rid = isset($_POST['rid']) ? $_POST['rid'] : '';
                $ret =  $this->payment_model->GetCenterWisePaymentItems($ide,$center,$user,$rid);
                echo $ret;
                
            }else{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
            }
            
        }
        
        public function ApproveRequest(){
            
            if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')){

                $ide = isset($_GET['ide']) ? $_GET['ide'] : '';
                $cride = isset($_GET['cride']) ? $_GET['cride'] : '';
                $stuid = isset($_GET['stuid']) ? $_GET['stuid'] : '';
                $qid = isset($_GET['qid']) ? $_GET['qid'] : '';

                if($ide != ""){
                    $ide = $ide."|";
                    $ret = $this->course_model->ApproveRequest($ide);
                     
                   // $studentcoursepay =  $this->student_model->GetCourseStudentPayment($stuid,$qid,$ide);
			
		    		//$challan = $this->student_model->CreateChallan($stuid,$studentcoursepay);
										
                     $ret = array(0 => "success");
                     
                } else {
                    $ret = array(0 => "fail");
                }

                echo json_encode($ret);
            
            }else {
                //If no session, redirect to login page
                redirect('login', 'refresh');
            }
            
        }
        
              
         public function DeclineRequest(){
            
            if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')){

                $ide = isset($_GET['ide']) ? $_GET['ide'] : '';

                if($ide != ""){
                     $ret = $this->course_model->UpdateCourseStatus($ide,"d");
                } else {
                    $ret = array(0 => "fail");
                }

                echo json_encode($ret);
            
            }else {
                //If no session, redirect to login page
                redirect('login', 'refresh');
            }
            
        }
        
        public function WaitingRequest(){
            
            if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')){

                $ide = isset($_GET['ide']) ? $_GET['ide'] : '';

                if($ide != ""){
                     $ret = $this->course_model->UpdateCourseStatus($ide,"w");
                } else {
                    $ret = array(0 => "fail");
                }

                echo json_encode($ret);
            
            }else {
                //If no session, redirect to login page
                redirect('login', 'refresh');
            }
            
        }
  
        public function PaySubmit() {
          
        if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')){  
        $this->load->library('form_validation');
        $this->form_validation->set_rules('pdata', 'Payment', 'trim|required|xss_clean|max_length[10000]');
          
          if ($this->form_validation->run() == false) {
            $response = array(
                'status' => 'error',
                'message' => validation_errors()
            );
        } else {
            
                $this->payment_model->AddStudentPayment($this->input->post('pdata', true),$this->input->post('cid', true),$this->input->post('sid', true),$this->input->post('rid', true));
           
          
          $response = array(
                'status' => 'success',
                'message' => "Payment Updated Successfully."
            );
            
        }
        
        echo  json_encode($response);
        
        }else{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
            }
        
      }
      
      public function DeleteLineItem(){
            
            if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')){

                $ide = isset($_GET['id']) ? $_GET['id'] : '';

                if($ide != ""){
                     $ret = $this->payment_model->DeletePayItem($ide);
                } else {
                    $ret = array(0 => "fail");
                }

                echo json_encode($ret);
            
            }else {
                //If no session, redirect to login page
                redirect('login', 'refresh');
            }
            
        }
        
          public function getChallanLists() {
            
            if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in') || $this->session->userdata('studlog_in')){
                $ide = isset($_POST['ide']) ? $_POST['ide'] : '';
                $user = isset($_POST['studid']) ? $_POST['studid'] : '';
                $center = isset($_POST['center']) ? $_POST['center'] : '';
                $ret =  $this->payment_model->GetChallanLists($ide,$user,$center);
                echo $ret;
                
            }else{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
            }
            
        }
        
        public function getAddPaymentLists() {
            
            if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in') || $this->session->userdata('studlog_in')){
                $ide = isset($_POST['ide']) ? $_POST['ide'] : '';
                $cid = isset($_POST['cid']) ? $_POST['cid'] : '';
                $sid = isset($_POST['sid']) ? $_POST['sid'] : '';
                
                $ret =  $this->payment_model->GetAddPaymentLists($ide,$cid,$sid);
                echo $ret;
                
            }else{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
            }
            
        }
        
        
        public function addPayment(){
            
            if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')){

                $chno = isset($_GET['chno']) ? $_GET['chno'] : '';
                $pdate = isset($_GET['pdate']) ? $_GET['pdate'] : '';
                $ptime = isset($_GET['ptime']) ? $_GET['ptime'] : '';
                $amtpaid = isset($_GET['amtpaid']) ? $_GET['amtpaid'] : '';
                $paymode = isset($_GET['paymode']) ? $_GET['paymode'] : '';
                $pdescription = isset($_GET['pdescription']) ? $_GET['pdescription'] : '';
                $ide = isset($_GET['ide']) ? $_GET['ide'] : '';
                $studid = isset($_GET['studid']) ? $_GET['studid'] : '';
               
				$billno = isset($_GET['billno']) ? $_GET['billno'] : '';
				$type = isset($_GET['type']) ? $_GET['type'] : '';
				$adminpassword = isset($_GET['adminpassword']) ? $_GET['adminpassword'] : '';
				
                if(ide != ""){
					
					
					//$checkadminpass = $this->student_model->checkAdminPassword($adminpassword);
					
					if($adminpassword != $this->config->item('super_pass') && $type=="paid"){
						$ret = array(0 => "passfail");
						echo json_encode($ret);exit;
					}
					
                     $this->payment_model->AddPaymentForChallan($chno,$pdate,$ptime,$amtpaid,$ide,$studid,$paymode,$pdescription,'',$billno,$type);
					
					if($type!="paid"){
					
						$this->load->model('notification_model','',TRUE);
				 		$this->notification_model->SubsequentPaymentNotification($studid,$amtpaid);
						
					}
					
                     $ret = array(0 => "success");
                } else {
                    $ret = array(0 => "fail");
                }

                echo json_encode($ret);
            
            }else {
                //If no session, redirect to login page
                redirect('login', 'refresh');
            }
            
        }
	
	
	 public function addPartialPayment(){
            
		if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')){

			$cride = $this->input->post('cride');
			$courseid = $this->input->post('ide');
			$studid = $this->input->post('studid');
			$partialamt = $this->input->post('partialamt');
			$grandtotal = $this->input->post('grandtotal');               

			$ret = $this->payment_model->AddPartialPayment($cride,$courseid,$studid,$partialamt,$grandtotal);
			echo json_encode($ret);

		}else {
			//If no session, redirect to login page
			redirect('login', 'refresh');
		}
            
    }
	
	
	
	// Edit Payment
	
	public function getEditPaymentLists() {
            
            if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in') || $this->session->userdata('studlog_in')){
                $ide = isset($_POST['ide']) ? $_POST['ide'] : '';
                $cid = isset($_POST['cid']) ? $_POST['cid'] : '';
                $sid = isset($_POST['sid']) ? $_POST['sid'] : '';
                
                $ret =  $this->payment_model->GetEditPaymentLists($ide,$cid,$sid);
                echo $ret;
                
            }else{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
            }
            
      }
	
	
      
      public function addRefundPayment(){
            
		if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')){

			$cride = $this->input->post('cride');
			$courseid = $this->input->post('ide');
			$studid = $this->input->post('studid');
			$refundamt = $this->input->post('refundamt');
                        $center = $this->input->post('center');
			
                        
                         $stuprofile =  $this->student_model->GetStudentProfile($studid);
                        $refundid = uniqid();
                         $qData = array(
                                        'id' => $refundid,
                                        'studentid' => $studid,
                                        'studid' =>$stuprofile['studid'],
                                        'courseid' => $courseid,
                                        'requestid' => $cride,
                                        'center' => $center,
                                        'reason' => "Discounts/Scholarship",
                                        'doj' => '',
                                        'batch' => '',
                                        'housenameno' => $stuprofile['housenameno'],
                                        'contactaddress' => $stuprofile['contactaddress'],
                                        'contactpost' => $stuprofile['contactpost'],
                                        'contactcountry' => $stuprofile['contactcountry'],
                                        'contactstate' => $stuprofile['contactstate'],
                                        'contactdistrict' => $stuprofile['contactdistrict'],
                                        'contactpincode' => $stuprofile['contactpincode'],
                                        'accountholdername' => '',
                                        'bankname' => $stuprofile['bankname'],
                                        'branch' => $stuprofile['branch'],
                                        'ifsccode' => $stuprofile['ifsccode'],
                                        'bankaccountno' => $stuprofile['bankaccountno'],
                                        'status' => 'w',
                                        'type' => "Discounts/Scholarship",
                                        'requestedrefundamt' => $refundamt,
                                        'created_at' => date('Y-m-d H:i:s')
                                    );
                                     $type = 'init';
                                    $this->payment_model->AddRefundApplication($qData,$type);
                                    $ret = array(0 => "success");

			echo json_encode($ret);

		}else {
			//If no session, redirect to login page
			redirect('login', 'refresh');
		}
            
    }
	
}
?>
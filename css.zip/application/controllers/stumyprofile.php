<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

use Dompdf\Dompdf;
use \setasign\Fpdi;

class Stumyprofile extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model('login_model','',TRUE);
                $this->load->model('course_model','',TRUE);
				$this->load->model('student_model','',TRUE);
		$this->load->model('payment_model','',TRUE);
		$this->load->model('qualification_model','',TRUE);
                 $this->load->library('table'); 

	}
	
	function index()
	{
		if($this->session->userdata('loggedin'))
   		{
                    $session_data = $this->session->userdata('loggedin');
                    $session_id = $session_data['id'];
                    $session_role = $session_data['role'];
                    
                    $data['user'] = $this->login_model->GetUserId();		
		
					if($session_role === 'student') {
						
						$data['action'] = $this->input->get('action');
						$cride = $this->input->get('id');
						
						$data['cride'] = $cride;
 												
						//$qid = $this->student_model->GetQualificationID($data['user']['id']);
								
						$data['qualificationoption'] = $this->qualification_model->GetAllQualifications('');
						
						$data['countrylist'] = $this->student_model->getCountryList();
						$data['statelist'] = $this->student_model->GetStateList();
						
						$data['stuprofile'] =  $this->student_model->GetStudentProfile($data['user']['id']);
						
						$data['coursepay'] =  $this->student_model->GetCoursePayment($data['user']['id'],$data['user']['qualificationid'],$cride);
						$data['studentcoursepay'] =  $this->student_model->GetCourseStudentPayment($data['user']['id'],$data['user']['qualificationid'],$cride);
						
						$data['qualification'] = $this->student_model->ViewStudentQualification($data['user']['id'],$data['user']['qualificationid']);
												
						$this->load->view('header', $data);
						
						if($data['action']=="profileedit" || $data['action']=="register"){
							
							$data['feesmaster'] = $this->student_model->getFeesMaster();
							$data['partialpaydetails'] = $this->payment_model->GetPartialPayment($cride,$data['user']['id'],$data['studentcoursepay'][0]['courseid']);
							
							$this->load->view('student_myprofile_view', $data);
						}else{
							$data['qualname'] = $this->student_model->GetQualificationname($data['stuprofile']['medium']);
							$this->load->view('student_myprofileview_view', $data);
						}
						
						$this->load->view('footer');
                            
                     }else{
						//If no session, redirect to login page
     					redirect('dashboard', 'refresh');
					}
		}
   		else
   		{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
   		}
		
	}
	
	
	public function myprofileSubmit() {
          
        if($this->session->userdata('loggedin')) {
			
			$session_data = $this->session->userdata('loggedin');
			$session_id = $session_data['id'];
			$session_role = $session_data['role'];

			$data['user'] = $this->login_model->GetUserId();
			
			//print_r($_FILES);print_r($_POST);exit;
			
        	$checkmyprofile = $this->student_model->CheckMyprofile($data['user']['id']);
			
			$data['stuprofile'] =  $this->student_model->GetStudentProfile($data['user']['id']);
			
			if($this->input->post('profilepercent', true)>$data['stuprofile']['profilepercent'])
			{
				$profilepercent = $this->input->post('profilepercent', true);
			}else{
				$profilepercent = $data['stuprofile']['profilepercent'];
			}
			
			if(intval($profilepercent) > 80){ 
				$profilepercent = 80;
			}
			
			if($data['stuprofile']['profilepic']!="" && $data['stuprofile']['profilepic']!="0"){
				$profilepercent = $profilepercent + 20;
			}
			
            $id = uniqid();
			
			$dob = $this->input->post('mpdob', true);
			$dob = date("Y-m-d",strtotime($dob));
			
			$pincode = $this->input->post('mppincode', true);
			$contactpincode = $this->input->post('mpcontactpincode', true);
			
			
			$mcode = $data['stuprofile']['smcode'];
			$mobile = $data['stuprofile']['smobile'];
			$email = $data['stuprofile']['semail'];
			
			if($pincode=="") $pincode = 0;
			if($contactpincode=="") $contactpincode = 0;
			
            $mpData = array(
                'stuid' => $data['user']['id'],
                'name' => $data['stuprofile']['stuname'],
				'mcode' => $mcode,
				'mobile' => $mobile,
				'email' => $email,
                'gender' => $this->input->post('mpgender', true),
                'dob' => $dob,
                'fathername' => $this->input->post('mpfathername', true),
                'fatheroccupation' => $this->input->post('mpfatheroccupation', true),
                'fatheremail' => $this->input->post('mpfatheremail', true),
                'fathercode' => $this->input->post('mpfathercode', true),
                'fatherphone' => $this->input->post('mpfathermobile', true),
                'mothername' => $this->input->post('mpmothername', true),
                'motheroccupation' => $this->input->post('mpmotheroccupation', true),
                'motheremail' => $this->input->post('mpmotheremail', true),
                'mothercode' => $this->input->post('mpmothercode', true),
                'motherphone' => $this->input->post('mpmothermobile', true),
                'communicationcontact' => $this->input->post('mpcomcontact', true),
                'nationality' => $this->input->post('mpnationality', true),
                'category' => $this->input->post('mpcategory', true),
                'bloodgroup' => $this->input->post('mpbloodgroup', true),
                'classstudy' => $this->input->post('mpclassstudy', true),
                'stream' => $this->input->post('mpstream', true),
                'schoolcollegename' => $this->input->post('mpcollegename', true),
                'eduaddress' => $this->input->post('mpaddressline', true),
                'edulandmark' => $this->input->post('mplandmark', true),
                'edudistrict' => $this->input->post('mpdistrict', true),
                'edustate' => $this->input->post('mpstate', true),
                'edupost' => $this->input->post('mppost', true),
                'edupincode' => $pincode,
                'educountry' => $this->input->post('mpcountry', true),
                'examboard' => $this->input->post('mpexamboard', true),
                'examclass' => $this->input->post('mpexamclass', true),
                'gradepercent' => $this->input->post('mpgradepercent', true),
                'preferredsubject' => $this->input->post('mpprefersubject', true),
                'eligiblescholar' => $this->input->post('mpscholarship', true),
                'medium' => $this->input->post('mpmedium', true),
                'mocktype' => $this->input->post('mpmocktype', true),
                'rollno' => $this->input->post('mprollno', true),
                'housenameno' => $this->input->post('mpcontacthouseno', true),
                'landmark' => $this->input->post('mpcontactlandmark', true),
                'contactaddress' => $this->input->post('mpcontactaddressline', true),
                'contactcountry' => $this->input->post('mpcontactcountry', true),
                'contactstate' => $this->input->post('mpcontactstate', true),
                'contactdistrict' => $this->input->post('mpcontactdistrict', true),
                'contactpost' => $this->input->post('mpcontactpost', true),
                'contactpincode' => $contactpincode,
				'guardianname' => $this->input->post('mpguardianname', true),
                'wacode' => $this->input->post('mpwacode', true),
                'whatsappno' => $this->input->post('mpwhatsappno', true),
                'accountholdername' => $this->input->post('mpaccholdername', true),
                'bankname' => $this->input->post('mpbankname', true),
                'branch' => $this->input->post('mpbranch', true),
                'ifsccode' => $this->input->post('mpifsccode', true),
                'bankaccountno' => $this->input->post('mpaccountnumber', true),
                'aadharnumber' => $this->input->post('mpaadharnumber', true),
                'profilepercent' => $profilepercent,
                'status' => 'a'
            );
            
			$marksheets = array();
			
			if(isset($_FILES["file"]) && !empty($_FILES["file"]['name'])){
				
				$total = count($_FILES['file']['name']);
				
				$validExtensions = array('.pdf', '.doc', '.docx');
				$imageExtensions = array('.jpg', '.jpeg', '.png', '.pdf');
				
				for( $i=0 ; $i < $total ; $i++ ) {
			
				$file_size = $_FILES['file']['size'][$i];
			
				if ((number_format($file_size / 1048576, 2) > 1)){      
					$ret = array('status'=>'ularge');
					echo json_encode($ret);
					exit(0);
				}
					
				}
				
				$dirname = FCPATH.'docs/marksheets/'.$data['user']['id'].'/';
				
				for( $i=0 ; $i < $total ; $i++ ) {
				
				$fileExtension = strrchr($_FILES['file']['name'][$i], ".");
				$fileName = "marksheet".($i+1).$fileExtension;
					
				$marksheets[$i] = $fileName;	
				
				$destinationfull = $dirname . $fileName;
					
				if(!file_exists($dirname)) mkdir($dirname,0777);
			
				if(file_exists($dirname.$prefileName)) unlink($dirname.$prefileName);
				
				if (in_array(strtolower($fileExtension), $imageExtensions)) {
					
					$resultfull = move_uploaded_file($_FILES['file']['tmp_name'][$i],$destinationfull);
					
					if(!$resultfull){
				    
						$ret = array('status' => "ufail");
						echo json_encode($ret);
						exit(0);
					}
								
				}else{
					
					$ret = array('status' => "exfail");
					echo json_encode($ret);
					exit(0);
					
				}
					
				}
								
			} 
			
			if(!empty($marksheets)){
				
				$mpData['marksheets'] = implode("|",$marksheets);
				
			}else{
				$mpData['marksheets'] = "0";
			}
			
			if(empty($mpData)){
				$response = array('status' => 'empty');
				echo  json_encode($response);
			}
			
			date_default_timezone_set('Asia/Kolkata');
			
			$mpData['updated_at'] = date('Y-m-d H:i:s');
			
			if(!$checkmyprofile){
				
				$mpData['id'] = $id;
				$mpData['profilepic'] = "0";
				$mpData['created_at'] = date('Y-m-d H:i:s');
				
				//$mpData = array_filter($mpData);
				
				$id = $this->student_model->SubmitMyprofile($mpData);
				$response = array(
					'status' => 'success',
					'id' => $id
				);
				echo  json_encode($response);
				
			}else{
								
				$mpData = array_filter($mpData);
				
				$id = $this->student_model->UpdateMyprofile($mpData);
				$response = array(
					'status' => 'success',
					'id' => $data['user']['id']
				);
				echo  json_encode($response);
				
			}
			
          
        }else {
                //If no session, redirect to login page
                redirect('login', 'refresh');
            }
    }
	
	
	public function getDistrictList() {
          
        if($this->session->userdata('loggedin')) {
			
			$state = $this->input->post('state');
			
			$result = $this->student_model->GetDistrictList($state);
			echo json_encode($result);
			
		}
	}
	
	public function getCountryStateList() {
          
        if($this->session->userdata('loggedin')) {
			
			$country = $this->input->post('country');
			
			$result = $this->student_model->GetCountryStateList($country);
			echo json_encode($result);
			
		}
	}
	
	
	// Upload Profile Picture
	
	public function changeProfilePhoto() {
		
		if($this->session->userdata('loggedin')) {
			
			//$post = isset($_POST) ? $_POST: array();
			$maxWidth = "500"; 
			$studentid = $this->input->post('studentid', true);
			$path = 'docs/profilepic/'.$studentid.'/';
			$validFormats = array("2", "3");
			$picName = $_FILES['profileImage']['name'];
			$size = $_FILES['profileImage']['size'];
			if(strlen($picName)) {
				//list($txt, $ext) = explode(".", $picName);
                                $extCode = exif_imagetype($_FILES['profileImage']['tmp_name']);
				$extArray = array();
                                $extArray["2"] ="jpeg";$extArray["3"] ="png";
				if(in_array($extCode,$validFormats)) {
					if($size<(1024*500)) {
						
						if(!file_exists($path)) mkdir($path,0777);
						$ext = $extArray[$extCode];
						$actualImageName = 'main.'.$ext;
						$filePath = $path.$actualImageName;
						$tmp = $_FILES['profileImage']['tmp_name'];
						if(move_uploaded_file($tmp, $filePath)) {
							$width = $this->getWidth($filePath);
							$height = $this->getHeight($filePath);						
							if ($width > $maxWidth){
								$scale = $maxWidth/$width;
								$uploaded = $this->resizeImage($filePath,$width,$height,$scale, $ext);
							} else {
								$scale = 1;
								$uploaded = $this->resizeImage($filePath,$width,$height,$scale, $ext);
							}
							
							$result = $this->student_model->UpdateProfilePic($studentid,$actualImageName);
							
							if($result){
								echo "<img id='photo' class='mw-100' file-name='".$actualImageName."' class='' src='".$filePath.'?'.time()."' class='preview'/>";}
							else{ echo "Upload failed";}
						}
						else
						echo "<p class='alert alert-danger mt-4'>Upload failed</p>";
					}
					else
					echo "<p class='alert alert-danger mt-4'>Image file size max 500 KB</p>"; 
				}
				else
				echo "<p class='alert alert-danger mt-4'>Invalid file format..</p>"; 
			}
			else
			echo "<p class='alert alert-danger mt-4'>Please select image..!</p>";
			exit;
			
		}else {
			//If no session, redirect to login page
			redirect('login', 'refresh');
		}
		
	}
	
	public function saveProfilePhoto() {
		
		if($this->session->userdata('loggedin')) {
			
			$post = isset($_POST) ? $_POST: array();
			$userId = isset($post['id']) ? intval($post['id']) : 0;		
			$path = 'images/tmp/'.$_POST['imageName'];
			$tmpWidth = 300; 
			$tmpHeight = 300; 
			if(isset($_POST['t']) and $_POST['t'] == "ajax") {
				extract($_POST);		
				$imagePath = 'images/'.$_POST['imageName'];
				$ratio = ($tmpWidth/$w1); 
				$nw = ceil($w1 * $ratio);
				$nh = ceil($h1 * $ratio);
				$nimg = imagecreatetruecolor($nw,$nh);			
				$imgSrc = imagecreatefromjpeg($path);
				imagecopyresampled($nimg,$imgSrc,0,0,$x1,$y1,$nw,$nh,$w1,$h1);
				imagejpeg($nimg,$imagePath,90);		
			}
			$updateQuery = "
				UPDATE ".$this->userTable." 
				SET photo = '".$_POST['imageName']."'
				WHERE id = '$userId'";
			mysqli_query($this->dbConnect, $updateQuery);
			$saveImagePath = $imagePath.'?'.time();
			echo $saveImagePath;
			exit(0); 
			
	 }else {
		//If no session, redirect to login page
		redirect('login', 'refresh');
	}
		
	}    	
	public function resizeImage($image,$width,$height,$scale, $ext) {
		$newImageWidth = ceil($width * $scale);
		$newImageHeight = ceil($height * $scale);
		$newImage = imagecreatetruecolor($newImageWidth,$newImageHeight);
		switch ($ext) {
			case 'jpg':
			case 'jpeg':
				$source = imagecreatefromjpeg($image);
				break;
			case 'gif':
				$source = imagecreatefromgif($image);
				break;
			case 'png':
				$source = imagecreatefrompng($image);
				break;
			default:
				$source = false;
				break;
		}	
		imagecopyresampled($newImage,$source,0,0,0,0,$newImageWidth,$newImageHeight,$width,$height);
		imagejpeg($newImage,$image,90);
		chmod($image, 0777);
		return $image;
	}	
	public function getHeight($image) {
		$sizes = getimagesize($image);
		$height = $sizes[1];
		return $height;
	}	
	public function getWidth($image) {
		$sizes = getimagesize($image);
		$width = $sizes[0];
		return $width;
	}
	
	public function downloadChallan() {
		
		if($this->session->userdata('loggedin')) {
			
			$session_data = $this->session->userdata('loggedin');
			$session_id = $session_data['id'];
			$session_role = $session_data['role'];
		
			$crid = $this->input->get('id');
			$challan = $this->input->get('challan');
			$cno = $this->input->get('cno');
			$userid = $this->input->get('userid');
			
			if($session_role === 'student') {
				$data['user'] = $this->login_model->GetUserId();
			}else{
				$data['user'] = $this->login_model->GetUserDetails($userid);
			}
			
			$qid = $this->student_model->GetQualificationID($data['user']['id']);

			$stuprofile =  $this->student_model->GetStudentProfile($data['user']['id']);
			//$coursepay =  $this->student_model->GetCoursePayment($data['user']['id'],$qid);
			$studentcoursepay =  $this->student_model->GetFeeChallanBill($data['user']['id'],$qid,$crid,$challan,$cno);
			
			$this->load->model('payment_model','',TRUE);
			$partialpaydetails = $this->payment_model->GetPartialPayment($crid,$data['user']['id'],$studentcoursepay[0]['courseid']);
			
			//$challan = $this->student_model->CreateChallan($data['user']['id'],$studentcoursepay);
			
			$bankaccno = $stuprofile['bankaccountno'];
			
			//print_r($studentcoursepay);exit;
			$challanno = $paymentdate = "";
			$totalamt = 0;
			
			foreach($studentcoursepay as $paylist){
				
				$challanno = $paylist['challanno'];
				$paymentdate = $paylist['paymentdate'];
				
				$totalamt += $paylist['totalamt'];
				
			}
			
			
			if($partialpaydetails['status']=="a"){
				
				$totalamt = $partialpaydetails['partialamt'];
				
			}
			
			$virtualaccno = "";
			//$accno = substr($bankaccno, 0, 6);
			$accno = "A183A11";
			
			$studentno = $data['user']['stuid'];
			
			if(strlen($studentno)<6) $studentno = "0".$studentno;
			
			$virtualaccno = $accno.$studentno.$challanno;
			
			
			
	$html = '<html>
              <title>Challan</title>
              <head>
			  <script type="text/javascript" src="'.base_url().'js/jquery-3.5.1.min.js"></script>
			  <script>
                    $(document).ready(function(){
                        window.print();
                    });
              </script>
			  <style>

				@font-face {font-family: "Segoe UI";src: url("'.base_url().'css/fonts/segoeui.eot");
				  src: url("'.base_url().'css/fonts/segoeui.eot?#iefix") format("embedded-opentype"), url("'.base_url().'css/fonts/segoeui.woff") format("woff"), url("'.base_url().'css/fonts/segoeui.ttf") format("truetype"), url("'.base_url().'css/fonts/segoeui.svg#ralewaythin") format("svg");font-weight: 400;font-style: normal;}
				@font-face {font-family: "Segoe UI";src: url("'.base_url().'css/fonts/segoeuil.eot");
				  src: url("'.base_url().'css/fonts/segoeuil.eot?#iefix") format("embedded-opentype"), url("'.base_url().'css/fonts/segoeuil.woff") format("woff"), url("'.base_url().'css/fonts/segoeuil.ttf") format("truetype"), url("'.base_url().'css/fonts/segoeuil.svg#ralewaythin") format("svg");font-weight: 300;font-style: normal;}
				@font-face {font-family: "Segoe UI";src: url("'.base_url().'css/fonts/segoeuib.eot");
				  src: url("'.base_url().'css/fonts/segoeuib.eot?#iefix") format("embedded-opentype"), url("'.base_url().'css/fonts/segoeuib.woff") format("woff"), url("'.base_url().'css/fonts/segoeuib.ttf") format("truetype"), url("'.base_url().'css/fonts/segoeuib.svg#ralewaythin") format("svg");font-weight: 700;font-style: normal;}
				@font-face {font-family: "Segoe UI";src: url("'.base_url().'css/fonts/seguisb.eot");
				  src: url("'.base_url().'css/fonts/seguisb.eot?#iefix") format("embedded-opentype"), url("'.base_url().'css/fonts/seguisb.woff") format("woff"), url("'.base_url().'css/fonts/seguisb.ttf") format("truetype"), url("'.base_url().'css/fonts/seguisb.svg#ralewaythin") format("svg");font-weight: 600;font-style: normal;}

			.challanrow{font-family: Segoe UI;border-collapse: collapse;max-width: 734px;margin: auto;font-size: 12px;background: #ffffff;padding: 0rem}
			.challan{font-family: Segoe UI;border: 0.75px solid #BCCAE8;border-collapse: collapse;max-width: 100%;margin: auto;font-size: 12px;background: #ffffff;}
			.challan th{text-align: left}
			.challan th,.challan td{border: 0.75px solid #BCCAE8;padding: 0.2rem 1rem;width: 50%}
			.challan p{display: flex;margin: 5px auto}
			.challan p span{font-size: 12px;color: #181E29;}
			.challan p span:first-child{width: 35%;font-weight: normal;}
			.challan p span:last-child{width: 65%;font-weight: bold;}
			table.challan tr.lastrow td{padding: 0.7rem 1rem;border: none}
			.challan td.totalamt{padding: 0.5rem 1rem;}
			.challan td.totalamt strong{margin-left: 3rem;color: #D63333;font-size: 14px;}

			.copy{max-width: 100%;margin: auto;color: #181E29;font-size: 12px;font-style: italic;font-family: Segoe UI;font-weight: 600;margin-bottom: 1rem}

			.challan td table{font-family: Segoe UI;border: 1px solid #D7DFF0;border-collapse: collapse;width: 80%;margin: 1rem 0 1rem 0.8rem;border-style: hidden;border-radius: 5px; box-shadow: 0 0 0 1px #D7DFF0;font-size:12px;}

			.challan td th{font-weight: 600;color: #536485;background: #E6EBF7;border: 1px solid #D7DFF0;border-width: 0px 0px 1px 0px;text-align: center}
			.challan td td{border: 1px solid #D7DFF0;border-width: 0px 0px 1px 0px;text-align: center;width: 50%}

			.barcode{margin: 4.5rem auto 1rem;width: 45%}
			.upi{margin: auto;display: block}

			.challan td table tr:last-child td:first-child {border-bottom-left-radius: 10px;}
			.challan td table tr:last-child td:last-child {border-bottom-right-radius: 10px;}

			.v-bottom{vertical-align: bottom}
		

		</style>
</head>
   <body>
	
	
	<div class="challanrow">

	<table width="100%" border="0" cellspacing="0" cellpadding="0" class="challan">
	  <tbody>
		<tr>
		  <th scope="col"><img src="'.base_url().'img/challan-logo.png" alt="" /></th>
		  <th scope="col"><img src="'.base_url().'img/southindian.png" alt="" /></th>
		</tr>
		<tr>
		  <td><strong>Remittance through Other Banks</strong></td>
		  <td><strong>Remittance through SIB FEE Module</strong></td>
		</tr>
		<tr>
		  <td>&nbsp;</td>
		  <td>Institution Code: <strong>1 (453.73.61)</strong></td>
		</tr>
		<tr valign="top">
			<td>
				<p><span>Name:</span> <span>Brilliant Study Centre</span></p>
				<p><span>Virtual A/C No:</span> <span>'.$virtualaccno.'</span></p>
				<p><span>IFSC Code:</span> <span>SIBL0000453</span></p>
				<p><span>Branch:</span> <span>SIB, Arunapuram</span></p>
			</td>
			
		 	 <td>
				<p><span>Name:</span> <span>'.$stuprofile['stuname'].'</span></p>
				<p><span>ID:</span> <span>'.$data['user']['stuid'].'</span></p>
				<p><span>Course:</span> <span>'.$studentcoursepay[0]['coursename'].'</span></p>
				<p><span>Challan No:</span> <span>'.$challanno.'</span></p>
				<p><span>Date:</span> <span>'.date("d-m-Y",strtotime($paymentdate)).'</span></p>
				<p><span>Phone:</span> <span>'.$stuprofile['smobile'].'</span></p>
			</td>
		</tr>
		<tr>
		  <td colspan="2" class="totalamt">Amount: <strong>Rs.'.number_format($totalamt,0).'/- ('.$this->getIndianCurrency($totalamt).' Only)</strong></td>
		</tr>
		<tr class="lastrow">
		  <td>Entered by:</td>
		  <td>Authorized Signature:</td>
		</tr>
	  </tbody>
	</table>

	<p class="copy">Student Copy</p>

	<table width="100%" border="0" cellspacing="0" cellpadding="0" class="challan">
	  <tbody>
		<tr>
		  <th scope="col"><img src="'.base_url().'img/challan-logo.png" alt="" /></th>
		  <th scope="col"><img src="'.base_url().'img/southindian.png" alt="" /></th>
		</tr>
		<tr>
		  <td><strong>Remittance through Other Banks</strong></td>
		  <td><strong>Remittance through SIB FEE Module</strong></td>
		</tr>
		<tr>
		  <td>&nbsp;</td>
		  <td>Institution Code: <strong>1 (453.73.61)</strong></td>
		</tr>
		<tr valign="top">
			<td>
				<p><span>Name:</span> <span>Brilliant Study Centre</span></p>
				<p><span>Virtual A/C No:</span> <span>'.$virtualaccno.'</span></p>
				<p><span>IFSC Code:</span> <span>SIBL0000453</span></p>
				<p><span>Branch:</span> <span>SIB, Arunapuram</span></p>
			</td>
			
		 	 <td>
				<p><span>Name:</span> <span>'.$stuprofile['stuname'].'</span></p>
				<p><span>ID:</span> <span>'.$data['user']['stuid'].'</span></p>
				<p><span>Course:</span> <span>'.$studentcoursepay[0]['coursename'].'</span></p>
				<p><span>Challan No:</span> <span>'.$challanno.'</span></p>
				<p><span>Date:</span> <span>'.date("d-m-Y",strtotime($paymentdate)).'</span></p>
				<p><span>Phone:</span> <span>'.$stuprofile['smobile'].'</span></p>
			</td>
		</tr>
		<tr>
		  <td colspan="2" class="totalamt">Amount: <strong>Rs.'.number_format($totalamt,0).'/- ('.$this->getIndianCurrency($totalamt).' Only)</strong></td>
		</tr>
		<tr>
		  <td>
		  
		  	<table width="100%" border="0" cellspacing="0" cellpadding="0">
			  <tbody>
				<tr>
				  <th scope="col">Values</th>
				  <th scope="col">Count</th>
				</tr>
				<tr>
				  <td>2000 x</td>
				  <td>&nbsp;</td>
				</tr>
				<tr>
				  <td>500 x</td>
				  <td>&nbsp;</td>
				</tr>
				<tr>
				  <td>100 x</td>
				  <td>&nbsp;</td>
				</tr>
				<tr>
				  <td>50 x</td>
				  <td>&nbsp;</td>
				</tr>
				<tr>
				  <td>20 x</td>
				  <td>&nbsp;</td>
				</tr>
				<tr>
				  <td>10 x</td>
				  <td>&nbsp;</td>
				</tr>
				<tr>
				  <td>5 x</td>
				  <td>&nbsp;</td>
				</tr>
				<tr>
				  <td>Coins</td>
				  <td>&nbsp;</td>
				</tr>
				<tr>
				  <td>Total Amount :</td>
				  <td>&nbsp;</td>
				</tr>
			  </tbody>
			</table>
			
		  </td>
		  <td style="padding-top: 12rem">Authorized Signature:</td>
		</tr>
				
	  </tbody>
	</table>
	
	<!--<img src="'.base_url().'img/barcode.png" alt="" class="barcode" />
	<img src="'.base_url().'img/upi.png" alt="" class="upi" />-->

</div></body></html>';
			
			echo $html;
			
			/*$this->load->library('pdf');
		    $this->pdf->load_view($html);
			$this->pdf->set_paper("a4", "portrait");
		    $this->pdf->render();
		    $this->pdf->stream("challan.pdf");*/
			
		/*require_once("./dompdf/autoload.inc.php");
        $dompdf = new DOMPDF();
        $dompdf->load_html($html);
        $dompdf->set_paper("a4", "portrait");
        $dompdf->render();
        $dompdf->stream("challan.pdf");*/
			
		}
		
	}
	
function getIndianCurrency(float $number)
{
    $decimal = round($number - ($no = floor($number)), 2) * 100;
    $hundred = null;
    $digits_length = strlen($no);
    $i = 0;
    $str = array();
    $words = array(0 => '', 1 => 'one', 2 => 'two',
        3 => 'three', 4 => 'four', 5 => 'five', 6 => 'six',
        7 => 'seven', 8 => 'eight', 9 => 'nine',
        10 => 'ten', 11 => 'eleven', 12 => 'twelve',
        13 => 'thirteen', 14 => 'fourteen', 15 => 'fifteen',
        16 => 'sixteen', 17 => 'seventeen', 18 => 'eighteen',
        19 => 'nineteen', 20 => 'twenty', 30 => 'thirty',
        40 => 'forty', 50 => 'fifty', 60 => 'sixty',
        70 => 'seventy', 80 => 'eighty', 90 => 'ninety');
    $digits = array('', 'hundred','thousand','lakh', 'crore');
    while( $i < $digits_length ) {
        $divider = ($i == 2) ? 10 : 100;
        $number = floor($no % $divider);
        $no = floor($no / $divider);
        $i += $divider == 10 ? 1 : 2;
        if ($number) {
            $plural = (($counter = count($str)) && $number > 9) ? 's' : null;
            $hundred = ($counter == 1 && $str[0]) ? ' and ' : null;
            //$str [] = ($number < 21) ? $words[$number].' '. $digits[$counter]. $plural.' '.$hundred:$words[floor($number / 10) * 10].' '.$words[$number % 10]. ' '.$digits[$counter].$plural.' '.$hundred;
			$str [] = ($number < 21) ? $words[$number].' '. $digits[$counter].' '.$hundred:$words[floor($number / 10) * 10].' '.$words[$number % 10]. ' '.$digits[$counter].' '.$hundred;
        } else $str[] = null;
    }
    $Rupees = implode('', array_reverse($str));
    $paise = ($decimal > 0) ? "." . ($words[$decimal / 10] . " " . $words[$decimal % 10]) . ' Paise' : '';
    //return ($Rupees ? $Rupees . 'Rupees ' : '') . $paise;
	return (ucwords($Rupees) ? ucwords($Rupees) : '') . ucwords($paise);
}
	
	public function downloadIDcard() {
	
	
	if($this->session->userdata('loggedin')) {
			
		$session_data = $this->session->userdata('loggedin');
		$session_id = $session_data['id'];
		$session_role = $session_data['role'];

		if($session_role === 'student') {
			
			$data['user'] = $this->login_model->GetUserId();
			
		}else{
		
			$userid = $this->input->get('userid');
			$data['user'] = $this->login_model->GetUserDetails($userid);
		
		}
		
		$studentid = $data['user']['id'];
		
		$coursepay =  $this->student_model->GetCoursePayment($data['user']['id'],'','');
		$stuprofile =  $this->student_model->GetStudentProfile($data['user']['id']);
						
		//print_r($stuprofile);exit;
		
		//$feepayments = $this->student_model->GetFeePayments($data['user']['id'],'',$requestid);
		
		$courseid = $coursepay[0]['courseid'];
		$photocopy_ht = $coursepay[0]['photocopy_ht'];
		
		//$coursename = $coursepay[0]['coursename'];
                $coursename="";
		$roll_number = $coursepay[0]['roll_number'];
		$stuid = $data['user']['stuid'];
		$stuname = $data['user']['pname'];
		$dob = date("d M Y",strtotime($stuprofile['dob']));
		$classstudy = $stuprofile['classstudy'];
		$mobile = $stuprofile['smobile'];
		$smcode = $stuprofile['smcode'];
		$email = $stuprofile['semail'];
		$profilepic = $data['user']['profilepic'];
		
		$examtime = $coursepay[0]['examtime'];
		$reportingtime = $coursepay[0]['reportingtime'];
		$cooloftime = $coursepay[0]['cooloftime'];
		$modeofexam = $coursepay[0]['modeofexam'];
		$duration = $coursepay[0]['duration'];
		                
				
		$guardianname = "";
		if($stuprofile['fathername']!="" && $stuprofile['fathername']!="0") $guardianname = $stuprofile['fathername'];
		else if($stuprofile['guardianname']!="" && $stuprofile['guardianname']!="0") $guardianname = $stuprofile['guardianname'];
		
		$fulladdress = $addressline1 = $addressline2 = $addressline3 = "";
		$addressline1 .= $stuprofile['housenameno'].", ";
		$addressline1 .= $stuprofile['contactaddress'].", ";
		
		if($stuprofile['contactaddress']!="" && $stuprofile['contactaddress']!="0") $fulladdress .= $stuprofile['landmark'].", ";
		
		$fulladdress .= $stuprofile['contactstate'].", ";
		$addressline2 .= $stuprofile['contactpost'].", ";
		//$fulladdress .= $stuprofile['contactcountry']." - ";
		$addressline3 .= $stuprofile['contactdistrict'].", ";
		$addressline3 .= $stuprofile['contactpincode'].".";
		
		$mobile = "Mob +".$smcode." ".$mobile;
		
		ob_start();
		
		require_once(FCPATH.'/fpdf/fpdf.php');
		//require_once(FCPATH.'/rpdf/rpdf.php');
		require_once(FCPATH.'/FPDI/src/autoload.php');
				
		// initiate FPDI
		$pdf = new Fpdi\Fpdi();
		
		//$pdf = new RPDF();

		// get the page count
		$pageCount = $pdf->setSourceFile(FCPATH.'/docs/idcard.pdf');
		// iterate through all pages
		for ($pageNo = 1; $pageNo <= $pageCount; $pageNo++) {
			// import a page
			$templateId = $pdf->importPage($pageNo);

			$pdf->AddFont('segoeuib','','segoeuib.php');

			$pdf->AddPage();
			// use the imported page and adjust the page size
			$pdf->useTemplate($templateId, ['adjustPageSize' => true]);
			
			$pdf->AddFont('segoeuib','','segoeuib.php');
			$pdf->SetFont('segoeuib','','10');
			$pdf->SetTextColor('58' ,'58' ,'58');
			
			$pdf->SetAutoPageBreak(false);
			
			$pdf->SetXY(3, 10);
			//$pdf->TextWithDirection(110,50,$coursename,'D');
			$pdf->MultiCell(140, 6, $coursename, 0, 'L', false);
			
			// Student Details
			
			$pdf->AddFont('segoeuib','','segoeuib.php');
			$pdf->SetFont('segoeuib','','10');
			$pdf->SetTextColor('0' ,'0' ,'0');
			
			$pdf->SetXY(3,44);
			$pdf->MultiCell(49, 3, strtoupper($stuname), 0, 'C', false);
			
			$pdf->SetXY(3, 48);
			$pdf->MultiCell(49, 3, $stuid, 0, 'C', false);
			
			/*$pdf->SetXY(64, 225);
			$pdf->MultiCell(60, 4.5, $email, 0, 'L', false);
			
			$pdf->SetXY(155, 224.5);
			$pdf->MultiCell(140, 6, $dob, 0, 'L', false);*/
						
			$pdf->SetXY(3, 53);
			$pdf->MultiCell(49, 3, $mobile, 0, 'C', false);
			
			/*$pdf->SetXY(178.5, 236);
			$pdf->MultiCell(140, 6, $guardianname, 0, 'L', false);*/
			
			$pdf->SetXY(2, 57);
			$pdf->MultiCell(49, 4.5, $addressline1, 0, 'L', false);
			
			$pdf->SetXY(2, 61);
			$pdf->MultiCell(49, 4.5, $addressline2, 0, 'L', false);
			
			$pdf->SetXY(2, 65);
			$pdf->MultiCell(49, 4.5, $addressline3, 0, 'L', false);
			
			//$pdf->SetXY(64, 261);
			//$pdf->MultiCell(140, 6, $classstudy, 0, 'L', false);
					
			$photo_ht = 'docs/profilepic/'.$studentid.'/'.$profilepic;
			if(file_exists($photo_ht)) $pdf->Image($photo_ht, 16.3, 17.8, 22.4, 24.3);
						
			//$pdf->Write(8, 'Hall Ticket');
		}	
		
			// Output the new PDF
			//I, D, F, S
			
			//$pdfoutput = "D";
			$pdfoutput = "I";
	
			$pdf->Output($pdfoutput,"IDcard_".$stuid.".pdf"); 
		
		ob_end_flush(); 
		
				
	}else {
		//If no session, redirect to login page
		redirect('login', 'refresh');
	}
	
	
}  
	
	
	
}
?>

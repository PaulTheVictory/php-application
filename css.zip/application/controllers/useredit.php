<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Useredit extends CI_Controller {

	function __construct() {
            
		parent::__construct();
		$this->load->model('users_model','',TRUE);$this->load->model('course_model','',TRUE);
                $this->load->model('login_model','',TRUE);$this->load->model('library_model','',TRUE);
                 $this->load->library('table'); $this->load->helper('form');

	}
	
	function index() {
            
            if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')) {

                $session_data = $this->session->userdata('loggedin');
                $session_id = $session_data['id'];
                $session_role = $session_data['role'];
                $id = isset($_GET['id']) ? $_GET['id'] : '';
                $data['user'] = $this->login_model->GetUserId();
				
				$data['roleaccess'] = $this->config->item('roleaccess');

				if($data['roleaccess']['Users'][1]!="y"){
					redirect($data['roleaccess']['defaultpage'], 'refresh');
				}
				
                $data['edit'] = $this->users_model->EditUser($id);
                $data['groups'] = $this->users_model->GetAllGroups($data['edit']['role'],"option");
                $data['centers'] = $this->users_model->GetAllCenters($data['edit']['centers'],'option');
                 $data['lcenters'] = $this->library_model->GetAllCenters($data['edit']['centers'],'option');
                $data['types'] = $this->users_model->GetGroupType($data['edit']['role']);
                $data['courses'] = $this->users_model->GetAllBatches($data['edit']['courses']);
                

                $data['menu'] = $this->load->view('headermenu', $data, TRUE);
                
                $this->load->view('header_view', $data);
                $this->load->view('usersedit_view', $data);
                $this->load->view('footer_view');
                
            } else {
                //If no session, redirect to login page
                redirect('login', 'refresh');
            }
            
        }
        
        
             
        
       public function userSubmit() {
            
        if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')) {
                $this->load->library('form_validation');
               
			$roleaccess = $this->config->item('roleaccess');
			
			if(isset($roleaccess['Users'][1]) && $roleaccess['Users'][1]=="y"){
				
                $this->form_validation->set_rules('pname', 'Name', 'trim|required|xss_clean|callback_alpha_numeric_spaces|max_length[100]');
                $this->form_validation->set_rules('uname', 'User Name', 'trim|required|xss_clean|callback_alpha_numeric_spaces|max_length[100]');
                $this->form_validation->set_rules('uemail', 'Email Address', 'trim|required|xss_clean|callback_alpha_numeric_spaces|max_length[100]');
                $this->form_validation->set_rules('umobile', 'Phone Number', 'trim|required|xss_clean|numeric|max_length[10]');
                $this->form_validation->set_rules('ugroups', 'User Group', 'trim|required|xss_clean|callback_alpha_numeric_spaces|max_length[1000]');
                $this->form_validation->set_rules('msession', 'Multi Session', 'trim|xss_clean|regex_match[/y|n/]|max_length[1]');
                $gname = $this->input->post('ugroups', true);
                $type = $this->users_model->GetGroupType($gname);
                
                if($type === "A") { 
                    $_POST['ucenters']=""; $_POST['lcenters']=""; 
                    $this->form_validation->set_rules('ucourses', 'Batches', 'trim|required|xss_clean|callback_alpha_numeric_spaces|max_length[1000]');
               }
                if($type === "F") { 
                    $_POST['ucourses']="";$_POST['lcenters']=""; 
                       $this->form_validation->set_rules('ucenters', 'Centers', 'trim|required|xss_clean|callback_alpha_numeric_spaces|max_length[500]');
                }
                
                if($type === "B") { 
                    $this->form_validation->set_rules('ucourses', 'Batches', 'trim|required|xss_clean|callback_alpha_numeric_spaces|max_length[1000]');
                    $this->form_validation->set_rules('ucenters', 'Centers', 'trim|required|xss_clean|callback_alpha_numeric_spaces|max_length[500]');
                    $this->form_validation->set_rules('lcenters', 'Library Centers', 'trim|required|xss_clean|callback_alpha_numeric_spaces|max_length[500]');
                }
                
                 if($type === "L") { 
                     $_POST['ucourses']="";$_POST['ucenters']=""; 
                    $this->form_validation->set_rules('lcenters', 'Centers', 'trim|required|xss_clean|callback_alpha_numeric_spaces|max_length[500]');
                }

                if ($this->form_validation->run() == false) {
                        $response = array(
                            'status' => 'error',
                            'message' => validation_errors()
                        );
                        echo json_encode($response);

                } else {

                    
                    
                     $response = $this->users_model->UpdateUser($this->input->post('pname', true),$this->input->post('uname', true),$this->input->post('umobile', true),$this->input->post('ugroups', true),
                             $this->input->post('uemail', true),$this->input->post('ucenters', true),$this->input->post('lcenters', true),$this->input->post('ucourses', true),
                             $this->input->post('userid', true),$this->input->post('msession', true));
                     echo  json_encode($response);
                }
				
			}else {

			  $response = array(
					'status' => 'error',
					'message' => 'User Permission denied'
				);
				echo json_encode($response);
			}
              
               
            }else{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
            }
            
    }
            

}
?>
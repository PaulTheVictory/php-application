<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Signup extends CI_Controller {

	function __construct()
	{

		parent::__construct();

		$this->load->model('student_model','',TRUE);
		$this->load->model('qualification_model','',TRUE);

	}
	
	function index()
	{
		
		if(!$this->session->userdata('loggedin') || !$this->session->userdata('studlog_in'))
   		{
				
			$this->load->view('header');
			
			$data['qualification'] = $this->qualification_model->GetAllQualifications('');
			$data['classstudymaster'] = $this->qualification_model->GetAllActiveClassstudyMaster("");
			
			$this->load->view('signup_view',$data);		
			$this->load->view('footer');
			
		}else{
			//If no session, redirect to login page
     		redirect('courses', 'refresh');
		}
		
	}
	
	public function studentSignup() {
        			
		$name  = isset($_POST['suname'])?$_POST['suname']:'';
		$parentname  = isset($_POST['suparentname'])?$_POST['suparentname']:'';
		$relationship  = isset($_POST['surelationship'])?$_POST['surelationship']:'';
		$type  = isset($_POST['sutype'])?$_POST['sutype']:'';
        $mcode  = isset($_POST['sumcode'])?$_POST['sumcode']:'';
        $mobile  = isset($_POST['sumobile'])?$_POST['sumobile']:'';
		$emailid  = isset($_POST['suemailid'])?$_POST['suemailid']:'';
		$password  = isset($_POST['supassword'])?$_POST['supassword']:'';
		$classstudy  = isset($_POST['suclassstudy'])?$_POST['suclassstudy']:'';
		$iagree  = isset($_POST['suiagree'])?$_POST['suiagree']:'';
					
		$ret = $this->student_model->StudentSignup($type,$name,$mcode,$mobile,$emailid,$password,$classstudy,$iagree,$parentname,$relationship);
		echo json_encode($ret);
		        

    }
	
	public function resendOTP() {
        
		$studid  = isset($_POST['studid'])?$_POST['studid']:'';

		$ret = $this->student_model->ResendOTP($studid);
		echo json_encode($ret);

    }
	
	public function verifyOTP() {
        
		$verifyotp  = isset($_POST['verifyotp'])?$_POST['verifyotp']:'';
		$studid  = isset($_POST['studid'])?$_POST['studid']:'';
		$password = isset($_POST['password'])?$_POST['password']:'';
		$studentno = isset($_POST['studentno'])?$_POST['studentno']:'';

		$ret = $this->student_model->VerifyOTP($studid,$verifyotp,$password,$studentno);
		echo json_encode($ret);

    }
	
	public function getAllClassMasterQualifications() {
        
		$classstudyid = isset($_POST['classstudyid'])?$_POST['classstudyid']:'';

		$ret = $this->qualification_model->getAllClassMasterQualifications($classstudyid);
		echo $ret;

    }
	
}
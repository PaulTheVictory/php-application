<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Receivebook extends CI_Controller {

	function __construct() {
            
		parent::__construct();
		
                $this->load->model('login_model','',TRUE);
                $this->load->model('library_model','',TRUE);
				$this->load->helper('form');
				$this->load->library('table');

	}
	
	function index() {
            
            if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')) {

                $session_data = $this->session->userdata('loggedin');
                $session_id = $session_data['id'];
                $session_role = $session_data['role'];
                $data['user'] = $this->login_model->GetUserId();

				$data['roleaccess'] = $this->config->item('roleaccess');
			
				if($data['roleaccess']['Receive Books'][3]!="y"){
					redirect($data['roleaccess']['defaultpage'], 'refresh');
				}
																	
				//$data['studentdetails'] = $this->library_model->GetStudentProfile($studentid);
				//$data['receivedetails'] = $this->library_model->GetReceivedBookDetails($studentid);
				
				/*$tmpl = array('table_open' => '<table class="sortable sorting disabled table" id="usertable" style="margin-top:0px;">');
					$this->table->set_template($tmpl);
					$this->table->set_heading('S.NO', 'BARCODE','BOOK NAME','EDITION','STUDENT ID','STUDENT NAME','DUE DATE','ISSUE DATE');*/
				
				$data['units'] = $this->library_model->GetAllCenters("",'option',$data['user']['lcenters']);               

				$data['menu'] = $this->load->view('headermenu', $data, TRUE);
                $this->load->view('header', $data);
                $this->load->view('receivebook_view', $data);
                $this->load->view('footer');
				
            } else {
                //If no session, redirect to login page
                redirect('login', 'refresh');
            }
            
        }
        

	 public function GetReceiveBookDetails() {
            
		if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in') ){

			$data['user'] = $this->login_model->GetUserId();
			
			$stuid = $this->input->post('stuid');
			
			$result =  $this->library_model->GetReceiveBookDetails($stuid);

			$row = array();
			
			$sno = 1;
			
			foreach($result as $key=>$col){			
				
				$duedate = date("d-m-Y",strtotime($col->duedate));
				$issuedate = date("d-m-Y h:i A",strtotime($col->created));
					
				$row[] = array($sno,$col->barcode,$col->bookname,$col->edition,$col->studid,$col->sname,$duedate,$issuedate);
									
				$sno++;
				
			}
									
			$ret = array("tabledata"=>$row);
			echo json_encode($ret);
			
		}else{
		//If no session, redirect to login page
		redirect('login', 'refresh');
		}

	}
	
	 public function GetReceivedBookList() {
            
		if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in') ){

			$data['user'] = $this->login_model->GetUserId();
			
			$stuid = $this->input->post('stuid');
			
			$result =  $this->library_model->GetReceivedBookList($stuid);

			$row = array();
			
			$sno = 1;
			
			foreach($result as $key=>$col){			
				
				$sname = $col->sname;
				$staffname = $col->staffname;
				
				if($sname=="") $sname = $staffname;
				
				$duedate = date("d-m-Y",strtotime($col->duedate));
				$issuedate = date("d-m-Y h:i A",strtotime($col->created));
					
				$row[] = array($sno,$col->barcode,$col->bookname,$col->edition,$col->studid,$sname,$duedate,$issuedate);
									
				$sno++;
				
			}
									
			$ret = array("tabledata"=>$row);
			echo json_encode($ret);
			
		}else{
		//If no session, redirect to login page
		redirect('login', 'refresh');
		}

	}
	
	 public function getstudentdetails() {
            
        if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')) {
			
			$roleaccess = $this->config->item('roleaccess');
			
			if(isset($roleaccess['Receive Books'][3]) && $roleaccess['Receive Books'][3]=="y"){
			         
				$barcode = $this->input->post("barcode",true);
			
				$barcodedetails = $this->library_model->GetIssuedBarcodeDetails($barcode); //print_r($barcodedetails);exit;       
			
			if(empty($barcodedetails)){
				
				$response = array(
					'status' => 'error',
					'message' => 'Book already received.'
				);
				
				echo json_encode($response);
				
			}else{
				
				$response = array(
					'status' => 'success',
					'data' => $barcodedetails
				);
				
				echo json_encode($response);
			}
                

			 } else {

 					$response = array(
                            'status' => 'error',
                            'message' => 'User Permission Denied'
                        );
                        echo json_encode($response);
                }
              
               
            }else{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
            }
            
    }
	
	public function addreceivebookSubmit() {
            
        if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')) {
                $this->load->library('form_validation');
			
			$roleaccess = $this->config->item('roleaccess');
			
			if(isset($roleaccess['Receive Books'][3]) && $roleaccess['Receive Books'][3]=="y"){
				
               				
				$stuid = $this->input->post('stuid', true);
				$barcode = $this->input->post('barcode', true);
                //$center = $this->input->post('center', true);
			
				//$studentdetails = $this->library_model->GetStudentProfile($stuid);
				$barcodedetails = $this->library_model->GetIssuedBarcodeDetails($barcode);//print_r($barcodedetails);exit;
				//$issueddetails = $this->library_model->GetIssuedBookDetails($stuid);
						
				if(empty($barcodedetails)){
					$response = array(
						'status' => 'error',
						'message' => "Book already received."
						);
					echo json_encode($response);
					exit(0);
				}
				
				if($barcodedetails['studid']==""){
					$response = array(
						'status' => 'error',
						'message' => "Student ID not found."
						);
					echo json_encode($response);
					exit(0);
				}
			
				//if($ibdid === "") {
														
				$response = $this->insertQ($stuid,$barcode,$barcodedetails['studentid']);
											
				/*}else {
					 $response = $this->updateQ($bsid);
				 }*/
				
				 echo json_encode($response);	
				
			 } else {

 					$response = array(
                            'status' => 'error',
                            'message' => 'User Permission Denied'
                        );
                        echo json_encode($response);
                }
              
               
            }else{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
            }
            
    }
    
        
    public function insertQ($stuid,$barcode,$studentid){
        
		$roleaccess = $this->config->item('roleaccess');
			
			if(isset($roleaccess['Receive Books'][3]) && $roleaccess['Receive Books'][3]=="y"){
							
            $qData = array(
                'studentid' => $studentid,
                'studid' => $stuid,
                'barcode' => $barcode,
                'issued' => "n",
                'received' => "y",
                'recieveddate' => date('Y-m-d H:i:s')
            );
                       

            $result = $this->library_model->UpdateReceiveBook($qData);
              
			$response = array(
			'status' => 'success',
			'message' => "Book received Successfully.",
			'studentid' => $studentid,
			'studid' => $stuid
			);
				
		 } else {

			$response = array(
					'status' => 'error',
					'message' => 'User Permission Denied'
				);
		}

         return $response;
		
    }
	
	
	public function receivebarcodelistpreview(){
        
		$roleaccess = $this->config->item('roleaccess');
			
			if(isset($roleaccess['Receive Books'][3]) && $roleaccess['Receive Books'][3]=="y"){
				
				$row = $qData = array();
				
				$barcode = $this->input->post('barcode', true);
				
				$barcodedetails = $this->library_model->GetIssuedBarcodeDetails($barcode);
						
				if(empty($barcodedetails)){
					$response = array(
						'status' => 'error',
						'message' => "Book already received."
						);
					echo json_encode($response);
					exit(0);
				}
				
				$type = $barcodedetails['type'];
				
				if($barcodedetails['studid']==""){
					
					if($type!="staff"){$uname = "Student";}else{$uname = "Staff";}
					
					$response = array(
						'status' => 'error',
						'message' => $uname." not found."
						);
					echo json_encode($response);
					exit(0);
				}
				
				$studid = $barcodedetails['studid'];
				$studentid = $barcodedetails['studentid'];
				$sname = $barcodedetails['sname'];
				$edition = $barcodedetails['edition'];
				$bookname = $barcodedetails['bookname'];
				$duedate = $barcodedetails['duedate'];
				$created = $barcodedetails['created'];
				
           				
			$duedate = date("d-m-Y",strtotime($duedate));
			$issuedate = date("d-m-Y h:i A",strtotime($created));

			$row = array('<p class="sno"></p>',$barcode,$bookname,$edition,$studid,$sname,$duedate,$issuedate,'<a class="del noedit" barcode="'.$barcode.'" href="javascript:void(0)"><img style="padding:5px 10px" src="images/delete.png"></a>');	
                 
			 $qData = array(
                'studentid' => $studentid,
                'studid' => $studid,
                'barcode' => $barcode,
                'issued' => "n",
                'received' => "y",
                'recieveddate' => date('Y-m-d H:i:s')
            );
				
            //$result = $this->library_model->UpdateReceiveBook($qData);
              
			$response = array(
			'status' => 'success',
			'message' => "Book added.",
			'studentid' => $studentid,
			'studid' => $studid,
			'data' => $barcodedetails,
			'tabledata' => $row,
			'tablerow' => $qData,
			'type' => $type
			);
								
		 } else {

			$response = array(
					'status' => 'error',
					'message' => 'User Permission Denied'
				);
		}

         echo json_encode($response);	
		
    }
	
	public function updateReceiveBook(){
        
		$roleaccess = $this->config->item('roleaccess');
			
			if(isset($roleaccess['Receive Books'][3]) && $roleaccess['Receive Books'][3]=="y"){
								
            $qData = $this->input->post('qData', true);

            $result = $this->library_model->UpdateReceiveBook($qData);
              
			if($result=="success"){
				$response = array(
                'status' => 'success',
                'message' => "Books Received Successfully."
            	);
			}else if($result=="fail"){
				$response = array(
                'status' => 'fail',
                'message' => "Books Received failed."
            	);
			}
            
				echo json_encode($response);
				
		 } else {

			$response = array(
				'status' => 'error',
				'message' => 'User Permission Denied'
			);
			echo json_encode($response);
		}

    }
    	
	
}
?>
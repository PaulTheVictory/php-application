<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Datami extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model('login_model','',TRUE);
                $this->load->model('course_model','',TRUE);
                 $this->load->library('table'); 

	}
	
	function index()
	{
		if($this->session->userdata('loggedin'))
   		{
                    $session_data = $this->session->userdata('loggedin');
                    $session_id = $session_data['id'];
                    $session_role = $session_data['role'];
                    $type = isset($_GET['type']) ? $_GET['type'] : '';
                    
			if($session_role === 'admin') {
                            
                            if($type === "course") {
                                
                                                               
                                //set unique id for course
                                for($i=0;$i < 1000 ; $i++){
    
                                $ide = uniqid();
                                $this-> db -> query("update admin_course set ide='$ide'  where ide = '$i'");
                               
                                }

                                //set unique id for fees
                                for($i=0;$i < 3000 ; $i++){
                                    $ide1 = uniqid();
                                    $this-> db -> query("update admin_group set id='$ide1'  where id = '$i'");
                                }


                                /* update couresid in the fees structure*/

                                $this-> db -> query("update admin_group,admin_course set admin_group.courseid=admin_course.ide  where admin_group.courseid =admin_course.courseid");



                                /* Change registration changes into registration fee and tutuion fees*/

                                $query0 = $this-> db -> query("SELECT * FROM admin_group where 1");
                                $row = $query0->result_array();
                                if ($row) {
                                    for($i = 0;$i<count($row);$i++) {

                                        if($row[$i]['description'] === 'Registration Charges'){
                                             $this-> db -> query("update admin_group set admin_group.description='Registration Fee'  where admin_group.id ='".$row['id']."'");
                                        }

                                        if($row[$i]['description'] === 'Caution Deposit'){
                                             $this-> db -> query("update admin_group set admin_group.tax='NA',admin_group.kf='NA',admin_group.cov='NA',admin_group.taxable='0'  where admin_group.id ='".$row['id']."'");
                                        }

                                        if(strpos($row[$i]['centers'], "_")){
                                        $center = str_replace("_", " ", $row[$i]['centers']);

                                         $this-> db -> query("update admin_group set centers='$center' where admin_group.id ='".$row[$i]['id']."'");
                  
                                        }

                                    }
                                    
                                    echo 'success';

                                }
                                
                                
                    
                            } else if($type === "qualification") {
                                
                                for($i=0;$i < 60 ; $i++){
                                    $ide1 = uniqid();
                                    $this-> db -> query("update admin_qualification set id='$ide1'  where id = '$i'");
                                }
                                
                                $this-> db -> query("update admin_course,admin_qualification set admin_course.qualification=admin_qualification.id  where admin_qualification.name = admin_course.qname");
                    
                            }else if($type === "student") {
                                
                               for($i=1;$i < 325880 ; $i++){
                                    $ide1 = uniqid();
                                    $this-> db -> query("update bscp_student_dump set id='$ide1'  where id = '$i'");
                                }
                                
                                $this-> db -> query("update bscp_student_dump,admin_qualification set bscp_student_dump.qualification=admin_qualification.id  where bscp_student_dump.qualification != '' and bscp_student_dump.qualification = admin_qualification.qualificationid");
                                echo 'success';
                    
                            }else if($type === "typouser") {
                                
                                ini_set('memory_limit', '-1');
                                
                                $query0 = $this-> db -> query("SELECT * FROM bscp_student where 1");
                                $row = $query0->result_array();
                                if ($row) {
                                    
                                    for($i = 0;$i<count($row);$i++) {
                                        
                                        
                                        $encrpassword = SHA1($this->config->item('pass_salt').$row[$i]['studid']);
                                        
                                         $query2  = $this-> db -> query('insert into typo_users (`id`, `username`, `password`, `mobile`, `role`, `email`, `name`, `qualification`, `address`, `address1`, `place`, `city`, `website`, `landline`, `pincode`) values ("'.$row[$i]['id'].'","'.$row[$i]['email'].'","'.$encrpassword.'","'.$row[$i]['contact'].'","student","'.$row[$i]['email'].'","'.$row[$i]['sname'].'","'.$row[$i]['qualification'].'","","","","","","","")');
                                    }
                                    
                                }
                                
                                
                                
                    
                            }else if($type === "erase") {
                                
                                $this-> db -> query("delete from typo_users  where username != 'admin@gmail.com'");
                                $this-> db -> query("delete from bscp_student_payments");
                                $this-> db -> query("delete from bscp_studentprofile");
                                $this-> db -> query("delete from bscp_student");
                                $this-> db -> query("delete from bscp_feepayments");
                                $this-> db -> query("delete from bscp_courserequest");
                               $this-> db -> query('update `bscp_billcounter` set billcounter="1"');
                                echo 'success';
                                
                            }else if($type === "erasemaster") {
                                
                                $this-> db -> query("delete from admin_course");
                                $this-> db -> query("delete from admin_group");
                                $this-> db -> query("delete from admin_qualification");                          
                                echo 'success';
                            }
                        }
		}
   		else
   		{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
   		}
		
	}
        
       
}
?>

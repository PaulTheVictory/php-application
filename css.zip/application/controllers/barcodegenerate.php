<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Barcodegenerate extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model('login_model','',TRUE);
                $this->load->model('library_model','',TRUE);
                $this->load->library('table');
				$this->load->helper('form');
	
	}
	
	function index()
	{
		if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in'))
   		{
                    $session_data = $this->session->userdata('loggedin');
                    $session_id = $session_data['id'];
                    $session_role = $session_data['role'];
                    
                    $data['user'] = $this->login_model->GetUserId();		
		
					$data['roleaccess'] = $this->config->item('roleaccess');

									
					$barcode = "1005752";
			
					$this->generate_barcode($barcode);
														
					//$data['menu'] = $this->load->view('headermenu', $data, TRUE);
																		
					//$this->load->view('header',$data);
					//$html = $this->load->view('barcodeprintpdf_view', $data, TRUE);
					//$this->load->view('footer');
			
					/*$this->load->helper('Dompdf_helper');
					$filename = 'Generated Barcodes ('.$data['bcdetails']['barcodefrom'].' - '. $data['bcdetails']['barcodeto'].')';
					pdf_create($html, $filename, TRUE);*/
                    
		}
   		else
   		{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
   		}
		
	}
		
	
	public function generate_barcode($barcode){
		
		if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in'))
   		{
			
			// Load library
			$this->load->library('zend');
			// Load in folder Zend
			$this->zend->load('Zend/Barcode');

			$dirname = './docs/barcode/';

			// Generate barcode
			$imageResource = Zend_Barcode::factory('code128', 'image', array('text'=>"$barcode",'stretchText'=>true,'withBorder'=>false,'font'=>3,'fontSize'=>18,'barHeight'=>40,'barThickWidth'=>3,'barThinWidth'=>2,'withQuietZones'=>false,'drawText'=>true), array('imageType'=>'png'))->draw();

			imagepng($imageResource, $dirname.$barcode.'.png');
			
			
			echo '<!DOCTYPE html>
				<html>
				<head>
				<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
				<title>Barcodes </title>
				</head>
				<body>
				<img src="'.$dirname.$barcode.'.png" alt="Barcode" />
				</body>
				</html>';
			
						
		}
   		else
   		{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
   		}		
		
	}
	
}
?>

<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Updatequalification extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model('login_model','',TRUE);
                $this->load->model('qualification_model','',TRUE);
                $this->load->helper('form');
	
	}
	
	function index()
	{
		if($this->session->userdata('loggedin'))
   		{
                    $session_data = $this->session->userdata('loggedin');
                    $session_id = $session_data['id'];
                    $session_role = $session_data['role'];
                    
                    $data['user'] = $this->login_model->GetUserId();		
		
					if($session_role === 'student') {
												
						$data['qualification'] =  $this->qualification_model->GetAllQualifications($data['user']['qualificationid']);
						
						$data['classstudymaster'] = $this->qualification_model->GetAllActiveClassstudyMaster($data['user']['qualificationid']);
						
						$this->load->view('header',$data);
						$this->load->view('stu_updatequalification_view', $data);
						$this->load->view('footer');
                            
                     }else{
						//If no session, redirect to login page
     					redirect('dashboard', 'refresh');
					}
		}
   		else
   		{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
   		}
		
	}
        
    public function qualificationSubmit() {
            
        if($this->session->userdata('loggedin') && $this->session->userdata('studlog_in')) {
            $this->load->library('form_validation');
            $this->form_validation->set_rules('qualification', 'Qualification', 'trim|required|xss_clean|alpha_numeric|max_length[20]'); 


            if ($this->form_validation->run() == false) {
                    $response = array(
                        'status' => 'error',
                        'message' => validation_errors()
                    );
                    echo json_encode($response);

            } else {
                 $user = $this->login_model->GetUserId();
                 $response = $this->qualification_model->UpdateStuQualification($this->input->post('qualification', true),$user['id']);
                 echo  json_encode($response);
            }
      
        
               
        }else{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
        }
        
    }
	
	
}
?>

<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

use \setasign\Fpdi;

class Printidcard extends CI_Controller {

	function __construct() {
            
		parent::__construct();
		
                $this->load->model('login_model','',TRUE);
                $this->load->model('student_model','',TRUE);
				$this->load->helper('form');
				$this->load->library('table');

	}
	
	function index() {
            
            if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')) {

                $session_data = $this->session->userdata('loggedin');
                $session_id = $session_data['id'];
                $session_role = $session_data['role'];
                $data['user'] = $this->login_model->GetUserId();

				/*$data['roleaccess'] = $this->config->item('roleaccess');
			
				if($data['roleaccess']['Transfer Books'][3]!="y"){
					redirect($data['roleaccess']['defaultpage'], 'refresh');
				}*/
				
				$printbatchid = $this->input->get('id');
				$sid = $this->input->get('sid');
				
				$data['htmldata'] =  $this->student_model->IDcardBatchPrinthtml($printbatchid,$sid);
					
				$this->load->library('pdf');
				$html = $this->load->view('printidcardpdf_view', $data, true);
				$this->pdf->createPDF($html, 'mypdf', false);
				
				
            } else {
                //If no session, redirect to login page
                redirect('login', 'refresh');
            }
            
        }
	
	public function generate_barcode($barcode,$studentid){
		
		if($this->session->userdata('loggedin'))
   		{
			
			// Load library
			$this->load->library('zend');
			// Load in folder Zend
			$this->zend->load('Zend/Barcode');

			$dirname = './docs/profilepic/'.$studentid.'/';

			// Generate barcode
			$imageResource = Zend_Barcode::factory('code128', 'image', array('text'=>"$barcode",'stretchText'=>true,'withBorder'=>false,'font'=>2,'fontSize'=>18,'barHeight'=>45,'barThickWidth'=>3,'barThinWidth'=>2,'withQuietZones'=>false,'drawText'=>true), array('imageType'=>'png'))->draw();

			imagepng($imageResource, $dirname.$barcode.'.png');
						
		}
   		else
   		{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
   		}		
		
	}
		
	
}
?>
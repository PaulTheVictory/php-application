<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Usereditgroup extends CI_Controller {

	function __construct() {
            
		parent::__construct();
		$this->load->model('users_model','',TRUE);
                $this->load->model('login_model','',TRUE);
                 $this->load->library('table'); $this->load->helper('form');

	}
	
	function index() {
            
            if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')) {

                $session_data = $this->session->userdata('loggedin');
                $session_id = $session_data['id'];
                $session_role = $session_data['role'];
                $id = isset($_GET['id']) ? $_GET['id'] : '';
                $data['user'] = $this->login_model->GetUserId();
				
				$data['roleaccess'] = $this->config->item('roleaccess');

				if($data['roleaccess']['User Group'][1]!="y"){
					redirect($data['roleaccess']['defaultpage'], 'refresh');
				}
				
                $data['gname'] = $this->users_model->GetGroupName($id);
                $data['grparr'] = $this->users_model->FetchGroupAccess($id);
                $data['grpid'] = $id;

                $data['menu'] = $this->load->view('headermenu', $data, TRUE);
                
                $this->load->view('header_view', $data);
                $this->load->view('usereditgroup_view', $data);
                $this->load->view('footer_view');
                
            } else {
                //If no session, redirect to login page
                redirect('login', 'refresh');
            }
            
        }
        
        
        
       public function groupSubmit() {
            
        if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')) {
			
			$roleaccess = $this->config->item('roleaccess');
			
			if(isset($roleaccess['User Group'][1]) && $roleaccess['User Group'][1]=="y"){
				
               $mArray=[];
               $gname=isset($_POST['uname']) ? $_POST['uname'] : '';
                $gtype=isset($_POST['ctype']) ? $_POST['ctype'] : '';
               $groupid=isset($_POST['groupid']) ? $_POST['groupid'] : '';
                $this->load->library('form_validation');
                $this->form_validation->set_rules('uname', 'Group Name', 'trim|required|xss_clean|callback_alpha_numeric_spaces|max_length[100]');
                $this->form_validation->set_rules('ctype', 'User Type', 'trim|required|xss_clean|regex_match[/A|F|B/]|max_length[10]'); 
         if ($this->form_validation->run() == false) {
            $response = array(
                'status' => 'error',
                'message' => validation_errors()
            );
        }else{
                foreach($_POST as $key=>$val){
                    if(($key === "uname")||($key==="groupid")||($key==="ctype")){continue;}
                   $lineArr = explode("-",$key);
                   
					$lineArr[1] = str_replace("_", " ", $lineArr[1]);
                   
                   if(!array_key_exists($lineArr[1], $mArray)){
                        $mArray[$lineArr[1]]=Array();
                        
                    } 
                    
                    if(!array_key_exists($lineArr[2], $mArray[$lineArr[1]])){
                        $mArray[$lineArr[1]][$lineArr[2]]['access'] = $lineArr[2]; 
                        $mArray[$lineArr[1]][$lineArr[2]]['add'] = ($lineArr[0]==='add')?$val:"n";
                        $mArray[$lineArr[1]][$lineArr[2]]['edit'] = ($lineArr[0]==='edit')?$val:"n";
                        $mArray[$lineArr[1]][$lineArr[2]]['delete'] = ($lineArr[0]==='del')?$val:"n";
                        $mArray[$lineArr[1]][$lineArr[2]]['view'] =  ($lineArr[0]==='view')?$val:"n";
                        $mArray[$lineArr[1]][$lineArr[2]]['defaultpage'] =  ($lineArr[0]==='dpage')?$val:"n";
                    } else{
                        if($lineArr[0]==='add') { $mArray[$lineArr[1]][$lineArr[2]]['add'] = $val;}
                        if($lineArr[0]==='edit') { $mArray[$lineArr[1]][$lineArr[2]]['edit'] = $val;}
                        if($lineArr[0]==='del') { $mArray[$lineArr[1]][$lineArr[2]]['delete'] = $val;}
                        if($lineArr[0]==='view') { $mArray[$lineArr[1]][$lineArr[2]]['view'] = $val;}
                        if($lineArr[0]==='dpage') { $mArray[$lineArr[1]][$lineArr[2]]['defaultpage'] = $val;}
                    }
                   
               
                }
                
               
                $this->insertQ($mArray,$gname,$groupid,$gtype);        
                $response = array(
                                'status' => 'success',
                                'message' => "Group Updated Successfully."
                            );
                 
               }
               echo json_encode($response);
				
			}else {

			  $response = array(
					'status' => 'error',
					'message' => 'User Permission denied'
				);
				echo json_encode($response);
			}
			
            }else{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
            }
            
    }
    
        
    public function insertQ($mArray,$gname,$groupid,$gtype){
        
        $this->users_model->DeleteGroup($groupid);
        
        foreach($mArray as $key=>$valArr){
             
            foreach($valArr as $akey=>$valArr1){
                $ide = uniqid();
            $qData = array(
                'id' => $ide,
                'groupid' => $groupid,
                'gname' => $gname,
                'gtype' => $gtype,
                'module' => $key,
                'access' => '',
                'uadd' => 'n',
                'uedit' => 'n',
                'udelete' => 'n',
                'uview' => 'n',
                'udefaultpage' => 'n'
            );
                
               $akey = str_replace('_', " ", $akey);
               $qData['access']=  $akey;    
               foreach($valArr1 as $skey=>$val){
                   if(array_key_exists("u".$skey, $qData)){
                       $qData["u".$skey] = $val;
                   }                   
               }   
            $this->users_model->InsertGroup($qData);                
                
            }
            
        }
            
    }
       

}
?>
<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Addbook extends CI_Controller {

	function __construct() {
            
		parent::__construct();
		
                $this->load->model('login_model','',TRUE);
                $this->load->model('library_model','',TRUE);
				$this->load->helper('form');
		$this->load->helper('download');

	}
	
	function index() {
            
            if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')) {

                $session_data = $this->session->userdata('loggedin');
                $session_id = $session_data['id'];
                $session_role = $session_data['role'];
                $data['user'] = $this->login_model->GetUserId();

				$data['roleaccess'] = $this->config->item('roleaccess');
			
				if($data['roleaccess']['Library Books'][0]!="y"){
					redirect($data['roleaccess']['defaultpage'], 'refresh');
				}
				
				$bid = $this->input->get('bid');
				
				$data['bid'] = $bid;
				
				$data['bookdetails'] = $this->library_model->BookDetails($bid);               

				$data['menu'] = $this->load->view('headermenu', $data, TRUE);
                $this->load->view('header', $data);
                $this->load->view('addbook_view', $data);
                $this->load->view('footer');
				
            } else {
                //If no session, redirect to login page
                redirect('login', 'refresh');
            }
            
        }
        
    
	 public function bookSubmit() {
            
        if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')) {
                $this->load->library('form_validation');
			
			$roleaccess = $this->config->item('roleaccess');
			
			if(isset($roleaccess['Library Books'][0]) && $roleaccess['Library Books'][0]=="y"){
				
                $bid = isset($_POST['bid']) ? $_POST['bid'] : '';
				
				if($bid==""){
					$validatation["bookname"] = "trim|required|xss_clean|callback_alpha_numeric_spaces|max_length[200]|is_unique[bscp_library_books.bookname]";
				}else{
					$validatation["bookname"] = "trim|required|xss_clean|callback_alpha_numeric_spaces|max_length[200]";
				}
                
                $validatation["isbnnumber"] = "trim|xss_clean|callback_alpha_numeric_spaces|max_length[50]";
                $validatation["author"] = "trim|required|xss_clean|callback_alpha_numeric_spaces|max_length[200]";
                $validatation["publisher"] = "trim|required|xss_clean|callback_alpha_numeric_spaces|max_length[200]";
                $validatation["category"] = "trim|required|xss_clean|callback_alpha_numeric_spaces|max_length[50]";
                $validatation["edition"] = "trim|xss_clean|callback_alpha_numeric_spaces|max_length[50]";
				$validatation["stream"] = "trim|required|xss_clean|callback_alpha_numeric_spaces|max_length[50]";
                $validatation["supplier"] = "trim|xss_clean|callback_alpha_numeric_spaces|max_length[200]";
                $validatation["dueperiod"] = "trim|xss_clean|callback_numeric|max_length[2]";
                $validatation["price"] = "trim|required|xss_clean|callback_numeric|max_length[5]";
               

                    foreach ($validatation as $key=>$val) {
                        $this->form_validation->set_rules($key, $key, $val);
                    }


                if ($this->form_validation->run() == false) {
                        $response = array(
                            'status' => 'error',
                            'message' => validation_errors()
                        );
                        echo json_encode($response);

                } else {


                     if($bid === "") {
						$response = $this->insertQ();
					 } else {
						 $response = $this->updateQ($bid);
					 }
                     echo  json_encode($response);
                }
				
			 } else {

 					$response = array(
                            'status' => 'error',
                            'message' => 'User Permission Denied'
                        );
                        echo json_encode($response);
                }
              
               
            }else{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
            }
            
    }
    
        
    public function insertQ(){
        
		$roleaccess = $this->config->item('roleaccess');
			
			if(isset($roleaccess['Library Books'][0]) && $roleaccess['Library Books'][0]=="y"){
				
        	$ide = uniqid();
				
            $qData = array(
                'id' => $ide,
                'bookname' => $this->input->post('bookname', true),
                'isbn_number' => $this->input->post('isbnnumber', true),
                'author' => $this->input->post('author', true),
                'publisher' => $this->input->post('publisher', true),
                'category' => $this->input->post('category', true),
                'edition' => $this->input->post('edition', true),
                'stream' => $this->input->post('stream', true),
                'supplier' => $this->input->post('supplier', true),
                'dueperiod' => $this->input->post('dueperiod', true),
                'price' => $this->input->post('price', true),
                'status' => "a",
                'created' => date('Y-m-d H:i:s')
            );
                       

            $id = $this->library_model->InsertBook($qData);
              
			if($id=="success"){
				 $response = array(
                	'status' => 'success',
                	'message' => "Book Created Successfully."
            	);
			}else{
				 $response = array(
                	'status' => 'exists',
                	'message' => "Book Already Exists."
            	);
			}
           
				
		 } else {

			$response = array(
					'status' => 'error',
					'message' => 'User Permission Denied'
				);
				echo json_encode($response);
		}

          return $response;
    }
    
       public function updateQ($bid){
        
		   $roleaccess = $this->config->item('roleaccess');
			
			if(isset($roleaccess['Library Books'][1]) && $roleaccess['Library Books'][1]=="y"){
				
            $qData = array(
                'id' => $bid,
                'bookname' => $this->input->post('bookname', true),
                'isbn_number' => $this->input->post('isbnnumber', true),
                'author' => $this->input->post('author', true),
                'publisher' => $this->input->post('publisher', true),
                'category' => $this->input->post('category', true),
                'edition' => $this->input->post('edition', true),
				'stream' => $this->input->post('stream', true),
                'supplier' => $this->input->post('supplier', true),
                'dueperiod' => $this->input->post('dueperiod', true),
                'price' => $this->input->post('price', true),
				'status' => "a",
                'created' => date('Y-m-d H:i:s')
            );
                       

            $id = $this->library_model->UpdateBook($qData);
            
			if($id=="success"){
				 $response = array(
					'status' => 'success',
					'message' => "Book Updated Successfully."
				);
			}else{
				 $response = array(
                	'status' => 'exists',
                	'message' => "Book Already Exists."
            	);
			}
				
				
		 } else {

			$response = array(
					'status' => 'error',
					'message' => 'User Permission Denied'
				);
				echo json_encode($response);
		}

          return $response;
    }
	
	public function uploadLibraryBook(){
            
		if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')){
			
			$roleaccess = $this->config->item('roleaccess');
			
			if(isset($roleaccess['Library Books'][0]) && $roleaccess['Library Books'][0]=="y"){

			//print_r($_FILES);exit;
			
			//$bname = $this->input->post('bname', true);
			
			if(isset($_FILES["file"]) && !empty($_FILES["file"]['name'])){
				
				$total = count($_FILES['file']['name']);
				
				$validExtensions = array('.xls');
								
				$dirname = FCPATH.'docs/addbook/';
								
				$fileExtension = strrchr($_FILES['file']['name'][0], ".");
				$fileName = "addbook_".date("YmdHis").$fileExtension;
									
				$destinationfull = $dirname . $fileName;
					
				if(!file_exists($dirname)) mkdir($dirname,0777);
							
				if (in_array(strtolower($fileExtension), $validExtensions)) {
					
					$resultfull = move_uploaded_file($_FILES['file']['tmp_name'][0],$destinationfull);
					
					if(!$resultfull){
				    
						$ret = array('status' => "ufail");
						echo json_encode($ret);
						exit(0);
						
					}else{
						
						$result = $this->addLibraryBook($fileName);
						
						$exceldata = "";
						if($result['exceldata']!=""){
							$exceldata = '<thead><tr><th style="width: 5%">S.no</th><th >ISBN</th><th>Book Name</th><th>Reason</th></tr></thead>';
							$exceldata .= $result['exceldata'];
							setcookie("exceldata", $exceldata, time()+3600, "/");
						}
						
						$ret = array('status' => "success","message"=>$result['message'],"exceldata"=>$exceldata);
						echo json_encode($ret);
						exit(0);
						
					}
								
				}else{
					
					$ret = array('status' => "exfail");
					echo json_encode($ret);
					exit(0);
					
				}
					
								
			}else{
				
				$ret = array('status' => "empty");
				echo json_encode($ret);
				exit(0);
				
			}
				
		 } else {

			$response = array(
					'status' => 'error',
					'message' => 'User Permission Denied'
				);
				echo json_encode($response);
		}		
			
			
		}
	  
  }
	
	
function addLibraryBook($fileName){
	
	ini_set('memory_limit', '-1');	
	ini_set('max_execution_time', 86400);
	
	include './import/excel_reader.php';     // include the class

	$filepath = FCPATH.'docs/addbook/'.$fileName;
		
	// creates an object instance of the class, and read the excel file data
	$excel = new PhpExcelReader;
	$excel->read($filepath);
		
	$sheet = $excel->sheets[0];
	
	$x = 2;

	//echo $sheet['numRows'];exit;
	
	$arr = array();
	
	$arr["message"] = "";
	$arr['printbid'] = "";
	$arr["exceldata"] = '';
	
	$exsno = 1;
	
  while($x <= $sheet['numRows']) {
	  	  
	  $sno = isset($sheet['cells'][$x][1]) ? $sheet['cells'][$x][1] : '';
	  $isbn = isset($sheet['cells'][$x][2]) ? $sheet['cells'][$x][2] : '';
	  $bookname = isset($sheet['cells'][$x][3]) ? $sheet['cells'][$x][3] : '';
	  $author = isset($sheet['cells'][$x][4]) ? $sheet['cells'][$x][4] : '-';
	  $category = isset($sheet['cells'][$x][5]) ? $sheet['cells'][$x][5] : '-';
	  $stream = isset($sheet['cells'][$x][6]) ? $sheet['cells'][$x][6] : '-';
	  $dueperiod = isset($sheet['cells'][$x][7]) ? $sheet['cells'][$x][7] : '-';
	  $publisher = isset($sheet['cells'][$x][8]) ? $sheet['cells'][$x][8] : '-';
	  $supplier = isset($sheet['cells'][$x][9]) ? $sheet['cells'][$x][9] : '-';
	  $price = isset($sheet['cells'][$x][10]) ? $sheet['cells'][$x][10] : '-';
	  $edition = isset($sheet['cells'][$x][11]) ? $sheet['cells'][$x][11] : '-';
	  
	  //echo $x.". ".$studentno."<br />";$x++;continue;
		  		  
	  // Add Book
	  
	  $ide = uniqid();
	  
	  $qData = array(
                'id' => $ide,
                'bookname' => $bookname,
                'isbn_number' => $isbn,
                'author' => $author,
                'publisher' => $publisher,
                'category' => $category,
                'edition' => $edition,
                'stream' => $stream,
                'supplier' => $supplier,
                'dueperiod' => $dueperiod,
                'price' => $price,
                'status' => "a",
                'created' => date('Y-m-d H:i:s')
            );
	  
	  
	  if(trim($bookname)!="" && trim($isbn)!="" && trim($author)!="" && trim($publisher)!="" && trim($category)!="" && trim($edition)!="" && trim($stream)!="" && trim($supplier)!="" && trim($dueperiod)!="" && trim($price)!=""){
	  
	  	  $id = $this->library_model->InsertBook($qData);
		  
		  if($id=="exists"){
			  $arr["message"] .= "<p><font color='red'>".$sno.". ".$bookname." - Book already exists</font></p>";
			  $arr["exceldata"] .= '<tr><td>'.$exsno.'</td><td>'.$isbn.'</td><td>'.$bookname.'</td><td>Book already exists</td></tr>';
			  $exsno++;
	  	  }
		  
	  }else{
		  $arr["message"] .= "<p><font color='red'>".$sno.". ".$bookname." - Some data missing</font></p>";
		  $arr["exceldata"] .= '<tr><td>'.$exsno.'</td><td>'.$isbn.'</td><td>'.$bookname.'</td><td>Some data missing</td></tr>';
		  $exsno++;
	  }
	  	  
	  $x++;
		  		  			  
  }
	
	if(file_exists($filepath)) unlink($filepath);
		
	return $arr;

}
	
public function downloadexcel(){
	
	if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')){
		
		if(isset($_COOKIE['exceldata']) && $_COOKIE['exceldata']!=""){
		
			$html = $_COOKIE['exceldata'];
			$savename = "Add_Books_Upload_Status".date('dmYHis');

			$html = str_replace('<tr>',"\n",$html);
			$html = str_replace('</tr>',"",$html);

			$html = str_replace('</th>',"\t",$html);
			$html = str_replace('<th>',"",$html);

			$html = str_replace('</td>',"\t",$html);
			$html = str_replace('<td>',"",$html);


			$html = strip_tags($html);

			$filename = $savename .".xls";

			setcookie("exceldata", "", time()+3600, "/");	

			force_download($filename, $html);
			
		}
		
	}else{
	//If no session, redirect to login page
	redirect('login', 'refresh');
	}
	
	
}

}
?>
<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Dashboard extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model('login_model','',TRUE);
                $this->load->model('course_model','',TRUE);
                 $this->load->library('table'); 

	}
	
	function index()
	{
		if($this->session->userdata('loggedin'))
   		{
                    $session_data = $this->session->userdata('loggedin');
                    $session_id = $session_data['id'];
                    $session_role = $session_data['role'];
                    
                    if($session_role === 'admin') {
                    $data['user'] = $this->login_model->GetUserId();		
				
                    $data['menu'] = $this->load->view('headermenu', $data, TRUE);
						
                    $this->load->view('header_view', $data);
                    $this->load->view('dashboard_view', $data);
                    $this->load->view('footer_view');
                    } else if($session_role === 'student') {
                        
                    $data['user'] = $this->login_model->GetUserId();		
		   		
                    $this->load->view('header', $data);
                   // $this->load->view('dashboard_view', $data);
                    $this->load->view('footer');
                    }
		}
   		else
   		{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
   		}
		
	}
        
      
	
	
}
?>

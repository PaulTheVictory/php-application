<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Sturegtests extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model('login_model','',TRUE);
                $this->load->model('course_model','',TRUE);
				$this->load->model('student_model','',TRUE);
                 $this->load->library('table'); 

	}
	
	function index()
	{
		if($this->session->userdata('loggedin'))
   		{
                    $session_data = $this->session->userdata('loggedin');
                    $session_id = $session_data['id'];
                    $session_role = $session_data['role'];
                    
                    $data['user'] = $this->login_model->GetUserId();		
		
					if($session_role === 'student') {
												
						$qid = $this->student_model->GetQualificationID($data['user']['id']);
												
						$data['regcourses'] =  $this->student_model->GetRegisteredCourses($data['user']['id'],'',true);
												
						$this->load->view('header', $data);
						$this->load->view('student_testregistered_view', $data);
						$this->load->view('footer');
                            
                     }else{
						//If no session, redirect to login page
     					redirect('dashboard', 'refresh');
					}
		}
   		else
   		{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
   		}
		
	}
	
	public function STIssueCenter(){
            
		if($this->session->userdata('loggedin')){

			$ide = isset($_GET['ide']) ? $_GET['ide'] : '';
			$type = isset($_GET['type']) ? $_GET['type'] : '';
			$center = isset($_GET['center']) ? $_GET['center'] : '';
			$city = isset($_GET['city']) ? $_GET['city'] : '';
			$courseid = isset($_GET['courseid']) ? $_GET['courseid'] : '';

			if($ide != ""){

			   //$cname= $this->course_model->GetCourseName($courseid);

			   $ret = $this->course_model->STIssueCenter($ide,$type,$center,$city,$courseid);


			} else {
				$ret = array(0 => "fail");
			}

			echo json_encode($ret);

		}else {
			//If no session, redirect to login page
			redirect('login', 'refresh');
		}
            
   }
	
	public function getIssueCenters(){
            
		if($this->session->userdata('loggedin')){

			$city = $this->input->post("city",true);
			$courseid = $this->input->post("courseid",true);
			
			$data['centers'] = $this->course_model->GetIssueCityWiseCenters($city,$courseid);

			echo json_encode($data);

		}else {
			//If no session, redirect to login page
			redirect('login', 'refresh');
		}
            
   }
	
	
}
?>

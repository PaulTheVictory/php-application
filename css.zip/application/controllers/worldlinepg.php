<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Worldlinepg extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model('login_model','',TRUE);
			$this->load->model('student_model','',TRUE);
			$this->load->library('table'); 
                 

	}
	
	function index()
	{
		if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in'))
   		{
                    $session_data = $this->session->userdata('loggedin');
                    $session_id = $session_data['id'];
                    $session_role = $session_data['role'];
                    
					$data['roleaccess'] = $this->config->item('roleaccess');

					if($data['roleaccess']['uview']!="y"){
						redirect($data['roleaccess']['defaultpage'], 'refresh');
					}
			
                    $data['user'] = $this->login_model->GetUserId();

					$data['menu'] = $this->load->view('headermenu', $data, TRUE);
			
                        $this->load->view('header_view', $data);
                        $this->load->view('worldlinepg_view', $data);
                        $this->load->view('footer_view');

                        
        }
   		else
   		{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
   		}
		
	}
	
public function worldlinepgList()
{

		
	if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')){
			
		$roleaccess = $this->config->item('roleaccess');
		
		$user = $this->login_model->GetUserId();
		$batches = $user['batches'];
		
		$columns = array( 
                            0 =>'name', 
                            1 =>'studid',
                            2=> 'courseid',
                            3=> 'center',
							4=> 'referenceid',
                            5=> 'referenceNo',
                            6=> 'paymentamount',
                            7=> 'paymentdate',
                            8=> 'statuscode',
                            9=> 'receiptno',
                            10=> '',
                        );

		$limit = $this->input->post('length');
        $start = $this->input->post('start');
        $order = $columns[$this->input->post('order')[0]['column']];
        $dir = $this->input->post('order')[0]['dir'];
		
		$searchcol = $this->input->post('searchcol', true);
  
        $totalData = $this->student_model->allwordlinepg_count($batches);
            
        $totalFiltered = $totalData; 
            
        if(empty($this->input->post('search')['value']))
        {            
            $posts = $this->student_model->allwordlinepg($limit,$start,$order,$dir,$batches);
        }
        else {
            $search = $this->input->post('search')['value']; 

            $posts =  $this->student_model->wordlinepg_search($limit,$start,$search,$order,$dir,$searchcol,$batches);

            $totalFiltered = $this->student_model->wordlinepg_search_count($search,$searchcol,$batches);
        }

        $data = array();
        if(!empty($posts))
        {
            foreach ($posts as $post)
            {

                $nestedData['name'] = strtoupper($post->name);
                $nestedData['studid'] = $post->studid;
                $nestedData['courseid'] = $post->courseid;
                $nestedData['center'] = $post->center;
				$nestedData['referenceid'] = $post->referenceid;
				
				$paymentmode = $post->paymentmode;
				
				if((strcmp($paymentmode,"online")===0 && strcmp($paymentmode,"Online")!==0) || (strcmp($paymentmode,"online")!==0 && strcmp($paymentmode,"Online")!==0)) $receiptno = ""; else $receiptno = $post->receiptno;
				
				if($post->referenceNo=="1") $nestedData['referenceNo'] = ""; else $nestedData['referenceNo'] = $post->referenceNo;
				
                $nestedData['paymentamount'] = $post->paymentamount;
				                
				$paymentdate = date('j M Y h:i a',strtotime($post->paymentdate));
				
				if($post->statuscode=="F"){
					$statuscode = "Failed - ". $post->statusdesc;$receiptno = "";
				}else if($post->statuscode=="S"){
					$statuscode = "Success";
				}else{
					$statuscode = "Failed";$receiptno = "";
				}
				
				$nestedData['statuscode'] = $statuscode;
								
                $nestedData['receiptno'] = $receiptno;
				
				$action = "";
				if($post->statuscode=="" || $post->statuscode=="1" || $post->statuscode=="F"){
					
					if(isset($roleaccess['Worldline Fetch'][3]) && $roleaccess['Worldline Fetch'][3]=="y"){
						$action = '<a href="javascript:void(0);" class="fetchwordlinepg" data-orderid="'.$post->referenceid.'" data-studentid="'.$post->studentid.'" data-courseid="'.$post->cid.'"><button>Fetch</button></a>';
					}
					//$paymentdate = "";				
				}
				
				$nestedData['paymentdate'] = $paymentdate;
								
				$nestedData['action'] = $action;
                //$nestedData['body'] = substr(strip_tags($post->body),0,50)."...";
                
                $data[] = $nestedData;

            }
        }
          
        $json_data = array(
                    "draw"            => intval($this->input->post('draw')),  
                    "recordsTotal"    => intval($totalData),  
                    "recordsFiltered" => intval($totalFiltered), 
                    "data"            => $data   
                    );
            
        echo json_encode($json_data); 
			
	}else{
			
		//If no session, redirect to login page
		redirect('login', 'refresh');
			
	}
		
}
	
	
public function fetchworldlinepayment(){
		
		if($this->session->userdata('loggedin'))
   		{
			
			$roleaccess = $this->config->item('roleaccess');
			
			$arr = array();
			$arr['paymenttable'] = "";
			$arr['paymentdata'] = array();
			
			if(isset($roleaccess['Worldline Fetch'][3]) && $roleaccess['Worldline Fetch'][3]=="y"){
			
			$session_data = $this->session->userdata('loggedin');
			$session_id = $session_data['id'];
			$session_role = $session_data['role'];

			$data['user'] = $this->login_model->GetUserId();		

			$orderId = $this->input->post('orderid');
			$studentid = $this->input->post('studentid');
			$courseid = $this->input->post('courseid');
			
			$pgMeTrnRefNo = "";
			
				 
				
					/**
					 * This Is the Kit File To Be Included For Transaction Request/Reponse
					 */
					include APPPATH.'third_party/worldline/Kit/AWLMEAPI.php';

					//create an Object of the above included class
					$obj = new AWLMEAPI();

					//This is the Unique Merchant Id
					$mId = $this->config->item('Merchant_ID');

					//This is the Merchant Key that is used for decryption also
					$enc_key = $this->config->item('Merchant_Key');

					//create a request for generate transaction status
					$response = $obj->getTransactionStatus( $mId , $orderId , $pgMeTrnRefNo , $enc_key);
				
					$RefNo = $response->getPgMeTrnRefNo();
					$OrderId = $response->getOrderId();
					$TrnAmt = $response->getTrnAmt()/100;
					$StatusCode = $response->getStatusCode();
					$StatusDesc = $response->getStatusDesc();
					$TrnReqDate = $response->getTrnReqDate();
					$ResponseCode = $response->getResponseCode();
					$Rrn = $response->getRrn();
					$AuthZCode = $response->getAuthZCode();
		
					$userid = $response->getAddField1();
					$courseid = $response->getAddField2();
					$requestid = $response->getAddField3();
				
				if($TrnReqDate!="")$TrnReqDate = date("d M, Y h:i A",strtotime($TrnReqDate));
				
				//$arr['paymentdata'] = $response;
				
				$arr['paymenttable'] =  '<table>
										<tr><!-- PG transaction reference number-->
											<td><label for="txnRefNo">Transaction Ref No. :</label></td>
											<td>'.$response->getPgMeTrnRefNo().'</td>
										</tr>
										<tr>	
											
											<!-- Merchant order number-->
											<td><label for="orderId">Order No. :</label></td>
											<td>'.$response->getOrderId().' </td>
										</tr>
										<tr>
											<!-- Transaction amount-->
											<td><label for="amount">Amount :</label></td>
											<td>'.$TrnAmt.'</td>
										</tr>
										<tr>	
											<!-- Transaction status code-->
											<td><label for="statusCode">Status Code :</label></td>
											<td>'.$response->getStatusCode().'</td>
										</tr>
										<tr>
											<!-- Transaction status description-->
											<td><label for="statusDesc">Status Desc :</label></td>
											<td>'.$response->getStatusDesc().'</td>
										</tr>
										<tr>
											<!-- Transaction date time-->
											<td><label for="txnReqDate">Transaction Request Date :</label></td>
											<td>'.$TrnReqDate.'</td>
										</tr>
										
										<tr>
											<!-- Transaction response code-->
											<td><label for="responseCode">Response Code :</label></td>
											<td>'.$response->getResponseCode().'</td>
										</tr>
										<tr>
											<!-- Bank reference number-->
											<td><label for="statusDesc">RRN :</label></td>
											<td>'.$response->getRrn().'</td>
										</tr>
										
										<tr>
											<!-- Authzcode-->
											<td><label for="authZStatus">AuthZCode :</label></td>	
											<td>'.$response->getAuthZCode().'</td>
										</tr>

									</table>';
				
							echo json_encode($arr);
									
		}else
   		{
     		//If no session, redirect to login page
     		echo json_encode($arr);
   		}
			
		}else
   		{
     		//If no session, redirect to login page
     		echo json_encode($arr);
   		}
		
	}
	
	
	public function updatefetchpayment(){
		
		if($this->session->userdata('loggedin'))
   		{
			
			$roleaccess = $this->config->item('roleaccess');
			
			$arr = array();
			$arr['paymenttable'] = "";
			$arr['paymentdata'] = array();
			
			if(isset($roleaccess['Worldline Fetch'][3]) && $roleaccess['Worldline Fetch'][3]=="y"){
				
			$session_data = $this->session->userdata('loggedin');
			$session_id = $session_data['id'];
			$session_role = $session_data['role'];

			$data['user'] = $this->login_model->GetUserId();		

			$orderId = $this->input->post('orderid');
			$paymentdata = $this->input->post('paymentdata');
			$courseid = $this->input->post('courseid');
			
			$pgMeTrnRefNo = "";
			
				
					/**
					 * This Is the Kit File To Be Included For Transaction Request/Reponse
					 */
					include APPPATH.'third_party/worldline/Kit/AWLMEAPI.php';

					//create an Object of the above included class
					$obj = new AWLMEAPI();

					//This is the Unique Merchant Id
					$mId = $this->config->item('Merchant_ID');

					//This is the Merchant Key that is used for decryption also
					$enc_key = $this->config->item('Merchant_Key');

					//create a request for generate transaction status
					$response = $obj->getTransactionStatus( $mId , $orderId , $pgMeTrnRefNo , $enc_key);
				
					$RefNo = $response->getPgMeTrnRefNo();
					$OrderId = $response->getOrderId();
					$TrnAmt = $response->getTrnAmt();
					$StatusCode = $response->getStatusCode();
					$StatusDesc = $response->getStatusDesc();
					$TrnReqDate = $response->getTrnReqDate();
					$ResponseCode = $response->getResponseCode();
					$Rrn = $response->getRrn();
					$AuthZCode = $response->getAuthZCode();
		
					$userid = $response->getAddField1();
					$courseid = $response->getAddField2();
					$requestid = $response->getAddField3();
								
					$paystatus = $this->student_model->UpdateWorldlineFetchPayment($userid,$RefNo,$OrderId,$TrnAmt,$StatusCode,$StatusDesc,$TrnReqDate,$ResponseCode,$Rrn,$AuthZCode,$courseid,$requestid);
		
					// Test Code Don't change 
		
					/*$StatusCode = "S";$OrderId = "606eed62277d9";
					$paystatus = $this->student_model->UpdateWorldlineFetchPayment('','12213124','606eed62277d9',100000,'S','Transaction authorised successfully ','2021-04-08 17:06:06','00','000000011221','001200');*/

					//print_r($response);exit;
				
				echo json_encode($paystatus);
						
			
		}else
   		{
     		//If no session, redirect to login page
     		echo json_encode($arr);
   		}
			
	}else
   		{
     		//If no session, redirect to login page
     		echo json_encode($arr);
   		}		
		
	}
         
	
}
?>

<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Examadd extends CI_Controller {

	function __construct() {
            
		parent::__construct();
		                $this->load->model('login_model','',TRUE);
                $this->load->model('exams_model','',TRUE);$this->load->helper('form');
                $this->load->model('course_model','',TRUE);
	}
	
	function index() {
            
            if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')) {

                $session_data = $this->session->userdata('loggedin');
                $session_id = $session_data['id'];
                $session_role = $session_data['role'];
                $data['user'] = $this->login_model->GetUserId();

				$data['roleaccess'] = $this->config->item('roleaccess');
			
				if($data['roleaccess']['Courses'][3]!="y"){
					redirect($data['roleaccess']['defaultpage'], 'refresh');
				}
				

                $data['menu'] = $this->load->view('headermenu', $data, TRUE);
                $data['districts'] = $this->exams_model->GetAllDistricts("",'option');
                $data['courses'] = $this->course_model->GetAllCourses("");
                $this->load->view('header_view', $data);
                $this->load->view('examadd_view', $data);
                $this->load->view('footer_view');
            } else {
                //If no session, redirect to login page
                redirect('login', 'refresh');
            }
            
        }
        
      public function examSubmit() {
          
          if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')) {
        $this->load->library('form_validation');
			  
		$roleaccess = $this->config->item('roleaccess');
		if(isset($roleaccess['Exam Master'][0]) && $roleaccess['Exam Master'][0]=="y"){
	$this->form_validation->set_rules('ename', 'Exam Name', 'trim|required|xss_clean|callback_alpha_numeric_spaces|max_length[100]|is_unique[bscp_exammaster.name]');		
        $this->form_validation->set_rules('selcourses', 'Course Name', 'trim|required|xss_clean|callback_alpha_numeric_spaces|max_length[5000]');
        $this->form_validation->set_rules('dcname', 'Display Course Name', 'trim|required|xss_clean|callback_alpha_numeric_spaces|max_length[100]');
        $this->form_validation->set_rules('duration', 'Duration Value', 'trim|xss_clean|numeric|max_length[3]');
        $this->form_validation->set_rules('durationfreq', 'Duration', 'trim|xss_clean|regex_match[/Month|Year/]|max_length[10]');
        $this->form_validation->set_rules('examdate', 'Exam Date', 'trim|xss_clean|callback_alpha_numeric_spaces|max_length[50]');
        $this->form_validation->set_rules('rtime', 'Reporting Time', 'trim|xss_clean|callback_alpha_numeric_spaces|max_length[50]');
        $this->form_validation->set_rules('ldate', 'Last Date & Time Of Application', 'trim|xss_clean|required|callback_alpha_numeric_spaces|max_length[50]');
        $this->form_validation->set_rules('seldistricts', 'Districts', 'trim|xss_clean|required|callback_alpha_numeric_spaces|max_length[1000]');
        $this->form_validation->set_rules('selcenters', 'Centers', 'trim|xss_clean|required|callback_alpha_numeric_spaces|max_length[1000]');
        $this->form_validation->set_rules('cdescription', 'Course Description', 'trim|xss_clean|max_length[5000]');


        if ($this->form_validation->run() == false) {
            $response = array(
                'status' => 'error',
                'message' => validation_errors()
            );
        }
        else {
            
            $date =$this->input->post('examdate', true);
            if($date === ""){ $date = NULL;}
            
            $rtime =$this->input->post('rtime', true);
            if($rtime === ""){ $rtime = NULL;}
            
            $ldate =$this->input->post('ldate', true);
            if($ldate === ""){ $ldate = NULL;}
            
            $duration = $this->input->post('duration', true)." ".$this->input->post('durationfreq', true);
            $courseids = $this->input->post('selcourses', true);
            $courseArr = explode("|",$courseids);
             $ide = uniqid();
            foreach( $courseArr as $akey => $aval){
           
                if($aval ==="") { continue;}
                $cid = $this->course_model->GetCourseUniqueId($aval);
                $qData = array(
                    'ide' => $ide,
                    'name' => $this->input->post('ename', true),
                    'courseid' => $cid,
                    'displaycname' => $this->input->post('dcname', true),
                    'duration' => $duration,
                    'date' => $date,
                    'rtime' => $rtime,
                    'ltime' => $ldate,
                    'description ' => $this->input->post('cdescription', true),
                    'active' => 'a',
                    'del' => 'n',
                    'created_at'=>date('Y-m-d H:i:s')
                );
            
            
            $id = $this->exams_model->AddMasterExam($qData);
            
            }
                $districts = explode("|",$this->input->post('seldistricts', true));
                $centers = explode("|",$this->input->post('selcenters', true));
                foreach ($districts as $key => $val) {
                    
                    if($val != ""){
                        foreach ($centers as $key1 => $val1) {
                            
                            if($this->exams_model->IsCenterNumRows($val,$val1) > 0){
                                $pide = uniqid();
                               $qData = array(
                                    'ide' => $pide,
                                    'examid' => $ide,
                                    'district' => $val,
                                    'center' => $val1,
                                    'created_at'=>date('Y-m-d H:i:s')
                                );

                                $this->exams_model->AddSelectedCenter($qData);
                            }
                            
                         } 
                    }
                    
                }
          
            $response = array(
                'status' => 'success',
                'message' => "Event Created Successfully.",
                'ide' => $ide
            );
        }

          echo  json_encode($response);
        
			
		}else {

		  $response = array(
				'status' => 'error',
				'message' => 'User Permission denied'
			);
			echo  json_encode($response);
		}
			  
          
        }else {
                //If no session, redirect to login page
                redirect('login', 'refresh');
            }
    }
    
        
        public function GetCenters() {
		
            if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')) {
        	
                $inword  = isset($_GET['term'])?$_GET['term']:'';
                $ret = $this->exams_model->GetAllCenters($inword);
                echo $ret;
            }
        }
        
       


}
?>
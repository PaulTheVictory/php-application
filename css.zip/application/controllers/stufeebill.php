<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Stufeebill extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model('login_model','',TRUE);
		$this->load->model('student_model','',TRUE);
        $this->load->helper('form');
	
	}
	
	function index()
	{
		if($this->session->userdata('loggedin'))
   		{
                    $session_data = $this->session->userdata('loggedin');
                    $session_id = $session_data['id'];
                    $session_role = $session_data['role'];
                    
                    $data['user'] = $this->login_model->GetUserId();		
						
					$crid = $this->input->get('crid');
					$cno = $this->input->get('cno');
			
					$data['feesmaster'] = $this->student_model->getFeesMaster();
			
					if($session_role === 'student') {
						
						$data['cno'] = $cno;
						
						if($crid!="" && $cno!=""){
						
						$data['feepaybill'] = $this->student_model->GetFeePaymentBill($data['user']['id'],$crid,$cno);
						
						//$this->load->view('header',$data);
						$this->load->view('student_feebill_view', $data);
						//$this->load->view('footer');
							
						}else{
							//If no session, redirect to login page
							redirect('stufeepayments', 'refresh');
						}
                            
                     }else{
						
						$userid = $this->input->get('userid');
						$data['user'] = $this->login_model->GetUserDetails($userid);
						
						if($crid!="" && $cno!=""){
						
						$data['feepaybill'] = $this->student_model->GetFeePaymentBill($userid,$crid,$cno);
						
						//$this->load->view('header',$data);
						$this->load->view('student_feebill_view', $data);
						//$this->load->view('footer');
							
						}else{
							//If no session, redirect to login page
							redirect('admissions', 'refresh');
						}
						
					}
		}
   		else
   		{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
   		}
		
	}
        
	
}

?>
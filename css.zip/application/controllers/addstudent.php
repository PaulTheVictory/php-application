<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Addstudent extends CI_Controller {

	function __construct() {
            
		parent::__construct();
		$this->load->model('login_model','',TRUE);
                $this->load->model('student_model','',TRUE);$this->load->helper('form');

	}
	
	function index() {
            
            if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')) {

                $session_data = $this->session->userdata('loggedin');
                $session_id = $session_data['id'];
                $session_role = $session_data['role'];
                $data['user'] = $this->login_model->GetUserId();
                $ide = isset($_GET['id']) ? $_GET['id'] : '';
                
                if($ide !== "") {
                    $data["student"] = $this->student_model->ViewStudentProfile($ide);
                } else{
                    $data["student"] = '';
                }

                $data['menu'] = $this->load->view('headermenu', $data, TRUE);
               

                $this->load->view('header_view', $data);
                $this->load->view('addstudent_view', $data);
                $this->load->view('footer_view');
            } else {
                //If no session, redirect to login page
                redirect('login', 'refresh');
            }
            
        }
        
      public function studentSubmit() {
          
          if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')) {
        $this->load->library('form_validation');
        $this->form_validation->set_rules('cname', 'Course Name', 'trim|required|xss_clean|callback_alpha_numeric_spaces|max_length[100]|is_unique[admin_course.coursename]');
        $this->form_validation->set_rules('duration', 'Duration Value', 'trim|required|xss_clean|numeric|max_length[3]');
        $this->form_validation->set_rules('durationfreq', 'Duration', 'trim|required|xss_clean|regex_match[/Month|Year/]|max_length[5]');
        $this->form_validation->set_rules('commence', 'Commences on', 'trim|required|xss_clean|callback_alpha_numeric_spaces|max_length[50]');
        $this->form_validation->set_rules('startson', 'Starts On', 'trim|required|xss_clean|callback_alpha_numeric_spaces|max_length[50]');
        $this->form_validation->set_rules('endson', 'Ends on', 'trim|xss_clean|required|callback_alpha_numeric_spaces|max_length[50]');
        $this->form_validation->set_rules('qualification', 'Qualification', 'trim|xss_clean|required|apha_numeric|max_length[100]');
        $this->form_validation->set_rules('regular', 'Class Schedule', 'trim|xss_clean|regex_match[/1|0/]|max_length[1]');
        $this->form_validation->set_rules('weekend', 'Class Schedule', 'trim|xss_clean|regex_match[/1|0/]|max_length[1]');
        $this->form_validation->set_rules('both', 'Class Schedule', 'trim|xss_clean|regex_match[/1|0/]|max_length[1]');
        $this->form_validation->set_rules('selcenters', 'Centers', 'trim|xss_clean|callback_alpha_numeric_spaces|max_length[100]');
        $this->form_validation->set_rules('cdescription', 'Course Description', 'trim|xss_clean|max_length[2000]');
                

        if ($this->form_validation->run() == false) {
            $response = array(
                'status' => 'error',
                'message' => validation_errors()
            );
        }
        else {
            $ide = uniqid();
            $duration = $this->input->post('duration', true)." ".$this->input->post('durationfreq', true);
            $cschedule = $this->input->post('regular', true)."|".$this->input->post('weekend', true)."|".$this->input->post('both', true);
            $coffset = $this->course_model->CourseOffset();
            $qData = array(
                'ide' => $ide,
                'courseid' => $coffset,
                'coursename' => $this->input->post('cname', true),
                'duration' => $duration,
                'commenceson' => $this->input->post('commence', true),
                'starts_on' => $this->input->post('startson', true),
                'ends_on' => $this->input->post('endson', true),
                'qualification' => $this->input->post('qualification', true),
                'cschedule' => $cschedule,
                'centers' => $this->input->post('selcenters', true),
                'description ' => $this->input->post('cdescription', true),
                'status' => 'Active',
                'del' => 'n',
                'created_at' => date('Y-m-d H:i:s')
            );
            
            

            $id = $this->course_model->AddCourse($qData);
          

            $response = array(
                'status' => 'success',
                'message' => "Course Created Successfully.",
                'ide' => $ide
            );
        }

          echo  json_encode($response);
          
        }else {
                //If no session, redirect to login page
                redirect('login', 'refresh');
            }
    }
    
        
     

}
?>
<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Forgotpassword extends CI_Controller {

	function __construct()
	{

		parent::__construct();

		$this->load->model('student_model','',TRUE);
		$this->load->model('qualification_model','',TRUE);

	}
	
	function index()
	{
		
		if(!$this->session->userdata('loggedin') || !$this->session->userdata('studlog_in'))
   		{
				
			$this->load->view('header');
			$data['qualification'] = $this->qualification_model->GetAllQualifications('');
			$this->load->view('forgotpassword_view',$data);		
			$this->load->view('footer');
			
		}else{
			//If no session, redirect to login page
     		redirect('courses', 'refresh');
		}
		
	}
	
	public function sendOTP() {
        			
		$fpmobile  = $this->input->post('fpmobile');
		$fpcode  = $this->input->post('fpcode');
					
		$ret = $this->student_model->SendOTP($fpmobile,$fpcode);
		echo json_encode($ret);
		        

    }
	
	public function forgotResendOTP() {
        
		$mobile = $this->input->post('usermobile');

		$ret = $this->student_model->ForgotResendOTP($mobile);
		echo json_encode($ret);

    }
	
	public function forgotVerifyOTP() {
        
		$verifyotp  = $this->input->post('verifyotp');
		$newpassword  = $this->input->post('supassword');
		$mobile  = $this->input->post('usermobile');

		$ret = $this->student_model->ForgotVerifyOTP($mobile,$verifyotp,$newpassword);
		echo json_encode($ret);

    }
	
}
<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class requestrefund extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model('login_model','',TRUE);
                $this->load->model('student_model','',TRUE);
		$this->load->model('payment_model','',TRUE);
                 $this->load->helper('form');

	}
	
	function index()
	{
		if($this->session->userdata('loggedin')&& $this->session->userdata('adlog_in'))
   		{
                    $session_data = $this->session->userdata('loggedin');
                    $session_id = $session_data['id'];
                    $session_role = $session_data['role'];
                    
					$data['roleaccess'] = $this->config->item('roleaccess');

					if($data['roleaccess']['Refund Activation'][0]!="y"){
						redirect($data['roleaccess']['defaultpage'], 'refresh');
					}
						
						$feepayid = $this->input->get('id');
                                                $sid = $this->input->get('sid');
                                                 $data['user'] = $this->login_model->GetUserId();
                                                $user = $this->login_model->GetUserDetails($sid);
                                                 $data['menu'] = $this->load->view('headermenu', $data, TRUE);
                                               // $ischkrefund = $this->payment_model->isCheckRefundStatus($feepayid);
                                              // if($ischkrefund === 'c') { redirect('stufeepayments', 'refresh'); }
						
						$data['crid'] = $feepayid;
                                                $data['sid'] = $sid;
												
						$data['feepayments'] = $this->student_model->GetFeePayments($user['id'],$user['qualificationid'],$feepayid);
						
						
						$refundid = $this->payment_model->isCheckRefund($feepayid);
                                                if($refundid === "") {
						$data['stuprofile'] =  $this->student_model->GetStudentProfile($user['id']);
                                                } else {
                                                 $data['stuprofile'] =  $this->payment_model->GetRefund($refundid);       
                                                }
                                                $this->load->view('header_view', $data);
						$this->load->view('requestrefund_view', $data);
						$this->load->view('footer_view');
                            
                     
		}
   		else
   		{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
   		}
		
	}
        
       
}
?>

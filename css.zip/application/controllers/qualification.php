<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Qualification extends CI_Controller {

	function __construct() {
            
		parent::__construct();
		$this->load->model('qualification_model','',TRUE);
                $this->load->model('login_model','',TRUE);
                $this->load->library('table'); $this->load->helper('form');

	}
	
	function index() {
            
           if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')) {

                $session_data = $this->session->userdata('loggedin');
                $session_id = $session_data['id'];
                $session_role = $session_data['role'];
                $data['user'] = $this->login_model->GetUserId();
			   
			    $data['roleaccess'] = $this->config->item('roleaccess');
			
				if($data['roleaccess']['Qualification'][0]!="y"){
					redirect($data['roleaccess']['defaultpage'], 'refresh');
				}

                $data['menu'] = $this->load->view('headermenu', $data, TRUE);
                
                $ide = isset($_GET['id']) ? $_GET['id'] : '';
               
                $tmpl = array('table_open' => '<table class="sortable disabled" id="subjecttable" style="margin-top:0px;">');

                    $this->table->set_template($tmpl);
                    $this->table->set_heading('','SUBJECT', 'RULE','VALUE','OUT OF MARK');
                    $data['classes'] = $this->qualification_model->GetAllClasses();
			   
			   		$data['classstudymaster'] = $this->qualification_model->GetAllClassstudyMaster("");
			   
                if($ide === '') {
                    
                     $data['streams'] = $this->qualification_model->GetAllStreams("",'');
                    $this->load->view('header_view', $data);
                    $this->load->view('qualification_view', $data);
                    $this->load->view('footer_view');
                
                } else if($ide !== ''){
					
					if($data['roleaccess']['Qualification'][1]!="y"){
						redirect($data['roleaccess']['defaultpage'], 'refresh');
					}
                    
                   // $data['qualification'] = $this->qualification_model->ViewQualification($ide);
                    $qualification = $this->qualification_model->ViewQualification($ide);
                    if($qualification['general'] === '') { redirect('qualificationlist', 'refresh');}
                    $data['streams'] = $this->qualification_model->GetAllStreams("","");
                    
                    
                    $data['qualification'] = $qualification;
                    $this->load->view('header_view', $data);
                    $this->load->view('editqualification_view', $data);
                    $this->load->view('footer_view');
                    
                    
                }
            } else {
                //If no session, redirect to login page
                redirect('login', 'refresh');
            }
            
        }
        
         public function getSubjects() {
            
            if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')|| $this->session->userdata('studlog_in')) {
                
                $ide = isset($_POST['id']) ? $_POST['id'] : 'default';	
                $ret =  $this->qualification_model->GetSubjects($ide);
                echo $ret;
                
            }else{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
            }
            
        }
        
        
        public function qualificationSubmit() {
            
        if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')) {
        $this->load->library('form_validation');
        $ide = isset($_POST['ide']) ? $_POST['ide'] : '';
        $xii_flag = isset($_POST['xii_flag']) ? $_POST['xii_flag'] : '';
        $exam = isset($_POST['exam']) ? $_POST['exam'] : '';
        $rexam = isset($_POST['rexam']) ? $_POST['rexam'] : '';
        $vexam = isset($_POST['vexam']) ? $_POST['vexam'] : '';
        $oexam = isset($_POST['oexam']) ? $_POST['oexam'] : '';
                       
        $postVar = $this->input->post('x',true);
        $xArr = json_decode($postVar);
        

		$this->form_validation->set_rules('classstudy', 'Class Studying', "trim|required|xss_clean|callback_alpha_numeric_spaces|max_length[200]");	
        
       if($ide == "") {
        $vqname = "trim|required|xss_clean|callback_alpha_numeric_spaces|max_length[100]|is_unique[admin_qualification.name]";
        $this->form_validation->set_rules('qname', 'Qualification Name', $vqname);
		   		   
       } else {
           $vqname = "trim|required|xss_clean|callback_alpha_numeric_spaces|max_length[100]";
           $this->form_validation->set_rules('qname', 'Qualification Name', $vqname);
       }
        $validatation["rule"] = "trim|required|xss_clean|regex_match[/[GL]TE/]|max_length[3]";
        $validatation["year"] = "trim|required|xss_clean|numeric|max_length[4]";
        $validatation["class"] = "trim|required|xss_clean|callback_alpha_numeric_spaces|max_length[100]";
        $validatation["rollno"] = "trim|xss_clean|regex_match[/Y|N/]|max_length[1]";
        $validatation["gracemark"] = "trim|xss_clean|regex_match[/Y|N/]|max_length[1]";
        $validatation["waitingresult"] = "trim|xss_clean|regex_match[/Y|N/]|max_length[1]";
        $validatation["completedresult"] = "trim|xss_clean|regex_match[/Y|N/]|max_length[1]";
        $subjectFlag= "0";$markFlag= "0";
        for ($i = 0 ; $i < count($xArr);$i++) {
          
            foreach ($xArr[$i] as $key=>$val) {
                if($xArr[$i]->subject != '') {
                    $skey = $xArr[$i]->stream." ".$key;
                    $_POST[$skey] = $val;                       
                    $this->form_validation->set_rules($skey, $skey, $validatation[$key]);
                    $subjectFlag= "1";
                    
                    $qmark = str_replace("|", "", $xArr[$i]->qmark);
                    $qgrade = str_replace("|", "", $xArr[$i]->qgrade);
                    if( ($qmark != '') || ($qgrade != '') ) { $markFlag = "1";}
                }
            }
            
        }
        
        if($subjectFlag === "0") { 
            $_POST['subject'] = '';     
            $this->form_validation->set_rules('subject', "Primary Subject Details", 'trim|required|xss_clean|callback_alpha_numeric_spaces|max_length[100]');
        }
        
        if($markFlag === "0") { 
            $_POST['mark'] = '';     
            $this->form_validation->set_rules('mark', "Primary Mark/Grade Details", 'trim|required|xss_clean|callback_alpha_numeric_spaces|max_length[100]');
        }
        
        if($xii_flag === '1') {
            
            $postVar1 = $this->input->post('xii',true);
            $xArr1 = json_decode($postVar1);
            $xii_subjectFlag= "0";$xii_markFlag= "0";
            for ($i = 0 ; $i < count($xArr1);$i++) {

                foreach ($xArr1[$i] as $key=>$val) {
                    if($xArr1[$i]->subject != '') {
                    $skey = "Higher secondary ".$xArr1[$i]->stream." ".$key;
                    $_POST[$skey] = $val;                       
                    $this->form_validation->set_rules($skey, $skey, $validatation[$key]);
                    $xii_subjectFlag= "1";
                    
                    $qmark = str_replace("|", "", $xArr1[$i]->qmark);
                    $qgrade = str_replace("|", "", $xArr1[$i]->qgrade);
                    if( ($qmark != '') || ($qgrade != '') ) { $xii_markFlag = "1";}
                }

                }

            }
            
            if($xii_subjectFlag === "0") { 
                $_POST['xii_subject'] = '';  
                $this->form_validation->set_rules('xii_subject', "Higher Secondary Subject Details", 'trim|required|xss_clean|callback_alpha_numeric_spaces|max_length[100]');
            }
               
            if($xii_markFlag === "0") { 
                $_POST['xii_mark'] = '';     
                $this->form_validation->set_rules('xii_mark', "Higher Secondary Mark/Grade Details", 'trim|required|xss_clean|callback_alpha_numeric_spaces|max_length[100]');
            }
            
            
        }
        
        if ($this->form_validation->run() == false) {
                $response = array(
                    'status' => 'error',
                    'message' => validation_errors()
                );
                echo json_encode($response);
                
        } else {
        
                 
            if($ide === '') {
                  $response = $this->insertQ($xii_flag,$exam,$rexam,$vexam,$oexam);
              }else if($ide !== ''){
                  $response = $this->updateQ($ide,$xii_flag,$exam,$rexam,$vexam,$oexam);
              } 
              
              echo  json_encode($response);
        }
      
        
               
            }else{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
            }
    }
    
        
    public function insertQ($xii_flag,$exam,$rexam,$vexam,$oexam){
        
		$marksheet_flag = $this->input->post('marksheet_flag',true);
		$marksheet_info = $this->input->post('marksheet_info',true);
		$classstudy = $this->input->post('classstudy',true);
		
        $ide = uniqid();
        $qoffset = $this->qualification_model->QualificationOffset();
            $qData = array(
                'id' => $ide,
                'name' => $this->input->post('qname', true),
                'qualificationid' => $qoffset,
                'qualification_rule' => '','qualification_year' => '',
                'class' => '','rollno' => '','gracemark' => '','waitingresult' => '',
                'xii_qualification_rule' => '','xii_qualification_year' => '',
                'xii_rollno' => '','xii_gracemark' => '','xii_waitingresult' => '',
                'xii_flag' => $xii_flag,
                'entrance' => $exam,'entrance_rule' => $rexam,
                'entrance_value' => $vexam,'entrance_outofmark' => $oexam,
                'status' => 'a',
                'del' => 'n',
                'created_at' => date('Y-m-d H:i:s'),
                'marksheet_flag' => $marksheet_flag,
                'marksheet_info' => $marksheet_info,
                'classstudy' => $classstudy
            );
            
            
            $id = $this->qualification_model->insertQualification($qData);
            
            $postVar = $this->input->post('x',true);
            $xArr = json_decode($postVar);
            
          for ($i = 0 ; $i < count($xArr);$i++) {
                
              if($xArr[$i]->subject !== "") {
                $qData = array(
                'id' => uniqid(),
                'parentid' => $ide,
                'qrule' => $xArr[$i]->rule,
                'year' => $xArr[$i]->year,
                'class' => $xArr[$i]->class,
                'rollno' => $xArr[$i]->rollno,
                'gracemark' => $xArr[$i]->gracemark,
                'waiting' => $xArr[$i]->resultwaiting,
                'completed' => $xArr[$i]->resultcompleted,
                'subject' => $xArr[$i]->subject,
                'rule' => $xArr[$i]->qrule,
                'mark' => $xArr[$i]->qmark,
                'grade' => $xArr[$i]->qgrade,
                'stream' => $xArr[$i]->stream,
                'outofmark' => $xArr[$i]->outofmark,
                'trule' => $xArr[$i]->trule,
                'total' => $xArr[$i]->mtotal,
                'created_at' => date('Y-m-d H:i:s')
                 );
                      
        
                $id = $this->qualification_model->insertQualification_x($qData);
              }
            
            }
            
            if($xii_flag === '1') {
                
                   $postVar = $this->input->post('xii',true);
                   $xArr = json_decode($postVar);

                   for ($i = 0 ; $i < count($xArr);$i++) {
                        if($xArr[$i]->subject !== "") {
                            $qData = array(
                             'id' => uniqid(),
                             'parentid' => $ide,
                             'qrule' => $xArr[$i]->rule,
                             'year' => $xArr[$i]->year,
                             'class' => $xArr[$i]->class,
                             'rollno' => $xArr[$i]->rollno,
                             'gracemark' => $xArr[$i]->gracemark,
                             'waiting' => $xArr[$i]->resultwaiting,
                             'completed' => $xArr[$i]->resultcompleted,
                             'subject' => $xArr[$i]->subject,
                             'rule' => $xArr[$i]->qrule,
                             'mark' => $xArr[$i]->qmark,
                             'grade' => $xArr[$i]->qgrade,
                             'stream' => $xArr[$i]->stream,
                             'outofmark' => $xArr[$i]->outofmark,
                             'trule' => $xArr[$i]->trule,
                             'total' => $xArr[$i]->mtotal,
                             'created_at' => date('Y-m-d H:i:s')
                              );

                            $id = $this->qualification_model->insertQualification_xii($qData);
                        }
                    }
            }

            $response = array(
                'status' => 'success',
                'message' => "Qualification Created Successfully."
            );

          return $response;
    }
    
    public function updateQ($ide,$xii_flag,$exam,$rexam,$vexam,$oexam){
        
           $marksheet_flag = $this->input->post('marksheet_flag',true);
		   $marksheet_info = $this->input->post('marksheet_info',true);
			$classstudy = $this->input->post('classstudy',true);
		
            $qData = array(
                'id' => $ide,
                'name' => $this->input->post('qname', true),
                'qualificationid' => $this->input->post('qualid', true),
                'qualification_rule' => '','qualification_year' => '',
                'class' => '','rollno' => '','gracemark' => '','waitingresult' => '',
                'xii_qualification_rule' => '','xii_qualification_year' => '',
                'xii_rollno' => '','xii_gracemark' => '','xii_waitingresult' => '',
                'xii_flag' => $xii_flag,
                'entrance' => $exam,'entrance_rule' => $rexam,
                'entrance_value' => $vexam,'entrance_outofmark' => $oexam,
                'status' => 'a',
                'del' => 'n',
                'created_at' => date('Y-m-d H:i:s'),
                'marksheet_flag' => $marksheet_flag,
                'marksheet_info' => $marksheet_info,
                'classstudy' => $classstudy
            );
            
            

            $id = $this->qualification_model->updateQualification($qData);
            
            $postVar = $this->input->post('x',true);
            $xArr = json_decode($postVar);
            
          
          
          for ($i = 0 ; $i < count($xArr);$i++) {
          
               
                                       
                $qData = array(    
                'id' => $xArr[$i]->id,
                'parentid' => $ide,               
                'qrule' => $xArr[$i]->rule,
                'year' => $xArr[$i]->year,
                'class' => $xArr[$i]->class,
                'rollno' => $xArr[$i]->rollno,
                'gracemark' => $xArr[$i]->gracemark,
                'waiting' => $xArr[$i]->resultwaiting,
                'completed' => $xArr[$i]->resultcompleted,
                'subject' => $xArr[$i]->subject,
                'rule' => $xArr[$i]->qrule,
                'mark' => $xArr[$i]->qmark,
                'grade' => $xArr[$i]->qgrade,
                'stream' => $xArr[$i]->stream,
                'outofmark' => $xArr[$i]->outofmark,
                'trule' => $xArr[$i]->trule,
                'total' => $xArr[$i]->mtotal,
                'created_at' => date('Y-m-d H:i:s')
                );
                      
        
                $id = $this->qualification_model->updateQualification_x($qData);
                
               
            
            }
            
            if($xii_flag === '1') {
                
                   $postVar = $this->input->post('xii',true);
                   $xArr = json_decode($postVar);



                   for ($i = 0 ; $i < count($xArr);$i++) {

                      

                       $qData = array( 
                       'id' => $xArr[$i]->id,
                       'parentid' => $ide,
                        'qrule' => $xArr[$i]->rule,
                        'year' => $xArr[$i]->year,
                        'class' => $xArr[$i]->class,
                        'rollno' => $xArr[$i]->rollno,
                        'gracemark' => $xArr[$i]->gracemark,
                        'waiting' => $xArr[$i]->resultwaiting,
                        'completed' => $xArr[$i]->resultcompleted,
                        'subject' => $xArr[$i]->subject,
                        'rule' => $xArr[$i]->qrule,
                        'mark' => $xArr[$i]->qmark,
                        'grade' => $xArr[$i]->qgrade,
                        'stream' => $xArr[$i]->stream,
                        'outofmark' => $xArr[$i]->outofmark,
                        'trule' => $xArr[$i]->trule,
                        'total' => $xArr[$i]->mtotal,
                       'created_at' => date('Y-m-d H:i:s')
                        );


                       $id = $this->qualification_model->updateQualification_xii($qData);

                      


                   }
                                
                
            }

            $response = array(
                'status' => 'success',
                'message' => "Qualification Updated Successfully."
            );

          return $response;

          
    }
    
    
  

}
?>
<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Idcardprint extends CI_Controller {

	function __construct() {
            
		parent::__construct();
		
                $this->load->model('login_model','',TRUE);
                $this->load->model('student_model','',TRUE);
				$this->load->helper('form');
				$this->load->library('table');
				$this->load->helper('My_datatable_helper');
		$this->load->helper('download');

	}
	
	function index() {
            
            if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')) {

                $session_data = $this->session->userdata('loggedin');
                $session_id = $session_data['id'];
                $session_role = $session_data['role'];
                $data['user'] = $this->login_model->GetUserId();

				$data['roleaccess'] = $this->config->item('roleaccess');
			
				if($data['roleaccess']['ID Card Batch Print'][3]!="y"){
					redirect($data['roleaccess']['defaultpage'], 'refresh');
				}
							
				$data['menu'] = $this->load->view('headermenu', $data, TRUE);
                $this->load->view('header', $data);
                $this->load->view('idcardprint_view', $data);
                $this->load->view('footer');
				
            } else {
                //If no session, redirect to login page
                redirect('login', 'refresh');
            }
            
        }
        
	public function GetIDCardPrintList() {
            
		if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in') ){
			
			$data['user'] = $this->login_model->GetUserId();
						
			$result =  $this->student_model->GetIDCardPrintList();

			$row = array();
			
			$sno = 1;
			
			foreach($result as $key=>$col){			
				
				$printtotalcount = check_printtotalcount($col->printbatchid);
				$printcount = check_printcount($col->printbatchid);
				$notprintcount = check_notprintcount($col->printbatchid);
				
				//$created = date("d-M-Y h:i A",strtotime($col->created));
							
				$row[] = array($sno,$col->printbatchid,$col->printbatchname,$col->batchname,$printtotalcount,$printcount,$notprintcount,'<a class="edit noedit" href="idcardbatchprint?id='.$col->printbatchid.'"><img style="padding:5px 10px" src="images/view.png"> View</a>');
									
				$sno++;
				
			}
									
			$ret = array("tabledata"=>$row);
			echo json_encode($ret);
			
		}else{
		//If no session, redirect to login page
		redirect('login', 'refresh');
		}

	}
	
	  public function uploadBatchprint(){
            
		if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')){

			//print_r($_FILES);exit;
			
			//$bname = $this->input->post('bname', true);
			
			if(isset($_FILES["file"]) && !empty($_FILES["file"]['name'])){
				
				$total = count($_FILES['file']['name']);
				
				$validExtensions = array('.xls');
								
				$dirname = FCPATH.'docs/idcardbatches/';
								
				$fileExtension = strrchr($_FILES['file']['name'][0], ".");
				$fileName = "idcardbatches_".date("YmdHis").$fileExtension;
									
				$destinationfull = $dirname . $fileName;
					
				if(!file_exists($dirname)) mkdir($dirname,0777);
							
				if (in_array(strtolower($fileExtension), $validExtensions)) {
					
					$resultfull = move_uploaded_file($_FILES['file']['tmp_name'][0],$destinationfull);
					
					if(!$resultfull){
				    
						$ret = array('status' => "ufail");
						echo json_encode($ret);
						exit(0);
						
					}else{
						
						$result = $this->addBatchprint($fileName);
						
						$exceldata = "";
						if($result['exceldata']!=""){
							$exceldata = '<thead><tr><th style="width: 5%">S.no</th><th >Student ID</th><th>Batch Name</th><th>Reason</th></tr></thead>';
							$exceldata .= $result['exceldata'];
							setcookie("exceldata", $exceldata, time()+3600, "/");
						}
						
						$ret = array('status' => "success","message"=>$result['message'],"exceldata"=>$exceldata);
						echo json_encode($ret);
						exit(0);
						
					}
								
				}else{
					
					$ret = array('status' => "exfail");
					echo json_encode($ret);
					exit(0);
					
				}
					
								
			}else{
				
				$ret = array('status' => "empty");
				echo json_encode($ret);
				exit(0);
				
			}
			
			
		}
	  
  }
	
	
function addBatchprint($fileName){
	
	ini_set('memory_limit', '-1');	
	ini_set('max_execution_time', 86400);
	
	include './import/excel_reader.php';     // include the class

	// creates an object instance of the class, and read the excel file data
	$excel = new PhpExcelReader;
	$excel->read(FCPATH.'docs/idcardbatches/'.$fileName);
		
	$sheet = $excel->sheets[0];
	
	$x = 2;

	//echo $sheet['numRows'];exit;
	
	$arr = array();
	
	$arr["message"] = "";
	$arr['printbid'] = "";
	$arr["exceldata"] = '';
	
	$exsno = 1;
	
  while($x <= $sheet['numRows']) {
	  	  
	  $sno = isset($sheet['cells'][$x][1]) ? $sheet['cells'][$x][1] : '';
	  $batchname = isset($sheet['cells'][$x][2]) ? $sheet['cells'][$x][2] : '';
	  $studentno = isset($sheet['cells'][$x][3]) ? $sheet['cells'][$x][3] : '';
	  //$courseno = isset($sheet['cells'][$x][4]) ? $sheet['cells'][$x][4] : '-';
	  
	  //echo $x.". ".$studentno."<br />";$x++;continue;
		  		  
	  // Add results
	  
	  $result = $this->student_model->AddIDcardBatchPrint($batchname,$studentno,$arr['printbid']);
	  
	  if($result['printbid']!="") $arr['printbid'] = $result['printbid'];
	  
	  if($result['response']=="nostudent" && trim($studentno)!="" && is_numeric($studentno)){
		  $arr["message"] .= "<p><font color='orange'>".$sno.". ".$studentno." - Not found</font></p>";
		  $arr["exceldata"] .= '<tr><td>'.$exsno.'</td><td>'.$studentno.'</td><td>'.$batchname.'</td><td>Student not found</td></tr>';
		  $exsno++;
		  
	  }else if($result['response']=="exists" && trim($studentno)!="" && is_numeric($studentno)){
		  $arr["message"] .= "<p><font color='red'>".$sno.". ".$studentno." - Batch already exists</font></p>";
		  $arr["exceldata"] .= '<tr><td>'.$exsno.'</td><td>'.$studentno.'</td><td>'.$batchname.'</td><td>Batch already exists</td></tr>';
		  $exsno++;
	  }else if($result['response']=="nobatch" && trim($studentno)!="" && is_numeric($studentno)){
		  $arr["message"] .= "<p><font color='red'>".$sno.". ".$studentno." - Batch Not assigned</font></p>";
		  $arr["exceldata"] .= '<tr><td>'.$exsno.'</td><td>'.$studentno.'</td><td>'.$batchname.'</td><td>Batch not assigned</td></tr>';
		  $exsno++;
	  }

	  //exit;

	  $x++;
		  		  			  
  }
		
	return $arr;

}
	
	
public function downloadexcel(){
	
	if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')){
		
		if(isset($_COOKIE['exceldata'])){
		
			$html = $_COOKIE['exceldata'];
			$savename = "IDcard_Batch_Upload_Status".date('d-m-Y-H_i_s');

			$html = str_replace('<tr>',"\n",$html);
			$html = str_replace('</tr>',"",$html);

			$html = str_replace('</th>',"\t",$html);
			$html = str_replace('<th>',"",$html);

			$html = str_replace('</td>',"\t",$html);
			$html = str_replace('<td>',"",$html);


			$html = strip_tags($html);

			$filename = $savename .".xls";

			setcookie("exceldata", "", time()+3600, "/");	

			force_download($filename, $html);
			
		}
		
	}else{
	//If no session, redirect to login page
	redirect('login', 'refresh');
	}
	
	
}
	
	
	
}
?>
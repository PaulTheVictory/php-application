<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class CourseChange extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model('login_model','',TRUE);
		$this->load->model('course_model','',TRUE);
		$this->load->library('table'); $this->load->helper('form');
                 $this->load->model('payment_model','',TRUE);

	}
	
	function index()
	{
		if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in'))
   		{
                    $session_data = $this->session->userdata('loggedin');
                    $session_id = $session_data['id'];
                    $session_role = $session_data['role'];
                    
					$data['roleaccess'] = $this->config->item('roleaccess');

					if($data['roleaccess']['uview']!="y"){
						redirect($data['roleaccess']['defaultpage'], 'refresh');
					}
			
                    $data['user'] = $this->login_model->GetUserId();

                    $data['menu'] = $this->load->view('headermenu', $data, TRUE);
			
                    $this->load->view('header_view', $data);
                    $this->load->view('coursechange_view', $data);
                    $this->load->view('footer_view');
                    
                    
                }else{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
   		}
		
	}
	
    public function courseChangeList()
    {

		
	if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')){
			
		$roleaccess = $this->config->item('roleaccess');
		
		$user = $this->login_model->GetUserId();
		$batches = $user['batches'];
		
		$columns = array( 
                            0 =>'created_at', 
                            1 =>'receiptno', 
                            2 =>'studid',
                            3=> 'sname',
                            4=> 'fcoursename',
			    5=> 'center',
                            6=> 'tcoursename',
                            7=> 'new_center',
                            8=> 'remitted',
                            8=> 'refundamount',
                            10=> ''
                        );

		$limit = $this->input->post('length');
        $start = $this->input->post('start');
        $order = $columns[$this->input->post('order')[0]['column']];
        $dir = $this->input->post('order')[0]['dir'];
		
		$searchcol = $this->input->post('searchcol', true);
  
        $totalData = $this->course_model->courseChange_count($batches);
            
        $totalFiltered = $totalData; 
            
        if(empty($this->input->post('search')['value']))
        {            
            $posts = $this->course_model->courseChangelist($limit,$start,$order,$dir,$batches);
        }
        else {
            $search = $this->input->post('search')['value']; 

            $posts =  $this->course_model->courseChangelist_search($limit,$start,$search,$order,$dir,$searchcol,$batches);

            $totalFiltered = $this->course_model->courseChangelist_search_count($search,$searchcol,$batches);
        }

        $data = array();
        if(!empty($posts))
        {
            foreach ($posts as $post)
            {

                $nestedData['receiptno'] = $post['receiptno'];
                $nestedData['sname'] = '<a class="noedit" target="_blank" href="'.base_url().'studentprofile?sid='.$post['studentid'].'">'.strtoupper($post['sname']).'</a>';                
                $nestedData['studid'] ='<a class="noedit" target="_blank" href="'.base_url().'studentprofile?sid='.$post['studentid'].'">'.$post['studid'].'</a>';  
                $nestedData['fcoursename'] ='<a class="noedit" target="_blank" href="'.base_url().'viewrequest?id='.$post['requestid'].'">'.$post['fcoursename'].'</a>'; 
		$nestedData['center'] = $post['center'];
                $nestedData['tcoursename'] ='<a class="noedit" target="_blank" href="'.base_url().'viewrequest?id='.$post['new_requestid'].'">'.$post['tcoursename'].'</a>'; 
		$nestedData['new_center'] = $post['new_center'];
                $nestedData['remitted'] = $post['remitted'];
                $nestedData['refundamount'] = $post['refundamount'];
                $nestedData['created_at'] = $post['created_at'];
           	
                $nestedData['actions'] = '<span  data-receiptno="'.$post['receiptno'].'" class="cchangeview" style="color:#0332AA;padding-left: 20px;background:url('.base_url().'images/view.png) no-repeat;background-position-y: 4px;cursor:pointer" >View</span>';;
            
                
                $data[] = $nestedData;

            }
        }
          
        $json_data = array(
                    "draw"            => intval($this->input->post('draw')),  
                    "recordsTotal"    => intval($totalData),  
                    "recordsFiltered" => intval($totalFiltered), 
                    "data"            => $data   
                    );
            
        echo json_encode($json_data); 
			
	}else{
			
		//If no session, redirect to login page
		redirect('login', 'refresh');
			
	}
		
    }
    
    public function getRefundPaymentLists() {
            
            if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in') || $this->session->userdata('studlog_in')){
                $cid = isset($_POST['cid']) ? $_POST['cid'] : '';
                $sid = isset($_POST['sid']) ? $_POST['sid'] : '';
                $center = isset($_POST['center']) ? $_POST['center'] : '';
               
                
                $ret =  $this->payment_model->GetCCPaymentLists($cid,$sid,$center);
                echo $ret;
                
            }else{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
            }
            
        }
    
     public function viewCourseChangePaymentLists() {
            
            if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')){
  
                $id = isset($_GET['id']) ? $_GET['id'] : '';
                $ret = array(0 => "success",1=>"");
        
            
                $html = $this->course_model->ViewCourseChangePaymentLists($id);
                $ret[1]= $html;
                echo json_encode($ret);
            }
        }
    


}
?>

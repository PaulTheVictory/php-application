<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Addpayment extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model('login_model','',TRUE);
                $this->load->model('payment_model','',TRUE);
                $this->load->model('course_model','',TRUE);
                 $this->load->library('table'); $this->load->helper('form');

	}
	
	function index()
	{
		if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in'))
   		{
                    $session_data = $this->session->userdata('loggedin');
                    $session_id = $session_data['id'];
                    $session_role = $session_data['role'];
                    $data['user'] = $this->login_model->GetUserId();
			
					$data['roleaccess'] = $this->config->item('roleaccess');
			
					if($data['roleaccess']['Course Add Payment'][3]!="y"){
						redirect($data['roleaccess']['defaultpage'], 'refresh');
					}
			
                    $data['ide'] = isset($_GET['id']) ? $_GET['id'] : 'default';	
                    $data['course'] = $this->course_model->EditCourse($data['ide'],"payment");
                    $data['fees'] = $this->payment_model->GetFeesMaster();
		
                    
                    $data['menu'] = $this->load->view('headermenu', $data, TRUE);
                    
                     $tmpl = array('table_open' => '<table class="sortable sorting disabled" id="paymenttable" style="margin-top:0px;">');
                                $this->table->set_template($tmpl);
                                $this->table->set_heading('S.NO', 'DESCRIPTION','SAC','AMOUNT', 'DISCOUNT','GST(%)','TOTAL');
						
                    $this->load->view('header_view', $data);
                    $this->load->view('addpayment_view', $data);
                    $this->load->view('footer_view');
		}
   		else
   		{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
   		}
		
	}
        
         public function getPaymentLists() {
            
            if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')){
                
                $ide = isset($_POST['id']) ? $_POST['id'] : 'default';	
                $ret =  $this->payment_model->GetAllPaymentItems($ide);
                
                echo $ret;
                
            }else{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
            }
            
        }
        
      public function PaySubmit() {
          
        if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')){  
        $this->load->library('form_validation');
        $this->form_validation->set_rules('pdata', 'Payment', 'trim|required|xss_clean|max_length[10000]');
       // $this->form_validation->set_rules('ptype', 'Payment Type', 'trim|required|xss_clean|regex_match[/1|0/]|max_length[1]');
          
          if ($this->form_validation->run() == false) {
            $response = array(
                'status' => 'error',
                'message' => validation_errors()
            );
        } else {
            
          $this->payment_model->AddPayment($this->input->post('pdata', true),$this->input->post('ptype', true),$this->input->post('cid', true));
          $response = array(
                'status' => 'success',
                'message' => "Payment Updated Successfully."
            );
            
        }
        
        echo  json_encode($response);
        
        }else{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
            }
        
      }
     	
	
	
	
}
?>

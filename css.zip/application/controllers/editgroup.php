<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Editgroup extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model('course_model','',TRUE);
                $this->load->model('login_model','',TRUE);

	}
	
	function index()
	{
		if($this->session->userdata('loggedin'))
   		{
                    $ide = isset($_GET['id']) ? $_GET['id'] : '';
     		    $session_data = $this->session->userdata('loggedin');
		    $session_id = $session_data['id'];
     		    $session_role = $session_data['role'];
		    $data['user'] = $this->login_model->GetUserId();
                    $data['edit'] = $this->course_model->EditGroup($ide);
				
                    $data['menu'] = $this->load->view('headermenu', $data, TRUE);
                    $this->load->view('header', $data);
                    $this->load->view('editgroup_view', $data);
                    $this->load->view('footer');
			
                }
   		else
   		{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
   		}
		
	}
        
         
        public function updateGroup() {
            
            if ($this->session->userdata('loggedin')) {

            $name = isset($_GET['name']) ? $_GET['name'] : '';
            $discount = isset($_GET['discount']) ? $_GET['discount'] : '';
            $cdiscount = isset($_GET['cdiscount']) ? $_GET['cdiscount'] : '';
            $ediscount = isset($_GET['ediscount']) ? $_GET['ediscount'] : '';
            $tax = isset($_GET['tax']) ? $_GET['tax'] : '';
            $ide = isset($_GET['id']) ? $_GET['id'] : '';
            
            if($name != "" && $ide != "" ){
                 $ret = $this->course_model->UpdateGroup($name, $discount, $cdiscount, $ediscount,$ide,$tax);
            } else {
                $ret = array(0 => "fail");
            }

           
            echo json_encode($ret);
            
            }else {
                //If no session, redirect to login page
                redirect('login', 'refresh');
            }
        
        
        }
	
	
	
	
}
?>
<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Bookhistory extends CI_Controller {

	function __construct() {
            
		parent::__construct();
		
                $this->load->model('login_model','',TRUE);
                $this->load->model('library_model','',TRUE);
				$this->load->helper('form');
				$this->load->library('table');
				$this->load->helper('My_datatable_helper');

	}
	
	function index() {
            
            if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')) {

                $session_data = $this->session->userdata('loggedin');
                $session_id = $session_data['id'];
                $session_role = $session_data['role'];
                $data['user'] = $this->login_model->GetUserId();

				$data['roleaccess'] = $this->config->item('roleaccess');
			
				if($data['roleaccess']['Issue Books'][3]!="y"){
					redirect($data['roleaccess']['defaultpage'], 'refresh');
				}
				
				$barcode = $this->input->get("bcode",true);
				
				$data['barcode'] = $barcode;
									
				$data['bookdetails'] = $this->library_model->GetBarcodeHistoryDetails($barcode);
				
				
				$data['units'] = $this->library_model->GetAllCenters("",'option',$data['user']['lcenters']);               

				$data['menu'] = $this->load->view('headermenu', $data, TRUE);
                $this->load->view('header', $data);
                $this->load->view('bookhistory_view', $data);
                $this->load->view('footer');
				
            } else {
                //If no session, redirect to login page
                redirect('login', 'refresh');
            }
            
        }
        
	public function GetBarcodeHistoryList() {
            
		if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in') ){
			
			$data['user'] = $this->login_model->GetUserId();
			
			$barcode = $this->input->post('barcode');
			
			$result =  $this->library_model->GetBarcodeHistoryList($barcode);

			$row = array();
			
			$sno = 1;
			
			foreach($result as $key=>$col){			
				
				$booktype = check_booktype($col->booktype);
				$duedate = change_DateFormat($col->duedate);
				
				$created = date("d-M-Y h:i A",strtotime($col->created));
				$recieveddate = date("d-M-Y h:i A",strtotime($col->recieveddate)); 
				$recieved = $col->receivedstatus;
				$dueperiod = $col->dueperiod;
				
				$sname = $col->sname;
				$studid = $col->studid;
				$staffname = $col->staffname;
				$staffmobile = $col->staffmobile;
				
				$stuname = $stuidno = "";
				
				if($sname!=""){
					$stuname = $sname;
					$stuidno = $studid;
				}else{
					$stuname = $staffname;
					$stuidno = $staffmobile;
				}
				
				if($recieved=="y"){
					$recieveddate = date("d-M-Y h:i A",strtotime($col->recieveddate)); 
					//$remaindue = get_issuehistoryremaindue($col->created,$col->recieveddate);
					$remaindue = "0";
					
				}else {
					$recieveddate = "-";
					$remaindue = get_bookremaindue($col->duedate);
				}
					
				$row[] = array($sno,$stuidno,$stuname,$col->price,$booktype,$created,$duedate,$recieveddate,$remaindue);
									
				$sno++;
				
			}
									
			$ret = array("tabledata"=>$row);
			echo json_encode($ret);
			
		}else{
		//If no session, redirect to login page
		redirect('login', 'refresh');
		}

	}	

	
	public function getbarcodedetails() {
            
        if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')) {
			
			$roleaccess = $this->config->item('roleaccess');
			
			if(isset($roleaccess['Issue Books'][3]) && $roleaccess['Issue Books'][3]=="y"){
			         
				$barcode = $this->input->post("barcode",true);
			
				$bookdetails = $this->library_model->GetBarcodeHistoryDetails($barcode);
			
			if(empty($bookdetails)){
								
					$response = array(
						'status' => 'error',
						'message' => 'Barcode not found'
					);
				
				echo json_encode($response);
				
			}else{
				
				$response = array(
					'status' => 'success',
					'data' => $bookdetails
				);
				
				echo json_encode($response);
			}
                

			 } else {

 					$response = array(
						'status' => 'error',
						'message' => 'User Permission Denied'
					);
                    echo json_encode($response);
				
                }
              
               
            }else{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
            }
            
    }
	
	
}
?>
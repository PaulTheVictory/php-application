<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Staffadd extends CI_Controller {

	function __construct() {
            
		parent::__construct();
		$this->load->model('users_model','',TRUE);$this->load->model('course_model','',TRUE);
                $this->load->model('login_model','',TRUE);$this->load->model('library_model','',TRUE);
                 $this->load->library('table'); $this->load->helper('form');

	}
	
	function index() {
            
            if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')) {

                $session_data = $this->session->userdata('loggedin');
                $session_id = $session_data['id'];
                $session_role = $session_data['role'];
                $data['user'] = $this->login_model->GetUserId();
				
				$data['roleaccess'] = $this->config->item('roleaccess');

				if($data['roleaccess']['Staffs'][0]!="y"){
					redirect($data['roleaccess']['defaultpage'], 'refresh');
				}
				
           
                $data['menu'] = $this->load->view('headermenu', $data, TRUE);
                
                $this->load->view('header_view', $data);
                $this->load->view('staffadd_view', $data);
                $this->load->view('footer_view');
                
            } else {
                //If no session, redirect to login page
                redirect('login', 'refresh');
            }
            
        }
        
        
             
        
       public function staffSubmit() {
            
        if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')) {
                $this->load->library('form_validation');
                
			$roleaccess = $this->config->item('roleaccess');
			
			if(isset($roleaccess['Staffs'][0]) && $roleaccess['Staffs'][0]=="y"){
			
                $this->form_validation->set_rules('staffname', 'Staff Name', 'trim|required|xss_clean|callback_alpha_numeric_spaces|max_length[200]|is_unique[bscp_staffs.staffname]');
                $this->form_validation->set_rules('staffemail', 'Email Address', 'trim|required|xss_clean|callback_alpha_numeric_spaces|max_length[200]');
                $this->form_validation->set_rules('staffmobile', 'Phone Number', 'trim|required|xss_clean|numeric|max_length[10]|is_unique[bscp_staffs.staffmobile]');
                
                if ($this->form_validation->run() == false) {
                        $response = array(
                            'status' => 'error',
                            'message' => validation_errors()
                        );
                        echo json_encode($response);

                } else {


                    
                     $response = $this->insertQ();
                     echo  json_encode($response);
                }
				
			}else {

				  $response = array(
						'status' => 'error',
						'message' => 'User Permission denied'
					);
					echo json_encode($response);
                }
              
               
            }else{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
            }
            
    }
    
        
    public function insertQ(){
        
		$roleaccess = $this->config->item('roleaccess');
			
		if(isset($roleaccess['Users'][0]) && $roleaccess['Users'][0]=="y"){
                    
        $ide = uniqid();
            $qData = array(
                'id' => $ide,
                'mcode' => '91',
                'staffmobile' => $this->input->post('staffmobile', true),
                'staffemail' => $this->input->post('staffemail', true),
                'staffname' => $this->input->post('staffname', true),
                'created_at' => date('Y-m-d H:i:s')
            );
                       

            $id = $this->users_model->AddStaff($qData);
                       
            $response = array(
                'status' => 'success',
                'message' => "Staff Created Successfully."
            );
			
		}else {

		  $response = array(
				'status' => 'error',
				'message' => 'User Permission denied'
			);
			echo json_encode($response);
		}
		

          return $response;
    }
    
        
        

}
?>
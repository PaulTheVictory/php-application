<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Stucoursedetails extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model('course_model','',TRUE);
                $this->load->model('login_model','',TRUE);
                $this->load->model('student_model','',TRUE);

	}
	
	function index()
	{
		if($this->session->userdata('loggedin'))
   		{
			$ide = isset($_GET['id']) ? $_GET['id'] : '';
			$session_data = $this->session->userdata('loggedin');
			$session_id = $session_data['id'];
			$session_role = $session_data['role'];
			$data['user'] = $this->login_model->GetUserId();
			$data['edit'] = $this->course_model->EditCourse($ide,"payment");

			if($session_role === 'student'){

				$courseid = $this->input->get('id');
				
				$data['courseid'] = $courseid;
					
				$data['centername'] =  $this->course_model->CheckCourseRequestCenter($courseid,$data['user']['id']);
				
				$data['searchoptions'] = $this->student_model->GetCourseSearchOptions($data['user']['qualificationid'],$courseid,$data['centername']);
				$data['coursedetails'] =  $this->student_model->GetCourseDetails($courseid,$data['user']['qualificationid']);
				
				$data['waiting'] =  $this->course_model->CheckCourseRequest($courseid,$data['user']['id']);
				
				$data['checksamequalify'] =  $this->course_model->CheckQualifyCourseRequest($data['user']['id'],$courseid,$data['coursedetails']['course']['qualification']);
				
				$this->load->view('header', $data);
				$this->load->view('student_coursedetails_view', $data);
				$this->load->view('footer'); 

			}else{
				//If no session, redirect to login page
				redirect('dashboard', 'refresh');
			}

		}
   		else
   		{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
   		}
		
	}
        
public function getCenterFee() {

	if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in') || $this->session->userdata('studlog_in')){
		
		$courseid = isset($_POST['courseid']) ? $_POST['courseid'] : '';
		$center = isset($_POST['center']) ? $_POST['center'] : '';
		$ret =  $this->student_model->GetCenterFee($courseid,$center);
		echo json_encode($ret);

	}else{
		echo json_encode(array(0=>"nosession"));
	}

}
        
         
      
	
	
	
}
?>
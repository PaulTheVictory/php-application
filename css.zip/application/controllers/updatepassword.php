<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Updatepassword extends CI_Controller {

	function __construct() {
            
		parent::__construct();
		$this->load->model('users_model','',TRUE);$this->load->model('course_model','',TRUE);
                $this->load->model('login_model','',TRUE);
                 $this->load->library('table'); $this->load->helper('form');

	}
	
	function index() {
            
            if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')) {

                $session_data = $this->session->userdata('loggedin');
                $session_id = $session_data['id'];
                $session_role = $session_data['role'];
                $data['user'] = $this->login_model->GetUserId();
				
				$data['roleaccess'] = $this->config->item('roleaccess');

				if(empty($data['roleaccess'])){
					redirect($data['roleaccess']['defaultpage'], 'refresh');
				}
				
                $data['menu'] = $this->load->view('headermenu', $data, TRUE);
                
                $this->load->view('header_view', $data);
                $this->load->view('updatepassword_view', $data);
                $this->load->view('footer_view');
                
            } else {
                //If no session, redirect to login page
                redirect('login', 'refresh');
            }
            
        }
        
        
             
        
       public function updatePassword() {
            
        if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')) {
                $this->load->library('form_validation');
                
			$roleaccess = $this->config->item('roleaccess');
			
			$oldpassword = $this->input->post('oldpassword');
			$newpassword = $this->input->post('newpassword');
			$confirmpassword = $this->input->post('confirmpassword');
			
			if(!empty($roleaccess)){
							
				 $this->form_validation->set_rules('oldpassword', 'Old Password', 'trim|required|xss_clean|callback_alpha_numeric_spaces|max_length[20]');
                $this->form_validation->set_rules('newpassword', 'New Password', 'trim|required|xss_clean|callback_alpha_numeric_spaces|max_length[20]');
                $this->form_validation->set_rules('confirmpassword', 'Confirm Password', 'trim|required|xss_clean|callback_alpha_numeric_spaces|max_length[20]');
               
                
                if($newpassword != $confirmpassword) { 
                    $response = array(
						'status' => 'error',
						'message' => 'Password Mismatch'
					);
					echo json_encode($response);exit;
                }                

                if ($this->form_validation->run() == false) {
                        $response = array(
                            'status' => 'error',
                            'message' => validation_errors()
                        );
                        echo json_encode($response);

                } else {


                    
                     $response = $this->insertQ($oldpassword,$newpassword);
                     echo  json_encode($response);
                }
				
			}else {

				  $response = array(
						'status' => 'error',
						'message' => 'User Permission denied'
					);
					echo json_encode($response);
                }
              
               
            }else{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
            }
            
    }
    
        
    public function insertQ($oldpassword,$newpassword){
        
		$roleaccess = $this->config->item('roleaccess');
		$data['user'] = $this->login_model->GetUserId();
		
		if(!empty($roleaccess)){
			
			/*$oldpassword = $this->input->post('oldpassword');
			$password = $this->input->post('newpassword');*/
			$encrpassword = SHA1($this->config->item('pass_salt').$newpassword);
			
        $ide = uniqid();
            $qData = array(
                'id' => $data['user']['id'],
                'password' => $encrpassword,
            );
                       

            $id = $this->users_model->UpdatePassword($qData,$oldpassword);
             
			if($id){
				$response = array(
                'status' => 'success',
                'message' => "Update Password Successfully."
            	);
			}else{
				$response = array(
                'status' => 'error',
                'message' => "Old Password mismatch."
            	);
			}
            
			
		}else {

		  $response = array(
				'status' => 'error',
				'message' => 'User Permission denied'
			);
			echo json_encode($response);
		}
		

          return $response;
    }
    
        
        

}
?>
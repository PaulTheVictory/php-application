<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Staffs extends CI_Controller {

	function __construct() {
            
		parent::__construct();
		$this->load->model('users_model','',TRUE);
                $this->load->model('login_model','',TRUE);
                 $this->load->library('table'); $this->load->helper('form');

	}
	
	function index() {
            
            if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')) {

                $session_data = $this->session->userdata('loggedin');
                $session_id = $session_data['id'];
                $session_role = $session_data['role'];
                $data['user'] = $this->login_model->GetUserId();


				$data['roleaccess'] = $this->config->item('roleaccess');

				if($data['roleaccess']['uview']!="y"){
					redirect($data['roleaccess']['defaultpage'], 'refresh');
				}
				

                $data['menu'] = $this->load->view('headermenu', $data, TRUE);
                
                $tmpl = array('table_open' => '<table class="sortable sorting disabled" id="usertable" style="margin-top:0px;">');
                $this->table->set_template($tmpl);
                $this->table->set_heading('S.NO','STAFF NAME','EMAIL ID','PHONE NUMBER','STATUS','ACTIONS');
                
              
                $this->load->view('header_view', $data);
                $this->load->view('staffs_view', $data);
                $this->load->view('footer_view');
                
            } else {
                //If no session, redirect to login page
                redirect('login', 'refresh');
            }
            
        }
        
        
       
          public function GetAdminStaffs() {
            
            if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in') ){
                
                $ret =  $this->users_model->GetAdminStaffs();
                echo $ret;
                
            }else{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
            }
            
        }
        
          public function ChangeStatus(){
            
            if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')){

				$roleaccess = $this->config->item('roleaccess');
			
				if(isset($roleaccess['Staffs'][1]) && $roleaccess['Staffs'][1]=="y"){
				
					$ide = isset($_GET['ide']) ? $_GET['ide'] : '';
					$status = isset($_GET['status']) ? $_GET['status'] : '';

					if($ide != ""){
						 $ret = $this->users_model->ChangeUserStatus($ide,$status);
					} else {
						$ret = array(0 => "fail");
					}

					echo json_encode($ret);

				} else {
                    $ret = array(0 => "fail");
					echo json_encode($ret);
                }
				
            
            }else {
                //If no session, redirect to login page
                redirect('login', 'refresh');
            }
            
        }
        
        
    
        
        public function Delstaff() {
            
            if ($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')) {

				$roleaccess = $this->config->item('roleaccess');
			
				if(isset($roleaccess['Staffs'][2]) && $roleaccess['Staffs'][2]=="y"){
					
					$ide = isset($_GET['ide']) ? $_GET['ide'] : '';

					if($ide != ""){
						 $ret = $this->users_model->DeleteStaff($ide);
					} else {
						$ret = array(0 => "fail");
					}

					echo json_encode($ret);
					
				} else {
						$ret = array(0 => "fail");
						echo json_encode($ret);
					}
            
            }else {
                //If no session, redirect to login page
                redirect('login', 'refresh');
            }
                
        }
        

}
?>
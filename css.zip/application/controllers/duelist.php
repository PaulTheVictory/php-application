<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Duelist extends CI_Controller {

	function __construct() {
            
		parent::__construct();
                $this->load->model('login_model','',TRUE);
		$this->load->model('reports_model','',TRUE);
               $this->load->model('course_model','',TRUE);
                $this->load->helper('download');

	}
	
	function index() {
            
           if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')) {

                $data['roleaccess'] = $this->config->item('roleaccess');

				if($data['roleaccess']['uview']!="y"){
					redirect($data['roleaccess']['defaultpage'], 'refresh');
				}
			   
                $data['user'] = $this->login_model->GetUserId();
                $data['menu'] = $this->load->view('headermenu', $data, TRUE);
                
                $cname = isset($_GET['cname']) ? $_GET['cname'] : '';
                $center = isset($_GET['center']) ? $_GET['center'] : 'All';
                $data['reports'] = "";$data['savename'] = "";$data['cname'] = "";$data['lcenters'] = "";
                if($cname !== "") {
                    $data['reports'] = $this->reports_model->DueList($cname,$center,$data['user']['batches']);
                    $data['savename'] = "Due_List_Report_".date('d-m-Y-H_i_s');
                    $data['cname'] = $this->course_model->GetCourseName($cname);
                    $data['lcenters'] = $this->course_model->GetCourseCenterList($cname);
                    $data['cid'] = $cname;
                } 
                
                 $this->load->view('header_view', $data);
                 $this->load->view('duelist_view', $data);
                 $this->load->view('footer_view');
                 
                
            } else {
                //If no session, redirect to login page
                redirect('login', 'refresh');
            }
            
        }
        
        function export() {
            
           if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')) {
               
			   $roleaccess = $this->config->item('roleaccess');
			   
			   if(isset($roleaccess['Due List Export'][3]) && $roleaccess['Due List Export'][3]=="y"){
              
				   $data['user'] = $this->login_model->GetUserId();
				   
                $data['menu'] = $this->load->view('headermenu', $data, TRUE);
                
                $cname = isset($_GET['cname']) ? $_GET['cname'] : '';
                $center = isset($_GET['center']) ? $_GET['center'] : 'All';
                 
                    $reports = $this->reports_model->DueList($cname,$center,$data['user']['batches']);
                    $savename = "Due_List_Report_".date('d-m-Y-H_i_s');
                 
                     $html = '<thead><tr><th>S.no</th><th >Student ID</th><th >Student Name</th><th>Country Code</th><th>Registered Mobile No</th><th>Country Code</th><th>Father Mobile No</th><th>Country Code</th><th>Mother Mobile No</th><th>Comments</th><th>Stream</th><th>Type</th><th>Course Name</th><th>Centre</th><th>Batch</th><th>Total Fee (With GST)</th><th>Total Fee (without GST)</th><th>Active Fee (without GST)</th><th>Active Discount</th><th>Given By</th><th>Reason</th><th>Remarks</th><th>To be paid (wihtout GST)</th><th>Paid (wihtout GST)</th><th>Net Due</th><th>GST+KF</th><th>KF Adjust</th><th>Total due</th><th>Course Change From</th><th>Course due date</th><th>Final due date</th></tr></thead>';
                    $i = 1;
                    foreach ($reports as $key=>$val){
                       
                        $html .= '<tr><td>'.$i.'</td><td>'.$val['studid'].'</td><td>'.$val['sname'].'</td><td>'.$val['mcode'].'</td><td>'.$val['mobile'].'</td><td>'.$val['fcountrycode'].'</td><td>'.$val['fatherphone'].'</td><td>'.$val['mcountrycode'].'</td><td>'.$val['motherphone'].'</td><td>'.$val['comments'].'</td><td>'.$val['stream'].'</td><td>'.$val['type'].'</td><td>'.$val['coursename'].'</td><td>'.$val['center'].'</td><td></td><td>'.$val['total'].'</td><td>'.$val['totalw'].'</td><td>'.$val['atotal'].'</td><td>'.$val['discount'].'</td><td>'.$val['givenby'].'</td><td>'.$val['reason'].'</td><td>'.$val['remarks'].'</td><td>'.$val['tobepaid'].'</td><td>'.$val['paid'].'</td><td>'.$val['netdue'].'</td><td>'.$val['gst'].'</td><td>'.$val['kfadjust'].'</td><td>'.$val['totaldue'].'</td><td>'.$val['coursenamefrom'].'</td><td></td><td></td></tr>';
                        $i++;
                        
                    }
                    
                 
                  $html = "<tr>Due List Reports </tr>".$html;       
                    $html = str_replace('<tr>',"\n",$html);
                     $html = str_replace('</tr>',"",$html);

                     $html = str_replace('</th>',"\t",$html);
                     $html = str_replace('<th>',"",$html);

                     $html = str_replace('</td>',"\t",$html);
                     $html = str_replace('<td>',"",$html);


                     $html = strip_tags($html);

                     $filename = $savename .".xls";

                     force_download($filename, $html);
			   }else{
				   redirect($roleaccess['defaultpage'], 'refresh');
			   }
            
               
           }else {
                //If no session, redirect to login page
                redirect('login', 'refresh');
            }
        }
        
     
}
?>
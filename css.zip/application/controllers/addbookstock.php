<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Addbookstock extends CI_Controller {

	function __construct() {
            
		parent::__construct();
		
                $this->load->model('login_model','',TRUE);
                $this->load->model('library_model','',TRUE);
		$this->load->library('table');
				$this->load->helper('form');

	}
	
	function index() {
            
            if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')) {

                $session_data = $this->session->userdata('loggedin');
                $session_id = $session_data['id'];
                $session_role = $session_data['role'];
                $data['user'] = $this->login_model->GetUserId();

				$data['roleaccess'] = $this->config->item('roleaccess');
			
				if($data['roleaccess']['Add Stock'][3]!="y"){
					redirect($data['roleaccess']['defaultpage'], 'refresh');
				}
				
				$bid = $this->input->get('bid');
				$center = $this->input->get('center');
				$btype = $this->input->get('btype');
				
				$data['bid'] = $bid;
				$data['center'] = $center;
				$data['btype'] = $btype;
				
				if($bid =="" || $center ==""  || $btype =="" ){
					redirect('library', 'refresh');
				}
				
				if(!empty($data['user']['lcenters']) && !in_array("All", $data['user']['lcenters']) && !in_array($center,$data['user']['lcenters'])){
					redirect('bookdetails?bid='.$bid, 'refresh');
				}
				
				$data['bookdetails'] = $this->library_model->BookDetails($bid);
				
				$data['menu'] = $this->load->view('headermenu', $data, TRUE);
				
				$tmpl = array('table_open' => '<table class="sortable sorting disabled table" id="usertable" style="margin-top:0px;">');
				$this->table->set_template($tmpl);
				$this->table->set_heading('S.NO', 'BARCODE','PRICE (AUTO FROM MASTER)','BOOK TYPE','ACTIONS');
				
				
                $this->load->view('header', $data);
                $this->load->view('addbookstock_view', $data);
                $this->load->view('footer');
				
            } else {
                //If no session, redirect to login page
                redirect('login', 'refresh');
            }
            
        }
        
    
	public function GetBookStockCenter() {
            
		if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in') ){

			$bid = $this->input->post('bid');
			$center = $this->input->post('center');
			
			$ret =  $this->library_model->GetBookStockCenter($bid,$center);
			echo $ret;

		}else{
		//If no session, redirect to login page
		redirect('login', 'refresh');
		}

	}
	
	 public function bookstockSubmit() {
            
        if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')) {
                $this->load->library('form_validation');
			
			$roleaccess = $this->config->item('roleaccess');
			
			if(isset($roleaccess['Add Stock'][0]) && $roleaccess['Add Stock'][0]=="y"){
				
               
				$bsid = isset($_POST['bsid']) ? $_POST['bsid'] : '';
				
				if($bsid === "") {
					$response = $this->insertQ();
				}else {
					 $response = $this->updateQ($bsid);
				 }
				
				 echo json_encode($response);	
				
			 } else {

 					$response = array(
                            'status' => 'error',
                            'message' => 'User Permission Denied'
                        );
                        echo json_encode($response);
                }
              
               
            }else{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
            }
            
    }
    
        
    public function insertQ(){
        
		$roleaccess = $this->config->item('roleaccess');
			
			if(isset($roleaccess['Add Stock'][0]) && $roleaccess['Add Stock'][0]=="y"){
				
        	$ide = uniqid();
				
            $qData = array(
                'id' => $ide,
                'bookid' => $this->input->post('bid', true),
                'center' => $this->input->post('center', true),
                'barcode' => $this->input->post('barcode', true),
                'price' => $this->input->post('price', true),
                'booktype' => $this->input->post('btype', true),
                'created_at' => date('Y-m-d H:i:s')
            );
                       

            $result = $this->library_model->InsertBookStock($qData);
              
			if($result=="success"){
				$response = array(
                'status' => 'success',
                'message' => "Book stock added Successfully."
            	);
			}else{
				$response = array(
                'status' => 'exists',
                'message' => "Book stock already exists."
            	);
			}
            
				
		 } else {

 					$response = array(
                            'status' => 'error',
                            'message' => 'User Permission Denied'
                        );
                        echo json_encode($response);
                }

          return $response;
    }
    	
	public function updateQ($bsid){
        
		$roleaccess = $this->config->item('roleaccess');
			
			if(isset($roleaccess['Add Stock'][1]) && $roleaccess['Add Stock'][1]=="y"){
								
            $qData = array(
                'id' => $bsid,
                'bookid' => $this->input->post('bid', true),
                'center' => $this->input->post('center', true),
                'barcode' => $this->input->post('barcode', true),
                'booktype' => $this->input->post('btype', true),				
                'price' => $this->input->post('price', true),
            );
                       

            $result = $this->library_model->UpdateBookStock($qData);
              
				$response = array(
                'status' => 'success',
                'message' => "Book stock updated Successfully."
            	);
            
				
		 } else {

			$response = array(
					'status' => 'error',
					'message' => 'User Permission Denied'
				);
			echo json_encode($response);
		}

          return $response;
    }
	
	 public function DelBookStock() {
            
            if ($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')) {
				
				$roleaccess = $this->config->item('roleaccess');
			
				if(isset($roleaccess['Add Stock'][2]) && $roleaccess['Add Stock'][2]=="y"){
			
					$ide = isset($_POST['ide']) ? $_POST['ide'] : '';
					$bid = isset($_POST['bid']) ? $_POST['bid'] : '';

					if($ide != ""){
						 $ret = $this->library_model->DelBookStock($ide,$bid);
					} else {
						$ret = array(0 => "fail");
					}

					echo json_encode($ret);
					
				} else {
                    $ret = array(0 => "fail");
					echo json_encode($ret);
                }
            
            }else {
                //If no session, redirect to login page
                redirect('login', 'refresh');
            }
                
        }

}
?>
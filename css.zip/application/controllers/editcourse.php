<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Editcourse extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model('course_model','',TRUE);
                $this->load->model('login_model','',TRUE);
                $this->load->model('qualification_model','',TRUE);$this->load->helper('form');

	}
	
	function index()
	{
		if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in'))
   		{
                    $ide = isset($_GET['id']) ? $_GET['id'] : '';
     		    $session_data = $this->session->userdata('loggedin');
		    $session_id = $session_data['id'];
     		    $session_role = $session_data['role'];
		    $data['user'] = $this->login_model->GetUserId();
			
					$data['roleaccess'] = $this->config->item('roleaccess');
			
					if($data['roleaccess']['Courses'][1]!="y"){
						redirect($data['roleaccess']['defaultpage'], 'refresh');
					}
			
                    $data['edit'] = $this->course_model->EditCourse($ide,"");
                    if($data['edit']['stest'] === "1") {
                       $data['units'] = $this->course_model->GetAllCities($data['edit']['centers']); 
                    } else {
                    $data['units'] = $this->course_model->GetAllCenters($data['edit']['centers'],'option');
                    }
                    $data['qualification'] = $this->qualification_model->GetAllQualifications($data['edit']['qualification']);
			
					$data['ahselectoptions'] = $this->course_model->GetAllAccounthead($data['edit']['accountinghead']);
				
                    $data['menu'] = $this->load->view('headermenu', $data, TRUE);
                    $this->load->view('header_view', $data);
                    $this->load->view('editcourse_view', $data);
                    $this->load->view('footer_view');
			
                }
   		else
   		{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
   		}
		
	}
        
         
    public function courseSubmit() {
        
        if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')) {
        $this->load->library('form_validation');
			
		$roleaccess = $this->config->item('roleaccess');
		if(isset($roleaccess['Courses'][1]) && $roleaccess['Courses'][1]=="y"){
					
        $this->form_validation->set_rules('cname', 'Course Name', 'trim|required|xss_clean|callback_alpha_numeric_spaces|max_length[100]');
        $this->form_validation->set_rules('cid', 'Course ID', 'trim|required|xss_clean|callback_alpha_numeric_spaces|max_length[100]');
        $this->form_validation->set_rules('courseid', 'Course ID', 'trim|required|xss_clean|numeric|max_length[10]');
        $this->form_validation->set_rules('duration', 'Duration Value', 'trim|required|xss_clean|numeric|max_length[3]');
        $this->form_validation->set_rules('durationfreq', 'Duration', 'trim|required|xss_clean|regex_match[/Month|Year/]|max_length[5]');
        $this->form_validation->set_rules('commence', 'Commences on', 'trim|required|xss_clean|callback_alpha_numeric_spaces|max_length[50]');
        $this->form_validation->set_rules('startson', 'Starts On', 'trim|required|xss_clean|callback_alpha_numeric_spaces|max_length[50]');
        $this->form_validation->set_rules('endson', 'Ends on', 'trim|xss_clean|required|callback_alpha_numeric_spaces|max_length[50]');
        $this->form_validation->set_rules('qualification', 'Qualification', 'trim|xss_clean|required|apha_numeric|max_length[100]');
        $this->form_validation->set_rules('regular', 'Class Schedule', 'trim|xss_clean|regex_match[/1|0/]|max_length[10]');
        $this->form_validation->set_rules('weekend', 'Class Schedule', 'trim|xss_clean|regex_match[/1|0/]|max_length[10]');
        $this->form_validation->set_rules('both', 'Class Schedule', 'trim|xss_clean|regex_match[/1|0/]|max_length[10]');
        $this->form_validation->set_rules('selcenters', 'Centers', 'trim|xss_clean|required|callback_alpha_numeric_spaces|max_length[10000]');
        $this->form_validation->set_rules('cdescription', 'Course Description', 'trim|xss_clean|callback_alpha_numeric_spaces|max_length[5000]');
        $this->form_validation->set_rules('ctype', 'Course Type', 'trim|xss_clean|regex_match[/online|offline|both|0/]|max_length[10]');
        $this->form_validation->set_rules('crefund', 'Refund Policy', 'trim|xss_clean|max_length[5000]'); 
			
		$this->form_validation->set_rules('stream', 'Stream','trim|required|xss_clean|apha_numeric|max_length[200]');
		$this->form_validation->set_rules('coursetype', 'Type','trim|required|xss_clean|apha_numeric|max_length[200]');
		$this->form_validation->set_rules('accounthead', 'Accounting Head','trim|required|xss_clean|max_length[200]');	
		$this->form_validation->set_rules('idcard_displayname', 'ID Card Display Name','trim|required|xss_clean|max_length[20]');

        if ($this->form_validation->run() == false) {
            $response = array(
                'status' => 'error',
                'message' => validation_errors()
            );
        }
        else {
            
            $qname = $this->qualification_model->GetSelectedQualification($this->input->post('qualification', true));
            $duration = $this->input->post('duration', true)." ".$this->input->post('durationfreq', true);
            $cschedule = $this->input->post('regular', true)."|".$this->input->post('weekend', true)."|".$this->input->post('both', true)."|".$this->input->post('hybrid', true)."|".$this->input->post('special', true)."|".$this->input->post('other', true);
           
            $etime = "";
            $examtime  = isset($_POST['examtime'])?$_POST['examtime']:'';
            if($examtime !== "") {
                $examtime = $this->input->post('examtime', true);
                $examtimefreq = $this->input->post('examtimefreq', true);
                $etime = $examtime." ".$examtimefreq;
            }
            
            $qData = array(
                'ide' => $this->input->post('cid', true),
                'courseid' => $this->input->post('courseid', true),
                'coursename' => $this->input->post('cname', true),
                'duration' => $duration,
                'commenceson' => $this->input->post('commence', true),
                'starts_on' => $this->input->post('startson', true),
                'ends_on' => $this->input->post('endson', true),
                'qualification' => $this->input->post('qualification', true),
                'qname' => $qname,
                'cschedule' => $cschedule,
                'centers' => $this->input->post('selcenters', true),
                'description' => $this->input->post('cdescription', true),
                'status' => 'a',
                'ctype' => $this->input->post('ctype', true),
                'screentest' => $this->input->post('stest', true),
                'refund' => $this->input->post('crefund', true),
                'examtime' => $etime,
                'cooloftime' => $this->input->post('cooloftime', true),
                'reportingtime' => $this->input->post('rtime', true),
                'modeofexam' => $this->input->post('modeofexam', true),
                'created_at' => date('Y-m-d H:i:s'),
                'stream' => $this->input->post('stream', true),
                'type' => $this->input->post('coursetype', true),
                'accountinghead' => $this->input->post('accounthead', true),
                'idcard_displayname' => $this->input->post('idcard_displayname', true)
            );
            
            

            $id = $this->course_model->UpdateCourse($qData);
          

            $response = array(
                'status' => 'success',
                'message' => "Course Created Successfully.",
                'ide' => $ide
            );
        }

                echo  json_encode($response); 
			
		}else {

		  $response = array(
				'status' => 'error',
				'message' => 'User Permission denied'
			);
			echo  json_encode($response);
		}
			
		}
                else
   		{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
   		}
        
    }
	
	
	
	
}
?>
<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Classstudymaster extends CI_Controller {

	function __construct() {
            
		parent::__construct();
		$this->load->model('qualification_model','',TRUE);
                $this->load->model('login_model','',TRUE);
                 $this->load->library('table'); $this->load->helper('form');

	}
	
	function index() {
            
            if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')) {

                $session_data = $this->session->userdata('loggedin');
                $session_id = $session_data['id'];
                $session_role = $session_data['role'];
                $data['user'] = $this->login_model->GetUserId();

				$data['roleaccess'] = $this->config->item('roleaccess');

				if($data['roleaccess']['uview']!="y"){
					redirect($data['roleaccess']['defaultpage'], 'refresh');
				}
				
                $data['menu'] = $this->load->view('headermenu', $data, TRUE);
                
                $tmpl = array('table_open' => '<table class="sortable sorting disabled" id="classtable" style="margin-top:0px;">');
                $this->table->set_template($tmpl);
                $this->table->set_heading('S.NO', 'CALSS STUDY NAME','ACTIONS');
                
              

                $this->load->view('header_view', $data);
                $this->load->view('classstudymaster_view', $data);
                $this->load->view('footer_view');
                
            } else {
                //If no session, redirect to login page
                redirect('login', 'refresh');
            }
            
        }
        
        
        
          public function GetClassstudyMaster() {
            
            if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in') ){
                
                $ret =  $this->qualification_model->GetClassstudyMaster();
                echo $ret;
                
            }else{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
            }
            
        }
        
        
       public function ClassstudyMasterSubmit() {
            
        if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')) {
			
                $this->load->library('form_validation');

				$ide = isset($_POST['eide']) ? $_POST['eide'] : '';	
			
                 if($ide === "") {
                	$validatation["csname"] = "trim|required|xss_clean|callback_alpha_numeric_spaces|max_length[100]|is_unique[bscp_classstudy_master.csname]";
                 } else {
                     $validatation["csname"] = "trim|required|xss_clean|callback_alpha_numeric_spaces|max_length[100]";
                 }
			

				foreach ($validatation as $key=>$val) {
					$this->form_validation->set_rules($key, "Class Study", $val);
				}


                if ($this->form_validation->run() == false) {
                        $response = array(
                            'status' => 'error',
                            'message' => validation_errors()
                        );
                        echo json_encode($response);

                } else {


						if($ide === "") {
                     		$response = $this->insertQ();
                         } else {
                             $response = $this->updateQ();
                         }
					
                     
                     echo  json_encode($response);
                }
			
			
               
            }else{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
            }
            
    }
    
        
    public function insertQ(){
        
			
			$roleaccess = $this->config->item('roleaccess');
			
			if(isset($roleaccess['Class Study Master'][0]) && $roleaccess['Class Study Master'][0]=="y"){
				
        $ide = uniqid();
            $qData = array(
                'id' => $ide,
                'csname' => $this->input->post('csname', true),          
                'created_at' => date('Y-m-d H:i:s')
            );
                       

            $id = $this->qualification_model->InsertClassstudyMaster($qData);
                       
            $response = array(
                'status' => 'success',
                'message' => " Class Study Created Successfully."
            );
				
			
            }else {

			  $response = array(
					'status' => 'error',
					'message' => 'User Permission Denied'
				);
				echo json_encode($response);
			}
		

          return $response;
    }
	
	 public function updateQ(){
        
		
		$roleaccess = $this->config->item('roleaccess');
			
			if(isset($roleaccess['Class Study Master'][1]) && $roleaccess['Class Study Master'][1]=="y"){
				
            $qData = array(
                'id' => $this->input->post('eide', true),
                'csname' => $this->input->post('csname', true),
                'created_at' => date('Y-m-d H:i:s')
            );
                       

            $this->qualification_model->UpdateClassstudyMaster($qData);
                       
            $response = array(
                'status' => 'success',
                'message' => "Class Study Updated Successfully."
            );
				
		}else {

		  $response = array(
				'status' => 'error',
				'message' => 'User Permission denied'
			);
			echo json_encode($response);
		}

          return $response;
    }
        
        public function DelClassstudyMaster() {
            
            if ($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')) {

				$roleaccess = $this->config->item('roleaccess');
			
				if(isset($roleaccess['Class Study Master'][2]) && $roleaccess['Class Study Master'][2]=="y"){
				
					$ide = isset($_GET['ide']) ? $_GET['ide'] : '';

					if($ide != ""){
						 $ret = $this->qualification_model->DelClassstudyMaster($ide);
					} else {
						$ret = array(0 => "fail");
					}

					echo json_encode($ret);
					
				} else {
                    $ret = array(0 => "fail");
					 echo json_encode($ret);
                }
					
            
            }else {
                //If no session, redirect to login page
                redirect('login', 'refresh');
            }
                
        }

}
?>
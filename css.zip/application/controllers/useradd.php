<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Useradd extends CI_Controller {

	function __construct() {
            
		parent::__construct();
		$this->load->model('users_model','',TRUE);$this->load->model('course_model','',TRUE);
                $this->load->model('login_model','',TRUE);$this->load->model('library_model','',TRUE);
                 $this->load->library('table'); $this->load->helper('form');

	}
	
	function index() {
            
            if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')) {

                $session_data = $this->session->userdata('loggedin');
                $session_id = $session_data['id'];
                $session_role = $session_data['role'];
                $data['user'] = $this->login_model->GetUserId();
				
				$data['roleaccess'] = $this->config->item('roleaccess');

				if($data['roleaccess']['Users'][0]!="y"){
					redirect($data['roleaccess']['defaultpage'], 'refresh');
				}
				
                $data['groups'] = $this->users_model->GetAllGroups("","option");
                $data['centers'] = $this->users_model->GetAllCenters("",'option');
                $data['courses'] = $this->users_model->GetAllBatches('');
                $data['lcenters'] = $this->library_model->GetAllCenters("",'option');


                $data['menu'] = $this->load->view('headermenu', $data, TRUE);
                
                $this->load->view('header_view', $data);
                $this->load->view('usersadd_view', $data);
                $this->load->view('footer_view');
                
            } else {
                //If no session, redirect to login page
                redirect('login', 'refresh');
            }
            
        }
        
        
             
        
       public function userSubmit() {
            
        if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')) {
                $this->load->library('form_validation');
                
			$roleaccess = $this->config->item('roleaccess');
			
			if(isset($roleaccess['Users'][0]) && $roleaccess['Users'][0]=="y"){
			
                $this->form_validation->set_rules('pname', 'Name', 'trim|required|xss_clean|callback_alpha_numeric_spaces|max_length[100]');
                $this->form_validation->set_rules('uname', 'User Name', 'trim|required|xss_clean|callback_alpha_numeric_spaces|max_length[100]|is_unique[typo_users.username]');
                $this->form_validation->set_rules('uemail', 'Email Address', 'trim|required|xss_clean|callback_alpha_numeric_spaces|max_length[100]|is_unique[typo_users.email]');
                $this->form_validation->set_rules('umobile', 'Phone Number', 'trim|required|xss_clean|numeric|max_length[10]');
                $this->form_validation->set_rules('ugroups', 'User Group', 'trim|required|xss_clean|callback_alpha_numeric_spaces|max_length[100]');
                 $this->form_validation->set_rules('msession', 'Multi Session', 'trim|xss_clean|regex_match[/y|n/]|max_length[1]');
                 $gname = $this->input->post('ugroups', true);
                $type = $this->users_model->GetGroupType($gname);
                
                if($type === "A") { 
                    $_POST['ucenters']=""; $_POST['lcenters']=""; 
                    $this->form_validation->set_rules('ucourses', 'Batches', 'trim|required|xss_clean|callback_alpha_numeric_spaces|max_length[1000]');
                }
                if($type === "F") { 
                    $_POST['ucourses']="";$_POST['lcenters']=""; 
                       $this->form_validation->set_rules('ucenters', 'Centers', 'trim|required|xss_clean|callback_alpha_numeric_spaces|max_length[500]');
                }
                
                if($type === "B") { 
                    $this->form_validation->set_rules('ucourses', 'Batches', 'trim|required|xss_clean|callback_alpha_numeric_spaces|max_length[1000]');
                    $this->form_validation->set_rules('ucenters', 'Centers', 'trim|required|xss_clean|callback_alpha_numeric_spaces|max_length[500]');
                    $this->form_validation->set_rules('lcenters', 'Library Centers', 'trim|required|xss_clean|callback_alpha_numeric_spaces|max_length[500]');
                }
                
                if($type === "L") { 
                    $_POST['ucourses']="";$_POST['ucenters']="";
                    $this->form_validation->set_rules('lcenters', 'Centers', 'trim|required|xss_clean|callback_alpha_numeric_spaces|max_length[500]');
                }

                if ($this->form_validation->run() == false) {
                        $response = array(
                            'status' => 'error',
                            'message' => validation_errors()
                        );
                        echo json_encode($response);

                } else {


                    
                     $response = $this->insertQ();
                     echo  json_encode($response);
                }
				
			}else {

				  $response = array(
						'status' => 'error',
						'message' => 'User Permission denied'
					);
					echo json_encode($response);
                }
              
               
            }else{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
            }
            
    }
    
        
    public function insertQ(){
        
		$roleaccess = $this->config->item('roleaccess');
			
		if(isset($roleaccess['Users'][0]) && $roleaccess['Users'][0]=="y"){
                    
        $ide = uniqid();
            $qData = array(
                'id' => $ide,
                'username' => $this->input->post('uname', true)."@brilliantpala.org",
                'password' => '',
                'mcode' => '91',
                'mobile' => $this->input->post('umobile', true),
                'role' => $this->input->post('ugroups', true),
                'email' => $this->input->post('uemail', true),
                'name' => $this->input->post('pname', true),
                'address' => '',
                'address1' => '',
                'place' => '',
                'city ' => '',
                'website ' => '',   
                'landline  ' => '',   
                'pincode ' => '',   
                'qualification ' => '',   
                'active ' => 'w',   
                'centers ' => $this->input->post('ucenters', true),   
                'lcenters ' => $this->input->post('lcenters', true),
                'courses ' => $this->input->post('ucourses', true),   
                'msession ' => $this->input->post('msession', true),
                'created_at' => date('Y-m-d H:i:s')
            );
                       

            $id = $this->users_model->AddUser($qData);
                       
            $response = array(
                'status' => 'success',
                'message' => "User Created Successfully."
            );
			
		}else {

		  $response = array(
				'status' => 'error',
				'message' => 'User Permission denied'
			);
			echo json_encode($response);
		}
		

          return $response;
    }
    
        
        

}
?>
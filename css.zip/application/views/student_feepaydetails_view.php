<link rel="stylesheet" href="<?php echo base_url();?>css/vendor/dataTables.bootstrap4.min.css">
<link rel="stylesheet" href="<?php echo base_url();?>css/vendor/datatables.responsive.bootstrap4.min.css">
<script src="<?php echo base_url();?>js/vendor/datatables.min.js"></script>

<script type="text/javascript">
$(document).ready(function(){
	
	var paystatus = "<?php echo $paystatus;?>";	
	
	if(paystatus=="S"){
		$('#paydoneModal').modal({show:true});
	}else if(paystatus=="F"){
		$('#payfailModal').modal({show:true});
	}else{
		$('#paydoneModal,#payfailModal').modal('hide');
	}
	
	
	$("#paydoneModal,#payfailModal").on("hidden.bs.modal", function () {
		var crid = "<?php echo $crid;?>";
  		window.history.pushState({}, document.title, "/" + "stufeepayments?id="+crid);
	});
	
	
	var profilepercent = "<?php echo $stuprofile['profilepercent'];?>";
	
	if(profilepercent<80 && paystatus==""){
		var crid = "<?php echo $crid;?>";
		var confirm = alert("Update your profile details. Redirecting to My Profile page");
		window.open("stumyprofile?action=register&id="+crid,"_self");
	}
	
	
	// Payment method
	
	$("input[name='paymethod']").change(function(){
				
		var paymethod = $(this).val();
		
		if(paymethod=="offline"){
			
			$(this).parent().parent().parent().find(".challanbtn").removeClass('d-none').addClass('d-block');
			$(this).parent().parent().parent().find(".paynowbtn").addClass('d-none').removeClass('d-block');
			
		}else if(paymethod=="online"){
			
			$(this).parent().parent().parent().find(".paynowbtn").removeClass('d-none').addClass('d-block');
			$(this).parent().parent().parent().find(".challanbtn").addClass('d-none').removeClass('d-block');
			
		}else{
			$(this).parent().parent().parent().find(".challanbtn,.paynowbtn").addClass('d-none').removeClass('d-block');
		}
		
	});
	
	$(".feepayments .dropdown-toggle,.feehead .dropdown-toggle").click(function(){
		$(".challanbtn,.paynowbtn").addClass('d-none').removeClass('d-block');
		$("input[name='paymethod']").prop('checked',false);
	});
		
	$(".feepayments .dropdown-menu,.feehead .dropdown-menu").on("click", function(event){
		event.stopPropagation();
    });	
	
	
	$(".checkrefund").click(function(e){
				
		e.preventDefault();
		
		var payurl = $(this).attr('href');
		var btntype = $(this).data('btntype');
		
		$('#refundModal').modal({show:true});
		$("#payurl").val(payurl);
		$("#btntype").val(btntype);
		
	});
	
	$(".iagree").click(function(){
				
		var payurl = $("#payurl").val();
		var btntype = $("#btntype").val();
		
		$('#refundModal').modal('hide');
		
		if(btntype=="paynow"){
			window.open(payurl,"_self");
		}else{
			window.open(payurl,"_blank");
		}
		
	});
	
	
});
</script>

<style>
		
	.feepayments h1{font-size: 18px;font-weight: bold;color: #0332AA;}
	.row .card{background: linear-gradient(0deg, #FFFFFF, #FFFFFF), #C4C4C4;box-shadow: 0px 0px 7px rgba(196, 196, 196, 0.35);border-radius: 10px;}
	h2{color: #364159;font-size: 20px;font-weight: bold;line-height: 36px;}
	.feepayments h2{color: #0332AA;font-size: 24px;font-weight: bold;line-height: 36px;}
	.feepayments p.list-item-heading{color: #6884CC;font-weight: 600;}
	/*.feepayments p.list-item-heading span:last-child{font-weight: 600;font-size: 14px;color: #364159;}*/
	
	.feepayments .crstatus-approve,.feepayments .crstatus-waitlisted,.feepayments .crstatus-pending{font-size: 12px !important;color: #ffffff !important;border-radius: 20px;text-transform: capitalize}
	.crstatus-approve{ background: #3CAF92;}
	.crstatus-waitlisted{background: #ED5252;}
	.crstatus-pending{background: #F48D25;}
	
	.feepayments .card:after{content: " ";color: #fff;position: absolute;width: 10px;height: 100%;top: 50%;transform: translateY(-50%);left: 0;border-top-left-radius: 10px;border-bottom-left-radius: 10px;}
	.feepayments.approve .card:after{background: #3CAF92;}
	.feepayments.waitlisted .card:after{background: #ED5252;}
	.feepayments.pending .card:after{background: #F48D25;}
	
	
	.border-right{border-right: 1px solid #D7DFF0!important;}
		
	.btn-primary{width: auto}
	.btn-primary.disabled, .btn-primary:disabled{background: #9AADDD;color: #ffffff;}
	
	.card h5{margin-bottom: 1rem;}
	h5{font-weight: bold;}
	.badge-outline-secondary, .badge-outline-theme-2{border: 1px solid #889DC6;color: #889DC6;background: #F6F7FA;}
	.badge{font-size: 12px;margin-right: 5px}
	
	.courseinfo .border-bottom{border-bottom: 1px solid #D7DFF0!important;}
	.courseinfo p.list-item-heading{font-size: 14px;color: #6884CC;font-weight: 600;}
	.courseinfo h4{font-size: 18px;font-weight: bold;line-height: 30px;color: #364159;}
 
	.icon-credit-card-2{background: url("img/icons/credit-card-2.png") no-repeat;width: 15px;height: 15px;display: inline-block;vertical-align: middle}
	.icon-check-circle{background: url("img/icons/check-circle-b.png") no-repeat;width: 15px;height: 15px;display: inline-block;vertical-align: middle}
	.icon-minus-circle{background: url("img/icons/minus-circle.png") no-repeat;width: 15px;height: 15px;display: inline-block;vertical-align: middle;margin-right: 5px}
	.icon-map-pin{background: url("img/icons/map-pin-b.png") no-repeat;width: 15px;height: 15px;display: inline-block;vertical-align: middle;margin-right: 5px}
	.icon-tag{background: url("img/icons/tag.png") no-repeat;width: 15px;height: 15px;display: inline-block;vertical-align: middle;margin-right: 5px}
	
	.icon-eye-b{background: url("img/icons/eye-b.png") no-repeat;width: 14px;height: 14px;display: inline-block;vertical-align: middle;margin-right: 5px}
	.icon-download-b{background: url("img/icons/download-b.png") no-repeat;width: 14px;height: 14px;display: inline-block;vertical-align: middle;margin-right: 5px}
	.icon-download{background: url("img/icons/download.png") no-repeat;width: 15px;height: 16px;display: inline-block;vertical-align: middle;margin-right: 5px}
	.dropdown-toggle::after{background: url("img/icons/downarrow.png") no-repeat;width: 9px;height: 6px;display: inline-block;vertical-align: middle;margin-left: 10px;border: none}
	
	p.totaldis {font-weight: bold;font-size: 24px;color: #F48D25;}
	p.paidfee {font-weight: bold;font-size: 24px;color: #209679;}
	p.duefee {font-weight: bold;font-size: 24px;color: #D63333;}
	p.totalpaid{font-weight: bold;font-size: 24px;color: #0332AA;}
	
	
	.table td.totalfee,p span.totalfee {font-weight: bold;font-size: 16px;color: #D63333;}
	.table td.totalamt,p span.totalamt {font-weight: bold;font-size: 12px;color: #6F83AA;letter-spacing: 0.5px;text-transform: uppercase;text-align: right !important}
	.table tr:last-child td{text-align: left}
	.table tr td:last-child,.table tr th:last-child{text-align: center}
	.table tr:last-child td:last-child{font-weight: bold;text-align: center}
	.table tr:last-child{text-align: center}
	
	.table{border: 1px solid #D7DFF0;border-collapse: collapse;border-style: hidden;border-radius: 10px 10px 0 0;box-shadow: 0 0 0 1px #d7dff0;}
	.table thead th{font-size: 12px;font-weight: bold;color: #6F83AA;letter-spacing: 0.5px;background: #E6EBF7;text-transform: uppercase;padding: 0.8rem;text-align: left}
	.table thead tr th:first-child{border-top-left-radius: 5px}
	.table thead tr th:last-child{border-top-right-radius: 5px}
	.table td, .table th{border-top: 1px solid #D7DFF0;padding: 0.9rem 0.75rem;color: #364159;font-weight: 600;}
	.thtax{display: block;text-align: center;}
	.thtaxvalue{display: flex;}
	.thtaxvalue span:first-child{width: 53%}
	
	h3.title{font-size: 12px;text-transform: uppercase;color: #0332AA;letter-spacing: 0.5px;font-weight: bold;}
	
	.payhistory a{font-size: 14px;font-weight: 600;color: #0332AA;}
	
</style>

 <?php 
				
					//print_r($studentcoursepay);
					//print_r($feepayments);

					$tablepay = $tablepaynow = $ide = "";
					$sno = $psno = 1;
	
					$grandtotal = $grandtotalnow = $totalfee = $paidfee = $duefee = $discountfee = $discount = $totaldiscount = 0;
	
					$coursename = $center = $refund = "";

					$checkdiscount = $kfcheck = false;

					//asort($coursepay);

					foreach($feesmaster as $key=>$feemaster){
																		
					foreach($coursepay as $paylist){
						
						if($feemaster['description'] == $paylist['description']){
							
						$coursename = $paylist['coursename'];
						$center = $paylist['centers'];
						$refund = $paylist['refundpolicy'];
						
						$amount = $paylist['amount'];
						$total = $paylist['total'];
						$taxable = $paylist['taxable'];
						$kf = $paylist['kf'];
						$cov = $paylist['cov'];
						$sac = 999293;
						
						$discountamt = 0;$thdiscount = $tddiscount = $thtax =  $tdtax = $thcov =  $tdcov = "";
						$taxamt = 0;
						$colspan=9;

						$tax = $paylist['tax'];
						$discount = $paylist['discount'];
							
						$activetotalamt = $amount;	
						
						if(intval($discount)>0) {
							
							$discountamt = $discount;
							$thdiscount = '<th scope="col" width="12%">Discount</th>';
							$tddiscount = '<td width="12%">'.$discountamt.'</td>';
							
							$amount = $amount - $discount;
							
							$checkdiscount = true;
							
						}else{
							$tddiscount = '<td>[DISCOUNT]</td>';
						}

						
						if($tax=="0" || $tax=="NA"){
							$tdnontaxable = $amount;
						}else{
							$tdnontaxable = 0;
						}

						if($tax!="0" && $tax!="NA"){ 

							$tdtaxable = $amount;				

							$taxgst = $tax/2;
							if(intval($tax)>0) $taxamt = $amount * ($tax/100);
							$taxamtgst = $taxamt/2;
							$taxamtgst = number_format($taxamtgst,2);

							//$colspan +=4;

						} else {
							$tdtaxable = 0;
							$taxgst = $taxamtgst = "NA";
						}

						$thtax = '<th scope="col" colspan="2" width="15%"><span class="thtax">CGST</span> <span class="thtaxvalue"><span>Rate %</span> <span>Amount</span></span></th>
							  <th scope="col" colspan="2" width="15%"><span class="thtax">SGST</span> <span class="thtaxvalue"><span>Rate %</span> <span>Amount</span></span></th>';

						$tdtax = '<td width="8%">'.$taxgst.'</td>
								  <td width="8%">'.$taxamtgst.'</td>
								  <td width="8%">'.$taxgst.'</td>
								  <td width="8%">'.$taxamtgst.'</td>';

						$tdkf = $thkf = ""; $colwidth = 15;
						if(($kf!="" && $kf!="0") || $kfcheck){
							
							$kfamt = $amount * ($kf/100);
							
							$thkf = '<th scope="col" width="8%">CESS KF(%)</th>
                  					 <th scope="col" width="8%">CESS KF Amount</th>';
							$tdkf = '<td width="12%">'.$kf.'</td>
									 <td width="8%">'.$kfamt.'</td>';
							
							
							$kfcheck = true;
							
							$colspan += 2;
							$colwidth -= 5;
							
						}
						
						
						
						if($cov!="0" && $cov!="NA"){
							$thcov = '<th scope="col" width="15%">CESS COV(%)</th>';
							$covamt = $amount * ($cov/100);
							$tdcov = '<td width="15%">'.$covamt.'%</td>';
							$colspan +=1;
						}
												
						$grandtotal += $total;
						
						$tablepay .= '<tr>
									  <th scope="row" width="7%">'.$sno.'.</th>
									  <td width="20%"><strong>'.$paylist['description'].'</strong></td>
									  <td width="11%">'.$activetotalamt.'</td>
									  <td width="11%">'.$tdnontaxable.'</td>
									  <td width="11%">'.$tdtaxable.'</td>
									  '.$tddiscount.'
									  '.$tdtax.'
									  '.$tdkf.'
									  '.$tdcov.'
									  <td width="10%">'.number_format($total,2).'</td>
									</tr>';
						
						/*$tablepay .= '<tr>
									  <th scope="row" width="10%">'.$sno.'.</th>
									  <td width="18%"><strong>'.$paylist['description'].'</strong></td>
									  <td width="15%">'.number_format($amount,2).'</td>
									  <td width="15%">'.$discountamt.'%</td>
									  <td width="10%">'.$tax.'%</td>
									   <td width="12%">'.$kf.'%</td>
									    <td width="15%">'.$cov.'%</td>
									  <td width="10%">'.number_format($total,2).'</td>
									</tr>';*/
						
												
						$sno++;
					}
						
					}

					}

					
					if($checkdiscount){ 
						$thdiscount = '<th scope="col" width="12%">Discount</th>';
						$tablepay = str_replace("<td>[DISCOUNT]</td>",'<td width="12%">0</td>',$tablepay);
						$colspan +=1;
					}
					else {
						$tablepay = str_replace("<td>[DISCOUNT]</td>",'',$tablepay);
					}

					$partialamt = $partialpaydetails['partialamt'];
					$partialstatus = $partialpaydetails['status'];
					$partialbalance = $partialamt;
		
					foreach($feesmaster as $key=>$feemaster){
						
					foreach($studentcoursepay as $stupaylist){
						
						if($feemaster['description'] == $stupaylist['description'] && $partialstatus=="a"){
							
							$amount = $stupaylist['amount'];
							$total = $stupaylist['grandtotal'];	
							
							if($partialbalance>0 ){
							
								if($partialamt>$total){ 
									$partialamt = $partialamt - $total;
									$partialbalance = $partialamt;
								}
								else{ 
									$total = $partialamt;
									$partialbalance = 0;
								}
														
								$grandtotalnow += $total;
								
								$tablepaynow .= '<tr>
										  <th scope="row">'.$psno.'.</th>
										  <td><strong>'.$stupaylist['description'].'</strong></td>
										  <td>'.number_format($total,2).'</td>
										</tr>';

								$psno++;							
							}
							
						}else if($feemaster['description'] == $stupaylist['description'] && $partialstatus==""){
							
							
							$amount = $stupaylist['amount'];
							$total = $stupaylist['grandtotal'];	
																					
							$grandtotalnow += $total;
								
								$tablepaynow .= '<tr>
										  <th scope="row">'.$psno.'.</th>
										  <td><strong>'.$stupaylist['description'].'</strong></td>
										  <td>'.number_format($total,2).'</td>
										</tr>';

								$psno++;							
							
						}
	
						
					}
						
					}

					foreach($feepayments['coursename'] as $key=>$feepayment){

						$ide = $feepayments['ide'][$key];
						$totalfee = round($feepayments['totalfee'][$key]);
						$paidfee = round($feepayments['paidfee'][$key]);
						$duefee = round($feepayments['duefee'][$key]);
						$discountfee = $feepayments['discountfee'][$key];
						$totaldiscount += round($feepayments['discount'][$key]);

					}
				
		?>
              
              
<main>

	<div class="container-fluid">

		<div class="row">
		  <div class="col-12">

			  <div class="row">
			   
			   	  <div class="col-12">
			   		<h1>Course Details</h1>
				  </div>
			   
			   </div>

			   <div class="mb-3"></div>
			   
			   
			   <div class="row courseinfo">
			   
				   <div class="col-12">
				   	
				   	<div class="card">
				   	
						<div class="card-body">
						
							<div class="row">
								
								<div class="col-md-3">
									<p class="list-item-heading">Course Name:</p>
								</div>
								
								<div class="col-md-9">
									<h4><?php echo $coursename;?></h4>
								</div>
								
							</div>
							
							<div class="row">
								
								<div class="col-md-3">
									<p class="list-item-heading">Center Name:</p>
								</div>
								
								<div class="col-md-9">
									<p><?php echo $center;?></p>
								</div>
								
							</div>
							
			   	
						</div>
			   	
					   </div>
				   	
				   </div>
				   
			  </div>
			  
			  
			   <div class="mb-5"></div>

		</div>

		</div>
		
		 <div class="row feehead">
		   			   
			  <div class="col-md-4">
				<h1>Fee Details</h1>
			  </div>
			  
			  <?php if($tablepaynow!=""){?>
			  
			  <div class="col-md-8 text-right">
				<button class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Make Payment</button>
				<div class="dropdown-menu">
								
					<div class="row px-3">
						<div class="col-12">
						<h3 class="title my-3">Amount to be Remitted now</h3>
						<p class="mb-3"> <span class="totalamt">GRAND TOTAL:</span> <span class="totalfee"><?php echo number_format($grandtotalnow,2); ?></span></p></div>
					</div>
				
					<h3 class="title px-3 pt-2">Select payment method</h3>					
						
						<div class="form-group px-3 py-2">
						  <div>
							  <div class="custom-control custom-radio col-sm-12 py-1">
								<input type="radio" id="paymethod1" name="paymethod" class="custom-control-input" value="online" required="">
								<label class="custom-control-label" for="paymethod1">Online Payment</label>
							  </div>
							  <div class="custom-control custom-radio col-sm-12 py-1">
								<input type="radio" id="paymethod2" name="paymethod" class="custom-control-input" value="offline" required="">
								<label class="custom-control-label" for="paymethod2">Offline Payment</label>
							  </div>
						</div>
						
						<a href="stumyprofile/downloadChallan?id=<?php echo $ide;?>&challan=unpaid" target="_blank" title="Download Challan" class="challanbtn d-none checkrefund" data-btntype="challan"><button class="btn btn-primary mt-4"><i class="icon-download"></i> Download Challan</button></a>
						
						<a href="stufeepayments/onlinepayment?id=<?php echo $ide;?>" title="Pay now" class="paynowbtn d-none checkrefund" data-btntype="paynow"><button class="btn btn-primary mt-4 w-100"><i class="icon-download"></i> Pay Now</button></a>
						
					  </div>
					  					  
				</div>
				
			  </div>
			  
			  <?php }?>

	    </div>
		
		<div class="mb-2"></div>
	
		<div class="row feepayments">
			
			<div class="col-12 mb-4">
				<div class="card">
					<div class="card-body p-0">

						
              <div id="customButtons5">
               
               <div class="row p-4">

					<div class="col-md-6 col-sm-6 col-xs-6 col-lg-3 col-6 text-left border-right px-3">
						<p class="list-item-heading mb-3"><i class="icon-credit-card-2"></i> Total Fees:</p>
						<p class="mb-4 totalpaid"> &#8377; <?php echo number_format($totalfee,2); ?></p>
					</div>

					<div class="col-md-6 col-sm-6 col-xs-6 col-lg-3 col-6 text-left border-right px-4">
						<p class="list-item-heading mb-3"><i class="icon-check-circle"></i>  Remitted Fees:</p>
						<p class="mb-4 paidfee">&#8377; <?php echo number_format($paidfee,2); ?></p>
					</div>

					<div class="col-md-6 col-sm-6 col-xs-6 col-lg-3 col-6 text-left border-right px-4">
						<p class="list-item-heading mb-3"><i class="icon-minus-circle"></i>  Due Fees:</p>
						<p class="mb-4 duefee">&#8377; <?php echo number_format($duefee,2); ?></p>
					</div>

					<div class="col-md-6 col-sm-6 col-xs-6 col-lg-3 col-6 text-left px-4">
						<p class="list-item-heading mb-3"><i class="icon-tag"></i>  Total Discount:</p>
						<p class="mb-4 totaldis">&#8377; <?php echo number_format($totaldiscount,2); ?></p>
					</div>

				</div>
				
				  <div class="border-bottom"></div>
			  
			  <div class="px-4 py-2 feesstructure">
			  
				  <h3 class="title my-4">Fees Structure</h3>
                
                <table class="table">
              <thead>
                <tr>
                  <th scope="col" width="5%">Sl. no.</th>
                  <th scope="col" width="15%">Description</th>
                  <th scope="col" width="8%">Total Fee</th>
                  <th scope="col" width="<?php echo $colwidth;?>%">Non Taxable Value</th>
                  <th scope="col" width="<?php echo $colwidth;?>%">Taxable Value</th>
                  <?php echo $thdiscount;?>
				  <?php echo $thtax;?>
                  <?php echo $thkf;?>
                  <?php echo $thcov;?>
                  <th scope="col" width="15%">Total</th>
                </tr>
              </thead>
              <tbody>
                
                <?php echo $tablepay; ?>
                
                <tr>

                  <td colspan="<?php echo $colspan;?>" class="totalamt">Grand total</td>
                  <td class="totalfee"><?php echo number_format($grandtotal,2); ?></td>
                </tr>
              </tbody>
            </table>
               
			</div>
				  		
				<?php if($tablepaynow!=""){?>  		
				  		
			  <div class="row px-4 py-2">

			  <div class="col-md-6">
                
              <h3 class="title my-4">Amount to be Remitted now</h3>
                
              <table class="table">
              <thead>
                <tr>
                  <th scope="col">Sl. no.</th>
                  <th scope="col">Fee description</th>
                  <th scope="col">total</th>
                </tr>
              </thead>
              <tbody>
                <!--<tr>
                  <th scope="row">1</th>
                  <td><strong>Registration Fee</strong></td>
                  <td>40,000</td>
                </tr>-->
                
                <?php echo $tablepaynow;?>
                
                <tr>
					<td></td>
                  <td class="totalamt">Grand total</td>
                  <td class="totalfee"><?php echo number_format($grandtotalnow,2); ?></td>
                </tr>
              </tbody>
            </table>
             
					</div>
             
					<div class="col-md-6 pt-5">
						
						<button class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Make Payment</button>
						<div class="dropdown-menu">
						
							<div class="row px-3">
								<div class="col-12">
								<h3 class="title my-3">Amount to be Remitted now</h3>
								<p class="mb-3"> <span class="totalamt">GRAND TOTAL:</span> <span class="totalfee"><?php echo number_format($grandtotalnow,2); ?></span></p></div>
							</div>
						
							<h3 class="title px-3 pt-2">Select payment method</h3>
							
								<div class="form-group px-3 py-2">
								  <div>
									  <div class="custom-control custom-radio col-sm-12 py-1">
										<input type="radio" id="paymethod3" name="paymethod" class="custom-control-input" value="online" required="">
										<label class="custom-control-label" for="paymethod3">Online Payment</label>
									  </div>
									  <div class="custom-control custom-radio col-sm-12 py-1">
										<input type="radio" id="paymethod4" name="paymethod" class="custom-control-input" value="offline" required="">
										<label class="custom-control-label" for="paymethod4">Offline Payment</label>
									  </div>
								</div>
								
								<a href="stumyprofile/downloadChallan?id=<?php echo $ide;?>&challan=unpaid" target="_blank" title="Download Challan" class="challanbtn d-none checkrefund" data-btntype="challan"><button class="btn btn-primary mt-4"><i class="icon-download"></i> Download Challan</button></a>
						
								<a href="stufeepayments/onlinepayment?id=<?php echo $ide;?>" title="Pay now" class="paynowbtn d-none checkrefund" data-btntype="paynow"><button class="btn btn-primary mt-4 w-100"><i class="icon-download"></i> Pay Now</button></a>
								
							  </div>
				</div>
					  
						
					</div>
            
				  </div>
           
           			<?php }?>
            
            		 
            		 <?php 
				  
				  		$payhistory = '';
				  
				  		foreach($feepayments['feepaymentid'] as $key1=>$feepaylist){
							
							$payhistory .= ' <tr>
								  <td>'.($key1+1).'.</td>
								  <td>'.date("d M Y",strtotime($feepayments['paymentdate'][$key1])).'</td>
								  <td>'.$feepayments['paymentmode'][$key1].'</td>
								  <td>'.number_format($feepayments['grandtotal'][$key1],2).'</td>
								  <td><a href="stufeebill?crid='.$crid.'&cno='.$feepayments['challanno'][$key1].'" target="_blank"><i class="icon-eye-b"></i>View</a></td>
							 	  </tr>';
							
							 /*<a href="stumyprofile/downloadChallan?id='.$crid.'&cno='.$feepayments['challanno'][$key1].'"target="_blank" ><i class="icon-download-b"></i> Download</a>*/
							
						}
				  
				    ?>
            
             		<?php if($payhistory!=""){?>
            		
            		
            		<div class="px-4 py-2">
            		
             		<h3 class="title my-4">Payment history</h3>
             		
             		
             		 <table class="table payhistory">
						  <thead>
							<tr>
							  <th scope="col" width="10%">Sl. no.</th>
							  <th scope="col" width="20%">Date</th>
							  <th scope="col" width="20%">Mode</th>
							  <th scope="col" width="20%">Amount Remitted</th>
							  <th scope="col" width="30%">Receipt</th>
							</tr>
						  </thead>

						 <tbody>

							  <?php echo $payhistory;?>

						 </tbody>

	  				  </table>
           
				  </div>
            
            
           		 <?php }?>
             
              </div>


					</div>

				</div>
			</div>
		</div>
				

	</div>
	
	<div id="refundModal" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
			
				<div class="modal-header">
			   		<h2 class="modal-title">Refund Policy</h2>
				   <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				</div>
				<div class="modal-body text-left">
											
					<?php echo $refund;?>
									
					<input type="hidden" id="btntype" value="" />
					<input type="hidden" id="payurl" value="" />											
										
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-primary iagree">I Agree</button>
					<button type="button" class="btn btn-outline-primary modalclose" data-dismiss="modal">Close</button>
				</div>
								
			</div>
		</div>
	</div>
	
	<?php if($paystatus!=""){?>
	
	<style>
		
		#paydoneModal.modal .modal-header,#payfailModal.modal .modal-header{padding: 10px 20px !important;border: none}	
		#paydoneModal.modal .modal-body,#payfailModal.modal .modal-body{padding:0 1.75rem 1.75rem}
		.modal-body p{text-align: left !important}
		.modal-backdrop.show {opacity: .5 !important;}
		
	</style>
	
	
	
	<div id="paydoneModal" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
				   <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				</div>
				<div class="modal-body text-center">
									
					<img src="css/img/brilliant-logo.png" alt="Payment Success" class="mb-3" />
					<h2 class="mb-4">Payment Successful!</h2>
									
					<p>Dear <?php echo $user['pname']; ?>,</p>
									
					<p>Your Fee remittance <font color=\"#0332aa\"><strong>Rs. <?php echo number_format($paydetails['totalamt']); ?>/-</strong></font> with Brilliant Study Centre Pala is successful.</p>
									
					<p>You are admitted to <font color=\"#0332aa\"><strong><?php echo $coursename;?></strong></font></p>
									
					<p>We will update you with more details shortly.</p>
										
				</div>
				<div class="modal-footer">
					<a href="stufeebill?crid=<?php echo $paydetails['requestid']; ?>&cno=<?php echo $paydetails['challanno']; ?>" target="_blank"><button type="button" class="btn btn-primary">View Bill</button></a>
					<button type="button" class="btn btn-outline-primary modalclose" data-dismiss="modal">Close</button>
				</div>
								
			</div>
		</div>
	</div>
	
	<div id="payfailModal" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
			
				<div class="modal-header">
				   <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				</div>
				<div class="modal-body text-center">
									
					<img src="css/img/brilliant-logo.png" alt="Payment Failure" class="mb-3" />
					<h2 class="mb-4">Payment Failure</h2>
									
					<p>Dear <?php echo $user['pname']; ?>,</p>
									
					<p>Unfortunately, your payment with Brilliant Study Centre Pala is failed.</p>
									
					<p>You may check with your bank for card transaction limit, if using Debit/Credit card.</p>
									
					<p>You can pay directly at any of our Study Centres or Download challan from your student panel and pay at any bank.</p>
									
					<p>For more details do contact us for all your admission related queries directly at <a href="mailto:admissions@brilliantpala.org"> <font color=\"#0332aa\">admissions@brilliantpala.org</font></a> | <a href="tel:04822206100"><font color=\"#0332aa\">04822 206100</font></a> | <a href="tel:04822206800"><font color=\"#0332aa\">04822 206800</font></a>.</p>
										
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-outline-primary modalclose" data-dismiss="modal">Close</button>
				</div>
								
			</div>
		</div>
	</div>
	
	
	<?php }?>


	</div>
</main>
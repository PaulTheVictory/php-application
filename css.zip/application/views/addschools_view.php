 <link href="<?php  echo base_url(); ?>css/jquery-ui.min.css?v=1.4" rel="stylesheet" type="text/css" />
 <script src="<?php  echo base_url(); ?>js/jquery-ui.min.js?v=1.3" type="text/javascript"></script>

 <style type="text/css">
     
     .ui-selectmenu-button.ui-button{ width: 97%; padding:13px;}
     #duration-button,#modeofexam-button,#examtimefreq-button,#subcriteria-button,#rule-button,#maincriteria-button,#stream-button,#coursetype-button,#accounthead-button{border: 1px solid #D7DFF0;background: #fff;font-size: 14px;color:#536485}
     #centers_chosen  {border: 1px solid #D7DFF0;background: #fff;padding: 8px 0px;}
     #districts_chosen  {border: 1px solid #D7DFF0;background: #fff;padding: 8px 0px;}
     #courses_chosen  {border: 1px solid #D7DFF0;background: #fff;padding: 8px 0px;}
     .chosen-container-multi .chosen-choices {border: 0px;background: none}
     .maincontent ul li.search-choice { height:auto; }
     .maincontent ul li.search-choice a{ height:auto; font-size: 14px;color:#536485}
     .chosen-container-multi .chosen-choices li.search-choice { background: #6884CC;border-radius: 5px;}
     .chosen-container-multi .chosen-choices li.search-choice {color: #fff;}
     .response p { float: right;font-size:12px;color:#eb345e;}
 </style>

	<div class="wrap dynamic-width" style="float: left;position: relative;min-width: 800px">
     <div style="margin-top: 10px; width: 99%; height: 50px; text-align: right;">
         <span style="font-weight: bold;font-size: 20px;padding: 10px;float:left;color: #364159">Add Seat Allotment School</span>
     </div>         
            <div id="course-container" class="add-course">
<?php echo form_open('addschools/schoolSubmit', array('id' => 'addSchoolForm')) ?>
                <div class="row-element">
                    <span class="title">School Name</span>
                    <span class="content"><input type="text"  name = "sname" class="sname" placeholder="School Name"></span>
                </div>
                <div class="row-element" id="hostel">
                    <span class="title">Hostel</span>                    
                    <span class="content">
                        <label style="text-align: left;min-width: 150px;color:#536485;background: none;border: 0px;width: auto;height: auto;float:left;font-size: 14px;font-weight: normal"><input type="radio" value="Yes" name = "hostel"   class="" style="margin: 5px;">Yes</label>
                        <label style="text-align: left;min-width: 150px;color:#536485;background: none;border: 0px;width: auto;height: auto;float:left;font-size: 14px;font-weight: normal"><input type="radio" value="No" name = "hostel"  class="" style="margin: 5px;">No</label>
                          </span>
                </div>
                <div class="row-element">
                    <span class="title" >Co-Ordinator Name</span>
                    <span class="content">
                        <input type="text" id = "coname" name = "coname" class="coname" placeholder="Co-Ordinator Name">                                             
                    </span>
                </div>
               <div class="row-element">
                    <span class="title" >Co-Ordinator Phone</span>
                    <span class="content">
                        <input type="text" id = "cophone" name = "cophone" class="cophone" placeholder="Co-Ordinator Phone">                                             
                    </span>
                </div>
                <div class="row-element">
                    <span class="title" >Location</span>
                    <span class="content">
                        <input type="text" id = "cophone" name = "address" class="address" placeholder="Location">                                             
                    </span>
                </div>
                 <div class="row-element">
                    <span class="title" >District</span>
                    <span class="content">
                        <input type="text" id = "district" name = "district" class="address" placeholder="District">                                             
                    </span>
                </div>
                 
                <div class="row-element">
                    <span class="title">Second Language</span>
                    <span class="content">
                        <select id="duration" name = "secondlang" class="duration" style="font-size: 13px;float:left">
                            <option value="" >Select Language</option>
                            <option>Malayalam</option>
                            <option>Hindi</option>
                            <option>French</option>
                        </select>                        
                    </span>
                </div>
              
       
            <?php echo form_close() ?>
                
            </div>
     <div style="margin-top: 0px; width: 98%; height: 70px; text-align: right;">
         <span  style="margin: 0px auto; float:right;margin-top: 18px;padding: 10px; color: #fff; background: #4f6fc4 none repeat scroll 0% 0%; border-radius:5px;cursor: pointer" class="btn savebtn" href="#">Save</span>
         <a style="margin: 0px auto; float:right;margin-top: 18px;margin-right:18px;padding: 9px 10px; color: #0332AA; background: linear-gradient(0deg, #FFFFFF, #FFFFFF), #C4C4C4;border: 1px solid #0332AA; border-radius:5px" class="btn" href="<?php echo base_url(); ?>schools">Back</a>
         <span class="response" style="margin: 0px auto; float:right;width: 80%; height: 30px;margin-top:20px"></span>
     </div>         
        
        </div>
    
    
    
<script type="text/javascript">
$(document).ready(function() {
    
    $(".duration").selectmenu();
         
          
      $(".savebtn").click(function(){
         
               if($(".response").hasClass('progress')) { return;}
               $(".response").html('').text('Progressing...');
                $(".response").addClass('progress');


                var addSchoolForm = $("#addSchoolForm");

                    $.ajax({
                        url: addSchoolForm.attr('action'),
                        type: 'post',
                        data: addSchoolForm.serialize(),
                        success: function(o){
                            
                            var response = $.parseJSON(o);
                            $(".response").html('');
                            if(response.status === 'success') {
                                
                                $(".response").css("color","rgb(25, 71, 15)");
                               $(".response").text(response.message);
                                $(location).prop('href', 'schools');
                            } else {
                                
                               $(".response").append(response.message); 
                               $(".response").removeClass('progress');
                           
                            }

                        }
                    });
                   
                              
            });
	
	
	$(".add-course").find("input").each(function(){
            
            $(this).keyup(function(event){
                if(event.keyCode == 13){
                    var ty = $(this).next();
                    event.preventDefault();
                    $('input')[$('input').index(this)+1].focus();
                    $('input')[$('input').index(this)+1].select();
                }
            });

            $(this).click(function(){ $(".errnotify").html("&nbsp;");});
            

        });
       

	
});
</script>
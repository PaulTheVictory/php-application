<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/dataTables.css?v=1.5" />
<script src="<?php echo base_url(); ?>js/jquery.dataTables.js?v=1.0" type="text/javascript"></script>
<script src="<?php echo base_url(); ?>js/onscan.min.js?v=1.0" type="text/javascript"></script>

 <style type="text/css">
	 
	 table.dataTable{margin-top: 1rem !important;width: 99% !important;margin: auto}
	 .table tr:last-child td{text-align: left}
	.table tr td:last-child,.table tr th:last-child{text-align: left}
	.table tr:last-child td:last-child{font-weight: 600;text-align: left}
	.table tr:last-child{text-align: center}
	
	.table{border: 1px solid #D7DFF0;border-collapse: collapse;border-style: hidden;border-radius: 10px 10px 0 0;box-shadow: 0 0 0 1px #d7dff0;}
	.table thead th{font-size: 12px;font-weight: bold;color: #6F83AA;letter-spacing: 0.5px;background: #E6EBF7;text-transform: uppercase;padding: 0.8rem;text-align: left}
	.table thead tr th:first-child{border-top-left-radius: 5px}
	.table thead tr th:last-child{border-top-right-radius: 5px}
	.table td, .table th{border-top: 1px solid #D7DFF0;padding: 0.9rem 0.75rem;color: #364159;font-weight: 600;}
	.table td{background: #ffffff;}
	
		
	h3.title{font-size: 12px;text-transform: uppercase;color: #0332AA;letter-spacing: 0.5px;font-weight: bold;}
	 h2{font-size: 12px;text-transform: uppercase;color: #0332AA;letter-spacing: 0.5px;font-weight: bold;}
	 
		
		.dataTables_empty{text-align: center !important}
		.dataTables_wrapper{overflow-x: auto}
	 
	 .card{background: linear-gradient(0deg, #FFFFFF, #FFFFFF), #C4C4C4;box-shadow: 0px 0px 7px rgba(196, 196, 196, 0.35);border-radius: 10px;}
	 
	 .form-group.floating{margin-bottom: 0}
	 
	 p.list-item-heading{color: #6884CC;font-weight: 600;}
	.feetop p.list-item-heading span:last-child{font-weight: 600;font-size: 14px;color: #364159;}
	 
	 .icon-edit{background: url(img/icons/edit3-b.png) no-repeat;width: 15px;height: 16px;display: inline-block;vertical-align: middle}
	 .bookdetails p span:last-child{font-weight: 600;font-size: 14px;line-height: 14px;color: #364159;}
	 .bookdetails p a {font-weight: 600;font-size: 14px;line-height: 20px;color: #0332AA;}

	 
	#issuestatusModal h2{font-size: 14px;text-transform: none;color: #364159;letter-spacing: 0px;font-weight: bold;}
	h5.modal-title p.headtitle{display: inline-block;width: 100%;text-align: center;font-weight: bold;font-size:17px;color: #fff;}
	h5.modal-title p.text-muted{display: inline-block;width: 100%;text-align: center;font-weight: 600;font-size: 14px;line-height: 36px;color: #181E29;line-height: 20px;}
	.modal-title img{display: block;margin: 1em auto}
	#EditbooklimitModal.modal .modal-header,#issuestatusModal.modal .modal-header{padding: 10px 20px !important;border: none}	
	#EditbooklimitModal.modal .modal-body,#issuestatusModal.modal .modal-body{padding:0 1.75rem 1.75rem}
	.modal-body p{text-align: left !important}
	.modal-backdrop.show {opacity: .5 !important;}
	 
	 .profilepic{width: 120px;height: 120px}
	 
	 table.dataTable{margin-top: 2rem !important}
	 .dataTables_filter{right: 0;left: inherit;top: 5px;}
	 .dataTables_filter input{width: 300px}
	 .dataTables_wrapper {top: 25px;padding-top: 3rem}
	 
 </style>
 
 <script type="text/javascript">
	 
	 var oTable,oTablehistory = "";
$(document).ready(function(){	
		
	
	$("select").change(function(){
		$(this).attr('value',$(this).val());
	});
	
	
         /* var columnData1 = [
              { "data": "created" },
                    { "data": "barcode" },
                    { "data": "bookname" },
                    { "data": "price" },
                    { "data": "booktype" },
                    { "data": "duedate" },
                    { "data": "dueperiod" },
                    
                  ];
        // columnData.push( {data: "id","visible":true} );
         //columnData.push( {data: "item_name_search","visible":false} );
         
       
        oTablehistory = $('#issuehistorytable').dataTable({
                    "bProcessing": true,
                    "bServerSide": true,
                    "sPaginationType": "full_numbers",
                    "ajax": {
                    "url": 'issuehistory/GetIssueBookDetails',
                    "type": "POST",
                   
                    "data":{ "stuid": "<?php echo $stuid; ?>"}
                     }, 
                     "oLanguage": {
                        "sProcessing": "<img src='<?php echo base_url(); ?>images/loader.gif'>"
                    },
                    'iDisplayLength': 1000,
                    "columns": columnData1,
                    "order": [[ 0, "desc" ]],
                    "fnDrawCallback": function( oSettings ) {
						
                        var count = 1;
						
                         $('#issuehistorytable').find("tr .sno").each(function(){                           
                            $(this).text(count);
                            count++;
                         });
                                                      
                    }
         }); 
	*/
	
	 oTable = $('#usertable').dataTable({
                    "bProcessing": true,
                    "sPaginationType": "full_numbers",
                     "oLanguage": {
                        "sProcessing": "<img src='<?php echo base_url(); ?>images/loader.gif'>",
						 "sEmptyTable": "No Books Added",
                    },
                    "columns": [
							{ title: "S.NO" },
							{ title: "BARCODE" },
							{ title: "BOOK NAME" },							
							{ title: "PRICE" },							
							{ title: "REFERENCE" },							
							{ title: "DUE DATE" },							
							{ title: "DUE" }	,							
							{ title: "ACTION" }						
						],
                    'iDisplayLength': 1000,
                    //"columns": columnData,
                    "order": [[ 0, "asc" ]],
                    "fnDrawCallback": function( oSettings ) {
						
                        var count = 1;
						
                         $('#usertable').find("tr .sno").each(function(){                           
                            $(this).text(count);
                            count++;
                         });
                                                      
                    }
         }); 
	
	
	oTablehistory = $('#issuehistorytable').dataTable({
                    "bProcessing": true,
                    "sPaginationType": "full_numbers",
                     "oLanguage": {
                        "sProcessing": "<img src='<?php echo base_url(); ?>images/loader.gif'>",
						 "sEmptyTable": "No Book History",
						 "sSearchPlaceholder": "Search Student",
                    },
                    "columns": [
							{ title: "S.NO" },
							{ title: "STUD ID / STAFF MOB NO." },	
							{ title: "STUD / STAFF NAME" },
							{ title: "PRICE" },							
							{ title: "REFERENCE" },	
							{ title: "ISSUE DATE" },
							{ title: "DUE DATE" },
							{ title: "RECEIVED DATE" },
							{ title: "DUE" }						
						],
                    'iDisplayLength': 1000,
                    //"columns": columnData,
                    "order": [[ 0, "asc" ]],
                    "fnDrawCallback": function( oSettings ) {
						
                        var count = 1;
						
                         $('#issuehistorytable').find("tr .sno").each(function(){                           
                            $(this).text(count);
                            count++;
                         });
                                                      
                    }
         }); 
         
      $('.dataTables_filter input').addClass('form-control');     
	
});
</script>

 <main> 
        
        <div class="container-fluid">
                 
    
    		<div class="row mb-3">
				<div class="col-md-10">
					<h1>Book History</h1>
				</div>
				<!--<div class="col-md-2">
					<button class="btn btn-primary staffbtn">Staff</button>
				</div>-->
				<div class="col-md-2">
					<a href="bookhistory" title="Clear"><button class="btn btn-primary">Clear</button></a>
				</div>
			</div> 
			             
             
             <div class="col-12 mb-4 issuebook p-0">			
        
        		<div class="card p-4">
                	                             
                <div class="row align-items-center">
                                      
                   
                    <div class="col-12 col-sm-5">
                    
				  		<div class="form-group position-relative error-l-50 floating">
                      
                    		<input type="text" name="barcode" value="" class="form-control barcode" id="barcode" placeholder=" " />
                       		 
							 <label>Scan Barcode <span>*</span> </label>
						</div>
						
					</div> 
              
               
                   <div class="col-12"> 
						<p class="alert stualert my-3"></p>
					  </div>           
                               
				 </div>
		   
                                      
			</div>
			
				
			
			</div>
             
           <?php if(!empty($bookdetails)){?>  
              
              <div class="issuedetails">
               
            <div class="row px-3 mt-4">     
                     
           <div class="col-12 p-0">
           
           <div class="card">
           
            <div class="course-container add-course mt-3 px-4">
                                                   
                  	<div class="row mb-3 feetop">
						
						<div class="col-md-2 col-sm-3 col-2 text-left px-2">
							<p class="list-item-heading mb-1"> <span>Barcode :</span> <span class="stuname"><?php echo $bookdetails['barcode']; ?></span></p>
						</div>
                   
						<div class="col-md-10 col-sm-10 col-10 text-left px-2">
							<p class="list-item-heading mb-1"> <span>Book Name :</span> <span class="stuname"><?php echo $bookdetails['bookname']; ?></span></p>
						</div>

					</div>
                  
                <div class="row mb-3 feetop">
                   
					<div class="col-md-3 col-sm-3 col-3 text-left px-2">
						<p class="list-item-heading mb-1"> <span>ISBN Number:</span> <span><?php echo $bookdetails['isbn_number']; ?></span></p>
					</div>

					<div class="col-md-3 col-sm-3 col-3 text-left px-2">
						<p class="list-item-heading mb-1"> <span>Author:</span> <span><?php echo $bookdetails['author']; ?></span></p>
					</div>

					<div class="col-md-3 col-sm-3 col-3 text-left px-2">
						<p class="list-item-heading mb-1"> <span>Publisher:</span> <span><?php echo $bookdetails['publisher']; ?></span></p>
					</div>

					<div class="col-md-3 col-sm-3 col-3 text-left px-2">
						<p class="list-item-heading mb-1"> <span>Category:</span> <span><?php echo $bookdetails['category']; ?></span></p>
					</div>
					
				</div>               
                                                        
                <div class="row mb-3 feetop">
                   
					<div class="col-md-3 col-sm-3 col-3 text-left px-2">
						<p class="list-item-heading mb-1"> <span>Edition:</span> <span><?php echo $bookdetails['edition']; ?></span></p>
					</div>

					<div class="col-md-3 col-sm-3 col-3 text-left px-2">
						<p class="list-item-heading mb-1"> <span>Price:</span> <span>Rs. <?php echo $bookdetails['price']; ?></span></p>
					</div>

					<div class="col-md-3 col-sm-3 col-3 text-left px-2">
						<p class="list-item-heading mb-1"> <span>Due Period:</span> <span><?php echo $bookdetails['dueperiod']; ?> days</span></p>
					</div>

					<div class="col-md-3 col-sm-3 col-3 text-left px-2">
						<p class="list-item-heading mb-1"> <span>Stream:</span> <span><?php echo $bookdetails['stream']; ?></span></p>
					</div>
					
				</div>              
                                                        
                <div class="row mb-3 feetop">
                   
					<div class="col-md-3 col-sm-3 col-3 text-left px-2">
						<p class="list-item-heading mb-1"> <span>Supplier:</span> <span><?php echo $bookdetails['supplier']; ?></span></p>
					</div>
					
				</div> 
                 
               
                </div>
                
			   </div>
               
            </div>
             
          
           </div>
           
			<div class="d-inline-block my-3"></div>
                 
         
          <div class="card p-4 mt-4">
                  
			  	<h2>Books History</h2>
                    
                <table id="issuehistorytable" class="sortable table" style="width:100%"></table>    
				<?php //echo $this->table->generate();  ?>
                                 		           
			</div>
     
      
			</div>
      
     		<?php }?>
       
 </div>
 
 </main>

	
<script type="text/javascript">
	
	var barcode = "";
	var center = "";
	var barcodes = [];
	var tabledata = [];
	var tablerow = [];
	
    $(document).ready(function() {
   
			
		$("select").change(function(){
			$(this).attr('value',$(this).val());
		});
		
		$("#barcode").focus();
		
		barcode = "<?php echo $barcode; ?>";		
		
		if(barcode!=""){
			loadresults(oTablehistory,barcode);
			$("#barcode").focus();
		}
		
		
	// Initialize with options
	onScan.attachTo(document, {
		suffixKeyCodes: [13], // enter-key expected at the end of a scan
		reactToPaste: false, // Compatibility to built-in scanners in paste-mode (as opposed to keyboard-mode)
		onScan: function(sCode, iQty) { // Alternative to document.addEventListener('scan')
			//console.log('Scanned: ' + iQty + 'x ' + sCode); 
			
			$("#barcode").val(sCode).focus();
			scanbarcodedetails(sCode);
		
			
		},
		onKeyDetect: function(iKeyCode){ // output all potentially relevant key events - great for debugging!
			//console.log('Pressed: ' + iKeyCode);
			//$("#barcode").focus();
		}
	});
		
	$('#barcode').keypress(function (e) {
	 var key = e.which;
	 if(key == 13)  // the enter key code
	  {
		var sCode = $(this).val();
		scanbarcodedetails(sCode);
	  }
	});		
		
	$(document).on("click",".del",function(){
		
		var r = confirm("Are you sure to delete the book?");
			
		if(r){
				
		var barcode = $(this).attr('barcode');
		
		for(var i=0;i<tabledata.length;i++){
			//if($.inArray(barcode, tabledata[i])) {
			if(tabledata[i][1] == barcode) {
				tabledata.splice(i, 1);
				tablerow.splice(i,1	);
				break;
			}
		}
		
		oTable.fnClearTable();
		
		if(tabledata.length>0){
			oTable.fnAddData(tabledata);
			oTable.fnDraw();
		}
		
		//console.log(tabledata);
				
		}
		
	});	
    
		
	$(document).on('focus click','input,select,textarea', function () {
	  	$(".alert").removeClass("alert-success alert-danger").html('');
	});		
           
});
	
	
	function scanbarcodedetails(barcode){
						
			if(barcode=="") {alert("Scan barcode"); $("#studentno").focus();return false;}
					
			$(".stualert").removeClass("alert-success alert-danger").text('');
		         
	   		$(".stualert").addClass("alert-success").text('Progressing...');

			$.ajax({
				url: "bookhistory/getbarcodedetails",
				type: 'post',
				data: {"barcode":barcode},
				success: function(o){

					var response = $.parseJSON(o);
										
					if(response.status === 'success') {

						//$(".stualert").addClass("alert-success").text(response.message);
					   //oTable.fnDraw(); 																		
						window.location.href = "?bcode="+barcode;
						
						
					}else {

					   $(".stualert").addClass("alert-danger").text(response.message); 
						
					}
					

				}
				
			});
		
	}
	
	<?php if(!empty($bookdetails)){?>
	
	
	function loadresults(oTablehistory,barcode){
	
	$.ajax({
                type: 'POST',
                url: 'bookhistory/GetBarcodeHistoryList',
                data: {"barcode":barcode},
                success: function(response) {
                   
					var obj1 = $.parseJSON(response);
					
					if(obj1['tabledata'].length>0){
						
						oTablehistory.fnClearTable();
						oTablehistory.fnAddData(obj1['tabledata']);
						oTablehistory.fnDraw();
												
					}
					
				}
		
	});

}
	
<?php }?>	
	
</script>
    
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/dataTables.css?v=1.5" />
<script src="<?php echo base_url(); ?>js/jquery.dataTables.js?v=1.0" type="text/javascript"></script>

<script src="<?php echo base_url();?>js/vendor/jquery.smartWizard.min.js"></script>
<link rel="stylesheet" href="<?php echo base_url();?>css/boot/vendor/smart_wizard.min.css">

 <style type="text/css">
	 
	 table.dataTable{margin-top: 1rem !important;width: 99% !important;margin: auto}
	 .table tr:last-child td{text-align: left}
	.table tr td:last-child,.table tr th:last-child{text-align: left}
	.table tr:last-child td:last-child{font-weight: 600;text-align: left}
	.table tr:last-child{text-align: center}
	
	.table{border: 1px solid #D7DFF0;border-collapse: collapse;border-style: hidden;border-radius: 10px 10px 0 0;box-shadow: 0 0 0 1px #d7dff0;}
	.table thead th{font-size: 12px;font-weight: bold;color: #6F83AA;letter-spacing: 0.5px;background: #E6EBF7;text-transform: uppercase;padding: 0.8rem;text-align: left}
	.table thead tr th:first-child{border-top-left-radius: 5px}
	.table thead tr th:last-child{border-top-right-radius: 5px}
	.table td, .table th{border-top: 1px solid #D7DFF0;padding: 0.9rem 0.75rem;color: #364159;font-weight: 600;}
	.table td{background: #ffffff;}
	
		
	h3.title{font-size: 12px;text-transform: uppercase;color: #0332AA;letter-spacing: 0.5px;font-weight: bold;}
	 h2{font-size: 12px;text-transform: uppercase;color: #0332AA;letter-spacing: 0.5px;font-weight: bold;}
	 
		
		.dataTables_empty{text-align: center !important}
		.dataTables_wrapper{overflow-x: auto}
	 
	 .card{background: linear-gradient(0deg, #FFFFFF, #FFFFFF), #C4C4C4;box-shadow: 0px 0px 7px rgba(196, 196, 196, 0.35);border-radius: 10px;}
	 
	 .form-group.floating{margin-bottom: 0}
	 
	 p.list-item-heading{color: #6884CC;font-weight: 600;}
	.feetop p.list-item-heading span:last-child{font-weight: 600;font-size: 14px;color: #364159;}
	 
	 .sw-btn-prev,.sw-btn-next{display: none}
	 
	 .sw-theme-default>ul.step-anchor>li.active>a{color: #0332AA !important;}
	.sw-theme-default{box-shadow: none}
	.sw-main>ul.step-anchor{padding: 0;}
	 
	 .addstockrow{position: absolute; right: 0;top: 6px;z-index: 1;}
	 
	 .sw-main.sw-theme-default .nav-tabs .nav-link{font-weight: 600;border-radius: 5px;font-size: 14px;padding: .5rem 1.25rem .5rem 1.25rem;color: #B3C2E6 !important;border: 1px solid #B3C2E6 !important}
	 .sw-main.sw-theme-default .nav-tabs .active .nav-link{color: #0332AA !important;border: 1px solid #0332AA !important}
	 .nav-tabs .nav-item{margin-bottom: 0px}
	 .sw-main.sw-theme-default>ul.step-anchor>li.active>a::before{background: none}
	 .sw-theme-default>ul.step-anchor>li{margin-right: 1rem;}
	 .sw-theme-default .step-content{padding: 0}
	 
	 table.dataTable{margin-top: 2rem !important}
	 .dataTables_filter{right: 0;left: inherit;top: 5px;}
	 .dataTables_filter input{width: 300px}
	 .dataTables_wrapper {top: 25px;padding-top: 3rem}
	 
 </style>
 
 <script type="text/javascript">
$(document).ready(function(){	
		
	
	$("select").change(function(){
		$(this).attr('value',$(this).val());
	});
	
	$(".addstock").click(function(){
		
		var center = $(".centers").val();
		var booktype = $(".booktype").val();
		
		if(center==""){ alert("Select center"); return false;}
		
		if(booktype==""){ alert("Select book type"); return false;}
		
		var url = 'addbookstock?bid=<?php echo $bid; ?>&center='+center+'&btype='+booktype;
										
	    $(location).prop('href', url);
	});
	
	
          var columnData = [
              { "data": "created_at" },
                    { "data": "center" },
                    { "data": "tstock" },
                    { "data": "library" },
                    { "data": "reference" },
                    { "data": "id" }
                    
                  ];
        // columnData.push( {data: "id","visible":true} );
         //columnData.push( {data: "item_name_search","visible":false} );
         
       
        var oTable = $('#usertable').dataTable({
                    "bProcessing": true,
                    "bServerSide": true,
                    "sPaginationType": "full_numbers",
                    "ajax": {
                    "url": 'bookdetails/GetBookStock',
                    "type": "POST",
                   
                    "data":{ "bid": "<?php echo $bid; ?>"}
                     }, 
                     "oLanguage": {
                        "sProcessing": "<img src='<?php echo base_url(); ?>images/loader.gif'>",
						 "sSearchPlaceholder": "Search Center",
                    },
                    'iDisplayLength': 20,
                    "columns": columnData,
                    "order": [[ 0, "desc" ]],
                    "fnDrawCallback": function( oSettings ) {
						
                        var count = 1;
						
                         $('#usertable').find("tr .sno").each(function(){                           
                            $(this).text(count);
                            count++;
                         });
                                                      
                    }
         }); 
         
         
          var columnData = [
              { "data": "created" },
                    { "data": "barcode" },
                    { "data": "studid" },
                    { "data": "sname" },
                    { "data": "booktype" },
                    { "data": "duedate" },
                    { "data": "dueperiod" }
                    
                  ];
        // columnData.push( {data: "id","visible":true} );
         //columnData.push( {data: "item_name_search","visible":false} );
         
       
        var oTable1 = $('#issuedstocktable').dataTable({
                    "bProcessing": true,
                    "bServerSide": true,
                    "sPaginationType": "full_numbers",
                    "ajax": {
                    "url": 'bookdetails/GetIssuedStockBookDetails',
                    "type": "POST",
                   
                    "data":{ "bid": "<?php echo $bid; ?>"}
                     }, 
                     "oLanguage": {
                        "sProcessing": "<img src='<?php echo base_url(); ?>images/loader.gif'>",
						 "sSearchPlaceholder": "Search Barcodes",
                    },
                    'iDisplayLength': 20,
                    "columns": columnData,
                    "order": [[ 0, "desc" ]],
                    "fnDrawCallback": function( oSettings ) {
						
                        var count = 1;
						
                         $('#issuedstocktable').find("tr .sno").each(function(){                           
                            $(this).text(count);
                            count++;
                         });
                                                      
                    }
         }); 
  
	$('.dataTables_filter input').addClass('form-control');
	
});
</script>

 <main> 
        
        <div class="container-fluid">
                 
    
		<h1>Single Book Item</h1>
               
            <div class="row px-3 mt-4">     
                     
           <div class="col-12 p-0">
           
           <div class="card">
           
            <div class="course-container add-course mt-3 px-4">
                    
                <div class="row mb-3 feetop">
                   
					<div class="col-12 text-left px-2">
						<p class="list-item-heading mb-1"> <span>Book Name :</span> <span><strong><?php echo $bookdetails['bookname']; ?></strong></span></p>
					</div>
                                                       
				</div>                
                                                        
                <div class="row mb-3 feetop">
                   
					<div class="col-md-3 col-sm-3 col-3 text-left px-2">
						<p class="list-item-heading mb-1"> <span>ISBN Number:</span> <span><?php echo $bookdetails['isbn_number']; ?></span></p>
					</div>

					<div class="col-md-3 col-sm-3 col-3 text-left px-2">
						<p class="list-item-heading mb-1"> <span>Author:</span> <span><?php echo $bookdetails['author']; ?></span></p>
					</div>

					<div class="col-md-3 col-sm-3 col-3 text-left px-2">
						<p class="list-item-heading mb-1"> <span>Publisher:</span> <span><?php echo $bookdetails['publisher']; ?></span></p>
					</div>

					<div class="col-md-3 col-sm-3 col-3 text-left px-2">
						<p class="list-item-heading mb-1"> <span>Category:</span> <span><?php echo $bookdetails['category']; ?></span></p>
					</div>
					
				</div>               
                                                        
                <div class="row mb-3 feetop">
                   
					<div class="col-md-3 col-sm-3 col-3 text-left px-2">
						<p class="list-item-heading mb-1"> <span>Edition:</span> <span><?php echo $bookdetails['edition']; ?></span></p>
					</div>

					<div class="col-md-3 col-sm-3 col-3 text-left px-2">
						<p class="list-item-heading mb-1"> <span>Price:</span> <span>Rs. <?php echo $bookdetails['price']; ?></span></p>
					</div>

					<div class="col-md-3 col-sm-3 col-3 text-left px-2">
						<p class="list-item-heading mb-1"> <span>Due Period:</span> <span><?php echo $bookdetails['dueperiod']; ?> days</span></p>
					</div>

					<div class="col-md-3 col-sm-3 col-3 text-left px-2">
						<p class="list-item-heading mb-1"> <span>Stream:</span> <span><?php echo $bookdetails['stream']; ?></span></p>
					</div>
					
				</div>              
                                                        
                <div class="row mb-3 feetop">
                   
					<div class="col-md-3 col-sm-3 col-3 text-left px-2">
						<p class="list-item-heading mb-1"> <span>Supplier:</span> <span><?php echo $bookdetails['supplier']; ?></span></p>
					</div>
					
				</div>
              
               
                </div>
                
			   </div>
               
            </div>
             
          
           </div>
           
			<div class="d-inline-block my-3"></div>
          
          <div class="card p-4">
          
          <div class="row mt-3 addstockrow">
                   
                  
                  <?php if(isset($roleaccess['Add Stock'][0]) && $roleaccess['Add Stock'][0]=="y"){?>
                   
                    <div class="col-12 d-flex mb-3 justify-content-end">
                    
                    	<div class="form-group floating mr-3">
                      
                    		<select id="centers" name="centers" value="" class="form-control centers">
								<option value="">Select Center </option>
                      		 	<?php echo $units;?>
                       		 </select>
                       		 
							 <label>Select Center  <span>*</span> </label>
						</div>
						
						<div class="form-group floating mr-3">
                      
                    		<select id="booktype" name="booktype" value="" class="form-control booktype">
								<option value="">Select Book Type </option>
								<option value="Library">Library</option>
                      		 	<option value="Reference">Reference</option>
                       		 </select>
                       		 
							 <label>Select Book Type <span>*</span> </label>
						</div>
						
						<a href="#" title="Add Stock Item" class="mr-3"><button class="btn btn-primary addstock">Add Stock</button></a>
				  		
					</div>
					
					 <?php }?>
					
				</div>
          
          <div id="smartWizardClickable">
            <ul class="card-header">
              <li><a href="#customButtons1">Available Stock</a></li>
              <li><a href="#customButtons2">Issued Stock Student wise</a></li>
            </ul>
            <div class="card-body">
              <div id="customButtons1">
                            
				   <?php 
				  
				  	$this->table->clear();
				  	$tmpl = array('table_open' => '<table class="sortable sorting disabled table" id="usertable" style="margin-top:0px;">');
					$this->table->set_template($tmpl);
					$this->table->set_heading('S.NO', 'CENTER NAME','TOTAL STOCK','LIBRARY','REFERENCE','ACTIONS');
				  
				  	echo $this->table->generate();  
				  ?>
           
				</div>
         
          		<div id="customButtons2">
              
				  <?php 
				  
				  	$this->table->clear();
				  	$tmpl = array('table_open' => '<table class="sortable sorting disabled table" id="issuedstocktable" style="margin-top:0px;">');
					$this->table->set_template($tmpl);
					$this->table->set_heading('S.NO', 'BARCODE','STUDENT ID','STUDENT NAME','REFERENCE','DUE DATE','DUE');
				  
				  	echo $this->table->generate(); 
					
				  ?>
           
				</div>
          
			  </div>
          
			   </div>
                    
                                         
           
			</div>
       
 </div>
 
 </main>
 
<script type="text/javascript">
	
    $(document).ready(function() {
   
    
           
    });
	
</script>
    
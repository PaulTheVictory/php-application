 <link href="<?php  echo base_url(); ?>css/jquery-ui.min.css?v=1.4" rel="stylesheet" type="text/css" />
 <script src="<?php  echo base_url(); ?>js/jquery-ui.min.js?v=1.3" type="text/javascript"></script>
 <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/dataTables.css?v=1.5" />
<script src="<?php echo base_url(); ?>js/jquery.dataTables.js?v=1.0" type="text/javascript"></script>

 <style type="text/css">
     
     .ui-selectmenu-button.ui-button{ width: 97%; padding:13px;}
     .maincontent ul li.search-choice { height:auto; }
     .maincontent ul li.search-choice a{ height:auto; font-size: 14px;color:#536485}
     .response p { float: right;font-size:12px;color:#eb345e;}
     
.sortable thead tr {
    background: #E6EBF7;
    border: 1px solid #D7DFF0;
    box-sizing: border-box;
    border-radius: 10px 10px 0px 0px;
}
.sortable tr th {
    border-right: 0px;
    padding: 20px 0;font-size: 13px;
      color: #6F83AA;
   cursor: pointer;
   text-align: center;

}

.sortable tr td:nth-child(1) {
   
    min-width:50px;color: #364159;
}

.sortable tr td:nth-child(2) {
   
    width:40%;
}

.sortable tr td {
    border-right: 0px;
    padding: 15px 5px;
    text-align: center;font-size: 13px;
    min-width:100px;
}
.sortable tr td a {
    color: #364159;
}

.dataTables_info { display: none; }
#classtable_paginate { display: inline-block;}
#classtable_filter input {display:none;}
.sortable tr td a:hover { text-decoration: underline; }
.sortable tr td span{ font-size: 14px;color: #364159 }
 </style>

	<div class="wrap dynamic-width" style="float: left;position: relative;min-width: 800px">
     <div style="margin-top: 10px; width: 99%; height: 50px; text-align: right;">
         <span style="font-weight: bold;font-size: 20px;padding: 10px;float:left;color: #364159">Add Accounting Head</span>
         
     </div>    
           
                 <?php if(isset($roleaccess['Accounting Head'][0]) && $roleaccess['Accounting Head'][0]=="y"){ ?> 
                 
                           
            <div id="course-container" class="add-course">
<?php echo form_open('accounthead/AccountheadSubmit', array('id' => 'locationForm')) ?>
                <div class="row-element">
                    <span class="content"><input placeholder="Accounting Head Name" type="text" value="" name = "accounthead" class="accounthead"></span>
                </div>
                
                
            <?php echo form_close() ?>
                
            </div>
            
       
     <div style="margin-top: 0px; width: 98%; height: 70px; text-align: right;">
         <span  style="margin: 0px auto; float:right;margin-top: 18px;padding: 10px; color: #fff; background: #4f6fc4 none repeat scroll 0% 0%; border-radius:5px;cursor: pointer" class="btn savebtn" href="#">Save</span>
         <a style="margin: 0px auto; float:right;margin-top: 18px;margin-right:18px;padding: 9px 10px; color: #0332AA; background: linear-gradient(0deg, #FFFFFF, #FFFFFF), #C4C4C4;border: 1px solid #0332AA; border-radius:5px" class="btn" href="<?php echo base_url(); ?>accounthead">Reset</a>
         <span class="response" style="margin: 0px auto; float:right;width: 80%; height: 30px;margin-top:20px"></span>
     </div>   
           
            <?php } ?> 
            
            
            <label style="color:#536485;background: none;border: 0px;width: 4%;height: 80px;float:left;">&nbsp;</label>     
       <div style="width:100%;height: auto;float:left">
         <?php echo $this->table->generate();  ?>             
         
        </div>     
        
        </div>
    
    
    
<script type="text/javascript">
$(document).ready(function() {
    
     var columnData = [
                   
		 			{ "data": "created_at" },
		 			{ "data": "ahname" },  
                    { "data": "ide" }                                     
                    
                    
                  ];
                
       
        var oTable = $('#classtable').dataTable({
                    "bProcessing": true,
                    "bServerSide": true,
                    "sPaginationType": "full_numbers",
                    "ajax": {
                    "url": 'accounthead/GetAccounthead',
                    "type": "POST",
                    "data":{ }
                     }, 
                     "oLanguage": {
                        "sProcessing": "<img src='<?php echo base_url(); ?>images/loader.gif'>"
                    },
                    'iDisplayLength': 10,
                    "columns": columnData,
                    "fnDrawCallback": function( oSettings ) {
						
						var count = 1;                    
                        $('#classtable').find("tr .sno").each(function(){
                          
                            $(this).text(count);
                            count++;
        
                          });
                        
                         $("#classtable").find(".del").each(function(){

                            $(this).click(function(){ 

                              if(confirm("Are you sure to delete this item ?")) {
                                    var ide = $(this).attr("data-id");
                                    $.get('accounthead/DelAccounthead',{
                                                               'ide':ide

                                                    }, function(o) { 
                                                            var obj1 = $.parseJSON(o);
                                                    if (obj1[0] === 'success') {
                                                        oTable.fnDraw(); 
                                                    } else if (obj1[0] === 'fail') {
                                                        alert("Error!!! please try again");
                                                }
                                    });
                                }

                              });
                        

                          });
                                             
                    }
         }); 
    
    
    $(".savebtn").click(function(){
         
               $(".response").html('').text('Progressing...');
     
               
                var locationForm = $("#locationForm");

                    $.ajax({
                        url: locationForm.attr('action'),
                        type: 'post',
                        data: locationForm.serialize(),
                        success: function(o){
                            
                            var response = $.parseJSON(o);
                            $(".response").html('');
                            if(response.status === 'success') {
                       
                                $(".response").css("color","rgb(25, 71, 15)");
                               $(".response").text(response.message);
                               oTable.fnDraw();
                               
                               
                            } else {
                                
                               $(".response").append(response.message); 
                           
                            }

                        }
                    });
                   
                              
            });
	
	
});
</script>
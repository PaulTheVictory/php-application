<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/dataTables.css?v=1.5" />
<script src="<?php echo base_url(); ?>js/jquery.dataTables.js?v=1.0" type="text/javascript"></script>
<script src="<?php echo base_url(); ?>js/onscan.min.js?v=1.0" type="text/javascript"></script>

 <style type="text/css">
	 
	 table.dataTable{margin-top: 1rem !important;width: 99% !important;margin: auto}
	 .table tr:last-child td{text-align: left}
	.table tr td:last-child,.table tr th:last-child{text-align: left}
	.table tr:last-child td:last-child{font-weight: 600;text-align: left}
	.table tr:last-child{text-align: center}
	
	.table{border: 1px solid #D7DFF0;border-collapse: collapse;border-style: hidden;border-radius: 10px 10px 0 0;box-shadow: 0 0 0 1px #d7dff0;}
	.table thead th{font-size: 12px;font-weight: bold;color: #6F83AA;letter-spacing: 0.5px;background: #E6EBF7;text-transform: uppercase;padding: 0.8rem;text-align: left}
	.table thead tr th:first-child{border-top-left-radius: 5px}
	.table thead tr th:last-child{border-top-right-radius: 5px}
	.table td, .table th{border-top: 1px solid #D7DFF0;padding: 0.9rem 0.75rem;color: #364159;font-weight: 600;}
	.table td{background: #ffffff;}
	
		
	h3.title{font-size: 12px;text-transform: uppercase;color: #0332AA;letter-spacing: 0.5px;font-weight: bold;}
	 h2{font-size: 12px;text-transform: uppercase;color: #0332AA;letter-spacing: 0.5px;font-weight: bold;}
	 
		
		.dataTables_empty{text-align: center !important}
		.dataTables_wrapper{overflow-x: auto}
	 
	 .card{background: linear-gradient(0deg, #FFFFFF, #FFFFFF), #C4C4C4;box-shadow: 0px 0px 7px rgba(196, 196, 196, 0.35);border-radius: 10px;}
	 
	 .form-group.floating{margin-bottom: 0}
	 
	 p.list-item-heading{color: #6884CC;font-weight: 600;}
	.feetop p.list-item-heading span:last-child{font-weight: 600;font-size: 14px;color: #364159;}
	 
	 .icon-edit{background: url(img/icons/edit3-b.png) no-repeat;width: 15px;height: 16px;display: inline-block;vertical-align: middle}
	 .bookdetails p span:last-child{font-weight: 600;font-size: 14px;line-height: 14px;color: #364159;}
	 .bookdetails p a {font-weight: 600;font-size: 14px;line-height: 20px;color: #0332AA;}

	 
	#receivestatusModal h2{font-size: 14px;text-transform: none;color: #364159;letter-spacing: 0px;font-weight: bold;}
	h5.modal-title p.headtitle{display: inline-block;width: 100%;text-align: center;font-weight: bold;font-size:17px;color: #fff;}
	h5.modal-title p.text-muted{display: inline-block;width: 100%;text-align: center;font-weight: 600;font-size: 14px;line-height: 36px;color: #181E29;line-height: 20px;}
	.modal-title img{display: block;margin: 1em auto}
	#EditbooklimitModal.modal .modal-header,#receivestatusModal.modal .modal-header{padding: 10px 20px !important;border: none}	
	#EditbooklimitModal.modal .modal-body,#receivestatusModal.modal .modal-body{padding:0 1.75rem 1.75rem}
	.modal-body p{text-align: left !important}
	.modal-backdrop.show {opacity: .5 !important;}
	 
	.profilepic{width: 120px;height: 120px}
	 
 </style>
 
 <script type="text/javascript">
	 
	 var oTable,oTablereceive = "";
	 
$(document).ready(function(){	
		
	
	$("select").change(function(){
		$(this).attr('value',$(this).val());
	});
		
	
         /* var columnData = [
              { "data": "created" },
                    { "data": "barcode" },
                    { "data": "bookname" },
                    { "data": "edition" },
                    { "data": "studentid" },
                    { "data": "studentname" },
                    { "data": "duedate" },
                    { "data": "issuedate" },
                    
                  ];*/
        // columnData.push( {data: "id","visible":true} );
         //columnData.push( {data: "item_name_search","visible":false} );
         
       
        oTable = $('#usertable').dataTable({
                    "bProcessing": true,
                    "sPaginationType": "full_numbers",
                     "oLanguage": {
                        "sProcessing": "<img src='<?php echo base_url(); ?>images/loader.gif'>",
						 "sEmptyTable": "No Results Found",
                    },
                    "columns": [
							{ title: "S.NO" },
							{ title: "BARCODE" },
							{ title: "BOOK NAME" },							
							{ title: "EDITION" },							
							{ title: "STUDENT ID" },							
							{ title: "STUDENT NAME" },							
							{ title: "DUE DATE" },							
							{ title: "ISSUE DATE" },							
							{ title: "ACTION" }
						],
                    'iDisplayLength': 1000,
                    //"columns": columnData,
                    "order": [[ 0, "asc" ]],
                    "fnDrawCallback": function( oSettings ) {
						
                        var count = 1;
						
                         $('#usertable').find("tr .sno").each(function(){                           
                            $(this).text(count);
                            count++;
                         });
                                                      
                    }
         }); 
         
         
          oTablereceive = $('#receivedhistorytable').dataTable({
                    "bProcessing": true,
                    "sPaginationType": "full_numbers",
                     "oLanguage": {
                        "sProcessing": "<img src='<?php echo base_url(); ?>images/loader.gif'>",
						 "sEmptyTable": "No Books History Found",
                    },
                    "columns": [
							{ title: "S.NO" },
							{ title: "BARCODE" },
							{ title: "BOOK NAME" },							
							{ title: "EDITION" },							
							{ title: "STUDENT ID" },							
							{ title: "STUDENT NAME" },							
							{ title: "DUE DATE" },							
							{ title: "ISSUE DATE" }							
						],
                    'iDisplayLength': 1000,
                    //"columns": columnData,
                    "order": [[ 0, "asc" ]],
                    "fnDrawCallback": function( oSettings ) {
						
                        var count = 1;
						
                         $('#receivedhistorytable').find("tr .sno").each(function(){                           
                            $(this).text(count);
                            count++;
                         });
                                                      
                    }
         }); 
  
	
});
</script>

 <main> 
        
        <div class="container-fluid">
                 
    
		<h1>Receive Book(s)</h1>
               
            <div class="row px-3 mt-4">     
                     
           <div class="col-12 p-0">
           
           <div class="card">
           
            <div class="course-container add-course mt-0 px-0">
                   
              <div class="d-flex flex-row">
             
				<a class="d-flex position-relative" href="#"><img alt="Profile" src="img/myprofile.png" class="img-thumbnail profilepic border-0 rounded-circle m-4 align-self-center"></a>
             
              <div class="d-flex flex-grow-1 min-width-zero">
                <div class="card-body pl-0 align-self-center d-flex flex-column flex-lg-row justify-content-between min-width-zero">
                  <div class="w-100">
                   
                          <div class="row mb-3 feetop">
                   
					<div class="col-12 text-left px-2">
						<p class="list-item-heading mb-1"> <span>Student Name :</span> <span class="stuname"></span></p>
					</div>
					
				</div>
                  
                <div class="row mb-3 feetop">
                   
					<div class="col-md-4 col-sm-4 col-4 text-left px-2">
						<p class="list-item-heading mb-1"> <span>Student ID:</span> <span class="studid"></span></p>
					</div>
                   
					<div class="col-md-3 col-sm-3 col-3 text-left px-2">
						<p class="list-item-heading mb-1"> <span>Mobile number:</span> <span class="stumobile"></span></p>
					</div>
					
				</div>  
                 
                  </div>
                </div>
              </div>
            </div>
                                  
               
                </div>
                
			   </div>
               
            </div>
             
          
           </div>
           
			<div class="d-inline-block my-3"></div>
          
          
		<h2 class="mt-4">Received Book(s)</h2>

        <div class="col-12 p-0 my-4 add-book">
                               
                 <div class="card">               
                                
                <div class="row mt-3 px-4 pt-3">
                
                	<div class="col-12 col-sm-5">
                    
						<div class="form-group position-relative error-l-50 floating mb-0">

							 <input id="barcode" name="barcode" minlength="3" maxlength="10" class="form-control barcode" placeholder=" " type="text" tabindex="1" >

							 <label>Scan Barcode <span>*</span> </label>
						</div>
						
						<input type="hidden" name="stuid" id="stuid" value="" />
						
					</div>
			  				
					<div class="col-12 col-sm-2">
				
 						 <button class="btn btn-primary savebtn">Save</button>

					 </div>
				 
					  <div class="col-12"> 
						<p class="alert my-3"></p>
					  </div>
				 
					</div>
				               
			   </div>
              
			   </div>
         
          	<div class="card p-4">
                                           
          		<table id="usertable" class="sortable table" style="width:100%"></table>
           
			</div>
         
          	<div class="card p-4 mt-4">
                     
				<h2>Books Received History</h2>
         		                                                
          		<table id="receivedhistorytable" class="sortable table" style="width:100%"></table>
           
			</div>
       
 </div>
 
 </main>
 
 
 
 <div id="receivestatusModal" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
				   <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				</div>
				<div class="modal-body text-center">
									
					<img src="css/img/brilliant-logo.png" alt="Brilliant Logo" class="mb-4" />
					<h3 class="my-4 receivestatus"></h3>
					
				</div>
				<div class="modal-footer">
					<!--<a href="#" target="_blank"><button type="button" class="btn btn-primary">View Bill</button></a>-->
					<button type="button" class="btn btn-outline-primary modalclose" data-dismiss="modal">Close</button>
				</div>
								
			</div>
		</div>
	</div>
	
<script type="text/javascript">
	
	var tabledata = [];
	var tablerow = [];
	
    $(document).ready(function() {
   
		$("#barcode").focus();
	
		$("select").change(function(){
			$(this).attr('value',$(this).val());
		});
		
		
	// Initialize with options
	onScan.attachTo(document, {
		suffixKeyCodes: [13], // enter-key expected at the end of a scan
		reactToPaste: false, // Compatibility to built-in scanners in paste-mode (as opposed to keyboard-mode)
		onScan: function(sCode, iQty) { // Alternative to document.addEventListener('scan')
			//console.log('Scanned: ' + iQty + 'x ' + sCode); 
			$("#barcode").val(sCode).focus();
			//scanbarcodedetails(sCode);
			loadreceivebookspreview(oTable,sCode)
		},
		onKeyDetect: function(iKeyCode){ // output all potentially relevant key events - great for debugging!
			//console.log('Pressed: ' + iKeyCode);
			//$("#barcode").focus();
		}
	});
    
		
	/*$(".savebtn").click(function(){

		var barcode = $("#barcode").val();

		scanbarcode(barcode);
                   
                              
     });*/
		
        $('#barcode').keypress(function (e) {
            var key = e.which;
            if(key == 13)  // the enter key code
             {
                   var sCode = $(this).val();
                   loadreceivebookspreview(oTable,sCode);
             }
	});
		
	$(document).on("click",".del",function(){
		
		var r = confirm("Are you sure to delete the book?");
			
		if(r){
				
		var barcode = $(this).attr('barcode');//console.log(barcode);return;
		
		for(var i=0;i<tabledata.length;i++){
			//if($.inArray(barcode, tabledata[i])) {
			if(tabledata[i][1] == barcode) {
				tabledata.splice(i, 1);
				tablerow.splice(i,1	);
				break;
			}
		}
		
		oTable.fnClearTable();
		
		if(tabledata.length>0){
			oTable.fnAddData(tabledata);
			oTable.fnDraw();
		}else{
			oTablereceive.fnClearTable();
		}
		
		//console.log(tabledata);
				
		}
		
	});		
		
		
	$(".savebtn").click(function(){

		if(jQuery.isEmptyObject(tablerow)){
			$(".alert").addClass('alert-danger').text("No Books Added");return false;
		}
		
		
		if($(".savebtn").hasClass('process')){
			
			$(".alert").addClass('alert-danger').text("Please wait while progressing...");
			
		}else{
		
			
			var r = confirm("Are you sure to receive the books?");
			
			if(r){
				
				$(".savebtn").addClass('process');
				$(".alert").removeClass('alert-danger').addClass('alert-success').text("Progressing...");

				$.ajax({
					type: 'POST',
					url: 'receivebook/updateReceiveBook',
					data: {"qData":tablerow},
					success: function(response) {

						var obj1 = $.parseJSON(response);

						if(obj1.status=="success"){

							$(".receivestatus").text(obj1.message);
							$('#receivestatusModal').modal({show:true});
							
						}else{
							$(".receivestatus").text(obj1.message);
							$('#receivestatusModal').modal({show:true});
						}

					}

				});

			}
			
		}
		
                              
     });
								
	$('#receivestatusModal').on('hidden.bs.modal', function () {
	  	location.assign('receivebook');
	});
		
		
	$(document).on('focus click','input,select,textarea', function () {
	  	$(".alert").removeClass("alert-success alert-danger").html('');
	});	
		
           
});
		
	
function loadreceivebookspreview(oTable,barcode){
		
		if(barcode=="") {alert("Scan barcode"); $("#barcode").focus();return false;}
		
		var bookexists = false;
		
		//barcodes.push(barcode);
		//return;
		
		var totalbooks = tabledata.length;
		
		$.ajax({
                type: 'POST',
                url: 'receivebook/receivebarcodelistpreview',
                data: {"barcode":barcode},
                success: function(response) {
                   
					var obj1 = $.parseJSON(response);
					
					if(obj1.status=="success"){
												
						if(obj1.tabledata.length>0){//console.log(tablerow);
							
							for (var i = 0; i <tabledata.length; i++) {
								if(tabledata[i][1] == barcode){
									bookexists = true;
								}
							}

							if(!bookexists){
								
								$(".alert").addClass("alert-success").text(obj1.message);
								
								tabledata.push(obj1.tabledata);
								tablerow.push(obj1.tablerow);
								
								var barcodedata = obj1.data;
								var type = obj1.type;
						
								var profilepic = "img/myprofile.png";

								if(barcodedata['profilepic'] !='0' && barcodedata['profilepic']!=0){

									profilepic = "docs/profilepic/"+barcodedata['studentid']+'/'+barcodedata['profilepic'];
								}

								$(".alert").removeClass("alert-success alert-danger").html('');

								$(".profilepic").attr('src',profilepic);

								if(type!="staff"){
									$(".stuname").text(barcodedata['sname']).prev('span').text("Student Name:")
									$(".studid").text(barcodedata['studid']).prev('span').text("Student ID:")
								}else{
									$(".stuname").text(barcodedata['sname']).prev('span').text("Staff Name:");
									$(".studid").text(barcodedata['studid']).prev('span').text("Email ID:");
								}
									$(".stumobile").text(barcodedata['mcode']+" "+barcodedata['contact']);
									$("#stuid").val(barcodedata['studid']);
								
									oTablereceive.fnClearTable();
									loadresults(oTablereceive,barcodedata['studid']);
								
							}else{
								
								$(".alert").addClass("alert-danger").text("Book already added.");
								
							}
															
							if(!jQuery.isEmptyObject(tabledata)){
								
								oTable.fnClearTable();
								oTable.fnAddData(tabledata);
								oTable.fnDraw();								
								
							}
																									
						}
						
					}else{
						$(".alert").addClass("alert-danger").text(obj1.message); 
					}
										
					setTimeout(function(){$(".alert").removeClass("alert-success alert-danger").html('');$("#barcode").val("").focus()},1000);
					
				}
		
		});

}	
	/*function scanbarcodedetails(barcode){
				
			if(barcode=="") {alert("Scan barcode"); $("#barcode").focus();return false;}
		
			//if(barcode.length < 3 || barcode.length > 7) {alert("Barcode must be upto 7 digit"); return false;}
			
			$(".alert").removeClass("alert-success alert-danger").text('');
		         
	   		$(".alert").addClass("alert-success").text('Progressing...');

			$.ajax({
				url: "receivebook/getstudentdetails",
				type: 'post',
				data: {"barcode":barcode},
				success: function(o){

					var response = $.parseJSON(o);
					
					if(response.status === 'success') {

						$(".alert").addClass("alert-success").text(response.message);
					   //oTable.fnDraw(); 
						
						var barcodedata = response.data;
						
						var profilepic = "img/myprofile.png";
						
						if(barcodedata['profilepic'] !='0' && barcodedata['profilepic']!=0){
							
							profilepic = "docs/profilepic/"+barcodedata['studentid']+'/'+barcodedata['profilepic'];
						}
						
						$(".alert").removeClass("alert-success alert-danger").html('');
						
						$(".profilepic").attr('src',profilepic);
						
						$(".stuname").text(barcodedata['sname']);
						$(".studid").text(barcodedata['studid']);
						$("#stuid").val(barcodedata['studid']);
						$(".stumobile").text(barcodedata['mcode']+" "+barcodedata['contact']);
						
						
					}else {

					   $(".alert").addClass("alert-danger").text(response.message); 

					}
					
					setTimeout(function(){$(".alert").removeClass("alert-success alert-danger").html('');$("#barcode").focus()},2000);

				}
			});
		
	}
	
	function scanbarcode(barcode){
				
			var stuid = $("#stuid").val();
		
			if(barcode=="") {alert("Scan barcode"); $("#barcode").focus();return false;}
		
			//if(barcode.length < 3 || barcode.length > 7) {alert("Barcode must be upto 7 digit"); return false;}
			
			$(".alert").removeClass("alert-success alert-danger").text('');
		         
	   		$(".alert").addClass("alert-success").text('Progressing...');

			$.ajax({
				url: "receivebook/addreceivebookSubmit",
				type: 'post',
				data: {"stuid":stuid,"barcode":barcode},
				success: function(o){

					var response = $.parseJSON(o);
					
					if(response.status === 'success') {

						$(".alert").addClass("alert-success").text(response.message);
					   //oTable.fnDraw(); 
						loadresults(oTable,response.studid)
						
					} else if(response.status === 'exists') {

					   $(".alert").addClass("alert-danger").text(response.message); 

					} else if(response.status === 'fail') {

					   $(".alert").addClass("alert-danger").text(response.message); 

					} else {

					   $(".alert").addClass("alert-danger").text(response.message); 

					}
					
					setTimeout(function(){$(".alert").removeClass("alert-success alert-danger").html('');$("#barcode").val("").focus()},2000);

				}
			});
		
	}*/
	
function loadresults(oTablereceive,stuid){
	
	$.ajax({
                type: 'POST',
                url: 'receivebook/GetReceivedBookList',
                data: {"stuid":stuid},
                success: function(response) {
                   
					var obj1 = $.parseJSON(response);
					
					if(obj1['tabledata'].length>0){
						
						oTablereceive.fnClearTable();
						oTablereceive.fnAddData(obj1['tabledata']);
						oTablereceive.fnDraw();
												
					}
					
				}
		
	});

}
	
</script>
    
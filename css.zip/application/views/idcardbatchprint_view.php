<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/dataTables.css?v=1.6" />
<script src="<?php echo base_url(); ?>js/jquery.dataTables.js?v=1.0" type="text/javascript"></script>

<style type="text/css">
	 
	 table.dataTable{margin-top: 2rem !important;width: 99% !important;margin: auto}
	 .table tr:last-child td{text-align: left}
	.table tr td:last-child,.table tr th:last-child{text-align: left}
	.table tr:last-child td:last-child{font-weight: 600;text-align: left}
	.table tr:last-child{text-align: center}
	
	.table{border: 1px solid #D7DFF0;border-collapse: collapse;border-style: hidden;border-radius: 10px 10px 0 0;box-shadow: 0 0 0 1px #d7dff0;}
	.table thead th{font-size: 12px;font-weight: bold;color: #6F83AA;letter-spacing: 0.5px;background: #E6EBF7;text-transform: uppercase;padding: 0.8rem;text-align: left}
	.table thead tr th:first-child{border-top-left-radius: 5px}
	.table thead tr th:last-child{border-top-right-radius: 5px}
	.table td, .table th{border-top: 1px solid #D7DFF0;padding: 0.9rem 0.75rem;color: #364159;font-weight: 600;}
	.table td{background: #ffffff;}
	
		
	.add-book .card{background: linear-gradient(0deg, #FFFFFF, #FFFFFF), #C4C4C4;box-shadow: 0px 0px 7px rgba(196, 196, 196, 0.35);border-radius: 10px;}
	
	h3.title{font-size: 12px;text-transform: uppercase;color: #0332AA;letter-spacing: 0.5px;font-weight: bold;}
		
		.dataTables_empty{text-align: center !important}
		.dataTables_wrapper{overflow-x: auto;padding-top: 2rem;}
	 
	 .notifycard .card{background: linear-gradient(0deg, #FFFFFF, #FFFFFF), #C4C4C4;box-shadow: 0px 0px 0px rgba(196, 196, 196, 0.35);border-radius: 5px;}
	 .notifycard .z-index{z-index: 1;}
	 
	 .form-group.floating{margin-bottom: 0}
	 
	 .notifycard p.text-muted{font-weight: 600;line-height: 16px;}
	
	 p{font-weight: 600;}
	
	 p.text-muted{font-weight: 600;line-height: 14px;color: #6884CC !important}
	
	 p.notetext{font-weight: 600;line-height: 12px;color: #354159 !important}
	 
	 .dataTables_filter{right: 0;left: 20px;top: 5px;}
	 #createprinttable_filter input{width: 300px}
	 #usertable_wrapper{top: 0px;padding-top: 3rem}
	 
	 textarea.form-control.smstext,textarea.form-control.whatsapptext{height: 110px}
	
	.alert{padding: 0.5rem 1.25rem;}
	
	.profileimg{width: 40px;height: 40px;border-radius: 50%}
	table.dataTable td{vertical-align: middle}
	
	.icon-edit{background: url(img/icons/edit3-b.png) no-repeat;width: 15px;height: 16px;display: inline-block;vertical-align: middle;margin-bottom: 2px;}
	
	h5.modal-title p.headtitle{display: inline-block;width: 100%;text-align: center;font-weight: bold;font-size:17px;color: #fff;}
	h5.modal-title p.text-muted{display: inline-block;width: 100%;text-align: center;font-weight: 600;font-size: 14px;line-height: 36px;color: #181E29;line-height: 20px;}
	.modal-title img{display: block;margin: 1em auto}
	#EditbatchnameModal.modal .modal-header{padding: 10px 20px !important;border: none}	
	#EditbatchnameModal.modal .modal-body{padding:0 1.75rem 1.75rem}
	.modal-body p{text-align: left !important}
	.modal-backdrop.show {opacity: .5 !important;}

 </style>
 
<script type="text/javascript">
	
	var oTable = "";
	
$(document).ready(function(){
		
	//window.print();
	
	 oTable = $('#createprinttable').dataTable({
					"processing": true,
					"sPaginationType": "full_numbers",
			 		"oLanguage": {
                        "sProcessing": "<img src='<?php echo base_url(); ?>images/loader.gif'>",
						 "sEmptyTable": "No Results Found",
						"sSearchPlaceholder": "Search Students",
                    },
                    "columns": [
							{ title: "" },
							{ title: "Sno" },
							{ title: "" },
							{ title: "STUDENT ID" },							
							{ title: "STUDENT NAME" },							
							{ title: "PHONE" },							
							{ title: "PRINTED" },							
							{ title: "ACTION" }
						],
			 			/*"columnDefs": [
							{
								"targets": 1,
								"render": function ( data, type, row ) {//console.log(row[15]);
									if (type === "display") {
										<?php //if($exam['type']=="Screening Test"){ ?>
											return "<a href=\"studentprofile?sid=" + encodeURIComponent(row[20]) + "\" target=\"_blank\">" + data + "</a>";
										<?php //}else{ ?>
											return "<a href=\"studentprofile?sid=" + encodeURIComponent(row[15]) + "\" target=\"_blank\">" + data + "</a>";
										<?php //} ?>
									}

									//return data;
								}
							}
						],*/
                    //"order": [[ 0, "desc" ]],
		 			'iDisplayLength': 200,
                    "fnDrawCallback": function( oSettings ) {
                        
    }
 }); 
	
	$('#createprinttable_filter input').addClass('form-control');
	
	loadresults(oTable);
	
	var chkbox = $('<input class="gchkbox" style="margin-left:9px;float:left;padding:5px;" type="checkbox"/>');
	
	$('#createprinttable').find("th").first().append(chkbox);
         $('#createprinttable').find("th").first().css("width","50px");
        $(chkbox).click(function(e){
           
            if($(this).is(":checked")){

                $('#createprinttable').find(".bccheckbox").each(function(){
                    $(this).prop( "checked", true );
                });

            } else {
                $('#createprinttable').find(".bccheckbox").each(function(){
                    $(this).prop( "checked", false );
                });
            }
           
        });
	
	
	$(".printcard").change(function(){
	
		var printcard = $(this).val();
		var ide = "";
		
		if(printcard=="") return false;
		
		if(printcard=="printall"){
			
			 $('#createprinttable').find(".bccheckbox").each(function(){
                 $(this).prop( "checked", true );
             });
			
		}
		
		 $(".bccheckbox").each(function(){

		   if($(this).is(":checked")) { ide += $(this).val()+"|";}

		 });
		
		if(ide=="") {alert("Select Students");return false;}
		
		window.open("printidcard?id=<?php echo $printbatchid; ?>&sid="+ide,"_blank");
		
	});
	
	
	$(".printaction").change(function(){
	
		var printaction = $(".printaction option:selected").val();
		var printactiontxt = $(".printaction option:selected").text();//alert(printactiontxt);return;
		var ide = "";
		
		if(printaction=="") return false;
		
		 $(".bccheckbox").each(function(){

		   if($(this).is(":checked")) { ide += $(this).val()+"|";}

		 });
		
		if(ide=="") {alert("Select Students");return false;}
		
		var r = confirm("Are you sure to "+printactiontxt+"?");
		
		if(r){
		
		$.ajax({
                type: 'POST',
                url: 'idcardbatchprint/printbatchaction',
                data: {"batchid":"<?php echo $printbatchid; ?>","ide":ide,"action":printaction},
                success: function(response) {
                   
					var obj1 = $.parseJSON(response);
					
					if(obj1[0]=="success"){
						loadresults(oTable);
					}else if(obj1[0]=="fail"){
						alert("Update action failed");
					}else{
						alert("Please try again");
					}
										
				}
		
			});
			
		}
		
	});
	
	$(".editbatchnamebtn").click(function(){

		   $('#EditbatchnameModal').modal({show:true});               
                              
     });
	
	$(".editsave").click(function(){
         
		
		$(".eresponse").html('').text('Progressing...');

		var editbatchnameForm = $("#editbatchnameForm");

			$.ajax({
				url: editbatchnameForm.attr('action'),
				type: 'post',
				data: editbatchnameForm.serialize(),
				success: function(o){

					var response = $.parseJSON(o);
					$(".eresponse").html('');
					if(response.status === 'success') {

						$(".eresponse").css("color","rgb(25, 71, 15)");
					   $(".eresponse").text(response.message);
					   
					   $('#EditbatchnameModal').modal('hide');		
						location.reload();
						
						$(".eresponse").html(""); 

					} else {

					   $(".eresponse").append(response.message); 

					}

				}
			});
                    
      });

});
	
function loadresults(oTable){
	
	$.ajax({
                type: 'POST',
                url: 'idcardbatchprint/batchprintdatatable',
                data: {"batchid":"<?php echo $_GET['id']; ?>"},
                success: function(response) {
                   
					var obj1 = $.parseJSON(response);
					
					oTable.fnClearTable();
					
					if(obj1['tabledata'].length>0){
						
						oTable.fnAddData(obj1['tabledata']);
						oTable.fnDraw();
												
					}
					
				}
		
	});

}
	
</script>
	
 <main> 
        
    <div class="container-fluid">
                               
		<div class="row">
			<div class="col-10">
				<h1>Print Batch Page</h1>
			</div>
			<div class="col-2">
				
			</div>
		</div>
              
              
              <div class="col-12 p-0 my-4 add-book">
              
              <div class="card">               
                                
                <div class="row mt-3 px-3 pt-3 pb-4 align-items-center">
                
                	<div class="col-12 col-sm-4">
                   
						<div class="row align-items-center">
						
							<div class="col-12 col-sm-4">
							
								<p class="text-muted">Batch Name :</p>
							
							</div>
							
							<div class="col-12 col-sm-4">
							
								<p><?php echo ucwords($pbdetails['batchname']);?></p>
							
							</div>
							
						</div>						
						
					</div>
                
                	<div class="col-12 col-sm-4">
                    
						<div class="row">
						
							<div class="col-12 col-sm-4">
							
								<p class="text-muted">Number of Student : </p>
							
							</div>
							
							<div class="col-12 col-sm-8">
							
								<p><?php echo $pbdetails['stucount'];?></p>
							
							</div>
							
						</div>
						
					</div>
                   
                   <div class="col-12 col-sm-4">
                    
						<div class="row">
						
							<div class="col-12 col-sm-4">
							
								<p class="text-muted">Print Batch ID : </p>
							
							</div>
							
							<div class="col-12 col-sm-8">
							
								<p><?php echo $printbatchid;?></p>
							
							</div>
							
						</div>
						
					</div>
                   
                   <div class="col-12 col-sm-4">
                    
						<div class="row">
						
							<div class="col-12 col-sm-4">
							
								<p class="text-muted">Print Batch Name : </p>
							
							</div>
							
							<div class="col-12 col-sm-8">
							
								<p><?php echo $pbdetails['printbatchname'];?> <a href="#" title="Edit" class="ml-3 editbatchnamebtn"><i class="icon-edit"></i> Edit</a></p>
							
							</div>
							
						</div>
						
					</div>
                
                	<div class="col-12 col-sm-4">
                    
						<div class="row">
						
							<div class="col-12 col-sm-4">
							
								<p class="text-muted">Course Name : </p>
							
							</div>
							
							<div class="col-12 col-sm-8">
							
								<p><?php echo ucwords($pbdetails['coursename']);?></p>
							
							</div>
							
						</div>
						
					</div>
                
                	<div class="col-12 col-sm-4">
                    
						<div class="row">
						
							<div class="col-12 col-sm-4">
							
								<p class="text-muted">No. of ID card Printed : </p>
							
							</div>
							
							<div class="col-12 col-sm-8">
							
								<p><?php echo $pbdetails['printed'];?></p>
							
							</div>
							
						</div>
						
					</div>
                
                	<div class="col-12 col-sm-4">
                    
						<div class="row">
						
							<div class="col-12 col-sm-4">
							
								<p class="text-muted">No. of ID card Non-Printed : </p>
							
							</div>
							
							<div class="col-12 col-sm-8">
							
								<p><?php echo $pbdetails['notprinted'];?></p>
							
							</div>
							
						</div>
						
					</div>
                
                	<div class="col-12 col-sm-4">
                    
						<div class="row">
						
							<div class="col-12 col-sm-4">
							
								<p class="text-muted">Print : </p>
							
							</div>
							
							<div class="col-12 col-sm-8">
							
								<div class="form-group position-relative error-l-50 floating">

									<select class="form-control printcard" name="printcard">
										<option value=""></option>
										<option value="printall">Print All</option>
										<option value="printselected">Print Selected</option>
									</select>

								</div>
							
							</div>
							
						</div>
						
					</div>
                
                	<div class="col-12 col-sm-4">
                    
						<div class="row">
						
							<div class="col-12 col-sm-4">
							
								<p class="text-muted">Action : </p>
							
							</div>
							
							<div class="col-12 col-sm-8">
							
								<div class="form-group position-relative error-l-50 floating">

									<select class="form-control printaction" name="printaction">
										<option value=""></option>
										<option value="markprint">Mark as Print</option>
										<option value="marknotprint">Mark as Not Printed</option>
										<option value="removebatch">Remove from Batch</option>
									</select>

								</div>
							
							</div>
							
						</div>
						
					</div>
                
                	<div class="col-12 mt-3">
                    
						<div class="row">
						
							<div class="col-12 col-sm-10">
														
							</div>
							
							<div class="col-12 col-sm-2">
							
								<a href="addstudentbatchprint?bid=<?php echo $printbatchid;?>" title="Add More Student"><button class="btn btn-primary addmorebtn">Add More Student</button></a>
							
							</div>
							
						</div>
						
					</div>
				 				 
					</div>
			               				               
			   </div>
              
			<div class="d-inline-block my-3"></div>
              
            <div class="card p-4 mt-4"> 
              
               	<table id="createprinttable" class="sortable table" style="width:100%"></table>
                                    
			</div>
                                     
		</div>
                                      
       
 </div>
 
 </main>
   
    <div class="modal fade" id="EditbatchnameModal" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog modal-xl" role="document">
	<div class="modal-content">
            <div class="modal-header" style="background-color: #6884CC;height: 50px;width: auto;padding: 10px">
	  
		<h5 class="modal-title w-100" id="exampleModalLabel">
		
			<div class="row">
			
				<div class="col-4">
					<p class="headtitle text-left">Edit Print Book Name</p>
				</div>
				
			</div>
			
		</h5>
	 </div>
           
           <?php echo form_open('idcardbatchprint/editbatchnameSubmit', array('id' => 'editbatchnameForm')) ?>
           
            <div class="row m-4">
               
                <div class="col-12 col-sm-6" >
                    <div class="form-group position-relative error-l-50 floating">
                      <input placeholder=" " type="text" name="editbatchname" id="editbatchname" class="form-control">
                      <input type="hidden" class="" name="printbatchid" id="printbatchid" value="<?php echo $printbatchid; ?>" >
                       <label for="editbatchname">Print Book Name <span>*</span></label>
                    </div>
				</div>
       	
        	</div> 
        
        <?php echo form_close() ?>
        
	  <div class="modal-footer">
                     <div class="form-group"> <span class="eresponse"></span></div>
	 			 <div class="form-group"> 
	 			 
					<button type="button" class="btn btn-primary paycancel float-left" data-dismiss="modal">Cancel</button>
					
				</div> 
				<div class="form-group">
				
					<button type="button" class="btn btn-primary previewbtn float-right editsave" >Save</button>
                
                </div> 
             
        
	  </div>
	</div>
  </div>
  </div>
    
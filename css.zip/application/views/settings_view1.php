
<style type="text/css">

.course-container {
    
    box-shadow: 3px 3px 3px #eee;
    -webkit-box-shadow:3px 3px 3px #eee;
    -moz-box-shadow:3px 3px 3px #eee;
    padding-top: 20px;
    
    width:98%;
    background: #fff;
    padding-left: 20px;
    border-radius: 10px;
    
}

.content {
  background: #FFF url('<?php echo base_url(); ?>/images/right.png') no-repeat center left;
  background-position-x: 100%;
  background-position-y: 30px;
  border-bottom: 0.5px solid #D7DFF0;
  padding-bottom: 0px;
  width: 90% !important;
  padding-left: 0px !important;
  padding-bottom: 0px !important;
}

.row-element { margin: 0px !important;}
</style>

<div class="wrap dynamic-width" style="float: left;position: relative;min-width: 800px">
     <div style="margin-top: 10px; width: 99%; height: 50px; text-align: right;">
         <span style="font-weight: bold;font-size: 20px;padding: 10px;float:left;color: #364159">Settings</span>
         </div>         
            <div class="course-container" class="add-course">
                        
             <?php if(isset($roleaccess['Locations'][3]) && $roleaccess['Locations'][3]=="y"){ ?> 
                                          
                <div class="row-element">
                    <a href="location" style="cursor: pointer">
                    <span class="content">
                      
                         <label style="cursor: pointer;color:#536485;background: none;border: 0px;width: 48%;height: auto;float:left;">
                         <span  id="Location" name="location" class="yearofpassing qualification_year" style="font-size: 13px;float:left">
                             <p style="font-size: 16px;color: #364159;margin: 5px;font-weight: bold;">Location</p>
                            <p style="font-size: 12px;color: #A2B4DA;margin: 5px">Add or edit course location</p>
                        </span>
                         </label>
                        </span>
                     </a>
                </div>
                
             <?php } ?>
               
             <?php if(isset($roleaccess['City'][3]) && $roleaccess['City'][3]=="y"){ ?> 
                
                <div class="row-element">
                    <a href="city" style="cursor: pointer">
                    <span class="content">
                      
                         <label style="cursor: pointer;color:#536485;background: none;border: 0px;width: 48%;height: auto;float:left;">
                         <span  id="City" name="city" class="yearofpassing qualification_year" style="font-size: 13px;float:left">
                             <p style="font-size: 16px;color: #364159;margin: 5px;font-weight: bold;">City</p>
                            <p style="font-size: 12px;color: #A2B4DA;margin: 5px">Add or edit screening test city</p>
                        </span>
                         </label>
                        </span>
                     </a>
                </div>
                
             <?php } ?>
               
             <?php if(isset($roleaccess['Centers'][3]) && $roleaccess['Centers'][3]=="y"){ ?>
                
                <div class="row-element">
                    <a href="center" style="cursor: pointer">
                    <span class="content">
                      
                         <label style="cursor: pointer;color:#536485;background: none;border: 0px;width: 48%;height: auto;float:left;">
                         <span  id="center" name="center" class="yearofpassing qualification_year" style="font-size: 13px;float:left">
                             <p style="font-size: 16px;color: #364159;margin: 5px;font-weight: bold;">Center</p>
                            <p style="font-size: 12px;color: #A2B4DA;margin: 5px">Add or edit screening test centers</p>
                        </span>
                         </label>
                        </span>
                     </a>
                </div>
                
             <?php } ?>
               
             <?php if(isset($roleaccess['Class'][3]) && $roleaccess['Class'][3]=="y"){ ?>
                
                 <div class="row-element">
                    <a href="stndclass" style="cursor: pointer">
                    <span class="content">
                      
                         <label style="cursor: pointer;color:#536485;background: none;border: 0px;width: 48%;height: auto;float:left;">
                         <span  id="Location" name="location" class="yearofpassing qualification_year" style="font-size: 13px;float:left">
                             <p style="font-size: 16px;color: #364159;margin: 5px;font-weight: bold;">Class</p>
                            <p style="font-size: 12px;color: #A2B4DA;margin: 5px">Add or edit class</p>
                        </span>
                         </label>
                        </span>
                     </a>
                </div>
                
             <?php } ?>
               
             <?php if(isset($roleaccess['Accounting Head'][3]) && $roleaccess['Accounting Head'][3]=="y"){ ?>
                
                 <div class="row-element">
                    <a href="accounthead" style="cursor: pointer">
                    <span class="content">
                      
                         <label style="cursor: pointer;color:#536485;background: none;border: 0px;width: 48%;height: auto;float:left;">
                         <span  id="Location" name="location" class="yearofpassing qualification_year" style="font-size: 13px;float:left">
                             <p style="font-size: 16px;color: #364159;margin: 5px;font-weight: bold;">Accounting Head</p>
                            <p style="font-size: 12px;color: #A2B4DA;margin: 5px">Add or edit Accounting Head</p>
                        </span>
                         </label>
                        </span>
                     </a>
                </div>
                
             <?php } ?>
               
             <?php if(isset($roleaccess['Users'][3]) && $roleaccess['Users'][3]=="y"){ ?>
                
                <div class="row-element">
                    <a href="users" style="cursor: pointer">
                    <span class="content">
                      
                         <label style="cursor: pointer;color:#536485;background: none;border: 0px;width: 48%;height: auto;float:left;">
                         <span  id="Users" name="users" class="yearofpassing qualification_year" style="font-size: 13px;float:left">
                             <p style="font-size: 16px;color: #364159;margin: 5px;font-weight: bold;">Users</p>
                            <p style="font-size: 12px;color: #A2B4DA;margin: 5px">Add or edit Users</p>
                        </span>
                         </label>
                        </span>
                     </a>
                </div>
                
             <?php } ?>
               
             <?php if(isset($roleaccess['User Group'][3]) && $roleaccess['User Group'][3]=="y"){ ?>
                
                 <div class="row-element">
                    <a href="usergroups" style="cursor: pointer">
                    <span class="content">
                      
                         <label style="cursor: pointer;color:#536485;background: none;border: 0px;width: 48%;height: auto;float:left;">
                         <span  id="Groupaccess" name="usergroups" class="yearofpassing qualification_year" style="font-size: 13px;float:left">
                             <p style="font-size: 16px;color: #364159;margin: 5px;font-weight: bold;">User Group</p>
                            <p style="font-size: 12px;color: #A2B4DA;margin: 5px">Add or edit Group Access</p>
                        </span>
                         </label>
                        </span>
                     </a>
                </div>
                
             <?php } ?>
               
             <?php if(isset($roleaccess['User Activation'][3]) && $roleaccess['User Activation'][3]=="y"){ ?>
                
                 <div class="row-element">
                    <a href="useractivate" style="cursor: pointer">
                    <span class="content">
                      
                         <label style="cursor: pointer;color:#536485;background: none;border: 0px;width: 48%;height: auto;float:left;">
                         <span  id="Useractivate" name="useractivate" class="yearofpassing qualification_year" style="font-size: 13px;float:left">
                             <p style="font-size: 16px;color: #364159;margin: 5px;font-weight: bold;">User Activation</p>
                            <p style="font-size: 12px;color: #A2B4DA;margin: 5px">Activate or Deactivate User</p>
                        </span>
                         </label>
                        </span>
                     </a>
                </div>
                
             <?php } ?>
               
             <?php if(isset($roleaccess['Branch'][3]) && $roleaccess['Branch'][3]=="y"){ ?>
                
                 <div class="row-element">
                    <a href="ccenter" style="cursor: pointer">
                    <span class="content">
                      
                         <label style="cursor: pointer;color:#536485;background: none;border: 0px;width: 48%;height: auto;float:left;">
                         <span  id="Useractivate" name="useractivate" class="yearofpassing qualification_year" style="font-size: 13px;float:left">
                             <p style="font-size: 16px;color: #364159;margin: 5px;font-weight: bold;">Branch</p>
                            <p style="font-size: 12px;color: #A2B4DA;margin: 5px">Add or Edit Branch</p>
                        </span>
                         </label>
                        </span>
                     </a>
                </div>
                
             <?php } ?>
                             
             <?php if(isset($roleaccess['Audit Logs'][3]) && $roleaccess['Audit Logs'][3]=="y"){ ?>
                
                 <div class="row-element">
                    <a href="auditlog" style="cursor: pointer">
                    <span class="content">
                      
                         <label style="cursor: pointer;color:#536485;background: none;border: 0px;width: 48%;height: auto;float:left;">
                         <span  id="auditlog" name="auditlog" class="yearofpassing qualification_year" style="font-size: 13px;float:left">
                             <p style="font-size: 16px;color: #364159;margin: 5px;font-weight: bold;">Audit Logs</p>
                            <p style="font-size: 12px;color: #A2B4DA;margin: 5px">View user activity logs</p>
                        </span>
                         </label>
                        </span>
                     </a>
                </div>
                
             <?php } ?>                
                              
            </div>
             
        <label style="background: none;border: 0px;width: 100%;height: 30px;">&nbsp;</label> 
      
              
        </div>
    


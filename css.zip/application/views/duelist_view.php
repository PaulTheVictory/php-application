<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/dataTables.css?v=1.5" />
<script src="<?php echo base_url(); ?>js/jquery.dataTables.js?v=1.0" type="text/javascript"></script>
 <link href="<?php  echo base_url(); ?>css/jquery-ui.min.css?v=1.4" rel="stylesheet" type="text/css" />
 <script src="<?php  echo base_url(); ?>js/jquery-ui.min.js?v=1.3" type="text/javascript"></script>
<style type="text/css">
    
.reportsTable thead tr  {
    background: #E6EBF7;

/* g8 */
border: 1px solid #D7DFF0;
box-sizing: border-box;
border-radius: 10px 10px 0px 0px;
 

}

    .reportsTable tr th {
        border-right: 0px;
    font-size: 13px;
      color: #6F83AA;
   cursor: pointer;
   text-align: center;padding: 4px;
   width: 5%;vertical-align: middle;
    }  
    
  .reportsTable tr { background: #fff;border-bottom: 1px solid #D7DFF0;}
.reportsTable tr td {
    border-right: 0px;
    padding: 5px 5px;
    text-align: center;font-size: 13px;
    vertical-align: middle;
}

    
     
    .reportsTable tr td:nth-child(4) {
  width: 15% !important;
}


.ui-selectmenu-button.ui-button{ width: 50%; padding:10px;padding-right: 0px;}
     #centers-button,#rtype-button{border: 1px solid #D7DFF0;background: #fff;font-size: 14px;color:#536485}
     .loader {
    display: none;
    position: absolute;
    top: 0; left: 0; right: 0; bottom: 0;
    background: rgba(255,255,255,0.8) url('<?php echo base_url(); ?>images/loader.gif') center center no-repeat;
    z-index: 1000;
}
</style>
<script type="text/javascript">
    
    $(window).load(function () {
    $(".loader").hide();   
    });
  
$(document).ready(function(){	

         $("#centers").selectmenu(); 
         
         
  $("#billSearch").click(function(){
     
     var center = $("#centers").val();
     var cname = $("#cname").attr('data-cname');

        if (typeof cname !== 'undefined' && cname !== false) {
                var chk = $("#cname").attr("data-cname");
                if(chk === "") { alert("Plese select course name for due list");return;}
        } else {
            alert("Plese select course name for change");return;
        }
     $(".loader").show();
     var url = 'duelist?cname='+cname+'&center='+center;
       $(location).prop('href', url);
     
  });
  
  $("#export").click(function(){
     
      var center = $("#centers").val();
     
    var cname = $("#cname").attr('data-cname');

        if (typeof cname !== 'undefined' && cname !== false) {
                var chk = $("#cname").attr("data-cname");
                if(chk === "") { alert("Plese select course name for due list");return;}
        } else {
            alert("Plese select course name for change");return;
        }
     var url = 'duelist/export?cname='+cname+'&center='+center;
       $(location).prop('href', url);
     
  });
  
  
  $("#cname").autocomplete({
            source: function (request, response) {
                $.ajax({
                    url: "courses/courseSearch",
                    contentType: "application/jsonp",
                    
                    data: {
                        term: request.term
                    },
                    success: function (data) {
                        data = $.parseJSON(data);
                        response(
                                $.map(data, function (item) {
                                    return {
                                        value: item.coursename,
                                        ide:item.ide
                                    };
                                })
                                );
                    }
                });
            },
            select: function (event, ui) {
                
                $("#cname").attr("data-cname",ui.item.ide);
                selectcenter(ui.item.ide);
          
            }
            
        })
  
                });
                
                function selectcenter(ide){
	
	$.ajax({
		type: 'POST',
		url: 'courses/GetCourseCenterList',
		data: {'ide':ide},
		success: function(response) {
                         $("#centers").selectmenu('destroy'); 
                        var obj1 = $.parseJSON(response);
                        obj1['center'] = "<option>All</option>"+obj1['center'];
			$("#centers").html(obj1['center']);
                        $("#centers").selectmenu(); 

		}

	});
	
}
</script>


<div class="wrap dynamic-width" style="float: left;position: relative;">
   
    <div style="margin-top: 10px; width: 100%; height:310px; text-align: right;">       
             <span style="font-weight: bold;font-size: 20px;padding: 10px;float:left;color: #364159">Due Report Summary</span>
             <div class="row-element">
                 <span class="title" style="padding: 0px;padding-left: 10px;color: #6F83AA;margin-top: 14px;">Course Name</span>                    
                    <span class="content" style="padding: 0px;color:#0332AA;font-weight: bold;width:39%">
                        <input placeholder="Enter Course Name" data-cname="<?php echo $cid;?>" value="<?php echo $cname;?>" type="text" id="cname" name = "cname" class="cname" style="width: 90%;margin: 5px;">  
                    </span>
                </div>
            
             <div class="row-element">
                 <span class="title" style="padding: 0px;padding-left: 10px;color: #6F83AA">Centers</span>                    
                    <span class="content" style="padding: 0px;color:#0332AA;font-weight: bold">
                        <select  id="centers" name = "centers" class="centers" style="width: 50%;font-size: 13px;float:left">
                            <option>All</option><?php echo $lcenters['center'];?>
                        </select>
                        </span>
                </div>
             
                        <div class="row-element">
                 <span class="title" style="padding: 0px;padding-left: 10px;color: #6F83AA;visibility: hidden">Search</span>                    
                    <span class="content" style="padding: 0px;color:#0332AA;font-weight: bold">
                       <span id="billSearch" style="cursor: pointer;margin-left:20px;font-weight: bold;font-size: 14px;padding: 5px 10px;color: #fff;border-radius:5px;background: linear-gradient(180deg, #4F70C4 0%, #1C47B3 100%);">Search</span>
                       
                              
             			<?php if(isset($roleaccess['Due List Export'][3]) && $roleaccess['Due List Export'][3]=="y"){ ?>                  
                      		 <span id="export" style="cursor: pointer;margin-left:20px;font-weight: bold;font-size: 14px;padding: 5px 10px;color: #fff;border-radius:5px;background: linear-gradient(180deg, #4F70C4 0%, #1C47B3 100%);">Export</span>    
                        <?php } ?>                
                        
                    </span>    
                    </span>
                </div>
             
             
            </div>  

    <div class="row-element" style="margin-top: 0px"><div class="loader"></div>
        <table class="reportsTable">
            
                
                <?php 
                      
                    $html = '<thead><tr><th>S.no</th><th >Student ID</th><th >Student Name</th>><th>Country Code</th><th>Registered Mobile No</th><th>Country Code</th><th>Father Mobile No</th><th>Country Code</th><th>Mother Mobile No</th><th>Comments</th><th>Stream</th><th>Type</th><th>Course Name</th><th>Centre</th><th>Batch</th><th>Total Fee (With GST)</th><th>Total Fee (without GST)</th><th>Active Fee (without GST)</th><th>Active Discount</th><th>Given By</th><th>Reason</th><th>Remarks</th><th>To be paid (wihtout GST)</th><th>Paid (wihtout GST)</th><th>Net Due</th><th>GST+KF</th><th>KF Adjust</th><th>Total due</th><th>Course Change From</th><th>Course due date</th><th>Final due date</th></tr></thead>';
                    $i = 1;
                    foreach ($reports as $key=>$val){
                       
                        $html .= '<tr><td>'.$i.'</td><td>'.$val['studid'].'</td><td>'.$val['sname'].'</td><td>'.$val['mcode'].'</td><td>'.$val['mobile'].'</td><td>'.$val['fcountrycode'].'</td><td>'.$val['fatherphone'].'</td><td>'.$val['mcountrycode'].'</td><td>'.$val['motherphone'].'</td><td>'.$val['comments'].'</td><td>'.$val['stream'].'</td><td>'.$val['type'].'</td><td>'.$val['coursename'].'</td><td>'.$val['center'].'</td><td></td><td>'.$val['total'].'</td><td>'.$val['totalw'].'</td><td>'.$val['atotal'].'</td><td>'.$val['discount'].'</td><td>'.$val['givenby'].'</td><td>'.$val['reason'].'</td><td>'.$val['remarks'].'</td><td>'.$val['tobepaid'].'</td><td>'.$val['paid'].'</td><td>'.$val['netdue'].'</td><td>'.$val['gst'].'</td><td>'.$val['kfadjust'].'</td><td>'.$val['totaldue'].'</td><td>'.$val['coursenamefrom'].'</td><td></td><td></td></tr>';
                        $i++;
                        
                    }
                    
                    if($i === 1) { echo '<tr><td colspan="30">No data available</td></tr>';} 
                    echo $html;
                    
                 
               
                 
                 ?>
        </table>
              
         
        </div>
        
        </div>
    
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/dataTables.css?v=1.5" />
<script src="<?php echo base_url(); ?>js/jquery.dataTables.js?v=1.0" type="text/javascript"></script>
<link rel="stylesheet" href="<?php echo base_url();?>css/boot/bootstrap.min.css">
<link rel="stylesheet" href="<?php echo base_url();?>css/boot/main.css?v=1">
<script src="<?php echo base_url();?>js/bootstrap.bundle.min.js"></script>
<link href="<?php  echo base_url(); ?>css/jquery-ui.min.css?v=1.4" rel="stylesheet" type="text/css" />
 <script src="<?php  echo base_url(); ?>js/jquery-ui.min.js?v=1.3" type="text/javascript"></script>
<style type="text/css">


.dataTables_wrapper input[type="text"] {
    padding: 0;
}
.dataTables_wrapper select {
    padding: 0;
}

.sortable thead tr  {
    background: #E6EBF7;

/* g8 */
border: 1px solid #D7DFF0;
box-sizing: border-box;
border-radius: 10px 10px 0px 0px;
 
}

.sortable tr td:nth-child(4) {
  text-align: left;
}

.sortable tr td:nth-child(5) {
  text-align: left;
}

.sortable tr td:nth-child(6) {
  text-align: left;
}

.sortable tr th:nth-child(4) {
  text-align: left;
}

.sortable tr th:nth-child(5) {
  text-align: left;
}

.sortable tr th:nth-child(6) {
  text-align: left;
}


.sortable tr th {
    border-right: 0px;
    padding: 12px 0 12px 4px;font-size: 13px;
      color: #6F83AA;
   cursor: pointer;
   text-align: center;

}

.dataTables_info { display: none; }
#addpaymenttable_paginate { display: none;}
#addpaymenttable_filter input {display:none;}

.sortable tr td {
    border-right: 0px;
    padding: 5px 5px;
    text-align: center;font-size: 13px;
    min-width:50px;vertical-align: middle;
}
.sortable tr td a {
    color: #364159;
}

#profile-right h2 {
    margin: 0px 0px 10px 0px;
}
#unpaidtable_filter input { padding-top:4px;background: #fff url('<?php echo base_url(); ?>/images/search.png') no-repeat center left;background-position-x: 10px;border: 1px solid #D7DFF0; line-height: 32px;margin-left: 10px;width:260px;border-radius: 5px;text-indent: 30px;font-size: 13px;}

.sortable tr td a:hover { text-decoration: underline; }
.dataTables_filter { right:10px !important;}
	
.btn-outline-primary {color: #0332AA;border-color: #0332AA;}
.btn {border-radius: 5px;outline: initial!important;box-shadow: none!important;box-shadow: initial!important;font-size: .8rem;padding: .5rem 1.25rem .5rem 1.25rem;transition: background-color box-shadow .1s linear;margin-bottom: 7px}
.btn-outline-primary:not(:disabled):not(.disabled).active, .btn-outline-primary:not(:disabled):not(.disabled):active, .show>.btn-outline-primary.dropdown-toggle,.btn-outline-primary:hover {background-color: #0332AA;border-color: #0332AA;color: #fff;}	
	
.ui-selectmenu-button.ui-button{ width: 125px;margin-top: 10px;float: right;border: 1px solid #D7DFF0;background: #fff;font-size: 13px;color:#536485;padding: 8px;margin-bottom: 4px;}
.ui-menu-item .ui-menu-item-wrapper{font-size: 13px}
	
	p.preview{color: #6884CC;font-weight: 600;font-size: 1rem;}
	p.preview span{font-weight: 600;color: #364159;font-size: 1rem;}
	
</style>
<script type="text/javascript">
	
	var searchcol = "";
	
$(document).ready(function(){	
		
	
	$("#searchtype").selectmenu();
		
	
	 $(document).delegate("#searchtype","selectmenuchange",function(event){
         
		 //oTable.fnDraw();
		 
	});
	
	 $(document).on("click",".clear",function(){
		
		$("#searchtype").selectmenu('destroy');
	    $("#searchtype").prop('selectedIndex',0);
	    $("#searchtype").selectmenu();
		
	});
	
	
	var oTable2 = "";
          var columnData = [
              
                    { "data": "created_at","searchable": false },
                    { "data": "studid" },
                    { "data": "challanno" },    
                    <?php if($type==="paid"){ echo '{"data":"paydate","searchable": false},';}?>
                    <?php if($type==="paid"){ echo '{"data":"receiptno"},';}?>
                                
                    { "data": "sname" },
                    { "data": "coursename" },                   
                    { "data": "center" ,"searchable": false},
                    { "data": "unpaid" , "searchable": false},
                    <?php if($type==="paid"){ echo '{"data":"paymode","searchable": false},';}?>
                    { "data": "ide" , "searchable": false}
                    
                    
                  ];
       
        var oTable = $('#unpaidtable').dataTable({
					"bProcessing": true,
                    "bServerSide": true,
                    "sPaginationType": "full_numbers",
                    "ajax": {
                    "url": 'payments/getPaymentLists',
                    "type": "POST",
                    "data":function(data){ 
						
						var searchtype = $("#searchtype").val();
						
						data.type= "<?php echo $type; ?>";
						data.searchcol= searchtype;
						
						}
                     }, 
                     "oLanguage": {
                        "sProcessing": "<img src='<?php echo base_url(); ?>images/loader.gif'>"
                    },
                    'iDisplayLength': 20,
                    "columns": columnData,
                    
                    "order": [0,"desc"],
                    "fnDrawCallback": function( oSettings ) {
                        
                         $("#unpaidtable_filter").find("input").focus();
                        var count = 1;
                        $('#unpaidtable').find("tr .sno").each(function(){
                           
                            $(this).text(count);
                            count++;
                            
                            $(this).closest("tr").find(".addpay").click(function(){
                                
                                $(".amtpaid").val(0);
                                $(".courseconfirm").trigger('click'); 
                                var challan = $(this).attr("data-chno");
                                var sid = $(this).attr("data-sid");
                                var cid = $(this).attr("data-cid");
                                var crid = $(this).attr("data-crid");
                                
                                $(".paysave").attr("data-attr",challan);
                                $(".paysave").attr("data-sid",sid);
                                $(".paysave").attr("data-cid",cid);
                                $(".paysave").attr("data-crid",crid);
                                
                                getAddPayments(challan,cid,sid); 
                                
                            });
							
							// Edit payment 
							
							$(this).closest("tr").find(".editpay").click(function(){
                                
                                $(".amtpaid").val(0);
                                $('#courseModal').modal({show:true});
                                var challan = $(this).attr("data-chno");
                                var sid = $(this).attr("data-sid");
                                var cid = $(this).attr("data-cid");
                                var crid = $(this).attr("data-crid");
                                var billno = $(this).attr("data-billno");
                                
                                $(".paysave").attr("data-attr",challan);
                                $(".paysave").attr("data-sid",sid);
                                $(".paysave").attr("data-cid",cid);
                                $(".paysave").attr("data-crid",crid);
                                $(".paysave").attr("data-billno",billno);
                                
                                getEditPayments(challan,cid,sid); 
                                
                            });
                                                        
                            var t = $(this).closest("tr").find(".sname").text();
                            $(this).closest("tr").find(".sname").text(t.toUpperCase());
                            
                        });
                        
                   
                    },"initComplete" : function() {
						
						var input = $('.dataTables_filter input').unbind(),
							self = this.api(),
							$searchButton = $('<button class="btn btn-outline-primary ml-3 search">')
									   .text('search')
									   .click(function() {
										  self.search(input.val()).draw();
									   }),
							$clearButton = $('<button class="btn btn-outline-primary ml-3 clear">')
									   .text('clear')
									   .click(function() {
										  input.val('');
										  $searchButton.click(); 
									   }) 
						$('.dataTables_filter').append($searchButton, $clearButton);
                                                
                                                 $(input).keyup(function(event){
                                                    if(event.keyCode == 13){
                                                        event.preventDefault();
                                                        $('.search').trigger('click');
                                                    }
                                                });
					}
         }); 
         
         
         
         function getAddPayments(challan,cid,sid) {
  
  var columnData2 = [
                    { "data": "desc_order" },
                    { "data": "description" },
                    { "data": "amount" },
                    { "data": "discount" },
                    { "data": "tax" },
                    { "data": "kf" },
                    { "data": "cov" },
                    { "data": "roundoff" },
                    { "data": "total" },
                    { "data": "paid" }
                    
                  ];
   oTable2 = $('#addpaymenttable').dataTable({
                    "bProcessing": true,
                    "bServerSide": true,
                    "sPaginationType": "full_numbers",
                    "ajax": {
                    "url": 'viewrequest/getAddPaymentLists',
                    "type": "POST",
                    "data":{ "ide": challan,"cid": cid
                        ,"sid":sid}
                     }, 
                     "oLanguage": {
                        "sProcessing": "<img src='<?php echo base_url(); ?>images/loader.gif'>"
                    },
                    'iDisplayLength': 20,
                    "columns": columnData2,
                    "order": [[ 0, "asc" ]],
                    "fnDrawCallback": function( oSettings ) {
						
						var data = this.fnGetData();//console.log(data);
						
						if(data.length > 0){
							var studid = data[0].studid;
							var sname = data[0].sname;

							$(".studname").text(sname);
							$(".studno").text(studid);
						}
						
                        var count = 1;       var total = 0;             
                        $('#addpaymenttable').find("tr .desc").each(function(){
                            
                            total = total+parseFloat($(this).closest("tr").find(".total").text());
        
                          });
                          
                         $(".paymode").val("");$(".paymode").trigger("change");
                          
                       $(".ptotal").text(total);    
                         $(".amtpaid").val(total);
                       $(".amtpaid").trigger("keyup");
                                      
                    }
         }); 
         }
         
         /*$(".paycancel").click(function(){
             oTable2.fnDestroy();
         });*/
         
         
               $(document).delegate(".amtpaid","keyup",function(event){
     
            if(!numCheck(this)) { alert('invalid key'); return;}  
      
            var paid = $(this).val(); var tpaid = $(this).val(); var totamt = $(".ptotal").text();
            
            $("#addpaymenttable").find("tr").each(function(){
               
               var split = $(this).find(".desc").attr("attr-split");
               split = (split === "")?"0":split;
               var linetotal = $(this).find(".total").text();
               $(this).find(".paid").text("0");
               if((parseFloat(paid) >= parseFloat(linetotal)) && (split === "0")){
                   $(this).find(".paid").text(linetotal);
                   paid = parseFloat(paid) - parseFloat(linetotal);
               } else if((parseFloat(paid) >= parseFloat(linetotal)) && (split === "1" || split === "-1" )){
                   $(this).find(".paid").text(linetotal);
                   paid = parseFloat(paid) - parseFloat(linetotal);
               } else if((parseFloat(paid) <= parseFloat(linetotal)) && (split === "1" || split === "-1" )){
                   $(this).find(".paid").text(paid);
                   paid = 0;
               }
                              
            });
     
            $(".ppaid").text(tpaid);
            var ty = parseFloat(totamt)-parseFloat(tpaid);
            $(".pdue").text(ty);
              
    });
    
    function numCheck(ele){

                var numchk = new RegExp("^[0-9.]*$");  
                if( numchk.test( $(ele).val() ) ){ return 1; } else { $(ele).val("");return 0;}
        }
    
    
    $(".paymode").change(function(){
      $("#pcenters").val('');$("#cperson").val('<?php echo $user['pname']; ?>');$("#prefno").val('');$("#prefno").val('');
       var type = $(this).val();
       if(type === "dd"){
           
          // $("#pcenters").closest(".col-12").css("display","none");
         //  $("#cperson").closest(".col-12").css("display","none");
           $("#prefno").closest(".col-12").css("display","block");
           $("#prefno").siblings("label").text("DD Number");
                      
           $("#prefno").parent().removeClass('hide');
		   $(".preprefno").addClass('hide').html('DD Number: <span></span>');
		   
       } else if(type === "net"){
           
        //   $("#pcenters").closest(".col-12").css("display","none");
        //   $("#cperson").closest(".col-12").css("display","none");
           $("#prefno").closest(".col-12").css("display","block");
           $("#prefno").siblings("label").text("Transaction ID");
		   
		   $("#prefno").parent().removeClass('hide');
		   $(".preprefno").addClass('hide').html('Transaction ID: <span></span>');
           
       } else if((type === "upi")||(type === "card")||(type === "challan")||(type === "cheque")||(type === "online")){
           
           var ltext = "";
           if(type === "upi") { ltext = "Received Number";} else if(type === "card"){ ltext = "Reference number";}
           else if(type === "challan"){ ltext = "Challan number";}else if(type === "cheque"){ ltext = "Cheque Number";}
           else if(type === "online"){ ltext = "Transaction ID";}
         //  $("#pcenters").closest(".col-12").css("display","none");
         //  $("#cperson").closest(".col-12").css("display","none");
           $("#prefno").closest(".col-12").css("display","block");
           $("#prefno").siblings("label").text(ltext);
		   
		   $("#prefno").parent().removeClass('hide');
		   $(".preprefno").addClass('hide').html(ltext+': <span></span>');
           
       }else if(type === "cash"){
           
           $("#prefno").closest(".col-12").css("display","none");
		   
		   $("#prefno").parent().addClass('hide');
           $("#prefno").closest(".col-12").css("display","none");
           
       }else {
          // $("#pcenters").closest(".col-12").css("display","none");
         //  $("#cperson").closest(".col-12").css("display","none");
           $("#prefno").closest(".col-12").css("display","none");
		   
		   $("#prefno").parent().addClass('hide');
           $("#prefno").closest(".col-12").css("display","none");
       }
    });
    
         
      $(".paysave").click(function(){
        
        if($(this).hasClass("progressing")) { return;}
       
       $(this).addClass("progressing");
       var chno = $(this).attr("data-attr");
       var sid = $(this).attr("data-sid");
       var cid = $(this).attr("data-cid");
       var crid = $(this).attr("data-crid");
       var pdate = $("#pdate").val();
       var ptime = $("#ptime").val();
       var amtpaid = $("#amtpaid").val();
		  
		var type = "<?php echo $type;?>";
		var billno = $(this).attr("data-billno"); 
		  
		  
	   var adminpassword = $("#adminpassword").val();
		  
		  var cperson = "<?php echo $user['pname']; ?>";
       
       amtpaid = (amtpaid === "")?0:amtpaid;
       amtpaid = parseFloat(amtpaid);
       if(amtpaid <= 0) { alert("Payment is should more than Zero");$(this).removeClass("progressing");return;}
       
       var paymode = $("#paymode").val();
       if(paymode === "") { alert("Payment mode is mandatory");$(this).removeClass("progressing");return;}
       if($("#pcenters").val() === "") { alert("Center is mandatory");$(this).removeClass("progressing");return;}
       if(cperson === "") { alert("Cash counter person is mandatory");$(this).removeClass("progressing");return;}
       if(($("#prefno").val() === "")&&(paymode !== "cash")) { alert("Reference no is mandatory");$(this).removeClass("progressing");return;}
       var paydescription = "";
       if(paymode === "cash") { paydescription = $("#pcenters").val()+"|"+cperson; }
       else { paydescription = $("#pcenters").val()+"|"+cperson+"|"+$("#prefno").val();}
      
       
        $.get('viewrequest/addPayment',{
                 'chno':chno,'pdate':pdate,'ptime':ptime,'paymode':paymode,'pdescription':paydescription,'amtpaid':amtpaid,"ide": cid,"billno":billno,"type":type,"adminpassword":adminpassword
                        ,"studid":sid

                 }, function(o) { 
                         var obj1 = $.parseJSON(o);
                if (obj1[0] === 'success') {
                     
                      $('#courseModal').modal('hide');
                     $('#paydoneModal').modal({show:true});
                      var view = '<?php echo base_url()."stufeebill?crid="?>'+crid+'&cno='+chno+'&userid='+sid;
                      $("#paydoneModal").find(".bill_view").attr("href",view);
                      $("#paydoneModal").find("a").attr('href',view);
                      $("#paydoneModal").find(".bill_view").click(function(){
                        $('#paydoneModal').modal('hide');
                      });
                      $(".paysave").removeClass("progressing"); $(".ppaid").text("0");
                      $(".pdue").text("0");
                      oTable.fnDraw();oTable2.fnDestroy();
                      

                 }else if (obj1[0] === 'passfail') {
					 
					 alert('Password mismatch.');
					 $(".paysave").removeClass("progressing");

             	}else if (obj1[0] === 'fail') {
					 alert('Payment add or update failed');
             	}
        });
        
       
       
    });
	
	$(".previewbtn").click(function(){
               
       var pdate = $("#pdate").val();
       var ptime = $("#ptime").val();
       var amtpaid = $("#amtpaid").val();
       var paymode = $("#paymode").val();
		 
		 var pcenters = $("#pcenters").val();
		 //var cperson = $(".cperson").val();
		 var cperson = "<?php echo $user['pname']; ?>";
		 var prefno = $("#prefno").val();
		
		var paymodetxt = $("#paymode option:checked").text();
		 
       amtpaid = (amtpaid === "")?0:amtpaid;
       amtpaid = parseFloat(amtpaid);
		 
       if(amtpaid <= 0) { alert("Payment is should more than Zero");$(this).removeClass("progress");return;}
		 
       if(paymode === "") { alert("Payment mode is mandatory");$(this).removeClass("progress");return;}
		 
       if($("#pcenters").val() === "") { alert("Center is mandatory");$(this).removeClass("progress");return;}
		 
       if(cperson === "") { alert("Cash counter person is mandatory");$(this).removeClass("progress");return;}
		 
       if(($("#prefno").val() === "")&&(paymode !== "cash")) { alert("Reference no is mandatory");$(this).removeClass("progress");return;}
		 
		 $(".prepaymode").prev(".form-group").addClass('hide');
		 $(".prepaymode").removeClass('hide').find('span').text(paymodetxt);
		 
		 $(".preamtpaid").prev(".form-group").addClass('hide');
		 $(".preamtpaid").removeClass('hide').find('span').text(amtpaid);
		 
       if(paymode === "cash") {
		   $(".prepcenters").prev(".form-group").addClass('hide');
		    $(".prepcenters").removeClass('hide').find('span').text(pcenters);
		   
		   $(".precperson").prev(".form-group").addClass('hide');
			$(".precperson").removeClass('hide').find('span').text(cperson);
		   
		    $(".preprefno").prev(".form-group").removeClass('hide');
		    $(".preprefno").addClass('hide').find('span').text("");
		   
	   }else { 
		   
		   $(".prepcenters").prev(".form-group").addClass('hide');
		   $(".prepcenters").removeClass('hide').find('span').text(pcenters);
		   
		   $(".precperson").prev(".form-group").addClass('hide');
		   $(".precperson").removeClass('hide').find('span').text(cperson);
		   
		   $(".preprefno").prev(".form-group").addClass('hide');
		   $(".preprefno").removeClass('hide').find('span').text(prefno);
	   }
		 
		 
		 $(".previewbtn").addClass('hide');
		 $(".backbtn,.paysave").removeClass('hide');
      
          
    });
	
	
	$(".backbtn").click(function(){
               
       var pdate = $("#pdate").val();
       var ptime = $("#ptime").val();
       var amtpaid = $("#amtpaid").val();
       var paymode = $("#paymode").val();
		 
		 var pcenters = $("#pcenters").val();
		 var cperson = $(".cperson").val();
		 var prefno = $("#prefno").val();
		 
       amtpaid = (amtpaid === "")?0:amtpaid;
       amtpaid = parseFloat(amtpaid);
		 		 
		 $(".prepaymode").prev(".form-group").removeClass('hide');
		 $(".prepaymode").addClass('hide').find('span').text("");
		 
		 $(".preamtpaid").prev(".form-group").removeClass('hide');
		 $(".preamtpaid").addClass('hide').find('span').text("");
		 
       if(paymode === "cash") {
		   $(".prepcenters").prev(".form-group").removeClass('hide');
		    $(".prepcenters").addClass('hide').find('span').text("");
		   
		   $(".precperson").prev(".form-group").removeClass('hide');
			$(".precperson").addClass('hide').find('span').text("");
		   
		    $(".preprefno").prev(".form-group").addClass('hide');
		    $(".preprefno").removeClass('hide').find('span').text("");
		   
	   }else { 
		   
		   $(".prepcenters").prev(".form-group").removeClass('hide');
		   $(".prepcenters").addClass('hide').find('span').text("");
		   
		   $(".precperson").prev(".form-group").removeClass('hide');
		   $(".precperson").addClass('hide').find('span').text("");
		   
		   $(".preprefno").prev(".form-group").removeClass('hide');
		   $(".preprefno").addClass('hide').find('span').text("");
	   }
		 
		 
		 $(".previewbtn").removeClass('hide');
		 $(".backbtn,.paysave").addClass('hide');
      
          
    });
	
	
	$('#courseModal').on('hidden.bs.modal', function () {
  		
		
		var totamt = $(".ptotal").text();
		
		var pdate = $("#pdate").val("");
       var ptime = $("#ptime").val("");
       var amtpaid = $("#amtpaid").val(totamt);
       var paymode = $("#paymode").val("");
		 
		 var pcenters = $("#pcenters").val("");
		 var cperson = $(".cperson").val("<?php echo $user['pname']; ?>");
		 var prefno = $("#prefno").val("");
		
		$("#adminpassword").val("");
				
		 $(".prepaymode").prev(".form-group").removeClass('hide');
		 $(".prepaymode").addClass('hide').find('span').text("");
		 
		 $(".preamtpaid").prev(".form-group").removeClass('hide');
		 $(".preamtpaid").addClass('hide').find('span').text("");
		 
      
		   $(".prepcenters").prev(".form-group").removeClass('hide');
		   $(".prepcenters").addClass('hide').find('span').text("");

		   $(".precperson").prev(".form-group").removeClass('hide');
		   $(".precperson").addClass('hide').find('span').text("");

		   $(".preprefno").prev(".form-group").removeClass('hide');
		   $(".preprefno").addClass('hide').find('span').text("");
		 
		 
		 $(".previewbtn").removeClass('hide');
		 $(".backbtn,.paysave").addClass('hide');
		
		oTable2.fnDraw();oTable2.fnDestroy();
		
	});
	
	
	// Edit Payment 
	
	
function getEditPayments(challan,cid,sid) {
  
  var columnData2 = [
                    { "data": "desc_order" },
                    { "data": "description" },
                    { "data": "amount" },
                    { "data": "discount" },
                    { "data": "tax" },
                    { "data": "kf" },
                    { "data": "cov" },
                    { "data": "roundoff" },
                    { "data": "total" },
                    { "data": "paid" }
                    
                  ];
   oTable2 = $('#addpaymenttable').dataTable({
                    "bProcessing": true,
                    "bServerSide": true,
                    "sPaginationType": "full_numbers",
                    "ajax": {
                    "url": 'viewrequest/getEditPaymentLists',
                    "type": "POST",
                    "data":{ "ide": challan,"cid": cid,"sid":sid}
                     }, 
                     "oLanguage": {
                        "sProcessing": "<img src='<?php echo base_url(); ?>images/loader.gif'>"
                    },
                    'iDisplayLength': 20,
                    "columns": columnData2,
                    "order": [[ 0, "asc" ]],
                    "fnDrawCallback": function( oSettings ) {
                        var count = 1;       var total = 0;  
						
						var data = this.fnGetData();//console.log(data);
						
						if(data.length > 0){
						
							var paydescription = data[0].paydescription;
							var paymentmode = data[0].paymentmode;
							var studid = data[0].studid;
							var sname = data[0].sname;

							var paydescarr = paydescription.split("|");//console.log(paydescarr);
							
							$(".studname").text(sname);
							$(".studno").text(studid);

							$('#paymode').val(paymentmode).change();

							var pcenters = paydescarr[0];
							var cperson = paydescarr[1];
							if(paymentmode!="cash") var prefno = paydescarr[2]; else var prefno = "";

							$("#pcenters").val(pcenters);
							$("#cperson").val(cperson);
							$("#prefno").val(prefno);
							
						}
						
                        $('#addpaymenttable').find("tr .desc").each(function(){
                            
                            total = total+parseFloat($(this).closest("tr").find(".total").text());
        
                          });
                          
                         //$(".paymode").val("");$(".paymode").trigger("change");
                          
                       $(".ptotal").text(total);    
                         $(".amtpaid").val(total);
                       $(".amtpaid").trigger("keyup");
                                      
                    }
         }); 
 }
	
	
});
</script>


<div class="wrap dynamic-width" style="float: left;position: relative">
    
    <div style="margin-top: 10px; width: 100%; height: 50px; text-align: right;">
             <span style="font-weight: bold;font-size: 20px;padding: 10px;float:left;color: #364159"><?php if($type==="paid"){ echo "Paid"; } else { echo "Unpaid Challan"; }?> Lists</span>
            </div>
            
            <div class="row align-items-end">
                 <div class="col-7">
                     <select id="searchtype">
                         <option value="stuid">Student ID</option>
                         <option value="stuname">Student Name</option>
                         <?php if($type==="paid"){?><option value="billno">Bill No</option><?php }?>
                         <option value="courseid">Course ID</option>
                         <option value="coursename">Course Name</option>
                         <option value="center">Center</option>
                     </select>
                 </div>                                                                           
    		</div> 
            
			<table class="sortable disabled table table-bordered" id="unpaidtable">
				<thead>
					   <th>SNO</th>
					   <th>STD ID</th>
					   <th>CHL ID</th>
					   <?php if($type==="paid"){?>
					   
					   <th>DATE</th>
					   <th>BILL NO</th>
					   
					   <?php }?>
					   
					   <th>STUDENT NAME</th>
					   <th>COURSE NAME</th>
					   <th>CENTER</th>
					   
					   <?php if($type==="paid"){?>
					   <th>PAID</th>
					   <?php }else{?>
					   <th>UNPAID</th>
					   <?php }?>
					   
					   <?php if($type==="paid"){?>
					   <th>PAYMENT MODE</th>
					   <?php }?>
					   
					   <th>ACTION</th>
					   
				</thead>				
		   </table>
                        
         <?php //echo $this->table->generate();  ?>             
         
         <style>

	.courseredirect{background: #3CAF92 !important;display: block;margin: auto;border: 1px solid #209679;}
	h5.modal-title p.headtitle{display: inline-block;width: 100%;text-align: center;font-weight: bold;font-size:17px;color: #fff;}
	h5.modal-title p.text-muted{display: inline-block;width: 100%;text-align: center;font-weight: 600;font-size: 14px;line-height: 36px;color: #181E29;line-height: 20px;}
	.modal-title img{display: block;margin: 1em auto}
        #paydoneModal.modal .modal-header,#payfailModal.modal .modal-header{padding: 10px 20px !important;border: none}	
		#paydoneModal.modal .modal-body,#payfailModal.modal .modal-body{padding:0 1.75rem 1.75rem}
		.modal-body p{text-align: left !important}
		.modal-backdrop.show {opacity: .5 !important;}
			 
			  .hide{display: none}
			 
			 input.form-control:disabled ~ label,select.form-control:disabled ~ label {transform: translate(1px,-122%) scale(0.80);opacity: 1;color: #536485;font-size: 12px;}
			 
	</style>
<button type="button" class="btn btn-outline-primary d-none courseconfirm" data-toggle="modal" data-backdrop="static" data-target="#courseModal">Confirm Submission</button>  
<!-- Modal -->

<?php if((isset($roleaccess['Bill List'][1]) && $roleaccess['Bill List'][1]=="y") || isset($roleaccess['Unpaid List'][0]) && $roleaccess['Unpaid List'][0]=="y"){ ?>

<div class="modal fade" id="courseModal" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog modal-xl" role="document">
	<div class="modal-content">
            <div class="modal-header" style="background-color: #6884CC;height: 50px;width: auto;padding: 10px">
	  
		<h5 class="modal-title w-100" id="exampleModalLabel">
		
			<div class="row">
			
				<div class="col-4">
					<p class="headtitle text-left"><?php if($type=="paid") {echo "Edit";}else {echo "Add";} ?> Payment</p>
				</div>
				<div class="col-8">
					<p class="headtitle text-right pr-3"> Student Name: <span class="studname mr-3"></span> Student ID: <span class="studno"></span></p>
				</div>
			</div>
			
		</h5>
	 </div>
            <div class="row" style="width: 98%;margin: 0px auto;margin-top: 25px;">
                <div class="col-12 col-sm-6" style="display: none">
                    <div class="form-group position-relative error-l-50 floating">
                      <input type="text" value="<?php date_default_timezone_set('Asia/Kolkata'); echo date("d/m/Y"); ?>" class="form-control" name="pdate" id="pdate" required  placeholder=" " >
                     <label for="date">Date <span>*</span></label>
                    </div>
                    
                    <p class="preview prepdate hide">Date: <span></span></p>
                    
		</div>
                <div class="col-12 col-sm-6" style="display: none">
                    <div class="form-group position-relative error-l-50 floating">
                        <input type="text" value="<?php echo date("h:i a"); ?>" class="form-control" name="ptime" id="ptime"   placeholder=" " >
                     <label for="time">Time <span>*</span></label>
                    </div>
                    
                    <p class="preview preptime hide">Time: <span></span></p>
		</div>
                <div class="col-12 col-sm-6">
              <div class="form-group position-relative error-l-50 floating">
                <select class="form-control paymode floating" id="paymode" name="paymode" required  >
                  <option value=""></option>
                  <option value="cash">Cash Counter Person</option>
                    <option value="online">Online Counter</option> 
                  <option value="dd">Demand Draft</option>
                  <option value="net">Netbanking</option>
                  <option value="upi">Gpay/Phonepe/UPI</option>     
                  <option value="card">Card</option> 
                  <option value="challan">Challan</option> 
                  <option value="cheque">Cheque</option> 
                
                </select>
                <label>Payment Mode <span>*</span></label>
              </div>
              
              <p class="preview prepaymode hide">Payment Mode: <span></span></p>
              
              </div>
               <div class="col-12 col-sm-6">
                    <div class="form-group position-relative error-l-50 floating">
                      <input type="text" class="form-control amtpaid" name="amtpaid" id="amtpaid" required  placeholder=" " >
                     <label for="date">Amount Paid <span>*</span></label>
                    </div>
                    
                    <p class="preview preamtpaid hide">Amount Paid: <span></span></p>
                    
		</div> 
                
                <div class="col-12 col-sm-6" >
              <div class="form-group position-relative error-l-50 floating">
                <select class="form-control pcenters floating" id="pcenters" name="pcenters" required  >
                  <option value=""></option>
                  <?php 
						
						if(!empty($user['centers']) && !in_array("All",$user['centers'])){
							
							foreach($user['centers'] as $ccenters){
								
								echo '<option>'.$ccenters.'</option>';
								
							}
							
						}else{
							//echo $units; 
							echo $branch;
						}
				  					
					?>                              
                </select>
                <label>Center <span>*</span></label>
              </div>
              
              <p class="preview prepcenters hide">Center: <span></span></p>
              
              </div> 
                
               <div class="col-12 col-sm-6" >
                    <div class="form-group position-relative error-l-50 floating">
                      <input type="text" class="form-control cperson" name="cperson" id="cperson" required  placeholder=" " value="<?php echo $user['pname']; ?>" disabled >
                     <label for="date">Cash Counter Person <span>*</span></label>
                    </div>
                    
                    <p class="preview precperson hide">Cash Counter Person: <span></span></p>
                    
		</div>  
                
                <div class="col-12 <?php if($type=="paid"){ echo 'col-sm-6';}else{echo 'col-sm-12';}?>" style="display: none">
                    <div class="form-group position-relative error-l-50 floating">
                      <input type="text" class="form-control prefno" name="prefno" id="prefno" required  placeholder=" " >
                     <label for="date">DD Number <span>*</span></label>
                    </div>
                    
                    <p class="preview hide preprefno">DD Number: <span></span></p>
                    
		</div>  
          
          <?php if($type=="paid"){?>
          
			 <div class="col-12 col-sm-6">

				<div class="form-group position-relative error-l-50 floating">
				  <input type="password" class="form-control adminpassword" name="adminpassword" id="adminpassword" required  placeholder=" " >
				 <label for="date">Enter Password <span>*</span></label>
				</div>

			</div>  
        
        <?php }?>
                
            </div>
	  <span style=";font-size: 17px;padding: 10px;float:left;color: #364159">Payment Details</span>
          <?php
           $this->table->clear();
         $tmpl = array('table_open' => '<table class="sortable disabled" id="addpaymenttable" style="width:98% !important;">');                 
         $this->table->set_template($tmpl);
         $this->table->set_heading('S.NO', 'PAYMENT FOR','AMOUNT', 'DISCOUNT','GST(%)','CESS KF(%)','CESS COV(%)','ROUND OFF','TOTAL','PAID');
         echo $this->table->generate();
          
          ?>
         
          <div class="row" style="width: 98%">

			<div class="col-md-12 text-right px-2">
			   <p class="list-item-heading mb-1"> <span>Total Amount:</span> <span class="ptotal" style="color: #1C47B3 !important"></span></p>
			</div>

			<div class="col-md-12 text-right px-2">
				<p class="list-item-heading mb-1"><span> Due Amount:</span> <span class="pdue" style="color: #D63333 !important"></span></p>
			</div>

			<div class="col-md-12 text-right px-2">
				<p class="list-item-heading mb-1"> <span>Total Paid:</span> <span class="ppaid" style="color: #209679 !important"></span></p>
			</div>

		</div>
        
	  <div class="modal-footer">
	  
	 			 <div class="form-group"> 
	 			 
					<button type="button" class="btn btn-primary paycancel float-left" data-dismiss="modal">Cancel</button>
					
				</div> 
				<div class="form-group">
				
					<button type="button" class="btn btn-primary previewbtn float-right" >Preview</button>
                
                </div> 
                <div class="form-group"> 
                
                	<button type="button" class="btn btn-primary backbtn float-left hide">Back</button>
                
                </div> 
                
                <div class="form-group"> 
                	<button type="button" class="btn btn-primary paysave float-right hide" ><?php if($type=="paid") {echo "Update";}else {echo "Save";} ?></button>
                
                </div> 
                
		<!--<div class="form-group"> 
                <button type="button" class="btn btn-primary paycancel float-left" data-dismiss="modal">Cancel</button>
            </div> 
                <div class="form-group"> 
                <button type="button" class="btn btn-primary paysave float-right" >Save</button>
                 </div> -->
	  </div>
	</div>
  </div>
  </div> 
    
    <?php } ?>
     
<div id="paydoneModal" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true" style="top:30%;">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
				   <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				</div>
				<div class="modal-body text-center">
									
					<img src="css/img/brilliant-logo.png" alt="Payment Success" class="mb-3" />
					<h2 class="mb-4">Payment Successful!</h2>
									
					<p>Your Payment for course registration has been updated successfully!</p>
										
				</div>
				<div class="modal-footer"><a href="" target="_blank" style="clear: both" class="bill_view">
                                        <button type="button" class="btn btn-primary vbclose">View Bill</button></a>
                                </div>
								
			</div>
		</div>
	</div>

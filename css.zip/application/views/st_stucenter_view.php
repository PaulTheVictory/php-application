<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/dataTables.css?v=1.5" />
<script src="<?php echo base_url(); ?>js/jquery.dataTables.js?v=1.0" type="text/javascript"></script>
<link rel="stylesheet" href="<?php echo base_url();?>css/boot/bootstrap.min.css">
<script src="<?php echo base_url();?>js/bootstrap.bundle.min.js"></script>
<link href="<?php  echo base_url(); ?>css/jquery-ui.min.css?v=1.4" rel="stylesheet" type="text/css" />
 <script src="<?php  echo base_url(); ?>js/jquery-ui.min.js?v=1.3" type="text/javascript"></script>
<style type="text/css">


	.dataTables_wrapper{top: 50px}
	
.dataTables_wrapper input[type="text"] {
    padding: 0;
}
.dataTables_wrapper select {
    padding: 0;
}

.sortable thead tr  {
    background: #E6EBF7;

/* g8 */
border: 1px solid #D7DFF0;
box-sizing: border-box;
border-radius: 10px 10px 0px 0px;
 

}
.sortable tr th {
    border-right: 0px;
    padding: 15px 0;font-size: 13px;
      color: #6F83AA;
   cursor: pointer;
   text-align: center;

}

.sortable tr th:nth-child(2) {
  
   text-align: left;
}

.sortable tr td:nth-child(2) {
  
   text-align: left;
}

.sortable tr th:nth-child(4) {
  
   text-align: left;
}

.sortable tr td:nth-child(4) {
  
   text-align: left;
}

/*.sortable tr th:nth-child(1) {
  width: 50px !important;
}

.sortable tr th:nth-child(2) {
    width: 10% !important;
  background: none;
   text-align: left;
}


.sortable tr th:nth-child(3) {
  background: none;
  width: 25% !important;
   text-align: center;
}

.sortable tr th:nth-child(6) {
  background: none;
  width: 20% !important;
   text-align: center;
}

.sortable tr th:nth-child(7) {
  background: none;
  width: 70px !important;
   text-align: center;
}
*/

.sortable tr td {
    border-right: 0px;
    padding: 5px 5px;
    text-align: center;font-size: 13px;
    min-width:50px;vertical-align: middle;
}
.sortable tr td a {
    color: #364159;
}

#profile-right h2 {
    margin: 0px 0px 10px 0px;
}

#studenttable_length { display: inline !important; }
#studenttable_filter input { padding-top:4px;background: #fff url('<?php echo base_url(); ?>/images/search.png') no-repeat center left;background-position-x: 10px;border: 1px solid #D7DFF0; line-height: 32px;margin-left: 10px;width:260px;border-radius: 5px;text-indent: 30px;font-size: 13px;}
.sortable tr td a:hover { text-decoration: underline; }
.dataTables_filter { right:10px !important;top: -84px}
	
.btn-outline-primary {color: #0332AA;border-color: #0332AA;background-color: transparent;font-weight: 600;font-size: .8rem;text-transform: none;margin: 0 10px}
.btn {border-radius: 5px;outline: initial!important;box-shadow: none!important;box-shadow: initial!important;font-size: .8rem;padding: .5rem 1.25rem .5rem 1.25rem;transition: background-color box-shadow .1s linear;margin-bottom: 7px}
.btn-outline-primary:not(:disabled):not(.disabled).active, .btn-outline-primary:not(:disabled):not(.disabled):active, .show>.btn-outline-primary.dropdown-toggle,.btn-outline-primary:hover {background-color: #0332AA;border-color: #0332AA;color: #fff;}
.ui-selectmenu-button.ui-button{ width: 125px;margin-top: 10px;float: right;border: 1px solid #D7DFF0;background: #fff;font-size: 13px;color:#536485;padding: 8px;margin-bottom: 4px;}
.ui-menu-item .ui-menu-item-wrapper{font-size: 13px}
#hcenter-button {float: none !important;}	
</style>
<script type="text/javascript">
	
	var oTable = "";
		
$(document).ready(function(){	
		
	
	
	$("#searchtype").selectmenu();
		
	
	 $(document).delegate("#searchtype","selectmenuchange",function(event){
         
		 //oTable.fnDraw();
		 
	});
	
	 $(document).on("click",".clear",function(){
		
		$("#searchtype").selectmenu('destroy');
	    $("#searchtype").prop('selectedIndex',0);
	    $("#searchtype").selectmenu();
		
	});
	
	
          var columnData = [
                    { "data": "ide" ,"bSortable":false},
                    { "data": "studid" },                
                    { "data": "sname" }, 
                    { "data": "mobile" }, 
                    { "data": "email"},
                    { "data": "scenter"},
                    { "data": "roll_number"},
                    { "data": "remitted" , "searchable": false},                   
                    { "data": "issue_ht" , "searchable": false},
                    { "data": "download_ht" , "searchable": false}  
                    
                  ];                                  
          // columnData.push( {data: "id","visible":true} );
         //columnData.push( {data: "item_name_search","visible":false} );
         
       
        oTable = $('#studenttable').dataTable({
                    "bProcessing": true,
                    "bServerSide": true,
                    "sPaginationType": "full_numbers",
                    "ajax": {
                    "url": 'screeningtest/GetAdmissionCenterStuLists',
                    "type": "POST",
                    "data":function(data){ 
                        
						var searchtype = $("#searchtype").val();
						
						data.searchcol= searchtype;
                        data.courseid = "<?php echo html_escape($courseid); ?>";     
                        data.type = "<?php echo html_escape($mode); ?>"; 
                        data.center = "<?php echo html_escape($center); ?>";
                      }
                     }, 
                     "oLanguage": {
                        "sProcessing": "<img src='<?php echo base_url(); ?>images/loader.gif'>"
                    },
                    'iDisplayLength': 20,
                    "columns": columnData,
                    "sorting":false,
                    "order": [[1, "desc" ]],
                    "fnDrawCallback": function( oSettings ) {
                        
                         $(".gchkbox").prop( "checked", false );
                         $(".status").each(function(){
                             
                             var rid = $(this).attr("data-rid");
                             var pid = $(this).attr("data-pid");
                             if(rid === 'p') { $(this).html('<p style="margin:0px;background:#3CAF92;padding:5px;color:#fff;width: 70px;border-radius: 5px;font-size:11px">Paid</p>'); }
                             
                             if(rid === '') { $(this).html('<p style="margin:0px;background:#ED5252;padding:5px;color:#fff;width: 70px;border-radius: 5px;;font-size:11px">Unpaid</p>'); }
                             
                         }); 
                        
                     },"initComplete" : function() {
						
						var input = $('.dataTables_filter input').unbind(),
							self = this.api(),
							$searchButton = $('<button class="btn btn-outline-primary ml-3 search">')
									   .text('search')
									   .click(function() {
										  self.search(input.val()).draw();
									   }),
							$clearButton = $('<button class="btn btn-outline-primary ml-3 clear">')
									   .text('clear')
									   .click(function() {
										  input.val('');
										  $searchButton.click(); 
									   }) 
						$('.dataTables_filter').append($searchButton, $clearButton);
                                                
                                                 $(input).keyup(function(event){
                                                    if(event.keyCode == 13){
                                                        event.preventDefault();
                                                        $('.search').trigger('click');
                                                    }
                                                });
					}
         }); 
         
         
         var chkbox = $('<input class="gchkbox" style="margin-left:17px;float:left;padding:5px;" type="checkbox"/>');
         
         $('#studenttable').find("th").first().append(chkbox);
         $('#studenttable').find("th").first().css("width","50px");
        $(chkbox).click(function(e){
           
            if($(this).is(":checked")){

                $('#studenttable').find(".crequest").each(function(){
                    $(this).prop( "checked", true );
                });

            } else {
                $('#studenttable').find(".crequest").each(function(){
                    $(this).prop( "checked", false );
                });
            }
           
        });
        
       
         $(".allocatecenter").click(function(){
            
            $('#newimportModal1').modal({show:true});
            
         });
            
         $(".hsave").click(function(){  
             
             if($(".hsave").hasClass("progress")){
                 alert("Please wait, Existing process is progresing...");return;
             }
             
             
         var ide =''; var type = 'Y'; var center = "";
           $(".crequest").each(function(){
               
               if($(this).is(":checked")) { ide += $(this).val()+"|";}
                
           });
           
           center = $("#hcenter").val();
         
          if(ide === '') { alert('select any request to allocate center and issue hallticket'); return;}
			 
			 $(".hsave").text("Progressing...");
			 $(".hsave").addClass("progress");
			 
            $.get('screeningtest/IssueHallticket',{
                                                                'ide':ide,'type':type,'center':center,'city': '<?php echo $center;?>','courseid': '<?php echo $courseid;?>'

                                                     }, function(o) { 
                                                             var obj1 = $.parseJSON(o);
                                                              $(".hsave").removeClass("progress");
                                                     if (obj1[0] === 'success') {
                                                         var r = confirm("Success!!! Request Updated.");			
                                                        if(r){
                                                           $('#newimportModal1').modal('hide'); 
                                                           oTable.fnDraw(); 
                                                        }
                                                         
                                                     } else if (obj1[0] === 'fail') {
                                                         alert("Error!!! please try again");
                                                 }else if (obj1[0] === 'novacant') {
                                                         var r =confirm("Error!!! Seats are filled in this center");
                                                          if(r){
                                                           $('#newimportModal1').modal('hide'); 
                                                           oTable.fnDraw(); 
                                                        }
                                                 }
                                     });
         
         });
         
           $("#templateUpload").click(function(){
		  
		$('#newimportModal').modal({show:true});
		   
	 }); 
         
	$('#newimportModal').on('hidden.bs.modal', function () {
  		
		$(".loader,.updateloader").addClass('d-none');
		$(".alert").removeClass('alert-success alert-danger').text("");
		$("#importmessage").html("");
		$(".importtemplate").removeClass('process');
		
	});
        
        
        $(".importtemplate").click(function(){
		  
		 var uploadfile = $("#uploadtemplate").val();
		 
		 if(uploadfile==""){
			 $(".alert").removeClass('alert-success').addClass('alert-danger').text("Upload import file");
			 return;
		 }
		 
		if($(".importtemplate").hasClass('process')){
			
			$(".alert").removeClass('alert-success').addClass('alert-danger').text("Please wait while importing...");
			
		}else{
		
			$(".importtemplate").addClass('process');
			$(".alert").removeClass('alert-danger').addClass('alert-success').text("Importing new admissions...");
			
			$(".loader").removeClass('d-none');
         		 
		 var formData = new FormData();
		 
		 var c=0;
		 var file_data,file;
		 $('input[type="file"]').each(function(){
			  file_data = $('input[type="file"]')[c].files; // get multiple files from input file
			  //console.log(file_data);
		   for(var i = 0;i<file_data.length;i++){
			   formData.append('file[]', file_data[i]); // we can put more than 1 image file
		   }
		  c++;
	    }); 
            
            formData.append('center', '<?php echo $center;?>');
            formData.append('courseid', '<?php echo $courseid;?>');
		 
		 $.ajax({
                type: 'POST',
                url: 'screeningtest/uploadTempalte',
                data: formData,
			    contentType: false,
    			processData: false,
                success: function(response) {
                   
					var obj1 = $.parseJSON(response);
							
					$(".loader").addClass('d-none');
					
					if(obj1['status']=="success"){
						
						$(".alert").addClass('alert-success').text("Template uploaded successfully.");
						
												
						setTimeout(function(){
							$(".alert").removeClass('alert-success').text("");
							location.reload();
						},2000);
						
					}else if(obj1['status']=="empty"){
						$(".importtemplate").removeClass('process');
						$(".alert").removeClass('alert-success').addClass('alert-danger').text("Upload file");
					}else if(obj1['status']=="ufail"){
						$(".importtemplate").removeClass('process');
						$(".alert").removeClass('alert-success').addClass('alert-danger').text("Upload failed");
					}else if(obj1['status']=="ularge"){
						$(".importtemplate").removeClass('process');
						$(".alert").removeClass('alert-success').addClass('alert-danger').text("Each upload file must be less than 1MB");
					}else if(obj1['status']=="exfail"){
						$(".importtemplate").removeClass('process');
						$(".alert").removeClass('alert-success').addClass('alert-danger').text("Support extension PDF only");
					}else if(obj1['status']==""){
						$(".importtemplate").removeClass('process');
						$(".alert").removeClass('alert-success').addClass('alert-danger').text("Please try again.");
					}
					
                }

            });
			
		}
		
		   
	 }); 
         
          $(".export").click(function(){
               
               var url = 'screeningtest/export?courseid=<?php echo $courseid; ?>&type=<?php echo $mode; ?>&center=<?php echo $center; ?>';
               $(location).prop('href', url);
               
            });
	
	
	
	// Change City
	
	$(".changecity").click(function(){
            
		$('#cityModal1').modal({show:true});

	});
            
	 $(".citysave").click(function(){ 
		 
	 	var ide =''; var city = "";
	   $(".crequest").each(function(){

		   if($(this).is(":checked")) { ide += $(this).val()+"|";}

	   });

	   city = $("#hcity").val();

	  if(ide === '') { alert('select any request to change city'); return;}
		 
		$.get('screeningtest/STChangeCity',{
			
			'ide':ide,'city': city,'courseid': '<?php echo $courseid;?>'

		 }, function(o) { 
				 var obj1 = $.parseJSON(o);
				 if (obj1[0] === 'success') {
					 var r = confirm("Success!!! Request Updated.");			
					if(r){
					   $('#cityModal1').modal('hide'); 
					   oTable.fnDraw(); 
						location.assign("screeningtest?id=<?php echo $courseid;?>&type=cenlist&mode=all&center="+city);
					}

				 } else if (obj1[0] === 'fail') {
					 alert("Error!!! please try again");
				 }
		 });

	 });
	
	
	// Issue HallTicket
	
	$(".hissue").click(function(){
		
             if($(".hissue").hasClass("progress")){
                 alert("Please wait, Existing process is progresing...");return;
             }
             
            
         	var ide =''; var type = 'Y'; var center = "";
           $(".crequest").each(function(){
               
               if($(this).is(":checked")) { ide += $(this).val()+"|";}
                
           });
           
           //center = $("#hcenter").val();
         
          if(ide === '') { alert('select any request to issue hallticket'); return;}
		
			$(".hissue").text("Progressing...");
		 	$(".hissue").addClass("progress");
		
            $.get('screeningtest/IssueHallticket',{
                'ide':ide,'type':type,'center':center,'city': '<?php echo $center;?>','courseid': '<?php echo $courseid;?>'

						 }, function(o) {
				
						 var obj1 = $.parseJSON(o);
						 $(".hissue").removeClass("progress").text("Issue Hallticket");
				
						 if (obj1[0] === 'success') {
							 var r = confirm("Success!!! Request Updated.");			
							if(r){
							   oTable.fnDraw(); 
							}

						 } else if (obj1[0] === 'fail') {
							 alert("Error!!! please try again");
					 	 }else if (obj1[0] === 'novacant') {
						   var r =confirm("Error!!! Seats are filled in this center");
						   if(r){
							  oTable.fnDraw(); 
							}
					 	 }
				
				 });
         
         });

	
});
</script>


<div class="wrap dynamic-width" style="float: left;position: relative">
    
    <div style="margin-top: 10px; width: 100%; height: 150px; text-align: right;">
             <span style="font-weight: bold;font-size: 20px;padding: 10px;float:left;color: #364159">Screening Test Results</span>
             
             <div class="row w-100 mb-3">
                
                <div class="col-6 text-left">
                
                 <span class="title" style="padding: 0px;padding-left: 10px;color: #6F83AA">Screening Test Name</span>                    
                    <span class="content" style="padding: 0px;color:#0332AA;font-weight: bold">
                            <?php echo $coursename;?>
                        </span>
                </div>
                
              <div class="col-3 text-left">
                 <span class="title" style="padding: 0px;padding-left: 10px;color: #6F83AA">City : </span>                    
                    <span class="content" style="padding: 0px;color:#0332AA;font-weight: bold;">
                            <?php echo $center;?>
                        </span>
                 
                </div>
                
                <?php if(isset($roleaccess['Change City'][3]) && $roleaccess['Change City'][3]=="y"){?>
                
              <div class="col-3 text-left">
                
                 <button style="font-size: 14px;padding: 8px;  color: #fff; margin: 0px auto; border-radius:5px;background: linear-gradient(180deg, #4F70C4 0%, #1C47B3 100%);" class="btn btn-primary changecity" type="button"  aria-haspopup="true" aria-expanded="false" >Change City</button>
                 
                </div>
                
                <?php }?>
                
                </div>
                
                 <div class="row w-100">
                 
                  <?php if(isset($roleaccess['Hall Ticket'][3]) && $roleaccess['Hall Ticket'][3]=="y"){?>
                  
                  <div class="col-2 mt-2 text-center">
                  
                  	<button id= "templateUpload" style="font-size: 14px;padding: 8px;  color: #fff; margin: 0px auto; position: relative; border-radius:5px;background: linear-gradient(180deg, #4F70C4 0%, #1C47B3 100%);" class="btn btn-primary" type="button"  >Template Upload</button>
                  				 
				</div>
                
                 <div class="col-2 mt-2 text-center">
                 
                 	 <button style="font-size: 14px;padding: 8px;  color: #fff; margin: 0px auto; border-radius:5px;background: linear-gradient(180deg, #4F70C4 0%, #1C47B3 100%);height: auto" class="btn btn-primary hissue" type="button"  aria-haspopup="true" aria-expanded="false" >Issue Hallticket</button>
					                  	
				</div> 
                
                 <div class="col-2 mt-2 text-center">
                 					 
                 	<button style="font-size: 14px;padding: 8px;  color: #fff; margin: 0px auto; border-radius:5px;background: linear-gradient(180deg, #4F70C4 0%, #1C47B3 100%);" class="btn btn-primary allocatecenter" type="button"  aria-haspopup="true" aria-expanded="false" >Allocate Center</button>
                 	
				</div>                
                    
                     <?php }?>
                     
                      <?php if(isset($roleaccess['Export ST'][3]) && $roleaccess['Export ST'][3]=="y"){?>
                     
                     <div class="col-1 mt-2 text-center">
                 
                 	 <button style="font-size: 14px;padding: 8px;  color: #fff; margin: 0px auto; border-radius:5px;background: linear-gradient(180deg, #4F70C4 0%, #1C47B3 100%);" class="btn btn-primary export" type="button"  aria-haspopup="true" aria-expanded="false" >Export</button>
					 
                 	
				</div>
              
                <?php }?>
                
                 <div class="col-1 align-items-end">
                     <select id="searchtype">
                        <option value="stuid">Student ID</option>
						 <option value="stuname">Student Name</option>
						 <option value="mobile">Mobile</option>
						 <option value="email">Email</option>
						 <option value="rollno">Roll No</option>
						 <option value="center">Center</option>
                     </select>
                 </div> 
                                                                                           
    		</div> 
             
            </div>         
         <?php echo $this->table->generate();  ?>             
         
        
        
        </div>
    
 
 <!--  Import Template  -->
<style>

	#newimportModal.modal .modal-header{padding: 5px 10px !important;border: none}	
	#newimportModal.modal .modal-body{padding:0 1.75rem 1.75rem}
	.modal-body p{text-align: left !important}
	.modal-backdrop.show {opacity: .5 !important;}
	#newimportModal h2{line-height: 24px;}

	#importmessage table{width: 100%;border-collapse: collapse;}
	#importmessage table td:nth-child(odd){width: 40%}
	#importmessage table td:nth-child(even){width: 60%}
	#importmessage table th,#importmessage table td{border: 1px solid #333;width: 50%;text-align: left;padding: 5px 10px}
	.loader p{text-align: center !important;}

	.studentdetails p span{font-weight: bold;display: block}

	label{color: #4F70C4;}

</style>
   
   <?php if(isset($roleaccess['Hall Ticket'][3]) && $roleaccess['Hall Ticket'][3]=="y"){?>
    
<div id="newimportModal" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
		<div class="modal-dialog modal-dialog-centered" role="document">
			<div class="modal-content">
				<div class="modal-header">
				   <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				</div>
				<div class="modal-body text-center">
									
					<h2 class="mb-4 mt-0 text-center">Upload Template</h2>
					
                                        <?php 
                                        $filename = FCPATH."docs/screentest/".$courseid."/".$center."/screeningtest.pdf";
                                        if(file_exists($filename)) { ?>
                                        
                                        <p class="mb-4 mt-0 text-center" style="text-align: center !important;">
                                            <a target="_blank" href="<?php echo base_url()."docs/screentest/".$courseid."/".$center."/screeningtest.pdf";?>">Click here</a> to view the current Uploaded Template 
                                        </p>
                                        <?php } ?>
					<label class="btn btn-outline-primary btn-upload my-3" for="uploadtemplate" title="Upload image file">
					  <input type="file" class="sr-only" id="uploadtemplate" name="uploadtemplate">Select Import File
                   </label>
                   
                   <div class="loader d-none">
						<img src='<?php echo base_url(); ?>images/loader.gif'>
						<p>Uploading template...</p>
					</div>
						
					
					<div id="importmessage"></div>				
										
				</div>
				<div class="modal-footer">
				
					<p class="alert mb-0"></p>
					
					<button type="button" class="btn btn-primary importtemplate">Import</button>
					<button type="button" class="btn btn-outline-primary modalclose" data-dismiss="modal">Close</button>
				</div>
								
			</div>
		</div>
	</div>

<?php }?>

 <!--  Import Template  -->

 <!--  Select Center  -->
<style>

	#newimportModal1.modal .modal-header{padding: 5px 10px !important;border: none}	
	#newimportModal1.modal .modal-body{padding:0 1.75rem 1.75rem}
	#newimportModal1 h2{line-height: 24px;}


</style>
    
<div id="newimportModal1" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
		<div class="modal-dialog modal-dialog-centered" role="document">
			<div class="modal-content">
				<div class="modal-header">
				   <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				</div>
				<div class="modal-body text-center " >
					<h2 class="mb-4 mt-0 text-center">Select Center</h2>				
                                        <select class="form-control hcenter floating" id="hcenter"required  >
					<option value="">----------</option>
                                        <?php 
                                          echo $centers;
                                         ?>
					              
					</select>			
										
				</div>
				<div class="modal-footer">
				
					<p class="alert mb-0"></p>
					
					<button type="button" class="btn btn-primary hsave">Save</button>
					<button type="button" class="btn btn-outline-primary modalclose" data-dismiss="modal">Close</button>
				</div>
								
			</div>
		</div>
	</div>

<!-- End  Select Center  -->

 <!--  Select City  -->
<style>

	#cityModal1.modal .modal-header{padding: 5px 10px !important;border: none}	
	#cityModal1.modal .modal-body{padding:0 1.75rem 1.75rem}
	#cityModal1 h2{line-height: 24px;}


</style>
    
<div id="cityModal1" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
		<div class="modal-dialog modal-dialog-centered" role="document">
			<div class="modal-content">
				<div class="modal-header">
				   <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				</div>
				<div class="modal-body text-center " >
					<h2 class="mb-4 mt-0 text-center">Select City</h2>
									
					<select class="form-control hcity floating" id="hcity" required  >
						<option value="">----- Select City -----</option>
						<?php echo $cities; ?>
					</select>			
										
				</div>
				<div class="modal-footer">
				
					<p class="alert mb-0"></p>
					
					<button type="button" class="btn btn-primary citysave">Save</button>
					<button type="button" class="btn btn-outline-primary modalclose" data-dismiss="modal">Close</button>
				</div>
								
			</div>
		</div>
	</div>

<!-- End  Select City  -->

<?php

//var_dump($qualification['general_x']);
?>
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/dataTables.css?v=1.5" />
<script src="<?php echo base_url(); ?>js/jquery.dataTables.js?v=1.0" type="text/javascript"></script>
 <link href="<?php  echo base_url(); ?>css/jquery-ui.min.css?v=1.4" rel="stylesheet" type="text/css" />
 <link href="<?php  echo base_url(); ?>css/chosen.min.css?v=1.3" rel="stylesheet" type="text/css" />

 <script src="<?php  echo base_url(); ?>js/jquery-ui.min.js?v=1.3" type="text/javascript"></script>
  <script src="<?php  echo base_url(); ?>js/chosen.jquery.min.js?v=1.2" type="text/javascript"></script>


 <style type="text/css">
     
     .dataTables_wrapper input[type="text"] {text-indent: 5px;}
.dataTables_wrapper select {
    padding: 0;
}

.sortable thead tr  {
    background: #E6EBF7;

/* g8 */
border: 1px solid #D7DFF0;
box-sizing: border-box;
border-radius: 10px 10px 0px 0px;
 

}
.sortable tr th {
    border-right: 0px;
    padding: 17px 0;font-size: 13px;
      color: #6F83AA;
   cursor: pointer;
   text-align: center;

}


.sortable tr td:nth-child(1) {
   
    
   width: auto;     
}

.sortable tr th:nth-child(2) { text-align: left;}
.sortable tr td:nth-child(2) {
   min-width:50px;
    color: #364159; vertical-align: middle;
    width:30%;
    text-align: left;
}

.sortable tr td:nth-child(3) {
   
    width:25%;
}

.sortable tr td:nth-child(4) {
   
    width:25%;
}


.sortable tr td {
    border-right: 0px;
    padding: 15px 5px;
    text-align: center;font-size: 13px;
    min-width:50px;
}
     .dataTables_info { display: none; }
#subjecttable_paginate,#subjecttable1_paginate { display: none;}
#subjecttable_filter input,#subjecttable1_filter input {display:none;}
     .ui-selectmenu-button.ui-button{ width: 97%; padding:6px;border: 1px solid #D7DFF0;background: #fff;font-size: 14px;color:#536485}
     
     #centers_chosen  {border: 1px solid #D7DFF0;background: #fff;padding: 8px 0px;}
     .chosen-container-multi .chosen-choices {border: 0px;background: none}
     .maincontent ul li.search-choice { height:auto; }
     .maincontent ul li.search-choice a{ height:auto; font-size: 14px;color:#536485}
     .chosen-container-multi .chosen-choices li.search-choice { background: #6884CC;border-radius: 5px;}
     .chosen-container-multi .chosen-choices li.search-choice {color: #fff;}
     
     .streams li { list-style: none;padding:5px;display: inline-block;width: 100%;}
     .ui-checkboxradio-radio-label .ui-icon-background { border: 1px solid #D7DFF0; }
.ui-checkboxradio-radio-label.ui-checkboxradio-checked .ui-icon, .ui-checkboxradio-radio-label.ui-checkboxradio-checked:hover .ui-icon { border-width: 5px;border-color: #0332aa;}
.dropLabel { color:#536485;background: none;border: 0px;width: 50%;height: auto;}
.chkLabel { text-align: left;color:#fff !important;;background: none !important;border: 0px !important;width: auto;height: auto;font-size: 13px}
.ui-selectmenu-text { font-size:13px;}
.course-container {
    
    box-shadow: 3px 3px 3px #eee;
    -webkit-box-shadow:3px 3px 3px #eee;
    -moz-box-shadow:3px 3px 3px #eee;
    padding-top: 20px;
    
    width:98%;
    background: #fff;
    padding-left: 20px;
    border-radius: 10px;
    
}
.response p { float: right;font-size:12px;color:#eb345e;}
.entrance_exam input { padding: 5px;}
.entrance_exam .ui-selectmenu-button.ui-button { padding: 10px;padding-right: 0px;}
.entrance_exam table { background: none;border: 0px;box-shadow: none;}
	 
	  .marksheets{display: flex;padding: 1.5rem 0}
	 .col-left{width: 20%}
	 .col-right{width: 48%}
	 
	 #classstudy-button,#classstudy-button .ui-selectmenu-text{height: 26px;line-height: 26px;padding-left: 6px}
	 #classstudy-button .ui-selectmenu-icon.ui-icon{margin-top: 6px}
	 
 </style>
<div class="wrap dynamic-width" style="float: left;position: relative;min-width: 800px">
     <div style="margin-top: 10px; width: 99%; height: 50px; text-align: right;">
         <span style="font-weight: bold;font-size: 20px;padding: 10px;float:left;color: #364159">Qualification</span>
         </div>         
            <div id="course-container" class="add-course">

               <div class="row-element" style="margin:0px">
                    <span class="content" style="padding:0px;">
                        <label style="color:#536485;background: none;border: 0px;width: 30%;height: auto;float:left;margin: 1rem auto;">
								<select id="classstudy" class="classstudy" style="font-size: 15px;float:left;height: 40px;">
									<?php echo $classstudymaster;?>
								</select>
                            </label>                          
                        </span>
                </div>
                
                <div class="row-element" >
                    <span class="content" style="padding: 0px"><input type="text" placeholder="Qualification Name" value="<?php echo $qualification['general']['name'];?>" class="qname"></span>
                </div>
                               
                <div class="row-element">                                      
                    <span class="content" style="padding: 0px">
                        <label class="chkLabel" style="color:#536485 !important"><input type="checkbox"   <?php  if($qualification['general']['xii_flag'] === '1') { echo 'checked';} ?>  id="show_xii" class="chkbox xii_flag" style="margin: 5px;">Enter XII Marksheet</label>
                    </span>
                </div>
                          
                          
				<div class="row marksheets">

					<div class="col-mark col-left">
						<span class="content" style="padding: 0px">
							<label class="chkLabel" style="color:#536485 !important"><input type="checkbox" class="chkbox marksheet_flag" name="marksheet_flag" style="margin: 5px;" <?php  if($qualification['general']['marksheet_flag'] === '1') { echo 'checked';} ?>>Marksheet Upload </label>
						</span>
					</div>

				   <div class="col-mark col-right">
						<span class="content" style="padding: 0px"><input type="text" placeholder="Marksheet Message" value="<?php  echo $qualification['general']['marksheet_info']; ?>" class="marksheet_info" name="marksheet_info" ></span>
					</div>

				</div>          
                
            </div>
        <label style="color:#536485;background: none;border: 0px;width: 100%;height: 20px;float:left;">&nbsp;</label> 
        <div style="width: 100%;height: auto;overflow: hidden"><div class="streams" style="width:15%;min-width: 100px;height: auto;float:left;border: 1px solid #D7DFF0;border-radius: 5px">
        <div style="width:100%;height:auto;margin:0px auto;background: #fff">
        <span style="font-size: 13px;color: #6F83AA;width: 300px;height:55px;text-align: center;vertical-align: middle;display: table-cell;background: #E6EBF7">BOARD OF EXAM</span>
        <ul class="x_std">
           <?php 
            echo $streams['X']; 
            ?>
        </ul>
        <input type="hidden" class="fstream">
        </div>
    </div>
    <div style="width:84%;height: auto;float:right">
        <div style="width:100%;height: auto;background: #6884cd;padding-left: 10px;padding-top: 10px">
             <div class="row-element" style="margin:0px">
                    <span class="content" style="padding:0px;">
                        <label style="color:#536485;background: none;border: 0px;width: 30%;height: auto;float:left;">
                    <select id="rule" class="rule qualification_rule" style="font-size: 13px;float:left">
                            <option value="" >Rule</option>
                            <option value="GTE">Greater Than</option>
                            <option value="LTE">Less Than</option>
                        </select>
                            </label>
                         <label style="color:#536485;background: none;border: 0px;width: 4%;height: 20px;float:left;">&nbsp;</label>
                         <label style="color:#536485;background: none;border: 0px;width: 30%;height: auto;float:left;">
                    <select  id="yearofpassing" class="yearofpassing qualification_year" style="font-size: 13px;float:left">
                            <option value="" >Year of Passing</option>
                            <?php 
                            $ret = "";
                              for($i = -5;$i <= 4;$i++)
                              {
                                  $ret .="<option>".date('Y', strtotime($i.' year'))."</option>";
                              }
                              echo $ret;
                            ?>
                        </select>
                         </label>
                          <label style="color:#536485;background: none;border: 0px;width: 4%;height: 20px;float:left;">&nbsp;</label>
                         <label style="color:#536485;background: none;border: 0px;width: 30%;height: auto;float:left;">
                    <select id="className" class="className qclass" style="font-size: 13px;float:left">
                        <option value="" >Class name</option>
                           <?php 
                        $ret = '';
                          $arr1 = $classes;
                          for($i = 0;$i < count($arr1);$i++){
                              if($qualification['general']['class'] === $arr1[$i]){
                                      $selected = 'selected="selected" ';
                                  }
                              $ret .="<option $selected >".$arr1[$i]."</option>";
                              $selected = '';
                          }
                          echo $ret;
                        ?>
                            
                        </select>
                             </label>
                          
                        </span>
                </div>
            
            
         <div class="row-element" style="margin:0px">
                                      
             <span class="content" style="padding:0px;width: 100%">
                        <label class="chkLabel"><input type="checkbox"  name="rollno" class="chkbox rollno" style="margin: 5px;">Get Roll Number</label>
                        <label class="chkLabel"><input type="checkbox"  name="gracemark" class="chkbox gracemark" style="margin: 5px;">Grace Mark awarded</label>
                        <label class="chkLabel"><input type="checkbox"  name="waitingresult" class="chkbox waitingresult" style="margin: 5px;">Allow If Result Is Waiting</label>
                         <label class="chkLabel"><input type="checkbox"  name="completed" class="chkbox completed" style="margin: 5px;">Allow If Result Is Completed</label>
                       
                          </span>
                </div>
        </div>
         <?php echo $this->table->generate();  ?>             
   
        </div></div>
        <label style="background: none;border: 0px;width: 100%;height: 30px;">&nbsp;</label> 
        <div class="show_xii" style="width:100%;height:auto;margin:0px auto;background: none;display: none">
         <label style="color:#0332AA;background: none;border: 0px;width: 100%;height: 20px;font-weight: bold;font-size: 13px;">ENTER XII MRKSHEET</label>  
         <label style="background: none;border: 0px;width: 100%;height: 20px;">&nbsp;</label> 
       
        <label style="color:#536485;background: none;border: 0px;width: 100%;height: 20px;float:left;">&nbsp;</label> 
        <div style="width: 100%;height: auto;overflow: hidden"><div class="streams" style="width:15%;min-width: 100px;height: auto;float:left;border: 1px solid #D7DFF0;border-radius: 5px">
        <div style="width:100%;height:auto;margin:0px auto;background: #fff">
        <span style="font-size: 13px;color: #6F83AA;width: 300px;height:55px;text-align: center;vertical-align: middle;display: table-cell;background: #E6EBF7">BOARD OF EXAM</span>
        <ul class="xii_std">
           <?php 
           $streams['XII'] = str_replace("radiocenters", "radiocenters1", $streams['XII']);
            echo $streams['XII']; 
            ?>
        </ul>
        </div>
    </div>
    <div style="width:84%;height: auto;float:right">
        <div style="width:100%;height: auto;background: #6884cd;padding-left: 10px;padding-top: 10px">
             <div class="row-element" style="margin:0px">
                    <span class="content" style="padding:0px;">
                        <label style="color:#536485;background: none;border: 0px;width: 30%;height: auto;float:left;">
                     <select id="rule" class="rule xii_rule" style="font-size: 13px;float:left">
                            <option value="" >Rule</option>
                            <option value="GTE">Greater Than</option>
                            <option value="LTE">Less Than</option>
                        </select>
                            </label>
                         <label style="color:#536485;background: none;border: 0px;width: 4%;height: 20px;float:left;">&nbsp;</label>
                         <label style="color:#536485;background: none;border: 0px;width: 30%;height: auto;float:left;">
                      <select  id="yearofpassing" class="yearofpassing xii_year" style="font-size: 13px;float:left">
                            <option value="" >Year of Passing</option>
                             <?php 
                            $ret1 = "";
                              for($i = -5;$i <= 4;$i++)
                              {
                                  $ret1 .="<option>".date('Y', strtotime($i.' year'))."</option>";
                              }
                              echo $ret1;
                            ?>
                        </select>
                         </label>
                          <label style="color:#536485;background: none;border: 0px;width: 4%;height: 20px;float:left;">&nbsp;</label>
                         <label style="color:#536485;background: none;border: 0px;width: 30%;height: auto;float:left;">
                    <select id="className" class="className xii_class" style="font-size: 13px;float:left">
                        <option value="" >Class name</option>
                           <?php 
                        $ret1 = '';
                          $arr2 = ['XII Class',"XI Class"];
                          for($i = 0;$i < count($arr2);$i++){
                              if($qualification['general']['class'] === $arr1[$i]){
                                      $selected = 'selected="selected" ';
                                  }
                              $ret1 .="<option >".$arr2[$i]."</option>";
                              
                          }
                          echo $ret1;
                        ?>
                            
                        </select>
                             </label>
                          
                        </span>
                </div>
            
            
         <div class="row-element" style="margin:0px">
                                      
             <span class="content" style="padding:0px;width: 100%">
                        <label class="chkLabel"><input type="checkbox"  name="xii_rollno" class="chkbox xii_rollno" style="margin: 5px;">Get Roll Number</label>
                        <label class="chkLabel"><input type="checkbox"  name="xii_gracemark" class="chkbox xii_gracemark" style="margin: 5px;">Grace Mark awarded</label>
                        <label class="chkLabel"><input type="checkbox"  name="xii_waitingresult" class="chkbox xii_waitingresult" style="margin: 5px;">Allow If Result Is Waiting</label>
                         <label class="chkLabel"><input type="checkbox"  name="xii_completed" class="chkbox xii_completed" style="margin: 5px;">Allow If Result Is Completed</label>
                       
                          </span>
                </div>
        </div>
         <?php
         
         $this->table->clear();
         $tmpl = array('table_open' => '<table class="sortable disabled" id="subjecttable1" style="margin-top:0px;">');                 
         $this->table->set_template($tmpl);
         $this->table->set_heading('','SUBJECT', 'RULE','VALUE','OUT OF MARK');
         echo $this->table->generate();  ?>             
   
        </div></div>
        <label style="background: none;border: 0px;width: 100%;height: 30px;">&nbsp;</label> 
        <label style="color:#0332AA;background: none;border: 0px;width: 100%;height: 20px;font-weight: bold;font-size: 13px;">PREVIOUS ENTRANCE EXAMS</label>  
         <label style="background: none;border: 0px;width: 100%;height: 20px;">&nbsp;</label> 
        <div class="course-container">

                  <div class="row-element entrance_exam">
                    <table class="sortable">
                        <?php
                        $exam = $qualification['general']['entrance'];
                        $examArr = explode("|", $exam);
                        
                        $rexam = $qualification['general']['entrance_rule'];
                        $rexamArr = explode("|", $rexam);
                        
                        $vexam = $qualification['general']['entrance_value'];
                        $vexamArr = explode("|", $vexam);
                        
                        $oexam = $qualification['general']['entrance_outofmark'];
                        $oexamArr = explode("|", $oexam);
                        $flag = 0;
                        for($i = 0;$i < count($examArr);$i++){
                            if($examArr[$i] === "") { continue;}
                            else {
                                $gselected = ($rexamArr[$i] === 'GTE')?'selected=selected':"";
                                $lselected = ($rexamArr[$i] === 'LTE')?'selected=selected':"";
                                $optionele = '<option '.$gselected.' value="GTE">Greater Than</option>  <option '.$lselected.' value="LTE">Less Than</option>';
                            echo '<tr>
                        <td><input type="text" placeholder="Add Entrance Exam Name" value="'.$examArr[$i].'" class="exam_name"></td>
                         <td><select  class="rule exam_rule" style="font-size: 13px;">'.$optionele.'</select></td>
                       <td> <input type="text" placeholder="Value" value="'.$vexamArr[$i].'" class="exam_value"></td>
                       <td> <input type="text" placeholder="Out off mark" value="'.$oexamArr[$i].'" class="exam_outoffmark"></td>
                        </tr>'; 
                                $flag = 1;
                            }
                        }
                        
                        if($flag === 0) { 
                            
                            echo '<tr>
                        <td><input type="text" placeholder="Add Entrance Exam Name" value="" class="exam_name"></td>
                         <td><select  class="rule exam_rule" style="font-size: 13px;"><option value="GTE">Greater Than</option>  <option value="LTE">Less Than</option></select></td>
                       <td> <input type="text" placeholder="Value" value="" class="exam_value"></td>
                       <td> <input type="text" placeholder="Out off mark" value="" class="exam_outoffmark"></td>
                        </tr>';
                            
                        }
                        ?>
               
                    </table>
                   
                   
                </div>    
            <div class="row-element"> <a href="javascript:void(0)" id="add_more" s style="text-align: left;font-size: 13px;color:#0332aa;">+ Add More Entrance Exams</a></div>
                
            </div>
        <label style="color:#536485;background: none;border: 0px;width: 100%;height: 20px;float:left;">&nbsp;</label>
        </div>
          <div style="margin-top: 0px; width: 98%; height: 70px; text-align: right;overflow: hidden">
         <span  style="margin: 0px auto; float:right;margin-top: 18px;padding: 10px; color: #fff; background: #4f6fc4 none repeat scroll 0% 0%; border-radius:5px;cursor: pointer" class="btn savebtn" href="#">Save</span>
         <a style="margin: 0px auto; float:right;margin-top: 18px;margin-right:18px;padding: 9px 10px; color: #0332AA; background: linear-gradient(0deg, #FFFFFF, #FFFFFF), #C4C4C4;border: 1px solid #0332AA; border-radius:5px" class="btn" href="<?php echo base_url(); ?>qualificationlist">Back</a>
         <span class="response" style="margin: 0px auto; float:right;width: 80%; height: 30px;margin-top:20px"></span>
          </div> 
        
        </div>
 
<script type="text/javascript">
    
$(document).ready(function() {
    
    var genX = <?php echo json_encode($qualification['general_x']); ?>;
    
    var genXII = <?php echo json_encode($qualification['general_xii']); ?>;
   
	var classstudy = "<?php echo $qualification['general']['classstudy']; ?>";
	$("#classstudy").val(classstudy);	
   
   $(".classstudy").selectmenu();
    $(".rule").selectmenu();
    $(".yearofpassing").selectmenu();
    $(".className").selectmenu();
    $(".radiocenters").checkboxradio();$(".radiocenters1").checkboxradio();
    $(".chkbox").checkboxradio();
    
     $("#show_xii").click(function(){
         if($(this).is(":checked")) { $(".show_xii").css("display","block");$(".xii_std").find("li").first().find("input").trigger("click");}
         else { $(".show_xii").css("display","none"); }

     });
     if($("#show_xii").is(":checked")) { $(".show_xii").css("display","block");}
     var columnData = [
                    { "data": "id" },
                    { "data": "subject" },
                    { "data": "rule" },
                    { "data": "mark_type" }
                    
                  ];
      
     var tab1= tableInitialize($("#subjecttable"),columnData,'X',$(".x_std"));
     var tab2 = tableInitialize($("#subjecttable1"),columnData,'XII',$(".xii_std"));
       var genData = [];var genDataXII = [];
         function tableInitialize (tabEle,columnData,ide,trigger){
         
         var oTable = tabEle.dataTable({
                    "bProcessing": true,
                    "bServerSide": true,
                    "sPaginationType": "full_numbers",
                    "ajax": {
                    "url": 'qualification/getSubjects',
                    "type": "POST",
                    "data":function ( d ) {d.id = ide;}
                     }, 
                     "oLanguage": {
                        "sProcessing": "<img src='<?php echo base_url(); ?>images/loader.gif'>"
                    },
                    'iDisplayLength': 10,
                    "columns": columnData,
                    "fnDrawCallback": function( oSettings ) {
                        tabEle.find("tbody").html("");
                      var obj1="",obj2 ="",type="",grade="",subArr=[];
                      for(var y= 0; y < oSettings.json.data.length; y++){
                          
                         obj1 = oSettings.json.data[y].subject;
                         obj2 = oSettings.json.data[y].mark_value;
                         type = oSettings.json.data[y].mark_type;
                         subArr = obj1.split("|");
                      
                        if(type === "1") { grade = obj2.split("|"); }
                        
                        var genObj = {  
                                "id" :"",    
                                "rule" :"",                                
                                "year" :"",
                                "class" :"",
                                "rollno" :"N",
                                "gracemark" :"N",
                                "resultwaiting" :"N",
                                "resultcompleted" :"N",
                                "subject" :"",
                                "qrule" :"",
                                "qmark" :"",
                                "qgrade" :"",
                                "stream" :"",
                                "outofmark" :"",
                                "trule" :"",
                                "mtotal" :""
                                
                             };
                             
                        genObj.stream = oSettings.json.data[y].stream; var xflag = 0;
                        if(ide === "X") {
                            $(genX).each(function(index) {

                                 var streamArr  = genX[index];
                                 if(streamArr.stream === oSettings.json.data[y].stream){
                                      genData.push(streamArr);xflag = 1;
                                 }
                             });

                             if(xflag === 0) { genData.push(genObj); }
                        
                        } else {
                            
                            $(genXII).each(function(index) {

                                 var streamArr  = genXII[index];
                                 if(streamArr.stream === oSettings.json.data[y].stream){
                                      genDataXII.push(streamArr);xflag = 1;
                                 }
                             });

                             if(xflag === 0) { genDataXII.push(genObj); }                      
                        }
                        
                         addRow(subArr,grade,type,oSettings.json.data[y].stream,tabEle,ide);
                          
                      }
                      
                      $(trigger).find("li").first().find("input").trigger("click");
                      
                       $(".x_std").find(".radiocenters").each(function(){
        
                            var ide = $(this).attr("attr-centers");
                            var ininde = "";var radioELe = $(this);
                            $("#subjecttable").find("tbody tr").each(function(){
                                var y = $(this).attr("attr-streams");
                                if( y === ide) {
                                    ininde = $(this).attr("attr-ide");
                                    radioELe.attr("attr-ide",ininde);
                                } 
                            });

                        });
     
                        $(".xii_std").find(".radiocenters1").each(function(){

                          var ide = $(this).attr("attr-centers");
                          var ininde = ""; var radioELe = $(this);
                          $("#subjecttable1").find("tbody tr").each(function(){
                              var y = $(this).attr("attr-streams");
                              if( y === ide) {
                                  ininde = $(this).attr("attr-ide");
                                  radioELe.attr("attr-ide",ininde);
                              } 
                          });

                       });
                      
                      
                    }
         });
         
         return oTable;
         
         }
         
         
          function addRow(ele,grade,type,stream,tableEle,ide){
        var trEle = "";
            var tdEle1 ="",tdEle2 ="",tdEle3 ="",tdEle4 ="",tdEle5 ="";
            var spanEle = '';var inpEle = '';var checkEle = '';var inpEle1 = '';
            var selectEle = "";var labelEle = "";var labelEle1 = "";
           var labelEle1 = ""; var esubject = ""; var estream = ''; var erule = "";
           var outofmark = "";var total = "";var trule = "";
           var etotal = "";var etrule = "";
           var emark="";var egrade = ""; var indiviIDE ="";
           
           if(ide === 'X') {
               
               for(var nm = 0 ; nm < genData.length;nm++) {
                   if(genData[nm].stream === stream) {
                        esubject = genData[nm].subject;
                        estream = genData[nm].stream;
                        erule = genData[nm].qrule;
                        emark = genData[nm].qmark;
                        egrade = genData[nm].qgrade;
                        outofmark = genData[nm].outofmark;
                        trule = genData[nm].trule;
                        total = genData[nm].mtotal;
                        indiviIDE = genData[nm].id;
                        break;
                   }
               }
           } else {
               
                for(var nm = 0 ; nm < genDataXII.length;nm++) {
                   if(genDataXII[nm].stream === stream) {
                        esubject = genDataXII[nm].subject;
                        estream = genDataXII[nm].stream;
                        erule = genDataXII[nm].qrule;
                        emark = genDataXII[nm].qmark;
                        egrade = genDataXII[nm].qgrade;
                        outofmark = genDataXII[nm].outofmark;
                        trule = genDataXII[nm].trule;
                        total = genDataXII[nm].mtotal;
                        indiviIDE = genDataXII[nm].id;
                        break;
                   }
               }
               
               
           }
           
 
            erule = erule.split("|");erule = erule.filter(item => item);var ri = 0;
            emark = emark.split("|");emark = emark.filter(item => item);var mi = 0;
            egrade = egrade.split("|");egrade = egrade.filter(item => item);var gi = 0;
            outofmark = outofmark.split("|");outofmark = outofmark.filter(item => item);var oi = 0;
            
            for(var i = 0 ; i < ele.length; i++){
                trEle = $("<tr></tr>").attr("role","row").attr("class","even");
                        $(trEle).attr("attr-streams",stream);
                tdEle1 = $("<td></td>");tdEle2 = $("<td></td>");tdEle3 = $("<td></td>");tdEle4 = $("<td></td>");tdEle5 = $("<td></td>");
                spanEle=$("<span></span>");spanEle.addClass("lsubject");
                trEle.attr("attr-ide",indiviIDE);
                if(type === "1") {
                    
                    inpEle = $("<select><option value=\"\">Select Grade</option></select>").attr("class","grade").css("width","50%");
                    for(var j = 0 ; j < grade.length; j++){
                        
                         $(inpEle).append("<option >"+grade[j]+"</option>");
                       
                    }
                    trEle.attr("attr-grade","y");
                    inpEle1 =$("<input />").attr("type","text").attr("class",'outofmark').attr("disabled","disabled");
                } else { inpEle =$("<input />").attr("type","text").attr("class",'mark'); trEle.attr("attr-grade","n");
                          inpEle.keyup(function(){
                               var numchk = new RegExp("^[0-9]*$");  
                               if( numchk.test( $(this).val() ) ){  } else { $(this).val("");alert('invalid key');}
                          });
                           inpEle1 =$("<input />").attr("type","text").attr("class",'outofmark');
                          inpEle1.keyup(function(){
                               var numchk = new RegExp("^[0-9]*$");  
                               if( numchk.test( $(this).val() ) ){  } else { $(this).val("");alert('invalid key');}
                          });
                }
                
                checkEle = $("<input />").attr("type","checkbox").attr("class","chkbox");
                
                
                var re = new RegExp(ele[i], 'g');
                 var myMatch = esubject.match(re);
                 if((myMatch !== null)&&(estream === stream) ){  checkEle.attr("checked","checked");}
                 if((myMatch !== null)&&(type === '1')&&(estream === stream))  {
                     $(inpEle).val(egrade[gi]);gi++;                     
                 }
                 
                 if((myMatch !== null)&&(type === '0')&&(estream === stream))  {
                     $(inpEle).val(emark[mi]);mi++;                     
                 }
                
                
                checkEle.addClass("subsel");
                selectEle = $("<select></select>").attr("class","rule").css("width","50%");
                selectEle.addClass('subrule');
                $(selectEle).html("<option value=\"GTE\">Greater Than</option><option value=\"LTE\">Less Than</option>");
                
                if((myMatch !== null)&&(estream === stream))  {
                     $(selectEle).val(erule[ri]);ri++;                     
                 }
                
                labelEle1 = $("<label></label>").attr("class","chkLabel");
                labelEle1.append(checkEle);
                tdEle1.append(labelEle1);
                tdEle2.append(spanEle.text(ele[i]));
                
                labelEle = $("<label></label>").attr("class","dropLabel");
                labelEle.append(selectEle);
                tdEle3.append(labelEle);
                
                labelEle1 = $("<label></label>").attr("class","dropLabel");
                labelEle1.append(inpEle);
                tdEle4.append(labelEle1);
                
                labelEle1 = $("<label></label>");
                labelEle1.append(inpEle1);
                tdEle5.append(labelEle1);
                if((myMatch !== null)&&(estream === stream))  {
                     $(inpEle1).val(outofmark[oi]);oi++;                     
                 }
                
                
                trEle.append(tdEle1);trEle.append(tdEle2);trEle.append(tdEle3);trEle.append(tdEle4);trEle.append(tdEle5);
                
                $(tableEle).find("tbody").append(trEle);
                tdEle1='';tdEle2='';tdEle3='';spanEle='';inpEle = '';trEle = "";selectEle=""
                labelEle1="";labelEle="";checkEle="";
                
                //append total mark - start
                 if(i === (ele.length -1)){
                     
                    var selectEle1 = $("<select></select>").attr("class","rule").css("width","50%");
                    selectEle1.addClass('trule');
                    $(selectEle1).html("<option value=\"GTE\">Greater Than</option><option value=\"LTE\">Less Than</option>");
                    var tdEle5 = $("<td></td>");var tdEle6 = $("<td></td>");
                    var inpEle2 =$("<input />").attr("type","text").attr("class",'totmark').css("width","100px").css("border-top","0px").css("border-left","0px").css("border-right","0px");
                          inpEle2.keyup(function(){
                               var numchk = new RegExp("^[0-9]*$");  
                               if( numchk.test( $(this).val() ) ){  } else { $(this).val("");alert('invalid key');}
                          });
                   var trEle1= $('<tr class="even" role="row" attr-streams="'+stream+'"><td></td><td>Total Mark</td></tr>');
                   if(type === "1") { trEle1.attr("attr-grade","y");} else { trEle1.attr("attr-grade","n");}
                   var labelEle2 = $("<label></label>").attr("class","dropLabel");
                   labelEle2.append(selectEle1);
                   if((estream === stream) && (trule != ''))  {
                     $(selectEle1).val(trule);                    
                    }
                   tdEle5.append(labelEle2);
                   tdEle6.append(inpEle2);
                   if(estream === stream)  {
                     $(inpEle2).val(total);                    
                    }
                    
                   trEle1.append(tdEle5);
                   trEle1.append(tdEle6);
                   $(tableEle).find("tbody").append(trEle1);
                     
                 }
            
                 //append total mark - end
            }
            
            
            $(tableEle).find(".grade").selectmenu();
            $(tableEle).find(".rule").selectmenu();
            $(tableEle).find(".chkbox").checkboxradio();
    
    }
    
        $(".xii_std").find(".radiocenters1").each(function(){
        
           $(this).click(function(){ 
         
        var ide = $(this).attr("attr-centers");
        var ininde = "";
        $("#subjecttable1").find("tbody tr").each(function(){
            var y= $(this).attr("attr-streams");
            if( y === ide) {
                $(this).css("display",""); ininde = $(this).attr("attr-ide");
            } else {  $(this).css("display","none"); }
        });
        
         $(this).attr("attr-ide",ininde);
         
         $(genDataXII).each(function(index) {

                var streamArr  = genDataXII[index];
                if(streamArr.stream === ide){
                    
                    $(".xii_rule").val(streamArr.rule);$(".xii_rule").selectmenu("refresh");
                    $(".xii_year").val(streamArr.year);$(".xii_year").selectmenu("refresh");
                    $(".xii_class").val(streamArr.class); $(".xii_class").selectmenu("refresh");
                    if(streamArr.rollno === "Y") {
                        $(".xii_rollno").prop("checked", true).checkboxradio('refresh');
                    } else { 
                        $(".xii_rollno").prop("checked", false).checkboxradio('refresh');
                    }
                    if(streamArr.gracemark === "Y") { 
                        $(".xii_gracemark").prop("checked", true).checkboxradio('refresh');
                    } else { 
                        $(".xii_gracemark").prop("checked", false).checkboxradio('refresh');
                    }
                    if(streamArr.resultwaiting === "Y") { 
                        $(".xii_waitingresult").prop("checked", true).checkboxradio('refresh');
                    } else { 
                        $(".xii_waitingresult").prop("checked", false).checkboxradio('refresh');
                    }
                    if(streamArr.resultcompleted === "Y") { 
                        $(".xii_completed").prop("checked", true).checkboxradio('refresh');
                    } else {
                        $(".xii_completed").prop("checked", false).checkboxradio('refresh');
                    }
                    
                }
                
            });
        
        });
      
               
     });
     
     $(".x_std").find(".radiocenters").each(function(){
        
           $(this).click(function(){ 
         
        var ide = $(this).attr("attr-centers");
        var ininde = "";
        $("#subjecttable").find("tbody tr").each(function(){
            var y= $(this).attr("attr-streams");
            if( y === ide) {
                $(this).css("display",""); ininde = $(this).attr("attr-ide");
            } else {  $(this).css("display","none"); }
        });
        
        $(this).attr("attr-ide",ininde);
        
        $(genData).each(function(index) {

                var streamArr  = genData[index];
                if(streamArr.stream === ide){
                    
                    $(".qualification_rule").val(streamArr.rule);$(".qualification_rule").selectmenu("refresh");
                    $(".qualification_year").val(streamArr.year);$(".qualification_year").selectmenu("refresh");
                    $(".qclass").val(streamArr.class); $(".qclass").selectmenu("refresh");
                    if(streamArr.rollno === "Y") {
                        $(".rollno").prop("checked", true).checkboxradio('refresh');
                    } else { 
                        $(".rollno").prop("checked", false).checkboxradio('refresh');
                    }
                    if(streamArr.gracemark === "Y") { 
                        $(".gracemark").prop("checked", true).checkboxradio('refresh');
                    } else { 
                        $(".gracemark").prop("checked", false).checkboxradio('refresh');
                    }
                    if(streamArr.resultwaiting === "Y") { 
                        $(".waitingresult").prop("checked", true).checkboxradio('refresh');
                    } else { 
                        $(".waitingresult").prop("checked", false).checkboxradio('refresh');
                    }
                    if(streamArr.resultcompleted === "Y") { 
                        $(".completed").prop("checked", true).checkboxradio('refresh');
                    } else {
                        $(".completed").prop("checked", false).checkboxradio('refresh');
                    }
                    
                }
                
            });
        
        });
      
               
     });
     
   $('.qualification_rule').on('selectmenuchange', function() {
        var stream = $('.streams input[name=radiocenters]:checked').attr("attr-centers");
        setGenArr(stream,this,"rule",genData);       
    });
    
    $('.qclass').on('selectmenuchange', function() {
        var stream = $('.streams input[name=radiocenters]:checked').attr("attr-centers");
        setGenArr(stream,this,"class",genData);       
    });
    
    $('.qualification_year').on('selectmenuchange', function() {
        var stream = $('.streams input[name=radiocenters]:checked').attr("attr-centers");
        setGenArr(stream,this,"year",genData);        
    });
    
    $('.rollno').click(function() {
        var stream = $('.streams input[name=radiocenters]:checked').attr("attr-centers");
        setGenArr(stream,this,"rollno",genData);       
    });
    
     $('.gracemark').click(function() {
        var stream = $('.streams input[name=radiocenters]:checked').attr("attr-centers");
        setGenArr(stream,this,"gracemark",genData);       
    });
    
     $('.waitingresult').click(function() {
        var stream = $('.streams input[name=radiocenters]:checked').attr("attr-centers");
        setGenArr(stream,this,"resultwaiting",genData);       
    });
    
    
     $('.completed').click(function() {
        var stream = $('.streams input[name=radiocenters]:checked').attr("attr-centers");
        setGenArr(stream,this,"resultcompleted",genData);       
    });
    
    //xii standard
    
     $('.xii_rule').on('selectmenuchange', function() {
        var stream = $('.streams input[name=radiocenters1]:checked').attr("attr-centers");
        setGenArr(stream,this,"rule",genDataXII);       
    });
    
    $('.xii_class').on('selectmenuchange', function() {
        var stream = $('.streams input[name=radiocenters1]:checked').attr("attr-centers");
        setGenArr(stream,this,"class",genDataXII);       
    });
    
    $('.xii_year').on('selectmenuchange', function() {
        var stream = $('.streams input[name=radiocenters1]:checked').attr("attr-centers");
        setGenArr(stream,this,"year",genDataXII);        
    });
    
    $('.xii_rollno').click(function() {
        var stream = $('.streams input[name=radiocenters1]:checked').attr("attr-centers");
        setGenArr(stream,this,"rollno",genDataXII);       
    });
    
     $('.xii_gracemark').click(function() {
        var stream = $('.streams input[name=radiocenters1]:checked').attr("attr-centers");
        setGenArr(stream,this,"gracemark",genDataXII);       
    });
    
     $('.xii_waitingresult').click(function() {
        var stream = $('.streams input[name=radiocenters1]:checked').attr("attr-centers");
        setGenArr(stream,this,"resultwaiting",genDataXII);       
    });
    
    
     $('.xii_completed').click(function() {
        var stream = $('.streams input[name=radiocenters1]:checked').attr("attr-centers");
        setGenArr(stream,this,"resultcompleted",genDataXII);       
    });
    
    function setGenArr(ide,ele,type,obj){
        
         $(obj).each(function(index) {

                var streamArr  = obj[index];
                if(streamArr.stream === ide){
                    
                    switch(type) {
                        case "rule":
                         streamArr.rule = $(ele).val();
                          break;
                        case "class":
                          streamArr.class = $(ele).val();
                          break;
                        case "year":
                          streamArr.year = $(ele).val();
                          break;
                        case "rollno":
                          var local ="";
                          if($(ele).is(":checked")) {local="Y";} else { local="N";}
                          streamArr.rollno = local;
                          break; 
                        case "gracemark":
                          var local ="";
                          if($(ele).is(":checked")) {local="Y";} else { local="N";}
                          streamArr.gracemark = local;
                          break; 
                        case "resultwaiting":
                          var local ="";
                          if($(ele).is(":checked")) {local="Y";} else { local="N";}
                          streamArr.resultwaiting = local;
                          break;  
                        case "resultcompleted":
                          var local ="";
                          if($(ele).is(":checked")) {local="Y";} else { local="N";}
                          streamArr.resultcompleted = local;
                          break;
                        default:
                          // code block
                    } 
                                       
                }
                
            });
        
    }
         
    $("#add_more").click(function(){
        var trEle = $("<tr></tr>");
        var selectEle = $("<select></select>").attr("class","rule");
        selectEle.addClass('exam_rule');
        $(selectEle).html("<option value=\"\">Rule</option><option value=\"GTE\">Greater Than</option><option value=\"LTE\">Less Than</option>");
        //$(selectEle).selectmenu();
        
        var tdEle = $("<td></td>");
        var inpELe = $("<input />").attr("type","text").attr("class",'exam_name').attr("placeholder",'Add Entrance Exam Name');
        $(tdEle).append(inpELe);
        
        var tdEle1 = $("<td></td>");
        $(tdEle1).append(selectEle);
        
        var tdEle2 = $("<td></td>");
        var inpELe2 = $("<input />").attr("type","text").attr("class",'exam_value').attr("placeholder",'Value');
        $(tdEle2).append(inpELe2);
        
        var tdEle3 = $("<td></td>");
        var inpELe3 = $("<input />").attr("type","text").attr("class",'exam_outoffmark').attr("placeholder",'Out off mark');
        $(tdEle3).append(inpELe3);
        
        $(trEle).append(tdEle);$(trEle).append(tdEle1);$(trEle).append(tdEle2);
        $(trEle).append(tdEle3);
        
        
        $(".entrance_exam").find(".sortable").append(trEle);
        $(".entrance_exam").find(".sortable").find(".rule").selectmenu();
    });
    
             
     $(".savebtn").click(function(){
         
               if($(".response").hasClass('progress')) { return;}
               $(".response").html('').text('Progressing...');
                $(".response").addClass('progress');
               
                  
               var entranceexam = '';var entrancerule = '';var entrancevalue = '';var entranceoutoffmark = '';
               $(".entrance_exam").find(".exam_name").each(function(){
                   
                   if($(this).val() !== "") { entranceexam += $(this).val()+"|"; }
                   
                });
                
                 $(".entrance_exam").find(".exam_rule").each(function(){
                   
                   if($(this).val() !== "") { entrancerule += $(this).val()+"|"; }
                   
                });
                
                 $(".entrance_exam").find(".exam_value").each(function(){
                   
                   if($(this).val() !== "") { entrancevalue += $(this).val()+"|"; }
                   
                });
                
                
                 $(".entrance_exam").find(".exam_outoffmark").each(function(){
                   
                   if($(this).val() !== "") { entranceoutoffmark += $(this).val()+"|"; }
                   
                });
 
                 $(".x_std").find(".radiocenters").each(function(){
        
                    var lstream = $(this).attr("attr-centers");
                    var subject = ''; var rule = '';var mark = '';var grade = ''; 
                    var outofmark = '';var mtotal = '';var trule = '';
                     $("#subjecttable").find(".subsel").each(function(){
                   
                        if( ($(this).is(":checked")) ) { 

                            var key = $(this).closest("tr").attr("attr-streams");
                            
                            if(lstream === key) {
                               
                                var t= $(this).closest("tr").find(".lsubject").text();
                                subject = subject+"|"+t;

                                var y= $(this).closest("tr").find(".subrule").val();
                                rule = rule+"|"+y;
                                
                                var z= $(this).closest("tr").find(".outofmark").val();
                                outofmark = outofmark+"|"+z;

                                var attrgrade = $(this).closest("tr").attr("attr-grade");
                                if(attrgrade === 'y') { 

                                    grade =  grade+"|"+$(this).closest("tr").find(".grade").val();

                                } else {
                                    mark =   mark+"|"+$(this).closest("tr").find(".mark").val();
                                }
                        
                            }
                        }

                      });
                      
                      $("#subjecttable").find(".totmark").each(function(){
                          var tstream = $(this).closest("tr").attr("attr-streams");
                          if(tstream === lstream){
                              mtotal = $(this).val();
                          }
                      });
                      
                       $("#subjecttable").find(".trule").each(function(){
                          var tstream = $(this).closest("tr").attr("attr-streams");
                          if(tstream === lstream){
                              trule = $(this).val();
                          }
                      });
                      
                       $(genData).each(function(index) {

                            var streamArr  = genData[index];
                            if(streamArr.stream === lstream){
                                streamArr.subject = subject;
                                streamArr.qrule = rule;
                                streamArr.qmark = mark;
                                streamArr.qgrade = grade;
                                streamArr.outofmark = outofmark;
                                 streamArr.trule = trule;
                                streamArr.mtotal = mtotal;
                            }
                        });
               
                });
                
                
             //XII
             var xii_flag = "0";
             if($("#show_xii").is(":checked")) { 
                 
                 xii_flag ="1";
             
                $(".xii_std").find(".radiocenters1").each(function(){
        
                    var lstream = $(this).attr("attr-centers");
                    var subject = ''; var rule = '';var mark = '';var grade = ''; 
                    var outofmark = '';var mtotal = '';var trule = '';
                     $("#subjecttable1").find(".subsel").each(function(){
                   
                        if( ($(this).is(":checked")) ) { 

                            var key = $(this).closest("tr").attr("attr-streams");
                            
                            if(lstream === key) {
                               
                                var t= $(this).closest("tr").find(".lsubject").text();
                                subject = subject+"|"+t;

                                var y= $(this).closest("tr").find(".subrule").val();
                                rule = rule+"|"+y;
                                
                                var z= $(this).closest("tr").find(".outofmark").val();
                                outofmark = outofmark+"|"+z;

                                var attrgrade = $(this).closest("tr").attr("attr-grade");
                                if(attrgrade === 'y') { 

                                    grade =  grade+"|"+$(this).closest("tr").find(".grade").val();

                                } else {
                                    mark =   mark+"|"+$(this).closest("tr").find(".mark").val();
                                }
                        
                            }
                        }

                      });
                      
                      $("#subjecttable1").find(".totmark").each(function(){
                          var tstream = $(this).closest("tr").attr("attr-streams");
                          if(tstream === lstream){
                              mtotal = $(this).val();
                          }
                      });
                      
                       $("#subjecttable1").find(".trule").each(function(){
                          var tstream = $(this).closest("tr").attr("attr-streams");
                          if(tstream === lstream){
                              trule = $(this).val();
                          }
                      });
                      
                       $(genDataXII).each(function(index) {

                            var streamArr  = genDataXII[index];
                            if(streamArr.stream === lstream){
                                streamArr.subject = subject;
                                streamArr.qrule = rule;
                                streamArr.qmark = mark;
                                streamArr.qgrade = grade;
                                streamArr.outofmark = outofmark;
                                streamArr.trule = trule;
                                streamArr.mtotal = mtotal;
                            }
                        });
                                 
               
                });
                
            } else { xii_flag ="0";}
		 
		 
		 		var classstudy = $("#classstudy").val();
		 
		 		// Marsheet Upload 
		 
		 		var marksheet_flag = "0";
				if($(".marksheet_flag").is(":checked")) marksheet_flag = "1";
		 
		 		var marksheet_info = $.trim($(".marksheet_info").val());
     
               var qname = $(".qname").val();
                   $.ajax({
                        url: 'qualification/qualificationSubmit',
                        type: 'post',
                        data:{ 'qualid':'<?php echo $qualification['general']['qualificationid'];?>','qname':qname,'exam':entranceexam,'rexam':entrancerule,'vexam':entrancevalue,'oexam':entranceoutoffmark,'ide':'<?php  $ide = $this->input->get('id', true); echo $ide;?>','x':JSON.stringify(genData),'xii_flag':xii_flag,'marksheet_flag':marksheet_flag,'marksheet_info':marksheet_info,'xii':JSON.stringify(genDataXII),'classstudy':classstudy},
                        success: function(o){
                            var response = $.parseJSON(o);
                            $(".response").html('');
                            if(response.status === 'success') {
                                $(".response").css("color","rgb(25, 71, 15)");
                               $(".response").text(response.message);
                               $(location).prop('href', 'qualificationlist');
                            } else {
                                
                               $(".response").append(response.message); 
                                $(".response").removeClass('progress');
                           
                            }

                        }
                    });
                   
                              
            });
    
           
    });
    </script>
   
 
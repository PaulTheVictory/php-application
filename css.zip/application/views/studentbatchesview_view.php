<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/dataTables.css?v=1.6" />
<script src="<?php echo base_url(); ?>js/jquery.dataTables.js?v=1.0" type="text/javascript"></script>
<link rel="stylesheet" href="<?php echo base_url();?>css/boot/bootstrap.min.css">
<script src="<?php echo base_url();?>js/bootstrap.bundle.min.js"></script>
<style type="text/css">


.dataTables_wrapper input[type="text"] {
    padding: 0;
}
.dataTables_wrapper select {
    padding: 0;
}

.sortable thead tr  {
    background: #E6EBF7;

/* g8 */
border: 1px solid #D7DFF0;
box-sizing: border-box;
border-radius: 10px 10px 0px 0px;
 

}
.sortable tr th {
    border-right: 0px;
    padding: 15px 0;font-size: 13px;
      color: #6F83AA;
   cursor: pointer;
   text-align: center;
	text-transform: uppercase;

}

.sortable tr th:nth-child(3) {
  text-align: left;
}

.sortable tr td:nth-child(3) {
  text-align: left;
}

.sortable tr td {
    border-right: 0px;
    padding: 5px 5px;
    text-align: center;font-size: 13px;
    min-width:50px;vertical-align: middle;
}
.sortable tr td a {
    color: #364159;
}

#profile-right h2 {
    margin: 0px 0px 10px 0px;
}

.resultstable_length { width: auto !important; }
#resultstable_filter input { padding-top:4px;background: #fff url('<?php echo base_url(); ?>/images/search.png') no-repeat center left;background-position-x: 10px;border: 1px solid #D7DFF0; line-height: 32px;margin-left: 10px;width:260px;border-radius: 5px;text-indent: 30px;font-size: 13px;}
.sortable tr td a:hover { text-decoration: underline; }
.dataTables_filter { right:10px !important;}
	
	/* Import Admission */
	
	.btn-primary{background-color: #0332AA;color: #ffffff;border-color: #0332AA;font-weight: 600;}
	.btn-primary:not(:disabled):not(.disabled).active, .btn-primary:not(:disabled):not(.disabled):active, .show>.btn-primary.dropdown-toggle,.btn-primary:hover{background-color: rgba(3,50,170,0.8);}
	
	.btn-outline-primary {color: #0332AA;border-color: #0332AA;font-weight: 600;}
	.btn {border-radius: 5px;outline: initial!important;box-shadow: none!important;box-shadow: initial!important;font-size: .8rem;padding: .5rem 1.25rem .5rem 1.25rem;transition: background-color box-shadow .1s linear;margin-bottom: 0px}
	.btn-outline-primary:not(:disabled):not(.disabled).active, .btn-outline-primary:not(:disabled):not(.disabled):active, .show>.btn-outline-primary.dropdown-toggle,.btn-outline-primary:hover {background-color: #0332AA;border-color: #0332AA;color: #fff;}
	p.alert{font-size: 14px;padding: .45rem 1.25rem;}
	p.alert-danger {color: #721c24;}
	p.alert-success {color: #155724;}
	
	#importmessage{text-align: left;line-height: 20px;font-size: 14px;}
	
	#importmessage hr{display: block;margin: 0.5rem auto;border-style: dashed;border-color: #0332AA}
	.maincontent h3{font-size: 16px;color: #0332AA}
	.maincontent h3 span{color: #333;}
	
	.maincontent p{margin-bottom: 0.2rem;font-size: 12px;line-height: 14px;}
	.maincontent p.success{color: #02F042}
	.maincontent p.fail{color: #FF1A1E}
	.maincontent p.exists{color: #FF7600}
	
	.exam p{font-size: 14px;font-weight: bold;color: #6F83AA;}
	.exam p span {font-size: 18px !important;font-weight: bold;font-size: 14px;color: #0332AA;line-height: 25px}
	
	.dataTables_processing{height: auto}
	
	/* Upload files*/	
	
	.box {position: relative;background: #ffffff;width: 100%;}
	.box-header {color: #444;display: block;padding: 10px;position: relative;border-bottom: 1px solid #f4f4f4;margin-bottom: 10px;}
	.box-tools {position: absolute;right: 10px;top: 5px;}
	.dropzone-wrapper {background: #F6F7FA;border: 1px dashed #BCCAE8;color: #92b0b3;position: relative;height: 40px;border-radius: 5px;}
	.dropzone-desc {position: absolute;margin: 0 auto;left: 0;right: 0;text-align: center;width: auto;top: 5px;font-size: 16px;}
	.dropzone,
	.dropzone:focus {position: absolute;outline: none !important;width: 100%;height: 40px;cursor: pointer;opacity: 0;}
	.dropzone-wrapper:hover,
	.dropzone-wrapper.dragover {background: #ecf0f5;}
	.preview-zone {text-align: center;}
	.preview-zone .box {box-shadow: none;border-radius: 0;margin-bottom: 0;}
	#filename {margin-top: 10px;margin-bottom: 10px;font-size: 14px;line-height: 2.7em;border: 1px solid #D7DFF0;
    border-radius: 5px;min-height: 40px;margin-top: 2.2rem;}
	.file-preview {background: #ccc;border: 5px solid #fff;box-shadow: 0 0 4px rgba(0, 0, 0, 0.5);display: inline-block;width: 60px;height: 60px;text-align: center;font-size: 14px;margin-top: 5px;}
	.closeBtn:hover {color: red;display:inline-block;}
	
	.icon-upload{background: url("img/icons/upload.png") no-repeat;width: 24px;height: 24px;display: inline-block;vertical-align: middle}
	.dropzone-desc p.list-item-heading{font-size: 14px;font-weight: 600;color: #536485;display: inline-block}
	.dropzone-desc p.text-muted{font-size: 10px;font-weight: normal;color: #6F83AA;}
	.dropzone-desc p.list-item-heading span{color: #db4d4d}
	
	p.alert-info{font-weight: 600;font-size: 14px;color: #355BBB;}
		
</style>
<script type="text/javascript">
	
	var oTable = "";
	
$(document).ready(function(){	
	    	
		 var oTable = $('#resultstable').dataTable({
					"processing": true,
					"sPaginationType": "full_numbers",
			 		"oLanguage": {
                        "sProcessing": "<img src='<?php echo base_url(); ?>images/loader.gif'>",
						 "sEmptyTable": "No Results Found"
                    },
                    "columns": [
							{ title: "Sno" },
							{ title: "Student ID" },
							{ title: "Student Name" },
							{ title: "Course Name" },
							{ title: "Actions" }
						],
			 			"columnDefs": [
							{
								"targets": 1,
								"render": function ( data, type, row ) {//console.log(row[15]);
									if (type === "display") {
										return "<a href=\"studentprofile?sid=" + encodeURIComponent(row[15]) + "\" target=\"_blank\">" + data + "</a>";
									}

									return data;
								}
							}
						],
                    //"order": [[ 0, "desc" ]],
                    "fnDrawCallback": function( oSettings ) {
                        
    }
 }); 
	
	loadresults(oTable);
	
	
	$("#uploadresults").change(function(){
		
		var filename = $(this).val().replace(/C:\\fakepath\\/i, '');
		
		if(filename!=""){
			$(".alert").removeClass('alert-danger alert-success').addClass('alert-info').text(filename);
			$(".cancelresults").removeClass('d-none');
		}else{
			$(".cancelresults").addClass('d-none');
		}
		
	});
	
	
	 $(".importresults").click(function(){
		  
		 var uploadfile = $("#uploadresults").val();
		 var bname = "<?php echo $_GET['bname']; ?>";
		 
		 if(uploadfile==""){
			 $(".alert").removeClass('alert-success alert-info').addClass('alert-danger').text("Upload batches file");
			 return;
		 }		 
		 
		if($(".importresults").hasClass('process')){
			
			$(".alert").removeClass('alert-success alert-info').addClass('alert-danger').text("Please wait while uploading...");
			
		}else{
		
			$(".importresults").addClass('process');
			$(".alert").removeClass('alert-danger alert-info').addClass('alert-success').text("Uploading batches...");
			
			$(".loader").removeClass('d-none');
         		 
		 var formData = new FormData();
		 
		 var c=0;
		 var file_data,file;
		 $('input[type="file"]').each(function(){
			  file_data = $('input[type="file"]')[c].files; // get multiple files from input file
			  //console.log(file_data);
		   for(var i = 0;i<file_data.length;i++){
			   formData.append('file[]', file_data[i]); // we can put more than 1 image file
		   }
		  c++;
	    }); 
			
			formData.append('bname', bname);
		 
		 $.ajax({
                type: 'POST',
                url: 'studentbatches/uploadBatchresults',
                data: formData,
			    contentType: false,
    			processData: false,
                success: function(response) {
                   
					var obj1 = $.parseJSON(response);
							
					$(".loader").addClass('d-none');
					
					if(obj1['status']=="success"){
						
						$(".alert").addClass('alert-success').text("Batches uploaded successfully.");
						
						$("#resultmessage").html(obj1['message']);
						
						//dataSet = obj1['tabledata'];
						
						$("#uploadresults").val('');
						$(".importresults").removeClass('process');
						//$(".approveresults").removeClass('d-none');
						
						loadresults(oTable);
																		
						setTimeout(function(){
							$(".alert").removeClass('alert-success').text("");
							//location.reload();
						},3000);
						
					}else if(obj1['status']=="empty"){
						$(".importresults").removeClass('process');
						$(".alert").removeClass('alert-success').addClass('alert-danger').text("Upload batches file");
					}else if(obj1['status']=="ufail"){
						$(".importresults").removeClass('process');
						$(".alert").removeClass('alert-success').addClass('alert-danger').text("Upload failed");
					}else if(obj1['status']=="exfail"){
						$(".importresults").removeClass('process');
						$(".alert").removeClass('alert-success').addClass('alert-danger').text("Support extension XLS only");
					}else if(obj1['status']==""){
						$(".importresults").removeClass('process');
						$(".alert").removeClass('alert-success').addClass('alert-danger').text("Please try again.");
					}
					
                }

            });
			
		}
		
		   
	 }); 
	
	
	$('#newimportModal').on('hidden.bs.modal', function () {
  		
		$(".loader,.updateloader").addClass('d-none');
		$(".alert").removeClass('alert-success alert-danger alert-info').text("");
		$("#resultmessage").html("");
		//$(".approveresults").removeClass('process');
		
	});
	
	
	$(document).on("click",".del",function(){
		
		var bname = "<?php echo $_GET['bname'] ?>";
		var studentid = $(this).data('stuid');
		var courseid = $(this).data('cid');
		
		$(".loader").removeClass('d-none');
		$(".alert").removeClass('alert-danger alert-info').addClass('alert-success').text("Processing...");
		
		var r = confirm("Are you sure to delete this student?");
		
		if(r){
		
		$.ajax({
                type: 'POST',
                url: 'studentbatches/deleteBatchResults',
                data: {"bname":bname,"studentid":studentid,"courseid":courseid},
                success: function(response) {
                   				
					var obj1 = $.parseJSON(response);
					
					//$(".approveresults").removeClass('process');
					$(".loader").addClass('d-none');
					
					if(obj1[0]=="success"){
											
						$(".alert").addClass('alert-success').text("Results data cleared.");
						$(".approveresults").addClass('d-none');
						
						loadresults(oTable);
														
					}
					
					setTimeout(function(){
						
						$("#uploadresults").val('');
						$(".loader,.updateloader").addClass('d-none');
						$(".alert").removeClass('alert-success alert-danger alert-info').text("");
						$("#resultmessage").html("");
						//$(".approveresults").removeClass('process');
						
					},2000);
					
				}
		
			});
			
		}
				
	});
	
	
	$('.cancelresults').click(function(){
		
		$("#uploadresults").val('');
		$(".loader,.updateloader").addClass('d-none');
		$(".alert").removeClass('alert-success alert-danger alert-info').text("");
		$("#resultmessage").html("");
		
	});
	
	
	$("input,select,textarea").click(function(){
		
		$(".alert").removeClass('alert-success alert-danger alert-info').text("");
		
	});

	
});
	
	
function loadresults(oTable){
	
	$(".dataTables_processing").show();
	
	$.ajax({
                type: 'POST',
                url: 'studentbatches/getBatchResults',
                data: {"bname":"<?php echo $_GET['bname']; ?>","status":"n"},
                success: function(response) {
                   
					var obj1 = $.parseJSON(response);
					
					$(".dataTables_processing").hide();
					
					if(obj1['tabledata'].length>0){
						
						oTable.fnClearTable();
						oTable.fnAddData(obj1['tabledata']);
						oTable.fnDraw();
						
						//$(".approveresults").removeClass('d-none');
						
					}
					
				}
		
	});

}
	
</script>


<div class="wrap dynamic-width" style="float: left;position: relative">
    
    
   			<div class="row w-100 align-items-center">
        	      
			  <div class="col-7 justify-content-center">

				<div style="margin-top: 10px; width: 100%; height: 50px; text-align: right;">
				 <span style="font-weight: bold;font-size: 20px;padding: 10px;float:left;color: #364159"><?php echo ucwords($batch['batchname']);?></span>
				</div>

				</div>
             
             	<?php if(isset($roleaccess['Batches'][1]) && $roleaccess['Batches'][1]=="y"){ ?>
             
             		<div class="col-5 text-right justify-content-end"><a href="docs/batches/batchestemplate.xls"><button type="button" class="btn btn-outline-primary">Download Template</button></a></div>
             	
             	<?php } ?>
             	
              <!--<div class="col-2 text-right justify-content-center">
              	<a href="examresults?id=<?php //echo $_GET['id'];?>"><button type="button" class="btn btn-primary">Upload Batch</button></a>
              </div>-->
              
			</div>
              
              <div class="row my-4 w-100 align-items-center exam">
              
				  <div class="col-12 justify-content-center"><p>Courses: <span><?php echo ucwords($batch['coursenames']);?></span></p></div>
              	  
			  </div>
            
              <div class="row mb-3 w-100 exam">
             	  	
             	  	<div class="col-3"><p>Co-ordinator Name: <span><?php echo $batch['coordinatoname'];?></span></p></div>
					<div class="col-3"><p>Created: <span><?php echo date("d-M-Y",strtotime($batch['created_at']));?></span></p></div>
             	  	
             	  </div>
                        
                        
              <?php if(isset($roleaccess['Batches'][1]) && $roleaccess['Batches'][1]=="y"){ ?>          
                         
            
            <div class="w-100 my-4 d-inline-block">
            
						<div class="card col-12 p-3 mb-4">

					 <div class="row align-items-center w-100">
					
					<div class="col-11 justify-content-start">
					
						<div id="drop-zone">
							<div class="dropzone-wrapper">
							  <div class="dropzone-desc" id="clickHere">
								<i class="icon-upload mb-2"></i>
								<p class="list-item-heading mb-1">Upload Batch</p>
							  </div>
							  <input type="file" name="uploadresults[]" id="uploadresults" class="dropzone">
							 
							</div>
							 
						</div>
						 
						 </div>
							 
							 <div class="col-1 justify-content-start text-right pr-0">       				 
                            				 
								<button type="button" class="btn btn-primary importresults">Upload</button>
                            				 
				   			</div>
				   
						 </div>
							 
							 <div class="border-bottom my-4"></div>
						
						
						<div class="row align-items-center w-100">
					
							<div class="col-6 d-flex justify-content-start">
							
								<div class="loader d-none">
									<img src='<?php echo base_url(); ?>images/loader.gif'>
								</div>
								
								 <p class="alert mb-0"></p>   
								 
							</div>
							
							<div class="col-6 justify-content-start text-right pr-0">
								
								<button type="button" class="btn btn-outline-primary cancelresults">Cancel</button>
								<!--<button type="button" class="btn btn-primary d-none approveresults">Approve Results</button>-->
								
							</div>
			   		
							</div> 
				   		
								<!--<div id='filename'><?php //echo $marksheetlist;?></div>-->
							  </div>
							  
							
				   
					  </div> 
                         
                                                  
                <?php } ?>                                                           
                                                                                                                             
                          
			<div class="my-4 d-inline-block"></div>
               
       	    
		<table id="resultstable" class="sortable" style="width:100%">
		
		
	</table>
       	        
       	                                                  
     <div id="resultmessage" class="my-4"></div>  	                                                                                                      
        	                                                  
  </div>
 
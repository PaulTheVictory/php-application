<script src="<?php echo base_url();?>js/bootstrap.bundle.min.js"></script>
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/dataTables.css?v=1.6" />
<script src="<?php echo base_url(); ?>js/jquery.dataTables.js?v=1.0" type="text/javascript"></script>
<link rel="stylesheet" href="<?php echo base_url();?>css/boot/bootstrap.min.css">
<link rel="stylesheet" href="<?php echo base_url();?>css/boot/main.css?v=1">


<style type="text/css">


.dataTables_wrapper input[type="text"] {
    padding: 0;
}
.dataTables_wrapper select {
    padding: 0;
}

.sortable thead tr  {
    background: #E6EBF7;

/* g8 */
border: 1px solid #D7DFF0;
box-sizing: border-box;
border-radius: 10px 10px 0px 0px;
 

}
.sortable tr th {
    border-right: 0px;
    padding: 15px 0;font-size: 13px;
      color: #6F83AA;
   cursor: pointer;
   text-align: center;

}

.sortable tr td:nth-child(1) {
  width:100px;
}

.sortable tr td:nth-child(2) {
  background: none;
   text-align: center;
}

.sortable tr th:nth-child(2) {
  background: #E6EBF7 url('<?php echo base_url(); ?>/images/datatable/sort_both.png') no-repeat center left;
  background-position-x: 110px;
  background-position-y: 16px;
   text-align: center;
}

.sortable tr td p { margin: 5px; }
.sortable tr td {
    border-right: 0px;
    padding: 0px;
    text-align: center;font-size: 13px;
    min-width:80px;vertical-align: middle;color:#000;
}
.sortable tr td a {
    color: #364159;
}

#profile-right h2 {
    margin: 0px 0px 10px 0px;
}

#templatetable_filter { width: auto !important; right:150px;}
#templatetable_filter input { padding-top:4px;background: #fff url('<?php echo base_url(); ?>/images/search.png') no-repeat center left;background-position-x: 10px;border: 1px solid #D7DFF0; line-height: 32px;margin-left: 10px;width:260px;border-radius: 5px;text-indent: 30px;font-size: 13px;}
.sortable tr td a:hover { text-decoration: underline; }
</style>
<script type="text/javascript">
$(document).ready(function(){	
  
	
          var columnData = [
              { "data": "created_at" },            
                    { "data": "sname" },
                    { "data": "secondlang" },
                    { "data": "hostel" },
                    { "data": "coname" },
                    { "data": "cophone" },
                    { "data": "address" },
                    { "data": "district" },
                    { "data": "id" }
                  ];

       
        var oTable = $('#templatetable').dataTable({
                    "bProcessing": true,
                    "bServerSide": true,
                    "sPaginationType": "full_numbers",
                    "ajax": {
                    "url": 'schools/GetAcademicSchools',
                    "type": "POST"
                     }, 
                     "oLanguage": {
                        "sProcessing": "<img src='<?php echo base_url(); ?>images/loader.gif'>"
                    },
                    'iDisplayLength': 20,
                    "columns": columnData,
                    "order": [[ 0, "created_at" ]],
                    "fnDrawCallback": function( oSettings ) {
                        var count = 1;
                         $("#templatetable").find(".sno").each(function(){
                             
                            $(this).text(count);
                            count++;
                            
                          });
                            
                    }
         }); 
         
   
            
          	
});
</script>


<div class="wrap dynamic-width" style="float: left;position: relative">
    
    <div style="margin-top: 10px; width: 100%; height: 50px; text-align: right;">
        <span style="font-weight: bold;font-size: 20px;padding: 10px;float:left;color: #364159">Seat Allotment Schools</span>
         
         </div>  
    <div style="margin-top: 10px; width: 100%; height: 50px; text-align: right;">

        <?php if(isset($roleaccess['Schools Add'][0]) && $roleaccess['Schools Add'][0]=="y"){ ?> 
             <a class="addschool" style="text-decoration:none;font-size: 14px;padding: 10px;  color: #fff; margin: 0px auto; position: relative; top: 5px;border-radius:5px;background: linear-gradient(180deg, #4F70C4 0%, #1C47B3 100%);" href="<?php echo base_url(); ?>addschools"><span style="position: relative;top:0px"><img  src="<?php echo $this->config->item('web_url') ?>images/addcourse.png" alt="Navigation" /></span><span style="margin-left:5px">Add Schools</span></a>
        <?php } ?> 
         
         </div>  
         <?php echo $this->table->generate();  ?>             
         
        
        
        </div>

<style>
		
		#addExamModal.modal .modal-header{padding: 5px 10px !important;border: none}	
		#addExamModal.modal .modal-body{padding:0 1.75rem 1.75rem}
		.modal-body p{text-align: left !important}
		.modal-backdrop.show {opacity: .5 !important;}
		#addExamModal h2{line-height: 24px;}
				
		.loader p{text-align: center !important;}
		
		.studentdetails p span{font-weight: bold;display: block}
		
		label{color: #4F70C4;}
		.row-element .content { width: 100% !important;}
                .chosen-container-multi .chosen-choices li.search-choice { background: #6884CC;border-radius: 5px;}
                .chosen-container-multi .chosen-choices li.search-choice {color: #fff;}
                #examtype_chosen { border: 1px solid #D7DFF0;background: #fff;width: 100% !important;padding: 6px;}
                .chosen-container-multi .chosen-choices {border: 0px;background: none}
                .maincontent ul li.search-choice { height:auto; }
     .maincontent ul li.search-choice a{ height:auto; font-size: 14px;color:#536485}
     .chosen-container-single .chosen-single { background: #fff !important;border: 0px !important;box-shadow: none !important}
	</style>
	
	<div id="addExamModal" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
		<div class="modal-dialog modal-dialog-centered" role="document">
			<div class="modal-content">
                            <div class="modal-header" style="padding: 0px !important">
                                    <div style="width: 100%;height: 45px;background: #6884CC">
                                        <span style="padding: 10px;position: relative;top: 10px;color: #fff;font-size: 14px">Add New Academic Year</span>
				   <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span style="color: #fff;position: relative;top: 7px;left: -7px;" aria-hidden="true">&times;</span></button>
				</div>
                                    </div>
                            <div class="modal-body text-center" style="padding-top: 10px;padding-left: 15px;padding-bottom: 10px">
				<?php echo form_open('allocation/addYear', array('id' => 'examForm')) ?>
                                    <div class="row-element" style="margin:0px">
                                    
                                    <span class="content">
                                        <input type="text" placeholder="Enter Academic Year"  id="yname" name="yname">

                                    </span>
                                    </div>
				
					 <?php echo form_close() ?>					
				</div>
				<div class="modal-footer">
				
					<div class="alert mb-0"></div>
					
					<button type="button" class="btn btn-primary saveexam"><img src='<?php echo base_url(); ?>images/loader.gif' class="updateloader d-none mr-2">Save</button>
					<button type="button" class="btn btn-outline-primary modalclose" data-dismiss="modal">Close</button>
				</div>
								
			</div>
		</div>
	</div>
    


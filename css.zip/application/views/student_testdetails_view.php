
<link rel="stylesheet" href="<?php echo base_url();?>css/vendor/dataTables.bootstrap4.min.css">
<link rel="stylesheet" href="<?php echo base_url();?>css/vendor/datatables.responsive.bootstrap4.min.css">
<script src="<?php echo base_url();?>js/vendor/datatables.min.js"></script>

<script type="text/javascript">
$(document).ready(function(){
    
	//var center = "<?php //echo $coursedetails['center'];?>";
	//$(".coursecenter").val(center);
	
	var centername = "<?php echo $centername;?>";
	$(".coursecenter").val(centername);
	
	
	$(".coursecenter").change(function(){
		
		var courseid = "<?php echo $courseid;?>";
		var center = $(this).val();
		
		getCenterFee(courseid,center)
	
		
	});
	
	$(".centertag").click(function(){
		
		var courseid = "<?php echo $courseid;?>";
		var center = $(this).text();
		
		$(".coursecenter").val(center);
		
		getCenterFee(courseid,center)
		
		/*$.post('stucoursedetails/getCenterFee',{
			'courseid':courseid,
			'center':center
		},function(o){
			
			var obj1 = $.parseJSON(o);//console.log(obj1);
			
			if(obj1['centerfees']!=""){
				
				$(".yearfee").html(obj1['centerfees']);
				$(".totalfeeamt").html("&#8377; "+obj1['totalfeeformat']);
				
			}else{
				alert('No fee details. Check later');
			}
			
		})*/
		
	});
	
	$(".requestreg").click(function(){
	   
	   var courseid = "<?php echo $courseid;?>";
	   var qid = "<?php echo $coursedetails['course']['qualification'];?>";
	   var center = $(".coursecenter").val();
	   var totalfee = $(".totalfeeamt").html();
	   var url = 'courseregister?id='+courseid+'&qid='+qid+'&center='+center+'&total='+totalfee;
		
        var checksamequalify = "<?php echo $checksamequalify;?>";
		
		if(checksamequalify){alert("Already applied for this qualification"); return false;}
		
		if(center==""){ alert("Select center"); return false;}
				
	    $(location).prop('href', url);
	});
	
	
	$("select").change(function(){
		$(this).attr('value',$(this).val());
	});

});
	
function getCenterFee(courseid,center){
	
		$.post('stucoursedetails/getCenterFee',{
			'courseid':courseid,
			'center':center
		},function(o){
			
			var obj1 = $.parseJSON(o);//console.log(obj1);
			
			if(obj1['centerfees']!=""){
				
				$(".feesstructure").removeClass('d-none');
				$("tbody .tryearfee").remove()
				$("tbody").prepend(obj1['centerfees']);
				$(".feesstructure thead").html(obj1['thead']);
				$(".totalfeeamt").html(obj1['totalfeeformat']);
				$(".totalamt").attr('colspan',obj1['colspan']);
				
			}
			
		})
		
}
</script>

<style>

	.coursetype .card{box-shadow: 0px 0px 7px rgba(196, 196, 196, 0.35);background: linear-gradient(0deg, #FFFFFF, #FFFFFF), #C4C4C4;cursor: pointer;border: 2px solid transparent;transition: all ease 0.3s}
	.rounded .coursetype .card{border-radius: 10px}
	.coursetype .card.active{border: 2px solid #0332AA;}
	.coursetype .card p {color: #889DC6;font-size: 14px;transition: all ease 0.3s}
	.coursetype .card img{filter: opacity(0.4);transition: all ease 0.3s}
	
	.coursetype .card.active p{color: #0332AA;}
	.coursetype .card.active img{filter: opacity(1);}
	
	.coursetop p{color: #6F83AA}
	
	.coursedetails h1{color: #0332AA;}
	.coursedetails .card,.courseinfo .card{background: linear-gradient(0deg, #FFFFFF, #FFFFFF), #C4C4C4;box-shadow: 0px 0px 7px rgba(196, 196, 196, 0.35);border-radius: 10px;}
	.coursedetails h2{color: #0332AA;font-size: 24px;font-weight: bold;line-height: 36px;}
	.coursedetails p.list-item-heading,.coursecontent .row div:first-child p,.yearfee .row div:first-child p{color: #6884CC;font-weight: 600;}
	
	.border-right{border-right: 1px solid #D7DFF0!important;}
	
	.yearfee .card{background: none;border: 0px solid #BCCAE8;box-shadow: none}
	.yearfee p{margin-bottom: 10px}
	.yearfee p.first,.yearfee p.second{font-weight: bold;font-size: 14px;color: #D21F1F;text-align: center}
	.yearfee .row div:last-child p{font-size: 15px;font-weight: bold;color: #0332AA;}
	
	.btn-primary{width: auto}
	
	.card h5{margin-bottom: 1rem;}
	h5{font-weight: bold;}
	.badge-outline-secondary, .badge-outline-theme-2{border: 1px solid #889DC6;color: #889DC6;background: #F6F7FA;}
	.badge{font-size: 12px;margin-right: 5px}
	
	.courseinfo .col-right .card .card-body{padding: 0;}
	.courseinfo .border-bottom{border-bottom: 1px solid #D7DFF0!important;}
	.col-right h5{padding: 1.2rem}
	
	.schedule .row div:first-child p{font-size: 12px;color: #6884CC;font-weight: bold;letter-spacing: 0.5px;text-transform: capitalize;}
	.schedule .row div:last-child p{font-size: 14px;font-weight: 600;}
	
	.relatedcourse p.list-item-heading{color: #6884CC;font-weight: 600;}
	.relatedcourse .row div:first-child p{font-size: 16px;color: #364159;font-weight: bold;}
	.relatedcourse .row div:last-child i{background: url(img/icons/arrow-right.png) no-repeat;width: 14px;height: 14px;display: inline-block;vertical-align: middle}
	
  .courseinfo ul {list-style: none;}
  .courseinfo li {list-style-position: inside;text-indent: 0em;font-stretch: normal;letter-spacing: normal;padding: 10px 10px 10px 35px;background: url("img/icons/check-circle.png") no-repeat left center; margin: 0;
  vertical-align: middle;}
	
	.icon-flag{background: url("img/icons/flag.png") no-repeat;width: 15px;height: 15px;display: inline-block;vertical-align: middle}
	.icon-check-square{background: url("img/icons/check-square.png") no-repeat;width: 15px;height: 15px;display: inline-block;vertical-align: middle}
	.icon-send{background: url("img/icons/send.png") no-repeat;width: 15px;height: 15px;display: inline-block;vertical-align: middle;margin-right: 5px}
	
	.totalfee span:first-child{font-weight: 600;font-size: 14px;color: #6884CC;}
	.totalfee span:last-child{font-weight: bold;font-size: 24px;color: #D63333;}
	
	.table td.totalfee {font-weight: bold;font-size: 16px;color: #D63333;}
	.table td.totalamt {font-weight: bold;font-size: 12px;color: #6F83AA;letter-spacing: 0.5px;text-transform: uppercase;text-align: right !important}
	.table thead tr th:first-child{border-top-left-radius: 5px}
	.table thead tr th:last-child{border-top-right-radius: 5px}
	.table tr:last-child td{text-align: left}
	.table tr td:last-child,.table tr th:last-child{text-align: center}
	.table tr:last-child td:last-child{font-weight: bold;text-align: center}
	.table tr:last-child{text-align: center}
	
	.table{border: 1px solid #D7DFF0;border-collapse: collapse;border-style: hidden;border-radius: 10px 10px 0 0;box-shadow: 0 0 0 1px #d7dff0;}
	.table thead th{font-size: 12px;font-weight: bold;color: #6F83AA;letter-spacing: 0.5px;background: #E6EBF7;text-transform: uppercase;padding: 0.8rem;text-align: left}
	.table thead tr th:first-child{border-top-left-radius: 10px}
	.table thead tr th:last-child{border-top-right-radius: 10px}
	.table td, .table th{border-top: 1px solid #D7DFF0;padding: 0.9rem 0.75rem;color: #364159;font-weight: 600;}
	.thtax{display: block;text-align: center;}
	.thtaxvalue{display: flex;}
	.thtaxvalue span:first-child{width: 53%}
	
	h3.title{font-size: 12px;text-transform: uppercase;color: #0332AA;letter-spacing: 0.5px;font-weight: bold;}
	
</style>

<?php 

	$timestamp = strtotime($coursedetails['course']['starts_on']);
    $timestamp1 = strtotime($coursedetails['course']['ends_on']);

	$csch = array_filter(explode("|",$coursedetails['course']['cschedule']));$regular = '';$hydrid = '';
	$cschedule = implode(", ",$csch);

	$screentest = $coursedetails['course']['screentest'];

	$timeduration = date('M Y',$timestamp).' - '. date('M Y',$timestamp1);

	$timeperiod = "Admission Time";
	$commences = "Commencing on";
	if($screentest=="1"){
		$timeperiod = "Application Period";
		$commences = "Test Date";
		$timeduration = date('d M, Y',$timestamp).' - '. date('d M, Y',$timestamp1);
	}

	$centersfee = $tablepay = "";
	$totalfee = 0;
	$count = 1;
	$checkdiscount = $kfcheck = false;

	foreach($coursedetails['centerfees'] as $key=>$centerfees){
		
						$discount = $tax = "";
		
						$amount = $centerfees['amount'];
						$total = $centerfees['total'];
						$taxable = $centerfees['taxable'];
						$kf = $centerfees['kf'];
						$cov = $centerfees['cov'];
						$sac = 999293;
		
						$discountamt = 0;$thdiscount = $tddiscount = $thtax =  $tdtax = $thcov =  $tdcov = "";
						$taxamt = 0;
						$colspan=9;

						$tax = $centerfees['tax'];
						$discount = $centerfees['discount'];
		
						$activetotalamt = $amount;
		
						if(intval($discount)>0) {
							
							$discountamt = $discount;
							$tddiscount = '<td width="12%">'.$discountamt.'</td>';
							
							$amount = $amount - $discount;
							
							$checkdiscount = true;
							
						}else{
							$tddiscount = '<td>[DISCOUNT]</td>';
						}
						
						if($tax=="0" || $tax=="NA"){
							$tdnontaxable = $amount;
						}else{
							$tdnontaxable = 0;
						}

						if($tax!="0" && $tax!="NA"){ 

							$tdtaxable = $amount;				

							$taxgst = $tax/2;
							if(intval($tax)>0) $taxamt = $amount * ($tax/100);
							$taxamtgst = $taxamt/2;
							$taxamtgst = number_format($taxamtgst,2);

							//$colspan +=4;

						} else {
							$tdtaxable = 0;
							$taxgst = $taxamtgst = "NA";
						}

						$thtax = '<th scope="col" colspan="2" width="15%"><span class="thtax">CGST</span> <span class="thtaxvalue"><span>Rate %</span> <span>Amount</span></span></th>
							  <th scope="col" colspan="2" width="15%"><span class="thtax">SGST</span> <span class="thtaxvalue"><span>Rate %</span> <span>Amount</span></span></th>';

						$tdtax = '<td width="8%">'.$taxgst.'</td>
								  <td width="8%">'.$taxamtgst.'</td>
								  <td width="8%">'.$taxgst.'</td>
								  <td width="8%">'.$taxamtgst.'</td>';


						$tdkf = $thkf = ""; $colwidth = 15;
						if(($kf!="" && $kf!="0") || $kfcheck){
							
							$kfamt = $amount * ($kf/100);
							
							$thkf = '<th scope="col" width="8%">CESS KF(%)</th>
                  					 <th scope="col" width="8%">CESS KF Amount</th>';
							$tdkf = '<td width="12%">'.$kf.'</td>
									 <td width="8%">'.$kfamt.'</td>';
							
							$kfcheck = true;
							
							$colspan += 2;
							$colwidth -= 5;
						}
						
						if($cov!="0" && $cov!="NA"){
							$thcov = '<th scope="col" width="15%">CESS COV(%)</th>';
							$covamt = $amount * ($cov/100);
							$tdcov = '<td width="15%">'.$covamt.'%</td>';
							$colspan +=1;
						}
		
						$totalfee += $centerfees['total'];
		
						$grandtotal += $total;
		
						$tablepay .= '<tr class="tryearfee">
									  <th scope="row" width="7%">'.$count.'.</th>
									  <td width="20%"><strong>'.$centerfees['description'].'</strong></td>
									  <td width="11%">'.$activetotalamt.'</td>
									  <td width="11%">'.$tdnontaxable.'</td>
									  <td width="11%">'.$tdtaxable.'</td>
									  '.$tddiscount.'
									  '.$tdtax.'
									  '.$tdkf.'
									  '.$tdcov.'
									  <td width="10%">'.number_format($total,2).'</td>
									</tr>';
		
						/*if(count($coursedetails['centerfees']) == $count) $mb_4 = ""; else $mb_4 = "mb-4";
		
						if($centerfees['tax']>0) $tax = ' + GST '.number_format($centerfees['tax']).'%';
		
						if($centerfees['discount']>0) $discount = '<div class="row">

												<div class="col-md-5">
													<p>Discount:</p>
												</div>

												<div class="col-md-7">
													<p>'.$centerfees['discount'].'% Offer</p>
												</div>

											</div>';

						$centersfee .= '<div class="card d-flex flex-row '.$mb_4.'">
																
									<div class="d-block w-100 p-3">
									
										<p class="first">'.$centerfees['description'].'</p>
										
											
											<div class="row">

												<div class="col-md-5">
													<p>Course Fee:</p>
												</div>

												<div class="col-md-7">
													<p>'.number_format($centerfees['amount']).$tax.'</p>
												</div>

											</div>
											
											'.$discount.'
									</div>
								</div>';*/
		
		$count++;
														
	}

	if($checkdiscount){ 
		$thdiscount = '<th scope="col" width="12%">Discount</th>';
		$tablepay = str_replace("<td>[DISCOUNT]</td>",'<td width="12%">0</td>',$tablepay);
		$colspan +=1;
	}
	else{
		$tablepay = str_replace("<td>[DISCOUNT]</td>",'',$tablepay);
	}

$thtax = '<th scope="col" colspan="2" width="15%"><span class="thtax">CGST</span> <span class="thtaxvalue"><span>Rate %</span> <span>Amount</span></span></th>
							  <th scope="col" colspan="2" width="15%"><span class="thtax">SGST</span> <span class="thtaxvalue"><span>Rate %</span> <span>Amount</span></span></th>';

?>

<main>
  <div class="container-fluid">
    <div class="row">
      <div class="col-12">
               
        <!--<div class="separator mb-5"></div>-->
        
        
        </div>
        
      </div>
      
		<div class="row coursedetails">
			
			
			<?php if(($courseid === "60f69bbac0ade")||($courseid === "61654d5bc4fbe")){?>
			 
			<div class="col-12 mb-4">
                               
				<div class="card">
					<div class="card-body">

						<label style="color:#ff3c3c;font-weight: bold;font-size: 18px;margin-bottom: 0px;"><span style="color: #364159;">Attention:</span> Offline Test Centres only in the state of KERALA. Overseas and inaccessable other students can write the test in ONLINE MODE.</label>

					</div>
				 </div>
       
			</div>

			<?php }?>

			<div class="col-12 mb-4">
				<div class="card">
					<div class="card-body">

						<div class="row">

							<div class="col-md-12 col-sm-12 col-lg-8 col-12">
							
								<h1 class="mb-2"><?php echo $coursedetails['course']['coursename']; ?></h1>

								<div class="row">

									<div class="col-md-3 col-xs-3 col-3 text-left border-right px-3">
										<img alt="Profile" src="<?php echo base_url();?>img/icons/clock.png" class="img-thumbnail border-0 mb-2">
										<p class="list-item-heading mb-1">Duration</p>
										<p class="mb-4 text-muted"><?php echo $coursedetails['course']['duration']; ?></p>
									</div>

									<div class="col-md-4 col-xs-4 col-4 text-left border-right px-4">
										<img alt="Profile" src="<?php echo base_url();?>img/icons/invoice.png" class="img-thumbnail border-0 mb-2">
										<p class="list-item-heading mb-1"><?php echo $timeperiod;?></p>
										<p class="mb-4 text-muted"><?php echo $timeduration;?></p>
									</div>

									<div class="col-md-4 col-xs-4 col-4 text-left px-4">
										<img alt="Profile" src="<?php echo base_url();?>img/icons/refresh-cw.png" class="img-thumbnail border-0 mb-2">
										<p class="list-item-heading mb-1"><?php echo $commences;?></p>
										<p class="mb-4 text-muted"><?php echo $coursedetails['course']['commenceson']; ?></p>
									</div>

								</div>
								
								<div class="mb-4"></div>

								<!--<div class="coursecontent">

									<div class="row">

										<div class="col-md-4">
											<p><i class="icon-flag"></i> Target Group :</p>
										</div>

										<div class="col-md-8">
											<p> Students who are studying in Class X</p>
										</div>

									</div>

									<div class="row">

										<div class="col-md-4">
											<p><i class="icon-check-square"></i> Admission Criteria :</p>
										</div>

										<div class="col-md-8">
											<p>Through Screening Test.</p>
										</div>

									</div>


								</div>-->

								<div class="mb-4"></div>

								<!--<div class="row">

									<div class="col-md-3">
										<label class="form-group has-float-label"><select class="form-control coursecenter"> <?php //echo $searchoptions['center'];?></select> <span>Select Center*</span></label>
									</div>
									
									<div class="col-md-4 d-flex align-items-center">
										<p class="totalfee"><span>Total Fee:</span> <span class="totalfeeamt">&#8377; <?php //echo number_format($totalfee);?></span></p>
									</div>

									<div class="col-md-5 text-right">
									    
									    <?php //if(($waiting === '')||($waiting === 'n')) { ?>
										<a href="#" class="requestreg"><button class="btn btn-primary w-5"><i class="icon-send"></i>Request For Registration</button></a>
										 <?php //} else if($waiting === 'w'){ ?>
										 <button class="btn btn-primary w-5"><i class="icon-send"></i>Waiting For Approval</button>
										 <?php //}else if($waiting === 'y'){ ?>
										 <button class="btn btn-primary w-5"><i class="icon-send"></i>Approved</button>
										 <?php //}?>
										 
									</div>

								</div>-->

							</div>
							<div class="col-md-12 col-sm-12 col-lg-4 col-12 yearfee">
							
							
							<div class="card d-flex flex-row mb-4">
																
									<div class="d-block w-100 p-3">
									
										<div class="form-group floating">
										<select class="form-control coursecenter" value="<?php echo $centername;?>" <?php if($waiting=="w" || $waiting=="q" || $waiting=="y") echo "disabled" ?> > <option value="">Select Center</option><?php echo $searchoptions['center'];?></select> <label <?php if($waiting=="w" || $waiting=="q" || $waiting=="y") echo "style='display:none'" ?>>Select Center <span>*</span></label>
										</div>
									
									</div>
									
								</div>
								
								<div class="card d-flex flex-row mb-4">
									
									<div class="d-block w-100 p-3">
									    
									    <?php if($waiting === '') { ?>
										<a href="#" class="requestreg"><button class="btn btn-primary w-100"><i class="icon-send"></i>Request For Registration</button></a>
										 <?php } else if(($waiting === 'w')||($waiting === 'n')){ ?>
										 <button class="btn btn-primary w-100"><i class="icon-send"></i>Waiting List</button>
										 <?php } else if($waiting === 's'){ ?>
										 <button class="btn btn-primary w-100"><i class="icon-send"></i>Shortlisted</button>
										 <?php } else if($waiting === 'q'){ ?>
										 <button class="btn btn-primary w-100"><i class="icon-send"></i>Waiting For Approval</button>
										 <?php }else if($waiting === 'y'){ ?>
										 <button class="btn btn-primary w-100"><i class="icon-send"></i>Approved</button>
										 <?php }?>
										 
									
									</div>
									
								</div>
								
								<?php 
									
									//echo $centersfee;
								?>
							
								<!--<div class="card d-flex flex-row mb-4">
																
									<div class="d-block w-100 p-3">
									
										<p class="first">First Year Fee</p>
										
											<div class="row">

												<div class="col-md-5">
													<p>Reg Fee:</p>
												</div>

												<div class="col-md-7">
													<p>2,000</p>
												</div>

											</div>
											
											<div class="row">

												<div class="col-md-5">
													<p>Course Fee:</p>
												</div>

												<div class="col-md-7">
													<p>40,000 + GST + KFC</p>
												</div>

											</div>
											
											<div class="row">

												<div class="col-md-5">
													<p>Discount:</p>
												</div>

												<div class="col-md-7">
													<p>10% Offer</p>
												</div>

											</div>
									</div>
								</div>-->
								
							</div>

						</div>
						
						<div class="feesstructure d-none">
						
						<h3 class="title my-4">Fees Structure</h3>
                
						<table class="table">
					  <thead>
						<tr>
						  <th scope="col" width="8%">Sl. no.</th>
						  <th scope="col" width="15%">Description</th>
						  <th scope="col" width="8%">Total Fee</th>
						  <th scope="col" width="<?php echo $colwidth;?>%">Non Taxable Value</th>
						  <th scope="col" width="<?php echo $colwidth;?>%">Taxable Value</th>
						  <?php echo $thdiscount;?>
						  <?php echo $thtax;?>
						  <?php echo $thkf;?>
						  <?php echo $thcov;?>
						  <th scope="col" width="15%">Total</th>
						</tr>
					  </thead>
					  <tbody>

						<?php echo $tablepay; ?>

						<tr>
						  <td colspan="<?php echo $colspan;?>" class="totalamt">Grand total</td>
						  <td class="totalfee totalfeeamt"><?php echo number_format($grandtotal,2); ?></td>
						</tr>
					  </tbody>
					</table>
					
						</div>

					</div>
				</div>
			</div>

		</div>
       
       <div class="row courseinfo">
      <div class="col-12 col-md-12 col-xl-8 col-left">
        <div class="card mb-4">
         <!-- <div class="lightbox"><a href="img/detail-5.jpg"><img alt="detail" src="img/detail-5.jpg" class="responsive border-0 card-img-top mb-3"></a></div>-->
          <div class="card-body">
           
           <?php echo $coursedetails['course']['description']; ?>
           
            <!--<div class="mb-5">
              <h5 class="card-title">Course Overview</h5>
              <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolo.  Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolo</p>
            </div>
            <div class="mb-5">
              <h5 class="card-title">What you’ll learn?</h5>
              <ul class="list-unstyled">
                <li>Study Strategies and Techniques to secure AIR under 5000 in JEE Mains and JEE Advanced</li>
                <li>Complete Continuity and Differentiability up to the level of JEE ADVANCE starting from very basics</li>
                <li>Training your natural awareness to increase your perception of situations</li>
                <li>Admission in the Best Engineering Colleges</li>
                <li>In depth knowledge of Mathematics, Physics, Chemistry</li>
                <li>Get advanced level of JEE ADVANCED</li>
              </ul>
            </div>
            
            <div class="mb-5">
              <h5 class="card-title">Who this course is for?</h5>
              <ul class="list-unstyled">
                <li>All the Maths stream students of class XI / XII / XIII who are preparing for JEE ADVANCE / JEE MAINS /
BOARDS and other competitive examination.</li>
                <li>Preparing for JEE ADVANCE / JEE MAINS / BOARDS and other competitive examination.</li>
                <li>All the Maths stream students of class XI / XII / XIII who are preparing</li>
                <li>Students preparing for JEE ADVANCE / JEE MAINS / BOARDS and other exams.</li>
              </ul>
            </div>-->
            
            
            <?php 
			  
			  	if($coursedetails['course']['refund']!="")
	
					
				echo '<h5 class="card-title my-3">Refund Policy</h5>'.$coursedetails['course']['refund']; 
			  
			  ?>
            
          </div>
        </div>
      </div>
      <div class="col-12 col-md-12 col-xl-4 col-right">
       
       <?php if($screentest!="1"){?>
       
       <div class="card mb-4 d-none d-lg-block schedule">
          <div class="card-body">
            <h5 class="card-title border-bottom"><span>Class Schedule</span></h5>
            
            
            <?php
			  
			  /*if(($csch[0] === 'regular') || ($sch[2] === 'both')) { $regular = '<p>Regular Batch-Monday to Saturday</p>';}
                if(($csch[1] === 'weekend') || ($sch[2] === 'both')) { $hydrid = '<p>Hybrid Batch-All Saturday/Sunday & selected vacations*</p>';}*/
			  
			  ?>
           
           <?php if($cschedule!=""){?>
           
            <div class="row px-3">

				<div class="col-md-4">
					<p><?php echo $cschedule;?></p>
				</div>

				<!--<div class="col-md-8">
					<?php //echo $cschedul//e;?>
				</div>-->

			</div>
			
			<?php }?>
			
			<?php //if($hydrid!=""){?>

			<!--<div class="row px-3">

				<div class="col-md-4">
					<p>Hybrid:</p>
				</div>

				<div class="col-md-8">
					<?php //echo $hydrid;?>
				</div>

			</div>-->
           
           <?php //}?>
            
          </div>
        </div>
        
        <?php }?>
        
        <div class="card mb-4 coursecenter">
       
          <div class="card-body">
          
			  <h5 class="card-title border-bottom"><span><?php if($courseid=="60f69bbac0ade"){ echo "Offline Exam Centres";}else{ echo "Centers";} ?></span></h5>
           
            <p class="mb-3 px-3">
            
            <?php 
				
				foreach($searchoptions['centers'] as $centers ){
					
					echo '<a href="#"><span class="badge badge-pill badge-outline-theme-2 mb-2 centertag">'.$centers.'</span> </a>';
					
				}
				
			?>
            
          </div>
        </div>
        
        <!--<div class="card mb-4 relatedcourse">
          <div class="card-body">
            <h5 class="card-title border-bottom">Related Courses</h5>
            <div>
              <div class="d-flex flex-row mb-0">
                <div class="pl-3 pt-2 pr-3 pb-2"><a href="#">
                  <p class="list-item-heading mb-0">Two Year Integrated IIT-JEE Programme (Regular & Hybrid)</p>
					<div class="row border-bottom ml-0 mr-0 mt-3"><div class="col-md-6 p-0"><p>&#8377; 85,000</p></div><div class="col-md-6 p-0 text-right"><i class="icon-arrow-right"></i></div></div>
                  </a></div>
              </div>
              <div class="d-flex flex-row mb-0">
                <div class="pl-3 pt-2 pr-3 pb-2"><a href="#">
                  <p class="list-item-heading mb-0">Advanced J2EE Programme
(Regular & Hybrid)</p>
                 <div class="row border-bottom ml-0 mr-0 mt-3"><div class="col-md-6 p-0"><p>&#8377; 85,000</p></div><div class="col-md-6 p-0 text-right"><i class="icon-arrow-right"></i></div></div>
                  </a></div>
              </div>
              <div class="d-flex flex-row mb-0">
                <div class="pl-3 pt-2 pr-3 pb-2"><a href="#">
                  <p class="list-item-heading mb-0">IIT-JEE Advance Programme - One Year Repeaters (Regular & Hybrid)</p>
                  <div class="row ml-0 mr-0 mt-3"><div class="col-md-6 p-0"><p>&#8377; 85,000</p></div><div class="col-md-6 p-0 text-right"><i class="icon-arrow-right"></i></div></div>
                  </a></div>
              </div>
              
            </div>
          </div>
        </div>-->
        
      </div>
        
    
    </div>
  </div>
</main>
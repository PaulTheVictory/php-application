<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/dataTables.css?v=1.5" />
<script src="<?php echo base_url(); ?>js/jquery.dataTables.js?v=1.0" type="text/javascript"></script>
 <link href="<?php  echo base_url(); ?>css/jquery-ui.min.css?v=1.4" rel="stylesheet" type="text/css" />
 <script src="<?php  echo base_url(); ?>js/jquery-ui.min.js?v=1.3" type="text/javascript"></script>
<style type="text/css">
    
.reportsTable thead tr  {
    background: #E6EBF7;

/* g8 */
border: 1px solid #D7DFF0;
box-sizing: border-box;
border-radius: 10px 10px 0px 0px;
 

}

    .reportsTable tr th {
        border-right: 0px;
    font-size: 13px;
      color: #6F83AA;
   cursor: pointer;
   text-align: center;padding: 4px;
   width: 5%;vertical-align: middle;
    }  
    
  .reportsTable tr { background: #fff;border-bottom: 1px solid #D7DFF0;}
.reportsTable tr td {
    border-right: 0px;
    padding: 5px 5px;
    text-align: center;font-size: 13px;
    vertical-align: middle;
}

    .reportsTable tr td:nth-child(6) {
  width: 30% !important;
} 
     
    .reportsTable tr td:nth-child(7) {
  width: 30% !important;
}

.reportsTable_length { width: auto !important; }
#reportsTable_filter input { padding-top:4px;background: #fff url('<?php echo base_url(); ?>/images/search.png') no-repeat center left;background-position-x: 10px;border: 1px solid #D7DFF0; line-height: 32px;margin-left: 10px;width:260px;border-radius: 5px;text-indent: 30px;font-size: 13px;}


.ui-selectmenu-button.ui-button{ width: 50%; padding:10px;padding-right: 0px;}
     #users-button,#modules-button{border: 1px solid #D7DFF0;background: #fff;font-size: 14px;color:#536485}
     .loader {
    display: none;
    position: absolute;
    top: 0; left: 0; right: 0; bottom: 0;
    background: rgba(255,255,255,0.8) url('<?php echo base_url(); ?>images/loader.gif') center center no-repeat;
    z-index: 1000;
}
</style>
<script type="text/javascript">
    
    $(window).load(function () {
    $(".loader").hide();   
    });
  
$(document).ready(function(){	

         $("#users").selectmenu(); 
         $("#modules").selectmenu();
         
         $(".adtime").datetimepicker({
  dateFormat: "yy-mm-dd"
    });

         
  $("#billSearch").click(function(){
     
     var sdate = $(".fromdate").val();
     var edate = $(".todate").val();
     var user = $("#users").val();
     var type = $("#modules").val();
     $(".loader").show();
     var url = 'auditlog?sdate='+sdate+'&edate='+edate+'&user='+user+"&type="+type;
       $(location).prop('href', url);
     
  });
  
   var oTable = $('#reportsTable').dataTable({
					"processing": true,
					"sPaginationType": "full_numbers",
			 		"oLanguage": {
                        "sProcessing": "<img src='<?php echo base_url(); ?>images/loader.gif'>",
						 "sEmptyTable": "No Results Found"
                    },
                    "fnDrawCallback": function( oSettings ) {
                        
    }
 }); 
  
                });
</script>


<div class="wrap dynamic-width" style="float: left;position: relative;">
   
    <div style="margin-top: 10px; width: 100%; height:310px; text-align: right;">       
             <span style="font-weight: bold;font-size: 20px;padding: 10px;float:left;color: #364159">User Activity Summary</span>
             <div class="row-element">
                 <span class="title" style="padding: 0px;padding-left: 10px;color: #6F83AA;margin-top: 14px;">Date</span>                    
                    <span class="content" style="padding: 0px;color:#0332AA;font-weight: bold;min-width: 250px;width: 100px">
                          <input type="text" value="<?php echo date("Y/m/d H:i",strtotime($sdate));?>" name = "fromdate" class="fromdate adtime" style="width: 90%;margin: 5px;background: #fff url('<?php echo base_url(); ?>/images/cal.png') no-repeat 95%;">  
                        </span>
                 <span class="content" style="padding: 0px;color:#0332AA;font-weight: bold;min-width: 250px;width: 100px">
                        <input type="text" value="<?php echo date("Y/m/d H:i",strtotime($edate));?>" name = "todate" class="todate adtime" style="width: 90%;margin: 5px;background: #fff url('<?php echo base_url(); ?>/images/cal.png') no-repeat 95%;">    
                        </span>
                </div>
             
              <div class="row-element">
                 <span class="title" style="padding: 0px;padding-left: 10px;color: #6F83AA">Users</span>                    
                    <span class="content" style="padding: 0px;color:#0332AA;font-weight: bold">
                        <select  id="users" name = "users" class="users" style="width: 50%;font-size: 13px;float:left">
                            <option value="All" >All</option>
                            <?php echo $users;?>
                        </select>
                        </span>
                </div>
             <div class="row-element">
                 <span class="title" style="padding: 0px;padding-left: 10px;color: #6F83AA">Modules</span>                    
                    <span class="content" style="padding: 0px;color:#0332AA;font-weight: bold">
                        <select  id="modules" name = "modules" class="modules" style="width: 50%;font-size: 13px;float:left">
                            <option value="All" >All</option>
                            <?php 
                            $ret1 = '';
                            $arr2 = ['Courses',"Qualification","First Qualification","Second Qualification","Admission Request","Student Profile","Student Fee Structure","Student Payments","User Group"];
                            for($i = 0;$i < count($arr2);$i++){
                              if($stype === $arr2[$i]){
                                      $selected = 'selected="selected" ';
                                  }
                              $ret1 .="<option $selected>".$arr2[$i]."</option>";
                              $selected="";
                            }
                          echo $ret1;
                        ?>
                        </select>
                        </span>
                </div>
             
        
             <div class="row-element">
                 <span class="title" style="padding: 0px;padding-left: 10px;color: #6F83AA;visibility: hidden">Search</span>                    
                    <span class="content" style="padding: 0px;color:#0332AA;font-weight: bold">
                       <span id="billSearch" style="cursor: pointer;margin-left:20px;font-weight: bold;font-size: 14px;padding: 5px 10px;color: #fff;border-radius:5px;background: linear-gradient(180deg, #4F70C4 0%, #1C47B3 100%);">Search</span>    
                    </span>    
                    </span>
                </div>
             
             
            </div>  

    <div class="row-element" style="margin-top: 0px"><div class="loader"></div>
        <table class="reportsTable" id="reportsTable">
                
                <?php 
                    
                    $html = '<thead><tr><th>S.No</th><th>Date</th><th>User Name</th><th>IP Address</th><th>Description</th><th>Old Value</th><th>New Value</th></tr></thead>';
                   $i= 1;
                    foreach ($reports as $key=>$val){
                        if(($val['new'] === "")||($val['old'] === "")) {continue;}
                       
                        $html .= '<tr><td>'.$i.'</td><td>'.$val['date'].'</td><td>'.$val['username'].'</td><td>'.$val['ipaddress'].'</td><td>'.$val['desc'].'</td><td>'.$val['old'].'</td><td>'.$val['new'].'</td></tr>';
                        $i++;
                    }
                    //if($i === 1) { $html .= '<tr><td colspan="7">No data available</td><tr>';}

                    echo $html;
                 
                 ?>
        </table>
              
         
        </div>
        
        </div>
    
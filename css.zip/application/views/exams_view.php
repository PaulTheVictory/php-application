<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/dataTables.css?v=1.5" />
<script src="<?php echo base_url(); ?>js/jquery.dataTables.js?v=1.0" type="text/javascript"></script>
<link rel="stylesheet" href="<?php echo base_url();?>css/boot/bootstrap.min.css">
<link rel="stylesheet" href="<?php echo base_url();?>css/boot/main.css?v=1">
<script src="<?php echo base_url();?>js/bootstrap.bundle.min.js"></script>
<link href="<?php  echo base_url(); ?>css/jquery-ui.min.css?v=1.4" rel="stylesheet" type="text/css" />
 <script src="<?php  echo base_url(); ?>js/jquery-ui.min.js?v=1.3" type="text/javascript"></script>
  <link href="<?php  echo base_url(); ?>css/chosen.min.css?v=1.3" rel="stylesheet" type="text/css" />
  <script src="<?php  echo base_url(); ?>js/chosen.jquery.min.js?v=1.2" type="text/javascript"></script>
<style type="text/css">


.dataTables_wrapper input[type="text"] {
    padding: 0;
}
.dataTables_wrapper select {
    padding: 0;
}

.sortable thead tr  {
    background: #E6EBF7;

/* g8 */
border: 1px solid #D7DFF0;
box-sizing: border-box;
border-radius: 10px 10px 0px 0px;
 
}


.sortable tr th {
    border-right: 0px;
    padding: 15px 0;font-size: 13px;
      color: #6F83AA;
   cursor: pointer;
   text-align: center;

}

.dataTables_info { display: none; }
#addpaymenttable_paginate { display: none;}
#addpaymenttable_filter input {display:none;}

.sortable tr td {
    border-right: 0px;
    padding: 5px 5px;
    text-align: center;font-size: 13px;
    min-width:50px;vertical-align: middle;
}
.sortable tr td a {
    color: #364159;
}

#profile-right h2 {
    margin: 0px 0px 10px 0px;
}
#paymentlist_filter input { padding-top:4px;background: #fff url('<?php echo base_url(); ?>/images/search.png') no-repeat center left;background-position-x: 10px;border: 1px solid #D7DFF0; line-height: 32px;margin-left: 10px;width:260px;border-radius: 5px;text-indent: 30px;font-size: 13px;}

.sortable tr td a:hover { text-decoration: underline; }
.dataTables_filter { right:10px !important;}
	.dataTables_processing{height: auto}
	
	.sortable tr th:nth-child(1),.sortable tr th:nth-child(2),.sortable tr th:nth-child(3),.sortable tr th:nth-child(7),.sortable tr th:nth-child(9) {background: #E6EBF7 url(https://admissions.brilliantpala.org//images/datatable/sort_both.png) no-repeat center left;background-position: right;text-align: center;}
	
	.btn-outline-primary {color: #0332AA;border-color: #0332AA;}
.btn {border-radius: 5px;outline: initial!important;box-shadow: none!important;box-shadow: initial!important;font-size: .8rem;padding: .5rem 1.25rem .5rem 1.25rem;transition: background-color box-shadow .1s linear;margin-bottom: 7px}
.btn-outline-primary:not(:disabled):not(.disabled).active, .btn-outline-primary:not(:disabled):not(.disabled):active, .show>.btn-outline-primary.dropdown-toggle,.btn-outline-primary:hover {background-color: #0332AA;border-color: #0332AA;color: #fff;}	
	
.ui-selectmenu-button.ui-button{ width: 125px;margin-top: 10px;float: right;border: 1px solid #D7DFF0;background: #fff;font-size: 13px;color:#536485;padding: 8px;margin-bottom: 4px;}
.ui-menu-item .ui-menu-item-wrapper{font-size: 13px}
	
</style>
<script type="text/javascript">
$(document).ready(function(){	
	
        $("#searchtype").selectmenu();
         $("#examtype").chosen();
        
	 $("#edate").datetimepicker({
            dateFormat: "yy-mm-dd"
         });
    
	$(document).on("click",".clear",function(){
		
		$("#searchtype").selectmenu('destroy');
	    $("#searchtype").prop('selectedIndex',0);
	    $("#searchtype").selectmenu();
		
	});
		
	var oTable = $('#paymentlist').DataTable({
            "processing": true,
            "serverSide": true,
            "sPaginationType": "full_numbers",
            "ajax":{
		     "url": "<?php echo base_url('exams/examsList') ?>",
		     "dataType": "json",
		     "type": "POST",
				"data":function(data){ 
						
						var searchtype = $("#searchtype").val();
						data.searchcol= searchtype;
						
						}
		     //"data":{  '<?php //echo $this->security->get_csrf_token_name(); ?>' : '<?php //echo $this->security->get_csrf_hash(); ?>' }
					}, 
				 "oLanguage": {
					"sProcessing": "<img src='<?php echo base_url(); ?>images/loader.gif'>"
				},
		'iDisplayLength': 20,
	    "columns": [
		          { "data": "sno" },
		          { "data": "examname" },
		          { "data": "examdate" },
		          { "data": "type" },
		          { "data": "stuapp" },
		          { "data": "actions" }
		       ],
		"order": [[ 0, "desc" ]],
                 "fnDrawCallback": function( oSettings ) {
                     $("#paymentlist").find(".del").each(function(){

                            $(this).click(function(){ 

                              if(confirm("Are you sure to delete this item ?")) {
                                    var ide = $(this).attr("id");
                                    $.get('exams/DelExam',{
                                                               'ide':ide

                                                    }, function(o) { 
                                                            var obj1 = $.parseJSON(o);
                                                    if (obj1[0] === 'success') {
                                                        oTable.draw();
                                                    } else if (obj1[0] === 'fail') {
                                                        alert("Error!!! please try again");
                                                }
                                    });
                                }

                              });
                        

                          });
                 },
		"initComplete" : function() {
						
						var input = $('.dataTables_filter input').unbind(),
							self = this.api(),
							$searchButton = $('<button class="btn btn-outline-primary ml-3 search">')
									   .text('search')
									   .click(function() {
										  self.search(input.val()).draw();
									   }),
							$clearButton = $('<button class="btn btn-outline-primary ml-3 clear">')
									   .text('clear')
									   .click(function() {
										  input.val('');
										  $searchButton.click(); 
									   });
						$('.dataTables_filter').append($searchButton, $clearButton);
                                                
                                                  $(input).keyup(function(event){
                                                    if(event.keyCode == 13){
                                                        event.preventDefault();
                                                        $('.search').trigger('click');
                                                    }
                                                });
					}

	    });
	
	
       
        $(document).on("click",".addexam",function(){
        
        $('#addExamModal').modal({show:true});
                
		
	});	
        
        $(document).on("click",".saveexam",function(){
            
               if($(this).hasClass("progress")) { return;}
               $(this).addClass("progress");
		
		/*var examname = $("#ename").val();
		var examdate = $("#edate").val();
		var examtype = $("#etype").val();
                var stuapp = $("#stuapp").val();*/
						
		$(".updateloader").removeClass('d-none');
		 var examForm = $("#examForm");
		 $.ajax({
                type: 'POST',
                url: examForm.attr('action'),
                data: examForm.serialize(),
                success: function(o) {
                                        $(".saveexam").removeClass("progress");
					var response = $.parseJSON(o);
					
					$(".updateloader").addClass('d-none');
										
					if(response.status === 'success'){
						
						$(".alert").addClass('alert-success').text(response.message);
																		
						setTimeout(function(){
							$(".alert").removeClass('alert-success').text("");
                                                         location.reload();
						},2000);
						
					}else {
						$(".alert").addClass('alert-danger').html(response.message);
					}
					
                }
			 
		 });
			
		
		
		
	});
		
	$('#addExamModal').on('hidden.bs.modal', function () {
  		
                 $(".saveexam").removeClass("progress");
		$(".loader,.updateloader").addClass('d-none');
		$(".alert").removeClass('alert-success alert-danger').text("");
		
	});
		
		
        
});
</script>


<div class="wrap dynamic-width" style="float: left;position: relative">
          
<div style="margin-top: 10px; width: 100%; height: 50px; text-align: right;">
	<span style="font-weight: bold;font-size: 20px;padding: 10px;float:left;color: #364159">Results</span>
</div>
                 
<style>

	.courseredirect{background: #3CAF92 !important;display: block;margin: auto;border: 1px solid #209679;}
	h5.modal-title p.headtitle{display: inline-block;width: 100%;text-align: center;font-weight: bold;font-size:17px;color: #fff;}
	h5.modal-title p.text-muted{display: inline-block;width: 100%;text-align: center;font-weight: 600;font-size: 14px;line-height: 36px;color: #181E29;line-height: 20px;}
	.modal-title img{display: block;margin: 1em auto}
	#paydoneModal.modal .modal-header,#payfailModal.modal .modal-header{padding: 10px 20px !important;border: none}	
	#paydoneModal.modal .modal-body,#payfailModal.modal .modal-body{padding:0 1.75rem 1.75rem}
	.modal-body p{text-align: left !important}
	.modal-backdrop.show {opacity: .5 !important;}
	

	.alert{font-size: 14px;}
	.maincontent p.alert-success {color: #155724;}
	.maincontent p.alert-danger {color: #721c24;}
        
        
	
</style>

<div class="row align-items-end">
    <div class="col-4">
        <?php if(isset($roleaccess['Add New Exam'][3]) && $roleaccess['Add New Exam'][3]=="y"){ ?>
         <a class="addexam" style="position: relative;top:-10px;left:10px;font-size: 14px;padding: 10px;  color: #fff; margin: 0px auto; border-radius:5px;background: linear-gradient(180deg, #4F70C4 0%, #1C47B3 100%);text-decoration: none" href="javascript:void(0)"><span><img  src="<?php echo $this->config->item('web_url') ?>images/addcourse.png" alt="Navigation" /></span><span style="margin-left:5px">Add New Exam</span></a>
         <?php } ?>
    </div>
                 <div class="col-3">
                     <select id="searchtype">
                         <option value="exam">Exam Name</option>
                         <option value="edate">Exam Date</option>
                         <option value="etype">Type of Exam</option>
                         <option value="stuapp">Students Appeared</option>
                     </select>
                 </div>                                                                           
    		</div> 
<div class="row">
	<div class="col-md-12">
               <table class="sortable disabled table table-bordered" id="paymentlist">
                    <thead>
                           <th>S.NO</th>
                           <th>EXAM NAME</th>
                           <th>EXAM DATE</th>
                           <th>TYPE OF EXAM</th>
                           <th>STUDENTS APPEARED</th>
                           <th>ACTIONS</th>                           
                    </thead>				
               </table>
        </div>
</div>


</div>  


	<style>
		
		#addExamModal.modal .modal-header{padding: 5px 10px !important;border: none}	
		#addExamModal.modal .modal-body{padding:0 1.75rem 1.75rem}
		.modal-body p{text-align: left !important}
		.modal-backdrop.show {opacity: .5 !important;}
		#addExamModal h2{line-height: 24px;}
				
		.loader p{text-align: center !important;}
		
		.studentdetails p span{font-weight: bold;display: block}
		
		label{color: #4F70C4;}
		.row-element .content { width: 100% !important;}
                .chosen-container-multi .chosen-choices li.search-choice { background: #6884CC;border-radius: 5px;}
                .chosen-container-multi .chosen-choices li.search-choice {color: #fff;}
                #examtype_chosen { border: 1px solid #D7DFF0;background: #fff;width: 100% !important;padding: 6px;}
                .chosen-container-multi .chosen-choices {border: 0px;background: none}
                .maincontent ul li.search-choice { height:auto; }
     .maincontent ul li.search-choice a{ height:auto; font-size: 14px;color:#536485}
     .chosen-container-single .chosen-single { background: #fff !important;border: 0px !important;box-shadow: none !important}
	</style>
	
	<div id="addExamModal" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
		<div class="modal-dialog modal-dialog-centered" role="document">
			<div class="modal-content">
                            <div class="modal-header" style="padding: 0px !important">
                                    <div style="width: 100%;height: 45px;background: #6884CC">
                                        <span style="padding: 10px;position: relative;top: 10px;color: #fff;font-size: 14px">Add Exam</span>
				   <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span style="color: #fff;position: relative;top: 7px;left: -7px;" aria-hidden="true">&times;</span></button>
				</div>
                                    </div>
                            <div class="modal-body text-center" style="padding-top: 10px;padding-left: 15px;padding-bottom: 10px">
				<?php echo form_open('exams/addExam', array('id' => 'examForm')) ?>
                                    <div class="row-element" style="margin:0px">
                                    
                                    <span class="content">
                                        <input type="text" placeholder="Exam Name"  id="ename" name="ename">

                                    </span>
                                    </div>
					<div class="row-element" style="margin:0px">
                                    
                                    <span class="content">
                                        <input type="text" placeholder="Exam Date" id="edate" name="edate" style="width:100%;background: #fff url('<?php echo base_url(); ?>/images/cal.png') no-repeat 99%;">

                                    </span>
                                    </div>
                                    <div class="row-element" style="margin:0px">
                                    
                                    <span class="content">
                                         <select id="examtype" name="etype">
                                             <option>Select Exam Type</option>
                                            <option>Weekly</option>
                                            <option>Model</option>
                                            <option>Screening Test</option>
                                         </select>

                                    </span>
                                    </div>
                                    <div class="row-element" style="margin:0px">
                                    
                                    <span class="content">
                                        <input type="text" placeholder="No of Students Appeared" id="stuapp" name="stuapp">

                                    </span>
                                    </div>
					 <?php echo form_close() ?>					
				</div>
				<div class="modal-footer">
				
					<div class="alert mb-0"></div>
					
					<button type="button" class="btn btn-primary saveexam"><img src='<?php echo base_url(); ?>images/loader.gif' class="updateloader d-none mr-2">Save</button>
					<button type="button" class="btn btn-outline-primary modalclose" data-dismiss="modal">Close</button>
				</div>
								
			</div>
		</div>
	</div>

<html><head>
<title>ID Card</title>
<script src="<?php echo base_url();?>js/jquery-3.5.1.min.js"></script>
<script>
	$(document).ready(function(){

		//window.print();

	});
</script>
    </head>
    <body>

<div style="text-align: center"> 
   
    <img style="margin :4rem auto 0;" src="downloadidcard/downloadStudentIDcard" alt="ID Card">
        
    </div>

</body>
</html>
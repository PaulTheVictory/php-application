
<script src="<?php echo base_url();?>js/jquery.validate/jquery.validate.min.js"></script>
<script src="<?php echo base_url();?>js/jquery.validate/additional-methods.min.js"></script>

<script type="text/javascript">
$(document).ready(function(){	
	
	$('#signupForm').submit( function(e){     

            e.preventDefault();
            var $form = $(this);

          // check if the input is valid
            if(! $form.valid()) return false;
		
			$(".step1 .alert,.step2 .alert").removeClass('alert-danger').text("");
		
		var password = $("#supassword").val();
		var confirmpassword = $("#suconfpassword").val();
		
		if(password!=confirmpassword){$(".alert").addClass('alert-danger').text("Mismatch password"); return false;}
		
		
		var errors;
		
		var sumobile = $("#sumobile").val();
		var sumcode = $("#sumcode").val();
		
		var $validator = $("#signupForm").validate();
		
		if(sumcode=="91" && sumobile!=""){
			
			var firstno = parseInt(sumobile.charAt(0));console.log(firstno);
			
			var noarr = [6, 7, 8, 9];
			
			if ($.inArray(firstno, noarr) === -1){
				
				$(".alert").addClass('alert-danger').text("Please enter valid mobile number"); return false;
				
			}
			
		}

		if($(".signupbtn").hasClass('process')){
			
			$(".step1 .alert").addClass('alert-danger').text("Please wait while processing...");
			
		}else{
		
			$(".signupbtn").addClass('process');
			$(".step1 .alert").removeClass('alert-danger').addClass('alert-success').text("Processing...");
			
           $.ajax({
                type: 'POST',
                url: 'signup/studentSignup',
                data: new FormData(this),
			    contentType: false,
    			processData: false,
                success: function(response) {
                   
					var obj1 = $.parseJSON(response);
					
					if(obj1[0]=="success"){
												
						$(".alert").removeClass('alert-danger');
						
						var studentid = "";
						if(obj1[5]!=""){
							$("#studentno").val(obj1[5]);
							studentid = "Your Student ID: "+ obj1[5] +". ";
						}else{
							$("#studentno").val('');
						}
						
						$(".step1 .alert").addClass('alert-success').text(studentid+"OTP send to your mobile number and email");
						setTimeout(function(){
							$(".step1 .alert").removeClass('alert-success').text("");
							$(".step1").fadeOut().addClass('d-none');
							$(".step2").fadeIn().removeClass('d-none');
							$("#studid").val(obj1[3]);
							$(".step2 h6").html("Please enter the verification code sent to your mobile number "+Masknumber(obj1[4])+".");
						},3000);
						
					}else if(obj1[0]=="exists"){
						$(".alert").addClass('alert-danger').text("Already exists. Please contact us for details.");
						$(".signupbtn").removeClass('process');
					}else if(obj1[0]=="fail"){
						$(".alert").addClass('alert-danger').text("Signup failed");
						$(".signupbtn").removeClass('process');
					}else if(obj1[0]==""){
						$(".alert").addClass('alert-danger').text("Please try again.");
						$(".signupbtn").removeClass('process');
					}
					
                }

            });
			
		}
		
        });
	
	$('#verifyForm').submit( function(e){     

            e.preventDefault();
            var $form = $(this);

          // check if the input is valid
            if(! $form.valid()) return false;
		
			$(".step1 .alert,.step2 .alert").removeClass('alert-danger').text("");
		
			$(".step2 .alert").addClass('alert-success').text("Processing...");
		
			var password = $("#supassword").val();
		
			var formData = new FormData(this);
			formData.append('password', password);

           $.ajax({
                type: 'POST',
                url: 'signup/verifyOTP',
                data: formData,
			    contentType: false,
    			processData: false,
                success: function(response) {
                   
					var obj1 = $.parseJSON(response);
					
					if(obj1[0]=="valid"){
						
						$(".step2 .alert").removeClass('alert-danger');
						$(".step2 .alert").addClass('alert-success').text("Signup Success");
						setTimeout(function(){
							$(".step2 .alert").removeClass('alert-success').text("");
							location.assign('stucourses');
						},3000);
						
					}else if(obj1[0]=="error"){
						$(".step2 .alert").removeClass('alert-success').addClass('alert-danger').text(obj1[1]);
					}else if(obj1[0]=="invalid"){
						$(".step2 .alert").removeClass('alert-success').addClass('alert-danger').text("OTP not matched");
					}else if(obj1[0]=="failed" || obj1[0]=="notfound"){
						$(".step2 .alert").removeClass('alert-success').addClass('alert-danger').text("Verification failed");
					}else if(obj1[0]==""){
						$(".step2 .alert").removeClass('alert-success').addClass('alert-danger').text("Please try again later");
					}
					
                }

            });
        });
	
	
	$('.resendcode').click( function(e){     
       
			$(".step1 .alert,.step2 .alert").removeClass('alert-danger').text("");
		
			$(".step2 .alert").addClass('alert-success').text("Processing...");
		
			var studid = $("#studid").val();

           $.ajax({
                type: 'POST',
                url: 'signup/resendOTP',
                data: {'studid':studid},
                success: function(response) {
                   
					var obj1 = $.parseJSON(response);
					
					if(obj1[0]=="success"){
						
						$(".step2 .alert").removeClass('alert-danger');
						$(".step2 .alert").addClass('alert-success').text("OTP send to your mobile number " +Masknumber(obj1[1])+ " and email.");
						setTimeout(function(){
							$(".step2 .alert").removeClass('alert-success').text("");
						},2000);
						
					}else if(obj1[0]=="failed"){
						$(".step2 .alert").removeClass('alert-success').addClass('alert-danger').text("Resend failed");
					}else if(obj1[0]==""){
						$(".step2 .alert").removeClass('alert-success').addClass('alert-danger').text("Please try again later");
					}
					
                }

            });
        });
	
	
	$("input[name='sutype']").change(function(){
		
		var type = $(this).val();
		
		if(type=="Sibling"){
			
			$(".parentname,.relation").fadeIn(800).removeClass('d-none');
			$("#suparentname,#surelationship").prop('required',true);
			
		}else{
			$(".parentname,.relation").fadeOut(800).addClass('d-none');
			$("#suparentname,#surelationship").prop('required',false);
		}
		
	});
	
	$("form select").change(function(){
		$(this).attr('value',$(this).val());
	});
	
	
	$("#sumcode").change(function(){
		
		var sumcode = $(this).val();
		
		if(sumcode!="91"){
			$("#sumobile").attr('minlength',3).attr('maxlength',20);
		}else{
			$("#sumobile").attr('minlength',10).attr('maxlength',10);
		}
		
	});
	
	
	/*$("#sucsmaster").change(function(){
		
		var classstudyid = $(this).val();
		
		$.ajax({
                type: 'POST',
                url: 'signup/getAllClassMasterQualifications',
                data: {'classstudyid':classstudyid},
                success: function(response) {
                   
					$("#suclassstudy").html(response);
					
					
                }

            });
		
	});*/
	
});
	
function Masknumber(number, character = "*"){
  number = number.replace(/[^0-9]+/g, ''); /*ensureOnlyNumbers*/
  var l = number.length;
  return number.substring(0,2) + character.repeat(l-4) + number.substring(l-2,l);
}

function Maskmail(email, character = "*"){
	
	var ename = email.split('@');
	var emailname = ename[0];
    var l = emailname.length;
	
	var maskdata = emailname.substring(0,2) + character.repeat(l-4) + emailname.substring(l-2,l);
	
  return maskdata+'@'+ename[1];
	
}
	
</script>

<main>
  <div class="container">
    <div class="row">
      <div class="col-12 mx-auto my-auto p-xs-0">
        <div class="card auth-card signup">
         
          	<div class="position-relative image-side"></div>
      
             <div class="form-side sign-form step1">
           
            <h3 class="mb-1">Get Started</h3>
            <h6 class="mb-4">Please sign up with your information</h6>
            
            <form id="signupForm" class="tooltip-right-bottom" novalidate>
            
            <div class="form-group position-relative error-l-50 mb-3">
               	  <div>
					  <div class="custom-control custom-radio col-sm-5">
						<input type="radio" id="sutype1" name="sutype" class="custom-control-input" value="Student" required="">
						<label class="custom-control-label" for="sutype1">Sign up as Student</label>
					  </div>
					  <!--div class="custom-control custom-radio col-sm-5">
						<input type="radio" id="sutype2" name="sutype" class="custom-control-input" value="Sibling" required="">
						<label class="custom-control-label" for="sutype2">Sign up as Sibling</label>
					  </div-->
                </div>
              </div>
           
            <div class="form-group position-relative error-l-50 floating">
				 <input class="form-control" id="suname" name="suname" placeholder=" " required >
            	 <label>Student Name <span>*</span></label>
             </div>
           
            <div class="form-group position-relative error-l-50 parentname d-none floating">
				 <input class="form-control" id="suparentname" name="suparentname" placeholder=" " required >
            	 <label>Parent Name <span>*</span></label>
             </div>
           
            <div class="form-group position-relative error-l-50 relation d-none floating">
				<select class="form-control" id="surelationship" name="surelationship" onclick="this.setAttribute('value', this.value);" value="" required>
					<option value=""></option>
					<option value="Father">Father</option>
					<option value="Mother">Mother</option>
					<option value="Guardian">Guardian</option>
				</select>
           		<label>Select Relationship</label>
             </div>
              
            <div class="form-row">
              
			  <div class="form-group col-md-3 position-relative error-l-50 floating">
				<select class="form-control" id="sumcode" name="sumcode" required>
				  <option value="91">+91</option><option value="44">+44</option><option value="65">+65</option><option value="973">+973</option><option value="20">+20</option><option value="98">+98</option><option value="964">+964</option><option value="972">+972</option><option value="962">+962</option><option value="965">+965</option><option value="961">+961</option><option value="968">+968</option><option value="970">+970</option><option value="974">+974</option><option value="966">+966</option><option value="90">+90</option><option value="971">+971</option><option value="967">+967</option><option value="93">+93</option><option value="374">+374</option><option value="994">+994</option><option value="76">+76</option><option value="996">+996</option><option value="92">+92</option><option value="963">+963</option><option value="992">+992</option><option value="993">+993</option><option value="998">+998</option><option value="357">+357</option><option value="253">+253</option><option value="291">+291</option><option value="995">+995</option><option value="352">+352</option><option value="249">+249</option>
				</select>
			  </div>

			  <div class="form-group col-md-9 position-relative error-l-50 floating">
				<input type="number" class="form-control" id="sumobile" name="sumobile" placeholder=" " minlength="10" maxlength="10" required="">
				<label>Mobile Number <span>*</span></label>
			  </div>
              
			</div>
             
             <div class="form-group position-relative error-l-50 floating">
				 <input type="email" class="form-control" id="suemailid" name="suemailid" placeholder=" " required >
            	<label>Email Address <span>*</span></label>
             </div>
             
              <div class="form-group position-relative error-l-50 floating">
				 <input class="form-control" type="password" id="supassword" name="supassword" placeholder=" " required > 
            	<label>Create Password <span>*</span></label>
             </div>
             
              <div class="form-group position-relative error-l-50 floating">
				 <input class="form-control" type="password" id="suconfpassword" name="suconfpassword" placeholder=" " required> 
            	<label>Confirm Password<span>*</span></label>
             </div>
             
              <div class="form-group position-relative error-l-50 floating">
                <select class="form-control" id="suclassstudy" name="suclassstudy" value="" required>
                  <?php echo $classstudymaster;?>
                </select>
                <label>Select Class Studying <span>*</span></label>
              </div>              
             
              <!--<div class="form-group position-relative error-l-50 floating">
                <select class="form-control" id="suclassstudy" name="suclassstudy" value="" required>
                  <?php //echo $qualification;?>
                </select>
                <label>Select Qualification <span>*</span></label>
              </div>-->
              
              <div class="form-group position-relative error-l-200 mb-3">
                <div class="custom-control custom-checkbox">
                  <input type="checkbox" class="custom-control-input" id="suiagree" name="suiagree" value="Yes" required>
                  <label class="custom-control-label" for="suiagree">I Agree to the <a href="<?php echo base_url();?>termsandconditions" title="Terms & Conditions" target="_blank">Terms & Conditions</a></label>
                </div>
              </div>
                            
              <button class="btn btn-primary signupbtn" type="submit">Sign Up</button>
              
            </form>
            
            <p class="alert"></p>
            
          </div>
          
          <div class="form-side verify-form step2 d-none">
           
            <h3 class="mb-1">Verification Code</h3>
            <h6 class="mb-4"> </h6>
            
            <form id="verifyForm" class="tooltip-right-bottom" novalidate>
                       
            <div class="form-group position-relative error-l-50">
				 <input class="form-control" id="verifyotp" name="verifyotp" placeholder="Verification Code*" minlength="4" maxlength="4" required >
             </div>
                               
               <input type="hidden" name="studid" id="studid" />
               <input type="hidden" name="studentno" id="studentno" />
                                                                               
              <button class="btn btn-primary verifybtn" type="submit">Submit</button>
              
            </form>
            
			  <p class="mb-3 text-muted text-center">Didn’t receive code? <a href="javascript:void(0);" class="resendcode">Resend code</a></p>
            
            <p class="alert"></p>
            
          </div>
         
        </div>
      </div>
    </div>
  </div>
</main>

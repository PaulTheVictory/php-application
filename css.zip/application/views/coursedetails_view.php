 <link href="<?php  echo base_url(); ?>css/jquery-ui.min.css?v=1.4" rel="stylesheet" type="text/css" />
 <script src="<?php  echo base_url(); ?>js/jquery-ui.min.js?v=1.3" type="text/javascript"></script>
 <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/dataTables.css?v=1.5" />
<script src="<?php echo base_url(); ?>js/jquery.dataTables.js?v=1.0" type="text/javascript"></script>
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/lc_switch.css?v=1.3" />
<script src="<?php echo base_url(); ?>js/lc_switch.min.js?v=1.0" type="text/javascript"></script>


 <style type="text/css">
     
     .row-element .title { color: #6884CC; padding: 5px;line-height: 20px;}
     .row-element .content { color: #364159; padding: 5px;line-height: 20px;font-size: 14px}
     .sortable thead tr  {
    background: #E6EBF7;

/* g8 */
border: 1px solid #D7DFF0;
box-sizing: border-box;
border-radius: 10px 10px 0px 0px;
 

}
.sortable tr th {
    border-right: 0px;
    padding: 20px 0;font-size: 13px;
      color: #6F83AA;
   cursor: pointer;
   text-align: center;

}


.sortable tr td:nth-child(1) {
   
    min-width:50px;color: #364159;
}

.sortable tr td:nth-child(2) {
   
    min-width:150px;
}

.sortable tr td {
    border-right: 0px;
    padding: 15px 5px;
    text-align: center;font-size: 13px;
    min-width:50px;
}
.sortable tr td a {
    color: #364159;
}

#profile-right h2 {
    margin: 0px 0px 10px 0px;
}

.dataTables_info { display: none; }
#paymenttable_paginate { display: none;}
#paymenttable_filter input {display:none;}
.sortable tr td a:hover { text-decoration: underline; }
.centers li { list-style: none;padding:5px;display: inline-block;width: 100%;}
.ui-checkboxradio-radio-label .ui-icon-background { border: 1px solid #D7DFF0; }
.ui-checkboxradio-radio-label.ui-checkboxradio-checked .ui-icon, .ui-checkboxradio-radio-label.ui-checkboxradio-checked:hover .ui-icon { border-width: 5px;border-color: #0332aa;}
.ui-selectmenu-button.ui-button{ width: auto;margin-top: 10px;float: left;border: 1px solid #D7DFF0;background: #fff;font-size: 13px;color:#536485;padding: 5px}
.sortable tr td span{ font-size: 14px;color: #364159 }
 .loader {
    display: none;
    position: absolute;
    top: 0; left: 0; right: 0; bottom: 0;
    background: rgba(255,255,255,0.8) url('<?php echo base_url(); ?>images/loader.gif') center center no-repeat;
    z-index: 1000;
}
 </style>

	<div class="wrap dynamic-width" style="float: left;position: relative;min-width: 800px">
     <div style="margin-top: 10px; width: 99%; height: 50px; text-align: right;">
         <span style="font-weight: bold;font-size: 20px;padding: 10px;float:left;color: #364159">Course Details</span>
        
        <?php if(isset($roleaccess['Courses'][1]) && $roleaccess['Courses'][1]=="y"){ ?>
        
        <?php if($this->session->userdata('adlog_in')) { ?> 
         <a style="padding: 10px;  color: #fff; margin: 0px auto; background: linear-gradient(180deg, #4F70C4 0%, #1C47B3 100%); position: relative; top: 5px;border-radius:5px;font-size: 14px" class="btn" href="<?php echo base_url(); ?>editcourse?id=<?php echo html_escape($edit['ide']); ?>"><span style="position: relative;top:4px"><img  src="<?php echo $this->config->item('web_url') ?>images/addcourse.png" alt="Navigation" /></span><span style="margin-left:5px">Edit Course</span></a>
        <?php } ?><?php } ?>
     </div>         
            <div id="course-container" class="add-course">

                <div class="row-element">
                    <span class="title">Course Name</span>
                    <span class="content" style="font-size: 16px;font-weight:bold"><?php echo html_escape($edit['coursename']); ?></span>
                </div>
                
                
                <div class="row-element">
                    <span class="title">ID Card Display Name</span>
                    <span class="content">
                        <label style="color:#536485;background: none;border: 0px;width: 48%;height: auto;float:left;"><?php echo html_escape($edit['idcard_displayname']); ?></label>                       
                    </span>
                </div>
                
                
                <div class="row-element">
                    <span class="title">Course Stream</span>
                    <span class="content">
                        <label style="color:#536485;background: none;border: 0px;width: 48%;height: auto;float:left;"><?php echo html_escape($edit['stream']); ?></label>                       
                    </span>
                </div>
                
                
                <div class="row-element">
                    <span class="title">Course Type</span>
                    <span class="content">
                        <label style="color:#536485;background: none;border: 0px;width: 48%;height: auto;float:left;"><?php echo html_escape($edit['type']); ?></label>                       
                    </span>
                </div>
                
                
                <div class="row-element">
                    <span class="title">Accounting Head</span>
                    <span class="content">
                        <label style="color:#536485;background: none;border: 0px;width: 48%;height: auto;float:left;"><?php echo html_escape($edit['accountinghead']); ?></label>                       
                    </span>
                </div>
                 <div class="row-element">
                    <span class="title">Screening Test</span>                    
                    <span class="content">
                        <?php if($edit['stest'] === '1') { echo "Available";}else { echo "Not Available";} ?>
                          </span>
                </div>
                <div class="row-element">
                    <span class="title">Duration</span>
                    <span class="content">
                        <label style="color:#536485;background: none;border: 0px;width: 48%;height: auto;float:left;"><?php echo html_escape($edit['duration']); ?></label>                       
                    </span>
                </div>
                
                <div class="row-element">
                    <span class="title"><?php  if($edit['stest'] === '1') { echo "Test Date";}else { echo "Commences on";}?></span>
                    <span class="content"><?php echo html_escape($edit['commenceson']); ?>
                                               
                    </span>
                </div>
                <?php  if($edit['stest'] === '1') { ?>
                <div class="row-element">
                    <span class="title">Exam Time</span>
                    <span class="content"><?php echo html_escape($edit['examtime']); ?>
                                               
                    </span>
                </div>
                <div class="row-element">
                    <span class="title">Cool of Time</span>
                    <span class="content"><?php echo html_escape($edit['cooloftime']); ?> Minutes
                                               
                    </span>
                </div>
                <div class="row-element">
                    <span class="title">Reporting Time</span>
                    <span class="content"><?php echo html_escape($edit['reportingtime']); ?>
                                               
                    </span>
                </div>
                <div class="row-element">
                    <span class="title">Mode of exam</span>
                    <span class="content"><?php echo html_escape($edit['modeofexam']); ?>
                                               
                    </span>
                </div>
                <?php } ?>
                <div class="row-element">
                    <span class="title"><?php  if($edit['stest'] === '1') { echo "Application Period:";}else { echo "Admission Time";}?></span>
                    <span class="content">
                        <?php 
                        $timestamp = strtotime($edit['starts_on']);
                        $timestamp1 = strtotime($edit['ends_on']);
                        echo  date('M Y',$timestamp).' - '. date('M Y',$timestamp1);
                        ?>                    
                    </span>
                </div>

                <div class="row-element">
                    <span class="title">Qualification</span>                    
                    <span class="content"><?php echo html_escape($edit['qname']); ?></span>
                </div>
                  <?php if($edit['stest'] !== '1') { ?>                
                <div class="row-element">
                    <span class="title">Class Schedule</span>                    
                    <span class="content">
                        <?php $csh =  explode("|",($edit['cshedule'])); if($csh[0] === 'regular') { echo "Regular,";} if($csh[1] === 'weekend') { echo "Weekend,";} if($csh[2] === 'both') { echo "Both,";} if($csh[3] === 'hybrid') { echo "Hybrid,";} if($csh[4] === 'special') { echo "Special,";} if($csh[5] === 'other') { echo "Other State";}?>
                          </span>
                </div>
                
                <div class="row-element">
                    <span class="title">Course Type</span>                    
                    <span class="content">
                        <?php if($edit['ctype'] === 'online') { echo "Online";}else if($edit['ctype'] === 'room') { echo "Class room";}else if($edit['ctype'] === 'both') { echo "Both";}?>
                          </span>
                </div>
                <?php } ?>              
                
                 <div class="row-element">
                    <span class="title">Centers</span>                    
                    <span class="content"><?php echo str_replace("|",",",html_escape($edit['centers1'])); ?></span>
                </div>
                
                <div class="row-element">
                    <span class="title">Course Description</span>                    
                    <span class="content">
                        <?php echo html_escape($edit['description']); ?>
                    </span>
                </div>
                
            <div class="row-element">
                    <span class="title">Refund Policy</span>                    
                    <span class="content">
                        <?php echo html_escape($edit['refund']); ?>
                    </span>
                </div>
                
            </div>
           <div style="margin-top: 10px; width: 100%; height: 50px; text-align: right;"><div class="loader"></div>
             <span style="font-weight: bold;font-size: 20px;padding: 10px;float:left;color: #364159">Course Fees</span>
                    
                    <?php if(isset($roleaccess['Course Edit Fees'][3]) && $roleaccess['Course Edit Fees'][3]=="y"){ ?>
                    
             <a style="font-size: 14px;padding: 10px;  color: #fff; margin: 0px auto; position: relative; top: 5px;border-radius:5px;background: linear-gradient(180deg, #4F70C4 0%, #1C47B3 100%);" href="<?php echo base_url(); ?>addpayment?id=<?php echo html_escape($edit['ide']); ?>"><span style="position: relative;top:4px"><img  src="<?php echo $this->config->item('web_url') ?>images/addcourse.png" alt="Navigation" /></span><span style="margin-left:5px">Edit fees</span></a>
                    <?php } ?>
         </div>  
  
    <div class="centers" style="width:18%;min-width: 100px;height: auto;float:left;border: 1px solid #D7DFF0;border-radius: 5px">
        <div style="width:100%;height:auto;margin:0px auto;background: #fff">
        <span style="color: #6F83AA;width: 300px;height:55px;text-align: center;font-size: 15px;vertical-align: middle;display: table-cell;background: #E6EBF7">Course Centers</span>
        <ul>
           <?php 
            echo $edit["centers"]; 
            ?>
        </ul>
        </div>
    </div>
    <div style="width:81%;height: auto;float:right">
         <?php echo $this->table->generate();  ?>             
         
        
     <div style="margin-top: 0px; width: 98%; height: 100px; ">
      
         <div style="text-align:right"><span style="color:#536485;font-size: 14px;font-weight: bold">Grand Total : </span> <span class="gtotal" style="font-size: 20px;font-weight: bold">12122</span></div>
          </div> 
        </div>
        
        </div>
  
<script type="text/javascript">
$(document).ready(function() {
    
    $(".radiocenters").checkboxradio();
        
    var columnData = [
                    { "data": "sno" },
                    { "data": "description" },
                    {"data": "active" },                            
                    { "data": "sac" },                    
                    { "data": "amount" },
                    { "data": "discount" },
                    { "data": "tax" },              
                    { "data": "total" }
                    
                  ];
                  
       
        var oTable = $('#paymenttable').dataTable({
                    "bProcessing": true,
                    "bServerSide": true,
                    "sPaginationType": "full_numbers",
                    "ajax": {
                    "url": 'coursedetails/getPaymentLists',
                    "type": "POST",
                    "data":{ "ide": "<?php echo html_escape($edit['ide']); ?>"}
                     }, 
                     "oLanguage": {
                        "sProcessing": "<img src='<?php echo base_url(); ?>images/loader.gif'>"
                    },
                    'iDisplayLength': 100,
                    "columns": columnData,
                    "fnDrawCallback": function( oSettings ) {
                        
                        $('#paymenttable').find("tr .lcs_check").each(function(){
                            
                            if( ($(this).val()) === "1") {
                             $(this).lc_switch().lcs_on();
                             $(this).closest("tr").addClass("show");
                            } else {
                             $(this).lc_switch().lcs_off();   
                            }
                          });
                        
                        $('#paymenttable').find("tr .description").each(function(){
                            var yT= $(this).attr("attr-centers");
                            $(this).closest("tr").attr("attr-centers",yT);        
                          });
                          
                          $(".centers").find("li").first().find("input").trigger("click");
                          var yT= $(".centers").find("li").first().find("input").attr("attr-centers");
                  
                       /*   $('#paymenttable').find("tbody tr").each(function(){
                 
                                if($(this).attr("attr-centers") === yT){ 
                                    $(this).css("display","");   
                                } else {
                                    const attr = $(this).attr('attr-centers');
                                    if (typeof attr !== 'undefined' && attr !== false) { $(this).css("display","none"); } 
                                    
                                }

                            });*/
                                             
                    }
         }); 
         
         $(".radiocenters").click(function(){ 
         
         var t = $(this).attr("attr-centers");  
               
        $('#paymenttable').find("tbody tr").each(function(){
                 
                if($(this).attr("attr-centers") === t){ 
                    $(this).css("display","");   
                    $(this).addClass("show");
                    
                } else {
                     const attr = $(this).attr('attr-centers');
                     if (typeof attr !== 'undefined' && attr !== false) { 
                         $(this).css("display","none"); 
                         $(this).removeClass("show");
                     } 
                }
                grandTotalUpdate();
            
            });
            
       
         
         });
         
           function grandTotalUpdate() {
        
       var ltotal = 0;
        $(".show").each(function(){
        
            var y = ($(this).find(".total").text() === '')?'0':($(this).find(".total").text());
            ltotal = parseFloat(ltotal) + parseFloat(y);ltotal = parseFloat(ltotal).toFixed(2);
           
        });
         $(".gtotal").text(ltotal);
    
    }
    
    
    $('body').delegate('.lcs_switch', 'click', function() {
        
        var desc = ""; var action = "";var centers = "";
        if($(this).hasClass("lcs_on")) {
            desc = $(this).closest("tr").find(".description").text();
            centers = $(this).closest("tr").attr("attr-centers");
            action = "0";
        } else {            
             desc = $(this).closest("tr").find(".description").text();
             centers = $(this).closest("tr").attr("attr-centers");
             action = "1";
        }
        
        $(".loader").show();
        $.get('coursedetails/UpdatePaymentForDescription',{
                                                               'ide':"<?php echo html_escape($edit['ide']); ?>",
                                                               'desc':desc,
                                                               'action':action,
                                                               'centers':centers

                                                    }, function(o) { 
                                                            var obj1 = $.parseJSON(o);
                                                    if (obj1[0] === 'success') {
                                                        alert("Success!!! Course Payment Updated");
                                                        $(".loader").hide();
                                                    } 
                                    });
     
    });

         
        
	
});
</script>
 <link href="<?php  echo base_url(); ?>css/jquery-ui.min.css?v=1.4" rel="stylesheet" type="text/css" />
 <script src="<?php  echo base_url(); ?>js/jquery-ui.min.js?v=1.3" type="text/javascript"></script>


 <style type="text/css">
     
.ui-selectmenu-text { font-size:13px;}
.course-container {
    
    /*box-shadow: 3px 3px 3px #eee;
    -webkit-box-shadow:3px 3px 3px #eee;
    -moz-box-shadow:3px 3px 3px #eee;*/
    padding-top: 20px;
    
    width:98%;
    background: #fff;
    padding-left: 20px;
    border-radius: 10px;
    
}

.row-element {
    display: inline-block;
    height: auto;
    margin: 10px auto;
    width: 100%;
}

.row-element .content {
   float: left;
    padding: 10px 15px;
    text-align: left;
    width: 95%;
    min-width: 400px;
}
.ui-selectmenu-button.ui-button{ width: 97%; padding:10px;border: 1px solid #D7DFF0;background: #fff;font-size: 14px;color:#536485}
	 
	  .qualificationcheck .card{background: linear-gradient(0deg, #FFFFFF, #FFFFFF), #C4C4C4;box-shadow: 0px 0px 7px rgba(196, 196, 196, 0.35);border-radius: 10px;}

 </style>
 <main> <div class="container-fluid">
         <?php echo form_open('updatequalification/qualificationSubmit', array('id' => 'qualificationForm')) ?>
<div class="wrap dynamic-width">
     <div style="margin-top: 10px; width: 99%; height: 50px; text-align: left;">
         <span style="font-weight: bold;font-size: 20px;padding: 10px;float:left;color: #364159">Update Qualification (Select Your Qualification To Avail New Courses and Tests)</span>
         </div>   
               
            <div class="row px-3 mt-4">     
                     
           <div class="col-12 qualificationcheck p-0">
           
           <div class="card">
           
            <div class="course-container add-course mt-3 px-4">
                                
                <div class="row">
                   
                    <div class="col-12 col-sm-6">
                    
				  		<div class="form-group floating">
                      
                    		<select  id="yearofpassing" name="qualification" class="form-control yearofpassing qualification_year">
                            <?php 
                              //echo $qualification;
								echo $classstudymaster;
                            ?>
                       		 </select>
							 <label>Select Class Studying <span>*</span> </label>
						</div>
					</div>
				</div>
               
                </div>
                
			   </div>
               
            </div>
             
        <label style="background: none;border: 0px;width: 100%;height: 30px;">&nbsp;</label> 
      
          <div style="margin-top: 0px; width: 98%; height: 70px; text-align: right;overflow: hidden">
         <span  style="margin: 0px auto; float:right;margin-top: 18px;padding: 10px; color: #fff; background: #4f6fc4 none repeat scroll 0% 0%; border-radius:5px;cursor: pointer" class="btn savebtn" href="#">Save</span>
         <a style="margin: 0px auto; float:right;margin-top: 18px;margin-right:18px;padding: 9px 10px; color: #0332AA; background: linear-gradient(0deg, #FFFFFF, #FFFFFF), #C4C4C4;border: 1px solid #0332AA; border-radius:5px" class="btn" href="<?php echo base_url(); ?>stuqualifyupdate">Back</a>
         <span class="response" style="margin: 0px auto; float:right;width: 80%; height: 30px;margin-top:20px"></span>
          </div> 
          
           </div>
       
        </div>
          <?php echo form_close() ?>
 </div>
     <style>

	.courseredirect{background: #3CAF92 !important;display: block;margin: auto;border: 1px solid #209679;}
	h5.modal-title p.headtitle{display: inline-block;width: 100%;text-align: center;font-weight: bold;font-size: 24px;line-height: 36px;color: #3CAF92;}
	h5.modal-title p.text-muted{display: inline-block;width: 100%;text-align: center;font-weight: 600;font-size: 14px;line-height: 36px;color: #181E29;line-height: 20px;}
	.modal-title img{display: block;margin: 1em auto}
	
</style>
     <button type="button" class="btn btn-outline-primary d-none courseconfirm" data-toggle="modal" data-backdrop="static" data-target="#courseModal">Confirm Submission</button>  
<!-- Modal -->
<div class="modal fade" id="courseModal" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog" role="document">
	<div class="modal-content">
	  <div class="modal-header">
	  
		<h5 class="modal-title" id="exampleModalLabel">
		
			<p class="headtitle mb-4">Success !!!</p>
		
			<p class="text-muted mb-4">Qualification Updated..</p>
		</h5>
	  </div>
	  
	  <div class="modal-footer">
		<button type="button" class="btn btn-primary courseredirect px-5" data-dismiss="modal">Okay</button>
	  </div>
	</div>
  </div>
</div>
 
 </main>
<script type="text/javascript">
    $(document).ready(function() {
   
    //$(".yearofpassing").selectmenu(); 
    
       $(".courseredirect").click(function(){
      
		   var uqtype = "<?php echo isset($_GET['type'])?$_GET['type']:''; ?>";
		   
		   var url = "";
		   if(uqtype=="test") url = "stutests"; 
		   else url = "stucourses";
			  
			$(location).prop('href', url);
          
         });
  
     $(".savebtn").click(function(){
         
               $(".response").html('').text('Progressing...');
                         
                var qualificationForm = $("#qualificationForm");

                    $.ajax({
                        url: qualificationForm.attr('action'),
                        type: 'post',
                        data: qualificationForm.serialize(),
                        success: function(o){
                            var response = $.parseJSON(o);
                            $(".response").html('');
                            if(response.status === 'success') {
                                 $(".courseconfirm").trigger('click');
                               
                            } else {
                                
                                $("#exampleModalLabel").find(".headtitle").text('ERROR');
                                $("#exampleModalLabel").find(".text-muted").text('Qualification is not matched for your request for course registration');
                               $(".courseconfirm").trigger('click'); 
                           
                            }

                        }
                    });
                   
                              
            });
    
           
    });
    </script>
    
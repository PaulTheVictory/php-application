<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Brilliant Study Centre, Pala</title>
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1">

<link rel="stylesheet" href="<?php echo base_url();?>css/fonts/iconsmind-s/css/iconsminds.css">
<link rel="stylesheet" href="<?php echo base_url();?>css/fonts/simple-line-icons/css/simple-line-icons.css">
<link rel="stylesheet" href="<?php echo base_url();?>css/boot/bootstrap.min.css">
<link rel="stylesheet" href="<?php echo base_url();?>css/boot/bootstrap.rtl.only.min.css">
<link rel="stylesheet" href="<?php echo base_url();?>css/boot/bootstrap-float-label.min.css">
<link rel="stylesheet" href="<?php echo base_url();?>css/boot/vendor/smart_wizard.min.css">

<link rel="stylesheet" href="<?php echo base_url();?>css/boot/main.css">

<link rel="stylesheet" href="<?php echo base_url();?>css/boot/styles-media.css?v=1.0">

<script src="<?php echo base_url();?>js/jquery-3.5.1.min.js"></script>

	<style>
		
		body.background main{min-height: 100%}
	
.sidebar-navigation {
  width: auto;
  height: auto;
  background-color: #fff;
  margin: 1rem auto;
}
.sidebar-navigation .title {
  display: block;
  font-size: 1.2em;
  background-color: #1e1e1e;
  padding: 20px 25px;
  color: #fff;
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 0.1em;
}
.sidebar-navigation > ul > li > a {
  text-transform: normal;
}
.sidebar-navigation ul {
  margin: 0;
  padding: 0;
	background: #fff;
}
.sidebar-navigation ul li {
  display: block;
}
.sidebar-navigation ul li a {
  position: relative;
  display: block;
  font-size: 1em;
  font-weight: 600;
  padding: 20px 25px;
  text-decoration: none;
  color: #2e2e2e;
  letter-spacing: 0.02em;
  border-bottom: 1px solid #eee;
  -webkit-transition: all 0.3s linear;
  -moz-transition: all 0.3s linear;
  -o-transition: all 0.3s linear;
  transition: all 0.3s linear;
}
.sidebar-navigation ul li a em {
  font-size: 18px;
  position: absolute;
  right: 15px;
  top: 50%;
  transform: translateY(-50%);
  padding: 5px 0;
  border-radius: 50%;
	font-style: normal;
}
.sidebar-navigation ul li a em:before{
content: "+";
  font-size: 18px;
  position: absolute;
  right: 0px;
  top: 50%;
  transform: translateY(-50%);
  padding: 5px 0;
  border-radius: 50%;
  font-style: normal;
	
}			
.sidebar-navigation ul li a em.mdi-chevron-down:before{
content: "+";	
}		
.sidebar-navigation ul li a em.minus:before{
content: "-";right: 3px;
}
.sidebar-navigation ul li:hover > a, .sidebar-navigation ul li.selected > a {
  background-color: #ecf0f1;
  color: #495d62;
  border-color: rgba(255, 255, 255, 0.1);
}
.sidebar-navigation ul li ul {
  display: none;
}
.sidebar-navigation ul li ul.open {
  display: block;
}
.sidebar-navigation ul li ul li a {
  color: #495d62;
  border-color: rgba(255, 255, 255, 0.1);
}
.sidebar-navigation ul li ul li a:before {
  content: "";
  width: 1px;
  height: 100%;
  margin-right: 5px;
  display: inline-block;
  vertical-align: middle;
  background-color: #6F83AA;
  -webkit-transition: all 0.2s linear;
  -moz-transition: all 0.2s linear;
  -o-transition: all 0.2s linear;
  transition: all 0.2s linear;
}
.sidebar-navigation ul li ul li:hover > a, .sidebar-navigation ul li ul li.selected > a {
  background-color: #e6ebed;
}
.sidebar-navigation ul li ul li:hover > a:before, .sidebar-navigation ul li ul li.selected > a:before {
  margin-right: 10px;
}
.sidebar-navigation ul li ul li.selected.selected--last > a {
  background-color: #94aab0;
  color: #fff;
}
.sidebar-navigation ul li ul li.selected.selected--last > a:before {
  background-color: #fff;
}

.subMenuColor1 {
  background-color: #fbfcfc;
}

.subMenuColor2 {
  background-color: white;
}

.subMenuColor2 {
  background-color: white;
}

.subMenuColor2 {
  background-color: white;
}

.subMenuColor2 {
  background-color: white;
}

.subMenuColor2 {
  background-color: white;
}

.subMenuColor2 {
  background-color: white;
}

.subMenuColor2 {
  background-color: white;
}

.subMenuColor2 {
  background-color: white;
}

.subMenuColor2 {
  background-color: white;
}
	
.menu .main-menu ul li > ul li a{height: 45px}
.menu .main-menu ul li > ul li.active a span{color: #03257D;background: #E6EBF7;}
.menu .main-menu ul li > ul li.active a{background: none;}
.menu .main-menu ul li > ul li a{margin: 0 auto}
.menu .main-menu ul  li > ul li a:focus, .menu .main-menu ul  li > ul li a:hover{background: none;}
.menu .main-menu ul  li > ul li a, .menu .main-menu ul  li > ul li a{padding-left: 26px !important;}
.menu .main-menu ul  li > ul li a span, .menu .main-menu ul  li > ul li a span{height: 34px;width: 100%;display: flex;flex-direction: row;justify-content: start;align-items: center;font-size: 16px;font-style: normal;font-weight: bold;border-bottom: 0px solid #f3f3f3;color: #4F70C4;transition: color .3s;transition: background .3s;padding: 0 0.8em;border-radius: 10px;margin: 0em 0em;}
.menu .main-menu ul  li > ul li a:focus span, .menu .main-menu ul  li > ul li a:hover span{color: #03257D;background: #E6EBF7;}
.icons-credit-card-1 {
    background: url(img/icons/credit-card-1.png) no-repeat;
}
.icons-list {background: url(img/icons/list.png) no-repeat;}
.icons-notify {background: url(img/icons/notify.png) no-repeat;}
.icons-exam {background: url(img/icons/exam.png) no-repeat;}		
		
.navbar .user .name{display: inline-block;vertical-align: middle;text-align: left;overflow: hidden; text-overflow: ellipsis; max-width: 135px; white-space: nowrap;font-size: 14px;font-family: 'Segoe UI';}
.navbar .user .stuid{display: block;font-size: 14px;line-height: 12px;font-family: 'Segoe UI';}
		
.icons-tests {background: url(images/tests.png) no-repeat;}
		
		.dropdown-menu{box-shadow: 0px 0px 15px rgba(0, 0, 0, 0.1);border-radius: 5px;border: none;}
		
/* Notifications */
		
.navbar #notificationDropdown{max-height: 380px;box-shadow: 0px 0px 15px rgba(0, 0, 0, 0.1);border-radius: 5px;border: none;overflow: hidden;}
.icon-bell {background: url(img/icons/bell.png) no-repeat;filter: brightness(0.5);}
.navbar .header-icon#notificationButton .count{font-weight: 600;color: #ffffff;width: 16px; height: 16px;background: #0332AA;top: 5px;right: 8px;line-height: 9px; align-items: center;display: flex;justify-content: center;}
	.icon-notify-s {background: url(img/icons/notify-s.png) no-repeat;width: 11px; height: 11px;display: inline-block;}
	.icon-notify-circle {width: 23px;height: 23px;background: #E6EBF7;border: 1px solid #D3DBEC; border-radius: 100%;justify-content: center;display: flex;align-items: center;}
		
		#notificationDropdown h3{font-weight: bold;font-size: 16px;line-height: 14px;color: #354159;}
		#notificationDropdown h4{font-size: 12px;line-height: 14px;color: #000000;}
		#notificationDropdown .text-small{font-size: 12px;line-height: 20px;font-weight: 600;color: rgba(54, 65, 89, 0.5) !important;}
		#notificationDropdown .link-small{font-size: 12px;line-height: 14px;color: #4265BF;}
		
	</style>
	
	<script>
	
		$(function(){
  var $ul   =   $('.sidebar-navigation > ul');
  
  $ul.find('li a').click(function(e){
    var $li = $(this).parent();
    
    if($li.find('ul').length > 0){
      e.preventDefault();
      
      if($li.hasClass('selected')){
        $li.removeClass('selected').find('li').removeClass('selected');
        $li.find('ul').slideUp(400);
        $li.find('a em').removeClass('minus');
      }else{
        
        if($li.parents('li.selected').length == 0){
          $ul.find('li').removeClass('selected');
          $ul.find('ul').slideUp(400);
          $ul.find('li a em').removeClass('minus');
        }else{
          $li.parent().find('li').removeClass('selected');
          $li.parent().find('> li ul').slideUp(400);
          $li.parent().find('> li a em').removeClass('minus');
        }
        
        $li.addClass('selected');
        $li.find('>ul').slideDown(400);
        $li.find('>a>em').addClass('minus');
      }
    }
  });
  
  
  $('.sidebar-navigation > ul ul').each(function(i){
    if($(this).find('>li>ul').length > 0){
      var paddingLeft = $(this).parent().parent().find('>li>a').css('padding-left');
      var pIntPLeft   = parseInt(paddingLeft);
      var result      = pIntPLeft + 20;
      
      $(this).find('>li>a').css('padding-left',result);
    }else{
      var paddingLeft = $(this).parent().parent().find('>li>a').css('padding-left');
      var pIntPLeft   = parseInt(paddingLeft);
      var result      = pIntPLeft + 20;
      
      $(this).find('>li>a').css('padding-left',result).parent().addClass('selected--last');
    }
  });
  
  var t = ' li > ul ';
  for(var i=1;i<=10;i++){
    $('.sidebar-navigation > ul > ' + t.repeat(i)).addClass('subMenuColor' + i);
  }
  
  var activeLi = $('li.selected');
  if(activeLi.length){
    opener(activeLi);
  }
  
  function opener(li){
    var ul = li.closest('ul');
    if(ul.length){
      
        li.addClass('selected');
        ul.addClass('open');
        li.find('>a>em').addClass('minus');
      
      if(ul.closest('li').length){
        opener(ul.closest('li'));
      }else{
        return false;
      }
      
    }
  }
  
});
		
	</script>

</head>

              
<?php if($this->session->userdata('loggedin') && !isset($roleaccess['Library']) && !isset($roleaccess['Notification']) && !isset($roleaccess['ID Card Batch Print'])){ ?>


<body id="app-container" class="menu-default show-spinner">

<div class="head-top d-flex align-items-center innertop">

<div class="container">

<div class="row">

	<div class="col-md-7 col-sm-6 col-xs-7 head-top-left">
	
		<div class="row">
		
			<div class="col-md-4 text-left"><a href="tel:04822 206100" title="Mobile"><i class="icon-phone"></i> 04822 206100</a> </div>
			<div class="col-md-6 text-left"><a href="mailto:admissions@brilliantpala.org" title="Email"><i class="icon-mail"></i> admissions@brilliantpala.org </a></div>
		</div>
		
	</div>
	
	<div class="col-md-5 col-sm-6 col-xs-5 head-top-right d-flex align-items-center justify-content-end">
		
		<span>Follow us on: </span>
		<a href="https://www.facebook.com/BrilliantStudyCentrePala/" target="_blank" title="Facebook"><i class="icon-facebook"></i></a> 
		<a href="https://twitter.com/BrilliantPala" target="_blank" title="Twitter"><i class="icon-twitter"></i></a> 
		<a href="https://www.youtube.com/BrilliantOnline/" target="_blank" title="Youtube"><i class="icon-youtube"></i></a>
		<a href="https://www.instagram.com/brilliantpala/" target="_blank" title="Instagram"><i class="icon-instagram"></i></a>
		<a href="https://in.pinterest.com/brilliantstudycentrepala/" target="_blank" title="Pinterest"><i class="icon-pinterest"></i></a>
   	
	</div>

</div>

	</div>
	
	</div>
	
<nav class="navbar fixed-top">
 
 <div class="container">
 
  <div class="d-flex align-items-center inner-navleft navbar-left">
   
   <a href="#" class="menu-button d-none">
    <svg class="main" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 9 17">
      <rect x="0.48" y="0.5" width="7" height="1"/>
      <rect x="0.48" y="7.5" width="7" height="1"/>
      <rect x="0.48" y="15.5" width="7" height="1"/>
    </svg>
    <svg class="sub" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 18 17">
      <rect x="1.56" y="0.5" width="16" height="1"/>
      <rect x="1.56" y="7.5" width="16" height="1"/>
      <rect x="1.56" y="15.5" width="16" height="1"/>
    </svg>
    </a>
    <a href="#" class="menu-button-mobile d-xs-block d-sm-block d-md-block">
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 26 17">
      <rect x="0.5" y="0.5" width="25" height="1"/>
      <rect x="0.5" y="7.5" width="25" height="1"/>
      <rect x="0.5" y="15.5" width="25" height="1"/>
    </svg>
    </a>
    </div>
    
  <a class="navbar-logo" href="<?php echo base_url();?>"><span class="logo d-none d-xs-block"></span> <span class="logo-mobile d-block d-xs-none"></span></a>
  
  <!--div class="search">
      <input type="text" placeholder="Search for courses, centers">
      <span class="search-icon"><i class="icon-magnifier"></i></span>
  </div-->
  
  <div class="navbar-right inner-navright">
    <div class="header-icons innertopleft d-inline-block align-middle">
		
    	<div class="position-relative d-sm-inline-block mr-5">
    	
			<div class="d-inline topmenu">
				<!--<a href="<?php echo base_url();?>" title="About us" class="<?=($this->uri->segment(1)==='aboutus')?'active':''?>">About us</a>-->
				<a href="<?php echo base_url();?>stucourses" title="Courses" class="<?=($this->uri->segment(1)==='stucourses')?'active':''?>">Courses</a>
				<!--<a href="<?php echo base_url();?>" title="Centers" class="<?=($this->uri->segment(1)==='centers')?'active':''?>">Centers</a>
				<a href="<?php echo base_url();?>" title="Blog" class="<?=($this->uri->segment(1)==='blog')?'active':''?>">Blog</a>-->
			</div>
   		   	
		</div>
    
    	<!--<div class="position-relative d-sm-inline-block mr-3">
        <button class="header-icon btn btn-empty" type="button" id="iconMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="icons-settings"></i></button>
        <div class="dropdown-menu dropdown-menu-right mt-3 position-absolute" id="iconMenuDropdown"><a href="#" class="icon-menu-item"><i class="iconsminds-equalizer d-block"></i> <span>Settings</span> </a><a href="#" class="icon-menu-item"><i class="iconsminds-male-female d-block"></i> <span>Users</span> </a><a href="#" class="icon-menu-item"><i class="iconsminds-puzzle d-block"></i> <span>Password</span> </a><a href="#" class="icon-menu-item"><i class="iconsminds-bar-chart-4 d-block"></i> <span>Profits</span> </a><a href="#" class="icon-menu-item"><i class="iconsminds-file d-block"></i> <span>Surveys</span> </a><a href="#" class="icon-menu-item"><i class="iconsminds-suitcase d-block"></i> <span>Tasks</span></a></div>
      </div>-->
      
      <div class="position-relative d-sm-inline-block mr-3">
        <button class="header-icon btn btn-empty" type="button" id="notificationButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="icon-bell"></i> <?php if($user['notifycount']>0){ ?><span class="count"><?php echo $user['notifycount'];?></span><?php }?></button>
        <div class="dropdown-menu dropdown-menu-right mt-3 position-absolute" id="notificationDropdown" <?php  if(empty($user['newmsg']) && empty($user['oldmsg'])){ echo 'style="height:auto;"'; }?>>
         
			<h3 class="mb-4">Notifications</h3>
         
          <div class="scroll">
           
           
           <?php  if(!empty($user['newmsg'])){ ?>
           
			  <div class="row">
				  <div class="col-6"><h4 class="d-flex flex-row mt-2 pb-2">New</h4></div>
				  <div class="col-6 text-right"><a href="stunotificationcenter" title="See All" class="link-small">See All</a></div>
			  </div>
          
          	<?php 
											  
					foreach($user['newmsg'] as $key=>$newmsg){
						
						if((count($user['oldmsg'])==0 && $key < 4) || (count($user['oldmsg'])>0 && $key < 2) ) {
			  
			  ?>
           
           
			   <div class="d-flex flex-row align-items-end mb-3 pb-2">
					<div class="icon-notify-circle"><i class="icon-notify-s"></i></div>
				  <div class="pl-3"><a href="#">
					<p class="text-muted mb-0 text-small"><?php echo date("d M Y",strtotime($newmsg['created_at'])); ?></p>
					<p class="font-weight-medium mb-1"><?php echo substr($newmsg['message'],0,30); ?></p>
					</a></div>
				</div>
            
            <?php }}?>
            
           <!-- <div class="d-flex flex-row align-items-end mb-3 pb-2">
				<div class="icon-notify-circle"><i class="icon-notify-s"></i></div>
              <div class="pl-3"><a href="#">
               	<p class="text-muted mb-0 text-small">15 Sep 2021</p>
                <p class="font-weight-medium mb-1">Model Test Held On Mid </p>
                </a></div>
            </div>-->
            
            
            <?php } ?>
            
            <?php  if(!empty($user['oldmsg'])){ ?>
            
             <div class="row">
				  <div class="col-6"><h4 class="d-flex flex-row mb-2 pb-2">Earlier</h4></div>
				   <?php  if(empty($user['newmsg'])){ ?>
				   	<div class="col-6 text-right"><a href="stunotificationcenter" title="See All" class="link-small">See All</a></div> 
				   <?php }?>
			  </div>
			              
            <?php foreach($user['oldmsg'] as $key1=>$oldmsg){
			  
			  if((count($user['newmsg'])==0 && $key1 < 4) || (count($user['newmsg'])>0 && $key1 < 2) ) {
			  
			  ?>
          
           
           <div class="d-flex flex-row align-items-end mb-3 pb-2">
				<div class="icon-notify-circle"><i class="icon-notify-s"></i></div>
              <div class="pl-3"><a href="#">
                <p class="text-muted mb-0 text-small"><?php echo date("d M Y",strtotime($oldmsg['created_at'])); ?></p>
                <p class="font-weight-medium mb-1"><?php echo substr($oldmsg['message'],0,30); ?></p>
                </a></div>
            </div>
            
           <?php }}?>
      
            
            <?php } ?>
            
            <?php  if(empty($user['newmsg']) && empty($user['oldmsg'])){ ?>
            
            	<div class="d-inline flex-row align-items-end mb-3 pb-2">
					<div class="pl-3">
						<p class="text-muted mb-0 text-small text-center">No Messages</p>
					</div>
            	</div>
            	
            <?php  } ?>
            
          </div>
        </div>
      </div>
     
    </div>
        
    <div class="user d-inline-block">
		  <button class="btn btn-empty p-0" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"	
		  	  <span><img alt="Profile Picture" src="<?php if($user['profilepic']!="0" && $user['profilepic']!=""){ echo "docs/profilepic/".$user['id']."/".$user['profilepic']."?".time();}else{echo "img/profilepic.png?".time();} ?>"></span>
		  	  <span class="name" title="<?php echo ucwords($user['pname']); ?>"><?php echo ucwords($user['pname']); ?> <span class="stuid">Student ID: <?php echo $user['stuid']; ?></span></span>  
      	 </button>
		  <div class="dropdown-menu dropdown-menu-right mt-3">
		  	<a class="dropdown-item" href="<?php echo base_url();?>stumyprofile">My Profile</a>
			<a class="dropdown-item" href="<?php echo base_url();?>logout">Log out</a>
		  </div>
    </div>
        
  </div>
</nav>

	<style>
	
		.menu .main-menu.default-transition{overflow-y: auto;height: calc(100% - 125px);}
		.menu .main-menu ul li a{margin: 1em 0.2em;}
		
		@media (max-width: 1100px){
			.menu .main-menu ul li a{font-size: 15px}
			.menu .main-menu ul li > ul li a span, .menu .main-menu ul li > ul li a span{font-size: 14px;}
		}
		
		@media (min-width:1422px){
			.menu .main-menu ul li a{font-size: 15px}
			.menu .main-menu ul li > ul li a span, .menu .main-menu ul li > ul li a span{font-size: 14px;}
		}
		
	</style>

<div class="menu">
  <div class="main-menu">
    <div class="scroll ps ps--active-y">
    
     <div class="sidebar-navigation">
     
  	 <ul>
        <li class="<?=($this->uri->segment(1)==='stumyprofile')?'active':''?>"><a href="<?php echo base_url();?>stumyprofile" title="My Profile"><i class="icons-user"></i> <span>My Profile</span></a></li>
	  	<li><a href="#"><i class="icons-bookmark"></i> <span>My Courses</span> <em class="mdi mdi-chevron-down"></em></a>
          <ul>
			  <li class="<?=($this->uri->segment(1)==='stucourses')?'active':''?>"><a href="<?php echo base_url();?>stucourses" title="Patients List"><span>Available Courses</span></a></li>
			  <li class="<?=($this->uri->segment(1)==='stuqualifyupdate')?'active':''?>"><a href="<?php echo base_url();?>stuqualifyupdate"><span>Update Qualification</span></a></li>
			  <li class="<?=($this->uri->segment(1)==='sturegcourses')?'active':''?>"><a href="<?php echo base_url();?>sturegcourses"><span>Applied Status</span></a></li>
			</ul>
	  	</li>
     
     	<li><a href="#"><i class="icons-tests"></i> <span>Screening Test</span> <em class="mdi mdi-chevron-down"></em></a>
          <ul>
			  <li class="<?=($this->uri->segment(1)==='updatequalification')?'active':''?>"><a href="<?php echo base_url();?>updatequalification?type=test" title="Apply"><span>Apply</span></a></li>
			  <li class="<?=($this->uri->segment(1)==='sturegtests')?'active':''?>"><a href="<?php echo base_url();?>sturegtests" title="Registered Test"><span>Registered Test</span></a></li>
			  <li class="<?=($this->uri->segment(1)==='stuhallticket')?'active':''?>"><a href="<?php echo base_url();?>stuhallticket" title="Hall Ticket"><span>Hall Ticket</span></a></li>
			</ul>
	  	</li>
     
      <!-- <li><a href="#"><i class="icons-bookmark"></i> <span>My Course Fee</span> <em class="mdi mdi-chevron-down"></em></a>
          <ul>
			  <li class="<?=($this->uri->segment(1)==='coursefee')?'active':''?>"><a href="#" title="Course Fee"><span>Course Fee</span></a></li>
			  <li class="<?=($this->uri->segment(1)==='remitted')?'active':''?>"><a href="#" title="Remitted"><span>Remitted</span></a></li>
			  <li class="<?=($this->uri->segment(1)==='due')?'active':''?>"><a href="#" title="Due"><span>Due</span></a></li>
			  <li class="<?=($this->uri->segment(1)==='discount')?'active':''?>"><a href="#" title="Discount"><span>Discount</span></a></li>
			  <li class="<?=($this->uri->segment(1)==='scholarship')?'active':''?>"><a href="#" title="Scholarship"><span>Scholarship</span></a></li>
			  <li class="<?=($this->uri->segment(1)==='refund')?'active':''?>"><a href="#" title="Refund"><span>Refund</span></a></li>
			</ul>
	  	</li>-->
       <li class="<?=($this->uri->segment(1)==='updatequalification')?'active':''?>"><a href="<?php echo base_url();?>updatequalification"><i class="icons-bookmark"></i> <span>New Courses</span></a></li>
        <li class="<?=($this->uri->segment(1)==='stuexam')?'active':''?>"><a href="<?php echo base_url();?>stuexam"><i class="icons-exam"></i> <span>Event Master</span></a></li>
        <li class="<?=($this->uri->segment(1)==='stufeepayments')?'active':''?>"><a href="<?php echo base_url();?>stufeepayments"><i class="icons-credit-card-1"></i> <span>Fee and Payments</span></a></li>
        <li class="<?=($this->uri->segment(1)==='sturefund')?'active':''?>"><a href="<?php echo base_url();?>sturefund"><i class="icons-credit-card-1"></i> <span>Refund Status</span></a></li>
        <li class="<?=($this->uri->segment(1)==='sturesults')?'active':''?>"><a href="<?php echo base_url();?>sturesults"><i class="icons-list"></i> <span>Results</span></a></li>
        <li class="<?=($this->uri->segment(1)==='stunotificationcenter')?'active':''?>"><a href="<?php echo base_url();?>stunotificationcenter"><i class="icons-notify"></i> <span>Notification Centre</span></a></li>
        <!--<li><a href="<?php echo base_url();?>"><i class="icons-pie-chart"></i> <span>LMS</span></a></li>
        <li><a href="<?php echo base_url();?>"><i class="icons-file-text"></i> <span>Assessments</span></a></li>-->
        <li><a href="<?php echo base_url();?>logout" class="last"><i class="icons-power"></i> <span>Logout</span></a></li>
        
  </ul>
</div>
      <!--<ul class="list-unstyled">
       
       <?php //if($this->session->userdata('logged_in') || $this->session->userdata('adlog_in')){ ?>
       
        <li class="<?=($this->uri->segment(1)==='dashboard')?'active':''?>"><a href="<?php echo base_url();?>" title="Dashboard"><i class="icons-dashboard"></i> <span>Dashboard</span></a></li>
        <li class="<?=($this->uri->segment(1)==='myprofile')?'active':''?>"><a href="<?php echo base_url();?>stumyprofile" title="My Profile"><i class="icons-user"></i> <span>My Profile</span></a></li>
        <li class="<?=($this->uri->segment(1)==='eligiblecourses')?'active':''?>"><a href="<?php echo base_url();?>stucourses" title="Patients List"><i class="icons-thumbs-up"></i> <span>Eligible Courses</span></a></li>
        <li class="<?=($this->uri->segment(1)==='sturegcourses')?'active':''?>"><a href="<?php echo base_url();?>sturegcourses"><i class="icons-bookmark"></i> <span>Registered Courses</span></a></li>
        <li class="<?=($this->uri->segment(1)==='stuqualifyupdate')?'active':''?>"><a href="<?php echo base_url();?>stuqualifyupdate"><i class="icons-bookmark"></i> <span>Qualification Update</span></a></li>-->
        <!--<li><a href="<?php echo base_url();?>"><i class="icons-pie-chart"></i> <span>LMS</span></a></li>
        <li><a href="<?php echo base_url();?>"><i class="icons-file-text"></i> <span>Assessments</span></a></li>-->
        <!--<li><a href="<?php echo base_url();?>logout" class="last"><i class="icons-power"></i> <span>Logout</span></a></li>
                
      </ul>-->
    </div>
  </div>
  <!--<div class="sub-menu">
    <div class="scroll">
      
       <ul class="list-unstyled" data-link="staffs">
        <li><a href="<?php echo base_url();?>staff"><i class="simple-icon-user"></i> <span class="d-inline-block">Add Staff</span></a></li>
        <li><a href="<?php echo base_url();?>staffview"><i class="simple-icon-eye"></i> <span class="d-inline-block">View Staffs</span></a></li>
      </ul>
      
      <ul class="list-unstyled" data-link="survey">
        <li><a href="<?php echo base_url();?>survey"><i class="simple-icon-user"></i> <span class="d-inline-block">Add Survey</span></a></li>
        <li><a href="<?php echo base_url();?>surveyview"><i class="simple-icon-eye"></i> <span class="d-inline-block">View Survey</span></a></li>
      </ul>
     
    </div>
  </div>-->
</div>

</div>

<?php }else if(isset($roleaccess['Library']) || isset($roleaccess['Notification']) || isset($roleaccess['ID Card Batch Print'])) { ?>

<style>

	.menu .main-menu.default-transition{overflow-y: auto;height: calc(100% - 100px);}
	
	.icons-students {background: url(images/students.png) no-repeat;}
	.icons-admissions {background: url(images/courses.png) no-repeat;}
	.icons-accounts {background: url(images/payments.png) no-repeat;}
	.icons-tests {background: url(images/tests.png) no-repeat;}	
	.icons-list {background: url(img/icons/list.png) no-repeat;}	
	.icons-review {background: url(images/review.png) no-repeat;}	
	i.icons-settings {background: url(img/icons/settings.png) no-repeat;}	
	i.icons-logout {background: url(images/logout.png) no-repeat;}
	
	.fixed-top{top: 0px;}
	.menu{padding-top: 90px;}
	.navbar .user .name{max-width: 200px;}
	.navbar .user .stuid{line-height: 20px}
</style>

<body id="app-container" class="menu-default show-spinner">
	
<nav class="navbar fixed-top">
 
 <div class="container">
 
    
  <a class="navbar-logo" href="<?php echo base_url();?>"><span class="logo d-none d-xs-block"></span> <span class="logo-mobile d-block d-xs-none"></span></a>
  
  
  <div class="navbar-right inner-navright">

        
    <div class="user d-inline-block">
		  <button class="btn btn-empty p-0" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"	
		  	  <span><img alt="Profile Picture" src="<?php if($user['profilepic']!="0" && $user['profilepic']!=""){ echo "docs/profilepic/".$user['id']."/".$user['profilepic']."?".time();}else{echo "img/profilepic.png?".time();} ?>"></span>
		  	  <span class="name" title="<?php echo ucwords($user['pname']); ?>"><?php echo ucwords($user['pname']); ?> <span class="stuid"><?php echo $user['name']; ?></span></span>  
      	 </button>
		  <div class="dropdown-menu dropdown-menu-right mt-3">
		  	<!--<a class="dropdown-item" href="<?php echo base_url();?>stumyprofile">My Profile</a>-->
			<a class="dropdown-item" href="<?php echo base_url();?>logout">Log out</a>
		  </div>
    </div>
        
  </div>
</nav>
<div class="menu">
  <div class="main-menu">
    <div class="scroll ps ps--active-y">
    
     <div class="sidebar-navigation">
     
  	 <ul>
       
        <?php echo $menu; ?>
        
  </ul>
  
</div>
     
    </div>
  </div>

</div>

</div>



<?php }else{ ?>    
         
<body class="background show-spinner no-footer ltr rounded">
<div class="fixed-background"></div>

<div class="head-top d-flex align-items-center">

<div class="container">

<div class="row">

	<div class="col-md-7 col-sm-6 col-xs-7 head-top-left">
	
		<div class="row">
		
			<div class="col-md-4 text-left"><a href="tel:04822 206100" title="Mobile"><i class="icon-phone"></i> 04822 206100</a> </div>
			<div class="col-md-6 text-left"><a href="mailto:admissions@brilliantpala.org" title="Email"><i class="icon-mail"></i> admissions@brilliantpala.org </a></div>
		</div>
		
	</div>
	
	<div class="col-md-5 col-sm-6 col-xs-5 head-top-right d-flex align-items-center justify-content-end">
		
		<span>Follow us on: </span>
	<a href="https://www.facebook.com/BrilliantStudyCentrePala/" target="_blank" title="Facebook"><i class="icon-facebook"></i></a> 
  	<a href="https://twitter.com/BrilliantPala" target="_blank" title="Twitter"><i class="icon-twitter"></i></a> 
  	<a href="https://www.youtube.com/BrilliantOnline/" target="_blank" title="Youtube"><i class="icon-youtube"></i></a> 
  	<a href="https://www.instagram.com/brilliantpala/" target="_blank" title="Instagram"><i class="icon-instagram"></i></a>
	<a href="https://in.pinterest.com/brilliantstudycentrepala/" target="_blank" title="Pinterest"><i class="icon-pinterest"></i></a>
  	<!--<a href="#" title="Linkedin"><i class="icon-linkedin"></i></a>-->
   	
	</div>

</div>

	</div>
	
	</div>

<nav class="navbar fixed-top">
   
   <div class="container">
   
    <!--<div class="d-flex align-items-center navbar-left">
    <a href="#" class="menu-button d-none d-md-block">
    <svg class="main" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 9 17">
      <rect x="0.48" y="0.5" width="7" height="1"/>
      <rect x="0.48" y="7.5" width="7" height="1"/>
      <rect x="0.48" y="15.5" width="7" height="1"/>
    </svg>
    <svg class="sub" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 18 17">
      <rect x="1.56" y="0.5" width="16" height="1"/>
      <rect x="1.56" y="7.5" width="16" height="1"/>
      <rect x="1.56" y="15.5" width="16" height="1"/>
    </svg>
    </a><a href="#" class="menu-button-mobile d-xs-block d-sm-block d-md-none">
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 26 17">
      <rect x="0.5" y="0.5" width="25" height="1"/>
      <rect x="0.5" y="7.5" width="25" height="1"/>
      <rect x="0.5" y="15.5" width="25" height="1"/>
    </svg>
    </a>
      
    </div>-->

  <a class="navbar-logo" href="<?php echo base_url();?>" title="Brilliant Study Centre, Pala"><span class="logo d-none d-xs-block"></span> <span class="logo-mobile d-block d-xs-none"></span></a>
  
  <!--<div class="search">
      <input type="text" placeholder="Search for courses, centers">
      <span class="search-icon"><i class="icon-magnifier"></i></span>
  </div>-->
  
  <div class="navbar-right outer-navright">
    <div class="header-icons align-middle">
    	
    	<div class="row d-flex align-items-center">
    	
    	<div class="d-inline topmenu col-sm-7 d-flex topleftbtn justify-content-start">
		<a href="https://brilliantpala.org/about-us/" target="_blank" title="About us">About us</a>
   		<a href="https://brilliantpala.org/all-courses/" target="_blank" title="Courses">Courses</a>
   		<a href="https://brilliantpala.org/results/" target="_blank" title="Results">Results</a>
   		<a href="https://brilliantpala.org/our-campuses-and-satellite-centres/" target="_blank" title="Centers">Centers</a>
		</div>
   		
   		<div class="d-inline col-sm-5 d-flex toprightbtn justify-content-end">
   		
			<a href="<?php echo base_url();?>login" title="Login" class="mr-4"><button type="button" class="btn btn-primary mb-1" <?=($this->uri->segment(1)==='login' || $this->uri->segment(1)=='')?'disabled':''?>>Login</button></a>
			<a href="<?php echo base_url();?>signup" title="Sign up"><button type="button" class="btn btn-primary mb-1" <?=($this->uri->segment(1)==='signup')?'disabled':''?>>Sign up</button></a>
		
		</div>
   	
		</div>
    	
    </div>
  </div>
  
	</div>
	
</nav>

<!--<div class="menu">
  <div class="main-menu">
    <div class="scroll">
      <ul class="list-unstyled">
              
        <li><a href="<?php echo base_url();?>"><i class="icons-dashboard"></i> <span></span></a></li>
                                  
      </ul>
    </div>
  </div>
</div>  -->                    
                               
<?php }?>
                                
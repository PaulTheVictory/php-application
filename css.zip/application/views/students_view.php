<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/dataTables.css?v=1.6" />
<script src="<?php echo base_url(); ?>js/jquery.dataTables.js?v=1.0" type="text/javascript"></script>
<link rel="stylesheet" href="<?php echo base_url();?>css/boot/bootstrap.min.css">
<link rel="stylesheet" href="<?php echo base_url();?>css/boot/main.css?v=1">
<script src="<?php echo base_url();?>js/bootstrap.bundle.min.js"></script>
<link href="<?php  echo base_url(); ?>css/jquery-ui.min.css?v=1.4" rel="stylesheet" type="text/css" />
<script src="<?php  echo base_url(); ?>js/jquery-ui.min.js?v=1.3" type="text/javascript"></script>
<style type="text/css">


.dataTables_wrapper input[type="text"] {
    padding: 0;
}
.dataTables_wrapper select {
    padding: 0;
}

.sortable thead tr  {
    background: #E6EBF7;

/* g8 */
border: 1px solid #D7DFF0;
box-sizing: border-box;
border-radius: 10px 10px 0px 0px;
 

}
.sortable tr th {
    border-right: 0px;
    padding: 15px 0;font-size: 13px;
      color: #6F83AA;
   cursor: pointer;
   text-align: center;

}

.sortable tr th:nth-child(1) {
  background: #E6EBF7 url('<?php echo base_url(); ?>/images/datatable/sort_both.png') no-repeat center left;
  background-position-x: 90px;
  background-position-y: 16px;
   text-align: left;padding-left: 10px;
}

.sortable tr th:nth-child(2) {
  background: #E6EBF7 url('<?php echo base_url(); ?>/images/datatable/sort_both.png') no-repeat center left;
  background-position-x: 110px;
  background-position-y: 16px;
   text-align: left;
}

.sortable tr td:nth-child(3) {
  
   text-align: left;
}


.sortable tr td:nth-child(5) {
  
   text-align: left;
}



.sortable tr td {
    border-right: 0px;
    padding: 5px;
    text-align: center;font-size: 13px;
    min-width:100px;vertical-align: middle;
}
.sortable tr td a {
    color: #364159;
}

#profile-right h2 {
    margin: 0px 0px 10px 0px;
}
.sortable tr td:nth-child(1) {

   text-align: left;padding-left: 10px;
}
.studenttable_length { width: auto !important; }
#studenttable_filter input { padding-top:4px;background: #fff url('<?php echo base_url(); ?>/images/search.png') no-repeat center left;background-position-x: 10px;border: 1px solid #D7DFF0; line-height: 32px;margin-left: 10px;width:260px;border-radius: 5px;text-indent: 30px;font-size: 13px;}
.sortable tr td a:hover { text-decoration: underline; }
	
.btn-outline-primary {color: #0332AA;border-color: #0332AA;}
.btn {border-radius: 5px;outline: initial!important;box-shadow: none!important;box-shadow: initial!important;font-size: .8rem;padding: .5rem 1.25rem .5rem 1.25rem;transition: background-color box-shadow .1s linear;margin-bottom: 7px}
.btn-outline-primary:not(:disabled):not(.disabled).active, .btn-outline-primary:not(:disabled):not(.disabled):active, .show>.btn-outline-primary.dropdown-toggle,.btn-outline-primary:hover {background-color: #0332AA;border-color: #0332AA;color: #fff;}	
	
.ui-selectmenu-button.ui-button{ width: 125px;margin-top: 10px;float: right;border: 1px solid #D7DFF0;background: #fff;font-size: 13px;color:#536485;padding: 8px;margin-bottom: 4px;}
.ui-menu-item .ui-menu-item-wrapper{font-size: 13px}
	
</style>
<script type="text/javascript">
$(document).ready(function(){	
		
	
	$("#searchtype").selectmenu();
	
	$(document).on("click",".clear",function(){
		
		$("#searchtype").selectmenu('destroy');
	    $("#searchtype").prop('selectedIndex',0);
	    $("#searchtype").selectmenu();
		
	});
	
          var columnData = [
              
                    { "data": "studid" },                    
                    { "data": "sname" },
                    { "data": "email" },
                    { "data": "contact"},       
                    { "data": "city" , "searchable": false},
                    { "data": "id" , "searchable": false}
                    
                  ];
        // columnData.push( {data: "id","visible":true} );
         //columnData.push( {data: "item_name_search","visible":false} );
         
       
        var oTable = $('#studenttable').dataTable({
                    "bProcessing": true,
                    "bServerSide": true,
                    "sPaginationType": "full_numbers",
                    "ajax": {
                    "url": 'students/allstudentsList',
                    "type": "POST",
					"data":function(data){ 
						
						var searchtype = $("#searchtype").val();
						data.searchcol= searchtype;
						
						}
                     }, 
                     "oLanguage": {
                        "sProcessing": "<img src='<?php echo base_url(); ?>images/loader.gif'>"
                    },
                    'iDisplayLength': 20,
                    "columns": columnData,
                    "order": [[ 0, "desc" ]],
                    "fnDrawCallback": function( oSettings ) {
                           
                        $("#studenttable").find(".idValue").each(function(){
                            var t = $(this).text();
                            var res = t.toUpperCase(); $(this).text(res);
                        });
                  
                         $("#studenttable").find(".del").each(function(){

                            $(this).click(function(){ 

                              if(confirm("Are you sure to delete this student details ?")) {
                                    var ide = $(this).attr("id");
                                    $.get('students/DelStudent',{
                                                               'ide':ide

                                                    }, function(o) { 
                                                            var obj1 = $.parseJSON(o);
                                                    if (obj1[0] === 'success') {
                                                        oTable.fnDraw(); 
                                                    } else if (obj1[0] === 'fail') {
                                                        alert("Error!!! please try again");
                                                }
                                    });
                                }

                              });
                        

                          });
                            
                    },
				"initComplete" : function() {
						
						var input = $('.dataTables_filter input').unbind(),
							self = this.api(),
							$searchButton = $('<button class="btn btn-outline-primary ml-3 search">')
									   .text('search')
									   .click(function() {
										  self.search(input.val()).draw();
									   }),
							$clearButton = $('<button class="btn btn-outline-primary ml-3 clear">')
									   .text('clear')
									   .click(function() {
										  input.val('');
										  $searchButton.click(); 
									   }) 
						$('.dataTables_filter').append($searchButton, $clearButton);
                                                
                                                 $(input).keyup(function(event){
                                                    if(event.keyCode == 13){
                                                        event.preventDefault();
                                                        $('.search').trigger('click');
                                                    }
                                                });
					}
         }); 
         
         
         
  
	
});
</script>


<div class="wrap dynamic-width" style="float: left;position: relative">
    
    <div style="margin-top: 10px; width: 100%; height: 50px; text-align: right;">
             <span style="font-weight: bold;font-size: 20px;padding: 10px;float:left;color: #364159">Students List</span>
             
             <div class="row align-items-center">
                 <div class="col-5" style="position: relative;top: -8px">
                     <select id="searchtype">
                         <option value="stuid">Student ID</option>
                         <option value="stuname">Student Name</option>
                         <option value="email">Email</option>
                         <option value="contact">Contact</option>
                         <option value="qname">Qualification</option>
                     </select>
                 </div>                                                                           
    		</div> 
            
             <?php if($user['role'] === 'admin') { ?>
             <a style="font-size: 14px;padding: 10px;  color: #fff; margin: 0px auto; position: relative; top: -45px;border-radius:5px;background: linear-gradient(180deg, #4F70C4 0%, #1C47B3 100%);" href="<?php echo base_url(); ?>addstudent"><span style="position: relative;top:4px"><img  src="<?php echo $this->config->item('web_url') ?>images/addcourse.png" alt="Navigation" style="vertical-align: inherit" /></span><span style="margin-left:5px">Add Student</span></a>
             <?php }?>
         </div>         
         <?php echo $this->table->generate();  ?>             
         
        
        
        </div>
    
 
    


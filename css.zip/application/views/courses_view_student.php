<link rel="stylesheet" href="<?php echo base_url();?>css/boot/vendor/dataTables.bootstrap4.min.css">
<link rel="stylesheet" href="<?php echo base_url();?>css/boot/vendor/datatables.responsive.bootstrap4.min.css">
<script src="<?php echo base_url();?>js/vendor/datatables.min.js"></script>

<script type="text/javascript">
$(document).ready(function(){
	
	$(".coursetype .card").click(function(){
		
		$(".coursetype .card").removeClass('active');
		
		$(this).addClass('active');
		
	});

	
});
</script>

<style>

	.coursetype .card{box-shadow: 0px 0px 7px rgba(196, 196, 196, 0.35);background: linear-gradient(0deg, #FFFFFF, #FFFFFF), #C4C4C4;cursor: pointer;border: 2px solid transparent;transition: all ease 0.3s}
	.rounded .coursetype .card{border-radius: 10px}
	.coursetype .card.active{border: 2px solid #0332AA;}
	.coursetype .card p {color: #889DC6;font-size: 14px;transition: all ease 0.3s}
	.coursetype .card img{filter: opacity(0.4);transition: all ease 0.3s}
	
	.coursetype .card.active p{color: #0332AA;}
	.coursetype .card.active img{filter: opacity(1);}
	
	.coursetop p{color: #6F83AA}
	
	.courselist .course-col-2{background: linear-gradient(0deg, #FFFFFF, #FFFFFF), #C4C4C4;box-shadow: 0px 0px 7px rgba(196, 196, 196, 0.35);border-radius: 10px;}
	.coursecontent{min-height: 300px;}
	.courselist h2{color: #0332AA;font-size: 24px;font-weight: bold;line-height: 36px;}
	.courselist p.list-item-heading,.coursecontent .row div:first-child p{color: #6884CC;font-weight: 600;}
	
	.border-right{border-right: 1px solid #D7DFF0!important;}
	
	.btn-primary{width: auto}
	
</style>

<main>
  <div class="container-fluid">
    <div class="row">
      <div class="col-12">
        <h1>Search Course</h1>
        
           <div class="mb-4"></div>
           
           <h6 class="mb-4"><strong>Select Course Type</strong></h6>
        
			<div class="row coursetype">
				<div class="col-md-6 col-sm-6 col-lg-4 col-12 mb-4">
					<div class="card active" data-type="room">
						<div class="card-body">
							<div class="text-center">
								<img alt="Profile" src="<?php echo base_url();?>img/icons/room.png" class="img-thumbnail border-0 mb-3">
								<p class="list-item-heading mb-1">Class Room</p>
							</div>
						</div>
					</div>
				</div>
				<div class="col-md-6 col-sm-6 col-lg-4 col-12 mb-4">
					<div class="card" data-type="online">
						<div class="card-body">
							<div class="text-center">
								<img alt="Profile" src="<?php echo base_url();?>img/icons/online.png" class="img-thumbnail border-0 mb-3">
								<p class="list-item-heading mb-1">Online Class</p>
							</div>
						</div>
					</div>
				</div>
				<div class="col-md-6 col-sm-6 col-lg-4 col-12 mb-4">
					<div class="card" data-type="test">
						<div class="card-body">
							<div class="text-center">
								<img alt="Profile" src="<?php echo base_url();?>img/icons/series.png" class="img-thumbnail border-0 mb-3">
								<p class="list-item-heading mb-1">Test Series</p>
							</div>
						</div>
					</div>
				</div>
			</div>
              
              <h6 class="mb-4"><strong>Select Stream</strong></h6>
              
              <div class="row stream">
                         
				<div class="col-md-6 col-sm-6 col-lg-2 col-12 mb-4">
					
					 <div class="custom-control custom-radio col-sm-3">
						<input type="radio" id="stream1" name="stream" class="custom-control-input" value="medical" >
						<label class="custom-control-label" for="stream1">Medical</label>
					  </div>
					
				</div>
                         
				<div class="col-md-6 col-sm-6 col-lg-2 col-12 mb-4">
					
					 <div class="custom-control custom-radio col-sm-3">
						<input type="radio" id="stream2" name="stream" class="custom-control-input" value="engineering" >
						<label class="custom-control-label" for="stream2">Engineering</label>
					  </div>
					
				</div>
                         
				<div class="col-md-6 col-sm-6 col-lg-2 col-12 mb-4">
					
					 <div class="custom-control custom-radio col-sm-3">
						<input type="radio" id="stream3" name="stream" class="custom-control-input" value="foundations" >
						<label class="custom-control-label" for="stream3">Foundations</label>
					  </div>
					
				</div>
             
		  	</div>
              
              
              <h6 class="mb-4"><strong>Select Class & Location</strong></h6>
              
              
               <div class="row stream">
                         
				<div class="col-md-6 col-sm-6 col-lg-3 col-12 mb-4">
					
					 <div class="form-group">
						<select class="form-control classstudy" name="classstudy">
						  <option value="">Class Studying</option>
						  <option value="Studying">Studying</option>
						</select>
				     </div>
					
				</div>
                         
				<div class="col-md-6 col-sm-6 col-lg-3 col-12 mb-4">
					
					 <div class="form-group">
						<select class="form-control State" name="State" >
						  <option value="">State</option>
						  <option value="State1">State1</option>
						</select>
				     </div>
					
				</div>
                         
				<div class="col-md-6 col-sm-6 col-lg-3 col-12 mb-4">
					
					 <div class="form-group">
						<select class="form-control Center" name="Center">
						  <option value="">Center</option>
						  <option value="Center">Center</option>
						</select>
				     </div>
					
				</div>
                         
				<div class="col-md-6 col-sm-6 col-lg-2 col-12 mb-4">
					
					<button class="btn btn-primary">Apply</button>
					
				</div>
             
		  	</div>
              
              
              <div class="separator mb-4"></div>
               
        </div>
        
      </div>
      
      
       
	  <div class="row coursetop mb-3">
	  	
		  <div class="col-md-6">
			  <p class="list-item-heading"><?php echo count($courses);?> Courses available</p>
		  </div>
		  
		  <div class="col-md-6 text-right">
		  	<p class="list-item-heading">Page 1 of 1</p>
		  </div>
	  	
	  	
	  </div>
       
       
        <div class="row courselist mb-3">
	  	
            <?php
            
            for($i = 0 ; $i < count($courses);$i++){
                $timestamp = strtotime($courses[$i]['starts_on']);
                $timestamp1 = strtotime($courses[$i]['ends_on']);
                $csch = explode("|",$courses[$i]['cschedule']);$regular = '';$hydrid = '';
                
                if(($csch[0] === '1') || ($sch[2] === '1')) { $regular = '<p class="mb-0">Regular Batch-Monday to Saturday</p>';}
                if(($csch[1] === '1') || ($sch[2] === '1')) { $hydrid = '<p>Hybrid Batch-All Saturday/Sunday & selected vacations*</p>';}
                
                echo '<div class="col-md-6 d-flex">
		  
			  <div class="course-col-2 p-4">
			  	
				  <h2 class="mb-4">'. $courses[$i]['coursename'].'</h2>
		  	
		  			<div class="separator mb-3"></div>
		  			
				  <div class="row">
				  	
					  <div class="col-md-4 text-center border-right">
					  	<img alt="Profile" src="'. base_url().'img/icons/clock.png" class="img-thumbnail border-0 mb-2">
					  	<p class="list-item-heading mb-1">Duration</p>
					  	<p class="mb-4 text-muted">'. $courses[$i]['duration'].'</p>
					  </div>
					  
					  <div class="col-md-4 text-center border-right">
					  	<img alt="Profile" src="'. base_url().'img/icons/invoice.png" class="img-thumbnail border-0 mb-2">
					  	<p class="list-item-heading mb-1">Admission Time</p>
					  	<p class="mb-4 text-muted">'. date('M Y',$timestamp).' - '. date('M Y',$timestamp1).'</p>
					  </div>
					  
					  <div class="col-md-4 text-center">
					  	<img alt="Profile" src="'. base_url().'img/icons/refresh-cw.png" class="img-thumbnail border-0 mb-2">
					  	<p class="list-item-heading mb-1">Commences</p>
					  	<p class="mb-4 text-muted">'. $courses[$i]['commenceson'].'</p>
					  </div>
				  	
				  </div>
		  			
		  			<div class="separator mt-3 mb-4"></div>
		  			
		  			<div class="coursecontent">
		  			
				  <div class="row">
				  	
					  <div class="col-md-4">
						  <p>Qualification :</p>
					  </div>
					  
					   <div class="col-md-8">
						   <p>'. $courses[$i]['qname'].'</p>
					   </div>
				  	
				  </div>
				  
				 
				  
				  <div class="row">
				  	
					  <div class="col-md-4">
						  <p>Class Schedule:</p>
					  </div>
					  
					   <div class="col-md-8">'.$regular.$hydrid.'</div>
				  	
				  </div>
				  
				  <div class="row">
				  	
					  <div class="col-md-4">
						  <p>Center :</p>
					  </div>
					  
					   <div class="col-md-8">
						   <p>'.  str_replace("|", ',', $courses[$i]['centers']).'</p>
					   </div>
				  	
				  </div>
				  
				  </div>
				  
				  
				  <div class="mb-5"></div>
				  
				  
				  <div class="row">
				  	
					  <div class="col-md-6">
						  <button class="btn btn-outline-primary"><a href="'. base_url().'coursedetails?id='. $courses[$i]['ide'].'">Read More</a></button>
					  </div>
					  
					   <div class="col-md-6 text-right">
						  <button class="btn btn-primary w-5">Register Now</button>
					   </div>
				  	
				  </div>
			  	
			  </div>
			  
		  </div>';
                
            }
            
            
            
            
            ?>
		  
	</div>
        
    
  </div>
</main>
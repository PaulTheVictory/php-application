<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/dataTables.css?v=1.5" />
<script src="<?php echo base_url(); ?>js/jquery.dataTables.js?v=1.0" type="text/javascript"></script>
 <link href="<?php  echo base_url(); ?>css/jquery-ui.min.css?v=1.4" rel="stylesheet" type="text/css" />
 <script src="<?php  echo base_url(); ?>js/jquery-ui.min.js?v=1.3" type="text/javascript"></script>


<style type="text/css">


.dataTables_wrapper input[type="text"] {text-indent: 5px;}
.dataTables_wrapper select {
    padding: 0;
}

.sortable thead tr  {
    background: #E6EBF7;

/* g8 */
border: 1px solid #D7DFF0;
box-sizing: border-box;
border-radius: 10px 10px 0px 0px;
 

}
.sortable tr th {
    border-right: 0px;
    padding: 20px 0;font-size: 13px;
      color: #6F83AA;
   cursor: pointer;
   text-align: center;

}


.sortable tr td:nth-child(1) {
   
    min-width:50px;color: #364159;
}

.sortable tr td:nth-child(2) {
   
    width:30%;
}

.sortable tr td {
    border-right: 0px;
    padding: 15px 5px;
    text-align: center;font-size: 13px;
    min-width:100px;
}
.sortable tr td a {
    color: #364159;
}

#profile-right h2 {
    margin: 0px 0px 10px 0px;
}

.dataTables_info { display: none; }
#paymenttable_paginate { display: none;}
#paymenttable_filter input {display:none;}
.sortable tr td a:hover { text-decoration: underline; }
.centers li { list-style: none;padding:5px;display: inline-block;width: 100%;}
.ui-checkboxradio-radio-label .ui-icon-background { border: 1px solid #D7DFF0; }
.ui-checkboxradio-radio-label.ui-checkboxradio-checked .ui-icon, .ui-checkboxradio-radio-label.ui-checkboxradio-checked:hover .ui-icon { border-width: 5px;border-color: #0332aa;}
.ui-selectmenu-button.ui-button{ width: 150px;margin-top: 10px;border: 1px solid #D7DFF0;background: #fff;font-size: 13px;color:#536485;padding: 5px}
.response p { float: right;font-size:12px;color:#eb345e;}
</style>



<div class="wrap dynamic-width" style="float: left;position: relative">
    
    <div style="margin-top: 10px; width: 100%; height: 50px; text-align: right;">
             <span style="font-weight: bold;font-size: 20px;padding: 10px;float:left;color: #364159">Add Payment</span>
             
             <?php if(isset($roleaccess['Courses'][3]) && $roleaccess['Courses'][3]=="y"){ ?>
             
             <a style="font-size: 14px;padding: 10px;  color: #fff; margin: 0px auto; position: relative; top: 5px;border-radius:5px;background: linear-gradient(180deg, #4F70C4 0%, #1C47B3 100%);" href="<?php echo base_url(); ?>coursedetails?id=<?php echo $course['ide'];?>"><span style="position: relative;top:4px"><img  src="<?php echo $this->config->item('web_url') ?>images/addcourse.png" alt="Navigation" /></span><span style="margin-left:5px">View Course</span></a>
             <?php } ?>
         </div>  
    <div style="margin-top: 0px; width: 98%; height:50px; ">
       <div style="padding: 10px">
           <label style="font-size: 14px;color:#536485;">Course Name :</label> 
           <label style="font-size: 18px;color:#0332aa;font-weight: bold"><?php echo $course['coursename'];?></label></div>
     </div> 
    <div class="centers" style="width:18%;min-width: 100px;height: auto;float:left;border: 1px solid #D7DFF0;border-radius: 5px">
        <div style="width:100%;height:auto;margin:0px auto;background: #fff">
        <span style="color: #6F83AA;width: 300px;height:55px;text-align: center;font-size: 15px;vertical-align: middle;display: table-cell;background: #E6EBF7">Course Centers</span>
        <ul>
           <?php 
            echo $course['centers']; 
            ?>
        </ul>
        </div>
    </div>
    <div style="width:81%;height: auto;float:right">
         <?php echo $this->table->generate();  ?>             
         
        
     <div style="margin-top: 0px; width: 98%; height: 100px; ">
         <a href="javascript:void(0)" id="add_more" selected-centers ="" style="text-align: left;font-size: 14px;color:#0332aa;">+ Add more</a>
         <div style="text-align:right"><span style="color:#536485;font-size: 14px;font-weight: bold">Grand Total : </span> <span class="gtotal" style="font-size: 20px;font-weight: bold">12122</span></div>
          <span  style="margin: 0px auto; float:right;margin-top: 18px;padding: 10px; color: #fff; background: #4f6fc4 none repeat scroll 0% 0%; border-radius:5px;cursor: pointer" class="btn savebtn" href="#">Save</span>
         <a style="margin: 0px auto; float:right;margin-top: 18px;margin-right:18px;padding: 9px 10px; color: #0332AA; background: linear-gradient(0deg, #FFFFFF, #FFFFFF), #C4C4C4;border: 1px solid #0332AA; border-radius:5px" class="btn" href="<?php echo base_url(); ?>courses">Back</a>
         <span class="response" style="margin: 0px auto; float:right;width: 80%; height: 30px;margin-top:20px"></span>
     </div> 
        <?php echo form_open('addpayment/PaySubmit', array('id' => 'paySubmit')) ?> <input value="<?php echo $ide; ?>" class="cid" name="cid" type="hidden"> <input class="pdata" name="pdata" type="hidden"><input class="ptype" name="ptype" type="hidden"><?php echo form_close() ?>
        </div>
        </div>
    
 
    <script type="text/javascript">
$(document).ready(function(){	
    
      var descArr = '<?php echo $fees['general'];?>';
      var taxArr = '<?php echo json_encode($fees['tax']);?>';
      var splitArr = '<?php echo json_encode($fees['split']);?>';
		
	$(".radiocenters").checkboxradio();
        
          var columnData = [
                    { "data": "sno" },
                    { "data": "description" },
                    { "data": "sac" },                    
                    { "data": "amount" },
                    { "data": "discount" },
                    { "data": "tax" },
                    { "data": "total" }
                    
                  ];
                  
       
        var oTable = $('#paymenttable').dataTable({
                    "bProcessing": true,
                    "bServerSide": true,
                    "sPaginationType": "full_numbers",
                    "ajax": {
                    "url": 'addpayment/getPaymentLists',
                    "type": "POST",
                    "data":{ "id": "<?php echo html_escape($ide); ?>"}
                     }, 
                     "oLanguage": {
                        "sProcessing": "<img src='<?php echo base_url(); ?>images/loader.gif'>"
                    },
                    'iDisplayLength': 100,
                    "columns": columnData,
                    "fnDrawCallback": function( oSettings ) {
                      
                         $(".ptype").val(oSettings.json.data.length);
                         var taxPArr = $.parseJSON(taxArr);
                         var splitPArr = $.parseJSON(splitArr);
                         $("#paymenttable").find(".desc").each(function(){
                             
                             var descVal = $(this).val();
                             
                             $(this).html(descArr);
                             $(this).val(descVal);
                             
                                                        
                             var tax   = taxPArr[descVal];
                             var split = splitPArr[descVal];
                             
                            if(tax === "0"){
                                 
                                
                                 $(this).closest("tr").find(".tax").closest("td").append("<span class=\"taxna\" style=\"color: #536485;\">NA</span>");
                                 $(this).closest("tr").find(".tax").remove();
                                 
                            }
                            
                            $(this).closest("tr").attr("data-split",split);
                                                      
                             $(this).selectmenu();
                             
                             
                         });           
                         
                         $('#paymenttable').find("tr select").each(function(){
                            var yT= $(this).attr("attr-centers");
                            $(this).closest("tr").attr("attr-centers",yT);        
                          });
                          
                         
                          
                          $(".centers").find("li").first().find("input").trigger("click");
                          var yT= $(".centers").find("li").first().find("input").attr("attr-centers");
                          $("#add_more").attr("selected-centers",yT);
                                                            
                                      
                    }
         }); 
         
        
        
         
        $("#add_more").click(function(){  addRow(this); });
         
         $(".radiocenters").click(function(){ 
         
         var t = $(this).attr("attr-centers");  
        $("#add_more").attr("selected-centers",t);     
        var gVar = true;
        $('#paymenttable').find("tbody tr").each(function(){
                 
                if($(this).attr("attr-centers") === t){ 
                    $(this).addClass("show");
                    $(this).css("display","");
                    gVar = false;
                } else {
                    $(this).removeClass("show");
                    $(this).css("display","none");
                }
            
            });
            
            if(gVar) { addRow($("#add_more"));/*addRow($("#add_more"));*/}grandTotalUpdate();
         
         });
         
   

    function addRow(ele){
        var trEle = $("<tr></tr>").attr("role","row").attr("class","even show");
            var tdEle ="";
            var inpEle = '';var spanEle = '';
            var selectEle = $("<select></select>").attr("class","taxable").css("display","none");
            var selectEle1 = $("<select class=\"desc\"><option>Select Fees</option></select>");$(selectEle1).append(descArr);
            $(selectEle).html("<option value=\"0\">Non-taxable</option><option value=\"1\">Taxable</option>");
            var arrClass = ['','desc','sac','amount','discount','tax','total'];
            for(var i = 0 ; i < 7; i++){
                tdEle = $("<td></td>");inpEle=$("<input />").attr("type","text");
                if(i === 1) { 
                    selectEle1.addClass(arrClass[i]);
                    tdEle.append(selectEle1);
                   
                    tdEle.append(selectEle);
                    $(selectEle1).selectmenu();
                }
                else if (i !== 0 && i !== 6){ inpEle.addClass(arrClass[i]).val("0"); tdEle.append(inpEle);}
                if(i === 6) { spanEle = $("<span></span>");spanEle.addClass(arrClass[i]).css("color","#536485;").text("0");tdEle.append(spanEle);
                    inpEle.attr("name","pid").attr("class",'pid').attr("type",'hidden').val(''); tdEle.append(inpEle);}
                trEle.append(tdEle);
                tdEle='';inpEle='';
            }
            
            
            $('#paymenttable').find("tbody").append(trEle);
           // $('#paymenttable').find(".taxable").selectmenu();
            $(trEle).attr("attr-centers",$(ele).attr("selected-centers"));
    
    }
    
    
    $(document).delegate(".desc","selectmenuchange",function(event){
     
       var descVal = $(this).val();
                             var taxPArr = $.parseJSON(taxArr);
                            var splitPArr = $.parseJSON(splitArr);
                         
                             var tax   = taxPArr[descVal];
                             var split = splitPArr[descVal];
                                                        
                            if(tax === "0"){
                                 
                                
                                 $(this).closest("tr").find(".tax").closest("td").append("<span class=\"taxna\" style=\"color: #536485;\">NA</span>");
                                 $(this).closest("tr").find(".tax").remove();
                    
                            } else {
                                
                                
                                $(this).closest("tr").find(".taxna").closest("td").append("<input class=\"tax\" type=\"text\" value=\"0\">");
                                $(this).closest("tr").find(".taxna").remove();
                                
                                
                             
                            }
                            
                            $(this).closest("tr").attr("data-split",split);
    
    });
    
     
      
     $(document).delegate(".amount","keyup",function(event){
     
       if(!numCheck(this)) { alert('invalid key'); return;}  
      
       var amount = $(this).val(); 
       var discount = $(this).closest("tr").find(".discount").val();
       var tax = 0;var kf = 0;var cov = 0;
       if($(this).closest("tr").find(".tax").length){
           tax = $(this).closest("tr").find(".tax").val();
       }
      
  
       
       lineTotalUpdate(this,amount,discount,tax,kf,cov);
    
    });
    
      $(document).delegate(".discount","keyup",function(event){
     
       if(!numCheck(this)) { alert('invalid key'); return;}  
      
       var amount = $(this).closest("tr").find(".amount").val();
       var discount = $(this).val(); 
     
       //if(parseInt(discount) > 100) { alert('invalid key'); return; }
       
       var tax = 0;var kf = 0;var cov = 0;
       if($(this).closest("tr").find(".tax").length){
           tax = $(this).closest("tr").find(".tax").val();
       }
      
   
       lineTotalUpdate(this,amount,discount,tax,kf,cov);
              
    });
    
     $(document).delegate(".tax","keyup",function(event){
     
       if(!numCheck(this)) { alert('invalid key'); return;}  
      
       var amount = $(this).closest("tr").find(".amount").val();
       var discount = $(this).closest("tr").find(".discount").val();
       var tax = $(this).val(); 
       
       var kf = 0;var cov = 0;
       

       
       //if(parseInt(discount) > 100) { alert('invalid key'); return; }
       lineTotalUpdate(this,amount,discount,tax,kf,cov);
    
    });
    
        
        
    function lineTotalUpdate(ele,amount,discount,tax,kf,cov) {
        
        var total = 0;
        
        amount = (amount === '')?0:amount;
        discount = (discount === '')?0:discount;
   
        
        
          // var  tdis = (parseFloat(amount).toFixed(2))*(parseFloat(discount).toFixed(2)/100);
           amount = (parseFloat(amount).toFixed(2)) - (parseFloat(discount).toFixed(2));
           var ttax = (parseFloat(amount))* (parseFloat(tax)/100);
          
           
           total  = parseFloat(amount) + parseFloat(ttax) ;
       
      
        total = parseFloat(total).toFixed(2);
        $(ele).closest("tr").find(".total").text(total);  
       
        grandTotalUpdate();
        
    }
    
    
    function grandTotalUpdate() {
        
       var ltotal = 0;
        $(".show").each(function(){
        
            var y = ($(this).find(".total").text() === '')?'0':($(this).find(".total").text());
            ltotal = parseFloat(ltotal) + parseFloat(y);ltotal = parseFloat(ltotal).toFixed(2);
           
        });
         $(".gtotal").text(ltotal);
    
    }
    
    
    function numCheck(ele){
        
            var numchk = new RegExp("^[0-9.]*$");  
            if( numchk.test( $(ele).val() ) ){ return 1; } else { $(ele).val("");return 0;}
    }
    
   
    
    $(".savebtn").click(function(){
       
                if($(".response").hasClass('progress')) { return;}
               $(".response").html('').text('Progressing...');
                $(".response").addClass('progress');
               var data = "";
               $("tbody tr").each(function(){
                   var tax = "";var kf = "0";var cov = "0";
                   if($(this).find(".tax").length)
                   {
                       tax = $(this).find(".tax").val();
                   } else { 
                       tax = "NA";
                   }
                   
                  
                   var split = $(this).attr("data-split");
                   
                   data += $(this).attr("attr-centers")+"|"+$(this).find(".desc").val()+"|"+$(this).find(".sac").val()+"|"+$(this).find(".amount").val()
                            +"|"+$(this).find(".discount").val()+"|"+tax+"|"+kf+"|"+cov+"|"+$(this).find(".total").text()+"|"+$(this).find(".pid").val()
                            +"|"+$(this).find(".taxable").val()+"|"+split+"$";
                    
               });
               
              
               var payForm = $("#paySubmit"); payForm.find(".pdata").val(data);

                    $.ajax({
                        url: payForm.attr('action'),
                        type: 'post',
                        data: payForm.serialize(),
                        success: function(o){
                            
                            var response = $.parseJSON(o);
                            $(".response").html('');
                            if(response.status === 'success') {
                                
                                $(".response").css("color","rgb(25, 71, 15)");
                               $(".response").text(response.message);
                               $(location).prop('href', 'coursedetails?id=<?php echo html_escape($ide); ?>');
                               
                               
                            } else {
                                
                               $(".response").append(response.message); 
                               $(".response").removeClass('progress');
                           
                            }

                        }
                    });
                   
                              
            });
         
	
});


</script>


<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/dataTables.css?v=1.5" />
<script src="<?php echo base_url(); ?>js/jquery.dataTables.js?v=1.0" type="text/javascript"></script>
<script src="<?php echo base_url(); ?>js/onscan.min.js?v=1.0" type="text/javascript"></script>

 <style type="text/css">
     
	 .add-book .card{background: linear-gradient(0deg, #FFFFFF, #FFFFFF), #C4C4C4;box-shadow: 0px 0px 7px rgba(196, 196, 196, 0.35);border-radius: 10px;}
	 
	  table.dataTable{margin-top: 2rem !important}
	 .table tr:last-child td{text-align: left}
	.table tr td:last-child,.table tr th:last-child{text-align: left}
	.table tr:last-child td:last-child{font-weight: 600;text-align: left}
	.table tr:last-child{text-align: center}
	
	.table{border: 1px solid #D7DFF0;border-collapse: collapse;border-style: hidden;border-radius: 10px 10px 0 0;box-shadow: 0 0 0 1px #d7dff0;}
	.table thead th{font-size: 12px;font-weight: bold;color: #6F83AA;letter-spacing: 0.5px;background: #E6EBF7;text-transform: uppercase;padding: 0.8rem;text-align: left}
	.table thead tr th:first-child{border-top-left-radius: 5px}
	.table thead tr th:last-child{border-top-right-radius: 5px}
	.table td, .table th{border-top: 1px solid #D7DFF0;padding: 0.9rem 0.75rem;color: #364159;font-weight: 600;}
	.table td{background: #ffffff;}
	
		
	h3.title{font-size: 12px;text-transform: uppercase;color: #0332AA;letter-spacing: 0.5px;font-weight: bold;}
		
	 .dataTables_empty{text-align: center !important}
	 .dataTables_wrapper{overflow-x: auto}
	 .dataTables_paginate{ display: none}
	 
	 .dataTables_filter{right: 0;left: inherit;top: 5px;}
	 #usertable_filter input{width: 300px}
	 #usertable_wrapper{top: 0px;padding-top: 3rem}
	 
	 
	 p.list-item-heading{color: #6884CC;font-weight: 600;}
	.feetop p.list-item-heading span:last-child{font-weight: 600;font-size: 14px;color: #364159;}
	 
  
	 .editsavebtn,.cancelbtn{width: auto;padding: 3px;font-size: 12px}
 </style>

<script type="text/javascript">
	
	var oTable = "";
	
$(document).ready(function(){	
		
	
	$("select").change(function(){
		$(this).attr('value',$(this).val());
	});
	
	$(".addstock").click(function(){
		
		var center = $(".centers").val();
		
		if(center==""){ alert("Select center"); return false;}
		
		var url = 'addbookstock?bid=<?php echo $bid; ?>&center='+center;
										
	    $(location).prop('href', url);
	});
	
	
          var columnData = [
              { "data": "created_at" },
                    { "data": "barcode" },
                    { "data": "price" },
                    { "data": "booktype" },
                    { "data": "id" }
                    
                  ];
        // columnData.push( {data: "id","visible":true} );
         //columnData.push( {data: "item_name_search","visible":false} );
         
       
        oTable = $('#usertable').dataTable({
                    "bProcessing": true,
                    "bServerSide": true,
                    "sPaginationType": "full_numbers",
                    "ajax": {
                    "url": 'addbookstock/GetBookStockCenter',
                    "type": "POST",
                   
                    "data":{ "bid": "<?php echo $bid; ?>","center": "<?php echo $center; ?>"}
                     }, 
                     "oLanguage": {
                        "sProcessing": "<img src='<?php echo base_url(); ?>images/loader.gif'>",
						 "sSearchPlaceholder": "Search Barcodes"
                    },
                    'iDisplayLength': 1000,
                    "columns": columnData,
                    "order": [[ 0, "desc" ]],
                    "fnDrawCallback": function( oSettings ) {
						
                        var count = 1;
						
                         $('#usertable').find("tr .sno").each(function(){                           
                            $(this).text(count);
                            count++;
                         });
						
						$("#usertable").find(".del").each(function(){

                            $(this).click(function(){ 

                              if(confirm("Are you sure to delete this item ?")) {
                                    var ide = $(this).attr("data-id");
								    var bid = $(this).attr("data-bid");
                                    $.post('addbookstock/DelBookStock',{
											'ide':ide,'bid':bid
										}, function(o) { 
												var obj1 = $.parseJSON(o);
										
										$("#barcode").focus();
										
										if (obj1[0] === 'success') {
											oTable.fnDraw(); 
										} else if (obj1[0] === 'fail') {
											alert("Error!!! please try again");
										}
                                    });
                                }

                              });
                        
                          });
						
         				                                             
                    }
         }); 
         
         
         $('#usertable_filter input').addClass('form-control');
  
	
});
</script>

<main> 
        
        <div class="container-fluid">
        
        <div class="col-12 mb-4 add-book">
        
        <h1>Add Stock</h1> 
        
        
        <div class="row px-3 mt-4">     
                     
           <div class="col-12 p-0">
           
           <div class="card">
           
            <div class="course-container add-course mt-3 px-4">
                    
                <div class="row mb-3 feetop">
                   
					<div class="col-12 text-left px-2">
						<p class="list-item-heading mb-1"> <span>Book Name :</span> <span><strong><?php echo $bookdetails['bookname']; ?></strong></span></p>
					</div>
                                                       
				</div>                
                                                        
                <div class="row mb-3 feetop">
                   
					<div class="col-md-3 col-sm-3 col-3 text-left px-2">
						<p class="list-item-heading mb-1"> <span>Center:</span> <span><?php echo $center; ?></span></p>
					</div>

					
				</div>               
                                                                      
               
                </div>
                               
               				 
			   </div>
                            
               
            </div>
            
            
            <div class="col-12 p-0 my-4 add-book">
                               
                 <div class="card">               
                                
                <div class="row mt-3 px-3 pt-3">
                
                	<div class="col-12 col-sm-5">
                    
						<div class="form-group position-relative error-l-50 floating mb-0">

							 <input id="barcode" name="barcode" minlength="3" maxlength="7" class="form-control barcode" placeholder=" " type="text" tabindex="1" >

							 <label>Scan Barcode <span>*</span> </label>
						</div>
						
					</div>
                
                	<div class="col-12 col-sm-5">
                    
						<div class="form-group position-relative error-l-50 floating mb-0">

							 <input id="price" name="price" minlenth="2" maxlength="5" class="form-control price" placeholder=" " type="number" tabindex="2" value="<?php echo $bookdetails['price']; ?>" >

							 <label>Price <span>*</span> </label>
						</div>
						
					</div>
			  				
					<div class="col-12 col-sm-2">
				
 						 <button class="btn btn-primary savebtn">Save</button>

					 </div>
				 
					  <div class="col-12"> 
						<p class="alert my-3"></p>
					  </div>
				 
					</div>
				               
			   </div>
              
			   </div>
             
          
           </div>
           
            <?php echo $this->table->generate();  ?>
           
        
			</div>
		         
				                                   
  </div>
 
 </main>
   
       
<script type="text/javascript">
		
$(document).ready(function() {
      
	
	$("#barcode").focus();
	
	$("form select").change(function(){
		$(this).attr('value',$(this).val());
	});
	
	
	// Initialize with options
onScan.attachTo(document, {
    suffixKeyCodes: [13], // enter-key expected at the end of a scan
    reactToPaste: false, // Compatibility to built-in scanners in paste-mode (as opposed to keyboard-mode)
    onScan: function(sCode, iQty) { // Alternative to document.addEventListener('scan')
        //console.log('Scanned: ' + iQty + 'x ' + sCode); 
		$("#barcode").val(sCode).focus();
		scanbarcode(sCode);
    },
    onKeyDetect: function(iKeyCode){ // output all potentially relevant key events - great for debugging!
        //console.log('Pressed: ' + iKeyCode);
		//$("#barcode").focus();
    }
});
	
	
    $(".savebtn").click(function(){
		
			var barcode = $("#barcode").val();
		
			scanbarcode(barcode);
                   
                              
     });
	
	
	$(document).on("click",".edit",function(){
		
		
		$("#usertable").find(".editstock").each(function(){
			
			var price = $(this).data('price');
			$(this).find("img").removeClass('d-none');
			$(this).find(".editsavebtn,.cancelbtn").remove();
			$(this).parent().parent().find("td:nth-child(3)").html(price);
			$(this).removeClass('editstock').addClass('edit');
			
		});
		
				
		var bsid = $(this).data('bsid');
		var elem = $(this).parent().parent();
		
		var tdbarcode = elem.find("td:nth-child(2)").text();
		var tdprice = elem.find("td:nth-child(3)").text();
		
		$(this).append('<button class="btn btn-primary editsavebtn mr-2">Save</button><button class="btn btn-primary cancelbtn">X</button>').find("img").addClass('d-none');
		
		//$(elem).find("td:nth-child(2)").html('<input type="text" class="form-control tdbarcode" value="'+tdbarcode+'" />').fadeIn();
		$(elem).find("td:nth-child(3)").html('<input type="number" class="form-control tdprice" value="'+tdprice+'" />').fadeIn();
			      
		$(this).removeClass('edit').addClass('editstock');
                              
     });
	
	
	$(document).on("click",".editsavebtn",function(){
				
		var bsid = $(this).parent().data('id');
		var elem = $(this).parent();
		var parelem = $(this).parent().parent().parent();
		
		var tdbarcode = parelem.find("td:nth-child(2)").text();
		var tdprice = parelem.find(".tdprice").val();
		
		updatescanbarcode(elem,parelem,bsid,tdbarcode,tdprice)
                   
                              
     });
	
	$(document).on("click",".cancelbtn",function(){
				
		var bsid = $(this).parent().data('id');
		var price = $(this).parent().data('price');
		var elem = $(this).parent();
		var parelem = $(this).parent().parent().parent();
		
		var tdbarcode = parelem.find("td:nth-child(2)").text();
		var tdprice = parelem.find(".tdprice").val();
		  
		elem.find("img").removeClass('d-none');
		parelem.find(".editsavebtn,.cancelbtn").remove();
		parelem.find("td:nth-child(3)").html(price);
		elem.removeClass('editstock').addClass('edit');
                              
     });
	
            
});
	
	
	function scanbarcode(barcode){
		
			var bid = "<?php echo $bid; ?>";
			var center = "<?php echo $center; ?>";
			var btype = "<?php echo $btype; ?>";
			var price = $("#price").val();
		
			if(barcode=="") {alert("Scan barcode"); return false;}
		
			if(barcode.length < 3 || barcode.length > 7) {alert("Barcode must be upto 7 digit"); return false;}
			
			$(".alert").removeClass("alert-success alert-danger").text('');
		         
	   		$(".alert").addClass("alert-success").text('Progressing...');

			$.ajax({
				url: "addbookstock/bookstockSubmit",
				type: 'post',
				data: {"bid":bid,"center":center,"barcode":barcode,"price":price,"btype":btype},
				success: function(o){

					var response = $.parseJSON(o);
					
					if(response.status === 'success') {

						$(".alert").addClass("alert-success").text(response.message);
					   oTable.fnDraw(); 

					} else if(response.status === 'exists') {

					   $(".alert").addClass("alert-danger").text(response.message); 

					} else {

					   $(".alert").addClass("alert-danger").text(response.message); 

					}
					
					setTimeout(function(){$(".alert").removeClass("alert-success alert-danger").html('');$("#barcode").val("").focus()},1000);

				}
			});
		
	}
	
	
	function updatescanbarcode(elem,parelem,bsid,barcode,price){
		
			var bid = "<?php echo $bid; ?>";
			var center = "<?php echo $center; ?>";
			var btype = "<?php echo $btype; ?>";
			//var price = $("#price").val();
		
			if(barcode=="") {alert("Scan barcode"); return false;}
					         
			$.ajax({
				url: "addbookstock/bookstockSubmit",
				type: 'post',
				data: {"bid":bid,"center":center,"barcode":barcode,"price":price,"bsid":bsid,"btype":btype},
				success: function(o){

					var response = $.parseJSON(o);
					
					if(response.status === 'success') {

					   //oTable.fnDraw(); 
						
						elem.find("img").removeClass('d-none');
						parelem.find(".editsavebtn,.cancelbtn").remove();
						parelem.find("td:nth-child(3)").html(price);
						elem.removeClass('editstock').addClass('edit');
						elem.data("price",price);

					} else if(response.status === 'exists') {

					   alert(response.message); 

					} else {

					  alert(response.message); 

					}
					
					//setTimeout(function(){$(".alert").removeClass("alert-success alert-danger").html('');$("#barcode").val("").focus()},1000);

				}
			});
		
	}
	
</script>
<script src="<?php echo base_url();?>js/bootstrap.bundle.min.js"></script>
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/dataTables.css?v=1.6" />
<script src="<?php echo base_url(); ?>js/jquery.dataTables.js?v=1.0" type="text/javascript"></script>
<link rel="stylesheet" href="<?php echo base_url();?>css/boot/bootstrap.min.css">
<link rel="stylesheet" href="<?php echo base_url();?>css/boot/main.css?v=1">
  <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/lc_switch.css?v=1.3" />
<script src="<?php echo base_url(); ?>js/lc_switch.min.js?v=1.0" type="text/javascript"></script>

<style type="text/css">


.dataTables_wrapper input[type="text"] {
    padding: 0;
}
.dataTables_wrapper select {
    padding: 0;
}

.sortable thead tr  {
    background: #E6EBF7;

/* g8 */
border: 1px solid #D7DFF0;
box-sizing: border-box;
border-radius: 10px 10px 0px 0px;
 

}
.sortable tr th {
    border-right: 0px;
    padding: 15px 0;font-size: 13px;
      color: #6F83AA;
   cursor: pointer;
   text-align: center;

}

.sortable tr td:nth-child(1) {
  width:100px;
}

.sortable tr td:nth-child(2) {
  background: none;
   text-align: left;
}

.sortable tr th:nth-child(2) {
  background: #E6EBF7 url('<?php echo base_url(); ?>/images/datatable/sort_both.png') no-repeat center left;
  background-position-x: 110px;
  background-position-y: 16px;
   text-align: left;
}

.sortable tr td p { margin: 5px; }
.sortable tr td {
    border-right: 0px;
    padding: 0px;
    text-align: center;font-size: 13px;
    min-width:80px;vertical-align: middle;color:#000;
}
.sortable tr td a {
    color: #364159;
}

#profile-right h2 {
    margin: 0px 0px 10px 0px;
}

.templatetablee_length { width: auto !important; }
#templatetable_filter input { padding-top:4px;background: #fff url('<?php echo base_url(); ?>/images/search.png') no-repeat center left;background-position-x: 10px;border: 1px solid #D7DFF0; line-height: 32px;margin-left: 10px;width:260px;border-radius: 5px;text-indent: 30px;font-size: 13px;}
.sortable tr td a:hover { text-decoration: underline; }
</style>
<script type="text/javascript">
$(document).ready(function(){	
		
                $(".addcenter").click(function(){
                    $(".eresponse").text("");
                    $(".courseconfirm").trigger('click'); 
                });
                
	
          var columnData = [
              { "data": "created_at" },            
                    { "data": "name" },
                    { "data": "coursename" }, 
                    { "data": "date" },
                    { "data": "duration" },
                    { "data": "active" },
                    { "data": "ide" }
                    
                  ];
        // columnData.push( {data: "id","visible":true} );
         //columnData.push( {data: "item_name_search","visible":false} );
         
       
        var oTable = $('#templatetable').dataTable({
                    "bProcessing": true,
                    "bServerSide": true,
                    "sPaginationType": "full_numbers",
                    "ajax": {
                    "url": 'exammaster/GetExamMasters',
                    "type": "POST"
                     }, 
                     "oLanguage": {
                        "sProcessing": "<img src='<?php echo base_url(); ?>images/loader.gif'>"
                    },
                    'iDisplayLength': 20,
                    "columns": columnData,
                    "order": [[ 0, "created_at" ]],
                    "fnDrawCallback": function( oSettings ) {
                        var count = 1;
                        
                        $("#templatetable").find(".edit").each(function(){
                             
                            $(this).click(function(){ 
                                    $(".editresponse").text("");
                                    var ide = $(this).attr("data-id");
                                    var cname =  $(this).closest("tr").find(".name").text();
                                    var address1 =  $(this).closest("tr").find(".address1").text();
                                    var address2 =  $(this).closest("tr").find(".address2").text();
                                    var phonenumber =  $(this).closest("tr").find(".phone").text();
                                    var pincode =  $(this).closest("tr").find(".pincode").text();
                                    $("#eide").val(ide);
                                    $("#cname").val(cname);$("#address1").val(address1);
                                    $("#address2").val(address2);$("#phonenumber").val(phonenumber);
                                    $("#pincode").val(pincode);
                                    $(".courseconfirm1").trigger('click'); 
                              });

                          });
                          
                          $('#templatetable').find("tr .lcs_check").each(function(){
                            
                            if( ($(this).val()) === "a") {
                             $(this).lc_switch().lcs_on();
                            } else {
                             $(this).lc_switch().lcs_off();   
                            }
         
                          });
        
                         $("#templatetable").find(".del").each(function(){
                             
                            $(this).closest("tr").find(".sno").text(count);
                            count++;
                    

                            $(this).click(function(){ 

                              if(confirm("Are you sure to delete this item ?")) {
                                    var ide = $(this).attr("data-id");
                                    $.get('exammaster/DelExammaster',{
                                                               'ide':ide

                                                    }, function(o) { 
                                                            var obj1 = $.parseJSON(o);
                                                    if (obj1[0] === 'success') {
                                                        oTable.fnDraw(); 
                                                    } else if (obj1[0] === 'fail') {
                                                        alert("Error!!! please try again");
                                                }
                                    });
                                }

                              });
                        
                          });
                          
                          
                           $('#templatetable').find(".lcs_switch").click(function(){
                            
                            var status = "";
                            var ide = $(this).closest("p").attr("data-id");
                            if( ($(this).hasClass('lcs_off')) ) {
                             status ="a";
                            } else {
                              status ="d";
                            }
                            
                            if(confirm("Are you sure to change the status ?")) {
                                    
                                    $.get('exammaster/ChangeStatus',{
                                                               'ide':ide,'status':status

                                                    }, function(o) { 
                                                            var obj1 = $.parseJSON(o);
                                                    if (obj1[0] === 'success') {
                                                       // oTable.fnDraw(); 
                                                    } else if (obj1[0] === 'fail') {
                                                        alert("Error!!! please try again");
                                                }
                                    });
                                }
        
                          });
                          
                          
                                          
                    }
         }); 
         
         
                 $(".addsave").click(function(){
               
                $(".eresponse").html('').text('Progressing...');
                
               
                var locationForm = $("#addCenterForm");

                    $.ajax({
                        url: locationForm.attr('action'),
                        type: 'post',
                        data: locationForm.serialize(),
                        success: function(o){
                            
                            var response = $.parseJSON(o);
                            $(".response").html('');
                            if(response.status === 'success') {
                                
                                $(".eresponse").css("color","rgb(25, 71, 15)");
                               $(".eresponse").text(response.message);
                               oTable.fnDraw();
                               $('#courseModal').modal('hide');
                               
                            } else {
                                
                               $(".eresponse").text(response.message); 
                              
                           
                            }

                        }
                    });
                    
            });
            
              $(".editsave").click(function(){
               
                $(".editresponse").html('').text('Progressing...');
     
               $(".editresponse").text("");
                var locationForm = $("#editCenterForm");

                    $.ajax({
                        url: locationForm.attr('action'),
                        type: 'post',
                        data: locationForm.serialize(),
                        success: function(o){
                            
                            var response = $.parseJSON(o);
                            $(".response").html('');
                            if(response.status === 'success') {
                                
                                $(".editresponse").css("color","rgb(25, 71, 15)");
                               $(".editresponse").text(response.message);
                               oTable.fnDraw();
                               $('#courseModal1').modal('hide');
                               
                            } else {
                                
                               $(".editresponse").append(response.message); 
                           
                            }

                        }
                    });
                    
            });
  
	
});
</script>


<div class="wrap dynamic-width" style="float: left;position: relative">
    
    <div style="margin-top: 10px; width: 100%; height: 50px; text-align: right;">
        <span style="font-weight: bold;font-size: 20px;padding: 10px;float:left;color: #364159">Event Registrations</span>
         
         </div>  
    <div style="margin-top: 10px; width: 100%; height: 50px; text-align: right;">

        <?php if(isset($roleaccess['Exam Master'][0]) && $roleaccess['Exam Master'][0]=="y"){ ?> 
             <a class="addexam" style="text-decoration:none;font-size: 14px;padding: 10px;  color: #fff; margin: 0px auto; position: relative; top: 5px;border-radius:5px;background: linear-gradient(180deg, #4F70C4 0%, #1C47B3 100%);" href="examadd"><span style="position: relative;top:0px"><img  src="<?php echo $this->config->item('web_url') ?>images/addcourse.png" alt="Navigation" /></span><span style="margin-left:5px">Add Event</span></a>
        <?php } ?> 
         
         </div>  
         <?php echo $this->table->generate();  ?>             
         
        
        
        </div>
    


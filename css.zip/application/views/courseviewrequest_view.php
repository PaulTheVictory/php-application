<link rel="stylesheet" href="<?php echo base_url();?>css/boot/bootstrap.min.css">
 <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/dataTables.css?v=1.5" />
  <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/lc_switch.css?v=1.3" />
<script src="<?php echo base_url(); ?>js/jquery.dataTables.js?v=1.0" type="text/javascript"></script>
<script src="<?php echo base_url(); ?>js/lc_switch.min.js?v=1.0" type="text/javascript"></script>
 <link href="<?php  echo base_url(); ?>css/jquery-ui.min.css?v=1.4" rel="stylesheet" type="text/css" />
 <script src="<?php  echo base_url(); ?>js/jquery-ui.min.js?v=1.3" type="text/javascript"></script>
<link rel="stylesheet" href="<?php echo base_url();?>css/boot/bootstrap.min.css">
<link rel="stylesheet" href="<?php echo base_url();?>css/boot/main.css?v=1">
<script src="<?php echo base_url();?>js/bootstrap.bundle.min.js"></script>
<style>

	.coursetype .card{box-shadow: 0px 0px 7px rgba(196, 196, 196, 0.35);background: linear-gradient(0deg, #FFFFFF, #FFFFFF), #C4C4C4;cursor: pointer;border: 2px solid transparent;transition: all ease 0.3s}
	.rounded .coursetype .card{border-radius: 10px}
	.coursetype .card.active{border: 2px solid #0332AA;}
	.coursetype .card p {color: #889DC6;font-size: 14px;transition: all ease 0.3s}
	.coursetype .card img{filter: opacity(0.4);transition: all ease 0.3s}
	
	.coursetype .card.active p{color: #0332AA;}
	.coursetype .card.active img{filter: opacity(1);}
	
	.coursetop p{color: #6F83AA}
	
	.coursedetails h1{font-size: 24px;color: #0332AA;}
	.coursedetails .card,.courseinfo .card{background: linear-gradient(0deg, #FFFFFF, #FFFFFF), #0332AA;box-shadow: 0px 0px 7px rgba(196, 196, 196, 0.35);border-radius: 10px;}
	.coursedetails h2{color: #364159;font-size: 18px;font-weight: bold;line-height: 36px;}
	.coursedetails p.list-item-heading,.coursecontent .row div:first-child p,.yearfee .row div:first-child p{color: #6884CC;font-weight: 600;}
	
	
	p.preview{color: #6884CC;font-weight: 600;font-size: 1rem;}
	p.preview span{font-weight: 600;color: #364159;font-size: 1rem;}
	
	.border-right{border-right: 1px solid #D7DFF0!important;}
	
	.yearfee .card{background: #F6F7FA;border: 1px solid #BCCAE8;box-shadow: none}
	.yearfee p{margin-bottom: 1.5rem}
	.yearfee p.first,.yearfee p.second{font-weight: bold;font-size: 14px;color: #0332AA;text-align: left;text-transform: uppercase;}
	.yearfee .row div:last-child p{font-size: 14px;font-weight: 600;color: #364159;}
	
	.btn-primary{width: auto}
	
	.card h5{margin-bottom: 1rem;}
	h5{font-weight: bold;}
	.badge-outline-secondary, .badge-outline-theme-2{border: 1px solid #889DC6;color: #889DC6;background: #F6F7FA;}
	.badge{font-size: 12px;margin-right: 5px}
	
	.courseinfo .col-right .card .card-body{padding: 0;}
	.courseinfo .border-bottom{border-bottom: 1px solid #D7DFF0!important;}
	.col-right h5{padding: 1.2rem}
	
	.schedule .row div:first-child p{font-size: 12px;color: #6884CC;font-weight: bold;letter-spacing: 0.5px;text-transform: uppercase;}
	.schedule .row div:last-child p{font-size: 14px;font-weight: 600;}
	
	.relatedcourse p.list-item-heading{color: #6884CC;font-weight: 600;}
	.relatedcourse .row div:first-child p{font-size: 16px;color: #364159;font-weight: bold;}
	.relatedcourse .row div:last-child i{background: url(img/icons/arrow-right.png) no-repeat;width: 14px;height: 14px;display: inline-block;vertical-align: middle}
	
  .courseinfo ul {list-style: none;}
  .courseinfo li {list-style-position: inside;text-indent: 0em;font-stretch: normal;letter-spacing: normal;padding: 10px 10px 10px 35px;background: url("img/icons/check-circle.png") no-repeat left center; margin: 0;
  vertical-align: middle;}
	
	.icon-flag{background: url("img/icons/flag.png") no-repeat;width: 15px;height: 15px;display: inline-block;vertical-align: middle}
	.icon-check-square{background: url("img/icons/check-square.png") no-repeat;width: 15px;height: 15px;display: inline-block;vertical-align: middle}
	.icon-send{background: url("img/icons/send.png") no-repeat;width: 15px;height: 15px;display: inline-block;vertical-align: middle;margin-right: 5px}
	
	p.totalfee {font-weight: bold;font-size: 24px;color: #D63333;}
        
        .sortable thead tr  {
    background: #E6EBF7;

/* g8 */
border: 1px solid #D7DFF0;
box-sizing: border-box;
border-radius: 10px 10px 0px 0px;
 

}
.sortable tr th {
    border-right: 0px;
    padding: 15px 0;font-size: 13px;
      color: #6F83AA;
   cursor: pointer;
   text-align: center;

}


.sortable tr td:nth-child(1) {
   
    min-width:100px;color: #364159;
}

#paymenttable  tr td:nth-child(2) {
   
    width:40%;text-align: left;
}

#paymenttable  tr th:nth-child(2) {
   
    width:40%;text-align: left;
}

.sortable tr td {
    border-right: 0px;
    padding: 5px;
    text-align: center;font-size: 13px;
    min-width:100px;padding-bottom: 0px;
}
.sortable tr td a {
    color: #364159;
}


.dataTables_info { display: none; }
#paymenttable_paginate,#challantable_paginate,#addpaymenttable_paginate { display: none;}
#paymenttable_filter,#challantable_filter,#addpaymenttable_filter input {display:none;}
#paymenttable_wrapper{overflow-x:auto;}
.sortable tr td a:hover { text-decoration: underline; }
   .sortable tr td span {
    font-size: 14px;
    color: #364159;
}     

.hide span { color:#A2B4DA !important; }
.show span { color:#364159 !important; }
.ui-selectmenu-button.ui-button{ width: auto;margin-top: 10px;float: left;border: 1px solid #D7DFF0;background: #fff;font-size: 13px;color:#536485;padding: 5px}
.loader {
    display: none;
    position: absolute;
    top: 0; left: 0; right: 0; bottom: 0;
    background: rgba(255,255,255,0.8) url('<?php echo base_url(); ?>images/loader.gif') center center no-repeat;
    z-index: 1000;
}
	
.partialpay,.refundpay{display: inline-block;width: 42%;margin: 0px auto;text-align: center;}
#partialamt,#refundamt{color: #536485;border: 1px solid #D7DFF0;font-size: 14px;padding: 10px;display: inline-block;margin: 0px auto;outline: none;background: #fff;box-sizing: border-box;width: 65%;border-radius: 5px;height: 40px;}

.partialpaybtn{width: 30%;text-decoration: none !important;font-size: 14px;padding: 10px;  color: #fff !important; margin: 0px auto; position: relative;border-radius:5px;background: linear-gradient(180deg, #4F70C4 0%, #1C47B3 100%);}
.refundpaybtn{width: 30%;text-decoration: none !important;font-size: 14px;padding: 10px;  color: #fff !important; margin: 0px auto; position: relative;border-radius:5px;background: linear-gradient(180deg, #3CAF92 0%, #3CAF92 100%);}
	
	.form-control:focus~label, .custom-select:focus~label, input.form-control:not(:placeholder-shown) ~ label, select.form-control:not([value=""]):valid ~ label{margin-bottom: 0px}
	.form-group.floating>label{margin-bottom: 6px;line-height: 22px;}
	.form-group>label span{color: #db4d4d !important;}
	
	.marksheet p.list-item-heading{color: #6884CC;font-weight: 600;}
	.marksheet img{width: 100px;height: 130px;}
	.marksheet .gallery .col-2{position: relative;padding: 0;margin: 1rem;max-width: 10% !important}
	.marksheet .overlay{background: rgba(83, 100, 133,0.6) url(img/icons/eye.png) no-repeat center;width: 100%;height: 100%;position: absolute;border-radius: 0.75rem;top: 0;}
			
	.gallery a{text-align: center}
	.gallery a i{font-size: 4rem;padding: 1.5rem 0;display: block}
	.gallery a span.text{font-size: 10px;position: absolute;top: 28%;left: 14%;background: #ff0000;color: #fff;text-transform: uppercase;padding: 0px 7px;font-weight: bold;}
	
	@media (max-width:767px){
		
		.marksheet .gallery .col-2{max-width: 100% !important;}
	}
	
</style>
<script type="text/javascript">
$(document).ready(function(){
	var oTable2 = ""; var anyChange = "0";
  $(".back").click(function(){
      
       var url = 'admissions';
        $(location).prop('href', url);
          
  });
  
    $(document).on('lcs-statuschange', '.lcs_check', function() {
        
     if($(".edit-fees").find(".edit").hasClass("fesssave")) {       
        if($(this).is(':checked')) {
             $(this).closest("tr").addClass("show");
             $(this).closest("tr").removeClass("ahide");
             

         } else {
             
             var total = $(this).closest("tr").find(".total").text();
             total = parseFloat(total).toFixed(0);
             var paid = $(this).closest("tr").find(".paid").text();
             
             if(total !== paid) { 
                 $(this).closest("tr").addClass("ahide");
                 $(this).closest("tr").removeClass("show"); 
             } else {
                 $(this).lc_switch().lcs_off();   
             }

         }
         anyChange="1";
         grandTotalUpdate(); 
     } else {
         
        if( ($(this).val()) === "1") {
         $(this).lc_switch().lcs_off();

        } else {
         $(this).lc_switch().lcs_on();   
        }
     }
        
   });
        
    var columnData = [
                    { "data": "desc_order" },
                    { "data": "description" },
                    { "data": "centers" },
                    { "data": "sac" },                    
                    { "data": "amount" },
                    { "data": "discount" },
                    { "data": "tax" },
                    { "data": "kf" },
                    { "data": "cov" },
                    { "data": "total" },
                    { "data": "paid" },
                    { "data": "due" }
                    
                  ];
                  
       
        var oTable = $('#paymenttable').dataTable({
                    "bProcessing": true,
                    "bServerSide": true,
                    "sPaginationType": "full_numbers",
                    "ajax": {
                    "url": 'viewrequest/getPaymentLists',
                    "type": "POST",
                    "data":{ "ide": "<?php echo html_escape($qualification['courseid']); ?>"
                        ,"center":"<?php echo html_escape($qualification['center']); ?>"
                        ,"studid":"<?php echo html_escape($qualification['studentid']); ?>"
                        ,"rid":"<?php echo html_escape($rid); ?>"}
                     }, 
                     "oLanguage": {
                        "sProcessing": "<img src='<?php echo base_url(); ?>images/loader.gif'>"
                    },
                    'iDisplayLength': 20,
                    "columns": columnData,
                     "order": [[ 0, "asc" ]],
                    "fnDrawCallback": function( oSettings ) {
                                     
                        $('#paymenttable').find("tr .lcs_check").each(function(){
                            
                            if( ($(this).val()) === "1") {
                             $(this).lc_switch().lcs_on();
                             $(this).closest("tr").addClass("show");
                            } else {
                             $(this).lc_switch().lcs_off();   
                            }
                            
                           
                            
                            if($(this).closest("tr").find(".paid").text() === "") { $(this).closest("tr").find(".paid").text("0"); }
                            var tgiv = $(this).closest("tr").find(".discount").attr("attr-given");
                            var trea = $(this).closest("tr").find(".discount").attr("attr-reason");
                            var remar = $(this).closest("tr").find(".discount").attr("attr-remarks");
                            if( tgiv !== "" && trea !== "") {
                                $(this).closest("tr").find(".discount").siblings("p").show();                                
                            }
                            
                            if(remar !== '') {
                                $(this).closest("tr").find(".discount").siblings(".remarks").show();       
                            }
        
                          });
                          
                        grandTotalUpdate();                   
                    }
         }); 
         
         
        function grandTotalUpdate() {
        
            var ltotal = 0; var gpaidamt = 0; var gdueamt = 0;var kfadjustamt = 0;
             $("#paymenttable").find("tbody tr").each(function(){

                 var y = ($(this).find(".total").text() === '')?'0':($(this).find(".total").text());
                 ltotal = parseFloat(ltotal) + parseFloat(y);ltotal = parseFloat(ltotal).toFixed(2);
                 
                 var z = ($(this).find(".paid").text() === '')?'0':($(this).find(".paid").text());
                 gpaidamt = parseFloat(gpaidamt) + parseFloat(z);gpaidamt = parseFloat(gpaidamt).toFixed(2);
                 
                 var kfad = $(this).find(".paid").attr("attr-kfadjust");
                 kfad = (kfad === '')?'0':kfad;
                 kfadjustamt = parseFloat(kfadjustamt) + parseFloat(kfad);

             });
              $(".stotal").text(ltotal);
              //var rtotal = Math.round(ltotal);
              var rtotal = 0;
              $("#paymenttable").find("tbody tr").each(function(){
                  
                  var tamt = ($(this).find(".amount").attr("data-type"))?$(this).find(".amount").val():$(this).find(".amount").text();
                  var tdis = ($(this).find(".discount").attr("data-type"))?$(this).find(".discount").val():$(this).find(".discount").text();
                  var ttax = ($(this).find(".tax").attr("data-type"))?$(this).find(".tax").val():$(this).find(".tax").text();
                  var tkf = ($(this).find(".kf").attr("data-type"))?$(this).find(".kf").val():$(this).find(".kf").text();
                  
                  if((tkf === "NA")||(ttax === "NA")||(tkf === "")||(ttax === "")){
                      tkf = "0";ttax ="0";
                  }
                  var famt = parseFloat(tamt)-parseFloat(tdis);
                  var tottax = parseFloat(ttax)+parseFloat(tkf);
                  rtotal = parseFloat(rtotal)+parseFloat(famt*(1+(parseFloat(tottax))/100));
                  
              });
              
              rtotal = Math.round(rtotal);
              var roundoff = parseFloat(rtotal)-parseFloat(ltotal);
              
              if(roundoff !== 0) {
                  roundoff = parseFloat(roundoff).toFixed(2);
                  $(".roundoff").text(roundoff);
              } else {
                  $(".stotal").closest("div").css("display","none");
                  $(".roundoff").closest("div").css("display","none");
              }
              $(".gtotal").text(rtotal);
              gpaidamt = Math.ceil(gpaidamt);
              $(".gpaidamt").text(gpaidamt);
              var due = parseFloat(rtotal) - parseFloat(gpaidamt);
              if(kfadjustamt !== 0){
                  due = parseFloat(due) - parseFloat(kfadjustamt);
                  $(".kf_adjust").css("display","block");
                  $(".kfadjust").text(kfadjustamt);
              } else {
                  $(".kf_adjust").css("display","none");
              }
              
              if(parseFloat(due) > 0) { $(".gdueamt").text(due); } else { $(".gdueamt").text("0");}
    
       }
       
       $(".approve").click(function(){
           
          if( $(".edit-fees").find(".edit").hasClass("fesssave")) {alert('Kindly save the fees before confirm the request'); return;}
         var ide ='<?php echo $qualification['ide'];?>';
            $.get('viewrequest/ApproveRequest',{
                                                                'ide':ide,
                                                                'cride':'<?php echo $qualification['courseid'];?>',
                                                                'stuid':'<?php echo $qualification['studentid'];?>',
                                                                'qid':'<?php echo $qualification['qualificationid'];?>'

                                                     }, function(o) { 
                                                             var obj1 = $.parseJSON(o);
                                                     if (obj1[0] === 'success') {
                                                         alert("Success!!! Request Approved");
                                                         location.reload(); 
                                                     } else if (obj1[0] === 'fail') {
                                                         alert("Error!!! please try again");
                                                 }
                                     });
         
         });
         
         $(".decline").click(function(){
         var ide ='<?php echo $qualification['ide'];?>';
           
            $.get('viewrequest/DeclineRequest',{
                                                                'ide':ide

                                                     }, function(o) { 
                                                             var obj1 = $.parseJSON(o);
                                                     if (obj1[0] === 'success') {
                                                         alert("Success!!! Request Declined");
                                                          $(location).prop('href', 'admissions'); 
                                                     } else if (obj1[0] === 'fail') {
                                                         alert("Error!!! please try again");
                                                 }
                                     });
         
         });
         
         
          $(".waiting").click(function(){
         var ide ='<?php echo $qualification['ide'];?>';
           
            $.get('viewrequest/WaitingRequest',{
                                                                'ide':ide

                                                     }, function(o) { 
                                                             var obj1 = $.parseJSON(o);
                                                     if (obj1[0] === 'success') {
                                                         alert("Success!!! Waiting Request");
                                                          $(location).prop('href', 'admissions'); 
                                                     } else if (obj1[0] === 'fail') {
                                                         alert("Error!!! please try again");
                                                 }
                                     });
         
         });
    $(document).delegate(".amount","keyup",function(event){
     
       if(!numCheck(this)) { alert('invalid key'); return;}  
       
       var tot = $(this).closest("tr").find(".total").text();
       var paid = $(this).closest("tr").find(".paid").text();
      
       var amount = $(this).val(); 
       var discount = $(this).closest("tr").find(".discount").val();
       var tax = 0;var kf = 0;var cov = 0;
       if($(this).closest("tr").find(".tax").length){
           tax = $(this).closest("tr").find(".tax").val();
       }
      
//      if(Math.round(tot) === Math.round(paid)) {
//           if($(this).closest("tr").find(".kf").length){
//                kf = $(this).closest("tr").find(".kf").val();
//            }    
//       }
       
       if($(this).closest("tr").find(".cov").length){
           cov = $(this).closest("tr").find(".cov").val();
       }
       
       lineTotalUpdate(this,amount,discount,tax,kf,cov);
    
    });
    
      $(document).delegate(".discount","keyup",function(event){
     
       if(!numCheck(this)) { alert('invalid key'); return;}  
       
       var tot = $(this).closest("tr").find(".total").text();
       var due = $(this).closest("tr").find(".due").text();
       var amount = $(this).closest("tr").find(".amount").val();
       var cdiscount =  $(this).attr("cdiscount");
       due = (due === "")?"0":due;
//       if(due === "0") {
//            due = amount; 
//       }
       due = parseFloat(due)+parseFloat(cdiscount);
       
       var discount = $(this).val(); 
       discount = (discount === "")?0:parseFloat(discount);
       if(discount >0) {
            $(this).siblings().show();
        } else {  $(this).siblings("select").val("");$(this).siblings().hide(); }
        
        if(parseFloat(due) < parseFloat(discount)) {
            
            alert("The discount amount should be less than due");
            $(this).val(cdiscount); $(this).trigger("keyup");return;
        }
     
       
       var tax = 0;var kf = 0;var cov = 0;
       if($(this).closest("tr").find(".tax").length){
           tax = $(this).closest("tr").find(".tax").val();
       }
       
//       if(Math.round(tot) === Math.round(paid)) {
//           if($(this).closest("tr").find(".kf").length){
//                kf = $(this).closest("tr").find(".kf").val();
//            }    
//       }
       
       if($(this).closest("tr").find(".cov").length){
           cov = $(this).closest("tr").find(".cov").val();
       }
       lineTotalUpdate(this,amount,discount,tax,kf,cov);
              
    });
    
     $(document).delegate(".tax","keyup",function(event){
     
       if(!numCheck(this)) { alert('invalid key'); return;} 
       
        var tot = $(this).closest("tr").find(".total").text();
       var paid = $(this).closest("tr").find(".paid").text();
      
       var amount = $(this).closest("tr").find(".amount").val();
       var discount = $(this).closest("tr").find(".discount").val();
       var tax = $(this).val(); 
       
       var kf = 0;var cov = 0;
       
//        if(Math.round(tot) === Math.round(paid)) {
//           if($(this).closest("tr").find(".kf").length){
//                kf = $(this).closest("tr").find(".kf").val();
//            }    
//       }
       
       if($(this).closest("tr").find(".cov").length){
           cov = $(this).closest("tr").find(".cov").val();
       }
       
       //if(parseInt(discount) > 100) { alert('invalid key'); return; }
       lineTotalUpdate(this,amount,discount,tax,kf,cov);
    
    });
    
     $(document).delegate(".kf","keyup",function(event){
     
       if(!numCheck(this)) { alert('invalid key'); return;}  
       
       
        var tot = $(this).closest("tr").find(".total").text();
       var paid = $(this).closest("tr").find(".paid").text();
      
       var amount = $(this).closest("tr").find(".amount").val();
       var discount = $(this).closest("tr").find(".discount").val();
       
       
       var tax = 0;var cov = 0; var kf=0;
       
       // kf = $(this).val();  
       
      if($(this).closest("tr").find(".tax").length){
           tax = $(this).closest("tr").find(".tax").val();
       }
       
       if($(this).closest("tr").find(".cov").length){
           cov = $(this).closest("tr").find(".cov").val();
       }
       
       //if(parseInt(discount) > 100) { alert('invalid key'); return; }
       lineTotalUpdate(this,amount,discount,tax,kf,cov);
    
    });
    
    
     $(document).delegate(".cov","keyup",function(event){
     
       if(!numCheck(this)) { alert('invalid key'); return;}  
       
        var tot = $(this).closest("tr").find(".total").text();
       var paid = $(this).closest("tr").find(".paid").text();
      
       var amount = $(this).closest("tr").find(".amount").val();
       var discount = $(this).closest("tr").find(".discount").val();
       var cov = $(this).val(); 
       
       var tax = 0;var kf = 0;
       
      if($(this).closest("tr").find(".tax").length){
           tax = $(this).closest("tr").find(".tax").val();
       }
       
//       if(Math.round(tot) === Math.round(paid)) {
//           if($(this).closest("tr").find(".kf").length){
//                kf = $(this).closest("tr").find(".kf").val();
//            }    
//       }
       
       //if(parseInt(discount) > 100) { alert('invalid key'); return; }
       lineTotalUpdate(this,amount,discount,tax,kf,cov);
    
    });
        
        
        
    function lineTotalUpdate(ele,amount,discount,tax,kf,cov) {
        
        var total = 0;
        anyChange ="1";
        amount = (amount === '')?0:amount;
        discount = (discount === '')?0:discount;
        tax = (tax === '')?0:tax;
        kf = (kf === '')?0:kf;
        cov = (cov === '')?0:cov;
        
           //var  tdis = (parseFloat(amount).toFixed(2))*(parseFloat(discount).toFixed(2)/100);
           amount = (parseFloat(amount).toFixed(2)) - (parseFloat(discount).toFixed(2));
           var ttax = (parseFloat(amount))* (parseFloat(tax)/100);
           var tkf = (parseFloat(amount))* (parseFloat(kf)/100);
           var tcov = (parseFloat(amount))* (parseFloat(cov)/100);
           
           total  = parseFloat(amount) + parseFloat(ttax) + parseFloat(tkf) + parseFloat(tcov);
       
      
        total = parseFloat(total).toFixed(2);
        var paid = $(ele).closest("tr").find(".paid").text();
        paid = Math.round(paid);
        total = Math.round(total);
        $(ele).closest("tr").find(".total").text(total); 
      /*  if(total >= paid) {
            
        } else {
           // alert("Total amount should not be less than paid");
            if($(ele).hasClass("discount")) {
            $(ele).closest("tr").find(".discount").val("0"); 
            $(ele).closest("tr").find(".discount").trigger("keyup");
            } 
        }*/
         
       
        grandTotalUpdate();
        
    }
    
        function numCheck(ele){
              
                var numchk = new RegExp("^[0-9.]*$");  
                if( numchk.test( $(ele).val() ) ){ return 1; } else { $(ele).val("");return 0;}
            
        }
    
      
         $(".edit-fees").click(function(){
            
            if($(this).find(".edit").hasClass("open")) {
                
                $(this).find(".edit").text("Save Fees");
                $(this).find(".edit").removeClass("open");
                $(this).find(".edit").addClass("fesssave");
                var tax = "0";
                
                $('#paymenttable').find("tr span").each(function(){
                
                    var cname = $(this).attr("class");
                    var cvalue = $(this).text(); 
                    if(cname === 'desc') {
                        
                        var cen = $(this).attr("attr-centers");
                        $(this).closest("tr").attr("attr-centers",cen);
                        tax = $(this).attr("attr-taxable");
                    }
                    
                    if(cname === 'paid' && cvalue === "0"){
                        
                        var rm = $("<p class=\"remove\"></p>");
                        rm.css("background","#fff url(<?php echo base_url(); ?>images/delete.png) no-repeat ");
                        rm.css("float","right");rm.css("margin-right","10px");
                        rm.css("width","13px");
                        rm.css("height","16px");
                        rm.css("margin-top","6px");rm.css("cursor","pointer");
                        
                        var sttrsp = $(this).closest("tr").find(".desc").attr("attr-split");
                      /*  if(sttrsp !== "-1") {
                        $(this).closest("td").append(rm); }*/
                        
                        rm.click(function(){
                            //removePayItem(this);
                        });
                    }
                    
                    if((cname !== 'total')&&(cname !== 'desc')&&(cname !== 'paid')&&(cname !== 'due')) {
                        
                        if(cvalue === 'NA') {
                            
                            $(this).closest("td").html('<span style="padding-left:5px" data-type="spn" class="'+cname+'">'+cvalue+'</span>'); 
                            
                        } else {
                        
                             
                            if(cname === "discount"){
                                var given = $(this).closest("td").find("span").attr("attr-given");
                                var reason = $(this).closest("td").find("span").attr("attr-reason");
                                var remarks = $(this).closest("td").find("span").attr("attr-remarks");
                                var cdiscount = $(this).closest("td").find("span").attr("cdiscount");
                               var visibleflag = "display:none;";
                                if((given !=="") || (reason !== "") || (remarks !== "")) {visibleflag = "display:block;"; }
                                $(this).closest("td").append('<input cdiscount="'+cdiscount+'" style="padding-left:5px" data-type="inp" type="text" class="'+cname+'" value="'+cvalue+'">');
                                var givenby = $('<select style="'+visibleflag+'padding: 3px;min-width: 100px;margin: 5px;border: 1px solid #ccc;" class="givenby"><option value="">Given by</option><option>SGM</option><option>SKB</option><option>GTP</option><option>SJ</option></select>');
                                var reasonby = $('<select style="'+visibleflag+'padding: 3px;min-width: 100px;margin: 5px;border: 1px solid #ccc;" class="reason"><option value="">Reason</option><option>Financial Aid</option><option>Scholarship</option><option>Corrections</option><option>Course Change</option></select>');
                                 var remarksby = $('<input placeholder="Enter remarks" type="text" style="'+visibleflag+'padding: 3px;min-width: 100px;margin: 5px;border: 1px solid #ccc;" class="remarks">');
                               
                                $(givenby).val(given);$(reasonby).val(reason);$(remarksby).val(remarks);
                                $(this).closest("td").append(givenby);
                                $(this).closest("td").append(reasonby);
                                $(this).closest("td").append(remarksby);
                                 $(this).closest("td").find("p").remove(); $(this).closest("td").find("span").remove();
                               // $(this).closest("td").append('<select class="reason"><option>Financial Aid</option><option>Scholoarship</option></select>');
                            } else {
                                $(this).closest("td").html('<input style="padding-left:5px" data-type="inp" type="text" class="'+cname+'" value="'+cvalue+'">');
                            }
                        }
                                              
                    } else if((cname !== 'total')&&(cname === 'desc')&&(cname !== 'paid')&&(cname !== 'due')) {
                        
                        var plus = $("<p class=\"trig\"></p>");
                        
                        plus.css("background","#0332AA url(<?php echo base_url(); ?>images/plus.png) no-repeat ");
                        plus.css("float","left");
                        plus.css("width","13px");
                        plus.css("height","13px");
                        plus.css("margin-top","6px");plus.css("cursor","pointer");
                        
                        var split = $(this).attr("attr-split");
                        var rmpaid = $(this).closest("tr").find(".paid").text();
                        /*if(split === "1") {
                            $(this).closest("td").append(plus);
                        } else if((split === "-1")&&(rmpaid==="0")) {
                             var rem = $("<p class=\"trig\"></p>");
                             rem.css("background","#0332AA url(<?php echo base_url(); ?>images/minus.png) no-repeat ");
                             rem.css("float","left");
                             rem.css("width","13px");
                             rem.css("height","13px");
                             rem.css("margin-top","6px");rem.css("cursor","pointer");
                             //$(this).closest("td").append(rem);
                             $(rem).click(function(){
                                  var txt1 = $(this).siblings("span").text();
                                  var amt = $(this).closest("tr").find(".amount").val();
                                  $('#paymenttable').find("tr .desc").each(function(){
                                      
                                      var ut = $(this).text();
                                      if(txt1.includes(ut)) {
                                          var fg =  $(this).closest("tr").find(".amount").val();
                                          var fg = parseFloat(fg)+parseFloat(amt);
                                          $(this).closest("tr").find(".amount").val(fg);
                                          $(this).closest("tr").find(".amount").trigger("keyup");
                                      }
                                      
                                  });
                                  removePayItem(this);
                             });
                        }*/
                         
                        var selEle = $('<select style=\"display:none\" class=\"taxable\"></select>');   
                        selEle.html('<option value=\"0\">Non-taxable</option><option value=\"1\">Taxable</option>');
                        tax = (tax === "")?"0":tax;
                        selEle.val(tax);
                        $(this).closest("td").append(selEle);
                        selEle = '';
                        $(this).closest("td").css("padding-bottom","15px");
                        $(this).css("margin-left","6px");
                         
                         $(plus).click(function(){
                            
                            var ty = $(this).closest("tr");
                            var ty1 = $(this).closest("tr").clone();
                            
                            $(ty1).insertAfter(ty);
                            
                            var descName = $(ty).find(".desc").text();
                            var occur = 1; 
                            $('#paymenttable').find("tr .desc").each(function(){
                                      
                              var ut = $(this).text();                              
                              if(ut.includes(descName)) {
                                  if($(this).attr("attr-split") === "-1"){
                                      occur++;
                                  }                                 
                              }
                              
                              $(this).closest("tr").find("input").attr("readonly", true);
                              $(this).closest("tr").find("td").css("background","rgba(230,235,247,0.5)");
                            });
                            
                            $(ty1).find("input").attr("readonly", false);
                            $(ty1).find("td").css("background","#fff");
                            $(ty1).find(".desc").text(descName+" - Instalment "+occur);
                            $(ty1).find(".desc").attr("attr-split","-1");
                            $(ty1).find(".sno").attr("attr-id","");
                            $(ty1).find(".paid").text("0");
                            $(ty1).find(".discount").val("0");
                            $(ty1).find(".discount").siblings('select').hide();
                            occur = parseFloat(occur);occur++;
                            $(ty).find(".desc").attr("attr-occur",occur);
                            
                            $(ty1).find(".amount").val("0");
                             $(ty1).find(".total").text("0");
                            var t0 = $(ty).find(".amount").val();
                            var paidamt = $(ty).find(".paid").text();
                            var ramt = parseFloat(t0)-parseFloat(paidamt);
                            $(ty1).find(".amount").keyup(function(){                                
                                var t1 = $(this).val();   
                                t1 = (t1 === "")?0:t1;
                                if(ramt >= t1) {
                                    var t2 = parseFloat(t0) - parseFloat(t1);
                                    t2 = (t2<0)?0:t2;
                                    $(ty).find(".amount").val(t2);
                                    $(ty).find(".amount").trigger("keyup");
                                } else {
                                    $(ty1).find(".amount").val("0");
                                    $(ty1).find(".amount").trigger("keyup");
                                    alert("Amount should not greater than unpaid amount"); 
                                }
                                
                            });
                            
                            $(ty1).find(".trig").css("background","#D63333 url(<?php echo base_url(); ?>images/minus.png) no-repeat ");
                            $(ty1).find(".trig").click(function(){
                                $(ty1).closest("table").find("td").css("background","#fff");
                                $(ty1).closest("table").find("tr").find("input").attr("readonly", false);
                                var tuy = $(ty1).find(".amount").val();tuy = (tuy === "")?0:tuy;
                                var tuy1 = $(ty).find(".amount").val();tuy1 = (tuy1 === "")?0:tuy1;
                                var tu3 = parseFloat(tuy)+parseFloat(tuy1);
                                $(ty).find(".amount").val(tu3);
                                $(ty).find(".amount").trigger("keyup");
                                var occur2 = $(ty).find(".desc").attr("attr-occur");
                                occur2 = parseFloat(occur2);occur2--;
                                $(ty).find(".desc").attr("attr-occur",occur2);
                               $(ty1).remove(); grandTotalUpdate();
                            });
                            $(ty1).find(".remove").remove();
                            grandTotalUpdate();
                            var count = 1;
                            $(ty).closest("tbody").find("tr .sno").each(function(){
                                $(this).text(count); count++;
                            });
                           
                            
                         });
                         
                    }
                    
                   
                           
                });
                
               // $('#paymenttable').find(".taxable").selectmenu();
            
            } else {
            
                $(this).find(".edit").text("Edit Fees");
                $(this).find(".edit").removeClass("fesssave");
                $(this).find(".edit").addClass("open");
                
                SavePayment();
                 
               /* $('#paymenttable').find("tr input").each(function(){
                
                    var cname = $(this).attr("class");
                    var cvalue = $(this).val();
                    if((cname !== 'lcs_check')&&(cname !== 'desc')) {
                        $(this).closest("td").html('<span class="'+cname+'" >'+cvalue+'</span>');   
                    } else if((cname !== 'lcs_check')&&(cname === 'desc')) {
                        var tax = $(this).closest("td").find("select").val();
                        $(this).closest("td").html('<span attr-taxable="'+tax+'" class="'+cname+'" >'+cvalue+'</span>');   
                    }
                                               
                }); */
            
            }
                          
         });
         
         
         function removePayItem(rm){
         var id = $(rm).closest("tr").find(".sno").attr("attr-id");
                            
                            if(id !== "") {
                                $.get('viewrequest/DeleteLineItem',{
                                                                'id':id

                                                     }, function(o) { 
                                                             var obj1 = $.parseJSON(o);
                                                     if (obj1[0] === 'success') {
                                                        
                                                         
                                                     } else if (obj1[0] === 'fail') {
                                                        
                                                 }
                                });
                            }
                            
                            $(rm).closest("tr").remove();grandTotalUpdate();
         
         }
         
         function SavePayment(){
         
         if($(this).hasClass("progress")) { return;}
       $(".loader").show();
          $(this).addClass("progress");
         var data = "";   var ptype1 = "";  var reasonFlag = "0";var remarksFlag = "0";
         $(".anychange").val(anyChange);
         $("tbody tr").each(function(){
             
                    var reason = $(this).find(".reason").val();
                    var discount  = $(this).find(".discount").val();
                    if((reason === "")&&(discount !== "0")) { reasonFlag = "1";ptype1="";return false;}
             
                    var remarks = $(this).find(".remarks").val();
                    if((remarks === "")&&(discount !== "0")) { remarksFlag = "1";ptype1="";return false;}
                    var ptype = ($(this).find(".lcs_switch").hasClass('lcs_on'))?"1":"0";
                    ptype1 += ptype+"|";
                    
                    var tax= ($(this).find(".tax").attr("data-type") === "inp")?($(this).find(".tax").val()):($(this).find(".tax").text());
                    var kf= ($(this).find(".kf").attr("data-type") === "inp")?($(this).find(".kf").val()):($(this).find(".kf").text());
                    var cov= ($(this).find(".cov").attr("data-type") === "inp")?($(this).find(".cov").val()):($(this).find(".cov").text());
                    var split = $(this).find(".desc").attr("attr-split");
                   data += $(this).attr("attr-centers")+"|"+$(this).find(".desc").text()+"|"+$(this).find(".sac").val()+"|"+$(this).find(".amount").val()
                            +"|"+$(this).find(".discount").val()+"|"+tax+"|"+$(this).find(".total").text()+"|"+ptype
                            +"|"+$(this).find(".taxable").val()+"|"+$(this).find(".desc").attr("attr-id")+"|"+kf+"|"+cov+"|"+split+"|"+$(this).find(".paid").text()+"|"+$(this).find(".givenby").val()+"|"+$(this).find(".reason").val()+"|"+$(this).find(".remarks").val()+"$";
                    
               });
               
               if (ptype1.indexOf('1') > -1) {
               
               var payForm = $("#paySubmit"); payForm.find(".pdata").val(data);

                    $.ajax({
                        url: payForm.attr('action'),
                        type: 'post',
                        data: payForm.serialize(),
                        success: function(o){
                            
                            var response = $.parseJSON(o);
                            $(".response").html('');
                            if(response.status === 'success') {
                                
                               oTable.fnDraw(); 
                               if ( $( "#challantable" ).length ) {
                                   location.reload();
                               }
                               
                            } else {
                                
                            
                            }

                        }
                    });
                } else {
                        if(reasonFlag === "1") {
                            alert("Reason should be given");
                        }else if(remarksFlag === "1") {
                            alert("Please enter the discount remarks");
                        }else{
                             alert("Atleast one fee structure should be enable");
                        }
                        
                        $(".loader").hide();
                        $(this).removeClass("progress");
                        $(".edit-fees").find(".edit").text("Save Fees");
                        $(".edit-fees").find(".edit").removeClass("open");
                        $(".edit-fees").find(".edit").addClass("fesssave");
                    }
         }
         
         
         var columnData1 = [
                    { "data": "id" },
                    { "data": "challanno" },
                    { "data": "created_at" },
                    { "data": "payamt" },                    
                    { "data": "totalamt" },
                    { "data": "stupayid" }
                    
                  ];
         var oTable1 = $('#challantable').dataTable({
                    "bProcessing": true,
                    "bServerSide": true,
                    "sPaginationType": "full_numbers",
                    "ajax": {
                    "url": 'viewrequest/getChallanLists',
                    "type": "POST",
                    "data":{ "ide": "<?php echo html_escape($qualification['courseid']); ?>"
                        ,"studid":"<?php echo html_escape($qualification['studentid']); ?>"
                        ,"center":"<?php echo html_escape($qualification['center']); ?>"}
                     }, 
                     "oLanguage": {
                        "sProcessing": "<img src='<?php echo base_url(); ?>images/loader.gif'>"
                    },
                    'iDisplayLength': 20,
                    "columns": columnData1,
                    "fnDrawCallback": function( oSettings ) {
                        var count = 1;                    
                        $('#challantable').find("tr .sno").each(function(){
                          
                            $(this).text(count);
                            count++;
        
                          });
                          
                          $('#challantable').find("tr .payamt").each(function(){
                            
                            var totamt = $(this).closest("tr").find(".totalamt").text();
                            var payamt = $(this).text();
                            if((totamt === "0")||(totamt === "-0")) { $(this).closest("tr").css("display","none");return true;}
                            var balance = parseFloat(totamt)-parseFloat(payamt);
                            var challan = $(this).closest("tr").find(".challanno").text();
                            if(balance === 0) {
                                $(this).html("<span style=\"padding:5px;background: #EDFAF7;border: 1px solid #3CAF92;box-sizing: border-box;border-radius: 12px;color:#3CAF92;font-size:12px;width:50px;display:inline-block\">Paid</span>");
                                   $(this).closest("tr").find(".stupayid").html("<a target=\"_blank\" href=\"<?php echo base_url(); ?>stufeebill?crid=<?php echo html_escape($qualification['ide']); ?>&cno="+challan+"&userid=<?php echo html_escape($qualification['studentid']); ?>\" style=\"padding-left: 20px;background:url(<?php echo base_url(); ?>images/view.png) no-repeat;background-position-y: 4px;\" href=\"\">View</a>");
                            } else {
                                $(this).html("<span style=\"padding:5px;background: #FFF2F2;border: 1px solid #ED5252;box-sizing: border-box;border-radius: 12px;color:#ED5252;font-size:12px;width:50px;display:inline-block\">Unpaid</span>");
                                var addpay = $("<span class=\"addpay\" style=\"color:#0332AA;padding-left: 20px;background:url(<?php echo base_url(); ?>images/addpay.png) no-repeat;background-position-y: 4px;cursor:pointer\" >Add Payment</span>");
                                $(this).closest("tr").find(".stupayid").html(addpay);
                                $(addpay).click(function(){
                                    
                                   $(".courseconfirm").trigger('click'); 
                                    $(".paysave").attr("data-attr",challan);$(".paymode").val("");$(".paymode").trigger("change");
                                   if(oTable2 === "") { getAddPayments(challan); }
                                   
                                });
                            }
                            
        
                          });
                          
                                      
                    }
         }); 
         
         
        $(document).delegate(".amtpaid","keyup",function(event){
     
            if(!numCheck(this)) { alert('invalid key'); return;}  
      
            var paid = $(this).val(); var tpaid = $(this).val(); var totamt = $(".ptotal").text();
            
            $("#addpaymenttable").find("tr").each(function(){
               
               var split = $(this).find(".desc").attr("attr-split");
               split = (split === "")?"0":split;
               var linetotal = $(this).find(".total").text();
               $(this).find(".paid").text("0");
               if((parseFloat(paid) >= parseFloat(linetotal)) && (split === "0")){
                   $(this).find(".paid").text(linetotal);
                   paid = parseFloat(paid) - parseFloat(linetotal);
               } else if((parseFloat(paid) >= parseFloat(linetotal)) && (split === "1" || split === "-1" )){
                   $(this).find(".paid").text(linetotal);
                   paid = parseFloat(paid) - parseFloat(linetotal);
               } else if((parseFloat(paid) <= parseFloat(linetotal)) && (split === "1" || split === "-1" )){
                   $(this).find(".paid").text(paid);
                   paid = 0;
               }
                              
            });
     
            $(".ppaid").text(tpaid);
            var ty = parseFloat(totamt)-parseFloat(tpaid);
            $(".pdue").text(ty);
              
    });
    
    $(".paymode").change(function(){
      $("#pcenters").val('');$("#cperson").val('');$("#prefno").val('');$("#prefno").val('');
       var type = $(this).val();
       if(type === "dd"){
           
         //  $("#pcenters").closest(".col-12").css("display","none");
         //  $("#cperson").closest(".col-12").css("display","none");
           $("#prefno").closest(".col-12").css("display","block");
           $("#prefno").siblings("label").text("DD Number");
		   
		   $("#prefno").parent().removeClass('hide');
		   $(".preprefno").addClass('hide').html('DD Number: <span></span>');
                      
           
       } else if(type === "net"){
           
         //  $("#pcenters").closest(".col-12").css("display","none");
         //  $("#cperson").closest(".col-12").css("display","none");
           $("#prefno").closest(".col-12").css("display","block");
           $("#prefno").siblings("label").text("Transaction ID");
			   
		   $("#prefno").parent().removeClass('hide');
		   $(".preprefno").addClass('hide').html('Transaction ID: <span></span>');
           
       } else if((type === "upi")||(type === "card")||(type === "challan")||(type === "cheque")||(type === "online")){
           
           var ltext = "";
           if(type === "upi") { ltext = "Received Number";} else if(type === "card"){ ltext = "Reference number";}
           else if(type === "challan"){ ltext = "Challan number";}else if(type === "cheque"){ ltext = "Cheque Number";}
           else if(type === "online"){ ltext = "Transaction ID";}
          // $("#pcenters").closest(".col-12").css("display","none");
       //    $("#cperson").closest(".col-12").css("display","none");
           $("#prefno").closest(".col-12").css("display","block");
           $("#prefno").siblings("label").text(ltext);
			   
		   $("#prefno").parent().removeClass('hide');
		   $(".preprefno").addClass('hide').html(ltext+': <span></span>');
           
       } else if(type === "upi"){
           
         //  $("#pcenters").closest(".col-12").css("display","none");
         //  $("#cperson").closest(".col-12").css("display","none");
           $("#prefno").closest(".col-12").css("display","block");
           $("#prefno").siblings("label").text("Received Number");
		
		   $("#prefno").parent().removeClass('hide');
		   $(".preprefno").addClass('hide').html(ltext+': <span></span>');
           
       }else if(type === "cash"){
           
           
		   $("#prefno").parent().addClass('hide');
           $("#prefno").closest(".col-12").css("display","none");
           
       }else {
          // $("#pcenters").closest(".col-12").css("display","none");
          // $("#cperson").closest(".col-12").css("display","none");
		   $("#prefno").parent().addClass('hide');
           $("#prefno").closest(".col-12").css("display","none");
       }
    });
    
    $(".paysave").click(function(){
        
        if($(this).hasClass("progress")) { return;}
       
       $(this).addClass("progress");
       var chno = $(this).attr("data-attr");
       var pdate = $("#pdate").val();
       var ptime = $("#ptime").val();
       var amtpaid = $("#amtpaid").val();
       var paymode = $("#paymode").val();
       amtpaid = (amtpaid === "")?0:amtpaid;
       amtpaid = parseFloat(amtpaid);
       if(amtpaid <= 0) { alert("Payment is should more than Zero");$(this).removeClass("progress");return;}
       if(paymode === "") { alert("Payment mode is mandatory");$(this).removeClass("progress");return;}
       if($("#pcenters").val() === "") { alert("Center is mandatory");$(this).removeClass("progress");return;}
       if($(".cperson").val() === "") { alert("Cash counter person is mandatory");$(this).removeClass("progress");return;}
       if(($("#prefno").val() === "")&&(paymode !== "cash")) { alert("Reference no is mandatory");$(this).removeClass("progress");return;}
       var paydescription = "";
       if(paymode === "cash") { paydescription = $("#pcenters").val()+"|"+$(".cperson").val(); }
       else { paydescription = $("#pcenters").val()+"|"+$(".cperson").val()+"|"+$("#prefno").val();}
      
      
        $.get('viewrequest/addPayment',{
                 'chno':chno,'pdate':pdate,'ptime':ptime,'paymode':paymode,'pdescription':paydescription,'amtpaid':amtpaid,"ide": "<?php echo html_escape($qualification['courseid']); ?>"
                        ,"studid":"<?php echo html_escape($qualification['studentid']); ?>"

                 }, function(o) { 
                         var obj1 = $.parseJSON(o);
                 if (obj1[0] === 'success') {
                       $('#courseModal').modal('hide');
                     $('#paydoneModal').modal({show:true});
                      var view = '<?php echo base_url()."stufeebill?crid=".$qualification['ide']."&cno="?>'+chno+'&userid=<?php echo html_escape($qualification['studentid']); ?>';
                      $("#paydoneModal").find(".bill_view").attr("href",view);
                      $("#paydoneModal").find("a").attr('href',view);
                      $("#paydoneModal").find(".bill_view").click(function(){
                        $('#paydoneModal').modal('hide');location.reload();
                      });
                      $(".paysave").removeClass("progress"); $(".ppaid").text("0");
                      $(".pdue").text("0");
                      oTable.fnDraw();oTable2.fnDestroy();
                 } else if (obj1[0] === 'fail') {

             }
        });
        
       
       
    });
	
	
	 $(".previewbtn").click(function(){
               
       var pdate = $("#pdate").val();
       var ptime = $("#ptime").val();
       var amtpaid = $("#amtpaid").val();
       var paymode = $("#paymode").val();
		 
		 var pcenters = $("#pcenters").val();
		 var cperson = $(".cperson").val();
		 var prefno = $("#prefno").val();
		 
       amtpaid = (amtpaid === "")?0:amtpaid;
       amtpaid = parseFloat(amtpaid);
		 
       if(amtpaid <= 0) { alert("Payment is should more than Zero");$(this).removeClass("progress");return;}
		 
       if(paymode === "") { alert("Payment mode is mandatory");$(this).removeClass("progress");return;}
		 
       if($("#pcenters").val() === "") { alert("Center is mandatory");$(this).removeClass("progress");return;}
		 
       if($(".cperson").val() === "") { alert("Cash counter person is mandatory");$(this).removeClass("progress");return;}
		 
       if(($("#prefno").val() === "")&&(paymode !== "cash")) { alert("Reference no is mandatory");$(this).removeClass("progress");return;}
		 
		 $(".prepaymode").prev(".form-group").addClass('hide');
		 $(".prepaymode").removeClass('hide').find('span').text(paymode);
		 
		 $(".preamtpaid").prev(".form-group").addClass('hide');
		 $(".preamtpaid").removeClass('hide').find('span').text(amtpaid);
		 
       if(paymode === "cash") {
		   $(".prepcenters").prev(".form-group").addClass('hide');
		    $(".prepcenters").removeClass('hide').find('span').text(pcenters);
		   
		   $(".precperson").prev(".form-group").addClass('hide');
			$(".precperson").removeClass('hide').find('span').text(cperson);
		   
		    $(".preprefno").prev(".form-group").removeClass('hide');
		    $(".preprefno").addClass('hide').find('span').text("");
		   
	   }else { 
		   
		   $(".prepcenters").prev(".form-group").addClass('hide');
		   $(".prepcenters").removeClass('hide').find('span').text(pcenters);
		   
		   $(".precperson").prev(".form-group").addClass('hide');
		   $(".precperson").removeClass('hide').find('span').text(cperson);
		   
		   $(".preprefno").prev(".form-group").addClass('hide');
		   $(".preprefno").removeClass('hide').find('span').text(prefno);
	   }
		 
		 
		 $(".previewbtn").addClass('hide');
		 $(".backbtn,.paysave").removeClass('hide');
      
          
    });
	
	
	$(".backbtn").click(function(){
               
       var pdate = $("#pdate").val();
       var ptime = $("#ptime").val();
       var amtpaid = $("#amtpaid").val();
       var paymode = $("#paymode").val();
		 
		 var pcenters = $("#pcenters").val();
		 var cperson = $(".cperson").val();
		 var prefno = $("#prefno").val();
		 
       amtpaid = (amtpaid === "")?0:amtpaid;
       amtpaid = parseFloat(amtpaid);
		 		 
		 $(".prepaymode").prev(".form-group").removeClass('hide');
		 $(".prepaymode").addClass('hide').find('span').text("");
		 
		 $(".preamtpaid").prev(".form-group").removeClass('hide');
		 $(".preamtpaid").addClass('hide').find('span').text("");
		 
       if(paymode === "cash") {
		   $(".prepcenters").prev(".form-group").removeClass('hide');
		    $(".prepcenters").addClass('hide').find('span').text("");
		   
		   $(".precperson").prev(".form-group").removeClass('hide');
			$(".precperson").addClass('hide').find('span').text("");
		   
		    $(".preprefno").prev(".form-group").addClass('hide');
		    $(".preprefno").removeClass('hide').find('span').text("");
		   
	   }else { 
		   
		   $(".prepcenters").prev(".form-group").removeClass('hide');
		   $(".prepcenters").addClass('hide').find('span').text("");
		   
		   $(".precperson").prev(".form-group").removeClass('hide');
		   $(".precperson").addClass('hide').find('span').text("");
		   
		   $(".preprefno").prev(".form-group").removeClass('hide');
		   $(".preprefno").addClass('hide').find('span').text("");
	   }
		 
		 
		 $(".previewbtn").removeClass('hide');
		 $(".backbtn,.paysave").addClass('hide');
      
          
    });
	
	
	$('#courseModal').on('hidden.bs.modal', function () {
  		
		
		var totamt = $(".ptotal").text();
		
		var pdate = $("#pdate").val("");
       var ptime = $("#ptime").val("");
       var amtpaid = $("#amtpaid").val(totamt);
       var paymode = $("#paymode").val("");
		 
		 var pcenters = $("#pcenters").val("");
		 var cperson = $(".cperson").val("");
		 var prefno = $("#prefno").val("");
				
		 $(".prepaymode").prev(".form-group").removeClass('hide');
		 $(".prepaymode").addClass('hide').find('span').text("");
		 
		 $(".preamtpaid").prev(".form-group").removeClass('hide');
		 $(".preamtpaid").addClass('hide').find('span').text("");
		 
      
		   $(".prepcenters").prev(".form-group").removeClass('hide');
		   $(".prepcenters").addClass('hide').find('span').text("");

		   $(".precperson").prev(".form-group").removeClass('hide');
		   $(".precperson").addClass('hide').find('span').text("");

		   $(".preprefno").prev(".form-group").removeClass('hide');
		   $(".preprefno").addClass('hide').find('span').text("");
		 
		 
		 $(".previewbtn").removeClass('hide');
		 $(".backbtn,.paysave").addClass('hide');
		
		oTable2.fnDraw();
		
	});
	
         
          function getAddPayments(challan) {
  
  var columnData2 = [
                    { "data": "desc_order" },
                    { "data": "description" },
                    { "data": "amount" },
                    { "data": "discount" },
                    { "data": "tax" },
                    { "data": "kf" },
                    { "data": "cov" },
                    { "data": "roundoff" },
                    { "data": "total" },
                    { "data": "paid" }
                    
                  ];
   oTable2 = $('#addpaymenttable').dataTable({
                    "bProcessing": true,
                    "bServerSide": true,
                    "sPaginationType": "full_numbers",
                    "ajax": {
                    "url": 'viewrequest/getAddPaymentLists',
                    "type": "POST",
                    "data":{ "ide": challan,"cid": "<?php echo html_escape($qualification['courseid']); ?>"
                        ,"sid":"<?php echo html_escape($qualification['studentid']); ?>"}
                     }, 
                     "oLanguage": {
                        "sProcessing": "<img src='<?php echo base_url(); ?>images/loader.gif'>"
                    },
                    'iDisplayLength': 20,
                    "columns": columnData2,
                    "order": [[ 0, "asc" ]],
                    "fnDrawCallback": function( oSettings ) {
						
						var data = this.fnGetData();//console.log(data);
						
						if(data.length > 0){
							var studid = data[0].studid;
							var sname = data[0].sname;

							$(".studname").text(sname);
							$(".studno").text(studid);
						}
						
                        var count = 1;       var total = 0;             
                        $('#addpaymenttable').find("tr .desc").each(function(){
                            
                                                     
                            total = total+parseFloat($(this).closest("tr").find(".total").text());
        
                          });
                          
                       $(".paymode").val("");$(".paymode").trigger("change");
                          
                       $(".ptotal").text(total);   
                       $(".amtpaid").val(total);
                       $(".amtpaid").trigger("keyup");
                                      
                    }
         }); 
         }
         
      $(".vbclose").click(function(){
        location.reload();
      });
	
	
	// Partial Pay
	
	// Select your input element.
	var number = document.getElementById('partialamt');

	// Listen for input event on numInput.
	number.onkeydown = function(e) {
		if(!((e.keyCode > 95 && e.keyCode < 106)
		  || (e.keyCode > 47 && e.keyCode < 58) 
		  || e.keyCode == 8)) {
			return false;
		}
	}
	
	
	$(".partialpaybtn").click(function(){
        
		var partialamt = $("#partialamt").val();
		var grandtotal = $(".gtotal").text();
		var gdueamt = $(".gdueamt").text();
				
		
		if(partialamt=="") {alert('Enter partial amount');return false;}
		
		//if(parseInt(partialamt) < 2000 ){alert('Amount must be at least equal to any course fee');return false;}
		
		if(parseInt(partialamt) > parseInt(gdueamt) ){alert('Invalid amount greater than total amount');return false;}
		
		
       if($(this).hasClass("process")) { return;}
       
       $(this).addClass("process");
				
		$.post('viewrequest/addPartialPayment',{
                 'cride':"<?php echo html_escape($qualification['ide']); ?>","ide": "<?php echo html_escape($qualification['courseid']); ?>"
                        ,"studid":"<?php echo html_escape($qualification['studentid']); ?>","partialamt":partialamt,"grandtotal":grandtotal

                 }, function(o) { 
			
                   var obj1 = $.parseJSON(o);
			
                 if(obj1[0] == 'success') {
					 
					 alert('Partial amount added.');
					 $(".partialpaybtn").removeClass("process");
					 
				 }else if(obj1[0] == 'update') {
					 
					 alert('Partial amount updated.');
					 $(".partialpaybtn").removeClass("process");
					 
				 }else if(obj1[0] == 'fail') {
					 
					 alert('Partial amount failed.');
					 $(".partialpaybtn").removeClass("process");
					 
				 }else{
					 alert('Please try again');
					 $(".partialpaybtn").removeClass("process");
				 }
			
		});
		
		
	});
        
        //refund amount
        
        $(".refundpaybtn").click(function(){
        
		var refundamt = $("#refundamt").val();
				
		
		if(refundamt=="") {alert('Enter Refund amount');return false;}
		
		
                if($(this).hasClass("process")) { return;}

                $(this).addClass("process");
				
		$.post('viewrequest/addRefundPayment',{
                 'cride':"<?php echo html_escape($qualification['ide']); ?>","ide": "<?php echo html_escape($qualification['courseid']); ?>"
                        ,"studid":"<?php echo html_escape($qualification['studentid']); ?>","refundamt":refundamt,"center":"<?php echo html_escape($qualification['center']); ?>"

                 }, function(o) { 
			
                   var obj1 = $.parseJSON(o);
			
                 if(obj1[0] == 'success') {
					 
					 alert('Refund amount added.');
                                         $("#refundamt").val("");
					 $(".refundpaybtn").removeClass("process");
					 
				 }else if(obj1[0] == 'fail') {
					 
					 alert('Refund amount failed.');
					 $(".refundpaybtn").removeClass("process");
					 
				 }else{
					 alert('Please try again');
					 $(".refundpaybtn").removeClass("process");
				 }
			
		});
		
		
	});
	

	});
	
</script>

<div class="wrap dynamic-width" style="float: left;position: relative;min-width: 800px">
    
    
    <div class="row">
			<div class="col-12">

				<!--<div class="separator mb-5"></div>-->


			</div>

		</div>

		<div class="coursedetails">

			<div class="col-12 mb-4">
				<div class="card">
					<div class="card-body">

						<div class="row mb-5">

							<div class="col-md-6 col-sm-6 col-lg-8 col-12">
                                                                <h1 class="mb-2"><?php echo $student['sname'];?> (Student ID: <?php echo $student['studid'];?>)</h1>

								<h2 class="mb-2"><?php echo $course['coursename'];?></h2>

								<div class="row">

									<div class="col-md-3 text-left border-right px-3">
										<img alt="Profile" src="<?php echo base_url();?>img/icons/clock.png" class="img-thumbnail border-0 mb-2">
										<p class="list-item-heading mb-1">Duration</p>
										<p class="mb-4 text-muted"><?php echo $course['duration'];?></p>
									</div>

									<div class="col-md-3 text-left border-right px-4">
										<img alt="Profile" src="<?php echo base_url();?>img/icons/invoice.png" class="img-thumbnail border-0 mb-2">
										<p class="list-item-heading mb-1">Center</p>
										<p class="mb-4 text-muted"><?php echo $qualification['center'];?></p>
									</div>

									<div class="col-md-6 text-left px-4">
										<img alt="Profile" src="<?php echo base_url();?>img/icons/refresh-cw.png" class="img-thumbnail border-0 mb-2">
										<p class="list-item-heading mb-1">Qualification Details</p>
										<p class="mb-4 text-muted"><?php echo $course['qname'];?></p>
									</div>

								</div>

							</div>

							<div class="col-md-6 col-sm-6 col-lg-4 col-12 text-right">
								
								<p class="list-item-heading">Total Fee:</p>
								<p class="totalfee"><?php echo $qualification['total'];?></p>
						
							</div>

						</div>


						<div class="separator mb-5"></div>


						<div class="row yearfee">


							<div class="col-md-5 mb-4">

								<p class="first"> <?php echo $qualification['class'];?> details</p>

								<div class="d-block w-100 p-0">

									<div class="row">

										<div class="col-md-5">
											<p>Year of Passing:</p>
										</div>

										<div class="col-md-7">
											<p><?php echo $qualification['yearofpassing'];?></p>
										</div>

									</div>

									<div class="row">

										<div class="col-md-5">
											<p>Class Name:</p>
										</div>

										<div class="col-md-7">
											<p><?php echo $qualification['class'];?></p>
										</div>

									</div>

									<div class="row">

										<div class="col-md-5">
											<p>Board of Exams:</p>
										</div>

										<div class="col-md-7">
											<p><?php echo $qualification['stream'];?></p>
										</div>

									</div>

									<div class="row">

										<div class="col-md-5">
											<p>Status:</p>
										</div>

										<div class="col-md-7">
											<p><?php 
                                                                                        if($qualification['status'] === 'P') { echo 'Passed';}
                                                                                        else if($qualification['status'] === 'WFR') { echo 'Waiting For Result';}
                                                                                        else if($qualification['status'] === 'C') { echo 'Completed';}
                                                                                      
                                                                                        ?></p>
										</div>

									</div>

									<div class="row">

										<div class="col-md-5">
											<p>Roll Number:</p>
										</div>

										<div class="col-md-7">
											<p><?php echo $qualification['rollno'];?></p>
										</div>

									</div>

									<div class="row">

										<div class="col-md-5">
											<p>Grace Mark:</p>
										</div>

										<div class="col-md-7">
                                                                                        <p><?php echo ($qualification['gracemark'] === 'y')?"Yes":"No"; ?></p>
										</div>

									</div>
								</div>
							</div>

                                                                <?php
                                                                
                                                                if($qualification['subject'] !== '') {
                                                                    
                                                                    $subject = explode("|",$qualification['subject']);
                                                                    $mark = ($qualification['mark'] !== '')? explode("|",$qualification['mark']):"";
                                                                    $grade = ($qualification['grade'] !== '')? explode("|",$qualification['grade']):"";
                                                                    
                                                                    
                                                                    
                                                                    ?>
							<div class="col-md-4 mb-4">

								<p class="first"> <?php echo $qualification['class'];?> Marksheet</p>

								<div class="card d-flex d-block w-100 p-3">
                                                                    
                                                                   <?php 
                                                                   
                                                                   for($i = 0 ; $i < count($subject);$i++) {
                                                                   if($subject[$i] ==='') { continue;}
                                                                       $con = ($mark !== '')?$mark[$i]:$grade[$i];
                                                                        echo '<div class="row">

										<div class="col-md-5">
											<p>'.$subject[$i].':</p>
										</div>

										<div class="col-md-7">
											<p>'.$con.'</p>
										</div>

									</div>';
                                                                    }
                                                                   
                                                                   ?>
								
								</div>
							</div>
                                                    
                                                    <?php } ?>

						</div>


						<div class="separator mb-5"></div>

                                                <?php if($qualification['xii_yearofpassing'] !== '') {?>
						<div class="row yearfee">


							<div class="col-md-5 mb-4">

								<p class="first"> <?php echo $qualification['xii_class'];?> details</p>

								<div class="d-block w-100 p-0">

									<div class="row">

										<div class="col-md-5">
											<p>Year of Passing:</p>
										</div>

										<div class="col-md-7">
											<p><?php echo $qualification['xii_yearofpassing']; ?></p>
										</div>

									</div>

									<div class="row">

										<div class="col-md-5">
											<p>Class Name:</p>
										</div>

										<div class="col-md-7">
											<p><?php echo $qualification['xii_class'];?></p>
										</div>

									</div>

									<div class="row">

										<div class="col-md-5">
											<p>Board of Exams:</p>
										</div>

										<div class="col-md-7">
											<p><?php echo $qualification['xii_stream']; ?></p>
										</div>

									</div>

									<div class="row">

										<div class="col-md-5">
											<p>Status:</p>
										</div>

										<div class="col-md-7">
											<p><?php 
                                                                                        if($qualification['xii_status'] === 'P') { echo 'Passed';}
                                                                                        else if($qualification['xii_status'] === 'WFR') { echo 'Waiting For Result';}
                                                                                        else if($qualification['xii_status'] === 'C') { echo 'Completed';}
                                                                                      
                                                                                        ?></p>
										</div>

									</div>

									<div class="row">

										<div class="col-md-5">
											<p>Roll Number:</p>
										</div>

										<div class="col-md-7">
											<p><?php echo $qualification['xii_rollno']; ?></p>
										</div>

									</div>

									<div class="row">

										<div class="col-md-5">
											<p>Grace Mark:</p>
										</div>

										<div class="col-md-7">
											<p><?php echo ($qualification['xii_gracemark'] === 'y')?"Yes":"No"; ?></p>
										</div>

									</div>
								</div>
							</div>

                                                                <?php
                                                                
                                                                if($qualification['xii_subject'] !== '') {
                                                                    
                                                                    $xii_subject = explode("|",$qualification['xii_subject']);
                                                                    $xii_mark = ($qualification['xii_mark'] !== '')? explode("|",$qualification['xii_mark']):"";
                                                                    $xii_grade = ($qualification['xii_grade'] !== '')? explode("|",$qualification['xii_grade']):"";
                                                                    
                                                                    
                                                                    
                                                                    ?>
							<div class="col-md-4 mb-4">

								<p class="first"> <?php echo $qualification['xii_class'];?> Marksheet</p>

								<div class="card d-flex d-block w-100 p-3">

									<?php 
                                                                   
                                                                   for($i = 0 ; $i < count($xii_subject);$i++) {
                                                                   if($xii_subject[$i] ==='') { continue;}
                                                                       $con = ($xii_mark !== '')?$xii_mark[$i]:$xii_grade[$i];
                                                                        echo '<div class="row">

										<div class="col-md-5">
											<p>'.$xii_subject[$i].':</p>
										</div>

										<div class="col-md-7">
											<p>'.$con.'</p>
										</div>

									</div>';
                                                                    }
                                                                   
                                                                   ?>

									
								</div>
							</div>
                                                <?php } ?>

						</div>
                                                <div class="separator mb-5"></div>


						<div class="row yearfee">


							   <?php
                                                                                                                      
                                                            if($qualification['entrance_name'] !== "") {
                                                                
                                                                $examArr1 = explode("|", $qualification['entrance_name']);
                                                                $examArr2 = explode("|", $qualification['entrance_mark']);
                                                                $examArr3 = explode("|", $qualification['entrance_regno']);
                                                                
                                                                foreach ($examArr1 as $key => $value) {
                                                                    
                                                                    if($value === "") {continue;}
                                                            
                                                            echo '<div class="col-md-5 mb-4">
                                                            

								<p class="first">'.$value.' - Entrance Exam</p>

								<div class="d-block w-100 p-0">

									<div class="row">

										<div class="col-md-5">
											<p>Rank/Mark:</p>
										</div>

										<div class="col-md-7">
											<p>'.$examArr2[$key].'</p>
										</div>

									</div>

									<div class="row">

										<div class="col-md-5">
											<p>Registration Number:</p>
										</div>

										<div class="col-md-7">
											<p>'.$examArr3[$key].'</p>
										</div>

									</div>


								</div>
							</div>';
                                                                }
                                                            }
                                                            
                                                            ?>
						</div>


						<div class="mb-5"></div>

                                                <?php } ?>
                                                
                                                
					<?php
		
								$qmarksheets = $qualification['marksheets'];
								$qmarksheetsarr = explode('|',$qmarksheets);

								$qmarksheetlist = "";
								foreach($qmarksheetsarr as $qmarksheet){

									$ext = end(explode(".",$qmarksheet));

									if(strtolower($ext)!="pdf"){
										$qmarksheetlist .= '<div class="col-2"><a href="docs/courserequest/marksheets/'.$qualification['studentid'].'/'.$qmarksheet.'?'.time().'"><img class="img-fluid border-radius" src="docs/courserequest/marksheets/'.$qualification['studentid'].'/'.$qmarksheet.'?'.time().'"><div class="overlay"></div></a></div>';
									}
									else{
										$qmarksheetlist .= '<div class="col-2"><a href="docs/courserequest/marksheets/'.$qualification['studentid'].'/'.$qmarksheet.'?'.time().'" target="_blank"><span class="text">pdf</span><i class="glyph-icon simple-icon-doc"></i><div class="overlay"></div></a></div>';
									}

								}
			
							?>
        
							<?php if($qmarksheets!="" && $qmarksheets!="0"){?>
						   
						   <div class="mb-4 marksheet">

								<div class="row">

									  <div class="col-12">

											<p class="list-item-heading pb-2">Marksheets:</p>

											<div class="row gallery px-4 mb-4">
											  <?php echo $qmarksheetlist;?>
											</div>

									  </div>

								 </div>

							</div> 

							<?php }?>

						<div class="row">

							<div class="col-md-6 text-left">
								<button class="btn btn-outline-primary back">Back</button>

							</div>
                                                  

						</div>


					</div>

				</div>
			</div>
		</div>
    
    <div style="margin-top: 10px; width: 99%; height: 50px; text-align: right;"><div class="loader"></div>
             <span style="font-weight: bold;font-size: 20px;padding: 10px;float:left;color: #364159">Course Fees</span>
                     
           <?php if(isset($roleaccess['Admission Edit Fees'][3]) && $roleaccess['Admission Edit Fees'][3]=="y"){?>          
             <a  class="edit-fees" href="javascript:void(0)" style="text-decoration: none;font-size: 14px;padding: 10px;  color: #fff; margin: 0px auto; position: relative; top: 5px;border-radius:5px;background: linear-gradient(180deg, #4F70C4 0%, #1C47B3 100%);" ><span style="position: relative;top:0px;"><img  src="<?php echo $this->config->item('web_url') ?>images/addcourse.png" alt="Navigation" /></span><span class="edit open" style="margin-left:5px">Edit fees</span></a>
           <?php }?>
                    
         </div>  
  

    <div style="width:99%;height: auto;float:left">
         <?php echo $this->table->generate();  ?>             
         
        
     <div style="margin-top: 0px; width: 98%; height: 150px; ">
         <div style="text-align:right"><span style="color:#536485;font-size: 14px;">Sub Total : </span> <span class="stotal" style="font-size: 18px;font-weight: bold;color:#1C47B3"></span></div>
         <div style="text-align:right"><span style="color:#536485;font-size: 14px;">Roundoff : </span> <span class="roundoff" style="font-size: 18px;font-weight: bold;color:#1C47B3"></span></div>
         <div style="text-align:right"><span style="color:#536485;font-size: 14px;">Grand Total : </span> <span class="gtotal" style="font-size: 18px;font-weight: bold;color:#1C47B3"></span></div>
         <div style="text-align:right"><span style="color:#536485;font-size: 14px;">Paid Amount : </span> <span class="gpaidamt" style="font-size: 18px;font-weight: bold;color:#209679"></span></div>
         <div style="text-align:right" class="kf_adjust" style="display:none"><span style="color:#536485;font-size: 14px;">KF Adjust : </span> <span class="kfadjust" style="font-size: 18px;font-weight: bold;color:#209679"></span></div>
         <div style="text-align:right"><span style="color:#536485;font-size: 14px;">Due Amount : </span> <span class="gdueamt" style="font-size: 18px;font-weight: bold;color:#D63333"></span></div>
    </div> 
        <div style="margin-top: 0px; width: 98%; height: 50px; ">
       <?php if((isset($roleaccess['Refund Add'][3])) && ($roleaccess['Refund Add'][3]=="y") && ($qualification['refund'] !== '2') && ($qualification['refund'] !== '3')){?>
            <div class="refundpay" style="margin-right:15%"><input type="number" name="refundamt" id="refundamt" value="" placeholder="Enter Refund Amount"  />&nbsp;&nbsp;&nbsp;<a class="refundpaybtn" href="javascript:void(0)"><span style="position: relative;top:0px;"><img src="images/addcourse.png" alt="Navigation"></span><span class="edit open" style="margin-left:5px">Refund</span></a></div>
      <?php }?>
       <?php if(isset($roleaccess['Partial Payment'][3]) && $roleaccess['Partial Payment'][3]=="y"){?>
            <div class="partialpay"><input type="number" name="partialamt" id="partialamt" value="<?php if($partialpaydetails['partialamt']>0) {echo $partialpaydetails['partialamt'];} ?>" placeholder="Enter Partial Amount" min="0"  />&nbsp;&nbsp;&nbsp;<a class="partialpaybtn" href="javascript:void(0)"><span style="position: relative;top:0px;"><img src="images/addcourse.png" alt="Navigation"></span><span class="edit open" style="margin-left:5px">Add Amount</span></a></div>
       <?php }?>
       </div> 
        
        <?php
          if($qualification['approved'] === 'y'){
              
         echo '<span style="font-weight: bold;font-size: 20px;padding: 10px;float:left;color: #364159">Challan Details</span>';  
         
         $this->table->clear();
         $tmpl = array('table_open' => '<table class="sortable disabled" id="challantable" style="margin-top:0px;">');                 
         $this->table->set_template($tmpl);
         $this->table->set_heading('S.NO','CHALLAN NO', 'GENERATED DATE','STATUS','TOTAL','ACTION');
         echo $this->table->generate();  
              
          } else {
			  
			  if(isset($roleaccess['Admission Edit Fees'][3]) && $roleaccess['Admission Edit Fees'][3]=="y"){
				  
              echo '<div style="margin-top: 10px; width: 99%; height: 100px; text-align: right;">';
            
              if($qualification['approved'] === 'w' || $qualification['approved'] === 'n' || $qualification['approved'] === 'q'|| $qualification['approved'] === ''){
                echo '<a class="decline" style="left:-20px;font-size: 14px;padding: 10px;  color: #fff; border: 1px solid #0332AA;margin: 0px auto; position: relative; top: 5px;border-radius:5px; background: linear-gradient(0deg, #FFFFFF, #FFFFFF), #C4C4C4;" href="javascript:void(0)"></span><span style="margin-left:5px;color:  #0332AA;">Reject</span></a>';   
              }
              
              if($qualification['approved'] === 'w' || $qualification['approved'] === 'd' || $qualification['approved'] === 'n' || $qualification['approved'] === 'q' || $qualification['approved'] === ''){
                echo '<a class="approve" style="left:-10px;text-decoration: none;font-size: 14px;padding: 10px;  color: #fff; margin: 0px auto; border: 1px solid #0332AA;position: relative; top: 5px;border-radius:5px;background: linear-gradient(180deg, #4F70C4 0%, #1C47B3 100%);" href="javascript:void(0)"></span><span style="margin-left:3px;">Approve</span></a>';
              }
              if($qualification['approved'] === 'n' || $qualification['approved'] === 'd' || $qualification['approved'] === 'q' || $qualification['approved'] === ''){
                 echo ' <a class="waiting" style="text-decoration: none;font-size: 14px;padding: 10px;  color: #fff; margin: 0px auto; border: 1px solid #0332AA;position: relative; top: 5px;border-radius:5px;background: linear-gradient(180deg, #FFF3E8 0%, #FFF3E8 100%);" href="javascript:void(0)"></span><span style="margin-left:3px;color:  #0332AA;">Waiting</span></a>';
              }
              echo '</div>';
				  
			  }
             
          }
        
        ?>
        
         
        </div>
    <?php echo form_open('viewrequest/PaySubmit', array('id' => 'paySubmit')) ?> <input value="<?php echo $qualification['qualificationid']; ?>" class="qid" name="qid" type="hidden"><input value="<?php echo $qualification['studentid']; ?>" class="sid" name="sid" type="hidden"> <input value="<?php echo $qualification['ide']; ?>" class="ide" name="ide" type="hidden"><input value="<?php echo $qualification['courseid']; ?>" class="cid" name="cid" type="hidden"> <input class="pdata" name="pdata" type="hidden"><input class="ptype" name="rid" value="<?php echo $qualification['ide'];?>" type="hidden"><input type="hidden" name ="anychange" class="anychange"><?php echo form_close() ?>
    
    
    
</div>
  <style>

	.courseredirect{background: #3CAF92 !important;display: block;margin: auto;border: 1px solid #209679;}
	h5.modal-title p.headtitle{display: inline-block;width: 100%;text-align: center;font-weight: bold;font-size:17px;color: #fff;}
	h5.modal-title p.text-muted{display: inline-block;width: 100%;text-align: center;font-weight: 600;font-size: 14px;line-height: 36px;color: #181E29;line-height: 20px;}
	.modal-title img{display: block;margin: 1em auto}
        #paydoneModal.modal .modal-header,#payfailModal.modal .modal-header{padding: 10px 20px !important;border: none}	
		#paydoneModal.modal .modal-body,#payfailModal.modal .modal-body{padding:0 1.75rem 1.75rem}
		.modal-body p{text-align: left !important}
		.modal-backdrop.show {opacity: .5 !important;}
	  
	  .hide{display: none}
	  
	</style>
<button type="button" class="btn btn-outline-primary d-none courseconfirm" data-toggle="modal" data-backdrop="static" data-target="#courseModal">Confirm Submission</button>  
<!-- Modal -->


<?php if(isset($roleaccess['Admission Add Payment'][3]) && $roleaccess['Admission Add Payment'][3]=="y"){?>


<div class="modal fade" id="courseModal" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog modal-xl" role="document">
	<div class="modal-content">
            <div class="modal-header" style="background-color: #6884CC;height: 50px;width: auto;padding: 10px">
	  
		<h5 class="modal-title w-100" id="exampleModalLabel">
		
			<div class="row">
			
				<div class="col-4">
					<p class="headtitle">Add Payment</p>
				</div>
				<div class="col-8">
					<p class="headtitle text-right pr-3"> Student Name: <span class="studname mr-3"></span> Student ID: <span class="studno"></span></p>
				</div>
				
			</div>
				
		</h5>
	 </div>
            <div class="row" style="width: 98%;margin: 0px auto;margin-top: 25px;">
                <div class="col-12 col-sm-6" style="display: none">
                    <div class="form-group position-relative error-l-50 floating">
                        <input type="text" value="<?php date_default_timezone_set('Asia/Kolkata'); echo date("d/m/Y"); ?>" class="form-control" name="pdate" id="pdate" required  placeholder=" " >
                     <label for="date">Date <span>*</span></label>
                    </div>
                    
					<p class="preview prepdate hide">Date: <span></span></p>
		</div>
                <div class="col-12 col-sm-6" style="display: none">
                    <div class="form-group position-relative error-l-50 floating">
                        <input type="text" value="<?php echo date("h:i a"); ?>" class="form-control" name="ptime" id="ptime"   placeholder=" " >
                     <label for="time">Time <span>*</span></label>
                    </div>
                    
                    <p class="preview preptime hide">Time: <span></span></p>
		</div>
                <div class="col-12 col-sm-6">
              <div class="form-group position-relative error-l-50 floating">
                <select class="form-control paymode floating" id="paymode" name="paymode" required  >
                  <option value=""></option>
                  <option value="cash">Cash Counter Person</option>
                  <option value="online">Online Counter</option> 
                  <option value="dd">Demand Draft</option>
                  <option value="net">Netbanking</option>
                  <option value="upi">Gpay/Phonepe/UPI</option>  
                  <option value="card">Card</option> 
                  <option value="challan">Challan</option> 
                  <option value="cheque">Cheque</option> 
                </select>
                <label>Payment Mode <span>*</span></label>
              </div>
              
              <p class="preview prepaymode hide">Payment Mode: <span></span></p>
              
              </div>
               <div class="col-12 col-sm-6">
                    <div class="form-group position-relative error-l-50 floating">
                      <input type="text" class="form-control amtpaid" name="amtpaid" id="amtpaid" required  placeholder=" " >
                     <label for="date">Amount Paid <span>*</span></label>
                    </div>
                    
                     <p class="preview preamtpaid hide">Amount Paid: <span></span></p>
                     
		</div> 
                
                <div class="col-12 col-sm-6" >
              <div class="form-group position-relative error-l-50 floating">
                <select class="form-control pcenters floating" id="pcenters" name="pcenters" required  >
                  <option value=""></option>
                  <?php 
						
						if(!empty($user['centers']) && !in_array("All",$user['centers'])){
							
							foreach($user['centers'] as $ccenters){
								
								echo '<option>'.$ccenters.'</option>';
								
							}
							
						}else{
							//echo $units; 
							echo $branch;
						}
				  					
					?>                              
                </select>
                <label>Center <span>*</span></label>
              </div>
              
              <p class="preview prepcenters hide">Center: <span></span></p>
              
              </div> 
                
               <div class="col-12 col-sm-6">
                    <div class="form-group position-relative error-l-50 floating">
                      <input type="text" class="form-control cperson" name="cperson" id="cperson" required  placeholder=" " >
                     <label for="date">Cash Counter Person <span>*</span></label>
                    </div>
                    
                    <p class="preview precperson hide">Cash Counter Person: <span></span></p>
                    
		</div>  
                
                <div class="col-12 col-sm-12" style="display: none">
                    <div class="form-group position-relative error-l-50 floating">
                      <input type="text" class="form-control prefno" name="prefno" id="prefno" required  placeholder=" " >
                     <label for="date">DD Number <span>*</span></label>
                    </div>
                    
                    <p class="preview hide preprefno">DD Number: <span></span></p>
		</div>  
                
            </div>
	  <span style=";font-size: 17px;padding: 10px;float:left;color: #364159">Payment Details</span>
          <?php
           $this->table->clear();
         $tmpl = array('table_open' => '<table class="sortable disabled" id="addpaymenttable" style="width:98% !important;">');                 
         $this->table->set_template($tmpl);
         $this->table->set_heading('S.NO', 'PAYMENT FOR','AMOUNT', 'DISCOUNT','GST(%)','CESS KF(%)','CESS COV(%)','ROUNDOFF','TOTAL','PAID');
         echo $this->table->generate();
          
          ?>
          <div class="row" style="width: 98%">

									<div class="col-md-12 text-right px-2">
                                                                            <p class="list-item-heading mb-1"> <span>Total Amount:</span> <span class="ptotal" style="color: #1C47B3 !important"></span></p>
									</div>

									<div class="col-md-12 text-right px-2">
										<p class="list-item-heading mb-1"><span> Due Amount:</span> <span class="pdue" style="color: #D63333 !important"></span></p>
									</div>

									<div class="col-md-12 text-right px-2">
										<p class="list-item-heading mb-1"> <span>Total Paid:</span> <span class="ppaid" style="color: #209679 !important"></span></p>
									</div>

								</div>
        
	  <div class="modal-footer">
		
                <button type="button" class="btn btn-primary courseredirect cancelbtn float-left" data-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-primary previewbtn float-right" >Preview</button>
                
                <button type="button" class="btn btn-primary backbtn float-left hide">Back</button>
                <button type="button" class="btn btn-primary paysave float-right hide" >Save</button>                
                
	  </div>
	</div>
  </div>

</div>

<?php }?>


<div id="paydoneModal" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true" style="top:30%;">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
				   <button type="button" class="close vbclose" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				</div>
				<div class="modal-body text-center">
									
					<img src="css/img/brilliant-logo.png" alt="Payment Success" class="mb-3" />
					<h2 class="mb-4">Payment Successful!</h2>
									
					<p>Your Payment for course registration has been updated successfully! </p>
										
				</div>
                            <div class="modal-footer"><a href="" target="_blank" style="clear: both" class="bill_view"><button type="button" class="btn btn-primary ">View Bill</button></a></div>
								
			</div>
		</div>
	</div>


<style>
	
	body.background main{min-height: 500px;margin-top: 7rem !important}
	.contentpage .card{background: linear-gradient(0deg, #FFFFFF, #FFFFFF), #C4C4C4;box-shadow: 0px 0px 7px rgba(196, 196, 196, 0.35);border-radius: 10px;padding: 1rem;}
	
	ul li{margin-bottom: 15px}
	
</style>



<main class="contentpage">

	<div class="container">

		<div class="row">
		  <div class="col-12">

			  <div class="card"> 
			   
			   	<h1>Terms and Conditions</h1>
			   		
			   	  <ul>
			   		
				  <li>Signing up in the website does not guarantee admission to any course.</li>

				  <li>On signing up, you can apply to the courses eligible to you.</li>

				  <li>Admissions and allocation of students to different courses and centres are based purely on merit.</li>

				  <li>The applicant must submit the correct personal and contact details. </li>
				  <li>The student must update the details in case of any changes. </li>
				  <li>In the instance of a duplicate registration or registering with false information can lead to the disqualification.</li>

				  <li>Always ensure to contact the institute through the registered email or phone number referring the correct Student ID.</li>

				  <li>The institute reserves the right to modify the terms and conditions.</li>
				  
				  </ul>
				 
			   </div>

			   <div class="mb-3"></div>

		</div>

		</div>
		

	</div>
</main>
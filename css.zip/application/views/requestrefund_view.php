<link rel="stylesheet" href="<?php echo base_url();?>css/boot/bootstrap.min.css">
<link rel="stylesheet" href="<?php echo base_url();?>css/boot/main.css?v=1">
<script src="<?php echo base_url();?>js/bootstrap.bundle.min.js"></script>
<script src="<?php echo base_url();?>js/vendor/jquery.validate/jquery.validate.min.js"></script>
<script src="<?php echo base_url();?>js/vendor/jquery.validate/additional-methods.min.js"></script>
<link href="<?php  echo base_url(); ?>css/jquery-ui.min.css?v=1.4" rel="stylesheet" type="text/css" />
<script src="<?php  echo base_url(); ?>js/jquery-ui.min.js?v=1.3" type="text/javascript"></script>
<script type="text/javascript">
		
$(document).ready(function(){
    
        $(document).on("click",".prev-btn",function(){
             $(location).prop('href', 'studentprofile?sid=<?php echo $sid;?>');
        });
        $(document).on("click",".save-btn",function(){
            
             var accno = $("#bankaccountno").val();
            var reenteraccno = $(".mpreenteraccountnumber").val();
				
            if(accno != reenteraccno){
                   alert("Account number mismatch");
                    return false;
            }
            
            var refundForm = $("#refundForm");
            
            if(!Be(refundForm)){ 
                 $('html,body').animate({
        	scrollTop: $(".formscrolltop").offset().top},
        'slow');
                return false; 
            }
            
               if($(this).hasClass("progressing")) { return;}
               $(this).addClass("progressing");
		
								
		$(".updateloader").removeClass('d-none');
		 
		 $.ajax({
                type: 'POST',
                url: refundForm.attr('action'),
                data: refundForm.serialize(),
                success: function(o) {
                                        $(".save-btn").removeClass("progressing");
					var response = $.parseJSON(o);
					
					$(".updateloader").addClass('d-none');
										
					if(response.status === 'success'){
						
						$('#paydoneModal').modal({show:true});
																		
						setTimeout(function(){
							// $(location).prop('href', 'studentprofile?sid=<?php echo $sid;?>');
						},2000);
						
					}else {
						$(".alert").addClass('alert-danger').html(response.message);
					}
					
                }
			 
		 });
			
	});
        
         $(document).on("click",".refundok",function(){
             $(location).prop('href', 'studentprofile?sid=<?php echo $sid;?>');
        });
        
        $("#doj").datetimepicker();
		
        
	});
        
        
        function Be(e) {
	return !!$().validate && !!$(e).valid();
	//return true;
        }
    
</script>

<style>
		
	.feepayments h1{font-size: 18px;font-weight: bold;color: #0332AA;}
	.feepayments .card,.courseinfo .card{background: linear-gradient(0deg, #FFFFFF, #FFFFFF), #C4C4C4;box-shadow: 0px 0px 7px rgba(196, 196, 196, 0.35);border-radius: 10px;}
	.feepayments h2{color: #0332AA;font-size: 24px;font-weight: bold;line-height: 36px;}
	.feepayments p.list-item-heading{color: #6884CC;font-weight: 600;}
	.feepayments .feetop p.list-item-heading span:last-child{font-weight: 600;font-size: 14px;color: #364159;}
	
	.feepayments .crstatus-approve,.feepayments .crstatus-waitlisted,.feepayments .crstatus-pending{font-size: 12px !important;color: #ffffff !important;border-radius: 20px;text-transform: capitalize}
	.crstatus-approve{ background: #3CAF92;}
	.crstatus-waitlisted{background: #ED5252;}
	.crstatus-pending{background: #F48D25;}
	
	.feepayments .card:after{content: " ";color: #fff;position: absolute;width: 10px;height: 100%;top: 50%;transform: translateY(-50%);left: 0;border-top-left-radius: 10px;border-bottom-left-radius: 10px;}
	.feepayments.approve .card:after{background: #3CAF92;}
	.feepayments.waitlisted .card:after{background: #ED5252;}
	.feepayments.pending .card:after{background: #F48D25;}
	
	
	.border-right{border-right: 1px solid #D7DFF0!important;}
		
	.btn-primary{width: auto}
	.btn-primary.disabled, .btn-primary:disabled{background: #9AADDD;color: #ffffff;}
	
	.card h5{margin-bottom: 1rem;}
	h5{font-weight: bold;}
	.badge-outline-secondary, .badge-outline-theme-2{border: 1px solid #889DC6;color: #889DC6;background: #F6F7FA;}
	.badge{font-size: 12px;margin-right: 5px}
	
	.courseinfo .col-right .card .card-body{padding: 0;}
	.courseinfo .border-bottom{border-bottom: 1px solid #D7DFF0!important;}
	.col-right h5{padding: 1.2rem}
 	
	.save-btn{float: right}
	.prev-btn{float: left}
        
        .alert{font-size: 14px;}
	.maincontent p.alert-success {color: #155724;}
	.maincontent p.alert-danger {color: #721c24;}
        label { line-height: 18px !important;}
	
</style>


<div class="wrap dynamic-width" style="float: left;position: relative;min-width: 800px">

		<div class="row">
		  <div class="col-12">

			  <div class="row">
			   
			   	  <div class="col-md-9">
			   		<h1>Request Refund</h1>
				  </div>
				  
			   
			   </div>

			   <div class="mb-3"></div>

		</div>

		</div>
		
		<?php 
		
			if(!empty($feepayments['coursename'])){//print_r($feepayments);
				
			foreach($feepayments['coursename'] as $key=>$feepayment){
								
				$center = $feepayments['center'][$key];
				
				$courseid = $feepayments['courseid'][$key];	
				$cride = $feepayments['ide'][$key];	
		
                              
			
		?>
	
		<div class="row feepayments formscrolltop">
                    <?php echo form_open('stufeerefund/addRefund', array('id' => 'refundForm','class' => 'tooltip-right-bottom mb-4','novalidate'=>'')) ?> 
			<div class="col-12 mb-4">
				<div class="card">
					<div class="card-body">

						<div class="row">
								
								<div class="col-md-3">
									<p class="list-item-heading">Course Name:</p>
								</div>
								
								<div class="col-md-9">
									<h4><?php echo $feepayment;?></h4>
                                                                        <input type="hidden" required name="cid" value="<?php echo $courseid;?>"/>
								</div>
								
							</div>
							
							<div class="row">
								
								<div class="col-md-3">
									<p class="list-item-heading">Center Name:</p>
								</div>
								
								<div class="col-md-9">
									<p><?php echo $center;?></p>
                                                                        <input type="hidden" required name="center" value="<?php echo $center;?>"/>
								</div>
								
							</div>


					</div>

				</div>
			</div>
                    <div class="col-12 mb-4">
				<div class="card">
					<div class="card-body">

						<div class="row">
								
					
                                        <div class="row">

                                               <div class="col-12 col-sm-6">
                                                   
                                                        <div class="form-group position-relative error-l-50 floating">
                                                            <input type="text" disabled ="" class="form-control" name="sname" id="sname" required="" placeholder=" " value="<?php echo $stuprofile['stuname'];?>" >
                                                            <label for="sname">Student Name <span>*</span></label>
                                                        </div>
                                                
                                              </div>
                                            
                                            <div class="col-12 col-sm-6">
                                                        <div class="form-group position-relative error-l-50 floating">
                                                            <input disabled ="" type="number" class="form-control" required="" placeholder=" " value="<?php echo $stuprofile['studid'];?>">
                                                            <input type="hidden" required name="sid" value="<?php echo $stuprofile['studid'];?>"/>
                                                            <input type="hidden" required name="crid" value="<?php echo $cride;?>"/>
                                                            <input type="hidden" required name="stuid" value="<?php echo $sid;?>"/>
                                                            <label >Student ID <span>*</span></label>
                                                        </div>
                                                
                                              </div>
                                            <div class="col-12 col-sm-6">
                                                        <div class="form-group position-relative error-l-50 floating">
                                                            <input type="text" class="form-control" name="reason" id="reason" required="" placeholder=" " value=" <?php if(array_key_exists("reason", $stuprofile)){ echo  $stuprofile['reason'];}  ?>">
                                                            <label >Reason For Refund <span>*</span></label>
                                                        </div>
                                                
                                              </div>
                                            
                                            <div class="col-12 col-sm-6">
                                                        <div class="form-group position-relative error-l-50 floating">
                                                            <input type="text" class="form-control" name="doj" id="doj"  placeholder=" " value=" <?php if(array_key_exists("doj", $stuprofile)){ echo  $stuprofile['doj'];}  ?>">
                                                            <label >Date Of Joining <span></span></label>
                                                        </div>
                                                
                                              </div>
                                                      
                                            <div class="col-12 col-sm-6">
                                                        <div class="form-group position-relative error-l-50 floating">
                                                            <input type="text" class="form-control" name="batch" id="batch"  placeholder=" " value=" <?php if(array_key_exists("batch", $stuprofile)){ echo  $stuprofile['batch'];}  ?>">
                                                            <label >Batch Name <span></span></label>
                                                        </div>
                                                
                                              </div>
                                                      </div>
                                            <div class="col-12 mb-2">
                                                  <h4>Communication Address</h4>
                                            </div>
				  
			   
			                       
                                                   <div class="col-12 col-sm-6">
                                                <div class="form-group position-relative error-l-50 floating">
                                                    <input type="text" class="form-control" name="housenameno" id="housenameno" required="" placeholder=" " value="<?php echo $stuprofile['housenameno'];?>" />
                                                      
                                                   <label >House / Appartment no<span>*</span></label>
                                                </div>
                                              </div>
                                                   <div class="col-12 col-sm-6">
                                                <div class="form-group position-relative error-l-50 floating">
                                                  <input type="text" class="form-control" name="contactaddress" id="contactaddress" required="" placeholder=" " value="<?php echo $stuprofile['contactaddress'];?>" >
                                                   <label >Place / Street<span>*</span></label>
                                                </div>
                                              </div>
                                             <div class="col-12 col-sm-6">
                                                <div class="form-group position-relative error-l-50 floating">
                                                  <input type="text" class="form-control" name="contactpost" id="contactpost" required="" placeholder=" " value="<?php echo $stuprofile['contactpost'];?>" >
                                                   <label >Post office<span>*</span></label>
                                                </div>
                                              </div>
                                            <div class="col-12 col-sm-6">
                                                <div class="form-group position-relative error-l-50 floating">
                                                  <input type="text" class="form-control" name="contactcountry" id="contactcountry" required="" placeholder=" "  value="<?php echo $stuprofile['contactcountry'];?>" >
                                                   <label >Country<span>*</span></label>
                                                </div>
                                              </div>
                                            <div class="col-12 col-sm-6">
                                                <div class="form-group position-relative error-l-50 floating">
                                                  <input type="text" class="form-control" name="contactstate" id="contactstate" required="" placeholder=" "  value="<?php echo $stuprofile['contactstate'];?>">
                                                   <label >State<span>*</span></label>
                                                </div>
                                              </div>
                                            <div class="col-12 col-sm-6">
                                                <div class="form-group position-relative error-l-50 floating">
                                                  <input type="text" class="form-control" name="contactdistrict" id="contactdistrict" required="" placeholder=" "  value="<?php echo $stuprofile['contactdistrict'];?>">
                                                   <label >District<span>*</span></label>
                                                </div>
                                              </div>
                                             <div class="col-12 col-sm-6">
                                                <div class="form-group position-relative error-l-50 floating">
                                                  <input type="text" class="form-control" name="contactpincode" id="contactpincode" required="" placeholder=" "  value="<?php echo $stuprofile['contactpincode'];?>">
                                                   <label >Pincode<span>*</span></label>
                                                </div>
                                              </div>
                                            
                                            <div class="col-12 mb-2">
                                                  <h4>Student Account Details</h4>
                                                  <p style="color:#ff3c3c;font-weight: bold;font-size: 14px;margin-bottom: 0px;">All refunds will be processed and issued against Student Bank Account only</p>
                                            </div>
                                             <!--div class="col-12 col-sm-6">
                                                <div class="form-group position-relative error-l-50 floating">
                                                  
                                                   <input type="text" class="form-control" name="accountholdername" id="accountholdername" required="" placeholder=" " value="<?php //if($stuprofile['accountholdername'] != "0") { echo $stuprofile['accountholdername']; } else { echo "";}?>" />
                                                     <label >Account Holder Name<span>*</span></label>
                                                </div>
                                              </div-->
                                            <div class="col-12 col-sm-6">
                                                <div class="form-group position-relative error-l-50 floating">
                                                  <input type="text" class="form-control" name="bankname" id="bankname" placeholder=" " value="<?php if($stuprofile['bankname'] != "0") { echo $stuprofile['bankname']; } else { echo "";}?>" >
                                                   <label >Bank Name<span>*</span></label>
                                                </div>
                                              </div>
                                            <div class="col-12 col-sm-6">
                                                <div class="form-group position-relative error-l-50 floating">
                                                  <input type="text" class="form-control" name="branch" id="branch" placeholder=" "  value="<?php if($stuprofile['branch'] != "0") { echo $stuprofile['branch']; } else { echo "";}?>" >
                                                   <label >Branch<span>*</span></label>
                                                </div>
                                              </div>
                                            <div class="col-12 col-sm-6">
                                                <div class="form-group position-relative error-l-50 floating">
                                                  <input type="text" class="form-control" name="ifsccode" id="ifsccode" placeholder=" "  value="<?php if($stuprofile['ifsccode'] != "0") { echo $stuprofile['ifsccode']; } else { echo "";}?>">
                                                   <label >IFSC Code<span>*</span></label>
                                                </div>
                                              </div>
                                            <div class="col-12 col-sm-6">
                                                <div class="form-group position-relative error-l-50 floating">
                                                    <input type="text" class="form-control" name="bankaccountno" maxlength="18" id="bankaccountno"  placeholder=" "  value="<?php if($stuprofile['bankaccountno'] != "0") { echo $stuprofile['bankaccountno']; } else { echo "";}?>">
                                                   <label >Bank Account Number<span>*</span></label>
                                                </div>
                                              </div>
                                            <div class="col-12 col-sm-6">
                                                <div class="form-group position-relative error-l-50 floating">
                                                 <input type="number" class="form-control mpreenteraccountnumber" name="mpreenteraccountnumber" maxlength="18" placeholder=" " value="<?php if($stuprofile['bankaccountno']!="" && $stuprofile['bankaccountno']!="0"){ echo $stuprofile['bankaccountno'];}else{echo "";} ?>">
                                                 <label>Re-Enter Bank Account Number</label>
                                               </div>
                                             </div>
     
                                          </div>
                                          </div>
                                  
						</div>
						
					</div>

				</div>
			
                    <div class="col-12">
                                <div class="alert mb-0"></div>
				<button class="btn btn-outline-primary prev-btn mb-5" type="button"> Back</button>
				<button class="btn btn-primary save-btn mb-5" type="button"><img src='<?php echo base_url(); ?>images/loader.gif' class="updateloader d-none mr-2">Submit </button>
                                <input type="hidden" value="init" name="type">
                       
                    </div>
                    <?php echo form_close() ?>	
		</div>
		
		<?php }}else{?>
		
		<div class="row feepayments">

			<div class="col-12 mb-4">
				<div class="card">
					<div class="card-body">
					
						<p class="text-muted text-center mb-0">No Fee and Payments Found.</p>
					
				</div>
			</div>
		</div>
		
		<?php }?>

	</div>


         <style>

	h5.modal-title p.headtitle{display: inline-block;width: 100%;text-align: center;font-weight: bold;font-size:17px;color: #fff;}
	h5.modal-title p.text-muted{display: inline-block;width: 100%;text-align: center;font-weight: 600;font-size: 14px;line-height: 36px;color: #181E29;line-height: 20px;}
	.modal-title img{display: block;margin: 1em auto}
		.modal-body p{text-align: left !important}
		.modal-backdrop.show {opacity: .5 !important;}
                 #paydoneModal.modal .modal-header{padding: 10px 20px !important;border: none}	
		#paydoneModal.modal .modal-body{padding:0 1.75rem 1.75rem}
	</style>
    
    <div id="paydoneModal" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true" style="top:30%;">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
				   <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				</div>
				<div class="modal-body text-center">
									
					<img src="css/img/brilliant-logo.png" alt="Payment Success" class="mb-3" />
					<h2 class="mb-4">Refund Initiated!!!</h2>
									
					<p>Refund request has been updated successfully!</p>
										
				</div>
                            <div class="modal-footer">
                                <div class="form-group"> 
                                    <button type="button" class="refundok btn btn-primary float-left" data-dismiss="modal">Ok</button>
                                </div> 
                            </div>
								
			</div>
		</div>
	</div>
        
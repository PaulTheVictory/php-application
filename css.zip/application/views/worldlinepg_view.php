<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/dataTables.css?v=1.5" />
<script src="<?php echo base_url(); ?>js/jquery.dataTables.js?v=1.0" type="text/javascript"></script>
<link rel="stylesheet" href="<?php echo base_url();?>css/boot/bootstrap.min.css">
<link rel="stylesheet" href="<?php echo base_url();?>css/boot/main.css?v=1">
<script src="<?php echo base_url();?>js/bootstrap.bundle.min.js"></script>
<link href="<?php  echo base_url(); ?>css/jquery-ui.min.css?v=1.4" rel="stylesheet" type="text/css" />
 <script src="<?php  echo base_url(); ?>js/jquery-ui.min.js?v=1.3" type="text/javascript"></script>
<style type="text/css">


.dataTables_wrapper input[type="text"] {
    padding: 0;
}
.dataTables_wrapper select {
    padding: 0;
}

.sortable thead tr  {
    background: #E6EBF7;

/* g8 */
border: 1px solid #D7DFF0;
box-sizing: border-box;
border-radius: 10px 10px 0px 0px;
 
}

.sortable tr td:nth-child(4) {
  text-align: left;
}

.sortable tr td:nth-child(5) {
  text-align: left;
}

.sortable tr td:nth-child(6) {
  text-align: left;
}



.sortable tr th {
    border-right: 0px;
    padding: 15px 0;font-size: 13px;
      color: #6F83AA;
   cursor: pointer;
   text-align: center;

}

.dataTables_info { display: none; }
#addpaymenttable_paginate { display: none;}
#addpaymenttable_filter input {display:none;}

.sortable tr td {
    border-right: 0px;
    padding: 5px 5px;
    text-align: center;font-size: 13px;
    min-width:50px;vertical-align: middle;
}
.sortable tr td a {
    color: #364159;
}

#profile-right h2 {
    margin: 0px 0px 10px 0px;
}
#paymentlist_filter input { padding-top:4px;background: #fff url('<?php echo base_url(); ?>/images/search.png') no-repeat center left;background-position-x: 10px;border: 1px solid #D7DFF0; line-height: 32px;margin-left: 10px;width:260px;border-radius: 5px;text-indent: 30px;font-size: 13px;}

.sortable tr td a:hover { text-decoration: underline; }
.dataTables_filter { right:10px !important;}
	.dataTables_processing{height: auto}
	
	.sortable tr th:nth-child(1),.sortable tr th:nth-child(2),.sortable tr th:nth-child(3),.sortable tr th:nth-child(7),.sortable tr th:nth-child(9) {background: #E6EBF7 url(https://admissions.brilliantpala.org//images/datatable/sort_both.png) no-repeat center left;background-position: right;text-align: center;}
	
	.btn-outline-primary {color: #0332AA;border-color: #0332AA;}
.btn {border-radius: 5px;outline: initial!important;box-shadow: none!important;box-shadow: initial!important;font-size: .8rem;padding: .5rem 1.25rem .5rem 1.25rem;transition: background-color box-shadow .1s linear;margin-bottom: 7px}
.btn-outline-primary:not(:disabled):not(.disabled).active, .btn-outline-primary:not(:disabled):not(.disabled):active, .show>.btn-outline-primary.dropdown-toggle,.btn-outline-primary:hover {background-color: #0332AA;border-color: #0332AA;color: #fff;}	
	
.ui-selectmenu-button.ui-button{ width: 125px;margin-top: 10px;float: right;border: 1px solid #D7DFF0;background: #fff;font-size: 13px;color:#536485;padding: 8px;margin-bottom: 4px;}
.ui-menu-item .ui-menu-item-wrapper{font-size: 13px}
	
</style>
<script type="text/javascript">
$(document).ready(function(){	
	
	
	$("#searchtype").selectmenu();
	
	$(document).on("click",".clear",function(){
		
		$("#searchtype").selectmenu('destroy');
	    $("#searchtype").prop('selectedIndex',0);
	    $("#searchtype").selectmenu();
		
	});
		
	$('#paymentlist').DataTable({
            "processing": true,
            "serverSide": true,
            "sPaginationType": "full_numbers",
            "ajax":{
		     "url": "<?php echo base_url('worldlinepg/worldlinepgList') ?>",
		     "dataType": "json",
		     "type": "POST",
				"data":function(data){ 
						
						var searchtype = $("#searchtype").val();
						data.searchcol= searchtype;
						
						}
		     //"data":{  '<?php //echo $this->security->get_csrf_token_name(); ?>' : '<?php //echo $this->security->get_csrf_hash(); ?>' }
					}, 
				 "oLanguage": {
					"sProcessing": "<img src='<?php echo base_url(); ?>images/loader.gif'>"
				},
		'iDisplayLength': 20,
	    "columns": [
		          { "data": "name" },
		          { "data": "studid" },
		          { "data": "courseid" },
		          { "data": "center" },
		          { "data": "referenceid" },
		          { "data": "referenceNo" },
		          { "data": "paymentamount" },
		          { "data": "paymentdate" },
		          { "data": "statuscode" },
		          { "data": "receiptno" },
		          { "data": "action" },
		       ],
		"order": [[ 7, "desc" ]],
		"initComplete" : function() {
						
						var input = $('.dataTables_filter input').unbind(),
							self = this.api(),
							$searchButton = $('<button class="btn btn-outline-primary ml-3 search">')
									   .text('search')
									   .click(function() {
										  self.search(input.val()).draw();
									   }),
							$clearButton = $('<button class="btn btn-outline-primary ml-3 clear">')
									   .text('clear')
									   .click(function() {
										  input.val('');
										  $searchButton.click(); 
									   }) 
						$('.dataTables_filter').append($searchButton, $clearButton);
                                                
                                                 $(input).keyup(function(event){
                                                    if(event.keyCode == 13){
                                                        event.preventDefault();
                                                        $('.search').trigger('click');
                                                    }
                                                });
					}

	    });
	
	
	$(document).on("click",".fetchwordlinepg",function(){
		
		var orderid = $(this).data('orderid');
		var studentid = $(this).data('studentid');
		var courseid = $(this).data('courseid');
		
		$('#paymentupdateModal').modal({show:true});
		
		var studentname = $(this).parent().parent().find("td").eq(0).text();
		var studentno = $(this).parent().parent().find("td").eq(1).text();
		var courseno = $(this).parent().parent().find("td").eq(2).text();
		
		$(".studentname span").html(studentname);
		$(".studentno span").html(studentno);
		$(".courseno span").html(courseno);
		
		$("#paymenttable").html("");
		$(".loader").removeClass('d-none');
		
		 $.ajax({
                type: 'POST',
                url: 'worldlinepg/fetchworldlinepayment',
                data: {"orderid":orderid,"studentid":studentid,"courseid":courseid},
                success: function(response) {
                   //console.log(response);
					var obj1 = $.parseJSON(response);
					
					$(".loader").addClass('d-none');
										
					if(obj1['paymenttable']!=""){
						
						//$(".alert").addClass('alert-success').text("Profile details updated");						
						$("#paymenttable").html(obj1['paymenttable']);
						
						$("#orderid").val(orderid);
						$("#studentid").val(studentid);
						$("#courseid").val(courseid);
						
					}else{
						$(".alert").addClass('alert-danger').text("Payment fetching failed");
					}
					
                }
			 
		 });
		
		
	$(document).on("click",".updatepayment",function(){
		
		var orderid = $("#orderid").val();
		var studentid = $("#studentid").val();
		var courseid = $("#courseid").val();
			
		$(".alert").removeClass('alert-success alert-danger').text("");
		
		if($(".updatepayment").hasClass('process')){
			
			$(".alert").addClass('alert-danger').text("Please wait while progressing...");
			
		}else{
		
			$(".updatepayment").addClass('process');
			$(".alert").removeClass('alert-danger').addClass('alert-success').text("Progressing...");
         				
		var r = confirm("Are you sure to update the payment?");
		
		if(r){
			
			$(".updateloader").removeClass('d-none');
		
		 $.ajax({
                type: 'POST',
                url: 'worldlinepg/updatefetchpayment',
                data: {"orderid":orderid,"studentid":studentid,"courseid":courseid},
                success: function(response) {
                   console.log(response);
					var obj1 = $.parseJSON(response);
					
					$(".updateloader").addClass('d-none');
										
					if(obj1[0]=="success"){
						
						$(".alert").addClass('alert-success').text("Payment successfully updated");
						
						//$("#paymenttable").html(obj1['paymenttable']);
												
						setTimeout(function(){
							$(".updatepayment").removeClass('process');
							$(".alert").removeClass('alert-success').text("");
						},3000);
						
					}else if(obj1[0]=="notfound"){
						$(".updatepayment").removeClass('process');
						$(".alert").addClass('alert-danger').text("Payment not found");
					}else if(obj1[0]=="ufail"){
						$(".updatepayment").removeClass('process');
						$(".alert").addClass('alert-danger').text("Update payment failed");
					}else if(obj1[0]=="pfail"){
						$(".updatepayment").removeClass('process');
						$(".alert").addClass('alert-danger').text("Payment details updated successfully");
					}else if(obj1[0	]==""){
						$(".updatepayment").removeClass('process');
						$(".alert").addClass('alert-danger').text("Please try again.");
					}
					
                }
			 
		 });
			
		}
			
		}
		
		
	});
		
		
		
	$('#paymentupdateModal').on('hidden.bs.modal', function () {
  		
		$(".loader,.updateloader").addClass('d-none');
		$(".alert").removeClass('alert-success alert-danger').text("");
		
	});
		
		
	});
	
});
</script>


<div class="wrap dynamic-width" style="float: left;position: relative">
          
<div style="margin-top: 10px; width: 100%; height: 50px; text-align: right;">
	<span style="font-weight: bold;font-size: 20px;padding: 10px;float:left;color: #364159">Worldline Payment Lists</span>
</div>
                 
<style>

	.courseredirect{background: #3CAF92 !important;display: block;margin: auto;border: 1px solid #209679;}
	h5.modal-title p.headtitle{display: inline-block;width: 100%;text-align: center;font-weight: bold;font-size:17px;color: #fff;}
	h5.modal-title p.text-muted{display: inline-block;width: 100%;text-align: center;font-weight: 600;font-size: 14px;line-height: 36px;color: #181E29;line-height: 20px;}
	.modal-title img{display: block;margin: 1em auto}
	#paydoneModal.modal .modal-header,#payfailModal.modal .modal-header{padding: 10px 20px !important;border: none}	
	#paydoneModal.modal .modal-body,#payfailModal.modal .modal-body{padding:0 1.75rem 1.75rem}
	.modal-body p{text-align: left !important}
	.modal-backdrop.show {opacity: .5 !important;}
	
	.fetchwordlinepg button{min-height: 20px;padding: 0 10px;font-size: 13px;border-radius: 3px}
	
	.alert{font-size: 14px;}
	.maincontent p.alert-success {color: #155724;}
	.maincontent p.alert-danger {color: #721c24;}
	
</style>

<div class="row align-items-end">
                 <div class="col-7">
                     <select id="searchtype">
                         <option value="stuid">Student ID</option>
                         <option value="stuname">Student Name</option>
                         <option value="billno">Bill No</option>
                         <option value="orderid">Order ID</option>
                         <option value="refno">Referece No</option>
                         <option value="courseid">Course ID</option>
                         <option value="center">Center</option>
                     </select>
                 </div>                                                                           
    		</div> 

<div class="row">
	<div class="col-md-12">
               <table class="sortable disabled table table-bordered" id="paymentlist">
                    <thead>
                           <th>Student Name</th>
                           <th>Student ID</th>
                           <th>Course ID</th>
                           <th>Center</th>
                           <th>Order ID</th>
                           <th>Reference No</th>
                           <th>Amount</th>
                           <th>Date & Time</th>
                           <th>Status</th>	
                           <th>Bill Number</th>	
                           <th>Action</th>
                    </thead>				
               </table>
        </div>
</div>


</div>  


	<style>
		
		#paymentupdateModal.modal .modal-header{padding: 5px 10px !important;border: none}	
		#paymentupdateModal.modal .modal-body{padding:0 1.75rem 1.75rem}
		.modal-body p{text-align: left !important}
		.modal-backdrop.show {opacity: .5 !important;}
		#paymentupdateModal h2{line-height: 24px;}
		
		#paymenttable table{width: 100%;border-collapse: collapse;}
		#paymenttable table td:nth-child(odd){width: 40%}
		#paymenttable table td:nth-child(even){width: 60%}
		#paymenttable table th,#paymenttable table td{border: 1px solid #333;width: 50%;text-align: left;padding: 5px 10px}
		.loader p{text-align: center !important;}
		
		.studentdetails p span{font-weight: bold;display: block}
		
		label{color: #4F70C4;}
		
	</style>
	
	<div id="paymentupdateModal" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
		<div class="modal-dialog modal-lg" role="document">
			<div class="modal-content">
				<div class="modal-header">
				   <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				</div>
				<div class="modal-body text-center">
									
					<h2 class="mb-4 mt-0 text-center">Worldline Payment</h2>
										
					<div class="row studentdetails">
						<div class="col-md-4"><p class="studentname"><label>Student Name:</label> <span><strong>test</strong></span></p></div>
						<div class="col-md-4"><p class="studentno"><label>Student ID:</label> <span><strong>2342334</strong></span></p></div>
						<div class="col-md-4"><p class="courseno"><label>Course ID:</label> <span><strong>234</strong></span></p></div>
					</div>
					
					<div class="loader d-none">
						<img src='<?php echo base_url(); ?>images/loader.gif'>
						<p>Feching data...</p>
						</div>
					
					<div id="paymenttable"></div>
					
					<input type="hidden" id="orderid" value="" />
					<input type="hidden" id="studentid" value="" />
					<input type="hidden" id="courseid" value="" />
										
				</div>
				<div class="modal-footer">
				
					<p class="alert mb-0"></p>
					
					<button type="button" class="btn btn-primary updatepayment"><img src='<?php echo base_url(); ?>images/loader.gif' class="updateloader d-none mr-2">Update Payment</button>
					<button type="button" class="btn btn-outline-primary modalclose" data-dismiss="modal">Close</button>
				</div>
								
			</div>
		</div>
	</div>

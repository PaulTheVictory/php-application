<<<<<<< .mine
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/dataTables.css?v=1.5" />
<script src="<?php echo base_url(); ?>js/jquery.dataTables.js?v=1.0" type="text/javascript"></script>
 <link href="<?php  echo base_url(); ?>css/jquery-ui.min.css?v=1.4" rel="stylesheet" type="text/css" />
 <script src="<?php  echo base_url(); ?>js/jquery-ui.min.js?v=1.3" type="text/javascript"></script>
<style type="text/css">
    
.reportsTable thead tr  {
    background: #E6EBF7;

/* g8 */
border: 1px solid #D7DFF0;
box-sizing: border-box;
border-radius: 10px 10px 0px 0px;
 

}

    .reportsTable tr th {
        border-right: 0px;
    font-size: 13px;
      color: #6F83AA;
   cursor: pointer;
   text-align: center;padding: 4px;
   width: 5%;vertical-align: middle;
    }  
    
  .reportsTable tr { background: #fff;border-bottom: 1px solid #D7DFF0;}
.reportsTable tr td {
    border-right: 0px;
    padding: 5px 5px;
    text-align: center;font-size: 13px;
    vertical-align: middle;
}

    
     
    .reportsTable tr td:nth-child(4) {
  width: 15% !important;
}


.ui-selectmenu-button.ui-button{ width: 50%; padding:10px;padding-right: 0px;}
     #centers-button,#rtype-button{border: 1px solid #D7DFF0;background: #fff;font-size: 14px;color:#536485}
     .loader {
    display: none;
    position: absolute;
    top: 0; left: 0; right: 0; bottom: 0;
    background: rgba(255,255,255,0.8) url('<?php echo base_url(); ?>images/loader.gif') center center no-repeat;
    z-index: 1000;
}
</style>
<script type="text/javascript">
    
    $(window).load(function () {
    $(".loader").hide();   
    });
  
$(document).ready(function(){	

         $("#centers").selectmenu(); 
         
         var rtype = '<?php echo $type; ?>';
         $("#rtype").val(rtype);
         
         $("#rtype").selectmenu();
         
         $(".adtime").datetimepicker({
  dateFormat: "yy-mm-dd"
    });
         
        
         
  $("#billSearch").click(function(){
     
     var sdate = $(".fromdate").val();
     var edate = $(".todate").val();
     var center = $("#centers").val();
     var rtype = $("#rtype").val();
     $(".loader").show();
     var url = 'reports?sdate='+sdate+'&edate='+edate+'&center='+center+"&rtype="+rtype;
       $(location).prop('href', url);
     
  });
  
  $("#export").click(function(){
     
     var sdate = $(".fromdate").val();
     var edate = $(".todate").val();
     var center = $("#centers").val();
     var rtype = $("#rtype").val();
    
     var url = 'reports/export?sdate='+sdate+'&edate='+edate+'&center='+center+"&rtype="+rtype;
       $(location).prop('href', url);
     
  });
  
  
   $("#bulkprint").click(function(){
      
      var sdate = $(".fromdate").val();
     var edate = $(".todate").val();
     var center = $("#centers").val();
      var url = 'reports?sdate='+sdate+'&edate='+edate+'&center='+center+"&rtype=bulkprint";
       window.open(url, '_blank');
      
  });
  
                });
</script>

<?php $title['cr'] = "Collection Report";$title['cwd'] = "Course Wise Admitted List";
$title['dca'] = "Course Applied List";$title['sl'] = "Signup List";
$title['bl'] = "Bill List";$title['ul'] = "Unpaid List";$title['stunpl'] = "New Student First Paid List";$title['rfl'] = "Refund Paid List";?>
<div class="wrap dynamic-width" style="float: left;position: relative;">
   
    <div style="margin-top: 10px; width: 100%; height:310px; text-align: right;">       
             <span style="font-weight: bold;font-size: 20px;padding: 10px;float:left;color: #364159">Report Summary - <?php echo $title[$type];?></span>
             <div class="row-element">
                 <span class="title" style="padding: 0px;padding-left: 10px;color: #6F83AA;margin-top: 14px;">Date</span>                    
                    <span class="content" style="padding: 0px;color:#0332AA;font-weight: bold;min-width: 250px;width: 100px">
                          <input type="text" value="<?php echo date("Y/m/d H:i",strtotime($sdate));?>" name = "fromdate" class="fromdate adtime" style="width: 90%;margin: 5px;background: #fff url('<?php echo base_url(); ?>/images/cal.png') no-repeat 95%;">  
                        </span>
                 <span class="content" style="padding: 0px;color:#0332AA;font-weight: bold;min-width: 250px;width: 100px">
                        <input type="text" value="<?php echo date("Y/m/d H:i",strtotime($edate));?>" name = "todate" class="todate adtime" style="width: 90%;margin: 5px;background: #fff url('<?php echo base_url(); ?>/images/cal.png') no-repeat 95%;">    
                        </span>
                </div>
             <!--div class="row-element">
                 <span class="title" style="padding: 0px;padding-left: 10px;color: #6F83AA">To Date</span>                    
                    <span class="content" style="padding: 0px;color:#0332AA;font-weight: bold">
                        <input type="text" value="<?php echo date("Y/m/d H:i",strtotime($edate));?>" name = "todate" class="todate adtime" style="width: 50%;margin: 5px;background: #fff url('<?php echo base_url(); ?>/images/cal.png') no-repeat 98%;">    
                        </span>
                </div-->
             <div class="row-element">
                 <span class="title" style="padding: 0px;padding-left: 10px;color: #6F83AA">Centers</span>                    
                    <span class="content" style="padding: 0px;color:#0332AA;font-weight: bold">
                        <select  id="centers" name = "centers" class="centers" style="width: 50%;font-size: 13px;float:left">
                            <option value="All" >All</option>
                            <?php echo $units;?>
                        </select>
                        </span>
                </div>
             
             <div class="row-element">
                 <span class="title" style="padding: 0px;padding-left: 10px;color: #6F83AA">Report Type</span>                    
                    <span class="content" style="padding: 0px;color:#0332AA;font-weight: bold">
                        <select  id="rtype" name = "rtype" class="rtype" style="width: 50%;font-size: 13px;float:left">
                            <option value="cr" >Accounts Report</option>
                            <option value="cwd" >Course wise Admitted List</option>
                            <option value="dca" >Course Applied List</option>
                            <option value="sl" >Signup List</option>
                            <option value="bl" >Bill List</option>
                            <option value="ul" >Unpaid List</option>
                            <option value="stunpl" >New Student First Paid List</option>
                            <option value="rfl" >Refund Paid List</option>
                            <option value="wll" >Worldline List</option>
                        </select>
                        </span>
                </div>
             <div class="row-element">
                 <span class="title" style="padding: 0px;padding-left: 10px;color: #6F83AA;visibility: hidden">Search</span>                    
                    <span class="content" style="padding: 0px;color:#0332AA;font-weight: bold">
                       <span id="billSearch" style="cursor: pointer;margin-left:20px;font-weight: bold;font-size: 14px;padding: 5px 10px;color: #fff;border-radius:5px;background: linear-gradient(180deg, #4F70C4 0%, #1C47B3 100%);">Search</span>    
                       <span id="export" style="cursor: pointer;margin-left:20px;font-weight: bold;font-size: 14px;padding: 5px 10px;color: #fff;border-radius:5px;background: linear-gradient(180deg, #4F70C4 0%, #1C47B3 100%);">Export</span>    
                       <?php if($type === 'bl') { ?>
                       <span id="bulkprint" style="cursor: pointer;margin-left:20px;font-weight: bold;font-size: 14px;padding: 5px 10px;color: #fff;border-radius:5px;background: linear-gradient(180deg, #4F70C4 0%, #1C47B3 100%);">Bulk Print</span>    
                       <?php } ?>
                    </span>    
                    </span>
                </div>
             
             
            </div>  
    <?php if($type === 'cr') { ?>
    <div class="row-element"style="margin-bottom: 0px;margin-top: 30px">
        <span class="title" style="font-weight:bold;margin-bottom: 0px;padding: 0px;padding-left: 10px;color: #6F83AA;width:100%">Bill Generation Summary <?php echo date("Y-m-d H:i",strtotime($sdate));?> to <?php echo date("Y-m-d H:i",strtotime($edate));?> <?php if(array_key_exists("count", $reports)){ echo 'Bill Number ('.$reports['billno'].') '.$reports['count']." Bills";}?></span>                    
     </div>
    <?php } ?>
    <div class="row-element" style="margin-top: 0px"><div class="loader"></div>
        <table class="reportsTable">
            
                
                <?php if($type === 'cr') { 
                          
                    $html = '<thead><tr><th>S.nO</th><th>Counter Id</th><th>Counter name</th><th>Description</th><th>Reg Fee</th><th>Tuition Fee</th><th>S.Tax / <br>CGST</th><th>SB <br>CESS/<br>SGST</th><th>KK <br>CESS/<br>IGST/<br>KFC</th><th>CD</th><th>Other</th><th>Total</th><th>Cash</th><th>Card</th><th>Cheque</th><th>DD</th><th>SIB <br>Challan</th><th>Transfer</th><th>Online</th><th>Total</th><th>TDS</th></tr></thead>';
                    $i = 1; $mregFee = 0;$mtutionFee = 0;$mcgst = 0;$msgst = 0;
                    $mkf = 0;$mcd = 0;$mother = 0;$mtotal = 0;$mcash = 0;$mcard = 0;
                    $mcheque = 0;$mdd = 0;$mchallan = 0;$mtransfer = 0;$monline = 0;$mother1 = 0;$mpaid = 0;
                    foreach ($reports as $key=>$val){
                        if(($key === "count")||($key === "billno")) {continue;}
                        $coursename = array_key_exists('cname', $val)?$val['cname']:"";
                        $regFee = array_key_exists('Reg Fee', $val)?$val['Reg Fee']:0;
                        $tutionFee = array_key_exists('Tuition Fee', $val)?$val['Tuition Fee']:0;
                        $cd = array_key_exists('CD', $val)?$val['CD']:0;
                        $total = array_key_exists('total', $val)?$val['total']:0;
                        $paid = array_key_exists('paid', $val)?$val['paid']:0;
                        $tutionFee = round($tutionFee);

                        $cash = array_key_exists('cash', $val)?$val['cash']:0;
                        $dd = array_key_exists('dd', $val)?$val['dd']:0;
                        $challan = array_key_exists('challan', $val)?$val['challan']:0;
                        if($challan === 0 ) {$challan = array_key_exists('chellan', $val)?$val['chellan']:0;}
                        $transfer = array_key_exists('net', $val)?$val['net']:0;
                        $online = array_key_exists('online', $val)?$val['online']:0;
                        $card = array_key_exists('card', $val)?$val['card']:0;
                        $cheque = array_key_exists('cheque', $val)?$val['cheque']:0;

                        $calamount = floatval($regFee)+floatval($tutionFee);
                        $cgst = floatval($calamount)*.09;
                        $sgst = floatval($calamount)*.09;
                        $kf   = floatval($calamount)*.01;

                        $other = floatval($total) - (floatval($calamount)+floatval($cgst)+floatval($sgst)+floatval($kf)+floatval($cd));
                        $other1 = (floatval($cash)+floatval($dd)+floatval($challan)+floatval($transfer)+floatval($online)+floatval($card)+floatval($cheque))-floatval($paid);
                        $other = round($other,2);
                        $other1 = round($other1,2);
                        $cgst = round($cgst,2);
                        $sgst = round($sgst,2);
                        $kf = round($kf,2);

                        $html .= '<tr><td>'.$i.'</td><td>ALL</td><td>'.$center.'</td><td>'.$coursename.'</td><td>'.$regFee.'</td><td>'.$tutionFee.'</td><td>'.$cgst.'</td><td>'.$sgst.'</td><td>'.$kf.'</td><td>'.$cd.'</td><td>'.$other.'</td><td>'.$total.'</td><td>'.$cash.'</td><td>'.$card.'</td><td>'.$cheque.'</td><td>'.$dd.'</td><td>'.$challan.'</td><td>'.$transfer.'</td><td>'.$online.'</td><td>'.$paid.'</td><td>0</td></tr>';
                        $i++;
                        $mregFee = floatval($mregFee)+floatval($regFee);$mtutionFee = floatval($mtutionFee)+floatval($tutionFee);
                        $mcgst = floatval($mcgst)+floatval($cgst);$msgst = floatval($msgst)+floatval($sgst);$mkf = floatval($mkf)+floatval($kf);
                        $mcd = floatval($mcd)+floatval($cd);$mother = floatval($mother)+floatval($other);$mtotal = floatval($mtotal)+floatval($total);
                        $mcash = floatval($mcash)+floatval($cash);$mcard = floatval($mcard)+floatval($card); $mcheque = floatval($mcheque)+floatval($cheque);
                        $mdd = floatval($mdd)+floatval($dd);$mchallan = floatval($mchallan)+floatval($challan);$mtransfer = floatval($mtransfer)+floatval($transfer);
                        $monline = floatval($monline)+floatval($online);$mother1 = 0;$mpaid = floatval($mpaid)+floatval($paid);
                    }
                    if($i === 1) { echo '<tr><td colspan="22">No data available</td><tr>';} else{
                     
                    $html .= '<tr><td></td><td></td><td></td><td></td><td>'.$mregFee.'</td><td>'.$mtutionFee.'</td><td>'.$mcgst.'</td><td>'.$msgst.'</td><td>'.$mkf.'</td><td>'.$mcd.'</td><td>'.$mother.'</td><td>'.$mtotal.'</td><td>'.$mcash.'</td><td>'.$mcard.'</td><td>'.$mcheque.'</td><td>'.$mdd.'</td><td>'.$mchallan.'</td><td>'.$mtransfer.'</td><td>'.$monline.'</td><td>'.$mpaid.'</td><td>0</td></tr>';
                    }

                    echo $html;
           
       
           } else if($type === 'cwd'){ 
              
                    $html = '<thead><tr><th>S.no</th><th style="width: 30%">Course Name</th><th>Center</th><th>Student ID</th><th style="width: 10%">Student Name</th><th>Country Code</th><th>Mobile Number</th><th>Whats App No.</th><th>Email ID</th><th style="width: 20%">Qualification</th><th>Stream</th><th>Course Fee</th><th>Remitted</th><th>Initial Payment Date</th></tr></thead>';
                    $i = 1;
                    foreach ($reports as $key=>$val){
                        $html .= '<tr><td>'.$i.'</td><td>'.$val['coursename'].'</td><td>'.$val['center'].'</td><td>'.$val['studid'].'</td><td>'.$val['sname'].'</td><td>'.$val['mcode'].'</td><td>'.$val['contact'].'</td><td>'.$val['whatsappno'].'</td><td>'.$val['email'].'</td><td>'.$val['name'].'</td><td>'.$val['stream'].'</td><td>'.$val['total'].'</td><td>'.$val['remitted'].'</td><td>'.$val['pdate'].'</td> </tr>';
                        $i++;
                    }
                    if($i === 1) { echo '<tr><td colspan="13">No data available</td><tr>';} 
                    echo $html;
           
         
                 } else if($type === 'dca'){ 
                    $html = '<thead><tr><th>S.no</th><th>Student ID</th><th style="width: 20%">Student Name</th><th>Country Code</th><th>Mobile Number</th><th>Email ID</th><th style="width: 20%">Qualification</th><th>Stream</th><th style="width: 20%">Applied Course</th><th>Center</th><th>Present Status</th><th>Date of Registration</th></tr></thead>';
                    $i = 1;
                    foreach ($reports as $key=>$val){
                        $html .= '<tr><td>'.$i.'</td><td>'.$val['studid'].'</td><td>'.$val['sname'].'</td><td>'.$val['mcode'].'</td><td>'.$val['contact'].'</td><td>'.$val['email'].'</td><td>'.$val['qualification'].'</td><td>'.$val['stream'].'</td><td>'.$val['coursename'].'</td><td>'.$val['center'].'</td><td>'.$val['status'].'</td><td>'.$val['rdate'].'</td></tr>';
                        $i++;
                    }
                    if($i === 1) { echo '<tr><td colspan="11">No data available</td><tr>';} 
                    echo $html;
                 
                  }else if($type === 'sl'){ 
                 
                    $html = '<thead><tr><th style="width: 5%">S.no</th><th >Student ID</th><th style="width: 20%">Student Name</th><th>Country Code</th><th>Mobile Number</th><th>Email ID</th><th style="width: 20%">Qualification</th></tr></thead>';
                    $i = 1;
                    foreach ($reports as $key=>$val){
                        $html .= '<tr><td>'.$i.'</td><td>'.$val['studid'].'</td><td>'.$val['sname'].'</td><td>'.$val['mcode'].'</td><td>'.$val['contact'].'</td><td>'.$val['email'].'</td><td>'.$val['qualification'].'</td></tr>';
                        $i++;
                    }
                    if($i === 1) { echo '<tr><td colspan="6">No data available</td><tr>';} 
                    echo $html;
                  } else if($type === 'bl'){
                      
                  $i= 1;                 
                    $html = '<thead><tr><th style="width: 5%">S.no</th><th >Student ID</th><th >CHL ID</th><th >Date</th><th >Bill No</th><th style="width: 20%">Student Name</th><th style="width: 20%">Course Name</th><th>Center</th><th>Paid</th><th>Payment Mode</th></tr></thead>';
                    
                    foreach ($reports as $key=>$val){
                        $html .= '<tr><td>'.$i.'</td><td>'.$val['studid'].'</td><td>'.$val['challanno'].'</td><td>'.$val['paydate'].'</td><th >'.$val['receiptno'].'</th><td>'.$val['sname'].'</td><td>'.$val['coursename'].'</td><td>'.$val['center'].'</td><td>'.$val['paid'].'</td><td>'.$val['paymentmode'].'</td></tr>';
                        $i++;
                    }
                    
                    if($i === 1) { echo '<tr><td colspan="9">No data available</td><tr>';} 
                    echo $html;
                  } else if($type === 'ul'){
                      
                    $html = '<thead><tr><th style="width: 5%">S.no</th><th >Student ID</th><th >CHL ID</th><th style="width: 20%">Student Name</th><th style="width: 20%">Course Name</th><th>Center</th><th>Unpaid</th></tr></thead>';
                    $i = 1;
                    foreach ($reports as $key=>$val){
                        $html .= '<tr><td>'.$i.'</td><td>'.$val['studid'].'</td><td>'.$val['challanno'].'</td><td>'.$val['sname'].'</td><td>'.$val['coursename'].'</td><td>'.$val['center'].'</td><td>'.$val['unpaid'].'</td></tr>';
                        $i++;
                    }
                    
                    if($i === 1) { echo '<tr><td colspan="7">No data available</td><tr>';} 
                    echo $html;
                    
                  } else if($type === 'stunpl'){
                      
                    $html = '<thead><tr><th >S.no</th><th >Student ID</th><th >Student Name</th><th>Country Code</th><th>Mobile No</th><th>Email</th><th>City</th><th>Date of Birth:</th><th>Gender</th><th>Nationality</th><th>Category</th><th>Aadhar Number</th><th>Fathers Name</th><th>Country Code</th><th>Fathers Phone</th><th>Fathers Email</th><th>Fathers Occupation</th><th>Mothers Name</th><th>Country Code</th><th>Mothers Phone</th><th>Mothers Email</th><th>Mothers Occupation</th><th>Communication Contact</th><th>Blood Group</th><th>Class Studying / Complete</th><th>Stream</th><th>Name of School Last Studied / Studying</th><th>Address Line</th><th>Country</th><th>House / Appartment Name</th><th>Place / Street</th><th>Post Office</th><th>District</th><th>State</th><th>Country</th><th>Pincode</th><th>Country Code</th><th>Whatsapp Number</th><th>Guardian Name</th><th>Account Holder Name</th><th>Bank Name</th><th>Branch</th><th>IFSC Code</th><th>Bank Account Number</th><th>profile Percentage</th><th>Course Name</th><th>Center</th><th>Payment Date</th><th>Bill No</th><th>Paid</th><th>Payment Mode</th></tr></thead>';
                    $i = 1;
                    foreach ($reports as $key=>$val){
                        $landmark = ($val['landmark'] === "0")?"":$val['landmark'].",";
                        $html .= '<tr><td>'.$i.'</td><td>'.$val['studid'].'</td><td>'.$val['sname'].'</td><td>'.$val['mcode'].'</td><td>'.$val['contact'].'</td><td>'.$val['email'].'</td><td>'.$val['city'].'</td><td>'.$val['dob'].'</td><td>'.$val['gender'].'</td><td>'.$val['nationality'].'</td><td>'.$val['category'].'</td><td>'.$val['aadharnumber'].'</td><td>'.$val['fathername'].'</td><td>'.$val['fathercode'].'</td><td>'.$val['fatherphone'].'</td><td>'.$val['fatheremail'].'</td><td>'.$val['fatheroccupation'].'</td><td>'.$val['mothername'].'</td><td>'.$val['mothercode'].'</td><td>'.$val['motherphone'].'</td><td>'.$val['motheremail'].'</td><td>'.$val['motheroccupation'].'</td><td>'.$val['communicationcontact'].'</td><td>'.$val['bloodgroup'].'</td><td>'.$val['classstudy'].'</td><td>'.$val['stream'].'</td><td>'.$val['schoolcollegename'].'</td><td>'.$val['eduaddress'].",".$val['edulandmark'].",".$val['edudistrict'].",".$val['edustate'].",".$val['edupost'].",".$val['edupincode'].'</td><td>'.$val['educountry'].'</td><td>'.$val['housenameno'].'</td><td>'.$landmark.$val['contactaddress'].'</td><td>'.$val['contactpost'].'</td><td>'.$val['contactdistrict'].'</td><td>'.$val['contactstate'].'</td><td>'.$val['contactcountry'].'</td><td>'.$val['contactpincode'].'</td><td>'.$val['wacode'].'</td><td>'.$val['whatsappno'].'</td><td>'.$val['guardianname'].'</td><td>'.$val['accountholdername'].'</td><td>'.$val['bankname'].'</td><td>'.$val['branch'].'</td><td>'.$val['ifsccode'].'</td><td>'.$val['bankaccountno'].'</td><td>'.$val['profilepercent'].'</td><td>'.$val['coursename'].'</td><td>'.$val['center'].'</td><td>'.$val['paydate'].'</td><td>'.$val['receiptno'].'</td><td>'.$val['paid'].'</td><td>'.$val['paymentmode'].'</td></tr>';
                        $i++;
                    }
                    
                    if($i === 1) { echo '<tr><td colspan="47">No data available</td><tr>';} 
                    echo $html;
                  } else if($type === 'rfl'){
                      
                    $reports = $this->reports_model->RefundBillList($sdate,$edate,$center);
                    $savename = "Refund_Paid_Report_".date('d-m-Y-H_i_s');
                      
                        $html = '<thead><tr><th >S.no</th><th >App Date</th><th >App No</th><th >Student ID</th><th>Student Name</th><th>Course Name</th><th>Center</th><th>Refund Bill No</th><th>Remitted(without GST)</th><th>Refund Amount(without GST)</th><th>Trans Details</th><th>Reason For Refund</th></tr></thead>';
                    $i = 1;
                    foreach ($reports as $key=>$val){
                        
                        $html .= '<tr><td>'.$i.'</td><td>'.$val['appdate'].'</td><td>'.$val['appno'].'</td><td style="width:5% !important">'.$val['studid'].'</td><td>'.$val['sname'].'</td><td style="width:15% !important">'.$val['coursename'].'</td><td>'.$val['center'].'</td><td>'.$val['receiptno'].'</td><td style="width:5% !important">'.$val['remitted'].'</td><td style="width:5% !important">'.$val['refundamount'].'</td><td>'.$val['paydescription'].'</td><td>'.$val['reason'].'</td></tr>';
                        $i++;
                    }
                    
                    if($i === 1) { echo '<tr><td colspan="11">No data available</td><tr>';} 
                    echo $html;
                  } else if($type === 'wll'){
                      
                    $reports = $this->reports_model->WorldlineBillList($sdate,$edate,$center);
                    $savename = "Worldline_Report_".date('d-m-Y-H_i_s');
                      
                        $html = '<thead><tr><th >S.no</th><th >Student Name</th><th >Student ID</th><th >Course ID</th><th>Center</th><th>Order ID</th><th>Reference No</th><th>Amount</th><th>Date & Time</th><th>Status</th><th>Bill Number</th></tr></thead>';
                    $i = 1;
                    foreach ($reports as $key=>$val){
                        
                        $html .= '<tr><td>'.$i.'</td><td>'.$val['sname'].'</td><td>'.$val['studid'].'</td><td style="width:5% !important">'.$val['courseid'].'</td><td>'.$val['center'].'</td><td>'.$val['referenceid'].'</td><td style="width:15% !important">'.$val['referenceNo'].'</td><td>'.$val['paymentamount'].'</td><td style="width:5% !important">'.$val['paymentdate'].'</td><td style="width:5% !important">'.$val['statuscode'].'</td><td>'.$val['receiptno'].'</td></tr>';
                        $i++;
                    }
                    
                    if($i === 1) { echo '<tr><td colspan="10">No data available</td><tr>';} 
                    echo $html;
                  } 
               
                 
                 ?>
        </table>
              
         
        </div>
        
        </div>
    
 
    

||||||| .r336
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/dataTables.css?v=1.5" />
<script src="<?php echo base_url(); ?>js/jquery.dataTables.js?v=1.0" type="text/javascript"></script>
 <link href="<?php  echo base_url(); ?>css/jquery-ui.min.css?v=1.4" rel="stylesheet" type="text/css" />
 <script src="<?php  echo base_url(); ?>js/jquery-ui.min.js?v=1.3" type="text/javascript"></script>
<style type="text/css">
    
.reportsTable thead tr  {
    background: #E6EBF7;

/* g8 */
border: 1px solid #D7DFF0;
box-sizing: border-box;
border-radius: 10px 10px 0px 0px;
 

}

    .reportsTable tr th {
        border-right: 0px;
    font-size: 13px;
      color: #6F83AA;
   cursor: pointer;
   text-align: center;padding: 4px;
   width: 5%;vertical-align: middle;
    }  
    
  .reportsTable tr { background: #fff;border-bottom: 1px solid #D7DFF0;}
.reportsTable tr td {
    border-right: 0px;
    padding: 5px 5px;
    text-align: center;font-size: 13px;
    vertical-align: middle;
}

    
     
    .reportsTable tr td:nth-child(4) {
  width: 15% !important;
}


.ui-selectmenu-button.ui-button{ width: 50%; padding:10px;padding-right: 0px;}
     #centers-button,#rtype-button{border: 1px solid #D7DFF0;background: #fff;font-size: 14px;color:#536485}
     .loader {
    display: none;
    position: absolute;
    top: 0; left: 0; right: 0; bottom: 0;
    background: rgba(255,255,255,0.8) url('<?php echo base_url(); ?>images/loader.gif') center center no-repeat;
    z-index: 1000;
}
</style>
<script type="text/javascript">
    
    $(window).load(function () {
    $(".loader").hide();   
    });
  
$(document).ready(function(){	

         $("#centers").selectmenu(); 
         
         var rtype = '<?php echo $type; ?>';
         $("#rtype").val(rtype);
         
         $("#rtype").selectmenu();
         
         $(".adtime").datetimepicker({
  dateFormat: "yy-mm-dd"
    });
         
        
         
  $("#billSearch").click(function(){
     
     var sdate = $(".fromdate").val();
     var edate = $(".todate").val();
     var center = $("#centers").val();
     var rtype = $("#rtype").val();
     $(".loader").show();
     var url = 'reports?sdate='+sdate+'&edate='+edate+'&center='+center+"&rtype="+rtype;
       $(location).prop('href', url);
     
  });
  
  $("#export").click(function(){
     
     var sdate = $(".fromdate").val();
     var edate = $(".todate").val();
     var center = $("#centers").val();
     var rtype = $("#rtype").val();
    
     var url = 'reports/export?sdate='+sdate+'&edate='+edate+'&center='+center+"&rtype="+rtype;
       $(location).prop('href', url);
     
  });
  
  
   $("#bulkprint").click(function(){
      
      var sdate = $(".fromdate").val();
     var edate = $(".todate").val();
     var center = $("#centers").val();
      var url = 'reports?sdate='+sdate+'&edate='+edate+'&center='+center+"&rtype=bulkprint";
       window.open(url, '_blank');
      
  });
  
                });
</script>

<?php $title['cr'] = "Collection Report";$title['cwd'] = "Course Wise Admitted List";
$title['dca'] = "Course Applied List";$title['sl'] = "Signup List";
$title['bl'] = "Bill List";$title['ul'] = "Unpaid List";$title['stunpl'] = "New Student First Paid List";$title['rfl'] = "Refund Paid List";?>
<div class="wrap dynamic-width" style="float: left;position: relative;">
   
    <div style="margin-top: 10px; width: 100%; height:310px; text-align: right;">       
             <span style="font-weight: bold;font-size: 20px;padding: 10px;float:left;color: #364159">Report Summary - <?php echo $title[$type];?></span>
             <div class="row-element">
                 <span class="title" style="padding: 0px;padding-left: 10px;color: #6F83AA;margin-top: 14px;">Date</span>                    
                    <span class="content" style="padding: 0px;color:#0332AA;font-weight: bold;min-width: 250px;width: 100px">
                          <input type="text" value="<?php echo date("Y/m/d H:i",strtotime($sdate));?>" name = "fromdate" class="fromdate adtime" style="width: 90%;margin: 5px;background: #fff url('<?php echo base_url(); ?>/images/cal.png') no-repeat 95%;">  
                        </span>
                 <span class="content" style="padding: 0px;color:#0332AA;font-weight: bold;min-width: 250px;width: 100px">
                        <input type="text" value="<?php echo date("Y/m/d H:i",strtotime($edate));?>" name = "todate" class="todate adtime" style="width: 90%;margin: 5px;background: #fff url('<?php echo base_url(); ?>/images/cal.png') no-repeat 95%;">    
                        </span>
                </div>
             <!--div class="row-element">
                 <span class="title" style="padding: 0px;padding-left: 10px;color: #6F83AA">To Date</span>                    
                    <span class="content" style="padding: 0px;color:#0332AA;font-weight: bold">
                        <input type="text" value="<?php echo date("Y/m/d H:i",strtotime($edate));?>" name = "todate" class="todate adtime" style="width: 50%;margin: 5px;background: #fff url('<?php echo base_url(); ?>/images/cal.png') no-repeat 98%;">    
                        </span>
                </div-->
             <div class="row-element">
                 <span class="title" style="padding: 0px;padding-left: 10px;color: #6F83AA">Centers</span>                    
                    <span class="content" style="padding: 0px;color:#0332AA;font-weight: bold">
                        <select  id="centers" name = "centers" class="centers" style="width: 50%;font-size: 13px;float:left">
                            <option value="All" >All</option>
                            <?php echo $units;?>
                        </select>
                        </span>
                </div>
             
             <div class="row-element">
                 <span class="title" style="padding: 0px;padding-left: 10px;color: #6F83AA">Report Type</span>                    
                    <span class="content" style="padding: 0px;color:#0332AA;font-weight: bold">
                        <select  id="rtype" name = "rtype" class="rtype" style="width: 50%;font-size: 13px;float:left">
                            <option value="cr" >Accounts Report</option>
                            <option value="cwd" >Course wise Admitted List</option>
                            <option value="dca" >Course Applied List</option>
                            <option value="sl" >Signup List</option>
                            <option value="bl" >Bill List</option>
                            <option value="ul" >Unpaid List</option>
                            <option value="stunpl" >New Student First Paid List</option>
                            <option value="rfl" >Refund Paid List</option>
                        </select>
                        </span>
                </div>
             <div class="row-element">
                 <span class="title" style="padding: 0px;padding-left: 10px;color: #6F83AA;visibility: hidden">Search</span>                    
                    <span class="content" style="padding: 0px;color:#0332AA;font-weight: bold">
                       <span id="billSearch" style="cursor: pointer;margin-left:20px;font-weight: bold;font-size: 14px;padding: 5px 10px;color: #fff;border-radius:5px;background: linear-gradient(180deg, #4F70C4 0%, #1C47B3 100%);">Search</span>    
                       <span id="export" style="cursor: pointer;margin-left:20px;font-weight: bold;font-size: 14px;padding: 5px 10px;color: #fff;border-radius:5px;background: linear-gradient(180deg, #4F70C4 0%, #1C47B3 100%);">Export</span>    
                       <?php if($type === 'bl') { ?>
                       <span id="bulkprint" style="cursor: pointer;margin-left:20px;font-weight: bold;font-size: 14px;padding: 5px 10px;color: #fff;border-radius:5px;background: linear-gradient(180deg, #4F70C4 0%, #1C47B3 100%);">Bulk Print</span>    
                       <?php } ?>
                    </span>    
                    </span>
                </div>
             
             
            </div>  
    <?php if($type === 'cr') { ?>
    <div class="row-element"style="margin-bottom: 0px;margin-top: 30px">
        <span class="title" style="font-weight:bold;margin-bottom: 0px;padding: 0px;padding-left: 10px;color: #6F83AA;width:100%">Bill Generation Summary <?php echo date("Y-m-d H:i",strtotime($sdate));?> to <?php echo date("Y-m-d H:i",strtotime($edate));?> <?php if(array_key_exists("count", $reports)){ echo 'Bill Number ('.$reports['billno'].') '.$reports['count']." Bills";}?></span>                    
     </div>
    <?php } ?>
    <div class="row-element" style="margin-top: 0px"><div class="loader"></div>
        <table class="reportsTable">
            
                
                <?php if($type === 'cr') { 
                          
                    $html = '<thead><tr><th>S.nO</th><th>Counter Id</th><th>Counter name</th><th>Description</th><th>Reg Fee</th><th>Tuition Fee</th><th>S.Tax / <br>CGST</th><th>SB <br>CESS/<br>SGST</th><th>KK <br>CESS/<br>IGST/<br>KFC</th><th>CD</th><th>Other</th><th>Total</th><th>Cash</th><th>Card</th><th>Cheque</th><th>DD</th><th>SIB <br>Challan</th><th>Transfer</th><th>Online</th><th>Total</th><th>TDS</th></tr></thead>';
                    $i = 1; $mregFee = 0;$mtutionFee = 0;$mcgst = 0;$msgst = 0;
                    $mkf = 0;$mcd = 0;$mother = 0;$mtotal = 0;$mcash = 0;$mcard = 0;
                    $mcheque = 0;$mdd = 0;$mchallan = 0;$mtransfer = 0;$monline = 0;$mother1 = 0;$mpaid = 0;
                    foreach ($reports as $key=>$val){
                        if(($key === "count")||($key === "billno")) {continue;}
                        $coursename = array_key_exists('cname', $val)?$val['cname']:"";
                        $regFee = array_key_exists('Reg Fee', $val)?$val['Reg Fee']:0;
                        $tutionFee = array_key_exists('Tuition Fee', $val)?$val['Tuition Fee']:0;
                        $cd = array_key_exists('CD', $val)?$val['CD']:0;
                        $total = array_key_exists('total', $val)?$val['total']:0;
                        $paid = array_key_exists('paid', $val)?$val['paid']:0;
                        $tutionFee = round($tutionFee);

                        $cash = array_key_exists('cash', $val)?$val['cash']:0;
                        $dd = array_key_exists('dd', $val)?$val['dd']:0;
                        $challan = array_key_exists('challan', $val)?$val['challan']:0;
                        if($challan === 0 ) {$challan = array_key_exists('chellan', $val)?$val['chellan']:0;}
                        $transfer = array_key_exists('net', $val)?$val['net']:0;
                        $online = array_key_exists('online', $val)?$val['online']:0;
                        $card = array_key_exists('card', $val)?$val['card']:0;
                        $cheque = array_key_exists('cheque', $val)?$val['cheque']:0;

                        $calamount = floatval($regFee)+floatval($tutionFee);
                        $cgst = floatval($calamount)*.09;
                        $sgst = floatval($calamount)*.09;
                        $kf   = floatval($calamount)*.01;

                        $other = floatval($total) - (floatval($calamount)+floatval($cgst)+floatval($sgst)+floatval($kf)+floatval($cd));
                        $other1 = (floatval($cash)+floatval($dd)+floatval($challan)+floatval($transfer)+floatval($online)+floatval($card)+floatval($cheque))-floatval($paid);
                        $other = round($other,2);
                        $other1 = round($other1,2);
                        $cgst = round($cgst,2);
                        $sgst = round($sgst,2);
                        $kf = round($kf,2);

                        $html .= '<tr><td>'.$i.'</td><td>ALL</td><td>'.$center.'</td><td>'.$coursename.'</td><td>'.$regFee.'</td><td>'.$tutionFee.'</td><td>'.$cgst.'</td><td>'.$sgst.'</td><td>'.$kf.'</td><td>'.$cd.'</td><td>'.$other.'</td><td>'.$total.'</td><td>'.$cash.'</td><td>'.$card.'</td><td>'.$cheque.'</td><td>'.$dd.'</td><td>'.$challan.'</td><td>'.$transfer.'</td><td>'.$online.'</td><td>'.$paid.'</td><td>0</td></tr>';
                        $i++;
                        $mregFee = floatval($mregFee)+floatval($regFee);$mtutionFee = floatval($mtutionFee)+floatval($tutionFee);
                        $mcgst = floatval($mcgst)+floatval($cgst);$msgst = floatval($msgst)+floatval($sgst);$mkf = floatval($mkf)+floatval($kf);
                        $mcd = floatval($mcd)+floatval($cd);$mother = floatval($mother)+floatval($other);$mtotal = floatval($mtotal)+floatval($total);
                        $mcash = floatval($mcash)+floatval($cash);$mcard = floatval($mcard)+floatval($card); $mcheque = floatval($mcheque)+floatval($cheque);
                        $mdd = floatval($mdd)+floatval($dd);$mchallan = floatval($mchallan)+floatval($challan);$mtransfer = floatval($mtransfer)+floatval($transfer);
                        $monline = floatval($monline)+floatval($online);$mother1 = 0;$mpaid = floatval($mpaid)+floatval($paid);
                    }
                    if($i === 1) { echo '<tr><td colspan="22">No data available</td><tr>';} else{
                     
                    $html .= '<tr><td></td><td></td><td></td><td></td><td>'.$mregFee.'</td><td>'.$mtutionFee.'</td><td>'.$mcgst.'</td><td>'.$msgst.'</td><td>'.$mkf.'</td><td>'.$mcd.'</td><td>'.$mother.'</td><td>'.$mtotal.'</td><td>'.$mcash.'</td><td>'.$mcard.'</td><td>'.$mcheque.'</td><td>'.$mdd.'</td><td>'.$mchallan.'</td><td>'.$mtransfer.'</td><td>'.$monline.'</td><td>'.$mpaid.'</td><td>0</td></tr>';
                    }

                    echo $html;
           
       
           } else if($type === 'cwd'){ 
              
                    $html = '<thead><tr><th>S.no</th><th style="width: 30%">Course Name</th><th>Center</th><th>Student ID</th><th style="width: 10%">Student Name</th><th>Country Code</th><th>Mobile Number</th><th>Whats App No.</th><th>Email ID</th><th style="width: 20%">Qualification</th><th>Stream</th><th>Course Fee</th><th>Remitted</th><th>Initial Payment Date</th></tr></thead>';
                    $i = 1;
                    foreach ($reports as $key=>$val){
                        $html .= '<tr><td>'.$i.'</td><td>'.$val['coursename'].'</td><td>'.$val['center'].'</td><td>'.$val['studid'].'</td><td>'.$val['sname'].'</td><td>'.$val['mcode'].'</td><td>'.$val['contact'].'</td><td>'.$val['whatsappno'].'</td><td>'.$val['email'].'</td><td>'.$val['name'].'</td><td>'.$val['stream'].'</td><td>'.$val['total'].'</td><td>'.$val['remitted'].'</td><td>'.$val['pdate'].'</td> </tr>';
                        $i++;
                    }
                    if($i === 1) { echo '<tr><td colspan="13">No data available</td><tr>';} 
                    echo $html;
           
         
                 } else if($type === 'dca'){ 
                    $html = '<thead><tr><th>S.no</th><th>Student ID</th><th style="width: 20%">Student Name</th><th>Country Code</th><th>Mobile Number</th><th>Email ID</th><th style="width: 20%">Qualification</th><th>Stream</th><th style="width: 20%">Applied Course</th><th>Center</th><th>Present Status</th><th>Date of Registration</th></tr></thead>';
                    $i = 1;
                    foreach ($reports as $key=>$val){
                        $html .= '<tr><td>'.$i.'</td><td>'.$val['studid'].'</td><td>'.$val['sname'].'</td><td>'.$val['mcode'].'</td><td>'.$val['contact'].'</td><td>'.$val['email'].'</td><td>'.$val['qualification'].'</td><td>'.$val['stream'].'</td><td>'.$val['coursename'].'</td><td>'.$val['center'].'</td><td>'.$val['status'].'</td><td>'.$val['rdate'].'</td></tr>';
                        $i++;
                    }
                    if($i === 1) { echo '<tr><td colspan="11">No data available</td><tr>';} 
                    echo $html;
                 
                  }else if($type === 'sl'){ 
                 
                    $html = '<thead><tr><th style="width: 5%">S.no</th><th >Student ID</th><th style="width: 20%">Student Name</th><th>Country Code</th><th>Mobile Number</th><th>Email ID</th><th style="width: 20%">Qualification</th></tr></thead>';
                    $i = 1;
                    foreach ($reports as $key=>$val){
                        $html .= '<tr><td>'.$i.'</td><td>'.$val['studid'].'</td><td>'.$val['sname'].'</td><td>'.$val['mcode'].'</td><td>'.$val['contact'].'</td><td>'.$val['email'].'</td><td>'.$val['qualification'].'</td></tr>';
                        $i++;
                    }
                    if($i === 1) { echo '<tr><td colspan="6">No data available</td><tr>';} 
                    echo $html;
                  } else if($type === 'bl'){
                      
                  $i= 1;                 
                    $html = '<thead><tr><th style="width: 5%">S.no</th><th >Student ID</th><th >CHL ID</th><th >Date</th><th >Bill No</th><th style="width: 20%">Student Name</th><th style="width: 20%">Course Name</th><th>Center</th><th>Paid</th><th>Payment Mode</th></tr></thead>';
                    
                    foreach ($reports as $key=>$val){
                        $html .= '<tr><td>'.$i.'</td><td>'.$val['studid'].'</td><td>'.$val['challanno'].'</td><td>'.$val['paydate'].'</td><th >'.$val['receiptno'].'</th><td>'.$val['sname'].'</td><td>'.$val['coursename'].'</td><td>'.$val['center'].'</td><td>'.$val['paid'].'</td><td>'.$val['paymentmode'].'</td></tr>';
                        $i++;
                    }
                    
                    if($i === 1) { echo '<tr><td colspan="9">No data available</td><tr>';} 
                    echo $html;
                  } else if($type === 'ul'){
                      
                    $html = '<thead><tr><th style="width: 5%">S.no</th><th >Student ID</th><th >CHL ID</th><th style="width: 20%">Student Name</th><th style="width: 20%">Course Name</th><th>Center</th><th>Unpaid</th></tr></thead>';
                    $i = 1;
                    foreach ($reports as $key=>$val){
                        $html .= '<tr><td>'.$i.'</td><td>'.$val['studid'].'</td><td>'.$val['challanno'].'</td><td>'.$val['sname'].'</td><td>'.$val['coursename'].'</td><td>'.$val['center'].'</td><td>'.$val['unpaid'].'</td></tr>';
                        $i++;
                    }
                    
                    if($i === 1) { echo '<tr><td colspan="7">No data available</td><tr>';} 
                    echo $html;
                    
                  } else if($type === 'stunpl'){
                      
                    $html = '<thead><tr><th >S.no</th><th >Student ID</th><th >Student Name</th><th>Country Code</th><th>Mobile No</th><th>Email</th><th>City</th><th>Date of Birth:</th><th>Gender</th><th>Nationality</th><th>Category</th><th>Aadhar Number</th><th>Fathers Name</th><th>Country Code</th><th>Fathers Phone</th><th>Fathers Email</th><th>Fathers Occupation</th><th>Mothers Name</th><th>Country Code</th><th>Mothers Phone</th><th>Mothers Email</th><th>Mothers Occupation</th><th>Communication Contact</th><th>Blood Group</th><th>Class Studying / Complete</th><th>Stream</th><th>Name of School Last Studied / Studying</th><th>Address Line</th><th>Country</th><th>House / Appartment Name</th><th>Place / Street</th><th>Post Office</th><th>District</th><th>State</th><th>Country</th><th>Pincode</th><th>Country Code</th><th>Whatsapp Number</th><th>Guardian Name</th><th>Account Holder Name</th><th>Bank Name</th><th>Branch</th><th>IFSC Code</th><th>Bank Account Number</th><th>profile Percentage</th><th>Course Name</th><th>Center</th><th>Payment Date</th><th>Bill No</th><th>Paid</th><th>Payment Mode</th></tr></thead>';
                    $i = 1;
                    foreach ($reports as $key=>$val){
                        $landmark = ($val['landmark'] === "0")?"":$val['landmark'].",";
                        $html .= '<tr><td>'.$i.'</td><td>'.$val['studid'].'</td><td>'.$val['sname'].'</td><td>'.$val['mcode'].'</td><td>'.$val['contact'].'</td><td>'.$val['email'].'</td><td>'.$val['city'].'</td><td>'.$val['dob'].'</td><td>'.$val['gender'].'</td><td>'.$val['nationality'].'</td><td>'.$val['category'].'</td><td>'.$val['aadharnumber'].'</td><td>'.$val['fathername'].'</td><td>'.$val['fathercode'].'</td><td>'.$val['fatherphone'].'</td><td>'.$val['fatheremail'].'</td><td>'.$val['fatheroccupation'].'</td><td>'.$val['mothername'].'</td><td>'.$val['mothercode'].'</td><td>'.$val['motherphone'].'</td><td>'.$val['motheremail'].'</td><td>'.$val['motheroccupation'].'</td><td>'.$val['communicationcontact'].'</td><td>'.$val['bloodgroup'].'</td><td>'.$val['classstudy'].'</td><td>'.$val['stream'].'</td><td>'.$val['schoolcollegename'].'</td><td>'.$val['eduaddress'].",".$val['edulandmark'].",".$val['edudistrict'].",".$val['edustate'].",".$val['edupost'].",".$val['edupincode'].'</td><td>'.$val['educountry'].'</td><td>'.$val['housenameno'].'</td><td>'.$landmark.$val['contactaddress'].'</td><td>'.$val['contactpost'].'</td><td>'.$val['contactdistrict'].'</td><td>'.$val['contactstate'].'</td><td>'.$val['contactcountry'].'</td><td>'.$val['contactpincode'].'</td><td>'.$val['wacode'].'</td><td>'.$val['whatsappno'].'</td><td>'.$val['guardianname'].'</td><td>'.$val['accountholdername'].'</td><td>'.$val['bankname'].'</td><td>'.$val['branch'].'</td><td>'.$val['ifsccode'].'</td><td>'.$val['bankaccountno'].'</td><td>'.$val['profilepercent'].'</td><td>'.$val['coursename'].'</td><td>'.$val['center'].'</td><td>'.$val['paydate'].'</td><td>'.$val['receiptno'].'</td><td>'.$val['paid'].'</td><td>'.$val['paymentmode'].'</td></tr>';
                        $i++;
                    }
                    
                    if($i === 1) { echo '<tr><td colspan="47">No data available</td><tr>';} 
                    echo $html;
                  } else if($type === 'rfl'){
                      
                    $reports = $this->reports_model->RefundBillList($sdate,$edate,$center);
                    $savename = "Refund_Paid_Report_".date('d-m-Y-H_i_s');
                      
                        $html = '<thead><tr><th >S.no</th><th >App Date</th><th >App No</th><th >Student ID</th><th>Student Name</th><th>Course Nmae</th><th>Center</th><th>Refund Bill No</th><th>Remitted(without GST)</th><th>Refund Amount(without GST)</th><th>Trans Details</th><th>Reason For Refund</th></tr></thead>';
                    $i = 1;
                    foreach ($reports as $key=>$val){
                        
                        $html .= '<tr><td>'.$i.'</td><td>'.$val['appdate'].'</td><td>'.$val['appno'].'</td><td style="width:5% !important">'.$val['studid'].'</td><td>'.$val['sname'].'</td><td style="width:15% !important">'.$val['coursename'].'</td><td>'.$val['center'].'</td><td>'.$val['receiptno'].'</td><td style="width:5% !important">'.$val['remitted'].'</td><td style="width:5% !important">'.$val['refundamount'].'</td><td>'.$val['paydescription'].'</td><td>'.$val['reason'].'</td></tr>';
                        $i++;
                    }
                    
                    if($i === 1) { echo '<tr><td colspan="11">No data available</td><tr>';} 
                    echo $html;
                  } 
               
                 
                 ?>
        </table>
              
         
        </div>
        
        </div>
    
 
    

=======
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/dataTables.css?v=1.5" />
<script src="<?php echo base_url(); ?>js/jquery.dataTables.js?v=1.0" type="text/javascript"></script>
 <link href="<?php  echo base_url(); ?>css/jquery-ui.min.css?v=1.4" rel="stylesheet" type="text/css" />
 <script src="<?php  echo base_url(); ?>js/jquery-ui.min.js?v=1.3" type="text/javascript"></script>
<style type="text/css">
    
.reportsTable thead tr  {
    background: #E6EBF7;

/* g8 */
border: 1px solid #D7DFF0;
box-sizing: border-box;
border-radius: 10px 10px 0px 0px;
 

}

    .reportsTable tr th {
        border-right: 0px;
    font-size: 13px;
      color: #6F83AA;
   cursor: pointer;
   text-align: center;padding: 4px;
   width: 5%;vertical-align: middle;
    }  
    
  .reportsTable tr { background: #fff;border-bottom: 1px solid #D7DFF0;}
.reportsTable tr td {
    border-right: 0px;
    padding: 5px 5px;
    text-align: center;font-size: 13px;
    vertical-align: middle;
}

    
     
    .reportsTable tr td:nth-child(4) {
  width: 15% !important;
}


.ui-selectmenu-button.ui-button{ width: 50%; padding:10px;padding-right: 0px;}
     #centers-button,#rtype-button{border: 1px solid #D7DFF0;background: #fff;font-size: 14px;color:#536485}
     .loader {
    display: none;
    position: absolute;
    top: 0; left: 0; right: 0; bottom: 0;
    background: rgba(255,255,255,0.8) url('<?php echo base_url(); ?>images/loader.gif') center center no-repeat;
    z-index: 1000;
}
</style>
<script type="text/javascript">
    
    $(window).load(function () {
    $(".loader").hide();   
    });
  
$(document).ready(function(){	

         $("#centers").selectmenu(); 
         
         var rtype = '<?php echo $type; ?>';
         $("#rtype").val(rtype);
         
         $("#rtype").selectmenu();
         
         $(".adtime").datetimepicker({
  dateFormat: "yy-mm-dd"
    });
         
        
         
  $("#billSearch").click(function(){
     
     var sdate = $(".fromdate").val();
     var edate = $(".todate").val();
     var center = $("#centers").val();
     var rtype = $("#rtype").val();
     $(".loader").show();
     var url = 'reports?sdate='+sdate+'&edate='+edate+'&center='+center+"&rtype="+rtype;
       $(location).prop('href', url);
     
  });
  
  $("#export").click(function(){
     
     var sdate = $(".fromdate").val();
     var edate = $(".todate").val();
     var center = $("#centers").val();
     var rtype = $("#rtype").val();
    
     var url = 'reports/export?sdate='+sdate+'&edate='+edate+'&center='+center+"&rtype="+rtype;
       $(location).prop('href', url);
     
  });
  
  
   $("#bulkprint").click(function(){
      
      var sdate = $(".fromdate").val();
     var edate = $(".todate").val();
     var center = $("#centers").val();
      var url = 'reports?sdate='+sdate+'&edate='+edate+'&center='+center+"&rtype=bulkprint";
       window.open(url, '_blank');
      
  });
  
   $('#rtype').on('selectmenuchange', function() {
            var ty =  $(this).val(); 
            if(ty === 'bl'){                
                $("#bulkprint").css("display","inline");
            } else {
                $("#bulkprint").css("display","none");
            }


        });
  
                });
</script>

<?php $title['cr'] = "Collection Report";$title['cwd'] = "Course Wise Admitted List";
$title['dca'] = "Course Applied List";$title['sl'] = "Signup List";
$title['bl'] = "Bill List";$title['ul'] = "Unpaid List";$title['stunpl'] = "New Student First Paid List";$title['rfl'] = "Refund Paid List";
$title['ccl'] = "Course Change List";?>
<div class="wrap dynamic-width" style="float: left;position: relative;">
   
    <div style="margin-top: 10px; width: 100%; height:310px; text-align: right;">       
             <span style="font-weight: bold;font-size: 20px;padding: 10px;float:left;color: #364159">Report Summary - <?php echo $title[$type];?></span>
             <div class="row-element">
                 <span class="title" style="padding: 0px;padding-left: 10px;color: #6F83AA;margin-top: 14px;">Date</span>                    
                    <span class="content" style="padding: 0px;color:#0332AA;font-weight: bold;min-width: 250px;width: 100px">
                          <input type="text" value="<?php echo date("Y/m/d H:i",strtotime($sdate));?>" name = "fromdate" class="fromdate adtime" style="width: 90%;margin: 5px;background: #fff url('<?php echo base_url(); ?>/images/cal.png') no-repeat 95%;">  
                        </span>
                 <span class="content" style="padding: 0px;color:#0332AA;font-weight: bold;min-width: 250px;width: 100px">
                        <input type="text" value="<?php echo date("Y/m/d H:i",strtotime($edate));?>" name = "todate" class="todate adtime" style="width: 90%;margin: 5px;background: #fff url('<?php echo base_url(); ?>/images/cal.png') no-repeat 95%;">    
                        </span>
                </div>
             <!--div class="row-element">
                 <span class="title" style="padding: 0px;padding-left: 10px;color: #6F83AA">To Date</span>                    
                    <span class="content" style="padding: 0px;color:#0332AA;font-weight: bold">
                        <input type="text" value="<?php //echo date("Y/m/d H:i",strtotime($edate));?>" name = "todate" class="todate adtime" style="width: 50%;margin: 5px;background: #fff url('<?php echo base_url(); ?>/images/cal.png') no-repeat 98%;">    
                        </span>
                </div-->
             <div class="row-element">
                 <span class="title" style="padding: 0px;padding-left: 10px;color: #6F83AA">Centers</span>                    
                    <span class="content" style="padding: 0px;color:#0332AA;font-weight: bold">
                        <select  id="centers" name = "centers" class="centers" style="width: 50%;font-size: 13px;float:left">
                            <option value="All" >All</option>
                            <?php echo $units;?>
                        </select>
                        </span>
                </div>
             
             <div class="row-element">
                 <span class="title" style="padding: 0px;padding-left: 10px;color: #6F83AA">Report Type</span>                    
                    <span class="content" style="padding: 0px;color:#0332AA;font-weight: bold">
                        <select  id="rtype" name = "rtype" class="rtype" style="width: 50%;font-size: 13px;float:left">
                            <option value="cr" >Accounts Report</option>
                            <option value="cwd" >Course wise Admitted List</option>
                            <option value="dca" >Course Applied List</option>
                            <option value="sl" >Signup List</option>
                            <option value="bl" >Bill List</option>
                            <option value="ul" >Unpaid List</option>
                            <option value="stunpl" >New Student First Paid List</option>
                            <option value="rfl" >Refund Paid List</option>
                            <option value="ccl" >Course Change List</option>
                        </select>
                        </span>
                </div>
             <div class="row-element">
                 <span class="title" style="padding: 0px;padding-left: 10px;color: #6F83AA;visibility: hidden">Search</span>                    
                    <span class="content" style="padding: 0px;color:#0332AA;font-weight: bold">
                       <span id="billSearch" style="cursor: pointer;margin-left:20px;font-weight: bold;font-size: 14px;padding: 5px 10px;color: #fff;border-radius:5px;background: linear-gradient(180deg, #4F70C4 0%, #1C47B3 100%);">Search</span>    
                       <span id="export" style="cursor: pointer;margin-left:20px;font-weight: bold;font-size: 14px;padding: 5px 10px;color: #fff;border-radius:5px;background: linear-gradient(180deg, #4F70C4 0%, #1C47B3 100%);">Export</span>    
                       <span id="bulkprint" style="display: none;cursor: pointer;margin-left:20px;font-weight: bold;font-size: 14px;padding: 5px 10px;color: #fff;border-radius:5px;background: linear-gradient(180deg, #4F70C4 0%, #1C47B3 100%);">Bulk Print</span>    
                    </span>    
                    </span>
                </div>
             
             
            </div>  
    <?php if($type === 'cr') { ?>
    <div class="row-element"style="margin-bottom: 0px;margin-top: 30px">
        <span class="title" style="font-weight:bold;margin-bottom: 0px;padding: 0px;padding-left: 10px;color: #6F83AA;width:100%">Bill Generation Summary <?php echo date("Y-m-d H:i",strtotime($sdate));?> to <?php echo date("Y-m-d H:i",strtotime($edate));?> <?php if(array_key_exists("count", $reports)){ echo 'Bill Number ('.$reports['billno'].') '.$reports['count']." Bills";}?></span>                    
     </div>
    <?php } ?>
    <div class="row-element" style="margin-top: 0px"><div class="loader"></div>
        <table class="reportsTable">
            
                
                <?php if($type === 'cr') { 
                          
                    $html = '<thead><tr><th>S.nO</th><th>Counter Id</th><th>Counter name</th><th>Description</th><th>Reg Fee</th><th>Tuition Fee</th><th>S.Tax / <br>CGST</th><th>SB <br>CESS/<br>SGST</th><th>KK <br>CESS/<br>IGST/<br>KFC</th><th>CD</th><th>Other</th><th>Total</th><th>Cash</th><th>Card</th><th>Cheque</th><th>DD</th><th>SIB <br>Challan</th><th>Transfer</th><th>Online</th><th>Total</th><th>TDS</th></tr></thead>';
                    $i = 1; $mregFee = 0;$mtutionFee = 0;$mcgst = 0;$msgst = 0;
                    $mkf = 0;$mcd = 0;$mother = 0;$mtotal = 0;$mcash = 0;$mcard = 0;
                    $mcheque = 0;$mdd = 0;$mchallan = 0;$mtransfer = 0;$monline = 0;$mother1 = 0;$mpaid = 0;
                    foreach ($reports as $key=>$val){
                        if(($key === "count")||($key === "billno")) {continue;}
                        $coursename = array_key_exists('cname', $val)?$val['cname']:"";
                        $regFee = array_key_exists('Reg Fee', $val)?$val['Reg Fee']:0;
                        $tutionFee = array_key_exists('Tuition Fee', $val)?$val['Tuition Fee']:0;
                        $cd = array_key_exists('CD', $val)?$val['CD']:0;
                        $total = array_key_exists('total', $val)?$val['total']:0;
                        $paid = array_key_exists('paid', $val)?$val['paid']:0;
                        $tutionFee = round($tutionFee);

                        $cash = array_key_exists('cash', $val)?$val['cash']:0;
                        $dd = array_key_exists('dd', $val)?$val['dd']:0;
                        $challan = array_key_exists('challan', $val)?$val['challan']:0;
                        if($challan === 0 ) {$challan = array_key_exists('chellan', $val)?$val['chellan']:0;}
                        $transfer = array_key_exists('net', $val)?$val['net']:0;
                        $online = array_key_exists('online', $val)?$val['online']:0;
                        $card = array_key_exists('card', $val)?$val['card']:0;
                        $cheque = array_key_exists('cheque', $val)?$val['cheque']:0;

                        $calamount = floatval($regFee)+floatval($tutionFee);
                        $cgst = floatval($calamount)*.09;
                        $sgst = floatval($calamount)*.09;
                        $kf   = floatval($calamount)*.01;

                        $other = floatval($total) - (floatval($calamount)+floatval($cgst)+floatval($sgst)+floatval($kf)+floatval($cd));
                        $other1 = (floatval($cash)+floatval($dd)+floatval($challan)+floatval($transfer)+floatval($online)+floatval($card)+floatval($cheque))-floatval($paid);
                        $other = round($other,2);
                        $other1 = round($other1,2);
                        $cgst = round($cgst,2);
                        $sgst = round($sgst,2);
                        $kf = round($kf,2);

                        $html .= '<tr><td>'.$i.'</td><td>ALL</td><td>'.$center.'</td><td>'.$coursename.'</td><td>'.$regFee.'</td><td>'.$tutionFee.'</td><td>'.$cgst.'</td><td>'.$sgst.'</td><td>'.$kf.'</td><td>'.$cd.'</td><td>'.$other.'</td><td>'.$total.'</td><td>'.$cash.'</td><td>'.$card.'</td><td>'.$cheque.'</td><td>'.$dd.'</td><td>'.$challan.'</td><td>'.$transfer.'</td><td>'.$online.'</td><td>'.$paid.'</td><td>0</td></tr>';
                        $i++;
                        $mregFee = floatval($mregFee)+floatval($regFee);$mtutionFee = floatval($mtutionFee)+floatval($tutionFee);
                        $mcgst = floatval($mcgst)+floatval($cgst);$msgst = floatval($msgst)+floatval($sgst);$mkf = floatval($mkf)+floatval($kf);
                        $mcd = floatval($mcd)+floatval($cd);$mother = floatval($mother)+floatval($other);$mtotal = floatval($mtotal)+floatval($total);
                        $mcash = floatval($mcash)+floatval($cash);$mcard = floatval($mcard)+floatval($card); $mcheque = floatval($mcheque)+floatval($cheque);
                        $mdd = floatval($mdd)+floatval($dd);$mchallan = floatval($mchallan)+floatval($challan);$mtransfer = floatval($mtransfer)+floatval($transfer);
                        $monline = floatval($monline)+floatval($online);$mother1 = 0;$mpaid = floatval($mpaid)+floatval($paid);
                    }
                    if($i === 1) { echo '<tr><td colspan="22">No data available</td><tr>';} else{
                     
                    $html .= '<tr><td></td><td></td><td></td><td></td><td>'.$mregFee.'</td><td>'.$mtutionFee.'</td><td>'.$mcgst.'</td><td>'.$msgst.'</td><td>'.$mkf.'</td><td>'.$mcd.'</td><td>'.$mother.'</td><td>'.$mtotal.'</td><td>'.$mcash.'</td><td>'.$mcard.'</td><td>'.$mcheque.'</td><td>'.$mdd.'</td><td>'.$mchallan.'</td><td>'.$mtransfer.'</td><td>'.$monline.'</td><td>'.$mpaid.'</td><td>0</td></tr>';
                    }

                    echo $html;
           
       
           } else if($type === 'cwd'){ 
              
                    $html = '<thead><tr><th>S.no</th><th style="width: 30%">Course Name</th><th>Center</th><th>Student ID</th><th style="width: 10%">Student Name</th><th>Country Code</th><th>Mobile Number</th><th>Whats App No.</th><th>Email ID</th><th style="width: 20%">Qualification</th><th>Stream</th><th>Course Fee</th><th>Remitted</th><th>Initial Payment Date</th></tr></thead>';
                    $i = 1;
                    foreach ($reports as $key=>$val){
                        $html .= '<tr><td>'.$i.'</td><td>'.$val['coursename'].'</td><td>'.$val['center'].'</td><td>'.$val['studid'].'</td><td>'.$val['sname'].'</td><td>'.$val['mcode'].'</td><td>'.$val['contact'].'</td><td>'.$val['whatsappno'].'</td><td>'.$val['email'].'</td><td>'.$val['name'].'</td><td>'.$val['stream'].'</td><td>'.$val['total'].'</td><td>'.$val['remitted'].'</td><td>'.$val['pdate'].'</td> </tr>';
                        $i++;
                    }
                    if($i === 1) { echo '<tr><td colspan="13">No data available</td><tr>';} 
                    echo $html;
           
         
                 } else if($type === 'dca'){ 
                    $html = '<thead><tr><th>S.no</th><th>Student ID</th><th style="width: 20%">Student Name</th><th>Country Code</th><th>Mobile Number</th><th>Email ID</th><th style="width: 20%">Qualification</th><th>Stream</th><th style="width: 20%">Applied Course</th><th>Center</th><th>Present Status</th><th>Date of Registration</th></tr></thead>';
                    $i = 1;
                    foreach ($reports as $key=>$val){
                        $html .= '<tr><td>'.$i.'</td><td>'.$val['studid'].'</td><td>'.$val['sname'].'</td><td>'.$val['mcode'].'</td><td>'.$val['contact'].'</td><td>'.$val['email'].'</td><td>'.$val['qualification'].'</td><td>'.$val['stream'].'</td><td>'.$val['coursename'].'</td><td>'.$val['center'].'</td><td>'.$val['status'].'</td><td>'.$val['rdate'].'</td></tr>';
                        $i++;
                    }
                    if($i === 1) { echo '<tr><td colspan="11">No data available</td><tr>';} 
                    echo $html;
                 
                  }else if($type === 'sl'){ 
                 
                    $html = '<thead><tr><th style="width: 5%">S.no</th><th >Student ID</th><th style="width: 20%">Student Name</th><th>Country Code</th><th>Mobile Number</th><th>Email ID</th><th style="width: 20%">Qualification</th></tr></thead>';
                    $i = 1;
                    foreach ($reports as $key=>$val){
                        $html .= '<tr><td>'.$i.'</td><td>'.$val['studid'].'</td><td>'.$val['sname'].'</td><td>'.$val['mcode'].'</td><td>'.$val['contact'].'</td><td>'.$val['email'].'</td><td>'.$val['qualification'].'</td></tr>';
                        $i++;
                    }
                    if($i === 1) { echo '<tr><td colspan="6">No data available</td><tr>';} 
                    echo $html;
                  } else if($type === 'bl'){
                      
                  $i= 1;                 
                    $html = '<thead><tr><th style="width: 5%">S.no</th><th >Student ID</th><th >CHL ID</th><th >Date</th><th >Bill No</th><th style="width: 20%">Student Name</th><th style="width: 20%">Course Name</th><th>Center</th><th>Paid</th><th>Payment Mode</th></tr></thead>';
                    
                    foreach ($reports as $key=>$val){
                        $html .= '<tr><td>'.$i.'</td><td>'.$val['studid'].'</td><td>'.$val['challanno'].'</td><td>'.$val['paydate'].'</td><th >'.$val['receiptno'].'</th><td>'.$val['sname'].'</td><td>'.$val['coursename'].'</td><td>'.$val['center'].'</td><td>'.$val['paid'].'</td><td>'.$val['paymentmode'].'</td></tr>';
                        $i++;
                    }
                    
                    if($i === 1) { echo '<tr><td colspan="9">No data available</td><tr>';} 
                    echo $html;
                  } else if($type === 'ul'){
                      
                    $html = '<thead><tr><th style="width: 5%">S.no</th><th >Student ID</th><th >CHL ID</th><th style="width: 20%">Student Name</th><th style="width: 20%">Course Name</th><th>Center</th><th>Unpaid</th></tr></thead>';
                    $i = 1;
                    foreach ($reports as $key=>$val){
                        $html .= '<tr><td>'.$i.'</td><td>'.$val['studid'].'</td><td>'.$val['challanno'].'</td><td>'.$val['sname'].'</td><td>'.$val['coursename'].'</td><td>'.$val['center'].'</td><td>'.$val['unpaid'].'</td></tr>';
                        $i++;
                    }
                    
                    if($i === 1) { echo '<tr><td colspan="7">No data available</td><tr>';} 
                    echo $html;
                    
                  } else if($type === 'stunpl'){
                      
                    $html = '<thead><tr><th >S.no</th><th >Student ID</th><th >Student Name</th><th>Country Code</th><th>Mobile No</th><th>Email</th><th>City</th><th>Date of Birth:</th><th>Gender</th><th>Nationality</th><th>Category</th><th>Aadhar Number</th><th>Fathers Name</th><th>Country Code</th><th>Fathers Phone</th><th>Fathers Email</th><th>Fathers Occupation</th><th>Mothers Name</th><th>Country Code</th><th>Mothers Phone</th><th>Mothers Email</th><th>Mothers Occupation</th><th>Communication Contact</th><th>Blood Group</th><th>Class Studying / Complete</th><th>Stream</th><th>Name of School Last Studied / Studying</th><th>Address Line</th><th>Country</th><th>House / Appartment Name</th><th>Place / Street</th><th>Post Office</th><th>District</th><th>State</th><th>Country</th><th>Pincode</th><th>Country Code</th><th>Whatsapp Number</th><th>Guardian Name</th><th>Account Holder Name</th><th>Bank Name</th><th>Branch</th><th>IFSC Code</th><th>Bank Account Number</th><th>profile Percentage</th><th>Course Name</th><th>Center</th><th>Payment Date</th><th>Bill No</th><th>Paid</th><th>Payment Mode</th></tr></thead>';
                    $i = 1;
                    foreach ($reports as $key=>$val){
                        $landmark = ($val['landmark'] === "0")?"":$val['landmark'].",";
                        $html .= '<tr><td>'.$i.'</td><td>'.$val['studid'].'</td><td>'.$val['sname'].'</td><td>'.$val['mcode'].'</td><td>'.$val['contact'].'</td><td>'.$val['email'].'</td><td>'.$val['city'].'</td><td>'.$val['dob'].'</td><td>'.$val['gender'].'</td><td>'.$val['nationality'].'</td><td>'.$val['category'].'</td><td>'.$val['aadharnumber'].'</td><td>'.$val['fathername'].'</td><td>'.$val['fathercode'].'</td><td>'.$val['fatherphone'].'</td><td>'.$val['fatheremail'].'</td><td>'.$val['fatheroccupation'].'</td><td>'.$val['mothername'].'</td><td>'.$val['mothercode'].'</td><td>'.$val['motherphone'].'</td><td>'.$val['motheremail'].'</td><td>'.$val['motheroccupation'].'</td><td>'.$val['communicationcontact'].'</td><td>'.$val['bloodgroup'].'</td><td>'.$val['classstudy'].'</td><td>'.$val['stream'].'</td><td>'.$val['schoolcollegename'].'</td><td>'.$val['eduaddress'].",".$val['edulandmark'].",".$val['edudistrict'].",".$val['edustate'].",".$val['edupost'].",".$val['edupincode'].'</td><td>'.$val['educountry'].'</td><td>'.$val['housenameno'].'</td><td>'.$landmark.$val['contactaddress'].'</td><td>'.$val['contactpost'].'</td><td>'.$val['contactdistrict'].'</td><td>'.$val['contactstate'].'</td><td>'.$val['contactcountry'].'</td><td>'.$val['contactpincode'].'</td><td>'.$val['wacode'].'</td><td>'.$val['whatsappno'].'</td><td>'.$val['guardianname'].'</td><td>'.$val['accountholdername'].'</td><td>'.$val['bankname'].'</td><td>'.$val['branch'].'</td><td>'.$val['ifsccode'].'</td><td>'.$val['bankaccountno'].'</td><td>'.$val['profilepercent'].'</td><td>'.$val['coursename'].'</td><td>'.$val['center'].'</td><td>'.$val['paydate'].'</td><td>'.$val['receiptno'].'</td><td>'.$val['paid'].'</td><td>'.$val['paymentmode'].'</td></tr>';
                        $i++;
                    }
                    
                    if($i === 1) { echo '<tr><td colspan="47">No data available</td><tr>';} 
                    echo $html;
                  } else if($type === 'rfl'){
                      
                    $reports = $this->reports_model->RefundBillList($sdate,$edate,$center);
                    $savename = "Refund_Paid_Report_".date('d-m-Y-H_i_s');
                      
                        $html = '<thead><tr><th >S.no</th><th >App Date</th><th >App No</th><th >Student ID</th><th>Student Name</th><th>Course Nmae</th><th>Center</th><th>Refund Bill No</th><th>Remitted(without GST)</th><th>Refund Amount(without GST)</th><th>Trans Details</th><th>Reason For Refund</th></tr></thead>';
                    $i = 1;
                    foreach ($reports as $key=>$val){
                        
                        $html .= '<tr><td>'.$i.'</td><td>'.$val['appdate'].'</td><td>'.$val['appno'].'</td><td style="width:5% !important">'.$val['studid'].'</td><td>'.$val['sname'].'</td><td style="width:15% !important">'.$val['coursename'].'</td><td>'.$val['center'].'</td><td>'.$val['receiptno'].'</td><td style="width:5% !important">'.$val['remitted'].'</td><td style="width:5% !important">'.$val['refundamount'].'</td><td>'.$val['paydescription'].'</td><td>'.$val['reason'].'</td></tr>';
                        $i++;
                    }
                    
                    if($i === 1) { echo '<tr><td colspan="11">No data available</td><tr>';} 
                    echo $html;
                  } else if($type === 'ccl'){
                    $reports = $this->reports_model->CourseChangeList($sdate,$edate,$center);
                    $savename = "Course_Change_Report_".date('d-m-Y-H_i_s');
                    
                    $html = '<thead><tr><th >S.no</th><th >App Date</th><th >App No</th><th >Student ID</th><th>Student Name</th><th>From - Course Nmae</th><th>From - Center</th><th>To - Course Name</th><th>To - Center</th><th>Remitted(without GST)</th><th>Refund Amount(without GST)</th></tr></thead>';
                    $i = 1;
                    foreach ($reports as $key=>$val){
                        
                        $html .= '<tr><td>'.$i.'</td><td>'.$val['created_at'].'</td><td>'.$val['receiptno'].'</td><td style="width:5% !important">'.$val['studid'].'</td><td>'.$val['sname'].'</td><td style="width:15% !important">'.$val['fcoursename'].'</td><td>'.$val['center'].'</td><td>'.$val['tcoursename'].'</td><td style="width:5% !important">'.$val['new_center'].'</td><td style="width:5% !important">'.$val['remitted'].'</td><td>'.$val['refundamount'].'</td></tr>';
                        $i++;
                    }
                    
                    if($i === 1) { echo '<tr><td colspan="11">No data available</td><tr>';} 
                    echo $html;
                }
               
                 
                 ?>
        </table>
              
         
        </div>
        
        </div>
    >>>>>>> .r338

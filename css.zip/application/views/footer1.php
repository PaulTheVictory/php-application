
<div id="footer">

	<div class="wrap">
    
    	<span class="copyright"></span>
        
        <div class="clear"></div>
        
        
    </div>

</div>


<script src="<?php echo $this->config->item('web_url') ?>js/jquery.dlmenu.js" type="text/javascript"></script>
<script>
	$(function() {
		$( '#mobilemenu' ).dlmenu();
	});
</script>


</body>
</html>
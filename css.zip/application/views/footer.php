

<?php if(!$this->session->userdata('loggedin')){ ?>



<footer class="page-footer">

 <div class="container">

      <div class="row d-flex align-items-center">

        <div class="col-sm-6 d-flex justify-content-start">


		   	   <a href="#" title="Privacy Policies">Privacy Policies</a> 

			   <a href="termsandconditions" title="Terms & Conditions">Terms & Conditions</a> 

			   <!--<a href="#" title="Sitemap">Sitemap</a>--> 

			   <a href="https://brilliantpala.org/contact-us/" target="_blank" title="Contact us">Contact us</a>
       		

        </div>

        <div class="col-sm-6 d-flex justify-content-end">

          <p class="mb-0 text-muted"> &copy; <?php echo date('Y'); ?> Brilliant study centre. All rights Reserved </p>

        </div>

      </div>

    </div>

</footer>



<?php }?>



<script src="<?php echo base_url();?>js/bootstrap.bundle.min.js"></script>

<script src="<?php echo base_url();?>js/pala.script.js?v=1.1"></script>

<script src="<?php echo base_url();?>js/scripts.js?v=1.1"></script>



<script>



	$(document).ready(function(){

		
		<?php if(!$this->session->userdata('loggedin')){ ?>


		/*var headTop = $(".head-top").offset().top;


		$(window).scroll(function(event){

			var ww = $(window).width();

			var st = $(this).scrollTop();
			
				
			if (st > headTop){

				$(".fixed-top").css('top',0);

			}else{

				if(ww<420){ $(".fixed-top").css('top',65);}else if(ww<767){ $(".fixed-top").css('top',48);}else{$(".fixed-top").css('top',35);}

			}
			

			lastScrollTop = st;			

		});*/

		

		<?php }?>
		
		
		$(".menu .main-menu ul li a").click(function(event){
			 event.stopPropagation();
			
		});
		
		
		var ww = $(window).width();
		
		if(ww<767){
			var colspan = $('.totalamt').attr('colspan');$('.totalamt').attr('data-colspan',colspan);$('.totalamt').attr('colspan','2');
		}
		else{
			var colspan = $('.totalamt').data('colspan');$('.totalamt').attr('colspan',colspan);
		}
		
		
		$(window).resize(function(){
			
			var ww = $(window).width();
		
			if(ww<767){
				var colspan = $('.totalamt').attr('colspan');$('.totalamt').attr('data-colspan',colspan);$('.totalamt').attr('colspan','2');
			}
			else{
				var colspan = $('.totalamt').data('colspan');$('.totalamt').attr('colspan',colspan);
			}
			
		});

		

	});

	

</script>



</body>



</html>


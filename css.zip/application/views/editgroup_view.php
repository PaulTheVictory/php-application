
<style type="text/css">
    
    input[type="text"], input[type="password"]{
        width: 96%;
    }
    
</style>
<div id="pagetitle">

	<div class="wrap">
    
    	<h1>Edit Model</h1>
        
	</div>
    
</div>
<div class="maincontent">

	<div class="wrap">
    
            <div id="course-container" class="add-course-date">

                <div class="row-element">
                    <span class="title" style="padding: 0px;padding-top: 10px">Model</span>
                    <span class="content"><input type="text" value="<?php echo html_escape($edit['grpname']);?>" class="name" id="grpname"><input style="margin-left: 10px" type="checkbox" class="chk_name"></span>
                </div>

                <div class="row-element">
                    <span class="title" style="padding: 0px;padding-top: 10px">Discount (%)</span>
                    <span class="content"><input type="text" value="<?php echo $edit['discount'];?>" class="discount"><input style="margin-left: 10px" type="checkbox" class="chk_discount"></span>
                </div>
            
                <div class="row-element">
                    <span class="title" style="padding: 0px;padding-top: 10px">For Customer Profit Margin (%)</span>
                    <span class="content"><input type="text" value="<?php echo $edit['cdiscount'];?>" class="cust_discount"><input style="margin-left: 10px" type="checkbox" class="chk_cmargin"></span>
                </div>
            
            
                <div class="row-element">
                    <span class="title" style="padding: 0px;padding-top: 10px">For Electrician Profit  Margin (%)</span>
                    <span class="content"><input type="text" value="<?php echo $edit['ediscount'];?>" class="elec_discount"><input style="margin-left: 10px" type="checkbox" class="chk_emargin"></span>
                </div>
                
                <div class="row-element">
                    <span class="title" style="padding: 0px;padding-top: 10px">Tax (%)</span>
                    <span class="content"><input type="text" value="<?php echo $edit['tax'];?>" class="tax"><input style="margin-left: 10px" type="checkbox" class="chk_tax"></span>
                </div>
            
                 <div class="row-element">
                    <span class="content">
                        <input style="float: left" type="submit" class="course-submit" value="Submit">
                        <p class="errnotify" style="color:#aa3e41;margin:0px;padding:0px;float:left;padding-left:20px;padding-top:10px"> </p>
                        <input type="hidden"  class="cur_name" value="<?php echo $edit['grpname']; ?>">
                         <input type="hidden" value="<?php echo $edit['discount']; ?>"  class="cur_discount">
                          <input type="hidden" value="<?php echo $edit['cdiscount']; ?>"  class="cur_cdiscount">
                           <input type="hidden" value=<?php echo $edit['ediscount']; ?>"" class="cur_ediscount">
                      
                    </span>
                </div>
                
            </div>
        
        </div>
    
    </div>
<script type="text/javascript">
$(document).ready(function() {
	
	
	$(".add-course-date").find("input").each(function(){

          $(this).click(function(){ 
          
           $(".errnotify").html("&nbsp;");});

    });
    
    
    $(".add-course-date").find("input").each(function(){
            
            $(this).keyup(function(event){
                if(event.keyCode == 13){
                    var ty = $(this).next();
                    event.preventDefault();
                    $('input')[$('input').index(this)+1].focus();
                    $('input')[$('input').index(this)+1].select();
                }
            });

            $(this).click(function(){ $(".errnotify").html("&nbsp;");});
            

        });
   
	
	$(".add-course-date").find(".course-submit").click(function(){
		
		var name = $(".add-course-date").find(".name").val();
                var discount = $(".add-course-date").find(".discount").val();
                var cdiscount = $(".add-course-date").find(".cust_discount").val();
                 var ediscount = $(".add-course-date").find(".elec_discount").val();
                 var tax = $(".add-course-date").find(".tax").val();
                              
              
		
		$(this).val("Processing...");
		
				$.get('editgroup/updateGroup',{
					   'name':name, 
                                           'discount':discount, 
					   'cdiscount':cdiscount,
                                           'ediscount':ediscount,
                                           'tax':tax,
                                           'id':'<?php echo $edit['id'];?>'
                                           

				}, function(o) { 
					var obj1 = $.parseJSON(o);
					if(obj1[0] === 'success'){
						    
                                            $(".errnotify").html("<font style=\"color:#188f04\">Group has been edited succesfully!!</font>");
					    setTimeout(function(){ window.location.assign("group"); }, 500);
                                                
					}else if(obj1[0] === 'fail'){
                                                   $(".add-course-date").find(".course-submit").val("Submit");
                                                   alert("Error!! Please try again");                                                    
						
					}
				});	 
		
  	});
	
});
</script>
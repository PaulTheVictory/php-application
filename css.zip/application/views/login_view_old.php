<div id="pagetitle">

	<div class="wrap">
    
    	<h1>Login</h1>
        
	</div>
    
</div>

<div class="maincontent" style="text-align:center;">

	<div class="wrap">
    
    	<div id="loginform">    	

            <input type="text" placeHolder="User Name" id="emailid" />
            
            <input type="password" placeHolder="Password" id="password" />            
        
            <button id="loginbtn">Login</button>
            
            <div class="clear"></div>
            
            <span class="errnotify">&nbsp;</span>
            
            <div class="clear"></div>
            
        </div>
            
        <div class="clear"></div>
        
        
    
    </div>
    
</div>

<script type="text/javascript">
$(document).ready(function() {
	
	$("#loginform").find("#password").keyup(function(event){
    	if(event.keyCode == 13){
        	$("#loginbtn").click();
    	}
  	});
	
	$("#loginform").find("input").each(function(){

          $(this).click(function(){ $(".errnotify").html("&nbsp;");});

    });
	
	$("#loginform").find("#loginbtn").click(function(){
		
		var emailid = $("#loginform").find("#emailid").val();
		var password = $("#loginform").find("#password").val();
		
		if(emailid==""){ $(".errnotify").html("Invalid Email Address");return;}		
		if(password==""){ $(".errnotify").html("Invalid Password");return;}
		
		$(this).text("Processing...");
		
				$.get('login/verifyLogin',{
					   'emailid':emailid, 
					   'password':password

				}, function(o) { 
					var obj1 = $.parseJSON(o);
					if(obj1[0] == 'fail'){
						setTimeout(function(){ $(".errnotify").html("Member ID and Password did not match"); $("#loginform").find("#loginbtn").text("Login"); }, 500);
					}else if(obj1[0] == 'notactive'){
						setTimeout(function(){ $(".errnotify").html("Account is not active"); $("#loginform").find("#loginbtn").text("Login"); }, 500);
					}else if(obj1[0] == 'notfound'){
						setTimeout(function(){ $(".errnotify").html("Member ID not exists"); $("#loginform").find("#loginbtn").text("Login"); }, 500);
					}else if(obj1[0] == 'success'){
							location.reload("dashboard");
					}else if(obj1[0] == ''){
						setTimeout(function(){ $(".errnotify").html("Please try again later"); $("#loginform").find("#loginbtn").text("Login"); }, 2000);						
					}
				});	 
		
  	});
	
});
</script>
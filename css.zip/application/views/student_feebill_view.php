<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Brilliant Study Centre, Pala</title>
<!--<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1">-->

<link rel="stylesheet" href="<?php echo base_url();?>css/boot/bootstrap.min.css">
<link rel="stylesheet" href="<?php echo base_url();?>css/boot/bootstrap.rtl.only.min.css">
<link rel="stylesheet" href="<?php echo base_url();?>css/boot/bootstrap-float-label.min.css">
<link rel="stylesheet" href="<?php echo base_url();?>css/boot/main.css">

<script src="<?php echo base_url();?>js/jquery-3.5.1.min.js"></script>


<script type="text/javascript">
$(document).ready(function(){
	
	var $billclone = $(".feebill").clone();
	$('.billclone').html($billclone);
	
	window.print();

});
</script>

<style>
		
	.feebill h1{font-size: 18px;color: #364159;}
	.feebill .card{background: linear-gradient(0deg, #FFFFFF, #FFFFFF), #C4C4C4;box-shadow: 0px 0px 7px rgba(196, 196, 196, 0.35);border-radius: 0px;width: 100%;border-bottom: 11px solid #0332AA;}
	.feebill h2{color: #0332AA;font-size: 24px;font-weight: bold;line-height: 36px;}
	.feebill h3{color: #181E29;font-size: 16px;font-weight: bold;line-height: 24px;}
	.feebill h4{font-size: 12px;font-weight: bold;color: #355BBB;line-height: 20px;letter-spacing: 0.5px;text-transform: uppercase;}
	.feebill p.list-item-heading{color: #6884CC;font-weight: 600;}
	.feebill p.list-item-heading span:last-child{font-weight: 600;font-size: 14px;color: #364159;}
	.feebill p{color: #181E29;font-size: 12px;line-height: 18px;font-weight: normal;margin-bottom: 5px;}		
	.border-right{border-right: 1px solid #D7DFF0!important;}
		
	p.totalfee {font-weight: bold;font-size: 24px;color: #D63333;}
	
	.table{border: 0px solid #364159;border-collapse: separate !important;border-style: solid;border-radius: 10px;box-shadow: 0 0 0 0px #364159;margin: 1rem; table-layout: fixed;border-spacing: 0px;}
	.table thead th{font-size: 12px;font-weight: 600;color: #6F83AA;letter-spacing: 0.5px;background: #E6EBF7;text-transform: none;padding: 0.5rem;text-align: left;vertical-align: middle;border-bottom: 0px solid #364159;}
	.table thead tr th:first-child{border-top-left-radius: 10px;border-top: 0px solid #364159;}
	.table thead tr th:last-child{border-top-right-radius: 10px}
	.table td, .table th{font-size: 12px;border-top: 0px solid #364159;padding: 0.9rem 0.75rem;color: #364159;font-weight: 600;}
	.thtax{display: block;text-align: center;}
	.thtaxvalue{display: flex;}
	.thtaxvalue span:first-child{width: 53%}
	
	
.table {
    border: 1px solid #364159;
    -moz-border-radius: 10px;
    -webkit-border-radius: 10px;
    border-radius: 10px;
}
.table td, .table th {
    border-left: 0px solid #364159;
    border-top: 1px solid #364159;
    padding: 10px;
    text-align: left;
}
.table tr th:first-child{border-top: 1px solid #364159;border-radius: 0px}
.table th {
    background-color: transparent;
    border-top: none;
}
.table td:first-child, .table th:first-child {
    border-left: none;
}
.table th:first-child {
    -moz-border-radius: 10px 0 0 0;
    -webkit-border-radius: 10px 0 0 0;
    border-radius: 10px 0 0 0;
}
.table th:last-child {
    -moz-border-radius: 0 10px 0 0;
    -webkit-border-radius: 0 10px 0 0;
    border-radius: 0 10px 0 0;
}
.table th:only-child{
    -moz-border-radius: 10px 10px 0 0;
    -webkit-border-radius: 10px 10px 0 0;
    border-radius: 10px 10px 0 0;
}
.table tr:last-child td:first-child {
    -moz-border-radius: 0 0 0 10px;
    -webkit-border-radius: 0 0 0 10px;
    border-radius: 0 0 0 10px;
}
.table tr:last-child td:last-child {
    -moz-border-radius: 0 0 10px 0;
    -webkit-border-radius: 0 0 10px 0;
    border-radius: 0 0 10px 0;
} 
	
	.table td.totalfee {font-weight: bold;font-size: 16px;color: #D63333;}
	.table td.totalamt {font-weight: bold;font-size: 12px;color: #6F83AA;letter-spacing: 0.5px;text-transform: uppercase;text-align: right !important}
	.table tr:last-child td{text-align: center}
	.table tr td:last-child,.table tr th:last-child{text-align: center}
	.table tr:last-child td:last-child{font-weight: bold;text-align: center}
	.table tr:last-child{text-align: center}
	
	.feebill .hr{width: 100%;height: 3px;background: #0332AA;}
	
	main{max-width: 100%;margin: auto}
	
</style>


<?php 
	
	//print_r($feepaybill);

	$tablepay = $tablepaynow = $ide = "";
	$sno = $psno = 1;

	$grandtotal = $grandtotalnow = $totalfee = $paidfee = $duefee = $discountfee = $discount = 0;

	$coursename = $center = $paymentmode = $paymentdate = $receiptno = "";
	$checkdiscount = false;

	foreach($feesmaster as $key=>$feemaster){
		
	foreach($feepaybill['feebilldetails'] as $paylist){
		
		if($feemaster['description'] == $paylist['description']){

		$amount = $paylist['amount'];
		$paymentamount = $paylist['paymentamount'];
		$total = $paylist['total'];
		$taxable = $paylist['taxable'];
		$paymentmode = $paylist['paymentmode'];
		$paymentdate = $paylist['paymentdate'];
		$receiptno = $paylist['receiptno'];
		$kf = $paylist['kf'];
		$cov = $paylist['cov'];
		$sac = 999293;
		
		if($paymentamount==0) continue;	
		
		//$thtaxable = '<th scope="col" width="10%">Taxable</th>';
		//$thnontaxable = '<th scope="col" width="10%">Non Taxable</th>';

		$discount = $paylist['discount'];
		$discountamt = 0;$thdiscount = $tddiscount = $thtax =  $tdtax = "";
		$taxamt = 0;
		$colspan=9;
		
		$tax = $paylist['tax'];
		
		/*$amount1 = round($amount - ($amount * ($tax+$kf)/ (100+$tax+$kf)));
		if($amount==$amount1) $amount = $amount; else $amount = $amount1;*/
		
		$activetotalamt = $amount;	
				
		if(intval($discount)>0) {
							
			$discountamt = $discount;
			//$tddiscount = '<td width="10%">'.$discountamt.'</td>';

			$amount = $amount - $discount;

			$checkdiscount = true;
                        
                        $activetotalamt = $amount;

		}else{
			//$tddiscount = '<td>[DISCOUNT]</td>';
		}
		
		if($tax=="0" || $tax=="NA"){
			
			$tdnontaxable = $amount;
		}else{
			$tdnontaxable = 0;
		}
		
		if($tax!="0" && $tax!="NA"){ 
		
			$tdtaxable = $amount;				

			$taxgst = $tax/2;
			if(intval($tax)>0) $taxamt = $amount * ($tax/100);
			$taxamtgst = $taxamt/2;
			$taxamtgst = number_format($taxamtgst,2);
			
			//$colspan +=4;
			
		} else {
			$tdtaxable = 0;
			$taxgst = $taxamtgst = "NA";
		}
		
		$thtax = '<th scope="col" colspan="2" width="19%"><span class="thtax">CGST</span> <span class="thtaxvalue"><span>Rate %</span> <span>Amount</span></span></th>
			  <th scope="col" colspan="2" width="19%"><span class="thtax">SGST</span> <span class="thtaxvalue"><span>Rate %</span> <span>Amount</span></span></th>';

		$tdtax = '<td width="8%">'.$taxgst.'</td>
				  <td width="8%">'.$taxamtgst.'</td>
				  <td width="8%">'.$taxgst.'</td>
				  <td width="8%">'.$taxamtgst.'</td>';

		$nontaxvalue = $amount;
		$taxvalue = $amount + $taxamt;
		
					
		$tdkf = $thkf = "";	$colwidth = 15;
		if($kf!="" && $kf!="0"){

			$kfamt = $amount * ($kf/100);

			$thkf = '<th scope="col" width="8%">CESS KF(%)</th>
					 <th scope="col" width="8%">CESS KF Amount</th>';
			$tdkf = '<td width="12%">'.$kf.'</td>
					 <td width="8%">'.$kfamt.'</td>';

			$colspan += 2;
			$colwidth -= 5;
		}
				

		$grandtotal += $total;

		$tablepay .= '<tr>
					  <th scope="row" width="7%">'.$sno.'.</th>
					  <td width="15%"><strong>'.$paylist['description'].'</strong></td>
					  <td width="11%">'.$activetotalamt.'</td>
					  <td width="11%">'.$tdnontaxable.'</td>
					  <td width="11%">'.$tdtaxable.'</td>
					  '.$tddiscount.'
					  '.$tdtax.'
					  '.$tdkf.'
					  <td width="10%">'.number_format($total,2).'</td>
					</tr>';

		$sno++;
	}
		
	}
		
	}
	
	/*if($checkdiscount){ 
		$thdiscount = '<th scope="col" width="10%">Discount</th>';
		$tablepay = str_replace("<td>[DISCOUNT]</td>",'<td width="10%">0</td>',$tablepay);
		$colspan +=1;
	}
	else{
		$tablepay = str_replace("<td>[DISCOUNT]</td>",'',$tablepay);
	}*/

function getIndianCurrency(float $number)
{
    $decimal = round($number - ($no = floor($number)), 2) * 100;
    $hundred = null;
    $digits_length = strlen($no);
    $i = 0;
    $str = array();
    $words = array(0 => '', 1 => 'one', 2 => 'two',
        3 => 'three', 4 => 'four', 5 => 'five', 6 => 'six',
        7 => 'seven', 8 => 'eight', 9 => 'nine',
        10 => 'ten', 11 => 'eleven', 12 => 'twelve',
        13 => 'thirteen', 14 => 'fourteen', 15 => 'fifteen',
        16 => 'sixteen', 17 => 'seventeen', 18 => 'eighteen',
        19 => 'nineteen', 20 => 'twenty', 30 => 'thirty',
        40 => 'forty', 50 => 'fifty', 60 => 'sixty',
        70 => 'seventy', 80 => 'eighty', 90 => 'ninety');
    $digits = array('', 'hundred','thousand','lakh', 'crore');
    while( $i < $digits_length ) {
        $divider = ($i == 2) ? 10 : 100;
        $number = floor($no % $divider);
        $no = floor($no / $divider);
        $i += $divider == 10 ? 1 : 2;
        if ($number) {
            $plural = (($counter = count($str)) && $number > 9) ? 's' : null;
            $hundred = ($counter == 1 && $str[0]) ? ' and ' : null;
            //$str [] = ($number < 21) ? $words[$number].' '. $digits[$counter]. $plural.' '.$hundred:$words[floor($number / 10) * 10].' '.$words[$number % 10]. ' '.$digits[$counter].$plural.' '.$hundred;
			$str [] = ($number < 21) ? $words[$number].' '. $digits[$counter].' '.$hundred:$words[floor($number / 10) * 10].' '.$words[$number % 10]. ' '.$digits[$counter].' '.$hundred;
        } else $str[] = null;
    }
    $Rupees = implode('', array_reverse($str));
    $paise = ($decimal > 0) ? "." . ($words[$decimal / 10] . " " . $words[$decimal % 10]) . ' Paise' : '';
    //return ($Rupees ? $Rupees . 'Rupees ' : '') . $paise;
	return (ucwords($Rupees) ? ucwords($Rupees) : '') . ucwords($paise);
}

?>
<main>

	<div class="container-fluid">
		
	<div class="row feebill">
								
		<div class="card mb-2 p-4">
		
			<div class="row">
					
			<div class="col-md-6">
			
				<img src="<?php echo base_url(); ?>css/img/brilliant-logo.png" alt="Brilliant Pala Logo" class="mb-2" />
				
				<div class="mt-3"></div>
				
				<p>Receipt No. : <strong><?php echo $receiptno; ?></strong></p>
				<p>Dated : <strong><?php echo date("d-m-Y h:i A",strtotime($paymentdate)); ?></strong></p>
									
			</div>
			<div class="col-md-6 text-right">
				<h3>Brilliant Study Centre, Pala.</h3>
				<p>GSTIN: <strong>32AAEFB8385KIZ7</strong></p>
				<p>Mutholy, Puliyannoor PO, 686-573.</p>
				<p>Phone: 04822 206 100</p>
				<p>Email: admissions@brilliantpala.org</p>
			</div>
			
		
		</div>
			
			<div class="hr mt-1 mb-2"></div>
			
		<div class="row">
			
			<div class="col-md-6">
			
				<p>Student Id: <strong><?php echo $user['stuid']; ?></strong></p>
				<p class="mb-0">Student: <strong><?php echo strtoupper($user['pname']); ?></strong></p>
				
				<?php if(!empty($feepaybill['studentdetails'])){ ?>
				
				<div class="row">
					<div class="col-md-1"></div>
					<div class="col-md-6">
						<p><?php echo $feepaybill['studentdetails'][0]['housenameno']." ".$feepaybill['studentdetails'][0]['contactaddress'].", ".$feepaybill['studentdetails'][0]['contactpost'].", ".$feepaybill['studentdetails'][0]['contactdistrict'].", ".$feepaybill['studentdetails'][0]['contactstate'].", ".$feepaybill['studentdetails'][0]['contactcountry']." ".$feepaybill['studentdetails'][0]['contactpincode'].'.'; ?></p>
					</div>
				</div>
				
				<?php }?>
				
			</div>
			<div class="col-md-6 text-right">
				
				<p>Course:  <strong>[<?php echo $feepaybill['course'][0]['coursename']; ?>, <?php echo $feepaybill['course'][0]['center']; ?>]</strong></p>
				
			</div>
			
		</div>	
		
		<div class="row mb-2">
		
		 <table class="table">
              <thead>
                <tr>
                  <th scope="col" width="5%">Sl. no.</th>
                  <th scope="col" width="18%">Description</th>
                  <th scope="col" width="10%">Total Fee</th>
                  <th scope="col" width="<?php echo $colwidth;?>%">Non Taxable Value</th>
                  <th scope="col" width="<?php echo $colwidth;?>%">Taxable Value</th>
                  <?php echo $thdiscount;?>
				  <?php echo $thtax;?>
				  <?php echo $thkf;?>
                  <th scope="col" width="14%">Total</th>
                </tr>
              </thead>
              <tbody>
               
               
               <?php echo $tablepay;?>
                
                <!--<tr>
				  <th scope="row" width="5%">1.</th>
				  <td width="25%"><strong>Tuition Fee</strong></td>
				  <td width="10%">97531</td>
				  <td width="10%">12</td>
				  <td width="10%">12,000</td>
				  <td width="8%">9</td>
				  <td width="8%">1350</td>
				  <td width="8%">9</td>
				  <td width="8%">1350</td>
				  <td width="10%">2,000.00</td>
				</tr>-->
               
                <!--<tr>
				  <th scope="row" width="5%">2.</th>
				  <td width="25%" colspan="8"><strong>Kerala Flood 1% CESS Taxable value</strong></td>
				  <td width="10%">42.00</td>
				</tr>-->
                
                <tr>
                  <td colspan="<?php echo $colspan;?>" class="totalamt">Grand total</td>
                  <td class="totalfee"><?php echo number_format($grandtotal,2); ?></td>
                </tr>
              </tbody>
            </table>
            
			</div>
          
           
			<p class="mb-2">Total Amount: <strong>Rs.<?php echo number_format($grandtotal); ?>/- (<?php echo getIndianCurrency($grandtotal); ?> Only)</strong></p>

			<p class="mb-2">Payment Mode: <strong><?php echo strtoupper($paymentmode); ?></strong></p>

			<p class="mb-2">Remitted On: <strong><?php echo date("d-m-Y",strtotime($paymentdate)); ?></strong></p>
            
            
            <div class="row d-flex align-items-end mt-3 mb-0">
			
			<div class="col-md-6">
			
				<!--<img src="<?php //echo base_url(); ?>img/bill-barcode.png" alt="Barcode" width="30%" class="mb-3" />-->
				
			</div>
			<div class="col-md-6 text-right">
				
				<h4>Computer generated receipt</h4>
				
			</div>
			
		</div>

            
			</div>
			
		</div>
		
		<div class="mt-0 mb-2 w-100" style="border-bottom: 1px dashed #dee2e6!important;"></div>
		
		<div class="billclone"></div>
		

	</div>
</main>
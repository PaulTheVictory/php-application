<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/dataTables.css?v=1.5" />
<script src="<?php echo base_url(); ?>js/jquery.dataTables.js?v=1.0" type="text/javascript"></script>
<link href="<?php  echo base_url(); ?>css/jquery-ui.min.css?v=1.4" rel="stylesheet" type="text/css" />
 <script src="<?php  echo base_url(); ?>js/jquery-ui.min.js?v=1.3" type="text/javascript"></script>
<style type="text/css">


.dataTables_wrapper input[type="text"] {
    padding: 0;
}
.dataTables_wrapper select {
    padding: 0;
}

.sortable thead tr  {
    background: #E6EBF7;

/* g8 */
border: 1px solid #D7DFF0;
box-sizing: border-box;
border-radius: 10px 10px 0px 0px;
 

}
.sortable tr th {
    border-right: 0px;
    padding: 15px 0;font-size: 13px;
      color: #6F83AA;
   cursor: pointer;
   text-align: center;

}

.sortable tr th:nth-child(2) {
  
   text-align: left;
}

.sortable tr td:nth-child(2) {
  
   text-align: left;
}

.sortable tr th:nth-child(4) {
  
   text-align: left;
}

.sortable tr td:nth-child(4) {
  
   text-align: left;
}

/*.sortable tr th:nth-child(1) {
  width: 50px !important;
}

.sortable tr th:nth-child(2) {
    width: 10% !important;
  background: none;
   text-align: left;
}


.sortable tr th:nth-child(3) {
  background: none;
  width: 25% !important;
   text-align: center;
}

.sortable tr th:nth-child(6) {
  background: none;
  width: 20% !important;
   text-align: center;
}

.sortable tr th:nth-child(7) {
  background: none;
  width: 70px !important;
   text-align: center;
}
*/

.sortable tr td {
    border-right: 0px;
    padding: 5px 5px;
    text-align: center;font-size: 13px;
    min-width:50px;vertical-align: middle;
}
.sortable tr td a {
    color: #364159;
}

#profile-right h2 {
    margin: 0px 0px 10px 0px;
}

.studenttable_length { width: auto !important; }
#studenttable_filter input { padding-top:4px;background: #fff url('<?php echo base_url(); ?>/images/search.png') no-repeat center left;background-position-x: 10px;border: 1px solid #D7DFF0; line-height: 32px;margin-left: 10px;width:260px;border-radius: 5px;text-indent: 30px;font-size: 13px;}
.sortable tr td a:hover { text-decoration: underline; }
.dataTables_filter { right:10px !important;}
	

.btn-outline-primary {color: #0332AA;border-color: #0332AA;background-color: transparent;font-weight: 600;font-size: .8rem;text-transform: none;margin: 0 10px}
.btn {border-radius: 5px;outline: initial!important;box-shadow: none!important;box-shadow: initial!important;font-size: .8rem;padding: .5rem 1.25rem .5rem 1.25rem;transition: background-color box-shadow .1s linear;margin-bottom: 7px}
.btn-outline-primary:not(:disabled):not(.disabled).active, .btn-outline-primary:not(:disabled):not(.disabled):active, .show>.btn-outline-primary.dropdown-toggle,.btn-outline-primary:hover {background-color: #0332AA;border-color: #0332AA;color: #fff;}
.ui-selectmenu-button.ui-button{ width: 125px;margin-top: 10px;float: right;border: 1px solid #D7DFF0;background: #fff;font-size: 13px;color:#536485;padding: 8px;margin-bottom: 4px;}
.ui-menu-item .ui-menu-item-wrapper{font-size: 13px}
	
</style>
<script type="text/javascript">
$(document).ready(function(){	
		
	
	
	$("#searchtype").selectmenu();
		
	
	 $(document).delegate("#searchtype","selectmenuchange",function(event){
         
		 //oTable.fnDraw();
		 
	});
	
	 $(document).on("click",".clear",function(){
		
		$("#searchtype").selectmenu('destroy');
	    $("#searchtype").prop('selectedIndex',0);
	    $("#searchtype").selectmenu();
		
	});
	
          var columnData = [
              
                    { "data": "studid" },                
                    { "data": "sname" }, 
                    { "data": "mobile" }, 
                    { "data": "email"},
                     { "data": "roll_number"},
                    { "data": "city"},
                    { "data": "center"},
                    { "data": "remitted" , "searchable": false},                   
                    { "data": "download_ht" , "searchable": false}                       
                    
                  ];
        // columnData.push( {data: "id","visible":true} );
         //columnData.push( {data: "item_name_search","visible":false} );
         
       
        var oTable = $('#studenttable').dataTable({
                    "bProcessing": true,
                    "bServerSide": true,
                    "sPaginationType": "full_numbers",
                    "ajax": {
                    "url": 'screeningtest/GetAdmissionStuLists',
                    "type": "POST",
                    "data":function(data){ 
                        
						var searchtype = $("#searchtype").val();
						
						data.searchcol= searchtype;
                        data.courseid = "<?php echo html_escape($courseid); ?>";     
                        data.type = "<?php echo html_escape($mode); ?>";  
                      }
                     }, 
                     "oLanguage": {
                        "sProcessing": "<img src='<?php echo base_url(); ?>images/loader.gif'>"
                    },
                    'iDisplayLength': 20,
                    "columns": columnData,
                    "order": [[1, "desc" ]],
                    "fnDrawCallback": function( oSettings ) {
                        
                         $(".status").each(function(){
                             
                             var rid = $(this).attr("data-rid");
                             var pid = $(this).attr("data-pid");
                             if(rid === 'p') { $(this).html('<p style="margin:0px;background:#3CAF92;padding:5px;color:#fff;width: 70px;border-radius: 5px;font-size:11px">Paid</p>'); }
                             
                             if(rid === '') { $(this).html('<p style="margin:0px;background:#ED5252;padding:5px;color:#fff;width: 70px;border-radius: 5px;;font-size:11px">Unpaid</p>'); }
                             
                         }); 
                        
                     },"initComplete" : function() {
						
						var input = $('.dataTables_filter input').unbind(),
							self = this.api(),
							$searchButton = $('<button class="btn btn-outline-primary ml-3 search">')
									   .text('search')
									   .click(function() {
										  self.search(input.val()).draw();
									   }),
							$clearButton = $('<button class="btn btn-outline-primary ml-3 clear">')
									   .text('clear')
									   .click(function() {
										  input.val('');
										  $searchButton.click(); 
									   }) 
						$('.dataTables_filter').append($searchButton, $clearButton);
                                                
                                                 $(input).keyup(function(event){
                                                    if(event.keyCode == 13){
                                                        event.preventDefault();
                                                        $('.search').trigger('click');
                                                    }
                                                });
					}
         }); 
         
         
         
  $("#markExport").click(function(){
               
               var url = 'screeningtest/export?courseid=<?php echo $courseid; ?>&type=<?php echo $mode; ?>';
               $(location).prop('href', url);
               
            });
	
});
</script>


<div class="wrap dynamic-width" style="float: left;position: relative">
    
    <div style="margin-top: 10px; width: 100%; height: 100px; text-align: right;">
             <span style="font-weight: bold;font-size: 20px;padding: 10px;float:left;color: #364159">Screening Test Results</span>
                         
             <div class="row-element">
                 <span class="title" style="padding: 0px;padding-left: 10px;color: #6F83AA">Screening Test Name</span>                    
                    <span class="content" style="padding: 0px;color:#0332AA;font-weight: bold;width: 24%;min-width: 0;">
						<?php echo $coursename;?>
					</span>
                    
                     <?php if(isset($roleaccess['Export ST'][3]) && $roleaccess['Export ST'][3]=="y"){?>
                     
						 <span class="content" style="padding: 0px;color:#0332AA;font-weight: bold;width: 10%;min-width: 0;">

								<span id="markExport" style="cursor: pointer;margin-left:20px;font-weight: bold;font-size: 14px;padding: 5px 10px;color: #fff;border-radius:5px;background: linear-gradient(180deg, #4F70C4 0%, #1C47B3 100%);">Export</span>

						</span>  
                       
                       <?php }?>
                                     
                       <span class="content" style="padding: 0px;width: 10%;min-width: 0;position: relative;top: -16px">
						 <select id="searchtype">
							 <option value="stuid">Student ID</option>
							 <option value="stuname">Student Name</option>
							 <option value="mobile">Mobile</option>
							 <option value="email">Email</option>
							 <option value="rollno">Roll No</option>
                                                         <option value="city">City</option>
							 <option value="center">Center</option>
						 </select>
					  </span>           
                                       
                </div>
            </div>         
         <?php echo $this->table->generate();  ?>             
         
        
        
        </div>
    
 
    


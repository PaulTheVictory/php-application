 <script src="<?php echo base_url();?>js/bootstrap.bundle.min.js"></script>
<link href="<?php  echo base_url(); ?>css/jquery-ui.min.css?v=1.4" rel="stylesheet" type="text/css" />
 <script src="<?php  echo base_url(); ?>js/jquery-ui.min.js?v=1.3" type="text/javascript"></script>
 <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/dataTables.css?v=1.5" />
<script src="<?php echo base_url(); ?>js/jquery.dataTables.js?v=1.0" type="text/javascript"></script>
<link rel="stylesheet" href="<?php echo base_url();?>css/boot/bootstrap.min.css">
<link rel="stylesheet" href="<?php echo base_url();?>css/boot/main.css?v=1">

 <style type="text/css">
     
     .ui-selectmenu-button.ui-button{ width: 97%; padding:13px;}
     #country-button,#state-button,#District-button{border: 1px solid #D7DFF0;background: #fff;font-size: 14px;color:#536485;padding: 10px}
     .maincontent ul li.search-choice { height:auto; }
     .maincontent ul li.search-choice a{ height:auto; font-size: 14px;color:#536485}
     .response p { float: right;font-size:12px;color:#eb345e;}
     
.sortable thead tr {
    background: #E6EBF7;
    border: 1px solid #D7DFF0;
    box-sizing: border-box;
    border-radius: 10px 10px 0px 0px;
}
.sortable tr th {
    border-right: 0px;
    padding: 20px 0;font-size: 13px;
      color: #6F83AA;
   cursor: pointer;
   text-align: center;

}

.sortable tr td:nth-child(1) {
   
    min-width:50px;color: #364159;
}

.sortable tr td:nth-child(2) {
   
    width:40%;
}

.sortable tr td {
    border-right: 0px;
    padding: 15px 5px;
    text-align: center;font-size: 13px;
    min-width:100px;
}
.sortable tr td a {
    color: #364159;
}

.dataTables_info { display: none; }
#locationtable_filter input {display:none;}
.sortable tr td a:hover { text-decoration: underline; }
.sortable tr td span{ font-size: 14px;color: #364159 }
 </style>

	<div class="wrap dynamic-width" style="float: left;position: relative;min-width: 800px">
     <div style="margin-top: 10px; width: 99%; height: 50px; text-align: right;">
         <span style="font-weight: bold;font-size: 20px;padding: 10px;float:left;color: #364159">Add City</span>
         
     </div>        
           
            <?php if(isset($roleaccess['City'][0]) && $roleaccess['City'][0]=="y"){ ?> 
             
            <div id="course-container" class="add-course">
<?php echo form_open('city/citySubmit', array('id' => 'locationForm')) ?>
                <div class="row-element">
                    <span class="content"><input placeholder="City Name" type="text" value="" name = "cname" class="cname"></span>
                </div>
      
                
                <div class="row-element" >
                    
                    <span class="content">
                        
                        <label style="color:#536485;background: none;border: 0px;width: 48%;height: auto;float:left;">
                            <input type="text" name = "batchqty" class="batchqty" placeholder="Batch Quantity"> 
                         </label>
                    </span>
                </div>
                
                
            <?php echo form_close() ?>
                
            </div>
            
       
     <div style="margin-top: 0px; width: 98%; height: 70px; text-align: right;">
         <span  style="margin: 0px auto; float:right;margin-top: 18px;padding: 10px; color: #fff; background: #4f6fc4 none repeat scroll 0% 0%; border-radius:5px;cursor: pointer" class="btn savebtn" href="#">Save</span>
         <a style="margin: 0px auto; float:right;margin-top: 18px;margin-right:18px;padding: 9px 10px; color: #0332AA; background: linear-gradient(0deg, #FFFFFF, #FFFFFF), #C4C4C4;border: 1px solid #0332AA; border-radius:5px" class="btn" href="<?php echo base_url(); ?>city">Reset</a>
         <span class="response" style="margin: 0px auto; float:right;width: 80%; height: 30px;margin-top:20px"></span>
     </div>   
           
           <?php } ?> 
           
            <label style="color:#536485;background: none;border: 0px;width: 4%;height: 80px;float:left;">&nbsp;</label>     
       <div style="width:100%;height: auto;float:left">
         <?php echo $this->table->generate();  ?>             
         
        </div>     
        
        </div>
    
             <style>

	.courseredirect{background: #3CAF92 !important;display: block;margin: auto;border: 1px solid #209679;}
	h5.modal-title p.headtitle{display: inline-block;width: 100%;text-align: center;font-weight: bold;font-size:17px;color: #fff;}
	h5.modal-title p.text-muted{display: inline-block;width: 100%;text-align: center;font-weight: 600;font-size: 14px;line-height: 36px;color: #181E29;line-height: 20px;}
	.modal-title img{display: block;margin: 1em auto}
        #paydoneModal.modal .modal-header,#payfailModal.modal .modal-header{padding: 10px 20px !important;border: none}	
		#paydoneModal.modal .modal-body,#payfailModal.modal .modal-body{padding:0 1.75rem 1.75rem}
		.modal-body p{text-align: left !important}
		.modal-backdrop.show {opacity: .5 !important;}
			 
			  .hide{display: none}
			 
	</style>
	
	
	<?php if(isset($roleaccess['City'][1]) && $roleaccess['City'][1]=="y"){ ?> 
	
<button type="button" class="btn btn-outline-primary d-none courseconfirm" data-toggle="modal" data-backdrop="static" data-target="#courseModal">Confirm Submission</button>  
<!-- Modal -->


<div class="modal fade" id="courseModal" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog modal-xl" role="document">
	<div class="modal-content">
            <div class="modal-header" style="background-color: #6884CC;height: 50px;width: auto;padding: 10px">
	  
		<h5 class="modal-title w-100" id="exampleModalLabel">
		
			<div class="row">
			
				<div class="col-4">
					<p class="headtitle text-left">Edit City</p>
				</div>
				
			</div>
			
		</h5>
	 </div><?php echo form_open('city/citySubmit', array('id' => 'editlocationForm')) ?>
            <div class="row" style="width: 98%;margin: 0px auto;margin-top: 25px;">
                <div class="col-12 col-sm-6" >
                    <div class="form-group position-relative error-l-50 floating">
                      <input placeholder="City Name" type="text" name = "cname" id="cityname" class="form-control">
                       <label for="ciyname">City Name<span>*</span></label>
                    </div>
                    
		</div>
                <div class="col-12 col-sm-6" >
                    <div class="form-group position-relative error-l-50 floating">
                        <input type="text" value="" class="form-control" name="batchqty" id="bqty"   placeholder=" " >
                        <input type="hidden" class="" name="eide" id="eide" >
                     <label for="bqty">Batch Qty <span>*</span></label>
                    </div>
		</div>
          
        </div> <?php echo form_close() ?>
	  <div class="modal-footer">
                                <div class="form-group"> <span class="eresponse"></span></div>
	 			 <div class="form-group"> 
	 			 
					<button type="button" class="btn btn-primary paycancel float-left" data-dismiss="modal">Cancel</button>
					
				</div> 
				<div class="form-group">
				
					<button type="button" class="btn btn-primary previewbtn float-right editsave" >Save</button>
                
                </div> 
             
        
	  </div>
	</div>
  </div>
  </div> 
   
   <?php } ?> 
    
<script type="text/javascript">
$(document).ready(function() {
    
    
     var columnData = [
                   
                    { "data": "sno" },
                    { "data": "name" },                    
                    { "data": "batchqty" },                
                     { "data": "id" }
                    
                  ];
                
       
        var oTable = $('#locationtable').dataTable({
                    "bProcessing": true,
                    "bServerSide": true,
                    "sPaginationType": "full_numbers",
                    "ajax": {
                    "url": 'city/GetCitiess',
                    "type": "POST",
                    "data":{ }
                     }, 
                     "oLanguage": {
                        "sProcessing": "<img src='<?php echo base_url(); ?>images/loader.gif'>"
                    },
                    'iDisplayLength': 10,
                    "columns": columnData,
                    "fnDrawCallback": function( oSettings ) {
                        
                         $("#locationtable").find(".edit").each(function(){
                                
                                $(this).click(function(){ 
                                $(".eresponse").text("");
                                $("#cityname").val($(this).attr("data-name"));
                                $("#bqty").val($(this).attr("data-batchqty"));               
                                $("#eide").val($(this).attr("data-id"));
                                
                                $(".courseconfirm").trigger('click'); 
                         
                                });
                                
                            });
                        
                         $("#locationtable").find(".del").each(function(){

                            $(this).click(function(){ 

                              if(confirm("Are you sure to delete this item ?")) {
                                    var ide = $(this).attr("data-id");
                                    $.get('city/DelCity',{
                                                               'ide':ide

                                                    }, function(o) { 
                                                            var obj1 = $.parseJSON(o);
                                                    if (obj1[0] === 'success') {
                                                        oTable.fnDraw(); 
                                                    } else if (obj1[0] === 'fail') {
                                                        alert("Error!!! please try again");
                                                }
                                    });
                                }

                              });
                        
                          });
                                             
                    }
         }); 
    
    
    $(".savebtn").click(function(){
         
               $(".response").html('').text('Progressing...');
     
               
                var locationForm = $("#locationForm");

                    $.ajax({
                        url: locationForm.attr('action'),
                        type: 'post',
                        data: locationForm.serialize(),
                        success: function(o){
                            
                            var response = $.parseJSON(o);
                            $(".response").html('');
                            if(response.status === 'success') {
                       
                                $(".response").css("color","rgb(25, 71, 15)");
                               $(".response").text(response.message);
                               oTable.fnDraw();
                               
                               
                            } else {
                                
                               $(".response").append(response.message); 
                           
                            }

                        }
                    });
                   
                              
            });
            
            $(".editsave").click(function(){
               
                $(".eresponse").html('').text('Progressing...');
     
               
                var locationForm = $("#editlocationForm");

                    $.ajax({
                        url: locationForm.attr('action'),
                        type: 'post',
                        data: locationForm.serialize(),
                        success: function(o){
                            
                            var response = $.parseJSON(o);
                            $(".response").html('');
                            if(response.status === 'success') {
                                
                                $(".eresponse").css("color","rgb(25, 71, 15)");
                               $(".eresponse").text(response.message);
                               oTable.fnDraw();
                               $('#courseModal').modal('hide');
                               
                            } else {
                                
                               $(".eresponse").append(response.message); 
                           
                            }

                        }
                    });
                    
            });
	

	
});
</script>
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/dataTables.css?v=1.5" />
<script src="<?php echo base_url(); ?>js/jquery.dataTables.js?v=1.0" type="text/javascript"></script>

 <style type="text/css">
	 
	 table.dataTable{margin-top: 1rem !important;width: 99% !important;margin: auto}
	 .table tr:last-child td{text-align: left}
	.table tr td:last-child,.table tr th:last-child{text-align: left}
	.table tr:last-child td:last-child{font-weight: 600;text-align: left}
	.table tr:last-child{text-align: center}
	
	.table{border: 1px solid #D7DFF0;border-collapse: collapse;border-style: hidden;border-radius: 10px 10px 0 0;box-shadow: 0 0 0 1px #d7dff0;}
	.table thead th{font-size: 12px;font-weight: bold;color: #6F83AA;letter-spacing: 0.5px;background: #E6EBF7;text-transform: uppercase;padding: 0.8rem;text-align: left}
	.table thead tr th:first-child{border-top-left-radius: 5px}
	.table thead tr th:last-child{border-top-right-radius: 5px}
	.table td, .table th{border-top: 1px solid #D7DFF0;padding: 0.9rem 0.75rem;color: #364159;font-weight: 600;}
	.table td{background: #ffffff;}
	
		
	h3.title{font-size: 12px;text-transform: uppercase;color: #0332AA;letter-spacing: 0.5px;font-weight: bold;}
	 h2{font-size: 12px;text-transform: uppercase;color: #0332AA;letter-spacing: 0.5px;font-weight: bold;}
	 
		
		.dataTables_empty{text-align: center !important}
		.dataTables_wrapper{overflow-x: auto}
	 
	 .card{background: linear-gradient(0deg, #FFFFFF, #FFFFFF), #C4C4C4;box-shadow: 0px 0px 7px rgba(196, 196, 196, 0.35);border-radius: 10px;}
	 
	 .form-group.floating{margin-bottom: 0}
	 
	 p.list-item-heading{color: #6884CC;font-weight: 600;}
	.feetop p.list-item-heading span:last-child{font-weight: 600;font-size: 14px;color: #364159;}
	 
	 .icon-edit{background: url(img/icons/edit3-b.png) no-repeat;width: 15px;height: 16px;display: inline-block;vertical-align: middle}
	 .bookdetails p span:last-child{font-weight: 600;font-size: 14px;line-height: 14px;color: #364159;}
	 .bookdetails p a {font-weight: 600;font-size: 14px;line-height: 20px;color: #0332AA;}

	 
	#issuestatusModal h2{font-size: 14px;text-transform: none;color: #364159;letter-spacing: 0px;font-weight: bold;}
	h5.modal-title p.headtitle{display: inline-block;width: 100%;text-align: center;font-weight: bold;font-size:17px;color: #fff;}
	h5.modal-title p.text-muted{display: inline-block;width: 100%;text-align: center;font-weight: 600;font-size: 14px;line-height: 36px;color: #181E29;line-height: 20px;}
	.modal-title img{display: block;margin: 1em auto}
	#ExamcenterModal.modal .modal-header{padding: 10px 20px !important;border: none;border-radius: 10px 10px 0px 0px;}	
	#ExamcenterModal.modal .modal-body{padding:0 1.75rem 1.75rem}
	#ExamcenterModal.modal .modal-footer{border: none}
	.modal-body p{text-align: left !important}
	.modal .modal-content{border-radius: 10px}
	.modal-backdrop.show {opacity: .5 !important;}
	.modal .close{color: #ffffff;opacity: inherit}
	#ExamcenterModal.modal .modal-dialog{max-width: 700px}
	 
	 .profilepic{width: 120px;height: 120px}
	 
	 .examcenter .row div p{font-size: 14px;font-weight: 600;color: #526585;}
	 .examcenter .row div:first-child p{font-size: 14px;font-weight: 600;color: #6884CC;line-height: 19px;}
	 
	 .ecenterbtn{padding: 0.5rem}
	 
 </style>
 
 <script type="text/javascript">
	 
	 var oTable = "";
$(document).ready(function(){	
	
	$("select").change(function(){
		$(this).attr('value',$(this).val());
	});
	
	
	 oTable = $('#examtable').dataTable({
                    "bProcessing": true,
                    "sPaginationType": "full_numbers",
                     "oLanguage": {
                        "sProcessing": "<img src='<?php echo base_url(); ?>images/loader.gif'>",
						 "sEmptyTable": "No Events",
                    },
                    "columns": [
							{ title: "S.NO" },
							{ title: "EVENT NAME" },
							{ title: "COURSE NAME" },							
							{ title: "DATE & TIME" },							
							{ title: "REPORTING TIME" },							
							{ title: "DURATION" },							
							{ title: "LOCATION" }						
						],
                    'iDisplayLength': 1000,
                    //"columns": columnData,
                    "order": [[ 0, "asc" ]],
                    "fnDrawCallback": function( oSettings ) {
						
                        var count = 1;
						
                         $('#examtable').find("tr .sno").each(function(){                           
                            $(this).text(count);
                            count++;
                         });
                                                      
                    }
         }); 
           
	
});
</script>

 <main> 
        
        <div class="container-fluid">
                 
    
    		<div class="row mb-3">
				<div class="col-12">
					<h1>Event</h1>
				</div>
			</div> 
             
              
          <div class="issuedetails">
                                               
                <table id="examtable" class="sortable table" style="width:100%"></table>    
      
			</div>
      
       
 </div>
 
 </main>
 
 <div class="modal fade" id="ExamcenterModal" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog" role="document">
	<div class="modal-content">
            <div class="modal-header" style="background-color: #6884CC;height: 50px;width: auto;padding: 10px">
	  
		<h5 class="modal-title w-100" id="exampleModalLabel">
		
			<div class="row">
			
				<div class="col-10">
					<p class="headtitle text-left">Select Event Center</p>
				</div>
				
				<div class="col-2">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				</div>
				
			</div>
			
		</h5>
	 </div>
           
           <?php echo form_open('stuexam/examPrintSubmit', array('id' => 'examprintForm')) ?>
           
            <div class="row m-3 examcenter">
              
              <div class="col-12 col-sm-6">
                <div class="row">

					<div class="col-md-5 col-5">
						<p>Event Name:</p>
					</div>

					<div class="col-md-7 col-7">
						<p class="examname"></p>
					</div>

				</div>
			</div>
              
              <div class="col-12 col-sm-6">
                <div class="row">

					<div class="col-md-5 col-5">
						<p>Date & Time :</p>
					</div>

					<div class="col-md-7 col-7">
						<p class="exdatetime"></p>
					</div>

				</div>
			</div>
              
              <div class="col-12 col-sm-6">
                <div class="row">

					<div class="col-md-5 col-5">
						<p>Course Name :</p>
					</div>

					<div class="col-md-7 col-7">
						<p class="cname"></p>
					</div>

				</div>
			</div>
              
              <div class="col-12 col-sm-6">
                <div class="row">

					<div class="col-md-5 col-5">
						<p>Duration :</p>
					</div>

					<div class="col-md-7 col-7">
						<p class="duration"></p>
					</div>

				</div>
			</div>
              
              <div class="col-12 col-sm-6">
                <div class="row">

					<div class="col-md-5 col-5">
						<p>Reporting Time :</p>
					</div>

					<div class="col-md-7 col-7">
						<p class="rtime"></p>
					</div>

				</div>
			</div>
              
              <div class="col-12 col-sm-6 edistricttext d-none">
                <div class="row">

					<div class="col-md-5 col-5">
						<p>District :</p>
					</div>

					<div class="col-md-7 col-7">
						<p></p>
					</div>

				</div>
			</div>
              
              <div class="col-12 col-sm-6 ecentertext d-none">
                <div class="row">

					<div class="col-md-5 col-5">
						<p>Center :</p>
					</div>

					<div class="col-md-7 col-7">
						<p></p>
					</div>

				</div>
			</div>
              
              <div class="col-12">
                <div class="row">

					<div class="col-md-3 col-3">
						<p>Description :</p>
					</div>

					<div class="col-md-9 col-9">
						<p class="desc"></p>
					</div>

				</div>
			</div>
              
              <div class="col-12 mt-3 edistrictoption">
                <div class="row">

					<div class="col-md-3 col-3">
						<p>Select District</p>
					</div>

					<div class="col-md-9 col-9">
						<div class="form-group position-relative error-l-50 floating">
							<select name="examdistrict" id="examdistrict" class="form-control" value="">
								<option value="">Select District</option>
							</select>
						  <label for="examdistrict">Select District <span>*</span></label>
						</div>
					</div>

				</div>
			</div>
              
              <div class="col-12 mt-3 ecenteroption">
                <div class="row">

					<div class="col-md-3 col-3">
						<p>Select Center</p>
					</div>

					<div class="col-md-9 col-9">
						<div class="form-group position-relative error-l-50 floating">
							<select name="examcenter" id="examcenter" class="form-control" value="">
								<option value="">Select Center</option>
							</select>
						  <label for="examcenter">Select Center <span>*</span></label>
						</div>
					</div>

				</div>
			</div>
      	
      			<input type="hidden" name="examid" id="examid" />
       	
        	</div> 
        
        <?php echo form_close() ?>
        
        <p class="alert mx-3"></p>
        
	  <div class="modal-footer">
		  		
		  		<div class="form-group w-75"> 
	 			 
	 			    <button type="button" class="btn btn-outline-primary backbtn d-none">Back</button>
					
				</div>
	 			 <div class="form-group"> 
	 			 
					<button type="button" class="btn btn-primary confirmbtn float-right d-none" data-dismiss="modal">Confirm & Print</button>
					
				</div> 
				<div class="form-group">
				
					<button type="button" class="btn btn-primary proceedbtn float-right" >Proceed</button>
                
                </div> 
             
        
	  </div>
	</div>
  </div>
  </div>
 
<!-- <div id="ExamcenterModal" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
				   <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				</div>
				<div class="modal-body">
														
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-outline-primary modalclose" data-dismiss="modal">Close</button>
				</div>
								
			</div>
		</div>
	</div>-->
	
<script type="text/javascript">
	
    $(document).ready(function() {
   
			
		$("select").change(function(){
			$(this).attr('value',$(this).val());
		});
	//$('#ExamcenterModal').modal({show:true});		
		
	loadresults(oTable);	
    	
		
	$(document).on('click','.ecenterbtn', function () {
		
		var exid = $(this).data('eid');
		
		if(exid==""){alert('Exam center not found');return false;}
		
		$.ajax({
				url: 'stuexam/GetExamCenterDetails',
				type: 'post',
				data: {"exid":exid},
				success: function(o){

					var response = $.parseJSON(o);
					$(".response").html('');
					if(response.status === 'success') {

					   //oTable.fnDraw();
						
						var examdata = response.examdata;						
						
						var examid = examdata['id'];
						var examname = examdata['examname'];
						var coursename = examdata['displaycname'];
						var date = examdata['date'];
						var rtime = examdata['rtime'];
						var duration = examdata['duration'];
						var description = examdata['description'];
						var districtoption = examdata['districtoption'];
						var centeroption = examdata['centeroption'];
						
						$("#examid").val(examid);
						$(".examname").text(examname);
						$(".exdatetime").text(date);
						$(".cname").text(coursename);
						$(".duration").text(duration);
						$(".rtime").text(rtime);
						$(".desc").text(description);
						
						$("#examdistrict option").after(districtoption);
						//$("#examcenter option").after(centeroption);
						
					   $('#ExamcenterModal').modal({show:true});
					
					} else {

					  $('#ExamcenterModal').modal('hide');
					  alert(response.message); 
					  
					}

				}
			});
		
	});		
		
	$(document).on('change','#examdistrict', function () {
		
		var district = $(this).val();
		var examid= $("#examid").val();
		
		if(district==""){alert('Select district');$("#examcenter option:not(:first)").remove();return false;}
		
		$.ajax({
				url: 'stuexam/ExamCenterOptions',
				type: 'post',
				data: {"examid":examid,"district":district},
				success: function(o){

					var response = $.parseJSON(o);
					if(response.status === 'success') {

						var examdata = response.examdata;						
				
						var centeroption = examdata['centeroption'];
						
						$("#examcenter option:not(:first)").remove();
						$("#examcenter option").after(centeroption);
											
					} else {
					  $("#examcenter option:not(:first)").remove();
					  alert(response.message); 
					  
					}

				}
			});
		
	});		

	$(".proceedbtn").click(function(){		
		
		var district = $("#examdistrict").val();
		var center = $("#examcenter").val();	
		
		if(district=="") {alert("Select district");return false ;}
		
		if(center=="") {alert("Select center");return false ;}
		
		$(".proceedbtn").addClass('d-none');
		$(".confirmbtn,.backbtn").removeClass('d-none');
		
		$(".edistrictoption,.ecenteroption").addClass('d-none');
		
		$(".edistricttext").removeClass('d-none').find('.row div:last-child p').text(district);
		$(".ecentertext").removeClass('d-none').find('.row div:last-child p').text(center);
                              
     });		

	$(".backbtn").click(function(){		
				
		$(".proceedbtn").removeClass('d-none');
		$(".confirmbtn,.backbtn").addClass('d-none');
		
		$(".edistrictoption,.ecenteroption").removeClass('d-none');
		
		$(".edistricttext").addClass('d-none').find('.row div:last-child p').text("");
		$(".ecentertext").addClass('d-none').find('.row div:last-child p').text("");
                              
     });
		
		
	$(".confirmbtn").click(function(){
		
		var district = $("#examdistrict").val();
		var center = $("#examcenter").val();		
		var examid= $("#examid").val();
		
		$(".alert").removeClass("alert-success alert-danger").html('');
		
		if(examid=="") {$(".alert").addClass("alert-danger").text('Event center not found');return false ;}
		
		if(district=="") {$(".alert").addClass("alert-danger").text('Select district');return false ;}
		
		if(center=="") {$(".alert").addClass("alert-danger").text('Select center');return false ;}
		
		if($(".confirmbtn").hasClass('process')){
			
			$(".alert").addClass('alert-danger').text("Please wait while progressing...");
			
		}else{
		
			/*var r = confirm("Are you sure to confirm & print?");
			
			if(r){*/
				
			$(".alert").addClass('alert-success').text('Progressing...');	
			$(".confirmbtn").addClass('process');
			
			var examprintForm = $("#examprintForm");

			$.ajax({
				url: examprintForm.attr('action'),
				type: 'post',
				data: examprintForm.serialize(),
				success: function(o){

					var response = $.parseJSON(o);
					
					$(".confirmbtn").addClass('process');
					
					if(response.status === 'success') {

					   $(".alert").removeClass("alert-danger").addClass('alert-success').text(response.message);
					   
					   //$('#ExamcenterModal').modal('hide');
						loadresults(oTable);
						
						window.open("stuexam/ExamCenterPrint?examid="+examid,"_blank");
						
					} else {

					   $(".alert").removeClass("alert-success").addClass('alert-danger').text(response.message); 

					}

				}
			});
				
			//}
		}
                    
      });	
								
	$('#ExamcenterModal').on('hidden.bs.modal', function () {
	  	$(".examname,.exdatetime,.cname,.duration,.rtime,.desc").text("");
		$("#examid").val("");
		$("#examdistrict option:not(:first),#examcenter option:not(:first)").remove();
		$(".edistricttext,.ecentertext,.confirmbtn").addClass('d-none');
		$(".proceedbtn,.edistrictoption,.ecenteroption").removeClass('d-none');
		oTable.fnDraw();
	});
    
			
	$(document).on('focus click','input,select,textarea', function () {
	  	$(".alert").removeClass("alert-success alert-danger").html('');
	});		
           
});	
	
function loadresults(oTable){
	
	$.ajax({
                type: 'POST',
                url: 'stuexam/GetExamCenters',
                data: {},
                success: function(response) {
                   
					var obj1 = $.parseJSON(response);
					
					if(obj1['tabledata'].length>0){
						
						oTable.fnClearTable();
						oTable.fnAddData(obj1['tabledata']);
						oTable.fnDraw();
												
					}
					
				}
		
	});

}
		
</script>
    
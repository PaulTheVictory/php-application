<link href="<?php  echo base_url(); ?>css/jquery-te-1.4.0.css?v=1.52" rel="stylesheet" type="text/css" />
<script src="<?php  echo base_url(); ?>js/jquery-te-1.4.0.min.js" type="text/javascript"></script>
<link href="<?php  echo base_url(); ?>css/jquery-ui.min.css?v=1.4" rel="stylesheet" type="text/css" />
 <script src="<?php  echo base_url(); ?>js/jquery-ui.min.js?v=1.3" type="text/javascript"></script>
    
 <style type="text/css">
	 
	 table.dataTable{margin-top: 2rem !important}
	 .table tr:last-child td{text-align: left}
	.table tr td:last-child,.table tr th:last-child{text-align: left}
	.table tr:last-child td:last-child{font-weight: 600;text-align: left}
	.table tr:last-child{text-align: center}
	
	.table{border: 1px solid #D7DFF0;border-collapse: collapse;border-style: hidden;border-radius: 10px 10px 0 0;box-shadow: 0 0 0 1px #d7dff0;}
	.table thead th{font-size: 12px;font-weight: bold;color: #6F83AA;letter-spacing: 0.5px;background: #E6EBF7;text-transform: uppercase;padding: 0.8rem;text-align: left}
	.table thead tr th:first-child{border-top-left-radius: 5px}
	.table thead tr th:last-child{border-top-right-radius: 5px}
	.table td, .table th{border-top: 1px solid #D7DFF0;padding: 0.9rem 0.75rem;color: #364159;font-weight: 600;}
	.table td{background: #ffffff;}
	
		
	h3.title{font-size: 12px;text-transform: uppercase;color: #0332AA;letter-spacing: 0.5px;font-weight: bold;}
		
		.dataTables_empty{text-align: center !important}
		.dataTables_wrapper{overflow-x: auto}
	 
	 .notifycard .card{background: linear-gradient(0deg, #FFFFFF, #FFFFFF), #C4C4C4;box-shadow: 0px 0px 7px rgba(196, 196, 196, 0.35);border-radius: 10px;}
	 .notifycard .z-index{z-index: 1;}
	 
	 .form-group.floating{margin-bottom: 0}
	 
	 .notifycard p.text-muted{font-weight: 600;line-height: 16px;}
	 
	 .dataTables_filter{right: inherit;left: 20px;top: 5px;}
	 #usertable_filter input{width: 300px}
	 #usertable_wrapper{top: -60px;padding-top: 3rem}
	 
	 textarea.form-control.smstext,textarea.form-control.whatsapptext{height: 110px}

 </style>
 
 <script type="text/javascript">
$(document).ready(function(){	
	
	$(".emailtext").jqte();
	
	$(document).on("change","select",function(){
		$(this).attr('value',$(this).val());
	});
	
	$("input[name='sntype']").change(function(){
		
		var sntype = $(this).val();
				
		if(sntype=="batches"){
			
			$("."+sntype).removeClass('d-none');
			$(".coursewise,.individual").addClass('d-none');
			
		}else if(sntype=="coursewise"){
			
			$("."+sntype).removeClass('d-none');
			$(".batches,.individual").addClass('d-none');
			
		}else if(sntype=="individual"){
			
			$("."+sntype).removeClass('d-none');
			$(".coursewise,.batches").addClass('d-none');
			
		}
		
	});
	
	
	$("input[name='snmethod']").change(function(){
		
		var snmethod = $(this).val();
				
		if(snmethod=="sms"){
			
			$("."+snmethod+"col").removeClass('d-none');
			$(".emailcol,.whatsappcol").addClass('d-none');
			
		}else if(snmethod=="email"){
			
			$("."+snmethod+"col").removeClass('d-none');
			$(".smscol,.whatsappcol").addClass('d-none');
			
		}else if(snmethod=="whatsapp"){
			
			$("."+snmethod+"col").removeClass('d-none');
			$(".smscol,.emailcol").addClass('d-none');
			
		}
		
	});
	  
        $(".emailbtn").click(function(){
            $(this).text("Progressing..");
            if($(".eresponse").hasClass('progress')) { alert("Plese wait its processing");return;}
            else{ $(".eresponse").addClass('progress');}
            
            var sntype = $("input[name='sntype']:checked").val();
            var center="";var cid="";var batches="";var sid="";
             $(".emsntype").val(sntype);
             if(sntype==="batches"){
			$("#cname").val("");
                        $("#ccenter").val("");$("#sname").val("");
			batches = $("#batches").val();
                        $(".embatches").val(batches);
                        if(batches === "") { alert("Kindly select the student batch");return;}
                         
			
		}else if(sntype==="coursewise"){
			$("#batches").val("");$("#sname").val("");
			center = $("#ccenter").val();
                        cid = $("#cname").attr("data-cname");
                        $(".emcourseid").val(cid);$(".emcenter").val(center);
                        
                        if((cid === "")||(center === "")) { alert("Kindly select the course and center");return;}
			
		}else if(sntype==="individual"){
			$("#cname").val("");$("#sname").val("");
                        $("#ccenter").val("");$("#batches").val("");
			sid = $("#sname").attr("data-sname");
			$(".emstudentid").val(sid);
                        if(sid === "") { alert("Kindly select the student detail");return;}
			
		}
                
                var emailForm = $("#emailForm");

                    $.ajax({
                        url: emailForm.attr('action'),
                        type: 'post',
                        data: emailForm.serialize(),
                        success: function(o){
                            
                            var response = $.parseJSON(o);
                            $(".eresponse").html('');
                            if(response.status === 'success') {
                                
                                $(".emailbtn").text("Send");
                               $(".eresponse").text(response.message);
                               $(".eresponse").removeClass('progress');
                                
                            } else {
                                $(".emailbtn").text("Send");
                               $(".eresponse").append(response.message); 
                               $(".eresponse").removeClass('progress');
                           
                            }

                        }
                    });
             
        });
        
         $(".smsbtn").click(function(){
            $(this).text("Progressing..");
            if($(".smsresponse").hasClass('progress')) { alert("Plese wait its processing");return;}
            else{ $(".smsresponse").addClass('progress');}
            
            var sntype = $("input[name='sntype']:checked").val();
            var center="";var cid="";var batches="";var sid="";
             $(".smssntype").val(sntype);
             if(sntype==="batches"){
			$("#cname").val("");
                        $("#ccenter").val("");$("#sname").val("");
			batches = $("#batches").val();
                        $(".smsbatches").val(batches);
                        if(batches === "") { alert("Kindly select the student batch");return;}
                         
			
		}else if(sntype==="coursewise"){
			$("#batches").val("");$("#sname").val("");
			center = $("#ccenter").val();
                        cid = $("#cname").attr("data-cname");
                        $(".smscourseid").val(cid);$(".smscenter").val(center);
                        
                        if((cid === "")||(center === "")) { alert("Kindly select the course and center");return;}
			
		}else if(sntype==="individual"){
			$("#cname").val("");$("#sname").val("");
                        $("#ccenter").val("");$("#batches").val("");
			sid = $("#sname").attr("data-sname");
			$(".smsstudentid").val(sid);
                        if(sid === "") { alert("Kindly select the student detail");return;}
			
		}
                
                var emailForm = $("#smsForm");
 $(".smsresponse").html('');
                    $.ajax({
                        url: emailForm.attr('action'),
                        type: 'post',
                        data: emailForm.serialize(),
                        success: function(o){
                            
                            var response = $.parseJSON(o);
                           
                            if(response.status === 'success') {
                                
                                $(".smsbtn").text("Send");
                               $(".smsresponse").text(response.message);
                               $(".smsresponse").removeClass('progress');
                                
                            } else {
                                $(".smsbtn").text("Send");
                               $(".smsresponse").append(response.message); 
                               $(".smsresponse").removeClass('progress');
                           
                            }

                        }
                    });
             
        });
        
         $("#sname").autocomplete({
            source: function (request, response) {
                $.ajax({
                    url: "notification/studentSearch",
                    contentType: "application/jsonp",
                    
                    data: {
                        term: request.term
                    },
                    success: function (data) {
                        data = $.parseJSON(data);
                        response(
                                $.map(data, function (item) {
                                    return {
                                        value: item.sname,
                                        ide:item.id
                                    };
                                })
                                );
                    }
                });
            },
            select: function (event, ui) {
                
                $("#sname").attr("data-sname",ui.item.ide);
               
          
            }
            
        })._renderItem = function (ul, item) {

             return $("<li></li>")
                    .data("item.autocomplete", item)
                    .append('<a><div style="height: auto; width: auto; display: inline-block;"><p style="margin: 0px; padding: 0px; height: 20px; width: 100%; line-height: 30px;">' + item.studid + ' , '+item.sname+'</p></div></a>')
                    .appendTo(ul);
        };
        
         $("#cname").autocomplete({
            source: function (request, response) {
                $.ajax({
                    url: "courses/courseSearch",
                    contentType: "application/jsonp",
                    
                    data: {
                        term: request.term
                    },
                    success: function (data) {
                        data = $.parseJSON(data);
                        response(
                                $.map(data, function (item) {
                                    return {
                                        value: item.coursename,
                                        ide:item.ide
                                    };
                                })
                                );
                    }
                });
            },
            select: function (event, ui) {
                
                $("#cname").attr("data-cname",ui.item.ide);
                selectcenter(ui.item.ide);
          
            }
            
        })._renderItem = function (ul, item) {

             return $("<li></li>")
                    .data("item.autocomplete", item)
                    .append('<a><div style="height: auto; width: auto; display: inline-block;"><p style="margin: 0px; padding: 0px; height: 20px; width: 100%; line-height: 30px;">' + item.courseid + ' , '+item.coursename+'</p></div></a>')
                    .appendTo(ul);
        };
        
        function selectcenter(ide){
	
            $.ajax({
                    type: 'POST',
                    url: 'courses/GetCourseCenterList',
                    data: {'ide':ide},
                    success: function(response) {

                            var obj1 = $.parseJSON(response);
                            $("#ccenter").append(obj1['center']);
                            $("#ccenter").attr("data-id",ide);

                    }

            });
   
        }
        
        $("#templates").change(function(){
            var ide =$(this).val();
            $(".tmessagecontainer").find(".tmessage").remove();
            var txtarea =$('<textarea name="tmessage" class="form-control tmessage"></textarea>');
            $.ajax({
                    type: 'POST',
                    url: 'notification/getTemplateMessages',
                    data: {'ide':ide},
                    success: function(response) {
                            $(".tmessagecontainer").append(txtarea);
                            var obj1 = $.parseJSON(response);
                            $(txtarea).html(obj1.message);
                            
                    }

            });
            
        });
	
});
</script>

 <main> 
        
    <div class="container-fluid">
                 
		<h1>Send Notification</h1>
               
            <div class="row px-3 mt-4">     
                     
           <div class="col-12 notifycard p-0">
           
           <div class="card">
           
            <div class="course-container add-course p-4">
                                
                <div class="row">
                   
                    <div class="col-12 justify-content-start">
                    
						<div class="form-group position-relative error-l-50 mb-0">
						  <div class="d-flex">
							  <div class="custom-control custom-radio col-sm-2">
								<input type="radio" id="sntype1" name="sntype" class="custom-control-input" value="batches" required="" checked>
								<label class="custom-control-label" for="sntype1">Batches</label>
							  </div>
							  <div class="custom-control custom-radio col-sm-2">
								<input type="radio" id="sntype2" name="sntype" class="custom-control-input" value="coursewise" required="">
								<label class="custom-control-label" for="sntype2">Course Wise</label>
							  </div>
							  <div class="custom-control custom-radio col-sm-2">
								<input type="radio" id="sntype3" name="sntype" class="custom-control-input" value="individual" required="">
								<label class="custom-control-label" for="sntype3">Individual</label>
							  </div>
						</div>
					  </div>
				  		
					</div>
					
				</div>
               
                </div>
                
			   </div>
               
            </div>
            
            
            <div class="col-12 notifycard p-0 mt-4">
           
           <div class="card">
           
            <div class="course-container add-course p-4">
                                
                <div class="row align-items-center batches">
                   
                   	<div class="col-2">
                                                                		 
						<p class="text-muted mb-0">Select Batches </p>		
								  		
					</div>
                   
                    <div class="col-4">
                    
						<div class="form-group floating mr-3">
                      
                    		<select id="batches" name="batches" value="" class="form-control">
								<option value="">Select Batches </option>
								<?php echo $batches;?>
                       		 </select>
                       		 
							 <label>Select Batches </label>
						</div>
				  		
					</div>			
					
				</div>
              
               <div class="row align-items-center coursewise d-none">
                   
                   	<div class="col-2">
                                                                		 
						<p class="text-muted mb-0">Select Course </p>		
								  		
					</div>
                   
                    <div class="col-4">
                    
						<div class="form-group floating mr-3">
                      
                                                <input type="text" value="" class="form-control"  id="cname"  placeholder=" " >
                                                <label for="sname">Course Name <span>*</span></label>
						</div>
                                                    
					</div>	
					
					<div class="col-2">
                                                                		 
						<p class="text-muted mb-0">Select Center </p>		
								  		
					</div>
                   
                    <div class="col-4">
                    
						<div class="form-group floating mr-3">
                      
                                                    <select class="form-control " id="ccenter"   required  >
                                                            <option value="All">All</option>
                                                        </select>
                                                    <label>Center<span>*</span></label>
						</div>
				  		
					</div>		
											
					
				</div>
              
              
               <div class="row align-items-center individual d-none">
                   
                   	<div class="col-2">
                                                                		 
						<p class="text-muted mb-0">Select Individual </p>		
								  		
					</div>
                   
                    <div class="col-4">
                    
						<div class="form-group floating mr-3">
                      
                                                <input type="text" value="" class="form-control" name="sname" id="sname"  placeholder=" " >
                                                <label for="sname">Student Name <span>*</span></label>
						</div>
				  		
					</div>			
					
				</div>
               
                </div>
                
			   </div>
               
            </div>
             
             
             <div class="col-12 notifycard p-0 mt-4">
           
           <div class="card">
           
            <div class="course-container add-course p-4">
                                
<!--                    <div class="row">

                        <div class="col-3">

                                                    <p><strong>No. of Students</strong></p>

                                            </div>

                                             <div class="col-6">

                                                     <p class="noofstudent">0</p>

                                            </div>

                                    </div>-->
                                
                <div class="row mt-4 smsrow">
                   
                    <div class="col-3">
                    
						<div class="form-group position-relative error-l-50 mb-0">
						  <div>
							  <div class="custom-control custom-radio col-sm-2">
								<input type="radio" id="snmethod1" name="snmethod" class="custom-control-input snmethod" value="sms" required="" checked>
								<label class="custom-control-label" for="snmethod1">SMS</label>
							  </div>
						</div>
					  </div>
				  		
					</div>
					
					 <div class="col-6 smscol">
                                        <?php echo form_open('notification/smsSend', array('id' => 'smsForm')) ?>
                    				<div class="form-group position-relative error-l-50 mb-0">
							<select id="templates" name="templates" value="" class="form-control">
								<option value="">Select Templates </option>
								<?php echo $templates;?>
                                                    </select>
                                                    <input type="hidden" name="smssntype" class="smssntype" vlaue=""><input type="hidden" name="smscenter" class="smscenter" vlaue="">
                                                    <input type="hidden" name="smsbatches" class="smsbatches" vlaue=""><input type="hidden" name="smsstudentid" class="smsstudentid" vlaue="">
                                                    <input type="hidden" name="smscourseid" class="smscourseid" vlaue="">
					    </div>
                                             <div class="form-group position-relative error-l-50 mt-3 tmessagecontainer">
                                                 <textarea id="tmessage" name="tmessage" class="form-control tmessage">
								
                                                    </textarea>
                                            </div>
					   <?php echo form_close() ?> 
						 <div class="row mt-3 align-items-center justify-content-end">
							<span class="smsresponse" style="margin: 0px auto; float:right;width: 70%; height: 30px;margin-top:20px;margin-left:0px"></span>
						  							 <div class="col-3"><button class="btn btn-primary smsbtn">Send</button></div>
						 </div>
				  		
					</div>
                                       
					
				</div>
              
               <div class="row mt-4 emailrow">
                   
                    <div class="col-3">
                    
						<div class="form-group position-relative error-l-50 mb-0">
						  <div>
							  <div class="custom-control custom-radio col-sm-2">
								<input type="radio" id="snmethod2" name="snmethod" class="custom-control-input snmethod" value="email" required="">
								<label class="custom-control-label" for="snmethod2">Email</label>
							  </div>
						</div>
					  </div>
				  		
					</div>
					
					 <div class="col-6 emailcol d-none">
                    <?php echo form_open('notification/emailSend', array('id' => 'emailForm')) ?>
                    	<div class="form-group position-relative error-l-50 floating mb-3">
							 <input class="form-control" type="text" id="subject" name="subject" placeholder=" " > 
							<label>Subject </label>
						 </div>
					  
						<div class="form-group position-relative error-l-50 mb-0">
							<textarea name="emailtext" class="form-control emailtext" ></textarea>
					  	</div>
                                             <input type="hidden" name="emsntype" class="emsntype" vlaue="">
                                             <input type="hidden" name="emcenter" class="emcenter" vlaue=""><input type="hidden" name="embatches" class="embatches" vlaue="">
                                             <input type="hidden" name="emstudentid" class="emstudentid" vlaue=""><input type="hidden" name="emcourseid" class="emcourseid" vlaue="">
			<?php echo form_close() ?> 
					  	<div class="row mt-3 align-items-center justify-content-end">
                                                    <span class="eresponse" style="margin: 0px auto; float:right;width: 70%; height: 30px;margin-top:20px;margin-left:0px"></span>
						 	<div class="col-3"><button class="btn btn-primary emailbtn">Send</button></div>
					 	</div>
				  		
					</div>
					
				</div>
              
              
               <div class="row mt-4 whatsapprow">
                   
                    <div class="col-3">
                    
						<div class="form-group position-relative error-l-50 mb-0">
						  <div>
							  <div class="custom-control custom-radio col-sm-2">
								<input type="radio" id="snmethod3" name="snmethod" class="custom-control-input snmethod" value="whatsapp" required="">
								<label class="custom-control-label" for="snmethod3">Whatsapp</label>
							  </div>
						</div>
					  </div>
				  		
					</div>
					
					 <div class="col-6 whatsappcol d-none">
                    
						<div class="form-group position-relative error-l-50 mb-0">
							<textarea name="whatsapptext" class="form-control whatsapptext" ></textarea>
					  </div>
					  
						 <div class="row mt-3 align-items-center justify-content-end">
							 <div class="col-3"><button class="btn btn-primary whatsappbtn">Send</button></div>
						 </div>
				  		
					</div>
					
				</div>
               
                </div>
                
			   </div>
               
            </div>
          
           </div>
           
       
 </div>
 
 </main>
 

    

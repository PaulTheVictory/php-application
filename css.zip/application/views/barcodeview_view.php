<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/dataTables.css?v=1.6" />
<script src="<?php echo base_url(); ?>js/jquery.dataTables.js?v=1.0" type="text/javascript"></script>

<style type="text/css">
	 
	 table.dataTable{margin-top: 2rem !important}
	 .table tr:last-child td{text-align: left}
	.table tr td:last-child,.table tr th:last-child{text-align: left}
	.table tr:last-child td:last-child{font-weight: 600;text-align: left}
	.table tr:last-child{text-align: center}
	
	.table{border: 1px solid #D7DFF0;border-collapse: collapse;border-style: hidden;border-radius: 10px 10px 0 0;box-shadow: 0 0 0 1px #d7dff0;}
	.table thead th{font-size: 12px;font-weight: bold;color: #6F83AA;letter-spacing: 0.5px;background: #E6EBF7;text-transform: uppercase;padding: 0.8rem;text-align: left}
	.table thead tr th:first-child{border-top-left-radius: 5px}
	.table thead tr th:last-child{border-top-right-radius: 5px}
	.table td, .table th{border-top: 1px solid #D7DFF0;padding: 0.9rem 0.75rem;color: #364159;font-weight: 600;}
	.table td{background: #ffffff;}
	
		
	h3.title{font-size: 12px;text-transform: uppercase;color: #0332AA;letter-spacing: 0.5px;font-weight: bold;}
		
		.dataTables_empty{text-align: center !important}
		.dataTables_wrapper{overflow-x: auto;padding-top: 2rem;}
	 
	 .notifycard .card{background: linear-gradient(0deg, #FFFFFF, #FFFFFF), #C4C4C4;box-shadow: 0px 0px 0px rgba(196, 196, 196, 0.35);border-radius: 5px;}
	 .notifycard .z-index{z-index: 1;}
	 
	 .form-group.floating{margin-bottom: 0}
	 
	 .notifycard p.text-muted{font-weight: 600;line-height: 16px;}
	 
	 .dataTables_filter{right: 0;left: 20px;top: 5px;}
	 #barcodetable_filter input{width: 300px}
	 #usertable_wrapper{top: 0px;padding-top: 3rem}
	 
	 textarea.form-control.smstext,textarea.form-control.whatsapptext{height: 110px}

 </style>
 
<script type="text/javascript">
	
	var oTable = "";
	
$(document).ready(function(){
		
	//window.print();
	
	 var oTable = $('#barcodetable').dataTable({
					"processing": true,
					"sPaginationType": "full_numbers",
			 		"oLanguage": {
                        "sProcessing": "<img src='<?php echo base_url(); ?>images/loader.gif'>",
						 "sEmptyTable": "No Results Found",
						"sSearchPlaceholder": "Search Barcodes",
                    },
                    "columns": [
							{ title: "" },
							{ title: "Sno" },
							{ title: "Barcode" },							
							{ title: "Image" }
						],
			 			/*"columnDefs": [
							{
								"targets": 1,
								"render": function ( data, type, row ) {//console.log(row[15]);
									if (type === "display") {
										<?php //if($exam['type']=="Screening Test"){ ?>
											return "<a href=\"studentprofile?sid=" + encodeURIComponent(row[20]) + "\" target=\"_blank\">" + data + "</a>";
										<?php //}else{ ?>
											return "<a href=\"studentprofile?sid=" + encodeURIComponent(row[15]) + "\" target=\"_blank\">" + data + "</a>";
										<?php //} ?>
									}

									//return data;
								}
							}
						],*/
                    //"order": [[ 0, "desc" ]],
		 			'iDisplayLength': 1000,
                    "fnDrawCallback": function( oSettings ) {
                        
    }
 }); 
	
	$('#barcodetable_filter input').addClass('form-control');
	
	loadresults(oTable);
	
	var chkbox = $('<input class="gchkbox" style="margin-left:9px;float:left;padding:5px;" type="checkbox"/>');
	
	$('#barcodetable').find("th").first().append(chkbox);
         $('#barcodetable').find("th").first().css("width","50px");
        $(chkbox).click(function(e){
           
            if($(this).is(":checked")){

                $('#barcodetable').find(".bccheckbox").each(function(){
                    $(this).prop( "checked", true );
                });

            } else {
                $('#barcodetable').find(".bccheckbox").each(function(){
                    $(this).prop( "checked", false );
                });
            }
           
        });
	
	
	$(".printbarcode").click(function(){
	
		var ide = "";
		
		 $(".bccheckbox").each(function(){

		   if($(this).is(":checked")) { ide += $(this).val()+"|";}

		 });
		
		if(ide=="") {alert("Select Barcodes");return false;}
		
		window.open("barcodeview?id=<?php echo $batchid; ?>&bcno="+ide,"_blank");
		
	});

});
	
function loadresults(oTable){
	
	$.ajax({
                type: 'POST',
                url: 'barcodeview/barcodedatatable',
                data: {"batchid":"<?php echo $_GET['id']; ?>"},
                success: function(response) {
                   
					var obj1 = $.parseJSON(response);
					
					if(obj1['tabledata'].length>0){
						
						oTable.fnClearTable();
						oTable.fnAddData(obj1['tabledata']);
						oTable.fnDraw();
						
						$(".approveresults").removeClass('d-none');
						
					}
					
				}
		
	});

}
	
</script>
	
 <main> 
        
    <div class="container-fluid">
                               
		<div class="row">
			<div class="col-10">
				<h1>Generated Barcodes (<?php echo $bcdetails['barcodefrom'] ?> - <?php echo  $bcdetails['barcodeto'];?>)</h1>
			</div>
			<div class="col-2">
				<button class="btn btn-primary printbarcode">Print</button>
			</div>
		</div>
               
               <table id="barcodetable" class="sortable table" style="width:100%"></table>
                                      
       
 </div>
 
 </main>
    
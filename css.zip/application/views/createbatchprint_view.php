<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/dataTables.css?v=1.6" />
<script src="<?php echo base_url(); ?>js/jquery.dataTables.js?v=1.0" type="text/javascript"></script>
<link href="<?php  echo base_url(); ?>css/jquery-ui.min.css?v=1.4" rel="stylesheet" type="text/css" />
 <script src="<?php  echo base_url(); ?>js/jquery-ui.min.js?v=1.3" type="text/javascript"></script>

<style type="text/css">
	 
	 table.dataTable{margin-top: 2rem !important}
	 .table tr:last-child td{text-align: left}
	.table tr td:last-child,.table tr th:last-child{text-align: left}
	.table tr:last-child td:last-child{font-weight: 600;text-align: left}
	.table tr:last-child{text-align: center}
	
	.table{border: 1px solid #D7DFF0;border-collapse: collapse;border-style: hidden;border-radius: 10px 10px 0 0;box-shadow: 0 0 0 1px #d7dff0;}
	.table thead th{font-size: 12px;font-weight: bold;color: #6F83AA;letter-spacing: 0.5px;background: #E6EBF7;text-transform: uppercase;padding: 0.8rem;text-align: left}
	.table thead tr th:first-child{border-top-left-radius: 5px}
	.table thead tr th:last-child{border-top-right-radius: 5px}
	.table td, .table th{border-top: 1px solid #D7DFF0;padding: 0.9rem 0.75rem;color: #364159;font-weight: 600;}
	.table td{background: #ffffff;}
	
		
	.add-book .card{background: linear-gradient(0deg, #FFFFFF, #FFFFFF), #C4C4C4;box-shadow: 0px 0px 7px rgba(196, 196, 196, 0.35);border-radius: 10px;}
	
	h3.title{font-size: 12px;text-transform: uppercase;color: #0332AA;letter-spacing: 0.5px;font-weight: bold;}
		
		.dataTables_empty{text-align: center !important}
		.dataTables_wrapper{overflow-x: auto;padding-top: 2rem;}
	 
	 .notifycard .card{background: linear-gradient(0deg, #FFFFFF, #FFFFFF), #C4C4C4;box-shadow: 0px 0px 0px rgba(196, 196, 196, 0.35);border-radius: 5px;}
	 .notifycard .z-index{z-index: 1;}
	 
	 .form-group.floating{margin-bottom: 0}
	 
	 .notifycard p.text-muted{font-weight: 600;line-height: 16px;}
	
	 p{font-weight: 600;}
	
	 p.text-muted{font-weight: 600;line-height: 14px;color: #6884CC !important}
	
	 p.notetext{font-weight: 600;line-height: 12px;color: #354159 !important}
	 
	 .dataTables_filter{right: 0;left: 20px;top: 5px;}
	 #createprinttable_filter input{width: 300px}
	 #usertable_wrapper{top: 0px;padding-top: 3rem}
	 
	 textarea.form-control.smstext,textarea.form-control.whatsapptext{height: 110px}
	
	.profileimg{width: 40px;height: 40px;border-radius: 50%}
	table.dataTable td{vertical-align: middle}

 </style>
 
<script type="text/javascript">
	
	var oTable = "";
	
$(document).ready(function(){
		
	//window.print();
	
	 oTable = $('#createprinttable').dataTable({
					"processing": true,
					"sPaginationType": "full_numbers",
			 		"oLanguage": {
                        "sProcessing": "<img src='<?php echo base_url(); ?>images/loader.gif'>",
						 "sEmptyTable": "No Results Found",
						"sSearchPlaceholder": "Search Students",
                    },
                    "columns": [
							{ title: "" },
							{ title: "Sno" },
							{ title: "" },
							{ title: "STUDENT ID" },							
							{ title: "STUDENT NAME" },							
							{ title: "PHONE" }
						],
		 			'iDisplayLength': 200,
                    "fnDrawCallback": function( oSettings ) {
                        
    }
 }); 
	
	$('#createprinttable_filter input').addClass('form-control');
	
	//loadresults(oTable);
	
	var chkbox = $('<input class="gchkbox" style="margin-left:9px;float:left;padding:5px;" type="checkbox"/> SELECT ALL');
	
	$('#createprinttable').find("th").first().append(chkbox);
         $('#createprinttable').find("th").first().css("width","50px");
        $(chkbox).click(function(e){
           
            if($(this).is(":checked")){

                $('#createprinttable').find(".bccheckbox").each(function(){
                    $(this).prop( "checked", true );
                });

            } else {
                $('#createprinttable').find(".bccheckbox").each(function(){
                    $(this).prop( "checked", false );
                });
            }
           
        });
	
	
	$("#batchname").autocomplete({
            source: function (request, response) {
                $.ajax({
                    url: "createbatchprint/batchSearch",
                    contentType: "application/jsonp",
                    
                    data: {
                        term: request.term
                    },
                    success: function (data) {
                        data = $.parseJSON(data);
                        response(
                                $.map(data, function (item) {
                                    return {
                                        value: item.batchname,
                                        ide:item.id
                                    };
                                })
                                );
                    }
                });
            },
            select: function (event, ui) {
                
                $("#batchname").attr("data-bname",ui.item.value);
                loadresults(oTable,ui.item.value)
          
            }
            
        });
	
	
		$(".createprintbtn").click(function(){

			var batchname = $("#batchname").val();
			var printbatchname = $("#printbatchname").val();//alert(batchname);return;
			var ide = "";
			
			$(".alert").removeClass("alert-success alert-danger").html('');

			var count = 1;
			 $(".bccheckbox").each(function(){

			   if($(this).is(":checked")) { ide += $(this).val()+"|";}
				 
				count++;

			 });

			if(ide=="") {$(".alert").addClass("alert-danger").html('Select Students');return false;}
			
			if(count>120) {$(".alert").addClass("alert-danger").html('You can only Select 120 Student in one Print Batch');return false;}

			if($(".createprintbtn").hasClass('process')){
			
				$(".alert").addClass('alert-danger').text("Please wait while creating...");
			
			}else{
			
			var r = confirm("Are you sure to create batch?");
		
			if(r){
			
				$(".createprintbtn").addClass('process');
				$(".alert").removeClass('alert-danger').addClass('alert-success').text("Progressing...");
				
			$.ajax({
                type: 'POST',
                url: 'createbatchprint/createbatch',
                data: {"batchname":batchname,"printbatchname":printbatchname,"ide":ide},
                success: function(response) {
                   
					var obj1 = $.parseJSON(response);
					
					$('.showphotos').prop( "checked", false );
					
					if(obj1[0]=="success"){
						$(".createprintbtn").removeClass('process');
						$(".alert").addClass("alert-success").html('Print batch created.');
						loadresults(oTable,batchname);
					}else if(obj1[0]=="empty"){
						$(".alert").addClass("alert-danger").html(obj1[1]);
						$(".createprintbtn").removeClass('process');
					}else if(obj1[0]=="full"){
						$(".alert").addClass("alert-danger").html(obj1[1]);
						$(".createprintbtn").removeClass('process');
						loadresults(oTable,batchname);
					}else if(obj1[0]=="error"){
						$(".alert").addClass("alert-danger").html(obj1[1]);
						$(".createprintbtn").removeClass('process');
					}else{
						$(".alert").addClass("alert-danger").html('Please try again');
						$(".createprintbtn").removeClass('process');
					}
					
					setTimeout(function(){
						$("#batchname").val('');
						$(".alert").removeClass("alert-success alert-danger").html('');
					},3000);
					
				}
		
			});
				
			}
			
		}
		
		});
	
	$(".showphotos").click(function(){
		
		var batchname = $("#batchname").val();
		
		if(batchname!=""){
		
			if($(this).is(":checked")) {
				loadresults(oTable,batchname,"y");     
			}else{
				loadresults(oTable,batchname,"n")
			}
			
		}
		
	});
	
	$(document).on('focus click','input,select,textarea', function () {
	  	$(".alert").removeClass("alert-success alert-danger").html('');
	});	

});
	
function loadresults(oTable,batchname,showphoto=""){
	
	$.ajax({
                type: 'POST',
                url: 'createbatchprint/batchdatatable',
                data: {"batchname":batchname,"showphoto":showphoto},
                success: function(response) {
                   
					var obj1 = $.parseJSON(response);
					
					oTable.fnClearTable();
					
					if(obj1['tabledata'].length>0){
						
						oTable.fnAddData(obj1['tabledata']);
						oTable.fnDraw();
						
						//$(".approveresults").removeClass('d-none');
						
					}
					
				}
		
	});

}
	
</script>
	
 <main> 
        
    <div class="container-fluid">
                               
		<div class="row">
			<div class="col-10">
				<h1>Create New Print Batch</h1>
			</div>
			<div class="col-2">
				
			</div>
		</div>
              
              
              <div class="col-12 p-0 my-4 add-book">
              
              <div class="card">               
                                
                <div class="row mt-3 px-3 pt-3 align-items-center">
                
                	<div class="col-12 col-sm-5">
                   
						<div class="row align-items-center">
						
							<div class="col-12 col-sm-4">
							
								<p class="text-muted mb-0">Select Batch</p>
							
							</div>
							
							<div class="col-12 col-sm-8">
							
								<div class="form-group position-relative error-l-50 floating mb-0">

									<input id="batchname" name="batchname" data-bname="" minlength="2" maxlength="1000" class="form-control batchname" placeholder=" " type="text" tabindex="1" >

								</div>
							
							</div>
							
						</div>						
						
					</div>
			  				
					<div class="col-12 col-sm-5">
					
						<div class="row align-items-center">
						
							<div class="col-12 col-sm-4">
							
								<p class="text-muted mb-0">Enter Batch Name</p>
							
							</div>
							
							<div class="col-12 col-sm-8">
							
								<div class="form-group position-relative error-l-50 floating mb-0">

									<input id="printbatchname" name="printbatchname" minlength="2" maxlength="200" class="form-control printbatchname" placeholder=" " type="text" tabindex="2" >

								</div>
							
							</div>
							
						</div>		
						
					</div>
							
					<div class="col-12 col-sm-2">
				
 						 <button class="btn btn-primary createprintbtn">Create Print Batch</button>

					 </div>
				 
					  <div class="col-12 col-sm-4"> 
						<p class="alert my-3"></p>
					  </div>
					  
					  <div class="col-12 my-3">
					  <p class="notetext">*Note : You can only select 120 Student in one Print Batch</p>
					</div>
				 
					</div>
			               				               
			   </div>
              
		</div>
             
         <div class="d-inline-block my-3"></div>
              
		<div class="row align-items-center">
			
			<div class="col-md-3">
				
				<div class="form-group position-relative error-l-50 floating mb-0">

					<input class="showphotos" name="showphotos" style="margin:0px 10px;padding:5px;vertical-align: middle;width: 20px;height: 20px" type="checkbox" value="y" /> Show only photos

				</div>
								
			</div>
			
		</div> 
              
               
               <table id="createprinttable" class="sortable table" style="width:100%"></table>
                                      
       
 </div>
 
 </main>
    
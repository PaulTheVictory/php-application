<link rel="stylesheet" href="<?php echo base_url();?>css/vendor/dataTables.bootstrap4.min.css">
<link rel="stylesheet" href="<?php echo base_url();?>css/vendor/datatables.responsive.bootstrap4.min.css">
<script src="<?php echo base_url();?>js/vendor/datatables.min.js"></script>

<script src="<?php echo base_url();?>js/vendor/jquery.Jcrop.min.js" type="text/javascript"></script>
<link rel="stylesheet" href="<?php echo base_url();?>css/boot/jquery.Jcrop.min.css">

<script type="text/javascript">
		
$(document).ready(function(){
	
	var size,jcrop_api;
	
	$(".knowmore").click(function(e){
				
		var ppercent = $(this).data('ppercent');
		var screentest = $(this).data('screentest');
		var cride = $(this).data('cride');
		
		if(ppercent<80 && screentest!="1"){
			
			e.preventDefault();
			
			var confirm = alert("Update your profile details. Redirecting to My Profile page");
			
			setTimeout(function(){location.assign('stumyprofile?action=register&id='+cride);},1000)
		}
		
	});
	
	// Upload Hallticket
	
	$('.gethallticket').on('click', function(e){
		
		var cride = $(this).parent().prev('.knowmore').data('cride');
		var courseid = $(this).parent().prev('.knowmore').data('cid');
		var center = $(this).parent().prev('.knowmore').data('center');
		var htphoto = $(this).parent().prev('.knowmore').data('htphoto');
		
		$("#requestid").val(cride);
		$("#courseid").val(courseid);
		$("#center").val(center);
		$("#imageName").val(htphoto);
				
        $('#uploadHallticketPhotoModal').modal({show:true});  
		
		if(htphoto!=""){
			
			//center = center.toLowerCase();
			
			$("#cropImage,#savePhoto").addClass('d-none');
			$(".photopreview,#downloadhallticket").removeClass('d-none');
			$("img.previewcrop").attr('src','docs/screentest/'+courseid+'/'+center+'/'+htphoto+'?'+$.now());

			$(".filenamecrop").text(htphoto);
			$(".uploadtext").html("<strong>Your hall ticket photo preview</strong>");
			
		}
		
    });
	
	$('#profileImage').on('change', function()	{ 
				
		$("#previewProfilePhoto").html('');
		$(".alert").removeClass('alert-success alert-danger alert-info').text("");
		$("#previewProfilePhoto").html('<img src="<?php echo base_url(); ?>images/loader.gif" /> Uploading....');
		
		$("#cropImage,#savePhoto").removeClass('d-none');
		$(".photopreview,#downloadhallticket").addClass('d-none');
				
			var formData = new FormData();
		
			var poData = $("#cropImage").serializeArray();//console.log(poData);
			for (var j=0; j<poData.length; j++){
				formData.append(poData[j].name, poData[j].value);
			}
	
			var c=0;
            var file_data;
			file_data = $('#profileImage')[0].files; // get multiple files from input file
			  //console.log(file_data);
		    for(var i = 0;i<file_data.length;i++){
			   formData.append('profileImage', file_data[i]); // we can put more than 1 image file
		    }
			
			$.ajax({
					type: 'POST',
					url: 'stufeepayments/uploadHallticketPhoto',
					data: formData,
					contentType: false,
					processData: false,
					success: function(response) {
						
						$('#profileImage').val('');
						$("#previewProfilePhoto").html(response);
						
						$('img#photo').Jcrop({
						  aspectRatio: 1,
						  onSelect: function(c){
						   size = {x:c.x,y:c.y,w:c.w,h:c.h};
						  }
						});
												
						$('#imageName').val($('#photo').attr('file-name'));
					}

			});
					
	});	
	
	$("#savePhoto").click(function(){
				
		var ufilename = $('img#photo').attr('file-name');		
		if(ufilename=="" || typeof(ufilename)=="undefined"){$(".alert").addClass('alert-danger').text("Upload your photo.");return false;}
				
		if(typeof(size)=="undefined"){$(".alert").addClass('alert-danger').text("Crop image and save."); return false;}
		
		
		$(".alert").removeClass('alert-success alert-danger alert-info').text("");
		
		$(".loader").removeClass('d-none');
		
		
		var formData = new FormData();
		
		var poData = $("#cropImage").serializeArray();//console.log(poData);
			for (var j=0; j<poData.length; j++){
				formData.append(poData[j].name, poData[j].value);
		}
		
		formData.append('x', size.x);
		formData.append('y', size.y);
		formData.append('w', size.w);
		formData.append('h', size.h);
		formData.append('action', 'crop');
		
		$.ajax({
				type: 'POST',
				url: 'stufeepayments/uploadCropHallticketPhoto',
				data: formData,
				contentType: false,
				processData: false,
				success: function(response) {

					size = {};
					$(".loader").addClass('d-none');
					
					if(response!=""){
						
						$("#cropImage,#savePhoto").addClass('d-none');
						$(".photopreview,#downloadhallticket").removeClass('d-none');
						$("img.previewcrop").attr('src',response);

						var imageName = $("#imageName").val();
						var cride = $("#requestid").val();
						
						imageName = imageName.replace("_tmp","");
						$("#imageName").val(imageName);
						$("img#photo").attr('src',response);
						
						$(".filenamecrop").text(imageName);
												
						$("#"+cride).data('htphoto',imageName);
						
					}

				}

		});
		
	});
	
	
	$(".edituploadht").click(function(){
		
		var cride = $("#requestid").val();
		var courseid = $("#courseid").val();
		var center = $("#center").val();
		var htphoto = $("#imageName").val();
		
		if(htphoto!=""){
			
			if ($('img#photo').data('Jcrop')) {
				$('img#photo').data('Jcrop').destroy();
				$('img#photo').removeAttr('style');
			}
			
			$("#previewProfilePhoto").html('<img id="photo" file-name="'+htphoto+'" src="docs/screentest/'+courseid+'/'+center+'/'+htphoto+'?'+$.now()+'" class="preview mw-100" />');
			$('img#photo').Jcrop({
			  aspectRatio: 1,
			  onSelect: function(c){
			   size = {x:c.x,y:c.y,w:c.w,h:c.h};
			  }
			});
						
		}
		
		$(".loader").addClass('d-none');
		$("#cropImage,#savePhoto,#downloadhallticket").removeClass('d-none');
		$(".photopreview").addClass('d-none');
		$(".alert").removeClass('alert-success alert-danger alert-info').text("");
		
	});
	
	$('#uploadHallticketPhotoModal').on('hidden.bs.modal', function () {
  		
		$(".loader").addClass('d-none');
		$("#cropImage,#savePhoto").removeClass('d-none');
		$(".photopreview,#downloadhallticket").addClass('d-none');
		$(".alert").removeClass('alert-success alert-danger alert-info').text("");
		
		$("#previewProfilePhoto").html('');
		
		if ($('img#photo').data('Jcrop')) {
			$('img#photo').data('Jcrop').destroy();
			$('img#photo').removeAttr('style');
		}
		
	});
	
	$("#downloadhallticket").click(function(){
		
		var cride = $("#requestid").val();
		
		window.open("stufeepayments/downloadHallticket?crid="+cride,"_blank");
		
	});
	
	$("input,select,textarea").click(function(){
		
		$(".alert").removeClass('alert-success alert-danger alert-info').text("");
		
	});
        
        
        $(document).on("click",".addrefund",function(){
          
                var ide = $(this).attr("data-id");
                var tpe = $(this).attr("data-refund");
                tpe = (tpe ==="1")?"init":"update";
                $(location).prop('href', 'stufeerefund?id='+ide+"&type="+tpe);
            
                
	});	
        
	});	
        
            
</script>

<style>
		
	.feepayments h1{font-size: 18px;font-weight: bold;color: #0332AA;}
	.feepayments .card,.courseinfo .card{background: linear-gradient(0deg, #FFFFFF, #FFFFFF), #C4C4C4;box-shadow: 0px 0px 7px rgba(196, 196, 196, 0.35);border-radius: 10px;}
	.feepayments h2{color: #0332AA;font-size: 24px;font-weight: bold;line-height: 36px;}
	.feepayments p.list-item-heading{color: #6884CC;font-weight: 600;}
	.feepayments .feetop p.list-item-heading span:last-child{font-weight: 600;font-size: 14px;color: #364159;}
	
	.feepayments .crstatus-approve,.feepayments .crstatus-waitlisted,.feepayments .crstatus-pending{font-size: 12px !important;color: #ffffff !important;border-radius: 20px;text-transform: capitalize}
	.crstatus-approve{ background: #3CAF92;}
	.crstatus-waitlisted{background: #ED5252;}
	.crstatus-pending{background: #F48D25;}
	
	.feepayments .card:after{content: " ";color: #fff;position: absolute;width: 10px;height: 100%;top: 50%;transform: translateY(-50%);left: 0;border-top-left-radius: 10px;border-bottom-left-radius: 10px;}
	.feepayments.approve .card:after{background: #3CAF92;}
	.feepayments.waitlisted .card:after{background: #ED5252;}
	.feepayments.pending .card:after{background: #F48D25;}
	
	
	.border-right{border-right: 1px solid #D7DFF0!important;}
		
	.btn-primary{width: auto}
	.btn-primary.disabled, .btn-primary:disabled{background: #9AADDD;color: #ffffff;}
	
	.card h5{margin-bottom: 1rem;}
	h5{font-weight: bold;}
	.badge-outline-secondary, .badge-outline-theme-2{border: 1px solid #889DC6;color: #889DC6;background: #F6F7FA;}
	.badge{font-size: 12px;margin-right: 5px}
	
	.courseinfo .col-right .card .card-body{padding: 0;}
	.courseinfo .border-bottom{border-bottom: 1px solid #D7DFF0!important;}
	.col-right h5{padding: 1.2rem}
 
	.icon-credit-card-2{background: url("img/icons/credit-card-2.png") no-repeat;width: 15px;height: 15px;display: inline-block;vertical-align: middle}
	.icon-check-circle{background: url("img/icons/check-circle-b.png") no-repeat;width: 15px;height: 15px;display: inline-block;vertical-align: middle}
	.icon-minus-circle{background: url("img/icons/minus-circle.png") no-repeat;width: 15px;height: 15px;display: inline-block;vertical-align: middle;margin-right: 5px}
	.icon-map-pin{background: url("img/icons/map-pin-b.png") no-repeat;width: 15px;height: 15px;display: inline-block;vertical-align: middle;margin-right: 5px}
	.icon-invoice-b{background: url("img/icons/invoice-b.png") no-repeat;width: 15px;height: 15px;display: inline-block;vertical-align: middle;margin-right: 5px}
	
	p span.totalfee {font-weight: bold;font-size: 18px;color: #0332AA;}
	p span.paidfee {font-weight: bold;font-size: 18px;color: #209679;}
	p span.duefee {font-weight: bold;font-size: 18px;color: #D63333;}
	
	
	/* Upload Hall ticket Photo */
	
	.icon-edit3-b{background: url("img/icons/edit3-b.png") no-repeat;width: 15px;height: 16px;display: inline-block;vertical-align: middle;margin-left: 5px;cursor: pointer}
	.dropdown-toggle::after{margin-left: 0.8em;position: relative;top: 2px}
	
	/* Upload files*/	
	
	.box {position: relative;background: #ffffff;width: 100%;}
	.box-header {color: #444;display: block;padding: 10px;position: relative;border-bottom: 1px solid #f4f4f4;margin-bottom: 10px;}
	.box-tools {position: absolute;right: 10px;top: 5px;}
	.dropzone-wrapper {background: #F6F7FA;border: 1px dashed #BCCAE8;color: #92b0b3;position: relative;height: 100px;border-radius: 5px;}
	.dropzone-desc {position: absolute;margin: 0 auto;left: 0;right: 0;text-align: center;width: auto;top: 22px;font-size: 16px;}
	.dropzone,
	.dropzone:focus {position: absolute;outline: none !important;width: 100%;height: 100px;cursor: pointer;opacity: 0;}
	.dropzone-wrapper:hover,
	.dropzone-wrapper.dragover {background: #ecf0f5;}
	.preview-zone {text-align: center;}
	.preview-zone .box {box-shadow: none;border-radius: 0;margin-bottom: 0;}
	#filename {margin-top: 10px;margin-bottom: 10px;font-size: 14px;line-height: 2.7em;border: 1px solid #D7DFF0;
    border-radius: 5px;min-height: 40px;margin-top: 2.2rem;}
	.file-preview {background: #ccc;border: 5px solid #fff;box-shadow: 0 0 4px rgba(0, 0, 0, 0.5);display: inline-block;width: 60px;height: 60px;text-align: center;font-size: 14px;margin-top: 5px;}
	.closeBtn:hover {color: red;display:inline-block;}
	
	.icon-upload{background: url("img/icons/upload.png") no-repeat;width: 24px;height: 24px;display: inline-block;vertical-align: middle}
	.dropzone-desc p.list-item-heading{font-size: 14px;font-weight: 600;color: #536485;display: inline-block}
	.dropzone-desc p.text-muted{font-size: 10px;font-weight: normal;color: #6F83AA;}
	.dropzone-desc p.list-item-heading span{color: #db4d4d}
	.dropzone-desc p.text-center{text-align: center !important}
	
</style>


<main>

	<div class="container-fluid">

		<div class="row">
		  <div class="col-12">

			  <div class="row">
			   
			   	  <div class="col-md-9">
			   		<h1>Fee and Payments</h1>
				  </div>
				  <div class="col-md-3">
					 <div class="form-group">
						<select class="form-control schedule" name="schedule" >
						  <option value="">Sort By</option>
						  <option value="date">Date</option>
						  <option value="status">Status</option>
						</select>
					 </div>
				  </div>
			   
			   </div>

			   <div class="mb-3"></div>

		</div>

		</div>
		
		<?php 
		
			if(!empty($feepayments['coursename'])){//print_r($feepayments);
				
			foreach($feepayments['coursename'] as $key=>$feepayment){
								
				$admissiontime = date('M Y',strtotime($feepayments['starts_on'][$key])).' - '. date('M Y',strtotime($feepayments['ends_on'][$key]));
				
				$center = $feepayments['center'][$key];
				$totalfee = round($feepayments['totalfee'][$key]);
				$paidfee = round($feepayments['paidfee'][$key]);
				$duefee = round($feepayments['duefee'][$key]);
				
				$courseid = $feepayments['courseid'][$key];	
				$cride = $feepayments['ide'][$key];	
				
				$screentest = $feepayments['screentest'][$key];
                                $refund = $feepayments['refund'][$key];
				
				$photocopy_ht = $feepayments['photocopy_ht'][$key];
				$issue_ht = $feepayments['issue_ht'][$key];
				
		?>
	
		<div class="row feepayments">

			<div class="col-12 mb-4">
				<div class="card">
					<div class="card-body">

						<div class="row">

							<div class="col-md-8 col-sm-8 col-lg-8 col-12">
								
								<h1 class="mb-2"><?php echo $feepayment; ?></h1>

								<div class="row mb-3 feetop">

									<div class="col-md-3 col-sm-3 col-3 text-left px-2">
										<p class="list-item-heading mb-1"><i class="icon-map-pin"></i> <span>Assigned Center:</span> <span><?php echo $center; ?></span></p>
									</div>

									<div class="col-md-5 col-sm-5 col-5 text-left px-2">
										<p class="list-item-heading mb-1"><i class="icon-invoice-b"></i> <span>Admission Time:</span> <span><?php echo $admissiontime; ?></span></p>
									</div>
                                                                    <?php if($refund === '1') {?>
                                                                    
                                                                    <div class="col-md-4 col-sm-4 col-4 text-left px-2 mt-n2">
                                                                        <p class="list-item-heading mb-1"><i class="icon-invoice-b"></i> <span>Refund :</span><span> <button type="button" data-refund="<?php echo $refund; ?>" data-id="<?php echo $cride; ?>" class="btn btn-primary addrefund">Request</button></span></p>
									</div>
                                                                    <?php } else if($refund === '2'){?>
                                                                        <div class="col-md-4 col-sm-4 col-4 text-left px-2 mt-n2">
                                                                        <p class="list-item-heading mb-1"><i class="icon-invoice-b"></i> <span>Refund :</span><span> <button type="button" style="background:#F48D25 !important" class="btn btn-primary">Progressing</button></span></p>
									</div>
                                                                    <?php } else if($refund === '3'){?>
                                                                     <div class="col-md-4 col-sm-4 col-4 text-left px-2 mt-n2">
                                                                        <p class="list-item-heading mb-1"><i class="icon-invoice-b"></i> <span>Refund :</span><span> <button type="button" style="background:#3CAF92 !important" class="btn btn-primary">Progressing</button></span></p>
									</div>
                                                                    <?php }  else if($refund === '4'){?>
                                                                     <div class="col-md-4 col-sm-4 col-4 text-left px-2 mt-n2">
                                                                        <p class="list-item-heading mb-1"><i class="icon-invoice-b"></i> <span>Refund :</span><span> <button type="button" style="background:#3CAF92 !important" class="btn btn-primary">Completed</button></span></p>
									</div>
                                                                    
                                                                    <?php }  else if($refund === '5'){?>
                                                                     <div class="col-md-4 col-sm-4 col-4 text-left px-2 mt-n2">
                                                                        <p class="list-item-heading mb-1"><i class="icon-invoice-b"></i> <span>Refund :</span><span> <button type="button" style="background:#db4d4d !important" class="btn btn-primary">Not Eligible</button></span></p>
									</div>
                                                                    <?php }  else if($refund === '6'){?>
                                                                     <div class="col-md-4 col-sm-4 col-4 text-left px-2 mt-n2">
                                                                        <p class="list-item-heading mb-1"><i class="icon-invoice-b"></i> <span>Refund :</span><span> <button type="button" style="background:#db4d4d !important" class="btn btn-primary">Cancelled</button></span></p>
									</div>
                                                                    <?php } ?>

								</div>
								
								<div class="row">

									<div class="col-md-4 col-sm-4 col-4 text-left px-2">
										<p class="list-item-heading mb-1"><i class="icon-credit-card-2"></i> <span>Total Fees:</span> <span class="totalfee"><?php echo number_format($totalfee,2); ?></span></p>
									</div>

									<div class="col-md-4 col-sm-4 col-4 text-left px-2">
										<p class="list-item-heading mb-1"><i class="icon-check-circle"></i> <span> Remitted Fees:</span> <span class="paidfee"><?php echo number_format($paidfee,2); ?></span></p>
									</div>

									<div class="col-md-4 col-sm-4 col-4 text-left px-2">
										<p class="list-item-heading mb-1"><i class="icon-minus-circle"></i> <span>Due Fees:</span> <span class="duefee"><?php echo number_format($duefee,2); ?></span></p>
									</div>

								</div>

							</div>

							<div class="col-md-4 col-sm-4 col-lg-4 col-12 d-flex align-items-center justify-content-end">
								
								<div class="row w-100">

									<div class="col-md-12 text-right">
										<a href="<?php echo base_url();?>stufeepayments?id=<?php echo $cride;?>" title="Payments" data-ppercent="<?php echo $stuprofile['profilepercent'];?>" data-screentest="<?php echo $screentest;?>" data-cride="<?php echo $cride;?>" <?php if($issue_ht=="Y"){ echo 'data-cid="'.$courseid.'" data-center="'.$center.'"  data-htphoto="'.$photocopy_ht.'" class="knowmore"';}?> type="button" <?php if($issue_ht=="Y"){ echo 'data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"';}?> id="<?php echo $cride;?>"> <button class="btn btn-outline-primary <?php if($issue_ht=="Y"){ echo "dropdown-toggle";}?>">Payments</button></a>
										
										<?php if($issue_ht=="Y"){?>
										<div class="dropdown-menu">
											<a class="dropdown-item knowmore" href="<?php echo base_url();?>stufeepayments?id=<?php echo $cride;?>" data-ppercent="<?php echo $stuprofile['profilepercent'];?>" data-screentest="<?php echo $screentest;?>" data-cride="<?php echo $cride;?>" title="View Payments">View Payments</a>
											<a class="dropdown-item gethallticket" href="#" title="Get Hall Ticket">Get Hall Ticket</a>
										</div>
										<?php }?>
										
									</div>

								</div>
						
							</div>

						</div>


					</div>

				</div>
			</div>
		</div>
		
		<?php }}else{?>
		
		<div class="row feepayments">

			<div class="col-12 mb-4">
				<div class="card">
					<div class="card-body">
					
						<p class="text-muted text-center mb-0">No Fee and Payments Found.</p>
					
				</div>
			</div>
		</div>
		
		<?php }?>

	</div>


	</div>
</main>

<style>
		
	#uploadHallticketPhotoModal.modal .modal-header{padding: 18px 20px !important;background: #6884cd;}	
	#uploadHallticketPhotoModal.modal .modal-body{padding:1.4rem 1.4rem}
	.modal-body p{text-align: left !important}
	.modal-backdrop.show {opacity: .5 !important;}
	.modal .modal-content{border-radius: 10px}
	.modal .close{color: #ffffff;}
	h5.modal-title{color: #ffffff}
	
	.jcrop-holder{margin: auto}
		
</style>

<div id="uploadHallticketPhotoModal" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
				   <h5 class="modal-title" id="changeProfilePhotoModal">Download Hall Ticket</h5>
				   <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				</div>
				<div class="modal-body">
					<form id="cropImage" method="post" enctype="multipart/form-data" action="#">
						
						<div class="row align-items-center mt-4">
					
							<div class="col-12 justify-content-start">
								
								<p class="text-muted mb-3">Please upload your profile photo to download the hall ticket.</p>

								<div id="drop-zone">
									<div class="dropzone-wrapper">
									  <div class="dropzone-desc" id="clickHere">
										<i class="icon-upload mb-2"></i>
										<p class="list-item-heading mb-1">Upload Your Photo</p>
										  <p class="text-muted mb-2 text-center">Max photo size upto 1MB. File format JPG, PNG and JPEG only.</p>
									  </div>

									  <input type="file" name="profileImage" id="profileImage"  class="dropzone"/>

									</div>

								</div>

								 </div>
				   
						 </div>
						 
						
						<input type="hidden" name="requestid" id="requestid" value="" />
						<input type="hidden" name="studentid" id="studentid" value="<?php echo $user['id']; ?>" />
						<input type="hidden" name="courseid" id="courseid" value="" />
						<input type="hidden" name="center" id="center" value="" />
						<input type="hidden" name="imageName" value="" id="imageName" />						
						<div id='previewProfilePhoto' class="mt-3"></div>
						
					</form>
					
					<div class="row photopreview mt-4 d-none">
						
						<div class="col-2">
							<img src="" class="previewcrop w-100" />
						</div>
						<div class="col-10">
							
							<div class="row align-items-center">
						
								<div class="col-10">
									<p class="text-muted edituploadht mb-2"><span class="filenamecrop"></span> <i class="icon-edit3-b"></i></p>
									<p class="text-muted mb-0 uploadtext"><strong>Your profile photo uploaded successfully</strong></p>
								</div>
								<div class="col-2">
									<img src="img/icons/round-tick.png" alt="tick" class="w-100" />						
								</div>
						
							</div>
							
						</div>
						
					</div>
					
					<p class="alert mb-0 mt-2"></p>
					
				</div>
				<div class="modal-footer">
							
						<div class="w-25 text-left">
							<button type="button" class="btn btn-outline-primary modalclose justift-content-start" data-dismiss="modal">Cancel</button>
						</div>
						
						<div class="w-75 text-right">
							<img src="<?php echo base_url(); ?>images/loader.gif" class="loader d-none" />
							<button type="button" id="downloadhallticket" class="btn btn-primary d-none">Download Hall Ticket</button>
							<button type="button" id="savePhoto" class="btn btn-primary">Crop & Save</button>
						</div>
						
					</div>
				</div>
								
			</div>
		</div>
	</div>

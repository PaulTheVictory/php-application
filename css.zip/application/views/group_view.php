<div id="pagetitle">

	<div class="wrap">
    
    	<h1>Add Model</h1>
        
	</div>
    
</div>
<style type="text/css">


.dataTables_wrapper input[type="text"] {
    padding: 0;
}
.dataTables_wrapper select {
    padding: 0;
}
.sortable tr th {
    border-right: 1px solid #ddd;
    padding: 10px 0;font-size: 13px;
}
.sortable tr td {
    border-right: 1px solid #ddd;
    padding: 15px 5px;
    text-align: center;font-size: 13px;
}
.sortable tr td a {
    color: #333;
}

#profile-right h2 {
    margin: 0px 0px 10px 0px;
}

.assettable_length { width: auto !important; }
#assettable_filter input { border: 1px solid #ccc; line-height: 25px;margin-left: 10px;}
.sortable tr td a:hover { text-decoration: underline; }

.sortable tr td:first-child{
    width: 50%;
}
</style>
<script type="text/javascript">
$(document).ready(function(){	
		
	
          var columnData = [
                    { "data": "name" },
                     { "data": "discount" },
                      { "data": "customer_discount" },
                       { "data": "electrician_discount" },
                       { "data": "tax" }
                  ];
         columnData.push( {data: "id"} );
        // columnData.push( {data: "memtype","visible":false} );
         
       
        var oTable = $('#assettable').dataTable({
                    "bProcessing": true,
                    "bServerSide": true,
                    "sPaginationType": "full_numbers",
                    "ajax": {
                    "url": 'group/getGroups',
                    "type": "POST"
                     }, 
                     "oLanguage": {
                        "sProcessing": "<img src='<?php echo base_url(); ?>images/loader.gif'>"
                    },
                    'iDisplayLength': 10,
                    "columns": columnData,
                    "fnDrawCallback": function( oSettings ) {
                            $("#assettable").find(".del").each(function(){

                            $(this).click(function(){ 

                              if(confirm("Are you sure to delete this Group ?")) {
                                    var ide = $(this).attr("id");
                                    $.get('group/delGroup',{
                                                               'ide':ide

                                                    }, function(o) { 
                                                            var obj1 = $.parseJSON(o);
                                                    if (obj1[0] === 'success') {
                                                        oTable.fnDraw(); 
                                                    } else if (obj1[0] === 'fail') {
                                                        alert("Error!!! please try again");
                                                    }else  {
                                                            alert(obj1[0]);
                                                    }
                                    });
                                }

                              });
                        

                          });
                    }
         }); 
         
         $(".add-country").find("input").each(function(){

              $(this).click(function(){ $(".errnotify").html("&nbsp;");});
            
                $(this).keyup(function(event){
                    if(event.keyCode == 13){
                        var ty = $(this).next();
                        event.preventDefault();
                        $('input')[$('input').index(this)+1].focus();
                        
                    }
                });

        });
	
	$(".add-country").find(".course-submit").click(function(){
		
		var name = $(".add-country").find(".name").val();
                var discount = $(".add-country").find(".discount").val();
                var cust_discount = $(".add-country").find(".cust_discount").val();
                var elec_discount = $(".add-country").find(".elec_discount").val();
                var tax = $(".add-country").find(".tax").val();
                
		
		if(name === ""){ $(".errnotify").html("Invalid Group name");return;}		
		
		$(this).val("Processing...");
		
				$.get('group/insertGroup',{
					   'name':name,'discount':discount,'cust_discount':cust_discount,
                                           'elec_discount':elec_discount,'tax':tax

				}, function(o) { 
					var obj1 = $.parseJSON(o);
                                        $("#grpname").focus();
                                        $(".add-country").find(".course-submit").val("Submit");
                                if (obj1[0] === 'success') {
                                    
                                    $(".add-country").find('[type="text"]').each(function(){ $(this).val(''); });
                                     $(".errnotify").html("<font style=\"color:#188f04\">Group has been added succesfully!!</font>");
                                     oTable.fnDraw(); 

                                } else if (obj1[0] === 'exists') {
                      
                                    $(".errnotify").html("Group already exists...Please try again");

                                }else if (obj1[0] === 'fail') {
                                    $(".errnotify").html("Please try again");

                                }
                                
                                
                                
                            });

           });
           
            
	
});
</script>
<div class="maincontent">

    <div class="wrap" style="max-width: 960px;margin-top: 50px">
        
          <?php echo $this->table->generate();  ?>         
    
        <div id="course-container" class="add-country" style=" border: 1px solid #ccc;
    padding: 20px 20px 0;margin-top: 100px">

                <div class="row-element">
                    <span class="title" style="padding: 0px;padding-top: 10px">Model</span>
                    <span class="content"><input type="text" value="" class="name" id="grpname"></span>
                </div>

                <div class="row-element">
                    <span class="title" style="padding: 0px;padding-top: 10px">Discount (%)</span>
                    <span class="content"><input type="text" value="" class="discount"></span>
                </div>
            
                <div class="row-element">
                    <span class="title" style="padding: 0px;padding-top: 10px">For Customer Profit Margin (%)</span>
                    <span class="content"><input type="text" value="" class="cust_discount"></span>
                </div>
            
            
                <div class="row-element">
                    <span class="title" style="padding: 0px;padding-top: 10px">For Electrician  Profit Margin (%)</span>
                    <span class="content"><input type="text" value="" class="elec_discount"></span>
                </div>
            
                <div class="row-element">
                    <span class="title" style="padding: 0px;padding-top: 10px">Tax (%)</span>
                    <span class="content"><input type="text" value="" class="tax"></span>
                </div>
            
                 <div class="row-element">
                    <span class="content">
                        <input style="float: left" type="submit" class="course-submit" value="Submit">
                        <p class="errnotify" style="color:#aa3e41;margin:0px;padding:0px;float:left;padding-left:20px;padding-top:10px"> </p>
                    </span>
                </div>
                
            </div>

            
           
         
     
        </div>
    
    </div>
    


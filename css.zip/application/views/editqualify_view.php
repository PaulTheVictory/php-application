<?php
//var_dump($qualification1);
?>

<link rel="stylesheet" href="<?php echo base_url();?>css/fonts/simple-line-icons/css/simple-line-icons.css">

<link rel="stylesheet" href="<?php echo base_url();?>css/boot/bootstrap.min.css">
<link rel="stylesheet" href="<?php echo base_url();?>css/boot/main.css?v=3">

<script src="<?php echo base_url();?>js/bootstrap.bundle.min.js"></script>
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/dataTables.css?v=1.5" />
<script src="<?php echo base_url(); ?>js/jquery.dataTables.js?v=1.0" type="text/javascript"></script>
 <link href="<?php  echo base_url(); ?>css/jquery-ui.min.css?v=1.4" rel="stylesheet" type="text/css" />
 <link href="<?php  echo base_url(); ?>css/chosen.min.css?v=1.3" rel="stylesheet" type="text/css" />

 <script src="<?php  echo base_url(); ?>js/jquery-ui.min.js?v=1.3" type="text/javascript"></script>
  <script src="<?php  echo base_url(); ?>js/chosen.jquery.min.js?v=1.2" type="text/javascript"></script>
  
  <link rel="stylesheet" href="<?php echo base_url();?>css/boot/vendor/baguetteBox.min.css">
<script src="<?php echo base_url();?>js/vendor/baguetteBox.min.js"></script>

 <style type="text/css">
	 
	 ul li{margin-bottom: 0px}
     
     .dataTables_wrapper input[type="text"] {text-indent: 5px;}
.dataTables_wrapper select {
    padding: 0;
}

label {line-height: 1.5;}

.sortable thead tr  {
    background: #E6EBF7;

/* g8 */
border: 1px solid #D7DFF0;
box-sizing: border-box;
border-radius: 10px 10px 0px 0px;
 

}
.sortable tr th {
    border-right: 0px;
    padding: 17px 0;font-size: 13px;
      color: #6F83AA;
   cursor: pointer;
   text-align: center;

}


.sortable tr td:nth-child(1) {
   
    
   width: auto;     
}

.sortable tr th:nth-child(2) { text-align: left;}
.sortable tr td:nth-child(2) {
   min-width:50px;
    color: #364159; vertical-align: middle;
    width:50%;
    text-align: left;
}

.sortable tr td:nth-child(3) {
   
    width:25%;
}

.sortable tr td:nth-child(4) {
   
    width:25%;
}


.sortable tr td {
    border-right: 0px;
    padding: 15px 5px;
    text-align: center;font-size: 13px;
    min-width:50px;
}
     .dataTables_info { display: none; }
#subjecttable_paginate,#subjecttable1_paginate { display: none;}
#subjecttable_filter input,#subjecttable1_filter input {display:none;}
     .ui-selectmenu-button.ui-button{ width: 97%; padding:10px;border: 1px solid #D7DFF0;background: #fff;font-size: 14px;color:#536485}
     
     #centers_chosen  {border: 1px solid #D7DFF0;background: #fff;padding: 8px 0px;}
     .chosen-container-multi .chosen-choices {border: 0px;background: none}
     .maincontent ul li.search-choice { height:auto; }
     .maincontent ul li.search-choice a{ height:auto; font-size: 14px;color:#536485}
     .chosen-container-multi .chosen-choices li.search-choice { background: #6884CC;border-radius: 5px;}
     .chosen-container-multi .chosen-choices li.search-choice {color: #fff;}
     
     .streams li { list-style: none;padding:5px;display: inline-block;width: 100%;}
     .ui-checkboxradio-radio-label .ui-icon-background { border: 1px solid #D7DFF0; }
.ui-checkboxradio-radio-label.ui-checkboxradio-checked .ui-icon, .ui-checkboxradio-radio-label.ui-checkboxradio-checked:hover .ui-icon { border-width: 5px;border-color: #0332aa;}
.dropLabel { color:#536485;background: none;border: 0px;width: 50%;height: auto;}
.chkLabel { text-align: left;color:#536485 !important;;background: none !important;border: 0px !important;width: auto;height: auto;font-size: 13px}
.ui-selectmenu-text { font-size:13px;}
.course-container {
    
   /* box-shadow: 3px 3px 3px #eee;
    -webkit-box-shadow:3px 3px 3px #eee;
    -moz-box-shadow:3px 3px 3px #eee;*/
    padding-top: 20px;
    
    width:98%;
    background: #fff;
    padding-left: 20px;
    border-radius: 10px;
    
}

.row-element {
    height: auto;
    margin: 10px auto;
    width: 100%;
}

.row-element .content {
   float: left;
    padding: 10px 15px;
    text-align: left;
    width: 95%;
    min-width: 400px;
}
input[type="text"]{
	
	color:#536485;
	border:1px solid #D7DFF0;
	font-size:14px;
	padding:10px;	
	display:inline-block;
	margin:0px auto;
	outline:none;
	background: #fff;
	box-sizing:border-box;
        width: 100%;
        border-radius: 5px;
        height: 40px;
}
.hide { display: none;}
.show { display: "";}
.response p { display: block;font-size:12px;color:#eb345e;margin-right: 20px}
	 
	 .qualificationcheck .card{background: linear-gradient(0deg, #FFFFFF, #FFFFFF), #C4C4C4;box-shadow: 0px 0px 7px rgba(196, 196, 196, 0.35);border-radius: 10px;}
	 .xii_std .row-element,.x_std .row-element{width: auto}
	 .entrance_exam.row-element{display: inline-block}
         
         .icon-bookmark-s{background: url("img/icons/bookmark-s.png") no-repeat;width: 14px;height: 14px;display: inline-block;vertical-align: middle;margin-right: 0.5rem}
	.icon-phone-s{background: url("img/icons/phone-s.png") no-repeat;width: 14px;height: 14px;display: inline-block;vertical-align: middle;margin-right: 0.5rem}
	.icon-mail-s{background: url("img/icons/mail-s.png") no-repeat;width: 14px;height: 14px;display: inline-block;vertical-align: middle;margin-right: 0.5rem}
	.icon-edit3{background: url("img/icons/edit3.png") no-repeat;width: 15px;height: 16px;display: inline-block;vertical-align: middle;margin-right: 0.4rem}
	
	.profiletop p.list-item-heading{font-size: 14px;font-weight: 600;line-height: 20px;color: #6884CC !important;}
	.profiletop p.text-muted{font-size: 16px;font-weight: bold;line-height: 24px;color: #0332AA !important;}
        
        .profilename {
    font-size: 24px;
    color: #181E29;
    line-height: 36px;
}

.studid {
    font-size: 16px;
    display: block;
    line-height: 20px;
}
	 
	  /* Upload files*/	
	
	.box {position: relative;background: #ffffff;width: 100%;}
	.box-header {color: #444;display: block;padding: 10px;position: relative;border-bottom: 1px solid #f4f4f4;margin-bottom: 10px;}
	.box-tools {position: absolute;right: 10px;top: 5px;}
	.dropzone-wrapper {background: #F6F7FA;border: 1px dashed #BCCAE8;color: #92b0b3;position: relative;height: 120px;border-radius: 5px;}
	.dropzone-desc {position: absolute;margin: 0 auto;left: 0;right: 0;text-align: center;width: auto;top: 22px;font-size: 16px;}
	.dropzone,
	.dropzone:focus {position: absolute;outline: none !important;width: 100%;height: 150px;cursor: pointer;opacity: 0;}
	.dropzone-wrapper:hover,
	.dropzone-wrapper.dragover {background: #ecf0f5;}
	.preview-zone {text-align: center;}
	.preview-zone .box {box-shadow: none;border-radius: 0;margin-bottom: 0;}
	#filename {margin-top: 10px;margin-bottom: 10px;font-size: 14px;line-height: 2.7em;border: 1px solid #D7DFF0;
    border-radius: 5px;min-height: 40px;margin-top: 2.2rem;}
	.file-preview {background: #ccc;border: 5px solid #fff;box-shadow: 0 0 4px rgba(0, 0, 0, 0.5);display: inline-block;width: 60px;height: 60px;text-align: center;font-size: 14px;margin-top: 5px;}
	.closeBtn:hover {color: red;display:inline-block;cursor: pointer}
	
	.icon-upload{background: url("img/icons/upload.png") no-repeat;width: 24px;height: 24px;display: inline-block;vertical-align: middle}
	.dropzone-desc p.list-item-heading{font-size: 14px;font-weight: 600;color: #536485;}
	.dropzone-desc p.text-muted{font-size: 10px;font-weight: normal;color: #6F83AA;}
	.dropzone-desc p.list-item-heading span{color: #db4d4d}
	
	.dropzone-desc .text-center{text-align: center !important}
	
	.custom-radio label{font-size: 14px;font-weight: normal;color: #536485;}
	
	h3.title{font-size: 12px;font-weight: bold;color: #0332AA;letter-spacing: 0.5px;text-transform: uppercase;}
	.file_ms{font-size: 12px;color: #1C47B3;text-decoration-line: underline;display: inline-block}
	
	.myprofile .img-thumbnail{width: 115px;height: 115px}
	.icon-download{background: url("img/icons/download.png") no-repeat;width: 15px;height: 16px;display: inline-block;vertical-align: middle;margin-right: 0.5rem}
	 
 </style>

         
<div class="wrap dynamic-width" style="float: left;position: relative" >
     <div style="margin-top: 10px; width: 99%; height: 50px; text-align: right;">
         <span style="font-weight: bold;font-size: 20px;padding: 10px;float:left;color: #364159">Qualification Update</span>
         </div>         
           <div class="card mb-4">
				
				<div class="row">
          
          <div class="col-md-6 col-sm-6 col-lg-9 col-12">
           
            <div class="d-flex flex-row">
             
				<a class="d-flex position-relative myprofile" href="#"><img alt="Profile" src="<?php if($stuprofile['profilepic']!="0" && $stuprofile['profilepic']!=""){ echo "docs/profilepic/".$sid."/".$stuprofile['profilepic']."?".time();}else{echo "img/myprofile.png?".time();} ?>" class="img-thumbnail border-0 rounded-circle mx-4 my-4 align-items-center"> <!--<span class="profileedit"><i class="icon-edit"></i></span>--></a>
             
              <div class="d-flex flex-grow-1 min-width-zero">
                <div class="card-body pl-0 py-2 align-self-center d-flex flex-column flex-lg-row justify-content-between min-width-zero">
                  <div class="w-100">
					  <p class="list-item-heading mb-2 truncate font-weight-bold profilename"><?php echo ucwords($stuprofile['stuname']); ?> <span class="studid">Student ID: <?php echo $stuprofile['studid'];?></span></p>
                    
                    <div class="row profiletop">

						<div class="col-md-4 text-left px-3">
							<p class="list-item-heading mb-2"><i class="icon-bookmark-s"></i> Class Studying</p>
							<p class="mb-2 text-muted <?php if($stuprofile['classstudy']=="" || $stuprofile['classstudy']=="0"){ echo "empty";} ?>"><?php if($stuprofile['classstudy']!=""){ echo ucwords($stuprofile['classstudy']);}else{echo "-Nil-";} ?></p>
						</div>

						<div class="col-md-3 text-left px-2">
							<p class="list-item-heading mb-2"><i class="icon-phone-s"></i> Phone</p>
							<p class="mb-2 text-muted"><?php if($stuprofile['sumcode']!=""){ echo $stuprofile['sumcode'];}else{echo $stuprofile['smcode'];}?> <?php echo $stuprofile['smobile']; ?></p>
						</div>

						<div class="col-md-5 text-left px-2">
							<p class="list-item-heading mb-2"><i class="icon-mail-s"></i> Mail</p>
							<p class="mb-2 text-muted"><?php echo strtolower($stuprofile['semail']); ?></p>
						</div>

					</div>
                 
                  </div>
                </div>
              </div>
            </div>
            
          </div>
          

          
        </div>
				
			</div>
    <?php echo form_open('stuqualifyupdate/qualificationSubmit', array('id' => 'qualificationForm')) ?>
    
           <div class="col-12 qualificationcheck p-0">
               
           
           <div class="card">
           
            <div class="course-container add-course px-4">
               
               <div class="row qualifytop my-4">
               
               <div class="col-md-5 col-sm-5 mb-4"><span class="content"> <label style="color:#0332AA;background: none;border: 0px;width: 100%;height: 20px;font-weight: bold;font-size: 18px;">ENTER PRIMARY DETAILS </label></span></div>
               
                <div class="col-md-7 col-sm-7 text-right">
                    <h3 style="text-align:right"><span class="content text-right" style="color:#0332AA"><?php echo $qualification['general']['name'];?></span></h3>
                </div>
               
                 <div class="col-12 col-sm-6">
                    
				  		<div class="form-group floating">     
                                                                          
                             <select  id="selstream" name="stream" class="form-control stream yearofpassing">
                            <option value="" >Select Stream</option>
                             <?php 
                            $ret = "";
                              foreach($qualification['general_x'] as $key=>$val)
                              {
                                  if($qualification1['stream'] === $val['stream']){
                                      $selected = 'selected="selected" ';
                                  }
                                  $ret .="<option >".$val['stream']."</option>";
                              }
                              echo $ret;
                            ?>
                             </select>
                          
                         <label>Select Stream <span>*</span></label>
                         
						 </div>
					</div>
                
		</div>
                </div>
               </div>
                </div>
            <label style="color:#536485;background: none;border: 0px;width: 100%;height: 20px;"></label> 
               <div class="col-12 qualificationcheck p-0 primary_details" style="display:none">
           <div class="row">
                   <div class="col-md-12 col-sm-6 mb-4"><span class="content"> <label class="xdetails" style="color:#0332AA;background: none;border: 0px;width: 100%;height: 20px;font-weight: bold;font-size: 18px;">ENTER CLASS DETAILS </label></span></div>
               </div>
                   <div class="card primary_details" >
               <div class="course-container add-course px-4"> 
                
                   <div class="row">
                    <div class="col-12 col-sm-6">
                    
				  		<div class="form-group floating">
                      
                    		<select id="yearofpassing" name="yearofpassing" class="form-control yearofpassing qualification_year">
                            <option value="" >Year of Passing</option>
                            <?php 
                            $ret = "";
                              for($i = -5;$i <= 4;$i++)
                              {
                                  
                                  $datetime = date('Y', strtotime($i.' year'));$selected='';
                                   if($qualification1['yearofpassing'] === $datetime){
                                      $selected = 'selected="selected"';
                                  }
                                  
                                  $ret .="<option $selected >".$datetime."</option>";
                              }
                              echo $ret;
                            ?>
                        </select>
                        <label>Year of Passing <span>*</span></label>
                                                 
						</div>
                                                 
					</div>
                    
                   <div class="col-12 col-sm-6">
                    
				  		<div class="form-group floating">
                      
                    		<select id="className" name="status" class="form-control qstatus">
                                <option value="">Select Status</option>                       
                        	</select>
							<label>Result Status <span>*</span></label>
                                                    
                            </div>
					</div>  
                         
                                             
                        <!--</span>-->
                </div>
                <div class="row">
                     <div class="col-12 col-sm-12 primary_rollno" style="display:none">

			<div class="form-group floating">                        
               
                         	
                            <input type="text" name="rollno" placeholder=" " class="form-control rollno" >
			<label> Enter Roll No <span>*</span></label>                        
                          
                	</div>
                
                    </div>                    
                  
                </div>
                
                 <div class="row mb-4">
                    
                     <div class="col-12 col-sm-6 x_gmark" style="display:none">
             			 <div class="form-group">
						   <label>Grace Mark Awarded </label>
						  <div class="d-flex">
                   	
                    	<div class="custom-control custom-radio d-inline-block col-sm-3">
                          <input type="radio" id="gmarkyes" class="chkbox custom-control-input" value="y" name="gmark"> 
                          <label class="custom-control-label" for="gmarkyes">Yes</label>
						</div>
                         
                          <div class="custom-control custom-radio d-inline-block col-sm-3">
                            <input type="radio" id="gmarkno" class="chkbox custom-control-input" value="n" name="gmark"> 
                        	<label class="custom-control-label" for="gmarkno">No</label>
					  	</div>
							 </div>
							
                           </div>
                       </div>
                     <div class="col-12 col-sm-6">
             			 <div class="form-group chkLabel" style="display: none">
                        
                         <div class="custom-control custom-checkbox mb-4">
							<input type="checkbox" class="custom-control-input" <?php  if($qualification['general']['xii_flag'] === '1') { echo 'checked';} ?> id="show_xii" name="xii_flag" class="chkbox xii_flag">
						 </div>
                         
                        
               				 </div>                
                    </div>
		</div>
				
				</div>
	</div>
           </div> 
        <label style="color:#536485;background: none;border: 0px;width: 100%;height: 10px;float:left;"></label> 
        
         <div class="col-12 qualificationcheck p-0 primary_details" style="display:none">            
                       <div class="x_std"style="width: 98%;height: auto;overflow: hidden;">
                           <div class="row">
                   <div class="col-md-12 col-sm-6 mb-4"><span class="content"> <label class="xmark_details" style="color:#0332AA;background: none;border: 0px;width: 100%;height: 20px;font-weight: bold;font-size: 18px;">ENTER CLASS DETAILS </label></span></div>
               </div>
                         <div class="card mb-4">
        <div  style="width:100%;height:auto;margin:0px auto;">
            
            <?php
            $gradeArr1 = explode("|", $qualification1['grade']);
            $markArr1 = explode("|", $qualification1['mark']);
            foreach($qualification['general_x'] as $key=>$val){
                
                $markHTML = ''; $gradeFlag = '0'; $markFlag = '0';

                if(array_key_exists($val['stream'], $gradeX)){
                    $gradeArr = explode("|", $gradeX[$val['stream']]);
                    
                    $markHTML = '<div class="col-12 col-sm-6"><div class="form-group floating"><select name="" class="form-control gradelist" value="GRADE">';
                    for ($i = 0 ; $i <= count($gradeArr);$i++){
                        if($gradeArr[$i] != '') { 
							
							if($i == 0) $markHTML .= '<option value="">Select Grade</option>';
                            $markHTML .= '<option>'.$gradeArr[$i].'</option>';                         
                        }

                    }
                    $markHTML .= "</select><label> Select Grade <span>*</span></label></div></div>"; $gradeFlag='1';

                } else {
                    $markFlag = '1';
                    $markHTML = '<div class="col-12 col-sm-6"><div class="form-group floating"><input class="form-control marklist" name="" type="text"  placeholder=" " ><label> Enter Mark <span>*</span></label></div></div> ';
                }
                 $sarr = explode("|", $val['subject']); $visible = ($val['stream'] === $qualification1['stream'])?'show':'hide';
                 $soarr = explode("|", $val['outofmark']);
                 for ($i = 0 ; $i <= count($sarr);$i++){
                     if($sarr[$i] != '') {
                         
                     if(($val['stream'] === $qualification1['stream']) && ($gradeFlag === '1') && (array_key_exists($i, $gradeArr1)) ){
                         
                         $markHTML = str_replace('<option>'.$gradeArr1[$i].'</option>', '<option selected>'.$gradeArr1[$i].'</option>', $markHTML);
                         $markHTML = str_replace('name=""', 'name="gradelist[]"', $markHTML);
						 $markHTML = str_replace('value="GRADE"', 'value="'.$gradeArr1[$i].'"', $markHTML);
                     }else{
						 $markHTML = str_replace('value="GRADE"', 'value=""', $markHTML);
					 }
                     
                     
                     if(($val['stream'] === $qualification1['stream']) && ($markFlag === '1') && (array_key_exists($i, $markArr1)) ){
                         
                         $markHTML = '<div class="col-12 col-sm-6"><div class="form-group floating"><input class="form-control marklist" name="marklist[]" type="text" placeholder=" " value="'.$markArr1[$i].'"> <label> Enter Mark <span>*</span></label></div></div>';
                            
                     }
                     $outofmarkHTML ="";
                     if($markFlag === "1") { $outofmarkHTML ='<div attr-outofmark = "'.$soarr[$i].'" class="col-12 col-sm-3 outofmark">Out of mark '.$soarr[$i].'</div>'; }
                     
                         echo '<div class="row-element row align-items-center pt-3 '.$visible.'" attr-id="'.$val['id'].'" attr-streams="'.$val['stream'].'">
                        	<div class="col-12 col-sm-3">
                              <label>'.$sarr[$i].'</label>
                             </div>
                              '.$markHTML.$outofmarkHTML.'
                </div>';
                     }
                 }
                
            }
            
            
            ?>
        
    </div>
    </div>
       
			   </div></div>
       
        <label style="background: none;border: 0px;width: 100%;height: 10px;">&nbsp;</label> 
        <div class="show_xii" style="width:100%;height:auto;margin:0px auto;background: none;display: none">
        
                     
         <label style="background: none;border: 0px;width: 100%;height: 10px;">&nbsp;</label> 
         
          <div class="col-12 qualificationcheck p-0">
           
           <div class="card">
           
            <div class="course-container add-course px-4">
               
               <div class="row qualifytop my-4">
               
               <div class="col-12 col-sm-12 mb-4"><span class="content"> <label style="color:#0332AA;background: none;border: 0px;width: 100%;height: 20px;font-weight: bold;font-size: 18px;">ENTER HIGHER SECONDARY DETAILS </label></span></div>
     
               
                 <div class="col-12 col-sm-6">
                    
				  		<div class="form-group floating">     
                                                                          
                             <select  id="xii_selstream" name="xii_stream" class="form-control stream yearofpassing">
                            <option value="" >Select Stream</option>
                             <?php 
                            $ret = "";
                              foreach($qualification['general_xii'] as $key=>$val)
                              {
                                  if($qualification1['xii_stream'] === $val['stream']){
                                      $selected = 'selected="selected" ';
                                  }
                                  $ret .="<option >".$val['stream']."</option>";
                              }
                              echo $ret;
                            ?>
                             </select>
                          
                         <label>Select Stream <span>*</span></label>
                         
						 </div>
					</div>
                
		</div>
                </div>
               </div>
                </div>
            <label style="color:#536485;background: none;border: 0px;width: 100%;height: 20px;"></label> 
               <div class="col-12 qualificationcheck p-0 xii_details" style="display:none">
               <div class="row">
                   <div class="col-md-12 col-sm-6 mb-4"><span class="content"> <label class="xiidetails" style="color:#0332AA;background: none;border: 0px;width: 100%;height: 20px;font-weight: bold;font-size: 18px;">ENTER CLASS DETAILS </label></span></div>
               </div>
                   <div class="card " >
               <div class="course-container add-course px-4"> 
           
                   <div class="row">
                    <div class="col-12 col-sm-6">
                    
				  		<div class="form-group floating">
                      
                    		<select id="yearofpassing" name="xii_yearofpassing" class="form-control yearofpassing xii_year">
                            <option value="" >Year of Passing</option>
                            <?php 
                            $ret = "";
                              for($i = -5;$i <= 4;$i++)
                              {
                                  $datetime = date('Y', strtotime($i.' year'));$selected='';
                                   if($qualification1['xii_yearofpassing'] === $datetime){
                                      $selected = 'selected="selected"';
                                  }
                                  
                                  $ret .="<option $selected >".$datetime."</option>";
                              }
                              echo $ret;
                            ?>
                        </select>
                        <label>Year of Passing <span>*</span></label>
                                                 
						</div>
                                                 
					</div>
                    
                   <div class="col-12 col-sm-6">
                    
				  		<div class="form-group floating">
                      
                    		<select id="className" name="xii_status" class="form-control xii_status">
                                <option value="">Select Status</option>                               
                        	</select>
							<label>Result Status <span>*</span></label>
                                                    
                            </div>
					</div>  
                         
                                             
                        <!--</span>-->
                </div>
                <div class="row">
                     <div class="col-12 col-sm-12 higher_rollno" style="display:none">

			<div class="form-group floating">                        
               
                         	
                            <input type="text" name="xii_rollno" placeholder=" " class="form-control xii_rollno" >
			<label> Enter Roll No <span>*</span></label>                        
                          
                	</div>
                
                    </div>                    
                  
                </div>
                
                 <div class="row mb-4">
                    
                     <div class="col-12 col-sm-6 xii_gmark_parent" style="display:none">
             			 <div class="form-group">
						   <label>Grace Mark Awarded </label>
						  <div class="d-flex">
                   	
                    	<div class="custom-control custom-radio d-inline-block col-sm-3">
                          <input type="radio" id="xii_gmarkyes" class="chkbox custom-control-input" value="y" name="xii_gmark"> 
                          <label class="custom-control-label" for="xii_gmarkyes">Yes</label>
						</div>
                         
                          <div class="custom-control custom-radio d-inline-block col-sm-3">
                            <input type="radio" id="xii_gmarkno" class="chkbox custom-control-input" value="n" name="xii_gmark"> 
                        	<label class="custom-control-label" for="xii_gmarkno">No</label>
					  	</div>
							 </div>
							
                           </div>
                       </div>
		</div>
				
				</div>
	</div>
           </div> 
        <label style="color:#536485;background: none;border: 0px;width: 100%;height: 20px;float:left;"></label> 
         <div class="col-12 qualificationcheck p-0 xii_details" style="display:none">  
             
                       <div class="xii_std" style="width: 98%;height: auto;overflow: hidden">
                           <div class="row">
                   <div class="col-md-12 col-sm-6 mb-4"><span class="content"> <label class="mark_xiidetails" style="color:#0332AA;background: none;border: 0px;width: 100%;height: 20px;font-weight: bold;font-size: 18px;">ENTER CLASS DETAILS </label></span></div>
               </div>
                         <div class="card mb-4">
        <div  style="width:100%;height:auto;margin:0px auto;">
            
           <?php
            
             
            $gradeArr1 = explode("|", $qualification1['xii_grade']);
            $markArr1 = explode("|", $qualification1['xii_mark']);
            foreach($qualification['general_xii'] as $key=>$val){
                
                $markHTML = '';$gradeFlag = '0'; $markFlag = '0';

                if(array_key_exists($val['stream'], $gradeXII)){
                    $gradeArr = explode("|", $gradeXII[$val['stream']]);
                    $markHTML = '<div class="col-12 col-sm-6"><div class="form-group floating"><select name="" class="form-control gradelist" value="GRADE">';
                    for ($i = 0 ; $i <= count($gradeArr);$i++){
                        if($gradeArr[$i] != '') {
							
							if($i == 0) $markHTML .= '<option value="">Select Grade</option>';
							
                            $markHTML .= '<option>'.$gradeArr[$i].'</option>';
                        }

                    }
                    $markHTML .= "</select><label> Select Grade <span>*</span></label></div></div>";$gradeFlag='1';

                } else {
                    $markHTML = '<div class="col-12 col-sm-6"><div class="form-group floating"><input class="form-control marklist" name="" type="text" placeholder=" " ><label> Enter Mark <span>*</span></label></div></div> ';$markFlag = '1';
                }
                 $sarr = explode("|", $val['subject']);$visible = ($val['stream'] === $qualification1['xii_stream'])?'show':'hide';
                 $soarr = explode("|", $val['outofmark']);
                 for ($i = 0 ; $i <= count($sarr);$i++){
                     if($sarr[$i] != '') {
                         
                         if(($val['stream'] === $qualification1['xii_stream']) && ($gradeFlag === '1') && (array_key_exists($i, $gradeArr1)) ){
                         
                         $markHTML = str_replace('<option>'.$gradeArr1[$i].'</option>', '<option selected>'.$gradeArr1[$i].'</option>', $markHTML);
                         $markHTML = str_replace('name=""', 'name="xii_gradelist[]"', $markHTML);
						 $markHTML = str_replace('value="GRADE"', 'value="'.$gradeArr1[$i].'"', $markHTML);
                            
                        }else{
						 	$markHTML = str_replace('value="GRADE"', 'value=""', $markHTML);
						 }
                     
                     
                        if(($val['stream'] === $qualification1['xii_stream']) && ($markFlag === '1') && (array_key_exists($i, $markArr1)) ){
                         
                         $markHTML = '<div class="col-12 col-sm-6"><div class="form-group floating"><input class="form-control marklist" name="xii_marklist[]" type="text"  placeholder=" " value="'.$markArr1[$i].'"><label> Enter Mark <span>*</span></label></div></div> ';
                            
                        }
                        
                        $outofmarkHTML ="";
                        if($markFlag === "1") { $outofmarkHTML ='<div attr-outofmark = "'.$soarr[$i].'" class="col-12 col-sm-3 outofmark">Out of mark '.$soarr[$i].'</div>'; }
                         echo '<div class="row-element row align-items-center pt-3 '.$visible.'" attr-id="'.$val['id'].'" attr-streams="'.$val['stream'].'">
                        	<div class="col-12 col-sm-3">
                              <label>'.$sarr[$i].'</label>
                             </div>
                              '.$markHTML.$outofmarkHTML.'
                		</div>';
                     }
                 }
                
            }
            
            
            ?>
        
    </div>
    </div>
       
			   </div></div>
        </div>
        
        <?php 

			$marksheets = $qualification1['marksheets'];
			$marksheetlist = $refund = "";

			if($marksheets!="" && $marksheets!="0"){

				$marksheetsarr = explode('|',$marksheets);
				$mscount = 0;
				foreach($marksheetsarr as $key=>$marksheet){

					if($key==$mscount) $marksheet = $marksheet;else $marksheet = $marksheet.', ';

					$marksheetlist .= '<div class="file_ms px-2 gallery"> <a href="docs/courserequest/marksheets/'.$sid.'/'.$marksheet.'?'.time().'" target="_blank">'.$marksheet.'</a> &nbsp;&nbsp; <span class="glyph-icon iconsminds-close closeBtn deletemarksheet" data-filename="'.$marksheet.'" title="remove">X</span></div>';
					$mscount++;
				}

			}

		?>
      
      <?php if($qualification['general']['marksheet_flag']=="1"){?>
      
       <div class="row marksheetrow w-100 mx-0">
			<div class="col-md-12 col-sm-6 mb-4">
				<span class="content"> <label class="marksheettext" style="color:#0332AA;background: none;border: 0px;width: 100%;height: 20px;font-weight: bold;font-size: 18px;">UPLOAD MARKSHEETS <?php if($qualification['general']['marksheet_info']!=""){echo "(".$qualification['general']['marksheet_info'].")";}?></label></span>
			</div>
			
		<div class="col-12 mb-4 px-0">	
		
		<div class="card mb-4 p-3">
			
			<div class="row">
						<div class="col-md-12">
						  <div class="form-group position-relative error-l-50 floating">

						<div id="drop-zone">
							<div class="dropzone-wrapper">
							  <div class="dropzone-desc" id="clickHere">
								<i class="icon-upload mb-2"></i>
								<p class="list-item-heading mb-1">Upload Marksheets</p>
								  <p class="text-muted mb-2">Max each file size upto 1MB. File format JPG, JPEG, PNG and PDF only.</p>
							  </div>
							  <input type="file" name="file[]" id="file" class="dropzone" multiple >
							</div>

								<div id='filename'><?php echo $marksheetlist;?></div>
							  </div>
						  </div>
						</div>
					  </div>
			
    	</div>
             
			</div>
              
    </div>
      
      <?php }?>
       
        <?php  
             $exam = $qualification['general']['entrance'];
              $exam_outofmark = $qualification['general']['entrance_outofmark'];
            if($exam !== "") { 
                
                        $ename = $qualification1['entrance_name'];
                        $ename = explode("|",$ename);
                        
                        $exam_outofmark =  explode("|", $exam_outofmark); 
                        
                        $emark = $qualification1['entrance_mark'];
                        $emark = explode("|",$emark);
                        
                        $eregno = $qualification1['entrance_regno'];
                        $eregno = explode("|",$eregno);
                        
                        $examArr = [];$examArr1 = [];
                        foreach($ename as $key => $value){
                            if($value !== "") {
                                $examArr[$value] = $emark[$key];
                                $examArr1[$value] = $eregno[$key];
                            }
                        }
                   
                        echo '<label style="color:#0332AA;background: none;border: 0px;width: 100%;height: 20px;font-weight: bold;font-size: 13px;">PREVIOUS ENTRANCE EXAMS</label>  
                         <label style="background: none;border: 0px;width: 100%;height: 20px;">&nbsp;</label> 
                        <div class="course-container"><div class="row-element entrance_exam">';
                                             
                           
                           $exam = explode("|", $exam); $output =""; $mark = "" ; $regno = "";
                            foreach ($exam as $key => $value) {
                                  if($value !== "") {
                                      $selected = (in_array($value, $ename))?"checked":"";
                                      if($selected === "checked") { $mark = $examArr[$value];$regno = $examArr1[$value];}
                                    $output .= '<div class="content row">
									
									<div class="col-12 col-sm-3 entrancecheck">
             			 				<div class="form-group">
							 
											 <div class="custom-control custom-checkbox">
												<input type="checkbox" id="exam_sel'.$key.'" class="exam_sel custom-control-input" name="exam_sel" '.$selected.'> 
												<label class="custom-control-label" for="exam_sel'.$key.'"><span class="exam_name">'.$value.'</span></label>
											</div>
										
										</div></div>
										
                       			<div class="col-12 col-sm-4 entrancemark1">
             			 		<div class="form-group floating">
								
                              		<input type="text" attr-outofmark="'.$exam_outofmark[$key].'" class="form-control exam_mark" value="'.$mark.'" placeholder=" ">
                              		<label>Mark</label>
							  
							 	</div><label>Out of mark '.$exam_outofmark[$key].'</label></div>
							 
                              <div class="col-12 col-sm-5 entrancemark2">
             			 		<div class="form-group floating">
								
                             <input type="text" class="form-control exam_regno" value="'.$regno.'" placeholder=" "><label>Registration Number</label>
							 
							  </div></div>
							  </div>';
                                  }
                                  $selected = "";$mark="";$regno="";
                            }
                              echo $output."</div></div>";
            } 
        ?>
        <label style="color:#536485;background: none;border: 0px;width: 100%;height: 20px;float:left;">&nbsp;</label>
        
          <div style="margin-top: 0px; width: 98%; height: auto; text-align: right;overflow: hidden">
         <span  style="margin: 0px auto; float:right;margin-top: 18px;padding: 10px; color: #fff; background: #4f6fc4 none repeat scroll 0% 0%; border-radius:5px;cursor: pointer" class="btn savebtn" href="#">Next</span>
         <a style="margin: 0px auto; float:right;margin-top: 18px;margin-right:18px;padding: 9px 10px; color: #0332AA; background: linear-gradient(0deg, #FFFFFF, #FFFFFF), #C4C4C4;border: 1px solid #0332AA; border-radius:5px" class="btn" href="<?php echo base_url(); ?>studentprofile?sid=<?php echo $qualification1['studentid']?>">Back</a>
         <span class="response alert" style="margin: 0px auto; float:right;width: 80%; height: auto;margin-top:20px"></span>
          </div> 
        <input type="hidden" name="cid" value="<?php echo $qualification1['ide'];?>">
        <input type="hidden" class="x_qid" name="x_qid" value="">
        <input type="hidden" class="xii_qid" name="xii_qid" value="">
        <input type="hidden" class="hexam_name" name="hexam_name" value="">
        <input type="hidden" class="hexam_mark" name="hexam_mark" value="">
        <input type="hidden" class="hexam_regno" name="hexam_regno" value="">
        <input type="hidden" class="proll" name="proll" value="">
        <input type="hidden" class="hroll" name="hroll" value="">
        <input type="hidden" class="xout" name="xout" value="">
        <input type="hidden" class="xiiout" name="xiiout" value="">
        <input type="hidden" class="qclass" name="qclass" value="">
        <input type="hidden" class="hclassname" name="hclassname" value="">
        <input type="hidden" class="marksheets" name="marksheets" value="<?php echo $marksheets;?>">
        <input type="hidden" class="marksheet_flag" name="marksheet_flag" value="<?php echo $qualification['general']['marksheet_flag']; ?>">
        <input type="hidden" class="sid" name="sid" value="<?php echo $sid; ?>">
        </div>
          <?php echo form_close() ?>

<script type="text/javascript">
    
	var finalFiles = [];
	
window.addEventListener( "pageshow", function ( event ) {
  var perfEntries = performance.getEntriesByType("navigation");

    if (perfEntries[0].type === "back_forward") {
        location.reload(true);
    }

});
    
    $(document).ready(function() {
        
	 var genData = <?php echo json_encode($qualification['general_x']); ?>;
    
         var genDataXII = <?php echo json_encode($qualification['general_xii']); ?>;
         
         var curGen = <?php echo json_encode($qualification1); ?>;
         
	$("select").change(function(){
		$(this).attr('value',$(this).val());
	});
        
   
    if($("#show_xii").is(":checked")) { $(".show_xii").css("display","block");}
    
    
    $(".exam_sel").click(function(){
		
		if($(this).is(":checked")) {
			$(this).closest('.entrancecheck').parent().find('.entrancemark1,.entrancemark2').removeClass('d-none');
		}else{
			$(this).closest('.entrancecheck').parent().find('.entrancemark1,.entrancemark2').addClass('d-none');
		}
		
	});
		
  
    $('.qstatus').on('change', function() {
        var ty =  $(this).val(); 
        if((ty === "WFR" )||(ty === "C")) { 
            $(".x_std").fadeOut(function(){
                $(this).find(".gradelist").each(function(){
                    $(this).val("");
                });
                
                $(this).find(".marklist").each(function(){
                    $(this).val("");
                });
            });
			
			
        }
        else { 
            $(".x_std").fadeIn();
        }
    });
    
     $('.xii_status').on('change', function() {
        var ty =  $(this).val(); 
        if((ty === "WFR" )||(ty === "C")) {
            $(".xii_std").fadeOut(function(){
                $(this).find(".gradelist").each(function(){
                    $(this).val("");
                });
                
                $(this).find(".marklist").each(function(){
                    $(this).val("");
                });
            });
			
			
            
        } else {
            $(".xii_std").fadeIn();
			
        }
    });
    
    
    $('#selstream').on('change', function() {
        var ty =  $(this).val(); 
               if(ty === "") {  $(".primary_details").css("display","none");$(".qstatus option[value='WFR']").remove();$(".qstatus option[value='C']").remove();}
        $(genData).each(function(index) {

                            var streamArr  = genData[index];
                            if(streamArr.stream === ty){
                                $(".primary_details").css("display","block");
                                $(".xdetails").text("ENTER "+streamArr.class+" DETAILS");
                                $(".xmark_details").text("ENTER "+streamArr.class+" MARK");
                                $(".qclass").val(streamArr.class);
                                        
                                if(streamArr.rollno === "Y") { 
                                    $(".primary_rollno").css("display","block");$(".proll").val("1");
                                    $(".rollno").val(curGen.rollno);
                                }
                                else { 
                                    $(".rollno").val("");$(".primary_rollno").css("display","none");$(".proll").val("0");
                                }
                                
                                if(streamArr.gracemark === "Y") { 
                                    $(".x_gmark").css("display","block");
                                    if(curGen.gracemark === "y") { $("#gmarkyes").attr("checked","checked");} 
                                    if(curGen.gracemark === "n") { $("#gmarkno").attr("checked","checked");}
                                }
                                else { 
                                    $(".x_gmark").css("display","none");
                                    $("#gmarkyes").removeAttr("checked");
                                    $("#gmarkno").removeAttr("checked");
                                }
                                
                                if(streamArr.resultwaiting === "Y") { 
                                    var selected = "";
                                    $(".qstatus option[value='WFR']").remove();
                                    if(curGen.status === 'WFR') { selected = 'selected="selected"'}
                                    $(".qstatus").append('<option '+selected+' value="WFR">Waiting For Result</option>');
                                }else { 
                                    $(".qstatus option[value='WFR']").remove();
                                }
                                
                                if(streamArr.resultcompleted === "Y") { 
                                    var selected = "";
                                    $(".qstatus option[value='C']").remove();
                                    if(curGen.status === 'C') { selected = 'selected="selected"'}
                                    $(".qstatus").append('<option '+selected+' value="C">Completed</option>');
                                }else { 
                                    $(".qstatus option[value='C']").remove();
                                }
                                
                                if(streamArr.resultcompleted === "Y") {
                                    $(".qstatus option[value='P']").remove();
                                } else {
                                    $(".qstatus option[value='P']").remove();
                                    $(".qstatus").append('<option value="P">Passed</option>');
                                }
                                
                                var omark = streamArr.outofmark;
                                const omarkArr= omark.split("|");var oflag = 0;
                                $(omarkArr).each(function(index) {
                                    if(omarkArr[index] === ""){ oflag = 1;}
                                    else {
                                        oflag = 0;return false;
                                    }
                                });
                                
                                $(".xout").val(oflag);
                                
                            }
                        });
    
      
        $(".x_std").find(".row-element").each(function(){
           
           if(ty === $(this).attr("attr-streams")) 
           { $(this).removeClass("hide");$(this).addClass("show");
               $(this).find(".gradelist").attr("name","gradelist[]");
               $(this).find(".marklist").attr("name","marklist[]");
               $(".x_qid").val($(this).attr("attr-id"));
              
              
           
        }
           else
            { $(this).removeClass("show");$(this).addClass("hide");
                 $(this).find(".gradelist").attr("name","");
               $(this).find(".marklist").attr("name","");
            }   
           
        });
    });
    
     $(".marklist").each(function(){
       
       $(this).keyup(function(){
           var otm = $(this).closest(".row-element").find(".outofmark").attr("attr-outofmark");
           var tval = $(this).val();
           if(isNaN(tval)){
            tval = tval.replace(/[^0-9\.]/g,'');
            if(tval.split('.').length>2) 
             tval =tval.replace(/\.+$/,"");
           }
           $(this).val(tval);
           if(parseFloat(tval) > parseFloat(otm)) { alert("Enter value should not greater than the out of mark");$(this).val("0");}
        });
       
    });
    
    $('#xii_selstream').on('change', function() {
        var ty =  $(this).val(); 
         if(ty === "") {  $(".xii_details").css("display","none");$(".xii_status option[value='WFR']").remove();$(".xii_status option[value='C']").remove();}
        $(genDataXII).each(function(index) {

                            var streamArr  = genDataXII[index];
                            if(streamArr.stream === ty){
                                $(".xii_details").css("display","block");
                                 $(".xiidetails").text("ENTER "+streamArr.class+" DETAILS");
                                 $(".mark_xiidetails").text("ENTER "+streamArr.class+" MARK");
                                 $(".hclassname").val(streamArr.class);
                                
                                if(streamArr.rollno === "Y") { 
                                    $(".higher_rollno").css("display","block");
                                    $(".hroll").val("1");
                                    $(".xii_rollno").val(curGen.xii_rollno);
                                }
                                else { 
                                    $(".xii_rollno").val("");
                                    $(".higher_rollno").css("display","none");
                                    $(".hroll").val("0");}
                                
                                if(streamArr.gracemark === "Y") { 
                                    $(".xii_gmark").css("display","block");
                                    if(curGen.xii_gracemark === "y") { $("#xii_gmarkyes").attr("checked","checked");} 
                                    if(curGen.xii_gracemark === "n") { $("#xii_gmarkno").attr("checked","checked");}
                                }
                                else {
                                    $(".xii_gmark").css("display","none");
                                    $("#xii_gmarkyes").removeAttr("checked");
                                    $("#xii_gmarkno").removeAttr("checked");
                                }
                                
                                if(streamArr.resultwaiting === "Y") { 
                                    var selected = "";
                                     $(".xii_status option[value='WFR']").remove();
                                    if(curGen.xii_status === 'WFR') { selected = 'selected="selected"'}
                                    $(".xii_status").append('<option '+selected+' value="WFR">Waiting For Result</option>');
                                }else { 
                                    $(".xii_status option[value='WFR']").remove();
                                }
                                
                                if(streamArr.resultcompleted === "Y") { 
                                     var selected = "";
                                     $(".xii_status option[value='C']").remove();
                                     
                                    if(curGen.xii_status === 'C') { selected = 'selected="selected"'}
                                    $(".xii_status").append('<option value="C">Completed</option>');
                                }else { 
                                    $(".xii_status option[value='C']").remove();
                                }
                                
                                if(streamArr.resultcompleted === "Y") {
                                    $(".xii_status option[value='P']").remove();
                                } else {
                                    $(".xii_status option[value='P']").remove();
                                    $(".xii_status").append('<option value="P">Passed</option>');
                                }
                                
                                var omark = streamArr.outofmark;
                                const omarkArr= omark.split("|");var oflag = 0;
                                $(omarkArr).each(function(index) {
                                    if(omarkArr[index] === ""){ oflag = 1;}
                                    else {
                                        oflag = 0;return false;
                                    }
                                });
                                
                                $(".xiiout").val(oflag);
                            }
                        });
        $(".xii_std").find(".row-element").each(function(){
           
           if(ty === $(this).attr("attr-streams")) 
           { $(this).removeClass("hide");$(this).addClass("show");
               $(this).find(".gradelist").attr("name","xii_gradelist[]");
               $(this).find(".marklist").attr("name","xii_marklist[]");
                $(".xii_qid").val($(this).attr("attr-id"));
               
           }
           else
            { $(this).removeClass("show");$(this).addClass("hide");
              $(this).find(".gradelist").attr("name","");
               $(this).find(".marklist").attr("name","");
            
            }   
           
        });
    });
    
     
    $(".exam_mark").each(function(){
        
         $(this).keyup(function(){
           var otm = $(this).attr("attr-outofmark");
           var tval = $(this).val();
           if(isNaN(tval)){
            tval = tval.replace(/[^0-9\.]/g,'');
            if(tval.split('.').length>2) 
             tval =tval.replace(/\.+$/,"");
           }
           $(this).val(tval);
           if(parseFloat(tval) > parseFloat(otm)) { alert("Enter value should not greater than the out of mark");$(this).val("0");}
        });
        
    });
                         
     $(".savebtn").click(function(){
         
               $(".response").html('').text('Progressing...');
               
               <?php
               if($exam !== "") {
                   
                  ?> 
                  var exam_name ="";
                  var exam_mark ="";
                  var exam_regno ="";
                  $(".entrance_exam").find(".exam_sel").each(function(){
                     
                     if($(this).is(":checked")) {
                         exam_name += "|"+$(this).closest(".content").find(".exam_name").text();
                         exam_mark += "|"+$(this).closest(".content").find(".exam_mark").val();
                         exam_regno += "|"+$(this).closest(".content").find(".exam_regno").val();
                     }
                     
                  });
                  
                  $(".hexam_name").val(exam_name);
                  $(".hexam_mark").val(exam_mark);
                  $(".hexam_regno").val(exam_regno);
                <?php 
                  }               
                ?>
                         
                var qualificationForm = $("#qualificationForm");
		 
		  		var formData = new FormData();

					//for(var i=0;i<formstepid.length;i++){
						var poData = qualificationForm.serializeArray();console.log(poData);
						for (var j=0; j<poData.length; j++){
							formData.append(poData[j].name, poData[j].value);
						}
					//}
		 
					/*var c=0;
					var file_data,file;
					$('input[type="file"]').each(function(){
						  file_data = $('input[type="file"]')[c].files; // get multiple files from input file
						  //console.log(file_data);
					   for(var i = 0;i<file_data.length;i++){
						   formData.append('file[]', file_data[i]); // we can put more than 1 image file
					   }
					  c++;
				   });*/
		 
		 			for(var i = 0;i<finalFiles.length;i++){
						formData.append('file[]', finalFiles[i]); // we can put more than 1 image file
					 }
		 
		 			var approved = "<?php echo $qualification1['approved'];?>";
		 
		 		//qualificationForm.serialize()
		 
                    $.ajax({
                        url: qualificationForm.attr('action'),
                        type: 'post',
                        data: formData,
						contentType: false,
    					processData: false,
                        success: function(o){
                            var response = $.parseJSON(o);
                            $(".response").html('');
                            if(response.status === 'success') {
                                $(".response").css("color","rgb(25, 71, 15)");
                               $(".response").text(response.message);
								
								if(approved=="y"){
									var url = 'studentprofile?sid=<?php echo $qualification1['studentid'];?>';
									$(location).prop('href', url);
								}else{
									var url = 'confirmrequest?id=<?php echo $qualification1['ide'];?>&sid=<?php echo $qualification1['studentid'];?>&qid=<?php echo $qid;?>';
                               		$(location).prop('href', url);
								}
								
                               
                               
                            } else {
                                
                               $(".response").append(response.message); 
                           
                            }

                        }
                    });
                   
                              
            });
    
        $("#selstream").val(curGen.stream).trigger("change");
        $(".qstatus").val(curGen.status).trigger("change");
        
        $("#xii_selstream").val(curGen.xii_stream).trigger("change");
        $(".xii_status").val(curGen.xii_status).trigger("change");
        
     var dropZoneId = "drop-zone";
			var buttonId = "clickHere";
			var mouseOverClass = "mouse-over";
			var dropZone = $("#" + dropZoneId);
			var inputFile = dropZone.find("input");


		  var filecount = 0;
		  inputFile.on('change', function(e) {
			//finalFiles = {};
			//$('#filename').html("");
			var fileNum = this.files.length,
			  initial = 0,
			  counter = 0;

			$.each(this.files,function(idx,elm){
				//idx = initial + idx;
			    //finalFiles[filecount]=elm;
				finalFiles.push(elm);
				filecount++;
			});
			  
			  //console.log(finalFiles);
			  
			for (initial; initial < fileNum; initial++) {
			  counter = filecount - (initial+1);
			  $('#filename').append('<div id="file_'+ counter +'" class="file_ms px-2">' + this.files[initial].name + '&nbsp;&nbsp;<span class="glyph-icon iconsminds-close closeBtn" onclick="removeLine(this)" title="remove">X</span></div>');
			}
			  
		  });
		
		
		// Remove Marksheet
		
		$(".deletemarksheet").click(function(){
			
			var jqObj = $(this);
			
			var qfilename = $(this).data('filename');
			var crid = "<?php echo $qualification1['ide'];?>";
			var sid = "<?php echo $sid;?>";
			
			var r = confirm("Are you sure to delete the file?");
			
			if(r){
			
				$.post("stuqualifyupdate/deleteQMarksheet",{
					'crid':crid,
					'sid':sid,
					'qfilename':qfilename
				},function(o){

					var obj1 = $.parseJSON(o);

					if(obj1[0]=="success"){
						var container = jqObj.closest('div');
					    container.remove(); 
						//alert("Marksheet deleted successfully");
					}else if(obj1[0]=="fail"){
						//alert("Marksheet delete failed");
					}else if(obj1[0]==""){
						//alert("Please try again");
					}

				});
				
			}
			
		});
    
           
   });
	
var dropZoneId = "drop-zone";
var buttonId = "clickHere";
var mouseOverClass = "mouse-over";
var dropZone = $("#" + dropZoneId);
var inputFile = dropZone.find("input");
//var finalFiles = {};
	
$(function() {
	
var ooleft = dropZone.offset().left;
  var ooright = dropZone.outerWidth() + ooleft;
  var ootop = dropZone.offset().top;
  var oobottom = dropZone.outerHeight() + ootop;
 
  document.getElementById(dropZoneId).addEventListener("dragover", function(e) {
    e.preventDefault();
    e.stopPropagation();
    dropZone.addClass(mouseOverClass);
    var x = e.pageX;
    var y = e.pageY;

    if (!(x < ooleft || x > ooright || y < ootop || y > oobottom)) {
      inputFile.offset({
        top: y - 15,
        left: x - 100
      });
    } else {
      inputFile.offset({
        top: -400,
        left: -400
      });
    }

  }, true);

  if (buttonId != "") {
    var clickZone = $("#" + buttonId);

    var oleft = clickZone.offset().left;
    var oright = clickZone.outerWidth() + oleft;
    var otop = clickZone.offset().top;
    var obottom = clickZone.outerHeight() + otop;

    $("#" + buttonId).mousemove(function(e) {
      var x = e.pageX;
      var y = e.pageY;
      if (!(x < oleft || x > oright || y < otop || y > obottom)) {
        inputFile.offset({
          top: y - 15,
          left: x - 160
        });
      } else {
        inputFile.offset({
          top: -400,
          left: -400
        });
      }
    });
  }

  document.getElementById(dropZoneId).addEventListener("drop", function(e) {
    $("#" + dropZoneId).removeClass(mouseOverClass);
  }, true);

});
	
function removeLine(obj)
{
  inputFile.val('');
  var jqObj = $(obj);
  var container = jqObj.closest('div');
  var index = container.attr("id").split('_')[1];
  container.remove(); 

	if (index > -1) {
		finalFiles.splice(index, 1);
	}
	
  //delete finalFiles[index];
  //console.log(finalFiles);
}
    </script>
    
    <script src="<?php echo base_url();?>js/scripts.js?v=1.9"></script>
<script src="<?php echo base_url();?>js/pala.script.js?v=1.96"></script>
    

<script type="text/javascript">
$(document).ready(function(){
	
	
	
});
</script>

<style>
		
.refundrow{font-family: Segoe UI;border-collapse: collapse;margin: auto;font-size: 12px;background: #ffffff;padding: 0rem}
.refund{font-family: Segoe UI;border: 0.75px solid #BCCAE8;border-collapse: collapse;max-width: 100%;margin: auto;font-size: 12px;background: #ffffff;}
.refund th{text-align: left}
.refund th,.refund td{border: 0.75px solid #BCCAE8;padding: 0.6rem 1rem;width: auto}
.refund p span{font-size: 12px;color: #181E29;}
.refund p span:first-child{width: 35%;font-weight: normal;}
.refund p span:last-child{width: 65%;font-weight: bold;}
table.refund tr.lastrow td{padding: 0.7rem 1rem;border: none}
.refund td.totalamt{padding: 0.5rem 1rem;}
.refund td.totalamt strong{margin-left: 3rem;color: #D63333;font-size: 14px;}

.copy{max-width: 100%;margin: auto;color: #181E29;font-size: 12px;font-style: italic;font-family: Segoe UI;font-weight: 600;margin-bottom: 1rem}

.refund td table{font-family: Segoe UI;border: 1px solid #D7DFF0;border-collapse: collapse;width: 100%;margin: 1rem 0 1rem 0rem;border-style: hidden;border-radius: 5px; box-shadow: 0 0 0 1px #D7DFF0;font-size:12px;}

.refund td th{font-weight: 600;color: #536485;background: #E6EBF7;border: 1px solid #D7DFF0;border-width: 0px 0px 1px 0px;text-align: center}
.refund td td{border: 1px solid #D7DFF0;border-width: 0px 0px 1px 0px;text-align: center;width: 50%}

.barcode{margin: 4.5rem auto 1rem;width: 45%}
.upi{margin: auto;display: block}

.refund td table tr:last-child td:first-child {border-bottom-left-radius: 10px;}
.refund td table tr:last-child td:last-child {border-bottom-right-radius: 10px;}

.v-bottom{vertical-align: bottom}
	
.xswidth p,.smwidth p{display: flex;margin: 5px auto}
.xswidth p span:first-child{width: 15%;font-weight: bold;}
.xswidth p span:last-child{width: 85%;font-weight: normal;}
	
.smwidth p span:first-child{width: 25%;font-weight: bold;}
.smwidth p span:last-child{width: 75%;font-weight: normal;}
	
	.refund td table.datetable td{width: 15%;border-width: 0px 0px 1px 1px;}
	.refund td table.datetable th{border-width: 0px 0px 1px 1px;}
	
	.refund td table.feeremit th,.refund td table.feeremit td{width: 20%}
	.refund td table.feeremit td{padding: 0.3rem 1rem;border-width: 0px 0px 1px 1px;}
	.refund td table.feeremit th{border-width: 0px 0px 1px 1px;}
		
</style>


<main>

	<div class="container-fluid">
		
		<div class="col-12 mb-4 myprofile">
                   
			
   <div class="refundrow">

	<table width="100%" border="0" cellspacing="0" cellpadding="0" class="refund">
	  <tbody>
		<tr>
		
			<th scope="col" colspan="2">
		
				<div class="row">
					<div class="col-6">
						<h1>Refund Application</h1>
						<p>Application Number :</p>
					</div>
					<div class="col-6 text-right">
						<img src="css/img/brilliant-logo.png" alt="" />
					</div>
				</div>
		  	
			</th>
			
		</tr>
		<tr>
		  <td style="width: 25%"><strong>Name of the student <br/>(In BLOCK Letters)</strong></td>
		  <td><strong></strong></td>
		</tr>
		<tr>
		  <td><strong>Name of the parent / Guardian</strong></td>
		  <td><strong></strong></td>
		</tr>
		<tr>
		  <td colspan="2">
		  
		  	<div class="row xswidth">
				<div class="col-6">
					<p><span>User ID:</span> <span> </span></p>
					<p><span>Course:</span> <span> </span></p>
				</div>
				<div class="col-6">
					<p><span>Batch:</span> <span> </span></p>
					<p><span>Centre:</span> <span> </span></p>
				</div>
		  	</div>
		  	
		  </td>
		</tr>
		<tr>
		  <td>
		  	<strong>Communication Address with pincode</strong>
		  </td>
		   <td>
		  	 &nbsp;
		  </td>
		</tr>
		<tr>
		  <td><strong>Mob. No.</strong></td>
		  <td>
		  
		  	<div class="row">
				<div class="col-6">
					<p>1.</p>
				</div>
				<div class="col-6">
					<p>2.</p>
				</div>
		  	</div>
		  	
		  </td>
		</tr>
		<tr>
		  <td colspan="2">
		  	<strong>Total Amount Remitted</strong> ------------------------------------ (including GST & CD)
		  </td>
		</tr>
		<tr>
		  <td>
		  	<strong>Date of submission of application for refund</strong>
		  </td>
		  <td>
			  <table style="width:100%" class="datetable">
			  <tr>
				<th colspan="2">Date</th>
				<th colspan="2">Month</th>
				<th>Year</th>
			  </tr>
			  <tr>
				<td>0</td>
				<td>1</td>
				
				<td>1</td>
				<td>2</td>
				
				<td>1998</td>
				
			  </tr>
			</table>
		  </td>
		</tr>
		<tr valign="top">
			<td colspan="2">
				<p><strong>Reason for discountinue/scholarship:-</strong></p>
				<p></p>
			</td>
		</tr>
		<tr valign="top">
			<td colspan="2" class="smwidth">
				<h3><strong><u>Account Details</u></strong></h3>
				<p><span>Account Holder Name:</span> <span>Test</span></p>
				<p><span>Bank Name:</span> <span>SIB</span></p>
				<p><span>Branch:</span> <span>Arunapuram</span></p>
				<p><span>IFSC:</span> <span>SIBL0000453</span></p>
				<p><span>Account No.:</span> <span>00034141412334123</span></p>
			</td>
		</tr>
		
		
		<tr>
		  <td colspan="2">
			  <h2 class="text-center my-3"><strong>FOR OFFICE USE ONLY</strong></h2>
			  <p class="my-3">Date of receipt of refund application ......................................................... Signature of Officer in Charge ......................................................... </p>
		  </td>
		</tr>
	  
	  	<tr valign="top">
		  <td style="width: 50%	">
			 
			 <div class="row">
				<div class="col-9">
					<p><strong>No. of Class days/periods upto the date of submission of refund application</strong></p>
				</div>
				<div class="col-3">
					<p class="border h-75 w-100 mt-2"></p>
				</div>
		  	</div>
		  	
			  <div class="border-bottom my-3"></div>
		  	
			  <h4 class="text-center my-2"><strong>Fee Remitted</strong></h4>
			  
			  <table width="100%" border="0" cellspacing="0" cellpadding="0" class="feeremit">
			  <tbody>
				<tr>
				  <th scope="col" width="20%">Rt. No.</th>
				  <th scope="col" width="20%">Date</th>
				  <th scope="col" width="20%">Amount</th>
				  <th scope="col" width="20%">GST</th>
				  <th scope="col" width="20%">Total</th>
				</tr>
				<tr>
				  <td>&nbsp;</td>
				  <td>&nbsp;</td>
				  <td>&nbsp;</td>
				  <td>&nbsp;</td>
				  <td>&nbsp;</td>
				</tr>
				<tr>
				  <td>&nbsp;</td>
				  <td>&nbsp;</td>
				  <td>&nbsp;</td>
				  <td>&nbsp;</td>
				  <td>&nbsp;</td>
				</tr>
				<tr>
				  <td>&nbsp;</td>
				  <td>&nbsp;</td>
				  <td>&nbsp;</td>
				  <td>&nbsp;</td>
				  <td>&nbsp;</td>
				</tr>
				<tr>
				  <td>&nbsp;</td>
				  <td>&nbsp;</td>
				  <td>&nbsp;</td>
				  <td>&nbsp;</td>
				  <td>&nbsp;</td>
				</tr>
				<tr>
				  <td>CD</td>
				  <td>&nbsp;</td>
				  <td>&nbsp;</td>
				  <td>&nbsp;</td>
				  <td>&nbsp;</td>
				</tr>
				<tr>
				  <td>Grand Total</td>
				  <td>&nbsp;</td>
				  <td>&nbsp;</td>
				  <td>&nbsp;</td>
				  <td>&nbsp;</td>
				</tr>
				<tr>
				  <td>&nbsp;</td>
				  <td>&nbsp;</td>
				  <td>&nbsp;</td>
				  <td>&nbsp;</td>
				  <td>&nbsp;</td>
				</tr>
			  </tbody>
			</table>
		  	
		  	<div class="row mt-4 mb-5">
				<div class="col-7">
					<p><strong>Entered by</strong></p>
				</div>
				<div class="col-5">
					<p><strong>Checked by</strong></p>
				</div>
		  	</div>

		  	
		  </td>
		  
		  <td>
		  
			  <h4 class="text-center my-2"><strong>Refund Amount</strong></h4>
			  
			  <div class="row">
				<div class="col-6">
				
					<p class="text-center"><strong>Deductions</strong></p>
					
					<table width="100%" border="0" cellspacing="0" cellpadding="0">
					  <tbody>
						<tr>
						  <th scope="row">Course Fee + GST</th>
						  <td>&nbsp;</td>
						</tr>
						<tr>
						  <th scope="row">Any other
					Deduction</th>
						  <td>&nbsp;</td>
						</tr>
						<tr>
						  <th scope="row">Total
					Deduction</th>
						  <td>&nbsp;</td>
						</tr>
					  </tbody>
					</table>

				</div>
				<div class="col-6">
				
					<p class="text-center"><strong>Balance Amount</strong></p>
					
					<table width="100%" border="0" cellspacing="0" cellpadding="0">
					  <tbody>
						<tr>
						  <th scope="row">Fee</th>
						  <td>&nbsp;</td>
						</tr>
						<tr>
						  <th scope="row">GST</th>
						  <td>&nbsp;</td>
						</tr>
						<tr>
						  <th scope="row">CD</th>
						  <td>&nbsp;</td>
						</tr>
						<tr>
						  <th scope="row">Total</th>
						  <td>&nbsp;</td>
						</tr>
					  </tbody>
					</table>
					
				</div>
		  	</div>
		  	
		  	
			  <div style="height: 50px"></div>
		  	
			  <p>Rs.............................................................................................................................................................. ................................................................................................................... only</p>
		  	
		  	<div class="row mt-3 mb-5">
				<div class="col-7">
					<p><strong>Calculated by</strong></p>
				</div>
				<div class="col-5">
					<p><strong>Verified by</strong></p>
				</div>
		  	</div>
		  	
			 
		  </td>
		  
		</tr>
		
		
	  </tbody>
	</table>
	

</div>
                	
		
	</div>


	</div>
</main>
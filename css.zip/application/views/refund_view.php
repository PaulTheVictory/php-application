<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/dataTables.css?v=1.5" />
<script src="<?php echo base_url(); ?>js/jquery.dataTables.js?v=1.0" type="text/javascript"></script>
<link rel="stylesheet" href="<?php echo base_url();?>css/boot/bootstrap.min.css">
<link rel="stylesheet" href="<?php echo base_url();?>css/boot/main.css?v=1">
<script src="<?php echo base_url();?>js/bootstrap.bundle.min.js"></script>
<link href="<?php  echo base_url(); ?>css/jquery-ui.min.css?v=1.4" rel="stylesheet" type="text/css" />
 <script src="<?php  echo base_url(); ?>js/jquery-ui.min.js?v=1.3" type="text/javascript"></script>
  <link href="<?php  echo base_url(); ?>css/chosen.min.css?v=1.3" rel="stylesheet" type="text/css" />
  <script src="<?php  echo base_url(); ?>js/chosen.jquery.min.js?v=1.2" type="text/javascript"></script>
<style type="text/css">


.dataTables_wrapper input[type="text"] {
    padding: 0;
}
.dataTables_wrapper select {
    padding: 0;
}

.sortable thead tr  {
    background: #E6EBF7;

/* g8 */
border: 1px solid #D7DFF0;
box-sizing: border-box;
border-radius: 10px 10px 0px 0px;
 
}


.sortable tr th {
    border-right: 0px;
    padding: 15px 0;font-size: 13px;
      color: #6F83AA;
   cursor: pointer;
   text-align: center;

}

.dataTables_info { display: none; }
#addpaymenttable_paginate { display: none;}
#addpaymenttable_filter input {display:none;}

.sortable tr td {
    border-right: 0px;
    padding: 5px 5px;
    text-align: center;font-size: 13px;
    min-width:50px;vertical-align: middle;
}
.sortable tr td a {
    color: #364159;
}

#profile-right h2 {
    margin: 0px 0px 10px 0px;
}
#paymentlist_filter input { padding-top:4px;background: #fff url('<?php echo base_url(); ?>/images/search.png') no-repeat center left;background-position-x: 10px;border: 1px solid #D7DFF0; line-height: 32px;margin-left: 10px;width:260px;border-radius: 5px;text-indent: 30px;font-size: 13px;}

.sortable tr td a:hover { text-decoration: underline; }
.dataTables_filter { right:10px !important;}
	.dataTables_processing{height: auto}
	
	.sortable tr th:nth-child(1),.sortable tr th:nth-child(2),.sortable tr th:nth-child(3),.sortable tr th:nth-child(7),.sortable tr th:nth-child(9) {background: #E6EBF7 url(https://admissions.brilliantpala.org//images/datatable/sort_both.png) no-repeat center left;background-position: right;text-align: center;}
	
	.btn-outline-primary {color: #0332AA;border-color: #0332AA;}
.btn {border-radius: 5px;outline: initial!important;box-shadow: none!important;box-shadow: initial!important;font-size: .8rem;padding: .5rem 1.25rem .5rem 1.25rem;transition: background-color box-shadow .1s linear;margin-bottom: 7px}
.btn-outline-primary:not(:disabled):not(.disabled).active, .btn-outline-primary:not(:disabled):not(.disabled):active, .show>.btn-outline-primary.dropdown-toggle,.btn-outline-primary:hover {background-color: #0332AA;border-color: #0332AA;color: #fff;}	
	
.ui-selectmenu-button.ui-button{ width: 125px;margin-top: 10px;float: right;border: 1px solid #D7DFF0;background: #fff;font-size: 13px;color:#536485;padding: 8px;margin-bottom: 4px;}
.ui-menu-item .ui-menu-item-wrapper{font-size: 13px}
	
</style>
<script type="text/javascript">
$(document).ready(function(){	
	
        $("#searchtype").selectmenu();
         $("#examtype").chosen();
        
	 $("#edate").datetimepicker({
            dateFormat: "yy-mm-dd"
         });
    
	$(document).on("click",".clear",function(){
		
		$("#searchtype").selectmenu('destroy');
	    $("#searchtype").prop('selectedIndex',0);
	    $("#searchtype").selectmenu();
		
	});
	
        var oTable2 = "";
	var oTable = $('#paymentlist').DataTable({
            "processing": true,
            "serverSide": true,
            "sPaginationType": "full_numbers",
            "ajax":{
		     "url": "<?php echo base_url('refund/refundList') ?>",
		     "dataType": "json",
		     "type": "POST",
				"data":function(data){ 
						
						var searchtype = $("#searchtype").val();
						data.searchcol= searchtype;
						
						}
		     //"data":{  '<?php //echo $this->security->get_csrf_token_name(); ?>' : '<?php //echo $this->security->get_csrf_hash(); ?>' }
					}, 
				 "oLanguage": {
					"sProcessing": "<img src='<?php echo base_url(); ?>images/loader.gif'>"
				},
		'iDisplayLength': 20,
	    "columns": [
		          { "data": "appno" },
		          { "data": "studid" },
		          { "data": "sname" },
		          { "data": "cname" },
		          { "data": "center" },
                          { "data": "type" },
                          { "data": "requestedrefundamt" },
                          { "data": "status" },
                          { "data": "print" },
		          { "data": "actions" }
		       ],
		"order": [[ 0, "desc" ]],
                 "fnDrawCallback": function( oSettings ) {
                     
                      $('#paymentlist').find(".rstatus").each(function(){
                            
                                $(this).click(function(){
                                    
                                    var ide = $(this).attr("data-id");
                                    var cride = $(this).attr("data-cride");
                                    var shtml =$("<select><option value=''>Select Status</option><option value='w'>Waiting list</option><option value='p'>Progress</option><option value='n'>Not Eligible</option><option value='cd'>Cancelled</option></select>");
                                    $(this).closest("td").append(shtml);
                                    $(this).remove();
                                    $(shtml).change(function(){
                                        var stats=$(shtml).val();
                                       $(".paycancel2").click(function(){
                                           $(shtml).val("");oTable.draw();
                                       });
                                        if(stats === "n" ||stats === "cd") {     
                                            $(".courseconfirm2").trigger('click');
                                        } else{
                                            $("#refundremarks").val("");
                                            StatusChange(ide,cride,stats);
                                        }
                                       $(".remarkssave").click(function(){
                                           
                                          StatusChange(ide,cride,stats);
                                           
                                       });
                                       
                                    });

                                });
        
                          });
                          
                          function StatusChange(ide,cride,stats){
                          
                          
                                           var remarks = $("#refundremarks").val();
                                            if(stats === "n" ||stats === "cd") {
                                                if(remarks ==="") { alert("Kindly enter the remarks"); return;}
                                             }
                                           

                                                $.get('refund/ChangeStatus',{
                                                                        'ide':ide,'status':stats,'cride':cride,'remarks':remarks

                                                             }, function(o) { 
                                                                     var obj1 = $.parseJSON(o);
                                                             if (obj1[0] === 'success') {
                                                                 oTable.draw(); $("#refundremarks").val("");
                                                                 $(".paycancel2").trigger("click");
                                                             } else if (obj1[0] === 'fail') {
                                                                 alert("Error!!! please try again");
                                                         }
                                             });

                          
                          }
                     $("#paymentlist").find(".addrefund").each(function(){

                            $(this).click(function(){ 

                               $(".courseconfirm").trigger('click'); 
                                var center = $(this).attr("data-center");
                                var sid = $(this).attr("data-sid");
                                var cid = $(this).attr("data-cid");
                                var id = $(this).attr("data-id");
                                var crid = $(this).attr("data-cride");
                                var refund = $(this).attr("data-refund");
                                
                                $(".studname").text($(this).attr("data-student"));
                                $(".studno").text($(this).attr("data-studid"));
                    
                                $(".rramt").text(refund);
                                $(".paysave").attr("data-center",center);
                                $(".paysave").attr("data-sid",sid);
                                $(".paysave").attr("data-cid",cid);
                                $(".paysave").attr("data-id",id);
                                 $(".paysave").attr("data-cride",crid);
                                
                                getRefundPayments(sid,cid,center); 

                              });
                        

                          });
                          
                          
                           $('#paymentlist').find(".printrefund").each(function(){
                                $(this).click(function(){
                                   
                                    var type = $(this).attr("data-type");
                                    var ide = $(this).attr("data-id");
                                    var status = $(this).attr("data-status");
                                    if( ((type === "Discounts/Scholarship") || (type === "Course Change")) && (status === "w") ){
                                         $("#bankname").val($(this).attr("data-bankname"));
                                         $("#branch").val($(this).attr("data-branch"));
                                         $("#ifsccode").val($(this).attr("data-ifsccode"));
                                         $("#bankaccountno").val($(this).attr("data-bankaccountno"));
                                         $("#rebankaccountno").val($(this).attr("data-bankaccountno"));
                                         $(".banksave").attr("data-id",ide);
                                         $(".courseconfirm3").trigger('click');
                                    }else{
                                        var href = 'refund?print='+ide;
                                        window.open(href,"_blank");
                                    }
                                 });
                           });   
                          
                          
                           $("#paymentlist").find(".refundview").each(function(){

                            $(this).click(function(){ 

                               $(".courseconfirm1").trigger('click'); 
                                var center = $(this).attr("data-center");
                                var sid = $(this).attr("data-sid");
                                var cid = $(this).attr("data-cid");
                                var id = $(this).attr("data-id");
                                var crid = $(this).attr("data-cride");
                    
                                viewRefundPayments(id,sid); 

                              });
                        

                          });
                 },
		"initComplete" : function() {
						
						var input = $('.dataTables_filter input').unbind(),
							self = this.api(),
							$searchButton = $('<button class="btn btn-outline-primary ml-3 search">')
									   .text('search')
									   .click(function() {
										  self.search(input.val()).draw();
									   }),
							$clearButton = $('<button class="btn btn-outline-primary ml-3 clear">')
									   .text('clear')
									   .click(function() {
										  input.val('');
										  $searchButton.click(); 
									   });
						$('.dataTables_filter').append($searchButton, $clearButton);
                                                
                                                  $(input).keyup(function(event){
                                                    if(event.keyCode == 13){
                                                        event.preventDefault();
                                                        $('.search').trigger('click');
                                                    }
                                                });
					}

	    });
            
            function getRefundPayments(sid,cid,center) {
  
  var columnData2 = [
                    { "data": "desc_order" },
                    { "data": "description" },
                    { "data": "amount" },
                    { "data": "paid" },
                    { "data": "sac" },
                    { "data": "ide" },
                    { "data": "tax" },
                    { "data": "requestid" },
                    
                  ];
   oTable2 = $('#addpaymenttable').dataTable({
                    "bProcessing": true,
                    "bServerSide": true,
                    "sPaginationType": "full_numbers",
                    "ajax": {
                    "url": 'refund/getRefundPaymentLists',
                    "type": "POST",
                    "data":{ "sid": sid,"cid": cid,"center": center }
                     }, 
                     "oLanguage": {
                        "sProcessing": "<img src='<?php echo base_url(); ?>images/loader.gif'>"
                    },
                    'iDisplayLength': 20,
                    "columns": columnData2,
                    "order": [[ 0, "asc" ]],
                    "fnDrawCallback": function( oSettings ) {
                        var refund = 0;       var total = 0;        
                        $(".prefund").text(refund);
                        $('#addpaymenttable').find("tr .paid").each(function(){
                            
                            total = total+parseFloat($(this).text());
        
                          });
                          
                           $('#addpaymenttable').find("tr .refundamt").each(function(){
                            
                                $(this).keyup(function(){
                                    
                                   refundCalculate(this,$('#addpaymenttable'));
                                     
                                });
                                
                                refundCalculate(this,$('#addpaymenttable'));
                                        
                          });
                          
                         $(".paymode").val("");$(".paymode").trigger("change");
                          
                       $(".premit").text(total);    
                       // 
                                      
                    }
         }); 
         }
         
         $(".paycancel").click(function(){
            $("#reason").val("");$("#paymode").val("");
            $("#prefno").closest(".col-12").css("display","none");
            oTable2.fnDestroy();$(".paysave").removeClass("progressing");
         });
         
         
         
           $(".paymode").change(function(){
                $("#pcenters").val('');$("#cperson").val('');$("#prefno").val('');
                 var type = $(this).val();
                 if(type === "dd"){

                     $("#prefno").closest(".col-12").css("display","block");
                     $("#prefno").siblings("label").text("DD Number");
               
                 } else if(type === "net"){

                     $("#prefno").closest(".col-12").css("display","block");
                     $("#prefno").siblings("label").text("Transaction ID");

                 } else if(type === "cheque"){

                     var ltext = "Cheque Number";

                     $("#prefno").closest(".col-12").css("display","block");
                     $("#prefno").siblings("label").text(ltext);

                 }else if(type === "cash"){

                     $("#prefno").closest(".col-12").css("display","block");
                     $("#prefno").siblings("label").text("Date");
     
                 }
            });
    
          
     $(".paysave").click(function(){
        
        if($(this).hasClass("progressing")) { return;}
       $(this).text("Processing...");
       $(this).addClass("progressing");
       var sid = $(this).attr("data-sid");
       var cid = $(this).attr("data-cid");
       var refundid = $(this).attr("data-id");
       var center = $(this).attr("data-center");    
        var rid = $(this).attr("data-cride");    
       var reason = $("#reason").val();
       var refundremarks = $("#addrefremarks").val();
       
       if(reason === '') { alert("Reason should be Given");$(this).removeClass("progressing");$(this).text("Save");return;}
       
       var paymode = $("#paymode").val();
       if(paymode === '') { alert("Payment Mode should be Given");$(this).text("Save");return;}
       
       //if($("#prefno").val() === "") { alert("Reference no is mandatory");$(this).removeClass("progressing");$(this).text("Confirm Refund");return;}
       var paydescription = $("#prefno").val();
       var paydate = '';
       
       var stupayid=""; var amount=""; var remit=""; var refund = '';var gstrefund=""; var refundtotal = '';
        $('#addpaymenttable').find("tr .desc").each(function(){
                            
               stupayid += $(this).attr("attr-descid")+"|";
               amount   += $(this).closest("tr").find(".amount").text()+"|";
               remit    += $(this).closest("tr").find(".paid").text()+"|";
               refund   += $(this).closest("tr").find(".refundnet").text()+"|";
               gstrefund   += $(this).closest("tr").find(".gstrefund").text()+"|";
               refundtotal   += $(this).closest("tr").find(".refundtotal").text()+"|";
        });
       
       
        $.get('refund/addRefund',{'remarks':refundremarks,
                 'paymode':paymode,'pdescription':paydescription,'reason':reason,"ide": cid,"paydate": paydate
                        ,"studid":sid,"refundid":refundid,"center":center,'stupayid':stupayid,'amount':amount,'remit':remit,'refund':refund,'gstrefund':gstrefund,'refundtotal':refundtotal,"rid":rid

                 }, function(o) { 
                         var obj1 = $.parseJSON(o);
                if (obj1[0] === 'success') {
                     $(".paysave").text("Save");
                      $('#courseModal').modal('hide');
                     $('#paydoneModal').modal({show:true});
                     $(".paysave").text("Save");
                      $(".paysave").removeClass("progressing"); $(".prefund").text("0");
                      $(".premit").text("0");
                      oTable.draw();oTable2.fnDestroy();
                      

                 } else if (obj1[0] === 'fail') { $(this).text("Save");

             }
        });
        
       
       
    });
    
       $(".refundprint").click(function(){
           var refundid = $("#refundid").val();
           var link = 'refund/refundprint?ide='+refundid;
           window.open(link);
            
       });
	
        function refundCalculate(obj,tableEle){
            
            
            var remit =  $(obj).val();
             var trpaid =$(obj).closest("tr").find(".paid").text();
             var refundnet = parseFloat(trpaid)-parseFloat(remit);
             if(refundnet < 0) { 
                 alert("Refund amount should be lesser than the remitted amount");
                 $(obj).val("0");$(obj).trigger("keyup");return;
             }

             var tax =0.18;
             var gstrefund   = parseFloat(refundnet)*parseFloat(tax);
             gstrefund       = Number(gstrefund).toFixed(2);
             
             var cgst=  Math.round(parseFloat(gstrefund)/2);
             var sgst=  Math.round(parseFloat(gstrefund)/2);
             var refundtotal = parseFloat(refundnet)+parseFloat(cgst)+parseFloat(sgst);
             refundtotal = Math.round(refundtotal);

             $(obj).closest("tr").find(".refundnet").text(refundnet);
             $(obj).closest("tr").find(".gstrefund").text(gstrefund);
             $(obj).closest("tr").find(".refundtotal").text(refundtotal);
             
             var ramt=0;
             $(tableEle).find("tr .refundtotal").each(function(){ 
                var yu  = $(this).text();
                yu = (yu === "")?0:yu;
                ramt = ramt + parseFloat(yu);
             });
             
             $(".prefund").text(ramt);
            
        }
        
         
         function viewRefundPayments(id,sid) {
             
             $.get('refund/viewRefundPaymnets',{
                 'id':id

                 }, function(o) { 
                         var obj1 = $.parseJSON(o);
                if (obj1[0] === 'success') {
                     
                    $("#refundItems").html(obj1[1]);
                     
                    $(".studname").text($('#refundItems').find(".refundContainer").attr("data-student"));
                    $(".studno").text($('#refundItems').find(".refundContainer").attr("data-studid"));
                     
                    $('#refundItems').find(".reportsTable").find("tr .refundamt").each(function(){
                            
                                $(this).keyup(function(){
                                    
                                   refundCalculate(this,$('#refundItems').find(".reportsTable"));
                                     
                                });
                                
                                refundCalculate(this,$('#refundItems').find(".reportsTable"));
                                        
                          });
                          
                         var stat =  $("#refundItems").find(".prefund").attr("data-status");
                         $(".editsave").attr("data-sid",sid);
                         if(stat ==="n" || stat ==="cd")
                         {
                             $(".editsave").addClass("d-none");
                             $(".refundprint").addClass("d-none");
                         }else if(stat ==="cf")
                         {
                             $(".editsave").addClass("d-none");
                             $(".confirmsave").addClass("d-none");
                             $(".refundprint").removeClass("d-none");
                         }else if(stat ==="c")
                         {
                             $(".editsave").removeClass("d-none");
                             $(".confirmsave").removeClass("d-none");
                             $(".refundprint").removeClass("d-none");
                         }else{
                              $(".editsave").removeClass("d-none");
                              $(".refundprint").removeClass("d-none");
                         }
                     
                     
                 } else if (obj1[0] === 'fail') {

             }
        });
  
  
         }
         
          <?php //if(isset($roleaccess['Refund Edit'][3]) && $roleaccess['Refund Edit'][3]=="y"){ ?>
        $(".editsave").click(function(){
            if($(this).hasClass("progressing")) { return;}
            $(this).text("Progressing...");
            $(this).addClass("progressing");
            editRefund(this,"c");
       
        });
    
     $(".confirmsave").click(function(){
           if($(this).hasClass("progressing")) { return;}
           $(this).text("Progressing...");
           $(this).addClass("progressing");
           var paymode = $("#editpaymode").val();
       
       if(($("#editprefno").val() === "")&&(paymode !== "cash")) { 
           alert("Reference no is mandatory");
           $(this).removeClass("progressing");
           $(this).text("Confirm Refund");
           return;}
       
       editRefund(this,"cf");
       
    });
    
    
    editRefund = (obj,status)=>{
                 
       var refundid = $("#refundid").val();
       var reason = $("#editreason").val();
       
       if(reason === '') { alert("Reason should be Given");$(obj).removeClass("progressing");return;}
              
       var paydescription = $("#editprefno").val();
       var paydate = $("#editprefnodate").val();
       var paycheque = $("#editchequeno").val();
       var paymode = $("#editpaymode").val();
       var sid = $(".editsave").attr("data-sid");
       
       var stupayid=""; var amount=""; var remit=""; var refund = '';var gstrefund=""; var refundtotal = '';
        $('#refundItems').find(".reportsTable").find("tr .desc").each(function(){
                            
               stupayid += $(this).attr("attr-descid")+"|";
               amount   += $(this).closest("tr").find(".amount").text()+"|";
               remit    += $(this).closest("tr").find(".paid").text()+"|";
               refund   += $(this).closest("tr").find(".refundnet").text()+"|";
               gstrefund   += $(this).closest("tr").find(".gstrefund").text()+"|";
               refundtotal   += $(this).closest("tr").find(".refundtotal").text()+"|";
        });
       
       
        $.get('refund/editRefund',{'sid':sid,
                 'status':status,'refundid':refundid,'paymode':paymode,'pdescription':paydescription,'paydate':paydate,'paycheque':paycheque,'reason':reason,"stupayid":stupayid,'amount':amount,'remit':remit,'refund':refund,'gstrefund':gstrefund,'refundtotal':refundtotal

                 }, function(o) { 
                         var obj1 = $.parseJSON(o);
                if (obj1[0] === 'success') {
                     
                      $('#courseModal1').modal('hide');
                     $('#paydoneModal').modal({show:true});
                     if(status === "c"){
                         $(obj).text("Save");                         
                     }else {
                         $(obj).text("Confirm Refund"); 
                     }
                     
                      $(obj).removeClass("progressing");
                      $(".prefund").text("0");
                      $(".premit").text("0");
                      oTable.draw();oTable2.fnDestroy();
                      

                 } else if (obj1[0] === 'fail') {

             }
        });
        
    };
    
    $(".banksave").click(function(){
        
        if($(this).hasClass("progressing")){ return;}
        
        $(this).addClass("progressing");
        $(this).text("Progressing...");
         var ide        = $(this).attr("data-id");
         var bankname        = $("#bankname").val();
         var branch          =   $("#branch").val();
         var ifsccode        =   $("#ifsccode").val();
         var bankaccountno   = $("#bankaccountno").val();
         var rebankaccountno =  $("#rebankaccountno").val();
         if(bankaccountno !== rebankaccountno) { alert("Account Number Mismatch");$(".banksave").text("Confirm and Print");$(".banksave").removeClass("progressing"); return;}
         
          $.get('refund/addBankDetails',{
                 'ide':ide,'bankname':bankname,'branch':branch,"ifsccode": ifsccode,"bankaccountno": bankaccountno

                 }, function(o) { 
                         var obj1 = $.parseJSON(o);
                if (obj1[0] === 'success') {
                   
                     $('#courseModal3').modal('hide');
                     $(".banksave").text("Confirm and Print");
                     $(".banksave").removeClass("progressing"); 
                     oTable.draw();
                     var href = 'refund?print='+ide;
                     location.href= href;
             
                 } else if (obj1[0] === 'fail') { $(".banksave").text("Confirm and Print");$(".banksave").removeClass("progressing"); }
        });
        
    });
    
     <?php // } ?>
	        
});
</script>


<div class="wrap dynamic-width" style="float: left;position: relative">
          
<div style="margin-top: 10px; width: 100%; height: 50px; text-align: right;">
	<span style="font-weight: bold;font-size: 20px;padding: 10px;float:left;color: #364159">Refund Application</span>
</div>
                 
<style>

	.courseredirect{background: #3CAF92 !important;display: block;margin: auto;border: 1px solid #209679;}
	h5.modal-title p.headtitle{display: inline-block;width: 100%;text-align: center;font-weight: bold;font-size:17px;color: #fff;}
	h5.modal-title p.text-muted{display: inline-block;width: 100%;text-align: center;font-weight: 600;font-size: 14px;line-height: 36px;color: #181E29;line-height: 20px;}
	.modal-title img{display: block;margin: 1em auto}
	#paydoneModal.modal .modal-header,#payfailModal.modal .modal-header{padding: 10px 20px !important;border: none}	
	#paydoneModal.modal .modal-body,#payfailModal.modal .modal-body{padding:0 1.75rem 1.75rem}
	.modal-body p{text-align: left !important}
	.modal-backdrop.show {opacity: .5 !important;}
	

	.alert{font-size: 14px;}
	.maincontent p.alert-success {color: #155724;}
	.maincontent p.alert-danger {color: #721c24;}
        
        
	
</style>

<div class="row align-items-end">
 
                 <div class="col-7">
                     <select id="searchtype">
                         <option value="stuid">Student ID</option>
                         <option value="stuname">Student Name</option>
                         <option value="coursename">Course Name</option>
                         <option value="center">Center</option>
                         <option value="appno">App No</option>
                     </select>
                 </div>                                                                           
    		</div> 
<div class="row">
	<div class="col-md-12">
               <table class="sortable disabled table table-bordered" id="paymentlist">
                    <thead>
                           <th>APP.NO</th>
                           <th>STUDENT ID</th>
                           <th>STUDENT NAME</th>
                           <th>COURSE NAME</th>
                           <th>CENTER</th>
                           <th>TYPE</th>
                           <th>REQ REFUND AMOUNT</th>
                           <th>STATUS</th>
                           <th>PRINT</th>
                           <th>ACTIONS</th>                           
                    </thead>				
               </table>
        </div>
</div>


</div>  


	   <style>

	.courseredirect{background: #3CAF92 !important;display: block;margin: auto;border: 1px solid #209679;}
	h5.modal-title p.headtitle{display: inline-block;width: 100%;text-align: center;font-weight: bold;font-size:17px;color: #fff;}
	h5.modal-title p.text-muted{display: inline-block;width: 100%;text-align: center;font-weight: 600;font-size: 14px;line-height: 36px;color: #181E29;line-height: 20px;}
	.modal-title img{display: block;margin: 1em auto}
        #paydoneModal.modal .modal-header,#payfailModal.modal .modal-header{padding: 10px 20px !important;border: none}	
		#paydoneModal.modal .modal-body,#payfailModal.modal .modal-body{padding:0 1.75rem 1.75rem}
		.modal-body p{text-align: left !important}
		.modal-backdrop.show {opacity: .5 !important;}
	</style>
	
	
<?php if(isset($roleaccess['Refund Add'][3]) && $roleaccess['Refund Add'][3]=="y"){ ?>
	
<button type="button" class="btn btn-outline-primary d-none courseconfirm" data-toggle="modal" data-backdrop="static" data-target="#courseModal">Confirm Submission</button>  
<!-- Modal -->


<div class="modal fade" id="courseModal" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog modal-xl" role="document">
	<div class="modal-content">
            <div class="modal-header" style="background-color: #6884CC;height: 50px;width: auto;padding: 10px">
	  
		<h5 class="modal-title w-100" id="exampleModalLabel">
		
			<div class="row">
			
				<div class="col-4">
					<p class="headtitle text-left">Add Refund</p>
				</div>
				<div class="col-8">
					<p class="headtitle text-right pr-3"> Student Name: <span class="studname mr-3"></span> Student ID: <span class="studno"></span></p>
				</div>
			</div>
		</h5>
	 </div>
            <div class="row" style="width: 98%;margin: 0px auto;margin-top: 25px;">
                <div class="col-12 col-sm-6" style="display: none">
                    <div class="form-group position-relative error-l-50 floating">
                      <input type="text" value="<?php date_default_timezone_set('Asia/Kolkata'); echo date("d/m/Y"); ?>" class="form-control" name="pdate" id="pdate" required  placeholder=" " >
                     <label for="date">Date <span>*</span></label>
                    </div>
		</div>
                <div class="col-12 col-sm-6" style="display: none">
                    <div class="form-group position-relative error-l-50 floating">
                        <input type="text" value="<?php echo date("h:i a"); ?>" class="form-control" name="ptime" id="ptime"   placeholder=" " >
                     <label for="time">Time <span>*</span></label>
                    </div>
		</div>
                <div class="col-12 col-sm-6">
              <div class="form-group position-relative error-l-50 floating">
                <select class="form-control paymode floating" id="paymode" name="paymode" required  >
                  <option value=""></option>
                  <option value="cash">Cash</option>
                  <option value="dd">Demand Draft</option>
                  <option value="net">Bank Transfer</option>
                  <option value="cheque">Cheque</option> 
                
                </select>
                <label>Mode Of Refund<span>*</span></label>
              </div>
              </div>
               <div class="col-12 col-sm-6">
                    <div class="form-group position-relative error-l-50 floating">
                <select class="form-control reason floating" id="reason" name="reason" required  >
                  <option value=""></option>
                  <option value="scholarship">Scholarship</option>
                  <option value="faid">Financial Aid</option>
                  <option value="discontinue">Discontinue</option>
                  <option value="berror">Billing Error</option> 
                  <option value="excessfeeremit">Excess Fee remit</option> 
                  <option value="others">Others</option> 
                
                </select>
                <label>Reasons<span>*</span></label>
              </div>
		</div> 
                
                <div class="col-12 col-sm-6" style="display: none">
                    <div class="form-group position-relative error-l-50 floating">
                      <input type="text" class="form-control prefno" name="prefno" id="prefno" required  placeholder=" " >
                     <label for="date">DD Number <span>*</span></label>
                    </div>
		</div>  
                <div class="col-12 col-sm-6" style="display: none">
                    <div class="form-group position-relative error-l-50 floating">
                      <input type="text" class="form-control prefno" name="prefnodate" id="prefnodate" required  placeholder=" " >
                     <label for="date">Date <span>*</span></label>
                    </div>
		</div> 
                <div class="col-12 col-sm-6" >
                    <div class="form-group position-relative error-l-50 floating">
                      <input type="text" class="form-control addrefremarks" name="addrefremarks" id="addrefremarks"  placeholder=" " >
                     <label for="date">Remarks </label>
                    </div>
		</div> 
                
            </div>
	  <span style=";font-size: 17px;padding: 10px;float:left;color: #364159">Payment Details ( Exclusive of tax )</span>
          <?php
           $this->table->clear();
         $tmpl = array('table_open' => '<table class="sortable disabled" id="addpaymenttable" style="width:98% !important;">');                 
         $this->table->set_template($tmpl);
         $this->table->set_heading('S.NO', 'DESCRIPTION','AMOUNT', 'REMITTED', 'DEDUCTION','REFUND NET','GST REFUND','REFUND TOTAL');
         echo $this->table->generate();
          
          ?>
          <div class="row" style="width: 98%">

									<div class="col-md-12 text-right px-2">
                                                                            <p class="list-item-heading mb-1" style="visibility:hidden"> <span>Total Remitted Amount:</span> <span class="premit" style="color: #1C47B3 !important;"></span></p>
									</div>

									<div class="col-md-12 text-right px-2 mb-2">
										<p class="list-item-heading mb-1"><span> Total Refund Amount:</span> <span class="prefund" style="color: #D63333 !important"></span></p>
									</div>
              <div class="col-md-12 text-right px-2 mb-2">
										<p class="list-item-heading mb-1"><span> Requested Refund Amount:</span> <span class="rramt" style="color: #1C47B3 !important">0</span></p>
									</div>

								</div>
        
	  <div class="modal-footer">
		<div class="form-group"> 
                <button type="button" class="btn btn-primary paycancel float-left" data-dismiss="modal">Cancel</button>
            </div> 
         
              <div class="form-group"> 
                <button type="button" class="btn btn-primary paysave float-right " >Save</button>
                 </div>
                 </div>
	  </div>
	</div>
  </div>
  
  <?php } ?>
  
<div id="paydoneModal" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true" style="top:30%;">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
				   <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				</div>
				<div class="modal-body text-center">
									
					<img src="css/img/brilliant-logo.png" alt="Payment Success" class="mb-3" />
					<h2 class="mb-4">Payment Successful!</h2>
									
					<p>Your Refund for course has been updated successfully!</p>
										
				</div>
				<div class="modal-footer"></div>
								
			</div>
		</div>
	</div>

<style>
    
    .reportsTable thead tr  {
    background: #E6EBF7;

/* g8 */
border: 1px solid #D7DFF0;
box-sizing: border-box;
border-radius: 10px 10px 0px 0px;
 

}

    .reportsTable tr th {
        border-right: 0px;
    font-size: 13px;
      color: #6F83AA;
   cursor: pointer;
   text-align: center;padding: 4px;
   width: 5%;vertical-align: middle;
    }  
    
  .reportsTable tr { background: #fff;border-bottom: 1px solid #D7DFF0;}
.reportsTable tr td {
    border-right: 0px;
    padding: 5px 5px;
    text-align: center;font-size: 13px;
    vertical-align: middle;
}

    
     
    .reportsTable tr td:nth-child(4) {
  width: 10% !important;
}

    
</style>


<button type="button" class="btn btn-outline-primary d-none courseconfirm1" data-toggle="modal" data-backdrop="static" data-target="#courseModal1">Confirm Submission</button>  
<!-- Modal -->


<div class="modal fade" id="courseModal1" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog modal-xl modal-dialog-centered" role="document">
	<div class="modal-content">
            <div class="modal-header" style="background-color: #6884CC;height: 50px;width: auto;padding: 10px">
	  
		<h5 class="modal-title w-100" id="exampleModalLabel">
		
			<div class="row">
			
				<div class="col-4">
					<p class="headtitle text-left">View Refund</p>
				</div>
				<div class="col-8">
					<p class="headtitle text-right pr-3"> Student Name: <span class="studname mr-3"></span> Student ID: <span class="studno"></span></p>
				</div>
			</div>
		</h5>
	 </div>
            
            <div id="refundItems"></div>
        
	  <div class="modal-footer">
		<div class="form-group"> 
                <button type="button" class="btn btn-primary paycancel1 float-left" data-dismiss="modal">Cancel</button>
            </div> 
              <div class="form-group"> 
                <button type="button" class="btn btn-primary paycancel1 float-left editsave" data-dismiss="modal">Save</button>
            </div> 
              <?php //if(isset($roleaccess['Refund Edit'][3]) && $roleaccess['Refund Edit'][3]=="y"){ ?>
              <div class="form-group"> 
                <button type="button" class="btn btn-primary confirmsave float-right" >Confirm Refund</button>
                 </div> 
              <?php //} ?>
              <div class="form-group"> 
                <button type="button" class="btn btn-primary refundprint float-right" >Print</button>
                 </div>
	  </div>
	</div>
  </div>
  </div> 
<!--Remarks Popup --->
<button type="button" class="btn btn-outline-primary d-none courseconfirm2" data-toggle="modal" data-backdrop="static" data-target="#courseModal2">Add Remarks</button>  
<!-- Modal -->


<div class="modal fade" id="courseModal2" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog modal-l modal-dialog-centered" role="document">
	<div class="modal-content">
            <div class="modal-header" style="background-color: #6884CC;height: 50px;width: auto;padding: 10px">
	  
		<h5 class="modal-title" id="exampleModalLabel">
		
			<p class="headtitle">Add Remarks</p>
		</h5>
	 </div>
            <div class="row" style="width: 98%;margin: 0px auto;margin-top: 25px;">
                
               <div class="col-12 col-sm-12">
                    <div class="form-group position-relative error-l-50 floating">
                         <textarea id="refundremarks" name="name" rows="2" cols="30"></textarea>
                    </div>
		</div>
                
                
            </div>
        
	  <div class="modal-footer">
		<div class="form-group"> 
                <button type="button" class="btn btn-primary paycancel2 float-left" data-dismiss="modal">Cancel</button>
            </div> 
              <div class="form-group"> 
                <button type="button" class="btn btn-primary remarkssave float-right" >Save</button>
                 </div>              
	  </div>
	</div>
  </div>
  </div>  

<!-- Bank Account Details Popup -->
<button type="button" class="btn btn-outline-primary d-none courseconfirm3" data-toggle="modal" data-backdrop="static" data-target="#courseModal3">Add Bank Details</button>  



<div class="modal fade" id="courseModal3" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog modal-l modal-dialog-centered" role="document">
	<div class="modal-content">
            <div class="modal-header" style="background-color: #6884CC;height: 50px;width: auto;padding: 10px">
	  
		<h5 class="modal-title" id="exampleModalLabel">
		
			<p class="headtitle">Add Bank Details</p>
		</h5>
	 </div>
            <div class="row" style="width: 98%;margin: 0px auto;margin-top: 25px;">
                
                <div class="col-12 col-sm-6">
                    <div class="form-group position-relative error-l-50 floating">
                        <input type="text" class="form-control" name="bankname" id="bankname" placeholder=" " value="" >
                       <label >Bank Name</label>
                    </div>
                  </div>
                <div class="col-12 col-sm-6">
                    <div class="form-group position-relative error-l-50 floating">
                      <input type="text" class="form-control" name="branch" id="branch" placeholder=" "  value="" >
                       <label >Branch</label>
                    </div>
                  </div>
                <div class="col-12 col-sm-6 mt-2">
                    <div class="form-group position-relative error-l-50 floating">
                      <input type="text" class="form-control" name="ifsccode" id="ifsccode" placeholder=" "  value="">
                       <label >IFSC Code</label>
                    </div>
                  </div>
                <div class="col-12 col-sm-6 mt-2">
                    <div class="form-group position-relative error-l-50 floating">
                        <input type="text" class="form-control" name="bankaccountno" maxlength="18" id="bankaccountno"  placeholder=" "  value="">
                       <label >Bank Account Number</label>
                    </div>
                  </div>
                <div class="col-12 col-sm-12 mt-2">
                    <div class="form-group position-relative error-l-50 floating">
                     <input type="number" class="form-control " id ="rebankaccountno"  name="mpreenteraccountnumber" maxlength="18" placeholder=" " value="">
                     <label>Re-Enter Bank Account Number</label>
                   </div>
                 </div>
            </div>
        
	  <div class="modal-footer">
		<div class="form-group"> 
                <button type="button" class="btn btn-primary paycancel2 float-left" data-dismiss="modal">Cancel</button>
            </div> 
              <div class="form-group"> 
                <button type="button" class="btn btn-primary banksave float-right" >Confirm and Print</button>
                 </div>              
	  </div>
	</div>
  </div>
  </div>  
<link href="<?php  echo base_url(); ?>css/jquery-ui.min.css?v=1.4" rel="stylesheet" type="text/css" />
 <link href="<?php  echo base_url(); ?>css/chosen.min.css?v=1.3" rel="stylesheet" type="text/css" />
  <link href="<?php  echo base_url(); ?>css/jquery-te-1.4.0.css?v=1.52" rel="stylesheet" type="text/css" />
 <script src="<?php  echo base_url(); ?>js/jquery-ui.min.js?v=1.3" type="text/javascript"></script>
  <script src="<?php  echo base_url(); ?>js/chosen.jquery.min.js?v=1.2" type="text/javascript"></script>
    <script src="<?php  echo base_url(); ?>js/jquery-te-1.4.0.min.js" type="text/javascript"></script>

 <style type="text/css">
     
     .ui-selectmenu-button.ui-button{ width: 97%; padding:13px;}
      #duration-button,#modeofexam-button,#examtimefreq-button,#subcriteria-button,#rule-button,#maincriteria-button,#stream-button,#coursetype-button,#accounthead-button{border: 1px solid #D7DFF0;background: #fff;font-size: 14px;color:#536485}
     #centers_chosen  {border: 1px solid #D7DFF0;background: #fff;padding: 8px 0px;}
     .chosen-container-multi .chosen-choices {border: 0px;background: none}
     .maincontent ul li.search-choice { height:auto; }
     .maincontent ul li.search-choice a{ height:auto; font-size: 14px;color:#536485}
     .chosen-container-multi .chosen-choices li.search-choice { background: #6884CC;border-radius: 5px;}
     .chosen-container-multi .chosen-choices li.search-choice {color: #fff;}
     .response p { float: right;font-size:12px;color:#eb345e;}
 </style>

	<div class="wrap dynamic-width" style="float: left;position: relative;min-width: 800px">
     <div style="margin-top: 10px; width: 99%; height: 50px; text-align: right;">
         <span style="font-weight: bold;font-size: 20px;padding: 10px;float:left;color: #364159">Edit Course</span>
         
         <?php if(isset($roleaccess['Admission Add Payment'][3]) && $roleaccess['Admission Add Payment'][3]=="y"){?>
         
         <a style="padding: 10px;  color: #fff; margin: 0px auto; background: linear-gradient(180deg, #4F70C4 0%, #1C47B3 100%); position: relative; top: 5px;border-radius:5px;font-size: 14px" class="btn" href="<?php echo base_url(); ?>addpayment?id=<?php echo html_escape($edit['ide']); ?>"><span style="position: relative;top:4px"><img  src="<?php echo $this->config->item('web_url') ?>images/addcourse.png" alt="Navigation" /></span><span style="margin-left:5px">Add Payment</span></a>
         
         <?php }?>
         
     </div>         
            <div id="course-container" class="add-course">
<?php echo form_open('editcourse/courseSubmit', array('id' => 'courseForm')) ?>
                <div class="row-element">
                    <span class="title">Course Name</span>
                    <span class="content"><input type="text" name = "cname" value="<?php echo html_escape($edit['coursename']); ?>" class="name"><input type="hidden" name = "cid" value="<?php echo html_escape($edit['ide']); ?>" class="name"><input type="hidden" name = "courseid" value="<?php echo html_escape($edit['courseid']); ?>"></span>
                </div>
                
                <div class="row-element">
                    <span class="title">ID Card Display Name</span>
                    <span class="content">
                        <input type="text" name="idcard_displayname" class="idcard_displayname" value="<?php echo html_escape($edit['idcard_displayname']); ?>" maxlength="20">
                    </span>
                </div>
                
                <div class="row-element">
                    <span class="title" >Course Stream</span>
                    <span class="content">
                        <select id="stream" name = "stream" class="duration" style="font-size: 13px;float:left">
                           <option value="">Select Course Stream</option>
                            <option>MEDICAL</option>
                            <option>ENGINEERING</option>
                            <option>FOUNDATION</option>
                            <option>SCREENING TEST</option>
                            <option>SCHOOL PLUS</option>
                        </select>
                                              
                    </span>
                </div>
                
                <div class="row-element">
                    <span class="title" >Course Type</span>
                    <span class="content">
                        <select id="coursetype" name = "coursetype" class="duration" style="font-size: 13px;float:left">
                           <option value="">Select Course Type</option>
                            <option>REPEATER</option>
                            <option>RESIDENTIAL</option>
                            <option>LONG TERM</option>
                            <option>SPECIAL</option>
                            <option>HYBRID</option>
                            <option>PREFOUNDATION</option>
                            <option>IIT/AIMS</option>
                            <option>FOUNDATION</option>
                        </select>
                                              
                    </span>
                </div>
                
                <div class="row-element">
                    <span class="title" >Accounting Head</span>
                    <span class="content">
                        <select id="accounthead" name = "accounthead" class="duration" style="font-size: 13px;float:left">
                           <option value="">Select Accounting Head</option>
                            <?php echo $ahselectoptions;?>
                        </select>
                                              
                    </span>
                </div>
                
                 <div class="row-element">
                    <span class="title">Screening Test</span>                    
                    <span class="content">
                        <label style="text-align: left;min-width: 150px;color:#536485;background: none;border: 0px;width: auto;height: auto;float:left;font-size: 14px;font-weight: normal"><input type="checkbox" name = "stest"   <?php if($edit["stest"] ==="1"){ echo 'checked'; } ?> class="stest chkbox" style="margin: 5px;"></label>
                    </span>
                </div>
                
                <div class="row-element">
                    <span class="title">Duration</span>
                    <span class="content">
                        
                        
                        <label style="color:#536485;background: none;border: 0px;width: 48%;height: auto;float:left;">
                        <input placeholder="" type="text" name = "duration" value="<?php echo html_escape($edit['duration_value']); ?>" class="advalue" style="margin: 5px;background: #fff ">
                         </label>
                        <label style="color:#536485;background: none;border: 0px;width: 4%;height: 20px;float:left;">&nbsp;</label>
                        <label style="color:#536485;background: none;border: 0px;width: 48%;height: auto;float:left;">
                        <select id="duration" name = "durationfreq" class="duration" style="font-size: 13px;float:left">
                            <option value="" >Select Duration</option>
                            <option <?php  echo ($edit['duration_time']==='Month')?'selected="selected"':""; ?> >Month</option>
                            <option <?php echo ($edit['duration_time']==='Year')?'selected="selected"':""; ?> >Year</option>
                            <option <?php echo ($edit['duration_time']==='Days')?'selected="selected"':""; ?> >Days</option>
                            <option <?php echo ($edit['duration_time']==='Hours')?'selected="selected"':""; ?> >Hours</option>
                            <option <?php echo ($edit['duration_time']==='Minutes')?'selected="selected"':""; ?> >Minutes</option>
                        </select>
                         </label>
                    </span>
                </div>
                
                <div class="row-element">
                    <span class="title" id="commonces">Commences on</span>
                    <span class="content">
                        <input type="text" name = "commence" value="<?php echo html_escape($edit['commenceson']); ?>" id="maingroup" class="maingroup">
                       
                    </span>
                </div>
                <?php if($edit["stest"] ==="1"){  
                    
                    $etime = $edit["examtime"];
                    $etime = explode(" ", $etime);
                    
                    ?>
                 <div class="row-element" id="examtime">
                    <span class="title" >Exam Time</span>
                    <span class="content">
                        <label style="color:#536485;background: none;border: 0px;width: 48%;height: auto;float:left;">
                            <input placeholder="Enter Value" type="text" value="<?php echo $etime[0];?>" name = "examtime"  style="margin: 5px;background: #fff ">
                         </label>
                        <label style="color:#536485;background: none;border: 0px;width: 4%;height: 20px;float:left;">&nbsp;</label>
                        <label style="color:#536485;background: none;border: 0px;width: 48%;height: auto;float:left;">
                        <select id="examtimefreq" name = "examtimefreq" class="duration" style="font-size: 13px;float:left">
                           
                            <?php 
                        $ret = '';
                          $arr = ['AM',"PM"];
                          for($i = 0;$i < count($arr);$i++){
                              if($etime[1] === $arr[$i]){
                                      $selected = 'selected="selected" ';
                                  }
                              $ret1 .="<option >".$arr[$i]."</option>";
                              
                          }
                          echo $ret1;
                        ?>
                        </select>
                         </label>
                       
                    </span>
                </div>
               
                <div class="row-element" id="cooloftime" >
                    <span class="title" id="commonces">Cool of Time</span>
                    <span class="content">
                        <label style="color:#536485;background: none;border: 0px;width: 48%;height: auto;float:left;">
                            <input value="<?php echo $edit["cooloftime"];  ?>" placeholder="Enter Value" type="text" name = "cooloftime"  style="margin: 5px;background: #fff ">
                         </label>
                        <label style="color:#536485;background: none;border: 0px;width: 4%;height: 20px;float:left;">&nbsp;</label>
                        <label style="color:#536485;background: none;border: 0px;width: 48%;height: auto;float:left;margin-top: 15px">
                        Minutes
                         </label>
                       
                    </span>
                </div>
                
                <div class="row-element" id="rtime" >
                    <span class="title" >Reporting Time</span>
                    <span class="content">
                        <input type="text" name = "rtime" class="adtime" value="<?php echo $edit["reportingtime"];  ?>">
                       
                    </span>
                </div>
                
                <div class="row-element" id="modeofexam" >
                    <span class="title" >Mode Of Exam</span>
                    <span class="content">
                        <select id="modeofexam" name = "modeofexam" class="duration" style="font-size: 13px;float:left">
                          <?php 
                        $ret1 = '';
                          $arr1 = ['Online',"Offline"];
                          for($i = 0;$i < count($arr1);$i++){
                              if($edit["modeofexam"] === $arr1[$i]){
                                      $selected = 'selected="selected" ';
                                  }
                              $ret1 .="<option >".$arr1[$i]."</option>";
                              
                          }
                          echo $ret1;
                        ?>
                        </select>
                                              
                    </span>
                </div>
               <?php  } ?>
                <div class="row-element">
                    <span class="title" id="adtime">Admission Time</span>
                    <span class="content">
                        <label style="color:#536485;background: none;border: 0px;width: 48%;height: auto;float:left;">
                            <input placeholder="Starts on" type="text" name = "startson"  value="<?php echo html_escape($edit['starts_on']); ?>" class="adtime" style="margin: 5px;background: #fff url('<?php echo base_url(); ?>/images/cal.png') no-repeat 98%;"></label>
                         <label style="margin-left: 3%;color:#536485;background: none;border: 0px;width: 48%;height: auto;float:left;">
                             <input placeholder="Ends on" type="text" name = "endson" value="<?php echo html_escape($edit['ends_on']); ?>" class="adtime" style="margin: 5px;background: #fff url('<?php echo base_url(); ?>/images/cal.png') no-repeat 98%;"></label>
                        
                       
                    </span>
                </div>

                <div class="row-element">
                    <span class="title">Qualification</span>                    
                    <span class="content"><select id="maincriteria" name = "qualification" class="maincriteria" style="font-size: 13px;float:left">
                            <?php echo $qualification;?>
                        </select></span>
                </div>
                
                           
                
                <div class="row-element" id="csch" <?php if($edit["stest"] ==="1"){ echo 'style="display:none"'; } ?>>
                    <span class="title">Class Schedule</span>                    
                    <span class="content">
                        <label style="text-align: left;min-width: 150px;color:#536485;background: none;border: 0px;width: auto;height: auto;float:left;font-size: 14px"><input name = "regular" type="checkbox" <?php $schdule = explode("|",$edit["cshedule"]);echo ($schdule["0"] === "regular")?'checked="checked"':"";?> class="chkbox rbatch" style="margin: 5px;">Regular Batch</label>
                        <label style="text-align: left;min-width: 150px;color:#536485;background: none;border: 0px;width: auto;height: auto;float:left;font-size: 14px"><input  name = "weekend" type="checkbox"  <?php echo ($schdule["1"] === "weekend")?'checked="checked"':"";?> class="chkbox wbatch" style="margin: 5px;">Weekend batch</label>
                        <label style="text-align: left;min-width: 150px;color:#536485;background: none;border: 0px;width: auto;height: auto;float:left;font-size: 14px"><input name = "both" type="checkbox" <?php echo ($schdule["2"] === "both")?'checked="checked"':"";?> class="chkbox both" style="margin: 5px;">Both</label>
                        <label style="text-align: left;min-width: 150px;color:#536485;background: none;border: 0px;width: auto;height: auto;float:left;font-size: 14px"><input name = "hybrid" type="checkbox" <?php echo ($schdule["3"] === "hybrid")?'checked="checked"':"";?> class="chkbox hbatch" style="margin: 5px;">Hybrid batch</label>
                        <label style="text-align: left;min-width: 150px;color:#536485;background: none;border: 0px;width: auto;height: auto;float:left;font-size: 14px"><input  name = "special" type="checkbox"  <?php echo ($schdule["4"] === "special")?'checked="checked"':"";?> class="chkbox sbatch" style="margin: 5px;">Special batch</label>
                        <label style="text-align: left;min-width: 150px;color:#536485;background: none;border: 0px;width: auto;height: auto;float:left;font-size: 14px"><input name = "other" type="checkbox" <?php echo ($schdule["5"] === "other")?'checked="checked"':"";?> class="chkbox other" style="margin: 5px;">Other State</label>     
                    </span>
                </div>
                <div class="row-element" id="coutype" <?php if($edit["stest"] ==="1"){ echo 'style="display:none"'; } ?>>
                    <span class="title">Course Type</span>                    
                    <span class="content">
                        <label style="text-align: left;min-width: 150px;color:#536485;background: none;border: 0px;width: auto;height: auto;float:left;font-size: 14px;font-weight: normal"><input name = "ctype" type="radio" <?php echo ($edit["ctype"] === "online")?'checked="checked"':"";?> value="online" class="" style="margin: 5px;">Online</label>
                        <label style="text-align: left;min-width: 150px;color:#536485;background: none;border: 0px;width: auto;height: auto;float:left;font-size: 14px;font-weight: normal"><input  name = "ctype" type="radio"  <?php echo ($edit["ctype"] === "room")?'checked="checked"':"";?> value="room" class="" style="margin: 5px;">Class Room</label>
                        <label style="text-align: left;min-width: 150px;color:#536485;background: none;border: 0px;width: auto;height: auto;float:left;font-size: 14px;font-weight: normal"><input name = "ctype" type="radio" <?php echo ($edit["ctype"] === "both")?'checked="checked"':"";?> value="both" class="" style="margin: 5px;">Both</label>
                          </span>
                </div>
                
                 <div class="row-element">
                    <span class="title" id="scity"><?php if($edit["stest"] ==="1"){ echo "City";} else { echo 'Centers';}?></span>                    
                    <span class="content"><select multiple id="centers" name = "centers" class="centers" style="width: 100%;font-size: 13px;float:left">
                            <option value="" ><?php if($edit["stest"] ==="1"){ echo "Select City";} else { echo 'Select Center';}?></option>
                            <?php echo $units;?>
                        </select></span>
                    <input type="hidden" name="selcenters" class="selcenters" />
                </div>
                
                <div class="row-element">
                    <span class="title">Course Description</span>                    
                    <span class="content">
                        <textarea class="coursedesc"  name = "cdescription" style=" width: 100%;height:160px"><?php echo html_escape($edit['description']); ?></textarea>
                    </span>
                </div>
                <div class="row-element">
                    <span class="title">Refund Policy</span>                    
                    <span class="content">
                        <textarea class="refund" name = "crefund" style=" width: 100%;height:160px"><?php echo html_escape($edit['refund']); ?></textarea>
                    </span>
                </div>
                
       <?php echo form_close() ?>        
                
            </div>
     <div style="margin-top: 0px; width: 98%; height: 70px; text-align: right;">
         <span  style="margin: 0px auto; float:right;margin-top: 18px;padding: 10px; color: #fff; background: #4f6fc4 none repeat scroll 0% 0%; border-radius:5px;cursor: pointer" class="btn savebtn" href="#">Submit</span>
         <a style="margin: 0px auto; float:right;margin-top: 18px;margin-right:18px;padding: 9px 10px; color: #0332AA; background: linear-gradient(0deg, #FFFFFF, #FFFFFF), #C4C4C4;border: 1px solid #0332AA; border-radius:5px" class="btn" href="<?php echo base_url(); ?>courses">Back</a>
         <span class="response" style="margin: 0px auto; float:right;width: 80%; height: 30px;margin-top:20px"></span>
     </div>         
        
        </div>
    
    
    
<script type="text/javascript">
$(document).ready(function() {
	
	var stream = "<?php echo html_escape($edit['stream']); ?>";
	var coursetype = "<?php echo html_escape($edit['type']); ?>";
	var accounthead = "<?php echo html_escape($edit['accountinghead']); ?>";
	
	$("#stream").val(stream);
	$("#coursetype").val(coursetype);
	//$("#accounthead").val(accounthead);
    
    $(".duration").selectmenu();
    $(".chkbox").checkboxradio();
    $(".adtime").datetimepicker();
    $("#centers").chosen();$("#subcriteria").selectmenu();$("#rule").selectmenu();$("#maincriteria").selectmenu();
     $(".coursedesc").jqte();
     $(".refund").jqte();
    
    $(".add-course").find(".name").focus();
    
     $(".stest").click(function(){
        if($(this).is(":checked")){
            
             $("#csch").css("display","none");
            $("#coutype").css("display","none");
            $("#adtime").text("Application Period");
            $("#commonces").text("Test Date");
            $("#scity").text("City");
            
            $("#examtime").css("display","inline-block");
            $("#rtime").css("display","inline-block");
            $("#cooloftime").css("display","inline-block");
            $("#modeofexam").css("display","inline-block");

             $.get('addcourse/GetScreenTestCities',{ 'term':"1"}, function(o) { 

                     
                     $("#centers").chosen('destroy');  $("#centers").html(o);
                     $("#centers").chosen();
                     $("#centers_chosen").find(".chosen-search-input").val("Select City");

              });        
        } else {
            
            $("#csch").css("display","inline-block");
            $("#coutype").css("display","inline-block");
            $("#adtime").text("Admission Time");
            $("#commonces").text("Commences on");
            $("#scity").text("Centers");
            
            $("#examtime").css("display","none");
            $("#rtime").css("display","none");
            $("#cooloftime").css("display","none");
            $("#modeofexam").css("display","none");
            
            $.get('addcourse/GetScreenTestLocation',{ 'term':"0"}, function(o) { 

                     
                     $("#centers").chosen('destroy');  $("#centers").html(o);
                     $("#centers").chosen();
                     $("#centers_chosen").find(".chosen-search-input").val("Select Centers");

              }); 
            
        }
    });
    
     
         $(".savebtn").click(function(){
         
              if($(".response").hasClass('progress')) { return;}
               $(".response").html('').text('Progressing...');
                $(".response").addClass('progress');
               var centers = "";
               $("#centers_chosen").find("li span").each(function(){
                   centers += $(this).text()+"|";
               });
               
               if($(".rbatch").is(":checked")) {$(".rbatch").val("regular");} else { $(".rbatch").val("0");}
               if($(".wbatch").is(":checked")) {$(".wbatch").val("weekend");} else { $(".wbatch").val("0");}
               if($(".both").is(":checked")) {$(".both").val("both");} else { $(".both").val("0");}
               if($(".stest").is(":checked")) {$(".stest").val("1");} else { $(".stest").val("0");}
                if($(".hbatch").is(":checked")) {$(".hbatch").val("hybrid");} else { $(".hbatch").val("0");}
               if($(".sbatch").is(":checked")) {$(".sbatch").val("special");} else { $(".sbatch").val("0");}
               if($(".other").is(":checked")) {$(".other").val("other");} else { $(".other").val("0");}
               
               $(".selcenters").val(centers);
               
                var qualificationForm = $("#courseForm");

                    $.ajax({
                        url: qualificationForm.attr('action'),
                        type: 'post',
                        data: qualificationForm.serialize(),
                        success: function(o){
                            
                            var response = $.parseJSON(o);
                            $(".response").html('');
                            if(response.status === 'success') {
                                
                               
                                $(".response").css("color","rgb(25, 71, 15)");
                               $(".response").text(response.message);
                               $(location).prop('href', 'courses');
                            } else {
                                
                               $(".response").append(response.message); 
                               $(".response").removeClass('progress');
                           
                            }

                        }
                    });
                   
                              
            });
        
        
       /*  $(".centers").autocomplete({
            source: function (request, response) {
                $.ajax({
                    url: "addcourse/mainGroupSearch",
                    contentType: "application/jsonp",
                    
                    data: {
                        term: request.term
                    },
                    success: function (data) {
                        data = $.parseJSON(data);
                        response(
                                $.map(data, function (item) {
                                    return {
                                        value: item.name,
                                        groupid:item.id
                                    };
                                })
                                );
                    }
                });
            },
            select: function (event, ui) {
                
                $("#maingroup").val(ui.item.value);
                 $(".maingroupid").val(ui.item.groupid);
                
                
            }
        });*/
	
	
	$(".add-course").find("input").each(function(){
            
            $(this).keyup(function(event){
                if(event.keyCode == 13){
                    var ty = $(this).next();
                    event.preventDefault();
                    $('input')[$('input').index(this)+1].focus();
                    $('input')[$('input').index(this)+1].select();
                }
            });

            $(this).click(function(){ $(".errnotify").html("&nbsp;");});
            

        });
	
        
        $(".add-course").find(".mrp").keyup(function(){
            
               if($("#group").val() == "") { return;}
           
               var getVal = $(this).val();
               
               var discount = $(".discount").val();
               var cdiscount = $(".cdiscount").val();
               var ediscount = $(".ediscount").val();
               var tax = $(".tax").val();
               
               
               if(discount !== "") { discount = parseFloat(discount) / 100 ; } else { discount = 0;}
               if(cdiscount !== "") { cdiscount = parseFloat(cdiscount) / 100 ; } else { cdiscount = 0;}
               if(ediscount !== "") { ediscount = parseFloat(ediscount) / 100 ; } else { ediscount = 0;}
               if(tax !== "") { tax = parseFloat(tax) / 100 ; } else { tax = 0;}
               
               
               var purchase_price_discount = parseFloat(getVal) * discount;
               var purchase_price = parseFloat(getVal) - parseFloat(purchase_price_discount);
               var tax_calculate = parseFloat(purchase_price) * tax;
               purchase_price = purchase_price + parseFloat(tax_calculate);    
               
               var sell_price_discount = parseFloat(purchase_price) * cdiscount;
               var sell_price = parseFloat(purchase_price) + parseFloat(sell_price_discount);
               
               var sell_price_elec_discount = parseFloat(purchase_price) * ediscount;
               var sell_price_elec = parseFloat(purchase_price) + parseFloat(sell_price_elec_discount);

               purchase_price  = purchase_price.toFixed(2);
               sell_price      = sell_price.toFixed(2);
               sell_price_elec = sell_price_elec.toFixed(2);
  
               purchase_price  = Math.round(purchase_price);
               sell_price  = Math.round(sell_price);
               sell_price_elec  = Math.round(sell_price_elec);
                
               
               if(isNaN(purchase_price)) { $(".purchase_price").val("0"); } else { $(".purchase_price").val(purchase_price); }
               if(isNaN(sell_price)) { $(".sell_price").val("0"); } else { $(".sell_price").val(sell_price); }
               if(isNaN(sell_price_elec)) { $(".sell_price_elec").val("0"); } else { $(".sell_price_elec").val(sell_price_elec); }
           
           
        });
                
	$(".add-course").find(".course-submit").click(function(){
            return;
            
                if($(this).hasClass("progress")) {
                    return;
                }
		
		var itemname = $(".add-course").find(".name").val();
                var nickname = $(".add-course").find(".nickname").val();
                var group = $(".add-course").find(".group").val();
                var mrp = $(".add-course").find(".mrp").val();
                var purchaseprice = $(".add-course").find(".purchase_price").val();
                var sellprice = $(".add-course").find(".sell_price").val();
                var sell_price_elec = $(".add-course").find(".sell_price_elec").val();
                var groupid = $(".add-course").find(".groupid").val();
                var maingroupid = $(".add-course").find(".maingroupid").val();
                var maingroup = $(".add-course").find(".maingroup").val();
                var unit = $(".add-course").find(".units").val();
          
		
		if(itemname === ""){ $(".errnotify").html("Invalid item name");return;}		
		
                $(this).addClass("progress");
		$(this).val("Processing...");
		
				$.get('additem/insertItem',{
					   'itemname':itemname, 
                                           'nickname':nickname, 
                                           'group':group, 'maingroup':maingroup, 
                                           'mrp':mrp, 
                                           'purchaseprice':purchaseprice, 
					   'sellprice':sellprice,
                                           'sell_price_elec':sell_price_elec,
                                           'maingroupid':maingroupid,
                                           'groupid':groupid,
                                           'unit':unit

				}, function(o) { 
					var obj1 = $.parseJSON(o);
                                        $(".add-course").find(".course-submit").removeClass("progress");
                                        $(".add-course").find(".course-submit").val("Submit");
					if(obj1[0] === 'success'){
						    $(".add-course").find(".course-submit").val("Submit");
                                                    $(".errnotify").html("Item Successfully Added");
                                                    if($(".retain").is(":checked")) {
                                                        //dont do anything
                                                    } else {
                                                        $(".add-course").find("input").each(function(){ $(this).val(''); });
                                                        $(".add-course").find(".course-submit").val("Submit");
                                                    }
                                                    
                                                   // location.reload();
                                                
					}else if (obj1[0] === 'exists') {
                      
                                    alert("Item already exists...Please try again");

                                }else if(obj1[0] === 'fail'){
                                                   $(".add-course").find(".course-submit").val("Submit");
                                                   alert("Error!! Please try again");                                                    
						
					}
				});	 
		
  	});
	
});
</script>
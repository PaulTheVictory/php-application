<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/dataTables.css?v=1.5" />
<script src="<?php echo base_url(); ?>js/jquery.dataTables.js?v=1.0" type="text/javascript"></script>

 <style type="text/css">
	 
	 table.dataTable{margin-top: 2rem !important}
	 .table tr:last-child td{text-align: left}
	.table tr td:last-child,.table tr th:last-child{text-align: left}
	.table tr:last-child td:last-child{font-weight: 600;text-align: left}
	.table tr:last-child{text-align: center}
	
	.table{border: 1px solid #D7DFF0;border-collapse: collapse;border-style: hidden;border-radius: 10px 10px 0 0;box-shadow: 0 0 0 1px #d7dff0;}
	.table thead th{font-size: 12px;font-weight: bold;color: #6F83AA;letter-spacing: 0.5px;background: #E6EBF7;text-transform: uppercase;padding: 0.8rem;text-align: left}
	.table thead tr th:first-child{border-top-left-radius: 5px}
	.table thead tr th:last-child{border-top-right-radius: 5px}
	.table td, .table th{border-top: 1px solid #D7DFF0;padding: 0.9rem 0.75rem;color: #364159;font-weight: 600;}
	.table td{background: #ffffff;}
	
		
	h3.title{font-size: 12px;text-transform: uppercase;color: #0332AA;letter-spacing: 0.5px;font-weight: bold;}
		
		.dataTables_empty{text-align: center !important}
		.dataTables_wrapper{overflow-x: auto}
	 
	 .librarycard .card{background: linear-gradient(0deg, #FFFFFF, #FFFFFF), #C4C4C4;box-shadow: 0px 0px 7px rgba(196, 196, 196, 0.35);border-radius: 10px;}
	 .librarycard .z-index{z-index: 1;}
	 
	 .form-group.floating{margin-bottom: 0}
	 
	 .dataTables_filter{right: inherit;left: 20px;top: 5px;}
	 #usertable_filter input{width: 300px}
	 #usertable_wrapper{top: -60px;padding-top: 3rem}

 </style>
 
 <script type="text/javascript">
$(document).ready(function(){	
		
	
          var columnData = [
              { "data": "created" },
                    { "data": "bookname" },
                    { "data": "isbn_number" },
                    { "data": "status" },
                    { "data": "edition" }, 
                    { "data": "author" },
                    { "data": "publisher" },
                    { "data": "id" }
                    
                  ];
        // columnData.push( {data: "id","visible":true} );
         //columnData.push( {data: "item_name_search","visible":false} );
         
       
        var oTable = $('#usertable').dataTable({
                    "bProcessing": true,
                    "bServerSide": true,
                    "sPaginationType": "full_numbers",
                    "ajax": {
                    "url": 'library/GetBooks',
                    "type": "POST",
                   
                    "data":{ "type": ""}
                     }, 
                     "oLanguage": {
                        "sProcessing": "<img src='<?php echo base_url(); ?>images/loader.gif'>",
						 "sSearchPlaceholder": "Search Books",
                    },
                    'iDisplayLength': 20,
                    "columns": columnData,
                    "order": [[ 0, "desc" ]],
                    "fnDrawCallback": function( oSettings ) {
						
                        var count = 1;
						
                         $('#usertable').find("tr .sno").each(function(){                           
                            $(this).text(count);
                            count++;
                         });
                                                      
                    }
         }); 
         
         
         $('#usertable_filter input').addClass('form-control');
  
	
});
</script>

 <main> 
        
        <div class="container-fluid">
                 
	<div class="wrap dynamic-width">
    
     <div style="margin-top: 10px; width: 99%; height: 50px; text-align: left;">
         <span style="font-weight: bold;font-size: 20px;padding: 10px;float:left;color: #364159">Library</span>
         </div>   
               
            <div class="row px-3 mt-4">     
                     
           <div class="col-12 librarycard p-0">
           
           <div class="card">
           
            <div class="course-container add-course mt-3 px-4">
                                
                <div class="row">
                   
                    <div class="col-12 col-sm-4">
                    
				  		<!--<div class="form-group floating">
                      
                    		<select id="allcenters" name="allcenters" value="" class="form-control allcenters">
								<option value="">All Centers</option>
                       		 </select>
                       		 
							 <label>All Centers <span>*</span> </label>
						</div>-->
					</div>
                   
                    <div class="col-12 d-flex col-sm-8 mb-3 justify-content-end z-index">
                    
						<a href="addbook" title="Add Book Item" class="mr-3"><button class="btn btn-primary">Add Book Item</button></a>
			  		
			  		<?php if($roleaccess['Issue Books'][3]=="y"){ ?>
			  		
						<a href="issuebook" title="Issue Book" class="mr-3"><button class="btn btn-primary">Issue Book</button></a>
						
					<?php } ?>	
			  		
			  		<?php if($roleaccess['Receive Books'][3]=="y"){ ?>
			  		
						<a href="receivebook" title="Receive Book"><button class="btn btn-primary">Receive Book</button></a>
						
					<?php } ?>	
			  		
			  		<?php if($roleaccess['Generate Barcodes'][3]=="y"){ ?>
			  		
						<a href="generatebarcode" title="Receive Book" class="ml-3"><button class="btn btn-primary">Generate Barcode</button></a>
			  		
			  		<?php }?>
				  		
					</div>
					
				</div>
               
                </div>
                
			   </div>
               
            </div>
             
          
           </div>
           
           <?php echo $this->table->generate();  ?>
       
        </div>
 </div>
 
 </main>
 
<script type="text/javascript">
	
    $(document).ready(function() {
   
    
           
    });
	
</script>
    
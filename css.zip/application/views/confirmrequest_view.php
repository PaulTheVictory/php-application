
<link rel="stylesheet" href="<?php echo base_url();?>css/fonts/simple-line-icons/css/simple-line-icons.css">


<link rel="stylesheet" href="<?php echo base_url();?>css/boot/vendor/dataTables.bootstrap4.min.css">
<link rel="stylesheet" href="<?php echo base_url();?>css/boot/vendor/datatables.responsive.bootstrap4.min.css">

<link rel="stylesheet" href="<?php echo base_url();?>css/boot/vendor/baguetteBox.min.css">
<script src="<?php echo base_url();?>js/vendor/baguetteBox.min.js"></script>

<?php if($qid !== ""){?>
<link rel="stylesheet" href="<?php echo base_url();?>css/boot/bootstrap.min.css">
<link rel="stylesheet" href="<?php echo base_url();?>css/boot/main.css?v=3">

<script src="<?php echo base_url();?>js/bootstrap.bundle.min.js"></script>

<?php } ?>
<script type="text/javascript">
    
window.addEventListener( "pageshow", function ( event ) {
  var perfEntries = performance.getEntriesByType("navigation");

    if (perfEntries[0].type === "back_forward") {
        location.reload(true);
    }

});

$(document).ready(function(){
    
  
     $(".back").click(function(){
      
       var url = 'stucoursedetails?id=<?php echo $qualification['courseid'];?>';
        $(location).prop('href', url);
          
  });
  
    $(".courseredirect").click(function(){
      
      <?php if($qid === ""){?>
       var url = 'stucoursedetails?id=<?php echo $qualification['courseid'];?>';
        $(location).prop('href', url);
      <?php }else { ?>    
        var url = 'studentprofile?sid=<?php echo $sid;?>';
        $(location).prop('href', url);  
          <?php } ?>
  });
  
  $(".confirm").click(function(){
	  
	  var alerttext = '<label style="color:#ff3c3c;font-weight: bold;font-size: 14px;margin-bottom: 0px;"><span style="color: #364159;">Attention: </span> You can still apply for the same course with ONLINE ONLY option.</label>';
	  
	  var courseno = "<?php echo $courseno; ?>";
	  
	  if(courseno!="1009") { alerttext = "";}
	        
	 
         $.ajax({
                        url: 'confirmrequest/QualificationCheck',
                        type: 'post',
                       data: {
                        id: '<?php echo $qualification['ide'];?>',utype:'student'
                    },
                        success: function(o){
                            var response = $.parseJSON(o);
                            $(".response").html('');
                            if(response.status === 'success') {
                                $(".courseconfirm").trigger('click');
                               
                            } else {
                                
                               $("#exampleModalLabel").find(".headtitle").text('Qualification Alert');
							   $("#exampleModalLabel").find(".text-muted").text('Qualification is not matched for your requested course registration');
							   if(alerttext!="")$("#exampleModalLabel").find(".text-muted").after('<p class="mb-4">'+alerttext+'</p>');
							   $(".courseconfirm").trigger('click'); 
                           
                            }

                        }
                    });
		
  });
  
    
  
});
</script>

<style>
	
	main{margin: 0px auto}
	ul li{margin-bottom: 0px}

	h2.refund{color: #364159;font-size: 20px;font-weight: bold;line-height: 36px;}
	.coursetype .card{box-shadow: 0px 0px 7px rgba(196, 196, 196, 0.35);background: linear-gradient(0deg, #FFFFFF, #FFFFFF), #C4C4C4;cursor: pointer;border: 2px solid transparent;transition: all ease 0.3s}
	.rounded .coursetype .card{border-radius: 10px}
	.coursetype .card.active{border: 2px solid #0332AA;}
	.coursetype .card p {color: #889DC6;font-size: 14px;transition: all ease 0.3s}
	.coursetype .card img{filter: opacity(0.4);transition: all ease 0.3s}
	
	.coursetype .card.active p{color: #0332AA;}
	.coursetype .card.active img{filter: opacity(1);}
	
	.coursetop p{color: #6F83AA}
	
	.coursedetails h1{font-size: 18px;color: #364159;}
	.coursedetails .card,.courseinfo .card{background: linear-gradient(0deg, #FFFFFF, #FFFFFF), #C4C4C4;box-shadow: 0px 0px 7px rgba(196, 196, 196, 0.35);border-radius: 10px;}
	.coursedetails h2{color: #0332AA;font-size: 24px;font-weight: bold;line-height: 36px;}
	.coursedetails p.list-item-heading,.coursecontent .row div:first-child p,.yearfee .row div:first-child p{color: #6884CC;font-weight: 600;}
	
	.border-right{border-right: 1px solid #D7DFF0!important;}
	
	.yearfee .card{background: #F6F7FA;border: 1px solid #BCCAE8;box-shadow: none}
	.yearfee p{margin-bottom: 1.5rem}
	.yearfee p.first,.yearfee p.second{font-weight: bold;font-size: 14px;color: #0332AA;text-align: left;text-transform: uppercase;}
	.yearfee .row div:last-child p{font-size: 14px;font-weight: 600;color: #364159;}
	
	.btn-primary{width: auto}
	
	.card h5{margin-bottom: 1rem;}
	h5{font-weight: bold;}
	.badge-outline-secondary, .badge-outline-theme-2{border: 1px solid #889DC6;color: #889DC6;background: #F6F7FA;}
	.badge{font-size: 12px;margin-right: 5px}
	
	.courseinfo .col-right .card .card-body{padding: 0;}
	.courseinfo .border-bottom{border-bottom: 1px solid #D7DFF0!important;}
	.col-right h5{padding: 1.2rem}
	
	.schedule .row div:first-child p{font-size: 12px;color: #6884CC;font-weight: bold;letter-spacing: 0.5px;text-transform: uppercase;}
	.schedule .row div:last-child p{font-size: 14px;font-weight: 600;}
	
	.relatedcourse p.list-item-heading{color: #6884CC;font-weight: 600;}
	.relatedcourse .row div:first-child p{font-size: 16px;color: #364159;font-weight: bold;}
	.relatedcourse .row div:last-child i{background: url(img/icons/arrow-right.png) no-repeat;width: 14px;height: 14px;display: inline-block;vertical-align: middle}
	
  .courseinfo ul {list-style: none;}
  .courseinfo li {list-style-position: inside;text-indent: 0em;font-stretch: normal;letter-spacing: normal;padding: 10px 10px 10px 35px;background: url("img/icons/check-circle.png") no-repeat left center; margin: 0;
  vertical-align: middle;}
	
	.icon-flag{background: url("img/icons/flag.png") no-repeat;width: 15px;height: 15px;display: inline-block;vertical-align: middle}
	.icon-check-square{background: url("img/icons/check-square.png") no-repeat;width: 15px;height: 15px;display: inline-block;vertical-align: middle}
	.icon-send{background: url("img/icons/send.png") no-repeat;width: 15px;height: 15px;display: inline-block;vertical-align: middle;margin-right: 5px}
	
	p.totalfee {font-weight: bold;font-size: 24px;color: #D63333;}
        <?php if($qid !== ""){?>  
         .icon-bookmark-s{background: url("img/icons/bookmark-s.png") no-repeat;width: 14px;height: 14px;display: inline-block;vertical-align: middle;margin-right: 0.5rem}
	.icon-phone-s{background: url("img/icons/phone-s.png") no-repeat;width: 14px;height: 14px;display: inline-block;vertical-align: middle;margin-right: 0.5rem}
	.icon-mail-s{background: url("img/icons/mail-s.png") no-repeat;width: 14px;height: 14px;display: inline-block;vertical-align: middle;margin-right: 0.5rem}
	.icon-edit3{background: url("img/icons/edit3.png") no-repeat;width: 15px;height: 16px;display: inline-block;vertical-align: middle;margin-right: 0.4rem}
	
	.profiletop p.list-item-heading{font-size: 14px;font-weight: 600;line-height: 20px;color: #6884CC !important;}
	.profiletop p.text-muted{font-size: 16px;font-weight: bold;line-height: 24px;color: #0332AA !important;}
        
        .profilename {
    font-size: 24px;
    color: #181E29 !important;
    line-height: 36px;
}

.studid {
    font-size: 16px;
    display: block;
    line-height: 20px;
}

.btn-primary {
    color: #fff;
    background: linear-gradient(180deg, #4F70C4 0%, #1C47B3 100%);
    border: 1px solid #0332AA;
    box-sizing: border-box;
    width: auto;
}

.btn-primary:hover {
    color: #fff;
    background: linear-gradient(180deg, #0332AA 0%, #0332AA 100%);
    border: 1px solid #0332AA;
}
        <?php }?>  
	
	.marksheet p.list-item-heading{color: #6884CC;font-weight: 600;}
	.marksheet img{width: 100px;height: 130px;}
	.marksheet .gallery .col-2{position: relative;padding: 0;margin: 1rem;max-width: 10% !important}
	.marksheet .overlay{background: rgba(83, 100, 133,0.6) url(img/icons/eye.png) no-repeat center;width: 100%;height: 100%;position: absolute;border-radius: 0.75rem;top: 0;}
		
	.myprofile .img-thumbnail{width: 115px;height: 115px}
	
	.gallery a{text-align: center}
	.gallery a i{font-size: 4rem;padding: 1.5rem 0;display: block}
	.gallery a span.text{font-size: 10px;position: absolute;top: 28%;left: 14%;background: #ff0000;color: #fff;text-transform: uppercase;padding: 0px 7px;font-weight: bold;}
	
	@media (max-width:767px){
		
		.marksheet .gallery .col-2{max-width: 100% !important;}
	}
		
</style>


<main>
	<div class="container-fluid">
		<div class="row">
			<div class="col-12">

				<!--<div class="separator mb-5"></div>-->


			</div>

		</div>

		<div class="row coursedetails">

			<div class="col-12 mb-4 mt-4">
				<div class="card">
					<div class="card-body">
<?php if($qid === ""){?>
						<label style="color:#ff3c3c;font-weight: bold;font-size: 18px;margin-bottom: 0px;"><span style="color: #364159;">ATTENTION:</span> MUST CONFIRM YOUR QUALIFICATION DETAILS ENTERED, FOR ACTIVATING THE ADMISSION REQUEST.</label>
					<?php } else{ ?>
                                                <div class="col-md-12 col-sm-12 col-lg-9 col-12">
           
            <div class="d-flex flex-row">
             
				<a class="d-flex position-relative myprofile" href="#"><img alt="Profile" src="<?php if($stuprofile['profilepic']!="0" && $stuprofile['profilepic']!=""){ echo "docs/profilepic/".$sid."/".$stuprofile['profilepic']."?".time();}else{echo "img/myprofile.png?".time();} ?>" class="img-thumbnail border-0 rounded-circle mx-4 my-4 align-items-center"> <!--<span class="profileedit"><i class="icon-edit"></i></span>--></a>
             
              <div class="d-flex flex-grow-1 min-width-zero">
                <div class="card-body pl-0 py-2 align-self-center d-flex flex-column flex-lg-row justify-content-between min-width-zero">
                  <div class="w-100">
					  <p class="list-item-heading mb-2 truncate font-weight-bold profilename"><?php echo ucwords($stuprofile['stuname']); ?> <span class="studid">Student ID: <?php echo $stuprofile['studid'];?></span></p>
                    
                    <div class="row profiletop">

						<div class="col-md-4 text-left px-3">
							<p class="list-item-heading mb-2"><i class="icon-bookmark-s"></i> Class Studying</p>
							<p class="mb-2 text-muted <?php if($stuprofile['classstudy']=="" || $stuprofile['dob']=="0"){ echo "empty";} ?>"><?php if($stuprofile['classstudy']!=""){ echo ucwords($stuprofile['classstudy']);}else{echo "-Nil-";} ?></p>
						</div>

						<div class="col-md-3 text-left px-2">
							<p class="list-item-heading mb-2"><i class="icon-phone-s"></i> Phone</p>
							<p class="mb-2 text-muted"><?php if($stuprofile['sumcode']!=""){ echo $stuprofile['sumcode'];}else{echo $stuprofile['smcode'];}?> <?php echo $stuprofile['smobile']; ?></p>
						</div>

						<div class="col-md-5 text-left px-2">
							<p class="list-item-heading mb-2"><i class="icon-mail-s"></i> Mail</p>
							<p class="mb-2 text-muted"><?php echo strtolower($stuprofile['semail']); ?></p>
						</div>

					</div>
                 
                  </div>
                </div>
              </div>
            </div>
            
          </div>
                                                 <?php } ?>
					</div>
				</div>
			</div>

                   
                   
			<div class="col-12 mb-4">
				<div class="card">
					<div class="card-body">

						<div class="row courseinfo mb-5">

							<div class="col-md-8 col-sm-9 col-lg-8 col-12">

								<p class="list-item-heading">Course Name:</p>
								
								<h1 class="mb-2"><?php echo $course['coursename'];?></h1>

								<div class="row">

									<div class="col-md-3 col-sm-3 col-xs-3 text-left border-right px-3">
										<img alt="Profile" src="<?php echo base_url();?>img/icons/clock.png" class="img-thumbnail border-0 mb-2">
										<p class="list-item-heading mb-1">Duration</p>
										<p class="mb-4 text-muted"><?php echo $course['duration'];?></p>
									</div>

									<div class="col-md-3 col-sm-4 col-xs-4 text-left border-right px-4">
										<img alt="Profile" src="<?php echo base_url();?>img/icons/invoice.png" class="img-thumbnail border-0 mb-2">
										<p class="list-item-heading mb-1">Center</p>
										<p class="mb-4 text-muted"><?php echo $qualification['center'];?></p>
									</div>

									<div class="col-md-6 col-sm-5 col-xs-5 text-left px-4">
										<img alt="Profile" src="<?php echo base_url();?>img/icons/refresh-cw.png" class="img-thumbnail border-0 mb-2">
										<p class="list-item-heading mb-1">Qualification Details</p>
										<p class="mb-4 text-muted"><?php echo $course['qname'];?></p>
									</div>

								</div>

							</div>

							<div class="col-md-4 col-sm-3 col-lg-4 col-12 text-right">
								
								<p class="list-item-heading">Total Fee:</p>
								<p class="totalfee"><?php echo $qualification['total'];?></p>
						
							</div>

						</div>


						<div class="separator mb-4"></div>
						
						
						<div class="row mb-4">

							<div class="col-md-4 col-4 text-left">
                                                            <?php if($qid === "") {?>
								<a href="stuqualifyupdate?ide=<?php echo $qualification['ide'];?>&type=edit" title=""><button class="btn btn-outline-primary back">Back</button></a>
                                                            <?php } else {?> 
                                                                <a href="stuqualifyupdate?ide=<?php echo $sid;?>&cride=<?php echo $qualification['ide'];?>&qid=<?php echo $qid;?>" title=""><button class="btn btn-outline-primary back">Back</button></a>
                                                            <?php }?> 
							</div>
                                                    
							<div class="col-md-8 col-8 text-right justify-content-end">
							
								<div class="row crequestbtn">
								
                                	<div class="col-md-12 col-sm-12">
                                 		<button class="btn btn-primary confirm">Confirm Request</button>
									</div>
                                 
                                 </div>

							</div>
                                                   

						</div>


						<div class="separator mb-5"></div>


						<div class="row yearfee">


							<div class="col-md-7 col-sm-6 mb-4">

								<p class="first"> <?php echo $qualification['class'];?> details</p>

								<div class="d-block w-100 p-0">

									<div class="row">

										<div class="col-md-5 col-5">
											<p>Year of Passing:</p>
										</div>

										<div class="col-md-7 col-7">
											<p><?php echo $qualification['yearofpassing'];?></p>
										</div>

									</div>

									<div class="row">

										<div class="col-md-5 col-5">
											<p>Class Name:</p>
										</div>

										<div class="col-md-7 col-7">
											<p><?php echo $qualification['class'];?></p>
										</div>

									</div>

									<div class="row">

										<div class="col-md-5 col-5">
											<p>Board of Exams:</p>
										</div>

										<div class="col-md-7 col-7">
											<p><?php echo $qualification['stream'];?></p>
										</div>

									</div>

									<div class="row">

										<div class="col-md-5 col-5">
											<p>Status:</p>
										</div>

										<div class="col-md-7 col-7">
											<p><?php 
                                                                                        if($qualification['status'] === 'P') { echo 'Passed';}
                                                                                        else if($qualification['status'] === 'WFR') { echo 'Waiting For Result';}
                                                                                        else if($qualification['status'] === 'C') { echo 'Completed';}
                                                                                       ?>
                                                                                        </p>
										</div>

									</div>

									<div class="row">

										<div class="col-md-5 col-5">
											<p>Roll Number:</p>
										</div>

										<div class="col-md-7 col-7">
											<p><?php echo $qualification['rollno'];?></p>
										</div>

									</div>

									<div class="row">

										<div class="col-md-5 col-5">
											<p>Grace Mark:</p>
										</div>

										<div class="col-md-7 col-7">
                                                                                        <p><?php if($qualification['gracemark'] != '') {echo ($qualification['gracemark'] === 'y')?"Yes":"No";}?></p>
										</div>

									</div>
								</div>
							</div>

                                                                <?php
                                                                
                                                                if($qualification['subject'] !== '') {
                                                                    
                                                                    $subject = explode("|",$qualification['subject']);
                                                                    $mark = ($qualification['mark'] !== '')? explode("|",$qualification['mark']):"";
                                                                    $grade = ($qualification['grade'] !== '')? explode("|",$qualification['grade']):"";
                                                                    
                                                                    
                                                                    
                                                                    ?>
							<div class="col-md-4 col-sm-6 mb-4">

								<p class="first"> <?php echo $qualification['class'];?> Marksheet</p>

								<div class="card d-flex d-block w-100 p-3">
                                                                    
                                                                   <?php 
                                                                   
                                                                   for($i = 0 ; $i < count($subject);$i++) {
                                                                   if($subject[$i] ==='') { continue;}
                                                                       $con = ($mark !== '')?$mark[$i]:$grade[$i];
                                                                        echo '<div class="row">

										<div class="col-md-5 col-5">
											<p>'.$subject[$i].':</p>
										</div>

										<div class="col-md-7 col-7">
											<p>'.$con.'</p>
										</div>

									</div>';
                                                                    }
                                                                   
                                                                   ?>
								
								</div>
							</div>
                                                    
                                                    <?php } ?>

						</div>


						<div class="separator mb-5"></div>

                                                <?php if($qualification['xii_yearofpassing'] !== '') {?>
						<div class="row yearfee">


							<div class="col-md-5 mb-4">

								<p class="first"> <?php echo $qualification['xii_class'];?> details</p>

								<div class="d-block w-100 p-0">

									<div class="row">

										<div class="col-md-5 col-5">
											<p>Year of Passing:</p>
										</div>

										<div class="col-md-7 col-7">
											<p><?php echo $qualification['xii_yearofpassing']; ?></p>
										</div>

									</div>

									<div class="row">

										<div class="col-md-5 col-5">
											<p>Class Name:</p>
										</div>

										<div class="col-md-7 col-7">
											<p><?php echo $qualification['xii_class']; ?></p>
										</div>

									</div>

									<div class="row">

										<div class="col-md-5 col-5">
											<p>Board of Exams:</p>
										</div>

										<div class="col-md-7 col-7">
											<p><?php echo $qualification['xii_stream']; ?></p>
										</div>

									</div>

									<div class="row">

										<div class="col-md-5 col-5">
											<p>Status:</p>
										</div>

										<div class="col-md-7 col-7">
											<p><?php 
                                                                                        if($qualification['xii_status'] === 'P') { echo 'Passed';}
                                                                                        else if($qualification['xii_status'] === 'WFR') { echo 'Waiting For Result';}
                                                                                        else if($qualification['xii_status'] === 'C') { echo 'Completed';}
                                                                                       ?>
                                                                                        </p>
										</div>

									</div>

									<div class="row">

										<div class="col-md-5 col-5">
											<p>Roll Number:</p>
										</div>

										<div class="col-md-7 col-7">
											<p><?php echo $qualification['xii_rollno']; ?></p>
										</div>

									</div>

									<div class="row">

										<div class="col-md-5 col-5">
											<p>Grace Mark:</p>
										</div>

										<div class="col-md-7 col-7">
											<p><?php if($qualification['xii_gracemark'] != '') {echo ($qualification['xii_gracemark'] === 'y')?"Yes":"No";}?></p>
										</div>

									</div>
								</div>
							</div>

                                                                <?php
                                                                
                                                                if($qualification['xii_subject'] !== '') {
                                                                    
                                                                    $xii_subject = explode("|",$qualification['xii_subject']);
                                                                    $xii_mark = ($qualification['xii_mark'] !== '')? explode("|",$qualification['xii_mark']):"";
                                                                    $xii_grade = ($qualification['xii_grade'] !== '')? explode("|",$qualification['xii_grade']):"";
                                                                    
                                                                    
                                                                    
                                                                    ?>
							<div class="col-md-4 mb-4">

								<p class="first"> <?php echo $qualification['xii_class'];?> Marksheet</p>

								<div class="card d-flex d-block w-100 p-3">

									<?php 
                                                                   
                                                                   for($i = 0 ; $i < count($xii_subject);$i++) {
                                                                   if($xii_subject[$i] ==='') { continue;}
                                                                       $con = ($xii_mark !== '')?$xii_mark[$i]:$xii_grade[$i];
                                                                        echo '<div class="row">

										<div class="col-md-5 col-5">
											<p>'.$xii_subject[$i].':</p>
										</div>

										<div class="col-md-7 col-7">
											<p>'.$con.'</p>
										</div>

									</div>';
                                                                    }
                                                                   
                                                                   ?>

									
								</div>
							</div>
                                                <?php } ?>

						</div>

						<div class="separator mb-5"></div>
                          
                           <?php } ?>


						<div class="row yearfee">


							   <?php
                                                                                                                      
                                                            if($qualification['entrance_name'] != "") {
                                                                
                                                                $examArr1 = explode("|", $qualification['entrance_name']);
                                                                $examArr2 = explode("|", $qualification['entrance_mark']);
                                                                $examArr3 = explode("|", $qualification['entrance_regno']);
                                                                
                                                                foreach ($examArr1 as $key => $value) {
                                                                    
                                                                    if($value === "") {continue;}
                                                            
                                                            echo '<div class="col-md-5 mb-4">
                                                            

								<p class="first">'.$value.' - Entrance Exam</p>

								<div class="d-block w-100 p-0">

									<div class="row">

										<div class="col-md-5">
											<p>Rank/Mark:</p>
										</div>

										<div class="col-md-7">
											<p>'.$examArr2[$key].'</p>
										</div>

									</div>

									<div class="row">

										<div class="col-md-5">
											<p>Registration Number:</p>
										</div>

										<div class="col-md-7">
											<p>'.$examArr3[$key].'</p>
										</div>

									</div>


								</div>
							</div>';
                                                                }
                                                            }
                                                            
                                                            ?>
						</div>

						
						<?php
		
						
								if(isset($sid)) $userid = $sid; else $userid = $user['id'];
								
								$marksheets = $qualification['marksheets'];
								$marksheetsarr = explode('|',$marksheets);

								$marksheetlist = "";
								foreach($marksheetsarr as $marksheet){

									$ext = end(explode(".",$marksheet));

									if(strtolower($ext)!="pdf"){
										$marksheetlist .= '<div class="col-2"><a href="docs/courserequest/marksheets/'.$userid.'/'.$marksheet.'?'.time().'"><img class="img-fluid border-radius" src="docs/courserequest/marksheets/'.$userid.'/'.$marksheet.'?'.time().'"><div class="overlay"></div></a></div>';
									}
									else{
										$marksheetlist .= '<div class="col-2"><a href="docs/courserequest/marksheets/'.$user['id'].'/'.$marksheet.'?'.time().'" target="_blank"><span class="text">pdf</span><i class="glyph-icon simple-icon-doc"></i><div class="overlay"></div></a></div>';
									}

								}
			
							?>
        
							<?php if($marksheets!="" && $marksheets!="0"){?>
						   
						   <div class="mb-4 marksheet">

								<div class="row">

									  <div class="col-12">

											<p class="list-item-heading pb-2">Marksheets:</p>

											<div class="row gallery px-4 mb-4">
											  <?php echo $marksheetlist;?>
											</div>

									  </div>

								 </div>

							</div> 

							<?php }?> 
        
						<div class="mb-5"></div>

						<div class="row">

							<div class="col-md-4 col-4 text-left">
								<?php 
								
								$qeparams = "";
								if($qwfr=="y") $qeparams = "&wfr=y";
								
								if($qid === "") {
								
								?>
									<a href="stuqualifyupdate?ide=<?php echo $qualification['ide'];?>&type=edit<?php echo $qeparams;?>" title=""><button class="btn btn-outline-primary back">Back</button></a>
								<?php } else {?> 
                                	<a href="stuqualifyupdate?ide=<?php echo $sid;?>&cride=<?php echo $qualification['ide'];?>&qid=<?php echo $qid;?>" title=""><button class="btn btn-outline-primary back">Back</button></a>
								<?php }?> 
							</div>
                                                    
							<div class="col-md-8 col-8 text-right justify-content-end">
							
								<div class="row crequestbtn">
								
									<div class="col-md-6 col-sm-6">
										<span class="response" style="margin: 0px auto; float:right;width: 50%; height: 30px;margin-top:20px"></span>
									</div>
                                	<div class="col-md-6 col-sm-6">
                                 		<button class="btn btn-primary confirm">Confirm Request</button>
									</div>
                                 
                                 </div>

							</div>
                                                   

						</div>


					</div>

				</div>
			</div>
		</div>

	</div>


	</div>
	
	<style>

	.courseredirect{background: #3CAF92 !important;display: block;margin: auto;border: 1px solid #209679;}
	h5.modal-title p.headtitle{display: inline-block;width: 100%;text-align: center;font-weight: bold;font-size: 24px;line-height: 36px;color: #3CAF92;}
	h5.modal-title p.text-muted{display: inline-block;width: 100%;text-align: center;font-weight: 600;font-size: 14px;line-height: 36px;color: #181E29;line-height: 20px;}
	.modal-title img{display: block;margin: 1em auto}
	
</style>


<button type="button" class="btn btn-outline-primary d-none courseconfirm" data-toggle="modal" data-backdrop="static" data-target="#courseModal">Confirm Submission</button>  
<!-- Modal -->
<div class="modal fade" id="courseModal" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog" role="document">
	<div class="modal-content">
	  <div class="modal-header">
	  
		<h5 class="modal-title" id="exampleModalLabel">
		
			<!--img src="<?php echo base_url(); ?>/img/icons/round-tick.png" class="mb-4" /--> 
			
			<p class="headtitle mb-4">Successful!</p>
		
			<p class="text-muted mb-4">Your request for course registration has been sent successfully! We’ll update you soon.</p>
		</h5>
		<!--<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>-->
	  </div>
	  
	  <div class="modal-footer">
		<button type="button" class="btn btn-primary courseredirect px-5" data-dismiss="modal">Okay</button>
	  </div>
	</div>
  </div>
</div>
</main>

<?php
if($this->session->userdata('loggedin') && $this->session->userdata('adlog_in')){
?>
<script src="<?php echo base_url();?>js/pala.script.js?v=1.96"></script>
<script src="<?php echo base_url();?>js/scripts.js?v=1.9"></script>
<?php } ?>
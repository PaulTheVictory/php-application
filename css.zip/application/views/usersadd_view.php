 <link href="<?php  echo base_url(); ?>css/jquery-ui.min.css?v=1.4" rel="stylesheet" type="text/css" />
 <script src="<?php  echo base_url(); ?>js/jquery-ui.min.js?v=1.3" type="text/javascript"></script>
 <link href="<?php  echo base_url(); ?>css/chosen.min.css?v=1.3" rel="stylesheet" type="text/css" />
  <script src="<?php  echo base_url(); ?>js/chosen.jquery.min.js?v=1.2" type="text/javascript"></script>
 <style type="text/css">
     
     .ui-selectmenu-button.ui-button{ width: 97%; padding:13px;}
     #ugroups-button,#msession-button{border: 1px solid #D7DFF0;background: #fff;font-size: 14px;color:#536485;padding: 10px}
     .maincontent ul li.search-choice { height:auto; }
     .maincontent ul li.search-choice a{ height:auto; font-size: 14px;color:#536485}
     .response p { float: right;font-size:12px;color:#eb345e;}
     

#centers_chosen,#lcenters_chosen {border: 1px solid #D7DFF0;background: #fff;padding: 8px 0px;}
#ucourses_chosen  {border: 1px solid #D7DFF0;background: #fff;padding: 8px 0px;}
 .chosen-container-multi .chosen-choices {border: 0px;background: none}

.sortable tr td a:hover { text-decoration: underline; }
.sortable tr td span{ font-size: 14px;color: #364159 }
 .chosen-container-multi .chosen-choices li.search-choice { background: #6884CC;border-radius: 5px;}
.chosen-container-multi .chosen-choices li.search-choice {color: #fff;}

 </style>

	<div class="wrap dynamic-width" style="float: left;position: relative;min-width: 800px">
     <div style="margin-top: 10px; width: 99%; height: 50px; text-align: right;">
         <span style="font-weight: bold;font-size: 20px;padding: 10px;float:left;color: #364159">Add User</span>
         
     </div>         
            <div id="course-container" class="add-course">
<?php echo form_open('useradd/userSubmit', array('id' => 'userForm')) ?>
                 <div class="row-element">
                    <span class="title">Name</span>
                    <span class="content"><input placeholder="Name" type="text" value="" name = "pname" class="pname"></span>
                </div>
                <div class="row-element">
                    <span class="title">User Name</span>
                    <span class="content"><input style="width:50%" placeholder="User Name" type="text" value="" name = "uname" class="uname">@brilliantpala.org</span>
                </div>
                <div class="row-element">
                    <span class="title">Email Address</span>
                    <span class="content"><input placeholder="Email Address" type="text" value="" name = "uemail" class="uemail"></span>
                </div>
                <div class="row-element">
                    <span class="title">Mobile Number</span>
                    <span class="content"><input placeholder="Phone Number" type="text" value="" name = "umobile" class="umobile"></span>
                </div>
                 <div class="row-element">
                    <span class="title" >User Group</span>
                    <span class="content">
                        <select id="ugroups" name = "ugroups" class="ugroups" style="font-size: 13px;float:left">
                           <option value="">Select User Group</option>
                            <?php echo $groups;?>
                        </select>
                                              
                    </span>
                </div>
                
                 <div class="row-element baccess">
                    <span class="title" id="scity ">Batch Access</span>                    
                    <span class="content"><select multiple id="ucourses" style="width: 100%;font-size: 13px;float:left">
                            <option value="All">All</option>
                            <?php echo $courses;?>
                        </select></span>
                    <input type="hidden" name="ucourses" class="ucourses" />
                </div>
                <div class="row-element ccaccess">
                    <span class="title" id="scity">Collection Center Access</span>                    
                    <span class="content"><select multiple id="centers"  style="width: 100%;font-size: 13px;float:left">
                            <option>All</option>
                            <?php echo $centers;?>
                        </select></span>
                    <input type="hidden" name="ucenters" class="ucenters" />
                </div>
                <div class="row-element laccess">
                    <span class="title" id="scity">Library Center Access</span>                    
                    <span class="content"><select multiple id="lcenters"  style="width: 100%;font-size: 13px;float:left">
                            <option>All</option>
                            <?php echo $lcenters;?>
                        </select></span>
                    <input type="hidden" name="lcenters" class="lcenters" />
                </div>
                <div class="row-element">
                    <span class="title" id="scity">Multi Session</span>                    
                    <span class="content"><select id="msession"  name ="msession" style="width: 100%;font-size: 13px;float:left">
                            <option value="y">Yes</option>
                            <option value="n">No</option>
                        </select></span>
                </div>
                
            <?php echo form_close() ?>
                
            </div>
            
       
     <div style="margin-top: 0px; width: 98%; height: 70px; text-align: right;">
         <span  style="margin: 0px auto; float:right;margin-top: 18px;padding: 10px; color: #fff; background: #4f6fc4 none repeat scroll 0% 0%; border-radius:5px;cursor: pointer" class="btn savebtn" href="#">Save</span>
         <a style="margin: 0px auto; float:right;margin-top: 18px;margin-right:18px;padding: 9px 10px; color: #0332AA; background: linear-gradient(0deg, #FFFFFF, #FFFFFF), #C4C4C4;border: 1px solid #0332AA; border-radius:5px" class="btn" href="<?php echo base_url(); ?>users">Back</a>
         <span class="response" style="margin: 0px auto; float:right;width: 80%; height: 30px;margin-top:20px"></span>
     </div>   
    
        
        </div>
    
      

    
<script type="text/javascript">
$(document).ready(function() {
    
    $(".ugroups").selectmenu();$("#msession").selectmenu();
    $("#ucourses").chosen();
    $("#centers").chosen();$("#lcenters").chosen();
    $(".ccaccess").fadeOut();
    $(".baccess").fadeOut();
     $(".laccess").fadeOut();
    
    $(document).delegate(".ugroups","selectmenuchange",function(event){
                
        var ctype = $('option:selected', this).attr('data-type');
        if(ctype === "A"){ $(".baccess").fadeIn();$(".ccaccess").fadeOut();$(".laccess").fadeOut();}
        if(ctype === "F"){ $(".baccess").fadeOut();$(".ccaccess").fadeIn();$(".laccess").fadeOut();}
        if(ctype === "B"){ $(".baccess").fadeIn();$(".ccaccess").fadeIn();$(".laccess").fadeIn();}
        if(ctype === "L"){ $(".baccess").fadeOut();$(".ccaccess").fadeOut();$(".laccess").fadeIn();}

    });
    
    $("#centers_chosen").find(".chosen-search-input").val("Select Centers");
    $("#ucourses_chosen").find(".chosen-search-input").val("Select Courses");
    $("#lcourses_chosen").find(".chosen-search-input").val("Select Library Centers");
    
    $(".savebtn").click(function(){
        
                var uname = $(".uname").val();
                uname = uname+"@brilliantpala.org";
                var validRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@(brilliantpala.org)$/;  
                var receivedEmail = uname.trim();  
                if (!(receivedEmail.toLowerCase().match(validRegex))) {  
                    alert("Please enter valid user name with brilliant pala email address.");  
                    return;  
                } 
                
                var uemail = $(".uemail").val();               
                var validRegex1 = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;  
                var rEmail = uemail.trim();  
                if (!(rEmail.toLowerCase().match(validRegex1))) {  
                    alert("Please enter valid email address.");  
                    return;  
                } 
         
               if($(".response").hasClass('progress')) { return;}
               $(".response").html('').text('Progressing...');
                $(".response").addClass('progress');
               var centers = ""; var lcenters = "";var courses = "";
               $("#centers_chosen").find("li span").each(function(){
                   
                   if($(this).text() === "All") { centers = $(this).text();}else {
                        centers += $(this).text()+"|";
                   }
               });
               
               $("#lcenters_chosen").find("li span").each(function(){
                   
                   if($(this).text() === "All") { lcenters = $(this).text();}else {
                        lcenters += $(this).text()+"|";
                   }
               });
               
               $("#ucourses_chosen").find("li span").each(function(){
                   var txt = $(this).text();
                   var cid = $("option").filter(function() { return $(this).html() === txt; }).val();
                   if(cid === "All") { courses = cid;}else {
                        courses += cid+"|";
                   }
               });
               $(".ucenters").val(centers);$(".lcenters").val(lcenters);
               $(".ucourses").val(courses);               
               
                var userForm = $("#userForm");

                    $.ajax({
                        url: userForm.attr('action'),
                        type: 'post',
                        data: userForm.serialize(),
                        success: function(o){
                            
                            var response = $.parseJSON(o);
                            $(".response").html('');
                            if(response.status === 'success') {
                       
                              $(".response").css("color","rgb(25, 71, 15)");
                              $(".response").text(response.message);
                              $(location).prop('href', 'users');
                               
                            } else {
                                
                               $(".response").append(response.message); 
                               $(".response").removeClass('progress');
                           
                            }

                        }
                    });
                   
                              
            });
	
	
});
</script>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Brilliant Study Centre, Pala</title>
<!--<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1">-->

<link rel="stylesheet" href="<?php echo base_url();?>css/boot/bootstrap.min.css">
<link rel="stylesheet" href="<?php echo base_url();?>css/boot/bootstrap.rtl.only.min.css">
<link rel="stylesheet" href="<?php echo base_url();?>css/boot/bootstrap-float-label.min.css">
<link rel="stylesheet" href="<?php echo base_url();?>css/boot/main.css">

<script src="<?php echo base_url();?>js/jquery-3.5.1.min.js"></script>


<script type="text/javascript">
$(document).ready(function(){
	
		
	window.print();

});
</script>

<style>
		
	.feebill h1{font-size: 18px;color: #364159;}
	.feebill .card{background: linear-gradient(0deg, #FFFFFF, #FFFFFF), #C4C4C4;box-shadow: 0px 0px 7px rgba(196, 196, 196, 0.35);border-radius: 0px;width: 100%;border-bottom: 11px solid #0332AA;}
	.feebill h2{color: #0332AA;font-size: 24px;font-weight: bold;line-height: 36px;}
	.feebill h3{color: #181E29;font-size: 16px;font-weight: bold;line-height: 24px;}
	.feebill h4{font-size: 12px;font-weight: bold;color: #355BBB;line-height: 20px;letter-spacing: 0.5px;text-transform: uppercase;}
	.feebill p.list-item-heading{color: #6884CC;font-weight: 600;}
	.feebill p.list-item-heading span:last-child{font-weight: 600;font-size: 14px;color: #364159;}
	.feebill p{color: #181E29;font-size: 14px;line-height: 18px;font-weight: normal;margin-bottom: 5px;}		
	.border-right{border-right: 1px solid #D7DFF0!important;}
		
	p.totalfee {font-weight: bold;font-size: 24px;color: #D63333;}
	
	.table{border: 0px solid #364159;border-collapse: separate !important;border-style: solid;border-radius: 10px;box-shadow: 0 0 0 0px #364159;margin: 1rem; table-layout: fixed;border-spacing: 0px;}
	.table thead th{font-size: 12px;font-weight: 600;color: #6F83AA;letter-spacing: 0.5px;background: #E6EBF7;text-transform: none;padding: 0.5rem;text-align: center;vertical-align: middle;border-bottom: 1px solid #364159;}
	.table thead tr th:first-child{border-top-left-radius: 10px;border-top: 0px solid #364159;}
	.table thead tr th:last-child{border-top-right-radius: 10px}
	.table td, .table th{font-size: 14px;border-top: 0px solid #364159;padding: 0.9rem 0.75rem;color: #364159;font-weight: 600;}
	.thtax{display: block;text-align: center;}
	.thtaxvalue{display: flex;}
	.thtaxvalue span:first-child{width: 53%}
	
	
.table {
    border: 1px solid #364159;
    -moz-border-radius: 10px;
    -webkit-border-radius: 10px;
    border-radius: 10px;
}
.table th {
    border-left: 0px solid #364159;
    border-top: 1px solid #364159;
    padding: 10px;
    text-align: center;
}

.table td {
    border-right: 1px solid #364159;
    text-align: right;
}
.table tr th:first-child{border-top: 1px solid #364159;border-radius: 0px;}
.table th {
    background-color: transparent;
    border-top: none;
}
.table td:first-child, .table th:first-child {
    border-left: none;
}
.table th:first-child {
    -moz-border-radius: 10px 0 0 0;
    -webkit-border-radius: 10px 0 0 0;
    border-radius: 10px 0 0 0;
}
.table th:last-child {
    -moz-border-radius: 0 10px 0 0;
    -webkit-border-radius: 0 10px 0 0;
    border-radius: 0 10px 0 0;
}
.table th:only-child{
    -moz-border-radius: 10px 10px 0 0;
    -webkit-border-radius: 10px 10px 0 0;
    border-radius: 10px 10px 0 0;
}
.table tr:last-child td:first-child {
    -moz-border-radius: 0 0 0 10px;
    -webkit-border-radius: 0 0 0 10px;
    border-radius: 0 0 0 10px;
}
.table tr:last-child td:last-child {
    -moz-border-radius: 0 0 10px 0;
    -webkit-border-radius: 0 0 10px 0;
    border-radius: 0 0 10px 0;
    
} 
	
	.table td.totalfee {font-weight: bold;font-size: 16px;color: #D63333;}
	.table td.totalamt {font-weight: bold;font-size: 12px;color: #6F83AA;letter-spacing: 0.5px;text-transform: uppercase;text-align: right !important}
	.table tr:last-child td{text-align: center}
	.table tr td:last-child,.table tr th:last-child{text-align: center}
	.table tr:last-child td:last-child{font-weight: bold;text-align: center}
	.table tr:last-child{text-align: center}
	
	.feebill .hr{width: 100%;height: 3px;background: #0332AA;}
	
	main{max-width: 100%;margin: auto}
	
</style>


<?php 

$grandtotal = $refundbill['refundtotal'];

function getIndianCurrency(float $number)
{
    $decimal = round($number - ($no = floor($number)), 2) * 100;
    $hundred = null;
    $digits_length = strlen($no);
    $i = 0;
    $str = array();
    $words = array(0 => '', 1 => 'one', 2 => 'two',
        3 => 'three', 4 => 'four', 5 => 'five', 6 => 'six',
        7 => 'seven', 8 => 'eight', 9 => 'nine',
        10 => 'ten', 11 => 'eleven', 12 => 'twelve',
        13 => 'thirteen', 14 => 'fourteen', 15 => 'fifteen',
        16 => 'sixteen', 17 => 'seventeen', 18 => 'eighteen',
        19 => 'nineteen', 20 => 'twenty', 30 => 'thirty',
        40 => 'forty', 50 => 'fifty', 60 => 'sixty',
        70 => 'seventy', 80 => 'eighty', 90 => 'ninety');
    $digits = array('', 'hundred','thousand','lakh', 'crore');
    while( $i < $digits_length ) {
        $divider = ($i == 2) ? 10 : 100;
        $number = floor($no % $divider);
        $no = floor($no / $divider);
        $i += $divider == 10 ? 1 : 2;
        if ($number) {
            $plural = (($counter = count($str)) && $number > 9) ? 's' : null;
            $hundred = ($counter == 1 && $str[0]) ? ' and ' : null;
            //$str [] = ($number < 21) ? $words[$number].' '. $digits[$counter]. $plural.' '.$hundred:$words[floor($number / 10) * 10].' '.$words[$number % 10]. ' '.$digits[$counter].$plural.' '.$hundred;
			$str [] = ($number < 21) ? $words[$number].' '. $digits[$counter].' '.$hundred:$words[floor($number / 10) * 10].' '.$words[$number % 10]. ' '.$digits[$counter].' '.$hundred;
        } else $str[] = null;
    }
    $Rupees = implode('', array_reverse($str));
    $paise = ($decimal > 0) ? "." . ($words[$decimal / 10] . " " . $words[$decimal % 10]) . ' Paise' : '';
    //return ($Rupees ? $Rupees . 'Rupees ' : '') . $paise;
	return (ucwords($Rupees) ? ucwords($Rupees) : '') . ucwords($paise);
}

?>
<main>

	<div class="container-fluid">
		
	<div class="row feebill">
								
		<div class="card mb-2 p-4">
		
			<div class="row">
					
		
                            <div class="col-md-4">
			
				
									
			</div>
                            <div class="col-md-4">
			
				
                                <h3 style="font-size:24px;text-align: center">Brilliant Study Centre, Pala.</h3>
                                <p style="font-size:16px;text-align: center"><strong >Payment Voucher</strong></p>
									
			</div>
			<div class="col-md-4 text-right">
		
			</div>
			
		
		</div>
			
			<div class="hr mt-1 mb-2"></div>
			
		<div class="row">
			
			<div class="col-md-6">
                                
				
				<p>Student Id: <strong><?php echo $refundbill['studid']; ?></strong></p>
				<p class="mb-0">Student: <strong><?php echo strtoupper($refundbill['studentdetails']['name']); ?></strong></p>
				
				<?php if(!empty($refundbill['studentdetails'])){ ?>
				
				<div class="row">
					<div class="col-md-1"></div>
					<div class="col-md-6">
						<p><?php echo $refundbill['studentdetails']['housenameno']." ".$refundbill['studentdetails']['contactaddress'].", ".$refundbill['studentdetails']['contactpost'].", ".$refundbill['studentdetails']['contactdistrict'].", ".$refundbill['studentdetails']['contactstate'].", ".$refundbill['studentdetails']['contactcountry']." ".$refundbill['studentdetails']['contactpincode'].'.'; ?></p>
					</div>
				</div>
				
				<?php }?>
				
			</div>
			<div class="col-md-6 text-right">
				
				<p>Course:  <strong>[<?php echo $refundbill['coursename']; ?>, <?php echo $refundbill['center']; ?>]</strong></p>
				<p>Dated : <strong><?php echo date("d-m-Y h:i A",strtotime($refundbill['created_at'])); ?></strong></p>
			</div>
			
		</div>	
		
		<div class="row mb-2">
		
		 <table class="table">
              <thead>
                <tr>
                  <th scope="col" width="80%">Particulars</th>
                  <th scope="col" width="10%">Rs</th>
                  <th scope="col" width="10%">Ps</th>
                </tr>
              </thead>
              <tbody>
               
               
               <?php //echo $tablepay;?>
                  
                  <tr>
                  <td scope="col" width="80%">Fee Refund </td>
                  <td scope="col" width="10%"><?php echo $refundbill['refundamount'];?></td>
                  <td scope="col" width="10%" ></td>
                </tr>
               
                <tr>
                  <td scope="col" width="80%">CGST</td>
                  <td scope="col" width="10%"><?php echo $refundbill['cgst'];?></td>
                  <td scope="col" width="10%" ><?php echo $refundbill['pcgst'];?></td>
                </tr>
                 <tr>
                  <td scope="col" width="80%">SGST</td>
                  <td scope="col" width="10%"><?php echo $refundbill['sgst'];?></td>
                  <td scope="col" width="10%" ><?php echo $refundbill['psgst'];?></td>
                </tr>
                 <tr>
                  <td scope="col" width="80%">CD Refund</td>
                  <td scope="col" width="10%"></td>
                  <td scope="col" width="10%"></td>
                </tr>
                

                <tr>
                    <td style="border-top: 1px solid #364159;text-align:right" scope="col" width="80%">Grand total</td>
                  <td  colspan="" style="border-top: 1px solid #364159;" class="totalamt"><?php echo $grandtotal; ?></td>
                  <td style="border-top: 1px solid #364159;" class="totalfee"></td>
                </tr>
              </tbody>
            </table>
            
			</div>
          
           
			<p class="mb-2">Total Amount Paid: <strong>Rs.<?php echo number_format($grandtotal); ?>/- (<?php echo getIndianCurrency($grandtotal); ?> Only)</strong></p>

			<p class="mb-2">Payment Mode: <strong><?php echo strtoupper($refundbill['paymode']); ?></strong></p>
                        <?php    
                       
                        if($refundbill['paycheque'] !== ''){
                            echo '<p class="mb-2">Cheque Number : <strong>'.$refundbill['paycheque'].'</strong></p>';
                            echo '<p class="mb-2">Cheque Date : <strong>'.$refundbill['paydate'].'</strong></p>';
                        }
                        ?>

			<p class="mb-2">Reference No. : <strong><?php echo $refundbill['receiptno']; ?></strong></p>            
            
            <div class="row d-flex align-items-end mt-3 mb-0">
			
			<div class="col-md-6">
			
				<!--<img src="<?php //echo base_url(); ?>img/bill-barcode.png" alt="Barcode" width="30%" class="mb-3" />-->
				
			</div>
			<div class="col-md-6 text-right">
				
				<h4>Signature</h4>
				
			</div>
			
		</div>

            
			</div>
			
		</div>
		
		<div class="mt-0 mb-2 w-100" style="border-bottom: 1px dashed #dee2e6!important;"></div>
		
		<div class="billclone"></div>
		

	</div>
</main>
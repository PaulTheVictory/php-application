<link rel="stylesheet" href="<?php echo base_url();?>css/boot/vendor/dataTables.bootstrap4.min.css">
<link rel="stylesheet" href="<?php echo base_url();?>css/boot/vendor/datatables.responsive.bootstrap4.min.css">
<script src="<?php echo base_url();?>js/vendor/datatables.min.js"></script>

<script type="text/javascript">
$(document).ready(function(){
	
	var qualificationid = "<?php echo $user['qualificationid'];?>";
	var qualifyid = "<?php echo $qualifyid; ?>";
	
	if(qualifyid!="") $(".qualification").val(qualifyid);
	//else $(".qualification").val(qualificationid);
	
	$(".qualification option:first-child").text("Search for other courses");

	$(".coursetype .card").click(function(){
		
		$(".coursetype .card").removeClass('active');
		
		$(this).addClass('active');
		
	});
	
	
	$(".coursesearch").click(function(){
		
		var type = $(".coursetype option:selected").val();
		var schedule = $(".schedule option:selected").val();
		var center = $(".center option:selected").val();
		var duration = $(".duration option:selected").val();
		
		var searchpara = [];
		if(type!="") searchpara['type']=type;
		if(schedule!="") searchpara['schedule'] = schedule;
		if(center!="") searchpara['center'] = center;
		if(duration!="") searchpara['duration'] = duration;
		
		var searchparaurl = arrayToQueryString(searchpara);
		
		 window.location.href= "?"+searchparaurl;
		
	});
	
	$(".coursereset").click(function(){
		
		 window.location.href= "stucourses";
		
	});
	
	
	var coursetype = "<?php echo $type;?>";
	var schedule = "<?php echo $schedule;?>";
	var center = "<?php echo $center;?>";
	var duration = "<?php echo $duration;?>";
	
	$(".coursetype").val(coursetype);
	$(".schedule").val(schedule);
	$(".center").val(center);
	$(".duration").val(duration);
	
	
	$(".qualification").change(function(){
		
		var qualification = $(this).val();
		var searchpara = [];		
		if(qualification!="") searchpara['qid']=qualification;
		
		var searchparaurl = arrayToQueryString(searchpara);
		
		 window.location.href= "?"+searchparaurl;
		
	});
	
	
	$(".regnowbtn").click(function(e){
		
		var qualificationid = "<?php echo $user['qualificationid'];?>";
		var qid = $(this).data('qid');
		
		//console.log(qualificationid+ ' - '+qid);
		
		if(qualificationid!=qid){
			e.preventDefault();
			var r = confirm("Your are not eligible for this course. Please update your qualification.");
			
			if(r){
				location.assign('updatequalification');
			}
		}
		
	});

	
});
	
function arrayToQueryString(array_in){
    var out = new Array();

    for(var key in array_in){
        out.push(key + '=' + encodeURIComponent(array_in[key]));
    }

    return out.join('&');
}
	
</script>

<style>

	.coursetype .card{box-shadow: 0px 0px 7px rgba(196, 196, 196, 0.35);background: linear-gradient(0deg, #FFFFFF, #FFFFFF), #C4C4C4;cursor: pointer;border: 2px solid transparent;transition: all ease 0.3s}
	.rounded .coursetype .card{border-radius: 10px}
	.coursetype .card.active{border: 2px solid #0332AA;}
	.coursetype .card p {color: #889DC6;font-size: 14px;transition: all ease 0.3s}
	.coursetype .card img{filter: opacity(0.4);transition: all ease 0.3s}
	
	.coursetype .card.active p{color: #0332AA;}
	.coursetype .card.active img{filter: opacity(1);}
	
	.coursetop p{color: #6F83AA}
	
	.courselist .course-col-2,.stream .card{background: linear-gradient(0deg, #FFFFFF, #FFFFFF), #C4C4C4;box-shadow: 0px 0px 7px rgba(196, 196, 196, 0.35);border-radius: 10px;width: 100%}
	.coursecontent{min-height: 130px;}
	.coursecontent p,.courselist h2{overflow: hidden; -webkit-line-clamp: 8;text-overflow: ellipsis;overflow: hidden;display: -webkit-box;-webkit-box-orient: vertical;word-wrap: break-word;}
	.courselist h2{color: #0332AA;font-size: 18px;font-weight: bold;line-height: 36px;min-height: 0%}
	.courselist p.list-item-heading,.coursecontent .row div:first-child p{color: #6884CC;font-weight: 600;}
	
	.border-right{border-right: 1px solid #D7DFF0!important;}
	
	.btn-primary{width: auto}
	
	.coursecontent .centers p{overflow: hidden;white-space: inherit;text-overflow: ellipsis;display: -webkit-box;-webkit-line-clamp: 6;-webkit-box-orient: vertical;}
	
	@media (max-width: 580px){
		.courselist h2 {font-size: 16px !important;line-height: 26px}
	}
	
</style>

<main>
  <div class="container-fluid">
    <div class="row">
      <div class="col-12">
       
        
        
        <div class="row">

				<div class="col-md-8 col-sm-8 col-lg-8 col-12">

					<h1>My Courses</h1>

				</div>

				<div class="col-md-4 col-sm-4 col-lg-4 col-12">

					 <div class="form-group">
						<select class="form-control qualification" name="qualification" >
						  <?php //echo $qualification;
							
								echo $classstudymaster;
							?>
						</select>
					 </div>

				</div>

		</div>
        
           <div class="mb-2"></div>
           
           <!--<h6 class="mb-4"><strong>Select Course Type</strong></h6>
        
			<div class="row coursetype">
				<div class="col-md-6 col-sm-6 col-lg-4 col-12 mb-4">
					<div class="card active" data-type="room">
						<div class="card-body">
							<div class="text-center">
								<img alt="Profile" src="<?php echo base_url();?>img/icons/room.png" class="img-thumbnail border-0 mb-3">
								<p class="list-item-heading mb-1">Class Room</p>
							</div>
						</div>
					</div>
				</div>
				<div class="col-md-6 col-sm-6 col-lg-4 col-12 mb-4">
					<div class="card" data-type="online">
						<div class="card-body">
							<div class="text-center">
								<img alt="Profile" src="<?php echo base_url();?>img/icons/online.png" class="img-thumbnail border-0 mb-3">
								<p class="list-item-heading mb-1">Online Class</p>
							</div>
						</div>
					</div>
				</div>
				<div class="col-md-6 col-sm-6 col-lg-4 col-12 mb-4">
					<div class="card" data-type="test">
						<div class="card-body">
							<div class="text-center">
								<img alt="Profile" src="<?php echo base_url();?>img/icons/series.png" class="img-thumbnail border-0 mb-3">
								<p class="list-item-heading mb-1">Test Series</p>
							</div>
						</div>
					</div>
				</div>
			</div>
              
              <h6 class="mb-4"><strong>Select Stream</strong></h6>
              
              <div class="row stream">
                         
				<div class="col-md-6 col-sm-6 col-lg-2 col-12 mb-4">
					
					 <div class="custom-control custom-radio col-sm-3">
						<input type="radio" id="stream1" name="stream" class="custom-control-input" value="medical" >
						<label class="custom-control-label" for="stream1">Medical</label>
					  </div>
					
				</div>
                         
				<div class="col-md-6 col-sm-6 col-lg-2 col-12 mb-4">
					
					 <div class="custom-control custom-radio col-sm-3">
						<input type="radio" id="stream2" name="stream" class="custom-control-input" value="engineering" >
						<label class="custom-control-label" for="stream2">Engineering</label>
					  </div>
					
				</div>
                         
				<div class="col-md-6 col-sm-6 col-lg-2 col-12 mb-4">
					
					 <div class="custom-control custom-radio col-sm-3">
						<input type="radio" id="stream3" name="stream" class="custom-control-input" value="foundations" >
						<label class="custom-control-label" for="stream3">Foundations</label>
					  </div>
					
				</div>
             
		  	</div>
              
              
              <h6 class="mb-4"><strong>Select Class & Location</strong></h6>-->
              
              
               <!--<div class="row stream">
                         
				<div class="col-12 mb-4">

					<div class="card">
					
						<div class="card-body">
					
							<div class="row">

									<div class="col-md-6 col-sm-6 col-lg-6 col-12 mb-4">

										 <div class="form-group">
											<select class="form-control coursetype" name="coursetype">
											  <option value="">Course Type*</option>
											  <option value="room">Class Room</option>
											  <option value="online">Online Class</option>
											  <option value="both">Both</option>
											</select>
										 </div>

									</div>

									<div class="col-md-6 col-sm-6 col-lg-6 col-12 mb-4">

										 <div class="form-group">
											<select class="form-control schedule" name="schedule" >
											  <option value="">Class Schedule*</option>
											  <option value="regular">Regular Batch</option>
											  <option value="weekend">Weekend Batch</option>
											  <option value="both">Both</option>
											</select>
										 </div>

									</div>

							</div>

							<div class="row">

								<div class="col-md-6 col-sm-6 col-lg-6 col-12 mb-4">

									 <div class="form-group">
										<select class="form-control center" name="center">
										  <option value="">Available Center*</option>
										  <?php //echo $searchoptions['center'];?>
										</select>
									 </div>

								</div>

								<div class="col-md-6 col-sm-6 col-lg-6 col-12 mb-4">

									 <div class="form-group">
										<select class="form-control duration" name="duration">
										  <option value="">Duration*</option>
										  <?php 
											
												/*for($i=1;$i<=12;$i++){

													echo '<option value="'.$i.' Month">'.$i.' Month</option>';

												}*/
											
											?>
											
											<?php 
											
												/*for($i=1;$i<=10;$i++){

													echo '<option value="'.$i.' Year">'.$i.' Year</option>';

												}*/
											
											?>
										</select>
									 </div>

								</div>

							</div>
                         
							<div class="col-12 mb-0 text-right">

								<button class="btn btn-outline-primary mr-3 coursereset">Reset</button>

								<button class="btn btn-primary coursesearch">Search</button>

							</div>
            
		 		</div>
	
			</div>

		</div>
              
              
		  </div>-->
              
              <div class="separator mb-4"></div>
               
        </div>
        
      </div>
      
      
       
	  <div class="row coursetop mb-3">
	  	
		  <div class="col-6">
			  <p class="list-item-heading"><?php echo count($courses);?> Courses available</p>
		  </div>
		  
		  <div class="col-6 text-right">
		  	<p class="list-item-heading">Page 1 of 1</p>
		  </div>
	  	
	  	
	  </div>
       
       
        <div class="row courselist mb-3">
	  	
            <?php
            
            for($i = 0 ; $i < count($courses);$i++){
				
                $timestamp = strtotime($courses[$i]['starts_on']);
                $timestamp1 = strtotime($courses[$i]['ends_on']);
                $csch = array_filter(explode("|",$courses[$i]['cschedule']));$regular = '';$hydrid = '';
				$cschedule = implode(", ",$csch);
				
				$screentest = $courses[$i]['screentest'];
				$cide = $courses[$i]['ide'];
								                
                /*if(($csch[0] === 'regular') || ($sch[2] === 'both')) { $regular = '<p class="mb-0">Regular Batch-Monday to Saturday</p>';}
                if(($csch[1] === 'weekend') || ($sch[2] === 'both')) { $hydrid = '<p>Hybrid Batch-All Saturday/Sunday & selected vacations*</p>';}*/
				
				$classschedule = '<div class="row">

						  <div class="col-md-4">
							  <p>Class Schedule:</p>
						  </div>

						   <div class="col-md-8">'.ucwords($cschedule).'</div>

					  </div>';
				$timeperiod = "Admission Time";
				$commences = "Commencing on";
				$minheight = "";
				if($screentest=="1"){
					
					$timeperiod = "Application Period";
					$commences = "Test Date";				
					$classschedule = "";
					$minheight = 'style="min-height: 90px;"';
				}
				
				$disablebtn = $regnowbtn = "";
				
				$approved = $courses[$i]['approved'];
				
				$paylink = 'stucoursedetails?id='. $courses[$i]['ide'];
				
				$grandtotalnow = 0;
				foreach($studentcoursepay as $stupaylist){
						
					if($stupaylist['courseid'] == $cide){

						$total = $stupaylist['grandtotal'];	

						$grandtotalnow += $total;

					}
													
				}
				
				if($approved === 'n') {
					$disablebtn = "disabled";$regnowbtn = "Waiting List";
				}else if($approved === 'w'){
					$disablebtn = "disabled";$regnowbtn = "Waiting List";
				}else if($approved === 's'){
					$disablebtn = "disabled";$regnowbtn = "Shortlisted";
				}else if($approved === 'q'){
					$disablebtn = "disabled";$regnowbtn = "Waiting For Approval";
				}else if($approved=="y"){  
					$regnowbtn = "Pay Now";
					$paylink = "stumyprofile?action=register&id=".$courses[$i]['cride']; 
					
					if($grandtotalnow==0){
						$regnowbtn = "Payment History";
						$paylink = "stufeepayments?id=".$courses[$i]['cride']; 
					}
					
				}else{
					$regnowbtn = "Register Now";
				}
				
												
				
                echo '<div class="col-md-6 d-flex mb-4">
		  
			  <div class="course-col-2 p-4">
			  	
				  <h2 class="mb-2" title="'. $courses[$i]['coursename'].'">'. $courses[$i]['coursename'].'</h2>
		  	
		  			<div class="separator mb-2"></div>
		  			
				  <div class="row">
				  	
					  <div class="col-md-3 col-xs-3 col-3 text-center border-right">
					  	<img alt="Profile" src="'. base_url().'img/icons/clock.png" class="img-thumbnail border-0 mb-2">
					  	<p class="list-item-heading mb-1">Duration</p>
					  	<p class="mb-2 text-muted">'. $courses[$i]['duration'].'</p>
					  </div>
					  
					  <div class="col-md-5 col-xs-5 col-5 text-center border-right">
					  	<img alt="Profile" src="'. base_url().'img/icons/invoice.png" class="img-thumbnail border-0 mb-2">
					  	<p class="list-item-heading mb-1">'.$timeperiod.'</p>
					  	<p class="mb-2 text-muted">'. date('d M Y',$timestamp).' - '. date('d M Y',$timestamp1).'</p>
					  </div>
					  
					  <div class="col-md-4 col-xs-4 col-4 text-center">
					  	<img alt="Profile" src="'. base_url().'img/icons/refresh-cw.png" class="img-thumbnail border-0 mb-2">
					  	<p class="list-item-heading mb-1">'.$commences.'</p>
					  	<p class="mb-2 text-muted">'. $courses[$i]['commenceson'].'</p>
					  </div>
				  	
				  </div>
		  			
		  			<div class="separator my-2"></div>
		  			
		  			<div class="coursecontent" '.$minheight.'>
		  			
				  <div class="row">
				  	
					  <div class="col-md-4">
						  <p>Qualification :</p>
					  </div>
					  
					   <div class="col-md-8">
						   <p>'. $courses[$i]['qname'].'</p>
					   </div>
				  	
				  </div>
				  
				 '.$classschedule.'				  
				  
				  <div class="row">
				  	
					  <div class="col-md-4">
						  <p>Center :</p>
					  </div>
					  
					   <div class="col-md-8 centers">
						   <p>'.  str_replace("|", ', ', $courses[$i]['centers']).'</p>
					   </div>
				  	
				  </div>
				  
				  </div>
				  
				  
				  <div class="mb-0"></div>
				  
				  
				  <div class="row">
				  	
					  <div class="col-6">
						 <a href="'. base_url().'stucoursedetails?id='. $courses[$i]['ide'].'" data-qid="'.$courses[$i]['classstudy'].'" class="regnowbtn" > <button class="btn btn-outline-primary">Read More</button></a>
					  </div>
					  
					   <div class="col-6 text-right">
						   <a href="'.$paylink.'" data-qid="'.$courses[$i]['classstudy'].'" class="regnowbtn" ><button class="btn btn-primary w-5" '.$disablebtn.'>'.$regnowbtn.'</button><a>
						  
					   </div>
				  	
				  </div>
			  	
			  </div>
			  
		  </div>';
                
            }
            
            
            
            
            ?>
		  
	</div>
        
    
  </div>

</main>
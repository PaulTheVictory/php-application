<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/dataTables.css?v=1.5" />
<script src="<?php echo base_url(); ?>js/jquery.dataTables.js?v=1.0" type="text/javascript"></script>
<script src="<?php echo base_url(); ?>js/onscan.min.js?v=1.0" type="text/javascript"></script>

 <style type="text/css">
	 
	 table.dataTable{margin-top: 1rem !important;width: 99% !important;margin: auto}
	 .table tr:last-child td{text-align: left}
	.table tr td:last-child,.table tr th:last-child{text-align: left}
	.table tr:last-child td:last-child{font-weight: 600;text-align: left}
	.table tr:last-child{text-align: center}
	
	.table{border: 1px solid #D7DFF0;border-collapse: collapse;border-style: hidden;border-radius: 10px 10px 0 0;box-shadow: 0 0 0 1px #d7dff0;}
	.table thead th{font-size: 12px;font-weight: bold;color: #6F83AA;letter-spacing: 0.5px;background: #E6EBF7;text-transform: uppercase;padding: 0.8rem;text-align: left}
	.table thead tr th:first-child{border-top-left-radius: 5px}
	.table thead tr th:last-child{border-top-right-radius: 5px}
	.table td, .table th{border-top: 1px solid #D7DFF0;padding: 0.9rem 0.75rem;color: #364159;font-weight: 600;}
	.table td{background: #ffffff;}
	
		
	h3.title{font-size: 12px;text-transform: uppercase;color: #0332AA;letter-spacing: 0.5px;font-weight: bold;}
	 h2{font-size: 12px;text-transform: uppercase;color: #0332AA;letter-spacing: 0.5px;font-weight: bold;}
	 
		
		.dataTables_empty{text-align: center !important}
		.dataTables_wrapper{overflow-x: auto}
	 
	 .card{background: linear-gradient(0deg, #FFFFFF, #FFFFFF), #C4C4C4;box-shadow: 0px 0px 7px rgba(196, 196, 196, 0.35);border-radius: 10px;}
	 
	 .form-group.floating{margin-bottom: 0}
	 
	 p.list-item-heading{color: #6884CC;font-weight: 600;}
	.feetop p.list-item-heading span:last-child{font-weight: 600;font-size: 14px;color: #364159;}
	 
	 .icon-edit{background: url(img/icons/edit3-b.png) no-repeat;width: 15px;height: 16px;display: inline-block;vertical-align: middle}
	 .bookdetails p span:last-child{font-weight: 600;font-size: 14px;line-height: 14px;color: #364159;}
	 .bookdetails p a {font-weight: 600;font-size: 14px;line-height: 20px;color: #0332AA;}

	 
	 h5.modal-title p.headtitle{display: inline-block;width: 100%;text-align: center;font-weight: bold;font-size:17px;color: #fff;}
	h5.modal-title p.text-muted{display: inline-block;width: 100%;text-align: center;font-weight: 600;font-size: 14px;line-height: 36px;color: #181E29;line-height: 20px;}
	.modal-title img{display: block;margin: 1em auto}
	#EditbooklimitModal.modal .modal-header{padding: 10px 20px !important;border: none}	
	#EditbooklimitModal.modal .modal-body{padding:0 1.75rem 1.75rem}
	.modal-body p{text-align: left !important}
	.modal-backdrop.show {opacity: .5 !important;}
	 
 </style>
 
 <script type="text/javascript">
	 
	 var oTable = "";
$(document).ready(function(){	
		
	
	$("select").change(function(){
		$(this).attr('value',$(this).val());
	});
	
	$(".addstock").click(function(){
		
		var center = $(".centers").val();
		var booktype = $(".booktype").val();
		
		if(center==""){ alert("Select center"); return false;}
		
		if(booktype==""){ alert("Select book type"); return false;}
		
		var url = 'addbookstock?bid=<?php echo $bid; ?>&center='+center+'&btype='+booktype;
										
	    $(location).prop('href', url);
	});
	
	
          var columnData = [
              { "data": "created" },
                    { "data": "barcode" },
                    { "data": "bookname" },
                    { "data": "price" },
                    { "data": "booktype" },
                    { "data": "duedate" },
                    { "data": "dueperiod" },
                    
                  ];
        // columnData.push( {data: "id","visible":true} );
         //columnData.push( {data: "item_name_search","visible":false} );
         
       
        oTable = $('#usertable').dataTable({
                    "bProcessing": true,
                    "bServerSide": true,
                    "sPaginationType": "full_numbers",
                    "ajax": {
                    "url": 'issuebookdetails/GetIssueBookDetails',
                    "type": "POST",
                   
                    "data":{ "stuid": "<?php echo $stuid; ?>"}
                     }, 
                     "oLanguage": {
                        "sProcessing": "<img src='<?php echo base_url(); ?>images/loader.gif'>"
                    },
                    'iDisplayLength': 1000,
                    "columns": columnData,
                    "order": [[ 0, "desc" ]],
                    "fnDrawCallback": function( oSettings ) {
						
                        var count = 1;
						
                         $('#usertable').find("tr .sno").each(function(){                           
                            $(this).text(count);
                            count++;
                         });
                                                      
                    }
         }); 
         
         
         
  
	
});
</script>

 <main> 
        
        <div class="container-fluid">
                 
    
		<h1>Issue Book(s)</h1>
               
            <div class="row px-3 mt-4">     
                     
           <div class="col-12 p-0">
           
           <div class="card">
           
            <div class="course-container add-course mt-3 px-4">
                    
                <div class="row mb-3 feetop">
                   
					<div class="col-12 text-left px-2">
						<p class="list-item-heading mb-1"> <span>Student Name :</span> <span><strong><?php echo $studentdetails['stuname']; ?></strong></span></p>
					</div>
					
				</div>
                  
                <div class="row mb-3 feetop">
                   
					<div class="col-md-3 col-sm-3 col-3 text-left px-2">
						<p class="list-item-heading mb-1"> <span>Student ID:</span> <span><?php echo $studentdetails['studid']; ?></span></p>
					</div>
                   
					<div class="col-md-3 col-sm-3 col-3 text-left px-2">
						<p class="list-item-heading mb-1"> <span>Mobile number:</span> <span><?php echo $studentdetails['smcode']; ?> <?php echo $studentdetails['smobile']; ?></span></p>
					</div>
					
				</div>  
              
               
                </div>
                
			   </div>
               
            </div>
             
          
           </div>
           
			<div class="d-inline-block my-3"></div>
          
          
		<h2 class="mt-4">Book issue details</h2>

        <div class="col-12 p-0 my-4 add-book">
                               
                 <div class="card">               
                                
                <div class="row mt-3 px-3 pt-3">
                
                	<div class="col-12 col-sm-5">
                    
						<div class="form-group position-relative error-l-50 floating mb-0">

							 <input id="barcode" name="barcode" minlength="3" maxlength="7" class="form-control barcode" placeholder=" " type="text" tabindex="1" >

							 <label>Scan Barcode <span>*</span> </label>
						</div>
						
					</div>
			  				
					<div class="col-12 col-sm-2">
				
 						 <button class="btn btn-primary savebtn">Issue Book</button>

					 </div>
				 
					  <div class="col-12"> 
						<p class="alert my-3"></p>
					  </div>
				 
					</div>
				               
			   </div>
              
			   </div>
         
          <div class="card p-4">
                     
			  <div class="row bookdetails">
			  	
				  <div class="col-md-3">
					  <p class="list-item-heading mb-1"> <span>Book lending Limit:</span> <span class="totallimit"><span class="booklimitcount"><?php echo $studentdetails['booklimit']; ?></span> <a href="#" title="Edit" class="ml-3 editlimit process"><i class="icon-edit"></i> Edit</a></span></p>
				  </div>
				  
				  <div class="col-md-3">
				  	<p class="list-item-heading mb-1"> <span>No. of Books Lended:</span> <span class="totalissued"><?php echo $issueddetails['totalissued']; ?></span></p>
				  </div>
				  
				  <div class="col-md-3">
				  	<p class="list-item-heading mb-1"> <span>Available Book Limit:</span> <span class="totalavailable"><?php echo $studentdetails['booklimit'] - $issueddetails['totalissued']; ?></span></p>
				  </div>
			  	
			  </div>
                      
           <?php echo $this->table->generate();  ?>
           
			</div>
       
 </div>
 
 </main>
 
 <div class="modal fade" id="EditbooklimitModal" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog modal-xl" role="document">
	<div class="modal-content">
            <div class="modal-header" style="background-color: #6884CC;height: 50px;width: auto;padding: 10px">
	  
		<h5 class="modal-title w-100" id="exampleModalLabel">
		
			<div class="row">
			
				<div class="col-4">
					<p class="headtitle text-left">Edit Book Lending Limit</p>
				</div>
				
			</div>
			
		</h5>
	 </div>
           
           <?php echo form_open('issuebookdetails/issuebooklimitSubmit', array('id' => 'editbooklimitForm')) ?>
           
            <div class="row m-4">
               
                <div class="col-12 col-sm-6" >
                    <div class="form-group position-relative error-l-50 floating">
                      <input placeholder=" " type="number" name="booklimit" id="booklimit" class="form-control">
                      <input type="hidden" class="" name="studentid" id="studentid" value="<?php echo $studentdetails['id']; ?>" >
                       <label for="booklimit">Book lending Limit <span>*</span></label>
                    </div>
				</div>
       	
        	</div> 
        
        <?php echo form_close() ?>
        
	  <div class="modal-footer">
                     <div class="form-group"> <span class="eresponse"></span></div>
	 			 <div class="form-group"> 
	 			 
					<button type="button" class="btn btn-primary paycancel float-left" data-dismiss="modal">Cancel</button>
					
				</div> 
				<div class="form-group">
				
					<button type="button" class="btn btn-primary previewbtn float-right editsave" >Save</button>
                
                </div> 
             
        
	  </div>
	</div>
  </div>
  </div>
 
<script type="text/javascript">
	
    $(document).ready(function() {
   
		$("#barcode").focus();
	
		$("select").change(function(){
			$(this).attr('value',$(this).val());
		});
		
		
	// Initialize with options
	onScan.attachTo(document, {
		suffixKeyCodes: [13], // enter-key expected at the end of a scan
		reactToPaste: false, // Compatibility to built-in scanners in paste-mode (as opposed to keyboard-mode)
		onScan: function(sCode, iQty) { // Alternative to document.addEventListener('scan')
			//console.log('Scanned: ' + iQty + 'x ' + sCode); 
			$("#barcode").val(sCode).focus();
			scanbarcode(sCode);
		},
		onKeyDetect: function(iKeyCode){ // output all potentially relevant key events - great for debugging!
			//console.log('Pressed: ' + iKeyCode);
			//$("#barcode").focus();
		}
	});
    
		
	$(".savebtn").click(function(){

		var barcode = $("#barcode").val();

		scanbarcode(barcode);
                   
                              
     });
    
		
	$(".editlimit").click(function(){

		    $('#EditbooklimitModal').modal({show:true});               
                              
     });
		
		
		
	$(".editsave").click(function(){
         
		
		var booklimit = $("#booklimit").val();
		var booklimitcount = $(".booklimitcount").text();
		var totalissued = $(".totalissued").text();
		
		
		if(parseInt(booklimit) < 4 || parseInt(booklimit) < parseInt(totalissued)) {alert("Limit not less than default or books lended");return false ;}
		
		
		$(".eresponse").html('').text('Progressing...');


		var editbooklimitForm = $("#editbooklimitForm");

			$.ajax({
				url: editbooklimitForm.attr('action'),
				type: 'post',
				data: editbooklimitForm.serialize(),
				success: function(o){

					var response = $.parseJSON(o);
					$(".response").html('');
					if(response.status === 'success') {

						$(".eresponse").css("color","rgb(25, 71, 15)");
					   $(".eresponse").text(response.message);
					   //oTable.fnDraw();
					   $('#EditbooklimitModal').modal('hide');
						
						var booklimit = $("#booklimit").val();
						var totalavailable = $(".totalavailable").text();
						var totalissued = $(".totalissued").text();
						
						$(".booklimitcount").text(booklimit);
						totalavailable = parseInt(booklimit) - parseInt(totalissued)
						$(".totalavailable").text(totalavailable);
						
						$("#booklimit").val("");
						$(".eresponse").html(""); 

					} else {

					   $(".eresponse").append(response.message); 

					}

				}
			});
                    
      });
		
           
});
	
	
	function scanbarcode(barcode){
		
			var stuid = "<?php echo $stuid; ?>";
			var center = "<?php echo $center; ?>";
		
			if(barcode=="") {alert("Scan barcode"); return false;}
		
			//if(barcode.length < 3 || barcode.length > 7) {alert("Barcode must be upto 7 digit"); return false;}
			
			$(".alert").removeClass("alert-success alert-danger").text('');
		         
	   		$(".alert").addClass("alert-success").text('Progressing...');

			$.ajax({
				url: "issuebookdetails/addissuebookSubmit",
				type: 'post',
				data: {"stuid":stuid,"center":center,"barcode":barcode},
				success: function(o){

					var response = $.parseJSON(o);
					
					if(response.status === 'success') {

						$(".alert").addClass("alert-success").text(response.message);
					   oTable.fnDraw(); 
						
						var totalbook = <?php echo $studentdetails['booklimit']; ?>;
						
						var totalissued = $(".totalissued").text();
						var totalavailable = $(".totalavailable").text();
						
						totalissued = parseInt(totalissued) + 1;
						totalavailable = parseInt(totalavailable)  - 1;
						
						$(".totalissued").text(totalissued);
						$(".totalavailable").text(totalavailable);

					} else if(response.status === 'exists') {

					   $(".alert").addClass("alert-danger").text(response.message); 

					} else if(response.status === 'fail') {

					   $(".alert").addClass("alert-danger").text(response.message); 

					} else {

					   $(".alert").addClass("alert-danger").text(response.message); 

					}
					
					setTimeout(function(){$(".alert").removeClass("alert-success alert-danger").html('');$("#barcode").val("").focus()},1000);

				}
			});
		
	}
	
</script>
    
<script src="<?php echo base_url();?>js/vendor/jquery.validate/jquery.validate.min.js"></script>
<script src="<?php echo base_url();?>js/vendor/jquery.validate/additional-methods.min.js"></script>

 <style type="text/css">
     
	 .add-book .card{background: linear-gradient(0deg, #FFFFFF, #FFFFFF), #C4C4C4;box-shadow: 0px 0px 7px rgba(196, 196, 196, 0.35);border-radius: 10px;}
	 
    .response p { float: right;font-size:12px;color:#eb345e;}
	 
	  /* Upload files*/	
	
	.btn-primary{background-color: #0332AA;color: #ffffff;border-color: #0332AA;font-weight: 600;}
	.btn-primary:not(:disabled):not(.disabled).active, .btn-primary:not(:disabled):not(.disabled):active, .show>.btn-primary.dropdown-toggle,.btn-primary:hover{background-color: rgba(3,50,170,0.8);}
	
	.btn-outline-primary {color: #0332AA;border-color: #0332AA;font-weight: 600;}
	.btn {border-radius: 5px;outline: initial!important;box-shadow: none!important;box-shadow: initial!important;font-size: .8rem;padding: .5rem 1.25rem .5rem 1.25rem;transition: background-color box-shadow .1s linear;margin-bottom: 0px}
	.btn-outline-primary:not(:disabled):not(.disabled).active, .btn-outline-primary:not(:disabled):not(.disabled):active, .show>.btn-outline-primary.dropdown-toggle,.btn-outline-primary:hover {background-color: #0332AA;border-color: #0332AA;color: #fff;}
	p.alert{font-size: 14px;padding: .45rem 1.25rem;}
	p.alert-danger {color: #721c24;}
	p.alert-success {color: #155724;}
	
	.box {position: relative;background: #ffffff;width: 100%;}
	.box-header {color: #444;display: block;padding: 10px;position: relative;border-bottom: 1px solid #f4f4f4;margin-bottom: 10px;}
	.box-tools {position: absolute;right: 10px;top: 5px;}
	.dropzone-wrapper {background: #F6F7FA;border: 1px dashed #BCCAE8;color: #92b0b3;position: relative;height: 40px;border-radius: 5px;}
	.dropzone-desc {position: absolute;margin: 0 auto;left: 0;right: 0;text-align: center;width: auto;top: 5px;font-size: 16px;}
	.dropzone,
	.dropzone:focus {position: absolute;outline: none !important;width: 100%;height: 40px;cursor: pointer;opacity: 0;}
	.dropzone-wrapper:hover,
	.dropzone-wrapper.dragover {background: #ecf0f5;}
	.preview-zone {text-align: center;}
	.preview-zone .box {box-shadow: none;border-radius: 0;margin-bottom: 0;}
	#filename {margin-top: 10px;margin-bottom: 10px;font-size: 14px;line-height: 2.7em;border: 1px solid #D7DFF0;
    border-radius: 5px;min-height: 40px;margin-top: 2.2rem;}
	.file-preview {background: #ccc;border: 5px solid #fff;box-shadow: 0 0 4px rgba(0, 0, 0, 0.5);display: inline-block;width: 60px;height: 60px;text-align: center;font-size: 14px;margin-top: 5px;}
	.closeBtn:hover {color: red;display:inline-block;}
	
	.icon-upload{background: url("img/icons/upload.png") no-repeat;width: 24px;height: 24px;display: inline-block;vertical-align: middle}
	.dropzone-desc p.list-item-heading{font-size: 14px;font-weight: 600;color: #536485;display: inline-block}
	.dropzone-desc p.text-muted{font-size: 10px;font-weight: normal;color: #6F83AA;}
	.dropzone-desc p.list-item-heading span{color: #db4d4d}
	
	p.alert-info{font-weight: 600;font-size: 14px;color: #355BBB;}
  
 </style>

<main> 
        
        <div class="container-fluid">
        
        <div class="col-12 mb-4 add-book">
        
        <div class="row mb-3">
			<div class="col-md-10">
				<h1>Book Master</h1>
			</div>
			<div class="col-md-2">
				<a href="docs/addbook/addbooktemplate.xls"><button type="button" class="btn btn-outline-primary">Download Template</button></a>
			</div>
		</div> 
               
        <div class="card col-12 p-3 mb-4">

					 <div class="row align-items-center w-100">
					
					<div class="col-11 justify-content-start">
					
						<div id="drop-zone">
							<div class="dropzone-wrapper">
							  <div class="dropzone-desc" id="clickHere">
								<i class="icon-upload mb-2"></i>
								<p class="list-item-heading mb-1">Upload Books</p>
							  </div>
							  <input type="file" name="uploadresults[]" id="uploadresults" class="dropzone">
							 
							</div>
							 
						</div>
						 
						 </div>
							 
							 <div class="col-1 justify-content-start text-right pr-0">       				 
                            				 
								<button type="button" class="btn btn-primary importresults">Upload</button>
                            				 
				   			</div>
				   
						 </div>
							 
							 <div class="border-bottom my-4"></div>
						
						
						<div class="row align-items-center w-100">
					
							<div class="col-6 d-flex justify-content-start">
							
								<div class="loader d-none">
									<img src='<?php echo base_url(); ?>images/loader.gif'>
								</div>
								
								 <p class="ualert alert mb-0"></p>   
								 
							</div>
							
							<div class="col-6 justify-content-start text-right pr-0">
								
								<button type="button" class="btn btn-outline-primary cancelresults">Cancel</button>
								<!--<button type="button" class="btn btn-primary d-none approveresults">Approve Results</button>-->
								
							</div>
			   		
							</div> 
				   		
								<!--<div id='filename'><?php //echo $marksheetlist;?></div>-->
							  </div>
        
        <div class="card p-4">						 
        
       		 <form id="bookForm" action="addbook/bookSubmit" class="tooltip-right-bottom" novalidate>
        	                             
                <div class="row">
                   
                    <div class="col-12 col-sm-6">
                    
				  		<div class="form-group position-relative error-l-50 floating">
                      
                    		<input type="text" name="isbnnumber" value="<?php echo $bookdetails['isbn_number']; ?>" class="form-control isbnnumber" placeholder=" " />
                       		 
							 <label>ISBN Number </label>
						</div>
						
					</div>
              
               <div class="col-12 col-sm-6">
                    
				  		<div class="form-group position-relative error-l-50 floating">
                      
                    		<input type="text" name="bookname" value="<?php echo $bookdetails['bookname']; ?>" class="form-control bookname"  required placeholder=" " />
                       		 
							 <label>Book Name <span>*</span> </label>
						</div>
					</div>
              
               <div class="col-12 col-sm-6">
                    
				  		<div class="form-group position-relative error-l-50 floating">
                      
                    		<input type="text" name="author" value="<?php echo $bookdetails['author']; ?>" class="form-control author"  required placeholder=" " />
                       		 
							 <label>Author <span>*</span> </label>
						</div>
					</div>
              
              	 <div class="col-12 col-sm-6">
                    
				  		<div class="form-group position-relative error-l-50 floating">
                      
                    		<input type="text" name="publisher" value="<?php echo $bookdetails['publisher']; ?>" class="form-control publisher"  required placeholder=" " />
                       		 
							 <label>Publisher <span>*</span> </label>
						</div>
					</div>
              
              	 <div class="col-12 col-sm-6">
                    
				  		<div class="form-group position-relative error-l-50 floating">
                      
                    		<select name="category" value="<?php echo $bookdetails['category']; ?>" class="form-control category" required>
								<option value="">Category</option>
								 <option value="Chemistry">Chemistry</option>
								 <option value="Biology">Biology</option>
								 <option value="Maths">Maths</option>
								 <option value="Physics">Physics</option>
								 <option value="KVPY">KVPY</option>
								 <option value="NTSE">NTSE</option>
								 <option value="OLYMPIAD">OLYMPIAD</option>
								 <option value="PCM COMBO">PCM COMBO</option>
								 <option value="PCB COMBO">PCB COMBO</option>
                      		 
                       		 </select>
                       		 
							 <label>Category <span>*</span> </label>
						</div>
					</div>
              
              	 <div class="col-12 col-sm-6">
                    
				  		<div class="form-group position-relative error-l-50 floating">
                      
                    		<input type="text" name="edition" value="<?php echo $bookdetails['edition']; ?>" class="form-control edition" required placeholder=" " />
                       		 
							 <label>Edition <span>*</span> </label>
						</div>
					</div>
              
              	 <div class="col-12 col-sm-6">
                    
				  		<div class="form-group position-relative error-l-50 floating">
                      
                    		<select name="stream" value="<?php echo $bookdetails['stream']; ?>" class="form-control stream" required>
								<option value="">Stream</option>
								 <option value="Medical">Medical</option>
								 <option value="Engineering">Engineering</option>
								 <option value="Foundation">Foundation</option>
								 <option value="IIT">IIT</option>
								 <option value="Others">Others</option>
                       		 </select>
                       		 
							 <label>Stream <span>*</span> </label>
						</div>
					</div>
              
              	 <div class="col-12 col-sm-6">
                    
				  		<div class="form-group position-relative error-l-50 floating">
                      
                    		<input type="text" name="supplier" value="<?php echo $bookdetails['supplier']; ?>" class="form-control supplier" required placeholder=" " />
                       		 
							 <label>Supplier <span>*</span> </label>
						</div>
					</div>
              
              	 <div class="col-12 col-sm-6">
                    
                    <div class="form-row">
                    
				  		<div class="form-group col-md-10 position-relative error-l-50 floating">
                      
                    		<input type="number" name="dueperiod" value="<?php echo $bookdetails['dueperiod']; ?>" class="form-control dueperiod" required placeholder=" " minlength="1" maxlength="2" />                       		 
							 <label>Due Period <span>*</span> </label>
						</div>
						
						<div class="col-md-2 mt-2 text-center"> Days</div>
						
					</div>
             
					</div>
              
              	 <div class="col-12 col-sm-6">
                    
				  		<div class="form-group position-relative error-l-50 floating">
                      
                    		<input type="number" name="price" value="<?php echo $bookdetails['price']; ?>" class="form-control price" required placeholder=" "  minlength="2" maxlength="4" />
                       		 
							 <label>Price <span>*</span> </label>
							 
						</div>
					</div>
               
                               
				 </div>
               
				 <div class="row mt-3">

					  <div class="col-md-10"> 
						<p class="salert alert"></p>
					  </div>

					 <div class="col-md-2">

					 	 <input type="hidden" name="bid" value="<?php echo $bid; ?>" />
					 	 
 						 <button class="btn btn-primary savebtn"><?php if($bid==""){ echo "Save";}else{ echo "Update";}?></button>

					 </div>

				 </div>
		   
			</form>                              
                                      
			</div>
			</div>
		 
	
	       <div class="row mt-3">
	                                                                       
	                <div class="col-12 my-4">                                                       
		                                                                       
		          		<div id="resultmessage" class="my-4"></div>	 
	                                                                       
			  		</div>
		                                                                       
			</div>
			                                                                       
  </div>
 
 </main>
   
    
<script type="text/javascript">
$(document).ready(function() {
	
	var category = "<?php echo $bookdetails['category']; ?>";
	var stream = "<?php echo $bookdetails['stream']; ?>";
	
	$(".category").val(category);
	$(".stream").val(stream);
	
      
	$("form select").change(function(){
		$(this).attr('value',$(this).val());
	});
	
    $(".savebtn").click(function(){
		
			var bookForm = $("#bookForm");
		
			$(".salert").removeClass("alert-success alert-danger").html('');
		
			if(! $(bookForm).valid()) return false;
         
	   		$(".salert").addClass("alert-success").html('').text('Progressing...');

			$.ajax({
				url: bookForm.attr('action'),
				type: 'post',
				data: bookForm.serialize(),
				success: function(o){

					var response = $.parseJSON(o);
					
					if(response.status === 'success') {

					   $(".salert").addClass("alert-success").html(response.message);
						
						setTimeout(function(){$(".alert").removeClass("alert-success alert-danger").html('');location.assign('library');},1000);

					} else {

					   $(".salert").addClass("alert-danger").html(response.message); 

					}

				}
			});
                   
                              
     });
	
	// Upload Books
	
	
	$("#uploadresults").change(function(){
		
		var filename = $(this).val().replace(/C:\\fakepath\\/i, '');
		
		if(filename!=""){
			$(".ualert").removeClass('alert-danger alert-success').addClass('alert-info').text(filename);
			$(".cancelresults").removeClass('d-none');
		}else{
			$(".cancelresults").addClass('d-none');
		}
		
	});
	
	
	 $(".importresults").click(function(){
		  
		 var uploadfile = $("#uploadresults").val();
		 
		 if(uploadfile==""){
			 $(".ualert").removeClass('alert-success alert-info').addClass('alert-danger').text("Upload books file");
			 return;
		 }		 
		 
		if($(".importresults").hasClass('process')){
			
			$(".ualert").removeClass('alert-success alert-info').addClass('alert-danger').text("Please wait while uploading...");
			
		}else{
		
			$(".importresults").addClass('process');
			$(".ualert").removeClass('alert-danger alert-info').addClass('alert-success').text("Uploading books...");
			
			$(".loader").removeClass('d-none');
         		 
		 var formData = new FormData();
		 
		 var c=0;
		 var file_data,file;
		 $('input[type="file"]').each(function(){
			  file_data = $('input[type="file"]')[c].files; // get multiple files from input file
			  //console.log(file_data);
		   for(var i = 0;i<file_data.length;i++){
			   formData.append('file[]', file_data[i]); // we can put more than 1 image file
		   }
		  c++;
	    }); 
			
			//formData.append('bname', '');
		 
		 $.ajax({
                type: 'POST',
                url: 'addbook/uploadLibraryBook',
                data: formData,
			    contentType: false,
    			processData: false,
                success: function(response) {
                   
					var obj1 = $.parseJSON(response);
							
					$(".loader").addClass('d-none');
					
					if(obj1['status']=="success"){
						
						$(".ualert").addClass('alert-success').text("Books uploaded successfully.");
						
						$("#resultmessage").html(obj1['message']);
						
						if(obj1['exceldata']!=""){
							
							window.open("addbook/downloadexcel","_blank");
						}
						
						//dataSet = obj1['tabledata'];
						
						$("#uploadresults").val('');
						$(".importresults").removeClass('process');
						//$(".approveresults").removeClass('d-none');
																								
						setTimeout(function(){
							$(".ualert").removeClass('alert-success').text("");
							if(obj1['exceldata']=="") location.assign('library');
						},3000);
						
					}else if(obj1['status']=="empty"){
						$(".importresults").removeClass('process');
						$(".ualert").removeClass('alert-success').addClass('alert-danger').text("Upload book file");
					}else if(obj1['status']=="ufail"){
						$(".importresults").removeClass('process');
						$(".ualert").removeClass('alert-success').addClass('alert-danger').text("Upload failed");
					}else if(obj1['status']=="exfail"){
						$(".importresults").removeClass('process');
						$(".ualert").removeClass('alert-success').addClass('alert-danger').text("Support extension XLS only");
					}else if(obj1['status']=="error"){
						$(".importresults").removeClass('process');
						$(".ualert").removeClass('alert-success').addClass('alert-danger').text(obj1['message']);
					}else if(obj1['status']==""){
						$(".importresults").removeClass('process');
						$(".ualert").removeClass('alert-success').addClass('alert-danger').text("Please try again.");
					}
					
                }

            });
			
		}
		
		   
	 }); 
	
	
	$('.cancelresults').click(function(){
		
		$("#uploadresults").val('');
		$(".loader,.updateloader").addClass('d-none');
		$(".alert").removeClass('alert-success alert-danger alert-info').text("");
		$("#resultmessage").html("");
		
	});
	
	$(document).on('focus click','input,select,textarea', function () {
	  	$(".alert,.ualert").removeClass("alert-success alert-danger").html('');
	});
	
            
});
</script>
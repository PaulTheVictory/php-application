<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/dataTables.css?v=1.5" />
<script src="<?php echo base_url(); ?>js/jquery.dataTables.js?v=1.0" type="text/javascript"></script>
 <style type="text/css">

     .maincontent ul li.search-choice { height:auto; }
     .maincontent ul li.search-choice a{ height:auto; font-size: 14px;color:#536485}
     .response p { float: right;font-size:12px;color:#eb345e;}
     
.sortable thead tr {
    background: #E6EBF7;
    border: 1px solid #D7DFF0;
    box-sizing: border-box;
    border-radius: 10px 10px 0px 0px;
}
.sortable tr th {
    border-right: 0px;
    padding: 20px 0;font-size: 13px;
      color: #6F83AA;
   cursor: pointer;
   text-align: center;

}

.sortable tr td:nth-child(1) {
   
    min-width:50px;color: #364159;
}

.sortable tr th:nth-child(2) {
   
    text-align: left;
}

.sortable tr td:nth-child(2) {
   
    width:40%;
    text-align: left;
}

.sortable tr td {
    border-right: 0px;
    padding: 0px 2px;
    text-align: center;font-size: 13px;
    min-width:100px;
}
.sortable tr td a {
    color: #364159;
}

.dataTables_info,.dataTables_paginate { display: none; }
.dataTables_filter input {display:none;}
.sortable tr td a:hover { text-decoration: underline; }
.sortable tr td span{ font-size: 14px;color: #364159 }
.course-container{ margin-top: 15px;}
 </style>

	<div class="wrap dynamic-width" style="float: left;position: relative;min-width: 800px">
     <div style="margin-top: 10px; width: 99%; height: 50px; text-align: right;">
         <span style="font-weight: bold;font-size: 20px;padding: 10px;float:left;color: #364159">Edit Group</span>
         
     </div>         
            <?php echo form_open('usereditgroup/groupSubmit', array('id' => 'usergroupForm')) ?>
            <div id="course-container">

                <div class="row-element">
                    <span class="title">Group Name</span>
                    <span class="content"><input placeholder="Group Name" type="text" value="<?php echo $gname['name'];?>" name = "uname" class="uname"></span>
                </div>
                <div class="row-element">
                    <span class="title">User Type</span>
                    <span class="content">
                        <label style="text-align: left;min-width: 150px;color:#536485;background: none;border: 0px;width: auto;height: auto;float:left;font-size: 14px;font-weight: normal"><input type="radio" value="A" <?php echo ($gname["type"] === "A")?'checked="checked"':"";?> name = "ctype" class="" style="margin: 5px;">Acedemic</label>
                        <label style="text-align: left;min-width: 150px;color:#536485;background: none;border: 0px;width: auto;height: auto;float:left;font-size: 14px;font-weight: normal"><input type="radio" value="F" <?php echo ($gname["type"] === "F")?'checked="checked"':"";?>name = "ctype"  class="" style="margin: 5px;">Financial</label>
                        <label style="text-align: left;min-width: 150px;color:#536485;background: none;border: 0px;width: auto;height: auto;float:left;font-size: 14px;font-weight: normal"><input type="radio" value="L" <?php echo ($gname["type"] === "L")?'checked="checked"':"";?>name = "ctype"  class="" style="margin: 5px;">Library</label>
                        <label style="text-align: left;min-width: 150px;color:#536485;background: none;border: 0px;width: auto;height: auto;float:left;font-size: 14px;font-weight: normal"><input type="radio" value="B" <?php echo ($gname["type"] === "B")?'checked="checked"':"";?>name = "ctype"  class="" style="margin: 5px;">Both</label>
                        
                    </span>
                </div>
            </div>
            
            <div class="course-container">

               <span style=";font-size: 17px;padding: 10px;float:left;color: #364159">Students</span>
          <?php
           $this->table->clear();
         $tmpl = array('table_open' => '<table class="sortable disabled" id="studenttable" style="width:98% !important;">');                 
         $this->table->set_template($tmpl);
         $this->table->set_heading('S.NO', 'ACCESS','ADD', 'EDIT','DELETE','VIEW','DEFAULT');
         echo $this->table->generate();
          
          ?>
                
            </div>
            
            
            <div class="course-container">

               <span style=";font-size: 17px;padding: 10px;float:left;color: #364159">Admissions</span>
          <?php
           $this->table->clear();
         $tmpl = array('table_open' => '<table class="sortable disabled" id="admissionstable" style="width:98% !important;">');                 
         $this->table->set_template($tmpl);
         $this->table->set_heading('S.NO', 'ACCESS','ADD', 'EDIT','','VIEW','DEFAULT');
         echo $this->table->generate();
          
          ?>
                
            </div>
            
            <div class="course-container">

               <span style=";font-size: 17px;padding: 10px;float:left;color: #364159">Accounts</span>
          <?php
           $this->table->clear();
         $tmpl = array('table_open' => '<table class="sortable disabled" id="accountstable" style="width:98% !important;">');                 
         $this->table->set_template($tmpl);
         $this->table->set_heading('S.NO', 'ACCESS','ADD', 'EDIT','','VIEW','DEFAULT');
         echo $this->table->generate();
          
          ?>
                
            </div>
            
             <div class="course-container">

               <span style=";font-size: 17px;padding: 10px;float:left;color: #364159">Screening Test</span>
          <?php
           $this->table->clear();
         $tmpl = array('table_open' => '<table class="sortable disabled" id="screeningtesttable" style="width:98% !important;">');                 
         $this->table->set_template($tmpl);
         $this->table->set_heading('S.NO', 'ACCESS','ADD', 'EDIT','','VIEW','DEFAULT');
         echo $this->table->generate();
          
          ?>
                
            </div>
            
            <div class="course-container">

               <span style=";font-size: 17px;padding: 10px;float:left;color: #364159">Results</span>
          <?php
           $this->table->clear();
         $tmpl = array('table_open' => '<table class="sortable disabled" id="resultstable" style="width:98% !important;">');                 
         $this->table->set_template($tmpl);
         $this->table->set_heading('S.NO', 'ACCESS','ADD', 'EDIT','DELETE','VIEW','DEFAULT');
         echo $this->table->generate();
          
          ?>
                
            </div>
            
               <div class="course-container">

               <span style=";font-size: 17px;padding: 10px;float:left;color: #364159">Exam Master</span>
          <?php
           $this->table->clear();
         $tmpl = array('table_open' => '<table class="sortable disabled" id="examtable" style="width:98% !important;">');                 
         $this->table->set_template($tmpl);
         $this->table->set_heading('S.NO', 'ACCESS','ADD', 'EDIT','DELETE','VIEW','DEFAULT');
         echo $this->table->generate();
          
          ?>
                
            </div>
            
            <div class="course-container">

               <span style=";font-size: 17px;padding: 10px;float:left;color: #364159">Reports</span>
          <?php
           $this->table->clear();
         $tmpl = array('table_open' => '<table class="sortable disabled" id="reportstable" style="width:98% !important;">');                 
         $this->table->set_template($tmpl);
         $this->table->set_heading('S.NO', 'ACCESS','', 'EXPORT','','VIEW','DEFAULT');
         echo $this->table->generate();
          
          ?>
                
            </div>
            
             <div class="course-container">

               <span style=";font-size: 17px;padding: 10px;float:left;color: #364159">Settings</span>
          <?php
           $this->table->clear();
         $tmpl = array('table_open' => '<table class="sortable disabled" id="settingstable" style="width:98% !important;">');                 
         $this->table->set_template($tmpl);
         $this->table->set_heading('S.NO', 'ACCESS','ADD', 'EDIT','DELETE','VIEW','DEFAULT');
         echo $this->table->generate();
          
          ?>
                 
            </div>
            
             <div class="course-container">

               <span style=";font-size: 17px;padding: 10px;float:left;color: #364159">Library</span>
          <?php
           $this->table->clear();
         $tmpl = array('table_open' => '<table class="sortable disabled" id="librarytable" style="width:98% !important;">');                 
         $this->table->set_template($tmpl);
         $this->table->set_heading('S.NO', 'ACCESS','ADD', 'EDIT','DELETE','VIEW','DEFAULT');
         echo $this->table->generate();
          
          ?>
                 
            </div>
            
             <div class="course-container">

               <span style=";font-size: 17px;padding: 10px;float:left;color: #364159">Notification</span>
          <?php
           $this->table->clear();
         $tmpl = array('table_open' => '<table class="sortable disabled" id="notificationtable" style="width:98% !important;">');                 
         $this->table->set_template($tmpl);
         $this->table->set_heading('S.NO', 'ACCESS','ADD', 'EDIT','DELETE','VIEW','DEFAULT');
         echo $this->table->generate();
          
          ?>
                 
            </div>
            
            <input  type="hidden" value="<?php echo $grpid;?>" name="groupid">
            
        <?php echo form_close() ?>
     <div style="margin-top: 0px; width: 98%; height: 70px; text-align: right;">
         <span  style="margin: 0px auto; float:right;margin-top: 18px;padding: 10px; color: #fff; background: #4f6fc4 none repeat scroll 0% 0%; border-radius:5px;cursor: pointer" class="btn savebtn" href="#">Save</span>
         <a style="margin: 0px auto; float:right;margin-top: 18px;margin-right:18px;padding: 9px 10px; color: #0332AA; background: linear-gradient(0deg, #FFFFFF, #FFFFFF), #C4C4C4;border: 1px solid #0332AA; border-radius:5px" class="btn" href="<?php echo base_url(); ?>usergroups">Back</a>
         <span class="response" style="margin: 0px auto; float:right;width: 80%; height: 30px;margin-top:20px"></span>
     </div>   
    
        
        </div>
    
      

    
<script type="text/javascript">
$(document).ready(function() {
    
    var genData = <?php echo json_encode($grparr); ?>;
    
      
    var tbArray =["Students","Admissions","Accounts","Screening Test","Results","Exam Master","Reports","Settings","Library","Notification"];
    for(var i=0 ; i< tbArray.length;i++){
        InitializeTable(tbArray[i]);
    }
    
    function InitializeTable(type){
    
    var ele="";
    if(type==="Students"){ ele=$("#studenttable");}else if(type==="Admissions"){
         ele=$("#admissionstable");}else if(type==="Accounts"){ele=$("#accountstable");
    }else if(type==="Screening Test"){ ele=$("#screeningtesttable");}else if(type==="Results"){
         ele=$("#resultstable");}else if(type==="Exam Master"){
         ele=$("#examtable");}else if(type==="Reports"){ele=$("#reportstable");
    }else if(type==="Settings"){ ele=$("#settingstable");  }else if(type==="Library"){ ele=$("#librarytable");  }else if(type==="Notification"){ ele=$("#notificationtable");  }
    
    var columnData = [
                { "data": "id" },
                { "data": "access" },
                { "data": "uadd" },
                { "data": "uedit" },
                { "data": "udelete" },
                { "data": "uview" },
                { "data": "udefaultpage" }
                ];
         
    $(ele).dataTable({
                    "bProcessing": true,
                    "bServerSide": true,
                    "sPaginationType": "full_numbers",
                    "ajax": {
                    "url": 'useraddgroup/FetchModuleAccess',
                    "type": "POST",
                   
                    "data":{ "type": type}
                     }, 
                     "oLanguage": {
                        "sProcessing": "<img src='<?php echo base_url(); ?>images/loader.gif'>"
                    },
                    'iDisplayLength': 20,
                    "columns": columnData,
                    "order": [[ 0, "asc" ]],
                    "fnDrawCallback": function( oSettings ) {
                        var count = 1;
                         
                         $(ele).find("tr .sno").each(function(){
                            
                            $(this).text(count); count++;
                            var flag = $(this).closest("tr").find(".dpage").val();
                            if(flag ==="n"){ $(this).closest("tr").find(".dpage").remove();}
                            
                            var flag1 = $(this).closest("tr").find(".uadd").val();
                            if(flag1 ==="n"){ $(this).closest("tr").find(".uadd").remove();}
                            
                            var flag2 = $(this).closest("tr").find(".uedit").val();
                            if(flag2 ==="n"){ $(this).closest("tr").find(".uedit").remove();}
                            
                            var flag3 = $(this).closest("tr").find(".udelete").val();
                            if(flag3 ==="n"){ $(this).closest("tr").find(".udelete").remove();}
                            
                            var flag4 = $(this).closest("tr").find(".uview").val();
                            if(flag4 ==="n"){ $(this).closest("tr").find(".uview").remove();}
                            
        
                          });  
                          
                            $(ele).find("tr input[type=checkbox]").click(function(){
                            
                            if($(this).is(":checked")){
                                 $(this).val("y");                                  
                            }else{
                                 $(this).val("n");
                            }
                           
                          }); 
                          
                                              
                          $(ele).find("tr input[type=radio]").click(function(){
                            
                            if($(this).is(":checked")){
                                 $(this).val("y");
                                 $(this).closest("tr").find(".uview").prop("checked","true");
                                 $(this).closest("tr").find(".uview").val("y");                                 
                            }
                           
                          });
                          
                        $(genData).each(function(index) {

                            var accessArr  = genData[index];
                            
                            if(accessArr.module === type){
                                   
                                   $(ele).find("tr td").each(function(){
                                        if($(this).text() === accessArr.access){
                                            if(accessArr.uadd==="y"){
                                            $(this).closest("tr").find(".uadd").trigger('click');
                                            }

                                            if(accessArr.uedit==="y"){
                                            $(this).closest("tr").find(".uedit").trigger('click');
                                            }

                                            if(accessArr.udelete==="y"){
                                            $(this).closest("tr").find(".udelete").trigger('click');
                                            }

                                            if(accessArr.uview==="y"){
                                            $(this).closest("tr").find(".uview").trigger('click');
                                            }
                                            
											var dpage = $(this).closest("tr").find("input[type=radio]");
                                            if(accessArr.udefaultpage==="y"){
                                                $(dpage).val("y"); 
																								
                                            }else{
												$(dpage).val("n");
											}
                                        }
                                    });
                                    
                                
                            }
                        });
                                                                           
                    },"initComplete": function( settings, json ) {
						
						$(ele).find(".dpage").each(function(i, val){

						   if($(this).val()=="y"){ $(this).prop('checked', true);}

						});
						
					}
         });
				
    }
    
    $(".savebtn").click(function(){
         
               var dflag = "0";
                $(".dpage").each(function(){
                            
                    if($(this).is(":checked")){
                        var module =$(this).attr("data-module");
                        var access =$(this).attr("data-access");
                        $(this).attr("name","dpage-"+module+"-"+access);  
                        dflag="1";
                    }
                           
                });
               if(dflag === "0") { alert("Please select default page for this group");return;}
                if($(".response").hasClass('progress')) { return;}
               $(".response").html('').text('Progressing...');
                $(".response").addClass('progress');  
               
                var locationForm = $("#usergroupForm");

                    $.ajax({
                        url: locationForm.attr('action'),
                        type: 'post',
                        data: locationForm.serialize(),
                        success: function(o){
                            
                            var response = $.parseJSON(o);
                            $(".response").html('');
                            if(response.status === 'success') {
                       
                                $(".response").css("color","rgb(25, 71, 15)");
                               $(".response").text(response.message);
                               $(location).prop('href', 'usergroups');
                               
                            } else {
                                
                               $(".response").append(response.message); 
                               $(".response").removeClass('progress');
                           
                            }

                        }
                    });
                   
                              
            });
	
	
});
</script>
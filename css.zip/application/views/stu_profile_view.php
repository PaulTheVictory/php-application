
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/dataTables.css?v=1.5" />
<script src="<?php echo base_url(); ?>js/jquery.dataTables.js?v=1.0" type="text/javascript"></script>
<link href="<?php  echo base_url(); ?>css/jquery-ui.min.css?v=1.4" rel="stylesheet" type="text/css" />
 <script src="<?php  echo base_url(); ?>js/jquery-ui.min.js?v=1.3" type="text/javascript"></script>
 
<link rel="stylesheet" href="<?php echo base_url();?>css/fonts/simple-line-icons/css/simple-line-icons.css">
<link rel="stylesheet" href="<?php echo base_url();?>css/boot/bootstrap.min.css">
<script src="<?php echo base_url();?>js/bootstrap.bundle.min.js"></script>
<script src="<?php echo base_url();?>js/vendor/jquery.smartWizard.min.js"></script>
<link rel="stylesheet" href="<?php echo base_url();?>css/boot/vendor/baguetteBox.min.css">
<script src="<?php echo base_url();?>js/vendor/baguetteBox.min.js"></script>
<link rel="stylesheet" href="<?php echo base_url();?>css/boot/vendor/smart_wizard.min.css">
<link rel="stylesheet" href="<?php echo base_url();?>css/boot/vendor/bootstrap-datepicker3.min.css">
<script src="<?php echo base_url();?>js/vendor/bootstrap-datepicker.js"></script>

<script src="<?php echo base_url();?>js/vendor/jquery.validate/jquery.validate.min.js"></script>
<script src="<?php echo base_url();?>js/vendor/jquery.validate/additional-methods.min.js"></script>

  <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/lc_switch.css?v=1.3" />
<script src="<?php echo base_url(); ?>js/lc_switch.min.js?v=1.0" type="text/javascript"></script>
<script src="<?php echo base_url(); ?>js/webcam.js?v=1.1" type="text/javascript"></script>

<link rel="stylesheet" href="<?php echo base_url();?>css/boot/main.css?v=1">


<script type="text/javascript">
    
$(document).ready(function(){
    
    $(".printidcard").click(function(){
       
       var href ="<?php echo base_url(); ?>downloadidcard?userid="+'<?php echo $sid;?>';
       window.open(href,'_blank');
       
    });
    
    $(".camphoto").click(function(){
       
       if(!$("#savePic").hasClass('camphoto')){ $("#savePic").addClass('camphoto'); }
       
        Webcam.set({
            width: 450,
            height: 450,
            image_format: 'jpeg',
            jpeg_quality: 90
        });
  
        Webcam.attach( '#previewProfilePhoto' );

        function take_camphoto() {
            Webcam.snap( function(data_uri) {
                $(".image-tag").val(data_uri);
                document.getElementById('results').innerHTML = '<img src="'+data_uri+'"/>';
            } );
        }
       
    });
    
    $("#ccenter").change(function(){
                            $("#addpaymenttable1").dataTable().fnDestroy();
                            var center = $(this).val();
                            var ide = $(this).attr('data-id');
                             getNewPayments(ide,center);  
                        });
    
    $(".lcs_check").each(function(){
                            
                            if( ($(this).val() !== "0") &&($(this).val() !== "4")&&($(this).val() !== "5")&&($(this).val() !== "6")) {
                             $(this).lc_switch().lcs_on();
                            } else {
                             $(this).lc_switch().lcs_off();   
                            }
    });
    
    
     $(".feetop").find(".lcs_switch").click(function(){
                            
                            var status = "";
                            var ide = $(this).siblings(".lcs_check").attr("data-id");
                            if( ($(this).hasClass('lcs_off')) ) {
                             status ="1";
                            } else {
                              status ="0";
                            }
                            
                            if(confirm("Are you sure to enable the refund ?")) {
                                    
                                    $.get('studentprofile/ChangeStatus',{
                                                               'ide':ide,'status':status

                                                    }, function(o) { 
                                                            var obj1 = $.parseJSON(o);
                                                    if (obj1[0] === 'success') {
                                                       location.reload();
                                                    } else if (obj1[0] === 'fail') {
                                                        alert("Error!!! please try again");
                                                }
                                    });
                                }
        
                          });
	
	
	$(".editprofile").click(function(){
		
		$("#editprofile,.epsave,.epcancel").removeClass('d-none');
		$("#profileview,.editprofile").addClass('d-none');		
		
	});
	
	$(".epcancel").click(function(){
		
		$("#editprofile,.epsave,.epcancel").addClass('d-none');
		$("#profileview,.editprofile").removeClass('d-none');		
		
	});
	
	$("input.mpdob").datepicker({
		format: 'dd-mm-yyyy',
		endDate: '+0d',
		autoclose: !0,
		templates: {
			leftArrow: '<i class="simple-icon-arrow-left"></i>',
			rightArrow: '<i class="simple-icon-arrow-right"></i>'
		}

	});
	
	// Student Details Tab
	
	$("#studentdetailstab").smartWizard({
		selected: 0,
		theme: "default",
		transitionEffect: "fade",
		showStepURLhash: !1,
		anchorSettings: {
			enableAllAnchors: !0
		}
	});
	
	
	// Results datatable
	
	var oTable = $('.resulttable').dataTable({
                    "bProcessing": true,
                    "sPaginationType": "full_numbers",
                     "oLanguage": {
                        "sProcessing": "<img src='<?php echo base_url(); ?>images/loader.gif'>",
						 "sEmptyTable": "No results found"
                    },
                    'iDisplayLength': 5,
					"order": [0,"desc"],
                    "fnDrawCallback": function( oSettings ) {
						
					}
         });
	

	// Personal Details

	$(".epsave").click(function(e){
			
			if(! $("#profileform").valid()) return false;
	
			var accno = $(".mpaccountnumber").val();
			var reenteraccno = $(".mpreenteraccountnumber").val();

			if(accno!=reenteraccno && accno!=""){
				$(".alert").removeClass('alert-success').addClass('alert-danger').text("Account number mismatch");
				return false;
			}
				
	
			$(".alert").removeClass('alert-success').removeClass('alert-danger').text("");
	
			//if(formstep>0)formstepid.push("#form-step-"+formstep); else formstepid.push("#form-step-"+formstep);
	
			
			//var formid = formstepid.join(',');//console.log(formstepid);
	
			var formData = new FormData();
	
			//for(var i=0;i<formstepid.length;i++){
				var poData = $("#profileform").serializeArray();//console.log(poData);
				for (var j=0; j<poData.length; j++){
    				formData.append(poData[j].name, poData[j].value);
				}
			//}
	
			var profilepercent = 20;
			formData.append('profilepercent', profilepercent);
	
			var c=0;
            var file_data,file;
            $('input[type="file"]').each(function(){
                  file_data = $('input[type="file"]')[c].files; // get multiple files from input file
                  //console.log(file_data);
               for(var i = 0;i<file_data.length;i++){
                   formData.append('file[]', file_data[i]); // we can put more than 1 image file
               }
              c++;
           }); 
			
			var comments = $("#spcomments").val();
			formData.append('comments', comments);
	
			//var formData = new FormData(this);
			
           $.ajax({
                type: 'POST',
                url: 'studentprofile/myprofileSubmit',
                data: formData,
			    contentType: false,
    			processData: false,
                success: function(response) {
                   
					var obj1 = $.parseJSON(response);
										
					if(obj1['status']=="success"){
						
						//$(".alert").addClass('alert-success').text("Profile details updated");
						$('#profileupdateModal').modal({show:true});
						
						$('#profileupdateModal').on('hidden.bs.modal', function () {
						  location.reload();
						});
						
						setTimeout(function(){
							$(".alert").removeClass('alert-success').text("");
						},3000);
						
					}else if(obj1['status']=="exists"){
						$(".alert").addClass('alert-danger').text("Already exists");
					}else if(obj1['status']=="empty"){
						$(".alert").addClass('alert-danger').text("Profile data not found");
					}else if(obj1['status']=="fail"){
						$(".alert").addClass('alert-danger').text("Submission failed");
					}else if(obj1['status']=="uempty"){
						$(".alert").addClass('alert-danger').text("Upload marksheets");
					}else if(obj1['status']=="ularge"){
						$(".alert").addClass('alert-danger').text("Each upload file must be less than 1MB");
					}else if(obj1['status']=="exfail"){
						$(".alert").addClass('alert-danger').text("Support extension JPG,JPEG,PNG,PDF only");
					}else if(obj1['status']==""){
						$(".alert").addClass('alert-danger').text("Please try again.");
					}
					
                }

            });
			
	});
			
	
	var dropZoneId = "drop-zone";
	var buttonId = "clickHere";
	var mouseOverClass = "mouse-over";
	var dropZone = $("#" + dropZoneId);
	var inputFile = dropZone.find("input");
	var finalFiles = {};
  

  inputFile.on('change', function(e) {
    finalFiles = {};
    $('#filename').html("");
    var fileNum = this.files.length,
      initial = 0,
      counter = 0;

    $.each(this.files,function(idx,elm){
       finalFiles[idx]=elm;
    });

    for (initial; initial < fileNum; initial++) {
      counter = counter + 1;
      $('#filename').append('<div id="file_'+ initial +'" class="file_ms px-2">' + this.files[initial].name + '&nbsp;&nbsp;<span class="glyph-icon iconsminds-close closeBtn" onclick="removeLine(this)" title="remove">X</span></div>');
    }
  });
	
	var fathername = "<?php if($stuprofile['fathername']!="" && $stuprofile['fathername']!="0"){ echo $stuprofile['fathername'];}?>";
	var fatheroccupation = "<?php if($stuprofile['fatheroccupation']!="" && $stuprofile['fatheroccupation']!="0"){ echo $stuprofile['fatheroccupation'];}?>";
	var fatheremail = "<?php if($stuprofile['fatheremail']!="" && $stuprofile['fatheremail']!="0"){ echo $stuprofile['fatheremail'];}?>";
	var fathercode = "<?php if($stuprofile['fathercode']!="" && $stuprofile['fathercode']!="0"){ echo $stuprofile['fathercode'];}?>";
	var fatherphone = "<?php if($stuprofile['fatherphone']!="" && $stuprofile['fatherphone']!="0"){ echo $stuprofile['fatherphone'];}?>";
	var mothername = "<?php if($stuprofile['mothername']!="" && $stuprofile['mothername']!="0"){ echo $stuprofile['mothername'];}?>";
	var mothercode = "<?php if($stuprofile['mothercode']!="" && $stuprofile['mothercode']!="0"){ echo $stuprofile['mothercode'];}?>";
	var motherphone = "<?php if($stuprofile['motherphone']!="" && $stuprofile['motherphone']!="0"){ echo $stuprofile['motherphone'];}?>";
	var motheroccupation = "<?php if($stuprofile['motheroccupation']!="" && $stuprofile['motheroccupation']!="0"){ echo $stuprofile['motheroccupation'];}?>";
	var motheremail = "<?php if($stuprofile['motheremail']!="" && $stuprofile['motheremail']!="0"){ echo $stuprofile['motheremail'];}?>";
	
	var mcode = "<?php if($stuprofile['smcode']!="" && $stuprofile['smcode']!="0"){ echo $stuprofile['smcode'];}else{echo $stuprofile['sumcode'];}?>";
	
	$(".mpfathername").val(fathername);
	$(".mpfatheroccupation").val(fatheroccupation);
	$(".mpfatheremail").val(fatheremail);
	if(fathercode!="")$(".mpfathercode").val(fathercode); else $(".mpfathercode").val("+91");
	if(fathercode=="+91")$(".mpfathermobile").val(fatherphone); else $(".mpfathermobile").val(fatherphone).attr({"minlength":3,"maxlength":20});
	$(".mpmothername").val(mothername);
	if(mothercode!="")$(".mpmothercode").val(mothercode); else $(".mpmothercode").val("+91");
	if(mothercode=="+91")$(".mpmothermobile").val(motherphone);else $(".mpmothermobile").val(motherphone).attr({"minlength":3,"maxlength":20});
	$(".mpmotheremail").val(motheremail);
	$(".mpmotheroccupation").val(motheroccupation);
	
	if(mcode!="")$(".mpmcode").val(mcode); else $(".mpmcode").val("");
	
	var communicationcontact = "<?php if($stuprofile['communicationcontact']!="" && $stuprofile['communicationcontact']!="0"){ echo $stuprofile['communicationcontact'];}?>";
	var nationality = "<?php if($stuprofile['nationality']!="" && $stuprofile['nationality']!="0"){ echo $stuprofile['nationality'];}?>";
	var category = "<?php if($stuprofile['category']!="" && $stuprofile['category']!="0"){ echo $stuprofile['category'];}?>";
	var bloodgroup = "<?php if($stuprofile['bloodgroup']!="" && $stuprofile['bloodgroup']!="0"){ echo $stuprofile['bloodgroup'];}?>";
	var classstudy = "<?php if($stuprofile['classstudy']!="" && $stuprofile['classstudy']!="0"){ echo $stuprofile['classstudy'];}?>";
	var stream = "<?php if($stuprofile['stream']!="" && $stuprofile['stream']!="0"){ echo $stuprofile['stream'];}?>";
	
	$(".mpcomcontact").val(communicationcontact).attr('value',communicationcontact);
	$(".mpnationality").val(nationality).attr('value',nationality);
	$(".mpcategory").val(category).attr('value',category);
	$(".mpbloodgroup").val(bloodgroup).attr('value',bloodgroup);
	$(".mpclassstudy").val(classstudy).attr('value',classstudy);
	$(".mpstream").val(stream).attr('value',stream);
	
	//var schoolcollegename = "<?php //if($stuprofile['schoolcollegename']!="" && $stuprofile['schoolcollegename']!="0"){ echo $stuprofile['schoolcollegename'];}?>";
	var edudistrict = "<?php if($stuprofile['edudistrict']!="" && $stuprofile['edudistrict']!="0"){ echo $stuprofile['edudistrict'];}?>";
	var edustate = "<?php if($stuprofile['edustate']!="" && $stuprofile['edustate']!="0"){ echo $stuprofile['edustate'];}?>";
	//var edupost = "<?php //if($stuprofile['edupost']!="" && $stuprofile['edupost']!="0"){ echo $stuprofile['edupost'];}?>";
	var educountry = "<?php if($stuprofile['educountry']!="" && $stuprofile['educountry']!="0"){ echo $stuprofile['educountry'];}?>";
	var examboard = "<?php if($stuprofile['examboard']!="" && $stuprofile['examboard']!="0"){ echo $stuprofile['examboard'];}?>";
	var examclass = "<?php if($stuprofile['examclass']!="" && $stuprofile['examclass']!="0"){ echo $stuprofile['examclass'];}?>";
	var eligiblescholar = "<?php if($stuprofile['eligiblescholar']!="" && $stuprofile['eligiblescholar']!="0"){ echo $stuprofile['eligiblescholar'];}?>";
	var medium = "<?php if($stuprofile['medium']!="" && $stuprofile['medium']!="0"){ echo $stuprofile['medium'];}?>";
	var mocktype = "<?php if($stuprofile['mocktype']!="" && $stuprofile['mocktype']!="0"){ echo $stuprofile['mocktype'];}?>";

	//$(".mpcollegename").val(schoolcollegename).attr('value',schoolcollegename);
	//$(".mpdistrict").val(edudistrict).attr('value',edudistrict);
	$(".mpstate").val(edustate).attr('value',edustate);
	selectdiscrict('.mpdistrict',edustate,edudistrict);
	//$(".mppost").val(edupost).attr('value',edupost);
	$(".mpcountry").val(educountry).attr('value',educountry);
	$(".mpexamboard").val(examboard).attr('value',examboard);
	$(".mpexamclass").val(examclass).attr('value',examclass);
	$(".mpscholarship").val(eligiblescholar).attr('value',eligiblescholar);
	$(".mpmedium").val(medium).attr('value',medium);
	$(".mpmocktype").val(mocktype).attr('value',mocktype);
	
	
	var contactdistrict = "<?php if($stuprofile['contactdistrict']!="" && $stuprofile['contactdistrict']!="0"){ echo $stuprofile['contactdistrict'];}?>";
	var contactstate = "<?php if($stuprofile['contactstate']!="" && $stuprofile['contactstate']!="0"){ echo $stuprofile['contactstate'];}?>";
	//var contactpost = "<?php //if($stuprofile['contactpost']!="" && $stuprofile['contactpost']!="0"){ echo $stuprofile['contactpost'];}?>";
	var contactcountry = "<?php if($stuprofile['contactcountry']!="" && $stuprofile['contactcountry']!="0"){ echo $stuprofile['contactcountry'];}?>";
	var bankname = "<?php if($stuprofile['bankname']!="" && $stuprofile['bankname']!="0"){ echo $stuprofile['bankname'];}?>";
	
	var wacode = "<?php if($stuprofile['wacode']!="" && $stuprofile['wacode']!="0"){ echo $stuprofile['wacode'];}?>";
	var whatsappno = "<?php if($stuprofile['whatsappno']!="" && $stuprofile['whatsappno']!="0"){ echo $stuprofile['whatsappno'];}else{echo "";} ?>";
	
	//$(".mpcontactdistrict").val(contactdistrict).attr('value',contactdistrict);
	//$(".mpcontactstate").val(contactstate).attr('value',contactstate);
	selectstate('.mpcontactstate',contactcountry,contactstate);
	//selectdiscrict('.mpcontactdistrict',contactstate,contactdistrict);
	//$(".mpcontactpost").val(contactpost).attr('value',contactpost);
	$(".mpcontactcountry").val(contactcountry).attr('value',contactcountry);
	//$(".mpbankname").val(bankname).attr('value',bankname);
	if(wacode!="")$(".mpwacode").val(wacode); else $(".mpwacode").val("+91");
	if(wacode=="+91")$(".mpwhatsappno").val(whatsappno); else $(".mpwhatsappno").val(whatsappno).attr({"minlength":3,"maxlength":20});
	
	$(".mpcontactcountry").on('change', function(e) {
		
		var country = $(this).val();
		
		$.ajax({
                type: 'POST',
                url: 'stumyprofile/getCountryStateList',
                data: {'country':country},
                success: function(response) {
					
					var obj1 = $.parseJSON(response);
					
					if(obj1['stateoption']!=""){
						$(".mpcontactstate").remove();
						$(".constatelist").prepend('<select class="form-control mpcontactstate" name="mpcontactstate" value="">'+obj1['stateoption']+"</select>");
					}
					else{
						$(".mpcontactstate").remove();
						$(".constatelist").prepend('<input type="text" class="form-control mpcontactstate" name="mpcontactstate" placeholder=" " value="">');
					}
					
				}
			
		});
		
		
	});
	
	
	$(document).on('change','.mpcontactstate',function(){
		
		$(this).attr('value',$(this).val());
		
	});
	
	
	$(".mpfathercode,.mpmothercode,.mpwacode,.mpmcode").change(function(){
		
		var sumcode = $(this).val();
		
		if(sumcode!="+91"){
			$(this).closest('.form-row').find("input[type='number']").attr('minlength',3).attr('maxlength',20);
		}else{
			$(this).closest('.form-row').find("input[type='number']").attr('minlength',10).attr('maxlength',10);
		}
		
	});
	
	
	// Upload Profile Picture
	
	$('.profileedit').on('click', function(e){
        $('#changeProfilePhotoModal').modal({show:true});        
    });	
	$('#profileImage').on('change', function()	{
                if($("#savePic").hasClass('camphoto')){ $("#savePic").removeClass('camphoto'); }
		$("#previewProfilePhoto").html('');
		$("#previewProfilePhoto").html('Uploading....');
		uploadImage();
		//$("#cropImage").submit(function(){
		
			
			
		//});
		
		/*$("#cropImage").ajaxForm(
		{
		target: '#previewProfilePhoto',
		success:    function() { 
				$('img#photo').imgAreaSelect({
				aspectRatio: '1:1',
				onSelectEnd: getSizes,
			});
			$('#imageName').val($('#photo').attr('file-name'));
			}
		}).submit();*/

	});	
        
        $('#savePic').on('click', function(e){
            
                if($(this).hasClass("camphoto")){
                    
                    takeSnapShot();
                    
                } else {
                    if($("#profileImage").val()!="")location.reload();
                    else $(".alert").addClass('alert-danger').text("Upload image");
                }
		
	});	
        
        function b64toBlob(b64Data, contentType, sliceSize) {
        contentType = contentType || '';
        sliceSize = sliceSize || 512;

        var byteCharacters = atob(b64Data);
        var byteArrays = [];

        for (var offset = 0; offset < byteCharacters.length; offset += sliceSize) {
            var slice = byteCharacters.slice(offset, offset + sliceSize);

            var byteNumbers = new Array(slice.length);
            for (var i = 0; i < slice.length; i++) {
                byteNumbers[i] = slice.charCodeAt(i);
            }

            var byteArray = new Uint8Array(byteNumbers);

            byteArrays.push(byteArray);
        }

      var blob = new Blob(byteArrays, {type: contentType});
      return blob;
}

         takeSnapShot = () => {
             
            Webcam.snap( function(data_uri) {
                        
                            // Get the form
                var form = document.getElementById("cropImage");

                var ImageURL = data_uri;          
                var block = ImageURL.split(";");              
                var contentType = block[0].split(":")[1];              
                var realData = block[1].split(",")[1];          
                var blob = b64toBlob(realData, contentType);
              
                var fd = new FormData(form);
                fd.append("simage", blob);

         
                $.ajax({
                    url:"studentprofile/updateFromWebcam",
                    data: fd,
                    type:"POST",
                    contentType:false,
                    processData:false,
                    cache:false,
                    success: function(response) { location.reload();}

                });
            });
             
         };
	
        
        uploadImage = () => {
            
            var formData = new FormData();
		
			var poData = $("#cropImage").serializeArray();//console.log(poData);
			for (var j=0; j<poData.length; j++){
				formData.append(poData[j].name, poData[j].value);
			}
	
			var c=0;
            var file_data;
			file_data = $('#profileImage')[0].files; // get multiple files from input file
			  //console.log(file_data);
		    for(var i = 0;i<file_data.length;i++){
			   formData.append('profileImage', file_data[i]); // we can put more than 1 image file
		    }
			
			$.ajax({
					type: 'POST',
					url: 'studentprofile/changeProfilePhoto',
					data: formData,
					contentType: false,
					processData: false,
					success: function(response) {
						
                                                $("#previewProfilePhoto").css("width","auto");
                                                $("#previewProfilePhoto").css("height","auto");
						$("#previewProfilePhoto").html(response);
												
						$('#imageName').val($('#photo').attr('file-name'));
                                                
                                                var ppimgsrc = $('#photo').attr('src');
						$(".img-thumbnail,.user img").attr("src",ppimgsrc);
					}

			});
            
        };
	
	
	$("input,select,textarea").click(function(){
		
		$(".alert").removeClass('alert-danger alert-success').text("");
		
	});
		
	$('#savePhoto').on('click', function(e){
    e.preventDefault();
    params = {
            targetUrl: 'stumyprofile/saveProfilePhoto',
            action: 'save',
            x_axis: $('#hdn-x1-axis').val(),
            y_axis : $('#hdn-y1-axis').val(),
            x2_axis: $('#hdn-x2-axis').val(),
            y2_axis : $('#hdn-y2-axis').val(),
            thumb_width : $('#hdn-thumb-width').val(),
            thumb_height:$('#hdn-thumb-height').val()
        };
        saveCropImage(params);
    });   
    function getSizes(img, obj){
        var x_axis = obj.x1;
        var x2_axis = obj.x2;
        var y_axis = obj.y1;
        var y2_axis = obj.y2;
        var thumb_width = obj.width;
        var thumb_height = obj.height;
        if(thumb_width > 0) {
			$('#hdn-x1-axis').val(x_axis);
			$('#hdn-y1-axis').val(y_axis);
			$('#hdn-x2-axis').val(x2_axis);
			$('#hdn-y2-axis').val(y2_axis);
			$('#hdn-thumb-width').val(thumb_width);
			$('#hdn-thumb-height').val(thumb_height);
        } else {
            alert("Please select portion..!");
		}
    }   
    function saveCropImage(params) {
		$.ajax({
			url: params['targetUrl'],
			cache: false,
			dataType: "html",
			data: {
				action: params['action'],
				studentid: $('#studentid').val(),
				t: 'ajax',
				w1:params['thumb_width'],
				x1:params['x_axis'],
				h1:params['thumb_height'],
				y1:params['y_axis'],
				x2:params['x2_axis'],
				y2:params['y2_axis'],
				imageName :$('#imageName').val()
			},
			type: 'Post',
		   	success: function (response) {
					$('#changeProfilePhotoModal').modal('hide');
					$(".imgareaselect-border1,.imgareaselect-border2,.imgareaselect-border3,.imgareaselect-border4,.imgareaselect-border2,.imgareaselect-outer").css('display', 'none');
					console.log(response);
					$("#profilePhoto").attr('src', response);
					$("#previewProfilePhoto").html('');
					$("#profileImage").val();
					//$("#changeProfilePhoto").text('Change Photo');
			},
			error: function (xhr, ajaxOptions, thrownError) {
				alert('status Code:' + xhr.status + 'Error Message :' + thrownError);
			}
		});
    }
	
	$(".pchange").each(function(){

                            $(this).click(function(){ 

                               $(".courseconfirm").trigger('click'); 
                                var center = $(this).attr("data-center");
                                var sid = $(this).attr("data-sid");
                                var cid = $(this).attr("data-cid");
                                var rid = $(this).attr("data-id");
                               
                                $(".paysave").attr("data-center",center);
                                $(".paysave").attr("data-sid",sid);
                                $(".paysave").attr("data-cid",cid);
                                 $(".paysave").attr("data-rid",rid);
                                getRefundPayments(sid,cid,center); 

                              });
                        

                          });
                          
         $(".cenchange").each(function(){

                            $(this).click(function(){ 

                               $(".centerconfirm").trigger('click'); 
                           
                                var cid = $(this).attr("data-cid");
                                var center = $(this).attr("data-center");
                                var crid = $(this).attr("data-crid");                              ;
                               
                                selectcenter(cid,$("#newcenter"));
                                
                                $(".censave").attr("data-center",center);
                                $(".censave").attr("data-cid",cid);
                                $(".censave").attr("data-rid",crid);

                              });
                        

                          });
         
	  $("#cname").autocomplete({
            source: function (request, response) {
                $.ajax({
                    url: "courses/courseSearch",
                    contentType: "application/jsonp",
                    
                    data: {
                        term: request.term
                    },
                    success: function (data) {
                        data = $.parseJSON(data);
                        response(
                                $.map(data, function (item) {
                                    return {
                                        value: item.coursename,
                                        ide:item.ide
                                    };
                                })
                                );
                    }
                });
            },
            select: function (event, ui) {
                
                $("#cname").attr("data-cname",ui.item.ide);
                selectcenter(ui.item.ide,$("#ccenter"));
          
            }
            
        })._renderItem = function (ul, item) {

             return $("<li></li>")
                    .data("item.autocomplete", item)
                    .append('<a><div style="height: auto; width: auto; display: inline-block;"><p style="margin: 0px; padding: 0px; height: 20px; width: 100%; line-height: 30px;">' + item.courseid + ' , '+item.coursename+'</p></div></a>')
                    .appendTo(ul);
        };
        
        $(".paysave").click(function(){
        
        if($(this).hasClass("progressing")) {  return;}
        
        $(this).text("Progressing...");
        var attr = $("#cname").attr('data-cname');

        if (typeof attr !== 'undefined' && attr !== false) {
                var chk = $("#cname").attr("data-cname");
                if(chk === "") { alert("Plese select course name for change");return;}
        } else {
            alert("Plese select course name for change");return;
        }
        
        var chkecen =  $("#ccenter").val();
        if(chkecen === "") {  alert("Plese enter the center for course change");return;}
        
        var chkefund = $(".prefund").text();
       // if( chkefund === "0" || chkefund === "") {  alert("Plese enter refund amount for change");return;}
       
       $(this).addClass("progressing");
       var sid = $(this).attr("data-sid");
       var cid = $(this).attr("data-cid");
       var center = $(this).attr("data-center");    
       var ncenter = $("#ccenter").val();
       var ncid = $("#cname").attr("data-cname");
       var rid = $(this).attr("data-rid");
       var totalrefnd = $(".prefund").text();
       
       var refundapp =$("#ccrefund").val();
       
       var stupayid=""; var amount=""; var remit=""; var refund = '';
        $('#addpaymenttable').find("tr .desc").each(function(){
                            
               stupayid += $(this).attr("attr-descid")+"|";
               amount   += $(this).closest("tr").find(".amount").text()+"|";
               remit    += $(this).closest("tr").find(".paid").text()+"|";
               refund   += $(this).closest("tr").find(".refundamt").val()+"|";
        });
       
       
        $.get('courses/CourseChange',{
                 'sid':sid,'cid':cid,'center':center,"ncenter": ncenter
                        ,"ncid":ncid,'stupayid':stupayid,'amount':amount,'remit':remit,'refund':refund,"rid":rid,'totalr':totalrefnd,'refundapp':refundapp

                 }, function(o) { 
                         var obj1 = $.parseJSON(o);
                if (obj1[0] === 'success') {
                     
                      $(".paysave").removeClass("progressing");                     
                      location.reload();
                      

                 } else if (obj1[0] === 'fail') {
                     $(".paysave").removeClass("progressing");
                      $(".paysave").text("Save");
                     alert(obj1[1]);

                 }
        });
        
       
    });
    
    
        $(".censave").click(function(){
        
        if($(this).hasClass("progressing")) { return;}
        
        var newcenter =  $("#newcenter").val();
        if(newcenter === "") {  alert("Plese enter the center for center change");return;}
        
       $(this).addClass("progressing");
       var cid = $(this).attr("data-cid");
       var oldcenter = $(this).attr("data-center");    
       var rid = $(this).attr("data-rid");
       
       
        $.get('courses/CenterChange',{
                 'cid':cid,'center':oldcenter,"ncenter": newcenter,"rid":rid

                 }, function(o) { 
                         var obj1 = $.parseJSON(o);
                if (obj1[0] === 'success') {
                     
                      $(".censave").removeClass("progressing"); 
                      location.reload();
                      

                 } else if (obj1[0] === 'fail') {
                     $(".censave").removeClass("progressing");
                     alert(obj1[1]);

                 }
        });
        
       
    });
    
    $(document).on("click",".addrefund",function(){
          
                var ide = $(this).attr("data-id");
                var sid = '<?php echo $sid;?>';
               
                $(location).prop('href', 'requestrefund?id='+ide+"&sid="+sid);
            
                
	});
	
	
	// Change Password
	
	$(document).on("click",".changepassword",function(){
		
		$('#changepasswordModal').modal({show:true});				
		
	});
	
	$('#changepasswordModal').on('hidden.bs.modal', function () {
	 	$("#updatepwdForm").find("input").val("");
		$('#updatepwdForm input').removeClass('error');
		$('#updatepwdForm div.error').hide();
	});
	
	$(document).on("click",".updatepassword",function(){
		
			if(! $("#updatepwdForm").valid()) return false;
			
		
			$("#changepasswordModal .alert").removeClass('alert-success').removeClass('alert-danger').text("");
		
			var cppassword = $("#cppassword").val();
			var cpconfpassword = $("#cpconfpassword").val();

			if(cppassword!=cpconfpassword && cppassword!=""){
				$("#changepasswordModal .alert").removeClass('alert-success').addClass('alert-danger').text("Password mismatch");
				return false;
			}
				
	
			$("#changepasswordModal .alert").removeClass('alert-success').removeClass('alert-danger').text("");
		
		
			var formData = new FormData();

			var poData = $("#updatepwdForm").serializeArray();//console.log(poData);
			for (var j=0; j<poData.length; j++){
				formData.append(poData[j].name, poData[j].value);
			}
		
			var userid = "<?php echo $sid; ?>";
			formData.append("userid", userid);
			
           $.ajax({
                type: 'POST',
                url: 'studentprofile/changePassword',
                data: formData,
			    contentType: false,
    			processData: false,
                success: function(response) {
                   
					var obj1 = $.parseJSON(response);
										
					if(obj1['status']=="success"){
						
						$("#changepasswordModal .alert").addClass('alert-success').text("Profile password changed successfully");
						$("#updatepwdForm").find("input").val("");
						
						setTimeout(function(){
							$('#changepasswordModal').modal('hide');
							$("#changepasswordModal .alert").removeClass('alert-success alert-danger').text("");
						},3000);
						
					}else if(obj1['status']=="fail"){
						$("#changepasswordModal .alert").addClass('alert-danger').text("Password update failed");
					}else if(obj1['status']==""){
						$("#changepasswordModal .alert").addClass('alert-danger').text("Please try again.");
					}
					
                }

            });
		
	});
	
	
	// Add Admission
	
	$(document).on("click",".addadmission",function(){
		
		$('#addadmissionModal').modal({show:true});				
		
	});
	
	$('#addadmissionModal').on('hidden.bs.modal', function () {
	 	$("#addadmissionForm").find("input,select").val("").attr("value","");
		$('#addadmissionForm input').removeClass('error');
		$('#addadmissionForm div.error').hide();
		$("#addadmissionModal .alert").removeClass('alert-success alert-danger').text("");
	});
	
	
	$(document).on("change",".coursename",function(){
		
		var courseid = $(".coursename").val();
		var userid = "<?php echo $sid; ?>";
		
		$(this).attr('value',courseid);
		
		if(courseid!=""){
		
		$.post('studentprofile/getCoursewisecenterOptions',{
			'userid':userid,
			'courseid':courseid
		},function(response){
			
			var obj1 = $.parseJSON(response); 
			
			if(obj1['center']!=""){
						
				$(".coursecenter").html('<option value="">Select Center</option>'+obj1['center']);

			}else{
				$(".coursecenter").html('<option value="">Select Center</option>');
			}
			
		});
			
		}
		
		
	});
	
	$(document).on("change",".coursecenter",function(){
		$(this).attr('value',$(this).val());
	});
	
	
	$(document).on("click",".addadmissionbtn",function(){
		
			if(! $("#addadmissionForm").valid()) return false;
			
			$("#addadmissionModal .alert").removeClass('alert-success alert-danger').text("");
								
			var formData = new FormData();

			var poData = $("#addadmissionForm").serializeArray();//console.log(poData);
			for (var j=0; j<poData.length; j++){
				formData.append(poData[j].name, poData[j].value);
			}
		
			var userid = "<?php echo $sid; ?>";
			formData.append("userid", userid);
			
           $.ajax({
                type: 'POST',
                url: 'studentprofile/addAdmission',
                data: formData,
			    contentType: false,
    			processData: false,
                success: function(response) {
                   
					var obj1 = $.parseJSON(response);
										
					if(obj1[0]=="success"){
						
						$("#addadmissionModal .alert").addClass('alert-success').text("Admission created successfully");
						$("#addadmissionForm").find("input,select").val("").attr("value","");
						
						setTimeout(function(){
							location.reload();
							$("#addadmissionModal .alert").removeClass('alert-success alert-danger').text("");
						},3000);
						
					}else if(obj1[0]=="exists"){
						$("#addadmissionModal .alert").addClass('alert-danger').text("Course already applied");
					}else if(obj1[0]=="fail"){
						$("#addadmissionModal .alert").addClass('alert-danger').text("Admission failed");
					}else if(obj1[0]==""){
						$("#addadmissionModal .alert").addClass('alert-danger').text("Please try again.");
					}
					
                }

            });
		
	});
	
	
	// Report Card
	
	$(document).on("click",".getreportcard",function(){
		
		$('#reportcardModal').modal({show:true});	
				
	});
	
	$('.input-daterange input').datepicker({
		format: "dd-mm-yyyy",
		endDate: '+0d',
		autoclose: !0,
		templates: {
			leftArrow: '<i class="simple-icon-arrow-left"></i>',
			rightArrow: '<i class="simple-icon-arrow-right"></i>'
		}
	});	
	
	$(".reportcardbtn").click(function(){
     
     var sdate = $(".fromdate").val();
     var edate = $(".todate").val();
		
	if(sdate==""){ alert("Select from date");return;}
	if(edate==""){ alert("Select to date");return;}	
		
     var url = 'studentprofile/studentreportcard?sid=<?php echo $sid; ?>&sdate='+sdate+'&edate='+edate;
     window.open(url,'_blank');
     
  });
	
	$(document).on("click",".emailreportcard",function(){
		
		var sdate = $(".fromdate").val();
     	var edate = $(".todate").val();
		
		if(sdate==""){ alert("Select from date");return;}
		if(edate==""){ alert("Select to date");return;}	
		
		if($(".emailreportcard").hasClass('process')){
			
			$(".alert").addClass('alert-danger').text("Please wait while sending...");
			
		}else{
		
			$(".emailreportcard").addClass('process');
			$(".alert").removeClass('alert-danger').addClass('alert-success').text("Sending mail...");
         				
		var r = confirm("Are you sure to send mail?");
		
		if(r){
			
           $.ajax({
                type: 'POST',
                url: 'studentprofile/sendEmailStudentReportcard',
                data: {"sid":"<?php echo $sid; ?>","sdate":sdate,"edate":edate},
                success: function(response) {
                   										
					if(response==""){
						
						$("#reportcardModal .alert").addClass('alert-success').text("Report card email sent successfully");
						$("#reportcardForm").find("input,select").val("").attr("value","");
						
						setTimeout(function(){
							$(".emailreportcard").removeClass('process');
							$("#reportcardModal .alert").removeClass('alert-success alert-danger').text("");
						},3000);
						
					}else{
						$(".emailreportcard").removeClass('process');
						$("#reportcardModal .alert").addClass('alert-danger').text("Please try again.");
					}
					
                }

            });
			
		}
			
		}
		
	});
	
	
});


function selectcenter(ide,obj){
	
	$.ajax({
		type: 'POST',
		url: 'courses/GetCourseCenterList',
		data: {'ide':ide},
		success: function(response) {

                        var obj1 = $.parseJSON(response);
                        $(obj).html(obj1['center']);
                        $(obj).attr("data-id",ide);                        
			//$("#ccenter").html(obj1['center']);
                       // $("#ccenter").attr("data-id",ide);

		}

	});
   
}
	
function selectdiscrict(classname,state,district){
	
	$.ajax({
		type: 'POST',
		url: 'stumyprofile/getDistrictList',
		data: {'state':state},
		success: function(response) {

			var obj1 = $.parseJSON(response);

			$(classname).html(obj1['districtoption']);
			$(classname).val(district).attr('value',district);

		}

	});
	
}
	
function selectstate(classname,country,state){
	
	$.ajax({
		type: 'POST',
		url: 'stumyprofile/getCountryStateList',
		data: {'country':country},
		success: function(response) {

			var obj1 = $.parseJSON(response);

			if(obj1['stateoption']!=""){
				$(classname).remove();
				$(".constatelist").prepend('<select class="form-control mpcontactstate" name="mpcontactstate" value="">'+obj1['stateoption']+"</select>");
				$(classname).val(state).attr('value',state);
			}
			else{
				$(classname).remove();
				$(".constatelist").prepend('<input type="text" class="form-control mpcontactstate" name="mpcontactstate" placeholder=" " value="'+state+'">');
			}
			
		}

	});
	
}
	
var dropZoneId = "drop-zone";
var buttonId = "clickHere";
var mouseOverClass = "mouse-over";
var dropZone = $("#" + dropZoneId);
var inputFile = dropZone.find("input");
var finalFiles = {};
	
$(function() {
	
var ooleft = dropZone.offset().left;
  var ooright = dropZone.outerWidth() + ooleft;
  var ootop = dropZone.offset().top;
  var oobottom = dropZone.outerHeight() + ootop;
 
  document.getElementById(dropZoneId).addEventListener("dragover", function(e) {
    e.preventDefault();
    e.stopPropagation();
    dropZone.addClass(mouseOverClass);
    var x = e.pageX;
    var y = e.pageY;

    if (!(x < ooleft || x > ooright || y < ootop || y > oobottom)) {
      inputFile.offset({
        top: y - 15,
        left: x - 100
      });
    } else {
      inputFile.offset({
        top: -400,
        left: -400
      });
    }

  }, true);

  if (buttonId != "") {
    var clickZone = $("#" + buttonId);

    var oleft = clickZone.offset().left;
    var oright = clickZone.outerWidth() + oleft;
    var otop = clickZone.offset().top;
    var obottom = clickZone.outerHeight() + otop;

    $("#" + buttonId).mousemove(function(e) {
      var x = e.pageX;
      var y = e.pageY;
      if (!(x < oleft || x > oright || y < otop || y > obottom)) {
        inputFile.offset({
          top: y - 15,
          left: x - 160
        });
      } else {
        inputFile.offset({
          top: -400,
          left: -400
        });
      }
    });
  }

  document.getElementById(dropZoneId).addEventListener("drop", function(e) {
    $("#" + dropZoneId).removeClass(mouseOverClass);
  }, true);

});
	
function removeLine(obj)
{
  inputFile.val('');
  var jqObj = $(obj);
  var container = jqObj.closest('div');
  var index = container.attr("id").split('_')[1];
  container.remove(); 

  delete finalFiles[index];
  //console.log(finalFiles);
}
	
function Be(e) {
	return !!$().validate && !!$(e).valid()
	//return true;
}



 function getRefundPayments(sid,cid,center) {
  
  var columnData2 = [
                    { "data": "desc_order" },
                    { "data": "description" },
                    { "data": "amount" },
                    { "data": "paid" },
                    { "data": "sac" }
                    
                  ];
   var oTable2 = $('#addpaymenttable').dataTable({
                    "bProcessing": true,
                    "bServerSide": true,
                    "sPaginationType": "full_numbers",
                    "ajax": {
                    "url": 'coursechange/getRefundPaymentLists',
                    "type": "POST",
                    "data":{ "sid": sid,"cid": cid,"center": center }
                     }, 
                     "oLanguage": {
                        "sProcessing": "<img src='<?php echo base_url(); ?>images/loader.gif'>"
                    },
                    'iDisplayLength': 20,
                    "columns": columnData2,
                    "order": [[ 0, "asc" ]],
                    "fnDrawCallback": function( oSettings ) {
                        var refund = 0;       var total = 0;             
                        $('#addpaymenttable').find("tr .paid").each(function(){
                            
                            total = total+parseFloat($(this).text());
        
                          });
                          
                           $('#addpaymenttable').find("tr .refundamt").each(function(){
                            
                                $(this).keyup(function(){
                                    
                                    var ramt = 0;
                                    $('#addpaymenttable').find("tr .refundamt").each(function(){ 
                                        var yu  = $(this).val();
                                        yu = (yu === "")?0:yu;
                                        ramt = ramt + parseFloat(yu);
                                     });
                                     $(".prefund").text(ramt);   
                                     
                                     var yu1  = $(this).val();
                                     var yu2 =  $(this).closest("tr").find(".paid").text();
                                     
                                     if(parseFloat(yu1) > parseFloat(yu2)) { $(this).val("0");alert("CF amount should not greater than the remitted amount");}
                                });
                                        
                          });
                                                 
                          
                       $(".premit").text(total);    
                        $(".prefund").text(refund);
                        
                         $(".paycancel").click(function(){
                            oTable2.fnDestroy();$(".paysave").removeClass("progressing");
                         });
                                      
                    }
         }); 
         }
         
         
          function getNewPayments(cid,center) {
  
  var columnData2 = [
                    { "data": "sno" },
                    { "data": "description" },
                    { "data": "total" }
                   
                    
                  ];
    var oTable3 = $('#addpaymenttable1').dataTable({
                    "bProcessing": true,
                    "bServerSide": true,
                    "sPaginationType": "full_numbers",
                    "ajax": {
                    "url": 'refund/getNewCoursePaymentLists',
                    "type": "POST",
                    "data":{ "cid": cid,"center": center }
                     }, 
                     "oLanguage": {
                        "sProcessing": "<img src='<?php echo base_url(); ?>images/loader.gif'>"
                    },
                    'iDisplayLength': 20,
                    "columns": columnData2,
                    "order": [[ 0, "asc" ]],
                    "fnDrawCallback": function( oSettings ) {
                      
                                      
                    }
         }); 
         }
              
	
</script>

<style>
		
	.myprofile h1{font-family: Segoe UI;font-size: 24px;font-weight: bold;color: #364159;text-transform: capitalize}
	.myprofile .card{background: linear-gradient(0deg, #FFFFFF, #FFFFFF), #C4C4C4;box-shadow: 0px 0px 7px rgba(196, 196, 196, 0.35);border-radius: 10px;}
	.myprofile h2{color: #0332AA;font-size: 24px;font-weight: bold;line-height: 36px;}
	
	.border-right{border-right: 1px solid #D7DFF0!important;}
		
	.btn-primary{width: auto}
	.btn-primary.disabled, .btn-primary:disabled{background: #9AADDD;color: #ffffff;}
	
	.card h5{margin-bottom: 1rem;}
	h5{font-weight: bold;}
	.badge-outline-secondary, .badge-outline-theme-2{border: 1px solid #889DC6;color: #889DC6;background: #F6F7FA;}
	.badge{font-size: 12px;margin-right: 5px}
	
	.courseinfo .col-right .card .card-body{padding: 0;}
	.courseinfo .border-bottom{border-bottom: 1px solid #D7DFF0!important;}
	.col-right h5{padding: 1.2rem}
 
	.icon-status{background: url("img/icons/status-b.png") no-repeat;width: 15px;height: 15px;display: inline-block;vertical-align: middle}
	
	td.totalfee {font-weight: bold;font-size: 16px;color: #D63333;}
	
	.profilename{font-size: 24px;color: #181E29;line-height: 36px;}
	.progress-percent{font-size: 14px;color: #0332AA;}
	.profileedit{background: #0332AA;border: 3px solid #ffffff;width: 35px;height: 35px;border-radius: 50%;position: absolute;bottom: 20px;right: 20px;}
	.icon-edit{background: url("img/icons/edit.png") no-repeat;width: 14px;height: 14px;display: inline-block;vertical-align: middle;position: absolute;top: 27%;left: 27%;}
	
	.custom-control{display: inline-block}
	
	.icon-arrow-left{background: url("img/icons/leftarrow-btn.png") no-repeat;width: 6px;height: 10px;display: inline-block;vertical-align: middle;}
	.icon-arrow-right{background: url("img/icons/rightarrow-btn.png") no-repeat;width: 6px;height: 10px;display: inline-block;vertical-align: middle;}
	
	.table{border: 1px solid #D7DFF0;border-collapse: collapse}
	.table thead th{font-size: 12px;font-weight: bold;color: #6F83AA;letter-spacing: 0.5px;background: #E6EBF7;text-transform: uppercase}
	.table td, .table th{border-top: 1px solid #D7DFF0;}
	
	.next-btn,.payment-btn{float: right}
	.prev-btn{float: left}
	
	.btn-outline-primary:not(:disabled):not(.disabled).active .icon-arrow-left, .btn-outline-primary:not(:disabled):not(.disabled):active .icon-arrow-left,.btn-outline-primary:hover .icon-arrow-left{filter: contrast(0.2) brightness(2);}
		
	.sw-main.sw-theme-dots>ul.step-anchor.mpregister>li{width: 20%;}
	.sw-main.sw-theme-dots>ul.step-anchor.mpregister>li>a i{left: 42%;}
	
	.btn-toolbar{display: none}
	.sw-main.sw-theme-default .row .row div p{font-size: 14px;font-weight: 600;margin-bottom: 2rem;}	
	.sw-main.sw-theme-default .row .row div:first-child p{color: #6884CC;}	
	.sw-main.sw-theme-default .row .row div:last-child p{color: #364159;}
	.sw-main.sw-theme-default .row .row div p.empty,.profiletop p.text-muted.empty{color: #D7DFF0 !important;}
	
	.marksheet p.list-item-heading,.qmarksheet p.list-item-heading{color: #6884CC;font-weight: 600;}
	.marksheet img,.qmarksheet img{width: 100px;height: 130px;}
	.marksheet .gallery .col-2,.qmarksheet .gallery .col-2{position: relative;padding: 0;margin: 1rem;max-width: 10% !important}
	.marksheet .overlay,.qmarksheet .overlay{background: rgba(83, 100, 133,0.6) url(img/icons/eye.png) no-repeat center;width: 100%;height: 100%;position: absolute;border-radius: 0.75rem;top: 0;}
		
	.myprofile .img-thumbnail{width: 115px;height: 115px}
	
	.gallery a{text-align: center}
	.gallery a i{font-size: 4rem;padding: 1.5rem 0;display: block}
	.gallery a span.text{font-size: 10px;position: absolute;top: 28%;left: 14%;background: #ff0000;color: #fff;text-transform: uppercase;padding: 0px 7px;font-weight: bold;}
	
	@media (max-width:767px){
		
		.marksheet .gallery .col-2,.qmarksheet .gallery .col-2{max-width: 100% !important;}
	}
	
	.maincontent h3{color: #0332AA;font-size: 12px;font-weight: bold;line-height: 20px;letter-spacing: 0.5px;text-transform: uppercase;margin: 2rem auto}
	
	.icon-bookmark-s{background: url("img/icons/bookmark-s.png") no-repeat;width: 14px;height: 14px;display: inline-block;vertical-align: middle;margin-right: 0.5rem}
	.icon-phone-s{background: url("img/icons/phone-s.png") no-repeat;width: 14px;height: 14px;display: inline-block;vertical-align: middle;margin-right: 0.5rem}
	.icon-mail-s{background: url("img/icons/mail-s.png") no-repeat;width: 14px;height: 14px;display: inline-block;vertical-align: middle;margin-right: 0.5rem}
	.icon-edit3{background: url("img/icons/edit3.png") no-repeat;width: 15px;height: 16px;display: inline-block;vertical-align: middle;margin-right: 0.4rem}
	
	.profiletop p.list-item-heading{font-size: 14px;font-weight: 600;line-height: 20px;color: #6884CC !important;}
	.profiletop p.text-muted{font-size: 16px;font-weight: bold;line-height: 24px;color: #0332AA !important;}
	
	.sw-theme-default>ul.step-anchor>li.active>a{color: #0332AA !important;}
	.sw-theme-default{box-shadow: none}
	.sw-main>ul.step-anchor{padding: 0;}
	
	.btn.editprofile,.btn.epsave,.btn.epcancel,.btn.printidcard{font-family: Segoe UI;font-size: 14px;font-weight: 600;background: linear-gradient(180deg, #4F70C4 0%, #1C47B3 100%);border: 1px solid #0332AA;border-radius: 5px;line-height: 20px;}
	
	/* Upload files*/	
	
	.box {position: relative;background: #ffffff;width: 100%;}
	.box-header {color: #444;display: block;padding: 10px;position: relative;border-bottom: 1px solid #f4f4f4;margin-bottom: 10px;}
	.box-tools {position: absolute;right: 10px;top: 5px;}
	.dropzone-wrapper {background: #F6F7FA;border: 1px dashed #BCCAE8;color: #92b0b3;position: relative;height: 120px;border-radius: 5px;}
	.dropzone-desc {position: absolute;margin: 0 auto;left: 0;right: 0;text-align: center;width: auto;top: 22px;font-size: 16px;}
	.dropzone,
	.dropzone:focus {position: absolute;outline: none !important;width: 100%;height: 150px;cursor: pointer;opacity: 0;}
	.dropzone-wrapper:hover,
	.dropzone-wrapper.dragover {background: #ecf0f5;}
	.preview-zone {text-align: center;}
	.preview-zone .box {box-shadow: none;border-radius: 0;margin-bottom: 0;}
	#filename {margin-top: 10px;margin-bottom: 10px;font-size: 14px;line-height: 2.7em;border: 1px solid #D7DFF0;
    border-radius: 5px;min-height: 40px;margin-top: 2.2rem;}
	.file-preview {background: #ccc;border: 5px solid #fff;box-shadow: 0 0 4px rgba(0, 0, 0, 0.5);display: inline-block;width: 60px;height: 60px;text-align: center;font-size: 14px;margin-top: 5px;}
	.closeBtn:hover {color: red;display:inline-block;}
	
	.icon-upload{background: url("img/icons/upload.png") no-repeat;width: 24px;height: 24px;display: inline-block;vertical-align: middle}
	.dropzone-desc p.list-item-heading{font-size: 14px;font-weight: 600;color: #536485;}
	.dropzone-desc p.text-muted{font-size: 10px !important;font-weight: normal !important;color: #6F83AA !important;}
	.dropzone-desc p.list-item-heading span{color: #db4d4d}
	
	.dropzone-desc .text-center{text-align: center !important}
	.custom-radio label{font-size: 14px;font-weight: normal;color: #536485;}
	
	h3.title{font-size: 12px;font-weight: bold;color: #0332AA;letter-spacing: 0.5px;text-transform: uppercase;}
	.file_ms{font-size: 12px;color: #1C47B3;text-decoration-line: underline;}
	
	.myprofile .img-thumbnail{width: 115px;height: 115px}
	.icon-download{background: url("img/icons/download.png") no-repeat;width: 15px;height: 16px;display: inline-block;vertical-align: middle;margin-right: 0.5rem}
		
	/* Qualification */
	.yearfee .card{background: #F6F7FA;border: 1px solid #BCCAE8;box-shadow: none}
	.yearfee p{margin-bottom: 1.5rem}
	.yearfee p.first,.yearfee p.second{font-weight: bold;font-size: 14px;color: #0332AA;text-align: left;text-transform: uppercase;}
	.yearfee .row div:last-child p{font-size: 14px;font-weight: 600;color: #364159;}
	.yearfee p.list-item-heading,.yearfee .row div:first-child p{color: #6884CC;font-weight: 600;}
	
	/* Registered Course */
	
	.feepayments h2{font-size: 16px;font-weight: bold;color: #0332AA;line-height: 26px}
	.feepayments .card,.courseinfo .card{background: linear-gradient(0deg, #FFFFFF, #FFFFFF), #C4C4C4;box-shadow: 0px 0px 0px rgba(196, 196, 196, 0.35);border-radius: 0px;border: none;}
	.feepayments h3{color: #0332AA;font-size: 24px;font-weight: bold;line-height: 36px;}
	.feepayments p.list-item-heading{color: #6884CC !important;font-weight: 600;}
	.feepayments .feetop p.list-item-heading span:last-child{font-weight: 600;font-size: 14px;color: #364159;}
		
	.icon-credit-card-2{background: url("img/icons/credit-card-2.png") no-repeat;width: 15px;height: 15px;display: inline-block;vertical-align: middle}
	.icon-check-circle{background: url("img/icons/check-circle-b.png") no-repeat;width: 15px;height: 15px;display: inline-block;vertical-align: middle}
	.icon-minus-circle{background: url("img/icons/minus-circle.png") no-repeat;width: 15px;height: 15px;display: inline-block;vertical-align: middle;margin-right: 5px}
	.icon-map-pin{background: url("img/icons/map-pin-b.png") no-repeat;width: 15px;height: 15px;display: inline-block;vertical-align: middle;margin-right: 5px}
	.icon-invoice-b{background: url("img/icons/invoice-b.png") no-repeat;width: 15px;height: 15px;display: inline-block;vertical-align: middle;margin-right: 5px}
	.icon-chevron-down-b{background: url("img/icons/chevron-down-b.png") no-repeat;width: 14px;height: 14px;display: inline-block;vertical-align: middle;margin-left: 5px}
	
	p span.totalfee {font-weight: bold;font-size: 18px;color: #0332AA;}
	p span.paidfee {font-weight: bold;font-size: 18px;color: #209679;}
	p span.duefee {font-weight: bold;font-size: 18px;color: #D63333;}
	
	.feepayments .btn-outline-primary {color: #0332AA;border-color: #0332AA;background: linear-gradient(180deg, #ffffff 0%, #ffffff 100%);font-size: 14px;font-weight: 600;}
	.feepayments .btn-outline-primary:hover{color: #ffffff;background: linear-gradient(180deg, #0332AA 0%, #0332AA 100%);}
	.feepayments .btn-outline-primary:hover i{filter: contrast(0) brightness(5);}
	
	/* Fee Table */
	
	.table td.totalfee {font-weight: bold;font-size: 16px;color: #D63333;}
	.table td.totalamt {font-weight: bold;font-size: 12px;color: #6F83AA;letter-spacing: 0.5px;text-transform: uppercase;text-align: right !important}
	.table tr:last-child td{text-align: left}
	.table tr td:last-child,.table tr th:last-child{text-align: center}
	.table tr:last-child td:last-child{font-weight: bold;text-align: center}
	.table tr:last-child{text-align: center}
	
	.table{border: 1px solid #D7DFF0;border-collapse: collapse;border-style: hidden;border-radius: 10px 10px 0 0;box-shadow: 0 0 0 1px #d7dff0;}
	.table thead th{font-size: 12px;font-weight: bold;color: #6F83AA;letter-spacing: 0.5px;background: #E6EBF7;text-transform: uppercase;padding: 0.8rem;text-align: left}
	.table thead tr th:first-child{border-top-left-radius: 5px}
	.table thead tr th:last-child{border-top-right-radius: 5px}
	.table td, .table th{border-top: 1px solid #D7DFF0;padding: 0.9rem 0.75rem;color: #364159;font-weight: 600;}
	.thtax{display: block;text-align: center;}
	.thtaxvalue{display: flex;}
	.thtaxvalue span:first-child{width: 53%}
	
	h3.title{font-size: 12px;text-transform: uppercase;color: #0332AA;letter-spacing: 0.5px;font-weight: bold;}
	
	.payhistory a{font-size: 14px;font-weight: 600;color: #0332AA;}
	
	.form-group.floating>label{line-height: 18px}
	.form-control:focus~label, .custom-select:focus~label, input.form-control:not(:placeholder-shown) ~ label, select.form-control:not([value=""]):valid ~ label{margin-bottom: 12px;line-height: 14px;}
	
	.regcourses .crstatus-approved,.regcourses .crstatus-waitlisted,.regcourses .crstatus-pending,.regcourses .crstatus-rejected{font-size: 12px !important;color: #ffffff !important;border-radius: 20px;text-transform: capitalize;text-align: center;}
	.crstatus-approved{ background: #3CAF92;}
	.crstatus-waitlisted{background: #f48d25;}
	.crstatus-pending{background: #b06315;}
	.crstatus-rejected{background: #ED5252;}
	
	.regcourses p.list-item-heading span:last-child { font-weight: 600;font-size: 14px; color: #364159;}
	
	/*.regcourses .card:after{content: " ";color: #fff;position: absolute;width: 10px;height: 100%;top: 50%;transform: translateY(-50%);left: 0;border-top-left-radius: 10px;border-bottom-left-radius: 10px;}
	.regcourses.approved .card:after{background: #3CAF92;}
	.regcourses.waitlisted .card:after{background: #f48d25;}
	.regcourses.pending .card:after{background: #b06315;}
	.regcourses.rejected .card:after{background: #ED5252;}*/
	
	.studid{font-size: 16px;display: block;line-height: 20px}
	
	.results .table tr:last-child td:last-child,.results .table tr td:last-child{font-weight: 600;text-align: left}
        .ui-autocomplete { z-index: 10000;}
	
	.datepicker {transform: translate(0, 0em);z-index: 1050 !important;}
	.input-daterange .input-group-addon{padding: 4px 20px}
	.input-daterange input{text-align: left}
	
	.comments p{color: #ED5252;font-size: 16px}
	.spcomments .form-group.floating>label{top: 8px;bottom: inherit}
        
        #profileview p, #profileedit p, #memberprofile p {
    display: inline-block;
    width: 100%;
    margin: 12px 1%;
    vertical-align: top;
}
	
	.results .dataTables_wrapper {overflow-x: auto;}
	
</style>


<div class="wrap dynamic-width" style="float: left;position: relative;min-width: 800px">
	
		
		<div class="col-12 mb-4 myprofile">
                  
			  <div class="row align-items-center">

		   		<div class="col-md-5">
			   		<h1>Students Profile</h1>
				  </div>
                   <div class="col-md-2 text-right">
			   		<button type="button" class="btn btn-primary printidcard">Print ID Card</button>
				  </div>
				  
			<?php if($roleaccess['uedit'] === 'y') { ?>
		   		<div class="col-md-3 text-right">
					<button type="button" class="btn btn-primary editprofile"><i class="icon-edit3"></i> Edit Profile</button>
					<button type="button" class="btn btn-primary epsave d-none"> Save Profile</button>
					<button type="button" class="btn btn-primary epcancel d-none"> Cancel</button>
				  </div>
			<?php } ?>
				  
				  <p class="alert w-100"></p>
				  
			  </div>
                   
			<div class="card mb-4">
				
				<div class="row">
          
          <div class="col-md-6 col-sm-6 col-lg-9 col-12">
           
            <div class="d-flex flex-row">
             
				<a class="d-flex position-relative" href="#"><img alt="Profile" src="<?php if($stuprofile['profilepic']!="0" && $stuprofile['profilepic']!=""){ echo "docs/profilepic/".$sid."/".$stuprofile['profilepic']."?".time();}else{echo "img/myprofile.png?".time();} ?>" class="img-thumbnail border-0 rounded-circle mx-4 my-4 align-items-center"> <span class="profileedit"><i class="icon-edit"></i></span></a>
             
              <div class="d-flex flex-grow-1 min-width-zero">
                <div class="card-body pl-0 py-2 align-self-center d-flex flex-column flex-lg-row justify-content-between min-width-zero">
                  <div class="w-100">
					  <p class="list-item-heading mb-2 truncate font-weight-bold profilename"><?php echo ucwords($stuprofile['stuname']); ?> <span class="studid">Student ID: <?php echo $stuprofile['studid'];?></span></p>
                    
                    <div class="row profiletop">

						<div class="col-md-4 text-left px-3">
							<p class="list-item-heading mb-2"><i class="icon-bookmark-s"></i> Class Studying</p>
							<p class="mb-2 text-muted <?php if($stuprofile['classstudy']=="" || $stuprofile['classstudy']=="0"){ echo "empty";} ?>"><?php if($stuprofile['classstudy']!=""){ echo ucwords($stuprofile['classstudy']);}else{echo "-Nil-";} ?></p>
						</div>

						<div class="col-md-3 text-left px-2">
							<p class="list-item-heading mb-2"><i class="icon-phone-s"></i> Phone</p>
							<p class="mb-2 text-muted"><?php if($stuprofile['smcode']!=""){ echo $stuprofile['smcode'];}else{echo $stuprofile['sumcode'];}?> <?php echo $stuprofile['smobile']; ?></p>
						</div>

						<div class="col-md-5 text-left px-2">
							<p class="list-item-heading mb-2"><i class="icon-mail-s"></i> Mail</p>
							<p class="mb-2 text-muted"><?php echo strtolower($stuprofile['semail']); ?></p>
						</div>

					</div>
                   
                    <!--<p class="mb-2 text-small font-weight-semibold progress-percent">Profile Completeness: <span class="progressnum font-weight-bold"><?php //if($stuprofile['profilepercent']!=0){ echo ucwords($stuprofile['profilepercent']);}else{echo 0;} ?>%</span></p>
					<div class="progress">
					  <div class="progress-bar" role="progressbar" style="width: <?php //if($stuprofile['profilepercent']!=0){ echo ucwords($stuprofile['profilepercent']);}else{echo 0;} ?>%" aria-valuenow="<?php //if($stuprofile['profilepercent']!=0){ echo ucwords($stuprofile['profilepercent']);}else{echo 0;} ?>" aria-valuemin="0" aria-valuemax="100"></div>
					</div>-->
                  </div>
                </div>
              </div>
            </div>
            
          </div>
          
          <div class="col-md-3 col-sm-3 col-lg-3 col-12 d-flex align-items-center justify-content-center">
           
            <div class="mr-0">
             
               <?php if(isset($roleaccess['Change Password'][1]) && $roleaccess['Change Password'][1] === 'y') { ?>
               <button type="button" class="btn btn-outline-primary changepassword">Change Password</button>
               <?php } ?>
             
            </div>
            
          </div>
          
        </div>
				
			</div>
           
           <?php if(trim($stuprofile['comments'])!="" && $stuprofile['comments']!="0"){?>
           
           <div class="card mb-4 comments">
				
				<div class="row">
          
						<div class="col-12">

							
							<div class="d-flex flex-row">
             
								<div class="d-flex align-items-center position-relative p-3"><h4 class="m-0"><strong>Comments:</strong> </h4></div>
             
							  <div class="d-flex flex-grow-1 min-width-zero">
								<div class="card-body pl-0 py-2 align-self-center d-flex flex-column flex-lg-row justify-content-between min-width-zero">
								  <div class="w-100">
								  
									  <p class="list-item-heading mb-0 font-weight-bold"><?php echo $stuprofile['comments']; ?></p>

								  </div>
								</div>
							  </div>
            				</div>
					
					
						</div>
          
        		</div>
				
			</div>
           
           <?php }?>
            
            
            <?php if($roleaccess['uview'] === 'y') { ?>
            
            <div class="card mb-4 p-3">
          <div id="smartWizardClickable">
            <ul class="card-header border-bottom">
              <li><a href="#customButtons1">Profile</a></li>
              <?php if(isset($roleaccess['Registered Courses'][3]) && $roleaccess['Registered Courses'][3]=== 'y') { ?>
              	<li><a href="#customButtons2">Registered Courses</a></li>
              <?php } ?>
              
              <?php if(isset($roleaccess['Payments Tab'][3]) && $roleaccess['Payments Tab'][3]=== 'y') { ?>
              <li><a href="#customButtons3">Payment</a></li>
              <?php } ?>
              
              <?php if(isset($roleaccess['Results Tab'][3]) && $roleaccess['Results Tab'][3]=== 'y') { ?>
              <li><a href="#customButtons4">Results</a></li>
              <?php } ?>
            </ul>
            <div class="card-body">
              <div id="customButtons1">
              
              
              <div id="profileview">
              
              
              <div id="studentdetailstab">
            <ul class="card-header border-bottom">
              <li><a href="#sdtButtons1">Personal Details</a></li>
              <li><a href="#sdtButtons2">Education Details</a></li>
               <?php if(!empty($qualification)){?> <li><a href="#sdtButtons3">Qualification Details</a></li><?php }?>
              <li><a href="#sdtButtons4">Contact Details</a></li>
              <li><a href="#sdtButtons5">Bank Details</a></li>
            </ul>
            
            <div class="card-body">
            
            <div id="sdtButtons1">
            
            <?php if(isset($roleaccess['Save Profile Card'][3]) && $roleaccess['Save Profile Card'][3]=== 'y') { ?>
            
            	<div class="text-right mt-3">
            		<a href="studentprofile/studentprofilecard?sid=<?php echo $sid;?>" title="Profile Card" target="_blank"><button type="button" class="btn btn-outline-primary">Save Profile Card</button></a>
				</div>
           
            <?php } ?>
             
             <h3>Personal details</h3>   
                          
             <div class="row">
             
             <div class="col-12 col-sm-6">
                <div class="row">

					<div class="col-md-5">
						<p>Name:</p>
					</div>

					<div class="col-md-7">
						<p><?php if($stuprofile['stuname']!=""){ echo ucwords($stuprofile['stuname']);}else{echo "-Nil-";} ?></p>
					</div>

				</div>
			</div>
              
              <div class="col-12 col-sm-6">
              		<div class="row">

						<div class="col-md-5">
							<p>Date of Birth:</p>
						</div>

						<div class="col-md-7">
							<p class="<?php if($stuprofile['dob']=="" || $stuprofile['dob']=="0000-00-00" || $stuprofile['dob']=="01-01-1970"){ echo "empty";} ?>"><?php if($stuprofile['dob']!="" && $stuprofile['dob']!="0000-00-00" && $stuprofile['dob']!="01-01-1970"){ echo date("d-m-Y",strtotime($stuprofile['dob']));}else{echo "-Nil-";} ?></p>
						</div>

					</div>
              </div>
              
              <div class="col-12 col-sm-6">
              		<div class="row">

						<div class="col-md-5">
							<p>Gender:</p>
						</div>

						<div class="col-md-7">
							<p class="<?php if($stuprofile['gender']=="" || $stuprofile['gender']=="0"){ echo "empty";} ?>"><?php if($stuprofile['gender']!="" && $stuprofile['gender']!="0"){ echo $stuprofile['gender'];}else{echo "-Nil-";} ?></p>
						</div>

					</div>
              </div>
              
              <div class="col-12 col-sm-6">
                <div class="row">

					<div class="col-md-5">
						<p>Nationality:</p>
					</div>

					<div class="col-md-7">
						<p class="<?php if($stuprofile['nationality']=="" || $stuprofile['nationality']=="0"){ echo "empty";} ?>"><?php if($stuprofile['nationality']!="" && $stuprofile['nationality']!="0"){ echo $stuprofile['nationality'];}else{echo "-Nil-";} ?></p>
					</div>

				</div>
              </div>
              
              <div class="col-12 col-sm-6">
                <div class="row">

					<div class="col-md-5">
						<p>Category:</p>
					</div>

					<div class="col-md-7">
						<p class="<?php if($stuprofile['category']=="" || $stuprofile['category']=="0"){ echo "empty";} ?>"><?php if($stuprofile['category']!="" && $stuprofile['category']!="0"){ echo $stuprofile['category'];}else{echo "-Nil-";} ?></p>
					</div>

				</div>
              </div>
                           
              <div class="col-12 col-sm-6">
                <div class="row">

					<div class="col-md-5">
						<p>Aadhar Number:</p>
					</div>

					<div class="col-md-7">
						<p class="<?php if($stuprofile['aadharnumber']=="" || $stuprofile['aadharnumber']=="0"){ echo "empty";} ?>"><?php if($stuprofile['aadharnumber']!="" && $stuprofile['aadharnumber']!="0"){ echo $stuprofile['aadharnumber'];}else{echo "-Nil-";} ?></p>
					</div>

				</div>
			</div>
              
              <div class="col-12 col-sm-6">
                <div class="row">

					<div class="col-md-5">
						<p>Fathers Name:</p>
					</div>

					<div class="col-md-7">
						<p class="<?php if($stuprofile['fathername']=="" || $stuprofile['fathername']=="0"){ echo "empty";} ?>"><?php if($stuprofile['fathername']!="" && $stuprofile['fathername']!="0"){ echo $stuprofile['fathername'];}else{echo "-Nil-";} ?></p>
					</div>

				</div>
			</div>
              
              <div class="col-12 col-sm-6">
                <div class="row">

					<div class="col-md-5">
						<p>Fathers Phone:</p>
					</div>

					<div class="col-md-7">
						<p class="<?php if($stuprofile['fatherphone']=="" || $stuprofile['fatherphone']=="0"){ echo "empty";} ?>"><?php if($stuprofile['fatherphone']!="" && $stuprofile['fatherphone']!="0"){ echo $stuprofile['fathercode'].' '.$stuprofile['fatherphone'];}else{echo "-Nil-";} ?></p>
					</div>

				</div>
             
				 </div>
              
              <div class="col-12 col-sm-6">
                <div class="row">

					<div class="col-md-5">
						<p>Fathers Email:</p>
					</div>

					<div class="col-md-7">
						<p class="<?php if($stuprofile['fatheremail']=="" || $stuprofile['fatheremail']=="0"){ echo "empty";} ?>"><?php if($stuprofile['fatheremail']!="" && $stuprofile['fatheremail']!="0"){ echo $stuprofile['fatheremail'];}else{echo "-Nil-";} ?></p>
					</div>

				</div>
			</div>
              
              <div class="col-12 col-sm-6">
                <div class="row">

					<div class="col-md-5">
						<p>Fathers Occupation:</p>
					</div>

					<div class="col-md-7">
						<p class="<?php if($stuprofile['fatheroccupation']=="" || $stuprofile['fatheroccupation']=="0"){ echo "empty";} ?>"><?php if($stuprofile['fatheroccupation']!="" && $stuprofile['fatheroccupation']!="0"){ echo $stuprofile['fatheroccupation'];}else{echo "-Nil-";} ?></p>
					</div>

				</div>
			</div>
              
              <div class="col-12 col-sm-6">
                <div class="row">

					<div class="col-md-5">
						<p>Mothers Name:</p>
					</div>

					<div class="col-md-7">
						<p class="<?php if($stuprofile['mothername']=="" || $stuprofile['mothername']=="0"){ echo "empty";} ?>"><?php if($stuprofile['mothername']!="" && $stuprofile['mothername']!="0"){ echo $stuprofile['mothername'];}else{echo "-Nil-";} ?></p>
					</div>

				</div>
			</div>
              
              <div class="col-12 col-sm-6">
                <div class="row">

					<div class="col-md-5">
						<p>Mothers Phone:</p>
					</div>

					<div class="col-md-7">
						<p class="<?php if($stuprofile['motherphone']=="" || $stuprofile['motherphone']=="0"){ echo "empty";} ?>"><?php if($stuprofile['motherphone']!="" && $stuprofile['motherphone']!="0"){ echo $stuprofile['mothercode'].' '.$stuprofile['motherphone'];}else{echo "-Nil-";} ?></p>
					</div>

				</div>
                           
				 </div>
              
              <div class="col-12 col-sm-6">
				  <div class="row">

						<div class="col-md-5">
							<p>Mothers Email:</p>
						</div>

						<div class="col-md-7">
							<p class="<?php if($stuprofile['motheremail']=="" || $stuprofile['motheremail']=="0"){ echo "empty";} ?>"><?php if($stuprofile['motheremail']!="" && $stuprofile['motheremail']!="0"){ echo $stuprofile['motheremail'];}else{echo "-Nil-";} ?></p>
						</div>

					</div>
              
              </div>
              
              <div class="col-12 col-sm-6">
                <div class="row">

					<div class="col-md-5">
						<p>Mothers Occupation:</p>
					</div>

					<div class="col-md-7">
						<p class="<?php if($stuprofile['motheroccupation']=="" || $stuprofile['motheroccupation']=="0"){ echo "empty";} ?>"><?php if($stuprofile['motheroccupation']!="" && $stuprofile['motheroccupation']!="0"){ echo $stuprofile['motheroccupation'];}else{echo "-Nil-";} ?></p>
					</div>

				</div>
			</div>
              
              <div class="col-12 col-sm-6">
                <div class="row">

					<div class="col-md-5">
						<p>Communication Contact:</p>
					</div>

					<div class="col-md-7">
						<p class="<?php if($stuprofile['communicationcontact']=="" || $stuprofile['communicationcontact']=="0"){ echo "empty";} ?>"><?php if($stuprofile['communicationcontact']!="" && $stuprofile['communicationcontact']!="0"){ echo $stuprofile['communicationcontact'];}else{echo "-Nil-";} ?></p>
					</div>

				</div>
              </div>
              
              <div class="col-12 col-sm-6">
               
                <div class="row">

					<div class="col-md-5">
						<p>Blood Group:</p>
					</div>

					<div class="col-md-7">
						<p class="<?php if($stuprofile['bloodgroup']=="" || $stuprofile['bloodgroup']=="0"){ echo "empty";} ?>"><?php if($stuprofile['bloodgroup']!="" && $stuprofile['bloodgroup']!="0"){ echo $stuprofile['bloodgroup'];}else{echo "-Nil-";} ?></p>
					</div>

				</div>
    
              </div>
              
              <div class="col-12 col-sm-6">
                <div class="row">

					<div class="col-md-5">
						<p>Class Studying / Complete:</p>
					</div>

					<div class="col-md-7">
						<p class="<?php if($stuprofile['classstudy']=="" || $stuprofile['classstudy']=="0"){ echo "empty";} ?>"><?php if($stuprofile['classstudy']!="" && $stuprofile['classstudy']!="0"){ echo $stuprofile['classstudy'];}else{echo "-Nil-";} ?></p>
					</div>

				</div>
          
              </div>
              
              <div class="col-12 col-sm-6">
                <div class="row">

					<div class="col-md-5">
						<p>Stream:</p>
					</div>

					<div class="col-md-7">
						<p class="<?php if($stuprofile['stream']=="" || $stuprofile['stream']=="0"){ echo "empty";} ?>"><?php if($stuprofile['stream']!="" && $stuprofile['stream']!="0"){ echo $stuprofile['stream'];}else{echo "-Nil-";} ?></p>
					</div>

				</div>
              
              </div>
              
              			  
			  </div>
               
				  </div>
                
				  <!--<div class="border-bottom"></div>   -->                                                                
				  <div id="sdtButtons2">
				                            
				  <h3>Educational details</h3>                                                                                              
                <div class="row">
             
             <div class="col-12 col-sm-6">
                <div class="row">

					<div class="col-md-5">
						<p>Name of School Last Studied / Studying :</p>
					</div>

					<div class="col-md-7">
						<p class="<?php if($stuprofile['schoolcollegename']=="" || $stuprofile['schoolcollegename']=="0"){ echo "empty";} ?>"><?php if($stuprofile['schoolcollegename']!="" && $stuprofile['schoolcollegename']!="0"){ echo $stuprofile['schoolcollegename'];}else{echo "-Nil-";} ?></p>
					</div>

				</div>
              </div>
              
              <div class="col-12 col-sm-6">
                <div class="row">

					<div class="col-md-5">
						<p>Address Line:</p>
					</div>

					<div class="col-md-7">
						<p class="<?php if($stuprofile['eduaddress']=="" || $stuprofile['eduaddress']=="0"){ echo "empty";} ?>"><?php if($stuprofile['eduaddress']!="" && $stuprofile['eduaddress']!="0"){ echo $stuprofile['eduaddress'];}else{echo "-Nil-";} ?></p>
					</div>

				</div>
			</div>
              
              <div class="col-12 col-sm-6">
                <div class="row">

					<div class="col-md-5">
						<p>Country:</p>
					</div>

					<div class="col-md-7">
						<p class="<?php if($stuprofile['educountry']=="" || $stuprofile['educountry']=="0"){ echo "empty";} ?>"><?php if($stuprofile['educountry']!="" && $stuprofile['educountry']!="0"){ echo $stuprofile['educountry'];}else{echo "-Nil-";} ?></p>
					</div>

				</div>
              </div>
              
              <!--<div class="col-12 col-sm-6">
                <div class="row">

					<div class="col-md-5">
						<p>Educational Qualification List:</p>
					</div>

					<div class="col-md-7">
						<p class="<?php //if($qualname['qname']=="" || $qualname['qname']=="0"){ echo "empty";} ?>"><?php //if($qualname['qname']!="" && $qualname['qname']!="0"){ echo $qualname['qname'];}else{echo "-Nil-";} ?></p>
					</div>

				</div>
              </div>-->
              
              			  
			  </div>
                                                                                                             
           <?php
		
			$marksheets = $stuprofile['marksheets'];
				  
			if($marksheets!=""  && $marksheets!="0"){
				
			$marksheetsarr = explode('|',$marksheets);
			
			$marksheetlist = "";
			foreach($marksheetsarr as $marksheet){
				
				$ext = end(explode(".",$marksheet));
				
				if(strtolower($ext)!="pdf"){
					$marksheetlist .= '<div class="col-2"><a href="docs/marksheets/'.$sid.'/'.$marksheet.'"><img class="img-fluid border-radius" src="docs/marksheets/'.$sid.'/'.$marksheet.'"><div class="overlay"></div></a></div>';
				}
				else{
					$marksheetlist .= '<div class="col-2"><a href="docs/marksheets/'.$sid.'/'.$marksheet.'" target="_blank"><span class="text">pdf</span><i class="glyph-icon simple-icon-doc"></i><div class="overlay"></div></a></div>';
				}				
				
			}
				
			
		?>
                
       <div class="mb-4 marksheet">
				
			<div class="row">
          
				  <div class="col-md-6 col-sm-6 col-lg-12 col-12">

			  			<p class="list-item-heading p-0">Student Marksheets:</p>
			  			
			  			<div class="row gallery px-2 mb-4">
						  <?php echo $marksheetlist;?>
						</div>
			  
				  </div>
          
       		 </div>
				
		</div> 
                
        <?php }?>                                                                                             
                   
				  </div>                                                                                                                                                                                            
                              
              <?php if(!empty($qualification)){?>
              
              <div id="sdtButtons3">
               
               <!--<div class="border-bottom"></div>-->    
               
                 <?php if(isset($roleaccess['Qualification Edit'][1]) && $roleaccess['Qualification Edit'][1] == 'y') { ?>                                                                                                                                                                                 
				  		<h3>Qualification details  <a target="_blank" href="<?php echo base_url();?>stuqualifyupdate?ide=<?php echo $sid;?>&cride=<?php echo $qualification['ide'];?>&qid=<?php echo $qid;?>"><img style="padding:5px 10px" src="<?php echo base_url();?>images/edit.png"></a> </h3> 
                                 
                 <?php } ?>                                                                                                                                                                                   
                                  
              <div class="row yearfee">


							<div class="col-md-5 mb-4">

								<p class="first">Class <?php echo $qualification['class'];?> details</p>

								<div class="d-block w-100 p-0">

									<div class="row">

										<div class="col-md-5 col-5">
											<p>Year of Passing:</p>
										</div>

										<div class="col-md-7 col-7">
											<p><?php echo $qualification['yearofpassing'];?></p>
										</div>

									</div>

									<div class="row">

										<div class="col-md-5 col-5">
											<p>Class Name:</p>
										</div>

										<div class="col-md-7 col-7">
											<p><?php echo $qualification['class'];?></p>
										</div>

									</div>

									<div class="row">

										<div class="col-md-5 col-5">
											<p>Board of Exams:</p>
										</div>

										<div class="col-md-7 col-7">
											<p><?php echo $qualification['stream'];?></p>
										</div>

									</div>

									<div class="row">

										<div class="col-md-5 col-5">
											<p>Status:</p>
										</div>

										<div class="col-md-7 col-7">
											<p><?php echo ($qualification['status'] === 'P')?"Passed":"Waiting For Result";?></p>
										</div>

									</div>

									<div class="row">

										<div class="col-md-5 col-5">
											<p>Roll Number:</p>
										</div>

										<div class="col-md-7 col-7">
											<p><?php echo $qualification['rollno'];?></p>
										</div>

									</div>

									<div class="row">

										<div class="col-md-5 col-5">
											<p>Grace Mark:</p>
										</div>

										<div class="col-md-7 col-7">
                                                                                        <p><?php if($qualification['gracemark'] != '') {echo ($qualification['gracemark'] === 'y')?"Yes":"No";}?></p>
										</div>

									</div>
								</div>
							</div>

                                                                <?php
                                                                
                                                                if($qualification['subject'] !== '') {
                                                                    
                                                                    $subject = explode("|",$qualification['subject']);
                                                                    $mark = ($qualification['mark'] !== '')? explode("|",$qualification['mark']):"";
                                                                    $grade = ($qualification['grade'] !== '')? explode("|",$qualification['grade']):"";
                                                                    
                                                                    
                                                                    
                                                                    ?>
							<div class="col-md-4 mb-4">

								<p class="first">Class <?php echo $qualification['class'];?> Marksheet</p>

								<div class="card d-flex d-block w-100 p-3">
                                                                    
                                                                   <?php 
                                                                   
                                                                   for($i = 0 ; $i < count($subject);$i++) {
                                                                   if($subject[$i] ==='') { continue;}
                                                                       $con = ($mark !== '')?$mark[$i]:$grade[$i];
                                                                        echo '<div class="row">

										<div class="col-md-5 col-5">
											<p>'.$subject[$i].':</p>
										</div>

										<div class="col-md-7 col-7">
											<p>'.$con.'</p>
										</div>

									</div>';
                                                                    }
                                                                   
                                                                   ?>
								
								</div>
							</div>
                                                    
                                                    <?php } ?>

						</div>


						<div class="separator mb-5"></div>

                                                <?php if($qualification['xii_yearofpassing'] !== '') {?>
						<div class="row yearfee">


							<div class="col-md-5 mb-4">

								<p class="first">Class XII details</p>

								<div class="d-block w-100 p-0">

									<div class="row">

										<div class="col-md-5 col-5">
											<p>Year of Passing:</p>
										</div>

										<div class="col-md-7 col-7">
											<p><?php echo $qualification['xii_yearofpassing']; ?></p>
										</div>

									</div>

									<div class="row">

										<div class="col-md-5 col-5">
											<p>Class Name:</p>
										</div>

										<div class="col-md-7 col-7">
											<p>XII Standard</p>
										</div>

									</div>

									<div class="row">

										<div class="col-md-5 col-5">
											<p>Board of Exams:</p>
										</div>

										<div class="col-md-7 col-7">
											<p><?php echo $qualification['xii_stream']; ?></p>
										</div>

									</div>

									<div class="row">

										<div class="col-md-5 col-5">
											<p>Status:</p>
										</div>

										<div class="col-md-7 col-7">
											<p><?php echo ($qualification['xii_status'] === 'P')?"Passed":"Waiting For Result";?></p>
										</div>

									</div>

									<div class="row">

										<div class="col-md-5 col-5">
											<p>Roll Number:</p>
										</div>

										<div class="col-md-7 col-7">
											<p><?php echo $qualification['xii_rollno']; ?></p>
										</div>

									</div>

									<div class="row">

										<div class="col-md-5 col-5">
											<p>Grace Mark:</p>
										</div>

										<div class="col-md-7 col-7">
											<p><?php if($qualification['xii_gracemark'] != '') {echo ($qualification['xii_gracemark'] === 'y')?"Yes":"No";}?></p>
										</div>

									</div>
								</div>
							</div>

                                                                <?php
                                                                
                                                                if($qualification['xii_subject'] !== '') {
                                                                    
                                                                    $xii_subject = explode("|",$qualification['xii_subject']);
                                                                    $xii_mark = ($qualification['xii_mark'] !== '')? explode("|",$qualification['xii_mark']):"";
                                                                    $xii_grade = ($qualification['xii_grade'] !== '')? explode("|",$qualification['xii_grade']):"";
                                                                    
                                                                    
                                                                    
                                                                    ?>
							<div class="col-md-4 mb-4">

								<p class="first">Class XII Marksheet</p>

								<div class="card d-flex d-block w-100 p-3">

									<?php 
                                                                   
                                                                   for($i = 0 ; $i < count($xii_subject);$i++) {
                                                                   if($xii_subject[$i] ==='') { continue;}
                                                                       $con = ($xii_mark !== '')?$xii_mark[$i]:$xii_grade[$i];
                                                                        echo '<div class="row">

										<div class="col-md-5 col-5">
											<p>'.$xii_subject[$i].':</p>
										</div>

										<div class="col-md-7 col-7">
											<p>'.$con.'</p>
										</div>

									</div>';
                                                                    }
                                                                   
                                                                   ?>

									
								</div>
							</div>
                                                <?php } ?>

						</div>

                                                <?php } ?>
						<div class="separator mb-5"></div>


						<div class="row yearfee">


                                                            <?php
                                                                                                                      
                                                            if($qualification['entrance_name'] != "") {
                                                                
                                                                $examArr1 = explode("|", $qualification['entrance_name']);
                                                                $examArr2 = explode("|", $qualification['entrance_mark']);
                                                                $examArr3 = explode("|", $qualification['entrance_regno']);
                                                                
                                                                foreach ($examArr1 as $key => $value) {
                                                                    
                                                                    if($value === "") {continue;}
                                                            
                                                            echo '<div class="col-md-5 mb-4">
                                                            

								<p class="first">'.$value.' - Entrance Exam</p>

								<div class="d-block w-100 p-0">

									<div class="row">

										<div class="col-md-5 col-5">
											<p>Rank/Mark:</p>
										</div>

										<div class="col-md-7 col-7">
											<p>'.$examArr2[$key].'</p>
										</div>

									</div>

									<div class="row">

										<div class="col-md-5 col-5">
											<p>Registration Number:</p>
										</div>

										<div class="col-md-7 col-7">
											<p>'.$examArr3[$key].'</p>
										</div>

									</div>


								</div>
							</div>';
                                                                }
                                                            }
                                                            
                                                            ?>
							
						</div> 
                                                                                                                                                                                                           
                                                                                                                                                                                                           
   							<?php
		
								$qmarksheets = $qualification['marksheets'];
								$qmarksheetsarr = explode('|',$qmarksheets);

								$qmarksheetlist = "";
								foreach($qmarksheetsarr as $qmarksheet){

									$ext = end(explode(".",$qmarksheet));

									if(strtolower($ext)!="pdf"){
										$qmarksheetlist .= '<div class="col-2"><a href="docs/courserequest/marksheets/'.$sid.'/'.$qmarksheet.'?'.time().'"><img class="img-fluid border-radius" src="docs/courserequest/marksheets/'.$sid.'/'.$qmarksheet.'?'.time().'"><div class="overlay"></div></a></div>';
									}
									else{
										$qmarksheetlist .= '<div class="col-2"><a href="docs/courserequest/marksheets/'.$sid.'/'.$qmarksheet.'?'.time().'" target="_blank"><span class="text">pdf</span><i class="glyph-icon simple-icon-doc"></i><div class="overlay"></div></a></div>';
									}

								}
			
							?>
        
							<?php if($qmarksheets!="" && $qmarksheets!="0"){?>
						   
						   <div class="mb-4 qmarksheet">

								<div class="row">

									  <div class="col-12">

											<p class="list-item-heading pb-2">Marksheets:</p>

											<div class="row gallery px-4 mb-4">
											  <?php echo $qmarksheetlist;?>
											</div>

									  </div>

								 </div>

							</div> 

							<?php }?>
                                                                                                                                                                                                            
				  </div>
               
               <?php }?>                                                                                                                                                                                            
               
               <!--<div class="border-bottom"></div>-->                                                                     
               
            <div id="sdtButtons4">                                                   
				  
             <h3>Contact details</h3>   
              
               <div class="row">
                                         
              <div class="col-12">
                <div class="row">

					<div class="col-md-3">
						<p>House / Appartment Name:</p>
					</div>

					<div class="col-md-5">
						<p class="<?php if($stuprofile['housenameno']=="" || $stuprofile['housenameno']=="0"){ echo "empty";} ?>"><?php if($stuprofile['housenameno']!="" && $stuprofile['housenameno']!="0"){ echo $stuprofile['housenameno'];}else{echo "-Nil-";} ?></p>
					</div>

				</div>
			</div>
   
              
              <div class="col-12">
                <div class="row">

					<div class="col-md-3">
						<p>Place / Street:</p>
					</div>

					<div class="col-md-5">
						<p class="<?php if($stuprofile['contactaddress']=="" || $stuprofile['contactaddress']=="0"){ echo "empty";} ?>"><?php if($stuprofile['contactaddress']!="" && $stuprofile['contactaddress']!="0"){ echo $stuprofile['contactaddress'];}else{echo "-Nil-";} ?></p>
					</div>

				</div>
			</div>
              
              <div class="col-12">
                <div class="row">

					<div class="col-md-3">
						<p>Post Office:</p>
					</div>

					<div class="col-md-5">
						<p class="<?php if($stuprofile['contactpost']=="" || $stuprofile['contactpost']=="0"){ echo "empty";} ?>"><?php if($stuprofile['contactpost']!="" && $stuprofile['contactpost']!="0"){ echo $stuprofile['contactpost'];}else{echo "-Nil-";} ?></p>
					</div>

				</div>
              </div>
              
              <div class="col-12">
                <div class="row">

					<div class="col-md-3">
						<p>District:</p>
					</div>

					<div class="col-md-5">
						<p class="<?php if($stuprofile['contactdistrict']=="" || $stuprofile['contactdistrict']=="0"){ echo "empty";} ?>"><?php if($stuprofile['contactdistrict']!="" && $stuprofile['contactdistrict']!="0"){ echo $stuprofile['contactdistrict'];}else{echo "-Nil-";} ?></p>
					</div>

				</div>
              </div>
              
             <div class="col-12">
                <div class="row">

					<div class="col-md-3">
						<p>State:</p>
					</div>

					<div class="col-md-5">
						<p class="<?php if($stuprofile['contactstate']=="" || $stuprofile['contactstate']=="0"){ echo "empty";} ?>"><?php if($stuprofile['contactstate']!="" && $stuprofile['contactstate']!="0"){ echo $stuprofile['contactstate'];}else{echo "-Nil-";} ?></p>
					</div>

				</div>
              </div>
              
              <div class="col-12">
                <div class="row">

					<div class="col-md-3">
						<p>Country:</p>
					</div>

					<div class="col-md-5">
						<p class="<?php if($stuprofile['contactcountry']=="" || $stuprofile['contactcountry']=="0"){ echo "empty";} ?>"><?php if($stuprofile['contactcountry']!="" && $stuprofile['contactcountry']!="0"){ echo $stuprofile['contactcountry'];}else{echo "-Nil-";} ?></p>
					</div>

				</div>
              </div>
              
              <div class="col-12">
                <div class="row">

					<div class="col-md-3">
						<p>Pincode:</p>
					</div>

					<div class="col-md-5">
						<p class="<?php if($stuprofile['contactpincode']=="" || $stuprofile['contactpincode']=="0"){ echo "empty";} ?>"><?php if($stuprofile['contactpincode']!="" && $stuprofile['contactpincode']!="0"){ echo $stuprofile['contactpincode'];}else{echo "-Nil-";} ?></p>
					</div>

				</div>
			</div>
             			  
             	<div class="col-12">
                <div class="row">

					<div class="col-md-3 col-5">
						<p>Whatsapp Number:</p>
					</div>

					<div class="col-md-5 col-7">
						<p class="<?php if($stuprofile['whatsappno']=="" || $stuprofile['whatsappno']=="0"){ echo "empty";} ?>"><?php if($stuprofile['whatsappno']!="" && $stuprofile['whatsappno']!="0"){ echo $stuprofile['wacode'].' '.$stuprofile['whatsappno'];}else{echo "-Nil-";} ?></p>
					</div>

				</div>
                           
				 </div>	
              
              <div class="col-12">
                <div class="row">

					<div class="col-md-3 col-5">
						<p>Guardian Name:</p>
					</div>

					<div class="col-md-5 col-7">
						<p class="<?php if($stuprofile['guardianname']=="" || $stuprofile['guardianname']=="0"){ echo "empty";} ?>"><?php if($stuprofile['guardianname']!="" && $stuprofile['guardianname']!="0"){ echo $stuprofile['guardianname'];}else{echo "-Nil-";} ?></p>
					</div>

				</div>
			</div>
              			  
			  </div>                                                                                                 
                                                                                                                 
				  </div>
                 
                   <!--<div class="border-bottom"></div>-->   
                   
                               
                 <div id="sdtButtons5">
                                                                                                                       
				  <h3>Bank details</h3>   
                                                                                                                
               <div class="row">
                                         
              <div class="col-12">
                <div class="row">

					<div class="col-md-3">
						<p>Account Holder Name:</p>
					</div>

					<div class="col-md-4">
						<p class="<?php if($stuprofile['accountholdername']=="" || $stuprofile['accountholdername']=="0"){ echo "empty";} ?>"><?php if($stuprofile['accountholdername']!="" && $stuprofile['accountholdername']!="0"){ echo $stuprofile['accountholdername'];}else{echo "-Nil-";} ?></p>
					</div>

				</div>
              </div>
                                         
              <div class="col-12">
                <div class="row">

					<div class="col-md-3">
						<p>Bank Name:</p>
					</div>

					<div class="col-md-4">
						<p class="<?php if($stuprofile['bankname']=="" || $stuprofile['bankname']=="0"){ echo "empty";} ?>"><?php if($stuprofile['bankname']!="" && $stuprofile['bankname']!="0"){ echo $stuprofile['bankname'];}else{echo "-Nil-";} ?></p>
					</div>

				</div>
              </div>
              
             <div class="col-12">
                <div class="row">

					<div class="col-md-3">
						<p>Branch:</p>
					</div>

					<div class="col-md-4">
						<p class="<?php if($stuprofile['branch']=="" || $stuprofile['branch']=="0"){ echo "empty";} ?>"><?php if($stuprofile['branch']!="" && $stuprofile['branch']!="0"){ echo $stuprofile['branch'];}else{echo "-Nil-";} ?></p>
					</div>

				</div>
			</div>
             
              <div class="col-12">
                <div class="row">

					<div class="col-md-3">
						<p>IFSC Code:</p>
					</div>

					<div class="col-md-4">
						<p class="<?php if($stuprofile['ifsccode']=="" || $stuprofile['ifsccode']=="0"){ echo "empty";} ?>"><?php if($stuprofile['ifsccode']!="" && $stuprofile['ifsccode']!="0"){ echo $stuprofile['ifsccode'];}else{echo "-Nil-";} ?></p>
					</div>

				</div>
              </div>
             
              <div class="col-12">
                <div class="row">

					<div class="col-md-3">
						<p>Bank Account Number:</p>
					</div>

					<div class="col-md-4">
						<p class="<?php if($stuprofile['bankaccountno']=="" || $stuprofile['bankaccountno']=="0"){ echo "empty";} ?>"><?php if($stuprofile['bankaccountno']!="" && $stuprofile['bankaccountno']!="0"){ echo $stuprofile['bankaccountno'];}else{echo "-Nil-";} ?></p>
					</div>

				</div>
              </div>
              			  
			  </div> 
                                                             
				  </div>                                            
                                                              
                 </div>
                                                              
                     </div>                                              
                                                               
				</div>                                                
                                                                
              <div id="editprofile" class="d-none">

			  
			  <h3>Comments</h3>  
			  
				  <div class="col-12 col-sm-6 spcomments">
					  <div class="form-group position-relative error-l-50 floating">
						  <textarea class="form-control" name="spcomments" id="spcomments"  placeholder="" ><?php if($stuprofile['comments']!="" && $stuprofile['comments']!="0"){ echo $stuprofile['comments'];}else{echo "";} ?></textarea>	
					  </div>
				  </div>
			  
				  <h3>Personal details</h3>  
               
                <form id="profileform" class="tooltip-label-right mb-4" novalidate>
             
             <div class="row">
             
             <div class="col-12 col-sm-6">
              <div class="form-group position-relative error-l-50 floating">
                <input type="text" class="form-control" name="mpname" id="mpname"  placeholder=" " value="<?php if($stuprofile['stuname']!=""){ echo ucwords($stuprofile['stuname']);}else{echo "";} ?>" required >
                 <label for="mpname">Name <span>*</span></label>
              </div>
			</div>
             
            <div class="col-12 col-sm-6">
              
              <div class="form-row">
              
				  <div class="form-group col-md-3 position-relative error-l-50">
					<select class="form-control mpmcode" name="mpmcode" placeholder=" " required >
					  <option value="91">+91</option><option value="44">+44</option><option value="65">+65</option><option value="973">+973</option><option value="20">+20</option><option value="98">+98</option><option value="964">+964</option><option value="972">+972</option><option value="962">+962</option><option value="965">+965</option><option value="961">+961</option><option value="968">+968</option><option value="970">+970</option><option value="974">+974</option><option value="966">+966</option><option value="90">+90</option><option value="971">+971</option><option value="967">+967</option><option value="93">+93</option><option value="374">+374</option><option value="994">+994</option><option value="76">+76</option><option value="996">+996</option><option value="92">+92</option><option value="963">+963</option><option value="992">+992</option><option value="993">+993</option><option value="998">+998</option><option value="357">+357</option><option value="253">+253</option><option value="291">+291</option><option value="995">+995</option><option value="352">+352</option><option value="249">+249</option>
					</select>
				  </div>
             
				  <div class="form-group col-md-9 position-relative error-l-50 floating">
					<input type="number" class="form-control mpmobile" name="mpmobile" minlength="10" maxlength="10" placeholder=" " value="<?php if($stuprofile['smobile']!=""){ echo $stuprofile['smobile'];}else{echo "";} ?>" required >
					<label>Mobile <span>*</span></label>
				  </div>
              
			   </div>
             
				 </div>
             
             <div class="col-12 col-sm-6">
              <div class="form-group position-relative error-l-50 floating">
                <input type="text" class="form-control mpemail" name="mpemail"  placeholder=" " value="<?php if($stuprofile['semail']!=""){ echo $stuprofile['semail'];}else{echo "";} ?>" required >
                 <label for="mpemail">Email <span>*</span></label>
              </div>
			</div>
              
              <div class="col-12 col-sm-6">
				   <div class="form-group position-relative error-l-50 floating">
						<input class="form-control mpdob" name="mpdob" placeholder=" " value="<?php if($stuprofile['dob']!="" && $stuprofile['dob']!="0000-00-00" && $stuprofile['dob']!="01-01-1970"){ echo date("d-m-Y",strtotime($stuprofile['dob']));}else{echo "";} ?>">
						<label>DOB (DD-MM-YYYY)</label>
					</div>
              </div>
              
              <div class="col-12 col-sm-6">
              <div class="form-group position-relative error-l-50">
              	  <label>Gender</label>
               	  <div>
					  <div class="custom-control custom-radio col-sm-3">
						<input type="radio" id="mpgender1" name="mpgender" class="custom-control-input" value="Male"  <?php if($stuprofile['gender']=="Male"){ echo "checked";}else{echo "";} ?>>
						<label class="custom-control-label" for="mpgender1">Male</label>
					  </div>
					  <div class="custom-control custom-radio col-sm-3">
						<input type="radio" id="mpgender2" name="mpgender" class="custom-control-input" value="Female" <?php if($stuprofile['gender']=="Female"){ echo "checked";}else{echo "";} ?>>
						<label class="custom-control-label" for="mpgender2">Female</label>
					  </div>
					  <div class="custom-control custom-radio col-sm-3">
						<input type="radio" id="mpgender3" name="mpgender" class="custom-control-input" value="Others" <?php if($stuprofile['gender']=="Others"){ echo "checked";}else{echo "";} ?>>
						<label class="custom-control-label" for="mpgender3">Others</label>
					  </div>
                </div>
              </div>
              </div>
              
              <div class="col-12 col-sm-6">
              <div class="form-group position-relative error-l-50 floating">
                <select class="form-control mpnationality floating" name="mpnationality" onclick="this.setAttribute('value', this.value);" value="">
                  <option value=""></option>
                  <option value="Indian">Indian</option>
                  <option value="Others">Others</option>                  
                </select>
                <label>Nationality</label>
              </div>
              </div>
              
              <div class="col-12 col-sm-6">
              <div class="form-group position-relative error-l-50 floating">
                <select class="form-control mpcategory floating" name="mpcategory" onclick="this.setAttribute('value', this.value);" value="">
                  <option value=""></option>
                  <option value="General">General</option>
                  <option value="OBC">OBC</option>
                  <option value="SC">SC</option>
                  <option value="ST">ST</option>
                  <option value="Other">Other</option>                  
                </select>
                <label>Category</label>
              </div>
              </div>
              
              <div class="col-12 col-sm-6">
              <div class="form-group position-relative error-l-50 floating">
                <input type="number" class="form-control mpaadharnumber" name="mpaadharnumber" minlength="12" maxlength="12" placeholder=" " value="<?php if($stuprofile['aadharnumber']!="" && $stuprofile['aadharnumber']!="0"){ echo $stuprofile['aadharnumber'];}else{echo "";} ?>">
                 <label>Aadhar Number</label>
              </div>
			</div>
              
              <div class="col-12 col-sm-6">
              <div class="form-group position-relative error-l-50 floating">
                <input type="text" class="form-control mpfathername" name="mpfathername" placeholder=" "  value="<?php if($stuprofile['fathername']!=""){ echo $stuprofile['fathername'];}else{echo "";} ?>">
                 <label>Fathers Name</label>
              </div>
			</div>
              
              <div class="col-12 col-sm-6">
              
              <div class="form-row">
              
				  <div class="form-group col-md-3 position-relative error-l-50">
					<select class="form-control mpfathercode" name="mpfathercode" placeholder=" ">
					  <option value="+91">+91</option><option value="44">+44</option><option value="65">+65</option><option value="+973">+973</option><option value="+20">+20</option><option value="+98">+98</option><option value="+964">+964</option><option value="+972">+972</option><option value="+962">+962</option><option value="+965">+965</option><option value="+961">+961</option><option value="+968">+968</option><option value="+970">+970</option><option value="+974">+974</option><option value="+966">+966</option><option value="+90">+90</option><option value="+971">+971</option><option value="+967">+967</option><option value="+93">+93</option><option value="+374">+374</option><option value="+994">+994</option><option value="+76">+76</option><option value="+996">+996</option><option value="+92">+92</option><option value="+963">+963</option><option value="+992">+992</option><option value="+993">+993</option><option value="+998">+998</option><option value="+357">+357</option><option value="+253">+253</option><option value="+291">+291</option><option value="+995">+995</option><option value="+352">+352</option><option value="+249">+249</option>
					</select>
				  </div>
             
				  <div class="form-group col-md-9 position-relative error-l-50 floating">
					<input type="number" class="form-control mpfathermobile" name="mpfathermobile" minlength="10" maxlength="10" placeholder=" " value="<?php if($stuprofile['fatherphone']!=""){ echo $stuprofile['fatherphone'];}else{echo "";} ?>">
					<label>Fathers Phone</label>
				  </div>
              
			   </div>
             
				 </div>
              
              <div class="col-12 col-sm-6">
              <div class="form-group position-relative error-l-50 floating">
                <input type="email" class="form-control mpfatheremail" name="mpfatheremail" placeholder=" "  value="<?php if($stuprofile['fatheremail']!=""){ echo $stuprofile['fatheremail'];}else{echo "";} ?>">
                 <label>Fathers Email</label>
              </div>
			</div>
              
              <div class="col-12 col-sm-6">
              <div class="form-group position-relative error-l-50 floating">
                <input type="text" class="form-control mpfatheroccupation" name="mpfatheroccupation" placeholder=" "  value="<?php if($stuprofile['fatheroccupation']!=""){ echo $stuprofile['fatheroccupation'];}else{echo "";} ?>">
                 <label>Fathers Occupation</label>
              </div>
			</div>
              
              <div class="col-12 col-sm-6">
              <div class="form-group position-relative error-l-50 floating">
                <input type="text" class="form-control mpmothername" name="mpmothername" placeholder=" "  value="<?php if($stuprofile['mothername']!=""){ echo $stuprofile['mothername'];}else{echo "";} ?>">
                 <label>Mothers Name</label>
              </div>
			</div>
              
              <div class="col-12 col-sm-6">
              
              <div class="form-row">
              
				  <div class="form-group col-md-3 position-relative error-l-50">
					<select class="form-control mpmothercode" name="mpmothercode" >
					  <option value="+91">+91</option><option value="44">+44</option><option value="65">+65</option><option value="+973">+973</option><option value="+20">+20</option><option value="+98">+98</option><option value="+964">+964</option><option value="+972">+972</option><option value="+962">+962</option><option value="+965">+965</option><option value="+961">+961</option><option value="+968">+968</option><option value="+970">+970</option><option value="+974">+974</option><option value="+966">+966</option><option value="+90">+90</option><option value="+971">+971</option><option value="+967">+967</option><option value="+93">+93</option><option value="+374">+374</option><option value="+994">+994</option><option value="+76">+76</option><option value="+996">+996</option><option value="+92">+92</option><option value="+963">+963</option><option value="+992">+992</option><option value="+993">+993</option><option value="+998">+998</option><option value="+357">+357</option><option value="+253">+253</option><option value="+291">+291</option><option value="+995">+995</option><option value="+352">+352</option><option value="+249">+249</option>
					</select>
				  </div>
             
				  <div class="form-group col-md-9 position-relative error-l-50 floating">
					<input type="number" class="form-control mpmothermobile" name="mpmothermobile" minlength="10" maxlength="10" placeholder=" "  value="<?php if($stuprofile['motherphone']!=""){ echo $stuprofile['motherphone'];}else{echo "";} ?>">
					<label>Mothers Phone</label>
				  </div>
              
			   </div>
             
				 </div>
              
              <div class="col-12 col-sm-6">
               <div class="form-group position-relative error-l-50 floating">
                <input type="email" class="form-control mpmotheremail" name="mpmotheremail" placeholder=" " value="<?php if($stuprofile['motheremail']!=""){ echo $stuprofile['motheremail'];}else{echo "";} ?>">
                <label>Mothers Email</label>
              </div>
              </div>
              
              <div class="col-12 col-sm-6">
              <div class="form-group position-relative error-l-50 floating">
                <input type="text" class="form-control mpmotheroccupation" name="mpmotheroccupation" placeholder=" "  value="<?php if($stuprofile['motheroccupation']!=""){ echo $stuprofile['motheroccupation'];}else{echo "";} ?>">
                 <label>Mothers Occupation</label>
              </div>
			</div>
              
              <div class="col-12 col-sm-6">
              <div class="form-group position-relative error-l-50 floating">
                <select class="form-control mpcomcontact floating" name="mpcomcontact" onclick="this.setAttribute('value', this.value);" value="">
                  <option value=""></option>
                  <option value="Father">Father</option>
                  <option value="Mother">Mother</option>
                  <option value="Guardian">Guardian</option>                  
                </select>
                <label>Communication Contact</label>
              </div>
              </div>
              
              <div class="col-12 col-sm-6">
              <div class="form-group position-relative error-l-50 floating">
                <select class="form-control mpbloodgroup floating" name="mpbloodgroup"  onclick="this.setAttribute('value', this.value);" value="">
                  <option value=""></option>
                  <option value="A+">A+</option><option value="A1+">A1+</option><option value="A1B+">A1B+</option><option value="A2B+">A2B+</option><option value="A2+">A2+</option><option value="B+">B+</option><option value="O+">O+</option><option value="AB+">AB+</option><option value="A-">A-</option><option value="A1-">A1-</option><option value="A1B-">A1B-</option><option value="A2-">A2-</option><option value="B-">B-</option><option value="O-">O-</option><option value="AB-">AB-</option><option value="Not Aware">Not Aware</option> </select>
                <label>Blood Group</label>
              </div>
              </div>
              
              <div class="col-12 col-sm-6">
              <div class="form-group position-relative error-l-50 floating">
                <select class="form-control mpclassstudy floating" name="mpclassstudy" onclick="this.setAttribute('value', this.value);" value="">
                  <option value=""></option>
                 <option value="5th Standard">5th Standard</option><option value="6th Standard">6th Standard</option><option value="7th Standard">7th Standard</option><option value="8th Standard">8th Standard</option><option value="9th Standard">9th Standard</option><option value="X Standard">X Standard</option><option value="XI Standard">XI Standard</option><option value="XII Standard">XII Standard</option>                
                </select>
                <label>Class Studying / Complete</label>
              </div>
              </div>
              
              <div class="col-12 col-sm-6">
              <div class="form-group position-relative error-l-50 floating">
                <select class="form-control mpstream" name="mpstream" onclick="this.setAttribute('value', this.value);" value="">
                  <option value="">Stream</option>
                  <option value="Kerala State">Kerala State</option>
                  <option value="CBSE">CBSE</option>
                  <option value="ICSE/ISC">ICSE/ISC</option>
                  <option value="Kerala Technical">Kerala Technical</option> 
                  <option value="International">International</option> 
                  <option value="Others">Others</option>  
                  <option value="Outside India">Outside India</option>                
                </select>
                <label>Stream</label>
              </div>
              </div>
              
              			  
			  </div>
                                                 
             <div class="border-bottom"></div>                                                                                             
			 <h3>Education details</h3>  
            
             <div class="row">
             
             <div class="col-12 col-sm-6">
              <div class="form-group position-relative error-l-50 floating">
               
               <input type="text" class="form-control mpcollegename" name="mpcollegename" placeholder=" " value="<?php if($stuprofile['schoolcollegename']!="" && $stuprofile['schoolcollegename']!="0"){ echo $stuprofile['schoolcollegename'];}else{echo "";} ?>">
                
                <label>Name of School Last Studied / Studying</label>
              </div>
              </div>
              
                            
              <div class="col-12 col-sm-6">
              <div class="form-group position-relative error-l-50 floating">
                <input type="text" class="form-control" name="mpaddressline" placeholder=" " value="<?php if($stuprofile['eduaddress']!="" && $stuprofile['eduaddress']!="0"){ echo $stuprofile['eduaddress'];}else{echo "";} ?>">
                 <label>Address Line</label>
              </div>
			</div>
              
              <div class="col-12 col-sm-6">
              <div class="form-group position-relative error-l-50 floating">
                <select class="form-control mpcountry" name="mpcountry" onclick="this.setAttribute('value', this.value);" value="">
                  <option value=""></option>
                  <option value="India">India</option> 
                  <option value="Others">Others</option>                  
                </select>
                <label>Country</label>
              </div>
              </div>
              
             
              <!--<div class="col-12 col-sm-6">
              <div class="form-group position-relative error-l-50 floating">
                <select class="form-control mpmedium" name="mpmedium" onclick="this.setAttribute('value', this.value);" value="">
                  <option value=""></option>
                 <?php //echo $qualification;?>                
                </select>
                <label>Educational Qualification List</label>
              </div>
              </div>-->  
              
              <?php 

					$marksheets = $stuprofile['marksheets'];
					$marksheetlist = "";

					if($marksheets!="" && $marksheets!="0"){

						$marksheetsarr = explode('|',$marksheets);
						$mscount = 0;
						foreach($marksheetsarr as $key=>$marksheet){

							if($key==$mscount) $marksheet = $marksheet;else $marksheet = $marksheet.', ';

							$marksheetlist .= '<div class="file_ms px-2"> '.$marksheet.'&nbsp;&nbsp;</div>';
							$mscount++;
						}

					}

				?>
             
              <div class="col-12 col-sm-6">
                	
                 	<div class="row">
						<div class="col-md-12">
						  <div class="form-group position-relative error-l-50 floating">

						<div id="drop-zone">
							<div class="dropzone-wrapper">
							  <div class="dropzone-desc" id="clickHere">
								<i class="icon-upload mb-2"></i>
								<p class="list-item-heading mb-1">Upload Marksheets (Optional)</p>
								  <p class="text-muted mb-2">Max each file size upto 1MB. File format JPG, PNG and PDF only.</p>
							  </div>
							  <input type="file" name="file[]" id="file" class="dropzone" multiple>
							</div>

								<div id='filename'><?php echo $marksheetlist;?></div>
							  </div>
						  </div>
						</div>
					  </div>
             
			</div>
              
                          			  
			  </div>
                                                 
            <div class="border-bottom"></div>                                                                                             
			<h3>Contact details</h3>  
             
             <div class="row">
                                         
              <div class="col-12 col-sm-6">
              <div class="form-group position-relative error-l-50 floating">
                <input type="text" class="form-control mpcontacthouseno" name="mpcontacthouseno" placeholder=" " value="<?php if($stuprofile['housenameno']!="" && $stuprofile['housenameno']!="0"){ echo $stuprofile['housenameno'];}else{echo "";} ?>">
                 <label>House / Appartment Name</label>
              </div>
			</div>
              
              <div class="col-12 col-sm-6">
				  <div class="form-group position-relative error-l-50 floating">
					<input type="text" class="form-control mpcontactaddressline" name="mpcontactaddressline" placeholder=" " value="<?php if($stuprofile['contactaddress']!="" && $stuprofile['contactaddress']!="0"){ echo $stuprofile['contactaddress'];}else{echo "";} ?>">
					 <label>Place / Street</label>
				  </div>
			  </div>
              
              <div class="col-12 col-sm-6">
              <div class="form-group position-relative error-l-50 floating">
               <input type="text" class="form-control mpcontactpost" name="mpcontactpost" placeholder=" " value="<?php if($stuprofile['contactpost']!="" && $stuprofile['contactpost']!="0"){ echo $stuprofile['contactpost'];}else{echo "";} ?>">
                <label>Post Office</label>
              </div>
              </div>              
              
              <div class="col-12 col-sm-6">
              <div class="form-group position-relative error-l-50 floating">
                             
                <select class="form-control mpcontactcountry" name="mpcontactcountry" onclick="this.setAttribute('value', this.value);" value="">
                   <?php echo $countrylist['countryoption'];?>           
                </select>
                <label>Country</label>
              </div>
              </div>
              
             <div class="col-12 col-sm-6">
              <div class="form-group position-relative error-l-50 floating constatelist">
                <select class="form-control mpcontactstate" name="mpcontactstate" onclick="this.setAttribute('value', this.value);" value="">
                  <?php //echo $statelist['stateoption'];?>
                </select>
                <label>State</label>
              </div>
              </div>
              
              <div class="col-12 col-sm-6">
              <div class="form-group position-relative error-l-50 floating">
               	<input type="text" class="form-control mpcontactdistrict" name="mpcontactdistrict" placeholder=" " value="<?php if($stuprofile['contactdistrict']!="" && $stuprofile['contactdistrict']!="0"){ echo $stuprofile['contactdistrict'];}else{echo "";} ?>">
                <label>District</label>
              </div>
              </div>
              
              <div class="col-12 col-sm-6">
              <div class="form-group position-relative error-l-50 floating">
                <input type="text" class="form-control mpcontactpincode" name="mpcontactpincode" placeholder=" " value="<?php if($stuprofile['contactpincode']!="" && $stuprofile['contactpincode']!="0"){ echo $stuprofile['contactpincode'];}else{echo "";} ?>">
                 <label>Pincode</label>
              </div>
			</div>
             			  
             	<div class="col-12 col-sm-6">
              
              <div class="form-row">
              
				  <div class="form-group col-md-3 position-relative error-l-50">
					<select class="form-control mpwacode" name="mpwacode" >
					  <option value="+91">+91</option><option value="44">+44</option><option value="65">+65</option><option value="+973">+973</option><option value="+20">+20</option><option value="+98">+98</option><option value="+964">+964</option><option value="+972">+972</option><option value="+962">+962</option><option value="+965">+965</option><option value="+961">+961</option><option value="+968">+968</option><option value="+970">+970</option><option value="+974">+974</option><option value="+966">+966</option><option value="+90">+90</option><option value="+971">+971</option><option value="+967">+967</option><option value="+93">+93</option><option value="+374">+374</option><option value="+994">+994</option><option value="+76">+76</option><option value="+996">+996</option><option value="+92">+92</option><option value="+963">+963</option><option value="+992">+992</option><option value="+993">+993</option><option value="+998">+998</option><option value="+357">+357</option><option value="+253">+253</option><option value="+291">+291</option><option value="+995">+995</option><option value="+352">+352</option><option value="+249">+249</option>
					</select>
				  </div>
             
				  <div class="form-group col-md-9 position-relative error-l-50 floating">
					<input type="number" class="form-control mpwhatsappno" name="mpwhatsappno" minlength="10" maxlength="10" placeholder=" "  value="<?php if($stuprofile['whatsappno']!=""){ echo $stuprofile['whatsappno'];}else{echo "";} ?>">
					<label>Whatsapp Number</label>
				  </div>
              
			   </div>
             
				 </div>		
              
              <div class="col-12 col-sm-6">
              <div class="form-group position-relative error-l-50 floating">
                <input type="text" class="form-control mpguardianname" name="mpguardianname" placeholder=" " value="<?php if($stuprofile['guardianname']!="" && $stuprofile['guardianname']!="0"){ echo $stuprofile['guardianname'];}else{echo "";} ?>">
                 <label>Guardian Name</label>
              </div>
			</div>	 	  
              			  
			  </div>
               
             <div class="border-bottom"></div>                                                                                             
			<h3>Bank details</h3>                                                                        
           
             <div class="row">
                                         
              <div class="col-12 col-sm-6">
              <div class="form-group position-relative error-l-50 floating">
                <input type="text" class="form-control mpaccholdername" name="mpaccholdername" placeholder=" " value="<?php if($stuprofile['accountholdername']!="" && $stuprofile['accountholdername']!="0"){ echo $stuprofile['accountholdername'];}else{echo "";} ?>">
                 <label>Account Holder Name</label>
              </div>
			</div>
                                         
              <div class="col-12 col-sm-6">
              <div class="form-group position-relative error-l-50 floating">
               
               	<input type="text" class="form-control mpbankname" name="mpbankname" placeholder=" " value="<?php if($stuprofile['bankname']!="" && $stuprofile['bankname']!="0"){ echo $stuprofile['bankname'];}else{echo "";} ?>">
                <label>Bank Name</label>
              </div>
              </div>
              
             <div class="col-12 col-sm-6">
              <div class="form-group position-relative error-l-50 floating">
                <input type="text" class="form-control mpbranch" name="mpbranch" placeholder=" " value="<?php if($stuprofile['branch']!="" && $stuprofile['branch']!="0"){ echo $stuprofile['branch'];}else{echo "";} ?>">
                 <label>Branch</label>
              </div>
			</div>
             
              <div class="col-12 col-sm-6">
               <div class="form-group position-relative error-l-50 floating">
                <input type="text" class="form-control mpifsccode" name="mpifsccode" placeholder=" " value="<?php if($stuprofile['ifsccode']!="" && $stuprofile['ifsccode']!="0"){ echo $stuprofile['ifsccode'];}else{echo "";} ?>">
                <label>IFSC Code</label>
              </div>
              </div>
             
              <div class="col-12 col-sm-6">
               <div class="form-group position-relative error-l-50 floating">
                <input type="number" class="form-control mpaccountnumber" name="mpaccountnumber" maxlength="18" placeholder=" " value="<?php if($stuprofile['bankaccountno']!="" && $stuprofile['bankaccountno']!="0"){ echo $stuprofile['bankaccountno'];}else{echo "";} ?>">
                <label>Bank Account Number</label>
              </div>
              </div>
             
              <div class="col-12 col-sm-6">
               <div class="form-group position-relative error-l-50 floating">
                <input type="number" class="form-control mpreenteraccountnumber" name="mpreenteraccountnumber"  maxlength="18" placeholder=" " value="<?php if($stuprofile['bankaccountno']!="" && $stuprofile['bankaccountno']!="0"){ echo $stuprofile['bankaccountno'];}else{echo "";} ?>">
                <label>Re-Enter Bank Account Number</label>
              </div>
              </div>
              			  
			  </div>
                                                
                   <input type="hidden" id="sid" name="sid" value="<?php echo $sid;?>" />                            
                                                 
            </form>
             
              </div>                                                                                                                                                 
                                                                 
              </div>
              
              
              <?php if(isset($roleaccess['Registered Courses'][3]) && $roleaccess['Registered Courses'][3]=== 'y') { ?>
              
              <div id="customButtons2">
                            
                  <?php if(isset($roleaccess['Admission'][0]) && $roleaccess['Admission'][0]=== 'y') { ?>           
                            
					   <div class="text-right mt-3">         
							<button type="button" class="btn btn-outline-primary addadmission">Add Admission</button>      
					  </div>
                           
                  <?php } ?>                
                            
		<?php 

			if(!empty($feepayments['coursename'])){//print_r($feepayments);

			foreach($feepayments['coursename'] as $key=>$feepayment){

				
				$tablepay = $tablepaynow = $ide = "";
				$sno = $psno = 1;

				$grandtotal = $grandtotalnow = $totalfee = $paidfee = $duefee = $discountfee = $discount = $activetotalfee = $activetotaldiscount = 0;

				$coursename = $refundApp = "";
				
				$checkdiscount = false;
				
				$requestdate = date("d M Y",strtotime($feepayments['requested_at'][$key]));
				$approvedate = date("d M Y",strtotime($feepayments['approved_date'][$key]));
				
				$admissiontime = date('M Y',strtotime($feepayments['starts_on'][$key])).' - '. date('M Y',strtotime($feepayments['ends_on'][$key]));

				$center = $feepayments['center'][$key];
				$totalfee = $feepayments['totalfee'][$key];
				$paidfee = $feepayments['paidfee'][$key];
				$duefee = $feepayments['duefee'][$key];

				$courseid = $feepayments['courseid'][$key];	
				$cride = $feepayments['ide'][$key];	

				$screentest = $feepayments['screentest'][$key];
                                $refundApp = $feepayments['refund'][$key];
				
				$status = $feepayments['approved'][$key];	
 
				
				if($status=="y"){
					
							
					foreach($coursepay as $paylist){
						
						$requestid = $paylist['requestid'];
						
						if($cride != $requestid) continue; 
						
						
						$coursename = $paylist['coursename'];
						$center = $paylist['centers'];
						$refund = $paylist['refundpolicy'];
						
						$amount = $paylist['amount'];
						$total = $paylist['total'];
						$taxable = $paylist['taxable'];
						$kf = $paylist['kf'];
						$cov = $paylist['cov'];
						$sac = 999293;
						
						$active = $paylist['active'];
						
						$discountamt = 0;$thdiscount = $tddiscount = $thtax =  $tdtax = $thcov =  $tdcov = "";
						$taxamt = $activetotalamt = $activetotaltaxamt = 0;
						$colspan=11;

						$tax = $paylist['tax'];
						$discount = $paylist['discount'];
						
						$activetotalamt = $amount;
												
						if(intval($discount)>0) {
							
							$discountamt = $discount;
							$tddiscount = '<td width="12%">'.$discountamt.'</td>';
							
							$amount = $amount - $discount;
							
							$checkdiscount = true;
							
							if($active=="1")  $activetotaldiscount += $discountamt;
														
						}else{
							$tddiscount = '<td>[DISCOUNT]</td>';
						}
						
						if($tax=="0" || $tax=="NA"){
							$tdnontaxable = $amount;
						}else{
							$tdnontaxable = 0;
						}

						if($tax!="0" && $tax!="NA"){ 

							$tdtaxable = $amount;				

							$taxgst = $tax/2;
							if(intval($tax)>0) $taxamt = $amount * ($tax/100);
							$taxamtgst = $taxamt/2;
							$taxamtgst = number_format($taxamtgst,2);
							
							if(intval($tax)>0) $activetotaltaxamt = $activetotalamt * ($tax/100);
							
							//$colspan +=4;

						} else {
							$tdtaxable = 0;
							$taxgst = $taxamtgst = "NA";
						}

						$thtax = '<th scope="col" colspan="2" width="15%"><span class="thtax">CGST</span> <span class="thtaxvalue"><span>Rate %</span> <span>Amount</span></span></th>
							  <th scope="col" colspan="2" width="15%"><span class="thtax">SGST</span> <span class="thtaxvalue"><span>Rate %</span> <span>Amount</span></span></th>';

						$tdtax = '<td width="8%">'.$taxgst.'</td>
								  <td width="8%">'.$taxamtgst.'</td>
								  <td width="8%">'.$taxgst.'</td>
								  <td width="8%">'.$taxamtgst.'</td>';


						$kfamt = $amount * ($kf/100);
						
						$activetotalkfamt = $activetotalamt * ($kf/100);
												
						if($cov!="0" && $cov!="NA"){
							$thcov = '<th scope="col" width="15%">CESS COV(%)</th>';
							$covamt = $amount * ($cov/100);
							$tdcov = '<td width="15%">'.$covamt.'%</td>';
							$colspan +=1;
						}
												
						$grandtotal += $total;
						
						$activetotalfinalamt = round($activetotalamt);
						
						if($active=="1") {
							$activetotalfee += round($activetotalamt + $activetotaltaxamt + $activetotalkfamt);
						}
						
						$tablepay .= '<tr>
									  <th scope="row" width="7%">'.$sno.'.</th>
									  <td width="20%"><strong>'.$paylist['description'].'</strong></td>
									  <td width="11%">'.number_format($activetotalfinalamt,2).'</td>
									  <td width="11%">'.$tdnontaxable.'</td>
									  <td width="11%">'.$tdtaxable.'</td>
									  '.$tddiscount.'
									  '.$tdtax.'
									  <td width="12%">'.$kf.'</td>
									  <td width="8%">'.$kfamt.'</td>
									  '.$tdcov.'
									  <td width="10%">'.number_format($total,2).'</td>
									</tr>';
						
												
						$sno++;
					}
				
				
					if($checkdiscount){ 
						$thdiscount = '<th scope="col" width="12%">Discount</th>';
						$tablepay = str_replace("<td>[DISCOUNT]</td>",'<td width="12%">0</td>',$tablepay);
						$colspan +=1;
					}
					else {
						$tablepay = str_replace("<td>[DISCOUNT]</td>",'',$tablepay);
					}
					
				}else{
					
					$crstatusclass = "";
					$crstatus = "";
					$btnstatus = "";

					if($status=="y"){

						$crstatus = "Approved";
						$crstatusclass = "approved";
						$btnstatus = "";
						$approvedate = $approvedate;

					}else if($status=="w"){

						$crstatus = "Waiting List";
						$crstatusclass = "waitlisted";
						$btnstatus = "disabled";
						$approvedate = "Nil";

					}else if($status=="n"){

						$crstatus = "Not Qualified";
						$crstatusclass = "rejected";
						$btnstatus = "disabled";
						$approvedate = "Nil";

					}else if($status=="q"){

						$crstatus = "Waiting For Approval";
						$crstatusclass = "pending";
						$btnstatus = "disabled";
						$approvedate = "Nil";

					}else if($status=="d"){

						$crstatus = "Rejected";
						$crstatusclass = "rejected";
						$btnstatus = "disabled";
						$approvedate = "Nil";

					}else{
						$btnstatus = "disabled";
						$approvedate = "Nil";
					}
					
				}
		
					
		?>
		
		<?php if($status=="y"){?>
	
		<div class="row feepayments border-bottom my-0 mx-0">

			<div class="col-12">
				<div class="card">
					<div class="card-body px-0 pb-4 pt-0">

						<div class="row">

							<div class="col-md-6 col-sm-6 col-lg-8 col-12">
								<h2 class="mb-2"><?php echo $feepayment; ?>
                                           
                                           <?php if(isset($roleaccess['Admission'][1]) && $roleaccess['Admission'][1]=== 'y') { ?>
                                            	<a target="_blank" href="<?php echo base_url();?>viewrequest?id=<?php echo $cride;?>"><img style="padding:5px 10px" src="<?php echo base_url();?>images/edit.png"></a>
                                            <?php } ?>
                                            
                                            <?php if(isset($roleaccess['Course Change View'][0]) && $roleaccess['Course Change View'][0]=== 'y') { ?>
                                            	<span data-id="<?php echo $cride;?>" data-sid="<?php echo $sid;?>" data-cid="<?php echo $courseid;?>" data-center="<?php echo $center; ?>" class="pchange" style="cursor: pointer;position: relative;top:0px;margin-left: 13px;font-weight: bold;font-size: 14px;padding: 5px 10px;color: #fff;border-radius:5px;background: linear-gradient(180deg, #4F70C4 0%, #1C47B3 100%);">Course Change</span>
                                            <?php } ?>
                                  </h2>
								<div class="row mb-3 feetop">

									<div class="col-md-4 text-left px-2">
										<p class="list-item-heading mb-1"><i class="icon-map-pin"></i> <span>Assigned Center:</span> <span><?php echo $center; ?></span>
                                                                                <?php if(isset($roleaccess['Center Change View'][3]) && $roleaccess['Center Change View'][3]=== 'y') { ?>
                                                                                    <span  class="cenchange" style="cursor: pointer" data-center="<?php echo $center; ?>" data-crid="<?php echo $cride;?>" data-cid="<?php echo $courseid;?>" ><img  style="padding:5px 10px" src="<?php echo base_url();?>images/edit.png"></span>
                                                                                <?php } ?>
                                                                                </p>
									</div>

									<div class="col-md-5 text-left px-2">
										<p class="list-item-heading mb-1"><i class="icon-invoice-b"></i> <span>Admission Time:</span> <span><?php echo $admissiontime; ?></span></p>
									</div>
                                                                    <?php if(($refundApp === '0') ||($refundApp === '4') ||($refundApp === '5')||($refundApp === '6')) { ?>
                                                                        <div class="col-md-3 text-left px-2">
                                                                        
                                            <?php if(isset($roleaccess['Refund Activation'][0]) && $roleaccess['Refund Activation'][0]=== 'y') { ?>                                                       
													<p class="list-item-heading mb-1"><i class="icon-invoice-b"></i> <span>Refund:</span> <span><input data-id="<?php echo $cride;?>" type="checkbox" name="check-1" value="<?php echo $refundApp;?>" class="lcs_check" autocomplete="off" /></span></p>
                                                                             
                                             <?php } ?>                                
									</div>
                                                                    <?php } else if(($refundApp === '1')) {?>
                                                                    
                                                                    <div class="col-md-4 col-sm-4 col-4 text-left px-2 mt-n2">
                                                                        <p class="list-item-heading mb-1"><i class="icon-invoice-b"></i> <span>Refund :</span><span><input data-id="<?php echo $cride;?>" type="checkbox" name="check-1" value="<?php echo $refundApp;?>" class="lcs_check" autocomplete="off" /></span><span> <button type="button" data-refund="<?php echo $refundApp; ?>" data-id="<?php echo $cride; ?>" class="btn btn-primary addrefund">Request</button></span></p>
									</div>
                                                                    <?php } else if($refundApp === '2'){?>
                                                                        <div class="col-md-4 col-sm-4 col-4 text-left px-2 mt-n2">
                                                                        <p class="list-item-heading mb-1"><i class="icon-invoice-b"></i> <span>Refund :</span><span> <button type="button" style="background:#F48D25 !important" class="btn btn-primary">Progressing</button></span></p>
									</div>
                                                                    <?php } else if($refundApp === '3'){?>
                                                                     <div class="col-md-4 col-sm-4 col-4 text-left px-2 mt-n2">
                                                                        <p class="list-item-heading mb-1"><i class="icon-invoice-b"></i> <span>Refund :</span><span> <button type="button" style="background:#3CAF92 !important" class="btn btn-primary">Progressing</button></span></p>
									</div>
                                                                    <?php } ?>                                                                   

								</div>
								
								<div class="row regcourses mb-3">

									<div class="col-md-4 col-sm-4 text-left px-2">
										<p class="list-item-heading mb-1"><i class="icon-send"></i> <span>Requested Date:</span> <span><?php echo $requestdate; ?></span></p>
									</div>

									<div class="col-md-4 col-sm-4 text-left px-2">
										<p class="list-item-heading mb-1"><i class="icon-check-circle"></i> <span>Approved Date:</span> <span><?php echo $approvedate; ?></span></p>
									</div>

									<!--<div class="col-md-4 col-sm-4 text-left px-2">
										<p class="list-item-heading mb-1"><i class="icon-status"></i> <span>Status:</span> <span class="crstatus-<?php //echo $crstatusclass;?> px-3 py-2"><?php //echo $crstatus;?></span></p>
									</div>-->

								</div>
								
								<div class="row mb-3">

									<div class="col-md-6 text-left px-2">
										<p class="list-item-heading mb-1"><i class="icon-credit-card-2"></i> <span>Active Total Fees:</span> <span class="totalfee"><?php echo number_format($activetotalfee,2); ?></span></p>
									</div>

									<div class="col-md-6 text-left px-2">
										<p class="list-item-heading mb-1"><i class="icon-minus-circle"></i> <span>Active Total Discount:</span> <span class="duefee"><?php echo number_format($activetotaldiscount,2); ?></span></p>
									</div>

								</div>
								
								<div class="row">

									<div class="col-md-4 text-left px-2">
										<p class="list-item-heading mb-1"><i class="icon-credit-card-2"></i> <span>Total Fees:</span> <span class="totalfee"><?php echo number_format(round($totalfee),2); ?></span></p>
									</div>

									<div class="col-md-4 text-left px-2">
										<p class="list-item-heading mb-1"><i class="icon-check-circle"></i> <span> Remitted Fees:</span> <span class="paidfee"><?php echo number_format(round($paidfee),2); ?></span></p>
									</div>

									<div class="col-md-4 text-left px-2">
										<p class="list-item-heading mb-1"><i class="icon-minus-circle"></i> <span>Due Fees:</span> <span class="duefee"><?php echo number_format(round($duefee),2); ?></span></p>
									</div>

								</div>

							</div>

							<div class="col-md-6 col-sm-6 col-lg-4 col-12 d-flex align-items-center justify-content-end">
								
								<div class="row w-100">

									<div class="col-md-10 text-right">
										<a href="javascript:void(0);" title="Know More" data-ppercent="<?php echo $stuprofile['profilepercent'];?>" data-screentest="<?php echo $screentest;?>" data-cride="<?php echo $cride;?>" class="knowmore"> <button class="btn btn-outline-primary" type="button" data-toggle="collapse" data-target="#knowmore<?php echo $key;?>" aria-expanded="false" aria-controls="knowmore<?php echo $key;?>">Know More <i class="icon-chevron-down-b"></i></button></a>
									</div>

								</div>
						
							</div>

						</div>

					
						<div class="collapse" id="knowmore<?php echo $key;?>">
						  <div class="py-2 mt-0">
							
							<div class="px-0 py-2">
			  
									<h3 class="title mb-3 mt-2">Fees Structure</h3>

										<table class="table">
									  <thead>
										<tr>
										  <th scope="col" width="5%">Sl. no.</th>
										  <th scope="col" width="15%">Description</th>
										  <th scope="col" width="8%">Total Fee</th>
										  <th scope="col" width="10%">Non Taxable Value</th>
										  <th scope="col" width="10%">Taxable Value</th>
										  <?php echo $thdiscount;?>
										  <?php echo $thtax;?>
										  <th scope="col" width="8%">CESS KF %</th>
										  <th scope="col" width="8%">CESS KF Amount</th>
										  <?php echo $thcov;?>
										  <th scope="col" width="15%">Total</th>
										</tr>
									  </thead>
									  <tbody>

										<?php echo $tablepay; ?>

										<tr>

										  <td colspan="<?php echo $colspan;?>" class="totalamt">Grand total</td>
										  <td class="totalfee"><?php echo number_format($grandtotal,2); ?></td>
										</tr>
									  </tbody>
									</table>

							</div>
							
								<?php 
				  
								$payhistory = $challandetails = $partialdetails = "";
							   
							    $chno = 1;

								foreach($feepayments['feepaymentid'] as $key1=>$feepaylist){

									$requestid = $feepayments['requestid'][$key1];

									if($cride != $requestid) continue; 
									
									if($feepayments['paymentstatus'][$key1]=="p"){

									$payhistory .= ' <tr>
										  <td>'.$chno.'.</td>
										  <td>'.date("d M Y",strtotime($feepayments['paymentdate'][$key1])).'</td>
										  <td>'.$feepayments['paymentmode'][$key1].'</td>
										  <td>'.number_format($feepayments['grandtotal'][$key1],2).'</td>
										  <td><a href="stufeebill?crid='.$cride.'&cno='.$feepayments['challanno'][$key1].'&userid='.$sid.'" target="_blank"><i class="icon-eye-b"></i>View</a></td>
										  </tr>';
									
									$challandetails .= ' <tr>
										  <td>'.$chno.'.</td>
										  <td>'.$feepayments['challanno'][$key1].'</td>
										  <td>'.date("d M Y",strtotime($feepayments['paymentdate'][$key1])).'</td>
										  <td><span style="padding:5px;background: #EDFAF7;border: 1px solid #3CAF92;box-sizing: border-box;border-radius: 12px;color:#3CAF92;font-size:12px;width:50px;display:inline-block;text-align: center;">Paid</span></td>
										  <td>'.number_format($feepayments['grandtotal'][$key1],2).'</td>
										  <td><a href="stufeebill?crid='.$cride.'&cno='.$feepayments['challanno'][$key1].'&userid='.$sid.'" target="_blank"><i class="icon-eye-b"></i>View</a></td>
										  </tr>';
										
									}else{
										
										$challandetails .= ' <tr>
										  <td>'.$chno.'.</td>
										  <td><a href="stumyprofile/downloadChallan?id='.$cride.'&challan=unpaid&userid='.$sid.'" target="_blank">'.$feepayments['challanno'][$key1].'</a></td>
										  <td>'.date("d M Y",strtotime($feepayments['created_at'][$key1])).'</td>
										  <td><span style="padding:5px;background: #FFF2F2;border: 1px solid #ED5252;box-sizing: border-box;border-radius: 12px;color:#ED5252;font-size:12px;width:auto;display:inline-block">Unpaid</span></td>
										  <td>'.number_format($feepayments['grandtotal'][$key1],2).'</td>
										  <td><span class="addpay" style="color:#0332AA;padding-left: 20px;background:url(images/addpay.png) no-repeat;background-position-y: 4px;cursor:pointer">Add Payment</span></td>
										  </tr>';
									}

									 /*<a href="stumyprofile/downloadChallan?id='.$crid.'&cno='.$feepayments['challanno'][$key1].'"target="_blank" ><i class="icon-download-b"></i> Download</a>*/
									
									$chno++;

								}
							   
							   $prno = 1;
							   
							   foreach($allpartialpaydetails['partialamt'] as $key2=>$partiallist){
								   
								    $crqid = $allpartialpaydetails['requestid'][$key2];

									if($cride != $crqid) continue;
								   
								   	$partialdetails .= ' <tr>
										  <td>'.$prno.'.</td>
										  <td>'.date("d M Y",strtotime($allpartialpaydetails['updated_at'][$key2])).'</td>
										  <td>'.number_format($allpartialpaydetails['partialamt'][$key2],2).'</td>
										  </tr>';
								   
								    $prno++;
								   
							   }

							?>
							
							<?php if(isset($roleaccess['Payments Tab'][3]) && $roleaccess['Payments Tab'][3]=== 'y') { ?>
						
							<div class="px-0 py-2">

								<h3 class="title my-4">Challan Details</h3>


								 <table class="table payhistory">
									  <thead>
										<tr>
										  <th scope="col" width="10%">Sl. no.</th>
										  <th scope="col" width="20%">Challan ID</th>
										  <th scope="col" width="20%">Generated Date</th>
										  <th scope="col" width="20%">Status</th>
										  <th scope="col" width="15%">Total</th>
										  <th scope="col" width="15%">Action</th>
										</tr>
									  </thead>

									 <tbody>

										  <?php echo $challandetails;?>

									 </tbody>

								  </table>

							  </div>
							  
							  
							  <?php if($payhistory!=""){?>


								<div class="px-0 py-2">

								<h3 class="title my-4">Payment history</h3>


								 <table class="table payhistory">
									  <thead>
										<tr>
										  <th scope="col" width="10%">Sl. no.</th>
										  <th scope="col" width="25%">Date</th>
										  <th scope="col" width="20%">Mode</th>
										  <th scope="col" width="25%">Amount Remitted</th>
										  <th scope="col" width="20%">Receipt</th>
										</tr>
									  </thead>

									 <tbody>

										  <?php echo $payhistory;?>

									 </tbody>

								  </table>

							  </div>


							 <?php }?>
							  
							            
								<?php if($partialdetails!=""){?>


								<div class="px-0 py-2">

								<h3 class="title my-4">Partial Details</h3>


								 <table class="table payhistory">
									  <thead>
										<tr>
										  <th scope="col" width="10%">Sl. no.</th>
										  <th scope="col" width="25%">Generated Date</th>
										  <th scope="col" width="25%">Partial Amount</th>
										</tr>
									  </thead>

									 <tbody>

										  <?php echo $partialdetails;?>

									 </tbody>

								  </table>

							  </div>


							 <?php }?>
							 
							 <?php } ?>
					  
						  </div>
						</div>
            

					</div>

				</div>
			</div>
			            
		</div>
		
		<?php }else{?>
		
		<div class="row regcourses feepayments border-bottom my-0 mx-0 <?php echo $crstatusclass;?>">

			<div class="col-12 mb-4">
				<div class="card">
					<div class="card-body p-0">

						<div class="row">

							<div class="col-md-12 col-sm-12 col-lg-9 col-12">
								
								
								<h2 class="mb-2"><?php echo $feepayment; ?>
                                                                    
                                                                    <?php if(isset($roleaccess['Admission'][1]) && $roleaccess['Admission'][1]=== 'y') { ?>
                                                                    
                                                                     <a target="_blank" href="<?php echo base_url();?>viewrequest?id=<?php echo $cride;?>"><img style="padding:5px 10px" src="<?php echo base_url();?>images/edit.png"></a>
                                                                     
                                                                     <?php }?>
                                                               
                                                                </h2>

								<div class="row mb-3">

									<div class="col-md-4 col-sm-4 text-left px-2">
										<p class="list-item-heading mb-1"><i class="icon-send"></i> <span>Requested Date:</span> <span><?php echo $requestdate; ?></span></p>
									</div>

									<div class="col-md-4 col-sm-4 text-left px-2">
										<p class="list-item-heading mb-1"><i class="icon-check-circle"></i> <span>Approved Date:</span> <span><?php echo $approvedate; ?></span></p>
									</div>

									<div class="col-md-4 col-sm-4 text-left px-2">
										<p class="list-item-heading mb-1"><i class="icon-status"></i> <span>Status:</span> <span class="crstatus-<?php echo $crstatusclass;?> px-3 py-2"><?php echo $crstatus;?></span></p>
									</div>

								</div>
								
								<div class="row">

									<div class="col-md-4 col-sm-4 text-left px-2">
										<p class="list-item-heading mb-1"><i class="icon-map-pin"></i> <span>Course Location:</span> <span><?php echo $center; ?></span></p>
									</div>

									<div class="col-md-6 col-sm-6 text-left px-2">
										<p class="list-item-heading mb-1"><i class="icon-invoice"></i> <span>Admission Time:</span> <span><?php echo $admissiontime; ?></span></p>
									</div>

								</div>

							</div>

							<div class="col-md-12 col-sm-12 col-lg-3 col-12 d-flex align-items-center justify-content-end">
								
								<div class="row w-100">

									<!--<div class="col-md-11 text-right">
										<button class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" <?php //echo $btnstatus;?>>Register & Pay</button>
									</div>-->    

								</div>
						
							</div>

						</div>


					</div>

				</div>
			</div>
		</div>
		
		<?php }?>
		
		<?php }}else{?>
		
					<div class="row feepayments">

						<div class="col-12 mb-4">
							<div class="card">
								<div class="card-body">

									<p class="text-muted text-center mb-0">No Courses Found.</p>

							</div>
						</div>
					</div>

				</div> 
            
             <?php }?>
                                                              
              </div>
              
              <?php } ?>
              
              <?php if(isset($roleaccess['Payments Tab'][3]) && $roleaccess['Payments Tab'][3]=== 'y') { ?>
              
              <div id="customButtons3">
                            
				  <div class="mb-3"></div>
                             
             <?php 

				  $payhistory = '';$pyno = 1;
				  
			if(!empty($feepayments['coursename'])){//print_r($feepayments);

			foreach($feepayments['coursename'] as $key=>$feepayment){

				$paycoursename = $feepayments['coursename'][$key];
				$cride = $feepayments['ide'][$key];	
                       
				  		foreach($feepayments['feepaymentid'] as $key1=>$feepaylist){
										
							$requestid = $feepayments['requestid'][$key1];

							if($cride != $requestid) continue;
							
							if($feepayments['paymentstatus'][$key1]=="p"){
							
							$payhistory .= ' <tr>
								  <td>'.$pyno.'.</td>
								  <td>'.$paycoursename.'</td>
								  <td>'.date("d M Y",strtotime($feepayments['paymentdate'][$key1])).'</td>
								  <td>'.$feepayments['paymentmode'][$key1].'</td>
								  <td>'.number_format($feepayments['grandtotal'][$key1],2).'</td>
								  <td><a href="stufeebill?crid='.$cride.'&cno='.$feepayments['challanno'][$key1].'&userid='.$sid.'" target="_blank"><i class="icon-eye-b"></i>View</a></td>
							 	  </tr>';
							
							 /*<a href="stumyprofile/downloadChallan?id='.$crid.'&cno='.$feepayments['challanno'][$key1].'"target="_blank" ><i class="icon-download-b"></i> Download</a>*/
							
							$pyno++;
								
							}
							
						}
				
			}
				  
				    ?>
            
								<?php if($payhistory!=""){?>


								<div class="px-0 py-2">

								<!--<h3 class="title my-4">Payment history</h3>-->

								 <table class="table payhistory">
									  <thead>
										<tr>
										  <th scope="col" width="10%">Sl. no.</th>
										  <th scope="col" width="30%">Course Name</th>
										  <th scope="col" width="15%">Date</th>
										  <th scope="col" width="15%">Mode</th>
										  <th scope="col" width="15%">Amount Remitted</th>
										  <th scope="col" width="15%">Actions</th>
										</tr>
									  </thead>

									 <tbody>

										  <?php echo $payhistory;?>

									 </tbody>

								  </table>

							  </div>


							<?php }}else{?>
		
					<div class="row feepayments">

						<div class="col-12 mb-4">
							<div class="card">
								<div class="card-body">

									<p class="text-muted text-center mb-0">No Payments Found.</p>

							</div>
						</div>
					</div>

				</div>
                                                                  
               <?php }?>                                                     
                                                                   
                                                              
              </div>
              
              <?php } ?>
              
              
              <?php if(isset($roleaccess['Results Tab'][3]) && $roleaccess['Results Tab'][3]=== 'y') { ?>
              
				<div id="customButtons4">
					
					 <?php //if(isset($roleaccess['Report Card'][3]) && $roleaccess['Report Card'][3]=== 'y') { ?>
            
						<div class="text-right mt-3">
							<button type="button" class="btn btn-outline-primary getreportcard">Report Card</button>
						</div>

					<?php //} ?>
            
					
					 <?php if($results['model']!=""){?>
			  <div class="row">
			   
			   	  <div class="col-12">
			   		<h3>Model Exam Results</h3>
				  </div>
			   
			   </div>
			   
			   
			   <div class="px-0 py-2 results">
			                  
                <table class="table resulttable">
              <thead>
                <tr>
                  <th scope="col" width="12%">Exam Date</th>
                  <th scope="col" width="16%">Name of Exam</th>
                  <th scope="col" width="5%">Phy</th>
                  <th scope="col" width="5%">Che</th>
                  <th scope="col" width="5%">Bio</th>
                  <th scope="col" width="5%">Mat</th>
                  <th scope="col" width="5%">P-I</th>
                  <th scope="col" width="6%">P-II</th>
                  <th scope="col" width="6%">Total Marks</th>
                  <th scope="col" width="6%">Max Marks</th>
                  <th scope="col" width="6%">Highest Marks</th>
                  <th scope="col" width="6%">Percent %</th>
                  <th scope="col" width="5%">Grade</th>
                  <th scope="col" width="5%">Rank</th>
                  <th scope="col" width="6%">Students Appeared</th>
                </tr>
              </thead>
              <tbody>
                
                <?php echo $results['model'];?>
   
              </tbody>
            </table>
               
			</div>
		   
		   
		   <div class="mb-4"></div>
		   
		   <?php }?>
		   
		   <?php if($results['weekly']!=""){?>
		   
		    <div class="row">
			   
			   	  <div class="col-12">
			   		<h3>Weekly Exam Results</h3>
				  </div>
			   
			   </div>
			   
			   
			   <div class="px-0 py-2 results">
			                  
                <table class="table resulttable">
              <thead>
                <tr>
                  <th scope="col" width="12%">Exam Date</th>
                  <th scope="col" width="16%">Name of Exam</th>
                  <th scope="col" width="5%">Phy</th>
                  <th scope="col" width="5%">Che</th>
                  <th scope="col" width="5%">Bio</th>
                  <th scope="col" width="5%">Mat</th>
                  <th scope="col" width="5%">P-I</th>
                  <th scope="col" width="6%">P-II</th>
                  <th scope="col" width="6%">Total Marks</th>
                  <th scope="col" width="6%">Max Marks</th>
                  <th scope="col" width="6%">Highest Marks</th>
                  <th scope="col" width="6%">Percent %</th>
                  <th scope="col" width="5%">Grade</th>
                  <th scope="col" width="5%">Rank</th>
                  <th scope="col" width="6%">Students Appeared</th>
                </tr>
              </thead>
              <tbody>
                
                <?php echo $results['weekly'];?>
   
              </tbody>
            </table>
               
			</div>
		   
		   <?php }?>
		   
		   <?php if($results['test']!=""){?>
		   
		    <div class="row">
			   
			   	  <div class="col-12">
			   		<h1>Screening Test Results</h1>
				  </div>
			   
			   </div>

			   <div class="mb-3"></div>
			   
			   
			   <div class="px-0 py-2 results">
			                  
                <table class="table resulttable">
              <thead>
                <tr>
                  <th scope="col" width="12%">Exam Date</th>
                  <th scope="col" width="16%">Name of Exam</th>
                  <th scope="col" width="16%">Roll No</th>
                  <th scope="col" width="5%">Phy</th>
                  <th scope="col" width="5%">Che</th>
                  <th scope="col" width="5%">Bio</th>
                  <th scope="col" width="5%">Mat</th>
                  <th scope="col" width="5%">P-I</th>
                  <th scope="col" width="6%">P-II</th>
                  <th scope="col" width="6%">Total Marks</th>
                  <th scope="col" width="6%">Max Marks</th>
                  <th scope="col" width="6%">Highest Marks</th>
                  <th scope="col" width="6%">Percent %</th>
                  <th scope="col" width="5%">Grade</th>
                  <th scope="col" width="5%">Rank</th>
                  <th scope="col" width="5%">Out Of</th>
                  <th scope="col" width="5%">Status</th>
                  <th scope="col" width="5%">Scholarship Earned</th>
                  <th scope="col" width="5%">Remarks</th>
                  <th scope="col" width="6%">Students Appeared</th>
                </tr>
              </thead>
              <tbody>
                
                <?php echo $results['test'];?>
   
              </tbody>
            </table>
               
			</div>
		   
		   <?php }?>
		   
		   <?php if($results['model']=="" && $results['weekly']=="" && $results['test']==""){?>
		   
		   <div class="row results">

					<div class="col-12 mb-4">
						<div class="card">
							<div class="card-body">

								<p class="text-muted text-center mb-0">No Results Found.</p>

						</div>
					</div>
				</div>
			</div>
	   
		   <?php }?>
		   
					
				</div>
             
              <?php } ?>
              
                                          
            </div>
            
            
          </div>
        </div>
        
       <?php } ?>
        
      </div>
      
      
	</div>
	
	
	<div id="profileupdateModal" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
				   <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				</div>
				<div class="modal-body text-center">
									
					<img src="css/img/brilliant-logo.png" alt="Payment Success" class="mb-4" />
					<h2 class="mb-4">Profile details updated successful.</h2>
					
				</div>
				<div class="modal-footer">
					<!--<a href="#" target="_blank"><button type="button" class="btn btn-primary">View Bill</button></a>-->
					<button type="button" class="btn btn-outline-primary modalclose" data-dismiss="modal">Close</button>
				</div>
								
			</div>
		</div>
	</div>

   
   <?php if(isset($roleaccess['Change Password'][1]) && $roleaccess['Change Password'][1] === 'y') { ?>
	   
	   <div id="changepasswordModal" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
			  	   <h2 class="my-0">Change Profile Password</h2>
				   <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				</div>
				<div class="modal-body text-center">
														
					<form id="updatepwdForm" class="tooltip-right-bottom" novalidate>


					  <div class="form-group position-relative error-l-50 floating">
						 <input class="form-control" type="password" id="cppassword" name="cppassword" placeholder=" " required > 
						<label>Create Password <span>*</span></label>
					 </div>

					  <div class="form-group position-relative error-l-50 floating">
						 <input class="form-control" type="password" id="cpconfpassword" name="cpconfpassword" placeholder=" " required> 
						<label>Confirm Password<span>*</span></label>
					 </div>

					  <div class="form-group position-relative error-l-50 floating">
						 <input class="form-control" type="password" id="adminpassword" name="adminpassword" placeholder=" " required> 
						<label>Admin Password<span>*</span></label>
					 </div>

					</form>
					
				</div>
				<div class="modal-footer">
					<p class="alert mb-0"></p>
					<button class="btn btn-primary updatepassword" type="button">Update</button>
					<button type="button" class="btn btn-outline-primary modalclose" data-dismiss="modal">Close</button>
				</div>
								
			</div>
		</div>
	</div>
	   
	   <?php } ?>
	   
	   <?php if(isset($roleaccess['Admission'][0]) && $roleaccess['Admission'][0]=== 'y') { ?>
	   
	   <div id="addadmissionModal" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
			  	   <h2 class="my-0">Add Admission</h2>
				   <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				</div>
				<div class="modal-body text-center">
														
					<form id="addadmissionForm" class="tooltip-right-bottom" novalidate>
			  		
			  			<div class="form-group position-relative error-l-50 floating">
							<select class="form-control coursename" name="coursename" value="" required > <option value="">Select Course</option><?php echo $courseoptions['courses'];?></select> 
							<label>Select Course <span>*</span></label>
						</div>
			  		
				  		<div class="form-group position-relative error-l-50 floating">
							<select class="form-control coursecenter" name="coursecenter" value="" required > </select> 
							<label>Select Center <span>*</span></label>
						</div>
										
					  <div class="form-group position-relative error-l-50 floating">
						 <input class="form-control" type="password" id="courseadminpassword" name="courseadminpassword" placeholder=" " required> 
						<label>Admin Password<span>*</span></label>
					 </div>

					</form>
					
				</div>
				<div class="modal-footer">
					<p class="alert mb-0"></p>
					<button class="btn btn-primary addadmissionbtn" type="button">Create Admission</button>
					<button type="button" class="btn btn-outline-primary modalclose" data-dismiss="modal">Close</button>
				</div>
								
			</div>
		</div>
	</div>
	   
	   <?php } ?>
	   
	   <?php if(isset($roleaccess['Results Tab'][3]) && $roleaccess['Results Tab'][3]=== 'y') { ?>
	   
	   <div id="reportcardModal" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
			  	   <h2 class="my-0">Report Card</h2>
				   <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				</div>
				<div class="modal-body text-center">
														
					<form id="reportcardForm" class="tooltip-right-bottom mt-3" novalidate>
			  		
			  			<div class="form-group position-relative error-l-50 floating">
							<div class="input-group input-daterange">
								<input type="text" class="form-control fromdate" placeholder="From Date" value="">
								<div class="input-group-addon">to</div>
								<input type="text" class="form-control todate" placeholder="To Date" value="">
							</div>
						</div>

					</form>
					
					<p class="alert mt-3 mb-0"></p>
					
				</div>
				<div class="modal-footer">
					<button class="btn btn-outline-primary emailreportcard" type="button">Send Mail</button>
					<button class="btn btn-primary reportcardbtn" type="button">Get Report Card</button>
					<button type="button" class="btn btn-outline-primary modalclose" data-dismiss="modal">Close</button>
				</div>
								
			</div>
		</div>
	</div>
	   
	   <?php }?>

	   <style>

               .dataTables_wrapper input[type="text"] {
    padding: 0;
}
.dataTables_wrapper select {
    padding: 0;
}

.sortable thead tr  {
    background: #E6EBF7;

/* g8 */
border: 1px solid #D7DFF0;
box-sizing: border-box;
border-radius: 10px 10px 0px 0px;
 
}


.sortable tr th {
    border-right: 0px;
    padding: 15px 0;font-size: 13px;
      color: #6F83AA;
   cursor: pointer;
   text-align: center;

}

.dataTables_info { display: none; }
#addpaymenttable_paginate { display: none;}
#addpaymenttable1_paginate { display: none;}
#addpaymenttable_filter input {display:none;}
#addpaymenttable1_filter input {display:none;}

.sortable tr td {
    border-right: 0px;
    padding: 5px 5px;
    text-align: center;font-size: 13px;
    min-width:50px;vertical-align: middle;
}
.sortable tr td a {
    color: #364159;
}
	.courseredirect{background: #3CAF92 !important;display: block;margin: auto;border: 1px solid #209679;}
	h5.modal-title p.headtitle{display: inline-block;width: 100%;text-align: center;font-weight: bold;font-size:17px;color: #fff;}
	h5.modal-title p.text-muted{display: inline-block;width: 100%;text-align: center;font-weight: 600;font-size: 14px;line-height: 36px;color: #181E29;line-height: 20px;}
	.modal-title img{display: block;margin: 1em auto}
        #paydoneModal.modal .modal-header,#payfailModal.modal .modal-header{padding: 10px 20px !important;border: none}	
		#paydoneModal.modal .modal-body,#payfailModal.modal .modal-body{padding:0 1.75rem 1.75rem}
		.modal-body p{text-align: left !important}
		.modal-backdrop.show {opacity: .5 !important;}
	</style>
	

<?php if(isset($roleaccess['Course Change View'][0]) && $roleaccess['Course Change View'][0]=== 'y') { ?>
		
<button type="button" class="btn btn-outline-primary d-none courseconfirm" data-toggle="modal" data-backdrop="static" data-target="#courseModal">Confirm Submission</button>  
<!-- Modal -->


<div class="modal fade" id="courseModal" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog modal-xl" role="document">
	<div class="modal-content">
            <div class="modal-header" style="background-color: #6884CC;height: 50px;width: auto;padding: 10px">
	  
		<h5 class="modal-title" id="exampleModalLabel">
		
			<p class="headtitle">Course Change</p>
		</h5>
	 </div>
            <div class="row" style="width: 98%;margin: 0px auto;margin-top: 25px;">
                <div class="col-12 col-sm-6" style="display: none">
                    <div class="form-group position-relative error-l-50 floating">
                      <input type="text" value="<?php date_default_timezone_set('Asia/Kolkata'); echo date("d/m/Y"); ?>" required="" class="form-control" name="pdate" id="pdate" required  placeholder=" " >
                     <label for="date">Date <span>*</span></label>
                    </div>
		</div>
                <div class="col-12 col-sm-6" style="display: none">
                    <div class="form-group position-relative error-l-50 floating">
                        <input type="text" value="<?php echo date("h:i a"); ?>" class="form-control" required="" name="ptime" id="ptime"   placeholder=" " >
                     <label for="time">Time <span>*</span></label>
                    </div>
		</div>
                <div class="col-12 col-sm-6" >
                    <div class="form-group position-relative error-l-50 floating">
                        <input type="text" value="" class="form-control" name="cname" id="cname"  required="" placeholder=" " >
                     <label for="cname">New Course Name <span>*</span></label>
                    </div>
		</div>
               <div class="col-12 col-sm-6">
                    <div class="form-group position-relative error-l-50 floating">
                        <select class="form-control " id="ccenter" name="ccenter"  required  >
                     <option value=""></option>
                    </select>
                <label>Center<span>*</span></label>
                    </div>
		</div>
                
                
            </div>
	  <span style=";font-size: 17px;padding: 10px;float:left;color: #364159">Payment Details - Current Course</span>
          <?php
           $this->table->clear();
         $tmpl = array('table_open' => '<table class="sortable disabled" id="addpaymenttable" style="width:98% !important;">');                 
         $this->table->set_template($tmpl);
         $this->table->set_heading('S.NO', 'DESCRIPTION','AMOUNT', 'REMITTED', 'CARRY FORWARD');
         echo $this->table->generate();
          
          ?>
          <div class="row" style="width: 98%">

									<div class="col-md-12 text-right px-2">
                                                                            <p class="list-item-heading mb-1"> <span>Total Remitted Amount:</span> <span class="premit" style="color: #1C47B3 !important"></span></p>
									</div>

									<div class="col-md-12 text-right px-2">
										<p class="list-item-heading mb-1"><span> Total CF Amount:</span> <span class="prefund" style="color: #D63333 !important"></span></p>
									</div>

								</div>
          
          <div class="row " style="width: 98%;margin: 0px auto;margin-top: 10px;">
              <div class=" col-sm-6 " ></div><div class=" col-sm-4 " ></div>
                <div class=" col-sm-2 " >
                    <div class="form-group position-relative error-l-50 floating">
                      <input type="text" value=""  class="form-control" name="ccrefund" id="ccrefund"   placeholder=" " >
                     <label for="date">Refund Amount <span>*</span></label>
                    </div>
		</div>
             
          </div>
           <span style=";font-size: 17px;padding: 10px;float:left;color: #364159">Payment Details - New Course</span>
          <?php
           $this->table->clear();
         $tmpl1 = array('table_open' => '<table class="sortable disabled" id="addpaymenttable1" style="width:98% !important;">');                 
         $this->table->set_template($tmpl1);
         $this->table->set_heading('S.NO', 'DESCRIPTION','AMOUNT');
         echo $this->table->generate();
          
          ?>
          
        
	  <div class="modal-footer">
		<div class="form-group col-sm-6"> 
                <button type="button" class="btn btn-primary paycancel float-left" data-dismiss="modal">Cancel</button>
            </div> 
                <div class="form-group col-sm-6"> 
                <button type="button" class="btn btn-primary paysave float-right" >Save</button>
                 </div> 
	  </div>
	</div>
  </div>
  </div>  
  
  <?php } ?>

<?php if(isset($roleaccess['Course Change View'][0]) && $roleaccess['Course Change View'][0]=== 'y') { ?>
		
<button type="button" class="btn btn-outline-primary d-none centerconfirm" data-toggle="modal" data-backdrop="static" data-target="#centerModal">Center Change</button>  
<!-- Modal -->


<div class="modal fade" id="centerModal" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog modal-m" role="document">
	<div class="modal-content">
            <div class="modal-header" style="background-color: #6884CC;height: 50px;width: auto;padding: 10px">
	  
		<h5 class="modal-title" id="exampleModalLabel">
		
			<p class="headtitle">Center Change</p>
		</h5>
	 </div>
            <div class="row" style="width: 98%;margin: 0px auto;margin-top: 25px;">
                
               <div class="col-12 col-sm-8">
                    <div class="form-group position-relative error-l-50 floating">
                        <select class="form-control " id="newcenter" name="newcenter"  required  >
                     <option value=""></option>
                    </select>
                <label>Center<span>*</span></label>
                    </div>
		</div>
                
                
            </div>

	  <div class="modal-footer">
		<div class="form-group col-sm-6"> 
                <button type="button" class="btn btn-primary cencancel float-left" data-dismiss="modal">Cancel</button>
            </div> 
                <div class="form-group col-sm-6"> 
                <button type="button" class="btn btn-primary censave float-right" >Save</button>
                 </div> 
	  </div>
	</div>
  </div>
  </div>  
  
  <?php } ?>

<div id="changeProfilePhotoModal" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
				   <h5 class="modal-title" id="changeProfilePhotoModal">Profile Photo</h5>
				   <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				</div>
				<div class="modal-body">
					<form id="cropImage" method="post" enctype="multipart/form-data" action="#">
						
						<div class="row">
						<div class="col-md-12">
						  <div class="form-group position-relative error-l-50 floating">

						<div id="drop-zone">
							<div class="dropzone-wrapper">
							  <div class="dropzone-desc" id="clickHere">
								<i class="icon-upload mb-2"></i>
								<p class="list-item-heading text-center mb-1">Upload Image</p>
								  <p class="text-muted text-center mb-2">Upload passport photo in jpeg, jpg or png format below 300 KB.</p>
							  </div>
							  <input type="file" name="profileImage" id="profileImage" class="dropzone">
							</div>

							  </div>
						  </div>
						</div>
                                                     <div class="col-md-12">
                                                     <div class="col-md-12 text-center mb-2">
                                                         <span>OR</span>
				                     </div>
                                                    </div>
                                                    <div class="col-md-12">
                                                     <div class="col-md-12 text-center">
                                                         <button type="button" class="btn btn-primary camphoto">Cam Photo</button>
				                     </div>
                                                    </div>
                                               </div>
					
						<input type="hidden" name="studentid" id="studentid" value="<?php echo $sid; ?>" />
						<input type="hidden" name="hdn-x1-axis" id="hdn-x1-axis" value="" />
						<input type="hidden" name="hdn-y1-axis" id="hdn-y1-axis" value="" />
						<input type="hidden" name="hdn-x2-axis" value="" id="hdn-x2-axis" />
						<input type="hidden" name="hdn-y2-axis" value="" id="hdn-y2-axis" />
						<input type="hidden" name="hdn-thumb-width" id="hdn-thumb-width" value="" />
						<input type="hidden" name="hdn-thumb-height" id="hdn-thumb-height" value="" />
						<input type="hidden" name="action" value="" id="action" />
						<input type="hidden" name="imageName" value="" id="imageName" />						
						<div id='previewProfilePhoto' class="text-center"></div>
						<div id="thumbs" style="padding:5px; width:600px"></div>
                                                 <input type="hidden" name="image" class="snapshot-tag">
						
					</form>
		                                   
					<p class="alert"></p>
					
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-outline-primary modalclose" data-dismiss="modal">Close</button>
					<button type="button" id="savePic" class="btn btn-primary">Save</button>
					<!--<button type="button" id="savePhoto" class="btn btn-primary">Crop & Save</button>-->
				</div>
								
			</div>
		</div>
	</div>
  
<script src="<?php echo base_url();?>js/scripts.js?v=1.9"></script>
<script src="<?php echo base_url();?>js/pala.script.js?v=1.96"></script>

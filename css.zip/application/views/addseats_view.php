 <link href="<?php  echo base_url(); ?>css/jquery-ui.min.css?v=1.4" rel="stylesheet" type="text/css" />
 <script src="<?php  echo base_url(); ?>js/jquery-ui.min.js?v=1.3" type="text/javascript"></script>

 <style type="text/css">
     
     .ui-selectmenu-button.ui-button{ width: 97%; padding:13px;}
     #duration-button,#modeofexam-button,#examtimefreq-button,#subcriteria-button,#rule-button,#maincriteria-button,#stream-button,#coursetype-button,#accounthead-button{border: 1px solid #D7DFF0;background: #fff;font-size: 14px;color:#536485}
     #centers_chosen  {border: 1px solid #D7DFF0;background: #fff;padding: 8px 0px;}
     #districts_chosen  {border: 1px solid #D7DFF0;background: #fff;padding: 8px 0px;}
     #courses_chosen  {border: 1px solid #D7DFF0;background: #fff;padding: 8px 0px;}
     .chosen-container-multi .chosen-choices {border: 0px;background: none}
     .maincontent ul li.search-choice { height:auto; }
     .maincontent ul li.search-choice a{ height:auto; font-size: 14px;color:#536485}
     .chosen-container-multi .chosen-choices li.search-choice { background: #6884CC;border-radius: 5px;}
     .chosen-container-multi .chosen-choices li.search-choice {color: #fff;}
     .response p { float: right;font-size:12px;color:#eb345e;}
 </style>

	<div class="wrap dynamic-width" style="float: left;position: relative;min-width: 800px">
     <div style="margin-top: 10px; width: 99%; height: 50px; text-align: right;">
         <span style="font-weight: bold;font-size: 20px;padding: 10px;float:left;color: #364159">Add New Seat</span>
     </div>         
            <div id="course-container" class="add-course">
<?php echo form_open('addseats/seatSubmit', array('id' => 'addSeatForm')) ?>
                <div class="row-element">
                    <span class="title">School Name</span>
                    <span class="content">
                        <select id="duration" name = "sname" class="duration" style="font-size: 13px;float:left">
                            <option value="" >Select School</option>
                            <?php echo $schools;?>
                        </select>
                    </span>
                </div>
                  <div class="row-element">
                    <span class="title">Subjects</span>
                    <span class="content">
                        <select id="duration" name = "subjects" class="duration" style="font-size: 13px;float:left">
                            <option value="" >Select Subjects</option>
                            <option>PCMB</option>
                            <option>ISC</option>
                            <option>State</option>
                        </select>                        
                    </span>
                </div>
                  <div class="row-element">
                    <span class="title">Syallabus</span>
                    <span class="content">
                        <select id="duration" name = "syallabus" class="duration" style="font-size: 13px;float:left">
                            <option value="" >Select Syallabus</option>
                            <option>CBSE</option>
                            <option>ISC</option>
                            <option>French</option>
                        </select>                        
                    </span>
                </div>
                <div class="row-element" id="stream">
                    <span class="title">Stream</span>                    
                    <span class="content">
                        <label style="text-align: left;min-width: 150px;color:#536485;background: none;border: 0px;width: auto;height: auto;float:left;font-size: 14px;font-weight: normal"><input type="radio" value="AIIMS" name = "stream"   class="" style="margin: 5px;">AIIMS</label>
                        <label style="text-align: left;min-width: 150px;color:#536485;background: none;border: 0px;width: auto;height: auto;float:left;font-size: 14px;font-weight: normal"><input type="radio" value="IIT" name = "stream"  class="" style="margin: 5px;">IIT</label>
                          </span>
                </div>
                 <div class="row-element" id="type">
                    <span class="title">Type</span>                    
                    <span class="content">
                        <label style="text-align: left;min-width: 150px;color:#536485;background: none;border: 0px;width: auto;height: auto;float:left;font-size: 14px;font-weight: normal"><input type="radio" value="Hybrid" name = "type"   class="" style="margin: 5px;">Hybrid</label>
                        <label style="text-align: left;min-width: 150px;color:#536485;background: none;border: 0px;width: auto;height: auto;float:left;font-size: 14px;font-weight: normal"><input type="radio" value="Regular" name = "type"  class="" style="margin: 5px;">Regular</label>
                          </span>
                </div>
                <div class="row-element">
                    <span class="title" >Total Seats</span>
                    <span class="content">
                        <input type="text" id = "totalseats" name = "totalseats" class="totalseats" placeholder="Total Seats">   
                        <input type="hidden" value="<?php echo $yearid;?>" name = "yearid" class="totalseats" >   
                    </span>
                </div>
              
            <?php echo form_close() ?>
                
            </div>
     <div style="margin-top: 0px; width: 98%; height: 70px; text-align: right;">
         <span  style="margin: 0px auto; float:right;margin-top: 18px;padding: 10px; color: #fff; background: #4f6fc4 none repeat scroll 0% 0%; border-radius:5px;cursor: pointer" class="btn savebtn" href="#">Save</span>
         <a style="margin: 0px auto; float:right;margin-top: 18px;margin-right:18px;padding: 9px 10px; color: #0332AA; background: linear-gradient(0deg, #FFFFFF, #FFFFFF), #C4C4C4;border: 1px solid #0332AA; border-radius:5px" class="btn" href="<?php echo base_url(); ?>schools">Back</a>
         <span class="response" style="margin: 0px auto; float:right;width: 80%; height: 30px;margin-top:20px"></span>
     </div>         
        
        </div>
    
    
    
<script type="text/javascript">
$(document).ready(function() {
    
    $(".duration").selectmenu();
         
          
      $(".savebtn").click(function(){
         
               if($(".response").hasClass('progress')) { return;}
               $(".response").html('').text('Progressing...');
                $(".response").addClass('progress');


                var addSeatForm = $("#addSeatForm");

                    $.ajax({
                        url: addSeatForm.attr('action'),
                        type: 'post',
                        data: addSeatForm.serialize(),
                        success: function(o){
                            
                            var response = $.parseJSON(o);
                            $(".response").html('');
                            if(response.status === 'success') {
                                $(".response").css("color","rgb(25, 71, 15)");
                               $(".response").text(response.message);
                                $(location).prop('href', 'allocation?id='+'<?php echo $yearid;?>');
                            } else {
                                
                               $(".response").append(response.message); 
                               $(".response").removeClass('progress');
                           
                            }

                        }
                    });
                   
                              
            });
	
	
	$(".add-course").find("input").each(function(){
            
            $(this).keyup(function(event){
                if(event.keyCode == 13){
                    var ty = $(this).next();
                    event.preventDefault();
                    $('input')[$('input').index(this)+1].focus();
                    $('input')[$('input').index(this)+1].select();
                }
            });

            $(this).click(function(){ $(".errnotify").html("&nbsp;");});
            

        });
       

	
});
</script>
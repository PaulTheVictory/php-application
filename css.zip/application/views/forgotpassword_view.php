
<script src="<?php echo base_url();?>js/jquery.validate/jquery.validate.min.js"></script>
<script src="<?php echo base_url();?>js/jquery.validate/additional-methods.min.js"></script>

<script type="text/javascript">
$(document).ready(function(){	
	
	$('#forgotForm').submit( function(e){     

		e.preventDefault();
		var $form = $(this);

	    // check if the input is valid
		if(! $form.valid()) return false;

		$(".step1 .alert,.step2 .alert").removeClass('alert-danger').text("");
		
		if($(".forgotbtn").hasClass('process')){
			
			$(".step1 .alert").addClass('alert-danger').text("Please wait while processing...");
			
		}else{
		
			$(".forgotbtn").addClass('process');
			$(".step1 .alert").removeClass('alert-danger').addClass('alert-success').text("Processing...");
			
           $.ajax({
                type: 'POST',
                url: 'forgotpassword/sendOTP',
                data: new FormData(this),
			    contentType: false,
    			processData: false,
                success: function(response) {
                   
					var obj1 = $.parseJSON(response);
					
					if(obj1[0]=="success"){
												
						$(".alert").removeClass('alert-danger');
						$(".step1 .alert").addClass('alert-success').text("OTP send to your mobile number and email.");
						setTimeout(function(){
							$(".step1 .alert").removeClass('alert-success').text("");
							$(".step1").fadeOut().addClass('d-none');
							$(".step2").fadeIn().removeClass('d-none');
							$("#usermobile").val(obj1[1]);
							$(".step2 h6").html("Please enter the verification code sent to your mobile number "+Masknumber(obj1[1])+".");
						},3000);
						
					}else if(obj1[0]=="error"){
						$(".alert").addClass('alert-danger').text(obj1[1]);
						$(".forgotbtn").removeClass('process');
					}else if(obj1[0]=="failed"){
						$(".alert").addClass('alert-danger').text("OTP not send");
						$(".forgotbtn").removeClass('process');
					}else if(obj1[0]=="notfound"){
						$(".alert").addClass('alert-danger').text("Mobile number not found");
						$(".forgotbtn").removeClass('process');
					}else if(obj1[0]==""){
						$(".alert").addClass('alert-danger').text("Please try again.");
						$(".forgotbtn").removeClass('process');
					}
					
                }

            });
			
		}
		
    });
	
	$('#verifyForm').submit( function(e){     

            e.preventDefault();
            var $form = $(this);

          // check if the input is valid
            if(! $form.valid()) return false;
		
			var password = $("#supassword").val();
			var confirmpassword = $("#suconfpassword").val();

			if(password!=confirmpassword){$(".step2 .alert").addClass('alert-danger').text("Mismatch password"); return false;}
		
			$(".step1 .alert,.step2 .alert").removeClass('alert-danger').text("");
		
			$(".step2 .alert").addClass('alert-success').text("Processing...");

           $.ajax({
                type: 'POST',
                url: 'forgotpassword/forgotverifyOTP',
                data: new FormData(this),
			    contentType: false,
    			processData: false,
                success: function(response) {
                   
					var obj1 = $.parseJSON(response);
					
					if(obj1[0]=="success"){
						
						$(".step2 .alert").removeClass('alert-danger');
						$(".step2 .alert").addClass('alert-success').text("Password reset success");
						setTimeout(function(){
							$(".step2 .alert").removeClass('alert-success').text("");
							location.assign('login');
						},3000);
						
					}else if(obj1[0]=="error"){
						$(".step2 .alert").removeClass('alert-success').addClass('alert-danger').text(obj1[1]);
					}else if(obj1[0]=="failed" || obj1[0]=="notfound"){
						$(".step2 .alert").removeClass('alert-success').addClass('alert-danger').text("Verification failed");
					}else if(obj1[0]==""){
						$(".step2 .alert").removeClass('alert-success').addClass('alert-danger').text("Please try again later");
					}
					
                }

            });
        });
	
	
	$('.resendcode').click( function(e){     
       
			$(".step1 .alert,.step2 .alert").removeClass('alert-danger').text("");
		
			$(".step2 .alert").addClass('alert-success').text("Processing...");
		
			var usermobile = $("#usermobile").val();

           $.ajax({
                type: 'POST',
                url: 'forgotpassword/forgotResendOTP',
                data: {'usermobile':usermobile},
                success: function(response) {
                   
					var obj1 = $.parseJSON(response);
					
					if(obj1[0]=="success"){
						
						$(".step2 .alert").removeClass('alert-danger');
						$(".step2 .alert").addClass('alert-success').text("OTP send to your mobile number " +Masknumber(obj1[1])+ " and email.");
						setTimeout(function(){
							$(".step2 .alert").removeClass('alert-success').text("");
						},2000);
						
					}else if(obj1['type']=="error"){
						$(".step2 .alert").removeClass('alert-success').addClass('alert-danger').text(obj1[1]);
					}else if(obj1[0]=="notfound"){
						$(".step2 .alert").addClass('alert-danger').text("Mobile number not found");
					}else if(obj1[0]=="fail"){
						$(".step2 .alert").removeClass('alert-success').addClass('alert-danger').text("Resend failed");
					}else if(obj1[0]==""){
						$(".step2 .alert").removeClass('alert-success').addClass('alert-danger').text("Please try again later");
					}
					
                }

            });
        });
	
	
	$(".fpcode").change(function(){
		
		var fpcode = $(this).val();
		
		if(fpcode!="91"){
			$("#fpmobile").attr('minlength',3).attr('maxlength',20);
		}else{
			$("#fpmobile").attr('minlength',10).attr('maxlength',10);
		}
		
	});
	
});
	
function Masknumber(number, character = "*"){
  number = number.replace(/[^0-9]+/g, ''); /*ensureOnlyNumbers*/
  var l = number.length;
  return number.substring(0,2) + character.repeat(l-4) + number.substring(l-2,l);
}

function Maskmail(email, character = "*"){
	
	var ename = email.split('@');
	var emailname = ename[0];
    var l = emailname.length;
	
	var maskdata = emailname.substring(0,2) + character.repeat(l-4) + emailname.substring(l-2,l);
	
  return maskdata+'@'+ename[1];
	
}
	
</script>
<main>
  <div class="container">
    <div class="row">
      <div class="col-12 mx-auto my-auto p-xs-0">
        <div class="card auth-card signup my-5">
         
          	<div class="position-relative image-side"></div>
      
             <div class="form-side sign-form step1">
           
            <h3 class="mb-1">Forgot Password</h3>
            <h6 class="mb-4">Enter your registered mobile number</h6>
            
            <form id="forgotForm" class="tooltip-right-bottom" novalidate>
              
             <div class="form-row mt-3">
              
				  <div class="form-group col-md-3 position-relative error-l-50">
					<select class="form-control fpcode" name="fpcode" required >
					  <option value="91">+91</option><option value="973">+973</option><option value="20">+20</option><option value="98">+98</option><option value="964">+964</option><option value="972">+972</option><option value="962">+962</option><option value="965">+965</option><option value="961">+961</option><option value="968">+968</option><option value="970">+970</option><option value="974">+974</option><option value="966">+966</option><option value="90">+90</option><option value="971">+971</option><option value="967">+967</option><option value="93">+93</option><option value="374">+374</option><option value="994">+994</option><option value="76">+76</option><option value="996">+996</option><option value="92">+92</option><option value="963">+963</option><option value="992">+992</option><option value="993">+993</option><option value="998">+998</option><option value="357">+357</option><option value="253">+253</option><option value="291">+291</option><option value="995">+995</option><option value="352">+352</option><option value="249">+249</option>
					</select>
				  </div>
             
				  <div class="form-group col-md-9 position-relative error-l-50 floating">
					<input type="number" class="form-control" id="fpmobile" name="fpmobile" minlength="10" maxlength="10" placeholder=" " required="">
					  <label>Enter Mobile Number <span>*</span></label>
			  	  </div>
			  
				</div>
                            
              <button class="btn btn-primary forgotbtn" type="submit">Submit</button>
              
            </form>
            
            <p class="alert"></p>
            
          </div>
          
          <div class="form-side verify-form step2 d-none">
           
            <h3 class="mb-1">Verification Code</h3>
            <h6 class="mb-4"> </h6>
            
            <form id="verifyForm" class="tooltip-right-bottom" novalidate>
                       
            <div class="form-group position-relative error-l-50 floating">
				 <input class="form-control" id="verifyotp" name="verifyotp" placeholder=" " minlength="4" maxlength="4" required >
            	<label>Verification Code <span>*</span></label>
             </div>
             
              <div class="form-group position-relative error-l-50 floating">
				 <input class="form-control" type="password" id="supassword" name="supassword" placeholder=" " required > 
            	<label>New Password <span>*</span></label>
             </div>
             
              <div class="form-group position-relative error-l-50 mb-4 floating">
				 <input class="form-control" type="password" id="suconfpassword" name="suconfpassword" placeholder=" " required> 
            	<label>Confirm New Password <span>*</span></label>
             </div>
                               
               <input type="hidden" name="usermobile" id="usermobile" />
                                                                               
              <button class="btn btn-primary verifybtn" type="submit">Submit</button>
              
            </form>
            
			  <p class="mb-3 text-muted text-center">Didn’t receive code? <a href="javascript:void(0);" class="resendcode">Resend code</a></p>
            
            <p class="alert"></p>
            
          </div>
         
        </div>
      </div>
    </div>
  </div>
</main>

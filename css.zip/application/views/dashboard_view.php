<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/dataTables.css?v=1.5" />
<script src="<?php echo base_url(); ?>js/jquery.dataTables.js?v=1.0" type="text/javascript"></script>
<style type="text/css">

</style>


<div class="wrap dynamic-width" style="float: left;position: relative">
    
    <div style="margin-top: 10px; width: 100%; height: 50px; text-align: right;">
             <span style="font-weight: bold;font-size: 20px;padding: 10px;float:left;color: #364159">Admin Dashbaord List</span>
             <a style="font-size: 14px;padding: 10px;  color: #fff; margin: 0px auto; position: relative; top: 5px;border-radius:5px;background: linear-gradient(180deg, #4F70C4 0%, #1C47B3 100%);" href="<?php echo base_url(); ?>addcourse"><span style="position: relative;top:4px"><img  src="<?php echo $this->config->item('web_url') ?>images/addcourse.png" alt="Navigation" /></span><span style="margin-left:5px">Add Course</span></a>
         </div>         
        
        
        </div>
    
 
    


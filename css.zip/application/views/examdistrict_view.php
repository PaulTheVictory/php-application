<script src="<?php echo base_url();?>js/bootstrap.bundle.min.js"></script>
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/dataTables.css?v=1.6" />
<script src="<?php echo base_url(); ?>js/jquery.dataTables.js?v=1.0" type="text/javascript"></script>
<link rel="stylesheet" href="<?php echo base_url();?>css/boot/bootstrap.min.css">
<link rel="stylesheet" href="<?php echo base_url();?>css/boot/main.css?v=1">

<style type="text/css">


.dataTables_wrapper input[type="text"] {
    padding: 0;
}
.dataTables_wrapper select {
    padding: 0;
}

.sortable thead tr  {
    background: #E6EBF7;

/* g8 */
border: 1px solid #D7DFF0;
box-sizing: border-box;
border-radius: 10px 10px 0px 0px;
 

}
.sortable tr th {
    border-right: 0px;
    padding: 15px 0;font-size: 13px;
      color: #6F83AA;
   cursor: pointer;
   text-align: center;

}

.sortable tr td:nth-child(1) {
  width:100px;
}

.sortable tr td:nth-child(2) {
  background: none;
   text-align: left;
}

.sortable tr th:nth-child(2) {
  background: #E6EBF7 url('<?php echo base_url(); ?>/images/datatable/sort_both.png') no-repeat center left;
  background-position-x: 110px;
  background-position-y: 16px;
   text-align: left;
}

.sortable tr td p { margin: 5px; }
.sortable tr td {
    border-right: 0px;
    padding: 0px;
    text-align: center;font-size: 13px;
    min-width:80px;vertical-align: middle;color:#000;
}
.sortable tr td a {
    color: #364159;
}

#profile-right h2 {
    margin: 0px 0px 10px 0px;
}

.templatetablee_length { width: auto !important; }
#templatetable_filter input { padding-top:4px;background: #fff url('<?php echo base_url(); ?>/images/search.png') no-repeat center left;background-position-x: 10px;border: 1px solid #D7DFF0; line-height: 32px;margin-left: 10px;width:260px;border-radius: 5px;text-indent: 30px;font-size: 13px;}
.sortable tr td a:hover { text-decoration: underline; }
</style>
<script type="text/javascript">
$(document).ready(function(){	
		
                $(".adddistrict").click(function(){
                    $(".eresponse").text("");
                    $(".courseconfirm").trigger('click'); 
                });
                
	
          var columnData = [
              { "data": "created_at" },            
                    { "data": "name" },
                    { "data": "centers" }, 
                    { "data": "ide" }
                    
                  ];
        // columnData.push( {data: "id","visible":true} );
         //columnData.push( {data: "item_name_search","visible":false} );
         
       
        var oTable = $('#templatetable').dataTable({
                    "bProcessing": true,
                    "bServerSide": true,
                    "sPaginationType": "full_numbers",
                    "ajax": {
                    "url": 'examdistrict/GetDistricts',
                    "type": "POST",
                   
                    "data":{ "type": ""}
                     }, 
                     "oLanguage": {
                        "sProcessing": "<img src='<?php echo base_url(); ?>images/loader.gif'>"
                    },
                    'iDisplayLength': 20,
                    "columns": columnData,
                    "order": [[ 0, "created_at" ]],
                    "fnDrawCallback": function( oSettings ) {
                        var count = 1;
                        
                        $("#templatetable").find(".edit").each(function(){
                             
                            $(this).click(function(){ 
                                    $(".editresponse").text("");
                                    var ide = $(this).attr("data-id");
                                    var dname =  $(this).closest("tr").find(".name").text();
                                    $("#eide").val(ide);
                                    $("#edname").val(dname);
                                    $(".courseconfirm1").trigger('click'); 
                              });

                          });
        
                         $("#templatetable").find(".del").each(function(){
                             
                            $(this).closest("tr").find(".sno").text(count);
                            count++;
                    

                            $(this).click(function(){ 

                              if(confirm("Are you sure to delete this item ?")) {
                                    var ide = $(this).attr("data-id");
                                    $.get('examdistrict/DelDistrict',{
                                                               'ide':ide

                                                    }, function(o) { 
                                                            var obj1 = $.parseJSON(o);
                                                    if (obj1[0] === 'success') {
                                                        oTable.fnDraw(); 
                                                    } else if (obj1[0] === 'fail') {
                                                        alert("Error!!! please try again");
                                                }
                                    });
                                }

                              });
                        

                          });
                          
                          
                                          
                    }
         }); 
         
         
                 $(".addsave").click(function(){
               
                $(".eresponse").html('').text('Progressing...');
                
               
                var locationForm = $("#addDistrictForm");

                    $.ajax({
                        url: locationForm.attr('action'),
                        type: 'post',
                        data: locationForm.serialize(),
                        success: function(o){
                            
                            var response = $.parseJSON(o);
                            $(".response").html('');
                            if(response.status === 'success') {
                                
                                $(".eresponse").css("color","rgb(25, 71, 15)");
                               $(".eresponse").text(response.message);
                               oTable.fnDraw();
                               $('#courseModal').modal('hide');
                               
                            } else {
                                
                               $(".eresponse").append(response.message); 
                           
                            }

                        }
                    });
                    
            });
            
              $(".editsave").click(function(){
               
                $(".editresponse").html('').text('Progressing...');
     
               $(".editresponse").text("");
                var locationForm = $("#editDistrictForm");

                    $.ajax({
                        url: locationForm.attr('action'),
                        type: 'post',
                        data: locationForm.serialize(),
                        success: function(o){
                            
                            var response = $.parseJSON(o);
                            $(".response").html('');
                            if(response.status === 'success') {
                                
                                $(".editresponse").css("color","rgb(25, 71, 15)");
                               $(".editresponse").text(response.message);
                               oTable.fnDraw();
                               $('#courseModal1').modal('hide');
                               
                            } else {
                                
                               $(".editresponse").append(response.message); 
                           
                            }

                        }
                    });
                    
            });
  
	
});
</script>


<div class="wrap dynamic-width" style="float: left;position: relative">
    
    <div style="margin-top: 10px; width: 100%; height: 50px; text-align: right;">
             <span style="font-weight: bold;font-size: 20px;padding: 10px;float:left;color: #364159">Exam District List</span>
          <?php if(isset($roleaccess['Exam District Center'][0]) && $roleaccess['Exam District Center'][0]=="y"){ ?> 
              <a class="adddistrict" style="text-decoration:none;font-size: 14px;padding: 10px;  color: #fff; margin: 0px auto; position: relative; top: 5px;border-radius:5px;background: linear-gradient(180deg, #4F70C4 0%, #1C47B3 100%);" href="javascript:void(0)"><span style="position: relative;top:0px"><img  src="<?php echo $this->config->item('web_url') ?>images/addcourse.png" alt="Navigation" /></span><span style="margin-left:5px">Add District</span></a>
        
         	<?php } ?> 
         
         </div>         
         <?php echo $this->table->generate();  ?>             
         
        
        
        </div>
    
  <style>

	.courseredirect{background: #3CAF92 !important;display: block;margin: auto;border: 1px solid #209679;}
	h5.modal-title p.headtitle{display: inline-block;width: 100%;text-align: center;font-weight: bold;font-size:17px;color: #fff;}
	h5.modal-title p.text-muted{display: inline-block;width: 100%;text-align: center;font-weight: 600;font-size: 14px;line-height: 36px;color: #181E29;line-height: 20px;}
	.modal-title img{display: block;margin: 1em auto}
        #paydoneModal.modal .modal-header,#payfailModal.modal .modal-header{padding: 10px 20px !important;border: none}	
		#paydoneModal.modal .modal-body,#payfailModal.modal .modal-body{padding:0 1.75rem 1.75rem}
		.modal-body p{text-align: left !important}
		.modal-backdrop.show {opacity: .5 !important;}
			 
			  .hide{display: none}
			 
	</style>
    

	<?php if(isset($roleaccess['Exam District Center'][0]) && $roleaccess['Exam District Center'][0]=="y"){ ?> 
	
<button type="button" class="btn btn-outline-primary d-none courseconfirm" data-toggle="modal" data-backdrop="static" data-target="#courseModal">Confirm Submission</button>  
<!-- Modal -->


<div class="modal fade" id="courseModal" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog modal-xl" role="document">
	<div class="modal-content">
            <div class="modal-header" style="background-color: #6884CC;height: 50px;width: auto;padding: 10px">
	  
		<h5 class="modal-title w-100" id="exampleModalLabel">
		
			<div class="row">
			
				<div class="col-4">
					<p class="headtitle text-left">Add District</p>
				</div>
				
			</div>
			
		</h5>
	 </div><?php echo form_open('examdistrict/AddDistrict', array('id' => 'addDistrictForm')) ?>
            <div class="row" style="width: 98%;margin: 0px auto;margin-top: 25px;">
                <div class="col-12 col-sm-6" >
                    <div class="form-group position-relative error-l-50 floating">
                      <input placeholder="District Name" type="text" name = "dname" id="dname" class="form-control">
                       <label for="ciyname">District Name<span>*</span></label>
                    </div>
                    
		</div>
               
          
        </div> <?php echo form_close() ?>
	  <div class="modal-footer">
                                <div class="form-group"> <span class="eresponse"></span></div>
	 			 <div class="form-group"> 
	 			 
					<button type="button" class="btn btn-primary paycancel float-left" data-dismiss="modal">Cancel</button>
					
				</div> 
				<div class="form-group">
				
					<button type="button" class="btn btn-primary previewbtn float-right addsave" >Save</button>
                
                </div> 
             
        
	  </div>
	</div>
  </div>
  </div> 
    
    <?php } ?> 

	<?php if(isset($roleaccess['uedit']) && $roleaccess['uedit']=="y"){ ?> 
	
<button type="button" class="btn btn-outline-primary d-none courseconfirm1" data-toggle="modal" data-backdrop="static" data-target="#courseModal1">Confirm Submission</button>  
<!-- Modal -->


<div class="modal fade" id="courseModal1" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog modal-xl" role="document">
	<div class="modal-content">
            <div class="modal-header" style="background-color: #6884CC;height: 50px;width: auto;padding: 10px">
	  
		<h5 class="modal-title w-100" id="exampleModalLabel">
		
			<div class="row">
			
				<div class="col-4">
					<p class="headtitle text-left">Edit District</p>
				</div>
				
			</div>
			
		</h5>
	 </div><?php echo form_open('examdistrict/AddDistrict', array('id' => 'editDistrictForm')) ?>
            <div class="row" style="width: 98%;margin: 0px auto;margin-top: 25px;">
                <div class="col-12 col-sm-6" >
                    <div class="form-group position-relative error-l-50 floating">
                      <input placeholder="District Name" type="text" name = "dname" id="edname" class="form-control">
                       <input type="hidden" class="" name="eide" id="eide" >
                       <label for="ciyname">District Name<span>*</span></label>
                    </div>
                    
		</div>
               
          
        </div> <?php echo form_close() ?>
	  <div class="modal-footer">
                                <div class="form-group"> <span class="editresponse"></span></div>
	 			 <div class="form-group"> 
	 			 
					<button type="button" class="btn btn-primary paycancel float-left" data-dismiss="modal">Cancel</button>
					
				</div> 
				<div class="form-group">
				
					<button type="button" class="btn btn-primary previewbtn float-right editsave" >Save</button>
                
                </div> 
             
        
	  </div>
	</div>
  </div>
  </div> 
    
    <?php } ?> 
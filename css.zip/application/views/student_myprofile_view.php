<script src="<?php echo base_url();?>js/vendor/jquery.smartWizard.min.js"></script>
<link rel="stylesheet" href="<?php echo base_url();?>css/vendor/dataTables.bootstrap4.min.css">
<link rel="stylesheet" href="<?php echo base_url();?>css/vendor/datatables.responsive.bootstrap4.min.css">
<script src="<?php echo base_url();?>js/vendor/datatables.min.js"></script>
<script src="<?php echo base_url();?>js/vendor/jquery.validate/jquery.validate.min.js"></script>
<script src="<?php echo base_url();?>js/vendor/jquery.validate/additional-methods.min.js"></script>
<link rel="stylesheet" href="<?php echo base_url();?>css/boot/vendor/bootstrap-datepicker3.min.css">
<script src="<?php echo base_url();?>js/vendor/bootstrap-datepicker.js"></script>
<!--<link rel="stylesheet" href="<?php echo base_url();?>css/boot/vendor/cropper.min.css">
<script src="<?php echo base_url();?>js/vendor/cropper.min.js"></script>-->

<link rel="stylesheet" href="<?php echo base_url();?>css/boot/vendor/baguetteBox.min.css">
<script src="<?php echo base_url();?>js/vendor/baguetteBox.min.js"></script>

<script type="text/javascript">
	
	
	var tabcount = 0;
	var ppercent = 20;
	var totaltab = 0;
	
	var profilecomplete = <?php if($stuprofile['profilepercent']!=0){ echo $stuprofile['profilepercent'];}else{echo 0;}?>;
	
	var profilepicpercent = <?php if($stuprofile['profilepic']!="" && $stuprofile['profilepic']!="0"){ echo 20;}else{echo 0;}?>;
	
	var checkprofilepic = <?php if($stuprofile['profilepic']!="" && $stuprofile['profilepic']!="0"){ echo 1;}else{echo 0;}?>;
		
	
	
		
$(document).ready(function(){
	
	
	$("input.mpdob").datepicker({
		format: 'dd-mm-yyyy',
		endDate: '+0d',
		autoclose: !0,
		templates: {
			leftArrow: '<i class="simple-icon-arrow-left"></i>',
			rightArrow: '<i class="simple-icon-arrow-right"></i>'
		}

	});
	
	// ID Crad Preview
	
	$(".idcardpreviewbtn").click(function(e){
				
		var profilepercent = "<?php echo $stuprofile['profilepercent'];?>";
		
		if(profilepercent!="100"){alert("Complete profile");return false;}
		
		$.ajax({
		type: 'GET',
		url: 'downloadidcard',
		data: {"ptype":"preview"},
		success: function(response) {

				$('#IDcardpreivewModal').modal({show:true});
				$(".idcardpreview").html(response);
			
			}

		});
		
		
	});
	
	
	function Nextbtn(tabcount) {//console.log("n"+tabcount);
		
		totaltab = parseInt($(".sw-main.sw-theme-dots>ul.step-anchor>li").length);
		//if(totaltab>4){ppercent = 20;}
		
										
		if($(".sw-main.sw-theme-dots>ul.step-anchor>li").hasClass('active')){
			$(".sw-main.sw-theme-dots>ul.step-anchor>li").eq(tabcount).removeClass('active').addClass('done');
		}
								
		var stepcount = tabcount + 1;						
		
		
		//tabcount++;	
				
		//if(tabcount>totaltab) tabcount = totaltab;
		
		//if(tabcount>0) $(".prev-btn").removeClass('d-none');
		//var prevtab = totaltab - 1;
		//if(tabcount>prevtab){$(".payment-btn").removeClass('d-none');$(".next-btn").addClass('d-none');}
		
		$(".sw-main.sw-theme-dots>ul.step-anchor>li").eq(stepcount).removeClass('done').addClass('active');
		
		var percentnum = ppercent * stepcount + profilepicpercent;
		
		if(percentnum>100) percentnum = 100;
		
		$(".progress-bar").css('width',percentnum+"%");
		$(".progressnum").html(percentnum+"%");
		
    }
	
	
	function Prevbtn(tabcount) {//console.log("p"+tabcount);

		totaltab = parseInt($(".sw-main.sw-theme-dots>ul.step-anchor>li").length);
		//if(totaltab>4){ppercent = 20;}
		
		if($(".sw-main.sw-theme-dots>ul.step-anchor>li").hasClass('active')){
			$(".sw-main.sw-theme-dots>ul.step-anchor>li").eq(tabcount).removeClass('active').addClass('done');
		}	
								
		var stepcount = tabcount - 1;						
		
		//tabcount--;
		
		//if(tabcount<0) tabcount =0;
		
		//if(tabcount<1 || tabcount<0) $(".prev-btn").addClass('d-none');
		//if(tabcount<totaltab){$(".payment-btn").addClass('d-none');$(".next-btn").removeClass('d-none');}
		
		$(".sw-main.sw-theme-dots>ul.step-anchor>li").eq(stepcount).removeClass('done').addClass('active');
     
		var percentnum = ppercent * stepcount + profilepicpercent;
		
		if(percentnum<0) percentnum = 0;
		
		$(".progress-bar").css('width',percentnum+"%");
		$(".progressnum").html(percentnum+"%");
		
		
    }
	
	
	$("#smartWizardCustomButtons").on("showStep", (function (e, t, a, n, o) {//console.log(a);
																			 		
		"first" === o ? (/*$("#smartWizardCustomButtons .prev-btn").addClass("disabled"), */$("#smartWizardCustomButtons .finish-btn,#smartWizardCustomButtons .payment-btn,#smartWizardCustomButtons .submit-btn").addClass("d-none"), $("#smartWizardCustomButtons .next-btn").removeClass("d-none")) : "final" === o ? ($("#smartWizardCustomButtons .next-btn").addClass("d-none"), $("#smartWizardCustomButtons .payment-btn,#smartWizardCustomButtons .submit-btn").addClass("d-none"), $("#smartWizardCustomButtons .prev-btn").removeClass("d-none"), $("#smartWizardCustomButtons .finish-btn").removeClass("d-none")) : ($("#smartWizardCustomButtons .finish-btn,#smartWizardCustomButtons .payment-btn,#smartWizardCustomButtons .submit-btn").addClass("d-none"), $("#smartWizardCustomButtons .next-btn").removeClass("d-none"), $("#smartWizardCustomButtons .prev-btn").removeClass("d-none"));
																			 
	}));
	
		var formstepid = [];
		var formstepno = 0;
	
	$("#smartWizardCustomButtons").on("leaveStep", (function (e, t, a, n) {
		
		
		 $('html,body').animate({
        	scrollTop: $(".formscrolltop").offset().top},
        'slow');
				
		if ("forward" === n) {
			var o = $("#form-step-" + a);
			if(a!=2 && Be(o)){
				Nextbtn(a);
				formstepno = a;
				return myprofileSubmit(a,formstepid,ppercent,totaltab);
			}
			if(a!=2) return Be(o); else return true;
		}
		
		if ("backward" === n) {
			Prevbtn(a);
		}
				
	}))/*, $("#smartWizardCustomButtons .prev-btn").on("click", (function () {
		return $("#smartWizardCustomButtons").smartWizard("prev"), !0
	})), $("#smartWizardCustomButtons .next-btn").on("click", (function () {
		return $("#smartWizardCustomButtons").smartWizard("next"), !0
	})), $("#smartWizardCustomButtons .finish-btn").on("click", (function (e) {
		return !Be($("#smartWizardCustomButtons #form-step-3")) || (console.log("Form Done"), !1)
	}));*/
	
	$("#smartWizardCustomButtons .finish-btn").on("click", (function (e) {
		var o = $("#form-step-4");
		if(Be(o))myprofileSubmit(4,formstepid,ppercent,totaltab);
	}));
	
	// Personal Details
	
function myprofileSubmit(formstep,formstepid,ppercent,totaltab){
			
			if(formstep!=2 && ! $("#form-step-"+formstep).valid()) return false;
	
			if(formstep==4){
				var accno = $(".mpaccountnumber").val();
				var reenteraccno = $(".mpreenteraccountnumber").val();
				
				if(accno!=reenteraccno){
					$(".alert").removeClass('alert-success').addClass('alert-danger').text("Account number mismatch");
					return false;
				}
				
			}
	
			if(!checkprofilepic){
				alert("Upload profile photo");
				return false;
			}
	
			$(".alert").removeClass('alert-success').removeClass('alert-danger').text("");
	
			if(formstep>0)formstepid.push("#form-step-"+formstep); else formstepid.push("#form-step-"+formstep);
	
			
			var formid = formstepid.join(',');//console.log(formstepid);
	
			var formData = new FormData();
	
			for(var i=0;i<formstepid.length;i++){
				var poData = $(formstepid[i]).serializeArray();//console.log(poData);
				for (var j=0; j<poData.length; j++){
    				formData.append(poData[j].name, poData[j].value);
				}
			}
	
			var profilepercent = ppercent * (formstep) + profilepicpercent;
			formData.append('profilepercent', profilepercent);
	
			var c=0;
            var file_data,file;
            $('input[type="file"]').each(function(){
                  file_data = $('input[type="file"]')[c].files; // get multiple files from input file
                  //console.log(file_data);
               for(var i = 0;i<file_data.length;i++){
                   formData.append('file[]', file_data[i]); // we can put more than 1 image file
               }
              c++;
           }); 
			
			
           $.ajax({
                type: 'POST',
                url: 'stumyprofile/myprofileSubmit',
                data: formData,
			    contentType: false,
    			processData: false,
                success: function(response) {
                   
					var obj1 = $.parseJSON(response);
										
					if(obj1['status']=="success" && formstep==4){
						
						//$(".alert").addClass('alert-success').text("Profile details updated");
						
						$('#profileupdateModal').modal({show:true});
						
						setTimeout(function(){
							$(".alert").removeClass('alert-success').text("");
							if(totaltab<6){location.assign('stumyprofile');}
						},3000);
						
					}else if(obj1['status']=="exists"){
						$(".alert").addClass('alert-danger').text("Already exists");
					}else if(obj1['status']=="empty"){
						$(".alert").addClass('alert-danger').text("Profile data not found");
					}else if(obj1['status']=="fail"){
						$(".alert").addClass('alert-danger').text("Submission failed");
					}else if(obj1['status']=="uempty"){
						$(".alert").addClass('alert-danger').text("Upload marksheets");
					}else if(obj1['status']=="ularge"){
						$(".alert").addClass('alert-danger').text("Each upload file must be less than 1MB");
					}else if(obj1['status']=="exfail"){
						$(".alert").addClass('alert-danger').text("Support extension JPG,JPEG,PNG,PDF only");
					}else if(obj1['status']==""){
						$(".alert").addClass('alert-danger').text("Please try again.");
					}
					
                }

            });
			
		}
			
	
	var dropZoneId = "drop-zone";
	var buttonId = "clickHere";
	var mouseOverClass = "mouse-over";
	var dropZone = $("#" + dropZoneId);
	var inputFile = dropZone.find("input");
	var finalFiles = {};
  

  inputFile.on('change', function(e) {
    finalFiles = {};
    $('#filename').html("");
    var fileNum = this.files.length,
      initial = 0,
      counter = 0;

    $.each(this.files,function(idx,elm){
       finalFiles[idx]=elm;
    });

    for (initial; initial < fileNum; initial++) {
      counter = counter + 1;
      $('#filename').append('<div id="file_'+ initial +'" class="file_ms px-2">' + this.files[initial].name + '&nbsp;&nbsp;<span class="glyph-icon iconsminds-close closeBtn" onclick="removeLine(this)" title="remove"></span></div>');
    }
  });
	
	var fathername = "<?php if($stuprofile['fathername']!="" && $stuprofile['fathername']!="0"){ echo $stuprofile['fathername'];}?>";
	var fatheroccupation = "<?php if($stuprofile['fatheroccupation']!="" && $stuprofile['fatheroccupation']!="0"){ echo $stuprofile['fatheroccupation'];}?>";
	var fatheremail = "<?php if($stuprofile['fatheremail']!="" && $stuprofile['fatheremail']!="0"){ echo $stuprofile['fatheremail'];}?>";
	var fathercode = "<?php if($stuprofile['fathercode']!="" && $stuprofile['fathercode']!="0"){ echo $stuprofile['fathercode'];}?>";
	var fatherphone = "<?php if($stuprofile['fatherphone']!="" && $stuprofile['fatherphone']!="0"){ echo $stuprofile['fatherphone'];}?>";
	var mothername = "<?php if($stuprofile['mothername']!="" && $stuprofile['mothername']!="0"){ echo $stuprofile['mothername'];}?>";
	var mothercode = "<?php if($stuprofile['mothercode']!="" && $stuprofile['mothercode']!="0"){ echo $stuprofile['mothercode'];}?>";
	var motherphone = "<?php if($stuprofile['motherphone']!="" && $stuprofile['motherphone']!="0"){ echo $stuprofile['motherphone'];}?>";
	var motheroccupation = "<?php if($stuprofile['motheroccupation']!="" && $stuprofile['motheroccupation']!="0"){ echo $stuprofile['motheroccupation'];}?>";
	var motheremail = "<?php if($stuprofile['motheremail']!="" && $stuprofile['motheremail']!="0"){ echo $stuprofile['motheremail'];}?>";
	
	$(".mpfathername").val(fathername);
	$(".mpfatheroccupation").val(fatheroccupation);
	$(".mpfatheremail").val(fatheremail);
	if(fathercode!="")$(".mpfathercode").val(fathercode); else $(".mpfathercode").val("+91");
	if(fathercode=="+91")$(".mpfathermobile").val(fatherphone); else $(".mpfathermobile").val(fatherphone).attr({"minlength":3,"maxlength":20});
	$(".mpmothername").val(mothername);
	if(mothercode!="")$(".mpmothercode").val(mothercode); else $(".mpmothercode").val("+91");
	if(mothercode=="+91")$(".mpmothermobile").val(motherphone);else $(".mpmothermobile").val(motherphone).attr({"minlength":3,"maxlength":20});
	$(".mpmotheremail").val(motheremail);
	$(".mpmotheroccupation").val(motheroccupation);
	
	var communicationcontact = "<?php if($stuprofile['communicationcontact']!="" && $stuprofile['communicationcontact']!="0"){ echo $stuprofile['communicationcontact'];}?>";
	var nationality = "<?php if($stuprofile['nationality']!="" && $stuprofile['nationality']!="0"){ echo $stuprofile['nationality'];}?>";
	var category = "<?php if($stuprofile['category']!="" && $stuprofile['category']!="0"){ echo $stuprofile['category'];}?>";
	var bloodgroup = "<?php if($stuprofile['bloodgroup']!="" && $stuprofile['bloodgroup']!="0"){ echo $stuprofile['bloodgroup'];}?>";
	var classstudy = "<?php if($stuprofile['classstudy']!="" && $stuprofile['classstudy']!="0"){ echo $stuprofile['classstudy'];}?>";
	var stream = "<?php if($stuprofile['stream']!="" && $stuprofile['stream']!="0"){ echo $stuprofile['stream'];}?>";
	
	$(".mpcomcontact").val(communicationcontact).attr('value',communicationcontact);
	$(".mpnationality").val(nationality).attr('value',nationality);
	$(".mpcategory").val(category).attr('value',category);
	$(".mpbloodgroup").val(bloodgroup).attr('value',bloodgroup);
	$(".mpclassstudy").val(classstudy).attr('value',classstudy);
	$(".mpstream").val(stream).attr('value',stream);
	
	//var schoolcollegename = "<?php //if($stuprofile['schoolcollegename']!="" && $stuprofile['schoolcollegename']!="0"){ echo $stuprofile['schoolcollegename'];}?>";
	var edudistrict = "<?php if($stuprofile['edudistrict']!="" && $stuprofile['edudistrict']!="0"){ echo $stuprofile['edudistrict'];}?>";
	var edustate = "<?php if($stuprofile['edustate']!="" && $stuprofile['edustate']!="0"){ echo $stuprofile['edustate'];}?>";
	//var edupost = "<?php //if($stuprofile['edupost']!="" && $stuprofile['edupost']!="0"){ echo $stuprofile['edupost'];}?>";
	var educountry = "<?php if($stuprofile['educountry']!="" && $stuprofile['educountry']!="0"){ echo $stuprofile['educountry'];}?>";
	var examboard = "<?php if($stuprofile['examboard']!="" && $stuprofile['examboard']!="0"){ echo $stuprofile['examboard'];}?>";
	var examclass = "<?php if($stuprofile['examclass']!="" && $stuprofile['examclass']!="0"){ echo $stuprofile['examclass'];}?>";
	var eligiblescholar = "<?php if($stuprofile['eligiblescholar']!="" && $stuprofile['eligiblescholar']!="0"){ echo $stuprofile['eligiblescholar'];}?>";
	var medium = "<?php if($stuprofile['medium']!="" && $stuprofile['medium']!="0"){ echo $stuprofile['medium'];}?>";
	var mocktype = "<?php if($stuprofile['mocktype']!="" && $stuprofile['mocktype']!="0"){ echo $stuprofile['mocktype'];}?>";

	//$(".mpcollegename").val(schoolcollegename).attr('value',schoolcollegename);
	//$(".mpdistrict").val(edudistrict).attr('value',edudistrict);
	$(".mpstate").val(edustate).attr('value',edustate);
	selectdiscrict('.mpdistrict',edustate,edudistrict);
	//$(".mppost").val(edupost).attr('value',edupost);
	$(".mpcountry").val(educountry).attr('value',educountry);
	$(".mpexamboard").val(examboard).attr('value',examboard);
	$(".mpexamclass").val(examclass).attr('value',examclass);
	$(".mpscholarship").val(eligiblescholar).attr('value',eligiblescholar);
	if(medium!="")$(".mpmedium").val(medium).attr('value',medium);else $(".mpmedium").val("<?php echo $user['qualificationid']; ?>").attr('value',"<?php echo $user['qualificationid']; ?>");
	$(".mpmocktype").val(mocktype).attr('value',mocktype);
	
	
	var contactdistrict = "<?php if($stuprofile['contactdistrict']!="" && $stuprofile['contactdistrict']!="0"){ echo $stuprofile['contactdistrict'];}?>";
	var contactstate = "<?php if($stuprofile['contactstate']!="" && $stuprofile['contactstate']!="0"){ echo $stuprofile['contactstate'];}?>";
	//var contactpost = "<?php //if($stuprofile['contactpost']!="" && $stuprofile['contactpost']!="0"){ echo $stuprofile['contactpost'];}?>";
	var contactcountry = "<?php if($stuprofile['contactcountry']!="" && $stuprofile['contactcountry']!="0"){ echo $stuprofile['contactcountry'];}?>";
	var bankname = "<?php if($stuprofile['bankname']!="" && $stuprofile['bankname']!="0"){ echo $stuprofile['bankname'];}?>";
	
	var wacode = "<?php if($stuprofile['wacode']!="" && $stuprofile['wacode']!="0"){ echo $stuprofile['wacode'];}?>";
	var whatsappno = "<?php if($stuprofile['whatsappno']!="" && $stuprofile['whatsappno']!="0"){ echo $stuprofile['whatsappno'];}else{echo "";} ?>";
	
	if(contactcountry=="") contactcountry = "India";
	
	//$(".mpcontactdistrict").val(contactdistrict).attr('value',contactdistrict);
	//$(".mpcontactstate").val(contactstate).attr('value',contactstate);
	selectstate('.mpcontactstate',contactcountry,contactstate);
	//selectdiscrict('.mpcontactdistrict',contactstate,contactdistrict);
	//$(".mpcontactpost").val(contactpost).attr('value',contactpost);
	$(".mpcontactcountry").val(contactcountry).attr('value',contactcountry);
	//$(".mpbankname").val(bankname).attr('value',bankname);
	if(wacode!="")$(".mpwacode").val(wacode); else $(".mpwacode").val("+91");
	if(wacode=="+91")$(".mpwhatsappno").val(whatsappno); else $(".mpwhatsappno").val(whatsappno).attr({"minlength":3,"maxlength":20});
	
	// Get District List
	
	/*$(".mpcontactstate").on('change', function(e) {
		
		var state = $(this).val();
		
		$.ajax({
                type: 'POST',
                url: 'stumyprofile/getDistrictList',
                data: {'state':state},
                success: function(response) {
					
					var obj1 = $.parseJSON(response);
					
					$(".mpcontactdistrict").html(obj1['districtoption']);
					
				}
			
		});
		
		
	});
	
	$(".mpstate").on('change', function(e) {
		
		var state = $(this).val();
		
		$.ajax({
                type: 'POST',
                url: 'stumyprofile/getDistrictList',
                data: {'state':state},
                success: function(response) {
					
					var obj1 = $.parseJSON(response);
					
					$(".mpdistrict").html(obj1['districtoption']);
					
				}
			
		});
		
		
	});*/
	
	$(".mpcontactcountry").on('change', function(e) {
		
		var country = $(this).val();
		
		$.ajax({
                type: 'POST',
                url: 'stumyprofile/getCountryStateList',
                data: {'country':country},
                success: function(response) {
					
					var obj1 = $.parseJSON(response);
					
					if(obj1['stateoption']!=""){
						$(".mpcontactstate").remove();
						$(".constatelist").prepend('<select class="form-control mpcontactstate" name="mpcontactstate" required value="">'+obj1['stateoption']+"</select>");
					}
					else{
						$(".mpcontactstate").remove();
						$(".constatelist").prepend('<input type="text" class="form-control mpcontactstate" name="mpcontactstate" placeholder=" " value="">');
					}
					
				}
			
		});
		
		
	});
	
	
	$(document).on('change','.mpcontactstate',function(){
		
		$(this).attr('value',$(this).val());
		
	});
	
	
	// Upload Profile Picture
	
	$('.profileedit').on('click', function(e){
        $('#changeProfilePhotoModal').modal({show:true});        
    });	
	$('#profileImage').on('change', function()	{ 
		$("#previewProfilePhoto").html('');
		$("#previewProfilePhoto").html('Uploading....');
		
		//$("#cropImage").submit(function(){
		
			var formData = new FormData();
		
			var poData = $("#cropImage").serializeArray();//console.log(poData);
			for (var j=0; j<poData.length; j++){
				formData.append(poData[j].name, poData[j].value);
			}
	
			var c=0;
            var file_data;
			file_data = $('#profileImage')[0].files; // get multiple files from input file
			  //console.log(file_data);
		    for(var i = 0;i<file_data.length;i++){
			   formData.append('profileImage', file_data[i]); // we can put more than 1 image file
		    }
			
			$.ajax({
					type: 'POST',
					url: 'stumyprofile/changeProfilePhoto',
					data: formData,
					contentType: false,
					processData: false,
					success: function(response) {
						
						$("#previewProfilePhoto").html(response);
												
						$('#imageName').val($('#photo').attr('file-name'));
						
						var ppimgsrc = $('#photo').attr('src');
						$(".img-thumbnail,.user img").attr("src",ppimgsrc);
						
					}

			});
			
		//});
		
		/*$("#cropImage").ajaxForm(
		{
		target: '#previewProfilePhoto',
		success:    function() { 
				$('img#photo').imgAreaSelect({
				aspectRatio: '1:1',
				onSelectEnd: getSizes,
			});
			$('#imageName').val($('#photo').attr('file-name'));
			}
		}).submit();*/

	});	
	
	$('#savePic').on('click', function(e){
		
		if($("#profileImage").val()!=""){
			$('#changeProfilePhotoModal').modal('hide');
			$('#profileImage').val("");
			$("#previewProfilePhoto").html("");
			checkprofilepic = 1;
		}
		else $(".alert").addClass('alert-danger').text("Upload image");
		
	});	
	
	$('#changeProfilePhotoModal').on('hidden.bs.modal', function () {
		
		$('#profileImage').val("");
		$("#previewProfilePhoto").html("");
		
	});
	
	$("input,select,textarea").click(function(){
		
		$(".alert").removeClass('alert-danger alert-success').text("");
		
	});
		
	$('#savePhoto').on('click', function(e){
    e.preventDefault();
    params = {
            targetUrl: 'stumyprofile/saveProfilePhoto',
            action: 'save',
            x_axis: $('#hdn-x1-axis').val(),
            y_axis : $('#hdn-y1-axis').val(),
            x2_axis: $('#hdn-x2-axis').val(),
            y2_axis : $('#hdn-y2-axis').val(),
            thumb_width : $('#hdn-thumb-width').val(),
            thumb_height:$('#hdn-thumb-height').val()
        };
        saveCropImage(params);
    });   
    function getSizes(img, obj){
        var x_axis = obj.x1;
        var x2_axis = obj.x2;
        var y_axis = obj.y1;
        var y2_axis = obj.y2;
        var thumb_width = obj.width;
        var thumb_height = obj.height;
        if(thumb_width > 0) {
			$('#hdn-x1-axis').val(x_axis);
			$('#hdn-y1-axis').val(y_axis);
			$('#hdn-x2-axis').val(x2_axis);
			$('#hdn-y2-axis').val(y2_axis);
			$('#hdn-thumb-width').val(thumb_width);
			$('#hdn-thumb-height').val(thumb_height);
        } else {
            alert("Please select portion..!");
		}
    }   
    function saveCropImage(params) {
		$.ajax({
			url: params['targetUrl'],
			cache: false,
			dataType: "html",
			data: {
				action: params['action'],
				studentid: $('#studentid').val(),
				t: 'ajax',
				w1:params['thumb_width'],
				x1:params['x_axis'],
				h1:params['thumb_height'],
				y1:params['y_axis'],
				x2:params['x2_axis'],
				y2:params['y2_axis'],
				imageName :$('#imageName').val()
			},
			type: 'Post',
		   	success: function (response) {
					$('#changeProfilePhotoModal').modal('hide');
					$(".imgareaselect-border1,.imgareaselect-border2,.imgareaselect-border3,.imgareaselect-border4,.imgareaselect-border2,.imgareaselect-outer").css('display', 'none');
					console.log(response);
					$("#profilePhoto").attr('src', response);
					$("#previewProfilePhoto").html('');
					$("#profileImage").val();
					//$("#changeProfilePhoto").text('Change Photo');
			},
			error: function (xhr, ajaxOptions, thrownError) {
				alert('status Code:' + xhr.status + 'Error Message :' + thrownError);
			}
		});
    }
	
	
	// Payment method
	
	$("input[name='paymethod']").change(function(){
		
		var paymethod = $(this).val();
		
		if(paymethod=="offline"){
			
			$(".challanbtn,.submit-btn").removeClass('d-none');
			$(".payment-btn").addClass('d-none');
			
		}else{
			$(".challanbtn,.submit-btn").addClass('d-none');
			$(".payment-btn").removeClass('d-none');
		}
		
	});
	
	$(".checkrefund").click(function(e){
				
		e.preventDefault();
		
		var payurl = $(this).attr('href');
		var btntype = $(this).data('btntype');
		
		$('#refundModal').modal({show:true});
		$("#payurl").val(payurl);
		$("#btntype").val(btntype);
		
	});
	
	$(".iagree").click(function(){
				
		var payurl = $("#payurl").val();
		var btntype = $("#btntype").val();
		
		$('#refundModal').modal('hide');
		
		if(btntype=="paynow"){
			window.open(payurl,"_self");
		}else{
			window.open(payurl,"_blank");
		}
		
	});
	
	
	$("form select").change(function(){
		$(this).attr('value',$(this).val());
	});
	
	
	$(".mpfathercode,.mpmothercode,.mpwacode").change(function(){
		
		var sumcode = $(this).val();
		
		if(sumcode!="+91"){
			$(this).closest('.form-row').find("input[type='number']").attr('minlength',3).attr('maxlength',20);
		}else{
			$(this).closest('.form-row').find("input[type='number']").attr('minlength',10).attr('maxlength',10);
		}
		
	});

	
});
	
	
function selectdiscrict(classname,state,district){
	
	$.ajax({
		type: 'POST',
		url: 'stumyprofile/getDistrictList',
		data: {'state':state},
		success: function(response) {

			var obj1 = $.parseJSON(response);

			$(classname).html(obj1['districtoption']);
			$(classname).val(district).attr('value',district);

		}

	});
	
}
	
function selectstate(classname,country,state){
	
	$.ajax({
		type: 'POST',
		url: 'stumyprofile/getCountryStateList',
		data: {'country':country},
		success: function(response) {

			var obj1 = $.parseJSON(response);

			if(obj1['stateoption']!=""){
				$(classname).remove();
				$(".constatelist").prepend('<select class="form-control mpcontactstate" name="mpcontactstate" required value="">'+obj1['stateoption']+"</select>");
				$(classname).val(state).attr('value',state);
			}
			else{
				$(classname).remove();
				$(".constatelist").prepend('<input type="text" class="form-control mpcontactstate" name="mpcontactstate" placeholder=" " value="'+state+'">');
			}
			
		}

	});
	
}
	
var dropZoneId = "drop-zone";
var buttonId = "clickHere";
var mouseOverClass = "mouse-over";
var dropZone = $("#" + dropZoneId);
var inputFile = dropZone.find("input");
var finalFiles = {};
	
$(function() {
	
var ooleft = dropZone.offset().left;
  var ooright = dropZone.outerWidth() + ooleft;
  var ootop = dropZone.offset().top;
  var oobottom = dropZone.outerHeight() + ootop;
 
  document.getElementById(dropZoneId).addEventListener("dragover", function(e) {
    e.preventDefault();
    e.stopPropagation();
    dropZone.addClass(mouseOverClass);
    var x = e.pageX;
    var y = e.pageY;

    if (!(x < ooleft || x > ooright || y < ootop || y > oobottom)) {
      inputFile.offset({
        top: y - 15,
        left: x - 100
      });
    } else {
      inputFile.offset({
        top: -400,
        left: -400
      });
    }

  }, true);

  if (buttonId != "") {
    var clickZone = $("#" + buttonId);

    var oleft = clickZone.offset().left;
    var oright = clickZone.outerWidth() + oleft;
    var otop = clickZone.offset().top;
    var obottom = clickZone.outerHeight() + otop;

    $("#" + buttonId).mousemove(function(e) {
      var x = e.pageX;
      var y = e.pageY;
      if (!(x < oleft || x > oright || y < otop || y > obottom)) {
        inputFile.offset({
          top: y - 15,
          left: x - 160
        });
      } else {
        inputFile.offset({
          top: -400,
          left: -400
        });
      }
    });
  }

  document.getElementById(dropZoneId).addEventListener("drop", function(e) {
    $("#" + dropZoneId).removeClass(mouseOverClass);
  }, true);

});
	
function removeLine(obj)
{
  inputFile.val('');
  var jqObj = $(obj);
  var container = jqObj.closest('div');
  var index = container.attr("id").split('_')[1];
  container.remove(); 

  delete finalFiles[index];
  //console.log(finalFiles);
}
	
function Be(e) {
	return !!$().validate && !!$(e).valid()
	//return true;
}
	
</script>

<style>
		
	.regcourses h1{font-size: 18px;color: #364159;}
	.myprofile .card{background: linear-gradient(0deg, #FFFFFF, #FFFFFF), #C4C4C4;box-shadow: 0px 0px 7px rgba(196, 196, 196, 0.35);border-radius: 10px;}
	h2{color: #181E29;font-size: 20px;font-weight: bold;line-height: 32px;}
	.regcourses h2{color: #0332AA;font-size: 24px;font-weight: bold;line-height: 36px;}
	.regcourses p.list-item-heading{color: #6884CC;font-weight: 600;}
	.regcourses p.list-item-heading span:last-child{font-weight: 600;font-size: 14px;color: #364159;}
	
	.border-right{border-right: 1px solid #D7DFF0!important;}
		
	.btn-primary{width: auto}
	.btn-primary.disabled, .btn-primary:disabled{background: #9AADDD;color: #ffffff;}
	
	.card h5{margin-bottom: 1rem;}
	h5{font-weight: bold;}
	
	.col-right h5{padding: 1.2rem}
 
	.icon-status{background: url("img/icons/status-b.png") no-repeat;width: 15px;height: 15px;display: inline-block;vertical-align: middle}
	
	.table td.totalfee {font-weight: bold;font-size: 16px;color: #D63333;}
	.table td.totalamt {font-weight: bold;font-size: 12px;color: #6F83AA;letter-spacing: 0.5px;text-transform: uppercase;text-align: right !important}
	.table tr:last-child td{text-align: center}
	.table tr td:last-child,.table tr th:last-child{text-align: center}
	.table tr:last-child td:last-child{font-weight: bold;text-align: center}
	.table tr:last-child{text-align: center}
	
	.profilename{font-size: 24px;color: #181E29;line-height: 36px;}
	.progress-percent{font-size: 14px;color: #0332AA;}
	.profileedit{background: #0332AA;border: 3px solid #ffffff;width: 35px;height: 35px;border-radius: 50%;position: absolute;bottom: 20px;right: 20px;}
	.icon-edit{background: url("img/icons/edit.png") no-repeat;width: 14px;height: 14px;display: inline-block;vertical-align: middle;position: absolute;top: 27%;left: 27%;}
	
	.custom-control{display: inline-block}
	
	.icon-arrow-left{background: url("img/icons/leftarrow-btn.png") no-repeat;width: 6px;height: 10px;display: inline-block;vertical-align: middle;}
	.icon-arrow-right{background: url("img/icons/rightarrow-btn.png") no-repeat;width: 6px;height: 10px;display: inline-block;vertical-align: middle;}
	
	.table{border: 1px solid #D7DFF0;border-collapse: collapse;border-style: hidden;border-radius: 5px 5px 0 0;box-shadow: 0 0 0 1px #d7dff0;}
	.table thead th{font-size: 12px;font-weight: bold;color: #6F83AA;letter-spacing: 0.5px;background: #E6EBF7;text-transform: uppercase;padding: 0.5rem;text-align: left}
	.table thead tr th:first-child{border-top-left-radius: 5px}
	.table thead tr th:last-child{border-top-right-radius: 5px}
	.table td, .table th{border-top: 1px solid #D7DFF0;padding: 0.9rem 0.75rem;color: #364159;font-weight: 600;}
	.thtax{display: block;text-align: center;}
	.thtaxvalue{display: flex;}
	.thtaxvalue span:first-child{width: 53%}
	
	.next-btn,.payment-btn,.finish-btn,.submit-btn{float: right}
	.prev-btn{float: left}
	
	.btn-outline-primary:not(:disabled):not(.disabled).active .icon-arrow-left, .btn-outline-primary:not(:disabled):not(.disabled):active .icon-arrow-left,.btn-outline-primary:hover .icon-arrow-left{filter: contrast(0.2) brightness(2);}
		
	.sw-main.sw-theme-dots>ul.step-anchor.mpregister>li{width: 16%;}
	.sw-main.sw-theme-dots>ul.step-anchor.mpregister>li>a i{left: 38%;}
	
	.sw-main.sw-theme-dots>ul.step-anchor:before{background: linear-gradient(90deg, #355bbb 0%, #f3f3f3 0%);}
	
	/* Upload files*/	
	
	.box {position: relative;background: #ffffff;width: 100%;}
	.box-header {color: #444;display: block;padding: 10px;position: relative;border-bottom: 1px solid #f4f4f4;margin-bottom: 10px;}
	.box-tools {position: absolute;right: 10px;top: 5px;}
	.dropzone-wrapper {background: #F6F7FA;border: 1px dashed #BCCAE8;color: #92b0b3;position: relative;height: 120px;border-radius: 5px;}
	.dropzone-desc {position: absolute;margin: 0 auto;left: 0;right: 0;text-align: center;width: auto;top: 22px;font-size: 16px;}
	.dropzone,
	.dropzone:focus {position: absolute;outline: none !important;width: 100%;height: 150px;cursor: pointer;opacity: 0;}
	.dropzone-wrapper:hover,
	.dropzone-wrapper.dragover {background: #ecf0f5;}
	.preview-zone {text-align: center;}
	.preview-zone .box {box-shadow: none;border-radius: 0;margin-bottom: 0;}
	#filename {margin-top: 10px;margin-bottom: 10px;font-size: 14px;line-height: 2.7em;border: 1px solid #D7DFF0;
    border-radius: 5px;min-height: 40px;margin-top: 2.2rem;}
	.file-preview {background: #ccc;border: 5px solid #fff;box-shadow: 0 0 4px rgba(0, 0, 0, 0.5);display: inline-block;width: 60px;height: 60px;text-align: center;font-size: 14px;margin-top: 5px;}
	.closeBtn:hover {color: red;display:inline-block;}
	
	.icon-upload{background: url("img/icons/upload.png") no-repeat;width: 24px;height: 24px;display: inline-block;vertical-align: middle}
	.dropzone-desc p.list-item-heading{font-size: 14px;font-weight: 600;color: #536485;}
	.dropzone-desc p.text-muted{font-size: 10px;font-weight: normal;color: #6F83AA;}
	.dropzone-desc p.list-item-heading span{color: #db4d4d}
	
	.dropzone-desc .text-center{text-align: center !important}
	
	.custom-radio label{font-size: 14px;font-weight: normal;color: #536485;}
	
	h3.title{font-size: 12px;font-weight: bold;color: #0332AA;letter-spacing: 0.5px;text-transform: uppercase;}
	.file_ms{font-size: 12px;color: #1C47B3;text-decoration-line: underline;}
	
	.myprofile .img-thumbnail{width: 115px;height: 115px}
	.icon-download{background: url("img/icons/download.png") no-repeat;width: 15px;height: 16px;display: inline-block;vertical-align: middle;margin-right: 0.5rem}
	
	h3{font-size: 18px;color: #364159;font-weight: bold;}
	
	/* Qualification */
	.yearfee .card{background: #F6F7FA;border: 1px solid #BCCAE8;box-shadow: none}
	.yearfee p{margin-bottom: 1.5rem}
	.yearfee p.first,.yearfee p.second{font-weight: bold;font-size: 14px;color: #0332AA;text-align: left;text-transform: uppercase;}
	.yearfee .row div:last-child p{font-size: 14px;font-weight: 600;color: #364159;}
	.yearfee p.list-item-heading,.yearfee .row div:first-child p{color: #6884CC;font-weight: 600;}
	
	.sw-theme-default .sw-container{min-height: inherit !important}
	
	.marksheet p.list-item-heading,.qmarksheet p.list-item-heading{color: #6884CC;font-weight: 600;}
	.marksheet img,.qmarksheet img{width: 100px;height: 130px;}
	.marksheet .gallery .col-2,.qmarksheet .gallery .col-2{position: relative;padding: 0;margin: 1rem;max-width: 10% !important}
	.marksheet .overlay,.qmarksheet .overlay{background: rgba(83, 100, 133,0.6) url(img/icons/eye.png) no-repeat center;width: 100%;height: 100%;position: absolute;border-radius: 0.75rem;top: 0;}
		
	.myprofile .img-thumbnail{width: 115px;height: 115px}
	
	.gallery a{text-align: center}
	.gallery a i{font-size: 4rem;padding: 1.5rem 0;display: block}
	.gallery a span.text{font-size: 10px;position: absolute;top: 28%;left: 14%;background: #ff0000;color: #fff;text-transform: uppercase;padding: 0px 7px;font-weight: bold;}
	
	@media (max-width:767px){
		
		.marksheet .gallery .col-2,.qmarksheet .gallery .col-2{max-width: 100% !important;}
	}
	
	.idcardrow{margin: 0px auto !important}
		
</style>

<?php 

	$marksheets = $stuprofile['marksheets'];
	$marksheetlist = $refund = "";

	if($marksheets!="" && $marksheets!="0"){

		$marksheetsarr = explode('|',$marksheets);
		$mscount = 0;
		foreach($marksheetsarr as $key=>$marksheet){

			if($key==$mscount) $marksheet = $marksheet;else $marksheet = $marksheet.', ';

			$marksheetlist .= '<div class="file_ms px-2"> '.$marksheet.'&nbsp;&nbsp;</div>';
			$mscount++;
		}

	}

?>

<main>

	<div class="container-fluid">

		
		
		<div class="col-12 mb-4 myprofile">
       
        <div class="mb-4">
         
          <div id="smartWizardDot">
           
            <ul class="card-header <?php if($action=="register"){ echo "mpregister";}?>">
              <li><a href="#dotStep1"><i class="icon-users"></i></a>Personal Details</li>
              <li><a href="#dotStep2"><i class="icon-book-open"></i></a>Educational Details</li>
              <li><a href="#dotStep6"><i class="icon-book-open"></i></a>Qualification Details</li>
              <li><a href="#dotStep3"><i class="icon-phone-mp"></i></a>Contact Details</li>
              <li><a href="#dotStep4"><i class="icon-rupee-sign"></i></a>Bank Details</li>
             <?php if($action=="register"){?> <li><a href="#dotStep5"><i class="icon-credit-card"></i></a>Course Payment</li><?php }?>
            </ul>
            
			</div>
            
            </div>
            
			<div class="card mb-4 formscrolltop">
				
				<div class="row">
          
          <div class="col-md-8 col-sm-12 col-lg-8 col-12">
           
            <div class="d-flex flex-row">
             
				<a class="d-flex position-relative" href="javascript:void(0);"><img alt="Profile" src="<?php if($stuprofile['profilepic']!="0" && $stuprofile['profilepic']!=""){ echo "docs/profilepic/".$user['id']."/".$stuprofile['profilepic']."?".time();}else{echo "img/myprofile.png?".time();} ?>" class="img-thumbnail border-0 rounded-circle m-4 align-self-center"> <span class="profileedit"><i class="icon-edit"></i></span></a>
             
              <div class="d-flex flex-grow-1 min-width-zero">
                <div class="card-body pl-0 align-self-center d-flex flex-column flex-lg-row justify-content-between min-width-zero">
                  <div class="w-100">
                   <a href="#">
                    <p class="list-item-heading mb-2 truncate font-weight-bold profilename"><?php if($stuprofile['stuname']!=""){ echo ucwords($stuprofile['stuname']);} ?></p>
                    </a>
                    <p class="mb-2 text-small font-weight-semibold progress-percent">Profile Completeness: <span class="progressnum font-weight-bold"><?php if($stuprofile['profilepercent']!=0){ echo $stuprofile['profilepercent'];}else{echo 0;} ?>%</span></p>
					<div class="progress">
					  <div class="progress-bar" role="progressbar" style="width: <?php if($stuprofile['profilepercent']!=0){ echo $stuprofile['profilepercent'];}else{echo 0;} ?>%" aria-valuenow="<?php if($stuprofile['profilepercent']!=0){ echo $stuprofile['profilepercent'];}else{echo 0;} ?>" aria-valuemin="0" aria-valuemax="100"></div>
					</div>
                  </div>
                </div>
              </div>
            </div>
            
          </div>
          
          <div class="col-md-4 col-sm-12 col-lg-4 col-12 d-flex align-items-center justify-content-end">
           
            <div class="row w-100">
             
             	<div class="col-md-6">
             		<button type="button" class="btn btn-primary idcardpreviewbtn">ID Card</button>
				</div>
             
             	<div class="col-md-6">
             		<button type="button" class="btn btn-primary" disabled><?php if($stuprofile['profilepercent']=="100"){ echo "Update";}else{echo "Complete";} ?> Profile</button>
				</div>
           
            </div>
            
          </div>
          
        </div>
				
			</div>
            
            <div class="card mb-4">
          <div id="smartWizardCustomButtons">
            <ul class="card-header border-bottom">
              <li><a href="#customButtons1">Personal Details</a></li>
              <li><a href="#customButtons2">Educational Details</a></li>
              <li><a href="#customButtons6">Qualification Details</a></li>
              <li><a href="#customButtons3">Contact Details</a></li>
              <li><a href="#customButtons4">Bank Details</a></li>
              <?php if($action=="register"){?><li><a href="#customButtons5" class="100">Course Payment</a></li><?php }?>
            </ul>
            <div class="card-body">
              <div id="customButtons1">

                <form id="form-step-0" class="tooltip-right-bottom mb-4" novalidate>
             
             <div class="row">
             
             <div class="col-12 col-sm-6">
              <div class="form-group position-relative error-l-50 floating">
                <input type="text" class="form-control" name="mpname" id="mpname" required  placeholder=" " value="<?php if($stuprofile['stuname']!=""){ echo ucwords($stuprofile['stuname']);}else{echo "";} ?>" disabled>
                 <label for="mpname">Name <span>*</span></label>
              </div>
			</div>
              
              <div class="col-12 col-sm-6">
				   <div class="form-group position-relative error-l-50 floating">
						<input class="form-control mpdob" name="mpdob" placeholder=" " value="<?php if($stuprofile['dob']!="" && $stuprofile['dob']!="0000-00-00"){ echo date("d-m-Y",strtotime($stuprofile['dob']));}else{echo "";} ?>" required>
						<label>DOB (DD-MM-YYYY) <span>*</span></label>
					</div>
              </div>
              
              <div class="col-12 col-sm-6">
              <div class="form-group position-relative error-l-50">
              	  <label>Gender <span>*</span></label>
               	  <div>
					  <div class="custom-control custom-radio col-sm-3 col-3">
						<input type="radio" id="mpgender1" name="mpgender" class="custom-control-input" value="Male" required=""  <?php if($stuprofile['gender']=="Male"){ echo "checked";}else{echo "";} ?>>
						<label class="custom-control-label" for="mpgender1">Male</label>
					  </div>
					  <div class="custom-control custom-radio col-sm-3 col-4">
						<input type="radio" id="mpgender2" name="mpgender" class="custom-control-input" value="Female" required="" <?php if($stuprofile['gender']=="Female"){ echo "checked";}else{echo "";} ?>>
						<label class="custom-control-label" for="mpgender2">Female</label>
					  </div>
					  <div class="custom-control custom-radio col-sm-3 col-3 mb-3">
						<input type="radio" id="mpgender3" name="mpgender" class="custom-control-input" value="Others" required="" <?php if($stuprofile['gender']=="Others"){ echo "checked";}else{echo "";} ?>>
						<label class="custom-control-label" for="mpgender3">Others</label>
					  </div>
                </div>
              </div>
              </div>
              
              <div class="col-12 col-sm-6">
              <div class="form-group position-relative error-l-50 floating">
                <select class="form-control mpnationality floating" name="mpnationality" required value="">
                  <option value="">Nationality</option>
                  <option value="Indian">Indian</option>
                  <option value="Others">Others</option>                  
                </select>
                <label>Nationality <span>*</span></label>
              </div>
              </div>
              
              <div class="col-12 col-sm-6">
              <div class="form-group position-relative error-l-50 floating">
                <select class="form-control mpcategory floating" name="mpcategory" required value="">
                  <option value="">Category</option>
                  <option value="General">General</option>
                  <option value="OBC">OBC</option>
                  <option value="SC">SC</option>
                  <option value="ST">ST</option>
                  <option value="Other">Other</option>                  
                </select>
                <label>Category <span>*</span></label>
              </div>
              </div>
              
              <div class="col-12 col-sm-6">
              <div class="form-group position-relative error-l-50 floating">
                <input type="number" class="form-control mpaadharnumber" name="mpaadharnumber" minlength="12" maxlength="12" placeholder=" " value="<?php if($stuprofile['aadharnumber']!="" && $stuprofile['aadharnumber']!="0"){ echo $stuprofile['aadharnumber'];}else{echo "";} ?>">
                 <label>Aadhar Number</label>
              </div>
			</div>
              
              <div class="col-12 col-sm-6">
              <div class="form-group position-relative error-l-50 floating">
                <input type="text" class="form-control mpfathername" name="mpfathername" required placeholder=" "  value="<?php if($stuprofile['fathername']!=""){ echo $stuprofile['fathername'];}else{echo "";} ?>">
                 <label>Fathers Name <span>*</span></label>
              </div>
			</div>
              
              <div class="col-12 col-sm-6">
              
              <div class="form-row">
              
				  <div class="form-group col-md-3 position-relative error-l-50">
					<select class="form-control mpfathercode" name="mpfathercode" required placeholder=" ">
					  <option value="+91">+91</option><option value="44">+44</option><option value="65">+65</option><option value="+973">+973</option><option value="+20">+20</option><option value="+98">+98</option><option value="+964">+964</option><option value="+972">+972</option><option value="+962">+962</option><option value="+965">+965</option><option value="+961">+961</option><option value="+968">+968</option><option value="+970">+970</option><option value="+974">+974</option><option value="+966">+966</option><option value="+90">+90</option><option value="+971">+971</option><option value="+967">+967</option><option value="+93">+93</option><option value="+374">+374</option><option value="+994">+994</option><option value="+76">+76</option><option value="+996">+996</option><option value="+92">+92</option><option value="+963">+963</option><option value="+992">+992</option><option value="+993">+993</option><option value="+998">+998</option><option value="+357">+357</option><option value="+253">+253</option><option value="+291">+291</option><option value="+995">+995</option><option value="+352">+352</option><option value="+249">+249</option>
					</select>
				  </div>
             
				  <div class="form-group col-md-9 position-relative error-l-50 floating">
					<input type="number" class="form-control mpfathermobile" name="mpfathermobile" minlength="10" maxlength="10" required placeholder=" " value="<?php if($stuprofile['fatherphone']!=""){ echo $stuprofile['fatherphone'];}else{echo "";} ?>">
					<label>Fathers Phone <span>*</span></label>
				  </div>
              
			   </div>
             
				 </div>
              
              <div class="col-12 col-sm-6">
              <div class="form-group position-relative error-l-50 floating">
                <input type="email" class="form-control mpfatheremail" name="mpfatheremail" required placeholder=" "  value="<?php if($stuprofile['fatheremail']!=""){ echo $stuprofile['fatheremail'];}else{echo "";} ?>">
                 <label>Fathers/Guardian Email <span>*</span></label>
              </div>
			</div>
              
              <div class="col-12 col-sm-6">
              <div class="form-group position-relative error-l-50 floating">
                <input type="text" class="form-control mpfatheroccupation" name="mpfatheroccupation" required placeholder=" "  value="<?php if($stuprofile['fatheroccupation']!=""){ echo $stuprofile['fatheroccupation'];}else{echo "";} ?>">
                 <label>Fathers Occupation <span>*</span></label>
              </div>
			</div>
              
              <div class="col-12 col-sm-6">
              <div class="form-group position-relative error-l-50 floating">
                <input type="text" class="form-control mpmothername" name="mpmothername" required placeholder=" "  value="<?php if($stuprofile['mothername']!=""){ echo $stuprofile['mothername'];}else{echo "";} ?>">
                 <label>Mothers Name <span>*</span></label>
              </div>
			</div>
              
              <div class="col-12 col-sm-6">
              
              <div class="form-row">
              
				  <div class="form-group col-md-3 position-relative error-l-50">
					<select class="form-control mpmothercode" name="mpmothercode" required >
					  <option value="+91">+91</option><option value="44">+44</option><option value="65">+65</option><option value="+973">+973</option><option value="+20">+20</option><option value="+98">+98</option><option value="+964">+964</option><option value="+972">+972</option><option value="+962">+962</option><option value="+965">+965</option><option value="+961">+961</option><option value="+968">+968</option><option value="+970">+970</option><option value="+974">+974</option><option value="+966">+966</option><option value="+90">+90</option><option value="+971">+971</option><option value="+967">+967</option><option value="+93">+93</option><option value="+374">+374</option><option value="+994">+994</option><option value="+76">+76</option><option value="+996">+996</option><option value="+92">+92</option><option value="+963">+963</option><option value="+992">+992</option><option value="+993">+993</option><option value="+998">+998</option><option value="+357">+357</option><option value="+253">+253</option><option value="+291">+291</option><option value="+995">+995</option><option value="+352">+352</option><option value="+249">+249</option>
					</select>
				  </div>
             
				  <div class="form-group col-md-9 position-relative error-l-50 floating">
					<input type="number" class="form-control mpmothermobile" name="mpmothermobile" minlength="10" maxlength="10" required placeholder=" "  value="<?php if($stuprofile['motherphone']!=""){ echo $stuprofile['motherphone'];}else{echo "";} ?>">
					<label>Mothers Phone <span>*</span></label>
				  </div>
              
			   </div>
             
				 </div>
              
              <div class="col-12 col-sm-6">
               <div class="form-group position-relative error-l-50 floating">
                <input type="email" class="form-control mpmotheremail" name="mpmotheremail" placeholder=" " value="<?php if($stuprofile['motheremail']!=""){ echo $stuprofile['motheremail'];}else{echo "";} ?>">
                <label>Mothers Email</label>
              </div>
              </div>
              
              <div class="col-12 col-sm-6">
              <div class="form-group position-relative error-l-50 floating">
                <input type="text" class="form-control mpmotheroccupation" name="mpmotheroccupation" required placeholder=" "  value="<?php if($stuprofile['motheroccupation']!=""){ echo $stuprofile['motheroccupation'];}else{echo "";} ?>">
                 <label>Mothers Occupation <span>*</span></label>
              </div>
			</div>
              
              <div class="col-12 col-sm-6">
              <div class="form-group position-relative error-l-50 floating">
                <select class="form-control mpcomcontact floating" name="mpcomcontact" required value="">
                  <option value="">Communication Contact</option>
                  <option value="Father">Father</option>
                  <option value="Mother">Mother</option>
                  <option value="Guardian">Guardian</option>                  
                </select>
                <label>Communication Contact <span>*</span></label>
              </div>
              </div>
              
              <div class="col-12 col-sm-6">
              <div class="form-group position-relative error-l-50 floating">
                <select class="form-control mpbloodgroup floating" name="mpbloodgroup" required value="">
                  <option value="">Blood Group</option>
                  <option value="A+">A+</option><option value="A1+">A1+</option><option value="A1B+">A1B+</option><option value="A2B+">A2B+</option><option value="A2+">A2+</option><option value="B+">B+</option><option value="O+">O+</option><option value="AB+">AB+</option><option value="A-">A-</option><option value="A1-">A1-</option><option value="A1B-">A1B-</option><option value="A2-">A2-</option><option value="B-">B-</option><option value="O-">O-</option><option value="AB-">AB-</option><option value="Not Aware">Not Aware</option> </select>
                <label>Blood Group <span>*</span></label>
              </div>
              </div>
              
              <div class="col-12 col-sm-6">
              <div class="form-group position-relative error-l-50 floating">
                <select class="form-control mpclassstudy floating" name="mpclassstudy" required value="">
                  <option value="">Class Studying / Complete</option>
                 <option value="5th Standard">5th Standard</option><option value="6th Standard">6th Standard</option><option value="7th Standard">7th Standard</option><option value="8th Standard">8th Standard</option><option value="9th Standard">9th Standard</option><option value="X Standard">X Standard</option><option value="XI Standard">XI Standard</option><option value="XII Standard">XII Standard</option>                
                </select>
                <label>Class Studying / Complete <span>*</span></label>
              </div>
              </div>
              
              <div class="col-12 col-sm-6">
              <div class="form-group position-relative error-l-50 floating">
                <select class="form-control mpstream" name="mpstream" required value="">
                  <option value="">Stream</option>
                  <option value="Kerala State">Kerala State</option>
                  <option value="CBSE">CBSE</option>
                  <option value="ICSE/ISC">ICSE/ISC</option>
                  <option value="Kerala Technical">Kerala Technical</option> 
                  <option value="International">International</option> 
                  <option value="Others">Others</option>  
                  <option value="Outside India">Outside India</option>                  
                </select>
                <label>Stream <span>*</span></label>
              </div>
              </div>
              
              			  
			  </div>
                                                 
            </form>                
                
              </div>
              <div id="customButtons2">
                
             <form id="form-step-1" class="tooltip-right-bottom mb-4" enctype="multipart/form-data" novalidate>
             
             <div class="row">
             
             <div class="col-12 col-sm-6">
              <div class="form-group position-relative error-l-50 floating">
               
               <input type="text" class="form-control mpcollegename" name="mpcollegename" placeholder=" " required value="<?php if($stuprofile['schoolcollegename']!="" && $stuprofile['schoolcollegename']!="0"){ echo $stuprofile['schoolcollegename'];}else{echo "";} ?>">
               
                <!--<select class="form-control mpcollegename" name="mpcollegename" required value="">
                  <option value=""></option>
                  <option value="collegename">School/College Name</option>                  
                </select>-->
                
                <label>Name of School Last Studied / Studying  <span>*</span></label>
              </div>
              </div>
              
             <!-- <div class="col-12 col-sm-6">
               <div class="form-group position-relative error-l-50 floating">
                <input type="text" class="form-control mplandmark" name="mplandmark" value="" placeholder=" " value="<?php //if($stuprofile['edulandmark']!="" && $stuprofile['edulandmark']!="0"){ echo $stuprofile['edulandmark'];}else{echo "";} ?>">
                <label>Landmark</label>
              </div>
              </div>-->
              
                            
              <div class="col-12 col-sm-6">
              <div class="form-group position-relative error-l-50 floating">
                <input type="text" class="form-control" name="mpaddressline" required placeholder=" " value="<?php if($stuprofile['eduaddress']!="" && $stuprofile['eduaddress']!="0"){ echo $stuprofile['eduaddress'];}else{echo "";} ?>">
                 <label>Address Line <span>*</span></label>
              </div>
			</div>
              
              <div class="col-12 col-sm-6">
              <div class="form-group position-relative error-l-50 floating">
                <select class="form-control mpcountry" name="mpcountry" required value="">
                  <option value="">Country</option>
                  <option value="India">India</option> 
                  <option value="Others">Others</option>                  
                </select>
                <label>Country <span>*</span></label>
              </div>
              </div>
              
             <!--<div class="col-12 col-sm-6">
              <div class="form-group position-relative error-l-50 floating">
                <select class="form-control mpstate" name="mpstate" required value="">
                  <?php //echo $statelist['stateoption'];?>            
                </select>
                <label>State <span>*</span></label>
              </div>
              </div>
              
              <div class="col-12 col-sm-6">
              <div class="form-group position-relative error-l-50 floating">
                <select class="form-control mpdistrict" name="mpdistrict" required value="">
                  <option value=""></option>
                </select>
                <label>District <span>*</span></label>
              </div>
              </div>
              
              <div class="col-12 col-sm-6">
              <div class="form-group position-relative error-l-50 floating">
              
               <input type="text" class="form-control mppost" name="mppost" required placeholder=" "value="<?php //if($stuprofile['edupost']!="" && $stuprofile['edupost']!="0"){ echo $stuprofile['edupost'];}else{echo "";} ?>">
            
                <label>Post <span>*</span></label>
              </div>
              </div>
              
              <div class="col-12 col-sm-6">
              <div class="form-group position-relative error-l-50 floating">
                <input type="text" class="form-control" name="mppincode" required placeholder=" "value="<?php //if($stuprofile['edupincode']!="" && $stuprofile['edupincode']!="0"){ echo $stuprofile['edupincode'];}else{echo "";} ?>">
                 <label>Pincode <span>*</span></label>
              </div>
			</div>
              
              <div class="col-12"> <p class="text-muted font-weight-semibold">Marks/Grade Obtained:</p></div>
              
              <div class="col-12 col-sm-6">
              <div class="form-group position-relative error-l-50 floating">
                <select class="form-control mpexamboard" name="mpexamboard" required value="">
                  <option value=""></option>
                  <option value="CBSE">CBSE</option>
                  <option value="SSLC">SSLC</option>
                  <option value="ISC">ISC</option> 
                  <option value="Others">Others</option>                 
                </select>
                <label>Exam Board <span>*</span></label>
              </div>
              
              <div class="form-group position-relative error-l-50 floating">
                <select class="form-control mpexamclass" name="mpexamclass" required value="">
                  <option value=""></option>
                   <option value="5th Standard">5th Standard</option><option value="8th Standard">8th Standard</option><option value="9th Standard">9th Standard</option><option value="X Standard">X Standard</option><option value="XII Standard">XII Standard</option>                  
                </select>
                <label>Exam Class <span>*</span></label>
              </div>
              
              <div class="form-group position-relative error-l-50 floating">
                <input type="text" class="form-control" name="mpgradepercent" required placeholder=" " value="<?php //if($stuprofile['gradepercent']!="" && $stuprofile['gradepercent']!="0"){ echo $stuprofile['gradepercent'];}else{echo "";} ?>">
                 <label>Grade/Percentage <span>*</span></label>
              </div>
			</div> -->  
             
              <!--<div class="col-12 col-sm-6">
              <div class="form-group position-relative error-l-50 floating">
                <select class="form-control mpmedium" name="mpmedium" required value="">
                  <option value="">Educational Qualification List</option>
                 <?php //echo $qualificationoption;?>                
                </select>
                <label>Educational Qualification List <span>*</span></label>
              </div>
              </div>-->  
              
              <div class="col-12 col-sm-6">
                	
                 	<div class="row">
						<div class="col-md-12">
						  <div class="form-group position-relative error-l-50 floating">

						<div id="drop-zone">
							<div class="dropzone-wrapper">
							  <div class="dropzone-desc" id="clickHere">
								<i class="icon-upload mb-2"></i>
								<p class="list-item-heading mb-1">Upload Marksheets (Optional)</p>
								  <p class="text-muted mb-2">Max each file size upto 1MB. File format JPG, PNG and PDF only.</p>
							  </div>
							  <input type="file" name="file[]" id="file" class="dropzone" multiple>
							</div>

								<div id='filename'><?php echo $marksheetlist;?></div>
							  </div>
						  </div>
						</div>
					  </div>
             
			</div>
              
              <!--<div class="col-12">
              <div class="form-group position-relative error-l-50 floating">
                <input type="text" class="form-control" name="mpprefersubject" required placeholder=" " value="<?php //if($stuprofile['preferredsubject']!="" && $stuprofile['preferredsubject']!="0"){ echo $stuprofile['preferredsubject'];}else{echo "";} ?>">
                 <label>Preferred Subject <span>*</span></label>
              </div>
			</div>
              
              <div class="col-12 col-sm-6">
              <div class="form-group position-relative error-l-50 floating">
                <select class="form-control mpscholarship" name="mpscholarship" value="">
                  <option value=""></option>
                  <option value="Test">Test</option>                  
                </select>
                <label>Eligibility Scholarship</label>
              </div>
              </div>
              
              <div class="col-12 col-sm-6">
              <div class="form-group position-relative error-l-50 floating">
                <select class="form-control mpmedium" name="mpmedium" required value="">
                  <option value=""></option>
                  <option value="CBSE">CBSE</option>
                  <option value="SSLC">SSLC</option>
                  <option value="ISC">ISC</option> 
                  <option value="Others">Others</option>                  
                </select>
                <label>Medium <span>*</span></label>
              </div>
              </div>
              
			<div class="col-12"> <p class="text-muted font-weight-semibold">If you are enrolling for mock text then please enter your rollno. of NEET/JEE Mains/JEE Advance. </p></div>
              
              <div class="col-12 col-sm-6">
              <div class="form-group position-relative error-l-50 floating">
                <select class="form-control mpmocktype" name="mpmocktype" value="">
                  <option value=""></option>
                  <option value="Test">Test</option>                  
                </select>
                <label>Mock Type </label>
              </div>
              </div>
              
              <div class="col-12 col-sm-6">
              <div class="form-group position-relative error-l-50 floating">
                <input type="text" class="form-control" name="mprollno" placeholder=" " value="<?php //if($stuprofile['rollno']!="" && $stuprofile['rollno']!="0"){ echo $stuprofile['rollno'];}else{echo "";} ?>">
                 <label>Roll No. </label>
              </div>
			</div>-->
              
              			  
			  </div>
                                                 
            </form>
             
              </div>
              
<div id="customButtons6">

	<div class="row yearfee">


		<div class="col-md-5 mb-4">

			<p class="first">Class
				<?php echo $qualification['class'];?> details</p>

			<div class="d-block w-100 p-0">

				<div class="row">

					<div class="col-md-5 col-5">
						<p>Year of Passing:</p>
					</div>

					<div class="col-md-7 col-7">
						<p>
							<?php echo $qualification['yearofpassing'];?>
						</p>
					</div>

				</div>

				<div class="row">

					<div class="col-md-5 col-5">
						<p>Class Name:</p>
					</div>

					<div class="col-md-7 col-7">
						<p>
							<?php echo $qualification['class'];?>
						</p>
					</div>

				</div>

				<div class="row">

					<div class="col-md-5 col-5">
						<p>Board of Exams:</p>
					</div>

					<div class="col-md-7 col-7">
						<p>
							<?php echo $qualification['stream'];?>
						</p>
					</div>

				</div>

				<div class="row">

					<div class="col-md-5 col-5">
						<p>Status:</p>
					</div>

					<div class="col-md-7 col-7">
						<p>
							<?php echo ($qualification['status'] === 'P')?"Passed":"Waiting For Result";?>
						</p>
					</div>

				</div>

				<div class="row">

					<div class="col-md-5 col-5">
						<p>Roll Number:</p>
					</div>

					<div class="col-md-7 col-7">
						<p>
							<?php echo $qualification['rollno'];?>
						</p>
					</div>

				</div>

				<div class="row">

					<div class="col-md-5 col-5">
						<p>Grace Mark:</p>
					</div>

					<div class="col-md-7 col-7">
						<p>
							<?php if($qualification['gracemark'] != '') {echo ($qualification['gracemark'] === 'y')?"Yes":"No";}?>
						</p>
					</div>

				</div>
			</div>
		</div>

		<?php

		if ( $qualification[ 'subject' ] !== '' ) {

			$subject = explode( "|", $qualification[ 'subject' ] );
			$mark = ( $qualification[ 'mark' ] !== '' ) ? explode( "|", $qualification[ 'mark' ] ) : "";
			$grade = ( $qualification[ 'grade' ] !== '' ) ? explode( "|", $qualification[ 'grade' ] ) : "";



			?>
		<div class="col-md-4 mb-4">

			<p class="first">Class
				<?php echo $qualification['class'];?> Marksheet</p>

			<div class="card d-flex d-block w-100 p-3">

				<?php 
                                                                   
					for($i = 0 ; $i < count($subject);$i++) {
					if($subject[$i] ==='') { continue;}
					   $con = ($mark !== '')?$mark[$i]:$grade[$i];
						echo '<div class="row">

							<div class="col-md-5 col-5">
							<p>'.$subject[$i].':</p>
							</div>

							<div class="col-md-7 col-7">
							<p>'.$con.'</p>
							</div>

							</div>';
					}

				?>

			</div>
		</div>

		<?php } ?>

	</div>


	<div class="separator mb-5"></div>

	<?php if($qualification['xii_yearofpassing'] !== '') {?>
	<div class="row yearfee">


		<div class="col-md-5 mb-4">

			<p class="first">Class XII details</p>

			<div class="d-block w-100 p-0">

				<div class="row">

					<div class="col-md-5 col-5">
						<p>Year of Passing:</p>
					</div>

					<div class="col-md-7 col-7">
						<p>
							<?php echo $qualification['xii_yearofpassing']; ?>
						</p>
					</div>

				</div>

				<div class="row">

					<div class="col-md-5 col-5">
						<p>Class Name:</p>
					</div>

					<div class="col-md-7 col-7">
						<p>XII Standard</p>
					</div>

				</div>

				<div class="row">

					<div class="col-md-5 col-5">
						<p>Board of Exams:</p>
					</div>

					<div class="col-md-7 col-7">
						<p>
							<?php echo $qualification['xii_stream']; ?>
						</p>
					</div>

				</div>

				<div class="row">

					<div class="col-md-5 col-5">
						<p>Status:</p>
					</div>

					<div class="col-md-7 col-7">
						<p>
							<?php echo ($qualification['xii_status'] === 'P')?"Passed":"Waiting For Result";?>
						</p>
					</div>

				</div>

				<div class="row">

					<div class="col-md-5 col-5">
						<p>Roll Number:</p>
					</div>

					<div class="col-md-7 col-7">
						<p>
							<?php echo $qualification['xii_rollno']; ?>
						</p>
					</div>

				</div>

				<div class="row">

					<div class="col-md-5 col-5">
						<p>Grace Mark:</p>
					</div>

					<div class="col-md-7 col-7">
						<p>
							<?php if($qualification['xii_gracemark'] != '') {echo ($qualification['xii_gracemark'] === 'y')?"Yes":"No";}?>
						</p>
					</div>

				</div>
			</div>
		</div>

		<?php

		if ( $qualification[ 'xii_subject' ] !== '' ) {

			$xii_subject = explode( "|", $qualification[ 'xii_subject' ] );
			$xii_mark = ( $qualification[ 'xii_mark' ] !== '' ) ? explode( "|", $qualification[ 'xii_mark' ] ) : "";
			$xii_grade = ( $qualification[ 'xii_grade' ] !== '' ) ? explode( "|", $qualification[ 'xii_grade' ] ) : "";



			?>
		<div class="col-md-4 mb-4">

			<p class="first">Class XII Marksheet</p>

			<div class="card d-flex d-block w-100 p-3">

				<?php 
                                                                   
					for($i = 0 ; $i < count($xii_subject);$i++) {
					if($xii_subject[$i] ==='') { continue;}
					$con = ($xii_mark !== '')?$xii_mark[$i]:$xii_grade[$i];
					echo '<div class="row">

						<div class="col-md-5 col-5">
						<p>'.$xii_subject[$i].':</p>
						</div>

						<div class="col-md-7 col-7">
						<p>'.$con.'</p>
						</div>

						</div>';
					}

				?>


			</div>
		</div>
		<?php } ?>

	</div>
	<div class="separator mb-5"></div>

	<?php } ?>


	<div class="row yearfee">


		<?php

		if ( $qualification[ 'entrance_name' ] != "" ) {

			$examArr1 = explode( "|", $qualification[ 'entrance_name' ] );
			$examArr2 = explode( "|", $qualification[ 'entrance_mark' ] );
			$examArr3 = explode( "|", $qualification[ 'entrance_regno' ] );

			foreach ( $examArr1 as $key => $value ) {

				if ( $value === "" ) {
					continue;
				}

				echo '<div class="col-md-5 mb-4">
                                                            

								<p class="first">' . $value . ' - Entrance Exam</p>

								<div class="d-block w-100 p-0">

									<div class="row">

										<div class="col-md-5 col-5">
											<p>Rank/Mark:</p>
										</div>

										<div class="col-md-7 col-7">
											<p>' . $examArr2[ $key ] . '</p>
										</div>

									</div>

									<div class="row">

										<div class="col-md-5 col-5">
											<p>Registration Number:</p>
										</div>

										<div class="col-md-7 col-7">
											<p>' . $examArr3[ $key ] . '</p>
										</div>

									</div>


								</div>
							</div>';
			}
		}

		?>

	</div>

	<?php
		
								$qmarksheets = $qualification['marksheets'];
								$qmarksheetsarr = explode('|',$qmarksheets);

								$qmarksheetlist = "";
								foreach($qmarksheetsarr as $qmarksheet){

									$ext = end(explode(".",$qmarksheet));

									if(strtolower($ext)!="pdf"){
										$qmarksheetlist .= '<div class="col-2"><a href="docs/courserequest/marksheets/'.$user['id'].'/'.$qmarksheet.'?'.time().'"><img class="img-fluid border-radius" src="docs/courserequest/marksheets/'.$user['id'].'/'.$qmarksheet.'?'.time().'"><div class="overlay"></div></a></div>';
									}
									else{
										$qmarksheetlist .= '<div class="col-2"><a href="docs/courserequest/marksheets/'.$user['id'].'/'.$qmarksheet.'?'.time().'" target="_blank"><span class="text">pdf</span><i class="glyph-icon simple-icon-doc"></i><div class="overlay"></div></a></div>';
									}

								}
			
							?>
        
							<?php if($qmarksheets!="" && $qmarksheets!="0"){?>
						   
						   <div class="mb-4 qmarksheet">

								<div class="row">

									  <div class="col-12">

											<p class="list-item-heading pb-2">Marksheets:</p>

											<div class="row gallery px-4 mb-4">
											  <?php echo $qmarksheetlist;?>
											</div>

									  </div>

								 </div>

							</div> 

							<?php }?>

	<div class="mb-5"></div>

</div>
              
              <div id="customButtons3">
                
                <h3 class="mb-3">Enter Communication Contact (For Postal Communication)</h3>
                
                <form id="form-step-3" class="tooltip-right-bottom mb-4" novalidate>
             
             <div class="row">
             
            
                            
              <div class="col-12 col-sm-6">
              <div class="form-group position-relative error-l-50 floating">
                <input type="text" class="form-control mpcontacthouseno" name="mpcontacthouseno" required placeholder=" " value="<?php if($stuprofile['housenameno']!="" && $stuprofile['housenameno']!="0"){ echo $stuprofile['housenameno'];}else{echo "";} ?>">
                 <label>House / Appartment Name <span>*</span></label>
              </div>
			</div>
             
              <!--<div class="col-12 col-sm-6">
               <div class="form-group position-relative error-l-50 floating">
                <input type="text" class="form-control mpcontactlandmark" name="mpcontactlandmark" placeholder=" " value="<?php //if($stuprofile['landmark']!="" && $stuprofile['landmark']!="0"){ echo $stuprofile['landmark'];}else{echo "";} ?>">
                <label>Landmark</label>
              </div>
              </div>-->
              
              <div class="col-12 col-sm-6">
				  <div class="form-group position-relative error-l-50 floating">
					<input type="text" class="form-control mpcontactaddressline" name="mpcontactaddressline" required placeholder=" " value="<?php if($stuprofile['contactaddress']!="" && $stuprofile['contactaddress']!="0"){ echo $stuprofile['contactaddress'];}else{echo "";} ?>">
					 <label>Place / Street <span>*</span></label>
				  </div>
			  </div>
              
              <div class="col-12 col-sm-6">
              <div class="form-group position-relative error-l-50 floating">
               <input type="text" class="form-control mpcontactpost" name="mpcontactpost" required placeholder=" " value="<?php if($stuprofile['contactpost']!="" && $stuprofile['contactpost']!="0"){ echo $stuprofile['contactpost'];}else{echo "";} ?>">
               <!-- <select class="form-control mpcontactpost" name="mpcontactpost" required value="">
                  <option value=""></option>
                  <option value="Post">Post</option>                  
                </select>-->
                <label>Post Office <span>*</span></label>
              </div>
              </div>              
              
              <div class="col-12 col-sm-6">
              <div class="form-group position-relative error-l-50 floating">
                             
                <select class="form-control mpcontactcountry" name="mpcontactcountry" required value="">
                   <?php echo $countrylist['countryoption'];?>           
                </select>
                <label>Country <span>*</span></label>
              </div>
              </div>
              
             <div class="col-12 col-sm-6">
              <div class="form-group position-relative error-l-50 floating constatelist">
                <select class="form-control mpcontactstate" name="mpcontactstate" required value="">
                  <?php //echo $statelist['stateoption'];?>
                </select>
                <label>State <span>*</span></label>
              </div>
              </div>
              
              <div class="col-12 col-sm-6">
              <div class="form-group position-relative error-l-50 floating">
               	<input type="text" class="form-control mpcontactdistrict" name="mpcontactdistrict" required placeholder=" " value="<?php if($stuprofile['contactdistrict']!="" && $stuprofile['contactdistrict']!="0"){ echo $stuprofile['contactdistrict'];}else{echo "";} ?>">
                <!--<select class="form-control mpcontactdistrict" name="mpcontactdistrict" required value="">
                  <option value=""></option>
                </select>-->
                <label>District <span>*</span></label>
              </div>
              </div>
              
              <div class="col-12 col-sm-6">
              <div class="form-group position-relative error-l-50 floating">
                <input type="text" class="form-control mpcontactpincode" name="mpcontactpincode" required placeholder=" " value="<?php if($stuprofile['contactpincode']!="" && $stuprofile['contactpincode']!="0"){ echo $stuprofile['contactpincode'];}else{echo "";} ?>">
                 <label>Pincode <span>*</span></label>
              </div>
			</div>
             			  
             	<div class="col-12 col-sm-6">
              
              <div class="form-row">
              
				  <div class="form-group col-md-3 position-relative error-l-50">
					<select class="form-control mpwacode" name="mpwacode" required >
					  <option value="+91">+91</option><option value="44">+44</option><option value="65">+65</option><option value="+973">+973</option><option value="+20">+20</option><option value="+98">+98</option><option value="+964">+964</option><option value="+972">+972</option><option value="+962">+962</option><option value="+965">+965</option><option value="+961">+961</option><option value="+968">+968</option><option value="+970">+970</option><option value="+974">+974</option><option value="+966">+966</option><option value="+90">+90</option><option value="+971">+971</option><option value="+967">+967</option><option value="+93">+93</option><option value="+374">+374</option><option value="+994">+994</option><option value="+76">+76</option><option value="+996">+996</option><option value="+92">+92</option><option value="+963">+963</option><option value="+992">+992</option><option value="+993">+993</option><option value="+998">+998</option><option value="+357">+357</option><option value="+253">+253</option><option value="+291">+291</option><option value="+995">+995</option><option value="+352">+352</option><option value="+249">+249</option>
					</select>
				  </div>
             
				  <div class="form-group col-md-9 position-relative error-l-50 floating">
					<input type="number" class="form-control mpwhatsappno" name="mpwhatsappno" minlength="10" maxlength="10" required placeholder=" "  value="<?php if($stuprofile['whatsappno']!="" && $stuprofile['whatsappno']!="0"){ echo $stuprofile['whatsappno'];}else{echo "";} ?>">
					<label>Whatsapp Number <span>*</span></label>
				  </div>
              
			   </div>
             
				 </div>	
              
              <div class="col-12 col-sm-6">
              <div class="form-group position-relative error-l-50 floating">
                <input type="text" class="form-control mpguardianname" name="mpguardianname" placeholder=" " value="<?php if($stuprofile['guardianname']!="" && $stuprofile['guardianname']!="0"){ echo $stuprofile['guardianname'];}else{echo "";} ?>" required>
                 <label>Guardian Name <span>*</span></label>
              </div>
			</div>	  
              			  
			  </div>
                                                 
            </form>
             
              </div>
              <div id="customButtons4">
                
                <h3 class="mb-3">Enter Student Account Details (Indian Accounts except NRI, NRE, NRO)</h3>
                
                <form id="form-step-4" class="tooltip-right-bottom mb-4" novalidate>
             
             <div class="row">
                                         
              <div class="col-12 col-sm-6">
              <div class="form-group position-relative error-l-50 floating">
                <input type="text" class="form-control mpaccholdername" name="mpaccholdername" placeholder=" " value="<?php if($stuprofile['accountholdername']!="" && $stuprofile['accountholdername']!="0"){ echo $stuprofile['accountholdername'];}else{echo "";} ?>">
                 <label>Account Holder Name</label>
              </div>
			</div>
                                         
              <div class="col-12 col-sm-6">
              <div class="form-group position-relative error-l-50 floating">
               
               	<input type="text" class="form-control mpbankname" name="mpbankname" placeholder=" " value="<?php if($stuprofile['bankname']!="" && $stuprofile['bankname']!="0"){ echo $stuprofile['bankname'];}else{echo "";} ?>">
                <!--<select class="form-control mpbankname" name="mpbankname" placeholder=" ">
                  <option value=""></option>
                  <option value="HDFC">HDFC</option>
                  <option value="State Bank of India">State Bank of India</option>
                  <option value="ICICI">ICICI</option>                  
                </select>-->
                <label>Bank Name</label>
              </div>
              </div>
              
             <div class="col-12 col-sm-6">
              <div class="form-group position-relative error-l-50 floating">
                <input type="text" class="form-control mpbranch" name="mpbranch" placeholder=" " value="<?php if($stuprofile['branch']!="" && $stuprofile['branch']!="0"){ echo $stuprofile['branch'];}else{echo "";} ?>">
                 <label>Branch</label>
              </div>
			</div>
             
              <div class="col-12 col-sm-6">
               <div class="form-group position-relative error-l-50 floating">
                <input type="text" class="form-control mpifsccode" name="mpifsccode" placeholder=" " value="<?php if($stuprofile['ifsccode']!="" && $stuprofile['ifsccode']!="0"){ echo $stuprofile['ifsccode'];}else{echo "";} ?>">
                <label>IFSC Code</label>
              </div>
              </div>
             
              <div class="col-12 col-sm-6">
               <div class="form-group position-relative error-l-50 floating">
                <input type="number" class="form-control mpaccountnumber" name="mpaccountnumber"  maxlength="18" placeholder=" " value="<?php if($stuprofile['bankaccountno']!="" && $stuprofile['bankaccountno']!="0"){ echo $stuprofile['bankaccountno'];}else{echo "";} ?>">
                <label>Bank Account Number</label>
              </div>
              </div>
             
              <div class="col-12 col-sm-6">
               <div class="form-group position-relative error-l-50 floating">
                <input type="number" class="form-control mpreenteraccountnumber" name="mpreenteraccountnumber" maxlength="18" placeholder=" " value="<?php if($stuprofile['bankaccountno']!="" && $stuprofile['bankaccountno']!="0"){ echo $stuprofile['bankaccountno'];}else{echo "";} ?>">
                <label>Re-Enter Bank Account Number</label>
              </div>
              </div>
             
                       			  
			  </div>
                                                 
            </form>
             
              </div>
              
              <?php if($action=="register"){?>
              
              <?php 
				
					//print_r($studentcoursepay);
	
					$tablepay = $tablepaynow = "";
					$sno = $psno = 1;
	
					$grandtotal = $grandtotalnow = 0;
					$checkdiscount = $kfcheck = false;
	
					foreach($feesmaster as $key=>$feemaster){
												
						foreach($coursepay as $paylist){
						
							if($feemaster['description'] == $paylist['description']){
						
						$refund = $paylist['refundpolicy'];
						$amount = $paylist['amount'];
						$total = $paylist['total'];
						$taxable = $paylist['taxable'];
						$kf = $paylist['kf'];
						$cov = $paylist['cov'];
						$sac = 999293;
						
						$discountamt = 0;$thdiscount = $tddiscount = $thtax =  $tdtax = $thcov =  $tdcov = "";
						$taxamt = 0;
						$colspan=9;

						$tax = $paylist['tax'];
						$discount = $paylist['discount'];
								
						$activetotalamt = $amount;		
						
						if(intval($discount)>0) {
							
							$discountamt = $discount;
							$tddiscount = '<td width="12%">'.$discountamt.'</td>';
							
							$amount = $amount - $discount;
							
							$checkdiscount = true;
							
						}else{
							$tddiscount = '<td>[DISCOUNT]</td>';
						}
						
						if($tax=="0" || $tax=="NA"){
							$tdnontaxable = $amount;
						}else{
							$tdnontaxable = 0;
						}

						if($tax!="0" && $tax!="NA"){ 

							$tdtaxable = $amount;				

							$taxgst = $tax/2;
							if(intval($tax)>0) $taxamt = $amount * ($tax/100);
							$taxamtgst = $taxamt/2;
							$taxamtgst = number_format($taxamtgst,2);

							//$colspan +=4;

						} else {
							$tdtaxable = 0;
							$taxgst = $taxamtgst = "NA";
						}

						$thtax = '<th scope="col" colspan="2" width="15%"><span class="thtax">CGST</span> <span class="thtaxvalue"><span>Rate %</span> <span>Amount</span></span></th>
							  <th scope="col" colspan="2" width="15%"><span class="thtax">SGST</span> <span class="thtaxvalue"><span>Rate %</span> <span>Amount</span></span></th>';

						$tdtax = '<td width="8%">'.$taxgst.'</td>
								  <td width="8%">'.$taxamtgst.'</td>
								  <td width="8%">'.$taxgst.'</td>
								  <td width="8%">'.$taxamtgst.'</td>';

								
						$tdkf = $thkf = ""; $colwidth = 15;
						if(($kf!="" && $kf!="0") || $kfcheck){
							
							$kfamt = $amount * ($kf/100);
							
							$thkf = '<th scope="col" width="8%">CESS KF(%)</th>
                  					 <th scope="col" width="8%">CESS KF Amount</th>';
							$tdkf = '<td width="12%">'.$kf.'</td>
									 <td width="8%">'.$kfamt.'</td>';
							
							$kfcheck = true;
							
							$colspan += 2;
							$colwidth -= 5;
						}		
						
						if($cov!="0" && $cov!="NA"){
							$thcov = '<th scope="col" width="15%">CESS COV(%)</th>';
							$covamt = $amount * ($cov/100);
							$tdcov = '<td width="15%">'.$covamt.'%</td>';
							$colspan +=1;
						}
						
						
						$grandtotal += $total;
						
						$tablepay .= '<tr>
									  <th scope="row" width="7%">'.$sno.'</th>
									  <td width="15%"><strong>'.$paylist['description'].'</strong></td>
									  <td width="11%">'.$activetotalamt.'</td>
									  <td width="11%">'.$tdnontaxable.'</td>
									  <td width="11%">'.$tdtaxable.'</td>
									  '.$tddiscount.'
									  '.$tdtax.'
									  '.$tdkf.'
									  '.$tdcov.'
									  <td width="10%">'.number_format($total,2).'</td>
									</tr>';
						
						
						/*if(empty($studentcoursepay)){
							
							$grandtotalnow += $total;

							$tablepaynow .= '<tr>
										  <th scope="row">'.$psno.'</th>
										  <td><strong>'.$paylist['description'].'</strong></td>
										  <td>'.number_format($total,2).'</td>
										</tr>';

							$psno++;
							
						}*/
						
						
						$sno++;
					}
							
						}
					}
	
	
					if($checkdiscount){ 
						$thdiscount = '<th scope="col" width="12%">Discount</th>';
						$tablepay = str_replace("<td>[DISCOUNT]</td>",'<td width="12%">0</td>',$tablepay);
						$colspan +=1;
					}
					else {
						$tablepay = str_replace("<td>[DISCOUNT]</td>",'',$tablepay);
					}
		
	
					$partialamt = $partialpaydetails['partialamt'];
					$partialstatus = $partialpaydetails['status'];
					$partialbalance = $partialamt;
	
					foreach($feesmaster as $key=>$feemaster){
						
						foreach($studentcoursepay as $stupaylist){
						
						if($feemaster['description'] == $stupaylist['description'] && $partialstatus=="a"){
							
							$amount = $stupaylist['amount'];
							$total = $stupaylist['grandtotal'];	
							
							if($partialbalance>0 ){
							
								if($partialamt>$total){ 
									$partialamt = $partialamt - $total;
									$partialbalance = $partialamt;
								}
								else{ 
									$total = $partialamt;
									$partialbalance = 0;
								}
														
								$grandtotalnow += $total;
								
								$tablepaynow .= '<tr>
										  <th scope="row">'.$psno.'.</th>
										  <td><strong>'.$stupaylist['description'].'</strong></td>
										  <td>'.number_format($total,2).'</td>
										</tr>';

								$psno++;							
							}
							
						}else if($feemaster['description'] == $stupaylist['description'] && $partialstatus==""){
							
							
							$amount = $stupaylist['amount'];
							$total = $stupaylist['grandtotal'];	
																					
							$grandtotalnow += $total;
								
								$tablepaynow .= '<tr>
										  <th scope="row">'.$psno.'.</th>
										  <td><strong>'.$stupaylist['description'].'</strong></td>
										  <td>'.number_format($total,2).'</td>
										</tr>';

								$psno++;							
							
						}
	
						
						}
						
					}
				
				?>
              
              <div id="customButtons5" class="feesstructure">
                
                <table class="table">
              <thead>
                <tr>
                  <th scope="col" width="5%">Sl. no.</th>
                  <th scope="col" width="15%">Description</th>
                  <th scope="col" width="8%">Total Fee</th>
				  <th scope="col" width="<?php echo $colwidth;?>%">Non Taxable Value</th>
				  <th scope="col" width="<?php echo $colwidth;?>%">Taxable Value</th>
				  <?php echo $thdiscount;?>
				  <?php echo $thtax;?>
				  <?php echo $thkf;?>
				  <?php echo $thcov;?>
                  <th scope="col" width="20%">Total</th>
                </tr>
              </thead>
              <tbody>
                
                <?php echo $tablepay; ?>
                
                <tr>
                  <td colspan="<?php echo $colspan;?>" class="totalamt">Grand total</td>
                  <td class="totalfee"><?php echo number_format($grandtotal,2); ?></td>
                </tr>
              </tbody>
            </table>
               
               				
			  <div class="mb-4"></div>	
			  
			  <?php if($tablepaynow!=""){?>	  				    				  		  				    				  
			  <div class="row">

			  <div class="col-md-6">
                
              <h3 class="title my-4">Amount to be Remitted now</h3>
                
              <table class="table">
              <thead>
                <tr>
                  <th scope="col">Sl. no.</th>
                  <th scope="col">Fee description</th>
                  <th scope="col">total</th>
                </tr>
              </thead>
              <tbody>
                <!--<tr>
                  <th scope="row">1</th>
                  <td><strong>Registration Fee</strong></td>
                  <td>40,000</td>
                </tr>-->
                
                <?php echo $tablepaynow;?>
                
                <tr>
                  <td></td>
                  <td class="totalamt">Grand total</td>
                  <td class="totalfee"><?php echo number_format($grandtotalnow,2); ?></td>
                </tr>
              </tbody>
            </table>
             
					</div>
             
					<div class="col-md-6">
						
						<h3 class="title my-4">Select payment method</h3>
						
						<div class="form-group">
						  <div>
							  <div class="custom-control custom-radio col-sm-5">
								<input type="radio" id="paymethod1" name="paymethod" class="custom-control-input" value="online" required="">
								<label class="custom-control-label" for="paymethod1">Online Payment</label>
							  </div>
							  <div class="custom-control custom-radio col-sm-5">
								<input type="radio" id="paymethod2" name="paymethod" class="custom-control-input" value="offline" required="">
								<label class="custom-control-label" for="paymethod2">Offline Payment</label>
							  </div>
						</div>
					  </div>
					  
						<a href="stumyprofile/downloadChallan?id=<?php echo $cride;?>&challan=unpaid" target="_blank" title="Download Challan" class="challanbtn d-none checkrefund" data-btntype="challan"><button class="btn btn-primary mt-4"><i class="icon-download"></i> Download Challan</button></a>
						
					</div>
            
				  </div>
            
            		<?php }?>
             
              </div>
              
              <?php }?>
              
            </div>
            		
            <div class="btn-toolbar custom-toolbar text-center card-body pt-0 mb-5">
				<button class="btn btn-outline-primary prev-btn d-none mb-5" type="button"><i class="icon-arrow-left mr-2"></i> Previous</button>
				<button class="btn btn-primary next-btn mb-5" type="button">Next <i class="icon-arrow-right ml-2"></i></button>
				<?php if($action=="profileedit"){?>
         			<button class="btn btn-primary finish-btn d-none mb-5" type="button">Finish <i class="icon-arrow-right ml-2"></i></button>
          		<?php }else{?>
					<a href="stufeepayments/onlinepayment?id=<?php echo $cride;?>" title="Pay now" class="payment-btn d-none checkrefund" data-btntype="paynow"><button class="btn btn-primary mb-5" type="button">Proceed to Pay <i class="icon-arrow-right ml-2"></i></button></a>
           			<button class="btn btn-primary submit-btn d-none mb-5" type="button">Submit Profile <i class="icon-arrow-right ml-2"></i></button>
           		<?php }?>
            </div>
            
          </div>
        </div>
            
			<p class="alert"></p>
        
      </div>
	
		
	</div>
	
	<div id="refundModal" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
			
				<div class="modal-header">
			   		<h2 class="modal-title">Refund Policy</h2>
				   <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				</div>
				<div class="modal-body text-left">
											
					<?php echo $refund;?>
									
					<input type="hidden" id="btntype" value="" />
					<input type="hidden" id="payurl" value="" />											
										
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-primary iagree">I Agree</button>
					<button type="button" class="btn btn-outline-primary modalclose" data-dismiss="modal">Close</button>
				</div>
								
			</div>
		</div>
	</div>
	
	<style>
		
		#profileupdateModal.modal .modal-header{padding: 10px 20px !important;border: none}	
		#profileupdateModal.modal .modal-body{padding:0 1.75rem 1.75rem}
		.modal-body p{text-align: left !important}
		.modal-backdrop.show {opacity: .5 !important;}
		
	</style>
	
	<div id="profileupdateModal" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
				   <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				</div>
				<div class="modal-body text-center">
									
					<img src="css/img/brilliant-logo.png" alt="Payment Success" class="mb-4" />
					<h2 class="mb-4">Profile details updated successful.</h2>
					
				</div>
				<div class="modal-footer">
					<!--<a href="#" target="_blank"><button type="button" class="btn btn-primary">View Bill</button></a>-->
					<button type="button" class="btn btn-outline-primary modalclose" data-dismiss="modal">Close</button>
				</div>
								
			</div>
		</div>
	</div>
	
	<div id="changeProfilePhotoModal" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
				   <h5 class="modal-title" id="changeProfilePhotoModal">Profile Photo</h5>
				   <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				</div>
				<div class="modal-body">
					<form id="cropImage" method="post" enctype="multipart/form-data" action="#">
						
						<div class="row">
						<div class="col-md-12">
						  <div class="form-group position-relative error-l-50 floating">

						<div id="drop-zone">
							<div class="dropzone-wrapper">
							  <div class="dropzone-desc" id="clickHere">
								<i class="icon-upload mb-2"></i>
								<p class="list-item-heading text-center mb-1">Upload Image</p>
								  <p class="text-muted text-center mb-2">Upload passport photo in jpeg, jpg or png format below 300 KB.</p>
							  </div>
							  <input type="file" name="profileImage" id="profileImage" class="dropzone">
							</div>

							  </div>
						  </div>
						</div>
					  </div>
					
						<input type="hidden" name="studentid" id="studentid" value="<?php echo $user['id']; ?>" />
						<input type="hidden" name="hdn-x1-axis" id="hdn-x1-axis" value="" />
						<input type="hidden" name="hdn-y1-axis" id="hdn-y1-axis" value="" />
						<input type="hidden" name="hdn-x2-axis" value="" id="hdn-x2-axis" />
						<input type="hidden" name="hdn-y2-axis" value="" id="hdn-y2-axis" />
						<input type="hidden" name="hdn-thumb-width" id="hdn-thumb-width" value="" />
						<input type="hidden" name="hdn-thumb-height" id="hdn-thumb-height" value="" />
						<input type="hidden" name="action" value="" id="action" />
						<input type="hidden" name="imageName" value="" id="imageName" />						
						<div id='previewProfilePhoto' class="text-center"></div>
						<div id="thumbs" style="padding:5px; width:600p"></div>
						
					</form>
					
					<p class="alert"></p>
					
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-outline-primary modalclose" data-dismiss="modal">Close</button>
					<button type="button" id="savePic" class="btn btn-primary">Save</button>
					<!--<button type="button" id="savePhoto" class="btn btn-primary">Crop & Save</button>-->
				</div>
								
			</div>
		</div>
	</div>


<div id="IDcardpreivewModal" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
	<div class="modal-dialog" role="document">
		<div class="modal-content">

			<div class="modal-header">
				<h2 class="modal-title">ID Card Preview</h2>
			   <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
			</div>
			<div class="modal-body text-center idcardpreview">

															

			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-outline-primary modalclose" data-dismiss="modal">Close</button>
			</div>

		</div>
	</div>
</div>

	</div>
</main>
<script src="<?php echo base_url();?>js/vendor/jquery.smartWizard.min.js"></script>
<link rel="stylesheet" href="<?php echo base_url();?>css/boot/vendor/baguetteBox.min.css">
<script src="<?php echo base_url();?>js/vendor/baguetteBox.min.js"></script>

<script type="text/javascript">
$(document).ready(function(){
	
	$("#smartWizardClickable").on("showStep", (function (e, t, a, n, o) {
		
		if(a==1) $(".marksheet").removeClass('d-none');
		else $(".marksheet").addClass('d-none');
	}));
	
	$(".idcardpreviewbtn").click(function(e){
		
		var profilepercent = "<?php echo $stuprofile['profilepercent'];?>";
		
		if(profilepercent!="100"){alert("Complete profile");return false;}
								
		$.ajax({
		type: 'GET',
		url: 'downloadidcard',
		data: {"ptype":"preview"},
		success: function(response) {

				$('#IDcardpreivewModal').modal({show:true});
				$(".idcardpreview").html(response);
			
			}

		});
		
		
	});
	
});
</script>

<style>
		
	.regcourses h1{font-size: 18px;color: #364159;}
	.myprofile .card{background: linear-gradient(0deg, #FFFFFF, #FFFFFF), #C4C4C4;box-shadow: 0px 0px 7px rgba(196, 196, 196, 0.35);border-radius: 10px;}
	.regcourses h2,h2.modal-title{color: #0332AA;font-size: 24px;font-weight: bold;line-height: 36px;}
	.regcourses p.list-item-heading{color: #6884CC;font-weight: 600;}
	.regcourses p.list-item-heading span:last-child{font-weight: 600;font-size: 14px;color: #364159;}
	
	.border-right{border-right: 1px solid #D7DFF0!important;}
		
	.btn-primary{width: auto}
	.btn-primary.disabled, .btn-primary:disabled{background: #9AADDD;color: #ffffff;}
	
	.card h5{margin-bottom: 1rem;}
	h5{font-weight: bold;}
	.badge-outline-secondary, .badge-outline-theme-2{border: 1px solid #889DC6;color: #889DC6;background: #F6F7FA;}
	.badge{font-size: 12px;margin-right: 5px}
	
	.courseinfo .col-right .card .card-body{padding: 0;}
	.courseinfo .border-bottom{border-bottom: 1px solid #D7DFF0!important;}
	.col-right h5{padding: 1.2rem}
 
	.icon-status{background: url("img/icons/status-b.png") no-repeat;width: 15px;height: 15px;display: inline-block;vertical-align: middle}
	
	td.totalfee {font-weight: bold;font-size: 16px;color: #D63333;}
	
	.profilename{font-size: 24px;color: #181E29;line-height: 36px;}
	.progress-percent{font-size: 14px;color: #0332AA;}
	.profileedit{background: #0332AA;border: 3px solid #ffffff;width: 35px;height: 35px;border-radius: 50%;position: absolute;bottom: 20px;right: 20px;}
	.icon-edit{background: url("img/icons/edit.png") no-repeat;width: 14px;height: 14px;display: inline-block;vertical-align: middle;position: absolute;top: 27%;left: 27%;}
	
	.custom-control{display: inline-block}
	
	.icon-arrow-left{background: url("img/icons/leftarrow-btn.png") no-repeat;width: 6px;height: 10px;display: inline-block;vertical-align: middle;}
	.icon-arrow-right{background: url("img/icons/rightarrow-btn.png") no-repeat;width: 6px;height: 10px;display: inline-block;vertical-align: middle;}
	
	.table{border: 1px solid #D7DFF0;border-collapse: collapse}
	.table thead th{font-size: 12px;font-weight: bold;color: #6F83AA;letter-spacing: 0.5px;background: #E6EBF7;text-transform: uppercase}
	.table td, .table th{border-top: 1px solid #D7DFF0;}
	
	.next-btn,.payment-btn{float: right}
	.prev-btn{float: left}
	
	.btn-outline-primary:not(:disabled):not(.disabled).active .icon-arrow-left, .btn-outline-primary:not(:disabled):not(.disabled):active .icon-arrow-left,.btn-outline-primary:hover .icon-arrow-left{filter: contrast(0.2) brightness(2);}
		
	.sw-main.sw-theme-dots>ul.step-anchor.mpregister>li{width: 20%;}
	.sw-main.sw-theme-dots>ul.step-anchor.mpregister>li>a i{left: 42%;}
	
	.btn-toolbar{display: none}
	.sw-main.sw-theme-default .row .row div p{font-size: 14px;font-weight: 600;margin-bottom: 2rem;}	
	.sw-main.sw-theme-default .row .row div:first-child p{color: #6884CC;}	
	.sw-main.sw-theme-default .row .row div:last-child p{color: #364159;}
	.sw-main.sw-theme-default .row .row div p.empty{color: #D7DFF0;}
	
	.marksheet p.list-item-heading,.qmarksheet p.list-item-heading{color: #6884CC;font-weight: 600;}
	.marksheet img,.qmarksheet img{width: 100px;height: 130px;}
	.marksheet .gallery .col-2,.qmarksheet .gallery .col-2{position: relative;padding: 0;margin: 1rem;max-width: 10% !important}
	.marksheet .overlay,.qmarksheet .overlay{background: rgba(83, 100, 133,0.6) url(img/icons/eye.png) no-repeat center;width: 100%;height: 100%;position: absolute;border-radius: 0.75rem;top: 0;}
		
	.myprofile .img-thumbnail{width: 115px;height: 115px}
	
	.gallery a{text-align: center}
	.gallery a i{font-size: 4rem;padding: 1.5rem 0;display: block}
	.gallery a span.text{font-size: 10px;position: absolute;top: 28%;left: 14%;background: #ff0000;color: #fff;text-transform: uppercase;padding: 0px 7px;font-weight: bold;}
	
	@media (max-width:767px){
		
		.marksheet .gallery .col-2,.qmarksheet .gallery .col-2{max-width: 100% !important;}
	}
	
	/* Qualification */
	.yearfee .card{background: #F6F7FA;border: 1px solid #BCCAE8;box-shadow: none}
	.yearfee p{margin-bottom: 1.5rem}
	.yearfee p.first,.yearfee p.second{font-weight: bold;font-size: 14px;color: #0332AA;text-align: left;text-transform: uppercase;}
	.yearfee .row div:last-child p{font-size: 14px;font-weight: 600;color: #364159;}
	.yearfee p.list-item-heading,.yearfee .row div:first-child p{color: #6884CC;font-weight: 600;}
	
	.idcardrow{margin: 0px auto !important}
	
</style>


<main>

	<div class="container-fluid">
		
		<div class="col-12 mb-4 myprofile">
                   
			<div class="card mb-4">
				
				<div class="row">
          
          <div class="col-md-6 col-sm-12 col-lg-8 col-12">
           
            <div class="d-flex flex-row">
             
				<a class="d-flex position-relative" href="#"><img alt="Profile" src="<?php if($stuprofile['profilepic']!="0" && $stuprofile['profilepic']!=""){ echo "docs/profilepic/".$user['id']."/".$stuprofile['profilepic']."?".time();}else{echo "img/myprofile.png?".time();} ?>" class="img-thumbnail border-0 rounded-circle m-4 align-self-center"> <!--<span class="profileedit"><i class="icon-edit"></i></span>--></a>
             
              <div class="d-flex flex-grow-1 min-width-zero">
                <div class="card-body pl-0 align-self-center d-flex flex-column flex-lg-row justify-content-between min-width-zero">
                  <div class="w-100">
                   <a href="#">
                    <p class="list-item-heading mb-2 truncate font-weight-bold profilename"><?php echo ucwords($stuprofile['stuname']); ?></p>
                    </a>
                    <p class="mb-2 text-small font-weight-semibold progress-percent">Profile Completeness: <span class="progressnum font-weight-bold"><?php if($stuprofile['profilepercent']!=0){ echo $stuprofile['profilepercent'];}else{echo 0;} ?>%</span></p>
					<div class="progress">
					  <div class="progress-bar" role="progressbar" style="width: <?php if($stuprofile['profilepercent']!=0){ echo $stuprofile['profilepercent'];}else{echo 0;} ?>%" aria-valuenow="<?php if($stuprofile['profilepercent']!=0){ echo $stuprofile['profilepercent'];}else{echo 0;} ?>" aria-valuemin="0" aria-valuemax="100"></div>
					</div>
                  </div>
                </div>
              </div>
            </div>
            
          </div>
          
          <div class="col-md-6 col-sm-12 col-lg-4 col-12 d-flex align-items-center justify-content-end">
           
           <div class="row w-100">
             
             	<div class="col-md-6">
					<button type="button" class="btn btn-primary idcardpreviewbtn">ID Card</button>
				</div>
             
             	<div class="col-md-6">
             		<a href="stumyprofile?action=profileedit" title="Complete Profile"><button type="button" class="btn btn-primary"><?php if($stuprofile['profilepercent']=="100"){ echo "Update";}else{echo "Complete";} ?> Profile</button></a>
				</div>
           
            </div><!--
            
            <div class="mr-4">
             
				<a href="stumyprofile?action=profileedit" title="Complete Profile"><button type="button" class="btn btn-primary">Complete Profile</button></a>
             
            </div>-->
            
          </div>
          
        </div>
				
			</div>
            
            <div class="card mb-4">
          <div id="smartWizardClickable">
            <ul class="card-header border-bottom">
              <li><a href="#customButtons1">Personal Details</a></li>
              <li><a href="#customButtons2">Educational Details</a></li>
              <li><a href="#customButtons5">Qualification Details</a></li>
              <li><a href="#customButtons3">Contact Details</a></li>
              <li><a href="#customButtons4">Bank Details</a></li>
            </ul>
            <div class="card-body">
              <div id="customButtons1">
             
             <div class="row">
             
             <div class="col-12 col-sm-6">
                <div class="row">

					<div class="col-md-5 col-5">
						<p>Name:</p>
					</div>

					<div class="col-md-7 col-7">
						<p><?php if($stuprofile['stuname']!=""){ echo ucwords($stuprofile['stuname']);}else{echo "-Nil-";} ?></p>
					</div>

				</div>
			</div>
              
              <div class="col-12 col-sm-6">
              		<div class="row">

						<div class="col-md-5 col-5">
							<p>Date of Birth:</p>
						</div>

						<div class="col-md-7 col-7">
							<p class="<?php if($stuprofile['dob']=="" || $stuprofile['dob']=="0000-00-00"){ echo "empty";} ?>"><?php if($stuprofile['dob']!="" && $stuprofile['dob']!="0000-00-00"){ echo date("d-m-Y",strtotime($stuprofile['dob']));}else{echo "-Nil-";} ?></p>
						</div>

					</div>
              </div>
              
              <div class="col-12 col-sm-6">
              		<div class="row">

						<div class="col-md-5 col-5">
							<p>Gender:</p>
						</div>

						<div class="col-md-7 col-7">
							<p class="<?php if($stuprofile['gender']=="" || $stuprofile['gender']=="0"){ echo "empty";} ?>"><?php if($stuprofile['gender']!="" && $stuprofile['gender']!="0"){ echo $stuprofile['gender'];}else{echo "-Nil-";} ?></p>
						</div>

					</div>
              </div>
              
              <div class="col-12 col-sm-6">
                <div class="row">

					<div class="col-md-5 col-5">
						<p>Nationality:</p>
					</div>

					<div class="col-md-7 col-7">
						<p class="<?php if($stuprofile['nationality']=="" || $stuprofile['nationality']=="0"){ echo "empty";} ?>"><?php if($stuprofile['nationality']!="" && $stuprofile['nationality']!="0"){ echo $stuprofile['nationality'];}else{echo "-Nil-";} ?></p>
					</div>

				</div>
              </div>
              
              <div class="col-12 col-sm-6">
                <div class="row">

					<div class="col-md-5 col-5">
						<p>Category:</p>
					</div>

					<div class="col-md-7 col-7">
						<p class="<?php if($stuprofile['category']=="" || $stuprofile['category']=="0"){ echo "empty";} ?>"><?php if($stuprofile['category']!="" && $stuprofile['category']!="0"){ echo $stuprofile['category'];}else{echo "-Nil-";} ?></p>
					</div>

				</div>
              </div>
                           
              <div class="col-12 col-sm-6">
                <div class="row">

					<div class="col-md-5 col-5">
						<p>Aadhar Number:</p>
					</div>

					<div class="col-md-7 col-7">
						<p class="<?php if($stuprofile['aadharnumber']=="" || $stuprofile['aadharnumber']=="0"){ echo "empty";} ?>"><?php if($stuprofile['aadharnumber']!="" && $stuprofile['aadharnumber']!="0"){ echo $stuprofile['aadharnumber'];}else{echo "-Nil-";} ?></p>
					</div>

				</div>
			</div>
              
              <div class="col-12 col-sm-6">
                <div class="row">

					<div class="col-md-5 col-5">
						<p>Fathers Name:</p>
					</div>

					<div class="col-md-7 col-7">
						<p class="<?php if($stuprofile['fathername']=="" || $stuprofile['fathername']=="0"){ echo "empty";} ?>"><?php if($stuprofile['fathername']!="" && $stuprofile['fathername']!="0"){ echo $stuprofile['fathername'];}else{echo "-Nil-";} ?></p>
					</div>

				</div>
			</div>
              
              <div class="col-12 col-sm-6">
                <div class="row">

					<div class="col-md-5 col-5">
						<p>Fathers Phone:</p>
					</div>

					<div class="col-md-7 col-7">
						<p class="<?php if($stuprofile['fatherphone']=="" || $stuprofile['fatherphone']=="0"){ echo "empty";} ?>"><?php if($stuprofile['fatherphone']!="" && $stuprofile['fatherphone']!="0"){ echo $stuprofile['fathercode'].' '.$stuprofile['fatherphone'];}else{echo "-Nil-";} ?></p>
					</div>

				</div>
             
				 </div>
              
              <div class="col-12 col-sm-6">
                <div class="row">

					<div class="col-md-5 col-5">
						<p>Fathers Email:</p>
					</div>

					<div class="col-md-7 col-7">
						<p class="<?php if($stuprofile['fatheremail']=="" || $stuprofile['fatheremail']=="0"){ echo "empty";} ?>"><?php if($stuprofile['fatheremail']!="" && $stuprofile['fatheremail']!="0"){ echo $stuprofile['fatheremail'];}else{echo "-Nil-";} ?></p>
					</div>

				</div>
			</div>
              
              <div class="col-12 col-sm-6">
                <div class="row">

					<div class="col-md-5 col-5">
						<p>Fathers Occupation:</p>
					</div>

					<div class="col-md-7 col-7">
						<p class="<?php if($stuprofile['fatheroccupation']=="" || $stuprofile['fatheroccupation']=="0"){ echo "empty";} ?>"><?php if($stuprofile['fatheroccupation']!="" && $stuprofile['fatheroccupation']!="0"){ echo $stuprofile['fatheroccupation'];}else{echo "-Nil-";} ?></p>
					</div>

				</div>
			</div>
              
              <div class="col-12 col-sm-6">
                <div class="row">

					<div class="col-md-5 col-5">
						<p>Mothers Name:</p>
					</div>

					<div class="col-md-7 col-7">
						<p class="<?php if($stuprofile['mothername']=="" || $stuprofile['mothername']=="0"){ echo "empty";} ?>"><?php if($stuprofile['mothername']!="" && $stuprofile['mothername']!="0"){ echo $stuprofile['mothername'];}else{echo "-Nil-";} ?></p>
					</div>

				</div>
			</div>
              
              <div class="col-12 col-sm-6">
                <div class="row">

					<div class="col-md-5 col-5">
						<p>Mothers Phone:</p>
					</div>

					<div class="col-md-7 col-7">
						<p class="<?php if($stuprofile['motherphone']=="" || $stuprofile['motherphone']=="0"){ echo "empty";} ?>"><?php if($stuprofile['motherphone']!="" && $stuprofile['motherphone']!="0"){ echo $stuprofile['mothercode'].' '.$stuprofile['motherphone'];}else{echo "-Nil-";} ?></p>
					</div>

				</div>
                           
				 </div>
              
              <div class="col-12 col-sm-6">
				  <div class="row">

						<div class="col-md-5 col-5">
							<p>Mothers Email:</p>
						</div>

						<div class="col-md-7 col-7">
							<p class="<?php if($stuprofile['motheremail']=="" || $stuprofile['motheremail']=="0"){ echo "empty";} ?>"><?php if($stuprofile['motheremail']!="" && $stuprofile['motheremail']!="0"){ echo $stuprofile['motheremail'];}else{echo "-Nil-";} ?></p>
						</div>

					</div>
              
              </div>
              
              <div class="col-12 col-sm-6">
                <div class="row">

					<div class="col-md-5 col-5">
						<p>Mothers Occupation:</p>
					</div>

					<div class="col-md-7 col-7">
						<p class="<?php if($stuprofile['motheroccupation']=="" || $stuprofile['motheroccupation']=="0"){ echo "empty";} ?>"><?php if($stuprofile['motheroccupation']!="" && $stuprofile['motheroccupation']!="0"){ echo $stuprofile['motheroccupation'];}else{echo "-Nil-";} ?></p>
					</div>

				</div>
			</div>
              
              <div class="col-12 col-sm-6">
                <div class="row">

					<div class="col-md-5 col-5">
						<p>Communication Contact:</p>
					</div>

					<div class="col-md-7 col-7">
						<p class="<?php if($stuprofile['communicationcontact']=="" || $stuprofile['communicationcontact']=="0"){ echo "empty";} ?>"><?php if($stuprofile['communicationcontact']!="" && $stuprofile['communicationcontact']!="0"){ echo $stuprofile['communicationcontact'];}else{echo "-Nil-";} ?></p>
					</div>

				</div>
              </div>
              
              <div class="col-12 col-sm-6">
               
                <div class="row">

					<div class="col-md-5 col-5">
						<p>Blood Group:</p>
					</div>

					<div class="col-md-7 col-7">
						<p class="<?php if($stuprofile['bloodgroup']=="" || $stuprofile['bloodgroup']=="0"){ echo "empty";} ?>"><?php if($stuprofile['bloodgroup']!="" && $stuprofile['bloodgroup']!="0"){ echo $stuprofile['bloodgroup'];}else{echo "-Nil-";} ?></p>
					</div>

				</div>
    
              </div>
              
              <div class="col-12 col-sm-6">
                <div class="row">

					<div class="col-md-5 col-5">
						<p>Class Studying / Complete:</p>
					</div>

					<div class="col-md-7 col-7">
						<p class="<?php if($stuprofile['classstudy']=="" || $stuprofile['classstudy']=="0"){ echo "empty";} ?>"><?php if($stuprofile['classstudy']!="" && $stuprofile['classstudy']!="0"){ echo $stuprofile['classstudy'];}else{echo "-Nil-";} ?></p>
					</div>

				</div>
          
              </div>
              
              <div class="col-12 col-sm-6">
                <div class="row">

					<div class="col-md-5 col-5">
						<p>Stream:</p>
					</div>

					<div class="col-md-7 col-7">
						<p class="<?php if($stuprofile['stream']=="" || $stuprofile['stream']=="0"){ echo "empty";} ?>"><?php if($stuprofile['stream']!="" && $stuprofile['stream']!="0"){ echo $stuprofile['stream'];}else{echo "-Nil-";} ?></p>
					</div>

				</div>
              
              </div>
              
              			  
			  </div>
                                                                 
              </div>
              <div id="customButtons2">
                             
             <div class="row">
             
             <div class="col-12 col-sm-6">
                <div class="row">

					<div class="col-md-5 col-5">
						<p>Name of School Last Studied / Studying :</p>
					</div>

					<div class="col-md-7 col-7">
						<p class="<?php if($stuprofile['schoolcollegename']=="" || $stuprofile['schoolcollegename']=="0"){ echo "empty";} ?>"><?php if($stuprofile['schoolcollegename']!="" && $stuprofile['schoolcollegename']!="0"){ echo $stuprofile['schoolcollegename'];}else{echo "-Nil-";} ?></p>
					</div>

				</div>
              </div>
              
              <!--<div class="col-12 col-sm-6">
                <div class="row">

					<div class="col-md-5 col-5">
						<p>Landmark:</p>
					</div>

					<div class="col-md-7 col-7">
						<p class="<?php //if($stuprofile['edulandmark']=="" || $stuprofile['edulandmark']=="0"){ echo "empty";} ?>"><?php //if($stuprofile['edulandmark']!=""){ echo $stuprofile['edulandmark'];}else{echo "-Nil-";} ?></p>
					</div>

				</div>
              </div>-->
              
              <div class="col-12 col-sm-6">
                <div class="row">

					<div class="col-md-5 col-5">
						<p>Address Line:</p>
					</div>

					<div class="col-md-7 col-7">
						<p class="<?php if($stuprofile['eduaddress']=="" || $stuprofile['eduaddress']=="0"){ echo "empty";} ?>"><?php if($stuprofile['eduaddress']!="" && $stuprofile['eduaddress']!="0"){ echo $stuprofile['eduaddress'];}else{echo "-Nil-";} ?></p>
					</div>

				</div>
			</div>
              
              <div class="col-12 col-sm-6">
                <div class="row">

					<div class="col-md-5 col-5">
						<p>Country:</p>
					</div>

					<div class="col-md-7 col-7">
						<p class="<?php if($stuprofile['educountry']=="" || $stuprofile['educountry']=="0"){ echo "empty";} ?>"><?php if($stuprofile['educountry']!="" && $stuprofile['educountry']!="0"){ echo $stuprofile['educountry'];}else{echo "-Nil-";} ?></p>
					</div>

				</div>
              </div>
              
              <div class="col-12 col-sm-6">
                <div class="row">

					<div class="col-md-5 col-5">
						<p>Educational Qualification List:</p>
					</div>

					<div class="col-md-7 col-7">
						<p class="<?php if($qualname['qname']=="" || $qualname['qname']=="0"){ echo "empty";} ?>"><?php if($qualname['qname']!="" && $qualname['qname']!="0"){ echo $qualname['qname'];}else{echo "-Nil-";} ?></p>
					</div>

				</div>
              </div>
              
             <!--<div class="col-12 col-sm-6">
                <div class="row">

					<div class="col-md-5 col-5">
						<p>State:</p>
					</div>

					<div class="col-md-7 col-7">
						<p class="<?php //if($stuprofile['edustate']=="" || $stuprofile['edustate']=="0"){ echo "empty";} ?>"><?php //if($stuprofile['edustate']!=""){ echo $stuprofile['edustate'];}else{echo "-Nil-";} ?></p>
					</div>

				</div>
              </div>
              
              <div class="col-12 col-sm-6">
                <div class="row">

					<div class="col-md-5 col-5">
						<p>District:</p>
					</div>

					<div class="col-md-7 col-7">
						<p class="<?php //if($stuprofile['edudistrict']=="" || $stuprofile['edudistrict']=="0"){ echo "empty";} ?>"><?php //if($stuprofile['edudistrict']!=""){ echo $stuprofile['edudistrict'];}else{echo "-Nil-";} ?></p>
					</div>

				</div>
              </div>
              
              <div class="col-12 col-sm-6">
                <div class="row">

					<div class="col-md-5 col-5">
						<p>Post:</p>
					</div>

					<div class="col-md-7 col-7">
						<p class="<?php //if($stuprofile['edupost']=="" || $stuprofile['edupost']=="0"){ echo "empty";} ?>"><?php //if($stuprofile['edupost']!=""){ echo $stuprofile['edupost'];}else{echo "-Nil-";} ?></p>
					</div>

				</div>
              </div>
              
              <div class="col-12 col-sm-6">
                <div class="row">

					<div class="col-md-5 col-5">
						<p>Pincode:</p>
					</div>

					<div class="col-md-7 col-7">
						<p class="<?php //if($stuprofile['edupincode']=="" || $stuprofile['edupincode']=="0"){ echo "empty";} ?>"><?php //if($stuprofile['edupincode']!=""){ echo $stuprofile['edupincode'];}else{echo "-Nil-";} ?></p>
					</div>

				</div>
			</div>
                                          
              <div class="col-12 col-sm-6">
                <div class="row">

					<div class="col-md-5 col-5">
						<p>Exam Board:</p>
					</div>

					<div class="col-md-7 col-7">
						<p class="<?php //if($stuprofile['examboard']=="" || $stuprofile['examboard']=="0"){ echo "empty";} ?>"><?php //if($stuprofile['examboard']!=""){ echo $stuprofile['examboard'];}else{echo "-Nil-";} ?></p>
					</div>

				</div>
              </div>
              
              <div class="col-12 col-sm-6">
                <div class="row">

					<div class="col-md-5 col-5">
						<p>Exam Class:</p>
					</div>

					<div class="col-md-7 col-7">
						<p class="<?php //if($stuprofile['examclass']=="" || $stuprofile['examclass']=="0"){ echo "empty";} ?>"><?php //if($stuprofile['examclass']!=""){ echo $stuprofile['examclass'];}else{echo "-Nil-";} ?></p>
					</div>

				</div>
              </div>      
              
              <div class="col-12 col-sm-6">
                <div class="row">

					<div class="col-md-5 col-5">
						<p>Grade/Percentage:</p>
					</div>

					<div class="col-md-7 col-7">
						<p class="<?php //if($stuprofile['gradepercent']=="" || $stuprofile['gradepercent']=="0"){ echo "empty";} ?>"><?php //if($stuprofile['gradepercent']!=""){ echo $stuprofile['gradepercent'];}else{echo "-Nil-";} ?></p>
					</div>

				</div>
			</div>
              
              <div class="col-12 col-sm-6">
                <div class="row">

					<div class="col-md-5 col-5">
						<p>Preferred Subject:</p>
					</div>

					<div class="col-md-7 col-7">
						<p class="<?php //if($stuprofile['preferredsubject']=="" || $stuprofile['preferredsubject']=="0"){ echo "empty";} ?>"><?php //if($stuprofile['preferredsubject']!=""){ echo $stuprofile['preferredsubject'];}else{echo "-Nil-";} ?></p>
					</div>

				</div>
			</div>
              
              <div class="col-12 col-sm-6">
                <div class="row">

					<div class="col-md-5 col-5">
						<p>Eligibility Scholarship:</p>
					</div>

					<div class="col-md-7 col-7">
						<p class="<?php //if($stuprofile['eligiblescholar']=="" || $stuprofile['eligiblescholar']=="0"){ echo "empty";} ?>"><?php //if($stuprofile['eligiblescholar']!=""){ echo $stuprofile['eligiblescholar'];}else{echo "-Nil-";} ?></p>
					</div>

				</div>
              </div>
                            
              <div class="col-12 col-sm-6">
                <div class="row">

					<div class="col-md-5 col-5">
						<p>Mock Type:</p>
					</div>

					<div class="col-md-7 col-7">
						<p class="<?php //if($stuprofile['mocktype']=="" || $stuprofile['mocktype']=="0"){ echo "empty";} ?>"><?php //if($stuprofile['mocktype']!=""){ echo $stuprofile['mocktype'];}else{echo "-Nil-";} ?></p>
					</div>

				</div>
              </div>
              
              <div class="col-12 col-sm-6">
                <div class="row">

					<div class="col-md-5 col-5">
						<p>Roll No.:</p>
					</div>

					<div class="col-md-7 col-7">
						<p class="<?php //if($stuprofile['rollno']=="" || $stuprofile['rollno']=="0"){ echo "empty";} ?>"><?php //if($stuprofile['rollno']!=""){ echo $stuprofile['rollno'];}else{echo "-Nil-";} ?></p>
					</div>

				</div>
			</div>-->
              
              			  
			  </div>
                                                              
              </div>
              
              <div id="customButtons5">
              
              	<div class="row yearfee">


							<div class="col-md-5 mb-4">

								<p class="first">Class <?php echo $qualification['class'];?> details</p>

								<div class="d-block w-100 p-0">

									<div class="row">

										<div class="col-md-5 col-5">
											<p>Year of Passing:</p>
										</div>

										<div class="col-md-7 col-7">
											<p><?php echo $qualification['yearofpassing'];?></p>
										</div>

									</div>

									<div class="row">

										<div class="col-md-5 col-5">
											<p>Class Name:</p>
										</div>

										<div class="col-md-7 col-7">
											<p><?php echo $qualification['class'];?></p>
										</div>

									</div>

									<div class="row">

										<div class="col-md-5 col-5">
											<p>Board of Exams:</p>
										</div>

										<div class="col-md-7 col-7">
											<p><?php echo $qualification['stream'];?></p>
										</div>

									</div>

									<div class="row">

										<div class="col-md-5 col-5">
											<p>Status:</p>
										</div>

										<div class="col-md-7 col-7">
											<p><?php echo ($qualification['status'] === 'P')?"Passed":"Waiting For Result";?></p>
										</div>

									</div>

									<div class="row">

										<div class="col-md-5 col-5">
											<p>Roll Number:</p>
										</div>

										<div class="col-md-7 col-7">
											<p><?php echo $qualification['rollno'];?></p>
										</div>

									</div>

									<div class="row">

										<div class="col-md-5 col-5">
											<p>Grace Mark:</p>
										</div>

										<div class="col-md-7 col-7">
                                                                                        <p><?php if($qualification['gracemark'] != '') {echo ($qualification['gracemark'] === 'y')?"Yes":"No";}?></p>
										</div>

									</div>
								</div>
							</div>

                                                                <?php
                                                                
                                                                if($qualification['subject'] !== '') {
                                                                    
                                                                    $subject = explode("|",$qualification['subject']);
                                                                    $mark = ($qualification['mark'] !== '')? explode("|",$qualification['mark']):"";
                                                                    $grade = ($qualification['grade'] !== '')? explode("|",$qualification['grade']):"";
                                                                    
                                                                    
                                                                    
                                                                    ?>
							<div class="col-md-4 mb-4">

								<p class="first">Class <?php echo $qualification['class'];?> Marksheet</p>

								<div class="card d-flex d-block w-100 p-3">
                                                                    
                                                                   <?php 
                                                                   
                                                                   for($i = 0 ; $i < count($subject);$i++) {
                                                                   if($subject[$i] ==='') { continue;}
                                                                       $con = ($mark !== '')?$mark[$i]:$grade[$i];
                                                                        echo '<div class="row">

										<div class="col-md-5 col-5">
											<p>'.$subject[$i].':</p>
										</div>

										<div class="col-md-7 col-7">
											<p>'.$con.'</p>
										</div>

									</div>';
                                                                    }
                                                                   
                                                                   ?>
								
								</div>
							</div>
                                                    
                                                    <?php } ?>

						</div>


						<div class="separator mb-5"></div>

                                                <?php if($qualification['xii_yearofpassing'] !== '') {?>
						<div class="row yearfee">


							<div class="col-md-5 mb-4">

								<p class="first">Class XII details</p>

								<div class="d-block w-100 p-0">

									<div class="row">

										<div class="col-md-5 col-5">
											<p>Year of Passing:</p>
										</div>

										<div class="col-md-7 col-7">
											<p><?php echo $qualification['xii_yearofpassing']; ?></p>
										</div>

									</div>

									<div class="row">

										<div class="col-md-5 col-5">
											<p>Class Name:</p>
										</div>

										<div class="col-md-7 col-7">
											<p>XII Standard</p>
										</div>

									</div>

									<div class="row">

										<div class="col-md-5 col-5">
											<p>Board of Exams:</p>
										</div>

										<div class="col-md-7 col-7">
											<p><?php echo $qualification['xii_stream']; ?></p>
										</div>

									</div>

									<div class="row">

										<div class="col-md-5 col-5">
											<p>Status:</p>
										</div>

										<div class="col-md-7 col-7">
											<p><?php echo ($qualification['xii_status'] === 'P')?"Passed":"Waiting For Result";?></p>
										</div>

									</div>

									<div class="row">

										<div class="col-md-5 col-5">
											<p>Roll Number:</p>
										</div>

										<div class="col-md-7 col-7">
											<p><?php echo $qualification['xii_rollno']; ?></p>
										</div>

									</div>

									<div class="row">

										<div class="col-md-5 col-5">
											<p>Grace Mark:</p>
										</div>

										<div class="col-md-7 col-7">
											<p><?php if($qualification['xii_gracemark'] != '') {echo ($qualification['xii_gracemark'] === 'y')?"Yes":"No";}?></p>
										</div>

									</div>
								</div>
							</div>

                                                                <?php
                                                                
                                                                if($qualification['xii_subject'] !== '') {
                                                                    
                                                                    $xii_subject = explode("|",$qualification['xii_subject']);
                                                                    $xii_mark = ($qualification['xii_mark'] !== '')? explode("|",$qualification['xii_mark']):"";
                                                                    $xii_grade = ($qualification['xii_grade'] !== '')? explode("|",$qualification['xii_grade']):"";
                                                                    
                                                                    
                                                                    
                                                                    ?>
							<div class="col-md-4 mb-4">

								<p class="first">Class XII Marksheet</p>

								<div class="card d-flex d-block w-100 p-3">

									<?php 
                                                                   
                                                                   for($i = 0 ; $i < count($xii_subject);$i++) {
                                                                   if($xii_subject[$i] ==='') { continue;}
                                                                       $con = ($xii_mark !== '')?$xii_mark[$i]:$xii_grade[$i];
                                                                        echo '<div class="row">

										<div class="col-md-5 col-5">
											<p>'.$xii_subject[$i].':</p>
										</div>

										<div class="col-md-7 col-7">
											<p>'.$con.'</p>
										</div>

									</div>';
                                                                    }
                                                                   
                                                                   ?>

									
								</div>
							</div>
                                                <?php } ?>

						</div>

                                                <?php } ?>
						<div class="separator mb-5"></div>


						<div class="row yearfee">


                                                            <?php
                                                                                                                      
                                                            if($qualification['entrance_name'] != "") {
                                                                
                                                                $examArr1 = explode("|", $qualification['entrance_name']);
                                                                $examArr2 = explode("|", $qualification['entrance_mark']);
                                                                $examArr3 = explode("|", $qualification['entrance_regno']);
                                                                
                                                                foreach ($examArr1 as $key => $value) {
                                                                    
                                                                    if($value === "") {continue;}
                                                            
                                                            echo '<div class="col-md-5 mb-4">
                                                            

								<p class="first">'.$value.' - Entrance Exam</p>

								<div class="d-block w-100 p-0">

									<div class="row">

										<div class="col-md-5 col-5">
											<p>Rank/Mark:</p>
										</div>

										<div class="col-md-7 col-7">
											<p>'.$examArr2[$key].'</p>
										</div>

									</div>

									<div class="row">

										<div class="col-md-5 col-5">
											<p>Registration Number:</p>
										</div>

										<div class="col-md-7 col-7">
											<p>'.$examArr3[$key].'</p>
										</div>

									</div>


								</div>
							</div>';
                                                                }
                                                            }
                                                            
                                                            ?>
							
						</div>

						
						<?php
		
								$qmarksheets = $qualification['marksheets'];
								$qmarksheetsarr = explode('|',$qmarksheets);

								$qmarksheetlist = "";
								foreach($qmarksheetsarr as $qmarksheet){

									$ext = end(explode(".",$qmarksheet));

									if(strtolower($ext)!="pdf"){
										$qmarksheetlist .= '<div class="col-2"><a href="docs/courserequest/marksheets/'.$user['id'].'/'.$qmarksheet.'?'.time().'"><img class="img-fluid border-radius" src="docs/courserequest/marksheets/'.$user['id'].'/'.$qmarksheet.'?'.time().'"><div class="overlay"></div></a></div>';
									}
									else{
										$qmarksheetlist .= '<div class="col-2"><a href="docs/courserequest/marksheets/'.$user['id'].'/'.$qmarksheet.'?'.time().'" target="_blank"><span class="text">pdf</span><i class="glyph-icon simple-icon-doc"></i><div class="overlay"></div></a></div>';
									}

								}
			
							?>
        
							<?php if($qmarksheets!="" && $qmarksheets!="0"){?>
						   
						   <div class="mb-4 qmarksheet">

								<div class="row">

									  <div class="col-12">

											<p class="list-item-heading pb-2">Marksheets:</p>

											<div class="row gallery px-4 mb-4">
											  <?php echo $qmarksheetlist;?>
											</div>

									  </div>

								 </div>

							</div> 

							<?php }?>

						<div class="mb-5"></div>
              
              </div>
              
              
              <div id="customButtons3">
                             
             <div class="row">
                                         
              <div class="col-12">
                <div class="row">

					<div class="col-md-3 col-5">
						<p>House / Appartment Name:</p>
					</div>

					<div class="col-md-5 col-7">
						<p class="<?php if($stuprofile['housenameno']=="" || $stuprofile['housenameno']=="0"){ echo "empty";} ?>"><?php if($stuprofile['housenameno']!="" && $stuprofile['housenameno']!="0"){ echo $stuprofile['housenameno'];}else{echo "-Nil-";} ?></p>
					</div>

				</div>
			</div>
             
              <!--<div class="col-12">
                <div class="row">

					<div class="col-md-3 col-3">
						<p>Landmark:</p>
					</div>

					<div class="col-md-5 col-9">
						<p class="<?php //if($stuprofile['landmark']=="" || $stuprofile['landmark']=="0"){ echo "empty";} ?>"><?php //if($stuprofile['landmark']!=""){ echo $stuprofile['landmark'];}else{echo "-Nil-";} ?></p>
					</div>

				</div>
              </div>-->
              
              <div class="col-12">
                <div class="row">

					<div class="col-md-3 col-5">
						<p>Place / Street:</p>
					</div>

					<div class="col-md-5 col-7">
						<p class="<?php if($stuprofile['contactaddress']=="" || $stuprofile['contactaddress']=="0"){ echo "empty";} ?>"><?php if($stuprofile['contactaddress']!="" && $stuprofile['contactaddress']!="0"){ echo $stuprofile['contactaddress'];}else{echo "-Nil-";} ?></p>
					</div>

				</div>
			</div>
              
              <div class="col-12">
                <div class="row">

					<div class="col-md-3 col-5">
						<p>Post Office:</p>
					</div>

					<div class="col-md-5 col-7">
						<p class="<?php if($stuprofile['contactpost']=="" || $stuprofile['contactpost']=="0"){ echo "empty";} ?>"><?php if($stuprofile['contactpost']!="" && $stuprofile['contactpost']!="0"){ echo $stuprofile['contactpost'];}else{echo "-Nil-";} ?></p>
					</div>

				</div>
              </div>
              
              <div class="col-12">
                <div class="row">

					<div class="col-md-3 col-5">
						<p>District:</p>
					</div>

					<div class="col-md-5 col-7">
						<p class="<?php if($stuprofile['contactdistrict']=="" || $stuprofile['contactdistrict']=="0"){ echo "empty";} ?>"><?php if($stuprofile['contactdistrict']!="" && $stuprofile['contactdistrict']!="0"){ echo $stuprofile['contactdistrict'];}else{echo "-Nil-";} ?></p>
					</div>

				</div>
              </div>
              
             <div class="col-12">
                <div class="row">

					<div class="col-md-3 col-5">
						<p>State:</p>
					</div>

					<div class="col-md-5 col-7">
						<p class="<?php if($stuprofile['contactstate']=="" || $stuprofile['contactstate']=="0"){ echo "empty";} ?>"><?php if($stuprofile['contactstate']!="" && $stuprofile['contactstate']!="0"){ echo $stuprofile['contactstate'];}else{echo "-Nil-";} ?></p>
					</div>

				</div>
              </div>
              
              <div class="col-12">
                <div class="row">

					<div class="col-md-3 col-5">
						<p>Country:</p>
					</div>

					<div class="col-md-5 col-7">
						<p class="<?php if($stuprofile['contactcountry']=="" || $stuprofile['contactcountry']=="0"){ echo "empty";} ?>"><?php if($stuprofile['contactcountry']!="" && $stuprofile['contactcountry']!="0"){ echo $stuprofile['contactcountry'];}else{echo "-Nil-";} ?></p>
					</div>

				</div>
              </div>
              
              <div class="col-12">
                <div class="row">

					<div class="col-md-3 col-5">
						<p>Pincode:</p>
					</div>

					<div class="col-md-5 col-7">
						<p class="<?php if($stuprofile['contactpincode']=="" || $stuprofile['contactpincode']=="0"){ echo "empty";} ?>"><?php if($stuprofile['contactpincode']!="" && $stuprofile['contactpincode']!="0"){ echo $stuprofile['contactpincode'];}else{echo "-Nil-";} ?></p>
					</div>

				</div>
			</div>
             			  
             	<div class="col-12">
                <div class="row">

					<div class="col-md-3 col-5">
						<p>Whatsapp Number:</p>
					</div>

					<div class="col-md-5 col-7">
						<p class="<?php if($stuprofile['whatsappno']=="" || $stuprofile['whatsappno']=="0"){ echo "empty";} ?>"><?php if($stuprofile['whatsappno']!="" && $stuprofile['whatsappno']!="0"){ echo $stuprofile['wacode'].' '.$stuprofile['whatsappno'];}else{echo "-Nil-";} ?></p>
					</div>

				</div>
                           
				 </div>	
              
              <div class="col-12">
                <div class="row">

					<div class="col-md-3 col-5">
						<p>Guardian Name:</p>
					</div>

					<div class="col-md-5 col-7">
						<p class="<?php if($stuprofile['guardianname']=="" || $stuprofile['guardianname']=="0"){ echo "empty";} ?>"><?php if($stuprofile['guardianname']!="" && $stuprofile['guardianname']!="0"){ echo $stuprofile['guardianname'];}else{echo "-Nil-";} ?></p>
					</div>

				</div>
			</div>	  
              			  
			  </div>
                                                              
              </div>
              
              <div id="customButtons4">
                
             
             <div class="row">
                                         
              <div class="col-12">
                <div class="row">

					<div class="col-md-3 col-5">
						<p>Account Holder Name:</p>
					</div>

					<div class="col-md-4 col-7">
						<p class="<?php if($stuprofile['accountholdername']=="" || $stuprofile['accountholdername']=="0"){ echo "empty";} ?>"><?php if($stuprofile['accountholdername']!="" && $stuprofile['accountholdername']!="0"){ echo $stuprofile['accountholdername'];}else{echo "-Nil-";} ?></p>
					</div>

				</div>
              </div>
                                         
              <div class="col-12">
                <div class="row">

					<div class="col-md-3 col-5">
						<p>Bank Name:</p>
					</div>

					<div class="col-md-4 col-7">
						<p class="<?php if($stuprofile['bankname']=="" || $stuprofile['bankname']=="0"){ echo "empty";} ?>"><?php if($stuprofile['bankname']!="" && $stuprofile['bankname']!="0"){ echo $stuprofile['bankname'];}else{echo "-Nil-";} ?></p>
					</div>

				</div>
              </div>
              
             <div class="col-12">
                <div class="row">

					<div class="col-md-3 col-5">
						<p>Branch:</p>
					</div>

					<div class="col-md-4 col-7">
						<p class="<?php if($stuprofile['branch']=="" || $stuprofile['branch']=="0"){ echo "empty";} ?>"><?php if($stuprofile['branch']!="" && $stuprofile['branch']!="0"){ echo $stuprofile['branch'];}else{echo "-Nil-";} ?></p>
					</div>

				</div>
			</div>
             
              <div class="col-12">
                <div class="row">

					<div class="col-md-3 col-5">
						<p>IFSC Code:</p>
					</div>

					<div class="col-md-4 col-7">
						<p class="<?php if($stuprofile['ifsccode']=="" || $stuprofile['ifsccode']=="0"){ echo "empty";} ?>"><?php if($stuprofile['ifsccode']!="" && $stuprofile['ifsccode']!="0"){ echo $stuprofile['ifsccode'];}else{echo "-Nil-";} ?></p>
					</div>

				</div>
              </div>
             
              <div class="col-12">
                <div class="row">

					<div class="col-md-3 col-5">
						<p>Bank Account Number:</p>
					</div>

					<div class="col-md-4 col-7">
						<p class="<?php if($stuprofile['bankaccountno']=="" || $stuprofile['bankaccountno']=="0"){ echo "empty";} ?>"><?php if($stuprofile['bankaccountno']!="" && $stuprofile['bankaccountno']!="0"){ echo $stuprofile['bankaccountno'];}else{echo "-Nil-";} ?></p>
					</div>

				</div>
              </div>
              			  
			  </div>
                                                 
             
              </div>
              
                                          
            </div>
            
           <!-- <div class="btn-toolbar custom-toolbar text-center card-body pt-0 mb-5">
				<button class="btn btn-outline-primary prev-btn d-none mb-5" type="button"><i class="icon-arrow-left mr-2"></i> Previous</button>
				<button class="btn btn-primary next-btn mb-5" type="button">Next <i class="icon-arrow-right ml-2"></i></button>
				<button class="btn btn-primary payment-btn d-none mb-5" type="button">Continue Payment <i class="icon-arrow-right ml-2"></i></button>
            </div>-->
            
          </div>
        </div>
        
        <?php
		
			$marksheets = $stuprofile['marksheets'];
			$marksheetsarr = explode('|',$marksheets);
			
			$marksheetlist = "";
			foreach($marksheetsarr as $marksheet){
				
				$ext = end(explode(".",$marksheet));
				
				if(strtolower($ext)!="pdf"){
					$marksheetlist .= '<div class="col-2"><a href="docs/marksheets/'.$user['id'].'/'.$marksheet.'"><img class="img-fluid border-radius" src="docs/marksheets/'.$user['id'].'/'.$marksheet.'"><div class="overlay"></div></a></div>';
				}
				else{
					$marksheetlist .= '<div class="col-2"><a href="docs/marksheets/'.$user['id'].'/'.$marksheet.'" target="_blank"><span class="text">pdf</span><i class="glyph-icon simple-icon-doc"></i><div class="overlay"></div></a></div>';
				}
				
			}
			
		?>
        
        <?php if($marksheets!="" && $marksheets!="0"){?>
        
       <div class="card mb-4 marksheet d-none">
				
			<div class="row">
          
				  <div class="col-md-6 col-sm-6 col-lg-12 col-12">

			  			<p class="list-item-heading px-4 pt-4 pb-2">Student Marksheets:</p>
			  			
			  			<div class="row gallery px-4 mb-4">
						  <?php echo $marksheetlist;?>
						</div>
			  
				  </div>
          
       		 </div>
				
		</div> 
                
        <?php }?>     
        
      </div>
      
      
			
	
		
	</div>


	</div>
</main>


<div id="IDcardpreivewModal" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
	<div class="modal-dialog" role="document">
		<div class="modal-content">

			<div class="modal-header">
				<h2 class="modal-title">ID Card Preview</h2>
			   <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
			</div>
			<div class="modal-body text-center idcardpreview">

															

			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-outline-primary modalclose" data-dismiss="modal">Close</button>
			</div>

		</div>
	</div>
</div>
	
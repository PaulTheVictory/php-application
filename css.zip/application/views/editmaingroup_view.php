
<div id="pagetitle">

	<div class="wrap">
    
    	<h1>Edit Group</h1>
        
	</div>
    
</div>
<div class="maincontent">

	<div class="wrap">
    
            <div id="course-container" class="add-course-date">

                <div class="row-element">
                    <span class="title" style="padding: 0px;padding-top: 10px">Group</span>
                    <span class="content"><input type="text" value="<?php echo html_escape($edit['grpname']);?>" class="name" id="grpname"></span>
                </div>

                 <div class="row-element">
                    <span class="content">
                        <input style="float: left" type="submit" class="course-submit" value="Submit">
                        <p class="errnotify" style="color:#aa3e41;margin:0px;padding:0px;float:left;padding-left:20px;padding-top:10px"> </p>
                    </span>
                </div>
                
            </div>
        
        </div>
    
    </div>
<script type="text/javascript">
$(document).ready(function() {
	
	
	$(".add-course-date").find("input").each(function(){

          $(this).click(function(){ $(".errnotify").html("&nbsp;");});

    });
    
    
   
	
	$(".add-course-date").find(".course-submit").click(function(){
		
		var name = $(".add-course-date").find(".name").val();
               
		if(name === ""){ $(".errnotify").html("Please provide group name");return;}	
                
           
		
		$(this).val("Processing...");
		
				$.get('editmaingroup/updateGroup',{
					   'name':name, 
                                           'id':'<?php echo $edit['id'];?>'
                                           

				}, function(o) { 
					var obj1 = $.parseJSON(o);
					if(obj1[0] === 'success'){
						    
                                            $(".errnotify").html("<font style=\"color:#188f04\">Group has been edited succesfully!!</font>");
					    setTimeout(function(){ window.location.assign("maingroup"); }, 500);
                                                
					}else if(obj1[0] === 'fail'){
                                                   $(".add-course-date").find(".course-submit").val("Submit");
                                                   alert("Error!! Please try again");                                                    
						
					}
				});	 
		
  	});
	
});
</script>
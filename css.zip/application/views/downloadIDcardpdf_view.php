
<?php if($ptype!="preview"){ ?>


<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Brilliant Study Centre, Pala</title>
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1">

<link rel="stylesheet" href="<?php echo base_url();?>css/boot/bootstrap.min.css">
<link rel="stylesheet" href="<?php echo base_url();?>css/boot/bootstrap.rtl.only.min.css">
<link rel="stylesheet" href="<?php echo base_url();?>css/boot/bootstrap-float-label.min.css">
<link rel="stylesheet" href="<?php echo base_url();?>css/boot/main.css">

<script src="<?php echo base_url();?>js/jquery-3.5.1.min.js"></script>

	<style>
	
		/*@page {margin:0;padding:0;}
		html { margin: 0px;padding:0;}
		body { margin: 0px;padding:0;}*/
		
	</style>
	

</head>

<?php }?>

<?php
			
		$coursename = $coursepay['coursename'][0];
		$coursetype = $coursepay['idcard_displayname'][0];
		$stuid = $user['stuid'];
		$stuname = $user['pname'];
		$dob = date("d M Y",strtotime($stuprofile['dob']));
		$classstudy = $stuprofile['classstudy'];
		$mobile = $stuprofile['smobile'];
		$smcode = $stuprofile['smcode'];
		$email = $stuprofile['semail'];
		$profilepic = $user['profilepic'];
	
		$coursetype = substr($coursetype,0,20);
		$stuname = substr($stuname,0,20);
				                
				
		$guardianname = "";
		if($stuprofile['fathername']!="" && $stuprofile['fathername']!="0") $guardianname = $stuprofile['fathername'];
		else if($stuprofile['guardianname']!="" && $stuprofile['guardianname']!="0") $guardianname = $stuprofile['guardianname'];
		
		$fulladdress = $addressline1 = $addressline2 = $addressline3 = "";
		$addressline1 .= $stuprofile['housenameno'].", ";
		$addressline1 .= $stuprofile['contactaddress'].", ";
	
		$addressline1 = strtolower(substr($addressline1,0,35));
		$addressline1 = ucwords($addressline1);
		
		if($stuprofile['contactaddress']!="" && $stuprofile['contactaddress']!="0") $fulladdress .= $stuprofile['landmark'].", ";
		
		$fulladdress .= $stuprofile['contactstate'].", ";
		$addressline2 .= $stuprofile['contactpost'].", ";
		//$fulladdress .= $stuprofile['contactcountry']." - ";
	
		$addressline2 = strtolower(substr($addressline2,0,35));
		$addressline2 = ucwords($addressline2);
	
		$addressline3 .= $stuprofile['contactdistrict'].", ";
		$addressline3 .= $stuprofile['contactpincode'].".";
	
		$addressline3 = strtolower(substr($addressline3,0,35));
		$addressline3 = ucwords($addressline3);
		
		$mobile = "Mob +".$smcode." ".$mobile;
	
?>
<?php if($ptype!="preview"){ ?>
<body>
<?php } ?>

	<div class="idcardrow" style="text-align: center;max-width: 100%;max-height: 100%;margin:-42px auto -46px;"> 
  
		<div style="position: relative;width: 325px;height: 508px;margin: 0 auto">
		
			<div style="position: absolute;top: 20.6%;left: 29.6%;"><img src="<?php echo base_url();?>docs/profilepic/<?php echo $studentid?>/<?php echo $profilepic;?>" alt="" style="width: 133px;height: 145px;" /></div>
			
			<div style="position: absolute;width: 60%;top: 32%;left: -24%;transform: rotate(-90deg);line-height: 20px;"><span style="font-size: 13px;font-weight: bold;color: #222B39;text-transform: uppercase"><?php echo $coursetype;?></span></div>
			
			<div style="position: absolute;top: 30%;right: -9%;transform: rotate(-90deg);"><img src="<?php echo base_url();?>docs/profilepic/<?php echo $studentid?>/<?php echo $stuid.'.png';?>" alt="" style="width: 135px;height: 60px" /></div>
		
			<img src="<?php echo base_url();?>docs/idcard.jpg" alt="ID Card" style="width: 100%;height: auto;">
							
			<div style="position: absolute;width: 100%;top: 50%;left: 0;"><span style="font-size: 21px;font-weight: bold;color: #0332AA;word-break: break-word;"><?php echo strtoupper($stuname);?></span></div>
			
			<div style="position: absolute;width: 100%;top: 55.5%;left: 0;"><span style="font-size: 21px;font-weight: bold;color: #0332AA"><?php echo $stuid;?></span></div>
			
			<div style="position: absolute;width: 100%;top: 62%;left: 0;"><span style="font-size: 15px;font-weight: bold;color: #222B39"><?php echo $mobile;?></span></div>
			
			<div style="position: absolute;width: 100%;bottom: 28%;left: 0;padding: 0 1rem;text-align: left;"><span style="font-size: 15px;font-weight: bold;color: #222B39"><?php echo $addressline1;?></span></div>
			<div style="position: absolute;width: 100%;bottom: 24%;left: 0;padding: 0 1rem;text-align: left;"><span style="font-size: 15px;font-weight: bold;color: #222B39"><?php echo $addressline2;?></span></div>
			<div style="position: absolute;width: 100%;bottom: 20%;left: 0;padding: 0 1rem;text-align: left;"><span style="font-size: 15px;font-weight: bold;color: #222B39"><?php echo $addressline3;?></span></div>
						
		</div>
           
    </div>
    
    <?php if($ptype=="bulk"){ ?>
    
    	<div style="text-align: center;max-width: 100%;max-height: 100%;margin:-42px auto -46px;page-break-before: always"> 
  
			<div style="position: relative;width: 325px;height: 508px;margin: 0 auto">

				<div style="position: absolute;top: 20.6%;left: 29.6%;"><img src="<?php echo base_url();?>docs/profilepic/<?php echo $studentid?>/<?php echo $profilepic;?>" alt="" style="width: 133px;height: 145px;" /></div>

				<div style="position: absolute;width: 60%;top: 32%;left: -24%;transform: rotate(-90deg);line-height: 20px;"><span style="font-size: 13px;font-weight: bold;color: #222B39;text-transform: uppercase"><?php echo $coursetype;?></span></div>

				<div style="position: absolute;top: 30%;right: -9%;transform: rotate(-90deg);"><img src="<?php echo base_url();?>docs/profilepic/<?php echo $studentid?>/<?php echo $stuid.'.png';?>" alt="" style="width: 135px;height: 60px" /></div>

				<img src="<?php echo base_url();?>docs/idcard.jpg" alt="ID Card" style="width: 100%;height: auto;">

				<div style="position: absolute;width: 100%;top: 50%;left: 0;"><span style="font-size: 21px;font-weight: bold;color: #0332AA;word-break: break-word;"><?php echo strtoupper($stuname);?></span></div>

				<div style="position: absolute;width: 100%;top: 55.5%;left: 0;"><span style="font-size: 21px;font-weight: bold;color: #0332AA"><?php echo $stuid;?></span></div>

				<div style="position: absolute;width: 100%;top: 62%;left: 0;"><span style="font-size: 15px;font-weight: bold;color: #222B39"><?php echo $mobile;?></span></div>

				<div style="position: absolute;width: 100%;bottom: 28%;left: 0;padding: 0 1rem;text-align: left;"><span style="font-size: 15px;font-weight: bold;color: #222B39"><?php echo $addressline1;?></span></div>
				<div style="position: absolute;width: 100%;bottom: 24%;left: 0;padding: 0 1rem;text-align: left;"><span style="font-size: 15px;font-weight: bold;color: #222B39"><?php echo $addressline2;?></span></div>
				<div style="position: absolute;width: 100%;bottom: 20%;left: 0;padding: 0 1rem;text-align: left;"><span style="font-size: 15px;font-weight: bold;color: #222B39"><?php echo $addressline3;?></span></div>

			</div>
           
    	</div>
    
    	<div style="text-align: center;max-width: 100%;max-height: 100%;margin:-42px auto -46px;page-break-before: always"> 
  
			<div style="position: relative;width: 325px;height: 508px;margin: 0 auto">

				<div style="position: absolute;top: 20.6%;left: 29.6%;"><img src="<?php echo base_url();?>docs/profilepic/<?php echo $studentid?>/<?php echo $profilepic;?>" alt="" style="width: 133px;height: 145px;" /></div>

				<div style="position: absolute;width: 60%;top: 32%;left: -24%;transform: rotate(-90deg);line-height: 20px;"><span style="font-size: 13px;font-weight: bold;color: #222B39;text-transform: uppercase"><?php echo $coursetype;?></span></div>

				<div style="position: absolute;top: 30%;right: -9%;transform: rotate(-90deg);"><img src="<?php echo base_url();?>docs/profilepic/<?php echo $studentid?>/<?php echo $stuid.'.png';?>" alt="" style="width: 135px;height: 60px" /></div>

				<img src="<?php echo base_url();?>docs/idcard.jpg" alt="ID Card" style="width: 100%;height: auto;">

				<div style="position: absolute;width: 100%;top: 50%;left: 0;"><span style="font-size: 21px;font-weight: bold;color: #0332AA;word-break: break-word;"><?php echo strtoupper($stuname);?></span></div>

				<div style="position: absolute;width: 100%;top: 55.5%;left: 0;"><span style="font-size: 21px;font-weight: bold;color: #0332AA"><?php echo $stuid;?></span></div>

				<div style="position: absolute;width: 100%;top: 62%;left: 0;"><span style="font-size: 15px;font-weight: bold;color: #222B39"><?php echo $mobile;?></span></div>

				<div style="position: absolute;width: 100%;bottom: 28%;left: 0;padding: 0 1rem;text-align: left;"><span style="font-size: 15px;font-weight: bold;color: #222B39"><?php echo $addressline1;?></span></div>
				<div style="position: absolute;width: 100%;bottom: 24%;left: 0;padding: 0 1rem;text-align: left;"><span style="font-size: 15px;font-weight: bold;color: #222B39"><?php echo $addressline2;?></span></div>
				<div style="position: absolute;width: 100%;bottom: 20%;left: 0;padding: 0 1rem;text-align: left;"><span style="font-size: 15px;font-weight: bold;color: #222B39"><?php echo $addressline3;?></span></div>

			</div>
           
    	</div>
    
    	<div style="text-align: center;max-width: 100%;max-height: 100%;margin:-42px auto -46px;page-break-before: always"> 
  
			<div style="position: relative;width: 325px;height: 508px;margin: 0 auto">

				<div style="position: absolute;top: 20.6%;left: 29.6%;"><img src="<?php echo base_url();?>docs/profilepic/<?php echo $studentid?>/<?php echo $profilepic;?>" alt="" style="width: 133px;height: 145px;" /></div>

				<div style="position: absolute;width: 60%;top: 32%;left: -24%;transform: rotate(-90deg);line-height: 20px;"><span style="font-size: 13px;font-weight: bold;color: #222B39;text-transform: uppercase"><?php echo $coursetype;?></span></div>

				<div style="position: absolute;top: 30%;right: -9%;transform: rotate(-90deg);"><img src="<?php echo base_url();?>docs/profilepic/<?php echo $studentid?>/<?php echo $stuid.'.png';?>" alt="" style="width: 135px;height: 60px" /></div>

				<img src="<?php echo base_url();?>docs/idcard.jpg" alt="ID Card" style="width: 100%;height: auto;">

				<div style="position: absolute;width: 100%;top: 50%;left: 0;"><span style="font-size: 21px;font-weight: bold;color: #0332AA;word-break: break-word;"><?php echo strtoupper($stuname);?></span></div>

				<div style="position: absolute;width: 100%;top: 55.5%;left: 0;"><span style="font-size: 21px;font-weight: bold;color: #0332AA"><?php echo $stuid;?></span></div>

				<div style="position: absolute;width: 100%;top: 62%;left: 0;"><span style="font-size: 15px;font-weight: bold;color: #222B39"><?php echo $mobile;?></span></div>

				<div style="position: absolute;width: 100%;bottom: 28%;left: 0;padding: 0 1rem;text-align: left;"><span style="font-size: 15px;font-weight: bold;color: #222B39"><?php echo $addressline1;?></span></div>
				<div style="position: absolute;width: 100%;bottom: 24%;left: 0;padding: 0 1rem;text-align: left;"><span style="font-size: 15px;font-weight: bold;color: #222B39"><?php echo $addressline2;?></span></div>
				<div style="position: absolute;width: 100%;bottom: 20%;left: 0;padding: 0 1rem;text-align: left;"><span style="font-size: 15px;font-weight: bold;color: #222B39"><?php echo $addressline3;?></span></div>

			</div>
           
    	</div>
    
    	<div style="text-align: center;max-width: 100%;max-height: 100%;margin:-42px auto -46px;page-break-before: always"> 
  
			<div style="position: relative;width: 325px;height: 508px;margin: 0 auto">

				<div style="position: absolute;top: 20.6%;left: 29.6%;"><img src="<?php echo base_url();?>docs/profilepic/<?php echo $studentid?>/<?php echo $profilepic;?>" alt="" style="width: 133px;height: 145px;" /></div>

				<div style="position: absolute;width: 60%;top: 32%;left: -24%;transform: rotate(-90deg);line-height: 20px;"><span style="font-size: 13px;font-weight: bold;color: #222B39;text-transform: uppercase"><?php echo $coursetype;?></span></div>

				<div style="position: absolute;top: 30%;right: -9%;transform: rotate(-90deg);"><img src="<?php echo base_url();?>docs/profilepic/<?php echo $studentid?>/<?php echo $stuid.'.png';?>" alt="" style="width: 135px;height: 60px" /></div>

				<img src="<?php echo base_url();?>docs/idcard.jpg" alt="ID Card" style="width: 100%;height: auto;">

				<div style="position: absolute;width: 100%;top: 50%;left: 0;"><span style="font-size: 21px;font-weight: bold;color: #0332AA;word-break: break-word;"><?php echo strtoupper($stuname);?></span></div>

				<div style="position: absolute;width: 100%;top: 55.5%;left: 0;"><span style="font-size: 21px;font-weight: bold;color: #0332AA"><?php echo $stuid;?></span></div>

				<div style="position: absolute;width: 100%;top: 62%;left: 0;"><span style="font-size: 15px;font-weight: bold;color: #222B39"><?php echo $mobile;?></span></div>

				<div style="position: absolute;width: 100%;bottom: 28%;left: 0;padding: 0 1rem;text-align: left;"><span style="font-size: 15px;font-weight: bold;color: #222B39"><?php echo $addressline1;?></span></div>
				<div style="position: absolute;width: 100%;bottom: 24%;left: 0;padding: 0 1rem;text-align: left;"><span style="font-size: 15px;font-weight: bold;color: #222B39"><?php echo $addressline2;?></span></div>
				<div style="position: absolute;width: 100%;bottom: 20%;left: 0;padding: 0 1rem;text-align: left;"><span style="font-size: 15px;font-weight: bold;color: #222B39"><?php echo $addressline3;?></span></div>

			</div>
           
    	</div>
    
    	<div style="text-align: center;max-width: 100%;max-height: 100%;margin:-42px auto -46px;page-break-before: always"> 
  
			<div style="position: relative;width: 325px;height: 508px;margin: 0 auto">

				<div style="position: absolute;top: 20.6%;left: 29.6%;"><img src="<?php echo base_url();?>docs/profilepic/<?php echo $studentid?>/<?php echo $profilepic;?>" alt="" style="width: 133px;height: 145px;" /></div>

				<div style="position: absolute;width: 60%;top: 32%;left: -24%;transform: rotate(-90deg);line-height: 20px;"><span style="font-size: 13px;font-weight: bold;color: #222B39;text-transform: uppercase"><?php echo $coursetype;?></span></div>

				<div style="position: absolute;top: 30%;right: -9%;transform: rotate(-90deg);"><img src="<?php echo base_url();?>docs/profilepic/<?php echo $studentid?>/<?php echo $stuid.'.png';?>" alt="" style="width: 135px;height: 60px" /></div>

				<img src="<?php echo base_url();?>docs/idcard.jpg" alt="ID Card" style="width: 100%;height: auto;">

				<div style="position: absolute;width: 100%;top: 50%;left: 0;"><span style="font-size: 21px;font-weight: bold;color: #0332AA;word-break: break-word;"><?php echo strtoupper($stuname);?></span></div>

				<div style="position: absolute;width: 100%;top: 55.5%;left: 0;"><span style="font-size: 21px;font-weight: bold;color: #0332AA"><?php echo $stuid;?></span></div>

				<div style="position: absolute;width: 100%;top: 62%;left: 0;"><span style="font-size: 15px;font-weight: bold;color: #222B39"><?php echo $mobile;?></span></div>

				<div style="position: absolute;width: 100%;bottom: 28%;left: 0;padding: 0 1rem;text-align: left;"><span style="font-size: 15px;font-weight: bold;color: #222B39"><?php echo $addressline1;?></span></div>
				<div style="position: absolute;width: 100%;bottom: 24%;left: 0;padding: 0 1rem;text-align: left;"><span style="font-size: 15px;font-weight: bold;color: #222B39"><?php echo $addressline2;?></span></div>
				<div style="position: absolute;width: 100%;bottom: 20%;left: 0;padding: 0 1rem;text-align: left;"><span style="font-size: 15px;font-weight: bold;color: #222B39"><?php echo $addressline3;?></span></div>

			</div>
           
    	</div>
    
    	<div style="text-align: center;max-width: 100%;max-height: 100%;margin:-42px auto -46px;page-break-before: always"> 
  
			<div style="position: relative;width: 325px;height: 508px;margin: 0 auto">

				<div style="position: absolute;top: 20.6%;left: 29.6%;"><img src="<?php echo base_url();?>docs/profilepic/<?php echo $studentid?>/<?php echo $profilepic;?>" alt="" style="width: 133px;height: 145px;" /></div>

				<div style="position: absolute;width: 60%;top: 32%;left: -24%;transform: rotate(-90deg);line-height: 20px;"><span style="font-size: 13px;font-weight: bold;color: #222B39;text-transform: uppercase"><?php echo $coursetype;?></span></div>

				<div style="position: absolute;top: 30%;right: -9%;transform: rotate(-90deg);"><img src="<?php echo base_url();?>docs/profilepic/<?php echo $studentid?>/<?php echo $stuid.'.png';?>" alt="" style="width: 135px;height: 60px" /></div>

				<img src="<?php echo base_url();?>docs/idcard.jpg" alt="ID Card" style="width: 100%;height: auto;">

				<div style="position: absolute;width: 100%;top: 50%;left: 0;"><span style="font-size: 21px;font-weight: bold;color: #0332AA;word-break: break-word;"><?php echo strtoupper($stuname);?></span></div>

				<div style="position: absolute;width: 100%;top: 55.5%;left: 0;"><span style="font-size: 21px;font-weight: bold;color: #0332AA"><?php echo $stuid;?></span></div>

				<div style="position: absolute;width: 100%;top: 62%;left: 0;"><span style="font-size: 15px;font-weight: bold;color: #222B39"><?php echo $mobile;?></span></div>

				<div style="position: absolute;width: 100%;bottom: 28%;left: 0;padding: 0 1rem;text-align: left;"><span style="font-size: 15px;font-weight: bold;color: #222B39"><?php echo $addressline1;?></span></div>
				<div style="position: absolute;width: 100%;bottom: 24%;left: 0;padding: 0 1rem;text-align: left;"><span style="font-size: 15px;font-weight: bold;color: #222B39"><?php echo $addressline2;?></span></div>
				<div style="position: absolute;width: 100%;bottom: 20%;left: 0;padding: 0 1rem;text-align: left;"><span style="font-size: 15px;font-weight: bold;color: #222B39"><?php echo $addressline3;?></span></div>

			</div>
           
    	</div>
    
    	<div style="text-align: center;max-width: 100%;max-height: 100%;margin:-42px auto -46px;page-break-before: always"> 
  
			<div style="position: relative;width: 325px;height: 508px;margin: 0 auto">

				<div style="position: absolute;top: 20.6%;left: 29.6%;"><img src="<?php echo base_url();?>docs/profilepic/<?php echo $studentid?>/<?php echo $profilepic;?>" alt="" style="width: 133px;height: 145px;" /></div>

				<div style="position: absolute;width: 60%;top: 32%;left: -24%;transform: rotate(-90deg);line-height: 20px;"><span style="font-size: 13px;font-weight: bold;color: #222B39;text-transform: uppercase"><?php echo $coursetype;?></span></div>

				<div style="position: absolute;top: 30%;right: -9%;transform: rotate(-90deg);"><img src="<?php echo base_url();?>docs/profilepic/<?php echo $studentid?>/<?php echo $stuid.'.png';?>" alt="" style="width: 135px;height: 60px" /></div>

				<img src="<?php echo base_url();?>docs/idcard.jpg" alt="ID Card" style="width: 100%;height: auto;">

				<div style="position: absolute;width: 100%;top: 50%;left: 0;"><span style="font-size: 21px;font-weight: bold;color: #0332AA;word-break: break-word;"><?php echo strtoupper($stuname);?></span></div>

				<div style="position: absolute;width: 100%;top: 55.5%;left: 0;"><span style="font-size: 21px;font-weight: bold;color: #0332AA"><?php echo $stuid;?></span></div>

				<div style="position: absolute;width: 100%;top: 62%;left: 0;"><span style="font-size: 15px;font-weight: bold;color: #222B39"><?php echo $mobile;?></span></div>

				<div style="position: absolute;width: 100%;bottom: 28%;left: 0;padding: 0 1rem;text-align: left;"><span style="font-size: 15px;font-weight: bold;color: #222B39"><?php echo $addressline1;?></span></div>
				<div style="position: absolute;width: 100%;bottom: 24%;left: 0;padding: 0 1rem;text-align: left;"><span style="font-size: 15px;font-weight: bold;color: #222B39"><?php echo $addressline2;?></span></div>
				<div style="position: absolute;width: 100%;bottom: 20%;left: 0;padding: 0 1rem;text-align: left;"><span style="font-size: 15px;font-weight: bold;color: #222B39"><?php echo $addressline3;?></span></div>

			</div>
           
    	</div>
    
    	<div style="text-align: center;max-width: 100%;max-height: 100%;margin:-42px auto -46px;page-break-before: always"> 
  
			<div style="position: relative;width: 325px;height: 508px;margin: 0 auto">

				<div style="position: absolute;top: 20.6%;left: 29.6%;"><img src="<?php echo base_url();?>docs/profilepic/<?php echo $studentid?>/<?php echo $profilepic;?>" alt="" style="width: 133px;height: 145px;" /></div>

				<div style="position: absolute;width: 60%;top: 32%;left: -24%;transform: rotate(-90deg);line-height: 20px;"><span style="font-size: 13px;font-weight: bold;color: #222B39;text-transform: uppercase"><?php echo $coursetype;?></span></div>

				<div style="position: absolute;top: 30%;right: -9%;transform: rotate(-90deg);"><img src="<?php echo base_url();?>docs/profilepic/<?php echo $studentid?>/<?php echo $stuid.'.png';?>" alt="" style="width: 135px;height: 60px" /></div>

				<img src="<?php echo base_url();?>docs/idcard.jpg" alt="ID Card" style="width: 100%;height: auto;">

				<div style="position: absolute;width: 100%;top: 50%;left: 0;"><span style="font-size: 21px;font-weight: bold;color: #0332AA;word-break: break-word;"><?php echo strtoupper($stuname);?></span></div>

				<div style="position: absolute;width: 100%;top: 55.5%;left: 0;"><span style="font-size: 21px;font-weight: bold;color: #0332AA"><?php echo $stuid;?></span></div>

				<div style="position: absolute;width: 100%;top: 62%;left: 0;"><span style="font-size: 15px;font-weight: bold;color: #222B39"><?php echo $mobile;?></span></div>

				<div style="position: absolute;width: 100%;bottom: 28%;left: 0;padding: 0 1rem;text-align: left;"><span style="font-size: 15px;font-weight: bold;color: #222B39"><?php echo $addressline1;?></span></div>
				<div style="position: absolute;width: 100%;bottom: 24%;left: 0;padding: 0 1rem;text-align: left;"><span style="font-size: 15px;font-weight: bold;color: #222B39"><?php echo $addressline2;?></span></div>
				<div style="position: absolute;width: 100%;bottom: 20%;left: 0;padding: 0 1rem;text-align: left;"><span style="font-size: 15px;font-weight: bold;color: #222B39"><?php echo $addressline3;?></span></div>

			</div>
           
    	</div>
    
    	<div style="text-align: center;max-width: 100%;max-height: 100%;margin:-42px auto -46px;page-break-before: always"> 
  
			<div style="position: relative;width: 325px;height: 508px;margin: 0 auto">

				<div style="position: absolute;top: 20.6%;left: 29.6%;"><img src="<?php echo base_url();?>docs/profilepic/<?php echo $studentid?>/<?php echo $profilepic;?>" alt="" style="width: 133px;height: 145px;" /></div>

				<div style="position: absolute;width: 60%;top: 32%;left: -24%;transform: rotate(-90deg);line-height: 20px;"><span style="font-size: 13px;font-weight: bold;color: #222B39;text-transform: uppercase"><?php echo $coursetype;?></span></div>

				<div style="position: absolute;top: 30%;right: -9%;transform: rotate(-90deg);"><img src="<?php echo base_url();?>docs/profilepic/<?php echo $studentid?>/<?php echo $stuid.'.png';?>" alt="" style="width: 135px;height: 60px" /></div>

				<img src="<?php echo base_url();?>docs/idcard.jpg" alt="ID Card" style="width: 100%;height: auto;">

				<div style="position: absolute;width: 100%;top: 50%;left: 0;"><span style="font-size: 21px;font-weight: bold;color: #0332AA;word-break: break-word;"><?php echo strtoupper($stuname);?></span></div>

				<div style="position: absolute;width: 100%;top: 55.5%;left: 0;"><span style="font-size: 21px;font-weight: bold;color: #0332AA"><?php echo $stuid;?></span></div>

				<div style="position: absolute;width: 100%;top: 62%;left: 0;"><span style="font-size: 15px;font-weight: bold;color: #222B39"><?php echo $mobile;?></span></div>

				<div style="position: absolute;width: 100%;bottom: 28%;left: 0;padding: 0 1rem;text-align: left;"><span style="font-size: 15px;font-weight: bold;color: #222B39"><?php echo $addressline1;?></span></div>
				<div style="position: absolute;width: 100%;bottom: 24%;left: 0;padding: 0 1rem;text-align: left;"><span style="font-size: 15px;font-weight: bold;color: #222B39"><?php echo $addressline2;?></span></div>
				<div style="position: absolute;width: 100%;bottom: 20%;left: 0;padding: 0 1rem;text-align: left;"><span style="font-size: 15px;font-weight: bold;color: #222B39"><?php echo $addressline3;?></span></div>

			</div>
           
    	</div>
    
    <?php } ?>

<?php if($ptype!="preview"){ ?>

</body>
</html>


<?php } ?>
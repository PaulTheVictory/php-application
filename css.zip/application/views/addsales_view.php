 <link href="<?php  echo base_url(); ?>css/jquery-ui-custom.css" rel="stylesheet" type="text/css" />
 <script src="<?php  echo base_url(); ?>js/jquery-ui.min.js" type="text/javascript"></script>
<div id="pagetitle">

	<div class="wrap">
    
        <h1><?php  if(isset($_GET["type"]) && ($_GET["type"] == "bill")) {echo "Add Bill";} else { echo "Add Sales";}?></h1>
        
	</div>
    
</div>
 
 <style type="text/css">
     
     
     .sales-table {
    background-color: #fff;
    border: 1px solid #549ce5;
    border-collapse: collapse;
    height: 100%;
    width: 100%;
}

.total-table{
    background-color: #fff;
    border-collapse: collapse;
    height: auto;
    width: 300px;
    float: right;
    margin-top: 10px;
}


.total-table .estimatediscount {
    background-color: #fff;
    border: 1px solid #999;
    border-radius: 3px;
    color: #333;
    padding: 2px 5px;
    text-align: right;
    width: 75px;
    
}

.total-table .estimatetax , .total-table .paid {
    background-color: #fff;
    border: 1px solid #999;
    border-radius: 3px;
    color: #333;
    padding: 2px 5px;
    text-align: right;
    width: 75px;
}

.total-table td.grand {
    background: #2e71b6 none repeat scroll 0 0;
    color: #fff;
    font-size: 15px;
    padding: 8px 10px;
    text-align: right;
}


     

#tablehead td {
    background: #2e71b6 none repeat scroll 0 0;
    color: #fff;
    line-height: 25px;
    text-align: center;
}

.sales-table td, .total-table td {
    color: #333;
    font-size: 13px;
    padding: 8px 3px;
    text-align: left;
    vertical-align: middle;
}

.total-table td { text-align: right; }

input[type="text"] {

    margin: 0 0 5px;
    text-align: center;

    padding: 5px;
 
}


.sales-table tr td:nth-child(2){
    width: 50%;
}

.row-element {
    display: inline-block;
    height: auto;
    margin: 3px auto;
    width: 100%;
}

.ui-menu {
    
    max-height: 250px;
    overflow-y: scroll;
    overflow-x: hidden;
}

     
 </style>
<div class="maincontent">

	<div class="wrap">
    
            <div id="course-container" class="add-course">
                
                 <div class="row-element">
                     <span class="content"><input name="cust_type" checked type="radio" value="" class="unitname"  id="custEle">&nbsp;&nbsp;Customer Bill</span>
                    <span class="content"><input name="cust_type"  type="radio" value="" class="unitname" id="elecEle">&nbsp;&nbsp;Electrician Bill</span>
                     
                </div>
               
                 <div class="row-element">
                     <span class="content"><input style="text-align: left" placeholder="Customer Name" type="text" value="" class="sname"></span>
                </div>
                
                 <div class="row-element">
                    <span class="content"><input style="text-align: left" placeholder="Mobile Number" type="text" value="" class="smobile" ></span>
                </div>
                
                 <!--div class="row-element">
                     <span class="content"><input style="text-align: left" type="text" placeholder="Email" value="" class="semail" ></span>
                </div-->
                                
                <div class="row-element">
                    <span class="content amtdue"></span>
                </div>
                
               <table class="sales-table " style="">
                   <tbody>
                       <tr id="tablehead">
                           <td> S.No</td>
                           <!--td >Group</td>
                           <td >Model</td-->
                           <td >Item name</td>
                           <td >Rate (Rs)</td>
                           <td >Qty</td>
                           <td >Unit(s)</td>
                           <?php if(isset($_GET["type"]) && ($_GET["type"] == "bill")) {echo "<td>Tax (%)</td>";}?>
                           <td >Total Amount(Rs)</td>
                       </tr>
                       
                       <tr >
                            <td style="text-align: center"><span class="sno">1</span></td>
                           <!--td ><input type="text" value="" class="sgroup"  style="text-align: left"></td>
                           <td ><input type="text" value="" class="smodel"  style="text-align: left"></td-->
                           <td ><input type="text" value="" class="sitem" style="text-align: left"></td>
                           <td ><input type="text" value="" class="srate" ><input type="hidden" value="" class="sfrate" ></td>
                           <td ><input type="text" value="" class="sqty" ></td>
                           <td ><input type="text" value="" tabindex="-1" class="sunits nofocus" ></td>
                           <?php if(isset($_GET["type"]) && ($_GET["type"] == "bill")) {echo '<td ><input type="text" value="" tabindex="-1" class="stax" ></td>';}?>
                           <td ><input type="text" value="" class="samount lastele" ></td>
                       </tr>
                       
                   </tbody>
               </table>
                
                <table class="total-table">
                   <tbody>
                        <tr><td>Total</td><td style="font-size: 18px" class="estimatetotal">0</td></tr>
                        <tr style="display: none;"><td>Discount</td><td><input value="0" class="estimatediscount"></td></tr>
                        <tr class="gtotal"><td class="grand">Grand Total</td><td class="grand estimategrandvalue">0</td></tr>
                         <?php if(isset($_GET["type"]) && ($_GET["type"] == "bill")) {echo '';} else { echo '<tr ><td >Don\'t display rate</td><td><input type="checkbox" class="norate"></td></tr>'; }?>
                        <tr ><td >Amount paid</td><td><input value="0" class="paid paidele"></td></tr>
                        <tr class="save"><td ></td><td ><input class="btn_save" type="button" value="Save"></td></tr>
                        
                       
                   </tbody>
               </table>
                 
                
            </div>
        
        </div>
    
    </div>
 
<script type="text/javascript">
$(document).ready(function() {
    
    $(".add-course").find(".sname").focus();
    
     $(".add-course").find("input").each(function(){
            if($(this).hasClass("lastele")) {
                
            } else {
            $(this).keyup(function(event){
                gotoNext(event,this);
            });
        }

        });
    
    
     $(".sname").autocomplete({
            source: function (request, response) {
                $.ajax({
                    url: "addsales/nameSearch",
                    contentType: "application/jsonp",
                    
                    data: {
                        term: request.term
                    },
                    success: function (data) {
                        data = $.parseJSON(data);
                        response(
                                $.map(data, function (item) {
                                    return {
                                        value: item.name,
                                        cnumber:item.mobile,
                                        ide:item.ide
                                    };
                                })
                                );
                    }
                });
            },
            select: function (event, ui) {
                
                $(".smobile").val(ui.item.cnumber);
                checkUserDue(ui.item.ide);
          
            }
            
        }).data("uiAutocomplete")._renderItem = function (ul, item) {

             return $("<li></li>")
                    .data("item.autocomplete", item)
                    .append('<a><div style="height: auto; width: auto; display: inline-block;"><p style="margin: 0px; padding: 0px; height: 20px; width: 100%; line-height: 30px;">' + item.value + ' , '+item.cnumber+'</p></div></a>')
                    .appendTo(ul);
        };
        
        
        $(".smobile").autocomplete({
            source: function (request, response) {
                $.ajax({
                    url: "addsales/mobileSearch",
                    contentType: "application/jsonp",
                    
                    data: {
                        term: request.term
                    },
                    success: function (data) {
                        data = $.parseJSON(data);
                        response(
                                $.map(data, function (item) {
                                    return {
                                        value: item.mobile,
                                        name:item.name,
                                        ide:item.ide
                                    };
                                })
                                );
                    }
                });
            },
            select: function (event, ui) {
                
                $(".sname").val(ui.item.name);
                checkUserDue(ui.item.ide);
          
            }
            
        }).data("uiAutocomplete")._renderItem = function (ul, item) {

             return $("<li></li>")
                    .data("item.autocomplete", item)
                    .append('<a><div style="height: auto; width: auto; display: inline-block;"><p style="margin: 0px; padding: 0px; height: 20px; width: 100%; line-height: 30px;">' + item.value + ' , '+ item.name+'</p> </div></a>')
                    .appendTo(ul);
        };
        
    
   $(document).delegate(".sitem","keydown",function(){
       
        var ide = $(this).attr("data-id");
        var type = $(this).attr("data-type");
        
        autoItemSuggest(this,ide,type);
        
    });
    
    
    $(document).delegate(".sqty","keyup",function(event){
       
       var total = 0;
       var qty = $(this).val();
       var rate = $(this).closest("tr").find(".srate").val();
       
       if(rate !== "" && qty !== "") {
           rate = parseFloat(rate).toFixed(2);
           total =  rate * parseFloat(qty);
       }
      
        total = parseFloat(total).toFixed(2);
        $(this).closest("tr").find(".samount").val(total);  
       
       totalRateUpdate();
       
              
    });
    
    
    $(document).delegate(".srate","keyup",function(event){
       
       var total = 0;
       var rate = $(this).val();
       var qty = $(this).closest("tr").find(".sqty").val();
       
       if(rate !== "" && qty !== "") {
           rate = parseFloat(rate).toFixed(2);
           total =  rate * parseInt(qty);
       }
      
        total = parseFloat(total).toFixed(2);
        $(this).closest("tr").find(".samount").val(total);  
       
       totalRateUpdate();
       
              
    });
    
   
    
     $(document).delegate(".remove","click",function(event){
       
       $(this).closest("tr").remove();
       
       var cnt = 1;
       $('.sales-table').find("td span.sno").each(function(){ 
           
           $(this).html(cnt); cnt++;
       });   
       
       totalRateUpdate();
      // $(this).closest("tr").find(".sitem").focus();
              
    });
    
    
    $(document).delegate(".estimatediscount","keyup",function(){
       
       totalRateUpdate();       
              
    });
    
     
    
    $(document).delegate(".samount","keyup",function(event){
       
       if(event.keyCode === 13){
           createNewRow();           
       }
        
    });
    
    
    function checkUserDue(ide){
    
         $.get('addsales/checkDue', {
                     'ide':ide
                     }, function(o) {
                         var data = $.parseJSON(o);
                     if(data["status"] === "due") {
                         var due = data["amt"];
                         $(".amtdue").html("This Cusmtomer Amount due is <font style=\"font-size:20px;color:red\">Rs."+due+"</font>");
                     }
          });
          
        
    }
    

    
    
    function createNewRow(){
    
    
            var rowCount = $('.sales-table >tbody >tr').length;
           var newclass = "newbox"+rowCount;
           
           var appednString = '<td style="text-align: center"><span class="sno">'+rowCount+'</span></td><!--td ><input type="text" value="" class="sgroup '+newclass+'"  style="text-align: left"></td><td ><input type="text" value="" class="smodel"  style="text-align: left"></td--><td ><input type="text" value="" class="sitem hyyo '+newclass+'" style="text-align: left"></td>\n\
                             <td ><input type="text" value="" class="srate '+newclass+'" ><input type="hidden" value="" class="sfrate '+newclass+'" ></td><td ><input type="text" value="" class="sqty '+newclass+'" ></td>\n\
                             <td ><input type="text" value="" tabindex="-1" class="sunits '+newclass+' nofocus" ></td><?php if(isset($_GET["type"]) && ($_GET["type"] == "bill")) {echo '<td ><input tabindex="-1" type="text" value="" class="stax newbox" ></td>';}?><td ><input style="width:120px" type="text" value="" class="samount '+newclass+' lastele" ><a class="remove" href="javascript:void(0)" style="margin-left:10px;font-size:16px">x</a></td>';
           
           var trElement = $("<tr ></tr>");
           trElement.append(appednString);
           
           $('.sales-table').append(trElement);   
          
           $('.sales-table').find(".hyyo").focus();
           $('.sales-table').find(".hyyo").removeClass("hyyo");
           
           $('.sales-table').find("."+newclass).each(function(){
            
                if($(this).hasClass("lastele")) { } else {
                    $(this).keyup(function(event){
                        gotoNext(event,this);
                    });
                }

            });
            
            $('.sales-table').find(".newbox").each(function(){
            
                    $(this).keyup(function(event){
                        gotoNext(event,this);
                    });
            });
           
           //$("html, body").animate({ scrollTop: $(document).height() }, 1000);
    
    }
    
    
    function gotoNext(event,obj){
        
        if(event.keyCode == 13){

                    if($(obj).hasClass("norate")) { 
                        
                        $(".paidele").focus();
                        
                    }else if($(obj).hasClass("paidele")) { 
                        $(".btn_save").trigger("click");
                    }else {
                        var ty = $(obj).next();
                        event.preventDefault();
                        var cnt = 1;
                        var ele = $('input[type="text"]')[$('input[type="text"]').index(obj)+1];
                        if($(ele).hasClass("nofocus")) {
                            cnt = 2;
                        }
                        $('input[type="text"]')[$('input[type="text"]').index(obj)+cnt].focus();
                        $('input[type="text"]')[$('input[type="text"]').index(obj)+cnt].select();
                    }
                }
    }
    
   
    
    function autoItemSuggest(obj,ide,type){
        
  
        $(obj).autocomplete({
            source: function (request, response) {
                $.ajax({
                    url: "addsales/itemSearch",
                    contentType: "application/jsonp",
                    
                    data: {
                        test:request.term,
                        term: ide,
                        type: type
                    },
                    success: function (data) {
                        data = $.parseJSON(data);
                        response(
                                $.map(data, function (item) {
                                    return {
                                        value: item.name,
                                        name: item.name,
                                        sellprice:item.sellprice,
                                        sellpriceelec:item.sellpriceelec,
                                        tax:item.tax,
                                        unit:item.unit
                                    };
                                })
                                );
                    }
                });
            },
            select: function (event, ui) {
                
                var rate = "";
                var tax = "";
                var finalrate = "";
                if($('#elecEle').is(':checked'))  {
                    rate = ui.item.sellpriceelec;
                } else if ($('#custEle').is(':checked')) {
                    rate = ui.item.sellprice;
                }
                
                finalrate = rate;
                
                 if($(obj).closest("tr").find(".stax").length) {
                     $(obj).closest("tr").find(".stax").val(ui.item.tax);
                     var tax = ui.item.tax;
                     var ftaxamt = parseFloat(rate) * ( parseFloat(tax) * .01);
                     var staxamt = parseFloat(ftaxamt) * ( parseFloat(tax) * .01);
                     
                     var finaltaxamt = ftaxamt - staxamt;
                     
                     rate = parseFloat(rate) - finaltaxamt;
                     rate = parseFloat(rate).toFixed(2);
                     
                 }else {
                     
                 }
                
                 $(obj).val(ui.item.name);
                 $(obj).closest("tr").find(".srate").val(rate);
                 $(obj).closest("tr").find(".sfrate").val(finalrate);
                 $(obj).closest("tr").find(".sqty").val("1");
                 $(obj).closest("tr").find(".sunits").val(ui.item.unit);
                 $(obj).closest("tr").find(".samount").val(rate);
                // $(obj).closest("tr").find(".sqty").select();
              
                 
                 totalRateUpdate();
                     
            }
        });
        
           
    }
    
    function totalRateUpdate(){
        
         var totalRate = 0; var discountRate = 0; var grandTotalRate = 0;
                 $(".sales-table").find(".samount").each(function(){
                    
                    if($(this).val() === "") { } else {
                      totalRate = parseFloat($(this).val()) + totalRate;
                    }
                    
                 });
                 
                 totalRate = parseFloat(totalRate).toFixed(2);
                 $(".estimatetotal").html(totalRate);
                 
                 discountRate = $(".estimatediscount").val();
                 
                 var taxArray = [];
                 $(".sales-table").find(".stax").each(function(){
                    
                    var temptax = $(this).val();
                    var temprate = $(this).closest("tr").find(".samount").val();
                    temptax = temptax.toString();
                    
                     taxArray.push({tax:temptax,value:temprate});
                    
                 });
                 
                 $(".total-table").find(".tot_amt").each(function(){
                    $(this).html("0"); 
                 });
                 
                 var taxHTML = ""; 
                 
                 $.map(taxArray,function(item,index){
                     
                     var taxamt = 0;
                     var tempname  = "tax_value_"+item.tax;
                     tempname = tempname.replace(".","");
                     if($(".total-table").find("."+tempname).length){
                         
                         var temptot = $(".total-table").find("."+tempname).find(".tot_amt").html();
                         temptot = parseFloat(temptot) + parseFloat(item.value);
                         temptot = parseFloat(temptot).toFixed(2);
                         $(".total-table").find("."+tempname).find(".tot_amt").html(temptot);
                         
                         taxamt = parseFloat(temptot)*parseFloat(item.tax)*.01
                         taxamt = parseFloat(taxamt).toFixed(2);
                         $(".total-table").find("."+tempname).find(".tot_tax_amt").html(taxamt);
                         
                     } else {
                         if(item.tax === "0") { } else {
                            taxamt = parseFloat(item.value)*parseFloat(item.tax)*.01
                            taxHTML = "<tr class=\""+tempname+"\"><td>VAT "+item.tax+"% on : <span class=\"tot_amt\">"+item.value+"</span></td><td class=\"tot_tax_amt\">"+taxamt+"</td></tr>";
                            $(taxHTML).insertBefore($(".gtotal"));
                         }
                     }
                     
                 });
                 
                 var taxTotAmount = 0;
                 $(".total-table").find(".tot_tax_amt").each(function(){
                 
                    taxTotAmount = taxTotAmount + parseFloat($(this).html());
                 
                 });
                 
                 
               //  $(taxHTML).insertBefore($(".gtotal"));
                 
                 
                 grandTotalRate = totalRate - parseInt(discountRate) ;
                 grandTotalRate = grandTotalRate + taxTotAmount;
                  $(".estimategrandvalue").html(parseFloat(grandTotalRate).toFixed(2));
        
    }
    
    
    $(".btn_save").click(function(){
    
       <?php
       if(isset($_GET["type"]) && ($_GET["type"] == "bill")) { ?>
          insertBill();           
      <?php } else { ?>
          insertEstimate();
           
       <?php }?>
          
    
    });
    
    
    function insertBill(){
         
           var sname= $(".sname").val();
         var smobile= $(".smobile").val();
         var semail= $(".semail").val();
    
         if(sname === "") { alert("please enter customer name"); return;}
         
          var sitem = [] , srate =[] , sqty = [], sunits = [] , stax = []; samount = [];
          $(".sales-table ").find(".sitem").each(function(){
              var stemp = $(this).val();
              if(stemp !== "") { sitem.push(stemp);}
          });
          
          $(".sales-table ").find(".srate").each(function(){
              var stemp = $(this).val();
              if(stemp !== "") { srate.push(stemp);}
          });
          
          $(".sales-table ").find(".sqty").each(function(){
              var stemp = $(this).val();
              if(stemp !== "") { sqty.push(stemp);}
          });
          
          $(".sales-table ").find(".sunits").each(function(){
              var stemp = $(this).val();
              sunits.push(stemp);
          });
          
         $(".sales-table ").find(".stax").each(function(){
              var stemp = $(this).val();
              if(stemp !== "") { stax.push(stemp);}
          });
          
          $(".sales-table ").find(".samount").each(function(){
              var stemp = $(this).val();
              if(stemp !== "") { samount.push(stemp);}
          });
          
          var grand = $(".estimategrandvalue").html();
           var payments = $(".paid").val();
           
            if(sitem.length === 0) { alert("please enter any item name"); return;}
            
            $(this).val("Processing...");
          
         $.ajax({
            type: "POST",
            url: "addsales/insertBill",
            dataType: "json",
            data: { sname:sname,smobile:smobile,semail:semail,sitem: sitem, srate:srate, sqty : sqty,stax : stax, sunits:sunits, samount:samount, spayments:payments, sgrand:grand },
            success: function(data){
                //var data = $.parseJSON(msg);
                if(data["status"] == "success") {
                     
                     var t = confirm("Do you want to print this bill") 
                     if(t) { window.open('addsales/printSalesDetails?ide=' + data["bill_no"]+'&type=bill'); location.href = "addsales?type=bill"; } else { location.href = "addsales?type=bill"; }
                     
                }
            }
        });
         
         
     }
     
     
     function insertEstimate(){
         
           var sname= $(".sname").val();
         var smobile= $(".smobile").val();
         var semail= $(".semail").val();
    
         if(sname === "") { alert("please enter customer name"); return;}
         
          var sitem = [] , srate =[] , sqty = [], sunits = [] , stax = []; samount = [];
          $(".sales-table ").find(".sitem").each(function(){
              var stemp = $(this).val();
              if(stemp !== "") { sitem.push(stemp);}
          });
          
          $(".sales-table ").find(".srate").each(function(){
              var stemp = $(this).val();
              if(stemp !== "") { srate.push(stemp);}
          });
          
          $(".sales-table ").find(".sqty").each(function(){
              var stemp = $(this).val();
              if(stemp !== "") { sqty.push(stemp);}
          });
          
          $(".sales-table ").find(".sunits").each(function(){
              var stemp = $(this).val();
              sunits.push(stemp);
          });
          
        /*  $(".sales-table ").find(".stax").each(function(){
              var stemp = $(this).val();
              if(stemp !== "") { stax.push(stemp);}
          });*/
          
          $(".sales-table ").find(".samount").each(function(){
              var stemp = $(this).val();
              if(stemp !== "") { samount.push(stemp);}
          });
          
          var grand = $(".estimategrandvalue").html();
           var payments = $(".paid").val();
           
            if(sitem.length === 0) { alert("please enter any item name"); return;}
            
            $(this).val("Processing...");
          
         $.ajax({
            type: "POST",
            url: "addsales/insertEstimate",
            dataType: "json",
            data: { sname:sname,smobile:smobile,semail:semail,sitem: sitem, srate:srate, sqty : sqty, sunits:sunits, samount:samount, spayments:payments, sgrand:grand },
            success: function(data){
                //var data = $.parseJSON(msg);
                if(data["status"] == "success") {
                     
                     var t = confirm("Do you want to print this estimate");
                     if(t) { 
                         if( ($(".norate").length) && ($(".norate").is(":checked")) ) {
                             window.open('addsales/printSalesDetails?ide=' + data["bill_no"]+'&norate=no'); 
                         } else {
                             window.open('addsales/printSalesDetails?ide=' + data["bill_no"]); 
                         }
                         
                         location.href = "addsales"; 
                         
                     } else { location.href = "addsales"; }
                     
                }
            }
        });
         
         
     }
     	
	
});
</script>
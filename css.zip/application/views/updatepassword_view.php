 <link href="<?php  echo base_url(); ?>css/jquery-ui.min.css?v=1.4" rel="stylesheet" type="text/css" />
 <script src="<?php  echo base_url(); ?>js/jquery-ui.min.js?v=1.3" type="text/javascript"></script>
 <link href="<?php  echo base_url(); ?>css/chosen.min.css?v=1.3" rel="stylesheet" type="text/css" />
  <script src="<?php  echo base_url(); ?>js/chosen.jquery.min.js?v=1.2" type="text/javascript"></script>
 <style type="text/css">
     
     .ui-selectmenu-button.ui-button{ width: 97%; padding:13px;}
     #ugroups-button{border: 1px solid #D7DFF0;background: #fff;font-size: 14px;color:#536485;padding: 10px}
     .maincontent ul li.search-choice { height:auto; }
     .maincontent ul li.search-choice a{ height:auto; font-size: 14px;color:#536485}
     .response p { float: right;font-size:12px;color:#eb345e;}
     

#centers_chosen  {border: 1px solid #D7DFF0;background: #fff;padding: 8px 0px;}
#ucourses_chosen  {border: 1px solid #D7DFF0;background: #fff;padding: 8px 0px;}
 .chosen-container-multi .chosen-choices {border: 0px;background: none}

.sortable tr td a:hover { text-decoration: underline; }
.sortable tr td span{ font-size: 14px;color: #364159 }
 .chosen-container-multi .chosen-choices li.search-choice { background: #6884CC;border-radius: 5px;}
.chosen-container-multi .chosen-choices li.search-choice {color: #fff;}

 </style>

	<div class="wrap dynamic-width" style="float: left;position: relative;min-width: 800px">
     <div style="margin-top: 10px; width: 99%; height: 50px; text-align: right;">
         <span style="font-weight: bold;font-size: 20px;padding: 10px;float:left;color: #364159">Update Password</span>
         
     </div>         
            <div id="course-container" class="add-course">
<?php echo form_open('updatepassword/updatePassword', array('id' => 'userForm')) ?>
                
                 <div class="row-element">
                    <span class="title">Enter Old Password</span>
                    <span class="content"><input style="width:50%" placeholder="Enter Old Password" type="password" value="" name = "oldpassword" class="oldpassword"></span>
                </div>
                
                <div class="row-element">
                    <span class="title">Enter New Password</span>
                    <span class="content"><input style="width:50%" placeholder="Enter New Password" type="password" value="" name = "newpassword" class="newpassword"></span>
                </div>
                
                <div class="row-element">
                    <span class="title">Confirm Password</span>
                    <span class="content"><input style="width:50%" placeholder="Confirm Password" type="password" value="" name = "confirmpassword" class="confirmpassword"></span>
                </div>
                
            <?php echo form_close() ?>
                
            </div>
            
       
     <div style="margin-top: 0px; width: 98%; height: 70px; text-align: right;">
         <span  style="margin: 0px auto; float:right;margin-top: 18px;padding: 10px; color: #fff; background: #4f6fc4 none repeat scroll 0% 0%; border-radius:5px;cursor: pointer" class="btn savebtn" href="#">Save</span>
         <a style="margin: 0px auto; float:right;margin-top: 18px;margin-right:18px;padding: 9px 10px; color: #0332AA; background: linear-gradient(0deg, #FFFFFF, #FFFFFF), #C4C4C4;border: 1px solid #0332AA; border-radius:5px" class="btn" href="<?php echo base_url(); ?>users">Back</a>
         <span class="response" style="margin: 0px auto; float:right;width: 80%; height: 30px;margin-top:20px"></span>
     </div>   
    
        
        </div>
    
      

    
<script type="text/javascript">
$(document).ready(function() {
    
	$(".savebtn").click(function(){
        
                var oldpassword = $(".oldpassword").val();
                if ($.trim(oldpassword)=="") {  
                    alert("Please enter valid old password");  
                    return;  
                } 
                
                var newpassword = $(".newpassword").val();
                if ($.trim(newpassword)=="") {  
                    alert("Please enter valid new password");  
                    return;  
                } 
                
                var confirmpassword = $(".confirmpassword").val();               
                if ($.trim(confirmpassword)=="") {  
                    alert("Please enter valid confirm password");  
                    return;  
                } 
		
		 	if (newpassword!=confirmpassword) {
			 	alert("Password Mismatch");  
                    return;  
			} 
         
               if($(".response").hasClass('progress')) { return;}
               $(".response").html('').text('Progressing...');
                $(".response").addClass('progress');
              
               
                var userForm = $("#userForm");

                    $.ajax({
                        url: userForm.attr('action'),
                        type: 'post',
                        data: userForm.serialize(),
                        success: function(o){
                            
                            var response = $.parseJSON(o);
                            $(".response").html('');
                            if(response.status === 'success') {
                       
                              $(".response").css("color","rgb(25, 71, 15)");
                              $(".response").text(response.message);
                              $(location).prop('href', 'updatepassword');
                               
                            } else {
                                
                               $(".response").append(response.message); 
                               $(".response").removeClass('progress');
                           
                            }

                        }
                    });
                   
                              
            });
	
   	
});
</script>
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/dataTables.css?v=1.5" />
<script src="<?php echo base_url(); ?>js/jquery.dataTables.js?v=1.0" type="text/javascript"></script>
<style type="text/css">


.dataTables_wrapper input[type="text"] {
    padding: 0;
}
.dataTables_wrapper select {
    padding: 0;
}

.sortable thead tr  {
    background: #E6EBF7;

/* g8 */
border: 1px solid #D7DFF0;
box-sizing: border-box;
border-radius: 10px 10px 0px 0px;
 

}
.sortable tr th {
    border-right: 0px;
    padding: 15px 0;font-size: 13px;
      color: #6F83AA;
   cursor: pointer;
   text-align: center;

}

.sortable tr th:nth-child(1) {
  background: #E6EBF7 ;
   text-align: left;padding-left: 10px;
}

.sortable tr th:nth-child(2) {
  background: #E6EBF7;
 
   text-align: center;
}





.sortable tr td {
    border-right: 0px;
    padding: 15px 5px;
    text-align: center;font-size: 13px;
    min-width:100px;vertical-align: middle;
}
.sortable tr td a {
    color: #364159;
}

#profile-right h2 {
    margin: 0px 0px 10px 0px;
}

.qtable_length { width: auto !important; } #qtable_filter { right:170px !important;}
#qtable_filter input { padding-top:4px;background: #fff url('<?php echo base_url(); ?>/images/search.png') no-repeat center left;background-position-x: 10px;border: 1px solid #D7DFF0; line-height: 32px;margin-left: 10px;width:260px;border-radius: 5px;text-indent: 30px;font-size: 13px;}
.sortable tr td a:hover { text-decoration: underline; }
</style>
<script type="text/javascript">
$(document).ready(function(){	
		
	
          var columnData = [
              
                   
                    { "data": "appno" },
                    { "data": "coursename" },
                    { "data": "center" },
                    { "data": "remitted" },
                    { "data": "deduction" },
                    { "data": "refundamount" },
                    { "data": "gstrefund" },
                    { "data": "refundtotal" },
                    { "data": "status" },
                    { "data": "remarks" }
                    
                  ];
        // columnData.push( {data: "id","visible":true} );
         //columnData.push( {data: "item_name_search","visible":false} );
         
       
        var oTable = $('#qtable').dataTable({
                    "bProcessing": true,
                    "bServerSide": true,
                    "sPaginationType": "full_numbers",
                    "ajax": {
                    "url": 'sturefund/GetStudentReundLists',
                    "type": "POST"
                     }, 
                     "oLanguage": {
                        "sProcessing": "<img src='<?php echo base_url(); ?>images/loader.gif'>"
                    },
                    'iDisplayLength': 10,
                    "columns": columnData,
                    "fnDrawCallback": function( oSettings ) {
                                              
  
                            
                    }
         }); 
         
         
         
  
	
});
</script>

<main>
	<div class="container-fluid">
<div class="wrap dynamic-width" >
    
    <div class="row mb-4">
            
    <div class="col-xs-6">
         <span style="font-weight: bold;font-size: 20px;padding: 10px;float:left;color: #364159">Refund List</span>
                </div>
                
         </div>         
         <?php echo $this->table->generate();  ?>             
         
        
        
        </div>
    
 </div>
</main>
    


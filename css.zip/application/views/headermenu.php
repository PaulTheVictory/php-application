<?php 

	//print_r($roleaccess['Admissions']);

?>

<?php if(isset($roleaccess['Students'])) { ?>

<li><a href="#"><i class="icons-students"></i> <span>Students</span> <em class="mdi mdi-chevron-down"></em></a>

	<ul>
  
	   <li class="<?=($this->uri->segment(1)==='students')?'active':''?>"><a href="<?php echo base_url();?>students"> <span>Students List</span></a></li>
	  
	  <?php if(isset($roleaccess['Batches'][3]) && $roleaccess['Batches'][3]=="y") { ?>
	  	<li class="<?=($this->uri->segment(1)==='studentbatches')?'active':''?>"><a href="<?php echo base_url();?>studentbatches" title="Batches"><span>Batches</span></a></li>
	  <?php } ?>
	  
	  <?php if(isset($roleaccess['ID Card Batch Print'][3]) && $roleaccess['ID Card Batch Print'][3]=="y") { ?>
	  	<li class="<?=($this->uri->segment(1)==='idcardprint')?'active':''?>"><a href="<?php echo base_url();?>idcardprint" title="ID Card Print"><span>ID Card Print</span></a></li>
	  <?php } ?>	
	  
	</ul>

</li>

<?php } ?>

<?php //if($user['role'] === 'admin') { ?>

<?php if(isset($roleaccess['Admissions'])) { ?>

<li><a href="#"><i class="icons-admissions"></i> <span>Admissions</span> <em class="mdi mdi-chevron-down"></em></a>
	<ul>
  
  <?php if(isset($roleaccess['Admissions']['Courses'][3]) && $roleaccess['Admissions']['Courses'][3]=="y") { ?>
	  <li class="<?=($this->uri->segment(1)==='courses')?'active':''?>"><a href="<?php echo base_url();?>courses" title="Patients List"><span>Courses</span></a></li>
  <?php } ?>
  
  <?php if(isset($roleaccess['Admissions']['Qualification'][3]) && $roleaccess['Admissions']['Qualification'][3]=="y") { ?>
	  <li class="<?=($this->uri->segment(1)==='qualificationlist')?'active':''?>"><a href="<?php echo base_url();?>qualificationlist"><span>Qualification</span></a></li>
  <?php } ?>
  
  <?php if(isset($roleaccess['Admissions']['Admission Request'][3]) && $roleaccess['Admissions']['Admission Request'][3]=="y") { ?>
	  <li class="<?=($this->uri->segment(1)==='admissions')?'active':''?>"><a href="<?php echo base_url();?>admissions"><span>Admission Requests</span></a></li>
  <?php } ?>
  
  <?php if(isset($roleaccess['Admissions']['Course Change'][3]) && $roleaccess['Admissions']['Course Change'][3]=="y") { ?>
	  <li class="<?=($this->uri->segment(1)==='coursechange')?'active':''?>"><a href="<?php echo base_url();?>coursechange"><span>Course Change</span></a></li>
	  <?php } ?>
  
	</ul>
</li>
 	
 <?php } ?>	
 	
 	
 <?php if(isset($roleaccess['Accounts'])) { ?>
  	
<li><a href="#"><i class="icons-accounts"></i> <span>Accounts</span> <em class="mdi mdi-chevron-down"></em></a>
	<ul>
  
  	<?php if(isset($roleaccess['Accounts']['Bill List'][3]) && $roleaccess['Accounts']['Bill List'][3]=="y") { ?>
	  <li class="<?=($this->input->get('type')==='paid')?'active':''?>"><a href="<?php echo base_url();?>payments?type=paid" title="Bill List"><span>Bill List</span></a></li>
  	<?php } ?>
  
  	<?php if(isset($roleaccess['Accounts']['Unpaid List'][3]) && $roleaccess['Accounts']['Unpaid List'][3]=="y") { ?>	  
	  <li class="<?=($this->input->get('type')==='unpaid')?'active':''?>"><a href="<?php echo base_url();?>payments?type=unpaid"><span>Unpaid list</span></a></li>
	<?php } ?>
  
  	<?php if(isset($roleaccess['Accounts']['Due List'][3]) && $roleaccess['Accounts']['Due List'][3]=="y") { ?>
	    <li class="<?=($this->uri->segment(1)==='duelist')?'active':''?>"><a href="<?php echo base_url();?>duelist"><span>Due List</span></a></li>
	<?php } ?>
  
  	<?php if(isset($roleaccess['Accounts']['Refund'][3]) && $roleaccess['Accounts']['Refund'][3]=="y") { ?>
	    <li class="<?=($this->uri->segment(1)==='refund')?'active':''?>"><a href="<?php echo base_url();?>refund"><span>Refund</span></a></li>
	<?php } ?>
  
  	<?php if(isset($roleaccess['Accounts']['Worldline'][3]) && $roleaccess['Accounts']['Worldline'][3]=="y") { ?>
  		<li class="<?=($this->uri->segment(1)==='worldlinepg')?'active':''?>"><a href="<?php echo base_url();?>worldlinepg"><span>Worldline</span></a></li>
	<?php } ?>
  	 
	</ul>
</li>
 	
 <?php } ?>	
 	 <?php if(isset($roleaccess['Students']['Allocation'])) { ?>
  	
<li><a href="#"><i class="icons-students"></i> <span>Allocation</span> <em class="mdi mdi-chevron-down"></em></a>
	<ul>
           <?php if(isset($roleaccess['Students']['Allocation'][3]) && $roleaccess['Students']['Allocation'][3]=="y") { ?>     
  	  <li class="<?=($this->input->get('type')==='allocation')?'active':''?>"><a href="<?php echo base_url();?>allocation" title="Year Allocation"><span>Year Allocation</span></a></li>
          <?php } ?>
          <?php if(isset($roleaccess['Students']['Schools Add'][3]) && $roleaccess['Students']['Schools Add'][3]=="y") { ?>     
  	  <li class="<?=($this->input->get('type')==='schools')?'active':''?>"><a href="<?php echo base_url();?>schools" title="Allocation Schools"><span>Allocation Schools</span></a></li>
          <?php } ?>
  	</ul>
</li>
 	
 <?php } ?>	
 	
 <?php if(isset($roleaccess['Screening Test'])) { ?>	
	<li class="<?=($this->uri->segment(1)==='screeningtest')?'active':''?>"><a href="<?php echo base_url();?>screeningtest"><i class="icons-tests"></i> <span>Screening Test</span></a></li>
 <?php } ?>	
 	
 	
<?php if(isset($roleaccess['Results'])) { ?>
	<li class="<?=($this->uri->segment(1)==='exams')?'active':''?>"><a href="<?php echo base_url();?>exams"><i class="icons-list"></i> <span>Results</span></a></li>
<?php } ?>	
 
        <?php if(isset($roleaccess['Exam Master'])) { ?>
	<li class="<?=($this->uri->segment(1)==='exammaster')?'active':''?>"><a href="<?php echo base_url();?>exammaster"><i class="icons-list"></i> <span>Event Master</span></a></li>
<?php } ?>
 	
<?php if(isset($roleaccess['Reports'])) { ?>
	<li class="<?=($this->uri->segment(1)==='reports')?'active':''?>"><a href="<?php echo base_url();?>reports"><i class="icons-review"></i> <span>Reports</span></a></li>
<?php } ?>	
 	
<?php if(isset($roleaccess['Settings'])) { ?>
	<li class="<?=($this->uri->segment(1)==='settings')?'active':''?>"><a href="<?php echo base_url();?>settings"><i class="icons-settings"></i> <span>Settings</span></a></li>
 <?php } ?>	

 <?php //} ?>	
 
 <?php if(isset($roleaccess['Library'])) { ?>
 
 <li><a href="#"><i class="icons-admissions"></i> <span>Library</span> <em class="mdi mdi-chevron-down"></em></a>
	<ul>
		<li class="<?=($this->uri->segment(1)==='library')?'active':''?>"><a href="<?php echo base_url();?>library"> <span>Master</span></a></li>
		
		<?php if(isset($roleaccess['Issue Books'][3]) && $roleaccess['Issue Books'][3]=="y") { ?>
			<li class="<?=($this->uri->segment(1)==='issuehistory')?'active':''?>"><a href="<?php echo base_url();?>issuehistory"><span>History</span></a></li>
		<?php } ?>
		
		<?php if(isset($roleaccess['Transfer Books'][3]) && $roleaccess['Transfer Books'][3]=="y") { ?>
			<li class="<?=($this->uri->segment(1)==='transferbooks')?'active':''?>"><a href="<?php echo base_url();?>transferbooks"><span>Transfer</span></a></li>
		<?php } ?>
                        
                <?php if(isset($roleaccess['Library Reports'][3]) && $roleaccess['Library Reports'][3]=="y") { ?>
			<li class="<?=($this->uri->segment(1)==='libraryreports')?'active':''?>"><a href="<?php echo base_url();?>libraryreports"><span>Reports</span></a></li>
		<?php } ?>
		
	 </ul>
</li>

 <?php } ?>
 
 <?php if(isset($roleaccess['Notification'])) { ?>
 <li class="<?=($this->uri->segment(1)==='notification')?'active':''?>"><a href="<?php echo base_url();?>notification"><i class="icons-admissions"></i> <span>Notification</span></a></li>
  <?php } ?>
 
<li class="<?=($this->uri->segment(1)==='updatepassword')?'active':''?>"><a href="<?php echo base_url();?>updatepassword"><i class="icons-tests"></i> <span>Update Password</span></a></li>	
 
<li class="<?=($this->uri->segment(1)==='logout')?'active':''?>"><a class="last" href="<?php echo base_url();?>logout"><i class="icons-logout"></i> <span>Logout</span></a></li>
	  	
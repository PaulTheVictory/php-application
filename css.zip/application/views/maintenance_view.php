<main>

  <div class="container">

    <div class="row">

      <div class="col-12 mx-auto my-auto">

        <div class="card auth-card login">         

          

          <div class="position-relative image-side"></div>

          

          <div class="form-side login-form">

         

            <h3 class="mb-1">Site Under Maintenance</h3>

            <h5 class="mb-4">Sorry for the inconvenience. To improve our services, we have momentarily shutdown our site.</h5>

            

          </div>

      

        </div>

      </div>

    </div>

  </div>

</main>


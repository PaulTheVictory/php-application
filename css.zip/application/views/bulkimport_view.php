<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/dataTables.css?v=1.6" />
<script src="<?php echo base_url(); ?>js/jquery.dataTables.js?v=1.0" type="text/javascript"></script>
<link rel="stylesheet" href="<?php echo base_url();?>css/boot/bootstrap.min.css">
<script src="<?php echo base_url();?>js/bootstrap.bundle.min.js"></script>
<style type="text/css">


.dataTables_wrapper input[type="text"] {
    padding: 0;
}
.dataTables_wrapper select {
    padding: 0;
}

.sortable thead tr  {
    background: #E6EBF7;

/* g8 */
border: 1px solid #D7DFF0;
box-sizing: border-box;
border-radius: 10px 10px 0px 0px;
 

}
.sortable tr th {
    border-right: 0px;
    padding: 15px 0;font-size: 13px;
      color: #6F83AA;
   cursor: pointer;
   text-align: center;

}

.sortable tr th:nth-child(3) {
  text-align: left;
}

.sortable tr td:nth-child(3) {
  text-align: left;
}

/*.sortable tr th:nth-child(1) {
  width: 50px !important;
}

.sortable tr th:nth-child(2) {
    width: 10% !important;
  background: none;
   text-align: left;
}


.sortable tr th:nth-child(3) {
  background: none;
  width: 25% !important;
   text-align: center;
}

.sortable tr th:nth-child(6) {
  background: none;
  width: 20% !important;
   text-align: center;
}

.sortable tr th:nth-child(7) {
  background: none;
  width: 70px !important;
   text-align: center;
}
*/

.sortable tr td {
    border-right: 0px;
    padding: 5px 5px;
    text-align: center;font-size: 13px;
    min-width:50px;vertical-align: middle;
}
.sortable tr td a {
    color: #364159;
}

#profile-right h2 {
    margin: 0px 0px 10px 0px;
}

.importtable_length { width: auto !important; }
#importtable_filter input { padding-top:4px;background: #fff url('<?php echo base_url(); ?>/images/search.png') no-repeat center left;background-position-x: 10px;border: 1px solid #D7DFF0; line-height: 32px;margin-left: 10px;width:260px;border-radius: 5px;text-indent: 30px;font-size: 13px;}
.sortable tr td a:hover { text-decoration: underline; }
.dataTables_filter { right:10px !important;}
	
	/* Import Admission */
	
	.btn-primary{background-color: #0332AA;color: #ffffff;border-color: #0332AA;}
	.btn-primary:not(:disabled):not(.disabled).active, .btn-primary:not(:disabled):not(.disabled):active, .show>.btn-primary.dropdown-toggle,.btn-primary:hover{background-color: rgba(3,50,170,0.8);}
	
	.btn-outline-primary {color: #0332AA;border-color: #0332AA;}
	.btn {border-radius: 5px;outline: initial!important;box-shadow: none!important;box-shadow: initial!important;font-size: .8rem;padding: .5rem 1.25rem .5rem 1.25rem;transition: background-color box-shadow .1s linear;margin-bottom: 0px}
	.btn-outline-primary:not(:disabled):not(.disabled).active, .btn-outline-primary:not(:disabled):not(.disabled):active, .show>.btn-outline-primary.dropdown-toggle,.btn-outline-primary:hover {background-color: #0332AA;border-color: #0332AA;color: #fff;}
	p.alert{font-size: 14px;padding: .45rem 1.25rem;}
	p.alert-danger {color: #721c24;}
	p.alert-success {color: #155724;}
	
	#importmessage{text-align: left;line-height: 20px;font-size: 14px;}
	
	#importmessage hr{display: block;margin: 0.5rem auto;border-style: dashed;border-color: #0332AA}
	.maincontent h3{font-size: 16px;color: #0332AA}
	.maincontent h3 span{color: #333;}
	
	.maincontent p{margin-bottom: 0.2rem;font-size: 12px;line-height: 14px;}
	.maincontent p.success{color: #02F042}
	.maincontent p.fail{color: #FF1A1E}
	.maincontent p.exists{color: #FF7600}
	
</style>
<script type="text/javascript">
	
	var dataSet = "";
	
$(document).ready(function(){	
	         
       
        var oTable = $('#importtable').dataTable({
					"bProcessing": true,
					"sPaginationType": "full_numbers",
                    "data": dataSet,
			 		"oLanguage": {
                        "sProcessing": "<img src='<?php echo base_url(); ?>images/loader.gif'>"
                    },
                    "columns": [
							{ title: "Student ID" },
							{ title: "Student Name" },
							{ title: "Course ID" },
							{ title: "Course Name" },
							{ title: "Center ID" },
							{ title: "Center Name" },
							{ title: "Partial Amount" },
							{ title: "Status" }
						],
                    //"order": [[ 0, "desc" ]],
                    "fnDrawCallback": function( oSettings ) {
                        
    }
         }); 
      
	
	/* Import Admission */
         
     $("#bulkadmission").click(function(){
		  
		$('#newimportModal').modal({show:true});
		   
	 }); 
	
	
	 $(".importadmission").click(function(){
		  
		 var uploadfile = $("#uploadnewadmission").val();
		 
		 if(uploadfile==""){
			 $(".alert").removeClass('alert-success').addClass('alert-danger').text("Upload import file");
			 return;
		 }
		 
		if($(".importadmission").hasClass('process')){
			
			$(".alert").removeClass('alert-success').addClass('alert-danger').text("Please wait while importing...");
			
		}else{
		
			$(".importadmission").addClass('process');
			$(".alert").removeClass('alert-danger').addClass('alert-success').text("Importing new admissions...");
			
			$(".loader").removeClass('d-none');
         		 
		 var formData = new FormData();
		 
		 var c=0;
		 var file_data,file;
		 $('input[type="file"]').each(function(){
			  file_data = $('input[type="file"]')[c].files; // get multiple files from input file
			  //console.log(file_data);
		   for(var i = 0;i<file_data.length;i++){
			   formData.append('file[]', file_data[i]); // we can put more than 1 image file
		   }
		  c++;
	    }); 
		 
		 $.ajax({
                type: 'POST',
                url: 'bulkimport/uploadNewAdmission',
                data: formData,
			    contentType: false,
    			processData: false,
                success: function(response) {
                   
					var obj1 = $.parseJSON(response);
							
					$(".loader").addClass('d-none');
					
					if(obj1['status']=="success"){
						
						$(".alert").addClass('alert-success').text("Admissions imported successfully.");
						
						//$("#importmessage").html(obj1['message']);
						
						//dataSet = obj1['tabledata'];
						
						oTable.fnAddData(obj1['tabledata']);
						oTable.fnDraw();
												
						setTimeout(function(){
							$(".alert").removeClass('alert-success').text("");
							//location.reload();
						},3000);
						
					}else if(obj1['status']=="empty"){
						$(".importadmission").removeClass('process');
						$(".alert").removeClass('alert-success').addClass('alert-danger').text("Upload file");
					}else if(obj1['status']=="ufail"){
						$(".importadmission").removeClass('process');
						$(".alert").removeClass('alert-success').addClass('alert-danger').text("Import failed");
					}else if(obj1['status']=="ularge"){
						$(".importadmission").removeClass('process');
						$(".alert").removeClass('alert-success').addClass('alert-danger').text("Each upload file must be less than 1MB");
					}else if(obj1['status']=="exfail"){
						$(".importadmission").removeClass('process');
						$(".alert").removeClass('alert-success').addClass('alert-danger').text("Support extension XLS only");
					}else if(obj1['status']==""){
						$(".importadmission").removeClass('process');
						$(".alert").removeClass('alert-success').addClass('alert-danger').text("Please try again.");
					}
					
                }

            });
			
		}
		
		   
	 }); 
	
	
	$('#newimportModal').on('hidden.bs.modal', function () {
  		
		$(".loader,.updateloader").addClass('d-none');
		$(".alert").removeClass('alert-success alert-danger').text("");
		$("#importmessage").html("");
		$(".importadmission").removeClass('process');
		
	});
	
	
	$("input,select,textarea").click(function(){
		
		$(".alert").removeClass('alert-success alert-danger').text("");
		
	});
	
	$(".clear").click(function(){
		
		location.reload();
		
	});
  
	/* Import Admission */
	
});
</script>


<div class="wrap dynamic-width" style="float: left;position: relative">
    
    <div style="margin-top: 10px; width: 100%; height: 50px; text-align: right;">
             <span style="font-weight: bold;font-size: 20px;padding: 10px;float:left;color: #364159">Bulk Admission</span>
            </div>
              
              
              <div class="row text-center align-items-center w-100">
					
					<div class="col-2 justify-content-start">
					
					<label class="btn btn-outline-primary btn-upload my-3" for="uploadnewadmission" title="Upload image file">
					  <input type="file" class="sr-only" id="uploadnewadmission" name="uploadnewadmission">Select Import File
                   </label>
                           				 
				  </div>
                           				 
                   <div class="col-1 justify-content-start">       				 
                            				 
						<button type="button" class="btn btn-primary importadmission">Import</button>
                            				 
				   </div>
                           				 
                   <div class="col-1 justify-content-start">       				 
                            				 
						
                            				 
				   </div>
                           				 
                   <div class="col-8 text-right">       				 
                                                     				    				 
					   <a href="docs/newadmission/sampleadmissiondata.xls"><button type="button" class="btn btn-outline-primary">Download Sample</button></a>
                           				 
                       <button type="button" class="btn btn-outline-primary clear ml-3">Clear</button>    				 
                            				 
				   </div>
                            				                              				 
			</div>
             
              <div class="row px-4 w-100">
              
                <div class="loader d-none">
						<img src='<?php echo base_url(); ?>images/loader.gif'>
						<p>Importing admission...</p>
				   </div>
            
             </div>
              
          <p class="alert d-inline mb-0"></p>    
              
	<div class="mb-4"></div>
               
       	    
	<table id="importtable" class="sortable" style="width:100%"></table>
       	                                  
        	                                  
         <?php //echo $this->table->generate();  ?>             
         
        
        
        </div>
    
 
   <!--  Import Admission  -->
<style>

	#newimportModal.modal .modal-header{padding: 5px 10px !important;border: none}	
	#newimportModal.modal .modal-body{padding:0 1.75rem 1.75rem}
	.modal-body p{text-align: left !important}
	.modal-backdrop.show {opacity: .5 !important;}
	#newimportModal h2{line-height: 24px;}

	#importmessage table{width: 100%;border-collapse: collapse;}
	#importmessage table td:nth-child(odd){width: 40%}
	#importmessage table td:nth-child(even){width: 60%}
	#importmessage table th,#importmessage table td{border: 1px solid #333;width: 50%;text-align: left;padding: 5px 10px}
	.loader p{text-align: center !important;}

	.studentdetails p span{font-weight: bold;display: block}

	label{color: #4F70C4;}

</style>
    
<!--<div id="newimportModal" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
				   <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				</div>
				<div class="modal-body text-center">
									
					<h2 class="mb-4 mt-0 text-center">Bulk Admission</h2>
					
					
					<label class="btn btn-outline-primary btn-upload my-3" for="uploadnewadmission" title="Upload image file">
					  <input type="file" class="sr-only" id="uploadnewadmission" name="uploadnewadmission">Select Import File
                   </label>
                   
                   <div class="loader d-none">
						<img src='<?php echo base_url(); ?>images/loader.gif'>
						<p>Importing admission...</p>
					</div>
						
					
					<div id="importmessage"></div>				
										
				</div>
				<div class="modal-footer">
				
					<p class="alert mb-0"></p>
					
					<button type="button" class="btn btn-primary importadmission">Import</button>
					<button type="button" class="btn btn-outline-primary modalclose" data-dismiss="modal">Close</button>
				</div>
								
			</div>
		</div>
	</div>-->


 <!--  Import Admission  -->
 
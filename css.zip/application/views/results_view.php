<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/dataTables.css?v=1.6" />
<script src="<?php echo base_url(); ?>js/jquery.dataTables.js?v=1.0" type="text/javascript"></script>
<link rel="stylesheet" href="<?php echo base_url();?>css/boot/bootstrap.min.css">
<script src="<?php echo base_url();?>js/bootstrap.bundle.min.js"></script>
<style type="text/css">


.dataTables_wrapper input[type="text"] {
    padding: 0;
}
.dataTables_wrapper select {
    padding: 0;
}

.sortable thead tr  {
    background: #E6EBF7;

/* g8 */
border: 1px solid #D7DFF0;
box-sizing: border-box;
border-radius: 10px 10px 0px 0px;
 

}
.sortable tr th {
    border-right: 0px;
    padding: 15px 0;font-size: 13px;
      color: #6F83AA;
   cursor: pointer;
   text-align: center;
	text-transform: uppercase;

}

.sortable tr th:nth-child(3) {
  text-align: left;
}

.sortable tr td:nth-child(3) {
  text-align: left;
}

.sortable tr td {
    border-right: 0px;
    padding: 5px 5px;
    text-align: center;font-size: 13px;
    min-width:50px;vertical-align: middle;
}
.sortable tr td a {
    color: #364159;
}

#profile-right h2 {
    margin: 0px 0px 10px 0px;
}

.resultstable_length { width: auto !important; }
#resultstable_filter input { padding-top:4px;background: #fff url('<?php echo base_url(); ?>/images/search.png') no-repeat center left;background-position-x: 10px;border: 1px solid #D7DFF0; line-height: 32px;margin-left: 10px;width:260px;border-radius: 5px;text-indent: 30px;font-size: 13px;}
.sortable tr td a:hover { text-decoration: underline; }
.dataTables_filter { right:10px !important;}
	
	/* Import Admission */
	
	.btn-primary{background-color: #0332AA;color: #ffffff;border-color: #0332AA;font-weight: 600;}
	.btn-primary:not(:disabled):not(.disabled).active, .btn-primary:not(:disabled):not(.disabled):active, .show>.btn-primary.dropdown-toggle,.btn-primary:hover{background-color: rgba(3,50,170,0.8);}
	
	.btn-outline-primary {color: #0332AA;border-color: #0332AA;font-weight: 600;}
	.btn {border-radius: 5px;outline: initial!important;box-shadow: none!important;box-shadow: initial!important;font-size: .8rem;padding: .5rem 1.25rem .5rem 1.25rem;transition: background-color box-shadow .1s linear;margin-bottom: 0px}
	.btn-outline-primary:not(:disabled):not(.disabled).active, .btn-outline-primary:not(:disabled):not(.disabled):active, .show>.btn-outline-primary.dropdown-toggle,.btn-outline-primary:hover {background-color: #0332AA;border-color: #0332AA;color: #fff;}
	p.alert{font-size: 14px;padding: .45rem 1.25rem;}
	p.alert-danger {color: #721c24;}
	p.alert-success {color: #155724;}
	
	#importmessage{text-align: left;line-height: 20px;font-size: 14px;}
	
	#importmessage hr{display: block;margin: 0.5rem auto;border-style: dashed;border-color: #0332AA}
	.maincontent h3{font-size: 16px;color: #0332AA}
	.maincontent h3 span{color: #333;}
	
	.maincontent p{margin-bottom: 0.2rem;font-size: 12px;line-height: 14px;}
	.maincontent p.success{color: #02F042}
	.maincontent p.fail{color: #FF1A1E}
	.maincontent p.exists{color: #FF7600}
	
	.exam p{font-size: 14px;font-weight: bold;color: #6F83AA;}
	.exam p span {font-size: 18px !important;font-weight: bold;font-size: 14px;color: #0332AA;}
	
	.dataTables_processing{height: auto}
		
</style>
<script type="text/javascript">
	
	var oTable = "";
	
$(document).ready(function(){	
	    	
		 var oTable = $('#resultstable').dataTable({
					"processing": true,
					"sPaginationType": "full_numbers",
			 		"oLanguage": {
                        "sProcessing": "<img src='<?php echo base_url(); ?>images/loader.gif'>",
						 "sEmptyTable": "No Results Found"
                    },
                    "columns": [
							{ title: "Sno" },
							{ title: "Stu ID" },
							{ title: "Stu Name" },
							<?php if($exam['type']=="Screening Test"){ ?>
							{ title: "Roll No" },
							<?php } ?>
							{ title: "Phy" },
							{ title: "Che" },
							{ title: "Bio" },
							{ title: "Mat" },
							{ title: "P-I" },
							{ title: "P-II" },
							{ title: "Total Marks" },
							{ title: "Max Marks" },
							{ title: "Highest Marks" },
							{ title: "Percent %" },
							{ title: "Grade" },
							{ title: "Rank" },
							<?php if($exam['type']=="Screening Test"){ ?>
							{ title: "Out Of" },
							{ title: "Status" },
							{ title: "Scholar Earned" },
							{ title: "Remarks" }
							<?php } ?>
						],
			 			"columnDefs": [
							{
								"targets": 1,
								"render": function ( data, type, row ) {//console.log(row[15]);
									if (type === "display") {
										<?php if($exam['type']=="Screening Test"){ ?>
											return "<a href=\"studentprofile?sid=" + encodeURIComponent(row[20]) + "\" target=\"_blank\">" + data + "</a>";
										<?php }else{ ?>
											return "<a href=\"studentprofile?sid=" + encodeURIComponent(row[15]) + "\" target=\"_blank\">" + data + "</a>";
										<?php } ?>
									}

									return data;
								}
							}
						],
                    //"order": [[ 0, "desc" ]],
                    "fnDrawCallback": function( oSettings ) {
                        
    }
 }); 
	
	loadresults(oTable);

	
	$("input,select,textarea").click(function(){
		
		$(".alert").removeClass('alert-success alert-danger').text("");
		
	});

	
});
	
	
function loadresults(oTable){
	
	$(".dataTables_processing").show();
	
	$.ajax({
                type: 'POST',
                url: 'examresults/getExamResults',
                data: {"examid":"<?php echo $_GET['id']; ?>","status":"a","type":"<?php echo $exam['type'];?>"},
                success: function(response) {
                   
					var obj1 = $.parseJSON(response);
					
					$(".dataTables_processing").hide();
					
					if(obj1['tabledata'].length>0){
						
						oTable.fnClearTable();
						oTable.fnAddData(obj1['tabledata']);
						oTable.fnDraw();
						
						$(".approveresults").removeClass('d-none');
						
					}
					
				}
		
	});

}
	
</script>


<div class="wrap dynamic-width" style="float: left;position: relative">
    
    
   			<div class="row w-100 align-items-center">
        	      
			  <div class="col-7 justify-content-center">

				<div style="margin-top: 10px; width: 100%; height: 50px; text-align: right;">
				 <span style="font-weight: bold;font-size: 20px;padding: 10px;float:left;color: #364159">Results</span>
				</div>

				</div>
            
            <?php if(isset($roleaccess['Upload Results'][3]) && $roleaccess['Upload Results'][3]=="y"){ ?>
             
             	<div class="col-3 text-right justify-content-center"><a href="docs/examresults/<?php if($exam['type']=="Screening Test"){echo "examresultstemplatetest.xls";}else{echo "examresultstemplate.xls";} ?>"><button type="button" class="btn btn-outline-primary">Download Template</button></a></div>
              <div class="col-2 text-right justify-content-center"><a href="examresults?id=<?php echo $_GET['id'];?>"><button type="button" class="btn btn-primary">Upload Results</button></a></div>
              
              <?php }?>
              
		</div>
              
              <div class="row my-4 w-100 align-items-center exam">
              
				  <div class="col-12 justify-content-center"><p>Course Name: <span><?php echo $exam['examname'];?></span></p></div>
              	  
			  </div>
            
              <div class="row mb-3 w-100 exam">
             	  	
					<div class="col-3"><p>Date of Exam: <span><?php echo date("d-M-Y",strtotime($exam['date']));?></span></p></div>
             	  	<div class="col-3"><p>Type of Exam: <span><?php echo $exam['type'];?></span></p></div>
             	  	<div class="col-3"><p>Students Appeared: <span><?php echo $exam['stu_appeared'];?></span></p></div>
             	  	
             	  </div>
                         
                          
			<div class="my-4 d-inline-block"></div>
               
       	    
		<table id="resultstable" class="sortable" style="width:100%">
		
		
	</table>
       	                                  
        	                                                  
  </div>
 
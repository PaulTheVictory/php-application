<link rel="stylesheet" href="<?php echo base_url();?>css/vendor/dataTables.bootstrap4.min.css">
<link rel="stylesheet" href="<?php echo base_url();?>css/vendor/datatables.responsive.bootstrap4.min.css">
<script src="<?php echo base_url();?>js/vendor/datatables.min.js"></script>

<script type="text/javascript">
$(document).ready(function(){
	

});
</script>

<style>
		
	.regcourses h1{font-size: 18px;color: #364159;}
	.regcourses .card,.courseinfo .card{background: linear-gradient(0deg, #FFFFFF, #FFFFFF), #C4C4C4;box-shadow: 0px 0px 7px rgba(196, 196, 196, 0.35);border-radius: 10px;}
	.regcourses h2{color: #0332AA;font-size: 24px;font-weight: bold;line-height: 36px;}
	.regcourses p.list-item-heading{color: #6884CC;font-weight: 600;}
	.regcourses p.list-item-heading span:last-child{font-weight: 600;font-size: 14px;color: #364159;}
	
	.regcourses .crstatus-approved,.regcourses .crstatus-waitlisted,.regcourses .crstatus-pending,.regcourses .crstatus-rejected{font-size: 12px !important;color: #ffffff !important;border-radius: 20px;text-transform: capitalize;text-align: center;}
	.crstatus-approved{ background: #3CAF92;}
	.crstatus-waitlisted{background: #f48d25;}
	.crstatus-pending{background: #b06315;}
	.crstatus-rejected{background: #ED5252;}
	
	.regcourses .card:after{content: " ";color: #fff;position: absolute;width: 10px;height: 100%;top: 50%;transform: translateY(-50%);left: 0;border-top-left-radius: 10px;border-bottom-left-radius: 10px;}
	.regcourses.approved .card:after{background: #3CAF92;}
	.regcourses.waitlisted .card:after{background: #f48d25;}
	.regcourses.pending .card:after{background: #b06315;}
	.regcourses.rejected .card:after{background: #ED5252;}
	
	
	.border-right{border-right: 1px solid #D7DFF0!important;}
		
	.btn-primary{width: auto}
	.btn-primary.disabled, .btn-primary:disabled{background: #9AADDD;color: #ffffff;}
	
	.card h5{margin-bottom: 1rem;}
	h5{font-weight: bold;}
	.badge-outline-secondary, .badge-outline-theme-2{border: 1px solid #889DC6;color: #889DC6;background: #F6F7FA;}
	.badge{font-size: 12px;margin-right: 5px}
	
	.courseinfo .col-right .card .card-body{padding: 0;}
	.courseinfo .border-bottom{border-bottom: 1px solid #D7DFF0!important;}
	.col-right h5{padding: 1.2rem}
 
	.icon-status{background: url("img/icons/status-b.png") no-repeat;width: 15px;height: 15px;display: inline-block;vertical-align: middle}
	.icon-check-circle{background: url("img/icons/check-circle-b.png") no-repeat;width: 15px;height: 15px;display: inline-block;vertical-align: middle}
	.icon-send{background: url("img/icons/send-b.png") no-repeat;width: 15px;height: 15px;display: inline-block;vertical-align: middle;margin-right: 5px}
	.icon-map-pin{background: url("img/icons/map-pin-b.png") no-repeat;width: 15px;height: 15px;display: inline-block;vertical-align: middle;margin-right: 5px}
	.icon-invoice{background: url("img/icons/invoice-b.png") no-repeat;width: 15px;height: 15px;display: inline-block;vertical-align: middle;margin-right: 5px}
	
	p.totalfee {font-weight: bold;font-size: 24px;color: #D63333;}
	
</style>


<main>

	<div class="container-fluid">

		<div class="row">
		  <div class="col-12">

			  <div class="row">
			   
			   	  <div class="col-md-9">
			   		<h1>Applied Course Status</h1>
				  </div>
				  <div class="col-md-3">
					 <div class="form-group">
						<select class="form-control schedule" name="schedule" >
						  <option value="">Sort By</option>
						  <option value="date">Date</option>
						  <option value="status">Status</option>
						</select>
					 </div>
				  </div>
			   
			   </div>

			   <div class="mb-3"></div>

		</div>

		</div>
		
		<?php 
		
			if(!empty($regcourses)){
				
			foreach($regcourses as $courseslist){
				
				$ide = $courseslist['ide'];
				$requestdate = date("d M Y",strtotime($courseslist['requested_at']));
				$approvedate = date("d M Y",strtotime($courseslist['approved_date']));
				
				$admissiontime = date('M Y',strtotime($courseslist['starts_on'])).' - '. date('M Y',strtotime($courseslist['ends_on']));
				
				$center = $courseslist['center'];
				
				$status = $courseslist['approved'];
				
				$crstatusclass = "";
				$crstatus = "";
				$btnstatus = "";
				
				if($status=="y"){
					
					$crstatus = "Approved";
					$crstatusclass = "approved";
					$btnstatus = "";
					
				}else if($status=="w"){
					
					$crstatus = "Waiting List";
					$crstatusclass = "waitlisted";
					$btnstatus = "disabled";
					
				}else if($status=="n"){
					
					$crstatus = "Not Qualified";
					$crstatusclass = "rejected";
					$btnstatus = "disabled";
					
				}else if($status=="q"){
					
					$crstatus = "Waiting For Approval";
					$crstatusclass = "pending";
					$btnstatus = "disabled";
					
				}else if($status=="d"){
					
					$crstatus = "Rejected";
					$crstatusclass = "rejected";
					$btnstatus = "disabled";
					
				}else{
					$btnstatus = "disabled";
				}
				
				$grandtotalnow = 0;
				foreach($studentcoursepay as $stupaylist){
						
					if($stupaylist['courseid'] == $courseslist['courseid']){

						$total = $stupaylist['grandtotal'];	

						$grandtotalnow += $total;

					}
													
				}

				$screentest = $courseslist['screentest'];
				
				if($screentest=="1" || $grandtotalnow==0)$regbtn = "stufeepayments?id=".$ide; else $regbtn = "stumyprofile?action=register&id=".$ide;
				
				
		
		
		?>
	
		<div class="row regcourses <?php echo $crstatusclass;?>">

			<div class="col-12 mb-4">
				<div class="card">
					<div class="card-body">

						<div class="row">

							<div class="col-md-12 col-sm-12 col-lg-9 col-12">
								
								<h1 class="mb-2"><?php echo $courseslist['coursename']; ?></h1>

								<div class="row mb-3">

									<div class="col-md-4 col-sm-4 text-left px-2">
										<p class="list-item-heading mb-1"><i class="icon-send"></i> <span>Requested Date:</span> <span><?php echo $requestdate; ?></span></p>
									</div>

									<div class="col-md-4 col-sm-4 text-left px-2">
										<p class="list-item-heading mb-1"><i class="icon-check-circle"></i> <span>Approved Date:</span> <span><?php echo $approvedate; ?></span></p>
									</div>

									<div class="col-md-4 col-sm-4 text-left px-2">
										<p class="list-item-heading mb-1"><i class="icon-status"></i> <span>Status:</span> <span class="crstatus-<?php echo $crstatusclass;?> px-3 py-2"><?php echo $crstatus;?></span></p>
									</div>

								</div>
								
								<div class="row">

									<div class="col-md-4 col-sm-4 text-left px-2">
										<p class="list-item-heading mb-1"><i class="icon-map-pin"></i> <span>Course Location:</span> <span><?php echo $center; ?></span></p>
									</div>

									<div class="col-md-6 col-sm-6 text-left px-2">
										<p class="list-item-heading mb-1"><i class="icon-invoice"></i> <span>Admission Time:</span> <span><?php echo $admissiontime; ?></span></p>
									</div>

								</div>

							</div>

							<div class="col-md-12 col-sm-12 col-lg-3 col-12 d-flex align-items-center justify-content-end">
								
								<div class="row w-100">

									<div class="col-md-11 text-right">
										<button class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" <?php echo $btnstatus;?>>Register & Pay</button>
										<div class="dropdown-menu"><a class="dropdown-item" href="<?php echo base_url();?><?php echo $regbtn;?>">Register</a> <a class="dropdown-item" href="#">Cancel Request</a></div>
									</div>
									<!--<div class="col-md-2 d-flex align-items-center">
										img src="img/icons/vdot.png" class="mw-100" /         
									</div>-->     

								</div>
						
							</div>

						</div>


					</div>

				</div>
			</div>
		</div>
		
		<?php }}else{?>
		
		<div class="row regcourses">

			<div class="col-12 mb-4">
				<div class="card">
					<div class="card-body">
					
						<p class="text-muted text-center mb-0">No Applied Course Found.</p>
					
				</div>
			</div>
		</div>
		
		<?php }?>

	</div>


	</div>
</main>
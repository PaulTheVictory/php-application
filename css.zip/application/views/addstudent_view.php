 <link href="<?php  echo base_url(); ?>css/jquery-ui.min.css?v=1.4" rel="stylesheet" type="text/css" />
 <link href="<?php  echo base_url(); ?>css/chosen.min.css?v=1.3" rel="stylesheet" type="text/css" />
 <script src="<?php  echo base_url(); ?>js/jquery-ui.min.js?v=1.3" type="text/javascript"></script>
 <script src="<?php  echo base_url(); ?>js/chosen.jquery.min.js?v=1.2" type="text/javascript"></script>


 <style type="text/css">
     
     .ui-selectmenu-button.ui-button{ width: 97%; padding:11px;}
     #comcontact-button,#nationality-button,#category-button,#bloodgroup-button,
     #classstudying-button,#stream-button{border: 1px solid #D7DFF0;background: #fff;font-size: 14px;color:#536485}
     #centers_chosen  {border: 1px solid #D7DFF0;background: #fff;padding: 8px 0px;}
     .chosen-container-multi .chosen-choices {border: 0px;background: none}
     .maincontent ul li.search-choice { height:auto; }
     .maincontent ul li.search-choice a{ height:auto; font-size: 14px;color:#536485}
     .chosen-container-multi .chosen-choices li.search-choice { background: #6884CC;border-radius: 5px;}
     .chosen-container-multi .chosen-choices li.search-choice {color: #fff;}
     .response p { float: right;font-size:12px;color:#eb345e;}

.topmenu a {
    font-weight: bold;
font-size: 16px;
margin-left: 3em;
line-height: 48px;
color: #9AADDD;
padding: 5px 0;
position: relative;
height: 48px;
display: inline-block;
cursor:pointer;
}
.topmenu a:hover, .selection { border-bottom: 3px solid;color: #0332AA!important;}
 </style>

	<div class="wrap dynamic-width" style="float: left;position: relative;min-width: 800px">
     <div style="margin-top: 10px; width: 99%; height: 50px; text-align: right;">
         <span style="font-weight: bold;font-size: 20px;padding: 10px;float:left;color: #364159">Student Profile</span>
         <a class="addpay" style="padding: 10px;  color: #fff; margin: 0px auto; background: linear-gradient(180deg, #4F70C4 0%, #1C47B3 100%); position: relative; top: 5px;border-radius:5px;font-size: 14px" class="btn" href="<?php echo base_url(); ?>students"><span style="position: relative;top:4px"><img  src="<?php echo $this->config->item('web_url') ?>images/addcourse.png" alt="Navigation" /></span><span style="margin-left:5px">View Student List</span></a>
     </div>         
            <div id="course-container" class="add-course" style="padding-left: 0px">
                <div class="topmenu" style="border-bottom: 1px solid #D7DFF0;width:100%;height:60px">
                    
                    <a heref="" class="selection">Personal Details</a>
                    <a heref=""> Educational Details</a>
                    <a heref="">Contact Details</a>
                    <a heref="">Bank Details</a>
                    
                </div>
<?php echo form_open('addstudent/studentSubmit', array('id' => 'studentForm')) ?>
                
               <section class="tab1">
                <div class="vrow-element">
                    
                    <span class="hcontent"><input type="text"  placeholder="Name"  value="<?php echo $student['name'];?>" name = "cname" class="name"></span>
                     
                     <span class="hcontent">
                        <label style="text-align: left;min-width: 100px;color:#536485;background: none;border: 0px;width: auto;height: auto;float:left;font-size: 14px"><input type="checkbox" name = "regular"   class="chkbox rbatch" style="margin: 5px;">Male</label>
                        <label style="text-align: left;min-width: 100px;color:#536485;background: none;border: 0px;width: auto;height: auto;float:left;font-size: 14px"><input type="checkbox" name = "weekend"  class="chkbox wbatch" style="margin: 5px;">Female</label>
                        <label style="text-align: left;min-width: 100px;color:#536485;background: none;border: 0px;width: auto;height: auto;float:left;font-size: 14px"><input type="checkbox" name = "both"  class="chkbox both" style="margin: 5px;">Others</label>
                          </span>
                     
                    <span class="hcontent"><input type="text" placeholder="Email" name = "email" class="name" value="<?php echo $student['email'];?>"></span>
                    
                     <span class="hcontent"><input type="text" value="" placeholder="Father's Ocuupation" name = "cname" class="name"></span>
                    
                      <span class="hcontent"><input type="text" value="" placeholder="Father's Email" name = "cname" class="name"></span>
                  
                      <span class="hcontent"><input type="text" value="" placeholder="Father's Phone" name = "cname" class="name"></span>
                    
                      <span class="hcontent"><input type="text" value="" placeholder="Mother's Name" name = "cname" class="name"></span>
                
                      <span class="hcontent"><input type="text" value="" placeholder="Mother's Occupation" name = "cname" class="name"></span>
                    
                      <span class="hcontent"></span>
                </div>
                
                <div style="float: left;width:2%;height:60px"></div>
                <div class="vrow-element">
                    
 
                     <span class="hcontent"><input type="text" value="" placeholder="Mother's Email"  name = "cname" class="name"></span>
                     <span class="hcontent"><input type="text" value="" placeholder="Mother's Phone"  name = "cname" class="name"></span>
                     <span class="hcontent">
                        <label style="color:#536485;background: none;border: 0px;width: 100%;height: auto;float:left;">
                        <select id="comcontact" name = "comcontact" class="dropList" style="font-size: 13px;float:left">
                            <option value="" >Communication Contact</option>
                            <option>Permanent</option>
                            <option>Temporary</option>
                        </select>
                         </label>
                    </span>
                     <span class="hcontent">
                        <label style="color:#536485;background: none;border: 0px;width: 100%;height: auto;float:left;">
                        <select id="nationality" name = "nationality" class="dropList" style="font-size: 13px;float:left">
                            <option value="" >Nationality</option>
                            <option>Indian</option>
                            <option>Outside India</option>
                        </select>
                         </label>
                    </span>
                     <span class="hcontent">
                        <label style="color:#536485;background: none;border: 0px;width: 100%;height: auto;float:left;">
                        <select id="category" name = "category" class="dropList" style="font-size: 13px;float:left">
                            <option value="" >Category</option>
                            <option>Category 1</option>
                            <option>Category 2</option>
                        </select>
                         </label>
                    </span>
                     
                         <span class="hcontent">
                        <label style="color:#536485;background: none;border: 0px;width: 100%;height: auto;float:left;">
                        <select id="bloodgroup" name = "bloodgroup" class="dropList" style="font-size: 13px;float:left">
                            <option value="" >Blood Group</option>
                            <option>A+</option>
                            <option>B+</option>
                        </select>
                         </label>
                    </span>
                     <span class="hcontent">
                        <label style="color:#536485;background: none;border: 0px;width: 100%;height: auto;float:left;">
                        <select id="classstudying" name = "classstudying" class="dropList" style="font-size: 13px;float:left">
                            <option value="" >Class Studying</option>
                            <option>5th Standard</option>
                            <option>6th Standard</option>
                            <option>7th Standard</option>
                        </select>
                         </label>
                    </span>
                     <span class="hcontent">
                        <label style="color:#536485;background: none;border: 0px;width: 100%;height: auto;float:left;">
                        <select id="stream" name = "stream" class="dropList" style="font-size: 13px;float:left">
                            <option value="" >Stream</option>
                            <option>CBSE</option>
                            <option>HSC</option>
                        </select>
                         </label>
                    </span>
                      <span class="hcontent">
                        <span  style="margin: 0px auto; float:right;margin-top: 18px;padding: 10px; color: #fff; background: linear-gradient(180deg, #4F70C4 0%, #1C47B3 100%);border: 1px solid #0332AA; border-radius:5px;cursor: pointer" class="btn savebtn" href="#">Next ></span>
                    </span>
                </div>
                </section>
                <section class="tab2">
                    
                    
                </section>
            <?php echo form_close() ?>
                
            </div>
     
        
        </div>
    
    
    
<script type="text/javascript">
$(document).ready(function() {
    
    $(".dropList").selectmenu();
    $(".chkbox").checkboxradio();

    
    $(".savebtn").click(function(){
         
               $(".response").html('').text('Progressing...');
               var centers = "";
               $("#centers_chosen").find("li span").each(function(){
                   centers += $(this).text()+"|";
               });
               
               if($(".rbatch").is(":checked")) {$(".rbatch").val("1");} else { $(".rbatch").val("0");}
               if($(".wbatch").is(":checked")) {$(".wbatch").val("1");} else { $(".wbatch").val("0");}
               if($(".both").is(":checked")) {$(".both").val("1");} else { $(".both").val("0");}
               
               $(".selcenters").val(centers);
               
                var qualificationForm = $("#courseForm");

                    $.ajax({
                        url: qualificationForm.attr('action'),
                        type: 'post',
                        data: qualificationForm.serialize(),
                        success: function(o){
                            
                            var response = $.parseJSON(o);
                            $(".response").html('');
                            if(response.status === 'success') {
                                
                                var t = "<?php echo base_url(); ?>"+"addpayment?id="+response.ide;
                                $(".addpay").css("display","").attr("href",t);
                                $(".response").css("color","rgb(25, 71, 15)");
                               $(".response").text(response.message);
                            } else {
                                
                               $(".response").append(response.message); 
                           
                            }

                        }
                    });
                   
                              
            });
	
	
	$(".add-course").find("input").each(function(){
            
            $(this).keyup(function(event){
                if(event.keyCode == 13){
                    var ty = $(this).next();
                    event.preventDefault();
                    $('input')[$('input').index(this)+1].focus();
                    $('input')[$('input').index(this)+1].select();
                }
            });

            $(this).click(function(){ $(".errnotify").html("&nbsp;");});
            

        });
        $(document).delegate(".advalue","keyup",function(event){
     
            if(!numCheck(this)) { alert('invalid key'); return;}  
         });
        
	
        
        function numCheck(ele){
        
            var numchk = new RegExp("^[0-9.]*$");  
            if( numchk.test( $(ele).val() ) ){ return 1; } else { $(ele).val("");return 0;}
    }
	
});
</script>
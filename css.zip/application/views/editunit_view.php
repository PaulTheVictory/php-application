
<div id="pagetitle">

	<div class="wrap">
    
    	<h1>Edit Unit</h1>
        
	</div>
    
</div>
<div class="maincontent">

	<div class="wrap">
    
            <div id="course-container" class="add-course-date">

                <div class="row-element">
                    <span class="title" style="padding: 0px;padding-top: 10px">Unit</span>
                    <span class="content"><input type="text" value="<?php echo html_escape($edit['unit']);?>" class="name" id="grpname"></span>
                </div>

                 <div class="row-element">
                    <span class="content">
                        <input style="float: left" type="submit" class="course-submit" value="Submit">
                        <p class="errnotify" style="color:#aa3e41;margin:0px;padding:0px;float:left;padding-left:20px;padding-top:10px"> </p>
                    </span>
                </div>
                
            </div>
        
        </div>
    
    </div>
<script type="text/javascript">
$(document).ready(function() {
	
	
	$(".add-course-date").find("input").each(function(){

          $(this).click(function(){ $(".errnotify").html("&nbsp;");});

    });
    
    
    $(".add-course-date").find("input").each(function(){
            
            $(this).keyup(function(event){
                if(event.keyCode == 13){
                    var ty = $(this).next();
                    event.preventDefault();
                    $('input')[$('input').index(this)+1].focus();
                    $('input')[$('input').index(this)+1].select();
                }
            });

            $(this).click(function(){ $(".errnotify").html("&nbsp;");});            

        });
   
	
	$(".add-course-date").find(".course-submit").click(function(){
		
		var name = $(".add-course-date").find(".name").val();
               
		if(name === ""){ $(".errnotify").html("Please provide unit name");return;}	
                
           	$(this).val("Processing...");
		
				$.get('editunit/updateUnit',{
					   'unit':name, 
                                           'id':'<?php echo $edit['ide'];?>'
                                           
				}, function(o) { 
					var obj1 = $.parseJSON(o);
					if(obj1[0] === 'success'){
						    
                                            $(".errnotify").html("<font style=\"color:#188f04\">Unit has been edited succesfully!!</font>");
					    setTimeout(function(){ window.location.assign("units"); }, 500);
                                                
					}else if(obj1[0] === 'fail'){
                                                   $(".add-course-date").find(".course-submit").val("Submit");
                                                   alert("Error!! Please try again");                                                    
						
					}
				});	 
		
  	});
	
});
</script>
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/dataTables.css?v=1.5" />
<script src="<?php echo base_url(); ?>js/jquery.dataTables.js?v=1.0" type="text/javascript"></script>
	
 <script type="text/javascript">
$(document).ready(function(){	
    
            
        var oTable = $('.table').dataTable({
                    "bProcessing": true,
                    "sPaginationType": "full_numbers",
                     "oLanguage": {
                        "sProcessing": "<img src='<?php echo base_url(); ?>images/loader.gif'>",
						 "sEmptyTable": "No results found"
                    },
                    'iDisplayLength': 5,
					"order": [0,"desc"],
                    "fnDrawCallback": function( oSettings ) {
						
					}
         }); 
	
});
         
</script>
	<style type="text/css">

	.results .card{background: linear-gradient(0deg, #FFFFFF, #FFFFFF), #C4C4C4;box-shadow: 0px 0px 7px rgba(196, 196, 196, 0.35);border-radius: 10px;}
	
	.table tr:last-child td{text-align: left}
	.table tr td:last-child,.table tr th:last-child{text-align: left}
	.table tr:last-child td:last-child{font-weight: 600;text-align: left}
	.table tr:last-child{text-align: center}
	
	.table{border: 1px solid #D7DFF0;border-collapse: collapse;border-style: hidden;border-radius: 10px 10px 0 0;box-shadow: 0 0 0 1px #d7dff0;}
	.table thead th{font-size: 12px;font-weight: bold;color: #6F83AA;letter-spacing: 0.5px;background: #E6EBF7;text-transform: uppercase;padding: 0.8rem;text-align: left}
	.table thead tr th:first-child{border-top-left-radius: 5px}
	.table thead tr th:last-child{border-top-right-radius: 5px}
	.table td, .table th{border-top: 1px solid #D7DFF0;padding: 0.9rem 0.75rem;color: #364159;font-weight: 600;}
	.table td{background: #ffffff;}
	
		
	h3.title{font-size: 12px;text-transform: uppercase;color: #0332AA;letter-spacing: 0.5px;font-weight: bold;}
		
		.dataTables_empty{text-align: center !important}
		.dataTables_wrapper{overflow-x: auto}
	
</style>


<main>

	<div class="container-fluid">

		<div class="row">
		  <div class="col-12">

		  
		  <?php if($results['model']!=""){?>
			  <div class="row">
			   
			   	  <div class="col-12">
			   		<h1>Model Exam Results</h1>
				  </div>
			   
			   </div>

			   <div class="mb-3"></div>
			   
			   
			   <div class="px-0 py-2 results">
			                  
                <table class="table">
              <thead>
                <tr>
                  <th scope="col" width="12%">Exam Date</th>
                  <th scope="col" width="16%">Name of Exam</th>
                  <th scope="col" width="5%">Phy</th>
                  <th scope="col" width="5%">Che</th>
                  <th scope="col" width="5%">Bio</th>
                  <th scope="col" width="5%">Mat</th>
                  <th scope="col" width="5%">P-I</th>
                  <th scope="col" width="6%">P-II</th>
                  <th scope="col" width="6%">Total Marks</th>
                  <th scope="col" width="6%">Max Marks</th>
                  <th scope="col" width="6%">Highest Marks</th>
                  <th scope="col" width="6%">Percent %</th>
                  <th scope="col" width="5%">Grade</th>
                  <th scope="col" width="5%">Rank</th>
                  <th scope="col" width="6%">Students Appeared</th>
                </tr>
              </thead>
              <tbody>
                
                <?php echo $results['model'];?>
   
              </tbody>
            </table>
               
			</div>
		   
		   
		   <div class="mb-4"></div>
		   
		   <?php }?>
		   
		   <?php if($results['weekly']!=""){?>
		   
		    <div class="row">
			   
			   	  <div class="col-12">
			   		<h1>Weekly Exam Results</h1>
				  </div>
			   
			   </div>

			   <div class="mb-3"></div>
			   
			   
			   <div class="px-0 py-2 results">
			                  
                <table class="table">
              <thead>
                <tr>
                  <th scope="col" width="12%">Exam Date</th>
                  <th scope="col" width="16%">Name of Exam</th>
                  <th scope="col" width="5%">Phy</th>
                  <th scope="col" width="5%">Che</th>
                  <th scope="col" width="5%">Bio</th>
                  <th scope="col" width="5%">Mat</th>
                  <th scope="col" width="5%">P-I</th>
                  <th scope="col" width="6%">P-II</th>
                  <th scope="col" width="6%">Total Marks</th>
                  <th scope="col" width="6%">Max Marks</th>
                  <th scope="col" width="6%">Highest Marks</th>
                  <th scope="col" width="6%">Percent %</th>
                  <th scope="col" width="5%">Grade</th>
                  <th scope="col" width="5%">Rank</th>
                  <th scope="col" width="6%">Students Appeared</th>
                </tr>
              </thead>
              <tbody>
                
                <?php echo $results['weekly'];?>
   
              </tbody>
            </table>
               
			</div>
		   
		   <?php }?>
		   
		   <?php if($results['test']!=""){?>
		   
		    <div class="row">
			   
			   	  <div class="col-12">
			   		<h1>Screening Test Results</h1>
				  </div>
			   
			   </div>

			   <div class="mb-3"></div>
			   
			   
			   <div class="px-0 py-2 results">
			                  
                <table class="table">
              <thead>
                <tr>
                  <th scope="col" width="12%">Exam Date</th>
                  <th scope="col" width="16%">Name of Exam</th>
                  <th scope="col" width="16%">Roll No</th>
                  <th scope="col" width="5%">Phy</th>
                  <th scope="col" width="5%">Che</th>
                  <th scope="col" width="5%">Bio</th>
                  <th scope="col" width="5%">Mat</th>
                  <th scope="col" width="5%">P-I</th>
                  <th scope="col" width="6%">P-II</th>
                  <th scope="col" width="6%">Total Marks</th>
                  <th scope="col" width="6%">Max Marks</th>
                  <th scope="col" width="6%">Highest Marks</th>
                  <th scope="col" width="6%">Percent %</th>
                  <th scope="col" width="5%">Grade</th>
                  <th scope="col" width="5%">Rank</th>
                  <th scope="col" width="5%">Out Of</th>
                  <th scope="col" width="5%">Status</th>
                  <th scope="col" width="5%">Scholarship Earned</th>
                  <th scope="col" width="5%">Remarks</th>
                  <th scope="col" width="6%">Students Appeared</th>
                </tr>
              </thead>
              <tbody>
                
                <?php echo $results['test'];?>
   
              </tbody>
            </table>
               
			</div>
		   
		   <?php }?>
		   
		   <?php if($results['model']=="" && $results['weekly']=="" && $results['test']==""){?>
		   
		   <div class="row results">

					<div class="col-12 mb-4">
						<div class="card">
							<div class="card-body">

								<p class="text-muted text-center mb-0">No Results Found.</p>

						</div>
					</div>
				</div>
			</div>
	   
		   <?php }?>
			   
			   
			</div>
			
		</div>
		
	</div>
	
</main>
 
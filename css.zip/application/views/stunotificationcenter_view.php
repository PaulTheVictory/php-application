<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/dataTables.css?v=1.5" />
<script src="<?php echo base_url(); ?>js/jquery.dataTables.js?v=1.0" type="text/javascript"></script>
	
 <script type="text/javascript">
$(document).ready(function(){	
    
            
        var oTable = $('.table').dataTable({
                    "bProcessing": true,
                    "sPaginationType": "full_numbers",
                     "oLanguage": {
                        "sProcessing": "<img src='<?php echo base_url(); ?>images/loader.gif'>",
						 "sEmptyTable": "No notification found"
                    },
                    'iDisplayLength': 10,
					"order": [0,"desc"],
                    "fnDrawCallback": function( oSettings ) {
						
					}
         }); 
	
	
	$(document).on("click",".viewmsg",function(){
		           
			var nid = $(this).data('nid');
		 
		 	if(nid=="") {alert("Select notification"); return false;}

			$.ajax({
				url: 'stunotificationcenter/GetStudentSingleNotifications',
				type: 'post',
				data: {"nid":nid},
				success: function(o){

					var response = $.parseJSON(o);

				if(response)	{
					
					$('#notifymessageModal').modal({show:true});
					
					if(response['method']=="email"){
						$('#notifymessageModal').find('.emailtext').removeClass('d-none');
						$('#notifymessageModal').find('.headtitle').html(response['subject']);
					}else{
						$('#notifymessageModal').find('.emailtext').addClass('d-none');
						$('#notifymessageModal').find('.headtitle').html("SMS");
					}
					
					$('#notifymessageModal').find('.msgtext').html(response['message']);
					
				}else{
					alert("Notification not found");
					$('#notifymessageModal').modal('hide');
				}

				}
			});
             
     });
	
});
         
</script>
	<style type="text/css">

	.results .card{background: linear-gradient(0deg, #FFFFFF, #FFFFFF), #C4C4C4;box-shadow: 0px 0px 7px rgba(196, 196, 196, 0.35);border-radius: 10px;}
	
	.table tr:last-child td{text-align: left}
	.table tr td:last-child,.table tr th:last-child{text-align: left}
	.table tr:last-child td:last-child{font-weight: 600;text-align: left}
	.table tr:last-child{text-align: center}
	
	.table{border: 1px solid #D7DFF0;border-collapse: collapse;border-style: hidden;border-radius: 10px 10px 0 0;box-shadow: 0 0 0 1px #d7dff0;}
	.table thead th{font-size: 12px;font-weight: bold;color: #6F83AA;letter-spacing: 0.5px;background: #E6EBF7;text-transform: uppercase;padding: 0.8rem;text-align: left}
	.table thead tr th:first-child{border-top-left-radius: 5px}
	.table thead tr th:last-child{border-top-right-radius: 5px}
	.table td, .table th{border-top: 1px solid #D7DFF0;padding: 0.9rem 0.75rem;color: #364159;font-weight: 600;}
	.table td{background: #ffffff;}
	
		
	h3.title{font-size: 12px;text-transform: uppercase;color: #0332AA;letter-spacing: 0.5px;font-weight: bold;}
		
		.dataTables_empty{text-align: center !important}
		.dataTables_wrapper{overflow-x: auto}
		
		#notifymessageModal.modal .modal-header{padding: 10px 20px !important;border: none;background: #6884CC;color: #FFFFFF;border-radius: 10px 10px 0px 0px;}
		#notifymessageModal.modal .modal-header h2{font-weight: 600;font-size: 14px;line-height: 20px;}
		#notifymessageModal.modal .modal-content{border-radius: 10px 10px 0px 0px;}
		#notifymessageModal.modal .modal-body{padding:1.75rem 1.75rem;color: #364159;font-weight: 600;font-size: 14px;line-height: 26px;}
		.modal-body p{text-align: left !important}
		.modal-backdrop.show {opacity: .5 !important;}
		.modal .close{color: #ffffff}
	
</style>

<?php 

	$trdata = '';//print_r($notifydetails);
	foreach($notifydetails as $notify){
		
		if($notify['method']=="email"){
			
			$subject = $notify['subject'];
			
		}else{
			$subject = $notify['message'];
		}
		
		$trdata .= '<tr>
					  <td><input class="gchkbox" style="margin-left:9px;float:left;padding:5px;" type="checkbox"/></td>
					  <td>'.date("d M Y",strtotime($notify['created_at'])).'</td>
					  <td>'.$subject.'</td>
					  <td><a href="#" title="View" class="viewmsg" data-nid="'.$notify['id'].'"><img src="img/icons/eye-b.png" alt="View Icon" /> View</a></td>
				  	</tr>';
		
	}

?>

<main>

	<div class="container-fluid">

		<div class="row">
		  <div class="col-12">
		  
			  <div class="row">
			   
			   	  <div class="col-12">
			   		<h1>Notification</h1>
				  </div>
			   
			   </div>

			   <div class="mb-3"></div>
			   
			   
			   <div class="px-0 py-2 results">
			                  
                <table class="table">
              <thead>
                <tr>
                  <th scope="col" width="10%"><input class="gchkbox" style="margin-left:9px;float:left;padding:5px;" type="checkbox"/></th>
                  <th scope="col" width="30%">Date</th>
                  <th scope="col" width="30%">Subject / SMS</th>
                  <th scope="col" width="30%">Action</th>
                </tr>
              </thead>
              <tbody>
                
                	<?php echo $trdata; ?>
                
				   <!--<tr>
					  <td><input class="gchkbox" style="margin-left:9px;float:left;padding:5px;" type="checkbox"/></td>
					  <td>15 Sep 2021</td>
					  <td>II nd Batch Started On Oct 1</td>
					   <td><a href="#" title="View" class="viewmsg"><img src="img/icons/eye-b.png" alt="View Icon" /> View</a></td>
				  </tr>-->
   
              </tbody>
            </table>
               
			</div>
		   		   
		   
		   <!--<div class="row results">

					<div class="col-12 mb-4">
						<div class="card">
							<div class="card-body">

								<p class="text-muted text-center mb-0">No Notification.</p>

						</div>
					</div>
				</div>
			</div>-->
	   
			   
			   
			</div>
			
		</div>
		
	</div>
	
</main>

<div id="notifymessageModal" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
			  	   <h2 class="my-0 headtitle"></h2>
				   <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				</div>
				<div class="modal-body text-center">
														
					<p class="msgtext"></p>
					
					<p class="mb-1 d-none emailtext">Thanks</p>
					<p class="mb-1 d-none emailtext">Brilliant Study Centre Pala</p>
					
				</div>
								
			</div>
		</div>
	</div>
 
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/dataTables.css?v=1.6" />
<script src="<?php echo base_url(); ?>js/jquery.dataTables.js?v=1.0" type="text/javascript"></script>
  <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/lc_switch.css?v=1.3" />
<script src="<?php echo base_url(); ?>js/lc_switch.min.js?v=1.0" type="text/javascript"></script>
<style type="text/css">


.dataTables_wrapper input[type="text"] {
    padding: 0;
}
.dataTables_wrapper select {
    padding: 0;
}

.sortable thead tr  {
    background: #E6EBF7;

/* g8 */
border: 1px solid #D7DFF0;
box-sizing: border-box;
border-radius: 10px 10px 0px 0px;
 

}
.sortable tr th {
    border-right: 0px;
    padding: 15px 0;font-size: 13px;
      color: #6F83AA;
   cursor: pointer;
   text-align: center;

}
.sortable tr th:nth-child(1) {
  width:100px;
   text-align: center;
}

.sortable tr th:nth-child(2) {
  background: #E6EBF7 url('<?php echo base_url(); ?>/images/datatable/sort_both.png') no-repeat center left;
  background-position-x: 110px;
  background-position-y: 16px;
   text-align: left;
}

.sortable tr th:nth-child(3) {
  text-align: left;
}


.sortable tr th:nth-child(4) {
  width:200px;
}


.sortable tr td p { margin: 5px; }
.sortable tr td {
    border-right: 0px;
    padding: 0px;
    text-align: center;font-size: 13px;
    min-width:50px;vertical-align: middle;color:#000;
}
.sortable tr td a {
    color: #364159;
}

#profile-right h2 {
    margin: 0px 0px 10px 0px;
}

.usertable_length { width: auto !important; }
#usertable_filter input { padding-top:4px;background: #fff url('<?php echo base_url(); ?>/images/search.png') no-repeat center left;background-position-x: 10px;border: 1px solid #D7DFF0; line-height: 32px;margin-left: 10px;width:260px;border-radius: 5px;text-indent: 30px;font-size: 13px;}
.sortable tr td a:hover { text-decoration: underline; }
</style>
<script type="text/javascript">
$(document).ready(function(){	
		
	
          var columnData = [
              { "data": "created_at" },
                    { "data": "gname" },
                    { "data": "gtype" },
                    { "data": "groupid" }
                    
                  ];
        // columnData.push( {data: "id","visible":true} );
         //columnData.push( {data: "item_name_search","visible":false} );
         
       
        var oTable = $('#usertable').dataTable({
                    "bProcessing": true,
                    "bServerSide": true,
                    "sPaginationType": "full_numbers",
                    "ajax": {
                    "url": 'usergroups/GetGroups',
                    "type": "POST",
                   
                    "data":{ "type": ""}
                     }, 
                     "oLanguage": {
                        "sProcessing": "<img src='<?php echo base_url(); ?>images/loader.gif'>"
                    },
                    'iDisplayLength': 20,
                    "columns": columnData,
                    "order": [[ 0, "desc" ]],
                    "fnDrawCallback": function( oSettings ) {
                        var count = 1;
                        
                         $("#usertable").find("tr .sno").each(function(){
                            
                            $(this).text(count); count++;
                            var gtype = $(this).closest("tr").find(".gtype").text();
                            if(gtype === "A"){ $(this).closest("tr").find(".gtype").text("Acedemic");}
                            if(gtype === "F"){ $(this).closest("tr").find(".gtype").text("Financial");}
                            if(gtype === "B"){ $(this).closest("tr").find(".gtype").text("Both");}
                            if(gtype === "L"){ $(this).closest("tr").find(".gtype").text("Library");}
        
                          });
        
                         $("#usertable").find(".del").each(function(){

                            $(this).click(function(){ 

                              if(confirm("Are you sure to delete this item ?")) {
                                    var ide = $(this).attr("id");
                                    $.get('usergroups/Delgroups',{
                                                               'ide':ide

                                                    }, function(o) { 
                                                            var obj1 = $.parseJSON(o);
                                                    if (obj1[0] === 'success') {
                                                        oTable.fnDraw(); 
                                                    } else if (obj1[0] === 'fail') {
                                                        alert("Error!!! please try again");
                                                }
                                    });
                                }

                              });
                        

                          });
                          
                            
                    }
         }); 
         
         
         
  
	
});
</script>


<div class="wrap dynamic-width" style="float: left;position: relative">
    
    <div style="margin-top: 10px; width: 100%; height: 50px; text-align: right;">
             <span style="font-weight: bold;font-size: 20px;padding: 10px;float:left;color: #364159">User Groups</span>
             
          <?php if(isset($roleaccess['uadd']) && $roleaccess['uadd']=="y"){ ?> 
              
   				<a style="font-size: 14px;padding: 10px;  color: #fff; margin: 0px auto; position: relative; top: 5px;border-radius:5px;background: linear-gradient(180deg, #4F70C4 0%, #1C47B3 100%);" href="<?php echo base_url(); ?>useraddgroup"><span style="position: relative;top:4px"><img  src="<?php echo $this->config->item('web_url') ?>images/addcourse.png" alt="Navigation" /></span><span style="margin-left:5px">Add Group</span></a>
        
         <?php } ?> 
         
         </div>         
         <?php echo $this->table->generate();  ?>             
         
        
        
        </div>
    
 
    


<script src="<?php echo base_url(); ?>js/onscan.min.js?v=1.0" type="text/javascript"></script>

 <style type="text/css">
     
	 .add-book .card{background: linear-gradient(0deg, #FFFFFF, #FFFFFF), #C4C4C4;box-shadow: 0px 0px 7px rgba(196, 196, 196, 0.35);border-radius: 10px;}
	 
    .response p { float: right;font-size:12px;color:#eb345e;}
	 
	 .profilepic{width: 120px;height: 120px}
  
 </style>

<main> 
        
        <div class="container-fluid">
        
        <div class="col-12 mb-4 add-book">
        
			<div class="row mb-3">
				<div class="col-md-10">
					<h1>Issue Book(s)</h1>
				</div>
				<div class="col-md-2">
					<a href="#" title="Staff"><button class="btn btn-primary">Staff</button></a>
				</div>
			</div> 
        
        <div class="card p-4">
                	                             
                <div class="row align-items-center">
                                      
                    <div class="col-12 col-sm-2 text-center">
                    
                    	<img src="img/myprofile.png" class="profilepic img-thumbnail border-0 rounded-circle align-self-center" alt="Profile Pic" />
				  		
					</div>
                   
                    <div class="col-12 col-sm-5">
                    
				  		<div class="form-group position-relative error-l-50 floating">
                      
                    		<input type="text" name="studentid" value="" class="form-control studentid" id="studentid" placeholder=" " />
                       		 
							 <label>Student ID </label>
						</div>
						
					</div> 
              
              	 <div class="col-12 col-sm-5">
                    
				  		<div class="form-group position-relative error-l-50 floating">
                      
                    		<select name="centers" value="" class="form-control centers" required>
								<option value="">Select Center</option>
								 <?php echo $units;?>                      		 
                       		 </select>
                       		 
							 <label>Select Center <span>*</span> </label>
						</div>
						
					</div>
               
                               
				 </div>
               
				 <!--<div class="row mt-3">

					  <div class="col-md-8"> 
						<p class="alert"></p>
					  </div>
					  
					  <div class="col-md-2">
					 	 
 						 <button class="btn btn-primary scanbtn">Scan</button>

					 </div>

					 <div class="col-md-2">
					 	 
 						 <button class="btn btn-primary cancelbtn">Cancel</button>

					 </div>

				 </div>-->
		   
                                      
			</div>
			</div>
		                                    		                                 		
			                                    
  </div>
 
 </main>
   
    
<script type="text/javascript">
$(document).ready(function() {
	
      
	$("#studentid").focus();
	$(".centers").prop("selectedIndex", 1).attr('value',$(".centers option:nth-child(1)").text());
	
	$("select").change(function(){
		$(this).attr('value',$(this).val());
	});
	
		// Initialize with options
onScan.attachTo(document, {
    suffixKeyCodes: [13], // enter-key expected at the end of a scan
    reactToPaste: false, // Compatibility to built-in scanners in paste-mode (as opposed to keyboard-mode)
    onScan: function(sCode, iQty) { // Alternative to document.addEventListener('scan')
        //console.log('Scanned: ' + iQty + 'x ' + sCode); 
		$("#studentid").val(sCode).focus();
		scanbarcode(sCode);
    },
    onKeyDetect: function(iKeyCode){ // output all potentially relevant key events - great for debugging!
        //console.log('Pressed: ' + iKeyCode);
		//$("#barcode").focus();
    }
});
	
    $(document).on("click",".scanbtn",function(e){
				
			var studentid = $("#studentid").val();
		
			scanbarcode(studentid);
		                              
     });
	
    $(document).on("click",".proceedbtn",function(e){
						
			var studentid = $("#studentid").val();
			var center = $(".centers").val();
		
			if(studentid=="") { alert("Scan or Type Student ID"); return false;}
		
			if(center=="") { alert("Select Center"); return false;}
		
			window.open("issuebookdetails?stuid="+studentid+"&center="+center,"_self");
                              
     });
	
	$(document).on("click",".cancelbtn",function(e){
				
			$("#studentid").val("");
			$(".centers").prop("selectedIndex", 1).attr('value',$(".centers option:nth-child(1)").text());
			$(".scanbtn").removeClass('proceedbtn').addClass('scanbtn').text("Scan");
			$(".profilepic").attr('src','img/myprofile.png');                             
     });
	
            
});
	
function scanbarcode(studentid){
		
			var center = $(".centers").val();
		
			if(studentid=="") {alert("Scan Student ID"); return false;}
		
			//if(studentid.length < 3 || studentid.length > 7) {alert("Barcode must be upto 7 digit"); return false;}
			
			$(".alert").removeClass("alert-success alert-danger").text('');
		         
	   		$(".alert").addClass("alert-success").text('Progressing...');

			$.ajax({
				url: "issuebook/issuebookSubmit",
				type: 'post',
				data: {"studentid":studentid},
				success: function(o){

					var response = $.parseJSON(o);
					
					if(response.status === 'success') {

						var studata = response.data;
						
						var profilepic = "img/myprofile.png";
						
						if(studata['profilepic'] !='0' && studata['profilepic']!=0){
							
							profilepic = "docs/profilepic/"+studata['id']+'/'+studata['profilepic'];
						}
						
						$(".alert").removeClass("alert-success alert-danger").html('');
						
						$(".profilepic").attr('src',profilepic);
						
						$(".scanbtn").addClass('proceedbtn').removeClass('scanbtn').text("Proceed");

					} else {

					   $(".alert").addClass("alert-danger").text(response.message); 
						
						$(".profilepic").attr('src',profilepic);
						$(".scanbtn").removeClass('proceedbtn').addClass('scanbtn').text("Scan");

					}
					
					setTimeout(function(){$(".alert").removeClass("alert-success alert-danger").html('');},3000);

				}
			});
		
	}
	
</script>
 <link href="<?php  echo base_url(); ?>css/jquery-ui.min.css?v=1.4" rel="stylesheet" type="text/css" />
 <script src="<?php  echo base_url(); ?>js/jquery-ui.min.js?v=1.3" type="text/javascript"></script>
 <link href="<?php  echo base_url(); ?>css/chosen.min.css?v=1.3" rel="stylesheet" type="text/css" />
  <script src="<?php  echo base_url(); ?>js/chosen.jquery.min.js?v=1.2" type="text/javascript"></script>
 <style type="text/css">
     
     .ui-selectmenu-button.ui-button{ width: 97%; padding:13px;}
     #ugroups-button,#msession-button{border: 1px solid #D7DFF0;background: #fff;font-size: 14px;color:#536485;padding: 10px}
     .maincontent ul li.search-choice { height:auto; }
     .maincontent ul li.search-choice a{ height:auto; font-size: 14px;color:#536485}
     .response p { float: right;font-size:12px;color:#eb345e;}
     

#centers_chosen,#lcenters_chosen  {border: 1px solid #D7DFF0;background: #fff;padding: 8px 0px;}
#ucourses_chosen  {border: 1px solid #D7DFF0;background: #fff;padding: 8px 0px;}
 .chosen-container-multi .chosen-choices {border: 0px;background: none}

.sortable tr td a:hover { text-decoration: underline; }
.sortable tr td span{ font-size: 14px;color: #364159 }
 .chosen-container-multi .chosen-choices li.search-choice { background: #6884CC;border-radius: 5px;}
.chosen-container-multi .chosen-choices li.search-choice {color: #fff;}

 </style>

	<div class="wrap dynamic-width" style="float: left;position: relative;min-width: 800px">
     <div style="margin-top: 10px; width: 99%; height: 50px; text-align: right;">
         <span style="font-weight: bold;font-size: 20px;padding: 10px;float:left;color: #364159">Edit Staff</span>
         
     </div>         
            <div id="course-container" class="add-course">
<?php echo form_open('staffedit/staffSubmit', array('id' => 'userForm')) ?>
                <div class="row-element">
                    <span class="title">Name</span>
                    <span class="content"><input placeholder="Name" type="text" value="<?php echo $edit['staffname']; ?>" name = "staffname" class="staffname"></span>
                </div>
                <div class="row-element">
                    <span class="title">Email Address</span>
                    <span class="content"><input placeholder="Email Address" type="text" value="<?php echo $edit['staffemail']; ?>" name = "staffemail" class="staffemail"></span>
                </div>
                <div class="row-element">
                    <span class="title">Mobile Number</span>
                    <span class="content"><input placeholder="Phone Number" type="text" value="<?php echo $edit['staffmobile']; ?>" name = "staffmobile" class="staffmobile"></span>
                </div>
                <input type="hidden" name="staffid" value="<?php echo $edit['id'];?>" />
            <?php echo form_close() ?>
                
            </div>
            
       
     <div style="margin-top: 0px; width: 98%; height: 70px; text-align: right;">
         <span  style="margin: 0px auto; float:right;margin-top: 18px;padding: 10px; color: #fff; background: #4f6fc4 none repeat scroll 0% 0%; border-radius:5px;cursor: pointer" class="btn savebtn" href="#">Save</span>
         <a style="margin: 0px auto; float:right;margin-top: 18px;margin-right:18px;padding: 9px 10px; color: #0332AA; background: linear-gradient(0deg, #FFFFFF, #FFFFFF), #C4C4C4;border: 1px solid #0332AA; border-radius:5px" class="btn" href="<?php echo base_url(); ?>staffs">Back</a>
         <span class="response" style="margin: 0px auto; float:right;width: 80%; height: 30px;margin-top:20px"></span>
     </div>   
    
        
        </div>
    
      

    
<script type="text/javascript">
$(document).ready(function() {
       
    
    $(".savebtn").click(function(){
        
           var staffname = $(".staffname").val();  
                if (staffname=="") {  
                    alert("Please enter valid staff name.");  
                    return;  
                } 
		
				var staffmobile = $(".staffmobile").val(); 
				var validRegex1 = /^([0-9]{8,10})+$/;  
                var rMobile = staffmobile.trim();
                if (!(rMobile.match(validRegex1))) {  
                    alert("Please enter valid Phone Number.");  
                    return;  
                } 
                
                var staff = $(".staffemail").val();               
                var validRegex1 = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;  
                var rEmail = staff.trim();  
                if (!(rEmail.toLowerCase().match(validRegex1))) {  
                    alert("Please enter valid email address.");  
                    return;  
                } 
         
               if($(".response").hasClass('progress')) { return;}
               $(".response").html('').text('Progressing...');
               $(".response").addClass('progress');
               
                var userForm = $("#userForm");

                    $.ajax({
                        url: userForm.attr('action'),
                        type: 'post',
                        data: userForm.serialize(),
                        success: function(o){
                            
                            var response = $.parseJSON(o);
                            $(".response").html('');
                            if(response.status === 'success') {
                       
                              $(".response").css("color","rgb(25, 71, 15)");
                              $(".response").text(response.message);
                              $(location).prop('href', 'staffs');
                               
                            } else {
                                
                               $(".response").append(response.message); 
                               $(".response").removeClass('progress');
                           
                            }

                        }
                    });
                   
                              
            });
	
	
});
	
</script>
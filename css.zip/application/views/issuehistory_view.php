<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/dataTables.css?v=1.5" />
<script src="<?php echo base_url(); ?>js/jquery.dataTables.js?v=1.0" type="text/javascript"></script>
<script src="<?php echo base_url(); ?>js/onscan.min.js?v=1.0" type="text/javascript"></script>

 <style type="text/css">
	 
	 table.dataTable{margin-top: 1rem !important;width: 99% !important;margin: auto}
	 .table tr:last-child td{text-align: left}
	.table tr td:last-child,.table tr th:last-child{text-align: left}
	.table tr:last-child td:last-child{font-weight: 600;text-align: left}
	.table tr:last-child{text-align: center}
	
	.table{border: 1px solid #D7DFF0;border-collapse: collapse;border-style: hidden;border-radius: 10px 10px 0 0;box-shadow: 0 0 0 1px #d7dff0;}
	.table thead th{font-size: 12px;font-weight: bold;color: #6F83AA;letter-spacing: 0.5px;background: #E6EBF7;text-transform: uppercase;padding: 0.8rem;text-align: left}
	.table thead tr th:first-child{border-top-left-radius: 5px}
	.table thead tr th:last-child{border-top-right-radius: 5px}
	.table td, .table th{border-top: 1px solid #D7DFF0;padding: 0.9rem 0.75rem;color: #364159;font-weight: 600;}
	.table td{background: #ffffff;}
	
		
	h3.title{font-size: 12px;text-transform: uppercase;color: #0332AA;letter-spacing: 0.5px;font-weight: bold;}
	 h2{font-size: 12px;text-transform: uppercase;color: #0332AA;letter-spacing: 0.5px;font-weight: bold;}
	 
		
		.dataTables_empty{text-align: center !important}
		.dataTables_wrapper{overflow-x: auto}
	 
	 .card{background: linear-gradient(0deg, #FFFFFF, #FFFFFF), #C4C4C4;box-shadow: 0px 0px 7px rgba(196, 196, 196, 0.35);border-radius: 10px;}
	 
	 .form-group.floating{margin-bottom: 0}
	 
	 p.list-item-heading{color: #6884CC;font-weight: 600;}
	.feetop p.list-item-heading span:last-child{font-weight: 600;font-size: 14px;color: #364159;}
	 
	 .icon-edit{background: url(img/icons/edit3-b.png) no-repeat;width: 15px;height: 16px;display: inline-block;vertical-align: middle}
	 .bookdetails p span:last-child{font-weight: 600;font-size: 14px;line-height: 14px;color: #364159;}
	 .bookdetails p a {font-weight: 600;font-size: 14px;line-height: 20px;color: #0332AA;}

	 
	#issuestatusModal h2{font-size: 14px;text-transform: none;color: #364159;letter-spacing: 0px;font-weight: bold;}
	h5.modal-title p.headtitle{display: inline-block;width: 100%;text-align: center;font-weight: bold;font-size:17px;color: #fff;}
	h5.modal-title p.text-muted{display: inline-block;width: 100%;text-align: center;font-weight: 600;font-size: 14px;line-height: 36px;color: #181E29;line-height: 20px;}
	.modal-title img{display: block;margin: 1em auto}
	#EditbooklimitModal.modal .modal-header,#issuestatusModal.modal .modal-header{padding: 10px 20px !important;border: none}	
	#EditbooklimitModal.modal .modal-body,#issuestatusModal.modal .modal-body{padding:0 1.75rem 1.75rem}
	.modal-body p{text-align: left !important}
	.modal-backdrop.show {opacity: .5 !important;}
	 
	 .profilepic{width: 120px;height: 120px}
	 
	 table.dataTable{margin-top: 2rem !important}
	 .dataTables_filter{right: 0;left: inherit;top: 5px;}
	 .dataTables_filter input{width: 300px}
	 .dataTables_wrapper {top: 25px;padding-top: 3rem}
	 
 </style>
 
 <script type="text/javascript">
	 
	 var oTable,oTablehistory = "";
$(document).ready(function(){	
		
	
	$("select").change(function(){
		$(this).attr('value',$(this).val());
	});
	
	
         /* var columnData1 = [
              { "data": "created" },
                    { "data": "barcode" },
                    { "data": "bookname" },
                    { "data": "price" },
                    { "data": "booktype" },
                    { "data": "duedate" },
                    { "data": "dueperiod" },
                    
                  ];
        // columnData.push( {data: "id","visible":true} );
         //columnData.push( {data: "item_name_search","visible":false} );
         
       
        oTablehistory = $('#issuehistorytable').dataTable({
                    "bProcessing": true,
                    "bServerSide": true,
                    "sPaginationType": "full_numbers",
                    "ajax": {
                    "url": 'issuehistory/GetIssueBookDetails',
                    "type": "POST",
                   
                    "data":{ "stuid": "<?php echo $stuid; ?>"}
                     }, 
                     "oLanguage": {
                        "sProcessing": "<img src='<?php echo base_url(); ?>images/loader.gif'>"
                    },
                    'iDisplayLength': 1000,
                    "columns": columnData1,
                    "order": [[ 0, "desc" ]],
                    "fnDrawCallback": function( oSettings ) {
						
                        var count = 1;
						
                         $('#issuehistorytable').find("tr .sno").each(function(){                           
                            $(this).text(count);
                            count++;
                         });
                                                      
                    }
         }); 
	*/
	
	 oTable = $('#usertable').dataTable({
                    "bProcessing": true,
                    "sPaginationType": "full_numbers",
                     "oLanguage": {
                        "sProcessing": "<img src='<?php echo base_url(); ?>images/loader.gif'>",
						 "sEmptyTable": "No Books Added",
                    },
                    "columns": [
							{ title: "S.NO" },
							{ title: "BARCODE" },
							{ title: "BOOK NAME" },							
							{ title: "PRICE" },							
							{ title: "REFERENCE" },							
							{ title: "DUE DATE" },							
							{ title: "DUE" }	,							
							{ title: "ACTION" }						
						],
                    'iDisplayLength': 1000,
                    //"columns": columnData,
                    "order": [[ 0, "asc" ]],
                    "fnDrawCallback": function( oSettings ) {
						
                        var count = 1;
						
                         $('#usertable').find("tr .sno").each(function(){                           
                            $(this).text(count);
                            count++;
                         });
                                                      
                    }
         }); 
	
	
	oTablehistory = $('#issuehistorytable').dataTable({
                    "bProcessing": true,
                    "sPaginationType": "full_numbers",
                     "oLanguage": {
                        "sProcessing": "<img src='<?php echo base_url(); ?>images/loader.gif'>",
						 "sEmptyTable": "No Issued History",
						 "sSearchPlaceholder": "Search Barcodes",
                    },
                    "columns": [
							{ title: "S.NO" },
							{ title: "BARCODE" },
							{ title: "BOOK NAME" },							
							{ title: "PRICE" },							
							{ title: "REFERENCE" },	
						{ title: "ISSUE DATE" },
							{ title: "DUE DATE" },
						{ title: "RECEIVED DATE" },
							{ title: "DUE" }						
						],
                    'iDisplayLength': 1000,
                    //"columns": columnData,
                    "order": [[ 0, "asc" ]],
                    "fnDrawCallback": function( oSettings ) {
						
                        var count = 1;
						
                         $('#issuehistorytable').find("tr .sno").each(function(){                           
                            $(this).text(count);
                            count++;
                         });
                                                      
                    }
         }); 
         
      $('.dataTables_filter input').addClass('form-control');     
	
});
</script>

 <main> 
        
        <div class="container-fluid">
                 
    
    		<div class="row mb-3">
				<div class="col-md-6">
					<h1>History</h1>
				</div>
				<div class="col-md-2">
					<a href="bookhistory" title="Book"><button class="btn btn-primary">Book</button></a>
				</div>
				<div class="col-md-2">
					<button class="btn btn-primary staffbtn">Staff</button>
				</div>
				<div class="col-md-2">
					<a href="issuehistory" title="Clear"><button class="btn btn-primary">Clear</button></a>
				</div>
			</div> 
			             
             
             <div class="col-12 mb-4 issuebook p-0">			
        
        		<div class="card p-4">
                	                             
                <div class="row align-items-center">
                                      
                   <!-- <div class="col-12 col-sm-2 text-center">
                    
                    	<img src="img/myprofile.png" class="profilepic img-thumbnail border-0 rounded-circle align-self-center" alt="Profile Pic" />
				  		
					</div>-->
                   
                    <div class="col-12 col-sm-5">
                    
				  		<div class="form-group position-relative error-l-50 floating">
                      
                    		<input type="<?php if($type!="staff"){ echo "text";}else{ echo "number";}?>" name="studentno" value="" class="form-control studentno" id="studentno" placeholder=" " />
                       		 
							 <label><?php if($type!="staff"){ echo "Student ID";}else{ echo "Mobile Number";}?> <span>*</span> </label>
						</div>
						
					</div> 
              
              	 <!--<div class="col-12 col-sm-5">
                    
				  		<div class="form-group position-relative error-l-50 floating">
                      
                    		<select name="centers" value="" class="form-control centers" required>
								<option value="">Select Center</option>
								 <?php //echo $units;?>                      		 
                       		 </select>
                       		 
							 <label>Select Center <span>*</span> </label>
						</div>
						
					</div>-->
               
                   <div class="col-12"> 
						<p class="alert stualert my-3"></p>
					  </div>           
                               
				 </div>
		   
                                      
			</div>
			
				
			
			</div>
             
           <?php if(!empty($studentdetails)){?>  
              
              <div class="issuedetails">
               
            <div class="row px-3 mt-4">     
                     
           <div class="col-12 p-0">
           
           <div class="card">
           
            <div class="course-container add-course mt-0 px-0">
                   
                   <div class="d-flex flex-row">
             
				<a class="d-flex position-relative" href="#"><img alt="Profile" src="<?php if($studentdetails['profilepic']!="0" && $studentdetails['profilepic']!="") {echo "docs/profilepic/".$studentdetails['id']."/".$studentdetails['profilepic'];}else{ echo "img/myprofile.png";} ?>" class="img-thumbnail profilepic border-0 rounded-circle m-4 align-self-center"></a>
             
              <div class="d-flex flex-grow-1 min-width-zero">
                <div class="card-body pl-0 align-self-center d-flex flex-column flex-lg-row justify-content-between min-width-zero">
                  <div class="w-100">
                   
                          <div class="row mb-3 feetop">
                   
					<div class="col-12 text-left px-2">
						<p class="list-item-heading mb-1"> <span><?php if($type!="staff"){echo "Student";}else{echo "Staff";} ?> Name :</span> <span class="stuname"><?php echo $studentdetails['stuname']; ?></span></p>
					</div>
					
				</div>
                  
                <div class="row mb-3 feetop">
                   
					<div class="col-md-4 col-sm-4 col-4 text-left px-2">
						<p class="list-item-heading mb-1"> <span><?php if($type!="staff"){echo "Student";}else{echo "Email";} ?> ID:</span> <span class="studid"><?php echo $studentdetails['studid']; ?></span></p>
					</div>
                   
					<div class="col-md-3 col-sm-3 col-3 text-left px-2">
						<p class="list-item-heading mb-1"> <span>Mobile number:</span> <span class="stumobile"><?php echo $studentdetails['smcode']; ?> <?php echo $studentdetails['smobile']; ?></span></p>
					</div>
					
				</div>  
                 
                  </div>
                </div>
              </div>
            </div>
                                  
               
                </div>
                
			   </div>
               
            </div>
             
          
           </div>
           
			<div class="d-inline-block my-3"></div>
                 
         
          <div class="card p-4 mt-4">
                  
			  	<h2>Books Issued History</h2>
                    
                <table id="issuehistorytable" class="sortable table" style="width:100%"></table>    
				<?php //echo $this->table->generate();  ?>
                                 		           
			</div>
     
      
			</div>
      
     		<?php }?>
       
 </div>
 
 </main>

	
<script type="text/javascript">
	
	var stuid = "";
	var center = "";
	var barcodes = [];
	var tabledata = [];
	var tablerow = [];
	
    $(document).ready(function() {
   
			
		$("select").change(function(){
			$(this).attr('value',$(this).val());
		});
		
		stuid = "<?php echo $stuid; ?>";
		center = "<?php echo $center; ?>";
		
		
		if(stuid!=""){
			loadresults(oTablehistory,stuid);
			$("#barcode").focus();
		}else{
			$("#studentno").focus();
		}
		
		if(center!=""){
			$(".centers").val(center).attr('value',center);
		}
		
		if($(".centers option").length < 3){
			$(".centers").prop("selectedIndex", 1).attr('value',$(".centers option:nth-child(1)").text());
		}else{
			$(".centers").change(function(){
				if(stuid!=""){
										
					window.location.href = "?stuid="+stuid;
					
				}
			});
		}
		
		
	// Initialize with options
	onScan.attachTo(document, {
		suffixKeyCodes: [13], // enter-key expected at the end of a scan
		reactToPaste: false, // Compatibility to built-in scanners in paste-mode (as opposed to keyboard-mode)
		onScan: function(sCode, iQty) { // Alternative to document.addEventListener('scan')
			//console.log('Scanned: ' + iQty + 'x ' + sCode); 
			
		if(stuid!="" && $("#studentno").val()==""){
			$("#barcode").val(sCode).focus();
			//scanbarcode(sCode);
			loadissuebookspreview(oTable,sCode,stuid);
		}else if(stuid=="" || $("#studentno").val()!=""){
			$("#studentno").val(sCode).focus();
			scanbarcodedetails(sCode);
		}	
			
		},
		onKeyDetect: function(iKeyCode){ // output all potentially relevant key events - great for debugging!
			//console.log('Pressed: ' + iKeyCode);
			//$("#barcode").focus();
		}
	});
		
	$('#studentno').keypress(function (e) {
	 var key = e.which;
	 if(key == 13)  // the enter key code
	  {
		var sCode = $(this).val();
		scanbarcodedetails(sCode);
	  }
	});	
		
	$(".staffbtn").click(function(){
		
		window.location.href = "?type=staff";
		
	});		
		
	$(document).on("click",".del",function(){
		
		var r = confirm("Are you sure to delete the book?");
			
		if(r){
				
		var barcode = $(this).attr('barcode');
		
		for(var i=0;i<tabledata.length;i++){
			//if($.inArray(barcode, tabledata[i])) {
			if(tabledata[i][1] == barcode) {
				tabledata.splice(i, 1);
				tablerow.splice(i,1	);
				break;
			}
		}
		
		oTable.fnClearTable();
		
		if(tabledata.length>0){
			oTable.fnAddData(tabledata);
			oTable.fnDraw();
		}
		
		//console.log(tabledata);
				
		}
		
	});	
    
	<?php if(!empty($studentdetails)){?>	
		
	$(".savebtn").click(function(){

		//var barcode = $("#barcode").val();

		//scanbarcode(barcode);
		
		
		if(tablerow.length<1){ $(".alert").addClass('alert-danger').text("No Books Added.");return false;}
		
		
		if($(".savebtn").hasClass('process')){
			
			$(".alert").addClass('alert-danger').text("Please wait while progressing...");
			
		}else{
		
			
			var r = confirm("Are you sure to issue the books?");
			
			if(r){
				
				$(".savebtn").addClass('process');
				$(".alert").removeClass('alert-danger').addClass('alert-success').text("Progressing...");

				$.ajax({
					type: 'POST',
					url: 'issuehistory/InsertIssueBook',
					data: {"qData":tablerow},
					success: function(response) {

						var obj1 = $.parseJSON(response);

						if(obj1.status=="success"){

							$(".issuestatus").text(obj1.message);
							$('#issuestatusModal').modal({show:true});
							
						}else{
							$(".issuestatus").text(obj1.message);
							$('#issuestatusModal').modal({show:true});
						}

					}

				});

			}
			
		}
		
                              
     });
								
	$('#issuestatusModal').on('hidden.bs.modal', function () {
	  	location.assign('issuebook');
	});
    
	$(".editlimit").click(function(){

		   $('#EditbooklimitModal').modal({show:true});               
                              
     });
		
		
	$(".editsave").click(function(){
         
		
		var booklimit = $("#booklimit").val();
		var booklimitcount = $(".booklimitcount").text();
		var totalissued = $(".totalissued").text();
		
		
		if(parseInt(booklimit) < 4 || parseInt(booklimit) < parseInt(totalissued)) {alert("Limit not less than default or books lended");return false ;}
		
		
		$(".eresponse").html('').text('Progressing...');


		var editbooklimitForm = $("#editbooklimitForm");

			$.ajax({
				url: editbooklimitForm.attr('action'),
				type: 'post',
				data: editbooklimitForm.serialize(),
				success: function(o){

					var response = $.parseJSON(o);
					$(".response").html('');
					if(response.status === 'success') {

						$(".eresponse").css("color","rgb(25, 71, 15)");
					   $(".eresponse").text(response.message);
					   //oTable.fnDraw();
					   $('#EditbooklimitModal').modal('hide');
						
						var booklimit = $("#booklimit").val();
						var totalavailable = $(".totalavailable").text();
						var totalissued = $(".totalissued").text();
						
						$(".booklimitcount").text(booklimit);
						totalavailable = parseInt(booklimit) - parseInt(totalissued)
						$(".totalavailable").text(totalavailable);
						
						$("#booklimit").val("");
						$(".eresponse").html(""); 

					} else {

					   $(".eresponse").append(response.message); 

					}

				}
			});
                    
      });
	
	<?php }?>
		
	$(document).on('focus click','input,select,textarea', function () {
	  	$(".alert").removeClass("alert-success alert-danger").html('');
	});		
           
});
	
	function removeElement(array, elem) {
		var index = array.indexOf(elem);
		if (index > -1) {
			array.splice(index, 1);
		}
	}
	
	function scanbarcodedetails(barcode){
		
			var center = $(".centers").val();
				
			if(barcode=="") {alert("Scan barcode"); $("#studentno").focus();return false;}
		
			if(center=="") {alert("Select center"); $("#studentno").focus();return false;}
		
			//if(barcode.length < 3 || barcode.length > 7) {alert("Barcode must be upto 7 digit"); return false;}
			
			$(".stualert").removeClass("alert-success alert-danger").text('');
		         
	   		$(".stualert").addClass("alert-success").text('Progressing...');

			$.ajax({
				url: "issuehistory/getstudentdetails",
				type: 'post',
				data: {"barcode":barcode,"type":"<?php echo $type; ?>"},
				success: function(o){

					var response = $.parseJSON(o);
					
					var profilepic = "img/myprofile.png";
					
					if(response.status === 'success') {

						$(".stualert").addClass("alert-success").text(response.message);
					   //oTable.fnDraw(); 
						
						var barcodedata = response.data;
						
						
						if(barcodedata['profilepic'] !='0' && barcodedata['profilepic']!=''){
							
							profilepic = "docs/profilepic/"+barcodedata['id']+'/'+barcodedata['profilepic'];
						}
						
						$(".stualert").removeClass("alert-success alert-danger").html('');
						
						$(".profilepic").attr('src',profilepic);
						
						$(".stuname").text(barcodedata['stuname']);
						$(".studid").text(barcode);
						$("#stuid").val(barcode);
						$(".stumobile").text(barcodedata['smcode']+" "+barcodedata['smobile']);
						
						var type = "<?php echo $type; ?>";
						
						var extrapara = "";
						if(type=='staff') extrapara = "&type="+type; 
						
						window.location.href = "?stuid="+barcode+extrapara;
						
						
					}else {

					   $(".stualert").addClass("alert-danger").text(response.message); 

						$(".profilepic").attr('src',profilepic);
						$(".stuname,.studid,.stumobile").text("");
						$("#stuid").val("");
						$(".totalissued,.totalavailable,.booklimitcount").text("0");
												
						setTimeout(function(){
							$(".stualert").removeClass("alert-success alert-danger").html('');
							$("#studentno").val("");
							
							if(window.location.href.indexOf("stuid") != -1){
								location.assign('issuebook');
							}else{
								oTable.fnClearTable();
							}
							
						},2000);
						
					}
					

				}
				
			});
		
	}
	
	<?php if(!empty($studentdetails)){?>
	
	
	function loadissuebookspreview(oTable,barcode,stuid){
	
		var center = $(".centers").val();
		
		var bookexists = false;
		
		//barcodes.push(barcode);
		//return;
		
		var totalbooks = tabledata.length;
		
		$.ajax({
                type: 'POST',
                url: 'issuehistory/addbarcodelistpreview',
                data: {"barcode":barcode,"stuid":stuid,"center":center,"totalbooks":totalbooks,"type":"<?php echo $type; ?>"},
                success: function(response) {
                   
					var obj1 = $.parseJSON(response);
					
					if(obj1.status=="success"){
												
						if(obj1.tabledata.length>0){//console.log(tablerow);
							
							for (var i = 0; i <tabledata.length; i++) {
								if(tabledata[i][1] == barcode){
									bookexists = true;
								}
							}

							if(!bookexists){
								
								$(".alert").addClass("alert-success").text(obj1.message);
								
								tabledata.push(obj1.tabledata);
								tablerow.push(obj1.tablerow);
								
								var totalissued = $(".totalissued").text();
								var totalavailable = $(".totalavailable").text();

								totalissued = parseInt(totalissued) + 1;
								totalavailable = parseInt(totalavailable)  - 1;

								$(".totalissued").text(totalissued);
								$(".totalavailable").text(totalavailable);
								
							}else{
								
								$(".alert").addClass("alert-danger").text("Book already added.");
								
							}
															
							if(!jQuery.isEmptyObject(tabledata)){
								
								oTable.fnClearTable();
								oTable.fnAddData(tabledata);
								oTable.fnDraw();
								
							}
																									
						}
						
					}else{
						$(".alert").addClass("alert-danger").text(obj1.message); 
					}
										
					setTimeout(function(){$(".alert").removeClass("alert-success alert-danger").html('');$("#barcode").val("").focus()},1000);
					
				}
		
		});

}
	
	
	function loadresults(oTablehistory,stuid){
	
	$.ajax({
                type: 'POST',
                url: 'issuehistory/GetIssuedHistoryList',
                data: {"stuid":stuid},
                success: function(response) {
                   
					var obj1 = $.parseJSON(response);
					
					if(obj1['tabledata'].length>0){
						
						oTablehistory.fnClearTable();
						oTablehistory.fnAddData(obj1['tabledata']);
						oTablehistory.fnDraw();
												
					}
					
				}
		
	});

}
	
<?php }?>	
	
</script>
    
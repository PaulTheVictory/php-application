<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Brilliant Study Centre, Pala</title>
<!--<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1">-->

<link rel="stylesheet" href="<?php echo base_url();?>css/boot/bootstrap.min.css">
<link rel="stylesheet" href="<?php echo base_url();?>css/boot/bootstrap.rtl.only.min.css">
<link rel="stylesheet" href="<?php echo base_url();?>css/boot/bootstrap-float-label.min.css">
<link rel="stylesheet" href="<?php echo base_url();?>css/boot/main.css">

<script src="<?php echo base_url();?>js/jquery-3.5.1.min.js"></script>


<script type="text/javascript">
$(document).ready(function(){
		
	window.print();

});
</script>

<style>
		
	.feebill h1{font-size: 24px;color: #0332AA;font-weight: bold;text-transform: uppercase;line-height: 36px;text-align: center}
	.feebill .card{background: linear-gradient(0deg, #FFFFFF, #FFFFFF), #C4C4C4;box-shadow: 0px 0px 7px rgba(196, 196, 196, 0.35);border-radius: 0px;width: 100%;border-bottom: 0px solid #0332AA;}
	.feebill h2{color: #0332AA;font-size: 18px;font-weight: bold;line-height: 26px;}
	.feebill h3{color: #181E29;font-size: 24px;font-weight: bold;line-height: 24px;text-transform: uppercase;}
	.feebill h4{font-size: 12px;font-weight: bold;color: #355BBB;line-height: 20px;letter-spacing: 0.5px;text-transform: uppercase;}
	.feebill p.list-item-heading{color: #6884CC;font-weight: 600;}
	.feebill p.list-item-heading span:last-child{font-weight: 600;font-size: 14px;color: #364159;}
	.feebill p{color: #181E29;font-size: 14px;line-height: 18px;font-weight: normal;margin-bottom: 5px;}		
	.border-right{border-right: 1px solid #D7DFF0!important;}
	
	.feebill .hr{width: 100%;height: 3px;border-bottom: 3px solid #0332AA;}
	
	main{max-width: 100%;margin: auto}
	
	.examdetails .row div:first-child p{font-weight: 500}
	.examdetails .row div:last-child p{font-weight: bold}
	
</style>

<main>

	<div class="container-fluid">
		
	<div class="row feebill">
								
		<div class="card mb-2 p-4">
		
			<div class="row">
					
			<div class="col-md-6">
			
				<img src="<?php echo base_url(); ?>css/img/brilliant-logo.png" alt="Brilliant Pala Logo" class="mb-2" />
				
				<div class="mt-3"></div>					
									
			</div>
			<div class="col-md-6 text-right">
				<h3>Brilliant Study Centre, Pala.</h3>
				<p><strong>Examination Division</strong></p>
				<p>Mutholy, Puliyannoor PO, 686-573.</p>
				<p>Phone: 04822 206 100 / 206 800</p>
				<p>Student Portal: <strong>www.brilliantpala.org</strong></p>
				<p>Email: <strong>screeningtest@brilliantpala.org</strong></p>
			</div>
			
		
		</div>
			
			<div class="hr mt-1 mb-2"></div>
			
			<h1 class="my-3">Acknowledgement</h1>
						
			<div class="row examdetails">

				<h2 class="my-3">Student Details</h2>

				<div class="col-12 my-2">
                <div class="row">

					<div class="col-md-3 col-3">
						<p>Student ID :</p>
					</div>

					<div class="col-md-9 col-9">
						<p><?php echo $examprintdetails['studid']; ?></p>
					</div>

				</div>
			</div>
			
			<div class="col-12 my-2">
                <div class="row">

					<div class="col-md-3 col-3">
						<p>Name :</p>
					</div>

					<div class="col-md-9 col-9">
						<p><?php echo $examprintdetails['sname']; ?></p>
					</div>

				</div>
			</div>
			
			<div class="col-12 my-2">
                <div class="row">

					<div class="col-md-3 col-3">
						<p>Course Name :</p>
					</div>

					<div class="col-md-9 col-9">
						<p><?php echo $examprintdetails['displaycname']; ?></p>
					</div>

				</div>
			</div>
			
			
			<h2 class="my-3">Event Details</h2>
			
			
			<div class="col-12 my-2">
                <div class="row">

					<div class="col-md-3 col-3">
						<p>Event Name :</p>
					</div>

					<div class="col-md-9 col-9">
						<p><?php echo $examprintdetails['examname']; ?></p>
					</div>

				</div>
			</div>
			
			<div class="col-12 my-2">
                <div class="row">

					<div class="col-md-3 col-3">
						<p>Date & Time :</p>
					</div>
					<div class="col-md-9 col-9">
						<p><?php 
                                                $dt = ($examprintdetails['date'] === null)?"-":date("d-M-Y h:i A",strtotime($examprintdetails['date']));
                                                echo $dt; 
                                                ?></p>
					</div>

				</div>
			</div>
			
			<div class="col-12 my-2">
                <div class="row">

					<div class="col-md-3 col-3">
						<p>Reporting Time :</p>
					</div>

					<div class="col-md-9 col-9">
						<p><?php 
                                                $rt = ($examprintdetails['rtime'] === null)?"-":date("h:i A",strtotime($examprintdetails['rtime']));
                                                echo $rt;
                                                ?></p>
					</div>

				</div>
			</div>
			
			<div class="col-12 my-2">
                <div class="row">

					<div class="col-md-3 col-3">
						<p>Duration :</p>
					</div>

					<div class="col-md-9 col-9">
						<p><?php echo $examprintdetails['duration']; ?></p>
					</div>

				</div>
			</div>
			
			<div class="col-12 my-2">
                <div class="row">

					<div class="col-md-3 col-3">
						<p>District :</p>
					</div>

					<div class="col-md-9 col-9">
						<p><?php echo $examprintdetails['district']; ?></p>
					</div>

				</div>
			</div>
			
			<div class="col-12 my-2">
                <div class="row">

					<div class="col-md-3 col-3">
						<p>Center :</p>
					</div>

					<div class="col-md-9 col-9">
						<p><?php echo $examprintdetails['location']; ?></p>
					</div>

				</div>
			</div>
			
			<div class="col-12 my-2">
                <div class="row">

					<div class="col-md-3 col-3">
						<p>Center Address:</p>
					</div>

					<div class="col-md-9 col-9">
						<p><?php echo $examprintdetails['address1']; ?>, <?php echo $examprintdetails['address2']; ?>, <?php echo $examprintdetails['pincode']; ?>.</p>
					</div>

				</div>
			</div>
			
			<div class="col-12 my-2">
                <div class="row">

					<div class="col-md-3 col-3">
						<p>Contact Number :</p>
					</div>

					<div class="col-md-9 col-9">
						<p><?php echo $examprintdetails['phone']; ?></p>
					</div>

				</div>
			</div>
			
		
			</div>	
		        
		        <div class="hr mt-5 mb-2"></div>
            
			</div>
			
		</div>
						

	</div>
</main>
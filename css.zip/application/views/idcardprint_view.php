<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/dataTables.css?v=1.5" />
<script src="<?php echo base_url(); ?>js/jquery.dataTables.js?v=1.0" type="text/javascript"></script>
<script src="<?php echo base_url(); ?>js/onscan.min.js?v=1.0" type="text/javascript"></script>

 <style type="text/css">
	 
	 table.dataTable{margin-top: 1rem !important;width: 99% !important;margin: auto}
	 .table tr:last-child td{text-align: left}
	.table tr td:last-child,.table tr th:last-child{text-align: left}
	.table tr:last-child td:last-child{font-weight: 600;text-align: left}
	.table tr:last-child{text-align: center}
	
	.table{border: 1px solid #D7DFF0;border-collapse: collapse;border-style: hidden;border-radius: 10px 10px 0 0;box-shadow: 0 0 0 1px #d7dff0;}
	.table thead th{font-size: 12px;font-weight: bold;color: #6F83AA;letter-spacing: 0.5px;background: #E6EBF7;text-transform: uppercase;padding: 0.8rem;text-align: left}
	.table thead tr th:first-child{border-top-left-radius: 5px}
	.table thead tr th:last-child{border-top-right-radius: 5px}
	.table td, .table th{border-top: 1px solid #D7DFF0;padding: 0.9rem 0.75rem;color: #364159;font-weight: 600;}
	.table td{background: #ffffff;}
	
		
	h3.title{font-size: 12px;text-transform: uppercase;color: #0332AA;letter-spacing: 0.5px;font-weight: bold;}
	 h2{font-size: 12px;text-transform: uppercase;color: #0332AA;letter-spacing: 0.5px;font-weight: bold;}
	 
		
		.dataTables_empty{text-align: center !important}
		.dataTables_wrapper{overflow-x: auto}
	 
	 .card{background: linear-gradient(0deg, #FFFFFF, #FFFFFF), #C4C4C4;box-shadow: 0px 0px 7px rgba(196, 196, 196, 0.35);border-radius: 10px;}
	 
	 .form-group.floating{margin-bottom: 0}
	 
	 p.list-item-heading{color: #6884CC;font-weight: 600;}
	.feetop p.list-item-heading span:last-child{font-weight: 600;font-size: 14px;color: #364159;}
	 
	 .icon-edit{background: url(img/icons/edit3-b.png) no-repeat;width: 15px;height: 16px;display: inline-block;vertical-align: middle}
	 .bookdetails p span:last-child{font-weight: 600;font-size: 14px;line-height: 14px;color: #364159;}
	 .bookdetails p a {font-weight: 600;font-size: 14px;line-height: 20px;color: #0332AA;}

	 
	#issuestatusModal h2{font-size: 14px;text-transform: none;color: #364159;letter-spacing: 0px;font-weight: bold;}
	h5.modal-title p.headtitle{display: inline-block;width: 100%;text-align: center;font-weight: bold;font-size:17px;color: #fff;}
	h5.modal-title p.text-muted{display: inline-block;width: 100%;text-align: center;font-weight: 600;font-size: 14px;line-height: 36px;color: #181E29;line-height: 20px;}
	.modal-title img{display: block;margin: 1em auto}
	#EditbooklimitModal.modal .modal-header,#issuestatusModal.modal .modal-header{padding: 10px 20px !important;border: none}	
	#EditbooklimitModal.modal .modal-body,#issuestatusModal.modal .modal-body{padding:0 1.75rem 1.75rem}
	.modal-body p{text-align: left !important}
	.modal-backdrop.show {opacity: .5 !important;}
	 
	 .profilepic{width: 120px;height: 120px}
	 
	 table.dataTable{margin-top: 2rem !important}
	 .dataTables_filter{right: 0;left: inherit;top: 5px;}
	 .dataTables_filter input{width: 300px}
	 .dataTables_wrapper {top: 25px;padding-top: 3rem}
	 
	 /* Upload files*/	
	
	.btn-primary{background-color: #0332AA;color: #ffffff;border-color: #0332AA;font-weight: 600;}
	.btn-primary:not(:disabled):not(.disabled).active, .btn-primary:not(:disabled):not(.disabled):active, .show>.btn-primary.dropdown-toggle,.btn-primary:hover{background-color: rgba(3,50,170,0.8);}
	
	.btn-outline-primary {color: #0332AA;border-color: #0332AA;font-weight: 600;}
	.btn {border-radius: 5px;outline: initial!important;box-shadow: none!important;box-shadow: initial!important;font-size: .8rem;padding: .5rem 1.25rem .5rem 1.25rem;transition: background-color box-shadow .1s linear;margin-bottom: 0px}
	.btn-outline-primary:not(:disabled):not(.disabled).active, .btn-outline-primary:not(:disabled):not(.disabled):active, .show>.btn-outline-primary.dropdown-toggle,.btn-outline-primary:hover {background-color: #0332AA;border-color: #0332AA;color: #fff;}
	p.alert{font-size: 14px;padding: .45rem 1.25rem;}
	p.alert-danger {color: #721c24;}
	p.alert-success {color: #155724;}
	
	.box {position: relative;background: #ffffff;width: 100%;}
	.box-header {color: #444;display: block;padding: 10px;position: relative;border-bottom: 1px solid #f4f4f4;margin-bottom: 10px;}
	.box-tools {position: absolute;right: 10px;top: 5px;}
	.dropzone-wrapper {background: #F6F7FA;border: 1px dashed #BCCAE8;color: #92b0b3;position: relative;height: 40px;border-radius: 5px;}
	.dropzone-desc {position: absolute;margin: 0 auto;left: 0;right: 0;text-align: center;width: auto;top: 5px;font-size: 16px;}
	.dropzone,
	.dropzone:focus {position: absolute;outline: none !important;width: 100%;height: 40px;cursor: pointer;opacity: 0;}
	.dropzone-wrapper:hover,
	.dropzone-wrapper.dragover {background: #ecf0f5;}
	.preview-zone {text-align: center;}
	.preview-zone .box {box-shadow: none;border-radius: 0;margin-bottom: 0;}
	#filename {margin-top: 10px;margin-bottom: 10px;font-size: 14px;line-height: 2.7em;border: 1px solid #D7DFF0;
    border-radius: 5px;min-height: 40px;margin-top: 2.2rem;}
	.file-preview {background: #ccc;border: 5px solid #fff;box-shadow: 0 0 4px rgba(0, 0, 0, 0.5);display: inline-block;width: 60px;height: 60px;text-align: center;font-size: 14px;margin-top: 5px;}
	.closeBtn:hover {color: red;display:inline-block;}
	
	.icon-upload{background: url("img/icons/upload.png") no-repeat;width: 24px;height: 24px;display: inline-block;vertical-align: middle}
	.dropzone-desc p.list-item-heading{font-size: 14px;font-weight: 600;color: #536485;display: inline-block}
	.dropzone-desc p.text-muted{font-size: 10px;font-weight: normal;color: #6F83AA;}
	.dropzone-desc p.list-item-heading span{color: #db4d4d}
	
	p.alert-info{font-weight: 600;font-size: 14px;color: #355BBB;}
	 
 </style>
 
 <script type="text/javascript">
	 
	 var oTable,oTablehistory = "";
$(document).ready(function(){	
		
	
	$("select").change(function(){
		$(this).attr('value',$(this).val());
	});
		
	oTablehistory = $('#idcardprinttable').dataTable({
                    "bProcessing": true,
                    "sPaginationType": "full_numbers",
                     "oLanguage": {
                        "sProcessing": "<img src='<?php echo base_url(); ?>images/loader.gif'>",
						 "sEmptyTable": "No Batches",
						 "sSearchPlaceholder": "Search Batch",
                    },
                    "columns": [
							{ title: "S.NO" },
							{ title: "PRINT BATCH ID" },
							{ title: "PRINT BATCH NAME" },
							{ title: "BATCH NAME" },							
							{ title: "NUMBER OF STUDENT" },							
							{ title: "PRINTED" },	
						{ title: "NOT PRINTED" },
							{ title: "ACTIONS" }						
						],
                    'iDisplayLength': 20,
                    //"columns": columnData,
                    "order": [[ 0, "asc" ]],
                    "fnDrawCallback": function( oSettings ) {
						
                        var count = 1;
						
                         $('#idcardprinttable').find("tr .sno").each(function(){                           
                            $(this).text(count);
                            count++;
                         });
                                                      
                    }
         }); 
         
      $('.dataTables_filter input').addClass('form-control');     
	
});
</script>

 <main> 
        
        <div class="container-fluid">
                 
    
    		<div class="row mb-3">
				<div class="col-md-8">
					<h1>ID Card Print</h1>
				</div>
				<div class="col-md-2">
					<a href="docs/idcardbatches/idcardbatchestemplate.xls"><button type="button" class="btn btn-outline-primary">Download Template</button></a>
				</div>
				<div class="col-md-2">
					<a href="createbatchprint" title="Create New Print Batch"><button class="btn btn-primary">Create New Print Batch</button></a>
				</div>
			</div> 
			             
                                        
          <div class="issuedetails"> 
          
                          <div class="card col-12 p-3 mb-4">

					 <div class="row align-items-center w-100">
					
					<div class="col-11 justify-content-start">
					
						<div id="drop-zone">
							<div class="dropzone-wrapper">
							  <div class="dropzone-desc" id="clickHere">
								<i class="icon-upload mb-2"></i>
								<p class="list-item-heading mb-1">Upload Batches</p>
							  </div>
							  <input type="file" name="uploadresults[]" id="uploadresults" class="dropzone">
							 
							</div>
							 
						</div>
						 
						 </div>
							 
							 <div class="col-1 justify-content-start text-right pr-0">       				 
                            				 
								<button type="button" class="btn btn-primary importresults">Upload</button>
                            				 
				   			</div>
				   
						 </div>
							 
							 <div class="border-bottom my-4"></div>
						
						
						<div class="row align-items-center w-100">
					
							<div class="col-6 d-flex justify-content-start">
							
								<div class="loader d-none">
									<img src='<?php echo base_url(); ?>images/loader.gif'>
								</div>
								
								 <p class="alert mb-0"></p>   
								 
							</div>
							
							<div class="col-6 justify-content-start text-right pr-0">
								
								<button type="button" class="btn btn-outline-primary cancelresults">Cancel</button>
								<!--<button type="button" class="btn btn-primary d-none approveresults">Approve Results</button>-->
								
							</div>
			   		
							</div> 
				   		
								<!--<div id='filename'><?php //echo $marksheetlist;?></div>-->
							  </div>                
         
          <div class="card p-4 mt-4">
                                                                                                              
                <table id="idcardprinttable" class="sortable table" style="width:100%"></table>    
                                 		           
			</div>
     
      
			</div>
             
 </div>
 
 </main>

	<div id="resultmessage" class="my-4"></div>
	
<script type="text/javascript">
	
$(document).ready(function() {
   
	$("select").change(function(){
		$(this).attr('value',$(this).val());
	});
				
	loadresults(oTablehistory);
	
	
	$("#uploadresults").change(function(){
		
		var filename = $(this).val().replace(/C:\\fakepath\\/i, '');
		
		if(filename!=""){
			$(".alert").removeClass('alert-danger alert-success').addClass('alert-info').text(filename);
			$(".cancelresults").removeClass('d-none');
		}else{
			$(".cancelresults").addClass('d-none');
		}
		
	});
	
	
	 $(".importresults").click(function(){
		  
		 var uploadfile = $("#uploadresults").val();
		 var bname = "<?php echo $_GET['bname']; ?>";
		 
		 if(uploadfile==""){
			 $(".alert").removeClass('alert-success alert-info').addClass('alert-danger').text("Upload batches file");
			 return;
		 }		 
		 
		if($(".importresults").hasClass('process')){
			
			$(".alert").removeClass('alert-success alert-info').addClass('alert-danger').text("Please wait while uploading...");
			
		}else{
		
			$(".importresults").addClass('process');
			$(".alert").removeClass('alert-danger alert-info').addClass('alert-success').text("Uploading batches...");
			
			$(".loader").removeClass('d-none');
         		 
		 var formData = new FormData();
		 
		 var c=0;
		 var file_data,file;
		 $('input[type="file"]').each(function(){
			  file_data = $('input[type="file"]')[c].files; // get multiple files from input file
			  //console.log(file_data);
		   for(var i = 0;i<file_data.length;i++){
			   formData.append('file[]', file_data[i]); // we can put more than 1 image file
		   }
		  c++;
	    }); 
			
			formData.append('bname', '');
		 
		 $.ajax({
                type: 'POST',
                url: 'idcardprint/uploadBatchprint',
                data: formData,
			    contentType: false,
    			processData: false,
                success: function(response) {
                   
					var obj1 = $.parseJSON(response);
							
					$(".loader").addClass('d-none');
					
					if(obj1['status']=="success"){
						
						$(".alert").addClass('alert-success').text("Batches uploaded successfully.");
						
						$("#resultmessage").html(obj1['message']);
						
						if(obj1['exceldata']!=""){
							
							window.open("idcardprint/downloadexcel","_blank");
						}
						
						//dataSet = obj1['tabledata'];
						
						$("#uploadresults").val('');
						$(".importresults").removeClass('process');
						//$(".approveresults").removeClass('d-none');
																								
						setTimeout(function(){
							loadresults(oTablehistory);
							$(".alert").removeClass('alert-success').text("");
						},3000);
						
					}else if(obj1['status']=="empty"){
						$(".importresults").removeClass('process');
						$(".alert").removeClass('alert-success').addClass('alert-danger').text("Upload batches file");
					}else if(obj1['status']=="ufail"){
						$(".importresults").removeClass('process');
						$(".alert").removeClass('alert-success').addClass('alert-danger').text("Upload failed");
					}else if(obj1['status']=="exfail"){
						$(".importresults").removeClass('process');
						$(".alert").removeClass('alert-success').addClass('alert-danger').text("Support extension XLS only");
					}else if(obj1['status']==""){
						$(".importresults").removeClass('process');
						$(".alert").removeClass('alert-success').addClass('alert-danger').text("Please try again.");
					}
					
                }

            });
			
		}
		
		   
	 }); 
	
	
	$('.cancelresults').click(function(){
		
		$("#uploadresults").val('');
		$(".loader,.updateloader").addClass('d-none');
		$(".alert").removeClass('alert-success alert-danger alert-info').text("");
		$("#resultmessage").html("");
		
	});
    		
	$(document).on('focus click','input,select,textarea', function () {
	  	$(".alert").removeClass("alert-success alert-danger").html('');
	});		
           
});
	
	
	
	function loadresults(oTablehistory){
	
	$.ajax({
                type: 'POST',
                url: 'idcardprint/GetIDCardPrintList',
                data: {},
                success: function(response) {
                   
					var obj1 = $.parseJSON(response);
					
					if(obj1['tabledata'].length>0){
						
						oTablehistory.fnClearTable();
						oTablehistory.fnAddData(obj1['tabledata']);
						oTablehistory.fnDraw();
												
					}
					
				}
		
	});

}
		
</script>
    
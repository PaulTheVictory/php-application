<link rel="stylesheet" href="<?php echo base_url();?>css/vendor/dataTables.bootstrap4.min.css">
<link rel="stylesheet" href="<?php echo base_url();?>css/vendor/datatables.responsive.bootstrap4.min.css">
<script src="<?php echo base_url();?>js/vendor/datatables.min.js"></script>

<style>
		
	.regcourses h1{font-size: 18px;color: #364159;}
	.regcourses .card,.courseinfo .card{background: linear-gradient(0deg, #FFFFFF, #FFFFFF), #C4C4C4;box-shadow: 0px 0px 7px rgba(196, 196, 196, 0.35);border-radius: 10px;}
	.regcourses h2{color: #0332AA;font-size: 24px;font-weight: bold;line-height: 36px;}
	.regcourses p.list-item-heading{color: #6884CC;font-weight: 600;}
	.regcourses p.list-item-heading span:last-child{font-weight: 600;font-size: 14px;color: #364159;}
	
	.regcourses .crstatus-approved,.regcourses .crstatus-waitlisted,.regcourses .crstatus-pending,.regcourses .crstatus-rejected{font-size: 12px !important;color: #ffffff !important;border-radius: 20px;text-transform: capitalize;text-align: center;}
	.crstatus-approved{ background: #3CAF92;}
	.crstatus-waitlisted{background: #f48d25;}
	.crstatus-pending{background: #b06315;}
	.crstatus-rejected{background: #ED5252;}
	
	.regcourses .card:after{content: " ";color: #fff;position: absolute;width: 10px;height: 100%;top: 50%;transform: translateY(-50%);left: 0;border-top-left-radius: 10px;border-bottom-left-radius: 10px;}
	.regcourses.approved .card:after{background: #3CAF92;}
	.regcourses.waitlisted .card:after{background: #f48d25;}
	.regcourses.pending .card:after{background: #b06315;}
	.regcourses.rejected .card:after{background: #ED5252;}
	
	
	.border-right{border-right: 1px solid #D7DFF0!important;}
		
	.btn-primary{width: auto}
	.btn-primary.disabled, .btn-primary:disabled{background: #9AADDD;color: #ffffff;}
	
	.card h5{margin-bottom: 1rem;}
	h5{font-weight: bold;}
	.badge-outline-secondary, .badge-outline-theme-2{border: 1px solid #889DC6;color: #889DC6;background: #F6F7FA;}
	.badge{font-size: 12px;margin-right: 5px}
	
	.courseinfo .col-right .card .card-body{padding: 0;}
	.courseinfo .border-bottom{border-bottom: 1px solid #D7DFF0!important;}
	.col-right h5{padding: 1.2rem}
 
	.icon-status{background: url("img/icons/status-b.png") no-repeat;width: 15px;height: 15px;display: inline-block;vertical-align: middle}
	.icon-check-circle{background: url("img/icons/check-circle-b.png") no-repeat;width: 15px;height: 15px;display: inline-block;vertical-align: middle}
	.icon-send{background: url("img/icons/send-b.png") no-repeat;width: 15px;height: 15px;display: inline-block;vertical-align: middle;margin-right: 5px}
	.icon-map-pin{background: url("img/icons/map-pin-b.png") no-repeat;width: 15px;height: 15px;display: inline-block;vertical-align: middle;margin-right: 5px}
	.icon-invoice{background: url("img/icons/invoice-b.png") no-repeat;width: 15px;height: 15px;display: inline-block;vertical-align: middle;margin-right: 5px}
	
	p.totalfee {font-weight: bold;font-size: 24px;color: #D63333;}
	
</style>


<main>

	<div class="container-fluid">

		<div class="row">
		  <div class="col-12">

			  <div class="row">
			   
			   	  <div class="col-md-9">
			   		<h1>Registered Test</h1>
				  </div>
				  <div class="col-md-3">
					 <div class="form-group">
						<select class="form-control schedule" name="schedule" >
						  <option value="">Sort By</option>
						  <option value="date">Date</option>
						  <option value="status">Status</option>
						</select>
					 </div>
				  </div>
			   
			   </div>

			   <div class="mb-3"></div>

		</div>

		</div>
		
		<?php 
		
			if(!empty($regcourses)){
				
			foreach($regcourses as $courseslist){
				
				$ide = $courseslist['ide'];
				$requestdate = date("d M Y",strtotime($courseslist['requested_at']));
				$approvedate = date("d M Y",strtotime($courseslist['approved_date']));
				
				$admissiontime = date('M Y',strtotime($courseslist['starts_on'])).' - '. date('M Y',strtotime($courseslist['ends_on']));
				
				$center = $courseslist['center'];
				
				$status = $courseslist['approved'];
				$scenter = $courseslist['scenter'];
				$courseid = $courseslist['courseid'];
				$st_status = $courseslist['st_status'];
				
				$crstatusclass = "";
				$crstatus = "";
				$btnstatus = "";
				
				if($status=="y"){
					
					$crstatus = "Approved";
					$crstatusclass = "approved";
					$btnstatus = "";
					
				}else if($status=="w"){
					
					$crstatus = "Waiting List";
					$crstatusclass = "waitlisted";
					$btnstatus = "disabled";
					
				}else if($status=="n"){
					
					$crstatus = "Not Qualified";
					$crstatusclass = "rejected";
					$btnstatus = "disabled";
					
				}else if($status=="q"){
					
					$crstatus = "Waiting For Approval";
					$crstatusclass = "pending";
					$btnstatus = "disabled";
					
				}else if($status=="d"){
					
					$crstatus = "Rejected";
					$crstatusclass = "rejected";
					$btnstatus = "disabled";
					
				}else{
					$btnstatus = "disabled";
				}
				
				$screentest = $courseslist['screentest'];
				
				if($screentest=="1")$regbtn = "stufeepayments?id=".$ide; else $regbtn = "stumyprofile?action=register&id=".$ide;
		
		?>
	
		<div class="row regcourses <?php echo $crstatusclass;?>" id="<?php echo $ide; ?>">

			<div class="col-12 mb-4">
				<div class="card">
					<div class="card-body">

						<div class="row">

							<div class="col-md-12 col-sm-12 col-lg-9 col-12">
								
								<h1 class="mb-2"><?php echo $courseslist['coursename']; ?></h1>

								<div class="row mb-3">

									<div class="col-md-4 col-sm-4 text-left px-2">
										<p class="list-item-heading mb-1"><i class="icon-send"></i> <span>Requested Date:</span> <span><?php echo $requestdate; ?></span></p>
									</div>

									<div class="col-md-4 col-sm-4 text-left px-2">
										<p class="list-item-heading mb-1"><i class="icon-check-circle"></i> <span>Approved Date:</span> <span><?php echo $approvedate; ?></span></p>
									</div>

									<div class="col-md-4 col-sm-4 text-left px-2">
										<p class="list-item-heading mb-1"><i class="icon-status"></i> <span>Status:</span> <span class="crstatus-<?php echo $crstatusclass;?> px-3 py-2"><?php echo $crstatus;?></span></p>
									</div>

								</div>
								
								<div class="row">

									<div class="col-md-4 col-sm-4 text-left px-2">
										<p class="list-item-heading mb-1"><i class="icon-map-pin"></i> <span>Test Centre:</span> <span class="testcenter">
										<?php if($scenter=="" && $status=="y" && $st_status=="1"){ ?>
											<button class="btn btn-primary issuecenter" type="button" data-courseid="<?php echo $courseid;?>" data-center="<?php echo $center;?>" data-ide="<?php echo $ide;?>">Select Center</button>
										<?php }else{ echo $scenter;} ?>
										</span></p>
									</div>

									<div class="col-md-6 col-sm-6 text-left px-2">
										<p class="list-item-heading mb-1"><i class="icon-invoice"></i> <span>Admission Time:</span> <span><?php echo $admissiontime; ?></span></p>
									</div>

								</div>

							</div>

							<div class="col-md-12 col-sm-12 col-lg-3 col-12 d-flex align-items-center justify-content-end">
								
								<div class="row w-100">

									<div class="col-md-11 text-right">
										<a href="<?php echo base_url();?><?php echo $regbtn;?>" title="Know More"><button class="btn btn-primary" type="button" <?php echo $btnstatus;?>>Know More</button></a>
									</div>

								</div>
						
							</div>

						</div>


					</div>

				</div>
			</div>
		</div>
		
		<?php }}else{?>
		
		<div class="row regcourses">

			<div class="col-12 mb-4">
				<div class="card">
					<div class="card-body">
					
						<p class="text-muted text-center mb-0">No Registered Test Found.</p>
					
				</div>
			</div>
		</div>
		
		<?php }?>

	</div>


	</div>
</main>


<!--  Select Center  -->
<style>

	#newimportModal1.modal .modal-header{padding: 5px 10px !important;border: none}	
	#newimportModal1.modal .modal-body{padding:0 1.75rem 1.75rem}
	#newimportModal1 h2{line-height: 24px;}


</style>
    
<div id="newimportModal1" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
		<div class="modal-dialog modal-dialog-centered" role="document">
			<div class="modal-content">
				<div class="modal-header">
				   <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				</div>
				<div class="modal-body text-center " >
					<h2 class="mb-4 mt-0 text-center">Select Center</h2>				
                      <select class="form-control hcenter floating" id="hcenter" required  >
							
					  </select>	
			 
			 	<input type="hidden" name="icide" id="icide" value="" />
				<input type="hidden" name="iccenter" id="iccenter" value="" />
				<input type="hidden" name="iccourseid" id="iccourseid" value="" />												
													
										
				</div>
				<div class="modal-footer">
				
					<p class="alert mb-0"></p>
					
					<button type="button" class="btn btn-primary hsave">Save</button>
					<button type="button" class="btn btn-outline-primary modalclose" data-dismiss="modal">Close</button>
				</div>
								
			</div>
		</div>
	</div>

<!-- End  Select Center  -->


<script type="text/javascript">
	
$(document).ready(function(){
	
	$(".issuecenter").click(function(){
            		
		var ide = $(this).data("ide");
		var city = $(this).data("center");
		var courseid = $(this).data("courseid");
		
		if(city=="") { alert("No center"); return false;}
		
		$.post('sturegtests/getIssueCenters',{
			   'city': city,"courseid":courseid

		}, function(o) { 
				 var obj1 = $.parseJSON(o);
				 if (obj1["centers"] != '') {
					 
					 $("#icide").val(ide);
					 $("#iccenter").val(city);
		   			 $("#iccourseid").val(courseid);
					 
					 $('#newimportModal1').modal({show:true});
					 $(".hcenter").html('<option value="">----------</option>'+obj1["centers"]);

				 } else{
					 alert("Error!!! please try again");
			 	 }

		 });

	});
	
	$(".hsave").click(function(){
		
             $(".hsave").text("Progressing...");
             if($(".hsave").hasClass("progress")){
                 alert("Please wait, Existing process is progresing...");return;
             }
             
             $(".hsave").addClass("progress");
		
         	var ide =''; var type = ''; var center = "";
           $(".crequest").each(function(){
               
               if($(this).is(":checked")) { ide += $(this).val()+"|";}
                
           });
           
		   ide = $("#icide").val();
           center = $("#hcenter").val();
		   var city = $("#iccenter").val();
		   var courseid = $("#iccourseid").val();
         
          if(ide === '') { alert('select any request to allocate center'); return;}
            $.get('sturegtests/STIssueCenter',{
                       'ide':ide,'type':type,'center':center,'city': city,'courseid': courseid

				}, function(o) {
				
					 var obj1 = $.parseJSON(o);
					 $(".hsave").removeClass("progress").text("Save");
				
					 if (obj1[0] === 'success') {
						 
						$("#"+ide).find(".issuecenter").parent().html(center);

						var r = confirm("Success!!! Center Allocated.");			
						if(r){
						   $('#newimportModal1').modal('hide'); 
						}

					 } else if (obj1[0] === 'fail') {
							 alert("Error!!! please try again");
					 }else if (obj1[0] === 'novacant') {
						 var r =confirm("Error!!! Seats are filled in this center");
						 if(r){
						   $('#newimportModal1').modal('hide'); 
						 }
					 }
				
				 });
         
         });
	
	$('#newimportModal').on('hidden.bs.modal', function () {
  		
		$(".loader,.updateloader").addClass('d-none');
		$(".alert").removeClass('alert-success alert-danger').text("");
		$("#importmessage").html("");
		$(".importtemplate").removeClass('process');
		$(".hcenter").html('<option value="">----------</option>');
		
	});
	
});
	
</script>
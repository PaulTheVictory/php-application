<main>

  <div class="container">

    <div class="row">

      <div class="col-12 mx-auto my-auto">

        <div class="card auth-card login">         

          

          <div class="position-relative image-side"></div>

          

          <div class="form-side login-form">

         

            <h3 class="mb-1">Welcome Back!</h3>

            <h6 class="mb-4">Login with your student ID</h6>

            <?php echo validation_errors(); ?>



   			<?php echo form_open('verifylogin'); ?>

             <div class="form-group position-relative floating">

				 <input class="form-control" id="username" name="username" tabindex="1" placeholder=" " >
             
				 <label>Student ID <span>*</span></label>

             </div>

              <div class="form-group position-relative floating">

				 <input class="form-control" type="password" id="passowrd" name="password"  tabindex="2" placeholder=" " > 
             
             	<label>Password <span>*</span></label>

             </div>

             

              <div class="d-flex justify-content-end align-items-end forgetpass mb-3">

               <a href="<?php echo base_url();?>forgotpassword">Forget your password?</a>

              </div>

              

              <button class="btn btn-primary btn-lg btn-shadow" type="submit">LOGIN</button>

                            

            </form>

            

             <p class="text-muted text-center">Don't have an account? <a href="<?php echo base_url();?>signup" title="Sign up">Sign up</a></p>

            

          </div>

      

        </div>

      </div>

    </div>

  </div>

</main>


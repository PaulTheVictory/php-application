<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Brilliant Pala</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">


<link rel="stylesheet" type="text/css" href="<?php echo $this->config->item('web_url') ?>css/styles.css?v=1.5" />
<link rel="stylesheet" type="text/css" href="<?php echo $this->config->item('web_url') ?>css/styles-media.css?v=1.3" />
<link rel="stylesheet" type="text/css" href="<?php echo $this->config->item('web_url') ?>css/menu.css?v=1.5" />
<link rel="stylesheet" type="text/css" href="<?php echo $this->config->item('web_url') ?>css/mobilemenu.css" />


<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/commonstyle.css?v=1.7" />

<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/jquery.datetimepicker.css" />


<script type="text/javascript" src="<?php echo $this->config->item('web_url') ?>js/jquery.js"></script>
<script src="<?php echo $this->config->item('web_url') ?>js/menu.js?v=1.5" type="text/javascript"></script>
<script src="<?php echo $this->config->item('web_url') ?>js/modernizr.custom.js" type="text/javascript"></script>



<script src="<?php echo base_url(); ?>js/jquery.datetimepicker.js" type="text/javascript"></script>


<script>
var baseurl = "<?php echo base_url(); ?>";
</script>
<?php $session = 'set'; if($session !== 'unset') { ?>
<script>
/*ddsmoothmenu.init({
mainmenuid: "menu", //menu DIV id
orientation: 'h', //Horizontal or vertical menu: Set to "h" or "v"
classname: 'headermenu', //class added to menu's outer DIV
customtheme: ["#ffffff", "#004080"],
contentsource: "markup" //"markup" or ["container_id", "path_to_menu_file"]
}); */
</script>
<?php } ?>
<script type="text/javascript">
$(document).ready(function(){
	$('.datepicker').datetimepicker({
		timepicker:false,
		format:'d-m-Y'
	});
        
        var interval_id;
        
        $(window).load(function() {
                interval_id = setInterval(checkSessionExist, 5000);
        });
        
        $(window).focus(function() {
            if (!interval_id)
                interval_id = setInterval(checkSessionExist, 5000);
        });

        $(window).blur(function() {
            clearInterval(interval_id);
            interval_id = 0;
        });

        function checkSessionExist(){
         $.get( "verifylogin/checkSession", function( data ) {
           if(data !== "active"){
             clearInterval(interval_id);
             alert("Your Session has Expired. Please Login to continue !!");
             location.reload();
           }
        });
        }
});
</script>

<style>
	
.sidebar-navigation {
  width: auto;
  height: auto;
  background-color: #fff;
  margin: 1rem auto;
}
.sidebar-navigation .title {
  display: block;
  font-size: 1.2em;
  background-color: #1e1e1e;
  padding: 20px 25px;
  color: #fff;
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 0.1em;
}
.sidebar-navigation > ul > li > a {
  text-transform: normal;
}
.sidebar-navigation ul {
  margin: 0;
  padding: 0;
	background: #fff;
}
.sidebar-navigation ul li {
  display: block;
}
.sidebar-navigation ul li a {
  position: relative;
  display: block;
  font-size: 1em;
  font-weight: 600;
  padding: 20px 25px;
  text-decoration: none;
  color: #2e2e2e;
  letter-spacing: 0.02em;
  border-bottom: 1px solid #eee;
  -webkit-transition: all 0.3s linear;
  -moz-transition: all 0.3s linear;
  -o-transition: all 0.3s linear;
  transition: all 0.3s linear;
}
.sidebar-navigation ul li a em {
  font-size: 18px;
  position: absolute;
  right: 15px;
  top: 50%;
  transform: translateY(-50%);
  padding: 5px 0;
  border-radius: 50%;
	font-style: normal;
}
.sidebar-navigation ul li a em:before{
content: "+";
  font-size: 18px;
  position: absolute;
  right: 0px;
  top: 50%;
  transform: translateY(-50%);
  padding: 5px 0;
  border-radius: 50%;
  font-style: normal;
	
}			
.sidebar-navigation ul li a em.mdi-chevron-down:before{
content: "+";	
}		
.sidebar-navigation ul li a em.minus:before{
content: "-";right: 3px;
}
.sidebar-navigation ul li:hover > a, .sidebar-navigation ul li.selected > a {
  background-color: #ecf0f1;
  color: #495d62;
  border-color: rgba(255, 255, 255, 0.1);
}
.sidebar-navigation ul li ul {
  display: none;
}
.sidebar-navigation ul li ul.open {
  display: block;
}
.sidebar-navigation ul li ul li a {
  color: #495d62;
  border-color: rgba(255, 255, 255, 0.1);
}
.sidebar-navigation ul li ul li a:before {
  content: "";
  width: 1px;
  height: 100%;
  margin-right: 5px;
  display: inline-block;
  vertical-align: middle;
  background-color: #6F83AA;
  -webkit-transition: all 0.2s linear;
  -moz-transition: all 0.2s linear;
  -o-transition: all 0.2s linear;
  transition: all 0.2s linear;
}
.sidebar-navigation ul li ul li:hover > a, .sidebar-navigation ul li ul li.selected > a {
  background-color: #e6ebed;
}
.sidebar-navigation ul li ul li:hover > a:before, .sidebar-navigation ul li ul li.selected > a:before {
  margin-right: 10px;
}
.sidebar-navigation ul li ul li.selected.selected--last > a {
  background-color: #94aab0;
  color: #fff;
}
.sidebar-navigation ul li ul li.selected.selected--last > a:before {
  background-color: #fff;
}

.subMenuColor1 {
  background-color: #fbfcfc;
}

.subMenuColor2 {
  background-color: white;
}

.subMenuColor2 {
  background-color: white;
}

.subMenuColor2 {
  background-color: white;
}

.subMenuColor2 {
  background-color: white;
}

.subMenuColor2 {
  background-color: white;
}

.subMenuColor2 {
  background-color: white;
}

.subMenuColor2 {
  background-color: white;
}

.subMenuColor2 {
  background-color: white;
}

.subMenuColor2 {
  background-color: white;
}
	
	
.sidebar-navigation ul li a {height: 50px;display: flex;flex-direction: row;justify-content: start;align-items: center;font-size: 16px;font-style: normal;font-weight: bold;border-bottom: 0px solid #f3f3f3;color: #4F70C4;transition: color .3s;transition: background .3s;padding: 0 1em;border-radius: 10px;margin: 1em 0.5em;}	
.sidebar-navigation ul li > ul li a{height: 45px}
.sidebar-navigation ul li > ul li.active a span{color: #03257D;background: #E6EBF7;}
.sidebar-navigation ul li > ul li.active a{background: none;}
.sidebar-navigation ul li > ul li a{margin: 0 auto}
.sidebar-navigation ul  li > ul li a:focus, .sidebar-navigation ul  li > ul li a:hover{background: none;}
.sidebar-navigation ul  li > ul li a, .sidebar-navigation ul  li > ul li a{padding-left: 26px !important;}
.sidebar-navigation ul  li > ul li a span, .sidebar-navigation ul  li > ul li a span{height: 34px;width: 100%;display: flex;flex-direction: row;justify-content: start;align-items: center;font-size: 16px;font-style: normal;font-weight: bold;border-bottom: 0px solid #f3f3f3;color: #4F70C4;transition: color .3s;transition: background .3s;padding: 0 0.6em;border-radius: 10px;margin: 0em 0em;}
.sidebar-navigation ul  li > ul li a:focus span, .sidebar-navigation ul  li > ul li a:hover span{color: #03257D;background: #E6EBF7;}
	
.sidebar-navigation ul li.active a { color: #ffffff;background: #0332AA;}
.sidebar-navigation ul li a:focus, .sidebar-navigation ul li a:hover {color: #ffffff;background: #0332AA;}
	
.sidebar-navigation ul li i {font-size: 32px;line-height: 42px;width: 24px;height: 24px;display: inline-block;vertical-align: middle;}	
.sidebar-navigation ul li span {text-align: center;padding: 0 10px;line-height: 24px;}
	
.sidebar-navigation ul li a:focus i, .sidebar-navigation ul li a:hover i,.sidebar-navigation ul li.active a i { filter: contrast(0) brightness(2);}
	
.icons-credit-card-1 { background: url(img/icons/credit-card-1.png) no-repeat;}
.icons-list {background: url(img/icons/list.png) no-repeat;}	
	
.icons-students {background: url(images/students.png) no-repeat;}
.icons-admissions {background: url(images/courses.png) no-repeat;}
.icons-accounts {background: url(images/payments.png) no-repeat;}
.icons-tests {background: url(images/tests.png) no-repeat;}	
.icons-list {background: url(img/icons/list.png) no-repeat;}	
.icons-review {background: url(images/review.png) no-repeat;}	
i.icons-settings {background: url(img/icons/settings.png) no-repeat;}	
i.icons-logout {background: url(images/logout.png) no-repeat;}
	
.sidebar-navigation ul li a.last {color: #DB4D4D;}
.sidebar-navigation ul li a.last:hover { color: #ffffff; background: #DB4D4D;}
	
.navbar .user .name{display: inline-block;vertical-align: middle;text-align: left;overflow: hidden; text-overflow: ellipsis; max-width: 135px; white-space: nowrap;font-size: 14px;font-family: 'Segoe UI';}
.navbar .user .stuid{display: block;font-size: 14px;line-height: 12px;font-family: 'Segoe UI';}

.headermenu ul li a{float: none}
	 
.headermenu ul li a.mlist1 {background: url('<?php echo $this->config->item('web_url') ?>/images/grid.png') #fff no-repeat;background-position: 8px 16px;}

.headermenu ul li a.mlist1:hover {background: url('<?php echo $this->config->item('web_url') ?>/images/grid.png') #0332AA no-repeat;background-position: 8px 16px;}

.headermenu ul li a.mlist2 {background: url('<?php echo $this->config->item('web_url') ?>/images/user.png') #fff no-repeat;background-position: 8px 16px;}

.headermenu ul li a.mlist2:hover {background: url('<?php echo $this->config->item('web_url') ?>/images/user.png') #0332AA no-repeat;background-position: 8px 16px;}
	 
.headermenu ul li a.mlist3 {background: url('images/courses.png') #fff no-repeat;background-position: 8px 16px;}

.headermenu ul li a.mlist3:hover {background: url('images/courses1.png') #0332AA no-repeat;background-position: 8px 16px;}

.headermenu ul li a.mlist4 {background: url('<?php echo $this->config->item('web_url') ?>/images/review.png') #fff no-repeat;background-position: 9px 16px;}

.headermenu ul li a.mlist4:hover {background: url('<?php echo $this->config->item('web_url') ?>/images/qualification.png') #0332AA no-repeat;background-position: 9px 16px;}

.headermenu ul li a.mlist5 {background: url('<?php echo $this->config->item('web_url') ?>/img/icons/list.png') #fff no-repeat;background-position: 8px 15px;}
	 
.headermenu ul li a.mlist5:hover {background: url('<?php echo $this->config->item('web_url') ?>/images/results.png') #0332AA no-repeat;background-position: 8px 15px;}
	
.user{float: right}
.user .name {display: inline-block;vertical-align: middle;text-align: left;overflow: hidden;text-overflow: ellipsis;max-width: 170px;white-space: nowrap;font-size: 14px;font-family: 'Segoe UI';color: #364159;line-height: 20px;text-transform: none}
.btn {display: inline-block;font-weight: 600 !important;color: #212529;text-align: center;vertical-align: middle;-webkit-user-select: none;-moz-user-select: none;-ms-user-select: none;user-select: none;background-color: transparent;border: 1px solid transparent;padding: .375rem .75rem;font-size: 1rem;line-height: 1.5;border-radius: .25rem;-webkit-transition: color .15s ease-in-out,background-color .15s ease-in-out,border-color .15s ease-in-out,-webkit-box-shadow .15s ease-in-out;transition: color .15s ease-in-out,background-color .15s ease-in-out,border-color .15s ease-in-out,-webkit-box-shadow .15s ease-in-out;transition: color .15s ease-in-out,background-color .15s ease-in-out,border-color .15s ease-in-out,box-shadow .15s ease-in-out;transition: color .15s ease-in-out,background-color .15s ease-in-out,border-color .15s ease-in-out,box-shadow .15s ease-in-out,-webkit-box-shadow .15s ease-in-out;}
.user img {margin-right: 10px;border-radius: 30px;width: 40px;height: 40px;vertical-align: middle;border-style: none;}
.user .stuid {display: block;font-size: 12px;line-height: 20px;font-family: 'Segoe UI';}
.d-inline-block {display: inline-block!important;}
		
</style>
	
	<script>
	
		$(function(){
  var $ul   =   $('.sidebar-navigation > ul');
  
  $ul.find('li a').click(function(e){
    var $li = $(this).parent();
    
    if($li.find('ul').length > 0){
      e.preventDefault();
      
      if($li.hasClass('selected')){
        $li.removeClass('selected').find('li').removeClass('selected');
        $li.find('ul').slideUp(400);
        $li.find('a em').removeClass('minus');
      }else{
        
        if($li.parents('li.selected').length == 0){
          $ul.find('li').removeClass('selected');
          $ul.find('ul').slideUp(400);
          $ul.find('li a em').removeClass('minus');
        }else{
          $li.parent().find('li').removeClass('selected');
          $li.parent().find('> li ul').slideUp(400);
          $li.parent().find('> li a em').removeClass('minus');
        }
        
        $li.addClass('selected');
        $li.find('>ul').slideDown(400);
        $li.find('>a>em').addClass('minus');
      }
    }
  });
  
  
  $('.sidebar-navigation > ul ul').each(function(i){
    if($(this).find('>li>ul').length > 0){
      var paddingLeft = $(this).parent().parent().find('>li>a').css('padding-left');
      var pIntPLeft   = parseInt(paddingLeft);
      var result      = pIntPLeft + 20;
      
      $(this).find('>li>a').css('padding-left',result);
    }else{
      var paddingLeft = $(this).parent().parent().find('>li>a').css('padding-left');
      var pIntPLeft   = parseInt(paddingLeft);
      var result      = pIntPLeft + 20;
      
      $(this).find('>li>a').css('padding-left',result).parent().addClass('selected--last');
    }
  });
  
  var t = ' li > ul ';
  for(var i=1;i<=10;i++){
    $('.sidebar-navigation > ul > ' + t.repeat(i)).addClass('subMenuColor' + i);
  }
  
  var activeLi = $('li.selected');
  if(activeLi.length){
    opener(activeLi);
  }
  
  function opener(li){
    var ul = li.closest('ul');
    if(ul.length){
      
        li.addClass('selected');
        ul.addClass('open');
        li.find('>a>em').addClass('minus');
      
      if(ul.closest('li').length){
        opener(ul.closest('li'));
      }else{
        return false;
      }
      
    }
  }
  
});
		
	</script>

</head>

<body>

    <div id="headertop" style="height: 95px;">
    
    <div class="wrap" style="padding-top: 25px;padding-bottom: 25px;padding-left: 15px;">
    
        
<img src="./images/logo.png" style="margin-top: 0px; float: left;">
         <?php if($session !== 'unset') { ?>
        <div id="mobilemenu" class="dl-menuwrapper">
            <button class="dl-trigger"><img src="<?php echo $this->config->item('web_url') ?>images/nav.png" alt="Navigation" /></button>
            <ul class="dl-menu">
            
                <?php echo $menu; ?>
             
            </ul>
        </div><?php } ?>
        
        
        <div class="user d-inline-block">
		  <button class="btn btn-empty p-0" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"	
		  	  <span><img alt="Profile Picture" src="<?php if($user['profilepic']!="0" && $user['profilepic']!=""){ echo "docs/profilepic/".$user['id']."/".$user['profilepic']."?".time();}else{echo "img/profilepic.png?".time();} ?>"></span>
		  	  <span class="name" title="<?php echo ucwords($user['pname']); ?>"><?php echo ucwords($user['pname']); ?> <span class="stuid"><?php echo $user['name']; ?></span></span>  
      	 </button>
		<!--  <div class="dropdown-menu dropdown-menu-right mt-3">
		  	<a class="dropdown-item" href="<?php //echo base_url();?>stumyprofile">My Profile</a>
			<a class="dropdown-item" href="<?php //echo base_url();?>logout">Log out</a>
		  </div>-->
    </div>
       
        <div class="clear"></div>
        
    </div>

</div>
    <?php if($session !== 'unset') { ?>
    <div class="maincontent"  style="min-width: 1200px;margin-top: 5px;">
    
    
    <div class="mwidth" style="position: relative;float: left;background: linear-gradient(0deg, #FFFFFF, #FFFFFF), #C4C4C4;min-width: 180px;min-height: 1055px;">
        <div id="menu" class="sidebar-navigation">
        
            <ul>
                
                <?php echo $menu; ?>
                                    
            </ul>
        
        </div>
        
    </div>
    <?php } ?>
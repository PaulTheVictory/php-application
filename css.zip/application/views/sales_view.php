<div id="pagetitle">

	<div class="wrap">
    
    	<h1>Sales List</h1>
        
	</div>
    
</div>
<style type="text/css">


.dataTables_wrapper input[type="text"] {
    padding: 0;
}
.dataTables_wrapper select {
    padding: 0;
}
.sortable tr th {
    border-right: 1px solid #ddd;
    padding: 10px 0;font-size: 13px;
}
.sortable tr td {
    border-right: 1px solid #ddd;
    padding: 15px 5px;
    text-align: center;font-size: 13px;
}
.sortable tr td a {
    color: #333;
}

#profile-right h2 {
    margin: 0px 0px 10px 0px;
}

.assettable_length { width: auto !important; }
#assettable_filter input { border: 1px solid #ccc; line-height: 25px;margin-left: 10px;}
.sortable tr td a:hover { text-decoration: underline; }

.sortable tr td:first-child{
    width: 10%;
}
</style>
<script type="text/javascript">
$(document).ready(function(){	
		
	
          var columnData = [
              { "data": "bill_no" },
                     { "data": "date" },
                    
                     { "data": "name" },
                      { "data": "mobile" },
                      
                       { "data": "grand" }
                  ];
         columnData.push( {data: "paid"} );
         columnData.push( {data: "ide","visible":true} );
         
       
        var oTable = $('#assettable').dataTable({
                    "bProcessing": true,
                    "bServerSide": true,
                    "sPaginationType": "full_numbers",
                    "aaSorting": [[ 0, "desc" ]],
                    "ajax": {
                    "url": 'sales/getSales',
                    "type": "POST",
                    "data" : { "type" : '<?php  $type= isset($_GET['type'])?$_GET['type']:''; echo $type;?>' }
                     }, 
                     "oLanguage": {
                        "sProcessing": "<img src='<?php echo base_url(); ?>images/loader.gif'>"
                    },
                    'iDisplayLength': 10,
                    "columns": columnData,
                    "fnDrawCallback": function( oSettings ) {
                            $("#assettable").find(".del").each(function(){

                            $(this).click(function(){ 

                              if(confirm("Are you sure to delete this invoice ?")) {
                                    var ide = $(this).attr("id");
                                    $.get('sales/delSales',{
                                                               'ide':ide

                                                    }, function(o) { 
                                                            var obj1 = $.parseJSON(o);
                                                    if (obj1[0] === 'success') {
                                                        oTable.fnDraw(); 
                                                    } else if (obj1[0] === 'fail') {
                                                        alert("Error!!! please try again");
                                                    }else  {
                                                            alert(obj1[0]);
                                                    }
                                    });
                                }

                              });
                        

                          });
                    }
         }); 
         

	
	
           
            
	
});
</script>
<div class="maincontent">
   <?php 
        $type= isset($_GET['type'])?$_GET['type']:''; 
        $eststyle = "";$billstyle = "";
        if($type === "est") {
            $eststyle = "border-bottom: 2px solid;";
        } else if($type === "bill"){
            $billstyle = "border-bottom: 2px solid;";
        }
   ?>
    <div class="wrap" style="max-width: 960px;margin-top: 20px">
        <a style="<?php echo $eststyle;?>color:#f77460;float: left;padding:5px;margin-bottom: 60px" href="sales?type=est">View Estimate</a><a style="<?php echo $billstyle;?>color:#f77460;margin-bottom: 60px;float: right;padding:5px" href="sales?type=bill">View Bill</a>
          <?php echo $this->table->generate();  ?>         
    
     
        </div>
    
    </div>
    


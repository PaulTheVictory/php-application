 <link href="<?php  echo base_url(); ?>css/jquery-ui.min.css?v=1.4" rel="stylesheet" type="text/css" />
 <link href="<?php  echo base_url(); ?>css/chosen.min.css?v=1.3" rel="stylesheet" type="text/css" />
  <link href="<?php  echo base_url(); ?>css/jquery-te-1.4.0.css?v=1.52" rel="stylesheet" type="text/css" />
 <script src="<?php  echo base_url(); ?>js/jquery-ui.min.js?v=1.3" type="text/javascript"></script>
  <script src="<?php  echo base_url(); ?>js/chosen.jquery.min.js?v=1.2" type="text/javascript"></script>
    <script src="<?php  echo base_url(); ?>js/jquery-te-1.4.0.min.js" type="text/javascript"></script>

 <style type="text/css">
     
     .ui-selectmenu-button.ui-button{ width: 97%; padding:13px;}
     #duration-button,#modeofexam-button,#examtimefreq-button,#subcriteria-button,#rule-button,#maincriteria-button,#stream-button,#coursetype-button,#accounthead-button{border: 1px solid #D7DFF0;background: #fff;font-size: 14px;color:#536485}
     #centers_chosen  {border: 1px solid #D7DFF0;background: #fff;padding: 8px 0px;}
     #districts_chosen  {border: 1px solid #D7DFF0;background: #fff;padding: 8px 0px;}
     #courses_chosen  {border: 1px solid #D7DFF0;background: #fff;padding: 8px 0px;}
     .chosen-container-multi .chosen-choices {border: 0px;background: none}
     .maincontent ul li.search-choice { height:auto; }
     .maincontent ul li.search-choice a{ height:auto; font-size: 14px;color:#536485}
     .chosen-container-multi .chosen-choices li.search-choice { background: #6884CC;border-radius: 5px;}
     .chosen-container-multi .chosen-choices li.search-choice {color: #fff;}
     .response p { float: right;font-size:12px;color:#eb345e;}
 </style>

	<div class="wrap dynamic-width" style="float: left;position: relative;min-width: 800px">
     <div style="margin-top: 10px; width: 99%; height: 50px; text-align: right;">
         <span style="font-weight: bold;font-size: 20px;padding: 10px;float:left;color: #364159">Add Event</span>
     </div>         
            <div id="course-container" class="add-course">
<?php echo form_open('examadd/examSubmit', array('id' => 'examForm')) ?>
                <div class="row-element">
                    <span class="title">Event Name</span>
                    <span class="content"><input type="text"  name = "ename" class="ename"></span>
                </div>
                <div class="row-element">
                    <span class="title" >Course Name</span>
                    <span class="content">
                       <select multiple id="courses" name = "courses" class="courses" style="width: 100%;font-size: 13px;float:left">
                            
                            <?php echo $courses;?>
                        </select>      
                        <input type="hidden" name="selcourses" class="selcourses" />
                    </span>
                </div>
                 <div class="row-element">
                    <span class="title" >Display Course Name</span>
                    <span class="content">
                        <input type="text" id = "dcname" name = "dcname" class="dcname" placeholder="Display Course Name">                                             
                    </span>
                </div>
                 <div class="row-element">
                    <span class="title" id="adtime">Event Date & Time</span>
                    <span class="content">
                        <label style="color:#536485;background: none;border: 0px;width: 48%;height: auto;float:left;">
                            <input placeholder="Starts on" type="text" name = "examdate" class="adtime" style="margin: 5px;background: #fff url('<?php echo base_url(); ?>/images/cal.png') no-repeat 98%;"></label>
                    </span>
                </div>
                
                 <div class="row-element" id="rtime">
                    <span class="title" >Reporting Time</span>
                    <span class="content">
                        <input type="text" placeholder="Select Date" name = "rtime" class="adtime">
                       
                    </span>
                </div>
                
                <div class="row-element">
                    <span class="title">Duration</span>
                    <span class="content">
                        
                        
                        <label style="color:#536485;background: none;border: 0px;width: 48%;height: auto;float:left;">
                            <input placeholder="Enter Value" type="text" name = "duration" class="advalue" style="margin: 5px;background: #fff ">
                         </label>
                        <label style="color:#536485;background: none;border: 0px;width: 4%;height: 20px;float:left;">&nbsp;</label>
                        <label style="color:#536485;background: none;border: 0px;width: 48%;height: auto;float:left;">
                        <select id="duration" name = "durationfreq" class="duration" style="font-size: 13px;float:left">
                            <option value="" >Select Duration</option>
                            <option>Minutes</option>
                            <option>Hours</option>
                        </select>
                         </label>
                    </span>
                </div>
                
                <div class="row-element">
                    <span class="title" id="commonces">Last Date & Time of Application</span>
                    <span class="content">
                        <input type="text" placeholder="Select Date" name = "ldate" class="adtime">
                       
                    </span>
                </div>
                                      
                         
                
                 <div class="row-element">
                    <span class="title" id="scity">Districts</span>                    
                    <span class="content"><select multiple id="districts" name = "districts" class="districts" style="width: 100%;font-size: 13px;float:left">
                            
                            <?php echo $districts;?>
                        </select></span>
                    <input type="hidden" name="seldistricts" class="seldistricts" />
                </div>
                
                
                 <div class="row-element">
                    <span class="title" id="scity">Centers</span>                    
                    <span class="content"><select multiple id="centers" name = "centers" class="centers" style="width: 100%;font-size: 13px;float:left">
                        </select></span>
                    <input type="hidden" name="selcenters" class="selcenters" />
                 </div>
                
                <div class="row-element">
                    <span class="title">Description</span>                    
                    <span class="content">
                        <textarea class="coursedesc" name = "cdescription" style=" width: 100%;height:160px"></textarea>
                    </span>
                </div>
       
            <?php echo form_close() ?>
                
            </div>
     <div style="margin-top: 0px; width: 98%; height: 70px; text-align: right;">
         <span  style="margin: 0px auto; float:right;margin-top: 18px;padding: 10px; color: #fff; background: #4f6fc4 none repeat scroll 0% 0%; border-radius:5px;cursor: pointer" class="btn savebtn" href="#">Submit</span>
         <a style="margin: 0px auto; float:right;margin-top: 18px;margin-right:18px;padding: 9px 10px; color: #0332AA; background: linear-gradient(0deg, #FFFFFF, #FFFFFF), #C4C4C4;border: 1px solid #0332AA; border-radius:5px" class="btn" href="<?php echo base_url(); ?>courses">Back</a>
         <span class="response" style="margin: 0px auto; float:right;width: 80%; height: 30px;margin-top:20px"></span>
     </div>         
        
        </div>
    
    
    
<script type="text/javascript">
$(document).ready(function() {
    
    $(".duration").selectmenu();
    $(".adtime").datetimepicker();
    $("#districts").chosen();$("#centers").chosen();$("#courses").chosen();
    $(".coursedesc").jqte();
    $("#courses_chosen").find(".chosen-search-input").val("Select Courses");
    $("#districts_chosen").find(".chosen-search-input").val("Select Districts");
    $("#centers_chosen").find(".chosen-search-input").val("Select Centers");
     
    $("#districts").chosen().change(function(){
        var selname = $(this).val();
        selname = selname+"";
        $.get('examadd/GetCenters',{ 'term':selname}, function(o) { 
            
                     $("#centers").chosen('destroy');  
                     $("#centers").html(o);
                     $("#centers").chosen();
                     $("#centers_chosen").find(".chosen-search-input").val("Select Centers");

              });   
    });
        
      $(".savebtn").click(function(){
         
               if($(".response").hasClass('progress')) { return;}
               $(".response").html('').text('Progressing...');
                $(".response").addClass('progress');
               var centers = "";var districts = "";var courses = "";
               $("#centers_chosen").find("li span").each(function(){
                   centers += $(this).text()+"|";
               });
               
               $("#districts_chosen").find("li span").each(function(){
                   districts += $(this).text()+"|";
               });
               
               $("#courses_chosen").find("li span").each(function(){
                   courses += $(this).text()+"|";
               });
               
               
               $(".selcenters").val(centers);$(".seldistricts").val(districts);
               $(".selcourses").val(courses);
                var examForm = $("#examForm");

                    $.ajax({
                        url: examForm.attr('action'),
                        type: 'post',
                        data: examForm.serialize(),
                        success: function(o){
                            
                            var response = $.parseJSON(o);
                            $(".response").html('');
                            if(response.status === 'success') {
                                
                                var t = "<?php echo base_url(); ?>"+"addpayment?id="+response.ide;
                                $(".response").css("color","rgb(25, 71, 15)");
                               $(".response").text(response.message);
                                $(location).prop('href', 'exammaster');
                            } else {
                                
                               $(".response").append(response.message); 
                               $(".response").removeClass('progress');
                           
                            }

                        }
                    });
                   
                              
            });
	
	
	$(".add-course").find("input").each(function(){
            
            $(this).keyup(function(event){
                if(event.keyCode == 13){
                    var ty = $(this).next();
                    event.preventDefault();
                    $('input')[$('input').index(this)+1].focus();
                    $('input')[$('input').index(this)+1].select();
                }
            });

            $(this).click(function(){ $(".errnotify").html("&nbsp;");});
            

        });
        $(document).delegate(".advalue","keyup",function(event){
     
            if(!numCheck(this)) { alert('invalid key'); return;}  
         });
        
	
        
        function numCheck(ele){
        
            var numchk = new RegExp("^[0-9.]*$");  
            if( numchk.test( $(ele).val() ) ){ return 1; } else { $(ele).val("");return 0;}
    }
    
    
      $("#cname").autocomplete({
            source: function (request, response) {
                $.ajax({
                    url: "courses/courseSearch",
                    contentType: "application/jsonp",
                    
                    data: {
                        term: request.term
                    },
                    success: function (data) {
                        data = $.parseJSON(data);
                        response(
                                $.map(data, function (item) {
                                    return {
                                        value: item.coursename,
                                        ide:item.ide
                                    };
                                })
                                );
                    }
                });
            },
            select: function (event, ui) {
                
                $("#selcname").val(ui.item.ide);
          
            }
            
        })._renderItem = function (ul, item) {

             return $("<li></li>")
                    .data("item.autocomplete", item)
                    .append('<a><div style="height: auto; width: auto; display: inline-block;"><p style="margin: 0px; padding: 0px; height: 20px; width: 100%; line-height: 30px;">' + item.courseid + ' , '+item.coursename+'</p></div></a>')
                    .appendTo(ul);
        };
	
});
</script>
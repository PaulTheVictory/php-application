<link rel="stylesheet" href="<?php echo base_url();?>css/boot/vendor/dataTables.bootstrap4.min.css">
<link rel="stylesheet" href="<?php echo base_url();?>css/boot/vendor/datatables.responsive.bootstrap4.min.css">

<link rel="stylesheet" href="<?php echo base_url();?>css/boot/vendor/baguetteBox.min.css">
<script src="<?php echo base_url();?>js/vendor/baguetteBox.min.js"></script>

<script type="text/javascript">
$(document).ready(function(){
	

  $(".confirm").click(function(){
     
     var url = 'stuqualifyupdate?'+'&ide=<?php echo $qualification['ide'];?>&type=edit';
        $(location).prop('href', url);
      
  });
  
    $(".back").click(function(){
     
     var url = 'stuqualifyupdate';
        $(location).prop('href', url);
      
  });
  
  
 
    
  
});
</script>

<style>

	.coursetype .card{box-shadow: 0px 0px 7px rgba(196, 196, 196, 0.35);background: linear-gradient(0deg, #FFFFFF, #FFFFFF), #C4C4C4;cursor: pointer;border: 2px solid transparent;transition: all ease 0.3s}
	.rounded .coursetype .card{border-radius: 10px}
	.coursetype .card.active{border: 2px solid #0332AA;}
	.coursetype .card p {color: #889DC6;font-size: 14px;transition: all ease 0.3s}
	.coursetype .card img{filter: opacity(0.4);transition: all ease 0.3s}
	
	.coursetype .card.active p{color: #0332AA;}
	.coursetype .card.active img{filter: opacity(1);}
	
	.coursetop p{color: #6F83AA}
	
	.coursedetails h1{font-size: 18px;color: #364159;}
	.coursedetails .card,.courseinfo .card{background: linear-gradient(0deg, #FFFFFF, #FFFFFF), #C4C4C4;box-shadow: 0px 0px 7px rgba(196, 196, 196, 0.35);border-radius: 10px;}
	.coursedetails h2{color: #0332AA;font-size: 24px;font-weight: bold;line-height: 36px;}
	.coursedetails p.list-item-heading,.coursecontent .row div:first-child p,.yearfee .row div:first-child p{color: #6884CC;font-weight: 600;}
	
	.border-right{border-right: 1px solid #D7DFF0!important;}
	
	.yearfee .card{background: #F6F7FA;border: 1px solid #BCCAE8;box-shadow: none}
	.yearfee p{margin-bottom: 1.5rem}
	.yearfee p.first,.yearfee p.second{font-weight: bold;font-size: 14px;color: #0332AA;text-align: left;text-transform: uppercase;}
	.yearfee .row div:last-child p{font-size: 14px;font-weight: 600;color: #364159;}
	
	.btn-primary{width: auto}
	
	.card h5{margin-bottom: 1rem;}
	h5{font-weight: bold;}
	.badge-outline-secondary, .badge-outline-theme-2{border: 1px solid #889DC6;color: #889DC6;background: #F6F7FA;}
	.badge{font-size: 12px;margin-right: 5px}
	
	.courseinfo .col-right .card .card-body{padding: 0;}
	.courseinfo .border-bottom{border-bottom: 1px solid #D7DFF0!important;}
	.col-right h5{padding: 1.2rem}
	
	.schedule .row div:first-child p{font-size: 12px;color: #6884CC;font-weight: bold;letter-spacing: 0.5px;text-transform: uppercase;}
	.schedule .row div:last-child p{font-size: 14px;font-weight: 600;}
	
	.relatedcourse p.list-item-heading{color: #6884CC;font-weight: 600;}
	.relatedcourse .row div:first-child p{font-size: 16px;color: #364159;font-weight: bold;}
	.relatedcourse .row div:last-child i{background: url(img/icons/arrow-right.png) no-repeat;width: 14px;height: 14px;display: inline-block;vertical-align: middle}
	
  .courseinfo ul {list-style: none;}
  .courseinfo li {list-style-position: inside;text-indent: 0em;font-stretch: normal;letter-spacing: normal;padding: 10px 10px 10px 35px;background: url("img/icons/check-circle.png") no-repeat left center; margin: 0;
  vertical-align: middle;}
	
	.icon-flag{background: url("img/icons/flag.png") no-repeat;width: 15px;height: 15px;display: inline-block;vertical-align: middle}
	.icon-check-square{background: url("img/icons/check-square.png") no-repeat;width: 15px;height: 15px;display: inline-block;vertical-align: middle}
	.icon-send{background: url("img/icons/send.png") no-repeat;width: 15px;height: 15px;display: inline-block;vertical-align: middle;margin-right: 5px}
	
	p.totalfee {font-weight: bold;font-size: 24px;color: #D63333;}
	
	
	.marksheet p.list-item-heading{color: #6884CC;font-weight: 600;}
	.marksheet img{width: 100px;height: 130px;}
	.marksheet .gallery .col-2{position: relative;padding: 0;margin: 1rem;max-width: 10% !important}
	.marksheet .overlay{background: rgba(83, 100, 133,0.6) url(img/icons/eye.png) no-repeat center;width: 100%;height: 100%;position: absolute;border-radius: 0.75rem;top: 0;}
		
	.myprofile .img-thumbnail{width: 115px;height: 115px}
	
	.gallery a{text-align: center}
	.gallery a i{font-size: 4rem;padding: 1.5rem 0;display: block}
	.gallery a span.text{font-size: 10px;position: absolute;top: 28%;left: 14%;background: #ff0000;color: #fff;text-transform: uppercase;padding: 0px 7px;font-weight: bold;}
	
	@media (max-width:767px){
		
		.marksheet .gallery .col-2{max-width: 100% !important;}
	}
	
</style>


<main>
	<div class="container-fluid">
		<div class="row">
			<div class="col-12">

				<!--<div class="separator mb-5"></div>-->


			</div>

		</div>

		<div class="row coursedetails">

			<div class="col-12 mb-4">
				<div class="card">
					<div class="card-body">

						
						<div class="row yearfee">


							<div class="col-md-5 mb-4">

								<p class="first"> <?php echo $qualification['class'];?> details</p>

								<div class="d-block w-100 p-0">

									<div class="row">

										<div class="col-md-5 col-5">
											<p>Year of Passing:</p>
										</div>

										<div class="col-md-7 col-7">
											<p><?php echo $qualification['yearofpassing'];?></p>
										</div>

									</div>

									<div class="row">

										<div class="col-md-5 col-5">
											<p>Class Name:</p>
										</div>

										<div class="col-md-7 col-7">
											<p><?php echo $qualification['class'];?></p>
										</div>

									</div>

									<div class="row">

										<div class="col-md-5 col-5">
											<p>Board of Exams:</p>
										</div>

										<div class="col-md-7 col-7">
											<p><?php echo $qualification['stream'];?></p>
										</div>

									</div>

									<div class="row">

										<div class="col-md-5 col-5">
											<p>Status:</p>
										</div>

										<div class="col-md-7 col-7">
                                                                                    <p>
                                                                                        <?php 
                                                                                        if($qualification['status'] === 'P') { echo 'Passed';}
                                                                                        else if($qualification['status'] === 'WFR') { echo 'Waiting For Result';}
                                                                                        else if($qualification['status'] === 'C') { echo 'Completed';}
                                                                                      
                                                                                        ?>
                                                                                    </p>
										</div>

									</div>

									<div class="row">

										<div class="col-md-5 col-5">
											<p>Roll Number:</p>
										</div>

										<div class="col-md-7 col-7">
											<p><?php echo $qualification['rollno'];?></p>
										</div>

									</div>

									<div class="row">

										<div class="col-md-5 col-5">
											<p>Grace Mark:</p>
										</div>

										<div class="col-md-7 col-7">
                                                                                        <p><?php if($qualification['gracemark'] != '') {echo ($qualification['gracemark'] === 'y')?"Yes":"No";}?></p>
										</div>

									</div>
								</div>
							</div>

                                                                <?php
                                                                
                                                                if($qualification['subject'] !== '') {
                                                                    
                                                                    $subject = explode("|",$qualification['subject']);
                                                                    $mark = ($qualification['mark'] !== '')? explode("|",$qualification['mark']):"";
                                                                    $grade = ($qualification['grade'] !== '')? explode("|",$qualification['grade']):"";
                                                                    
                                                                    
                                                                    
                                                                    ?>
							<div class="col-md-4 mb-4">

								<p class="first"> <?php echo $qualification['class'];?> Marksheet</p>

								<div class="card d-flex d-block w-100 p-3">
                                                                    
                                                                   <?php 
                                                                   
                                                                   for($i = 0 ; $i < count($subject);$i++) {
                                                                   if($subject[$i] ==='') { continue;}
                                                                       $con = ($mark !== '')?$mark[$i]:$grade[$i];
                                                                        echo '<div class="row">

										<div class="col-md-5 col-5">
											<p>'.$subject[$i].':</p>
										</div>

										<div class="col-md-7 col-7">
											<p>'.$con.'</p>
										</div>

									</div>';
                                                                    }
                                                                   
                                                                   ?>
								
								</div>
							</div>
                                                    
                                                    <?php } ?>

						</div>


						<div class="separator mb-5"></div>

                                                <?php if($qualification['xii_yearofpassing'] !== '') {?>
						<div class="row yearfee">


							<div class="col-md-5 mb-4">

								<p class="first"> <?php echo $qualification['xii_class'];?> details</p>

								<div class="d-block w-100 p-0">

									<div class="row">

										<div class="col-md-5 col-5">
											<p>Year of Passing:</p>
										</div>

										<div class="col-md-7 col-7">
											<p><?php echo $qualification['xii_yearofpassing']; ?></p>
										</div>

									</div>

									<div class="row">

										<div class="col-md-5 col-5">
											<p>Class Name:</p>
										</div>

										<div class="col-md-7 col-7">
											<p>XII Standard</p>
										</div>

									</div>

									<div class="row">

										<div class="col-md-5 col-5">
											<p>Board of Exams:</p>
										</div>

										<div class="col-md-7 col-7">
											<p><?php echo $qualification['xii_stream']; ?></p>
										</div>

									</div>

									<div class="row">

										<div class="col-md-5 col-5">
											<p>Status:</p>
										</div>

										<div class="col-md-7 col-7">
                                                                                    <p>
                                                                                        <?php 
                                                                                        if($qualification['xii_status'] === 'P') { echo 'Passed';}
                                                                                        else if($qualification['xii_status'] === 'WFR') { echo 'Waiting For Result';}
                                                                                        else if($qualification['xii_status'] === 'C') { echo 'Completed';}
                                                                                      
                                                                                        ?>
                                                                                    </p>
										</div>

									</div>

									<div class="row">

										<div class="col-md-5 col-5">
											<p>Roll Number:</p>
										</div>

										<div class="col-md-7 col-7">
											<p><?php echo $qualification['xii_rollno']; ?></p>
										</div>

									</div>

									<div class="row">

										<div class="col-md-5 col-5">
											<p>Grace Mark:</p>
										</div>

										<div class="col-md-7 col-7">
											<p><?php if($qualification['xii_gracemark'] != '') {echo ($qualification['xii_gracemark'] === 'y')?"Yes":"No";}?></p>
										</div>

									</div>
								</div>
							</div>

                                                                <?php
                                                                
                                                                if($qualification['xii_subject'] !== '') {
                                                                    
                                                                    $xii_subject = explode("|",$qualification['xii_subject']);
                                                                    $xii_mark = ($qualification['xii_mark'] !== '')? explode("|",$qualification['xii_mark']):"";
                                                                    $xii_grade = ($qualification['xii_grade'] !== '')? explode("|",$qualification['xii_grade']):"";
                                                                    
                                                                    
                                                                    
                                                                    ?>
							<div class="col-md-4 mb-4">

								<p class="first"> <?php echo $qualification['xii_class'];?> Marksheet</p>

								<div class="card d-flex d-block w-100 p-3">

									<?php 
                                                                   
                                                                   for($i = 0 ; $i < count($xii_subject);$i++) {
                                                                   if($xii_subject[$i] ==='') { continue;}
                                                                       $con = ($xii_mark !== '')?$xii_mark[$i]:$xii_grade[$i];
                                                                        echo '<div class="row">

										<div class="col-md-5 col-5">
											<p>'.$xii_subject[$i].':</p>
										</div>

										<div class="col-md-7 col-7">
											<p>'.$con.'</p>
										</div>

									</div>';
                                                                    }
                                                                   
                                                                   ?>

									
								</div>
							</div>
                                                <?php } ?>

						</div>

                                               
						<div class="separator mb-5"></div>
													
 													<?php } ?>

						<div class="row yearfee">


                                                            <?php
                                                                                                                      
                                                            if($qualification['entrance_name'] != "") {
                                                                
                                                                $examArr1 = explode("|", $qualification['entrance_name']);
                                                                $examArr2 = explode("|", $qualification['entrance_mark']);
                                                                $examArr3 = explode("|", $qualification['entrance_regno']);
                                                                
                                                                foreach ($examArr1 as $key => $value) {
                                                                    
                                                                    if($value === "") {continue;}
                                                            
                                                            echo '<div class="col-md-5 mb-4">
                                                            

								<p class="first">'.$value.' - Entrance Exam</p>

								<div class="d-block w-100 p-0">

									<div class="row">

										<div class="col-md-5 col-5">
											<p>Rank/Mark:</p>
										</div>

										<div class="col-md-7 col-7">
											<p>'.$examArr2[$key].'</p>
										</div>

									</div>

									<div class="row">

										<div class="col-md-5 col-5">
											<p>Registration Number:</p>
										</div>

										<div class="col-md-7 col-7">
											<p>'.$examArr3[$key].'</p>
										</div>

									</div>


								</div>
							</div>';
                                                                }
                                                            }
                                                            
                                                            ?>
							
						</div>
						
						<?php
		
								$marksheets = $qualification['marksheets'];
								$marksheetsarr = explode('|',$marksheets);

								$marksheetlist = "";
								foreach($marksheetsarr as $marksheet){

									$ext = end(explode(".",$marksheet));

									if(strtolower($ext)!="pdf"){
										$marksheetlist .= '<div class="col-2"><a href="docs/courserequest/marksheets/'.$user['id'].'/'.$marksheet.'?'.time().'"><img class="img-fluid border-radius" src="docs/courserequest/marksheets/'.$user['id'].'/'.$marksheet.'?'.time().'"><div class="overlay"></div></a></div>';
									}
									else{
										$marksheetlist .= '<div class="col-2"><a href="docs/courserequest/marksheets/'.$user['id'].'/'.$marksheet.'?'.time().'" target="_blank"><span class="text">pdf</span><i class="glyph-icon simple-icon-doc"></i><div class="overlay"></div></a></div>';
									}

								}
			
							?>
        
							<?php if($marksheets!="" && $marksheets!="0"){?>
						   
						   <div class="mb-4 marksheet">

								<div class="row">

									  <div class="col-12">

											<p class="list-item-heading pb-2">Marksheets:</p>

											<div class="row gallery px-4 mb-4">
											  <?php echo $marksheetlist;?>
											</div>

									  </div>

								 </div>

							</div> 

							<?php }?> 


						<div class="mb-5"></div>

						<div class="row">

							<div class="col-md-4 col-4 text-left">
								<button class="btn btn-outline-primary back">Back</button>

							</div>
                                                    
							<div class="col-md-8 col-8 text-right justify-content-end">
                                                                
								<!--<button class="btn btn-primary confirm">Edit</button>
								<span class="response" style="margin: 0px auto; float:right;width: 50%; height: 30px;margin-top:20px"></span>-->

							</div>
                                                   

						</div>


					</div>

				</div>
			</div>
		</div>

	</div>


	</div>
	
	<style>

	.courseredirect{background: #3CAF92 !important;display: block;margin: auto;border: 1px solid #209679;}
	h5.modal-title p.headtitle{display: inline-block;width: 100%;text-align: center;font-weight: bold;font-size: 24px;line-height: 36px;color: #3CAF92;}
	h5.modal-title p.text-muted{display: inline-block;width: 100%;text-align: center;font-weight: 600;font-size: 14px;line-height: 36px;color: #181E29;line-height: 20px;}
	.modal-title img{display: block;margin: 1em auto}
	
</style>


<button type="button" class="btn btn-outline-primary d-none courseconfirm" data-toggle="modal" data-backdrop="static" data-target="#courseModal">Confirm Submission</button>  
<!-- Modal -->
<div class="modal fade" id="courseModal" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog" role="document">
	<div class="modal-content">
	  <div class="modal-header">
	  
		<h5 class="modal-title" id="exampleModalLabel">
		
			<!--img src="<?php echo base_url(); ?>/img/icons/round-tick.png" class="mb-4" /--> 
			
			<p class="headtitle mb-4">Successful!</p>
		
			<p class="text-muted mb-4">Your request for course registration has been sent successfully! We’ll update you soon.</p>
		</h5>
		<!--<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>-->
	  </div>
	  
	  <div class="modal-footer">
		<button type="button" class="btn btn-primary courseredirect px-5" data-dismiss="modal">Okay</button>
	  </div>
	</div>
  </div>
</div>
</main>
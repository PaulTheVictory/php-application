<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Barcodes (<?php echo $bcdetails['barcodefrom'] ?> - <?php echo  $bcdetails['barcodeto'];?>)</title>
<!--<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1">-->

<link rel="stylesheet" href="<?php echo base_url();?>css/boot/bootstrap.min.css">
<link rel="stylesheet" href="<?php echo base_url();?>css/boot/bootstrap.rtl.only.min.css">
<link rel="stylesheet" href="<?php echo base_url();?>css/boot/bootstrap-float-label.min.css">
<link rel="stylesheet" href="<?php echo base_url();?>css/boot/main.css">

<script src="<?php echo base_url();?>js/jquery-3.5.1.min.js"></script>


<script type="text/javascript">
$(document).ready(function(){
		
	window.print();

});
</script>

    
 <style type="text/css">
	 
	 table.dataTable{margin-top: 2rem !important}
	 .table tr:last-child td{text-align: left}
	.table tr td:last-child,.table tr th:last-child{text-align: left}
	.table tr:last-child td:last-child{font-weight: 600;text-align: left}
	.table tr:last-child{text-align: center}
	
	.table{border: 1px solid #D7DFF0;border-collapse: collapse;border-style: hidden;border-radius: 10px 10px 0 0;box-shadow: 0 0 0 1px #d7dff0;}
	.table thead th{font-size: 12px;font-weight: bold;color: #6F83AA;letter-spacing: 0.5px;background: #E6EBF7;text-transform: uppercase;padding: 0.8rem;text-align: left}
	.table thead tr th:first-child{border-top-left-radius: 5px}
	.table thead tr th:last-child{border-top-right-radius: 5px}
	.table td, .table th{border-top: 1px solid #D7DFF0;padding: 0.9rem 0.75rem;color: #364159;font-weight: 600;}
	.table td{background: #ffffff;}
	
		
	h3.title{font-size: 12px;text-transform: uppercase;color: #0332AA;letter-spacing: 0.5px;font-weight: bold;}
		
		.dataTables_empty{text-align: center !important}
		.dataTables_wrapper{overflow-x: auto}
	 
	 .notifycard .card{background: linear-gradient(0deg, #FFFFFF, #FFFFFF), #C4C4C4;box-shadow: 0px 0px 0px rgba(196, 196, 196, 0.35);border-radius: 5px;}
	 .notifycard .z-index{z-index: 1;}
	 
	 .form-group.floating{margin-bottom: 0}
	 
	 .notifycard p.text-muted{font-weight: 600;line-height: 16px;}
	 .notifycard{height: 105px;margin: 1.2rem auto}
	 
	 .dataTables_filter{right: 0;left: 20px;top: 5px;}
	 #usertable_filter input{width: 300px}
	 #usertable_wrapper{top: 0px;padding-top: 3rem}
	 
	 textarea.form-control.smstext,textarea.form-control.whatsapptext{height: 110px}

 </style>
 
	</head>
	
	<body>
	
 <main> 
        
    <div class="container-fluid">
                 
		<h2 class="text-center">Generated Barcodes (<?php echo $bcdetails['barcodefrom'] ?> - <?php echo  $bcdetails['barcodeto'];?>)</h2>
               
            <div class="row px-3 mt-0 mb-0">     
                                 
            
            <?php 
	
					//print_r($bcdetails);

					$dirname = './docs/barcode/'.$bcdetails['id'].'/';

					$fileList = glob($dirname.'*');
					
					$count = 1;
				
					$totalbc = count($fileList);
				
					foreach($fileList as $filename){
						
						if(is_file($filename)){
							//echo $filename, '<br>';
							
							
						if($count==10){
							$height = '68px';
						}else if($count > 10 && $count % 10 == 0 && $count!=0 && $totalbc!=$count){
							$height = '80px';
						}else{
							$height = '0px';
						}
							
				?>     
           
            <div class="col-12 notifycard p-0">
           
           <div class="card">
           
            <div class="course-container add-course p-4">
                     
                                                      
                <div class="row align-items-center batches">
                   
                    <div class="col-3 border-right text-center">
                    
						<img src="<?php echo $filename;?>" alt="Barcode" />
				  		
					</div>	
                   
                    <div class="col-3 border-right text-center">
                                          
                    		<img src="<?php echo $filename;?>" alt="Barcode" />
                    						  		
					</div>	
                   
                    <div class="col-3 border-right text-center">
                                          
                    		<img src="<?php echo $filename;?>" alt="Barcode" />
                    						  		
					</div>	
                   
                    <div class="col-3 text-center">
                                          
                    		<img src="<?php echo $filename;?>" alt="Barcode" />
                    						  		
					</div>	
					
									
					
				</div>
                    
                                          
               
                </div>
                
			   </div>
               
            </div>
             
				<div style="width:100%;height:<?php echo $height; ?>"></div>            
                                         
                   <?php }  $count++; } ?>      
             
          
           </div>
                       
       
 </div>
 
 </main>
   
	</body>
   
</html>
    
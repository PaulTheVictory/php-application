<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/dataTables.css?v=1.6" />
<script src="<?php echo base_url(); ?>js/jquery.dataTables.js?v=1.0" type="text/javascript"></script>
<link href="<?php  echo base_url(); ?>css/jquery-ui.min.css?v=1.4" rel="stylesheet" type="text/css" />
 <script src="<?php  echo base_url(); ?>js/jquery-ui.min.js?v=1.3" type="text/javascript"></script>
<link rel="stylesheet" href="<?php echo base_url();?>css/boot/bootstrap.min.css">
<script src="<?php echo base_url();?>js/bootstrap.bundle.min.js"></script>
<link rel="stylesheet" href="<?php echo base_url();?>css/boot/main.css?v=1">
<style type="text/css">


.dataTables_wrapper input[type="text"] {
    padding: 0;
}
.dataTables_wrapper select {
    padding: 0;
}

.sortable thead tr  {
    background: #E6EBF7;

/* g8 */
border: 1px solid #D7DFF0;
box-sizing: border-box;
border-radius: 10px 10px 0px 0px;
 

}
.sortable tr th {
    border-right: 0px;
    padding: 15px 0;font-size: 13px;
      color: #6F83AA;
   cursor: pointer;
   text-align: center;

}

.sortable tr th:nth-child(3) {
  text-align: left;
}

.sortable tr td:nth-child(3) {
  text-align: left;
}

/*.sortable tr th:nth-child(1) {
  width: 50px !important;
}

.sortable tr th:nth-child(2) {
    width: 10% !important;
  background: none;
   text-align: left;
}


.sortable tr th:nth-child(3) {
  background: none;
  width: 25% !important;
   text-align: center;
}

.sortable tr th:nth-child(6) {
  background: none;
  width: 20% !important;
   text-align: center;
}

.sortable tr th:nth-child(7) {
  background: none;
  width: 70px !important;
   text-align: center;
}
*/

.sortable tr td {
    border-right: 0px;
    padding: 5px 5px;
    text-align: center;font-size: 13px;
    min-width:50px;vertical-align: middle;
}
.sortable tr td a {
    color: #364159;
}

#profile-right h2 {
    margin: 0px 0px 10px 0px;
}

.studenttable_length { width: auto !important; }
#studenttable_filter input { padding-top:4px;background: #fff url('<?php echo base_url(); ?>/images/search.png') no-repeat center left;background-position-x: 10px;border: 1px solid #D7DFF0; line-height: 32px;margin-left: 10px;width:260px;border-radius: 5px;text-indent: 30px;font-size: 13px;}
.sortable tr td a:hover { text-decoration: underline; }
.dataTables_filter { right:10px !important;}
.ui-autocomplete { z-index: 10000;}	

</style>
<script type="text/javascript">
$(document).ready(function(){	
		
	 
          var columnData = [
              
                    { "data": "cuid" },
                    { "data": "courseid" },
                    { "data": "center" },       
                    { "data": "admitted" , "searchable": false},
                    { "data": "pending" , "searchable": false},
                    { "data": "waitinglist" , "searchable": false},
                    { "data": "shortlist" , "searchable": false},  
                    { "data": "rejected" , "searchable": false},      
                    { "data": "total" , "searchable": false},
                    { "data": "requested_at" , "searchable": false}   
                    
                    
                  ];
        // columnData.push( {data: "id","visible":true} );
         //columnData.push( {data: "item_name_search","visible":false} );
         
       
        var oTable = $('#studenttable').dataTable({
                    "bProcessing": true,
                    "bServerSide": true,
                    "sPaginationType": "full_numbers",
                    "ajax": {
                    "url": 'admissions/GetAdmissionCenterLists',
                    "type": "POST"
                     }, 
                     "oLanguage": {
                        "sProcessing": "<img src='<?php echo base_url(); ?>images/loader.gif'>"
                    },
                    'iDisplayLength': 20,
                    "columns": columnData,
                    "order": [[ 0, "desc" ]],
                    "fnDrawCallback": function( oSettings ) {
                        
    }
         }); 
         
         <?php if(isset($roleaccess['Export'][3]) && $roleaccess['Export'][3]=== 'y') { ?>
         
         $(document).on("click","#bulkexport",function(){
		
		$('#exportModal').modal({show:true});	
				
	});
         
         
         function selectcenter(ide){
	
	$.ajax({
		type: 'POST',
		url: 'courses/GetCourseCenterList',
		data: {'ide':ide},
		success: function(response) {

                        var obj1 = $.parseJSON(response);
                        $("#ccenter").html("<option>All</option>");
			$("#ccenter").append(obj1['center']);
                        $("#ccenter").attr("data-id",ide);
                        

		}

	});
   
}
      
        
	  $("#cname").autocomplete({
            source: function (request, response) {
                $.ajax({
                    url: "courses/courseSearch",
                    contentType: "application/jsonp",
                    
                    data: {
                        term: request.term
                    },
                    success: function (data) {
                        data = $.parseJSON(data);
                        response(
                                $.map(data, function (item) {
                                    return {
                                        value: item.coursename,
                                        ide:item.ide
                                    };
                                })
                                );
                    }
                });
            },
            select: function (event, ui) {
                
                $("#cname").attr("data-cname",ui.item.ide);
                selectcenter(ui.item.ide);
          
            }
            
        })._renderItem = function (ul, item) {

             return $("<li></li>")
                    .data("item.autocomplete", item)
                    .append('<a><div style="height: auto; width: auto; display: inline-block;"><p style="margin: 0px; padding: 0px; height: 20px; width: 100%; line-height: 30px;">' + item.courseid + ' , '+item.coursename+'</p></div></a>')
                    .appendTo(ul);
        };
        
        
	$(".exportbtn").click(function(){
     
              var cid =  $("#cname").attr("data-cname");
              var center =  $("#ccenter").val();
              var type =  $("#cstatus").val();
              if(cid === ""){
                  alert("Kindly select the course name");return;
              }else{
                    var url = 'admissions/export?courseid='+cid+'&type='+type+'&center='+center;              
                    $(location).prop('href', url);
              }
        });
	
        <?php } ?> 	
});
</script>


<div class="wrap dynamic-width" style="float: left;position: relative">
    
    <div style="margin-top: 10px; width: 100%; height: 50px; text-align: right;">
             <span style="font-weight: bold;font-size: 20px;padding: 10px;float:left;color: #364159">Admission List</span>
            </div>
            
        
    <!--  Import Admission  -->
        
    <?php if(isset($roleaccess['Bulk Admission'][3]) && $roleaccess['Bulk Admission'][3]=="y"){ ?>
                                                              
     <div class="row-element" style="margin-top:6px;">
                
                 <div style="float: left;width: auto;height: auto;text-align: left;margin-left:0px;margin-top: 10px;">
			 <a href="bulkimport"> <span id="bulkadmission" style="cursor: pointer;margin-left:10px;font-weight: bold;font-size: 14px;padding: 5px 10px;color: #fff;border-radius:5px;background: linear-gradient(180deg, #4F70C4 0%, #1C47B3 100%);">Bulk Admission</span></a>
                       <?php if(isset($roleaccess['Export'][3]) && $roleaccess['Export'][3]=== 'y') { ?>
                         <a href="javascript:void(0)"> <span id="bulkexport" style="cursor: pointer;margin-left:10px;font-weight: bold;font-size: 14px;padding: 5px 10px;color: #fff;border-radius:5px;background: linear-gradient(180deg, #4F70C4 0%, #1C47B3 100%);">Export</span></a>
                        <?php } ?> 
                         <?php if(isset($roleaccess['Bulk Discount'][3]) && $roleaccess['Bulk Discount'][3]=== 'y') { ?>
                         <a href="bulkdiscount"> <span id="bulkdiscount" style="cursor: pointer;margin-left:10px;font-weight: bold;font-size: 14px;padding: 5px 10px;color: #fff;border-radius:5px;background: linear-gradient(180deg, #4F70C4 0%, #1C47B3 100%);">Bulk Discount</span></a>
                        <?php } ?> 
                 </div>
                                                                            
    </div>
      	                                  
     <?php } ?> 
    
       	                                  
       <!--  Import Admission  -->
       	                                   	                                  
        	                                  
         <?php echo $this->table->generate();  ?>             
         
        
        
        </div>
    
  <?php if(isset($roleaccess['Export'][3]) && $roleaccess['Export'][3]=== 'y') { ?>
	   
	   <div id="exportModal" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
                            <div class="modal-header" style="background-color:#6884CC;padding:10px">
                                <h2 class="my-0" style="color:#fff;font-size:20px">Admission Export</h2>
				   <button style="color:#fff" type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				</div>
				<div class="modal-body text-center">
														
					<div class="row" style="width: 98%;margin: 0px auto;margin-top: 25px;">
                                
                                                <div class="col-12 col-sm-12 mb-4" >
                                                    <div class="form-group position-relative error-l-50 floating">
                                                        <input type="text" value="" data-cname="" class="form-control" name="cname" id="cname"  required="" placeholder=" " >
                                                     <label for="cname">Course Name <span>*</span></label>
                                                    </div>
                                                </div>
                                               <div class="col-12 col-sm-12 mb-4">
                                                    <div class="form-group position-relative error-l-50 floating">
                                                        <select class="form-control " id="ccenter" name="ccenter"  required  >
                                                            <option value="">All</option>
                                                    </select>
                                                <label for="ccenter">Center<span>*</span></label>
                                                    </div>
                                                </div>
                                            
                                                <div class="col-12 col-sm-12">
                                                    <div class="form-group position-relative error-l-50 floating">
                                                        <select class="form-control " id="cstatus" name="cstatus"  required  >
                                                           <option value="">All</option>
                                                            <option value="y">Admitted</option>
                                                            <option value="q">Applied</option>
                                                            <option value="w">Waiting List</option>
                                                            <option value="s">Short List</option>
                                                            <option value="n">Applied - NQ</option>
                                                            <option value="d">Denied</option>
                                                    </select>
                                                 <label for="cstatus">Status<span>*</span></label>
                                                    </div>
                                                </div>
                
                
                                        </div>
					
					
				</div>
				<div class="modal-footer">
				
					<button class="btn btn-primary exportbtn" type="button">Export</button>
					<button type="button" class="btn btn-outline-primary modalclose" data-dismiss="modal">Close</button>
				</div>
								
			</div>
		</div>
	</div>
	   
	   <?php }?>
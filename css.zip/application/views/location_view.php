 <link href="<?php  echo base_url(); ?>css/jquery-ui.min.css?v=1.4" rel="stylesheet" type="text/css" />
 <script src="<?php  echo base_url(); ?>js/jquery-ui.min.js?v=1.3" type="text/javascript"></script>
 <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/dataTables.css?v=1.5" />
<script src="<?php echo base_url(); ?>js/jquery.dataTables.js?v=1.0" type="text/javascript"></script>

 <style type="text/css">
     
     .ui-selectmenu-button.ui-button{ width: 97%; padding:13px;}
     #country-button,#state-button,#District-button{border: 1px solid #D7DFF0;background: #fff;font-size: 14px;color:#536485;padding: 10px}
     .maincontent ul li.search-choice { height:auto; }
     .maincontent ul li.search-choice a{ height:auto; font-size: 14px;color:#536485}
     .response p { float: right;font-size:12px;color:#eb345e;}
     
.sortable thead tr {
    background: #E6EBF7;
    border: 1px solid #D7DFF0;
    box-sizing: border-box;
    border-radius: 10px 10px 0px 0px;
}
.sortable tr th {
    border-right: 0px;
    padding: 20px 0;font-size: 13px;
      color: #6F83AA;
   cursor: pointer;
   text-align: center;

}

.sortable tr td:nth-child(1) {
   
    min-width:50px;color: #364159;
}

.sortable tr td:nth-child(2) {
   
    width:40%;
}

.sortable tr td {
    border-right: 0px;
    padding: 15px 5px;
    text-align: center;font-size: 13px;
    min-width:100px;
}
.sortable tr td a {
    color: #364159;
}

.dataTables_info { display: none; }
#locationtable_filter input { padding-top:4px;background: #fff url('<?php echo base_url(); ?>/images/search.png') no-repeat center left;background-position-x: 10px;border: 1px solid #D7DFF0; line-height: 32px;margin-left: 10px;width:260px;border-radius: 5px;text-indent: 30px;font-size: 13px;}
.sortable tr td a:hover { text-decoration: underline; }
.sortable tr td span{ font-size: 14px;color: #364159 }
 </style>

	<div class="wrap dynamic-width" style="float: left;position: relative;min-width: 800px">
     <div style="margin-top: 10px; width: 99%; height: 50px; text-align: right;">
         <span style="font-weight: bold;font-size: 20px;padding: 10px;float:left;color: #364159">Add Location</span>
         
     </div>       
		
           <?php if(isset($roleaccess['Locations'][0]) && $roleaccess['Locations'][0]=="y"){ ?>
           
            <div id="course-container" class="add-course">
<?php echo form_open('location/locationSubmit', array('id' => 'locationForm')) ?>
                <div class="row-element">
                    <span class="content"><input placeholder="Location / Center Name" type="text" value="" name = "cname" class="name"></span>
                </div>
                <div class="row-element">
                    <span class="content"><input placeholder="Google Location URL" type="text" value="" name = "gurl" class="name"></span>
                </div>
                
                <div class="row-element">
                    
                    <span class="content">
                        
                        <label style="color:#536485;background: none;border: 0px;width: 48%;height: auto;float:left;">
                        <select id="state" name = "state" class="duration" style="font-size: 13px;float:left">
                            <option value="">Select State</option>
                            <option value="Kerala">Kerala</option>
                            <option value="Tamil Nadu">Tamil Nadu</option>
<!--                            <option value="Andhra Pradesh">Andhra Pradesh</option>
                            <option value="Andaman and Nicobar Islands">Andaman and Nicobar Islands</option>
                            <option value="Arunachal Pradesh">Arunachal Pradesh</option>
                            <option value="Assam">Assam</option>
                            <option value="Bihar">Bihar</option>
                            <option value="Chandigarh">Chandigarh</option>
                            <option value="Chhattisgarh">Chhattisgarh</option>
                            <option value="Dadar and Nagar Haveli">Dadar and Nagar Haveli</option>
                            <option value="Daman and Diu">Daman and Diu</option>
                            <option value="Delhi">Delhi</option>
                            <option value="Lakshadweep">Lakshadweep</option>
                            <option value="Puducherry">Puducherry</option>
                            <option value="Goa">Goa</option>
                            <option value="Gujarat">Gujarat</option>
                            <option value="Haryana">Haryana</option>
                            <option value="Himachal Pradesh">Himachal Pradesh</option>
                            <option value="Jammu and Kashmir">Jammu and Kashmir</option>
                            <option value="Jharkhand">Jharkhand</option>
                            <option value="Karnataka">Karnataka</option>
                            <option value="Kerala">Kerala</option>
                            <option value="Madhya Pradesh">Madhya Pradesh</option>
                            <option value="Maharashtra">Maharashtra</option>
                            <option value="Manipur">Manipur</option>
                            <option value="Meghalaya">Meghalaya</option>
                            <option value="Mizoram">Mizoram</option>
                            <option value="Nagaland">Nagaland</option>
                            <option value="Odisha">Odisha</option>
                            <option value="Punjab">Punjab</option>
                            <option value="Rajasthan">Rajasthan</option>
                            <option value="Sikkim">Sikkim</option>
                            <option value="Tamil Nadu">Tamil Nadu</option>
                            <option value="Telangana">Telangana</option>
                            <option value="Tripura">Tripura</option>
                            <option value="Uttar Pradesh">Uttar Pradesh</option>
                            <option value="Uttarakhand">Uttarakhand</option>
                            <option value="West Bengal">West Bengal</option>-->
                        </select>
                         </label>
                        <label style="color:#536485;background: none;border: 0px;width: 4%;height: 20px;float:left;">&nbsp;</label>
                         <label style="color:#536485;background: none;border: 0px;width: 48%;height: auto;float:left;">
                            <select id="District" name = "District" class="duration" style="font-size: 13px;float:left">
                            <option value="" >District</option>
                            
                        </select>
                         </label>
                    </span>
                </div>
                <div class="row-element">
                    
                    <span class="content">
                        
                        <label style="color:#536485;background: none;border: 0px;width: 48%;height: auto;float:left;">
                            <input type="text" value="" placeholder="Pincode" name = "pincode" class="name">
                         </label>
                    </span>
                </div>

                
            <?php echo form_close() ?>
                
            </div>
            
       
     <div style="margin-top: 0px; width: 98%; height: 70px; text-align: right;">
         <span  style="margin: 0px auto; float:right;margin-top: 18px;padding: 10px; color: #fff; background: #4f6fc4 none repeat scroll 0% 0%; border-radius:5px;cursor: pointer" class="btn savebtn" href="#">Save</span>
         <a style="margin: 0px auto; float:right;margin-top: 18px;margin-right:18px;padding: 9px 10px; color: #0332AA; background: linear-gradient(0deg, #FFFFFF, #FFFFFF), #C4C4C4;border: 1px solid #0332AA; border-radius:5px" class="btn" href="<?php echo base_url(); ?>location">Reset</a>
         <span class="response" style="margin: 0px auto; float:right;width: 80%; height: 30px;margin-top:20px"></span>
     </div>  
           
            <?php } ?>
             
            <label style="color:#536485;background: none;border: 0px;width: 4%;height: 80px;float:left;">&nbsp;</label>     
       <div style="width:100%;height: auto;float:left">
         <?php echo $this->table->generate();  ?>             
         
        </div>     
        
        </div>
    
    
    
<script type="text/javascript">
$(document).ready(function() {
    
    $(".duration").selectmenu();
    
     var columnData = [
                   
                    { "data": "sno" },
                    { "data": "unit" },                    
                    { "data": "district" },
                    { "data": "state" },
                     { "data": "ide" }
                    
                  ];
                
       
        var oTable = $('#locationtable').dataTable({
                    "bProcessing": true,
                    "bServerSide": true,
                    "sPaginationType": "full_numbers",
                    "ajax": {
                    "url": 'location/GetLocations',
                    "type": "POST",
                    "data":{ }
                     }, 
                     "oLanguage": {
                        "sProcessing": "<img src='<?php echo base_url(); ?>images/loader.gif'>"
                    },
                    'iDisplayLength': 10,
                    "columns": columnData,
                    "fnDrawCallback": function( oSettings ) {
                        
                         $("#locationtable").find(".del").each(function(){

                            $(this).click(function(){ 

                              if(confirm("Are you sure to delete this item ?")) {
                                    var ide = $(this).attr("data-id");
                                    $.get('location/DelLocation',{
                                                               'ide':ide

                                                    }, function(o) { 
                                                            var obj1 = $.parseJSON(o);
                                                    if (obj1[0] === 'success') {
                                                        oTable.fnDraw(); 
                                                    } else if (obj1[0] === 'fail') {
                                                        alert("Error!!! please try again");
                                                }
                                    });
                                }

                              });
                        
                        
                              $(this).closest("tr").find(".screentest").each(function(){
                                  
                                  if($(this).text() === "0" || $(this).text() === "") { $(this).text("NA");}
                                  else if($(this).text() === "on"){ $(this).text("A"); }
                              });

                          });
                                             
                    }
         }); 
    
    
    $(".savebtn").click(function(){
         
               $(".response").html('').text('Progressing...');
     
               
                var locationForm = $("#locationForm");

                    $.ajax({
                        url: locationForm.attr('action'),
                        type: 'post',
                        data: locationForm.serialize(),
                        success: function(o){
                            
                            var response = $.parseJSON(o);
                            $(".response").html('');
                            if(response.status === 'success') {
                       
                                $(".response").css("color","rgb(25, 71, 15)");
                               $(".response").text(response.message);
                               oTable.fnDraw();
                               
                               
                            } else {
                                
                               $(".response").append(response.message); 
                           
                            }

                        }
                    });
                   
                              
            });
	
	
        $('#state').on('selectmenuchange', function() {
            var ty =  $(this).val(); 
            $.get('location/GetDistricts',{  'state':ty}, function(o) { 
                                        $("#District").html(o);
                                        $("#District").selectmenu('refresh');
                                });



        });
        
        
      
	
});
</script>
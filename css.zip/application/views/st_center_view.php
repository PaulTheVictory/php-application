<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/dataTables.css?v=1.5" />
<script src="<?php echo base_url(); ?>js/jquery.dataTables.js?v=1.0" type="text/javascript"></script>
<style type="text/css">


.dataTables_wrapper input[type="text"] {
    padding: 0;
}
.dataTables_wrapper select {
    padding: 0;
}

.sortable thead tr  {
    background: #E6EBF7;

/* g8 */
border: 1px solid #D7DFF0;
box-sizing: border-box;
border-radius: 10px 10px 0px 0px;
 

}
.sortable tr th {
    border-right: 0px;
    padding: 15px 0;font-size: 13px;
      color: #6F83AA;
   cursor: pointer;
   text-align: center;

}


/*.sortable tr th:nth-child(1) {
  width: 50px !important;
}

.sortable tr th:nth-child(2) {
    width: 10% !important;
  background: none;
   text-align: left;
}


.sortable tr th:nth-child(3) {
  background: none;
  width: 25% !important;
   text-align: center;
}

.sortable tr th:nth-child(6) {
  background: none;
  width: 20% !important;
   text-align: center;
}

.sortable tr th:nth-child(7) {
  background: none;
  width: 70px !important;
   text-align: center;
}
*/

.sortable tr td {
    border-right: 0px;
    padding: 5px 5px;
    text-align: center;font-size: 13px;
    min-width:50px;vertical-align: middle;
}
.sortable tr td a {
    color: #364159;
}

#profile-right h2 {
    margin: 0px 0px 10px 0px;
}

.studenttable_length { width: auto !important; }
#studenttable_filter input { padding-top:4px;background: #fff url('<?php echo base_url(); ?>/images/search.png') no-repeat center left;background-position-x: 10px;border: 1px solid #D7DFF0; line-height: 32px;margin-left: 10px;width:260px;border-radius: 5px;text-indent: 30px;font-size: 13px;}
.sortable tr td a:hover { text-decoration: underline; }
.dataTables_filter { right:10px !important;}
</style>
<script type="text/javascript">
$(document).ready(function(){	
		
	
          var columnData = [
              
                                
                    { "data": "center" }, 
                    { "data": "tqty" }, 
                    { "data": "applied" , "searchable": false},
                    { "data": "remitted" , "searchable": false},
                    { "data": "actualremitted" , "searchable": false},
                    { "data": "pending" , "searchable": false},
                    { "data": "htissued" , "searchable": false},
                    { "data": "htdownloaded" , "searchable": false}
                   
                  ];
        // columnData.push( {data: "id","visible":true} );
         //columnData.push( {data: "item_name_search","visible":false} );
         
       
        var oTable = $('#studenttable').dataTable({
                    "bProcessing": true,
                    "bServerSide": true,
                    "sPaginationType": "full_numbers",
                    "ajax": {
                    "url": 'screeningtest/GetAdmissionCenterLists',
                    "type": "POST",
                    "data":function(data){ 
                        
                        data.courseid = "<?php echo html_escape($courseid); ?>";                        
                      }
                     }, 
                     "oLanguage": {
                        "sProcessing": "<img src='<?php echo base_url(); ?>images/loader.gif'>"
                    },
                    'iDisplayLength': 20,
                    "columns": columnData,
                    "order": [[ 6, "desc" ]],
                    "fnDrawCallback": function( oSettings ) {
                        
                        
                    }
         }); 
         
       
  
	
	
});
</script>


<div class="wrap dynamic-width" style="float: left;position: relative">
    
    <div style="margin-top: 10px; width: 100%; height: 100px; text-align: right;">
             <span style="font-weight: bold;font-size: 20px;padding: 10px;float:left;color: #364159">Screening Test Results</span>
             <div class="row-element">
                 <span class="title" style="padding: 0px;padding-left: 10px;color: #6F83AA">Screening Test Name</span>                    
                    <span class="content" style="padding: 0px;color:#0332AA;font-weight: bold">
                            <?php echo $coursename;?>
                        </span>
                </div>
             
            </div>         
         <?php echo $this->table->generate();  ?>             
         
        
        
        </div>
    
 
    


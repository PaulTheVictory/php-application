<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Barcodes (<?php echo $bcdetails['barcodefrom'] ?> - <?php echo  $bcdetails['barcodeto'];?>)</title>
<!--<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1">-->

<script src="<?php echo base_url();?>js/jquery-3.5.1.min.js"></script>


<script type="text/javascript">
$(document).ready(function(){
		
	//window.print();

});
</script>

    
 <style type="text/css">
	
	html { margin: 0.5rem}
	table{border: 0px solid #D7DFF0;border-collapse: collapse;table-layout: fixed;width: 100%}
	table td, table th{border-top: 1px solid #D7DFF0;border-bottom: 1px solid #D7DFF0;padding: 1.5rem 1.5rem;color: #364159;font-weight: 600;border-right: 1px dashed #D7DFF0;text-align: center}
	 table tr td:first-child{border-left: 1px solid #D7DFF0;}
	table td{background: #ffffff;}
	

 </style>
 
	</head>
	
	<body>
	
                 
		<h2 style="text-align: center">Generated Barcodes (<?php echo $bcdetails['barcodefrom'] ?> - <?php echo  $bcdetails['barcodeto'];?>)</h2>
                  
               <table width="50%" border="0" cellspacing="0" cellpadding="0">
				  <tbody>
				                                       
            
            <?php 
	
					//print_r($bcdetails);

					$dirname = './docs/barcode/'.$bcdetails['id'].'/';
					$basepath = 'docs/barcode/'.$bcdetails['id'].'/';

					$fileList = glob($dirname.'*');
					
					$count = 1;
				
					$totalbc = count($fileList);
				
					foreach($fileList as $filename){
						
						if(is_file($filename)){
							//echo $filename, '<br>';
						
							$fname = end(explode("/", $filename));
							
							$path = $filename;
							$type = pathinfo($path, PATHINFO_EXTENSION);
							$data = file_get_contents($path);
							$base64 = 'data:image/' . $type . ';base64,' . base64_encode($data);
							
						/*if($count==10){
							$height = '68px';
						}else if($count > 10 && $count % 10 == 0 && $count!=0 && $totalbc!=$count){
							$height = '80px';
						}else{
							$height = '0px';
						}*/
							
							$height = '0px';
				?>     
           
       				<tr>
					  <td width="25%"><img src="<?php echo $base64;?>" alt="Barcode" /></td>
					  <td width="25%"><img src="<?php echo $base64;?>" alt="Barcode" /></td>
					  <td width="25%"><img src="<?php echo $base64;?>" alt="Barcode" /></td>
					  <td width="25%"><img src="<?php echo $base64;?>" alt="Barcode" /></td>
					</tr>
                   				
					  <tr><td colspan="4" style="border: none;padding: 0.5rem">&nbsp;</td></tr>			
                    				
                                                      
                   <?php }  $count++; } ?>      
             
          
        	
				  </tbody>
				</table>
                        
   
	</body>
   
</html>
    
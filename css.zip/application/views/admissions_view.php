<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/dataTables.css?v=1.5" />
<script src="<?php echo base_url(); ?>js/jquery.dataTables.js?v=1.0" type="text/javascript"></script>
<link rel="stylesheet" href="<?php echo base_url();?>css/boot/bootstrap.min.css">
<script src="<?php echo base_url();?>js/bootstrap.bundle.min.js"></script>
 <link href="<?php  echo base_url(); ?>css/jquery-ui.min.css?v=1.4" rel="stylesheet" type="text/css" />
 <script src="<?php  echo base_url(); ?>js/jquery-ui.min.js?v=1.3" type="text/javascript"></script>
<style type="text/css">


.dataTables_wrapper input[type="text"] {
    padding: 0;
}
.dataTables_wrapper select {
    padding: 0;
}

.sortable thead tr  {
    background: #E6EBF7;

/* g8 */
border: 1px solid #D7DFF0;
box-sizing: border-box;
border-radius: 10px 10px 0px 0px;
 

}
.sortable tr th {
    border-right: 0px;
    padding: 15px 0;font-size: 13px;
      color: #6F83AA;
   cursor: pointer;
   text-align: center;

}

.sortable tr th:nth-child(1) {
  width: 50px !important;
}




.sortable tr td {
    border-right: 0px;
    padding: 5px 5px;
    text-align: center;font-size: 13px;
    min-width:50px;vertical-align: middle;
}
.sortable tr td a {
    color: #364159;
}

#profile-right h2 {
    margin: 0px 0px 10px 0px;
}

.studenttable_length { width: auto !important; }
#studenttable_filter input { padding-top:4px;background: #fff url('<?php echo base_url(); ?>/images/search.png') no-repeat center left;background-position-x: 10px;border: 1px solid #D7DFF0; line-height: 32px;margin-left: 10px;width:260px;border-radius: 5px;text-indent: 30px;font-size: 13px;}
.sortable tr td a:hover { text-decoration: underline; }
.dataTables_filter { right:190px !important;}
.ui-selectmenu-button.ui-button{ width: 120px;margin-top: 10px;float: left;border: 1px solid #D7DFF0;background: #fff;font-size: 13px;color:#536485;padding: 5px}

</style>
<script type="text/javascript">
$(document).ready(function(){	
		
	 var commonFlag = "0"; var mtotal = "";
          var columnData = [
                    { "data": "requested_at" , "searchable": false,"bSortable":false},
                    { "data": "studid" },
                    { "data": "sname" },
                     { "data": "mobile" },
                    { "data": "stream" , "searchable": true},       
                    { "data": "yearofpassing" },
                    { "data": "class" },
                    { "data": "grade" },
                     
                    { "data": "id"},
                     { "data": "gracemark" },
                     {"data":"aq1"},
                     {"data":"aq2"},
                     {"data":"aq3"},
                    { "data": "approved" },
                    { "data": "xii_stream" , "searchable": false}   
                    
                    
                  ];
        // columnData.push( {data: "id","visible":true} );
         //columnData.push( {data: "item_name_search","visible":false} );
         
       $("#streamDrop").selectmenu();          
       
        var oTable = $('#studenttable').dataTable({
                    "bProcessing": true,
                    "bServerSide": true,
                    "sPaginationType": "full_numbers",
                    "ajax": {
                    "url": 'admissions/GetAdmissionLists',
                    "type": "POST",
                    "data":function(data){ 
                        
                        var searchVal = $("#streamDrop").val();
                       
                        data.courseid = "<?php echo html_escape($courseid); ?>";
                        data.center = "<?php echo html_escape($center); ?>";
                        data.type = "<?php echo html_escape($type); ?>";
                        data.cflag = commonFlag;
                        data.sval = searchVal;
                        data.mtotal = mtotal;
                                                 
                    }
                    
                     }, 
                     "oLanguage": {
                        "sProcessing": "<img src='<?php echo base_url(); ?>images/loader.gif'>"
                    },
                    'iDisplayLength': 20,
                    "columns": columnData,                    
                    "fnDrawCallback": function( oSettings ) {
                        
                        $("#studenttable").find(".idValue").each(function(){
                            var t = $(this).text();
                            var res = t.toUpperCase(); $(this).text(res);
                          
                            
                        });
                        
                       $("#studenttable").find(".streamVal").each(function(){
                           
                           if(($(this).attr("data-xii-stream") !== "" )&&($(this).attr("data-xii-status") !== "WFR" )&&($(this).attr("data-xii-status") !== "C" ))
                           {
                                  $(this).html($(this).attr("data-xii-stream"));
                                  $("#classtype").val("12");
                                  commonFlag = "1";
                           } else {
                               commonFlag = "2";
                           }
                            
                       });
                       
                       $("#studenttable").find(".yopVal").each(function(){
                           
                           if(($(this).attr("data-xii-yop") !== "" )&&($(this).attr("data-xii-status") !== "WFR" )&&($(this).attr("data-xii-status") !== "C" ))
                           {
                               $(this).html($(this).attr("data-xii-yop"));
                           }
                            
                       });
                       
                       $("#studenttable").find(".classVal").each(function(){
                           
                           if(($(this).attr("data-xii-class") !== "" )&&($(this).attr("data-xii-status") !== "WFR" )&&($(this).attr("data-xii-status") !== "C" ))
                           {
                               $(this).html($(this).attr("data-xii-class"));
                           }
                            
                       });
                       
                       
                       $("#studenttable").find(".graceVal").each(function(){
                           
                           if($(this).attr("data-xii-gracemark") !== "" )
                           {
                               $(this).html($(this).attr("data-xii-gracemark"));
                           }
                           
                           var t=$(this).html();
                           if(t === 'y') { $(this).html("Yes");}
                           if((t === 'n')||(t === '')) { $(this).html("No");}
                            
                       });
                        
                       $("#studenttable").find(".markVal").each(function(){
                           
                           if(($(this).attr("data-xii-mark") !== "")  && ($(this).attr("data-xii-status") !== "WFR") && ($(this).attr("data-xii-status") !== "C"))
                           {
                               var datamark = $(this).attr("data-xii-mark");
                               datamark = datamark.substring(1, datamark.length);
                               var res = datamark.replaceAll("|", "&emsp;&ensp;");
                               $(this).html(res);
                               
                               var totalArr = datamark.split("|"); var totalMark = 0;
                               for(var i = 0 ; i < totalArr.length;i++){
                                   if(totalArr[i] === "") { continue;}
                                   totalMark += parseFloat(totalArr[i]);
                               }
                               
                               $(this).closest("tr").find(".ctotal").text(totalMark);
                           } else if(($(this).attr("data-xii-grade") !== "") && ($(this).attr("data-xii-mark") === "") && ($(this).attr("data-xii-status") !== "WFR")&& ($(this).attr("data-xii-status") !== "C"))
                           {
                               var datamark = $(this).attr("data-xii-grade");
                               datamark = datamark.substring(1, datamark.length);
                               var res = datamark.replaceAll("|", "&emsp;&ensp;");
                               var resValue=0;
                               var resArr = datamark.split("|");
                               var gradeValArr = {};
                               gradeValArr["A+"] = '9'; gradeValArr["A"] = '8';
                               gradeValArr["B+"] = '7'; gradeValArr["B"] = '6';
                               gradeValArr["C+"] = '5'; gradeValArr["C"] = '4';
                               gradeValArr["D+"] = '3'; gradeValArr["D"] = '2';
                               
                               for(var i = 0 ; i < resArr.length;i++){
                                   if(resArr[i] === "") { continue;}
                                   resValue += parseFloat(gradeValArr[resArr[i]]);
                               }
                               
                               $(this).html(res);
                               $(this).closest("tr").find(".ctotal").text(resValue);
                               
                           }  else if($(this).attr("data-grade") !== "") 
                           {
                               var datamark = $(this).attr("data-grade");
                               datamark = datamark.substring(1, datamark.length);
                               var res = datamark.replaceAll("|", "&emsp;&ensp;");
                               $(this).html(res);
                               
                               var resValue=0;
                               var resArr = datamark.split("|");
                               var gradeValArr = {};
                               gradeValArr["A+"] = '9'; gradeValArr["A"] = '8';
                               gradeValArr["B+"] = '7'; gradeValArr["B"] = '6';
                               gradeValArr["C+"] = '5'; gradeValArr["C"] = '4';
                               gradeValArr["D+"] = '3'; gradeValArr["D"] = '2';
                               
                               for(var i = 0 ; i < resArr.length;i++){
                                   if(resArr[i] === "") { continue;}
                                   resValue += parseFloat(gradeValArr[resArr[i]]);
                               }
                               
                               $(this).closest("tr").find(".ctotal").text(resValue);
                          
                               
                           }  else if($(this).attr("data-mark") !== "")
                           {
                               var datamark = $(this).attr("data-mark");
                               datamark = datamark.substring(1, datamark.length);
                               var res = datamark.replaceAll("|", "&emsp;&ensp;");
                               $(this).html(res);
                               
                               var totalArr = datamark.split("|"); var totalMark = 0;
                               for(var i = 0 ; i < totalArr.length;i++){
                                   if(totalArr[i] === "") { continue;}
                                   totalMark += parseFloat(totalArr[i]);
                               }
                               
                               $(this).closest("tr").find(".ctotal").text(totalMark);
                               
                           } 
                       }); 
                    
                        
                        $(".cstatus").each(function(){
                             
                             var yu = $(this).text();
                             if(yu === 'y') { $(this).html('<p style="margin:0px;background:#3CAF92;padding:5px;color:#fff;width: 70px;border-radius: 5px;font-size:11px">Approved</p>'); }
                             
                             if(yu === 'w') { $(this).html('<p style="margin:0px;background:#F48D25;padding:5px;color:#fff;width: 70px;border-radius: 5px;;font-size:11px">Waiting list</p>'); }
                             
                             if(yu === 'n') { $(this).html('<p style="margin:0px;background:#ED5252;padding:5px;color:#fff;width: 70px;border-radius: 5px;;font-size:11px">Applied - NQ</p>'); }
                             
                             if(yu === 'q') { $(this).html('<p style="margin:0px;background:#B06315;padding:5px;color:#fff;width: 70px;border-radius: 5px;font-size:11px">Applied</p>'); }
                             
                             if(yu === 'd') { $(this).html('<p style="margin:0px;background:#ED5252;padding:5px;color:#fff;width: 70px;border-radius: 5px;;font-size:11px">Denied</p>'); }
                             
                             if(yu === '') { $(this).html('<p style="margin:0px;background:#ED5252;padding:5px;color:#fff;width: 70px;border-radius: 5px;;font-size:11px">Applied - Confirmation Pending</p>'); }
							
							if(yu === 's') { $(this).html('<p style="margin:0px;background:#F48D25;padding:5px;color:#fff;width: 70px;border-radius: 5px;;font-size:11px">Shortlist</p>'); }
                             
                         }); 
                        
                  
                         $("#studenttable").find(".del").each(function(){

                            $(this).click(function(){ 

                              if(confirm("Are you sure to delete this item ?")) {
                                    var ide = $(this).attr("id");
                                     $.get('admissions/DeleteRequest',{
                                                               'ide':ide

                                                    }, function(o) { 
                                                            var obj1 = $.parseJSON(o);
                                                    if (obj1[0] === 'success') {
                                                        alert("Success!!! Course Request Deleted");
                                                        oTable.fnDraw(); 
                                                    } else if (obj1[0] === 'fail') {
                                                        alert("Error!!! please try again");
                                                }
                                    });
                                }

                              });
                        

                          });
                          
                    }
         }); 
         
               
            $(document).delegate("#streamDrop","selectmenuchange",function(event){
                
                oTable.fnDraw();
            });
            
            $("#markSearch").click(function(){
               mtotal = $("#markTotal").val(); 
               mtotal = (mtotal === "")?0:mtotal;
               oTable.fnDraw();
            });
            
            
            $("#markExport").click(function(){
               
               var url = 'admissions/export?courseid=<?php echo $courseid; ?>&type=<?php echo $type; ?>&center=<?php echo $center; ?>';
               $(location).prop('href', url);
               
            });
            
            
        var chkbox = $('<input class="gchkbox" style="margin-left:17px;float:left;padding:5px;" type="checkbox"/>');
         
        $('#studenttable').find("th").first().append(chkbox);
        $('#studenttable').find("th").first().css("width","50px");
        $(chkbox).click(function(e){
           
            if($(this).is(":checked")){

                $('#studenttable').find(".crequest").each(function(){
                    $(this).prop( "checked", true );
                });

            } else {
                $('#studenttable').find(".crequest").each(function(){
                    $(this).prop( "checked", false );
                });
            }
           
        });
            
         $(".dropdown-item").click(function(){
         var ide =''; var type = $(this).attr("data-attr");
           $(".crequest").each(function(){
               
               if($(this).is(":checked")) { ide += $(this).val()+"|";}
                
           });
         
          if(ide === '') { alert('select any course request to approve'); return;}
            $.get('admissions/ApproveRequest',{
                                                                'ide':ide,'type':type

                                                     }, function(o) { 
                                                             var obj1 = $.parseJSON(o);
                                                     if (obj1[0] === 'success') {
                                                         alert("Success!!! Request Approved");
                                                         oTable.fnDraw(); 
                                                     } else if (obj1[0] === 'fail') {
                                                         alert("Error!!! please try again");
                                                 }
                                     });
         
         });
  
  

	
});
</script>


<div class="wrap dynamic-width" style="float: left;position: relative">
    
    <div style="margin-top: 10px; width: 100%; height: 190px; text-align: right;">
             <span style="font-weight: bold;font-size: 20px;padding: 10px;float:left;color: #364159">Admission Requests</span>
             <div class="row-element">
                 <span class="title" style="padding: 0px;padding-left: 10px;color: #6F83AA">Course Name</span>                    
                    <span class="content" style="padding: 0px;color:#0332AA;font-weight: bold">
                            <?php echo $coursename;?>
                        </span>
                </div>
             <div class="row-element">
                    <span class="title" style="padding: 0px;padding-left: 10px;color: #6F83AA">Location</span>                    
                    <span class="content" style="padding: 0px;color:#0332AA;font-weight: bold"><?php echo $center;?></span>
                    <input id="classtype" type="hidden" value="10">
                </div>
             <div class="row-element" style="margin-top:6px;">
                 <div style="float:left; width: auto; height: auto; text-align: left;">
                     <select id="streamDrop" style="width: 100px">
                         <option value="">Select Stream</option>
                         <option>CBSE</option>
                         <option>HSC</option>
                         <option>SSLC/THSLC</option>
                         <option>ICSE</option>
                         <option>ISC</option>
                         <option>OTHERS</option>
                     </select>
                 </div>
                 <div style="float: left;width: auto;height: auto;text-align: left;margin-left: 50px;margin-top: 10px;">
                     <input placeholder="Total Mark Greater Than" style="width: 170px;padding: 5px;height: auto;" type="text" id="markTotal"/>
                     <span id="markSearch" style="cursor: pointer;margin-left:20px;font-weight: bold;font-size: 14px;padding: 5px 10px;color: #fff;border-radius:5px;background: linear-gradient(180deg, #4F70C4 0%, #1C47B3 100%);">Search</span>
                     
                      <?php if(isset($roleaccess['Export'][3]) && $roleaccess['Export'][3]=="y"){ ?>
                     	<span id="markExport" style="cursor: pointer;margin-left:20px;font-weight: bold;font-size: 14px;padding: 5px 10px;color: #fff;border-radius:5px;background: linear-gradient(180deg, #4F70C4 0%, #1C47B3 100%);">Export</span>
                      <?php } ?>
                      
                 </div>
                 
                  <?php if(isset($roleaccess['Change Request'][3]) && $roleaccess['Change Request'][3]=="y"){ ?>
                  
             <button style="font-size: 14px;padding: 10px;  color: #fff; margin: 0px auto; position: relative; border-radius:5px;background: linear-gradient(180deg, #4F70C4 0%, #1C47B3 100%);" class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" >Change Request</button>
              <div class="dropdown-menu">
                  <a class="dropdown-item" data-attr="q" href="#">Applied</a> 
                  <a class="dropdown-item" data-attr="w" href="#">Waiting List</a>
                  <a class="dropdown-item" data-attr="y" href="#">Approved</a>
                  <a class="dropdown-item" data-attr="s" href="#">Shortlist</a>
                  <a class="dropdown-item" data-attr="d" href="#">Reject</a>
             </div>  
             
              <?php } ?>                                                                                                                            
    </div>    
             
         <?php echo $this->table->generate();  ?>             
         
        
        
        </div>
    
 
    


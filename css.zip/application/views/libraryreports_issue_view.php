<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/dataTables.css?v=1.5" />
<script src="<?php echo base_url(); ?>js/jquery.dataTables.js?v=1.0" type="text/javascript"></script>
<link rel="stylesheet" href="<?php echo base_url();?>css/boot/bootstrap.min.css">
<script src="<?php echo base_url();?>js/bootstrap.bundle.min.js"></script>
<style type="text/css">


.dataTables_wrapper input[type="text"] {
    padding: 0;
}
.dataTables_wrapper select {
    padding: 0;
}

.sortable thead tr  {
    background: #E6EBF7;

/* g8 */
border: 1px solid #D7DFF0;
box-sizing: border-box;
border-radius: 10px 10px 0px 0px;
 

}
.sortable tr th {
    border-right: 0px;
    padding: 15px 0;font-size: 13px;
      color: #6F83AA;
   cursor: pointer;
   text-align: center;

}


.sortable tr td {
    border-right: 0px;
    padding: 5px 5px;
    text-align: center;font-size: 13px;
    min-width:50px;vertical-align: middle;
}
.sortable tr td a {
    color: #364159;
}

#profile-right h2 {
    margin: 0px 0px 10px 0px;
}

.librarytable_length { width: auto !important; }
#librarytable_filter input { padding-top:4px;background: #fff url('<?php echo base_url(); ?>/images/search.png') no-repeat center left;background-position-x: 10px;border: 1px solid #D7DFF0; line-height: 32px;margin-left: 10px;width:260px;border-radius: 5px;text-indent: 30px;font-size: 13px;}
.sortable tr td a:hover { text-decoration: underline; }
.dataTables_filter { right:10px !important;}

.row-element { margin:0px !important;}
</style>
<script type="text/javascript">
$(document).ready(function(){	
		
	
          var columnData = [
              
                    { "data": "created_at" , "searchable": false},            
                    { "data": "barcode" }, 
                    { "data": "issued" }
                   
                  ];
       
        var oTable = $('#librarytable').dataTable({
                    "bProcessing": true,
                    "bServerSide": true,
                    "sPaginationType": "full_numbers",
                    "ajax": {
                    "url": 'libraryreports/GetIssuedStocks',
                    "type": "POST",
                    "data":function(data){ 
                            data.bookid= '<?php echo $bookid;?>',   
                             data.center= '<?php echo $location;?>';
                      }
                     }, 
                     "oLanguage": {
                        "sProcessing": "<img src='<?php echo base_url(); ?>images/loader.gif'>"
                    },
                    'iDisplayLength': 20,
                    "columns": columnData,
                    "order": [[ 1 ,"desc" ]],
                    "fnDrawCallback": function( oSettings ) {
                        
                        var count = 1;
						
                         $('#librarytable').find("tr .sno").each(function(){                           
                            $(this).text(count);
                            count++;
                            
                            var issued = $(this).closest("tr").find(".issued").text();
                            if(issued === "") { $(this).closest("tr").find(".issued").text("n");}
                         });
                    }
         }); 
         
       $(".export").click(function(){
               
               var url = 'libraryreports/export?center=<?php echo $location; ?>&bookid=<?php echo $bookid; ?>';
               $(location).prop('href', url);
               
            });
  
	
	
});
</script>


<div class="wrap dynamic-width" style="float: left;position: relative">
    
    <div style="margin-top: 10px; width: 100%; height: 150px; text-align: right;">
             <span style="font-weight: bold;font-size: 20px;padding: 10px;float:left;color: #364159">Library Stock Reports</span>
             <div class="row-element">
                 <span class="title" style="padding: 0px;padding-left: 10px;color: #6F83AA">Bank Name</span>                    
                    <span class="content" style="padding: 0px;color:#0332AA;font-weight: bold">
                            <?php echo $bname['bookname'];?>
                        </span>
                </div>
             <div class="row-element">
                 <span class="title" style="padding: 0px;padding-left: 10px;color: #6F83AA">Location</span>                    
                    <span class="content" style="padding: 0px;color:#0332AA;font-weight: bold">
                            <?php echo $location;?>
                        </span>
                </div>
             <div class="row-element">
                 <span class="title" style="padding: 0px;padding-left: 10px;color: #6F83AA">
                     <button style="font-size: 14px;padding: 6px;  color: #fff; margin: 0px auto; border-radius:5px;background: linear-gradient(180deg, #4F70C4 0%, #1C47B3 100%);" class="btn btn-primary export" type="button"  aria-haspopup="true" aria-expanded="false" >Export</button>
                 </span>   
                        
                </div>
             
             <div class="row-element">
                 <span class="title" style="padding: 0px;padding-left: 10px;color: #6F83AA">
                     <button style="font-size: 14px;padding: 6px;  color: #fff; margin: 0px auto; border-radius:5px;background: linear-gradient(180deg, #4F70C4 0%, #1C47B3 100%);" class="btn btn-primary export" type="button"  aria-haspopup="true" aria-expanded="false" >Export</button>
                 </span>   
                        
                </div>
             
            </div>         
         <?php echo $this->table->generate();  ?>             
         
        
        
        </div>
    
 
    


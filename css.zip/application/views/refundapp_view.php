<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Brilliant Study Centre, Pala</title>
<!--<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1">-->

<link rel="stylesheet" href="<?php echo base_url();?>css/boot/bootstrap.min.css">
<link rel="stylesheet" href="<?php echo base_url();?>css/boot/bootstrap.rtl.only.min.css">
<link rel="stylesheet" href="<?php echo base_url();?>css/boot/bootstrap-float-label.min.css">
<link rel="stylesheet" href="<?php echo base_url();?>css/boot/main.css">
<!--<link rel="stylesheet" href="<?php //echo base_url();?>css/boot/styles.css">-->

<script src="<?php echo base_url();?>js/jquery-3.5.1.min.js"></script>


<script type="text/javascript">
$(document).ready(function(){
	
	window.print();

});
</script>

<style>

body {
  -webkit-print-color-adjust: exact !important;
}
.refundrow{font-family: Segoe UI;border-collapse: collapse;margin: auto;font-size: 14px;background: #ffffff;padding: 0rem}
.refund{table-layout:fixed;font-family: Segoe UI;border:1px solid #BCCAE8;border-collapse: collapse;max-width: 100%;margin: auto;font-size: 16px;background: #ffffff;}
.refund th{text-align: left}
.refund th,.refund td{border: 2px solid #BCCAE8;padding: 0.4rem 1rem;width: auto}
.refund p span{font-size: 16px;color: #181E29;}
.refund p span:first-child{width: 35%;font-weight: normal;}
.refund p span:last-child{width: 65%;font-weight: bold;}
table.refund tr.lastrow td{padding: 0.7rem 1rem;border: none}
.refund td.totalamt{padding: 0.5rem 1rem;}
.refund td.totalamt strong{margin-left: 3rem;color: #D63333;font-size: 16px;}

.copy{max-width: 100%;margin: auto;color: #181E29;font-size: 14px;font-style: italic;font-family: Segoe UI;font-weight: 600;margin-bottom: 1rem}
	
.refund td table{font-family: Segoe UI;border: 0.75px solid #D7DFF0;border-collapse: collapse;width: 100%;margin: 1rem 0 1rem 0rem;border-style: hidden;border-radius: 5px; box-shadow: 0 0 0 0px #D7DFF0;font-size:14px;border-collapse: separate !important;border-style: solid;border-radius: 10px;box-shadow: 0 0 0 0px #364159;margin: 1rem auto; table-layout: fixed;border-spacing: 0px;}

.refund td th{font-weight: 600;color: #536485;background: #E6EBF7;border: 1px solid #D7DFF0;border-width: 0px 0px 1px 0px;text-align: center}
.refund td td{border: 1px solid #D7DFF0;border-width: 0px 0px 1px 0px;text-align: center;width: 50%}

.barcode{margin: 4.5rem auto 1rem;width: 45%}
.upi{margin: auto;display: block}

.refund td table tr:last-child td:first-child {border-bottom-left-radius: 10px;}
.refund td table tr:last-child td:last-child {border-bottom-right-radius: 10px;}
	
	.refund > tr td:first-child{border: 1px solid #D7DFF0;border-width: 0px 0xp 0px 1px}

/*.table{border-collapse: separate !important;border-style: solid;border-radius: 10px;datetable : 0 0 0 0px #364159;margin: 1rem; table-layout: fixed;border-spacing: 0px;}
.table {
    border: 1px solid #364159;
    -moz-border-radius: 10px;
    -webkit-border-radius: 10px;
    border-radius: 10px;
}
.table td, .table th {
    border-left: 0px solid #364159;
    border-top: 1px solid #364159;
    padding: 10px;
    text-align: left;
}
.table tr th:first-child{border-top: 1px solid #364159;border-radius: 0px}
.table th {
    background-color: transparent;
    border-top: none;
}
.table td:first-child, .table th:first-child {
    border-left: none;
}
.table th:first-child {
    -moz-border-radius: 10px 0 0 0;
    -webkit-border-radius: 10px 0 0 0;
    border-radius: 10px 0 0 0;
}
.table th:last-child {
    -moz-border-radius: 0 10px 0 0;
    -webkit-border-radius: 0 10px 0 0;
    border-radius: 0 10px 0 0;
}
.table th:only-child{
    -moz-border-radius: 10px 10px 0 0;
    -webkit-border-radius: 10px 10px 0 0;
    border-radius: 10px 10px 0 0;
}
.table tr:last-child td:first-child {
    -moz-border-radius: 0 0 0 10px;
    -webkit-border-radius: 0 0 0 10px;
    border-radius: 0 0 0 10px;
}
.table tr:last-child td:last-child {
    -moz-border-radius: 0 0 10px 0;
    -webkit-border-radius: 0 0 10px 0;
    border-radius: 0 0 10px 0;
}*/	
	
.v-bottom{vertical-align: bottom}
	
.xswidth p,.smwidth p{display: flex;margin: 5px auto}
.xswidth p span:first-child{width: 17%;font-weight: bold;}
.xswidth p span:last-child{width: 85%;font-weight: normal;}
	
.smwidth p span:first-child{width: 25%;font-weight: bold;}
.smwidth p span:last-child{width: 75%;font-weight: normal;}
	
	.refund td table.datetable td{width: 15%;border-width: 0px 0px 1px 1px;}
	.refund td table.datetable th:first-child{border: none;border-top-left-radius: 10px}
	.refund td table.datetable th:last-child{border-top-right-radius: 10px}
	.refund td table.datetable td:first-child{border-left: 0px;}
	.refund td table.datetable tr:last-child td{border-bottom: 0px;}
	.refund td table.datetable th{border-width: 0px 0px 1px 1px;}
	
	
	.refund td table.feeremit th,.refund td table.feeremit td{width: 20%}
	.refund td table.feeremit td{padding: 0.3rem 1rem;border-width: 0px 0px 1px 1px;}
	.refund td table.feeremit th{border-width: 0px 0px 1px 1px;}
	
	.refund td table.feeremit th:first-child{border: none;border-top-left-radius: 10px}
	.refund td table.feeremit th:last-child{border-top-right-radius: 10px}
	.refund td table.feeremit td:first-child{border-left: 0px;}
	.refund td table.feeremit tr:last-child td{border-bottom: 0px;}
	
	.refund td table.refundamt tr:first-child th{border-top-left-radius: 10px}
	.refund td table.refundamt tr:last-child th{border-bottom-left-radius: 10px}
	.refund td table.refundamt td:first-child{border-left: 0px;}
	.refund td table.refundamt tr:last-child th,.refund td table.refundamt tr:last-child td{border-bottom: 0px;}
		
</style>


<main style="margin:  0px auto !important">

	<div class="container-fluid">
		
		<div class="col-12 mb-4 myprofile">
                   
			
   <div class="refundrow">

	<table width="100%" border="0" cellspacing="0" cellpadding="0" class="refund">
	  <tbody>
		<tr>
		
			<th scope="col" colspan="2">
		
				<div class="row">
					<div class="col-6">
                                            <h1  style="font-size:1.5rem;font-weight:bold">Refund Application</h1>
						<p>Application Number : <strong><?php echo $appno;?></strong></p>
					</div>
					<div class="col-6 text-right">
						<img src="css/img/brilliant-logo.png" alt="" />
					</div>
				</div>
		  	
			</th>
			
		</tr>
		<tr>
		  <td style="width: 25%"><strong>Name of the student <br/>(In BLOCK Letters)</strong></td>
                  <td><strong><?php echo strtoupper($sname);?></strong></td>
		</tr>
		<tr>
		  <td><strong>Name of the parent / Guardian</strong></td>
		  <td><strong><?php echo $guardianname;?></strong></td>
		</tr>
		<tr>
		  <td colspan="2">
		  
		  	<div class="row xswidth">
				<div class="col-6">
					<p><span>User ID:</span> <span><?php echo $userid;?> </span></p>
					<p><span>Course:</span> <span><?php echo $coursename;?> </span></p>
				</div>
				<div class="col-6">
					<p><span>Batch:</span> <span><?php echo $batch;?> </span></p>
					<p><span>Centre:</span> <span><?php echo $center;?> </span></p>
				</div>
                            <div class="col-6">
					<p><span>Date Of Joining:</span> <span> <?php echo $doj;?></span></p>
					
				</div>
		  	</div>
		  	
		  </td>
		</tr>
		<tr>
		  <td>
		  	<strong>Communication Address with pincode</strong>
		  </td>
		   <td>
		  	<span> <?php echo $caddress;?></span>
		  </td>
		</tr>
		<tr>
		  <td><strong>Mob. No.</strong></td>
		  <td>
		  
		  	<div class="row">
				<div class="col-6">
					<p>1) <?php echo $mobileno;?></p>
				</div>
				<div class="col-6">
					<p>2) <?php echo $fmobile;?></p>
				</div>
		  	</div>
		  	
		  </td>
		</tr>
		<tr>
		  <td colspan="2">
                      <strong>Total Amount Remitted : </strong> <strong >__________________________</strong> (including GST & CD)
		  </td>
		</tr>
		<tr>
		  <td>
		  	<strong>Date of submission of application for refund</strong>
		  </td>
		  <td>
			  <table style="width:100%" class="datetable">
			  <tr>
				<th>Date</th>
				<th>Month</th>
				<th>Year</th>
			  </tr>
			  <tr>
				<td><?php $time=strtotime($rdate); echo date("d",$time);?></td>				
				<td><?php echo date("F",$time); ?></td>
				<td><?php echo date("Y",$time); ?></td>
				
			  </tr>
			</table>
		  </td>
		</tr>
		<tr valign="top">
			<td colspan="2">
				<p><strong>Reason for refund request:-</strong> <?php echo $reason;?></p>
				
			</td>
		</tr>
		<tr valign="top">
			<td  class="smwidth">
				<h3 style="font-size:1.5rem"><strong><u>Account Details</u></strong></h3>
				<!--p><span>Account Holder Name:</span> <span><?php //echo $accountholdername;?></span></p-->
				<p><span>Bank Name:</span> <span><?php echo $bankname;?></span></p>
				<p><span>Branch:</span> <span><?php echo $branch;?></span></p>
				
			</td>
                        
                        <td  class="smwidth">
                            <p><span>IFSC:</span> <span><?php echo $ifsccode;?></span></p>
				<p><span>Account No.:</span> <span><?php echo $bankaccountno;?></span></p>
                        </td>
		</tr>
				
		<tr>
		  <td colspan="2">
                      <h2 class="text-center my-3" style="font-size:1rem"><strong>FOR OFFICE USE ONLY</strong></h2>
			  <p class="my-3">Date of receipt of refund application ......................................................... Signature of Officer in Charge ......................................................... </p>
		  </td>
		</tr>
	  
	  	<tr valign="top">
		  <td style="width: 50%">
			 
			 <div class="row">
				<div class="col-9">
					<p><strong>No. of Class days/periods upto the date of submission of refund application</strong></p>
				</div>
				<div class="col-3">
					<p class="border h-75 w-100 mt-2"></p>
				</div>
		  	</div>
		  	
			  <div class="border-bottom my-3"></div>
		  	
			  <h4 class="text-center my-2" style="font-size:1rem"><strong>Fee Remitted</strong></h4>
			  
			  <table width="100%" border="0" cellspacing="0" cellpadding="0" class="feeremit">
			  <tbody>
				<tr>
				  <th scope="col" width="20%">Rt. No.</th>
				  <th scope="col" width="20%">Date</th>
				  <th scope="col" width="20%">Amount</th>
				  <th scope="col" width="20%">GST</th>
				  <th scope="col" width="20%">Total</th>
				</tr>
				<tr>
				  <td>&nbsp;</td>
				  <td>&nbsp;</td>
				  <td>&nbsp;</td>
				  <td>&nbsp;</td>
				  <td>&nbsp;</td>
				</tr>
				<tr>
				  <td>&nbsp;</td>
				  <td>&nbsp;</td>
				  <td>&nbsp;</td>
				  <td>&nbsp;</td>
				  <td>&nbsp;</td>
				</tr>
				<tr>
				  <td>&nbsp;</td>
				  <td>&nbsp;</td>
				  <td>&nbsp;</td>
				  <td>&nbsp;</td>
				  <td>&nbsp;</td>
				</tr>
				<tr>
				  <td>&nbsp;</td>
				  <td>&nbsp;</td>
				  <td>&nbsp;</td>
				  <td>&nbsp;</td>
				  <td>&nbsp;</td>
				</tr>
				<tr>
				  <td>CD</td>
				  <td>&nbsp;</td>
				  <td>&nbsp;</td>
				  <td>&nbsp;</td>
				  <td>&nbsp;</td>
				</tr>
				<tr>
				  <td>Grand Total</td>
				  <td>&nbsp;</td>
				  <td>&nbsp;</td>
				  <td>&nbsp;</td>
				  <td>&nbsp;</td>
				</tr>
				<tr>
				  <td>&nbsp;</td>
				  <td>&nbsp;</td>
				  <td>&nbsp;</td>
				  <td>&nbsp;</td>
				  <td>&nbsp;</td>
				</tr>
			  </tbody>
			</table>
		  	
		  	<div class="row mt-4 mb-2">
				<div class="col-7">
					<p><strong>Entered by</strong></p>
				</div>
				<div class="col-5">
					<p><strong>Checked by</strong></p>
				</div>
		  	</div>

		  	
		  </td>
		  
		  <td style="width: 50%">
		  
			  <h4 class="text-center my-2" style="font-size:1rem"><strong>Refund Amount</strong></h4>
			  
			  <div class="row">
				<div class="col-6">
				
					<p class="text-center"><strong>Deductions</strong></p>
					
					<table width="100%" border="0" cellspacing="0" cellpadding="0" class="refundamt">
					  <tbody>
						<tr>
						  <th scope="row">Course Fee + GST</th>
						  <td>&nbsp;</td>
						</tr>
						<tr>
						  <th scope="row">Any other
					Deduction</th>
						  <td>&nbsp;</td>
						</tr>
						<tr>
						  <th scope="row">Total
					Deduction</th>
						  <td>&nbsp;</td>
						</tr>
					  </tbody>
					</table>

				</div>
				<div class="col-6">
				
					<p class="text-center"><strong>Balance Amount</strong></p>
					
					<table width="100%" border="0" cellspacing="0" cellpadding="0" class="refundamt">
					  <tbody>
						<tr>
						  <th scope="row">Fee</th>
						  <td>&nbsp;</td>
						</tr>
						<tr>
						  <th scope="row">GST</th>
						  <td>&nbsp;</td>
						</tr>
						<tr>
						  <th scope="row">CD</th>
						  <td>&nbsp;</td>
						</tr>
						<tr>
						  <th scope="row">Total</th>
						  <td>&nbsp;</td>
						</tr>
					  </tbody>
					</table>
					
				</div>
		  	</div>
		  	
		  	<div class="row mt-3">
				<div class="col-7">
					<p>Entered in ERP </p>
                                        <p>Date : ..........................</p> 
				</div>
				<div class="col-5">
					<p>Mode Of Payment : .......................................</p>
                                        <p>Ref no : ......................................</p>
				</div>
		  	</div>
			 
		  	
			  <p>Rs...........................................................................................</p>
		  	
		  	<div class="row mt-3">
				<div class="col-7">
					<p><strong>Calculated by</strong></p>
				</div>
				<div class="col-5">
					<p><strong>Verified by</strong></p>
				</div>
		  	</div>
		  	
			 
		  </td>
		  
		</tr>
		
		
	  </tbody>
	</table>
	

</div>
                	
		
	</div>
            
            <div class="col-12 mb-4 mypassbook">
                
                <?php
                 
                 $dirname = 'docs/refund/'.$studentid.'/';
                 $fileName1 = $ide.".jpg"; $fileName2 = $ide.".jpeg"; $fileName3 = $ide.".png";
                 $destinationfull1 = $dirname . $fileName1;$destinationfull2 = $dirname . $fileName2;
                 $destinationfull3 = $dirname . $fileName3;
               
                 if(file_exists($destinationfull1)){                     
                     echo '<div class="col-12"><img class="img-fluid border-radius" src="'.$destinationfull1.'"></div>';                     
                 }else if(file_exists($destinationfull2)){                     
                     echo '<div class="col-12"><img class="img-fluid border-radius" src="'.$destinationfull2.'"></div>';                     
                 }else if(file_exists($destinationfull3)){                     
                     echo '<div class="col-12"><img class="img-fluid border-radius" src="'.$destinationfull3.'"></div>';                     
                 }
                
                ?>
                
                
                
            </div>


	</div>
</main>
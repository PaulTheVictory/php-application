 <link href="<?php  echo base_url(); ?>css/jquery-ui.min.css?v=1.4" rel="stylesheet" type="text/css" />
 <link href="<?php  echo base_url(); ?>css/chosen.min.css?v=1.3" rel="stylesheet" type="text/css" />
  <link href="<?php  echo base_url(); ?>css/jquery-te-1.4.0.css?v=1.52" rel="stylesheet" type="text/css" />
 <script src="<?php  echo base_url(); ?>js/jquery-ui.min.js?v=1.3" type="text/javascript"></script>
  <script src="<?php  echo base_url(); ?>js/chosen.jquery.min.js?v=1.2" type="text/javascript"></script>
    <script src="<?php  echo base_url(); ?>js/jquery-te-1.4.0.min.js" type="text/javascript"></script>

 <style type="text/css">
     
     .ui-selectmenu-button.ui-button{ width: 97%; padding:13px;}
     #duration-button,#modeofexam-button,#examtimefreq-button,#subcriteria-button,#rule-button,#maincriteria-button,#stream-button,#coursetype-button,#accounthead-button{border: 1px solid #D7DFF0;background: #fff;font-size: 14px;color:#536485}
     #centers_chosen  {border: 1px solid #D7DFF0;background: #fff;padding: 8px 0px;}
     .chosen-container-multi .chosen-choices {border: 0px;background: none}
     .maincontent ul li.search-choice { height:auto; }
     .maincontent ul li.search-choice a{ height:auto; font-size: 14px;color:#536485}
     .chosen-container-multi .chosen-choices li.search-choice { background: #6884CC;border-radius: 5px;}
     .chosen-container-multi .chosen-choices li.search-choice {color: #fff;}
     .response p { float: right;font-size:12px;color:#eb345e;}
 </style>

	<div class="wrap dynamic-width" style="float: left;position: relative;min-width: 800px">
     <div style="margin-top: 10px; width: 99%; height: 50px; text-align: right;">
         <span style="font-weight: bold;font-size: 20px;padding: 10px;float:left;color: #364159">Add Course</span>
         <a class="addpay" style="display:none;padding: 10px;  color: #fff; margin: 0px auto; background: linear-gradient(180deg, #4F70C4 0%, #1C47B3 100%); position: relative; top: 5px;border-radius:5px;font-size: 14px" class="btn" href="<?php echo base_url(); ?>addpayment"><span style="position: relative;top:4px"><img  src="<?php echo $this->config->item('web_url') ?>images/addcourse.png" alt="Navigation" /></span><span style="margin-left:5px">Add Payment</span></a>
     </div>         
            <div id="course-container" class="add-course">
<?php echo form_open('addcourse/courseSubmit', array('id' => 'courseForm')) ?>
                <div class="row-element">
                    <span class="title">Course Name</span>
                    <span class="content"><input type="text" value="" name = "cname" class="name"></span>
                </div>
                
                <div class="row-element">
                    <span class="title">ID Card Display Name</span>
                    <span class="content">
                        <input type="text" name="idcard_displayname" class="idcard_displayname" maxlength="20">
                    </span>
                </div>
                
                <div class="row-element">
                    <span class="title" >Course Stream</span>
                    <span class="content">
                        <select id="stream" name = "stream" class="duration" style="font-size: 13px;float:left">
                           <option value="">Select Course Stream</option>
                            <option>MEDICAL</option>
                            <option>ENGINEERING</option>
                            <option>FOUNDATION</option>
                            <option>SCREENING TEST</option>
                            <option>SCHOOL PLUS</option>
                        </select>
                                              
                    </span>
                </div>
                
                <div class="row-element">
                    <span class="title" >Course Type</span>
                    <span class="content">
                        <select id="coursetype" name = "coursetype" class="duration" style="font-size: 13px;float:left">
                           <option value="">Select Course Type</option>
                            <option>REPEATER</option>
                            <option>RESIDENTIAL</option>
                            <option>LONG TERM</option>
                            <option>SPECIAL</option>
                            <option>HYBRID</option>
                            <option>PREFOUNDATION</option>
                            <option>IIT/AIMS</option>
                            <option>FOUNDATION</option>
                        </select>
                                              
                    </span>
                </div>
                
                <div class="row-element">
                    <span class="title" >Accounting Head</span>
                    <span class="content">
                        <select id="accounthead" name = "accounthead" class="duration" style="font-size: 13px;float:left">
                           <option value="">Select Accounting Head</option>
                            <?php echo $ahselectoptions;?>
                        </select>
                                              
                    </span>
                </div>
                
                <div class="row-element">
                    <span class="title">Screening Test</span>                    
                    <span class="content">
                        <label style="text-align: left;min-width: 150px;color:#536485;background: none;border: 0px;width: auto;height: auto;float:left;font-size: 14px;font-weight: normal"><input type="checkbox" name = "stest"   class="stest chkbox" style="margin: 5px;"></label>
                    </span>
                </div>
                <div class="row-element">
                    <span class="title">Duration</span>
                    <span class="content">
                        
                        
                        <label style="color:#536485;background: none;border: 0px;width: 48%;height: auto;float:left;">
                            <input placeholder="Enter Value" type="text" name = "duration" class="advalue" style="margin: 5px;background: #fff ">
                         </label>
                        <label style="color:#536485;background: none;border: 0px;width: 4%;height: 20px;float:left;">&nbsp;</label>
                        <label style="color:#536485;background: none;border: 0px;width: 48%;height: auto;float:left;">
                        <select id="duration" name = "durationfreq" class="duration" style="font-size: 13px;float:left">
                            <option value="" >Select Duration</option>
                            <option>Month</option>
                            <option>Year</option>
                            <option>Days</option>
                            <option>Hours</option>
                            <option>Minutes</option>
                        </select>
                         </label>
                    </span>
                </div>
                
                <div class="row-element">
                    <span class="title" id="commonces">Commences on</span>
                    <span class="content">
                        <input type="text" name = "commence" id="maingroup" class="maingroup">
                       
                    </span>
                </div>
                
                <div class="row-element" id="examtime" style="display:none">
                    <span class="title" >Exam Time</span>
                    <span class="content">
                        <label style="color:#536485;background: none;border: 0px;width: 48%;height: auto;float:left;">
                            <input placeholder="Enter Value" type="text" name = "examtime"  style="margin: 5px;background: #fff ">
                         </label>
                        <label style="color:#536485;background: none;border: 0px;width: 4%;height: 20px;float:left;">&nbsp;</label>
                        <label style="color:#536485;background: none;border: 0px;width: 48%;height: auto;float:left;">
                        <select id="examtimefreq" name = "examtimefreq" class="duration" style="font-size: 13px;float:left">
                           
                            <option>AM</option>
                            <option>PM</option>
                        </select>
                         </label>
                       
                    </span>
                </div>
                
                <div class="row-element" id="cooloftime" style="display:none">
                    <span class="title" id="commonces">Cool of Time</span>
                    <span class="content">
                        <label style="color:#536485;background: none;border: 0px;width: 48%;height: auto;float:left;">
                            <input placeholder="Enter Value" type="text" name = "cooloftime"  style="margin: 5px;background: #fff ">
                         </label>
                        <label style="color:#536485;background: none;border: 0px;width: 4%;height: 20px;float:left;">&nbsp;</label>
                        <label style="color:#536485;background: none;border: 0px;width: 48%;height: auto;float:left;margin-top: 15px">
                        Minutes
                         </label>
                       
                    </span>
                </div>
                
                <div class="row-element" id="rtime" style="display:none">
                    <span class="title" >Reporting Time</span>
                    <span class="content">
                        <input type="text" name = "rtime" class="adtime">
                       
                    </span>
                </div>
                
                <div class="row-element" id="modeofexam" style="display:none">
                    <span class="title" >Mode Of Exam</span>
                    <span class="content">
                        <select id="modeofexam" name = "modeofexam" class="duration" style="font-size: 13px;float:left">
                           <option value="">Select Exam Mode</option>
                            <option>Online</option>
                            <option>Offline</option>
                        </select>
                                              
                    </span>
                </div>

                <div class="row-element">
                    <span class="title" id="adtime">Admission Time</span>
                    <span class="content">
                        <label style="color:#536485;background: none;border: 0px;width: 48%;height: auto;float:left;">
                            <input placeholder="Starts on" type="text" name = "startson" class="adtime" style="margin: 5px;background: #fff url('<?php echo base_url(); ?>/images/cal.png') no-repeat 98%;"></label>
                         <label style="margin-left: 3%;color:#536485;background: none;border: 0px;width: 48%;height: auto;float:left;">
                             <input placeholder="Ends on" type="text" name = "endson" class="adtime" style="margin: 5px;background: #fff url('<?php echo base_url(); ?>/images/cal.png') no-repeat 98%;"></label>
                        
                       
                    </span>
                </div>

                <div class="row-element">
                    <span class="title">Qualification</span>                    
                    <span class="content"><select id="maincriteria" name = "qualification" class="maincriteria" style="font-size: 13px;float:left">
                            <?php echo $qualification;?>
                        </select></span>
                </div>
                          
                
                
                <div class="row-element" id="csch">
                    <span class="title">Class Schedule</span>                    
                    <span class="content">
                        <label style="text-align: left;min-width: 150px;color:#536485;background: none;border: 0px;width: auto;height: auto;float:left;font-size: 14px"><input type="checkbox" name = "regular"   class="chkbox rbatch" style="margin: 5px;">Regular Batch</label>
                        <label style="text-align: left;min-width: 150px;color:#536485;background: none;border: 0px;width: auto;height: auto;float:left;font-size: 14px"><input type="checkbox" name = "weekend"  class="chkbox wbatch" style="margin: 5px;">Weekend Batch</label>
                        <label style="text-align: left;min-width: 150px;color:#536485;background: none;border: 0px;width: auto;height: auto;float:left;font-size: 14px"><input type="checkbox" name = "both"  class="chkbox both" style="margin: 5px;">Both</label>
                         <label style="text-align: left;min-width: 150px;color:#536485;background: none;border: 0px;width: auto;height: auto;float:left;font-size: 14px"><input type="checkbox" name = "hybrid"   class="chkbox hbatch" style="margin: 5px;">Hybrid</label>
                        <label style="text-align: left;min-width: 150px;color:#536485;background: none;border: 0px;width: auto;height: auto;float:left;font-size: 14px"><input type="checkbox" name = "special"  class="chkbox sbatch" style="margin: 5px;">Special</label>
                        <label style="text-align: left;min-width: 150px;color:#536485;background: none;border: 0px;width: auto;height: auto;float:left;font-size: 14px"><input type="checkbox" name = "other"  class="chkbox other" style="margin: 5px;">Other State</label>
                    </span>
                </div>
                
                <div class="row-element" id="coutype">
                    <span class="title">Course Type</span>                    
                    <span class="content">
                        <label style="text-align: left;min-width: 150px;color:#536485;background: none;border: 0px;width: auto;height: auto;float:left;font-size: 14px;font-weight: normal"><input type="radio" value="online" name = "ctype"   class="" style="margin: 5px;">Online</label>
                        <label style="text-align: left;min-width: 150px;color:#536485;background: none;border: 0px;width: auto;height: auto;float:left;font-size: 14px;font-weight: normal"><input type="radio" value="room" name = "ctype"  class="" style="margin: 5px;">Class Room</label>
                        <label style="text-align: left;min-width: 150px;color:#536485;background: none;border: 0px;width: auto;height: auto;float:left;font-size: 14px;font-weight: normal"><input type="radio" value="both" name = "ctype"  class="" style="margin: 5px;">Both</label>
                          </span>
                </div>
                
                
                
                 <div class="row-element">
                    <span class="title" id="scity">Centers</span>                    
                    <span class="content"><select multiple id="centers" name = "centers" class="centers" style="width: 100%;font-size: 13px;float:left">
                            <option value="" >Select center</option>
                            <?php echo $units;?>
                        </select></span>
                    <input type="hidden" name="selcenters" class="selcenters" />
                </div>
                
                <div class="row-element">
                    <span class="title">Course Description</span>                    
                    <span class="content">
                        <textarea class="coursedesc" name = "cdescription" style=" width: 100%;height:160px"></textarea>
                    </span>
                </div>
                <div class="row-element">
                    <span class="title">Refund Policy</span>                    
                    <span class="content">
                        <textarea class="refund" name = "crefund" style=" width: 100%;height:160px"></textarea>
                    </span>
                </div>
            <?php echo form_close() ?>
                
            </div>
     <div style="margin-top: 0px; width: 98%; height: 70px; text-align: right;">
         <span  style="margin: 0px auto; float:right;margin-top: 18px;padding: 10px; color: #fff; background: #4f6fc4 none repeat scroll 0% 0%; border-radius:5px;cursor: pointer" class="btn savebtn" href="#">Submit</span>
         <a style="margin: 0px auto; float:right;margin-top: 18px;margin-right:18px;padding: 9px 10px; color: #0332AA; background: linear-gradient(0deg, #FFFFFF, #FFFFFF), #C4C4C4;border: 1px solid #0332AA; border-radius:5px" class="btn" href="<?php echo base_url(); ?>courses">Back</a>
         <span class="response" style="margin: 0px auto; float:right;width: 80%; height: 30px;margin-top:20px"></span>
     </div>         
        
        </div>
    
    
    
<script type="text/javascript">
$(document).ready(function() {
    
    $(".duration").selectmenu();
    $(".chkbox").checkboxradio();
    $(".adtime").datetimepicker();
    $("#centers").chosen();$("#subcriteria").selectmenu();$("#rule").selectmenu();$("#maincriteria").selectmenu();
    $(".coursedesc").jqte();
    $(".refund").jqte();
    
    $(".stest").click(function(){
        if($(this).is(":checked")){
            
            $("#csch").css("display","none");
            $("#coutype").css("display","none");
            $("#adtime").text("Application Period");
            $("#commonces").text("Test Date");
            $("#scity").text("City");
            
            $("#examtime").css("display","inline-block");
            $("#rtime").css("display","inline-block");
            $("#cooloftime").css("display","inline-block");
            $("#modeofexam").css("display","inline-block");
            
             $.get('addcourse/GetScreenTestCities',{ 'term':"1"}, function(o) { 

                     
                     $("#centers").chosen('destroy');  
                     $("#centers").html(o);
                     $("#centers").chosen();
                     $("#centers_chosen").find(".chosen-search-input").val("Select City");

              });        
        } else {
            
            $("#csch").css("display","inline-block");
            $("#coutype").css("display","inline-block");
            $("#adtime").text("Admission Time");
            $("#commonces").text("Commences on");
            $("#scity").text("Centers");
             
            $("#examtime").css("display","none");
            $("#rtime").css("display","none");
            $("#cooloftime").css("display","none");
            $("#modeofexam").css("display","none");
            
            $.get('addcourse/GetScreenTestLocation',{ 'term':"0"}, function(o) { 

                     
                     $("#centers").chosen('destroy');  $("#centers").html(o);
                     $("#centers").chosen();
                     $("#centers_chosen").find(".chosen-search-input").val("Select Centers");

              }); 
            
        }
    });
    
    $(".savebtn").click(function(){
         
               if($(".response").hasClass('progress')) { return;}
               $(".response").html('').text('Progressing...');
                $(".response").addClass('progress');
               var centers = "";
               $("#centers_chosen").find("li span").each(function(){
                   centers += $(this).text()+"|";
               });
               
               if($(".rbatch").is(":checked")) {$(".rbatch").val("regular");} else { $(".rbatch").val("0");}
               if($(".wbatch").is(":checked")) {$(".wbatch").val("weekend");} else { $(".wbatch").val("0");}
               if($(".both").is(":checked")) {$(".both").val("both");} else { $(".both").val("0");}
               if($(".stest").is(":checked")) {$(".stest").val("1");} else { $(".stest").val("0");}
               if($(".hbatch").is(":checked")) {$(".hbatch").val("hybrid");} else { $(".hbatch").val("0");}
               if($(".sbatch").is(":checked")) {$(".sbatch").val("special");} else { $(".sbatch").val("0");}
               if($(".other").is(":checked")) {$(".other").val("other");} else { $(".other").val("0");}

               
               $(".selcenters").val(centers);
               
                var qualificationForm = $("#courseForm");

                    $.ajax({
                        url: qualificationForm.attr('action'),
                        type: 'post',
                        data: qualificationForm.serialize(),
                        success: function(o){
                            
                            var response = $.parseJSON(o);
                            $(".response").html('');
                            if(response.status === 'success') {
                                
                                var t = "<?php echo base_url(); ?>"+"addpayment?id="+response.ide;
                                $(".addpay").css("display","").attr("href",t);
                                $(".response").css("color","rgb(25, 71, 15)");
                               $(".response").text(response.message);
                                $(location).prop('href', 'courses');
                            } else {
                                
                               $(".response").append(response.message); 
                               $(".response").removeClass('progress');
                           
                            }

                        }
                    });
                   
                              
            });
	
	
	$(".add-course").find("input").each(function(){
            
            $(this).keyup(function(event){
                if(event.keyCode == 13){
                    var ty = $(this).next();
                    event.preventDefault();
                    $('input')[$('input').index(this)+1].focus();
                    $('input')[$('input').index(this)+1].select();
                }
            });

            $(this).click(function(){ $(".errnotify").html("&nbsp;");});
            

        });
        $(document).delegate(".advalue","keyup",function(event){
     
            if(!numCheck(this)) { alert('invalid key'); return;}  
         });
        
	
        
        function numCheck(ele){
        
            var numchk = new RegExp("^[0-9.]*$");  
            if( numchk.test( $(ele).val() ) ){ return 1; } else { $(ele).val("");return 0;}
    }
	
});
</script>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Brilliatpala | Profile Card | <?php echo $stuprofile['studid'];?></title>
<!--<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1">-->

<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>css/boot/bootstrap.min.css" media='screen,print'>
<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>css/boot/main.css" media='screen,print'>

<script src="<?php echo base_url();?>js/jquery-3.5.1.min.js"></script>


<script type="text/javascript">
$(document).ready(function(){
		
	window.print();

});
</script>

<style type="text/css">
		
	.h1, .h2, .h3, .h4, .h5, .h6, h1, h2, h3, h4, h5, h6 {line-height: 1.3}
	h1 {font-size: 24px;padding-bottom: 10px;display: inline-block;font-weight: bold;text-transform: uppercase}
	h2 {font-size: 1.4rem}
	h3 {font-size: 1.3rem;margin-bottom: 1rem}
		
	main{max-width: 100%;margin: auto}
	
	#sdtButtons1,#sdtButtons2, #sdtButtons3, #sdtButtons4{margin-bottom: 2rem;border: 2px solid #333;padding: 1rem;border-radius: 10px}
	
	.h5, h5 {font-size: 1.1rem;}
	.pageone{min-height: 1380px}
	
</style>


<?php 
	
	$coursenamesarr = array();
	
	$coursenames = "<ol class='p-2'>";
	
	foreach($feepayments['coursename'] as $key=>$feepayment){
		
		//array_push($coursenamesarr,$feepayment);
		
		$coursenames .= "<li>".$feepayment."</li>";
		
	}
	
	
	if(!empty($coursenamesarr)){
		
		$coursenames = implode(", ",$coursenamesarr);
		
	}
	
	
	$coursenames .= "</ol>";
	
	
?>
<main>

	<div class="container-fluid">
		
		
		<div id="profileview">
              
              
              <div id="studentdetailstab">
           
           <div class="row p-3 align-items-center">
					
			<div class="col-md-2">
			
				<img src="<?php echo base_url(); ?>css/img/brilliant-logo.png" alt="Brilliant Pala Logo" class="mb-2" />
													
			</div>
			<div class="col-md-8 text-center">
						
				<h1>Personal Details Card</h1>
				
			</div>
			
		
		</div>
           
            
            <div class="card-body">
            
            
            <div class="pageone">
            
            
            <div id="sdtButtons2">
				                            
				  <h3>Sign Up Data</h3> 
               
           <div class="row">
          
          <div class="col-md-10 col-sm-10 col-lg-10 col-12">                                                                                                                                                                                              
                <div class="d-flex flex-row">
                          
              <div class="d-flex flex-grow-1 min-width-zero">
                <div class="card-body pl-0 py-2 align-self-center d-flex flex-column flex-lg-row justify-content-between min-width-zero">
                  <div class="w-100">
                   
                   <div class="row profiletop">

						<div class="col-12 col-sm-6">
							<div class="row">

								<div class="col-md-5">
									<h5>Student Name:</h5>
								</div>

								<div class="col-md-7">
									<h5><?php if($stuprofile['stuname']!=""){ echo ucwords($stuprofile['stuname']);}else{echo "-Nil-";} ?></h5>
								</div>

							</div>
						</div>
					
					<div class="col-12 col-sm-6">
						<div class="row">

							<div class="col-md-5">
								<h5>Student ID:</h5>
							</div>

							<div class="col-md-7">
								<h5><?php if($stuprofile['studid']!=""){ echo $stuprofile['studid'];}else{echo "-Nil-";} ?></h5>
							</div>

						</div>
					</div>

					</div>
                  
                  <div class="row profiletop">

						<div class="col-12 col-sm-6">
							<div class="row">

								<div class="col-md-5">
									<p>Mobile:</p>
								</div>

								<div class="col-md-7">
									<p><?php if($stuprofile['sumcode']!=""){ echo $stuprofile['sumcode'];}else{echo $stuprofile['smcode'];}?> <?php echo $stuprofile['smobile']; ?></p>
								</div>

							</div>
						</div>
					
					<div class="col-12 col-sm-6">
						<div class="row">

							<div class="col-md-5">
								<p>Email:</p>
							</div>

							<div class="col-md-7">
								<p><?php echo strtolower($stuprofile['semail']); ?></p>
							</div>

						</div>
					</div>

					</div>
                  
                  
                  <div class="row profiletop">
					
					<div class="col-12 col-sm-6">
						<div class="row">

							<div class="col-md-5">
								<p>Batch:</p>
							</div>

							<div class="col-md-7">
								<p><?php echo "-Nil-"; ?></p>
							</div>

						</div>
					</div>

						<div class="col-12">
							<div class="row">

								<div class="col-md-2">
									<p>Course Name:</p>
								</div>

								<div class="col-md-10">
									<?php echo $coursenames; ?>
								</div>

							</div>
						</div>

					</div>
                                      
                   
                  </div>
                </div>
              </div>
                            			
            </div>
                                                                                                           
              </div>  
                                                                                                           
			  <div class="col-md-2 col-sm-2 col-lg-2 col-12">
			  	
			  	
			  <img alt="Profile" style="width: 180px;height: 180px" src="<?php if($stuprofile['profilepic']!="0" && $stuprofile['profilepic']!=""){ echo base_url()."docs/profilepic/".$sid."/".$stuprofile['profilepic']."?".time();}else{echo "img/myprofile.png?".time();} ?>" class="img-thumbnail border-0 align-items-center">
			  	
			  	
			  </div>                                                                                           
                                                                                                            
                                                                                                               
                                                                                                            
              </div>      
                                                                                                             
				  </div>
           
            
            <div id="sdtButtons1">
             
             <h3>Personal details</h3>   
             
             <div class="row">
             
             <div class="col-12 col-sm-6">
                <div class="row">

					<div class="col-md-5">
						<p>Name:</p>
					</div>

					<div class="col-md-7">
						<p><?php if($stuprofile['stuname']!=""){ echo ucwords($stuprofile['stuname']);}else{echo "-Nil-";} ?></p>
					</div>

				</div>
			</div>
              
              <div class="col-12 col-sm-6">
              		<div class="row">

						<div class="col-md-5">
							<p>Date of Birth:</p>
						</div>

						<div class="col-md-7">
							<p class="<?php if($stuprofile['dob']=="" || $stuprofile['dob']=="0000-00-00" || $stuprofile['dob']=="01-01-1970"){ echo "empty";} ?>"><?php if($stuprofile['dob']!="" && $stuprofile['dob']!="0000-00-00" && $stuprofile['dob']!="01-01-1970"){ echo date("d-m-Y",strtotime($stuprofile['dob']));}else{echo "-Nil-";} ?></p>
						</div>

					</div>
              </div>
              
              <div class="col-12 col-sm-6">
              		<div class="row">

						<div class="col-md-5">
							<p>Gender:</p>
						</div>

						<div class="col-md-7">
							<p class="<?php if($stuprofile['gender']=="" || $stuprofile['gender']=="0"){ echo "empty";} ?>"><?php if($stuprofile['gender']!="" && $stuprofile['gender']!="0"){ echo $stuprofile['gender'];}else{echo "-Nil-";} ?></p>
						</div>

					</div>
              </div>
              
              <div class="col-12 col-sm-6">
                <div class="row">

					<div class="col-md-5">
						<p>Nationality:</p>
					</div>

					<div class="col-md-7">
						<p class="<?php if($stuprofile['nationality']=="" || $stuprofile['nationality']=="0"){ echo "empty";} ?>"><?php if($stuprofile['nationality']!="" && $stuprofile['nationality']!="0"){ echo $stuprofile['nationality'];}else{echo "-Nil-";} ?></p>
					</div>

				</div>
              </div>
              
              <div class="col-12 col-sm-6">
                <div class="row">

					<div class="col-md-5">
						<p>Category:</p>
					</div>

					<div class="col-md-7">
						<p class="<?php if($stuprofile['category']=="" || $stuprofile['category']=="0"){ echo "empty";} ?>"><?php if($stuprofile['category']!="" && $stuprofile['category']!="0"){ echo $stuprofile['category'];}else{echo "-Nil-";} ?></p>
					</div>

				</div>
              </div>
                           
              <div class="col-12 col-sm-6">
                <div class="row">

					<div class="col-md-5">
						<p>Aadhar Number:</p>
					</div>

					<div class="col-md-7">
						<p class="<?php if($stuprofile['aadharnumber']=="" || $stuprofile['aadharnumber']=="0"){ echo "empty";} ?>"><?php if($stuprofile['aadharnumber']!="" && $stuprofile['aadharnumber']!="0"){ echo $stuprofile['aadharnumber'];}else{echo "-Nil-";} ?></p>
					</div>

				</div>
			</div>
             
				 <div class="col-12"> <h3>Parents Details</h3></div>
              
              <div class="col-12 col-sm-6">
                <div class="row">

					<div class="col-md-5">
						<p>Fathers Name:</p>
					</div>

					<div class="col-md-7">
						<p class="<?php if($stuprofile['fathername']=="" || $stuprofile['fathername']=="0"){ echo "empty";} ?>"><?php if($stuprofile['fathername']!="" && $stuprofile['fathername']!="0"){ echo $stuprofile['fathername'];}else{echo "-Nil-";} ?></p>
					</div>

				</div>
			</div>
              
              <div class="col-12 col-sm-6">
                <div class="row">

					<div class="col-md-5">
						<p>Fathers Phone:</p>
					</div>

					<div class="col-md-7">
						<p class="<?php if($stuprofile['fatherphone']=="" || $stuprofile['fatherphone']=="0"){ echo "empty";} ?>"><?php if($stuprofile['fatherphone']!="" && $stuprofile['fatherphone']!="0"){ echo $stuprofile['fathercode'].' '.$stuprofile['fatherphone'];}else{echo "-Nil-";} ?></p>
					</div>

				</div>
             
				 </div>
              
              <div class="col-12 col-sm-6">
                <div class="row">

					<div class="col-md-5">
						<p>Fathers Email:</p>
					</div>

					<div class="col-md-7">
						<p class="<?php if($stuprofile['fatheremail']=="" || $stuprofile['fatheremail']=="0"){ echo "empty";} ?>"><?php if($stuprofile['fatheremail']!="" && $stuprofile['fatheremail']!="0"){ echo $stuprofile['fatheremail'];}else{echo "-Nil-";} ?></p>
					</div>

				</div>
			</div>
              
              <div class="col-12 col-sm-6">
                <div class="row">

					<div class="col-md-5">
						<p>Fathers Occupation:</p>
					</div>

					<div class="col-md-7">
						<p class="<?php if($stuprofile['fatheroccupation']=="" || $stuprofile['fatheroccupation']=="0"){ echo "empty";} ?>"><?php if($stuprofile['fatheroccupation']!="" && $stuprofile['fatheroccupation']!="0"){ echo $stuprofile['fatheroccupation'];}else{echo "-Nil-";} ?></p>
					</div>

				</div>
			</div>
              
              <div class="col-12 col-sm-6">
                <div class="row">

					<div class="col-md-5">
						<p>Mothers Name:</p>
					</div>

					<div class="col-md-7">
						<p class="<?php if($stuprofile['mothername']=="" || $stuprofile['mothername']=="0"){ echo "empty";} ?>"><?php if($stuprofile['mothername']!="" && $stuprofile['mothername']!="0"){ echo $stuprofile['mothername'];}else{echo "-Nil-";} ?></p>
					</div>

				</div>
			</div>
              
              <div class="col-12 col-sm-6">
                <div class="row">

					<div class="col-md-5">
						<p>Mothers Phone:</p>
					</div>

					<div class="col-md-7">
						<p class="<?php if($stuprofile['motherphone']=="" || $stuprofile['motherphone']=="0"){ echo "empty";} ?>"><?php if($stuprofile['motherphone']!="" && $stuprofile['motherphone']!="0"){ echo $stuprofile['mothercode'].' '.$stuprofile['motherphone'];}else{echo "-Nil-";} ?></p>
					</div>

				</div>
                           
				 </div>
              
              <div class="col-12 col-sm-6">
				  <div class="row">

						<div class="col-md-5">
							<p>Mothers Email:</p>
						</div>

						<div class="col-md-7">
							<p class="<?php if($stuprofile['motheremail']=="" || $stuprofile['motheremail']=="0"){ echo "empty";} ?>"><?php if($stuprofile['motheremail']!="" && $stuprofile['motheremail']!="0"){ echo $stuprofile['motheremail'];}else{echo "-Nil-";} ?></p>
						</div>

					</div>
              
              </div>
              
              <div class="col-12 col-sm-6">
                <div class="row">

					<div class="col-md-5">
						<p>Mothers Occupation:</p>
					</div>

					<div class="col-md-7">
						<p class="<?php if($stuprofile['motheroccupation']=="" || $stuprofile['motheroccupation']=="0"){ echo "empty";} ?>"><?php if($stuprofile['motheroccupation']!="" && $stuprofile['motheroccupation']!="0"){ echo $stuprofile['motheroccupation'];}else{echo "-Nil-";} ?></p>
					</div>

				</div>
			</div>
              
              <div class="col-12 col-sm-6">
                <div class="row">

					<div class="col-md-5">
						<p>Communication Contact:</p>
					</div>

					<div class="col-md-7">
						<p class="<?php if($stuprofile['communicationcontact']=="" || $stuprofile['communicationcontact']=="0"){ echo "empty";} ?>"><?php if($stuprofile['communicationcontact']!="" && $stuprofile['communicationcontact']!="0"){ echo $stuprofile['communicationcontact'];}else{echo "-Nil-";} ?></p>
					</div>

				</div>
              </div>
              
              <div class="col-12 col-sm-6">
               
                <div class="row">

					<div class="col-md-5">
						<p>Blood Group:</p>
					</div>

					<div class="col-md-7">
						<p class="<?php if($stuprofile['bloodgroup']=="" || $stuprofile['bloodgroup']=="0"){ echo "empty";} ?>"><?php if($stuprofile['bloodgroup']!="" && $stuprofile['bloodgroup']!="0"){ echo $stuprofile['bloodgroup'];}else{echo "-Nil-";} ?></p>
					</div>

				</div>
    
              </div>
              
              <div class="col-12 col-sm-6">
                <div class="row">

					<div class="col-md-5">
						<p>Class Studying / Complete:</p>
					</div>

					<div class="col-md-7">
						<p class="<?php if($stuprofile['classstudy']=="" || $stuprofile['classstudy']=="0"){ echo "empty";} ?>"><?php if($stuprofile['classstudy']!="" && $stuprofile['classstudy']!="0"){ echo $stuprofile['classstudy'];}else{echo "-Nil-";} ?></p>
					</div>

				</div>
          
              </div>
              
              <div class="col-12 col-sm-6">
                <div class="row">

					<div class="col-md-5">
						<p>Stream:</p>
					</div>

					<div class="col-md-7">
						<p class="<?php if($stuprofile['stream']=="" || $stuprofile['stream']=="0"){ echo "empty";} ?>"><?php if($stuprofile['stream']!="" && $stuprofile['stream']!="0"){ echo $stuprofile['stream'];}else{echo "-Nil-";} ?></p>
					</div>

				</div>
              
              </div>
              
              			  
			  </div>
               
				  </div>
                
                
                <div id="sdtButtons4">                                                   
				  
             <h3>Contact details</h3>   
              
               <div class="row">
                                        
                <div class="col-12 col-sm-6">
                <div class="row">

					<div class="col-md-5">
						<p>Guardian Name:</p>
					</div>

					<div class="col-md-7">
						<p class="<?php if($stuprofile['guardianname']=="" || $stuprofile['guardianname']=="0"){ echo "empty";} ?>"><?php if($stuprofile['guardianname']!="" && $stuprofile['guardianname']!="0"){ echo $stuprofile['guardianname'];}else{echo "-Nil-";} ?></p>
					</div>

				</div>
			</div>                        
                                        
                                         
              <div class="col-12 col-sm-6">
                <div class="row">

					<div class="col-md-7">
						<p>House / Appartment Name:</p>
					</div>

					<div class="col-md-5">
						<p class="<?php if($stuprofile['housenameno']=="" || $stuprofile['housenameno']=="0"){ echo "empty";} ?>"><?php if($stuprofile['housenameno']!="" && $stuprofile['housenameno']!="0"){ echo $stuprofile['housenameno'];}else{echo "-Nil-";} ?></p>
					</div>

				</div>
			</div>
   
              
              <div class="col-12 col-sm-6">
                <div class="row">

					<div class="col-md-5">
						<p>Place / Street:</p>
					</div>

					<div class="col-md-7">
						<p class="<?php if($stuprofile['contactaddress']=="" || $stuprofile['contactaddress']=="0"){ echo "empty";} ?>"><?php if($stuprofile['contactaddress']!="" && $stuprofile['contactaddress']!="0"){ echo $stuprofile['contactaddress'];}else{echo "-Nil-";} ?></p>
					</div>

				</div>
			</div>
              
              <div class="col-12 col-sm-6">
                <div class="row">

					<div class="col-md-5">
						<p>Post Office:</p>
					</div>

					<div class="col-md-7">
						<p class="<?php if($stuprofile['contactpost']=="" || $stuprofile['contactpost']=="0"){ echo "empty";} ?>"><?php if($stuprofile['contactpost']!="" && $stuprofile['contactpost']!="0"){ echo $stuprofile['contactpost'];}else{echo "-Nil-";} ?></p>
					</div>

				</div>
              </div>
              
              <div class="col-12 col-sm-6">
                <div class="row">

					<div class="col-md-5">
						<p>District:</p>
					</div>

					<div class="col-md-7">
						<p class="<?php if($stuprofile['contactdistrict']=="" || $stuprofile['contactdistrict']=="0"){ echo "empty";} ?>"><?php if($stuprofile['contactdistrict']!="" && $stuprofile['contactdistrict']!="0"){ echo $stuprofile['contactdistrict'];}else{echo "-Nil-";} ?></p>
					</div>

				</div>
              </div>
              
             <div class="col-12 col-sm-6">
                <div class="row">

					<div class="col-md-5">
						<p>State:</p>
					</div>

					<div class="col-md-7">
						<p class="<?php if($stuprofile['contactstate']=="" || $stuprofile['contactstate']=="0"){ echo "empty";} ?>"><?php if($stuprofile['contactstate']!="" && $stuprofile['contactstate']!="0"){ echo $stuprofile['contactstate'];}else{echo "-Nil-";} ?></p>
					</div>

				</div>
              </div>
              
              <div class="col-12 col-sm-6">
                <div class="row">

					<div class="col-md-5">
						<p>Country:</p>
					</div>

					<div class="col-md-7">
						<p class="<?php if($stuprofile['contactcountry']=="" || $stuprofile['contactcountry']=="0"){ echo "empty";} ?>"><?php if($stuprofile['contactcountry']!="" && $stuprofile['contactcountry']!="0"){ echo $stuprofile['contactcountry'];}else{echo "-Nil-";} ?></p>
					</div>

				</div>
              </div>
              
              <div class="col-12 col-sm-6">
                <div class="row">

					<div class="col-md-5">
						<p>Pincode:</p>
					</div>

					<div class="col-md-7">
						<p class="<?php if($stuprofile['contactpincode']=="" || $stuprofile['contactpincode']=="0"){ echo "empty";} ?>"><?php if($stuprofile['contactpincode']!="" && $stuprofile['contactpincode']!="0"){ echo $stuprofile['contactpincode'];}else{echo "-Nil-";} ?></p>
					</div>

				</div>
			</div>
             			  
             	<div class="col-12 col-sm-6">
                <div class="row">

					<div class="col-md-5 col-5">
						<p>Whatsapp Number:</p>
					</div>

					<div class="col-md-7 col-7">
						<p class="<?php if($stuprofile['whatsappno']=="" || $stuprofile['whatsappno']=="0"){ echo "empty";} ?>"><?php if($stuprofile['whatsappno']!="" && $stuprofile['whatsappno']!="0"){ echo $stuprofile['wacode'].' '.$stuprofile['whatsappno'];}else{echo "-Nil-";} ?></p>
					</div>

				</div>
                           
				 </div>	
              
              			  
			  </div>                                                                                                 
                                                                                                                 
				  </div>
				  
				  
				</div>
				  
				  
				  <div id="sdtButtons2">
				                            
				  <h3>Educational details</h3>                                                                                              
                <div class="row">
             
             <div class="col-12 col-sm-6">
                <div class="row">

					<div class="col-md-5">
						<p>Name of School Last Studied / Studying :</p>
					</div>

					<div class="col-md-7">
						<p class="<?php if($stuprofile['schoolcollegename']=="" || $stuprofile['schoolcollegename']=="0"){ echo "empty";} ?>"><?php if($stuprofile['schoolcollegename']!="" && $stuprofile['schoolcollegename']!="0"){ echo $stuprofile['schoolcollegename'];}else{echo "-Nil-";} ?></p>
					</div>

				</div>
              </div>
              
              <div class="col-12 col-sm-6">
                <div class="row">

					<div class="col-md-5">
						<p>Address Line:</p>
					</div>

					<div class="col-md-7">
						<p class="<?php if($stuprofile['eduaddress']=="" || $stuprofile['eduaddress']=="0"){ echo "empty";} ?>"><?php if($stuprofile['eduaddress']!="" && $stuprofile['eduaddress']!="0"){ echo $stuprofile['eduaddress'];}else{echo "-Nil-";} ?></p>
					</div>

				</div>
			</div>
              
              <div class="col-12 col-sm-6">
                <div class="row">

					<div class="col-md-5">
						<p>Country:</p>
					</div>

					<div class="col-md-7">
						<p class="<?php if($stuprofile['educountry']=="" || $stuprofile['educountry']=="0"){ echo "empty";} ?>"><?php if($stuprofile['educountry']!="" && $stuprofile['educountry']!="0"){ echo $stuprofile['educountry'];}else{echo "-Nil-";} ?></p>
					</div>

				</div>
              </div>
                            			  
			  </div>
                                                                                                             
                   
				  </div>                                                                                                                                                                                            
                              
              <?php if(!empty($qualification)){?>
              
              <div id="sdtButtons3">
               
               <!--<div class="border-bottom"></div>-->                                                                                             
				  <h3>Qualification details</h3>                                                                                   
                                                                                                                       
              <div class="row yearfee">


							<div class="col-md-5 mb-4">

								<p class="first">Class <?php echo $qualification['class'];?> details</p>

								<div class="d-block w-100 p-0">

									<div class="row">

										<div class="col-md-5 col-5">
											<p>Year of Passing:</p>
										</div>

										<div class="col-md-7 col-7">
											<p><?php echo $qualification['yearofpassing'];?></p>
										</div>

									</div>

									<div class="row">

										<div class="col-md-5 col-5">
											<p>Class Name:</p>
										</div>

										<div class="col-md-7 col-7">
											<p><?php echo $qualification['class'];?></p>
										</div>

									</div>

									<div class="row">

										<div class="col-md-5 col-5">
											<p>Board of Exams:</p>
										</div>

										<div class="col-md-7 col-7">
											<p><?php echo $qualification['stream'];?></p>
										</div>

									</div>

									<div class="row">

										<div class="col-md-5 col-5">
											<p>Status:</p>
										</div>

										<div class="col-md-7 col-7">
											<p><?php echo ($qualification['status'] === 'P')?"Passed":"Waiting For Result";?></p>
										</div>

									</div>

									<div class="row">

										<div class="col-md-5 col-5">
											<p>Roll Number:</p>
										</div>

										<div class="col-md-7 col-7">
											<p><?php echo $qualification['rollno'];?></p>
										</div>

									</div>

									<div class="row">

										<div class="col-md-5 col-5">
											<p>Grace Mark:</p>
										</div>

										<div class="col-md-7 col-7">
												<p><?php if($qualification['gracemark'] != '') {echo ($qualification['gracemark'] === 'y')?"Yes":"No";}?></p>
										</div>

									</div>
								</div>
							</div>

							<?php

							if($qualification['subject'] !== '') {

								$subject = explode("|",$qualification['subject']);
								$mark = ($qualification['mark'] !== '')? explode("|",$qualification['mark']):"";
								$grade = ($qualification['grade'] !== '')? explode("|",$qualification['grade']):"";



								?>
							<div class="col-md-4 mb-4">

								<p class="first">Class <?php echo $qualification['class'];?> Marksheet</p>

								<div class="card d-flex d-block w-100 p-3">
                                                                    
									<?php 

									for($i = 0 ; $i < count($subject);$i++) {
									if($subject[$i] ==='') { continue;}
									   $con = ($mark !== '')?$mark[$i]:$grade[$i];
										echo '<div class="row">

												<div class="col-md-5 col-5">
												<p>'.$subject[$i].':</p>
												</div>

												<div class="col-md-7 col-7">
												<p>'.$con.'</p>
												</div>

												</div>';
									}

									?>
								
								</div>
							</div>
                                                    
                                                    <?php } ?>

						</div>


                      <?php if($qualification['xii_yearofpassing'] !== '') {?>
                      
                      <div class="separator mb-5"></div>
                      
						<div class="row yearfee">


							<div class="col-md-5 mb-4">

								<p class="first">Class XII details</p>

								<div class="d-block w-100 p-0">

									<div class="row">

										<div class="col-md-5 col-5">
											<p>Year of Passing:</p>
										</div>

										<div class="col-md-7 col-7">
											<p><?php echo $qualification['xii_yearofpassing']; ?></p>
										</div>

									</div>

									<div class="row">

										<div class="col-md-5 col-5">
											<p>Class Name:</p>
										</div>

										<div class="col-md-7 col-7">
											<p>XII Standard</p>
										</div>

									</div>

									<div class="row">

										<div class="col-md-5 col-5">
											<p>Board of Exams:</p>
										</div>

										<div class="col-md-7 col-7">
											<p><?php echo $qualification['xii_stream']; ?></p>
										</div>

									</div>

									<div class="row">

										<div class="col-md-5 col-5">
											<p>Status:</p>
										</div>

										<div class="col-md-7 col-7">
											<p><?php echo ($qualification['xii_status'] === 'P')?"Passed":"Waiting For Result";?></p>
										</div>

									</div>

									<div class="row">

										<div class="col-md-5 col-5">
											<p>Roll Number:</p>
										</div>

										<div class="col-md-7 col-7">
											<p><?php echo $qualification['xii_rollno']; ?></p>
										</div>

									</div>

									<div class="row">

										<div class="col-md-5 col-5">
											<p>Grace Mark:</p>
										</div>

										<div class="col-md-7 col-7">
											<p><?php if($qualification['xii_gracemark'] != '') {echo ($qualification['xii_gracemark'] === 'y')?"Yes":"No";}?></p>
										</div>

									</div>
								</div>
							</div>

							<?php

							if($qualification['xii_subject'] !== '') {

								$xii_subject = explode("|",$qualification['xii_subject']);
								$xii_mark = ($qualification['xii_mark'] !== '')? explode("|",$qualification['xii_mark']):"";
								$xii_grade = ($qualification['xii_grade'] !== '')? explode("|",$qualification['xii_grade']):"";



								?>
							<div class="col-md-4 mb-4">

								<p class="first">Class XII Marksheet</p>

								<div class="card d-flex d-block w-100 p-3">

									<?php 
                                                                   
									   for($i = 0 ; $i < count($xii_subject);$i++) {
									   if($xii_subject[$i] ==='') { continue;}
										   $con = ($xii_mark !== '')?$xii_mark[$i]:$xii_grade[$i];
											echo '<div class="row">

													<div class="col-md-5 col-5">
														<p>'.$xii_subject[$i].':</p>
													</div>

													<div class="col-md-7 col-7">
														<p>'.$con.'</p>
													</div>

												</div>';
											}

										   ?>

									
								</div>
							</div>
									<?php } ?>

						</div>

								<?php } ?>
                                               
                                               
                         <?php if($qualification['entrance_name'] != "") {?>                      
                                                
						<div class="separator mb-5"></div>


						<div class="row yearfee">


							<?php

								$examArr1 = explode("|", $qualification['entrance_name']);
								$examArr2 = explode("|", $qualification['entrance_mark']);
								$examArr3 = explode("|", $qualification['entrance_regno']);

								foreach ($examArr1 as $key => $value) {

									if($value === "") {continue;}
                                                            
                                                            echo '<div class="col-md-5 mb-4">
                                                            

								<p class="first">'.$value.' - Entrance Exam</p>

								<div class="d-block w-100 p-0">

									<div class="row">

										<div class="col-md-5 col-5">
											<p>Rank/Mark:</p>
										</div>

										<div class="col-md-7 col-7">
											<p>'.$examArr2[$key].'</p>
										</div>

									</div>

									<div class="row">

										<div class="col-md-5 col-5">
											<p>Registration Number:</p>
										</div>

										<div class="col-md-7 col-7">
											<p>'.$examArr3[$key].'</p>
										</div>

									</div>


								</div>
						</div>';
									
								}
							?>
							
						</div> 
             			
              			<?php }?>
              
              </div>
               
               <?php }?>
                                                              
                 </div>
                                                              
                     </div>                                              
                                                               
				</div>		

	</div>
</main>
<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Maintenance_hook
{
    function __construct()
    {
        log_message('debug', 'Accessing Maintenance Hook!');
    }

    public function check_maintenance_mode()
    {
        
        include(APPPATH.'config/config.php');
        
        if (isset( $_SERVER['REMOTE_ADDR']) && $_SERVER['REMOTE_ADDR'] == '192.168.64.2')
        {
            ##do nothing
        }else if(isset($config['maintenance_mode']) && $config['maintenance_mode'] === TRUE){
                    include(APPPATH . 'views/maintenance_view.php');
                    echo "IP: ". $_SERVER['REMOTE_ADDR'];
                    exit;
                }

        }
}
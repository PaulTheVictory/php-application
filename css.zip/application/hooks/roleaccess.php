<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Roleaccess
{
	var $CI;
    function __construct()
    {
		$this->CI =& get_instance();
        //log_message('debug', 'Accessing Maintenance Hook!');
		$this->CI->load->model('login_model','',TRUE);
    }

    public function getroleaccess()
    {
        
        //include(APPPATH.'config/config.php');
        
		if($this->CI->session->userdata('adlog_in')){
			
			$currentpage = $this->CI->uri->segment(1);
			
			$session_data = $this->CI->session->userdata('loggedin');
                        $status = $this->CI->login_model->CheckSessionsStatus();
                        if($status ==="c"){
                            $this->CI->login_model->login_model->endSession();
                            $this->CI->session->unset_userdata('loggedin');		
                            $this->CI->session->sess_destroy();
                            redirect(base_url(), 'refresh');
                        }else{
                            $roleaccess_hook = $this->CI->login_model->GetRoleAccess($session_data['role'],$currentpage);
			
                            $this->CI->config->set_item('roleaccess',$roleaccess_hook);
                        }
			//print_r($this->roleaccess);
			
		}else{
			$this->CI->config->set_item('roleaccess',array());
		}
       

     }
}
<?php

class Student_Model extends CI_Model {


    public function __construct() {

       $this->load->library('Datatables');

    }
	
	
    public function StudentSignup($type,$name,$mcode,$mobile,$emailid,$password,$classstudy,$iagree,$parentname,$relationship) {

		$result = array(0 => "");
					
		if($type!="Sibling"){ 
			$whereclaue = '	(s.mobile="'.$mobile.'" or s.emailid="'.$emailid.'") and (u.mobile="'.$mobile.'" or u.username="'.$emailid.'")';
			$whereclaueolduser = '	(mobile="'.$mobile.'" or username="'.$emailid.'")';
			$whereclaueolduser1 = '	(contact="'.$mobile.'" or email="'.$emailid.'")';
		}
		else{
			$parentname = ucwords(strtolower($parentname));
			$whereclaue = '	((mobile="'.$mobile.'" and parentname="'.$parentname.'") or (emailid="'.$emailid.'" and parentname="'.$parentname.'"))';
			$whereclaueolduser = '	((mobile<>"" and mobile="'.$mobile.'" and name="'.$name.'") or (username<>"" and username="'.$emailid.'" and name="'.$name.'"))';
			$whereclaueolduser1 = '	((contact<>"" and contact="'.$mobile.'" and sname="'.$name.'") or (email<>"" and email="'.$emailid.'" and sname="'.$name.'")) order by created_at desc';
		}
		
		$query = $this-> db -> query('select s.mobile from bscp_signup as s,typo_users as u where '.$whereclaue);
		$row = $query->result_array();
			

		if($type!="Sibling" && $query->num_rows()>0){

			$result = array(0 => "exists");
            return $result;		

		}else if($type=="Sibling" && $query->num_rows()>2){

			$result = array(0 => "exists");
            return $result;		

		}else{
			
			$query1 = $this-> db -> query('select * from typo_users where '.$whereclaueolduser);
			$row1 = $query1->result_array();
			
			if($query1->num_rows()>0){
					
				
				$result = array(0 => "exists");
            	return $result;
				
				/*$mobile = $row1[0]['mobile'];
				$email = $row1[0]['email'];
				$name = $row1[0]['name'];
				
				$query2 = $this-> db -> query('select * from bscp_student where '.$whereclaueolduser1);
				$row2= $query2->result_array();
				
				$studid = "";
				if($query2->num_rows()>0){
					$studid = $row2[0]['studid'];
				}
				
				$id = uniqid();

				$password = SHA1($this->config->item('pass_salt').$password);

				$offset=5*60*60 + 30*60;
				$dateformat = 'Y-m-d H:i:s';
				$curtime = gmdate($dateformat, time()+$offset);
			
			
				if($type!="Sibling"){
					$parentname = $relationship = "";
				}
						
				//$name = ucwords(strtolower($name));
				$name = $this->titleCase($name);
			
				$query1  = $this-> db -> query('insert into bscp_signup (`id`, `type`, `name`, `mcode`, `mobile`, `emailid`, `password`, `classstudy`, `iagree`, `testpressstatus`, `status`, `created`, `verifycode`, `verifystatus`, `parentname`, `relationship`) values ("'.$id.'","'.$type.'","'.$name.'","'.$mcode.'","'.$mobile.'","'.$emailid.'","'.$password.'","'.$classstudy.'","'.$iagree.'","a","a","'.$curtime.'","","","'.$parentname.'","'.$relationship.'")');
			
			
				if($query1){

					$smsresponse = $this->sendActivationCode($id);
					$result = array(0 => "success",1=>"verify",2=>$smsresponse,3=>$id,4=>$mobile,5=>$studid );
					return $result;

				}else{

					$result = array(0 => "fail");
					return $result;
				}*/	

			}else{

				$id = uniqid();

				$password = SHA1($this->config->item('pass_salt').$password);

				$offset=5*60*60 + 30*60;
				$dateformat = 'Y-m-d H:i:s';
				$curtime = gmdate($dateformat, time()+$offset);
			
			
				if($type!="Sibling"){
					$parentname = $relationship = "";
				}
						
				//$name = ucwords(strtolower($name));
				$name = $this->titleCase($name);
			
				$query1  = $this-> db -> query('insert into bscp_signup (`id`, `type`, `name`, `mcode`, `mobile`, `emailid`, `password`, `classstudy`, `iagree`, `testpressstatus`, `status`, `created`, `verifycode`, `verifystatus`, `parentname`, `relationship`) values ("'.$id.'","'.$type.'","'.$name.'","'.$mcode.'","'.$mobile.'","'.$emailid.'","'.$password.'","'.$classstudy.'","'.$iagree.'","a","a","'.$curtime.'","","","'.$parentname.'","'.$relationship.'")');
			
			
				if($query1){

					$smsresponse = $this->sendActivationCode($id);
					$result = array(0 => "success",1=>"verify",2=>$smsresponse,3=>$id,4=>$mobile,5=>"" );
					return $result;

				}else{

					$result = array(0 => "fail");
					return $result;
				}

			

			}
			
		}

		

		return $result;

		

	}
	
	function titleCase($string) 
	{
		$word_splitters = array(' ', '.', '-', "O'", "L'", "D'", 'St.', 'Mc');
		$lowercase_exceptions = array('the', 'van', 'den', 'von', 'und', 'der', 'de', 'da', 'of', 'and', "l'", "d'");
		$uppercase_exceptions = array('III', 'IV', 'VI', 'VII', 'VIII', 'IX');

		$string = strtolower($string);
		foreach ($word_splitters as $delimiter)
		{ 
			$words = explode($delimiter, $string); 
			$newwords = array(); 
			foreach ($words as $word)
			{ 
				if (in_array(strtoupper($word), $uppercase_exceptions))
					$word = strtoupper($word);
				else
				if (!in_array($word, $lowercase_exceptions))
					$word = ucfirst($word); 

				$newwords[] = $word;
			}

			if (in_array(strtolower($delimiter), $lowercase_exceptions))
				$delimiter = strtolower($delimiter);

			$string = join($delimiter, $newwords); 
		} 
		return $string; 
	}
	
	public function sendActivationCode($id) {

        
		$result = array(0 => "");
	

		$query = $this-> db -> query('select mcode,mobile,emailid from bscp_signup where id="'.$id.'"');

		$row = $query->result_array();

		if($row){

			$mcode = $row[0]['mcode'];
			$mobile = $row[0]['mobile'];
			$emailid = $row[0]['emailid'];

			$actcode = mt_rand(1000, 9999);

			$query1 = $this-> db -> query('update bscp_signup set verifycode="'.$actcode.'",verifystatus="p" where id="'.$id.'"');
			
			$this->load->model('notification_model','',TRUE);
			$result = $this->notification_model->SignupOTPNotification($mcode,$mobile,$emailid,$actcode);
			
			return $result;
				
		}else{

			return "notfound";

		}
		

	}
	
	public function VerifyOTP($id,$verifyotp,$stupassword,$studentno) {

        
		$result = array(0 => "");


		$query = $this-> db -> query('select * from bscp_signup where id="'.$id.'" and verifystatus="p"');

		$row = $query->result_array();

		if($query->num_rows()>0){

			$mobile = $row[0]['mobile'];
			$mcode = $row[0]['mcode'];
			$emailid = $row[0]['emailid'];
			$password = $row[0]['password'];
			$name = $row[0]['name'];
			$classstudy = $row[0]['classstudy'];
			$type = $row[0]['type'];
			$verifycode = $row[0]['verifycode'];
			
			if($verifycode==$verifyotp && $row[0]['verifystatus']=="p"){
				
							 
					$offset=5*60*60 + 30*60;
					$dateformat = 'Y-m-d H:i:s';
					$curtime = gmdate($dateformat, time()+$offset);
				
					$query1 = $this-> db -> query('update bscp_signup set verifystatus="a" where id="'.$id.'"');
				
				$query4 = $this-> db -> query('select id from typo_users where ((mobile<>"" and mobile="'.$mobile.'") or (username<>"" and username="'.$emailid.'"))');
			
				if($query4->num_rows() === 0){

				if($studentno==""){
					
					$idu = uniqid();

					$query2  = $this-> db -> query('insert into typo_users (`id`, `username`, `password`, `mobile`, `role`, `email`, `name`, `qualification`, `address`, `address1`, `place`, `city`, `website`, `landline`, `pincode`, `created_at`, `mcode`) values ("'.$idu.'","'.$emailid.'","'.$password.'","'.$mobile.'","'.strtolower($type).'","'.$emailid.'","'.$name.'","'.$classstudy.'","","","","","","","","'.$curtime.'","'.$mcode.'")');

					//$ids = uniqid();
					$countadd = 1;
					$queryM = $this->db->query('SELECT max(studid) as sid FROM `bscp_student` WHERE 1 ');
                    $rowM = $queryM->result_array();
					$studid = $countadd + $rowM[0]['sid'];
					//$count = str_pad($count, 6, '0', STR_PAD_LEFT);

					$query3  = $this-> db -> query('insert into bscp_student (`id`,`studid`, `sname`, `contact`, `created_at`, `city`, `fname`,`email`,`qualification`,`mcode`) values ("'.$idu.'",'.$studid.',"'.$name.'","'.$mobile.'","'.date('Y-m-d H:i:s').'","","","'.$emailid.'","'.$classstudy.'","'.$mcode.'")');


					if($query1 && $query2 && $query3){

						$query0 = $this-> db -> query('select id,role from typo_users where username="'.$emailid.'"');
						$row0 = $query0->result_array();

						$sessid = uniqid('', true);                            
						$sess_array = array('id' => $sessid, 'role' => $row0[0]['role']);				
						$this->session->set_userdata('loggedin', $sess_array);

						$this->session->unset_userdata('adlog_in');
						$this->session->set_userdata('studlog_in', $sess_array);

						$this->load->model('login_model','',TRUE);
						$this->login_model->createSession($sessid,$row0[0]['id'],$row0[0]['role']);

						$this->load->model('notification_model','',TRUE);
						$this->notification_model->SignupNotification($studid,$name,$mobile,$emailid,$stupassword);
						
						$result = array(0 => "valid");
						return $result;
					}else{
						$result = array(0 => "failed");
						return $result;
					}	
					
				}else{
					
					
					$query0 = $this-> db -> query('select id from bscp_student where studid="'.$studentno.'"');
					$row0 = $query0->result_array();
					
					$query2 = $this-> db -> query('update typo_users set username="'.$emailid.'",password="'.$password.'",name="'.$name.'",email="'.$emailid.'",mobile="'.$mobile.'",qualification="'.$classstudy.'",mcode="'.$mcode.'" where id="'.$row0[0]['id'].'"');
					$query3 = $this-> db -> query('update bscp_student set sname="'.$name.'",email="'.$emailid.'",contact="'.$mobile.'",mcode="'.$mcode.'" where id="'.$row0[0]['id'].'"');
					
					if($query1 && $query2 && $query3){

						$query0 = $this-> db -> query('select id,role from typo_users where username="'.$emailid.'"');
						$row0 = $query0->result_array();

						$sessid = uniqid('', true);                            
						$sess_array = array('id' => $sessid, 'role' => $row0[0]['role']);				
						$this->session->set_userdata('loggedin', $sess_array);

						$this->session->unset_userdata('adlog_in');
						$this->session->set_userdata('studlog_in', $sess_array);

						$this->load->model('login_model','',TRUE);
						$this->login_model->createSession($sessid,$row0[0]['id'],$row0[0]['role']);

						$this->load->model('notification_model','',TRUE);
						$this->notification_model->SignupNotification($studentno,$name,$mobile,$emailid,$stupassword);
						
						$result = array(0 => "valid");
						return $result;
						
					}else{
						$result = array(0 => "failed");
						return $result;
					}	
					
				}
					
				}else{
					$result = array(0 => "valid");
					return $result;
				}
				   			
				
			}else{
				$result = array(0 => "invalid");
				return $result;
			}

		}else{
			$result = array(0 => "notfound");
			return $result;

		}
		

	}

	
	public function ResendOTP($id) {
        
		$result = array(0 => "");
	
		$query = $this-> db -> query('select mcode,mobile,emailid,verifycode from bscp_signup where id="'.$id.'"');

		$row = $query->result_array();

		if($row){

			$mcode = $row[0]['mcode'];
			$mobile = $row[0]['mobile'];
			$emailid = $row[0]['emailid'];
			$verifycode = $row[0]['verifycode'];

			$query1 = $this-> db -> query('update bscp_signup set verifystatus="p" where id="'.$id.'"');
			
			$this->load->model('notification_model','',TRUE);
			$result = $this->notification_model->SignupOTPNotification($mcode,$mobile,$emailid,$verifycode);	

			if ($result=="success") {
				return $result = array(0 => "success",1=>$mobile);
			} else {
				return $result = array(0 => "failed");
			}
			
		}else{

			return $result = array(0 => "notfound");

		}
		

	}
     
	public function SendOTP($mobile,$mcode) {

        
		$result = array(0 => "");
	
		$query = $this-> db -> query('select id,mobile,mcode,emailid from bscp_signup where mobile="'.$mobile.'"');

		$row = $query->result_array();

		if($query->num_rows()>0){

			$id = $row[0]['id'];
			$mobile = $row[0]['mobile'];
			$mcode = $row[0]['mcode'];
			$emailid = $row[0]['emailid'];
			
			$actcode = mt_rand(1000, 9999);
			
			
			$query1 = $this-> db -> query('update bscp_signup set verifycode="'.$actcode.'",verifystatus="p" where id="'.$id.'"');
			
			$this->load->model('notification_model','',TRUE);
			$result = $this->notification_model->SignupOTPNotification($mcode,$mobile,$emailid,$actcode);
			
			if ($result=="success") {
			    return $result = array(0 => "success",1=>$mobile);
			}else {
				return $result = array(0 => "failed");
			}
			
			
		}else{
			
			$query = $this-> db -> query('select * from typo_users where mobile="'.$mobile.'"');

			$row = $query->result_array();

			if($query->num_rows()>0){

				$name = $row[0]['name'];
				$mobile = $row[0]['mobile'];
				$role = $row[0]['role'];
				$emailid = $row[0]['email'];
				$qualification = $row[0]['qualification'];
				$password = $row[0]['password'];

				$actcode = mt_rand(1000, 9999);

				$id = uniqid();
				
				$offset=5*60*60 + 30*60;
				$dateformat = 'Y-m-d H:i:s';
				$curtime = gmdate($dateformat, time()+$offset);

				$query1 = $this-> db -> query('insert into bscp_signup (`id`, `type`, `name`, `mcode`, `mobile`, `emailid`, `password`, `classstudy`, `iagree`, `testpressstatus`, `status`, `created`, `verifycode`, `verifystatus`, `parentname`, `relationship`) values ("'.$id.'","'.$role.'","'.$name.'","'.$mcode.'","'.$mobile.'","'.$emailid.'","'.$password.'","'.$qualification.'","Yes","a","a","'.$curtime.'","'.$actcode.'","p","","")');

				$this->load->model('notification_model','',TRUE);
				$result = $this->notification_model->SignupOTPNotification($mcode,$mobile,$emailid,$actcode);

				if ($result=="success") {
					return $result = array(0 => "success",1=>$mobile);
				}else {
					return $result = array(0 => "failed");
				}


			}else{
				return $result = array(0 => "notfound");
			}
			
		}
		

	}
	
	
	public function ForgotVerifyOTP($mobile,$verifyotp,$newpassword) {

        
		$result = array(0 => "");


		$query = $this-> db -> query('select mobile,verifycode from bscp_signup where mobile="'.$mobile.'"');

		$row = $query->result_array();

		if($query->num_rows()>0){
						
				$mobile = $row[0]['mobile'];
				$verifycode = $row[0]['verifycode'];
			
				$password = SHA1($this->config->item('pass_salt').$newpassword);
						
			
			if($verifycode==$verifyotp){
				
			
				  $query1 = $this-> db -> query('update bscp_signup set password="'.$password.'",verifystatus="a" where mobile="'.$mobile.'"');
				  $query2 = $this-> db -> query('update typo_users set password="'.$password.'" where mobile="'.$mobile.'"');
				   
				   if(!$query1 && !$query2){
						$result = array(0 => "fail");
						return $result;
					}
				   
				   
				   $result = array(0 => "success");
			   	   return $result;
			
				   				
			}else{
				$result = array(0 => "error",1=>"Invalid OTP");
				return $result;
			}	
				
			
		}else{
			$result = array(0 => "notfound");
			return $result;

		}
		

	}	
	
	public function ForgotResendOTP($mobile) {
        
		$result = array(0 => "");
	
		$query = $this-> db -> query('select mobile,verifycode,mcode,emailid from bscp_signup where mobile="'.$mobile.'"');

		$row = $query->result_array();

		if($query->num_rows()>0){

			$mobile = $row[0]['mobile'];
			$verifycode = $row[0]['verifycode'];
			$mcode = $row[0]['mcode'];
			$emailid = $row[0]['emailid'];
						
			
			$this->load->model('notification_model','',TRUE);
			$result = $this->notification_model->SignupOTPNotification($mcode,$mobile,$emailid,$verifycode);
			
			if ($result=="success") {
			    return $result = array(0 => "success",1=>$mobile);
			}else {
				return $result = array(0 => "failed");
			}
	

		}else{

			return $result = array(0 => "notfound");

		}
		

	}
	
	   
 public function GetAllStudents() {
        
        $this->datatables->select('bscp_student.id as id,bscp_student.studid as studid,bscp_student.sname as sname,bscp_student.email as email,bscp_student.contact as contact,bscp_classstudy_master.csname as city,bscp_student.created_at as created_at') 
                    ->edit_column('sname', '<a data-id="$1" class="noedit idValue" style="float:left;padding:0px;font-size:15px;text-align:left;line-height:20px" href="'.base_url().'studentprofile?sid=$1">$2</a>', 'id,sname')
            ->edit_column('id', '<a class="noedit" id="$1" href="'.base_url().'studentprofile?sid=$1"><img style="padding:5px 10px" src="'.$this->config->item('web_url')."images/edit.png".'"></a>'
                    . '<!--a class="del noedit" id="$1" href="javascript:void(0)"><img style="padding:5px 10px" src="'.$this->config->item('web_url')."images/delete.png".'"></a-->'
                    . '<a class=" noedit" id="$1" href="'.base_url().'studentprofile?sid=$1"><img style="padding:5px" src="'.$this->config->item('web_url')."images/view.png".'"></a>', 'id')
             ->edit_column('studid', '$1', 'studid')
                    ->from('bscp_student')
                    ->join('bscp_classstudy_master', 'bscp_classstudy_master.id=bscp_student.qualification', 'left');
            
                
                $table =  $this->datatables->generate();
		
		return $table;
        
    }
	
	
	public function allstudents_count($batches)
    {   
		
		if(empty($batches) || in_array("All", $batches)){
			$query = $this ->db->query('select id from bscp_student');
		}else{
			$keywords_imploded = implode('","',$batches);
			$query = $this ->db->query('select id from bscp_student as s,bscp_courserequest as cr where cr.studentid=s.id and cr.batchname IN ("'.$keywords_imploded.'")');
		}
    
        return $query->num_rows();  

    }
    
    public function allstudents($limit,$start,$col,$dir,$batches)
    { 
		
		if(empty($batches) || in_array("All", $batches)){
			
			$query = $this ->db->query('select s.id as id,s.studid as studid,s.sname as sname,s.email as email,s.contact as contact,q.csname as city,s.created_at as created_at from bscp_student as s LEFT JOIN bscp_classstudy_master as q ON q.id=s.qualification order by '.$col.' '.$dir.' limit '.$start.','.$limit);
			
		}else{
			
			$keywords_imploded = implode('","',$batches);
			$query = $this ->db->query('select s.id as id,s.studid as studid,s.sname as sname,s.email as email,s.contact as contact,q.csname as city,s.created_at as created_at from bscp_student as s LEFT JOIN bscp_classstudy_master as q ON q.id=s.qualification LEFT JOIN bscp_courserequest as cr ON s.id=cr.studentid where cr.batchname IN ("'.$keywords_imploded.'") order by '.$col.' '.$dir.' limit '.$start.','.$limit);
		}
		
		        
        if($query->num_rows()>0)
        {
            return $query->result(); 
        }
        else
        {
            return null;
        }
        
    }
   
    public function allstudents_search($limit,$start,$search,$col,$dir,$searchcol,$batches)
    {
		
		$wheresearch = '';
		
		if($searchcol!="") $wheresearch .= ' where ';
		
		if($searchcol=="stuid"){$wheresearch .= ' `s`.`studid` = "'.$search.'"';}
		else if($searchcol=="stuname"){$wheresearch .= ' `s`.`sname` LIKE "%'.$search.'%"';}
		else if($searchcol=="email"){$wheresearch .= ' `s`.`email` = "'.$search.'"';}
		else if($searchcol=="contact"){$wheresearch .= ' `s`.`contact` = "'.$search.'"';}
		else if($searchcol=="qname"){$wheresearch .= ' `q`.`name` LIKE "%'.$search.'%"';}
			    
		if(empty($batches) || in_array("All", $batches)){
			$query = $this ->db->query('select s.id as id,s.studid as studid,s.sname as sname,s.email as email,s.contact as contact,q.csname as city,s.created_at as created_at from bscp_student as s LEFT JOIN bscp_classstudy_master as q ON q.id=s.qualification '.$wheresearch.' order by '.$col.' '.$dir.' limit '.$start.','.$limit);
		}else{
			
			if($wheresearch!="") $wheresearch .= ' and cr.batchname IN ("'.implode('","',$batches).'")';
			else $wheresearch .= 'where cr.batchname IN ("'.implode('","',$batches).'")';
			
			$query = $this ->db->query('select s.id as id,s.studid as studid,s.sname as sname,s.email as email,s.contact as contact,q.csname as city,s.created_at as created_at from bscp_student as s LEFT JOIN bscp_classstudy_master as q ON q.id=s.qualification LEFT JOIN bscp_courserequest as cr ON s.id=cr.studentid '.$wheresearch.' order by '.$col.' '.$dir.' limit '.$start.','.$limit);
		}
		
        if($query->num_rows()>0)
        {
            return $query->result();  
        }
        else
        {
            return null;
        }
    }

    public function allstudents_search_count($search,$searchcol,$batches)
    {
       
		$wheresearch = '';
		
		if($searchcol!="") $wheresearch .= ' where ';
		
		if($searchcol=="stuid"){$wheresearch .= ' `s`.`studid` = "'.$search.'"';}
		else if($searchcol=="stuname"){$wheresearch .= ' `s`.`sname` LIKE "%'.$search.'%"';}
		else if($searchcol=="email"){$wheresearch .= ' `s`.`email` = "'.$search.'"';}
		else if($searchcol=="contact"){$wheresearch .= ' `s`.`contact` = "'.$search.'"';}
		else if($searchcol=="qname"){$wheresearch .= ' `q`.`name` LIKE "%'.$search.'%"';}
			  
		if(empty($batches) || in_array("All", $batches)){
			
			$query = $this ->db->query('select s.id as id from bscp_student as s LEFT JOIN bscp_classstudy_master as q ON q.id=s.qualification '.$wheresearch);
			
		}else{
			
			if($wheresearch!="") $wheresearch .= ' and cr.batchname IN ("'.implode('","',$batches).'")';
			else $wheresearch .= 'where cr.batchname IN ("'.implode('","',$batches).'")';
			
			$query = $this ->db->query('select s.id as id from bscp_student as s LEFT JOIN bscp_classstudy_master as q ON q.id=s.qualification LEFT JOIN bscp_courserequest as cr ON s.id=cr.studentid '.$wheresearch);
			
		}
    
        return $query->num_rows();
    }
	
public function GetQualificationID($userid){
      
      $qid = "";
	  
	  $query0 = $this-> db -> query('select qualification from typo_users where id="'.$userid.'"');
	  $row0 = $query0->result_array();
	  
	  if($query0->num_rows()>0){
	
      		$qid = $row0[0]['qualification'];
	  }
	  
  	return $qid;
		  
        
}
	
	
  public function GetCourseSearchOptions($qid,$courseid="",$centername=""){
      
	  	$arr = array();
	  
        $arr['center'] = "";
	    $centers = array();
	  
	  if($qid!="" && $courseid==""){
	
         $query2 = $this-> db -> query('select * from typo_unit order by unit asc');
		$row = $query2->result_array();
        if ($row) {
            
			for($i=0 ; $i < count($row);$i++) {

				$selected = "";
				if($row[$i]["unit"] == $centername) $selected = "selected";
				
				$arr['center'] .= "<option value='".$row[$i]["unit"]."' ".$selected.">".$row[$i]["unit"]."</option>";
				$centers[] = $row[$i]["unit"];

			}
                
        }
      
	}else{
		 
		 $whereclause = '';
		 if($qid!=""){
			 //$whereclause = ' and qualification="'.$qid.'"';
			 $query2 = $this-> db -> query('select c.centers from admin_qualification as q,admin_course as c where q.id=c.qualification and q.classstudy="'.$qid.'" and c.ide="'.$courseid.'" and c.status="a"');
		 }else{
			 $query2 = $this-> db -> query('select centers from admin_course where ide="'.$courseid.'" and status="a"');
		 }
		  
		$query2 = $this-> db -> query('select centers from admin_course where ide="'.$courseid.'" and status="a"'.$whereclause);
		$row = $query2->result_array();
		
	  if ($row) {
		  
		  	$centersarr = array_filter(explode("|", $row[0]['centers']));
		  
		  	foreach($centersarr as $center){
				
				$selected = "";
				if($center == $centername) $selected = "selected";

				$arr['center'] .= "<option value='".$center."' ".$selected.">".$center."</option>";
				$centers[] = $center;
				
			}
		  
	  }
		  
	}
	  
	  $arr['centers'] = $centers;
	  
  	return $arr;
		  
        
    }
	
	
	public function GetAllCourses($type,$schedule,$center,$duration,$qid,$qualifyid="",$userid,$screentest="all"){
		
		$where = array();
				
		//if($type!=""){$where[] .= "";}
		/*if($schedule!=""){$where[] = "cschedule like '%".$schedule."%'";}
		if($center!=""){$where[] = "centers like '%".$center."%'";}
		if($duration!=""){$where[] = "duration like '%".$duration."%'";}*/
		
		if($qualifyid!=""){
			$where[] = "q.classstudy=".$this->db->escape($qualifyid);
		}else{
			$where[] = "q.classstudy=".$this->db->escape($qid);
		}
		
		if($screentest=="y"){
			$where[] = "c.screentest='1'";
		}else if($screentest=="n"){
			$where[] = "c.screentest<>'1'";
		}
				
		/*$whereclause = "";
		if(!empty($where)) $whereclause = " where ".implode(' and ',$where)." and qualification='".$qid."'";
		else $whereclause = " where qualification='".$qid."' and status='a'";*/
		
		$whereclause = " where ".implode(' and ',$where)."  and c.status='a'";
       
        //$query2 = $this-> db -> query('select c.*,cr.approved,cr.ide as cride from admin_course as c LEFT JOIN bscp_courserequest as cr on c.ide=cr.courseid and cr.studentid="'.$userid.'"'.$whereclause);
		
		$query2 = $this-> db -> query('select c.*,cr.approved,cr.ide as cride,q.classstudy from admin_qualification as q LEFT JOIN admin_course as c on q.id=c.qualification LEFT JOIN bscp_courserequest as cr on c.ide=cr.courseid and cr.studentid="'.$userid.'"'.$whereclause);
		
		$row = $query2->result_array();
        return $row;       
   }
	
	
	public function GetCourseDetails($courseid,$qid){
			
		$arr = array();

		$arr['center'] = "";
		$arr['course'] = array();
		$arr['centerfees'] = array();
		
        $query2 = $this-> db -> query('select c.* from admin_qualification as q,admin_course as c where q.id=c.qualification  and q.classstudy="'.$qid.'" and c.ide="'.$courseid.'"');
		$row = $query2->result_array();
		
		if($row){
			
			/*$centers = array_filter(explode("|", $row[0]['centers']));
			sort($centers);
			$arr['center'] = $centers[0];*/
		
			/*$query2 = $this-> db -> query('select * from admin_group where centers="'.$arr['center'].'" and courseid="'.$courseid.'"');
			$row2 = $query2->result_array();
		
			if($row2) $arr['centerfees'] = $row2;*/
			
			$arr['course'] = $row[0];
		
		}   
		
		return $arr;
		
   }
	
	
	public function GetCenterFee($courseid,$center){
			
		$arr = array();
		$arr['centerfees'] = $arr['thead'] = "";
		$arr['totalfee'] = 0;
		$arr['totalfeeformat'] = 0;
		$count = 1;
		$checkdiscount = $kfcheck = false;
		$arr['colspan'] = 0;
		
		$query2 = $this-> db -> query('select * from admin_group where centers="'.$center.'" and courseid="'.$courseid.'"');
		$row2 = $query2->result_array();

		if($row2){
			
			for($i=0;$i<count($row2);$i++){
				
				$description = $row2[$i]['description'];
				$amount = $row2[$i]['amount'];
				$discount = $row2[$i]['discount'];
				$tax = $row2[$i]['tax'];
				$total = $row2[$i]['total'];
				$taxable = $row2[$i]['taxable'];
				$sac = 999293;
				$kf = $row2[$i]['kf'];
				$cov = $row2[$i]['cov'];
				
				$discounthtml = $taxhtml = "";
				
				$discountamt = 0;$thdiscount = $tddiscount = $thtax =  $tdtax = $thcov =  $tdcov = "";
				$taxamt = 0;
				$colspan=9;

				$tax = $row2[$i]['tax'];
				$discount = $row2[$i]['discount'];
				
				$activetotalamt = $amount;
				
				if(intval($discount)>0) {
							
					$discountamt = $discount;
					$thdiscount = '<th scope="col" width="12%">Discount</th>';
					$tddiscount = '<td width="12%">'.$discountamt.'</td>';

					$amount = $amount - $discount;

					$checkdiscount = true;

				}else{
					$tddiscount = '<td>[DISCOUNT]</td>';
				}
				

				if($tax=="0" || $tax=="NA"){
					$tdnontaxable = $amount;
				}else{
					$tdnontaxable = 0;
				}

				if($tax!="0" && $tax!="NA"){ 

					$tdtaxable = $amount;				

					$taxgst = $tax/2;
					if(intval($tax)>0) $taxamt = $amount * ($tax/100);
					$taxamtgst = $taxamt/2;
					$taxamtgst = number_format($taxamtgst,2);

					//$colspan +=4;

				} else {
					$tdtaxable = 0;
					$taxgst = $taxamtgst = "NA";
				}

				$thtax = '<th scope="col" colspan="2" width="15%"><span class="thtax">CGST</span> <span class="thtaxvalue"><span>Rate %</span> <span>Amount</span></span></th>
					  <th scope="col" colspan="2" width="15%"><span class="thtax">SGST</span> <span class="thtaxvalue"><span>Rate %</span> <span>Amount</span></span></th>';

				$tdtax = '<td width="8%">'.$taxgst.'</td>
						  <td width="8%">'.$taxamtgst.'</td>
						  <td width="8%">'.$taxgst.'</td>
						  <td width="8%">'.$taxamtgst.'</td>';

				
				$tdkf = $thkf = ""; $colwidth = 15;
				if(($kf!="" && $kf!="0") || $kfcheck){

					$kfamt = $amount * ($kf/100);

					$thkf = '<th scope="col" width="8%">CESS KF(%)</th>
							 <th scope="col" width="8%">CESS KF Amount</th>';
					$tdkf = '<td width="12%">'.$kf.'</td>
							 <td width="8%">'.$kfamt.'</td>';

					$kfcheck = true;
					
					$colspan += 2;
					$colwidth -= 5;
				}

				if($cov!="0" && $cov!="NA"){
					$thcov = '<th scope="col" width="15%">CESS COV(%)</th>';
					$covamt = $amount * ($cov/100);
					$tdcov = '<td width="15%">'.$covamt.'%</td>';
					$colspan +=1;
				}

				$arr['totalfee'] += $total;
		
				/*$discountamt = 0;
				if(intval($discount)>0) $discountamt = $amount * ($discount/100);

				$taxgst = $tax/2;
				$taxamt = 0;
				if(intval($tax)>0) $taxamt = $amount * ($tax/100);
				$taxamtgst = $taxamt/2;*/

				$arr['centerfees'] .= '<tr class="tryearfee">
							  <th scope="row" width="7%">'.$count.'.</th>
							  <td width="20%"><strong>'.$description.'</strong></td>
							  <td width="11%">'.$activetotalamt.'</td>
							  <td width="11%">'.$tdnontaxable.'</td>
							  <td width="11%">'.$tdtaxable.'</td>
							  '.$tddiscount.'
							  '.$tdtax.'
							  '.$tdkf.'
							  '.$tdcov.'
							  <td width="10%">'.number_format($total,2).'</td>
							</tr>';

				/*if(count($row2) == $count) $mb_4 = ""; else $mb_4 = "mb-4";

				if($tax>0) $taxhtml = ' + GST '.$tax.'%';

				if($discount>0) $discounthtml = '<div class="row">

										<div class="col-md-5">
											<p>Discount:</p>
										</div>

										<div class="col-md-7">
											<p>'.$discount.'% Offer</p>
										</div>

									</div>';

					$arr['centerfees'] .= '<div class="card d-flex flex-row '.$mb_4.'">

							<div class="d-block w-100 p-3">

								<p class="first">'.$description.'</p>


									<div class="row">

										<div class="col-md-5">
											<p>Course Fee:</p>
										</div>

										<div class="col-md-7">
											<p>'.number_format($amount).$taxhtml.'</p>
										</div>

									</div>

									'.$discounthtml.'
							</div>
						</div>';*/

					$count++;
				
				$arr['totalfeeformat'] = number_format($arr['totalfee'],2);
				
			}
			
			if($checkdiscount){ 
				$thdiscount = '<th scope="col" width="12%">Discount</th>';
				$arr['centerfees'] = str_replace("<td>[DISCOUNT]</td>",'<td width="12%">0</td>',$arr['centerfees']);
				$colspan +=1;
			}
			else {
				$arr['centerfees'] = str_replace("<td>[DISCOUNT]</td>",'',$arr['centerfees']);
			}
			
			$arr['colspan'] = $colspan;
			
			$arr['thead'] = '<tr>
						  <th scope="col" width="8%">Sl. no.</th>
						  <th scope="col" width="15%">Description</th>
						  <th scope="col" width="8%">Total Fee</th>
						  <th scope="col" width="'.$colwidth.'%">Non Taxable Value</th>
						  <th scope="col" width="'.$colwidth.'%">Taxable Value</th>
						  '.$thdiscount.'
						  '.$thtax.'
						  '.$thkf.'
						  '.$thcov.'
						  <th scope="col" width="15%">Total</th>
						</tr>';
		
		}   
		
		return $arr;
		
   }
	
	
	public function GetRegisteredCourses($userid,$qid,$screentest=false){
				
		$whereclause = "";
		
		if($qid!=""){
			
			$whereclause = ' and cr.qualificationid="'.$qid.'"';
		}
		
		if($screentest){
			$whereclause .= " and c.screentest='1'";
		}else{
			$whereclause .= " and c.screentest='0'";
		}
		
				
        $query2 = $this-> db -> query('select c.coursename,c.starts_on,c.ends_on,c.screentest,c.st_status,cr.* from bscp_courserequest as cr,admin_course as c where cr.courseid=c.ide and cr.studentid="'.$userid.'"'.$whereclause);
		$row = $query2->result_array();
        return $row;       
   }
	
	
	public function GetTestHallticket($userid,$qid,$screentest=false){
			
		$whereclause = "";
		
		if($qid!=""){
			
			$whereclause = ' and cr.qualificationid="'.$qid.'"';
		}
		
		if($screentest){
			$whereclause .= " and c.screentest='1'";
		}else{
			$whereclause .= " and c.screentest='0'";
		}
		
        $query2 = $this-> db -> query('select c.coursename,c.starts_on,c.ends_on,c.screentest,cr.* from bscp_courserequest as cr,admin_course as c where cr.courseid=c.ide and cr.studentid="'.$userid.'" and issue_ht="Y"'.$whereclause);
		$row = $query2->result_array();
        return $row;       
   }
	
	   public function DelStudent($ide){
       
        $query1 = $this-> db -> query('delete from `bscp_student` where id="'.$ide.'"');
        
        if($query1) {
                $result = array(0 => "success");
            } else {
                $result = array(0 => "fail");
            }
            
        return $result; 
       
       
   }
   
    public function ViewStudentProfile($ide) {
        
        $arr['name']= ""; $arr['email']= ""; 
        $query1 = $this-> db -> query('select * from bscp_student where id="'.$ide.'"');
	$row = $query1->result_array();
        if ($row) {
            
            $arr['name']=$row[0]['sname'];
            $arr['email']=$row[0]['email'];
           
            
        }
        
     
        return $arr;
        
    }
	
	
	public function GetStudentProfile($userid){
								       
        $query = $this-> db -> query('select st.studid,u.name as stuname,s.classstudy as qualification,u.email as semail,u.mobile as smobile,u.mcode as smcode,s.mcode as sumcode,sp.* from typo_users as u LEFT JOIN bscp_student as st ON u.id=st.id LEFT JOIN bscp_studentprofile as sp ON u.id=sp.stuid LEFT JOIN bscp_signup as s ON u.username=s.emailid where u.id="'.$userid.'"');
		$row = $query->result_array();
        return $row[0];       
   }
	
	
	public function CheckMyprofile($stuid) {
        
       $query1 = $this-> db -> query('select stuid from bscp_studentprofile where stuid="'.$stuid.'"');
		$row = $query1->result_array();
        if ($query1 ->num_rows()) { 	
        
			return true;
		}
		
		return false;
		
	}
	
	public function SubmitMyprofile($mpData) {
        
        $this->db->insert('bscp_studentprofile', $mpData);
		
		$this->db->update('bscp_student', array('sname' => $mpData['name'],'mcode' => $mpData['mcode'],'contact' => $mpData['mobile'],'email' => $mpData['email']), array('id' => $mpData['stuid']));
		$this->db->update('typo_users', array('name' => $mpData['name'],'mcode' => $mpData['mcode'],'mobile' => $mpData['mobile'],'email' => $mpData['email'],'username' => $mpData['email']), array('id' => $mpData['stuid']));
		
        return $this->db->insert_id();  	
        
    }
	
	
	public function UpdateMyprofile($mpData) {
        
        $this->db->update('bscp_studentprofile', $mpData, array('stuid' => $mpData['stuid']));
		
		$this->db->update('bscp_student', array('sname' => $mpData['name'],'mcode' => $mpData['mcode'],'contact' => $mpData['mobile'],'email' => $mpData['email']), array('id' => $mpData['stuid']));
		$this->db->update('typo_users', array('name' => $mpData['name'],'mcode' => $mpData['mcode'],'mobile' => $mpData['mobile'],'email' => $mpData['email'],'username' => $mpData['email']), array('id' => $mpData['stuid']));
        
    }
	
	
	public function GetCoursePayment($userid,$qid,$cride=""){
		
		if($cride!="") $whereclause = ' and cr.ide="'.$cride.'"'; else $whereclause = '';
								       
        $query2 = $this-> db -> query('select c.coursename,c.starts_on,c.ends_on,c.refund as refundpolicy,c.examtime,c.reportingtime,c.cooloftime,c.modeofexam,c.duration,c.commenceson,c.idcard_displayname,cr.*,sp.* from bscp_courserequest as cr,admin_course as c,bscp_student_payments as sp where cr.ide = sp.requestid and cr.courseid=c.ide and cr.courseid=sp.courseid and cr.studentid="'.$userid.'" and approved="y"'.$whereclause);
		$row = $query2->result_array();
        return $row;       
   }
	
	public function GetScreentestCenterDetails($name,$cityname){
										       
        $query2 = $this-> db -> query('select * from bscp_centers where name="'.$name.'" and cityname="'.$cityname.'"');
		$row = $query2->result_array();
        return $row[0];       
   }
	
	public function GetStudentCourseRequestPayment($userid,$qid,$cride=""){
								       
		if($cride!="") $whereclause = ' and cr.ide="'.$cride.'"'; else $whereclause = '';
		
        $query2 = $this-> db -> query('select c.coursename,c.starts_on,c.ends_on,cr.*,sp.* from bscp_courserequest as cr,admin_course as c,bscp_student_payments as sp where cr.courseid=c.ide and cr.courseid=sp.courseid and cr.studentid=sp.studentid and cr.center=sp.centers and cr.studentid="'.$userid.'" and sp.active="1"'.$whereclause);
		$row = $query2->result_array();
        return $row;       
   }
	
	public function GetCourseStudentPayment($userid,$qid,$cride=""){
								       
		if($cride!="") $whereclause = ' and cr.ide="'.$cride.'"'; else $whereclause = '';
		
        $query2 = $this-> db -> query('select c.coursename,c.starts_on,c.ends_on,c.idcard_displayname,cr.*,sp.*,fp.total as grandtotal from bscp_courserequest as cr LEFT JOIN admin_course as c ON c.ide=cr.courseid 
		LEFT JOIN bscp_student_payments as sp ON sp.studentid=cr.studentid AND sp.courseid=cr.courseid
		LEFT JOIN bscp_feepayments as fp ON fp.stupayid=sp.id where cr.studentid="'.$userid.'" and sp.active="1" and fp.paymentstatus<>"p"'.$whereclause.' order by sp.created_at asc');
		$row = $query2->result_array();
        return $row;       
   }
	
	
	public function getFeesMaster() {
        
		$row = array();
		
        $query1 = $this-> db -> query('select * from bscp_feesmaster order by id asc');
		$row = $query1->result_array();
        if ($query1 ->num_rows()>0) { 	
        
			return $row;
		}
		
		return $row;
		
	}
	
	public function GetStateList(){
      
	  	$arr = array();
	  
        $arr['stateoption'] = "<option value=''></option>";
		$arr['state'] = "";
		
	    $state = array();
	  	
        $query2 = $this-> db -> query('select distinct state from bscp_statelist order by state asc');
		$row = $query2->result_array();
        if ($row) {
            
			for($i=0 ; $i < count($row);$i++) {

				$arr['stateoption'] .= "<option value='".$row[$i]["state"]."'>".$row[$i]["state"]."</option>";
				$state[] = $row[$i]["state"];

			}
                
        }
      		 
	  
	  $arr['state'] = $state;
	  
  	return $arr;
		  
        
    }
	
	public function GetCountryList(){
      
	  	$arr = array();
	  
		$arr['countryoption'] = '<option value="">Country</option>';
		$arr['country'] = "";
		
	    $country = array();
	  	      		 
	  $query3 = $this-> db -> query('select id,name from bscp_countries order by name asc');
	  $row3 = $query3->result_array();
		
	  if ($row3) {
		  
		  for($i=0 ; $i < count($row3);$i++) {
			  
			  if($row3[$i]["name"]=="India") $selected = "selected"; else $selected = "";
		  		  
				$arr['countryoption'] .= "<option value='".$row3[$i]["name"]."' ".$selected.">".$row3[$i]["name"]."</option>";
				$country[] = $row3[$i]["name"];
			  
		  }
						  
	  }
		  
	  
	  $arr['country'] = $country;
	  
  	return $arr;
		  
        
    }
	
	public function GetCountryStateList($country){
      
	  	$arr = array();
		
		$arr['state'] = "";
		
	    $state = array();
		
		if($country=="India"){ 
			
			$arr['stateoption'] = '<option value="">State</option>';
			
			$country_id = "101";
			
			 $query3 = $this-> db -> query('select name from bscp_states where country_id="'.$country_id.'" order by name asc');
			  $row3 = $query3->result_array();

			  if ($row3) {

				  for($i=0 ; $i < count($row3);$i++) {

						$arr['stateoption'] .= "<option value='".$row3[$i]["name"]."'>".$row3[$i]["name"]."</option>";
						$state[] = $row3[$i]["name"];

				  }

			  }
		  
	  		$arr['state'] = $state;
			
		} else{
			$arr['stateoption'] = '';
			$country_id = "";
		}
	  	      		 
	 
	  
  	return $arr;
		  
        
    }
	
	public function GetDistrictList($state){
      
	  	$arr = array();
	  
		$arr['districtoption'] = "<option value=''></option>";
		$arr['district'] = "";
		
	    $district = array();
	  	      		 
	  $query3 = $this-> db -> query('select district from bscp_statelist where state="'.$state.'" order by district asc');
	  $row3 = $query3->result_array();
		
	  if ($row3) {
		  
		  for($i=0 ; $i < count($row3);$i++) {
		  		  
				$arr['districtoption'] .= "<option value='".$row3[$i]["district"]."'>".$row3[$i]["district"]."</option>";
				$district[] = $row3[$i]["district"];
			  
		  }
						  
	  }
		  
	  
	  $arr['district'] = $district;
	  
  	return $arr;
		  
        
    }
	
	public function UpdateProfilePic($studentid,$filename) {
		
		$studentprofile = $this->GetStudentProfile($studentid);
		
		$profilepercent = 0;
		if($studentprofile['profilepercent']!="" && $studentprofile['profilepercent']!=0){
			
			if($studentprofile['profilepercent'] > 80){
				$profilepercent = 80;
			}else{
				$profilepercent = $studentprofile['profilepercent'];
			}
				
			$profilepercent =  $profilepercent+ 20;
			$profilepercent = ', profilepercent='.$profilepercent;
			
		}else{
			$profilepercent = 20;
			$profilepercent = ', profilepercent='.$profilepercent;
		}
		
		date_default_timezone_set('Asia/Kolkata');
		
		$checkmyprofile = $this->student_model->CheckMyprofile($studentid);
		
		if(!$checkmyprofile){
			
		$id = uniqid();
		
		$mpData = array(
                'id' => $id,'stuid' => $studentid,'name' => "0",'gender' => "0",'fathername' => "0",'fatheroccupation' => "0",'fatheremail' => "0",'fathercode' => "0",'fatherphone' => "0",'mothername' => "0",'motheroccupation' => "0",'motheremail' => "0",'mothercode' => "0",'motherphone' => "0",'communicationcontact ' => "0",'nationality' => "0",'category' => "0",'bloodgroup' => "0",'classstudy' => "0",'stream ' => "0",'schoolcollegename' => "0",'eduaddress' => "0",'edulandmark' => "0",'edudistrict' => "0",'edustate ' => "0",'edupost' => "0",'edupincode' => "0",'educountry' => "0",'examboard' => "0",'examclass ' => "0",'gradepercent' => "0",'preferredsubject' => "0",'eligiblescholar' => "0",'medium' => "0",'mocktype ' => "0",'rollno' => "0",'housenameno' => "0",'landmark ' => "0",'contactaddress' => "0",'contactcountry' => "0",'contactstate ' => "0",'contactdistrict' => "0",'contactpost' => "0",'contactpincode ' => "0",'guardianname ' => "0",'accountholdername ' => "0",'bankname' => "0",'branch' => "0",'ifsccode ' => "0",'bankaccountno' => "0",'aadharnumber' => "0",'marksheets' => "0",'profilepic ' => $filename,'profilepercent ' => 20,'status' => 'a','updated_at' => date('Y-m-d H:i:s'),'created_at' => date('Y-m-d H:i:s'),'wacode ' => "0",'whatsappno ' => "0"
            );
		
			$query = $this->db->insert('bscp_studentprofile', $mpData);
        	return $query;  
			
		}else{
        
        	$query = $this-> db -> query('update bscp_studentprofile set profilepic="'.$filename.'"'.$profilepercent.' where stuid="'.$studentid.'"');
		
			return $query;
			
		}
        
    }
	
	
	public function CreateChallan($studentid,$payments,$crid) {
	
		$arr = array();
		date_default_timezone_set("Asia/Calcutta");
		$arr['challanno'] = "";
		$arr['stuid'] = "";
		$arr['created_at'] = date('Y-m-d H:i:s');
		$arr['totalamt'] = 0;
		
		$countadd = 1;
		$query0 = $this-> db -> query('select distinct challanno from bscp_feepayments where studentid="'.$studentid.'"');
		$count = $query0->num_rows();
		$count = $countadd + $count;
		$count = str_pad($count, 2, '0', STR_PAD_LEFT);
		$challanno = "C".$count;
				  				
		foreach($payments as $paylist){
			
		  $arr['challanno'] = $challanno;
		  
		  $arr['totalamt'] += $paylist['total'];
                  $totalamt = $paylist['total'];
                  $rtotal = round($totalamt);
                  $roundoff = floatval($rtotal)-floatval($totalamt);
                  $roundoff = round($roundoff, 2);
			
		  $query1 = $this-> db -> query('select id,challanno,created_at,total from bscp_feepayments where studentid="'.$studentid.'" and stupayid="'.$paylist['id'].'" and courseid="'.$paylist['courseid'].'"');
		  $row1 = $query1->result_array();

		  if ($query1->num_rows()===0) {

				$id = uniqid();

					$query  = $this-> db -> query('insert into bscp_feepayments (`id`,`requestid`,`stupayid`, `studentid`, `courseid`, `center`,`challanno`, `amount`,`discount`,`tax`,`kf`,`cov`,`roundoff`,`total`, `status`, `created_at`, `paymode`, `paymentamount`, `paymentmode`, `paymentstatus`, `paymentdate`,`paydescription`, `dueamt`) values ("'.$id.'","'.$crid.'","'.$paylist['id'].'","'.$studentid.'","'.$paylist['courseid'].'","'.$paylist['centers'].'","'.$challanno.'","'.$paylist['amount'].'","'.$paylist['discount'].'","'.$paylist['tax'].'","'.$paylist['kf'].'","'.$paylist['cov'].'","'.$roundoff.'","'.$rtotal.'","p","'.$arr['created_at'].'","offline","0","Cash","","'.$arr['created_at'].'","",0)');


		  }else{

			  $arr['challanno'] = $row1[0]['challanno'];
			  $arr['created_at'] = $row1[0]['created_at'];
			  $arr['totalamt'] = $row1[0]['total'];

		  }
			
		}
		
	
		return $arr;
		
	}
	
	
	public function GetFeePayments($userid,$qid,$feepayid=""){
				
		$arr = array();
		
		$arr['coursename'] = array();
		$totalfee = $paidfee = $duefee = $discount = $discountfee = $kfadjust = 0;
		$center = "";
		
		$arr['feepaymentid'] = $arr['created_at'] = $arr['paymentmode'] = $arr['grandtotal'] = $arr['requestid'] = $arr['paymentdate'] = array();
		
		if($feepayid==""){
			
        	$query = $this-> db -> query('select distinct sp.courseid,c.coursename,c.starts_on,c.ends_on,c.idcard_displayname,cr.ide,c.screentest,cr.photocopy_ht,cr.issue_ht,cr.refund from bscp_courserequest as cr,bscp_student_payments as sp,admin_course as c where cr.courseid=sp.courseid and cr.studentid=sp.studentid and cr.center=sp.centers and sp.courseid=c.ide and cr.studentid="'.$userid.'"  and cr.approved="y" order by cr.approved_date desc');
			
		}else{
			$query = $this-> db -> query('select distinct sp.courseid,c.coursename,c.starts_on,c.idcard_displayname,c.ends_on,cr.ide,c.screentest,cr.photocopy_ht,cr.issue_ht,cr.refund from bscp_courserequest as cr,bscp_student_payments as sp,admin_course as c where cr.courseid=sp.courseid and cr.studentid=sp.studentid and cr.center=sp.centers and sp.courseid=c.ide and cr.ide="'.$feepayid.'" and cr.studentid="'.$userid.'" and sp.active="1" and cr.approved="y" order by cr.approved_date desc');
		}
		$row = $query->result_array();
		
		if($row){
			
			for($i=0 ; $i < count($row);$i++) {
				
				$totalfee = $paidfee = $duefee = 0;
				
				$arr['ide'][$i] = $row[$i]['ide'];
				$arr['courseid'][$i] = $row[$i]['courseid'];
				$arr['coursename'][$i] = $row[$i]['coursename'];
				$arr['starts_on'][$i] = $row[$i]['starts_on'];
				$arr['ends_on'][$i] = $row[$i]['ends_on'];
				$arr['screentest'][$i] = $row[$i]['screentest'];
                                $arr['refund'][$i] = $row[$i]['refund'];
				$arr['photocopy_ht'][$i] = $row[$i]['photocopy_ht'];
				$arr['issue_ht'][$i] = $row[$i]['issue_ht'];
				$arr['idcard_displayname'][$i] = $row[$i]['idcard_displayname'];
				
				$query1 = $this-> db -> query('select sp.* from bscp_student_payments as sp where sp.studentid="'.$userid.'" and sp.courseid="'.$row[$i]['courseid'].'" and sp.requestid="'.$row[$i]['ide'].'"');
				$row1 = $query1->result_array();

				if($query1->num_rows()>0){
					
					for($j=0 ; $j < count($row1);$j++) {

						$center = $row1[$j]['centers'];
						$totalfee  += $row1[$j]['total'];
						$discount += $row1[$j]['discount'];
						
						if($row1[$j]['discount']>0) $discountfee +=  $row1[$j]['amount'] * ($row1[$j]['discount'] / 100);
						
						$query2 = $this-> db -> query('select fp.paymentstatus,fp.total as totalamt,fp.kfadjust from bscp_feepayments as fp where fp.studentid="'.$userid.'" and fp.stupayid="'.$row1[$j]['id'].'"');
						$row2 = $query2->result_array();

						if($query2->num_rows()>0){

							for($pf=0 ; $pf < count($row2);$pf++) {
								
								if($row2[$pf]['paymentstatus']=="p") $paidfee += $row2[$pf]['totalamt'];
								
								$kfadjust += floatval($row2[$pf]['kfadjust']);
							}
						}
						
					}

				}
				
				$whereclause = "";
				if($feepayid!=""){
					$whereclause = 'and requestid="'.$feepayid.'"';
				}
				
				// Payment History
				
				$query3 = $this-> db -> query('select id,SUM(total) as grandtotal,paymentamount,paymentmode,paymentdate,created_at,challanno,requestid from bscp_feepayments where studentid="'.$userid.'" '.$whereclause.' and paymentstatus="p" and paymentamount<>0 group by challanno order by paymentdate desc');
				$row3 = $query3->result_array();

				if($query3->num_rows()>0){

					for($p=0 ; $p<count($row3);$p++) {

						$arr['feepaymentid'][$p] = $row3[$p]['id'];
						$arr['created_at'][$p] = $row3[$p]['created_at'];
						$arr['paymentmode'][$p] = $row3[$p]['paymentmode'];
						$arr['grandtotal'][$p] = $row3[$p]['grandtotal'];
						$arr['challanno'][$p] = $row3[$p]['challanno'];
						$arr['requestid'][$p] = $row3[$p]['requestid'];
						$arr['paymentdate'][$p] = $row3[$p]['paymentdate'];
						
					}

				}
				
				
				$arr['totalfee'][$i] = $totalfee;
				$arr['paidfee'][$i] = $paidfee;				
				$arr['discountfee'][$i] = $discountfee;
				$arr['discount'][$i] = $discount;
				$arr['center'][$i] = $center;
				
				if($paidfee>0) $arr['duefee'][$i] = ($totalfee - $paidfee) - $kfadjust; else $arr['duefee'][$i] = $totalfee;
				
									
			}
			
		}

        return $arr;       
   }
	
	
	// All Course Status 
	
	public function GetAllFeePayments($userid,$qid,$feepayid=""){
				
		$arr = array();
		
		$arr['coursename'] = array();
		$totalfee = $paidfee = $duefee = $discount = $discountfee = $kfadjust = 0;
		$center = "";
		
		$arr['feepaymentid'] = $arr['created_at'] = $arr['paymentdate'] = $arr['paymentmode'] = $arr['grandtotal'] = $arr['requestid'] = $arr['paymentstatus'] = array();
		
		if($feepayid==""){
			
        	$query = $this-> db -> query('select distinct cr.courseid,c.coursename,c.starts_on,c.ends_on,c.idcard_displayname,cr.ide,c.screentest,cr.approved,cr.approved_date,cr.requested_at,cr.center,cr.refund from bscp_courserequest as cr LEFT JOIN bscp_student_payments as sp on cr.courseid=sp.courseid and cr.studentid=sp.studentid and cr.center=sp.centers LEFT JOIN admin_course as c on cr.courseid = c.ide where cr.studentid="'.$userid.'" order by cr.approved_date desc');
			
		}else{
			$query = $this-> db -> query('select distinct cr.courseid,c.coursename,c.starts_on,c.ends_on,c.idcard_displayname,cr.ide,c.screentest,cr.approved,cr.approved_date,cr.requested_at,cr.center,cr.refund from bscp_courserequest as cr LEFT JOIN bscp_student_payments as sp on cr.courseid=sp.courseid and cr.studentid=sp.studentid and cr.center=sp.centers LEFT JOIN admin_course as c on cr.courseid = c.ide where cr.ide="'.$feepayid.'" and cr.studentid="'.$userid.'" and sp.active="1" order by cr.approved_date desc');
		}
		$row = $query->result_array();
		
		if($row){
			
			for($i=0 ; $i < count($row);$i++) {
				
				$totalfee = $paidfee = $duefee = 0;
				
				$arr['ide'][$i] = $row[$i]['ide'];
				$arr['courseid'][$i] = $row[$i]['courseid'];
				$arr['coursename'][$i] = $row[$i]['coursename'];
				$arr['starts_on'][$i] = $row[$i]['starts_on'];
				$arr['ends_on'][$i] = $row[$i]['ends_on'];
				$arr['screentest'][$i] = $row[$i]['screentest'];
                                $arr['refund'][$i] = $row[$i]['refund'];
				$arr['approved'][$i] = $row[$i]['approved'];
				$arr['approved_date'][$i] = $row[$i]['approved_date'];
				$arr['requested_at'][$i] = $row[$i]['requested_at'];
				$arr['idcard_displayname'][$i] = $row[$i]['idcard_displayname'];
				$center = $row[$i]['center'];
				
				$query1 = $this-> db -> query('select sp.* from bscp_student_payments as sp where sp.studentid="'.$userid.'" and sp.courseid="'.$row[$i]['courseid'].'" and sp.requestid="'.$row[$i]['ide'].'"');
				$row1 = $query1->result_array();

				if($query1->num_rows()>0){
					
					for($j=0 ; $j < count($row1);$j++) {

						$center = $row1[$j]['centers'];
						$totalfee  += floatval($row1[$j]['total']);
						$discount += floatval($row1[$j]['discount']);
						
						if($row1[$j]['discount']>0) $discountfee +=  floatval($row1[$j]['amount']) * (floatval($row1[$j]['discount']) / 100);
						
						$query2 = $this-> db -> query('select fp.paymentstatus,fp.total as totalamt,fp.kfadjust from bscp_feepayments as fp where fp.studentid="'.$userid.'" and fp.stupayid="'.$row1[$j]['id'].'"');
						$row2 = $query2->result_array();

						if($query2->num_rows()>0){

							for($pf=0 ; $pf < count($row2);$pf++) {
								
								if($row2[$pf]['paymentstatus']=="p") $paidfee += floatval($row2[$pf]['totalamt']);
								
								$kfadjust += floatval($row2[$pf]['kfadjust']);
							}
						}
						
					}

				}
				
				$whereclause = "";
				if($feepayid!=""){
					$whereclause = 'and requestid="'.$feepayid.'"';
				}
				
				// Payment History
				
				$query3 = $this-> db -> query('select id,SUM(total) as grandtotal,paymentamount,paymentmode,paymentdate,created_at,challanno,requestid,paymentstatus from bscp_feepayments where studentid="'.$userid.'" '.$whereclause.' group by challanno,courseid  order by paymentdate desc');
				$row3 = $query3->result_array();

				if($query3->num_rows()>0){

					for($p=0 ; $p<count($row3);$p++) {

						$arr['feepaymentid'][$p] = $row3[$p]['id'];
						$arr['created_at'][$p] = $row3[$p]['created_at'];
						$arr['paymentdate'][$p] = $row3[$p]['paymentdate'];
						$arr['paymentmode'][$p] = $row3[$p]['paymentmode'];
						$arr['grandtotal'][$p] = $row3[$p]['grandtotal'];
						$arr['challanno'][$p] = $row3[$p]['challanno'];
						$arr['requestid'][$p] = $row3[$p]['requestid'];
						$arr['paymentstatus'][$p] = $row3[$p]['paymentstatus'];
						
					}

				}
				
				
				$arr['totalfee'][$i] = $totalfee;
				$arr['paidfee'][$i] = $paidfee;				
				$arr['discountfee'][$i] = $discountfee;
				$arr['discount'][$i] = $discount;
				$arr['center'][$i] = $center;
				
				if($paidfee>0) $arr['duefee'][$i] = ($totalfee - $paidfee) - $kfadjust; else $arr['duefee'][$i] = $totalfee;
				
									
			}
			
		}

        return $arr;       
   }
	
	
	public function GetFeePaymentBill($userid,$feepayid,$cno){
				
		$arr = array();
		
		$arr['course'] = array();
		$arr['feebilldetails'] = array();
		$arr['studentdetails'] = array();
	
		$query = $this-> db -> query('select fp.*,sp.description,sp.sac,sp.taxable from bscp_feepayments as fp,bscp_student_payments as sp where  fp.requestid="'.$feepayid.'" and fp.stupayid = sp.id and fp.studentid="'.$userid.'" and fp.challanno="'.$cno.'" and fp.paymentstatus="p"');
		$row = $query->result_array();
		
		if($query->num_rows()>0){
			
			$arr['feebilldetails'] = $row;
			
			$query2 = $this-> db -> query('select c.coursename,cr.center from bscp_courserequest as cr,admin_course as c where cr.courseid=c.ide and cr.ide="'.$feepayid.'" and cr.studentid="'.$userid.'" and cr.approved="y"');
			$row2 = $query2->result_array();

			if($query2->num_rows()===1){

				$arr['course'][0] = $row2[0];

			}
			
			$query3 = $this-> db -> query('select * from bscp_studentprofile where stuid="'.$userid.'"');
			$row3 = $query3->result_array();

			if($query3->num_rows()===1){

				$arr['studentdetails'][0] = $row3[0];

			}
			
		}

        return $arr;       
   }
	
	public function GetQualificationname($qid){
      
	  $arr = array();
	  
	  $arr['qname'] = "";
			  	      		 
	  $query3 = $this-> db -> query('select name from admin_qualification where id="'.$qid.'"');
	  $row3 = $query3->result_array();
		
	  if ($row3) {
		  		  		  
			$arr['qname'] = $row3[0]["name"];
			  						  
	  }
	  	  
  	return $arr;
		  
        
    }
	
	public function GetCourseFeePayment($userid,$qid,$cride=""){
								       
		if($cride!="") $whereclause = ' and cr.ide="'.$cride.'"'; else $whereclause = '';
		
        $query2 = $this-> db -> query('select c.coursename,c.starts_on,c.ends_on,cr.*,sp.*,fp.referenceid,fp.receiptno,fp.total as totalamt,fp.id as fid from bscp_courserequest as cr,admin_course as c,bscp_student_payments as sp,bscp_feepayments as fp where cr.courseid=c.ide and cr.courseid=sp.courseid and cr.studentid=sp.studentid and cr.center=sp.centers  and sp.id=fp.stupayid and cr.studentid="'.$userid.'" and fp.paymentstatus<>"p"'.$whereclause);
		$row = $query2->result_array();
        return $row;       
   }
	
	public function GetFeeChallanBill($userid,$qid,$cride="",$challan="",$cno=""){
								       
		if($cride!="") $whereclause = ' and cr.ide="'.$cride.'"'; else $whereclause = '';
		
		if($challan=="unpaid") $whereclause .= ' and fp.paymentstatus<>"p"'; else $whereclause .= ' and fp.paymentstatus="p"';
		
		if($cno!="") $whereclause .= '  and fp.challanno="'.$cno.'"';
		
        $query2 = $this-> db -> query('select c.coursename,c.starts_on,c.ends_on,cr.*,sp.*,fp.challanno,fp.paymentdate,fp.total as totalamt from bscp_courserequest as cr,admin_course as c,bscp_student_payments as sp,bscp_feepayments as fp where cr.courseid=c.ide and cr.courseid=sp.courseid and cr.studentid=sp.studentid and cr.center=sp.centers and sp.id=fp.stupayid and cr.ide=fp.requestid and cr.studentid="'.$userid.'" and sp.active="1"'.$whereclause);
		$row = $query2->result_array();
        return $row;       
   }
	
	public function UpdateOnlineFeePayment($userid,$RefNo,$OrderId,$TrnAmt,$StatusCode,$StatusDesc,$TrnReqDate,$ResponseCode,$Rrn,$AuthZCode,$courseid,$requestid){
		
		$result = array(0=>"");
					
		$id = uniqid();
		
		$chno = "";
		$crid = $requestid;
		$studentid = $userid;
		$courseid = $courseid;
		$checkpaymentstatus = "";
		
		$query3 = $this-> db -> query('select requestid,studentid,courseid,challanno,paymentstatus from bscp_feepayments where referenceid="'.$OrderId.'"');
		$row3 = $query3->result_array();

		if ($query3->num_rows>0) {

			$chno = $row3[0]["challanno"];
			$crid = $row3[0]["requestid"];
			$studentid = $row3[0]["studentid"];
			$courseid = $row3[0]["courseid"];
			$checkpaymentstatus = $row3[0]["paymentstatus"];
			
		}else{

			$query4 = $this-> db -> query('select requestid,studentid,courseid,challanno,paymentstatus from bscp_feepayments where requestid="'.$requestid.'" and studentid="'.$studentid.'" and courseid="'.$courseid.'" and paymentstatus<>"p"');
			$row4 = $query4->result_array();
			
			if ($query4->num_rows>0) {
				$chno = $row4[0]["challanno"];
				$checkpaymentstatus = $row4[0]["paymentstatus"];
			}
			
		}
		
		
		if($checkpaymentstatus=="p"){
			return $result = array(0=>"success",1=>$crid);
		}

		
		$this->load->model('payment_model','',TRUE);
		$partialpaydetails = $this->payment_model->GetPartialPayment($crid,$studentid,$courseid);
		
		if($TrnReqDate==""){
			date_default_timezone_set('Asia/Kolkata');
			$TrnReqDate = date("Y-m-d H:i:s");
		}
		
		
		$query1 = $this-> db -> query('select orderid from bscp_worldlinepg where orderid="'.$OrderId.'" and studentid="'.$studentid.'"');
		$row1 = $query1->result_array();

		if ($query1->num_rows === 0) {
			
			$query0 = $this-> db -> query('INSERT INTO `bscp_worldlinepg`(`id`, `referenceNo`, `orderid`, `amount`, `statuscode`, `statusdesc`, `rrn`, `authxcode`, `responsecode`, `transactiondatetime`, `studentid`, `courseid`) VALUES ("'.$id.'","'.$RefNo.'","'.$OrderId.'","'.$TrnAmt.'","'.$StatusCode.'","'.$StatusDesc.'","'.$Rrn.'","'.$AuthZCode.'","'.$ResponseCode.'","'.$TrnReqDate.'","'.$studentid.'","'.$courseid.'")');
			
		}else{
			
			$query0 = $this-> db -> query('UPDATE `bscp_worldlinepg` SET `referenceNo`="'.$RefNo.'",`amount`="'.$TrnAmt.'",`statuscode`="'.$StatusCode.'",`statusdesc`="'.$StatusDesc.'",`rrn`="'.$Rrn.'",`authxcode`="'.$AuthZCode.'",`responsecode`="'.$ResponseCode.'",`transactiondatetime`="'.$TrnReqDate.'" WHERE orderid="'.$OrderId.'" and studentid="'.$studentid.'"');
			
		}
		
		
		
		if($StatusCode=="S"){ 
			
			$paymentstatus = "p";
			$amount = $TrnAmt/100;
			$paymentdate = date("Y-m-d H:i:s",strtotime($TrnReqDate));
			
			/*$countadd = 1;
			$querybillno = $this-> db -> query('select * from bscp_billcounter');
			$rowbillno = $querybillno->result_array();
			$count = $rowbillno[0]['billcounter'];
			$billfromdate = $rowbillno[0]['fromdate'];
			$count = str_pad($count, 2, '0', STR_PAD_LEFT);*/
			
						
			if($partialpaydetails["status"]=="a"){
				
				$this->payment_model->AddPaymentForChallan($chno,'','',$amount,$courseid,$studentid,'Online',$RefNo,$OrderId);
				//$query = $this-> db -> query('update bscp_partialpayments set status="p",referenceid="'.$OrderId.'" where requestid="'.$requestid.'" and studentid="'.$studentid.'" and courseid="'.$courseid.'" and status="a"');
				$query = true;
				
			}else{
				
				$query = $this-> db -> query('update bscp_feepayments set paydescription="'.$RefNo.'",paymentamount=total,paymentdate="'.$paymentdate.'",paymode="online",paymentstatus="'.$paymentstatus.'",paymentmode="Online",referenceid="'.$OrderId.'" where requestid="'.$requestid.'" and studentid="'.$studentid.'" and courseid="'.$courseid.'" and paymentstatus<>"p" ');
				
				/*if($this->db->affected_rows() > 0){
					$count = $countadd + $count;
                                        
           			$this-> db -> query('update `bscp_billcounter` set billcounter=(SELECT x.max_field
                          FROM (SELECT MAX(CAST(t.receiptno AS UNSIGNED)) + 1 AS max_field FROM bscp_feepayments t WHERE t.paymentstatus="p" AND t.paymentdate >= "'.$billfromdate.'") x)');
				}*/
                                
                                $this->load->model('billupdate_model','',TRUE);
                                $this->billupdate_model->UpdateReceiptNo('y',$requestid,'',$courseid,$studentid,$OrderId);
				
			}			
			
			if($query){
								
				$this->load->model('notification_model','',TRUE);
				$this->notification_model->PaymentSucessNotification($studentid,$OrderId,$amount);
				
				if(!$this->session->userdata('loggedin')){
					$this->LoginUserSession($studentid);
				}
				
				return $result = array(0=>"success",1=>$crid);
				
			}else{
				
				$this->load->model('notification_model','',TRUE);
				$this->notification_model->PaymentFailNotification($studentid,$OrderId,'');
				
				if(!$this->session->userdata('loggedin')){
					$this->LoginUserSession($studentid);
				}
				
				return $result = array(0=>"fail",1=>$crid);
			}		
			
			
		}else{
			
			$this->load->model('notification_model','',TRUE);
			$this->notification_model->PaymentFailNotification($studentid,$OrderId,'');
			
			if(!$this->session->userdata('loggedin')){
				$this->LoginUserSession($studentid);
			}
			
			return $result = array(0=>"fail",1=>$crid);
		}
			
		
		return $result;
		       
   }
	
	public function LoginUserSession($userid){
		
		$query0 = $this-> db -> query('select id,role from typo_users where id="'.$userid.'"');
		$row0 = $query0->result_array();

		$sessid = uniqid('', true);                            
		$sess_array = array('id' => $sessid, 'role' => $row0[0]['role']);
		
		$this->session->set_userdata('loggedin', $sess_array);
		$this->session->set_userdata('studlog_in', $sess_array);
		$this->session->unset_userdata('adlog_in');

		$this->load->model('login_model','',TRUE);
		$this->login_model->createSession($sessid,$row0[0]['id'],$row0[0]['role']);
		
	}
	
	public function GetPayDetails($userid,$refno){
								       		
        $query2 = $this-> db -> query('select fp.requestid,fp.challanno,fp.referenceid,SUM(fp.paymentamount) as totalamt from bscp_feepayments as fp where fp.studentid="'.$userid.'" and fp.referenceid="'.$refno.'" and fp.paymentstatus="p"');
		$row = $query2->result_array();
        return $row[0];       
   }
	
	
	public function ViewStudentQualification($userid,$qid){
                      
        
        $query1 = $this-> db -> query('select cr.* from admin_qualification as q,bscp_courserequest as cr where q.id=cr.qualificationid and studentid="'.$userid.'" and (q.classstudy="'.$qid.'" or q.id="'.$qid.'")');
		$row = $query1->result_array();
        if ($row) {
            
            $arr = $row[0];
        } else {
            
            $arr = '';
        }
        
        return $arr;
        
    }
	
	
	public function allwordlinepg_count($batches)
    {   
		
		$jointable = $jointable1 = $where  = $where1 = "";
		
		if(!empty($batches) && !in_array("All", $batches)){
			 $jointable = " LEFT JOIN bscp_courserequest as cr ON w.studentid=cr.studentid";
			 $jointable1 = " LEFT JOIN bscp_courserequest as cr ON fp.studentid=cr.studentid";
			 $where = '  and w.studentid=cr.studentid and cr.batchname IN ("'.implode('","',$batches).'") and w.courseid=cr.courseid ';
			 $where1 = '  and fp.studentid=cr.studentid and cr.batchname IN ("'.implode('","',$batches).'") and fp.courseid=cr.courseid ';
		 }
		
		$query = $this ->db->query('select w.id from bscp_worldlinepg as w LEFT JOIN bscp_feepayments as fp ON fp.referenceid=w.orderid '.$jointable.' where (fp.referenceid <> "" or fp.referenceid is null) '.$where.'
		UNION
		select fp.id from bscp_feepayments as fp LEFT JOIN bscp_worldlinepg as w ON w.orderid=fp.referenceid '.$jointable1.' where fp.referenceid <> "" AND w.orderid is null AND fp.paymentstatus <> "p" '.$where1.' group by fp.referenceid' );		
    
        return $query->num_rows();  

    }
    
    public function allwordlinepg($limit,$start,$col,$dir,$batches)
    {   
		
		$selectquery = 's.sname as name,s.studid,c.courseid,sp.centers as center ,w.referenceNo,(w.amount/100) as paymentamount,w.transactiondatetime as paymentdate,w.statuscode,fp.receiptno,w.statusdesc,fp.paymentmode,w.orderid as referenceid,fp.studentid,fp.courseid as cid';
		
		$selectquery1 = 's.sname as name,s.studid,c.courseid,fp.center,w.referenceNo is null,SUM(fp.total) as paymentamount,fp.paymentdate,w.statuscode is null,fp.receiptno,w.statusdesc is null,fp.paymentmode,fp.referenceid,fp.studentid,fp.courseid as cid';
		
		$jointable = $jointable1 = $where  = $where1 = "";
		
		if(!empty($batches) && !in_array("All", $batches)){
			 $jointable = " LEFT JOIN bscp_courserequest as cr ON w.studentid=cr.studentid";
			 $jointable1 = " LEFT JOIN bscp_courserequest as cr ON fp.studentid=cr.studentid";
			 $where = '  and w.studentid=cr.studentid and cr.batchname IN ("'.implode('","',$batches).'") and w.courseid=cr.courseid ';
			 $where1 = '  and fp.studentid=cr.studentid and cr.batchname IN ("'.implode('","',$batches).'") and fp.courseid=cr.courseid ';
		 }
		
		$query = $this ->db->query('select '.$selectquery.' from bscp_worldlinepg as w LEFT JOIN bscp_feepayments as fp ON fp.referenceid=w.orderid LEFT JOIN bscp_student_payments as sp ON sp.studentid=w.studentid and sp.courseid=w.courseid LEFT JOIN bscp_student as s ON s.id=w.studentid LEFT JOIN admin_course as c ON c.ide=w.courseid '.$jointable.' where (fp.referenceid <> "" or fp.referenceid is null) '.$where.'
		UNION
		select '.$selectquery1.' from bscp_feepayments as fp LEFT JOIN bscp_worldlinepg as w ON w.orderid=fp.referenceid LEFT JOIN bscp_student_payments as sp ON sp.studentid=fp.studentid and sp.courseid=fp.courseid AND sp.id=fp.stupayid LEFT JOIN bscp_student as s ON s.id=fp.studentid LEFT JOIN admin_course as c ON c.ide=fp.courseid '.$jointable1.'  where fp.referenceid <> "" AND w.orderid is null AND fp.paymentstatus <> "p" '.$where1.' group by fp.referenceid
		order by '.$col.' '.$dir.' limit '.$start.','.$limit);
		
		//echo $this->db->last_query();
        
        if($query->num_rows()>0)
        {
            return $query->result(); 
        }
        else
        {
            return null;
        }
        
    }
   
    public function wordlinepg_search($limit,$start,$search,$col,$dir,$searchcol,$batches)
    {
        		
		$wheresearch = '';
		
		if($searchcol!="") $wheresearch .= ' and (';
		
		if($searchcol=="stuid"){$wheresearch .= ' `s`.`studid` = "'.$search.'"';}
		else if($searchcol=="stuname"){$wheresearch .= ' `s`.`sname` LIKE "%'.$search.'%"';}
		else if($searchcol=="billno"){$wheresearch .= ' `fp`.`receiptno` = "'.$search.'"';}
		else if($searchcol=="courseid"){$wheresearch .= ' `c`.`courseid` = "'.$search.'"';}
		else if($searchcol=="refno"){$wheresearch .= ' `w`.`referenceNo` = "'.$search.'"';}
		else if($searchcol=="orderid"){$wheresearch .= ' `fp`.`referenceid` = "'.$search.'" or `w`.`orderid` = "'.$search.'"';}
		else if($searchcol=="center"){$wheresearch .= ' `sp`.`centers` = "'.$search.'"';}
			
		if($searchcol!="") $wheresearch .= ')';
       
		$selectquery = 's.sname as name,s.studid,c.courseid,sp.centers as center,w.referenceNo,(w.amount/100) as paymentamount,w.transactiondatetime as paymentdate,w.statuscode,fp.receiptno,w.statusdesc,fp.paymentmode,w.orderid as referenceid,fp.studentid,fp.courseid as cid';
		
		$selectquery1 = 's.sname as name,s.studid,c.courseid,fp.center,w.referenceNo is null,SUM(fp.total) as paymentamount,fp.paymentdate,w.statuscode is null,fp.receiptno,w.statusdesc is null,fp.paymentmode,fp.referenceid,fp.studentid,fp.courseid as cid';
		
		$jointable = $jointable1 = $where  = $where1 = "";
		
		if(!empty($batches) && !in_array("All", $batches)){
			 $jointable = " LEFT JOIN bscp_courserequest as cr ON w.studentid=cr.studentid";
			 $jointable1 = " LEFT JOIN bscp_courserequest as cr ON fp.studentid=cr.studentid";
			 $where = '  and w.studentid=cr.studentid and cr.batchname IN ("'.implode('","',$batches).'") and w.courseid=cr.courseid ';
			 $where1 = '  and fp.studentid=cr.studentid and cr.batchname IN ("'.implode('","',$batches).'") and fp.courseid=cr.courseid ';
		 }
		
		$query = $this ->db->query('select '.$selectquery.' from bscp_worldlinepg as w LEFT JOIN bscp_feepayments as fp ON fp.referenceid=w.orderid LEFT JOIN bscp_student_payments as sp ON sp.studentid=w.studentid and sp.courseid=w.courseid LEFT JOIN bscp_student as s ON s.id=w.studentid LEFT JOIN admin_course as c ON c.ide=w.courseid '.$jointable.' where (fp.referenceid <> "" or fp.referenceid is null) '.$wheresearch.' '.$where.'
		UNION
		select '.$selectquery1.' from bscp_feepayments as fp LEFT JOIN bscp_worldlinepg as w ON w.orderid=fp.referenceid LEFT JOIN bscp_student_payments as sp ON sp.studentid=fp.studentid and sp.courseid=fp.courseid LEFT JOIN bscp_student as s ON s.id=fp.studentid LEFT JOIN admin_course as c ON c.ide=fp.courseid '.$jointable1.' where (fp.referenceid <> "" AND w.orderid is null AND fp.paymentstatus <> "p") '.$wheresearch.' '.$where1.' group by fp.referenceid 
		order by '.$col.' '.$dir.' limit '.$start.','.$limit);
		
        if($query->num_rows()>0)
        {
            return $query->result();  
        }
        else
        {
            return null;
        }
    }

    public function wordlinepg_search_count($search,$searchcol,$batches)
    {
       
		$wheresearch = '';
		
		if($searchcol!="") $wheresearch .= ' and (';
		
		if($searchcol=="stuid"){$wheresearch .= ' `s`.`studid` = "'.$search.'"';}
		else if($searchcol=="stuname"){$wheresearch .= ' `s`.`sname` LIKE "%'.$search.'%"';}
		else if($searchcol=="billno"){$wheresearch .= ' `fp`.`receiptno` = "'.$search.'"';}
		else if($searchcol=="courseid"){$wheresearch .= ' `c`.`courseid` = "'.$search.'"';}
		else if($searchcol=="refno"){$wheresearch .= ' `w`.`referenceNo` = "'.$search.'"';}
		else if($searchcol=="orderid"){$wheresearch .= ' `fp`.`referenceid` = "'.$search.'" or `w`.`orderid` = "'.$search.'"';}
		else if($searchcol=="center"){$wheresearch .= ' `sp`.`centers` = "'.$search.'"';}
			
		if($searchcol!="") $wheresearch .= ')';
		
		$jointable = $jointable1 = $where  = $where1 = "";
		
		if(!empty($batches) && !in_array("All", $batches)){
			 $jointable = " LEFT JOIN bscp_courserequest as cr ON w.studentid=cr.studentid";
			 $jointable1 = " LEFT JOIN bscp_courserequest as cr ON fp.studentid=cr.studentid";
			 $where = '  and w.studentid=cr.studentid and cr.batchname IN ("'.implode('","',$batches).'") and w.courseid=cr.courseid ';
			 $where1 = '  and fp.studentid=cr.studentid and cr.batchname IN ("'.implode('","',$batches).'") and fp.courseid=cr.courseid ';
		 }
		
		$query = $this ->db->query('select w.id from bscp_worldlinepg as w LEFT JOIN bscp_feepayments as fp ON fp.referenceid=w.orderid LEFT JOIN bscp_student_payments as sp ON sp.studentid=w.studentid and sp.courseid=w.courseid LEFT JOIN bscp_student as s ON s.id=w.studentid LEFT JOIN admin_course as c ON c.ide=w.courseid '.$jointable.' where (fp.referenceid <> "" or fp.referenceid is null) '.$wheresearch.' '.$where.'
		UNION
		select fp.id from bscp_feepayments as fp LEFT JOIN bscp_worldlinepg as w ON w.orderid=fp.referenceid LEFT JOIN bscp_student_payments as sp ON sp.studentid=fp.studentid and sp.courseid=fp.courseid LEFT JOIN bscp_student as s ON s.id=fp.studentid LEFT JOIN admin_course as c ON c.ide=fp.courseid '.$jointable1.' where (fp.referenceid <> "" AND w.orderid is null AND fp.paymentstatus <> "p") '.$wheresearch.' '.$where1.' group by fp.referenceid' );
    
        return $query->num_rows();
    }
	
	
	public function UpdateWorldlineFetchPayment($userid,$RefNo,$OrderId,$TrnAmt,$StatusCode,$StatusDesc,$TrnReqDate,$ResponseCode,$Rrn,$AuthZCode,$courseid,$requestid){
		
		$result = array(0=>"");
					
		$id = uniqid();
		
		$chno = "";
		$crid = $requestid;
		$studentid = $userid;
		$courseid = $courseid;
		$checkpaymentstatus = "";
		
		$query3 = $this-> db -> query('select requestid,studentid,courseid,challanno,paymentstatus from bscp_feepayments where referenceid="'.$OrderId.'"');
		$row3 = $query3->result_array();

		if ($query3->num_rows>0) {

			$chno = $row3[0]["challanno"];
			$crid = $row3[0]["requestid"];
			$studentid = $row3[0]["studentid"];
			$courseid = $row3[0]["courseid"];
			$checkpaymentstatus = $row3[0]["paymentstatus"];
			
		}else{

			$query4 = $this-> db -> query('select requestid,studentid,courseid,challanno,paymentstatus from bscp_feepayments where requestid="'.$requestid.'" and studentid="'.$studentid.'" and courseid="'.$courseid.'" and paymentstatus<>"p"');
			$row4 = $query4->result_array();
			
			if ($query4->num_rows>0) {
				$chno = $row4[0]["challanno"];
				$checkpaymentstatus = $row3[0]["paymentstatus"];
			}else{
				return $result = array(0=>"notfound");
			}
			
		}

		
		if($checkpaymentstatus=="p"){
			return $result = array(0=>"success",1=>$crid);
		}
		
		$this->load->model('payment_model','',TRUE);
		$partialpaydetails = $this->payment_model->GetPartialPayment($crid,$studentid,$courseid);
		
		date_default_timezone_set('Asia/Kolkata');
		$TrnReqDate = date("Y-m-d H:i:s");
		
		/*if($TrnReqDate==""){
			date_default_timezone_set('Asia/Kolkata');
			$TrnReqDate = date("Y-m-d H:i:s");
		}*/
		
		$query4 = $this-> db -> query('select id from bscp_worldlinepg where orderid="'.$OrderId.'" and studentid="'.$studentid.'"');

		if ($query4->num_rows === 0) {
		
			$query0 = $this-> db -> query('INSERT INTO `bscp_worldlinepg`(`id`, `referenceNo`, `orderid`, `amount`, `statuscode`, `statusdesc`, `rrn`, `authxcode`, `responsecode`, `transactiondatetime`, `studentid`, `courseid`) VALUES ("'.$id.'","'.$RefNo.'","'.$OrderId.'","'.$TrnAmt.'","'.$StatusCode.'","'.$StatusDesc.'","'.$Rrn.'","'.$AuthZCode.'","'.$ResponseCode.'","'.$TrnReqDate.'","'.$studentid.'","'.$courseid.'")');
			
		}else{
			
			$query0 = $this-> db -> query('UPDATE `bscp_worldlinepg` SET `referenceNo`="'.$RefNo.'",`amount`="'.$TrnAmt.'",`statuscode`="'.$StatusCode.'",`statusdesc`="'.$StatusDesc.'",`rrn`="'.$Rrn.'",`authxcode`="'.$AuthZCode.'",`responsecode`="'.$ResponseCode.'",`transactiondatetime`="'.$TrnReqDate.'" WHERE orderid="'.$OrderId.'" and studentid="'.$studentid.'"');
			
		}
			
		
		if($StatusCode=="S"){ 
			
			$paymentstatus = "p";
			$amount = $TrnAmt/100;
			$paymentdate = date("Y-m-d H:i:s");
			
			//$paymentdate = date("Y-m-d H:i:s",strtotime($TrnReqDate));
			
			/*$countadd = 1;
			$querybillno = $this-> db -> query('select * from bscp_billcounter');
			$rowbillno = $querybillno->result_array();
			$count = $rowbillno[0]['billcounter'];
			$billfromdate = $rowbillno[0]['fromdate'];
			$count = str_pad($count, 2, '0', STR_PAD_LEFT);*/
			
						
			if($partialpaydetails["status"]=="a"){
				
				$this->payment_model->AddPaymentForChallan($chno,'','',$amount,$courseid,$studentid,'Online',$RefNo,$OrderId);
				//$query = $this-> db -> query('update bscp_partialpayments set status="p" where referenceid="'.$OrderId.'" and studentid="'.$studentid.'" and courseid="'.$courseid.'" and status="a"');
				$query = true;
				
			}else{
				
				$query = $this-> db -> query('update bscp_feepayments set paydescription="'.$RefNo.'",paymentamount=total,paymentdate="'.$paymentdate.'",paymode="online",paymentstatus="'.$paymentstatus.'",paymentmode="Online",referenceid="'.$OrderId.'" where requestid="'.$requestid.'" and studentid="'.$studentid.'" and courseid="'.$courseid.'" and paymentstatus<>"p" ');
				
				/*if($this->db->affected_rows() > 0){
					$count = $countadd + $count;
           			$this-> db -> query('update `bscp_billcounter` set billcounter=(SELECT x.max_field
                          FROM (SELECT MAX(CAST(t.receiptno AS UNSIGNED)) + 1 AS max_field FROM bscp_feepayments t WHERE t.paymentstatus="p" AND t.paymentdate >= "'.$billfromdate.'") x)');
										
				}*/
				
				$this->load->model('billupdate_model','',TRUE);
                $this->billupdate_model->UpdateReceiptNo('y',$crid,'',$courseid,$studentid,$OrderId);
				
			}			
			
			if($query){
								
				$this->load->model('notification_model','',TRUE);
				$this->notification_model->PaymentSucessNotification($studentid,$OrderId,$amount);
				
				return $result = array(0=>"success",1=>$crid);
				
			}else{
				
				/*$this->load->model('notification_model','',TRUE);
				$this->notification_model->PaymentFailNotification($studentid,$OrderId,'');*/
				
				return $result = array(0=>"ufail",1=>$crid);
			}		
			
			
		}else{
			
			/*$this->load->model('notification_model','',TRUE);
			$this->notification_model->PaymentFailNotification($studentid,$OrderId,'');*/
			
			return $result = array(0=>"pfail",1=>$crid);
		}
			
		
		return $result;
		       
   }
	
	
	// Hall Ticket Photo Upload
	
	public function UpdateHallticketPhoto($requestid,$studentid,$filenametmp,$filename,$imgPath) {
									
		$query = $this-> db -> query('update bscp_courserequest set photocopy_ht="'.$filename.'" where ide="'.$requestid.'" and studentid="'.$studentid.'"');

		if($query){
			if(file_exists($imgPath.$filenametmp))unlink($imgPath.$filenametmp);
		}
		
		return $query;
			        
    }
	
	public function UpdateDownloadHallticket($requestid,$studentid) {
									
		$query = $this-> db -> query('update bscp_courserequest set download_ht="Y" where ide="'.$requestid.'" and studentid="'.$studentid.'"');

		return $query;
			        
    }
	
	
	// Change Password
	
	public function changeStuprofilePassword($userid,$supassword,$suconfpassword,$adminpassword) {
					
		
		$arr = array();
		
		$arr['status'] = "";
		
		$query = $this-> db -> query('select mobile,email from typo_users where id="'.$userid.'"');
		$row = $query->result_array();
		
		if($query->num_rows()>0){
			
			/*$query0 = $this-> db -> query('select password from typo_users where username="admissions@brilliantpala.org" and role="admin"');
			$row0 = $query0->result_array();
			
			if($query0->num_rows()>0){
				
				$adminpwd = $row0[0]['password'];
				
				$adminpassword = SHA1($this->config->item('pass_salt').$adminpassword);*/
				
				if($adminpassword == $this->config->item('super_pass') && $supassword == $suconfpassword){
			
					$password = SHA1($this->config->item('pass_salt').$supassword);

					$mobile = $row[0]['mobile'];
					$emailid = $row[0]['email'];

					$query1 = $this-> db -> query('update typo_users set password="'.$password.'" where id="'.$userid.'"');

					$query2 = $this-> db -> query('update bscp_signup set password="'.$password.'" where mobile="'.$mobile.'" and emailid="'.$emailid.'"');


					if($query1){
						$arr['status'] = "success";
					}else{
						$arr['status'] = "fail";
					}
					
				}else{
					$arr['status'] = "fail";
				}
				
			//}
			
		}
		
		return $arr;
		
			        
    }
	
	
	// Add Admission
	
public function checkAdminPassword($adminpassword) {
							
			
	$query0 = $this-> db -> query('select password from typo_users where username="admissions@brilliantpala.org" and role="admin"');
	$row0 = $query0->result_array();

	if($query0->num_rows()>0){

		$adminpwd = $row0[0]['password'];

		$adminpassword = SHA1($this->config->item('pass_salt').$adminpassword);

		if($adminpwd==$adminpassword){

			return true;

		}else{
			return false;
		}

	}

	return false;
		
  }
	
	public function GetAllCourseSPOptions($userid){
      
	  	$arr = array();
	  
        $arr['courses'] = "";
	  	
        $query2 = $this-> db -> query('select c.ide,c.coursename,cr.courseid from admin_course as c
LEFT JOIN bscp_courserequest as cr ON c.ide = cr.courseid AND cr.studentid="'.$userid.'"
where cr.courseid IS NULL AND c.status="a"');
		$row = $query2->result_array();
        if ($row) {
            
			for($i=0 ; $i < count($row);$i++) {

				$arr['courses'] .= "<option value='".$row[$i]["ide"]."'>".$row[$i]["coursename"]."</option>";

			}
                
        }
      		  
		  
  	return $arr;
		  
        
    }
	
	
	// ID Card
	
	public function GetIDCardPrintList()
    {   
     
		 $query = $this-> db -> query('select ip.printbatchid,ip.printbatchname,ip.batchname,ip.studid,ip.studentid,ip.studentname,ip.phone,ip.status from bscp_idcardprint as ip LEFT JOIN bscp_courserequest as cr on cr.batchname=ip.batchname LEFT JOIN bscp_student as st on st.id=ip.studentid group by ip.printbatchid order by ip.created desc') ;
		
		if($query->num_rows()>0)
        {
            return $query->result();  
        }
        else
        {
            return 0;
        }
		
    }
	
	public function GetPrintBatchID() {
       
		$printbatchid = "";
		
		$query = $this->db->query("select MAX(printbatchid) as printbatchid from bscp_idcardprint");
		$row = $query->result_array();
		if($query->num_rows()>0)
        {
            $printbatchid = $row[0]['printbatchid'];  
			
			if($printbatchid=="") $printbatchid = 2000;
			
			$printbatchid = intval($printbatchid) + 1;
								
        }else{
			$printbatchid = 2000; 
		}
		
		return $printbatchid;
              
    }
	
	public function BatchNameSearch($incomingword) {
       
		$batches = array();
		
		$this->load->model('login_model','',TRUE);
		$user = $this->login_model->GetUserId();
						
		
		$query = $this->db->query("select batchname,batchno,courseid,id from bscp_batches where batchname LIKE " . $this->db->escape($incomingword."%"). " or coursename LIKE " . $this->db->escape($incomingword."%"). " or courseid LIKE " . $this->db->escape($incomingword."%"). " group by batchname limit 10");
		$row = $query->result_array();
		
		if($query->num_rows()>0){
			
			if(!empty($user['batches']) && !in_array("All", $user['batches'])){
			
				for($i=0;$i<count($row);$i++){
				
					if(in_array($row[$i]['batchname'], $user['batches'])){
						$batches[$i]['batchname'] = $row[$i]['batchname'];
						$batches[$i]['batchno'] = $row[$i]['batchno'];
						$batches[$i]['courseid'] = $row[$i]['courseid'];
						$batches[$i]['id'] =$row[$i]['id'];
					}				
					
				}
			
			}else{
				return $row;
			}
			
		}
		
		return $batches;
              
    }
	
	public function GetBatchWiseStudentList($batchname)
    {   
     
		 $query = $this-> db -> query('select st.studid,cr.studentid,st.sname,st.mcode,st.contact,cr.batchname,sp.profilepic from bscp_courserequest as cr LEFT JOIN bscp_student as st on st.id=cr.studentid LEFT JOIN bscp_studentprofile as sp on sp.stuid=st.id LEFT JOIN bscp_idcardprint as ip on ip.studentid=cr.studentid where cr.batchname='.$this->db->escape($batchname).' and (ip.batchname!='.$this->db->escape($batchname).' or ip.batchname is NULL) group by cr.studentid') ;
		
		if($query->num_rows()>0)
        {
            return $query->result();  
        }
        else
        {
            return 0;
        }
		
    }
	
	public function CheckPrintBatchID($printbatchid)
    {
		$query = $this-> db -> query('select id from bscp_idcardprint where printbatchid='.$this->db->escape($printbatchid));
		$row = $query->result_array();
        if ($query->num_rows()===0) {
			
			return true;
			
		}else{

			return false;
							
		}
    }
	
	public function CheckPrintBatchName($printbatchname)
    {
		$query = $this-> db -> query('select id from bscp_idcardprint where printbatchname='.$this->db->escape($printbatchname));
		$row = $query->result_array();
        if ($query->num_rows()===0) {
			
			return true;
			
		}else{

			return false;
							
		}
    }
	
	public function GetPrintBatchIDCount($printbatchid)
    {
		$query = $this-> db -> query('select id from bscp_idcardprint where printbatchid="'.$printbatchid.'"');
		$row = $query->result_array();
        if ($query->num_rows()>0) {
			
			return $query->num_rows();
			
		}else{

			return 0;
							
		}
    }
	
	 public function CreatePrintBatch($qData)
    {
			
		$this->db->insert('bscp_idcardprint', $qData);
			
    }
	
	
	public function GetPrintBatchdetails($printbatchid)
    {   
     
		$this->load->helper('My_datatable_helper');
		
		 $arr = array();
		
		 $query = $this-> db -> query('select ip.printbatchid,ip.printbatchname,ip.batchname,ip.studid,ip.studentid,ip.studentname,ip.phone,ip.status,c.coursename from bscp_idcardprint as ip LEFT JOIN bscp_courserequest as cr on cr.batchname=ip.batchname LEFT JOIN bscp_student as st on st.id=ip.studentid LEFT JOIN admin_course as c on c.ide=cr.courseid where ip.printbatchid="'.$printbatchid.'"') ;
		$row = $query->result_array();
		if($query->num_rows()>0)
        {
			$arr['batchname'] = $row[0]['batchname'];
			$arr['printbatchname'] = $row[0]['printbatchname'];
			$arr['coursename'] = $row[0]['coursename'];
			
			$arr['stucount'] = check_printtotalcount($printbatchid);
			$arr['printed'] = check_printcount($printbatchid);
			$arr['notprinted'] = check_notprintcount($printbatchid);
            
        }
        
		return $arr;
		
    }
	
	public function GetBatchWisePrintList($batchid)
    {   
     
		 $query = $this-> db -> query('select ip.printbatchid,ip.studid,ip.studentid,ip.studentname,ip.phone,ip.status,sp.profilepic from bscp_idcardprint as ip LEFT JOIN bscp_student as st on st.id=ip.studentid LEFT JOIN bscp_studentprofile as sp on sp.stuid=st.id where ip.printbatchid='.$this->db->escape($batchid)) ;
		
		if($query->num_rows()>0)
        {
            return $query->result();  
        }
        else
        {
            return 0;
        }
		
    }
	
	
	public function IDcardBatchPrinthtml($printbatchid,$sid)
    {
		
		$html = $pagebreak = "";
		
		$sidarr = array_filter(explode("|",$sid));
		
		for($i=0;$i<count($sidarr);$i++){
			
			$studentid = $sidarr[$i];
			
			$coursepay =  $this->GetFeePayments($studentid,'','');
			$stuprofile =  $this->GetStudentProfile($studentid);
			
			$coursename = $coursepay['coursename'][0];
			$coursetype = $coursepay['idcard_displayname'][0];
			$stuid = $stuprofile['studid'];
			$stuname = $stuprofile['stuname'];
			$dob = date("d M Y",strtotime($stuprofile['dob']));
			$mobile = $stuprofile['smobile'];
			$smcode = $stuprofile['smcode'];
			$email = $stuprofile['semail'];
			$profilepic = $stuprofile['profilepic'];

			$coursetype = substr($coursetype,0,20);
			$stuname = substr($stuname,0,20);

			$fulladdress = $addressline1 = $addressline2 = $addressline3 = "";
			$addressline1 .= $stuprofile['housenameno'].", ";
			$addressline1 .= $stuprofile['contactaddress'].", ";

			$addressline1 = strtolower(substr($addressline1,0,35));
			$addressline1 = ucwords($addressline1);

			if($stuprofile['contactaddress']!="" && $stuprofile['contactaddress']!="0") $fulladdress .= $stuprofile['landmark'].", ";

			$fulladdress .= $stuprofile['contactstate'].", ";
			$addressline2 .= $stuprofile['contactpost'].", ";
			//$fulladdress .= $stuprofile['contactcountry']." - ";

			$addressline2 = strtolower(substr($addressline2,0,35));
			$addressline2 = ucwords($addressline2);

			$addressline3 .= $stuprofile['contactdistrict'].", ";
			$addressline3 .= $stuprofile['contactpincode'].".";

			$addressline3 = strtolower(substr($addressline3,0,35));
			$addressline3 = ucwords($addressline3);

			$mobile = "Mob +".$smcode." ".$mobile;
			
			if($profilepic!="" && $profilepic!="0") $profilepic = base_url().'docs/profilepic/'.$studentid.'/'.$profilepic;
			else $profilepic = base_url().'img/myprofile.png';
			
			$this->generate_barcode($stuid,$studentid);
			
			if($i>0) $pagebreak = 'page-break-before: always;'; 
			
			$html .= '<div style="text-align: center;max-width: 100%;max-height: 100%;margin:-42px auto -46px;'.$pagebreak.'"> 
  
		<div style="position: relative;width: 325px;height: 508px;margin: 0 auto">
		
			<div style="position: absolute;top: 20.6%;left: 29.6%;"><img src="'.$profilepic.'" alt="" style="width: 133px;height: 145px;" /></div>
			
			<div style="position: absolute;width: 60%;top: 32%;left: -24%;transform: rotate(-90deg);line-height: 20px;"><span style="font-size: 13px;font-weight: bold;color: #222B39;text-transform: uppercase">'.$coursetype.'</span></div>
			
			<div style="position: absolute;top: 30%;right: -9%;transform: rotate(-90deg);"><img src="'.base_url().'docs/profilepic/'.$studentid.'/'.$stuid.'.png" alt="" style="width: 135px;height: 60px" /></div>
		
			<img src="'.base_url().'docs/idcard.jpg" alt="ID Card" style="width: 100%;height: auto;">
							
			<div style="position: absolute;width: 100%;top: 50%;left: 0;"><span style="font-size: 21px;font-weight: bold;color: #0332AA;word-break: break-word;">'.strtoupper($stuname).'</span></div>
			
			<div style="position: absolute;width: 100%;top: 55.5%;left: 0;"><span style="font-size: 21px;font-weight: bold;color: #0332AA">'.$stuid.'</span></div>
			
			<div style="position: absolute;width: 100%;top: 62%;left: 0;"><span style="font-size: 15px;font-weight: bold;color: #222B39">'.$mobile.'</span></div>
			
			<div style="position: absolute;width: 100%;bottom: 28%;left: 0;padding: 0 1rem;text-align: left;"><span style="font-size: 15px;font-weight: bold;color: #222B39">'.$addressline1.'</span></div>
			<div style="position: absolute;width: 100%;bottom: 24%;left: 0;padding: 0 1rem;text-align: left;"><span style="font-size: 15px;font-weight: bold;color: #222B39">'.$addressline2.'</span></div>
			<div style="position: absolute;width: 100%;bottom: 20%;left: 0;padding: 0 1rem;text-align: left;"><span style="font-size: 15px;font-weight: bold;color: #222B39">'.$addressline3.'</span></div>
						
		</div>
           
    	</div>';
			
	}
			
		return $html;
		
	}
	
	
	public function AddIDcardBatchPrint($batchname,$studentno,$printbid){
		
		$roleaccess = $this->config->item('roleaccess');
		
		$this->load->model('login_model','',TRUE);
		$user = $this->login_model->GetUserId();
				
		$arr = array();
		
		$arr['response'] = "";
		$arr['printbid'] = "";
				
		$studentdetials = $this->getStudentno($studentno);
		
		$studentid = $studentname = $studentmobile = "";
		if(!empty($studentdetials)){
			$studentid = $studentdetials['studid'];
			$studentname = $studentdetials['sname'];
			$studentmobile = $studentdetials['mobile'];
		}else{
			$arr['response'] = "nostudent";
			return $arr;
		}
		
		
		$query0 = $this-> db -> query('select ide,batchname,courseid from bscp_courserequest where studentid="'.$studentid.'" and batchname="'.$batchname.'"');
		$row0 = $query0->result_array();
					
		if ($query0->num_rows() === 0) {
			$arr['response'] = "nobatch";
			return $arr;
		}
			
				
		if($studentid!=""){
				
		$query = $this-> db -> query('select id from bscp_idcardprint where batchname="'.$batchname.'" and studentid="'.$studentid.'"');
		$row = $query->result_array();
					
		if ($query->num_rows() > 0) {
				
			$arr['response'] = "exists";			
			
		}else{
			
			$batchcolumn = "";
			
			if($printbid!=""){
				$batchcolumn = ' and printbatchid="'.$printbid.'"';
				$arr['printbid'] = $printbid;
			}
			
			$query1 = $this-> db -> query('select id,printbatchid,printbatchname from bscp_idcardprint where batchname="'.$batchname.'"'.$batchcolumn);
			$row1 = $query1->result_array();

			if ($query1->num_rows() > 0) {
			
				$printbatchid = $row1[0]['printbatchid'];
				$printbatchname = $row1[0]['printbatchname'];
				
			}else{
				$printbatchid = $this->GetPrintBatchID();
				$printbatchname = $printbatchid;
				$arr['printbid'] = $printbatchid;
			}
			
			//$checkbatchid = $this->CheckPrintBatchID($printbatchid);
			//$checkbatchname = $this->CheckPrintBatchName($printbatchname);
			$batchidcount = $this->GetPrintBatchIDCount($printbatchid);

			if ($batchidcount == 120) {

				$printbatchid = $this->GetPrintBatchID();
				$printbatchname = $printbatchid;
				
				$arr['printbid'] = $printbatchid;

			}
			
			   $ide = uniqid();

			   $qData = array(
					'id' => $ide,
					'printbatchid' => $printbatchid,
					'printbatchname' => $printbatchname,
					'studentid' => $studentid,
					'studid' => $studentno,
					'batchname' => $batchname,
					'studentname' => $studentname,
					'phone' => $studentmobile,
					'status' => "n",
					'created' => date('Y-m-d H:i:s')
				);

			   $ret = $this->CreatePrintBatch($qData);

			   $arr['response'] = "success";
			
		}
						
			
			
		}
		
		return $arr;
		
	}
	
	public function getStudentno($studentno){
		
		$arr = array();
				
		$query = $this-> db -> query('select id,sname,contact from bscp_student where studid="'.$studentno.'"');
		$row = $query->result_array();

		if ($query->num_rows() === 1) {
			$arr['studid'] = $row[0]["id"];
			$arr['sname'] = $row[0]["sname"];
			$arr['mobile'] = $row[0]["contact"];
		}
		
		return $arr;
		
	}
	
	
	public function generate_barcode($barcode,$studentid){
					
		// Load library
		$this->load->library('zend');
		// Load in folder Zend
		$this->zend->load('Zend/Barcode');

		$dirname = './docs/profilepic/'.$studentid.'/';

		if(!file_exists($dirname.$barcode.'.png')){
			
			// Generate barcode
			$imageResource = Zend_Barcode::factory('code128', 'image', array('text'=>"$barcode",'stretchText'=>true,'withBorder'=>false,'font'=>2,'fontSize'=>18,'barHeight'=>45,'barThickWidth'=>3,'barThinWidth'=>2,'withQuietZones'=>false,'drawText'=>true), array('imageType'=>'png'))->draw();

			imagepng($imageResource, $dirname.$barcode.'.png');
			
		}
								
	}
	
	public function PrintBatchAction($batchid,$ide,$action)
    {
		$this->load->model('notification_model','',TRUE);				
		$sidarr = array_filter(explode("|",$ide));
		
		for($i=0;$i<count($sidarr);$i++){
			
			$studentid = $sidarr[$i];
			
			if($action=="markprint"){
				
				$query = $this-> db -> query('update bscp_idcardprint set status="y" where printbatchid="'.$batchid.'" and studentid="'.$studentid.'"');
                                
				$this->notification_model->IDCardConfirmation($studentid);
				
			}else if($action=="marknotprint"){
				
				$query = $this-> db -> query('update bscp_idcardprint set status="n" where printbatchid="'.$batchid.'" and studentid="'.$studentid.'"');
				
			}else if($action=="removebatch"){
				
				$query = $this-> db -> query('delete from bscp_idcardprint where printbatchid="'.$batchid.'" and studentid="'.$studentid.'"');
				
			}
			
			
		}
		
		if($query){
			return "success";
		}
		return "fail";	
		
	}
	
	public function UpdatePrintBatchName($qData)
    {
		$this->db->update('bscp_idcardprint', $qData, array('printbatchid' => $qData['printbatchid']));
        
    }
	
function SendSMSConfiguration($substr,$mobile){
		
		$messTemplate = 'token=8ee49eb9f9e3477aa36d209657024cab&sender=BRLINT&number=NuMbER&route=2&type=1&sms='.$substr;
		
		$substr = $messTemplate;
		
		$searchFOr = 'NuMbER';
		$replacewith = $mobile;
		$substr = str_replace($searchFOr, $replacewith, $substr);
		
		$url = "http://textu.in/httpapi/httpapi?";

		$ch = curl_init($url);


		curl_setopt($ch, CURLOPT_POST, 1);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $substr);
		curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
		curl_setopt($ch, CURLOPT_HEADER, 0);  // DO NOT RETURN HTTP HEADERS 
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);  // RETURN THE CONTENTS OF THE CALL

		$return_val = curl_exec($ch);
		$err = curl_error($ch);

		curl_close($ch);

		if ($err) {
		   return "failed";
		} else {
			return "success";
		}
		
	}
	
function SendEmailConfiguration($email,$subject,$body,$attach){
            
		$config = $this->config->item('amazonses');

		$this->load->library('email', $config);
		$this->email->set_newline("\r\n");

		$this->email->from('admissions@brilliantpala.org', 'Admissions Brilliant');
		$this->email->to($email);	 
		$this->email->subject($subject);		
		$this->email->message($body);

		if($attach != "") {
			$this->email->attach($attach);
		}
		
		if($this->email->send())
		{
			echo '';
		}else{
			//echo $this->email->print_debugger();
		}
            
 }


}

?>
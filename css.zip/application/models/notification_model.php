<?php

class Notification_Model extends CI_Model {


    public function __construct() {

       $this->load->library('Datatables');

    }
	
	
	public function SignupOTPNotification($mcode,$mobile,$emailid,$verifycode){
		
			$body = "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.=w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\"><html><head><meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\"></head><body style=\"background:#fff; padding:20px;font-family: Segoe UI;\">
	
			<div style=\"background:#F6F7FA;width:600px;margin:auto;padding:1rem 0 3rem;\"> 
		
				<img src=\"https://admissions.brilliantpala.org/css/img/brilliantpala.png\" alt=\"Brilliant Study Centre\" style=\"margin:auto;padding:1rem 0 2rem;display:block;\" width=\"auto\">
		
				<table style=\"background:#fff;border:0px solid #E8E8E8; border-radius:0px; border-collapse:collapse; overflow:hidden;padding:10px;margin:0 auto; font-size: 15px; width:460px\"><tbody>
				
	  			<tr><td style=\"text-align:center; width:auto; color:#333; padding:20px;\"><img src=\"https://admissions.brilliantpala.org/img/email/welcome-email.jpg\" alt=\"Welcome Email\" width=\"auto\"></td></tr>
				
	  			<tr><td style=\"text-align:center; line-height:1.4em; padding:10px 20px;\">
				
				<p style=\"font-size: 24px;font-weight:bold; line-height:36px; margin:10px 0 25px;color: #181E29;\">Welcome to Brilliant Pala</p>
				
				<p style=\"font-size: 14px;line-height: 20px;margin:10px 0;color: #364159;\">OTP for your one time signup is <font color=\"#0332aa\"><strong>".$verifycode."</strong></font></p>
				
				</td></tr>
	  			
	  			<tr><td style=\"font-weight: normal;font-size: 14px;line-height: 20px;text-align:center; padding:10px 20px;color: #364159;\">Thanks,<br>Brilliant Study Centre Pala</td></tr>
				
				<tr><td style=\"text-align:center; padding:0px;color:#333;\">&nbsp;</td></tr>
								
	  			</tbody></table>
				
				<div style=\"font-size: 12px;line-height: 18px;color: #889DC6;text-align:center;padding:2em 0;\">
				
					<a href=\"#\" title=\"Contact Us\" style=\"color: #889DC6;vertical-align: middle;padding-right:8px\">Contact Us</a> <font size=\"5\">&#46;</font>
					<a href=\"#\" title=\"Terms and Conditions\" style=\"color: #889DC6;vertical-align: middle;padding:0 8px\">Terms and Conditions</a> <font size=\"5\">&#46;</font>
					<a href=\"#\" title=\"Privacy Policy\" style=\"color: #889DC6;vertical-align: middle;padding:0 8px\">Privacy Policy </a> <font size=\"5\">&#46;</font>
					<a href=\"#\" title=\"Help\" style=\"color: #889DC6;vertical-align: middle;padding-left:8px\">Help</a> 
				
				</div>
				
				<div style=\"text-align:center;padding:0em 0;\">
				
					<a href=\"https://www.facebook.com/BrilliantStudyCentrePala/\" title=\"Facebook\" style=\"vertical-align: middle;padding-right:8px\"><img src=\"https://admissions.brilliantpala.org/img/email/facebook.png\" alt=\"Facebook\" width=\"auto\"></a>
					<a href=\"https://twitter.com/BrilliantPala\" title=\"Twitter\" style=\"vertical-align: middle;padding:0 8px\"><img src=\"https://admissions.brilliantpala.org/img/email/twitter.png\" alt=\"Twitter\" width=\"auto\"></a>
					<a href=\"https://www.youtube.com/BrilliantOnline/\" title=\"Youtube\" style=\"vertical-align: middle;padding:0 8px\"><img src=\"https://admissions.brilliantpala.org/img/email/youtube.png\" alt=\"Youtube\" width=\"auto\"></a>
					<a href=\"https://www.instagram.com/brilliantpala/\" title=\"Instagram\" style=\"vertical-align: middle;padding:0 8px\"><img src=\"https://admissions.brilliantpala.org/img/email/instagram.png\" alt=\"Instagram\" width=\"auto\"></a>
					<a href=\"https://in.pinterest.com/brilliantstudycentrepala/\" title=\"Pinterest\" style=\"vertical-align: middle;padding-left:8px\"><img src=\"https://admissions.brilliantpala.org/img/email/pinterest.png\" alt=\"Pinterest\" width=\"auto\"></a>				 
				</div>
				
				</div>
				
				</body></html>";
				
				$subject = "Welcome to Brilliant Pala";
				
                 $this->SendEmailConfiguration($emailid,$subject,$body,"");
			
		if($mcode=="91"){
			
			$messTemplate = 'Welcome%20to%20Brilliant%20Pala,%0A%0AOTP%20for%20your%20one%20time%20signup%20is%20[VcOdE]%0A%0AThanks,%0A%0ABrilliant%20Study%20Centre%20Pala.';

			$substr = $messTemplate;

			$searchFOr = '[VcOdE]';
			$replacewith = $verifycode;
			$substr = str_replace($searchFOr, $replacewith, $substr);

			$response = $this->SendSMSConfiguration($substr,$mobile,'1707161555273880116');
		
			return $response;
		}else{
			return "success";
		}
	
}
	
	public function SignupNotification($studentid,$studentname,$mobile,$emailid,$stupassword){
		
		$subject = "Thank You for Signing Up!";
			
			$body = "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.=w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\"><html><head><meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\"></head><body style=\"background:#fff; padding:20px;font-family: Segoe UI;\">
	
			<div style=\"background:#F6F7FA;width:600px;margin:auto;padding:1rem 0 3rem;\"> 
		
				<img src=\"https://admissions.brilliantpala.org/css/img/brilliantpala.png\" alt=\"Brilliant Study Centre\" style=\"padding:1rem 0 2rem;display:block;margin:auto\" width=\"auto\">
		
				<table style=\"background:#fff;border:0px solid #E8E8E8; border-radius:0px; border-collapse:collapse; overflow:hidden;padding:20px;margin:0 auto; font-size: 15px; width:460px\"><tbody>
				
	  			<tr><td style=\"text-align:center; width:auto; color:#333; padding:20px;\"><img src=\"https://admissions.brilliantpala.org/img/email/signup.jpg\" alt=\"Welcome Email\" width=\"auto\"></td></tr>
				
	  			<tr><td style=\"text-align:center; line-height:1.4em; padding:10px 20px;\">
				
				<p style=\"font-size: 24px;font-weight:bold; line-height:36px; margin:10px 0;color: #181E29;\">Thank You for Signing Up!</p>
								
				</td></tr>
				
				<tr><td style=\"font-size: 14px;line-height: 20px;text-align:left;padding:10px 25px;color: #364159;\">
				
				<p style=\"margin:10px 0;\">Dear ".$studentname.",</p>
				
				<p style=\"margin:10px 0;\">Welcome to Brilliant Study Centre Pala, Please note your Student ID and Password,</p>
								
				<p style=\"font-size: 14px;line-height: 20px;margin:10px 0;color: #364159;\">Student id: <font color=\"#0332aa\"><strong>".$studentid."</strong></font></p>
								
				<p style=\"font-size: 14px;line-height: 20px;margin:10px 0;color: #364159;\">Password: <font color=\"#0332aa\"><strong>".$stupassword."</strong></font></p>
				
				<p style=\"margin:10px 0;\">You can use your Student ID, Registered Email and Registered Mobile Number as user name for login.Please use the same login id for applying to any courses.</p>
				
				<p style=\"margin:10px 0;\">Click here <a href=\"https://admissions.brilliantpala.org/\" title=\"Login\">https://admissions.brilliantpala.org/</a> to Login, Update your profile and Register for available courses based on your Qualification/Class studying.</p>
				
				<p style=\"margin:10px 0;\">Duplicate registrations will disqualify you from all your previous scholarships.</p>
				
				</td></tr>
				
				<tr><td style=\"text-align:center; padding:0px;color:#333;\">&nbsp;</td></tr>
	  			
	  			<tr><td style=\"font-weight: normal;font-size: 14px;line-height: 20px;text-align:left; padding:10px 20px;color: #364159;\">Thanks,<br>Brilliant Study Centre Pala</td></tr>
				
				<tr><td style=\"text-align:center; padding:0px;color:#333;\">&nbsp;</td></tr>
								
	  			</tbody></table>
				
				<div style=\"font-size: 12px;line-height: 18px;color: #889DC6;text-align:center;padding:2em 0;\">
				
					<a href=\"#\" title=\"Contact Us\" style=\"color: #889DC6;vertical-align: middle;padding-right:8px\">Contact Us</a> <font size=\"5\">&#46;</font>
					<a href=\"#\" title=\"Terms and Conditions\" style=\"color: #889DC6;vertical-align: middle;padding:0 8px\">Terms and Conditions</a> <font size=\"5\">&#46;</font>
					<a href=\"#\" title=\"Privacy Policy\" style=\"color: #889DC6;vertical-align: middle;padding:0 8px\">Privacy Policy </a> <font size=\"5\">&#46;</font>
					<a href=\"#\" title=\"Help\" style=\"color: #889DC6;vertical-align: middle;padding-left:8px\">Help</a> 
				
				</div>
				
				<div style=\"text-align:center;padding:0em 0;\">
				
					<a href=\"https://www.facebook.com/BrilliantStudyCentrePala/\" title=\"Facebook\" style=\"vertical-align: middle;padding-right:8px\"><img src=\"https://admissions.brilliantpala.org/img/email/facebook.png\" alt=\"Facebook\" width=\"auto\"></a>
					<a href=\"https://twitter.com/BrilliantPala\" title=\"Twitter\" style=\"vertical-align: middle;padding:0 8px\"><img src=\"https://admissions.brilliantpala.org/img/email/twitter.png\" alt=\"Twitter\" width=\"auto\"></a>
					<a href=\"https://www.youtube.com/BrilliantOnline/\" title=\"Youtube\" style=\"vertical-align: middle;padding:0 8px\"><img src=\"https://admissions.brilliantpala.org/img/email/youtube.png\" alt=\"Youtube\" width=\"auto\"></a>
					<a href=\"#\" title=\"Instagram\" style=\"vertical-align: middle;padding:0 8px\"><img src=\"https://admissions.brilliantpala.org/img/email/instagram.png\" alt=\"Instagram\" width=\"auto\"></a>
					<a href=\"#\" title=\"Pinterest\" style=\"vertical-align: middle;padding-left:8px\"><img src=\"https://admissions.brilliantpala.org/img/email/pinterest.png\" alt=\"Pinterest\" width=\"auto\"></a>				 
				</div>
				
				</div>
				
				</body></html>";
				
				
                 $this->SendEmailConfiguration($emailid,$subject,$body,"");
						
			
			$messTemplate = 'Dear%20[StUdEnTnAmE],%0A%0AWelcome%20to%20Brilliant%20Study%20Centre%20Pala.%0A%0AYour%20Student%20ID%20[StUdEnTiD]%20and%20Password%20is%20[PaSsWoRd]%0A%0AClick%20[LoGiNlInK]%20and%20update%20your%20details.%0A%0A%0AThanks.';

			$substr = $messTemplate;
		
			$searchFOr = '[StUdEnTnAmE]';
			$replacewith = $studentname;
			$substr = str_replace($searchFOr, $replacewith, $substr);

			$searchFOr = '[StUdEnTiD]';
			$replacewith = $studentid;
			$substr = str_replace($searchFOr, $replacewith, $substr);

			$searchFOr = '[PaSsWoRd]';
			$replacewith = $stupassword;
			$substr = str_replace($searchFOr, $replacewith, $substr);

			$searchFOr = '[LoGiNlInK]';
			$replacewith = "https://admissions.brilliantpala.org/";
			$substr = str_replace($searchFOr, $replacewith, $substr);

			$response = $this->SendSMSConfiguration($substr,$mobile,'1707161931851602949');
		
		return $response;
		
	}
	
	public function CourseRegisterNotification($userid,$courseid){
		
			$this->load->model('login_model','',TRUE);
			$userdetails = $this->login_model->GetUserDetails($userid);
		
			if($userdetails['name']!=""){
				
				$studentname = $userdetails['pname'];
				$emailid = $userdetails['emailid'];
				$mobile = $userdetails['mobile'];
				
				$query2 = $this-> db -> query('select coursename from admin_course where ide="'.$courseid.'"');
				$row2 = $query2->result_array();
				if($query2->num_rows()>0){
					
					$coursename = $row2[0]['coursename'];
									
		
			$subject = "Course Registered Successfully!";
			
			$body = "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.=w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\"><html><head><meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\"></head><body style=\"background:#fff; padding:20px;font-family: Segoe UI;\">
	
		<div style=\"background:#F6F7FA;width:600px;margin:auto;padding:1rem 0 3rem;\"> 
		
				<img src=\"https://admissions.brilliantpala.org/css/img/brilliantpala.png\" alt=\"Brilliant Study Centre\" style=\"padding:1rem 0 2rem;display:block;margin:auto\" width=\"auto\">
		
				<table style=\"background:#fff;border:0px solid #E8E8E8; border-radius:0px; border-collapse:collapse; overflow:hidden;padding:20px;margin:0 auto; font-size: 15px; width:460px\"><tbody>
				
	  			<tr><td style=\"text-align:center; width:auto; color:#333; padding:20px;\"><img src=\"https://admissions.brilliantpala.org/img/email/courseregister.jpg\" alt=\"Course Register\" width=\"auto\"></td></tr>
				
	  			<tr><td style=\"text-align:center; line-height:1.4em; padding:10px 20px;\">
				
				<p style=\"font-size: 24px;font-weight:bold; line-height:36px; margin:10px 0;color: #181E29;\">Course Registered Successfully!</p>
								
				</td></tr>
				
				<tr><td style=\"font-size: 14px;line-height: 20px;text-align:left;padding:10px 25px;color: #364159;\">
				
				<p style=\"margin:10px 0;\">Dear ".$studentname.",</p>
				
				<p style=\"margin:10px 0;\">You have successfully registered for <font color=\"#0332aa\"><strong>".$coursename."</strong></font></p>
																				
				<p style=\"margin:10px 0;\">We will let you know the confirmation of your admission at the earliest. Once confirmed please login to your account and Update you profile and Remit the Course Fee.</p>
								
				<p style=\"margin:10px 0;\">Duplicate registrations will disqualify you from all your previous scholarships.</p>
				
				</td></tr>
				
				<tr><td style=\"text-align:center; padding:0px;color:#333;\">&nbsp;</td></tr>
	  			
	  			<tr><td style=\"font-weight: normal;font-size: 14px;line-height: 20px;text-align:left; padding:10px 20px;color: #364159;\">Thanks,<br>Brilliant Study Centre Pala</td></tr>
				
				<tr><td style=\"text-align:center; padding:0px;color:#333;\">&nbsp;</td></tr>
								
	  			</tbody></table>
				
				<div style=\"font-size: 12px;line-height: 18px;color: #889DC6;text-align:center;padding:2em 0;\">
				
					<a href=\"#\" title=\"Contact Us\" style=\"color: #889DC6;vertical-align: middle;padding-right:8px\">Contact Us</a> <font size=\"5\">&#46;</font>
					<a href=\"#\" title=\"Terms and Conditions\" style=\"color: #889DC6;vertical-align: middle;padding:0 8px\">Terms and Conditions</a> <font size=\"5\">&#46;</font>
					<a href=\"#\" title=\"Privacy Policy\" style=\"color: #889DC6;vertical-align: middle;padding:0 8px\">Privacy Policy </a> <font size=\"5\">&#46;</font>
					<a href=\"#\" title=\"Help\" style=\"color: #889DC6;vertical-align: middle;padding-left:8px\">Help</a> 
				
				</div>
				
				<div style=\"text-align:center;padding:0em 0;\">
				
					<a href=\"https://www.facebook.com/BrilliantStudyCentrePala/\" title=\"Facebook\" style=\"vertical-align: middle;padding-right:8px\"><img src=\"https://admissions.brilliantpala.org/img/email/facebook.png\" alt=\"Facebook\" width=\"auto\"></a>
					<a href=\"https://twitter.com/BrilliantPala\" title=\"Twitter\" style=\"vertical-align: middle;padding:0 8px\"><img src=\"https://admissions.brilliantpala.org/img/email/twitter.png\" alt=\"Twitter\" width=\"auto\"></a>
					<a href=\"https://www.youtube.com/BrilliantOnline/\" title=\"Youtube\" style=\"vertical-align: middle;padding:0 8px\"><img src=\"https://admissions.brilliantpala.org/img/email/youtube.png\" alt=\"Youtube\" width=\"auto\"></a>
					<a href=\"#\" title=\"Instagram\" style=\"vertical-align: middle;padding:0 8px\"><img src=\"https://admissions.brilliantpala.org/img/email/instagram.png\" alt=\"Instagram\" width=\"auto\"></a>
					<a href=\"#\" title=\"Pinterest\" style=\"vertical-align: middle;padding-left:8px\"><img src=\"https://admissions.brilliantpala.org/img/email/pinterest.png\" alt=\"Pinterest\" width=\"auto\"></a>				 
				</div>
				
				</div>
				
				</body></html>";
				
				
                 $this->SendEmailConfiguration($emailid,$subject,$body,"");
						
			
			$messTemplate = 'Dear%20[StUdEnTnAmE],%0A%0AYou%20have%20successfully%20registered%20for%20[CoUrSeNaMe]%0A%0AWe%20will%20let%20you%20know%20once%20the%20admission%20is%20confirmed.%0A%0A%0AThanks,%0ABrilliant%20Pala';

			$substr = $messTemplate;

			$searchFOr = '[StUdEnTnAmE]';
			$replacewith = $studentname;
			$substr = str_replace($searchFOr, $replacewith, $substr);

			$searchFOr = '[CoUrSeNaMe]';
			$replacewith = $coursename;
			$substr = str_replace($searchFOr, $replacewith, $substr);

			$response = $this->SendSMSConfiguration($substr,$mobile,'1707161931867340913');
		
			return $response;
					
				}

		}

		return 'failed';
		
	}
	
	public function AdmissionNotification($userid,$courseid){
		
		
			$this->load->model('login_model','',TRUE);
			$userdetails = $this->login_model->GetUserDetails($userid);
		
			if($userdetails['name']!=""){
				
				$studentname = $userdetails['pname'];
				$emailid = $userdetails['emailid'];
				$mobile = $userdetails['mobile'];
				
				$query2 = $this-> db -> query('select coursename from admin_course where ide="'.$courseid.'"');
				$row2 = $query2->result_array();
				if($query2->num_rows()>0){
					
					$coursename = $row2[0]['coursename'];
					
			$subject = "Congrats! You've Got Admission";
			
			$body = "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.=w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\"><html><head><meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\"></head><body style=\"background:#fff; padding:20px;font-family: Segoe UI;\">
	
		<div style=\"background:#F6F7FA;width:600px;margin:auto;padding:1rem 0 3rem;\"> 
		
				<img src=\"https://admissions.brilliantpala.org/css/img/brilliantpala.png\" alt=\"Brilliant Study Centre\" style=\"padding:1rem 0 2rem;display:block;margin:auto\" width=\"auto\">
		
				<table style=\"background:#fff;border:0px solid #E8E8E8; border-radius:0px; border-collapse:collapse; overflow:hidden;padding:20px;margin:0 auto; font-size: 15px; width:460px\"><tbody>
				
	  			<tr><td style=\"text-align:center; width:auto; color:#333; padding:20px;\"><img src=\"https://admissions.brilliantpala.org/img/email/admission.jpg\" alt=\"Course Register\" width=\"auto\"></td></tr>
				
	  			<tr><td style=\"text-align:center; line-height:1.4em; padding:10px 20px;\">
				
				<p style=\"font-size: 24px;font-weight:bold; line-height:36px; margin:10px 0;color: #181E29;\">Congrats! You've Got Admission</p>
								
				</td></tr>
				
				<tr><td style=\"font-size: 14px;line-height: 20px;text-align:left;padding:10px 25px;color: #364159;\">
				
				<p style=\"margin:10px 0;\">Dear ".$studentname.",</p>
				
				<p style=\"margin:10px 0;\">You have successfully admitted for <font color=\"#0332aa\"><strong>".$coursename."</strong></font></p>
																				
				<p style=\"margin:10px 0;\">Please login to your account <a href=\"https://admissions.brilliantpala.org/\" title=\"Login\">https://admissions.brilliantpala.org/</a> update your profile and remit the course fee within <strong>7 days</strong>, to secure your seat for the applied course.</p>
				
				<p style=\"margin:10px 0;\">You can pay online using Credit/Debit card and Net banking by login into your student profile.</p>
				
				<p style=\"margin:10px 0;\">If you are using a debit card please check your daily transaction limit with your bank, before making the online payments.</p>
				
				<p style=\"margin:10px 0;\">Do contact us for all your admission related queries directly at admissions@brilliantpala.org | <a href=\"tel:04822 206100\">04822 206100</a> | <a href=\"tel:04822 206800\">04822 206800</a>.</p>
				
				</td></tr>
				
				<tr><td style=\"text-align:center; padding:0px;color:#333;\">&nbsp;</td></tr>
	  			
	  			<tr><td style=\"font-weight: normal;font-size: 14px;line-height: 20px;text-align:left; padding:10px 20px;color: #364159;\">Thanks,<br>Brilliant Study Centre Pala</td></tr>
				
				<tr><td style=\"text-align:center; padding:0px;color:#333;\">&nbsp;</td></tr>
								
	  			</tbody></table>
				
				<div style=\"font-size: 12px;line-height: 18px;color: #889DC6;text-align:center;padding:2em 0;\">
				
					<a href=\"#\" title=\"Contact Us\" style=\"color: #889DC6;vertical-align: middle;padding-right:8px\">Contact Us</a> <font size=\"5\">&#46;</font>
					<a href=\"#\" title=\"Terms and Conditions\" style=\"color: #889DC6;vertical-align: middle;padding:0 8px\">Terms and Conditions</a> <font size=\"5\">&#46;</font>
					<a href=\"#\" title=\"Privacy Policy\" style=\"color: #889DC6;vertical-align: middle;padding:0 8px\">Privacy Policy </a> <font size=\"5\">&#46;</font>
					<a href=\"#\" title=\"Help\" style=\"color: #889DC6;vertical-align: middle;padding-left:8px\">Help</a> 
				
				</div>
				
				<div style=\"text-align:center;padding:0em 0;\">
				
					<a href=\"https://www.facebook.com/BrilliantStudyCentrePala/\" title=\"Facebook\" style=\"vertical-align: middle;padding-right:8px\"><img src=\"https://admissions.brilliantpala.org/img/email/facebook.png\" alt=\"Facebook\" width=\"auto\"></a>
					<a href=\"https://twitter.com/BrilliantPala\" title=\"Twitter\" style=\"vertical-align: middle;padding:0 8px\"><img src=\"https://admissions.brilliantpala.org/img/email/twitter.png\" alt=\"Twitter\" width=\"auto\"></a>
					<a href=\"https://www.youtube.com/BrilliantOnline/\" title=\"Youtube\" style=\"vertical-align: middle;padding:0 8px\"><img src=\"https://admissions.brilliantpala.org/img/email/youtube.png\" alt=\"Youtube\" width=\"auto\"></a>
					<a href=\"#\" title=\"Instagram\" style=\"vertical-align: middle;padding:0 8px\"><img src=\"https://admissions.brilliantpala.org/img/email/instagram.png\" alt=\"Instagram\" width=\"auto\"></a>
					<a href=\"#\" title=\"Pinterest\" style=\"vertical-align: middle;padding-left:8px\"><img src=\"https://admissions.brilliantpala.org/img/email/pinterest.png\" alt=\"Pinterest\" width=\"auto\"></a>				 
				</div>
				
				</div>
				
				</body></html>";
				
				
                 $this->SendEmailConfiguration($emailid,$subject,$body,"");
						
			
			$messTemplate = 'Dear%20[StUdEnTnAmE],%0A%0ACongratulations,%0A%0AYou%20have%20successfully%20admitted%20for%20[CoUrSeNaMe]%0A%0ALogin%20to%20your%20account%20[LoGiNlInK],%20update%20profile%20and%20remit%20the%20Course%20Fee%20within%207%20days%0A%0A%0AThanks,%0ABrilliant%20Pala';

			$substr = $messTemplate;

			$searchFOr = '[StUdEnTnAmE]';
			$replacewith = $studentname;
			$substr = str_replace($searchFOr, $replacewith, $substr);

			$searchFOr = '[CoUrSeNaMe]';
			$replacewith = $coursename;
			$substr = str_replace($searchFOr, $replacewith, $substr);

			$searchFOr = '[LoGiNlInK]';
			$replacewith = "https://admissions.brilliantpala.org/";
			$substr = str_replace($searchFOr, $replacewith, $substr);

			$response = $this->SendSMSConfiguration($substr,$mobile,'1707162515376318881');
		
			return $response;
					
			}

		}

		return 'failed';
					
		
	}
	
	public function PaymentSucessNotification($userid,$OrderId,$paidamt){
		
		
			$this->load->model('login_model','',TRUE);
			$userdetails = $this->login_model->GetUserDetails($userid);
		
			if($userdetails['name']!=""){
				
				$studentname = $userdetails['pname'];
				$emailid = $userdetails['emailid'];
				$mobile = $userdetails['mobile'];
				
				$query2 = $this-> db -> query('select c.coursename from bscp_feepayments as fp,admin_course as c where fp.courseid = c.ide and fp.referenceid="'.$OrderId.'"');
				$row2 = $query2->result_array();
				if($query2->num_rows()>0){
					
					$coursename = $row2[0]['coursename'];
					
			$subject = "Payment Successful!";
			
			$body = "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.=w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\"><html><head><meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\"></head><body style=\"background:#fff; padding:20px;font-family: Segoe UI;\">
	
		<div style=\"background:#F6F7FA;width:600px;margin:auto;padding:1rem 0 3rem;\"> 
		
				<img src=\"https://admissions.brilliantpala.org/css/img/brilliantpala.png\" alt=\"Brilliant Study Centre\" style=\"padding:1rem 0 2rem;display:block;margin:auto\" width=\"auto\">
		
				<table style=\"background:#fff;border:0px solid #E8E8E8; border-radius:0px; border-collapse:collapse; overflow:hidden;padding:20px;margin:0 auto; font-size: 15px; width:460px\"><tbody>
				
	  			<tr><td style=\"text-align:center; width:auto; color:#333; padding:20px;\"><img src=\"https://admissions.brilliantpala.org/img/email/paymentsuccess.jpg\" alt=\"Payment Success\" width=\"auto\"></td></tr>
				
	  			<tr><td style=\"text-align:center; line-height:1.4em; padding:10px 20px;\">
				
				<p style=\"font-size: 24px;font-weight:bold; line-height:36px; margin:10px 0;color: #181E29;\">Payment Successful!</p>
								
				</td></tr>
				
				<tr><td style=\"font-size: 14px;line-height: 20px;text-align:left;padding:10px 25px;color: #364159;\">
				
				<p style=\"margin:10px 0;\">Dear ".$studentname.",</p>
				
				<p style=\"margin:10px 0;\">Your Fee remittance Rs. <font color=\"#0332aa\"><strong>".number_format($paidamt,2)."</strong></font>/- with Brilliant Study Centre Pala is successful.</p>
				
				<p style=\"margin:10px 0;\">You are admitted to <font color=\"#0332aa\"><strong>".$coursename."</strong></font></p>
								
				<p style=\"margin:10px 0;\">We will update you with more details shortly.</p>
				
				</td></tr>
				
				<tr><td style=\"text-align:center; padding:0px;color:#333;\">&nbsp;</td></tr>
	  			
	  			<tr><td style=\"font-weight: normal;font-size: 14px;line-height: 20px;text-align:left; padding:10px 20px;color: #364159;\">Thanks,<br>Brilliant Study Centre Pala</td></tr>
				
				<tr><td style=\"text-align:center; padding:0px;color:#333;\">&nbsp;</td></tr>
								
	  			</tbody></table>
				
				<div style=\"font-size: 12px;line-height: 18px;color: #889DC6;text-align:center;padding:2em 0;\">
				
					<a href=\"#\" title=\"Contact Us\" style=\"color: #889DC6;vertical-align: middle;padding-right:8px\">Contact Us</a> <font size=\"5\">&#46;</font>
					<a href=\"#\" title=\"Terms and Conditions\" style=\"color: #889DC6;vertical-align: middle;padding:0 8px\">Terms and Conditions</a> <font size=\"5\">&#46;</font>
					<a href=\"#\" title=\"Privacy Policy\" style=\"color: #889DC6;vertical-align: middle;padding:0 8px\">Privacy Policy </a> <font size=\"5\">&#46;</font>
					<a href=\"#\" title=\"Help\" style=\"color: #889DC6;vertical-align: middle;padding-left:8px\">Help</a> 
				
				</div>
				
				<div style=\"text-align:center;padding:0em 0;\">
				
					<a href=\"https://www.facebook.com/BrilliantStudyCentrePala/\" title=\"Facebook\" style=\"vertical-align: middle;padding-right:8px\"><img src=\"https://admissions.brilliantpala.org/img/email/facebook.png\" alt=\"Facebook\" width=\"auto\"></a>
					<a href=\"https://twitter.com/BrilliantPala\" title=\"Twitter\" style=\"vertical-align: middle;padding:0 8px\"><img src=\"https://admissions.brilliantpala.org/img/email/twitter.png\" alt=\"Twitter\" width=\"auto\"></a>
					<a href=\"https://www.youtube.com/BrilliantOnline/\" title=\"Youtube\" style=\"vertical-align: middle;padding:0 8px\"><img src=\"https://admissions.brilliantpala.org/img/email/youtube.png\" alt=\"Youtube\" width=\"auto\"></a>
					<a href=\"#\" title=\"Instagram\" style=\"vertical-align: middle;padding:0 8px\"><img src=\"https://admissions.brilliantpala.org/img/email/instagram.png\" alt=\"Instagram\" width=\"auto\"></a>
					<a href=\"#\" title=\"Pinterest\" style=\"vertical-align: middle;padding-left:8px\"><img src=\"https://admissions.brilliantpala.org/img/email/pinterest.png\" alt=\"Pinterest\" width=\"auto\"></a>				 
				</div>
				
				</div>
				
				</body></html>";
				
				
                 $this->SendEmailConfiguration($emailid,$subject,$body,"");
						
			
			$messTemplate = 'Dear%20[StUdEnTnAmE],%0A%0AYour%20Fee%20remittance%20Rs%20[PaIdAmOuNt]%20with%20Brilliant%20Study%20Centre%20Pala%20is%20successful.%0A%0AWill%20update%20you%20with%20more%20details%20shortly.%0A%0A%0AThanks,%0ABrilliant%20Pala';

			$substr = $messTemplate;

			$searchFOr = '[StUdEnTnAmE]';
			$replacewith = $studentname;
			$substr = str_replace($searchFOr, $replacewith, $substr);

			$searchFOr = '[CoUrSeNaMe]';
			$replacewith = $coursename;
			$substr = str_replace($searchFOr, $replacewith, $substr);

			$searchFOr = '[PaIdAmOuNt]';
			$replacewith = $paidamt;
			$substr = str_replace($searchFOr, $replacewith, $substr);

			$response = $this->SendSMSConfiguration($substr,$mobile,'1707161578673263765');
		
			return $response;
					
			}

		}

		return 'failed';
					
		
	}
	
	public function PaymentFailNotification($userid,$OrderId,$paidamt){
		
		
			$this->load->model('login_model','',TRUE);
			$userdetails = $this->login_model->GetUserDetails($userid);
		
			if($userdetails['name']!=""){
				
				$studentname = $userdetails['pname'];
				$emailid = $userdetails['emailid'];
				$mobile = $userdetails['mobile'];
				
					
			$subject = "Oops! Payment Failed";
			
			$body = "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.=w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\"><html><head><meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\"></head><body style=\"background:#fff; padding:20px;font-family: Segoe UI;\">
	
			<div style=\"background:#F6F7FA;width:600px;margin:auto;padding:1rem 0 3rem;\"> 
		
				<img src=\"https://admissions.brilliantpala.org/css/img/brilliantpala.png\" alt=\"Brilliant Study Centre\" style=\"padding:1rem 0 2rem;display:block;margin:auto\" width=\"auto\">
		
				<table style=\"background:#fff;border:0px solid #E8E8E8; border-radius:0px; border-collapse:collapse; overflow:hidden;padding:20px;margin:0 auto; font-size: 15px; width:460px\"><tbody>
				
	  			<tr><td style=\"text-align:center; width:auto; color:#333; padding:20px;\"><img src=\"https://admissions.brilliantpala.org/img/email/paymentfail.jpg\" alt=\"Payment Fail\" width=\"auto\"></td></tr>
				
	  			<tr><td style=\"text-align:center; line-height:1.4em; padding:10px 20px;\">
				
				<p style=\"font-size: 24px;font-weight:bold; line-height:36px; margin:10px 0;color: #181E29;\">Oops! Payment Failed</p>
								
				</td></tr>
				
				<tr><td style=\"font-size: 14px;line-height: 20px;text-align:left;padding:10px 25px;color: #364159;\">
				
				<p style=\"margin:10px 0;\">Dear ".$studentname.",</p>
				
				<p style=\"margin:10px 0;\">Unfortunately, your payment with Brilliant Study Centre Pala is failed.</p>
				
				<p style=\"margin:10px 0;\">You may check with your bank for card transaction limit, if using Debit/Credit card.</p>
								
				<p style=\"margin:10px 0;\">You can pay directly at any of our Study Centres or Download challan from your student panel and pay at any bank.</p>
								
				<p style=\"margin:10px 0;\">For more details do contact us for all your admission related queries directly at admissions@brilliantpala.org | <a href=\"tel:04822 206100\">04822 206100</a> | <a href=\"tel:04822 206800\">04822 206800</a>.</p>
				
				</td></tr>
				
				<tr><td style=\"text-align:center; padding:0px;color:#333;\">&nbsp;</td></tr>
	  			
	  			<tr><td style=\"font-weight: normal;font-size: 14px;line-height: 20px;text-align:left; padding:10px 20px;color: #364159;\">Thanks,<br>Brilliant Study Centre Pala</td></tr>
				
				<tr><td style=\"text-align:center; padding:0px;color:#333;\">&nbsp;</td></tr>
								
	  			</tbody></table>
				
				<div style=\"font-size: 12px;line-height: 18px;color: #889DC6;text-align:center;padding:2em 0;\">
				
					<a href=\"#\" title=\"Contact Us\" style=\"color: #889DC6;vertical-align: middle;padding-right:8px\">Contact Us</a> <font size=\"5\">&#46;</font>
					<a href=\"#\" title=\"Terms and Conditions\" style=\"color: #889DC6;vertical-align: middle;padding:0 8px\">Terms and Conditions</a> <font size=\"5\">&#46;</font>
					<a href=\"#\" title=\"Privacy Policy\" style=\"color: #889DC6;vertical-align: middle;padding:0 8px\">Privacy Policy </a> <font size=\"5\">&#46;</font>
					<a href=\"#\" title=\"Help\" style=\"color: #889DC6;vertical-align: middle;padding-left:8px\">Help</a> 
				
				</div>
				
				<div style=\"text-align:center;padding:0em 0;\">
				
					<a href=\"https://www.facebook.com/BrilliantStudyCentrePala/\" title=\"Facebook\" style=\"vertical-align: middle;padding-right:8px\"><img src=\"https://admissions.brilliantpala.org/img/email/facebook.png\" alt=\"Facebook\" width=\"auto\"></a>
					<a href=\"https://twitter.com/BrilliantPala\" title=\"Twitter\" style=\"vertical-align: middle;padding:0 8px\"><img src=\"https://admissions.brilliantpala.org/img/email/twitter.png\" alt=\"Twitter\" width=\"auto\"></a>
					<a href=\"https://www.youtube.com/BrilliantOnline/\" title=\"Youtube\" style=\"vertical-align: middle;padding:0 8px\"><img src=\"https://admissions.brilliantpala.org/img/email/youtube.png\" alt=\"Youtube\" width=\"auto\"></a>
					<a href=\"#\" title=\"Instagram\" style=\"vertical-align: middle;padding:0 8px\"><img src=\"https://admissions.brilliantpala.org/img/email/instagram.png\" alt=\"Instagram\" width=\"auto\"></a>
					<a href=\"#\" title=\"Pinterest\" style=\"vertical-align: middle;padding-left:8px\"><img src=\"https://admissions.brilliantpala.org/img/email/pinterest.png\" alt=\"Pinterest\" width=\"auto\"></a>				 
				</div>
				
				</div>
				
				</body></html>";
				
				
                 $this->SendEmailConfiguration($emailid,$subject,$body,"");
						
			
			$messTemplate = 'Dear%20[StUdEnTnAmE],%20Unfortunately,%20your%20payment%20with%20Brilliant%20Study%20Centre%20Pala%20is%20failed.%0A%0A%0AThanks,%0ABrilliant%20Pala';

			$substr = $messTemplate;

			$searchFOr = '[StUdEnTnAmE]';
			$replacewith = $studentname;
			$substr = str_replace($searchFOr, $replacewith, $substr);

			$response = $this->SendSMSConfiguration($substr,$mobile,'1707161578692752581');
		
			return $response;
					

		}

		return 'failed';
					
		
	}
	
	public function SubsequentPaymentNotification($userid,$paidamt){
		
		
			$this->load->model('login_model','',TRUE);
			$userdetails = $this->login_model->GetUserDetails($userid);
		
			if($userdetails['name']!=""){
				
				$studentname = $userdetails['pname'];
				$emailid = $userdetails['emailid'];
				$mobile = $userdetails['mobile'];
				
			
			$subject = "Payment Successful!";
			
			$body = "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.=w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\"><html><head><meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\"></head><body style=\"background:#fff; padding:20px;font-family: Segoe UI;\">
	
		<div style=\"background:#F6F7FA;width:600px;margin:auto;padding:1rem 0 3rem;\"> 
		
				<img src=\"https://admissions.brilliantpala.org/css/img/brilliantpala.png\" alt=\"Brilliant Study Centre\" style=\"padding:1rem 0 2rem;display:block;margin:auto\" width=\"auto\">
		
				<table style=\"background:#fff;border:0px solid #E8E8E8; border-radius:0px; border-collapse:collapse; overflow:hidden;padding:20px;margin:0 auto; font-size: 15px; width:460px\"><tbody>
				
	  			<tr><td style=\"text-align:center; width:auto; color:#333; padding:20px;\"><img src=\"https://admissions.brilliantpala.org/img/email/paymentsuccess.jpg\" alt=\"Payment Successful!\" width=\"auto\"></td></tr>
				
	  			<tr><td style=\"text-align:center; line-height:1.4em; padding:10px 20px;\">
				
				<p style=\"font-size: 24px;font-weight:bold; line-height:36px; margin:10px 0;color: #181E29;\">Payment Successful!</p>
								
				</td></tr>
				
				<tr><td style=\"font-size: 14px;line-height: 20px;text-align:left;padding:10px 25px;color: #364159;\">
				
				<p style=\"margin:10px 0;\">Dear ".$studentname.",</p>
				
				<p style=\"margin:10px 0;\">Your Fee remittance Rs. <font color=\"#0332aa\"><strong>".number_format($paidamt,2)."</strong></font>/- with Brilliant Study Centre Pala is successful.</p>
																
				</td></tr>
				
				<tr><td style=\"text-align:center; padding:0px;color:#333;\">&nbsp;</td></tr>
	  			
	  			<tr><td style=\"font-weight: normal;font-size: 14px;line-height: 20px;text-align:left; padding:10px 20px;color: #364159;\">Thanks,<br>Brilliant Study Centre Pala</td></tr>
				
				<tr><td style=\"text-align:center; padding:0px;color:#333;\">&nbsp;</td></tr>
								
	  			</tbody></table>
				
				<div style=\"font-size: 12px;line-height: 18px;color: #889DC6;text-align:center;padding:2em 0;\">
				
					<a href=\"#\" title=\"Contact Us\" style=\"color: #889DC6;vertical-align: middle;padding-right:8px\">Contact Us</a> <font size=\"5\">&#46;</font>
					<a href=\"#\" title=\"Terms and Conditions\" style=\"color: #889DC6;vertical-align: middle;padding:0 8px\">Terms and Conditions</a> <font size=\"5\">&#46;</font>
					<a href=\"#\" title=\"Privacy Policy\" style=\"color: #889DC6;vertical-align: middle;padding:0 8px\">Privacy Policy </a> <font size=\"5\">&#46;</font>
					<a href=\"#\" title=\"Help\" style=\"color: #889DC6;vertical-align: middle;padding-left:8px\">Help</a> 
				
				</div>
				
				<div style=\"text-align:center;padding:0em 0;\">
				
					<a href=\"https://www.facebook.com/BrilliantStudyCentrePala/\" title=\"Facebook\" style=\"vertical-align: middle;padding-right:8px\"><img src=\"https://admissions.brilliantpala.org/img/email/facebook.png\" alt=\"Facebook\" width=\"auto\"></a>
					<a href=\"https://twitter.com/BrilliantPala\" title=\"Twitter\" style=\"vertical-align: middle;padding:0 8px\"><img src=\"https://admissions.brilliantpala.org/img/email/twitter.png\" alt=\"Twitter\" width=\"auto\"></a>
					<a href=\"https://www.youtube.com/BrilliantOnline/\" title=\"Youtube\" style=\"vertical-align: middle;padding:0 8px\"><img src=\"https://admissions.brilliantpala.org/img/email/youtube.png\" alt=\"Youtube\" width=\"auto\"></a>
					<a href=\"#\" title=\"Instagram\" style=\"vertical-align: middle;padding:0 8px\"><img src=\"https://admissions.brilliantpala.org/img/email/instagram.png\" alt=\"Instagram\" width=\"auto\"></a>
					<a href=\"#\" title=\"Pinterest\" style=\"vertical-align: middle;padding-left:8px\"><img src=\"https://admissions.brilliantpala.org/img/email/pinterest.png\" alt=\"Pinterest\" width=\"auto\"></a>				 
				</div>
				
				</div>
				
				</body></html>";
				
				
                 $this->SendEmailConfiguration($emailid,$subject,$body,"");
						
			
			$messTemplate = 'Dear%20[StUdEnTnAmE],%0A%0AYour%20Fee%20remittance%20Rs%20[PaIdAmOuNt]%20with%20Brilliant%20Study%20Centre%20Pala%20is%20successful,%0A%0A%0AThanks,%0ABrilliant%20Pala';

			$substr = $messTemplate;

			$searchFOr = '[StUdEnTnAmE]';
			$replacewith = $studentname;
			$substr = str_replace($searchFOr, $replacewith, $substr);

			$searchFOr = '[PaIdAmOuNt]';
			$replacewith = $paidamt;
			$substr = str_replace($searchFOr, $replacewith, $substr);

			$response = $this->SendSMSConfiguration($substr,$mobile,'1707162556981625564');
		
			return $response;
					
		}

		return 'failed';
					
		
	}
	
	
	public function CourseChangeNotification($userid){
		
		
			$this->load->model('login_model','',TRUE);
			$userdetails = $this->login_model->GetUserDetails($userid);
		
			if($userdetails['name']!=""){
				
				$studentname = $userdetails['pname'];
				$emailid = $userdetails['emailid'];
				$mobile = $userdetails['mobile'];
				
					
			$subject = "Course Change Successful";
			
			$body = "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.=w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\"><html><head><meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\"></head><body style=\"background:#fff; padding:20px;font-family: Segoe UI;\">
	
			<div style=\"background:#F6F7FA;width:600px;margin:auto;padding:1rem 0 3rem;\"> 
		
				<img src=\"https://admissions.brilliantpala.org/css/img/brilliantpala.png\" alt=\"Brilliant Study Centre\" style=\"padding:1rem 0 2rem;display:block;margin:auto\" width=\"auto\">
		
				<table style=\"background:#fff;border:0px solid #E8E8E8; border-radius:0px; border-collapse:collapse; overflow:hidden;padding:20px;margin:0 auto; font-size: 15px; width:460px\"><tbody>
				
	  			<tr><td style=\"text-align:center; width:auto; color:#333; padding:20px;\"><img src=\"https://admissions.brilliantpala.org/img/email/courseregister.jpg\" alt=\"Course Change Successful\" width=\"auto\"></td></tr>
				
	  			<tr><td style=\"text-align:center; line-height:1.4em; padding:10px 20px;\">
				
				<p style=\"font-size: 24px;font-weight:bold; line-height:36px; margin:10px 0;color: #181E29;\">Course Change Successful</p>
								
				</td></tr>
				
				<tr><td style=\"font-size: 14px;line-height: 20px;text-align:left;padding:10px 25px;color: #364159;\">
				
				<p style=\"margin:10px 0;\">Dear ".$studentname.",</p>
				
				<p style=\"margin:10px 0;\">Your Course/Centre Change Request has been processed.</p>
				
				<p style=\"margin:10px 0;\">Please <a href=\"https://admissions.brilliantpala.org/\" title=\"Login\">login</a> to your student panel for more details</p>
																
				<p style=\"margin:10px 0;\">For more details do contact us for all your admission related queries directly at admissions@brilliantpala.org | <a href=\"tel:04822 206100\">04822 206100</a> | <a href=\"tel:04822 206800\">04822 206800</a>.</p>
				
				</td></tr>
				
				<tr><td style=\"text-align:center; padding:0px;color:#333;\">&nbsp;</td></tr>
	  			
	  			<tr><td style=\"font-weight: normal;font-size: 14px;line-height: 20px;text-align:left; padding:10px 20px;color: #364159;\">Thanks,<br>Brilliant Study Centre Pala</td></tr>
				
				<tr><td style=\"text-align:center; padding:0px;color:#333;\">&nbsp;</td></tr>
								
	  			</tbody></table>
				
				<div style=\"font-size: 12px;line-height: 18px;color: #889DC6;text-align:center;padding:2em 0;\">
				
					<a href=\"#\" title=\"Contact Us\" style=\"color: #889DC6;vertical-align: middle;padding-right:8px\">Contact Us</a> <font size=\"5\">&#46;</font>
					<a href=\"#\" title=\"Terms and Conditions\" style=\"color: #889DC6;vertical-align: middle;padding:0 8px\">Terms and Conditions</a> <font size=\"5\">&#46;</font>
					<a href=\"#\" title=\"Privacy Policy\" style=\"color: #889DC6;vertical-align: middle;padding:0 8px\">Privacy Policy </a> <font size=\"5\">&#46;</font>
					<a href=\"#\" title=\"Help\" style=\"color: #889DC6;vertical-align: middle;padding-left:8px\">Help</a> 
				
				</div>
				
				<div style=\"text-align:center;padding:0em 0;\">
				
					<a href=\"https://www.facebook.com/BrilliantStudyCentrePala/\" title=\"Facebook\" style=\"vertical-align: middle;padding-right:8px\"><img src=\"https://admissions.brilliantpala.org/img/email/facebook.png\" alt=\"Facebook\" width=\"auto\"></a>
					<a href=\"https://twitter.com/BrilliantPala\" title=\"Twitter\" style=\"vertical-align: middle;padding:0 8px\"><img src=\"https://admissions.brilliantpala.org/img/email/twitter.png\" alt=\"Twitter\" width=\"auto\"></a>
					<a href=\"https://www.youtube.com/BrilliantOnline/\" title=\"Youtube\" style=\"vertical-align: middle;padding:0 8px\"><img src=\"https://admissions.brilliantpala.org/img/email/youtube.png\" alt=\"Youtube\" width=\"auto\"></a>
					<a href=\"#\" title=\"Instagram\" style=\"vertical-align: middle;padding:0 8px\"><img src=\"https://admissions.brilliantpala.org/img/email/instagram.png\" alt=\"Instagram\" width=\"auto\"></a>
					<a href=\"#\" title=\"Pinterest\" style=\"vertical-align: middle;padding-left:8px\"><img src=\"https://admissions.brilliantpala.org/img/email/pinterest.png\" alt=\"Pinterest\" width=\"auto\"></a>				 
				</div>
				
				</div>
				
				</body></html>";
				
				
                 $this->SendEmailConfiguration($emailid,$subject,$body,"");
						
			
			$messTemplate = 'Dear%20[StUdEnTnAmE],%0A%0AYour%20Course/Centre%20Change%20Request%20has%20been%20processed.%20Please%20login%20to%20your%20student%20panel%20for%20more%20details.%0A%0ABrilliant%20Pala';

			$substr = $messTemplate;

			$searchFOr = '[StUdEnTnAmE]';
			$replacewith = $studentname;
			$substr = str_replace($searchFOr, $replacewith, $substr);

			$response = $this->SendSMSConfiguration($substr,$mobile,'1707162556964178058');
		
			return $response;
					

		}

		return 'failed';
					
		
	}
	
	
	public function RefundNotification($userid){
		
		
			$this->load->model('login_model','',TRUE);
			$userdetails = $this->login_model->GetUserDetails($userid);
		
			if($userdetails['name']!=""){
				
				$studentname = $userdetails['pname'];
				$emailid = $userdetails['emailid'];
				$mobile = $userdetails['mobile'];
				
					
			$subject = "Refund Request Successful";
			
			$body = "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.=w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\"><html><head><meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\"></head><body style=\"background:#fff; padding:20px;font-family: Segoe UI;\">
	
			<div style=\"background:#F6F7FA;width:600px;margin:auto;padding:1rem 0 3rem;\"> 
		
				<img src=\"https://admissions.brilliantpala.org/css/img/brilliantpala.png\" alt=\"Brilliant Study Centre\" style=\"padding:1rem 0 2rem;display:block;margin:auto\" width=\"auto\">
		
				<table style=\"background:#fff;border:0px solid #E8E8E8; border-radius:0px; border-collapse:collapse; overflow:hidden;padding:20px;margin:0 auto; font-size: 15px; width:460px\"><tbody>
				
	  			<tr><td style=\"text-align:center; width:auto; color:#333; padding:20px;\"><img src=\"https://admissions.brilliantpala.org/img/email/courseregister.jpg\" alt=\"Refund Request Successful\" width=\"auto\"></td></tr>
				
	  			<tr><td style=\"text-align:center; line-height:1.4em; padding:10px 20px;\">
				
				<p style=\"font-size: 24px;font-weight:bold; line-height:36px; margin:10px 0;color: #181E29;\">Refund Request Successful</p>
								
				</td></tr>
				
				<tr><td style=\"font-size: 14px;line-height: 20px;text-align:left;padding:10px 25px;color: #364159;\">
				
				<p style=\"margin:10px 0;\">Dear ".$studentname.",</p>
				
				<p style=\"margin:10px 0;\">Your refund request has been processed. You will receive your Cheque/Transfer within next 7 working days</p>
																				
				<p style=\"margin:10px 0;\">For more details do contact us for all your admission related queries directly at admissions@brilliantpala.org | <a href=\"tel:04822 206100\">04822 206100</a> | <a href=\"tel:04822 206800\">04822 206800</a>.</p>
				
				</td></tr>
				
				<tr><td style=\"text-align:center; padding:0px;color:#333;\">&nbsp;</td></tr>
	  			
	  			<tr><td style=\"font-weight: normal;font-size: 14px;line-height: 20px;text-align:left; padding:10px 20px;color: #364159;\">Thanks,<br>Brilliant Study Centre Pala</td></tr>
				
				<tr><td style=\"text-align:center; padding:0px;color:#333;\">&nbsp;</td></tr>
								
	  			</tbody></table>
				
				<div style=\"font-size: 12px;line-height: 18px;color: #889DC6;text-align:center;padding:2em 0;\">
				
					<a href=\"#\" title=\"Contact Us\" style=\"color: #889DC6;vertical-align: middle;padding-right:8px\">Contact Us</a> <font size=\"5\">&#46;</font>
					<a href=\"#\" title=\"Terms and Conditions\" style=\"color: #889DC6;vertical-align: middle;padding:0 8px\">Terms and Conditions</a> <font size=\"5\">&#46;</font>
					<a href=\"#\" title=\"Privacy Policy\" style=\"color: #889DC6;vertical-align: middle;padding:0 8px\">Privacy Policy </a> <font size=\"5\">&#46;</font>
					<a href=\"#\" title=\"Help\" style=\"color: #889DC6;vertical-align: middle;padding-left:8px\">Help</a> 
				
				</div>
				
				<div style=\"text-align:center;padding:0em 0;\">
				
					<a href=\"https://www.facebook.com/BrilliantStudyCentrePala/\" title=\"Facebook\" style=\"vertical-align: middle;padding-right:8px\"><img src=\"https://admissions.brilliantpala.org/img/email/facebook.png\" alt=\"Facebook\" width=\"auto\"></a>
					<a href=\"https://twitter.com/BrilliantPala\" title=\"Twitter\" style=\"vertical-align: middle;padding:0 8px\"><img src=\"https://admissions.brilliantpala.org/img/email/twitter.png\" alt=\"Twitter\" width=\"auto\"></a>
					<a href=\"https://www.youtube.com/BrilliantOnline/\" title=\"Youtube\" style=\"vertical-align: middle;padding:0 8px\"><img src=\"https://admissions.brilliantpala.org/img/email/youtube.png\" alt=\"Youtube\" width=\"auto\"></a>
					<a href=\"#\" title=\"Instagram\" style=\"vertical-align: middle;padding:0 8px\"><img src=\"https://admissions.brilliantpala.org/img/email/instagram.png\" alt=\"Instagram\" width=\"auto\"></a>
					<a href=\"#\" title=\"Pinterest\" style=\"vertical-align: middle;padding-left:8px\"><img src=\"https://admissions.brilliantpala.org/img/email/pinterest.png\" alt=\"Pinterest\" width=\"auto\"></a>				 
				</div>
				
				</div>
				
				</body></html>";
				
				
                 $this->SendEmailConfiguration($emailid,$subject,$body,"");
						
			
			$messTemplate = 'Dear%20[StUdEnTnAmE],%0A%0AYour%20refund%20request%20has%20been%20processed.%20You%20will%20receive%20your%20Cheque/Transfer%20within%20next%207%20working%20days.%0A%0ABrilliant%20Pala';

			$substr = $messTemplate;

			$searchFOr = '[StUdEnTnAmE]';
			$replacewith = $studentname;
			$substr = str_replace($searchFOr, $replacewith, $substr);

			$response = $this->SendSMSConfiguration($substr,$mobile,'1707162556946971933');
		
			return $response;
					

		}

		return 'failed';
					
		
	}
	
        public function RefundConfirmatiion($userid) {
            
            $response ="";
            $this->load->model('login_model','',TRUE);
            $userdetails = $this->login_model->GetUserDetails($userid);
		
            if($userdetails['name']!=""){

                    $studentname = $userdetails['pname'];    
                    $emailid = $userdetails['emailid'];
                    $mobile = $userdetails['mobile'];
                    
                    		
			$subject = "Refund Confirmation";
			
			$body = "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.=w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\"><html><head><meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\"></head><body style=\"background:#fff; padding:20px;font-family: Segoe UI;\">
	
			<div style=\"background:#F6F7FA;width:600px;margin:auto;padding:1rem 0 3rem;\"> 
		
				<img src=\"https://admissions.brilliantpala.org/css/img/brilliantpala.png\" alt=\"Brilliant Study Centre\" style=\"padding:1rem 0 2rem;display:block;margin:auto\" width=\"auto\">
		
				<table style=\"background:#fff;border:0px solid #E8E8E8; border-radius:0px; border-collapse:collapse; overflow:hidden;padding:20px;margin:0 auto; font-size: 15px; width:460px\"><tbody>
				
	  			<tr><td style=\"text-align:center; width:auto; color:#333; padding:20px;\"><img src=\"https://admissions.brilliantpala.org/img/email/courseregister.jpg\" alt=\"Refund Request Successful\" width=\"auto\"></td></tr>
				
	  			<tr><td style=\"text-align:center; line-height:1.4em; padding:10px 20px;\">
				
				<p style=\"font-size: 24px;font-weight:bold; line-height:36px; margin:10px 0;color: #181E29;\">Refund Confirmation</p>
								
				</td></tr>
				
				<tr><td style=\"font-size: 14px;line-height: 20px;text-align:left;padding:10px 25px;color: #364159;\">
				
				<p style=\"margin:10px 0;\">Dear ".$studentname.",</p>
				
				<p style=\"margin:10px 0;\">Your Refund Request has been processed and transferred to your bank account. Please check with your bank for confirmation</p>
																				
				<p style=\"margin:10px 0;\">For more details do contact us for all your admission related queries directly at admissions@brilliantpala.org | <a href=\"tel:04822 206100\">04822 206100</a> | <a href=\"tel:04822 206800\">04822 206800</a>.</p>
				
				</td></tr>
				
				<tr><td style=\"text-align:center; padding:0px;color:#333;\">&nbsp;</td></tr>
	  			
	  			<tr><td style=\"font-weight: normal;font-size: 14px;line-height: 20px;text-align:left; padding:10px 20px;color: #364159;\">Thanks,<br>Brilliant Study Centre Pala</td></tr>
				
				<tr><td style=\"text-align:center; padding:0px;color:#333;\">&nbsp;</td></tr>
								
	  			</tbody></table>
				
				<div style=\"font-size: 12px;line-height: 18px;color: #889DC6;text-align:center;padding:2em 0;\">
				
					<a href=\"#\" title=\"Contact Us\" style=\"color: #889DC6;vertical-align: middle;padding-right:8px\">Contact Us</a> <font size=\"5\">&#46;</font>
					<a href=\"#\" title=\"Terms and Conditions\" style=\"color: #889DC6;vertical-align: middle;padding:0 8px\">Terms and Conditions</a> <font size=\"5\">&#46;</font>
					<a href=\"#\" title=\"Privacy Policy\" style=\"color: #889DC6;vertical-align: middle;padding:0 8px\">Privacy Policy </a> <font size=\"5\">&#46;</font>
					<a href=\"#\" title=\"Help\" style=\"color: #889DC6;vertical-align: middle;padding-left:8px\">Help</a> 
				
				</div>
				
				<div style=\"text-align:center;padding:0em 0;\">
				
					<a href=\"https://www.facebook.com/BrilliantStudyCentrePala/\" title=\"Facebook\" style=\"vertical-align: middle;padding-right:8px\"><img src=\"https://admissions.brilliantpala.org/img/email/facebook.png\" alt=\"Facebook\" width=\"auto\"></a>
					<a href=\"https://twitter.com/BrilliantPala\" title=\"Twitter\" style=\"vertical-align: middle;padding:0 8px\"><img src=\"https://admissions.brilliantpala.org/img/email/twitter.png\" alt=\"Twitter\" width=\"auto\"></a>
					<a href=\"https://www.youtube.com/BrilliantOnline/\" title=\"Youtube\" style=\"vertical-align: middle;padding:0 8px\"><img src=\"https://admissions.brilliantpala.org/img/email/youtube.png\" alt=\"Youtube\" width=\"auto\"></a>
					<a href=\"#\" title=\"Instagram\" style=\"vertical-align: middle;padding:0 8px\"><img src=\"https://admissions.brilliantpala.org/img/email/instagram.png\" alt=\"Instagram\" width=\"auto\"></a>
					<a href=\"#\" title=\"Pinterest\" style=\"vertical-align: middle;padding-left:8px\"><img src=\"https://admissions.brilliantpala.org/img/email/pinterest.png\" alt=\"Pinterest\" width=\"auto\"></a>				 
				</div>
				
				</div>
				
				</body></html>";
				
				
                 $this->SendEmailConfiguration($emailid,$subject,$body,"");
            
                    $messTemplate = 'Dear%20[StUdEnTnAmE],Your%20Refund%20Request%20has%20been%20processed%20and%20transferred%20to%20your%20bank%20account.%20Please%20check%20with%20your%20bank%20for%20confirmation.%20Thanks%20Brilliant%20Pala';

                    $substr = $messTemplate;

                    $searchFOr = '[StUdEnTnAmE]';
                    $replacewith = $studentname;
                    $substr = str_replace($searchFOr, $replacewith, $substr);

                    $response = $this->SendSMSConfiguration($substr,$mobile,'1707163721001991625');
            }

            return $response;
            
        }

        public function PartialPaymentNotification($userid,$partialamt){		
		
			$this->load->model('login_model','',TRUE);
			$userdetails = $this->login_model->GetUserDetails($userid);
		
			if($userdetails['name']!=""){
				
				$studentname = $userdetails['pname'];
				$emailid = $userdetails['emailid'];
				$mobile = $userdetails['mobile'];
				
					
				//$duedate = date("d/M/Y","+7 days");
				
			$subject = "Partial Payment Request Successful";
			
			$body = "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.=w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\"><html><head><meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\"></head><body style=\"background:#fff; padding:20px;font-family: Segoe UI;\">
	
			<div style=\"background:#F6F7FA;width:600px;margin:auto;padding:1rem 0 3rem;\"> 
		
				<img src=\"https://admissions.brilliantpala.org/css/img/brilliantpala.png\" alt=\"Brilliant Study Centre\" style=\"padding:1rem 0 2rem;display:block;margin:auto\" width=\"auto\">
		
				<table style=\"background:#fff;border:0px solid #E8E8E8; border-radius:0px; border-collapse:collapse; overflow:hidden;padding:20px;margin:0 auto; font-size: 15px; width:460px\"><tbody>
				
	  			<tr><td style=\"text-align:center; width:auto; color:#333; padding:20px;\"><img src=\"https://admissions.brilliantpala.org/img/email/paymentsuccess.jpg\" alt=\"Partial Payment Request Successful\" width=\"auto\"></td></tr>
				
	  			<tr><td style=\"text-align:center; line-height:1.4em; padding:10px 20px;\">
				
				<p style=\"font-size: 24px;font-weight:bold; line-height:36px; margin:10px 0;color: #181E29;\">Partial Payment Request Successful</p>
								
				</td></tr>
				
				<tr><td style=\"font-size: 14px;line-height: 20px;text-align:left;padding:10px 25px;color: #364159;\">
				
				<p style=\"margin:10px 0;\">Dear ".$studentname.",</p>
				
				<p style=\"margin:10px 0;\"> Your request for partial fee payment for Rs. <font color=\"#0332aa\"><strong>".number_format($partialamt,2)."</strong></font>/- has been enabled.</p>
				
				<p style=\"margin:10px 0;\">Please <a href=\"https://admissions.brilliantpala.org/\" title=\"Login\">login</a> to your student panel and remit your partial payment.</p>
																				
				<p style=\"margin:10px 0;\">For more details do contact us for all your admission related queries directly at admissions@brilliantpala.org | <a href=\"tel:04822 206100\">04822 206100</a> | <a href=\"tel:04822 206800\">04822 206800</a>.</p>
				
				</td></tr>
				
				<tr><td style=\"text-align:center; padding:0px;color:#333;\">&nbsp;</td></tr>
	  			
	  			<tr><td style=\"font-weight: normal;font-size: 14px;line-height: 20px;text-align:left; padding:10px 20px;color: #364159;\">Thanks,<br>Brilliant Study Centre Pala</td></tr>
				
				<tr><td style=\"text-align:center; padding:0px;color:#333;\">&nbsp;</td></tr>
								
	  			</tbody></table>
				
				<div style=\"font-size: 12px;line-height: 18px;color: #889DC6;text-align:center;padding:2em 0;\">
				
					<a href=\"#\" title=\"Contact Us\" style=\"color: #889DC6;vertical-align: middle;padding-right:8px\">Contact Us</a> <font size=\"5\">&#46;</font>
					<a href=\"#\" title=\"Terms and Conditions\" style=\"color: #889DC6;vertical-align: middle;padding:0 8px\">Terms and Conditions</a> <font size=\"5\">&#46;</font>
					<a href=\"#\" title=\"Privacy Policy\" style=\"color: #889DC6;vertical-align: middle;padding:0 8px\">Privacy Policy </a> <font size=\"5\">&#46;</font>
					<a href=\"#\" title=\"Help\" style=\"color: #889DC6;vertical-align: middle;padding-left:8px\">Help</a> 
				
				</div>
				
				<div style=\"text-align:center;padding:0em 0;\">
				
					<a href=\"https://www.facebook.com/BrilliantStudyCentrePala/\" title=\"Facebook\" style=\"vertical-align: middle;padding-right:8px\"><img src=\"https://admissions.brilliantpala.org/img/email/facebook.png\" alt=\"Facebook\" width=\"auto\"></a>
					<a href=\"https://twitter.com/BrilliantPala\" title=\"Twitter\" style=\"vertical-align: middle;padding:0 8px\"><img src=\"https://admissions.brilliantpala.org/img/email/twitter.png\" alt=\"Twitter\" width=\"auto\"></a>
					<a href=\"https://www.youtube.com/BrilliantOnline/\" title=\"Youtube\" style=\"vertical-align: middle;padding:0 8px\"><img src=\"https://admissions.brilliantpala.org/img/email/youtube.png\" alt=\"Youtube\" width=\"auto\"></a>
					<a href=\"#\" title=\"Instagram\" style=\"vertical-align: middle;padding:0 8px\"><img src=\"https://admissions.brilliantpala.org/img/email/instagram.png\" alt=\"Instagram\" width=\"auto\"></a>
					<a href=\"#\" title=\"Pinterest\" style=\"vertical-align: middle;padding-left:8px\"><img src=\"https://admissions.brilliantpala.org/img/email/pinterest.png\" alt=\"Pinterest\" width=\"auto\"></a>				 
				</div>
				
				</div>
				
				</body></html>";
				
				
                 $this->SendEmailConfiguration($emailid,$subject,$body,"");
						
							
			$messTemplate = 'Dear%20[StUdEnTnAmE],%0A%0AYour%20request%20for%20partial%20fee%20payment%20for%20Rs.%20[PaRtIaLAmOuNt]%20has%20been%20enabled.%0APlease%20login%20to%20your%20student%20panel%20and%20remit%20your%20partial%20payment.%0A%0ABrilliant%20Pala';
				
			//$messTemplate = 'Dear%20[StUdEnTnAmE],%0A%0AYour%20request%20for%20partial%20fee%20payment%20for%20Rs.%20[PaRtIaLAmOuNt]%20has%20been%20enabled.%20Please%20login%20to%20your%20student%20panel%20and%20remit%20your%20partial%20payment.Your%20next%20fee%20due%20date%20is%20[DuEdAtE].%0A%0ABrilliant%20Pala';

			$substr = $messTemplate;

			$searchFOr = '[StUdEnTnAmE]';
			$replacewith = $studentname;
			$substr = str_replace($searchFOr, $replacewith, $substr);
				
			$searchFOr = '[PaRtIaLAmOuNt]';
			$replacewith = $partialamt;
			$substr = str_replace($searchFOr, $replacewith, $substr);
				
			/*$searchFOr = '[DuEdAtE]';
			$replacewith = $duedate;
			$substr = str_replace($searchFOr, $replacewith, $substr);*/

			//$response = $this->SendSMSConfiguration($substr,$mobile,'1707162556920087234');
			 $response = $this->SendSMSConfiguration($substr,$mobile,'1707162609464136973');
		
			return $response;
					

		}

		return 'failed';
					
		
	}
	
	
	public function ShortlistedNotification($crqid){
		
		
			$query2 = $this-> db -> query('select cr.studentid,c.coursename from bscp_courserequest as cr,admin_course as c where cr.courseid = c.ide and cr.ide="'.$crqid.'"');
			$row2 = $query2->result_array();
			if($query2->num_rows()>0){

				$coursename = $row2[0]['coursename'];
				$userid = $row2[0]['studentid'];
				
				
				$this->load->model('login_model','',TRUE);
				$userdetails = $this->login_model->GetUserDetails($userid);

				if($userdetails['name']!=""){

					$studentname = $userdetails['pname'];
					$emailid = $userdetails['emailid'];
					$mobile = $userdetails['mobile'];
				
				
					
			$subject = "Application Shortlisted";
			
			$body = "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.=w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\"><html><head><meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\"></head><body style=\"background:#fff; padding:20px;font-family: Segoe UI;\">
	
			<div style=\"background:#F6F7FA;width:600px;margin:auto;padding:1rem 0 3rem;\"> 
		
				<img src=\"https://admissions.brilliantpala.org/css/img/brilliantpala.png\" alt=\"Brilliant Study Centre\" style=\"padding:1rem 0 2rem;display:block;margin:auto\" width=\"auto\">
		
				<table style=\"background:#fff;border:0px solid #E8E8E8; border-radius:0px; border-collapse:collapse; overflow:hidden;padding:20px;margin:0 auto; font-size: 15px; width:460px\"><tbody>
				
	  			<tr><td style=\"text-align:center; width:auto; color:#333; padding:20px;\"><img src=\"https://admissions.brilliantpala.org/img/email/courseregister.jpg\" alt=\"Application Shortlisted\" width=\"auto\"></td></tr>
				
	  			<tr><td style=\"text-align:center; line-height:1.4em; padding:10px 20px;\">
				
				<p style=\"font-size: 24px;font-weight:bold; line-height:36px; margin:10px 0;color: #181E29;\">Application Shortlisted</p>
								
				</td></tr>
				
				<tr><td style=\"font-size: 14px;line-height: 20px;text-align:left;padding:10px 25px;color: #364159;\">
				
				<p style=\"margin:10px 0;\">Dear ".$studentname.",</p>
				
				<p style=\"margin:10px 0;\">Your application for <font color=\"#0332aa\"><strong>".$coursename."</strong></font> has been shortlisted.</p>
				
				<p style=\"margin:10px 0;\">We will update you with further details Shortly. You can <a href=\"https://admissions.brilliantpala.org/\" title=\"Update\">update</a> your profile and Upload Marksheet now.</p>
																
				<p style=\"margin:10px 0;\">For more details do contact us for all your admission related queries directly at admissions@brilliantpala.org | <a href=\"tel:04822 206100\">04822 206100</a> | <a href=\"tel:04822 206800\">04822 206800</a>.</p>
				
				</td></tr>
				
				<tr><td style=\"text-align:center; padding:0px;color:#333;\">&nbsp;</td></tr>
	  			
	  			<tr><td style=\"font-weight: normal;font-size: 14px;line-height: 20px;text-align:left; padding:10px 20px;color: #364159;\">Thanks,<br>Brilliant Study Centre Pala</td></tr>
				
				<tr><td style=\"text-align:center; padding:0px;color:#333;\">&nbsp;</td></tr>
								
	  			</tbody></table>
				
				<div style=\"font-size: 12px;line-height: 18px;color: #889DC6;text-align:center;padding:2em 0;\">
				
					<a href=\"#\" title=\"Contact Us\" style=\"color: #889DC6;vertical-align: middle;padding-right:8px\">Contact Us</a> <font size=\"5\">&#46;</font>
					<a href=\"#\" title=\"Terms and Conditions\" style=\"color: #889DC6;vertical-align: middle;padding:0 8px\">Terms and Conditions</a> <font size=\"5\">&#46;</font>
					<a href=\"#\" title=\"Privacy Policy\" style=\"color: #889DC6;vertical-align: middle;padding:0 8px\">Privacy Policy </a> <font size=\"5\">&#46;</font>
					<a href=\"#\" title=\"Help\" style=\"color: #889DC6;vertical-align: middle;padding-left:8px\">Help</a> 
				
				</div>
				
				<div style=\"text-align:center;padding:0em 0;\">
				
					<a href=\"https://www.facebook.com/BrilliantStudyCentrePala/\" title=\"Facebook\" style=\"vertical-align: middle;padding-right:8px\"><img src=\"https://admissions.brilliantpala.org/img/email/facebook.png\" alt=\"Facebook\" width=\"auto\"></a>
					<a href=\"https://twitter.com/BrilliantPala\" title=\"Twitter\" style=\"vertical-align: middle;padding:0 8px\"><img src=\"https://admissions.brilliantpala.org/img/email/twitter.png\" alt=\"Twitter\" width=\"auto\"></a>
					<a href=\"https://www.youtube.com/BrilliantOnline/\" title=\"Youtube\" style=\"vertical-align: middle;padding:0 8px\"><img src=\"https://admissions.brilliantpala.org/img/email/youtube.png\" alt=\"Youtube\" width=\"auto\"></a>
					<a href=\"#\" title=\"Instagram\" style=\"vertical-align: middle;padding:0 8px\"><img src=\"https://admissions.brilliantpala.org/img/email/instagram.png\" alt=\"Instagram\" width=\"auto\"></a>
					<a href=\"#\" title=\"Pinterest\" style=\"vertical-align: middle;padding-left:8px\"><img src=\"https://admissions.brilliantpala.org/img/email/pinterest.png\" alt=\"Pinterest\" width=\"auto\"></a>				 
				</div>
				
				</div>
				
				</body></html>";
				
				
                 $this->SendEmailConfiguration($emailid,$subject,$body,"");
						
			
					$messTemplate = 'Dear%20[StUdEnTnAmE],%0A%0AYour%20application%20for%20[CoUrSeNaMe]%20has%20been%20shortlisted.%0AWe%20will%20update%20you%20with%20further%20details%20Shortly.%20You%20can%20update%20your%20profile%20and%20Upload%20Marksheet%20now.%0A%0AThanks%0ABrilliant%20Pala';

					$substr = $messTemplate;

					$searchFOr = '[StUdEnTnAmE]';
					$replacewith = $studentname;
					$substr = str_replace($searchFOr, $replacewith, $substr);

					$searchFOr = '[CoUrSeNaMe]';
					$replacewith = $coursename;
					$substr = str_replace($searchFOr, $replacewith, $substr);


					$response = $this->SendSMSConfiguration($substr,$mobile,'1707162609504458079');

					return $response;
					
				}
					

		}

		return 'failed';
					
		
	}
        
        public function SendAdminUserCredentails($userid,$password){
		
				
				
				$this->load->model('login_model','',TRUE);
				$userdetails = $this->login_model->GetUserDetails($userid);

				if($userdetails['name']!=""){

					$username = $userdetails['name'];
					$emailid = $userdetails['emailid'];
                                        $pname = $userdetails['pname'];
				
				
					
			$subject = "Your brilliant study centre account was activated";
			
			$body = "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.=w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\"><html><head><meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\"></head><body style=\"background:#fff; padding:20px;font-family: Segoe UI;\">
	
			<div style=\"background:#F6F7FA;width:600px;margin:auto;padding:1rem 0 3rem;\"> 
		
				<img src=\"https://admissions.brilliantpala.org/css/img/brilliantpala.png\" alt=\"Brilliant Study Centre\" style=\"padding:1rem 0 2rem;display:block;margin:auto\" width=\"auto\">
		
				<table style=\"background:#fff;border:0px solid #E8E8E8; border-radius:0px; border-collapse:collapse; overflow:hidden;padding:20px;margin:0 auto; font-size: 15px; width:460px\"><tbody>
				
	  			<tr><td style=\"text-align:center; width:auto; color:#333; padding:20px;\"><img src=\"https://admissions.brilliantpala.org/img/email/courseregister.jpg\" alt=\"Account Activated\" width=\"auto\"></td></tr>
				
	  			<tr><td style=\"text-align:center; line-height:1.4em; padding:10px 20px;\">
				
				<p style=\"font-size: 24px;font-weight:bold; line-height:36px; margin:10px 0;color: #181E29;\">Account Activated</p>
								
				</td></tr>
				
				<tr><td style=\"font-size: 14px;line-height: 20px;text-align:left;padding:10px 25px;color: #364159;\">
				
				<p style=\"margin:10px 0;\">Hello ".$pname.",</p>
				
                                <p style=\"margin:10px 0;\">Kindly find below your account credentails,</p>

				<p style=\"margin:10px 0;\">Username : <font color=\"#0332aa\"><strong>".$username."</strong></font></p>
				
				<p style=\"margin:10px 0;\">Password : <font color=\"#0332aa\"><strong>".$password."</strong></font></p>
                                    
				</td></tr>
				
				<tr><td style=\"text-align:center; padding:0px;color:#333;\">&nbsp;</td></tr>
	  			
	  			<tr><td style=\"font-weight: normal;font-size: 14px;line-height: 20px;text-align:left; padding:10px 20px;color: #364159;\">Thanks,<br>Brilliant Study Centre Pala</td></tr>
				
				<tr><td style=\"text-align:center; padding:0px;color:#333;\">&nbsp;</td></tr>
								
	  			</tbody></table>
				
				<div style=\"font-size: 12px;line-height: 18px;color: #889DC6;text-align:center;padding:2em 0;\">
				
					<a href=\"#\" title=\"Contact Us\" style=\"color: #889DC6;vertical-align: middle;padding-right:8px\">Contact Us</a> <font size=\"5\">&#46;</font>
					<a href=\"#\" title=\"Terms and Conditions\" style=\"color: #889DC6;vertical-align: middle;padding:0 8px\">Terms and Conditions</a> <font size=\"5\">&#46;</font>
					<a href=\"#\" title=\"Privacy Policy\" style=\"color: #889DC6;vertical-align: middle;padding:0 8px\">Privacy Policy </a> <font size=\"5\">&#46;</font>
					<a href=\"#\" title=\"Help\" style=\"color: #889DC6;vertical-align: middle;padding-left:8px\">Help</a> 
				
				</div>
				
				<div style=\"text-align:center;padding:0em 0;\">
				
					<a href=\"https://www.facebook.com/BrilliantStudyCentrePala/\" title=\"Facebook\" style=\"vertical-align: middle;padding-right:8px\"><img src=\"https://admissions.brilliantpala.org/img/email/facebook.png\" alt=\"Facebook\" width=\"auto\"></a>
					<a href=\"https://twitter.com/BrilliantPala\" title=\"Twitter\" style=\"vertical-align: middle;padding:0 8px\"><img src=\"https://admissions.brilliantpala.org/img/email/twitter.png\" alt=\"Twitter\" width=\"auto\"></a>
					<a href=\"https://www.youtube.com/BrilliantOnline/\" title=\"Youtube\" style=\"vertical-align: middle;padding:0 8px\"><img src=\"https://admissions.brilliantpala.org/img/email/youtube.png\" alt=\"Youtube\" width=\"auto\"></a>
					<a href=\"#\" title=\"Instagram\" style=\"vertical-align: middle;padding:0 8px\"><img src=\"https://admissions.brilliantpala.org/img/email/instagram.png\" alt=\"Instagram\" width=\"auto\"></a>
					<a href=\"#\" title=\"Pinterest\" style=\"vertical-align: middle;padding-left:8px\"><img src=\"https://admissions.brilliantpala.org/img/email/pinterest.png\" alt=\"Pinterest\" width=\"auto\"></a>				 
				</div>
				
				</div>
				
				</body></html>";
				
				
                                $this->SendEmailConfiguration($emailid,$subject,$body,"");
						
			
					
				}
					
			
		
	}
	
	 public function sendEmailStudentReportcard($userid,$sdate,$edate){
		
				
				
	$this->load->model('login_model','',TRUE);
	$userdetails = $this->login_model->GetUserDetails($userid);


	$this->load->model('exams_model','',TRUE);
	$results = $this->exams_model->GetStudentResult($userid,$sdate,$edate);

	if($userdetails['name']!=""){

		$username = $userdetails['name'];
		$emailid = $userdetails['emailid'];
		$pname = $userdetails['pname'];
				
			$examtable = "";		
					
			if($results['model']!=""){
					
					$examtable .=  "<div style=\"display: -webkit-box;display: -ms-flexbox;display: flex;-ms-flex-wrap: wrap;flex-wrap: wrap; margin-right: -15px;margin-left: -15px;\">
			   
			   	  <div style=\"width: 100%;\">
			   		<h3 style=\"color: #181E29; font-size: 20px;font-weight: bold;line-height: 24px;margin-bottom: 0px; text-align: center; text-transform: uppercase;padding: 0.8rem; border-radius: 10px;border: 1px solid #181E29\">Model Exam Results</h3>
				  </div>
			   
			   </div>

			   <div style=\"margin-bottom: 1rem\"></div>
			   
			   
			   <div style=\"padding: .5rem 0;\">
			                  
                <table>
              <thead>
                <tr>
                  <th style=\"border-left: none;\" scope=\"col\" width=\"12%\">Exam Date</th>
                  <th scope=\"col\" width=\"16%\">Name of Exam</th>
                  <th scope=\"col\" width=\"5%\">Phy</th>
                  <th scope=\"col\" width=\"5%\">Che</th>
                  <th scope=\"col\" width=\"5%\">Bio</th>
                  <th scope=\"col\" width=\"5%\">Mat</th>
                  <th scope=\"col\" width=\"5%\">P-I</th>
                  <th scope=\"col\" width=\"6%\">P-II</th>
                  <th scope=\"col\" width=\"6%\">Total Marks</th>
                  <th scope=\"col\" width=\"6%\">Max Marks</th>
                  <th scope=\"col\" width=\"6%\">Highest Marks</th>
                  <th scope=\"col\" width=\"6%\">Percent %</th>
                  <th scope=\"col\" width=\"5%\">Grade</th>
                  <th scope=\"col\" width=\"5%\">Rank</th>
                  <th scope=\"col\" width=\"6%\">Students Appeared</th>
                </tr>
              </thead>
              <tbody>
                
                ". $results['model']."
   
              </tbody>
            </table>
               
			</div>
		   
		   
		   <div style=\"margin-bottom: 1.5rem\"></div>";
						
		}
					
					
	if($results['weekly']!=""){
		
		 $examtable .= "<div style=\"display: -webkit-box;display: -ms-flexbox;display: flex;-ms-flex-wrap: wrap;flex-wrap: wrap; margin-right: -15px;margin-left: -15px;\">
			   
			   	  <div style=\"-webkit-box-flex: 0;-ms-flex: 0 0 100%;flex: 0 0 100%;max-width: 100%;\">
			   		<h3 style=\"color: #181E29; font-size: 20px;font-weight: bold;line-height: 24px;margin-bottom: 0px; text-align: center; text-transform: uppercase;padding: 0.8rem; border-radius: 10px;border: 1px solid #181E29;\">Weekly Exam Results</h3>
				  </div>
			   
			   </div>

			   <div style=\"margin-bottom: 1rem\"></div>
			   
			   
			  <div style=\"padding: .5rem 0;\">
			                  
                <table style=\"border-collapse: separate !important;border: 1px solid #181E29;border-radius: 10px;webkit-border-radius: 10px;-moz-border-radius: 10px;box-shadow: 0 0 0 0px #364159; margin: 1rem auto;table-layout: fixed;border-spacing: 0px;width: 100%;\">
              <thead>
                <tr>
                  <th style=\"border-left: none;\" scope=\"col\" width=\"12%\">Exam Date</th>
                  <th scope=\"col\" width=\"16%\">Name of Exam</th>
                  <th scope=\"col\" width=\"5%\">Phy</th>
                  <th scope=\"col\" width=\"5%\">Che</th>
                  <th scope=\"col\" width=\"5%\">Bio</th>
                  <th scope=\"col\" width=\"5%\">Mat</th>
                  <th scope=\"col\" width=\"5%\">P-I</th>
                  <th scope=\"col\" width=\"6%\">P-II</th>
                  <th scope=\"col\" width=\"6%\">Total Marks</th>
                  <th scope=\"col\" width=\"6%\">Max Marks</th>
                  <th scope=\"col\" width=\"6%\">Highest Marks</th>
                  <th scope=\"col\" width=\"6%\">Percent %</th>
                  <th scope=\"col\" width=\"5%\">Grade</th>
                  <th scope=\"col\" width=\"5%\">Rank</th>
                  <th scope=\"col\" width=\"6%\">Students Appeared</th>
                </tr>
              </thead>
              <tbody>
                
                ".$results['weekly']."
   
              </tbody>
            </table>
               
			</div>";
	}	   
				
					
			$subject = "Report Card";
			
			$body = "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.=w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\"><html><head><meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />
			<style>
			
					table{border: 0px solid #364159;border-collapse: separate !important;border-style: solid;border-radius: 10px;box-shadow: 0 0 0 0px #364159;margin: 1rem auto; table-layout: fixed;border-spacing: 0px;}
				table thead th{font-size: 12px;font-weight: 600;color: #6F83AA;letter-spacing: 0.5px;background: #E6EBF7;text-transform: none;padding: 0.5rem;text-align: left;vertical-align: middle;border-bottom: 0px solid #364159;}
				table thead tr th:first-child{border-top-left-radius: 10px;border-top: 0px solid #364159;}
				table thead tr th:last-child{border-top-right-radius: 10px}
				table td, table th{font-size: 12px;border-top: 0px solid #364159;padding: 0.9rem 0.75rem;color: #364159;font-weight: 600;}
				table {border: 1px solid #181E29;-moz-border-radius: 10px;-webkit-border-radius: 10px;border-radius: 10px;}
				table td, table th {border-left: 1px solid #181E29;border-top: 1px solid #181E29;padding: 10px;text-align: left;}
				table tr th:first-child{border-top: 1px solid #181E29;border-radius: 0px}
				table th {background-color: transparent;border-top: none;}
				table td:first-child, table th:first-child { border-left: none;}
				table th:first-child {-moz-border-radius: 10px 0 0 0; -webkit-border-radius: 10px 0 0 0;border-radius: 10px 0 0 0;}
				table th:last-child {-moz-border-radius: 0 10px 0 0; -webkit-border-radius: 0 10px 0 0; border-radius: 0 10px 0 0;}
				table th:only-child{-moz-border-radius: 10px 10px 0 0;-webkit-border-radius: 10px 10px 0 0;border-radius: 10px 10px 0 0;}
				table tr:last-child td:first-child {-moz-border-radius: 0 0 0 10px;-webkit-border-radius: 0 0 0 10px; border-radius: 0 0 0 10px;}
				table tr:last-child td:last-child {-moz-border-radius: 0 0 10px 0;-webkit-border-radius: 0 0 10px 0; border-radius: 0 0 10px 0;} 

				table td.totalfee {font-weight: bold;font-size: 16px;color: #D63333;}
				table td.totalamt {font-weight: bold;font-size: 12px;color: #6F83AA;letter-spacing: 0.5px;text-transform: uppercase;text-align: right !important}
				table tr:last-child td{text-align: left}
				table tr td:last-child,table tr th:last-child{text-align: center}
				table tr:last-child td:last-child{font-weight: bold;text-align: center}
				table tr:last-child{text-align: center}
	
			</style>
			
			</head><body style=\"font-family: Segoe UI;\">

	<div style=\"background:#F6F7FA;width:auto;margin:auto;padding: 3rem 0;\">
		
	<div style=\"display: -webkit-box;display: -ms-flexbox;display: flex;-ms-flex-wrap: wrap;flex-wrap: wrap; margin-right: -15px;margin-left: -15px;\">
								
		<div style=\"width: 100%;border: none;background:#FFFFFF;width:85%;margin: 0 auto;padding: 2rem;\">
		
			<div style=\"display: -webkit-box;display: -ms-flexbox;display: flex;-ms-flex-wrap: wrap;flex-wrap: wrap; margin-right: -15px;margin-left: -15px;\">
					
			<div style=\"width: 50%;\">
			
				<img src=\"https://admissions.brilliantpala.org/css/img/brilliantpala.png\" alt=\"Brilliant Pala Logo\" style=\"margin-top: 2rem\" />
																	
			</div>
			<div style=\"width: 50%;text-align: right;\">
				<h2 style=\"color: #181E29; font-size: 18px;font-weight: bold; line-height: 36px;text-transform: uppercase;\">Brilliant Study Centre, Pala.</h2>
				<p style=\"color: #181E29;font-size: 12px;line-height: 18px;font-weight: normal; margin-bottom: 5px;text-transform: uppercase;\">Mutholy, Puliyannoor PO, 686-573.</p>
				<p style=\"color: #181E29;font-size: 12px;line-height: 18px;font-weight: normal; margin-bottom: 5px;text-transform: uppercase;\">Phone: 04822 206 100</p>
				<p style=\"color: #181E29;font-size: 12px;line-height: 18px;font-weight: normal; margin-bottom: 5px;text-transform: uppercase;\">Email: admissions@brilliantpala.org</p>
			</div>
			
		
		</div>
			
			<div style=\"width: 100%;height: 3px;background: #0332AA;margin-bottom: 1rem;margin-top: .25rem\"></div>
			
		<div style=\"display: -webkit-box;display: -ms-flexbox;display: flex;-ms-flex-wrap: wrap;flex-wrap: wrap; margin-right: -15px;margin-left: -15px;margin-bottom: 1rem;\">
			
			<div style=\"width: 33.33333%;\">
			
				<p style=\"color: #181E29;font-size: 12px;line-height: 18px;font-weight: normal; margin-bottom: 5px;text-transform: uppercase;\">Student Id: <strong>".$userdetails['stuid']."</strong></p>
				<p style=\"color: #181E29;font-size: 12px;line-height: 18px;font-weight: normal; margin-bottom: 5px;text-transform: uppercase;margin-bottom: 0;\">Student: <strong>".strtoupper($userdetails['pname'])."</strong></p>
								
			</div>
			<div style=\"width: 33.33333%;text-align: left;\">
				
				<p style=\"color: #181E29;font-size: 12px;line-height: 18px;font-weight: normal; margin-bottom: 5px;text-transform: uppercase;\">Date: <strong>".date("d-m-Y")."</strong></p>
				<p style=\"color: #181E29;font-size: 12px;line-height: 18px;font-weight: normal; margin-bottom: 5px;text-transform: uppercase;margin-bottom: 0;\">Date Range: <strong>".date("d-m-Y",strtotime($sdate))." - ".date("d-m-Y",strtotime($edate))."</strong></p>
				
			</div>
			
		</div>	
		
		
		 <div style=\"display: -webkit-box;display: -ms-flexbox;display: flex;-ms-flex-wrap: wrap;flex-wrap: wrap; margin-right: -15px;margin-left: -15px;margin: 1rem 0;\">
			   
			   	  <div style=\"width: 100%;\">
			   		<h1 style=\"font-size: 28px;color: #181E29;font-weight: bold;text-transform: uppercase;text-align: center;\">Report Card</h1>
				  </div>
			   
			   </div>

			   <div style=\"margin-bottom: 1.5rem\"></div>
			   
					".$examtable."             
                       
            <div style=\"display: -webkit-box;display: -ms-flexbox;display: flex;-ms-flex-wrap: wrap;flex-wrap: wrap; margin-right: -15px;margin-left: -15px;display: -webkit-box!important;display: -ms-flexbox!important; display: flex!important;-webkit-box-align: end!important;-ms-flex-align: end!important; align-items: flex-end!important;margin-bottom: 0;margin-top: 1.5rem\">
			
				<div style=\"width: 50%;\"></div>
				<div style=\"width: 50%;text-align: right;\">

					<h4 style=\"font-size: 12px;font-weight: bold;color: #181E29;line-height: 20px;letter-spacing: 0.5px;text-transform: uppercase;margin-top: 3rem;\">Teacher</h4>

				</div>

			</div>

            
			</div>
			
		</div>
		
	</div>
<body></html>";
				
				
                      $this->SendEmailConfiguration($emailid,$subject,$body,"");
						
			
					
				}
					
			
		
	}
        
         public function SendHallticket($ide,$coursename){
		
			$query1 = $this-> db -> query("select studentid from bscp_courserequest where ide='".$ide."'");
                        $row1 = $query1->result_array();
                        if($row1){
				
                            $userid =$row1[0]['studentid'];
                           
				$this->load->model('login_model','',TRUE);
				$userdetails = $this->login_model->GetUserDetails($userid);

				if($userdetails['name']!=""){

					$mobile = $userdetails['mobile'];
					$emailid = $userdetails['emailid'];
                                        $pname = $userdetails['pname'];
					
                                        $subject = "Your screening test hall ticket from brilliant study centre";

                                        $body = "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.=w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\"><html><head><meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\"></head><body style=\"background:#fff; padding:20px;font-family: Segoe UI;\">

                                        <div style=\"background:#F6F7FA;width:600px;margin:auto;padding:1rem 0 3rem;\"> 

                                                <img src=\"https://admissions.brilliantpala.org/css/img/brilliantpala.png\" alt=\"Brilliant Study Centre\" style=\"padding:1rem 0 2rem;display:block;margin:auto\" width=\"auto\">

                                                <table style=\"background:#fff;border:0px solid #E8E8E8; border-radius:0px; border-collapse:collapse; overflow:hidden;padding:20px;margin:0 auto; font-size: 15px; width:460px\"><tbody>

                                                <tr><td style=\"text-align:center; line-height:1.4em; padding:10px 20px;\">

                                                <p style=\"font-size: 24px;font-weight:bold; line-height:36px; margin:10px 0;color: #181E29;\">Hall Ticket Issued</p>

                                                </td></tr>

                                                <tr><td style=\"font-size: 14px;line-height: 20px;text-align:left;padding:10px 25px;color: #364159;\">

                                                <p style=\"margin:10px 0;\">Dear ".$pname.",</p>

                                                <p style=\"margin:10px 0;\">Hall Ticket for ".$coursename." is available for download</p>

                                                <p style=\"margin:10px 0;\">Click here  https://bit.ly/3D6ii9K to  download.</p>

                                                <p style=\"margin:10px 0;\">Queries if any may please be forwarded to screeeningtest@brilliantpala.org</p>

                                                </td></tr>

                                                <tr><td style=\"text-align:center; padding:0px;color:#333;\">&nbsp;</td></tr>

                                                <tr><td style=\"font-weight: normal;font-size: 14px;line-height: 20px;text-align:left; padding:10px 20px;color: #364159;\">Thanks,<br>Brilliant Study Centre Pala</td></tr>

                                                <tr><td style=\"text-align:center; padding:0px;color:#333;\">&nbsp;</td></tr>

                                                </tbody></table>

                                                <div style=\"font-size: 12px;line-height: 18px;color: #889DC6;text-align:center;padding:2em 0;\">

                                                        <a href=\"#\" title=\"Contact Us\" style=\"color: #889DC6;vertical-align: middle;padding-right:8px\">Contact Us</a> <font size=\"5\">&#46;</font>
                                                        <a href=\"#\" title=\"Terms and Conditions\" style=\"color: #889DC6;vertical-align: middle;padding:0 8px\">Terms and Conditions</a> <font size=\"5\">&#46;</font>
                                                        <a href=\"#\" title=\"Privacy Policy\" style=\"color: #889DC6;vertical-align: middle;padding:0 8px\">Privacy Policy </a> <font size=\"5\">&#46;</font>
                                                        <a href=\"#\" title=\"Help\" style=\"color: #889DC6;vertical-align: middle;padding-left:8px\">Help</a> 

                                                </div>

                                                <div style=\"text-align:center;padding:0em 0;\">

                                                        <a href=\"https://www.facebook.com/BrilliantStudyCentrePala/\" title=\"Facebook\" style=\"vertical-align: middle;padding-right:8px\"><img src=\"https://admissions.brilliantpala.org/img/email/facebook.png\" alt=\"Facebook\" width=\"auto\"></a>
                                                        <a href=\"https://twitter.com/BrilliantPala\" title=\"Twitter\" style=\"vertical-align: middle;padding:0 8px\"><img src=\"https://admissions.brilliantpala.org/img/email/twitter.png\" alt=\"Twitter\" width=\"auto\"></a>
                                                        <a href=\"https://www.youtube.com/BrilliantOnline/\" title=\"Youtube\" style=\"vertical-align: middle;padding:0 8px\"><img src=\"https://admissions.brilliantpala.org/img/email/youtube.png\" alt=\"Youtube\" width=\"auto\"></a>
                                                        <a href=\"#\" title=\"Instagram\" style=\"vertical-align: middle;padding:0 8px\"><img src=\"https://admissions.brilliantpala.org/img/email/instagram.png\" alt=\"Instagram\" width=\"auto\"></a>
                                                        <a href=\"#\" title=\"Pinterest\" style=\"vertical-align: middle;padding-left:8px\"><img src=\"https://admissions.brilliantpala.org/img/email/pinterest.png\" alt=\"Pinterest\" width=\"auto\"></a>				 
                                                </div>

                                                </div>

                                                </body></html>";


                                                $this->SendEmailConfiguration($emailid,$subject,$body,"");

                                                $messTemplate = 'Dear%20Student,Hall%20ticket%20for%20[CoUrSeNaMe]%20is%20now%20available%20for%20download%20from%20student%20panel.Brilliant%20Pala';

                                                        $substr = $messTemplate;

                                                       
                                                        $searchFOr = '[CoUrSeNaMe]';
                                                        $replacewith = $coursename;
                                                        $substr = str_replace($searchFOr, $replacewith, $substr);


                                                        $response = $this->SendSMSConfiguration($substr,$mobile,'1707163239977036667');

                                                       // return $response;
                                    	
				}
					
			
                        }
	}
        
        public function StudentNameSearch($incomingword) {
       
            $query = $this->db->query("select id,sname,contact,email,studid from bscp_student where sname LIKE " . $this->db->escape($incomingword."%"). " or contact LIKE " . $this->db->escape($incomingword."%"). " or contact LIKE " . $this->db->escape($incomingword."%"). " or studid LIKE " . $this->db->escape($incomingword."%"). "limit 10");
            $row = $query->result_array();
            return $row;
              
    }
	
    
    public function SendEmailNotification($type,$batch,$cid,$center,$sid,$subject,$emailtext){
       
                        if($type ==="batches"){
                            $query1 = $this-> db -> query("select studentid from bscp_courserequest where batchname='".$batch."'");
                            $row1 = $query1->result_array();
                        }else if($type ==="coursewise"){
                            if($center === "All"){ $where ="";}else{ $where = " and center='".$center.'"'; }
                            $query1 = $this-> db -> query("select studentid from bscp_courserequest where courseid='".$cid."'".$where);
                            $row1 = $query1->result_array();
                        }else if($type ==="individual"){
                            $query1 = $this-> db -> query("select id as studentid from bscp_student where id='".$sid."'");
                            $row1 = $query1->result_array();
                        }
		
                        if($row1){
                            
                            foreach($row1 as $val) {
				
                            $userid =$val['studentid'];
                           
				$this->load->model('login_model','',TRUE);
				$userdetails = $this->login_model->GetUserDetails($userid);

				if($userdetails['name']!=""){

					$mobile = $userdetails['mobile'];
					$emailid = $userdetails['emailid'];
                                        $pname = $userdetails['pname'];
					
                                     
                                        $body = "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.=w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\"><html><head><meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\"></head><body style=\"background:#fff; padding:20px;font-family: Segoe UI;\">

                                        <div style=\"background:#F6F7FA;width:600px;margin:auto;padding:1rem 0 3rem;\"> 

                                                <img src=\"https://admissions.brilliantpala.org/css/img/brilliantpala.png\" alt=\"Brilliant Study Centre\" style=\"padding:1rem 0 2rem;display:block;margin:auto\" width=\"auto\">

                                                <table style=\"background:#fff;border:0px solid #E8E8E8; border-radius:0px; border-collapse:collapse; overflow:hidden;padding:20px;margin:0 auto; font-size: 15px; width:460px\"><tbody>

                                                <tr><td style=\"text-align:center; line-height:1.4em; padding:10px 20px;\">

                                                <p style=\"font-size: 24px;font-weight:bold; line-height:36px; margin:10px 0;color: #181E29;\">Notification</p>

                                                </td></tr>

                                                <tr><td style=\"font-size: 14px;line-height: 20px;text-align:left;padding:10px 25px;color: #364159;\">

                                                <p style=\"margin:10px 0;\">Dear ".$pname.",</p>

                                                <p style=\"margin:10px 0;\">".$emailtext."</p>

                                                </td></tr>

                                                <tr><td style=\"text-align:center; padding:0px;color:#333;\">&nbsp;</td></tr>

                                                <tr><td style=\"font-weight: normal;font-size: 14px;line-height: 20px;text-align:left; padding:10px 20px;color: #364159;\">Thanks,<br>Brilliant Study Centre Pala</td></tr>

                                                <tr><td style=\"text-align:center; padding:0px;color:#333;\">&nbsp;</td></tr>

                                                </tbody></table>

                                                <div style=\"font-size: 12px;line-height: 18px;color: #889DC6;text-align:center;padding:2em 0;\">

                                                        <a href=\"#\" title=\"Contact Us\" style=\"color: #889DC6;vertical-align: middle;padding-right:8px\">Contact Us</a> <font size=\"5\">&#46;</font>
                                                        <a href=\"#\" title=\"Terms and Conditions\" style=\"color: #889DC6;vertical-align: middle;padding:0 8px\">Terms and Conditions</a> <font size=\"5\">&#46;</font>
                                                        <a href=\"#\" title=\"Privacy Policy\" style=\"color: #889DC6;vertical-align: middle;padding:0 8px\">Privacy Policy </a> <font size=\"5\">&#46;</font>
                                                        <a href=\"#\" title=\"Help\" style=\"color: #889DC6;vertical-align: middle;padding-left:8px\">Help</a> 

                                                </div>

                                                <div style=\"text-align:center;padding:0em 0;\">

                                                        <a href=\"https://www.facebook.com/BrilliantStudyCentrePala/\" title=\"Facebook\" style=\"vertical-align: middle;padding-right:8px\"><img src=\"https://admissions.brilliantpala.org/img/email/facebook.png\" alt=\"Facebook\" width=\"auto\"></a>
                                                        <a href=\"https://twitter.com/BrilliantPala\" title=\"Twitter\" style=\"vertical-align: middle;padding:0 8px\"><img src=\"https://admissions.brilliantpala.org/img/email/twitter.png\" alt=\"Twitter\" width=\"auto\"></a>
                                                        <a href=\"https://www.youtube.com/BrilliantOnline/\" title=\"Youtube\" style=\"vertical-align: middle;padding:0 8px\"><img src=\"https://admissions.brilliantpala.org/img/email/youtube.png\" alt=\"Youtube\" width=\"auto\"></a>
                                                        <a href=\"#\" title=\"Instagram\" style=\"vertical-align: middle;padding:0 8px\"><img src=\"https://admissions.brilliantpala.org/img/email/instagram.png\" alt=\"Instagram\" width=\"auto\"></a>
                                                        <a href=\"#\" title=\"Pinterest\" style=\"vertical-align: middle;padding-left:8px\"><img src=\"https://admissions.brilliantpala.org/img/email/pinterest.png\" alt=\"Pinterest\" width=\"auto\"></a>				 
                                                </div>

                                                </div>

                                                </body></html>";


                                                $this->SendEmailConfiguration($emailid,$subject,$body,"");
					
									$id = uniqid();
									$created_at = date('Y-m-d H:i:s');		
									$query2 = $this-> db -> query("INSERT INTO `bscp_notificationcenter`(`id`, `studentid`, `method`, `type`, `templateid`, `subject`, `message`, `created_at`) VALUES ('".$id."','".$userid."','email','".$type."','','".$subject."','".$emailtext."','".$created_at."')");
				}
					
                            }
                        }
                        
                   
	}
        
        public function GetTemplates(){
        
		   $roleaccess = $this->config->item('roleaccess');
		   
    	   $this->datatables->select('created_at,id,templateid,name,message,active') 
           
            ->edit_column('name', '<span class="name">$1</a>', 'name')
            ->edit_column('templateid', '<span class="templateid">$1</a>', 'templateid')
            ->edit_column('message', '<span class="message">$1</a>', 'message')
            ->edit_column('active', '$1', 'check_smstemplateactive(id,active,"'.$roleaccess['SMS Templates'][1].'")')
            ->edit_column('id', '$1', 'check_smstemplateeditdel(id,"'.$roleaccess['SMS Templates'][1].'","'.$roleaccess['SMS Templates'][2].'")')
            ->edit_column('created_at', '<span class="sno">$1</a>', 'created_at')              
            ->from('bscp_smstemplate');
            
            $table =  $this->datatables->generate();
            return $table;
    
    }
    
     public function AddTemplate($qData){
		
		
        $this->db->insert('bscp_smstemplate', $qData);
        return $this->db->insert_id();	
		
    }
    
    public function EditTemplate($ide) {
        
        $arr['name']= "";  $arr['templateid']= "";$arr['message']= "";
        
        $query1 = $this-> db -> query('select id,name,templateid,message from bscp_smstemplate where id="'.$ide.'"');
	$row = $query1->result_array();
        if ($query1 ->num_rows()) {
            
            $arr['name']=$row[0]['name'];
            $arr['templateid']=$row[0]['templateid'];
            $arr['message']=$row[0]['message'];
            $arr['id']=$row[0]['id'];
            
        }     
       
        return $arr;
        
    }
    
    public function UpdateTemplate($id,$tname,$tid,$message){
        
        $query1 = $this-> db -> query('update `bscp_smstemplate` set name="'.$tname.'",templateid="'.$tid.'",message="'.$message.'" where id="'.$id.'"');
        
         $response = array(
                'status' => 'success',
                'message' => "Template Updated Successfully."
            );

          return $response;
        
    }
    
     public function DelMessage($ide){
        
        $query1 = $this-> db -> query('delete from `bscp_smstemplate` where id="'.$ide.'"');
        if($query1) {
            
            $result = array(0 => "success");
        } else {
            $result = array(0 => "fail");
        }
        
        return $result; 
        
        
    }
    
    public function GetAllTemplates($inp){
       
        $query2 = $this-> db -> query('select id,name from bscp_smstemplate where active="a"');
	$row = $query2->result_array();
        
        $retHTML = "";
        $selected="";
        $inpArray =explode("|",$inp);
        if ($row) {
            
                for($i=0 ; $i < count($row);$i++) {
                    if(in_array($row[$i]["name"], $inpArray)) {
                        $selected = 'selected=selected';
                    }
                    
                    $retHTML .= "<option value='".$row[$i]["id"]."'" .$selected.">".$row[$i]["name"]."</option>";
                   $selected = "";
                }
                
        }
        return $retHTML;       
   }
   
   public function GetSelectedTemplates($ide){
       
        $query2 = $this-> db -> query('select templateid,message from bscp_smstemplate where active="a" and id="'.$ide.'"');
	$row = $query2->result_array();
        
        $retHTML = Array();
        if ($row) {
            
           $retHTML[0] = $row[0]['message'];
           $retHTML[1] = $row[0]['templateid'];
                
        }
        return $retHTML;       
   }
   
    public function SendSMSNotification($type,$batch,$cid,$center,$sid,$smsdetails){
       
                        $smstext = $smsdetails[0];$tid=$smsdetails[1];
                        if($type ==="batches"){
                            $query1 = $this-> db -> query("select studentid,coursename from bscp_courserequest as cr LEFT JOIN admin_course as a ON a.ide=cr.courseid  where cr.batchname='".$batch."'");
                            $row1 = $query1->result_array();
                        }else if($type ==="coursewise"){
                            if($center === "All"){ $where ="";}else{ $where = " and center='".$center."'"; }
                            $query1 = $this-> db -> query("select studentid,coursename from bscp_courserequest as cr LEFT JOIN admin_course as a ON a.ide=cr.courseid where cr.courseid='".$cid."'".$where);
                            $row1 = $query1->result_array();
                        }else if($type ==="individual"){
                            $query1 = $this-> db -> query("select id as studentid from bscp_student where id='".$sid."'");
                            $row1 = $query1->result_array();
                        }
		
                        if($row1){
                            
                            foreach($row1 as $val) {
                                $userid =$val['studentid'];
                                $coursename =(array_key_exists("coursename", $val))?$val['coursename']:"";
                                $this->load->model('login_model','',TRUE);
				$userdetails = $this->login_model->GetUserDetails($userid);

				if($userdetails['name']!=""){

					$mobile = $userdetails['mobile'];
                                         $pname = $userdetails['pname'];
					
                                                        $substr = $smstext;
                                                        
                                                        $searchFOr = '[studentname]';
                                                        $replacewith = $pname;
                                                        $substr = str_replace($searchFOr, $replacewith, $substr);

                                                       
                                                        $searchFOr = '[coursename]';
                                                        $replacewith = $coursename;
                                                        $substr = str_replace($searchFOr, $replacewith, $substr);


                                                       $response = $this->SendSMSConfiguration($substr,$mobile,$tid);
					
									$id = uniqid();
									$created_at = date('Y-m-d H:i:s');		
									$query2 = $this-> db -> query("INSERT INTO `bscp_notificationcenter`(`id`, `studentid`, `method`, `type`, `templateid`, `subject`, `message`, `created_at`) VALUES ('".$id."','".$userid."','sms','".$type."','".$tid."','','".$substr."','".$created_at."')");
                                }
                                
                            }
                        }
    }
    
    public function ChangeTemplateStatus($ide,$status){
        
        $query1 = $this-> db -> query('update `bscp_smstemplate` set active="'.$status.'" where id="'.$ide.'"');
        if($query1) {
            $result = array(0 => "success");
        } else {
            $result = array(0 => "fail");
        }
        
        return $result; 
        
        
    }
	
	public function GetStudentNotifications($userid){
        
		$arr = array();
		
    	$query = $this-> db -> query('select `id`, `studentid`, `method`, `type`, `templateid`, `subject`, `message`, `created_at` from bscp_notificationcenter where studentid="'.$userid.'" order by created_at desc');
		$row = $query->result_array();
        
        if ($query->num_rows()>0) {
			
			for($i = 0;$i<count($row);$i++){
				
				$arr[$i]['id'] = $row[$i]['id'];
           		$arr[$i]['studentid'] = $row[$i]['studentid'];
           		$arr[$i]['method'] = $row[$i]['method'];
           		$arr[$i]['type'] = $row[$i]['type'];
           		$arr[$i]['templateid'] = $row[$i]['templateid'];
           		$arr[$i]['subject'] = $row[$i]['subject'];
           		$arr[$i]['message'] = $row[$i]['message'];
           		$arr[$i]['created_at'] = $row[$i]['created_at'];
				
			}           
                
        }
		
        return $arr;   
    
    }
	
	public function GetStudentSingleNotifications($userid,$nid){
        
		$arr = array();
		
    	$query = $this-> db -> query('select `id`, `studentid`, `method`, `type`, `templateid`, `subject`, `message`, `created_at` from bscp_notificationcenter where studentid="'.$userid.'" and id="'.$nid.'" order by created_at desc');
		$row = $query->result_array();
        
        if ($query->num_rows()>0) {
			
			for($i = 0;$i<count($row);$i++){
				
				$arr['id'] = $row[$i]['id'];
           		$arr['studentid'] = $row[$i]['studentid'];
           		$arr['method'] = $row[$i]['method'];
           		$arr['type'] = $row[$i]['type'];
           		$arr['templateid'] = $row[$i]['templateid'];
           		$arr['subject'] = $row[$i]['subject'];
           		$arr['message'] = $row[$i]['message'];
           		$arr['created_at'] = $row[$i]['created_at'];
				
			}           
                
        }
		
        return $arr;   
    
    }
    
        public function IDCardConfirmation($userid) {
            
            $response ="";
            $this->load->model('login_model','',TRUE);
            $userdetails = $this->login_model->GetUserDetails($userid);
		
            if($userdetails['name']!=""){

                    $studentname = $userdetails['pname'];    
                    $emailid = $userdetails['emailid'];
                    $mobile = $userdetails['mobile'];
                    
                    		
			$subject = "Ready to collect your brilliant study centre ID Card";
			
			$body = "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.=w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\"><html><head><meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\"></head><body style=\"background:#fff; padding:20px;font-family: Segoe UI;\">
	
			<div style=\"background:#F6F7FA;width:600px;margin:auto;padding:1rem 0 3rem;\"> 
		
				<img src=\"https://admissions.brilliantpala.org/css/img/brilliantpala.png\" alt=\"Brilliant Study Centre\" style=\"padding:1rem 0 2rem;display:block;margin:auto\" width=\"auto\">
		
				<table style=\"background:#fff;border:0px solid #E8E8E8; border-radius:0px; border-collapse:collapse; overflow:hidden;padding:20px;margin:0 auto; font-size: 15px; width:460px\"><tbody>
				
	  			<tr><td style=\"text-align:center; width:auto; color:#333; padding:20px;\"><img src=\"https://admissions.brilliantpala.org/img/email/courseregister.jpg\" alt=\"ID Card Collection\" width=\"auto\"></td></tr>
				
	  			<tr><td style=\"text-align:center; line-height:1.4em; padding:10px 20px;\">
				
				<p style=\"font-size: 24px;font-weight:bold; line-height:36px; margin:10px 0;color: #181E29;\">ID Card Collection</p>
								
				</td></tr>
				
				<tr><td style=\"font-size: 14px;line-height: 20px;text-align:left;padding:10px 25px;color: #364159;\">
				
				<p style=\"margin:10px 0;\">Dear ".$studentname.",</p>
				
				<p style=\"margin:10px 0;\">Your ID Card is ready and you can collect it from your class teacher</p>
																				
				<p style=\"margin:10px 0;\">For more details do contact us for all your admission related queries directly at admissions@brilliantpala.org | <a href=\"tel:04822 206100\">04822 206100</a> | <a href=\"tel:04822 206800\">04822 206800</a>.</p>
				
				</td></tr>
				
				<tr><td style=\"text-align:center; padding:0px;color:#333;\">&nbsp;</td></tr>
	  			
	  			<tr><td style=\"font-weight: normal;font-size: 14px;line-height: 20px;text-align:left; padding:10px 20px;color: #364159;\">Thanks,<br>Brilliant Study Centre Pala</td></tr>
				
				<tr><td style=\"text-align:center; padding:0px;color:#333;\">&nbsp;</td></tr>
								
	  			</tbody></table>
				
				<div style=\"font-size: 12px;line-height: 18px;color: #889DC6;text-align:center;padding:2em 0;\">
				
					<a href=\"#\" title=\"Contact Us\" style=\"color: #889DC6;vertical-align: middle;padding-right:8px\">Contact Us</a> <font size=\"5\">&#46;</font>
					<a href=\"#\" title=\"Terms and Conditions\" style=\"color: #889DC6;vertical-align: middle;padding:0 8px\">Terms and Conditions</a> <font size=\"5\">&#46;</font>
					<a href=\"#\" title=\"Privacy Policy\" style=\"color: #889DC6;vertical-align: middle;padding:0 8px\">Privacy Policy </a> <font size=\"5\">&#46;</font>
					<a href=\"#\" title=\"Help\" style=\"color: #889DC6;vertical-align: middle;padding-left:8px\">Help</a> 
				
				</div>
				
				<div style=\"text-align:center;padding:0em 0;\">
				
					<a href=\"https://www.facebook.com/BrilliantStudyCentrePala/\" title=\"Facebook\" style=\"vertical-align: middle;padding-right:8px\"><img src=\"https://admissions.brilliantpala.org/img/email/facebook.png\" alt=\"Facebook\" width=\"auto\"></a>
					<a href=\"https://twitter.com/BrilliantPala\" title=\"Twitter\" style=\"vertical-align: middle;padding:0 8px\"><img src=\"https://admissions.brilliantpala.org/img/email/twitter.png\" alt=\"Twitter\" width=\"auto\"></a>
					<a href=\"https://www.youtube.com/BrilliantOnline/\" title=\"Youtube\" style=\"vertical-align: middle;padding:0 8px\"><img src=\"https://admissions.brilliantpala.org/img/email/youtube.png\" alt=\"Youtube\" width=\"auto\"></a>
					<a href=\"#\" title=\"Instagram\" style=\"vertical-align: middle;padding:0 8px\"><img src=\"https://admissions.brilliantpala.org/img/email/instagram.png\" alt=\"Instagram\" width=\"auto\"></a>
					<a href=\"#\" title=\"Pinterest\" style=\"vertical-align: middle;padding-left:8px\"><img src=\"https://admissions.brilliantpala.org/img/email/pinterest.png\" alt=\"Pinterest\" width=\"auto\"></a>				 
				</div>
				
				</div>
				
				</body></html>";
				
				
                 $this->SendEmailConfiguration($emailid,$subject,$body,"");
            
                    $messTemplate = 'Dear%20[StUdEnTnAmE],Your%20ID%20Card%20is%20ready%20and%20you%20can%20collect%20it%20from%20your%20class%20teacher.%20Thanks,%20Brilliant%20Pala';

                    $substr = $messTemplate;

                    $searchFOr = '[StUdEnTnAmE]';
                    $replacewith = $studentname;
                    $substr = str_replace($searchFOr, $replacewith, $substr);

                    $response = $this->SendSMSConfiguration($substr,$mobile,'1707163905110156667');
            }

            return $response;
            
        }
	
	function SendSMSConfiguration($substr,$mobile,$templateid=""){
		
		
		if($templateid!="") $templateid = "&templateid=".$templateid;
		
		$messTemplate = 'token=8ee49eb9f9e3477aa36d209657024cab&sender=BRLINT&number=NuMbER&route=2&type=1'.$templateid.'&sms='.$substr;
		
		$substr = $messTemplate;
		
		$searchFOr = 'NuMbER';
		$replacewith = $mobile;
		$substr = str_replace($searchFOr, $replacewith, $substr);
		
		$url = "http://textu.in/httpapi/httpapi?";

		$ch = curl_init($url);


		curl_setopt($ch, CURLOPT_POST, 1);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $substr);
		curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
		curl_setopt($ch, CURLOPT_HEADER, 0);  // DO NOT RETURN HTTP HEADERS 
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);  // RETURN THE CONTENTS OF THE CALL

		$return_val = curl_exec($ch);
		$err = curl_error($ch);

		curl_close($ch);

		if ($err) {
		   return "failed";
		} else {
			return "success";
		}
		
	}
	
	function SendEmailConfiguration($email,$subject,$body,$attach){
            
		$config = $this->config->item('amazonses');

		$this->load->library('email', $config);
		$this->email->set_newline("\r\n");

		$this->email->from('admissions@brilliantpala.org', 'Admissions Brilliant');
		$this->email->to($email);	 
		$this->email->subject($subject);		
		$this->email->message($body);

		if($attach != "") {
			$this->email->attach($attach);
		}
		
		if($this->email->send())
		{
			echo '';
		}else{
			//echo $this->email->print_debugger();
		}
            
 }
	
}

?>
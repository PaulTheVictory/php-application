<?php

Class Payment_Model extends CI_Model {
    
     public function __construct() {
        
       $this->load->library('Datatables');
       $this->load->helper('My_datatable_helper');
  
    }

    public function GetAllPaymentItems($ide) {
        
        $arr = Array();
		
		$arr['list'] = "";
		
                //$this->datatables->set_database("default");
	    $this->datatables->select('id,sno,description,sac,amount,discount,tax,centers,total,taxable') 
                    ->edit_column('sno', '<span class="sno">$1</span>', '')
                     ->edit_column('description', '<select class="desc" ><option>$1</option></select><select style="display:none" non-taxable="$3" taxable="$3" attr-centers="$2" class="taxable"><option value="0" >Non-Taxable</option><option value="1" >Taxable</option></select>', 'description,centers,taxable')
                     ->edit_column('sac', '<input type="text" class="sac" value="$1">', 'sac')
                     ->edit_column('amount', '<input type="text"  class="amount" value="$1">', 'amount')
                     ->edit_column('discount', '<input type="text"  class="discount" value="$1">', 'discount')
                     ->edit_column('tax', '<input type="text"  class="tax" value="$1">', 'tax')
                    ->edit_column('total', '<span style="color:#536485"  class="total" >$1</span><input type="hidden"  name="pid" class="pid" value="$2">', 'total,id')
                    ->from('admin_group')->where('courseid',$ide) ;
                

                $table =  $this->datatables->generate();
                
              //  $table = str_replace('non-taxable="0"', 'selected', $table);
             //   $table = str_replace('taxable="1"', 'selected="selected"', $table);
             
		
		return $table;
        
    }
    
    public function GetSelectedPaymentItems($ide) {
        
        $arr = Array();
		
		$arr['list'] = "";
		
		$roleaccess = $this->config->item('roleaccess');
		
                //$this->datatables->set_database("default");
	    $this->datatables->select('sno,description,active,sac,amount,discount,tax,kf,cov,centers,total') 
                     ->edit_column('description', '<span class="description" attr-centers="$2">$1</span><span></span>', 'description,centers')
                    ->edit_column('active', '$1', 'check_courseeditfees(active,"'.$roleaccess['Course Edit Fees'][3].'")')                    
                     ->edit_column('sac', '<span>$1</span>', 'sac')
                     ->edit_column('amount', '<span>$1</span>', 'amount')
                     ->edit_column('discount', '<span>$1</span>', 'discount')
                     ->edit_column('tax', '<span>$1</span>', 'tax')
                    ->edit_column('kf', '<span>$1</span>', 'kf')
                    ->edit_column('cov', '<span>$1</span>', 'cov')
                    ->edit_column('total', '<span style="color: #536485;" class="total">$1</span>', 'total')
                    ->from('admin_group')->where('courseid',$ide) ;
                
                $table =  $this->datatables->generate();
		
		return $table;
        
    }
    
     public function AddPayment($pdata,$ptype,$cid)
    {
         
         $row = explode("$", $pdata);
         for($i = 0 ; $i < count($row);$i++){
             
             if($row[$i] === "") {continue;}
             $col = explode("|", $row[$i]);if($col[1] === '') { continue;}
             $ide = (html_escape($col[9]) === "")?uniqid():(html_escape($col[9]));
              $qData = array(
                'id' => $ide,
                'courseid' => $cid,
                'centers' => html_escape($col[0]),
                'description' => html_escape($col[1]),
                'sac' => html_escape($col[2]),
                'amount' => html_escape($col[3]),
                'discount' => html_escape($col[4]),
                'tax' => html_escape($col[5]),
                  'kf' => html_escape($col[6]),
                  'cov' => html_escape($col[7]),
                'total' => html_escape($col[8]),
                  'taxable' => html_escape($col[10]),
                  'split' => html_escape($col[11]),
                'created_at' => date('Y-m-d H:i:s')
            );
            
             
             if(html_escape($col[9]) !== "") {
                  $this->db->update('admin_group', $qData, array('id' => $qData['id']));
             } else {
                 
                  $this->db->insert('admin_group', $qData);
             }
             
             
         }
         
         
         return true;
       
    }
    
    public function GetCenterWisePaymentItems($ide,$center,$studid,$rid) {
        
        
        $query1 = $this-> db -> query('select id from bscp_student_payments  where  requestid="'.$rid.'"');
	$row = $query1->result_array();
        if ($row) {
            
            $this->datatables->select('bscp_student_payments.desc_order as desc_order,bscp_student_payments.givenby as givenby,bscp_student_payments.reason as reason,bscp_student_payments.remarks as remarks,bscp_student_payments.id as id,bscp_student_payments.created_at as created_at,bscp_student_payments.description as description,bscp_student_payments.sac as sac,'
                    . 'bscp_student_payments.amount as amount,bscp_student_payments.discount as discount,bscp_student_payments.tax as tax,bscp_student_payments.kf as kf,bscp_student_payments.cov as cov,'
                    . 'bscp_student_payments.centers as centers,bscp_student_payments.total as total,bscp_student_payments.active as active,bscp_student_payments.taxable as taxable,bscp_student_payments.split as split,'
                    . ',sum(bscp_feepayments.kfadjust) as kfadjust,sum(bscp_feepayments.paymentamount) as paid,round(sum(bscp_feepayments.total - bscp_feepayments.paymentamount)/(1+(bscp_feepayments.tax/100))) as due') 
                    ->edit_column('desc_order', '$1', 'desc_order')
                     ->edit_column('description', '<span attr-id="$5" attr-split = "$4" attr-occur = "1" class="desc" attr-centers="$2" attr-taxable="$3">$1</span>', 'description,centers,taxable,split,id')
                     ->edit_column('centers', '<p><input type="checkbox" name="check-1" value="$1" class="lcs_check" autocomplete="off" /></p>', 'active')                    
                     ->edit_column('sac', '<span class="sac">$1</span>', 'sac')
                     ->edit_column('amount', '<span class="amount">$1</span>', 'amount')
                     ->edit_column('discount', '<span cdiscount="$1" attr-given="$2" attr-reason="$3" attr-remarks="$4" class="discount">$1</span><p style="font-size:12px;margin:0px;width:150px;display:none;text-align:left">Given by : $2</p><p style="font-size:12px;margin:0px;width:150px;display:none;text-align:left">Reason : $3</p><p class="remarks" style="font-size:12px;margin:0px;width:150px;display:none;text-align:left">Remarks : $4</p>', 'discount,givenby,reason,remarks')
                     ->edit_column('tax', '<span class="tax">$1</span>', 'tax')
                    ->edit_column('kf', '<span class="kf">$1</span>', 'kf')
                    ->edit_column('cov', '<span class="cov">$1</span>', 'cov')
                    ->edit_column('total', '<span style="color: #536485;" class="total">$1</span>', 'total')
                    ->edit_column('paid', '<span style="color: #536485" attr-kfadjust="$2" class="paid">$1</span>', 'paid,kfadjust')
                    ->edit_column('due', '<span style="color: #536485" class="due">$1</span>', 'due')
                    ->from('bscp_student_payments')->where('bscp_student_payments.requestid',$rid)->group_by('description')
                    ->join('bscp_feepayments', 'bscp_feepayments.stupayid=bscp_student_payments.id', 'left');
                
                $table =  $this->datatables->generate();
            
        } else {
        
        $this->datatables->select('created_at as desc_order,description,sac,amount,discount,tax,kf,cov,centers,total,taxable,split,centers as paid,(amount-discount) as due') 
                     ->edit_column('description', '<span attr-id="" attr-split = "$4" attr-occur = "1" class="desc" attr-centers="$2" attr-taxable="$3">$1</span>', 'description,centers,taxable,split')
                     ->edit_column('centers', '<p><input type="checkbox" name="check-1" value="1" class="lcs_check" autocomplete="off" /></p>', '')                    
                     ->edit_column('sac', '<span class="sac">$1</span>', 'sac')
                     ->edit_column('amount', '<span class="amount">$1</span>', 'amount')
                     ->edit_column('discount', '<span class="discount">$1</span>', 'discount')
                     ->edit_column('tax', '<span class="tax">$1</span>', 'tax')                 
                    ->edit_column('kf', '<span class="kf">$1</span>', 'kf')
                    ->edit_column('cov', '<span class="cov">$1</span>', 'cov')
                    ->edit_column('total', '<span style="color: #536485;" class="total">$1</span>', 'total')
                ->edit_column('desc_order', '<p class="sno" attr-id="">1</p>', '')
                ->edit_column('paid', '<span style="color: #536485" class="paid">0</span>', '0')
                ->edit_column('due', '<span style="color: #536485" class="due">$1</span>', 'due')
                    ->from('admin_group')->where('courseid',$ide)->where('centers',$center) ;
                
                $table =  $this->datatables->generate();
		
		
        }
        
        return $table;
        
    }
    
    
     public function AddStudentPayment($pdata,$cid,$sid,$rid)
    {
        date_default_timezone_set("Asia/Calcutta");
        $total = $activetotal = 0;$paycheck = 0;
        $row = explode("$", $pdata);
        $descArray['Registration Charges'] = 1;$descArray['Caution Deposit'] = 2;
        $descArray['Screening Test Registration Charges'] = 3;$descArray['Tuition Fee'] = 4;
        $descArray['Tuition Fee - 1'] = 5;$descArray['Tuition Fee - 2'] = 6;
    
         for($i = 0 ; $i < count($row);$i++){
             
             if($row[$i] === "") {continue;}
             $col = explode("|", $row[$i]);if($col[1] === '') { continue;}
             $ide = (html_escape($col[9]) === "")?uniqid():(html_escape($col[9]));
             if(intVal($col[6]) !== intVal($col[13])) { $paycheck = 1;} else{ $paycheck = 0;}
             
             $decs_Order = (array_key_exists($col[1], $descArray))?$descArray[$col[1]]:1;
             $col[14] = ($col[14] === 'null')?"":$col[14];
             $col[15] = ($col[15] === 'null')?"":$col[15];
             $col[16] = ($col[16] === 'null')?"":$col[16];
             
             $total = 0;$totalwithoutkf = html_escape($col[6]);
             $amount= floatval($col[3]);$discount= floatval($col[4]);
             $tax= floatval($col[5]);$kf= floatval($col[10]);
             $totax = floatval($tax)+floatval($kf);
             $total = floatval(($amount - $discount)*(1+$totax/100));
             $total = round($total);
             //withoutkf - 24789
             //withkf = 25000
             
              $qData = array(
                'id' => $ide,
                'courseid' => $cid,
                'requestid' => $rid,
                'centers' => html_escape($col[0]),
                'description' => html_escape($col[1]),
                'sac' => html_escape($col[2]),
                'amount' => html_escape($col[3]),
                'discount' => html_escape($col[4]),
                'givenby' => html_escape($col[14]),
                'reason' => html_escape($col[15]),
                'remarks' => html_escape($col[16]),
                'tax' => html_escape($col[5]),
                'total' => $total,
                'active' => html_escape($col[7]),
                'taxable' => html_escape($col[8]),
                'kf' => html_escape($col[10]),
                'cov' => html_escape($col[11]),
                'split' => html_escape($col[12]),
                'studentid' => html_escape($sid),
                'created_at' => date('Y-m-d H:i:s'),
                  'desc_order ' => $decs_Order
            );
            
             
             if(html_escape($col[9]) !== "") {
                  $this->db->update('bscp_student_payments', $qData, array('id' => $qData['id']));
             } else {
                 
                  $this->db->insert('bscp_student_payments', $qData);
             }
             
             $ret = $this->GetCourseRequestStatus($rid);
             if(($ret === "y")) {
                if($qData['active']==='0'){
                
                    $this-> db -> query("delete from `bscp_feepayments` where courseid = '".$cid."' AND stupayid = '".$qData['id']."' AND studentid = '".$sid."' AND paymentstatus = ''");
                                  
                } else if($this->CheckPendingFees($qData['id'],$cid,$sid)){
                 
                    $this->UpdateFeesPayments($qData,$cid,$sid,$col[13],$totalwithoutkf);
                 
                } else if(!$this->CheckFeesExists($qData['id'],$cid,$sid,$paycheck)){
                 
                    $this->InsertFeesPayments($qData,$cid,$sid,$col[13],$rid,$totalwithoutkf);
                }
            }
            
             $total = floatval($total) + floatval(html_escape($col[6]));
			 
			 
			 // Check Partial Payment
			 
			 if($qData['active']==='1'){
				 
				 $query4 = $this-> db -> query("select total from bscp_feepayments where courseid = '".$cid."' AND stupayid = '".$qData['id']."' AND studentid = '".$sid."' AND paymentstatus = ''");
       		  	 $row4 = $query4->result_array();
			  
				  if ($query4->num_rows() > 0) {

					 $activetotal = floatval($activetotal) + floatval($row4[0]['total']);

				  }
				 
			 }
             
         }
         
          $query1 = $this-> db -> query('update `bscp_courserequest` set total="'.$total.'" where ide="'.$rid.'"');
		
		
		 // Check Partial Payment
		
		  $query3 = $this-> db -> query('select id,partialamount from bscp_partialpayments where requestid="'.$rid.'" and studentid="'.$sid.'" and courseid="'.$cid.'" and status="a"');
		  $row3 = $query3->result_array();

		  if ($query3->num_rows() > 0) {
			  			  
				  if($activetotal <= $row3[0]['partialamount']){

					  $this-> db -> query("delete from `bscp_partialpayments` where id = '".$row3[0]['id']."' AND courseid = '".$cid."' AND studentid = '".$sid."' AND status = 'a'");

				  }
				  			  
		  }
         
         
         return true;
       
    }
    
    public function CheckPendingFees($id,$cid,$sid){
        
        $status = false;
        $query = $this-> db -> query('select id from bscp_feepayments where stupayid="'.$id.'" and courseid="'.$cid.'" and studentid="'.$sid.'" and paymentstatus=""');
	$row = $query->result_array();
        if ($query->num_rows()>0) {
            $status = true;
        }
        
        return $status;
        
    }
    
    
    public function CheckFeesExists($id,$cid,$sid,$paycheck){
        
        $status = false; $whereclause = "";
        if($paycheck) { $whereclause = ' and paymentstatus=""';}
        $query = $this-> db -> query('select id from bscp_feepayments where stupayid="'.$id.'" and courseid="'.$cid.'" and studentid="'.$sid.'"'.$whereclause);
	$row = $query->result_array();
        if ($query->num_rows()>0) {
            $status = true;
        }
        
        return $status;
        
    }
    
    
    public function UpdateFeesPayments($qData,$cid,$sid,$paidpay,$totalwithoutkf){
        
        $kfadjust = 0;$paidwithoutgst=0;
        
         $query2 = $this-> db -> query('select total,kf,tax from bscp_feepayments where stupayid="'.$qData['id'].'" and courseid="'.$cid.'" and studentid="'.$sid.'" and paymentstatus="p"');
	$row = $query2->result_array();
        if ($row) {
            for($i=0 ; $i < count($row);$i++) {
                $ltotal = floatval($row[$i]['total'])/(1+(floatval($row[$i]['tax'])+floatval($row[$i]['kf']))/100);
                $paidwithoutgst = $paidwithoutgst + $ltotal;
            }
            
        }
               
           $remainamt = floatval($qData['amount']) - floatval($qData['discount']) - floatval($paidwithoutgst);
           $ramount = round($remainamt);
           $roundoff = floatval($ramount)-floatval($remainamt); 
           $roundoff = round($roundoff,2);
       
                 $tax = ($qData['tax'] !== "NA")?$qData['tax']:"0";
                   $kf  = ($qData['kf'] !== "NA")?$qData['kf']:"0";
                   $cov = ($qData['cov'] !== "NA")?$qData['cov']:"0";
                   
                   $totamount =  floatval($ramount)*(1+(floatval($tax))/100);
                   $totamount = round($totamount);
                   if($kf === "1"){
                    $kfadjust = floatval($ramount)*(0.01);
                    $kfadjust= round($kfadjust);
                   }
                 
                   $ramount = floatval($ramount) + floatval($qData['discount']);
        
                    $this-> db -> query('update `bscp_feepayments` set kfadjust="'.$kfadjust.'",paymentdate="'.date('Y-m-d H:i:s').'",created_at="'.date('Y-m-d H:i:s').'",amount="'.$ramount.'",discount="'.$qData['discount'].'",tax="'.$qData['tax'].'",kf="0",cov="'.$qData['cov'].'",roundoff="'.$roundoff.'",total="'.$totamount.'" where stupayid="'.$qData['id'].'" and courseid="'.$cid.'" and studentid="'.$sid.'" and paymentstatus=""');
        
    }
    
    public function InsertFeesPayments($qData,$cid,$sid,$paidpay,$rid,$totalwithoutkf){
       
        $challanno = "";
        
        //check existing open challan no
       $query = $this-> db -> query('select challanno from bscp_feepayments where courseid="'.$cid.'" and studentid="'.$sid.'" and paymentstatus="" group by challanno');
       $row = $query->result_array();
       if ($query->num_rows()>0) {
            $challanno = $row[0]['challanno'];
       }
       
       if($challanno === ""){
           
                $countadd = 1;
		$query0 = $this-> db -> query('select distinct challanno from bscp_feepayments where studentid="'.$sid.'"');
		$count = $query0->num_rows();
		$count = $countadd + $count;
		$count = str_pad($count, 2, '0', STR_PAD_LEFT);
		$challanno = "C".$count;
           
       }
       
       $id = uniqid(); 
       $kfadjust = 0;
          
       
       $paidwithoutgst=0;
        
         $query2 = $this-> db -> query('select total,kf,tax from bscp_feepayments where stupayid="'.$qData['id'].'" and courseid="'.$cid.'" and studentid="'.$sid.'" and paymentstatus="p"');
	$row = $query2->result_array();
        if ($row) {
            for($i=0 ; $i < count($row);$i++) {
                $ltotal = floatval($row[$i]['total'])/(1+(floatval($row[$i]['tax'])+floatval($row[$i]['kf']))/100);
                $paidwithoutgst = $paidwithoutgst + $ltotal;
            }
            
        }
               
           $remainamt = floatval($qData['amount']) - floatval($qData['discount']) - floatval($paidwithoutgst);
           $ramount = round($remainamt);
           $roundoff = floatval($ramount)-floatval($remainamt); 
           $roundoff = round($roundoff,2);
       
                 $tax = ($qData['tax'] !== "NA")?$qData['tax']:"0";
                   $kf  = ($qData['kf'] !== "NA")?$qData['kf']:"0";
                   $cov = ($qData['cov'] !== "NA")?$qData['cov']:"0";
                   
                   $totamount =  floatval($ramount)*(1+(floatval($tax))/100);
                   $totamount = round($totamount);
                   
                  $ramount = floatval($ramount) + floatval($qData['discount']);
                   
                if(($challanno !== "")&&($ramount > 0)) {   
                     $query  = $this-> db -> query('insert into bscp_feepayments (`id`,`requestid`,`stupayid`, `studentid`, `courseid`, `center`,`challanno`, `amount`,`discount`,`tax`,`kf`,`kfadjust`,`cov`,`roundoff`,`total`, `status`, `created_at`, `paymode`, `paymentamount`, `paymentmode`, `paymentstatus`, `paymentdate`,`paydescription`, `dueamt`) values ("'.$id.'","'.$rid.'","'.$qData['id'].'","'.$sid.'","'.$cid.'","'.$qData['centers'].'","'.$challanno.'","'.$ramount.'","'.$qData['discount'].'","'.$qData['tax'].'","0","'.$kfadjust.'","'.$qData['cov'].'","'.$roundoff.'","'.$totamount.'","p","'.$qData['created_at'].'","offline","0","Cash","","'.$qData['created_at'].'","",0)');
                }
    }
    
    public function GetCourseRequestStatus($rid){
        
        $status = "";
        $query2 = $this-> db -> query('select approved from bscp_courserequest where ide="'.$rid.'"');
	$row = $query2->result_array();
        if ($row) {
            $status = $row[0]['approved'];
        }
        
        return $status;
        
    }




    public function GetFeesMaster(){
        
        $retHTML['general'] = "";$retHTML['tax'] = [];$retHTML['split'] = [];
        $query2 = $this-> db -> query('select * from bscp_feesmaster');
	$row = $query2->result_array();
        if ($row) {
            
                for($i=0 ; $i < count($row);$i++) {
                        $retHTML['general'] .= "<option>".$row[$i]["description"]."</option>";
                        $retHTML['tax'][$row[$i]["description"]] = $row[$i]["tax"];
                        $retHTML['split'][$row[$i]["description"]] = $row[$i]["split"];
                    
                }
                
        }
        
        return $retHTML;
        
    }
    
    public function DeletePayItem($ide){
        
        $query1 = $this-> db -> query('delete from bscp_student_payments where id="'.$ide.'"');
        $query1 = $this-> db -> query('delete from bscp_feepayments where stupayid="'.$ide.'"');
	if($query1) {
                $result = array(0 => "success");
            } else {
                $result = array(0 => "fail");
            }
            
        return $result; 
        
    }
    
    
       public function GetChallanLists($ide,$user,$center) {
        
        $arr = Array();
		
		$arr['list'] = "";
		
                //$this->datatables->set_database("default");
	    $this->datatables->select('studentid,requestid,DATE_FORMAT(paymentdate,"%d-%m-%Y %h:%i %p") as created_at,id,stupayid,challanno,sum(total) as totalamt,sum(paymentamount) as payamt',FALSE) 
                     ->edit_column('created_at', '<p>$1</p>', 'created_at')
                    ->edit_column('challanno', '<a class="challanno" target="_blank" href="stumyprofile/downloadChallan?id=$2&challan=unpaid&userid=$3" style="color:#0332AA">$1</a>', 'challanno,requestid,studentid')
                     ->edit_column('payamt', '<p class="payamt">$1</p>', 'payamt')
                    ->edit_column('totalamt', '<p class="totalamt">$1</p>', 'totalamt')
                    ->edit_column('stupayid', '<p class="stupayid" data-id="$1"></p>', 'id')
                    ->edit_column('id', '<p class="sno" data-id="$1"></p>', 'id')
                    
                    ->from('bscp_feepayments')->where('courseid',$ide)->where('studentid',$user)->where('center',$center)->where('total <> "0"')->where('total <> "-0"')->group_by('challanno');
                
                $table =  $this->datatables->generate();
		
		return $table;
        
    }
    
    
     public function GetAddPaymentLists($challan,$ide,$user) {
        
        $arr = Array();
		
		$arr['list'] = "";
		
                //$this->datatables->set_database("default");
	    $this->datatables->select('bscp_student_payments.desc_order as desc_order,bscp_feepayments.roundoff as roundoff,bscp_feepayments.amount as amount,bscp_student_payments.description as description,bscp_student_payments.centers as centers,bscp_student_payments.split as split,'
                    . 'bscp_feepayments.total as total,bscp_feepayments.paymentamount as paid,bscp_feepayments.id as id,'
                    . 'bscp_feepayments.tax as tax,bscp_feepayments.discount as discount,bscp_feepayments.kf as kf,bscp_feepayments.cov as cov,bscp_student.studid,bscp_student.sname') 
                    ->edit_column('desc_order', '$1', 'desc_order')
                      ->edit_column('description', '<span attr-split = "$3"  class="desc" attr-centers="$2" >$1</span>', 'description,centers,split')
                     ->edit_column('amount', '<span class="amount">$1</span>', 'amount')
                     ->edit_column('discount', '<span class="discount">$1</span>', 'discount')
                     ->edit_column('tax', '<span class="tax">$1</span>', 'tax')
                    ->edit_column('kf', '<span class="kf">$1</span>', 'kf')
                    ->edit_column('cov', '<span class="cov">$1</span>', 'cov')
                    ->edit_column('total', '<span style="color: #536485;" class="total">$1</span>', 'total')
                    ->edit_column('paid', '<span style="color: #536485;" class="paid">$1</span>', 'paid')
                    ->from('bscp_feepayments')->where('challanno',$challan)->where('bscp_feepayments.courseid',$ide)->where('bscp_feepayments.studentid',$user)
                     ->join('bscp_student_payments', 'bscp_student_payments.id=bscp_feepayments.stupayid', 'left')
		 			 ->join('bscp_student', 'bscp_student.id=bscp_feepayments.studentid', 'left');
                
                $table =  $this->datatables->generate();
		
		return $table;
        
    }
	
	// Edit payment
	
	
	public function GetEditPaymentLists($challan,$ide,$user) {
        
        $arr = Array();
		
		$arr['list'] = "";
		
                //$this->datatables->set_database("default");
	    $this->datatables->select('bscp_student_payments.desc_order as desc_order,bscp_feepayments.roundoff as roundoff,bscp_feepayments.amount as amount,bscp_student_payments.description as description,bscp_student_payments.centers as centers,bscp_student_payments.split as split,'
                    . 'bscp_feepayments.total as total,bscp_feepayments.paymentamount as paid,bscp_feepayments.id as id,'
                    . 'bscp_feepayments.tax as tax,bscp_feepayments.discount as discount,bscp_feepayments.kf as kf,bscp_feepayments.cov as cov,bscp_feepayments.paydescription,bscp_feepayments.paymentmode,bscp_student.studid,bscp_student.sname') 
                    ->edit_column('desc_order', '$1', 'desc_order')
                      ->edit_column('description', '<span attr-split = "$3"  class="desc" attr-centers="$2" >$1</span>', 'description,centers,split')
                     ->edit_column('amount', '<span class="amount">$1</span>', 'amount')
                     ->edit_column('discount', '<span class="discount">$1</span>', 'discount')
                     ->edit_column('tax', '<span class="tax">$1</span>', 'tax')
                    ->edit_column('kf', '<span class="kf">$1</span>', 'kf')
                    ->edit_column('cov', '<span class="cov">$1</span>', 'cov')
                    ->edit_column('total', '<span style="color: #536485;" class="total">$1</span>', 'total')
                    ->edit_column('paid', '<span style="color: #536485;" class="paid">$1</span>', 'paid')
                    ->from('bscp_feepayments')->where('challanno',$challan)->where('bscp_feepayments.courseid',$ide)->where('bscp_feepayments.studentid',$user)->where('bscp_feepayments.amount <> "0"')
                     ->join('bscp_student_payments', 'bscp_student_payments.id=bscp_feepayments.stupayid', 'left')
					 ->join('bscp_student', 'bscp_student.id=bscp_feepayments.studentid', 'left');
                
                $table =  $this->datatables->generate();
		
		return $table;
        
    }
	
    
    public function AddPaymentForChallan($chno,$pdate,$ptime,$amtpaid,$ide,$studid,$paymode,$pdescription,$OrderId,$receiptno="",$type=""){
        
        $split = "0";$totamt = 0;$curamtarr = [];$amtArr = []; $curamt = 0; $bkpamtpaid = $amtpaid;
        $amountArr=[];$taxArr=[];$discountArr=[];$kfArr=[];$covArr=[];
		
		
		$paymentdate = "";
		
		if($type=="paid"){
			
			$query3 = $this-> db -> query('select paymentdate from bscp_feepayments where studentid="'.$studid.'" and courseid="'.$ide.'" and challanno="'.$chno.'" and paymentstatus="p"');
			$row3 = $query3->result_array();
			
			if ($query3->num_rows() > 0) {
				$paymentdate = $row3[0]['paymentdate'];
			}
			
			$query = $this-> db -> query('update bscp_feepayments set paymentmode="Cash",paydescription="",paymentamount=0,paymentstatus="" where studentid="'.$studid.'" and courseid="'.$ide.'" and challanno="'.$chno.'"');
			
			$query1 = $this-> db -> query('update bscp_feepayments set challanno="'.$chno.'" where studentid="'.$studid.'" and courseid="'.$ide.'" and paymentstatus<>"p"');
			
		}
		
		
		
        $query2 = $this-> db -> query('select a.*,b.split from bscp_feepayments as a,bscp_student_payments as b where a.studentid="'.$studid.'" and a.courseid="'.$ide.'" and a.challanno="'.$chno.'" and a.stupayid=b.id order by b.desc_order asc');
	$row = $query2->result_array();
        if ($row) {
            
                for($i=0 ; $i < count($row);$i++) {
                       
                       $totamt = intval($totamt)+intVal($row[$i]['total']);
                      // $query3 = $this-> db -> query('select description,split from bscp_student_payments where id="'.$row[$i]['stupayid'].'"');
                       //$row1 = $query3->result_array();
                       
                       //if ($row1) {
                           
                           $split = $row[$i]['split'];
                           
                       //}
                       
                       if( (intVal($amtpaid) >= intVal($row[$i]['total'])) && ($split === "0")){
                           
                           $amtpaid = intVal($amtpaid) - intval($row[$i]['total']);
                           $curamt = intval($row[$i]['total']);
                           
                           
                       } else if((intVal($amtpaid) >= intVal($row[$i]['total'])) && ($split === "1" || $split === "-1")){
                          
                           $amtpaid = intVal($amtpaid) - intval($row[$i]['total']);
                           $curamt = intval($row[$i]['total']);
                       }else if((intVal($amtpaid) <= intVal($row[$i]['total'])) && ($split === "1" || $split === "-1")){
                                                      
                           $curamt = $amtpaid;
                           $amtpaid = 0;
                       }
                       
                       $amtArr[$row[$i]['id']] = number_format($curamt,2);
                       $amountArr[$row[$i]['id']] = $row[$i]['amount'];
                       $discountArr[$row[$i]['id']] = $row[$i]['discount'];
                       $taxArr[$row[$i]['id']] = $row[$i]['tax'];
                       $kfArr[$row[$i]['id']] = $row[$i]['kf'];
                       $covArr[$row[$i]['id']] = $row[$i]['cov'];
                       $curamtarr[$row[$i]['id']] = $row[$i]['total'];
                       $curamt = 0;
                }
                
        }
        
        $challanno = ""; $countadd = 1;
        if(intval($totamt) !== intval($bkpamtpaid)){
            $query0 = $this-> db -> query('select distinct challanno from bscp_feepayments where studentid="'.$studid.'"');
		$count = $query0->num_rows();
		$count = $countadd + $count;
		$count = str_pad($count, 2, '0', STR_PAD_LEFT);
		$challanno = "C".$count;
                
        }
        
        foreach ($amtArr as $key=>$val){
            $val = str_replace(",", "", $val);
           // $strtotime = strtotime($pdate." ". $ptime);
            date_default_timezone_set("Asia/Calcutta");
            
			if($paymentdate=="") $paytime = date('Y-m-d H:i:s');
			else $paytime = $paymentdate;
			
            $paymode = ($paymode === "")?"cash":$paymode;
            $this-> db -> query('update `bscp_feepayments` set paymentmode="'.$paymode.'",paydescription="'.$pdescription.'",paymentdate="'.$paytime.'",paymentamount="'.$val.'",paymentstatus="p" where id="'.$key.'" and total="'.$val.'"');
            if($this->db->affected_rows() <= 0) {
                if($val === "0") { 
                    $this-> db -> query('update `bscp_feepayments` set challanno="'.$challanno.'",created_at="'.date('Y-m-d H:i:s').'" where id="'.$key);
                    
                } else {
                                                          
                   $id = uniqid();
                   $remainamt = floatval($curamtarr[$key]) - floatval($val);
                   $remainamt = round($remainamt);
                   
                   $tax = ($taxArr[$key] !== "NA")?$taxArr[$key]:"0";
                   $kf  = ($kfArr[$key] !== "NA")?$kfArr[$key]:"0";
                   $cov = ($covArr[$key] !== "NA")?$covArr[$key]:"0";
                   
                    $tottax = intVal($tax)+intVal($kf)+intVal($cov);
                   $calamount1 = floatval($remainamt)*floatval($tottax);
                   $calamount1 = round($calamount1);
                   $divTax = 100+intVal($tottax);
                   
                   $caltax = $calamount1 / $divTax;
                   $caltax = round($caltax, 2);
                                  
                   $calamount = floatval($remainamt) - floatval($caltax);
                   $calamount = round($calamount);
                   
                   $roundoff = "0";
                   
                   $discount = $discountArr[$key];
                   $discount = ($discount === "")?0:$discount;
                   $calamount = round($calamount)+round($discount);
                   
                   if(($challanno !== "")&&($calamount > 0)&&($remainamt > 0)) {
                    $this-> db -> query('insert into bscp_feepayments (`id`,`requestid`,`stupayid`, `studentid`, `courseid`, `center`,`challanno`, `amount`,`discount`,`tax`,`kf`,`cov`,`roundoff`,`total`, `status`, `created_at`, `paymode`, `paymentamount`, `paymentmode`, `paymentstatus`, `paymentdate`,`paydescription`, `dueamt`) SELECT "'.$id.'",`requestid`,`stupayid`, `studentid`, `courseid`,`center`, "'.$challanno.'", "'.$calamount.'",`discount`,`tax`,`kf`,`cov`,"'.$roundoff.'","'.$remainamt.'", `status`, `created_at`, `paymode`, `paymentamount`, `paymentmode`, `paymentstatus`, `paymentdate`,`paydescription`, `dueamt` FROM bscp_feepayments WHERE id = "'.$key.'"');
                   }
                    
                   
                  
                   $camount1 = intval($val) * intVal($tottax);
                   $ctax  = $camount1 / $divTax;
                   $ctax = round($ctax, 2);
                   $camount = floatval($val) - floatval($ctax);
                   $camount = round($camount)+round($discount);
              
                   $this-> db -> query('update `bscp_feepayments` set paymentmode="'.$paymode.'",paydescription="'.$pdescription.'",paymentdate="'.$paytime.'",paymentamount="'.$val.'",paymentstatus="p",amount="'.$camount.'",total="'.$val.'" where id="'.$key.'"'); 
                   
					//update
                   /*$qData = array(
                        'id' => $key,
                        'paymentmode' => $paymode,
                        'paydescription' => $pdescription,
                        'paymentdate' => $paytime,
                        'paymentamount' => $val,
                        'paymentstatus' => 'p',
                        'amount' => $camount,
                        'total' => $val
                    );
                   $this->db->update('bscp_feepayments', $qData, array('id' => $qData['id']));*/
					
                   //Kf adjustment
                   $kfadjust=0;
                    $query2 = $this-> db -> query('select b.kf as kf from bscp_feepayments as a left join bscp_student_payments as b on a.stupayid=b.id where a.id="'.$id.'"');
                    $row = $query2->result_array();
                    if ($row) {
                        
                            if($row[0]['kf']==="1"){
                                
                                $calamount = round($calamount) - round($discount);
                                $kfadjust = round($calamount*0.01);
                                $this-> db -> query('update `bscp_feepayments` set kfadjust="'.$kfadjust.'" where id="'.$id.'"'); 
                  
                                
                            }
                    }
                    
                    $kfadjust1=0;
                    $query21 = $this-> db -> query('select b.kf as kf from bscp_feepayments as a left join bscp_student_payments as b on a.stupayid=b.id where a.id="'.$key.'"');
                    $row1 = $query21->result_array();
                    if ($row1) {
                        
                            if($row1[0]['kf']==="1"){
                                
                                $camount = round($camount) - round($discount);
                                $kfadjust1 = round($camount*0.01);
                                $this-> db -> query('update `bscp_feepayments` set kfadjust="'.$kfadjust1.'" where id="'.$key.'"'); 
                  
                                
                            }
                    }
                    
                    //kfadjustment end
                }
            }
                        
        }
        
      //  $this->UpdateReceiptNo($amtArr,$ide,$studid);
        $this->load->model('billupdate_model','',TRUE);
        $this->billupdate_model->UpdateReceiptNo('n','',$amtArr,$ide,$studid,$OrderId,$receiptno,$type);
        
               
    }
	
	
	// Partial payment
	
	 public function AddPartialPayment($cride,$courseid,$studentid,$partialamt,$grandtotal){
		 
		 $result = array(0 => "");
		 
		 date_default_timezone_set("Asia/Calcutta");
         $paytime = date('Y-m-d H:i:s');
		 
		  $query3 = $this-> db -> query('select id from bscp_partialpayments where requestid="'.$cride.'" and studentid="'.$studentid.'" and courseid="'.$courseid.'" and status="a"');
		  $row1 = $query3->result_array();

		  if ($query3->num_rows() > 0) {
		 
			  
			  $query = $this-> db -> query('UPDATE `bscp_partialpayments` SET `partialamount`='.$partialamt.', `updated_at`="'.$paytime.'" WHERE requestid="'.$cride.'" and studentid="'.$studentid.'" and courseid="'.$courseid.'" and status="a"');

			 if($query){
				
				 $result = array(0 => "update");

			 }else{
				 $result = array(0 => "fail");
			 }
			
			   
		 }else{
			  
			  $id = uniqid();

			 $query = $this-> db -> query('INSERT INTO `bscp_partialpayments` (`id`, `requestid`, `studentid`, `courseid`, `partialamount`, `status`, `updated_at`, `created_at`) VALUES ("'.$id.'","'.$cride.'","'.$studentid.'","'.$courseid.'",'.$partialamt.',"a","'.$paytime.'","'.$paytime.'")');

			 if($query){

				 $query = $this-> db -> query('UPDATE `bscp_feepayments` SET `created_at`="'.$paytime.'" WHERE requestid="'.$cride.'" and studentid="'.$studentid.'" and courseid="'.$courseid.'" and paymentstatus<>"p"');
				 
				 $this->load->model('notification_model','',TRUE);
				 $this->notification_model->PartialPaymentNotification($studentid,$partialamt);
				 
				 $result = array(0 => "success");

			 }else{
				 $result = array(0 => "fail");
			 }
			  
		  }
		 
		 return $result;
		 
		 
	 }
	
	public function GetPartialPayment($cride,$studentid,$courseid){        
           
		$arr = array();
		
		$arr['partialamt'] = 0;
		$arr['status'] = "";
		
        $query0 = $this-> db -> query('select partialamount,status from bscp_partialpayments where requestid="'.$cride.'" and studentid="'.$studentid.'" and courseid="'.$courseid.'" and status="a"');
		$row = $query0->result_array();
		
		if($query0->num_rows()>0){
			
			$partialamount = $row[0]['partialamount'];
			$status = $row[0]['status'];
			
			$arr['partialamt'] = $partialamount;
			$arr['status'] = $status;
			
		}
		
		
		return $arr;
               
    }
	
	public function GetAllPartialPayment($studentid){        
           
		$arr = array();
		
		$arr['partialamt'] = $arr['status'] = $arr['courseid'] = $arr['requestid'] = array();
		
        $query0 = $this-> db -> query('select partialamount,status,courseid,requestid,updated_at from bscp_partialpayments where studentid="'.$studentid.'" and status="a"');
		$row = $query0->result_array();
		
		if($query0->num_rows()>0){
			
			for($i=0 ; $i < count($row);$i++) {
				
				$partialamount = $row[$i]['partialamount'];
				$status = $row[$i]['status'];
				$courseid = $row[$i]['courseid'];
				$requestid = $row[$i]['requestid'];
				$updated_at = $row[$i]['updated_at'];

				$arr['partialamt'][$i] = $partialamount;
				$arr['status'][$i] = $status;
				$arr['courseid'][$i] = $courseid;
				$arr['requestid'][$i] = $requestid;
				$arr['updated_at'][$i] = $updated_at;
				
			}
			
		}
		
		
		return $arr;
               
    }
    
    public function GetUnpaidLists(){
        
          
            $this->datatables->select('bscp_feepayments.studentid as studentid,bscp_feepayments.courseid as courseid,bscp_feepayments.created_at as created_at,bscp_student.studid as studid,bscp_feepayments.challanno as challanno,bscp_feepayments.requestid as requestid,'
                    . 'bscp_student.sname as sname,admin_course.coursename as coursename,admin_course.ide as cid,bscp_feepayments.center as center,bscp_feepayments.id as ide,'
                    . 'sum(bscp_feepayments.total) as unpaid') 
                    ->edit_column('created_at', '<span class="sno">$1</span>', '')
                    ->edit_column('studid', '<a target="_blank" href="studentprofile?sid=$2">$1</a>', 'studid,studentid')
                    ->edit_column('coursename', '<a target="_blank" href="coursedetails?id=$2">$1</a>', 'coursename,cid')
                    ->edit_column('sname', '<span class="sname">$1</span>', 'sname') 
                    ->edit_column('total', '<span style="font-weight:bold">$1</span>', 'total')                    
                    ->edit_column('ide', '<span data-cid="$2" data-sid="$3" data-chno="$1" data-crid="$4" class="addpay" style="color:#0332AA;padding-left: 20px;background:url('.base_url().'images/addpay.png) no-repeat;background-position-y: 4px;cursor:pointer" >Add Payment</span>', 'challanno,courseid,studentid,requestid')
                     ->edit_column('challanno', '<a target="_blank" href="stumyprofile/downloadChallan?id=$2&challan=unpaid&userid=$3" style="color:#0332AA">$1</a>', 'challanno,requestid,studentid')
                    ->from('bscp_feepayments')->where('(bscp_feepayments.paymentstatus="" and bscp_feepayments.amount != "0")')->group_by('challanno,studentid,studentid,center,courseid')
                    ->join('bscp_student', 'bscp_student.id=bscp_feepayments.studentid', 'left')
                     ->join('admin_course', 'admin_course.ide=bscp_feepayments.courseid', 'left');
                
                $table =  $this->datatables->generate();
            
               
        return $table;
        
    }
    
    
    public function GetPaidLists(){
        
          
            $this->datatables->select('bscp_feepayments.courseid as courseid,bscp_feepayments.paymentmode as paymode,bscp_feepayments.requestid as cride,DATE_FORMAT(bscp_feepayments.paymentdate,"%d-%m-%Y %h:%i %p") as paydate,bscp_feepayments.receiptno as receiptno,bscp_feepayments.studentid as studentid,bscp_feepayments.courseid as courseid,bscp_feepayments.paymentdate as created_at,bscp_student.studid as studid,bscp_feepayments.challanno as challanno,'
                    . 'bscp_student.sname as sname,admin_course.coursename as coursename,admin_course.ide as cid,bscp_feepayments.center as center,bscp_feepayments.id as ide,'
                    . 'sum(bscp_feepayments.total) as unpaid',FALSE) 
                    ->edit_column('created_at', '<span class="sno">$1</span>', '')
                    ->edit_column('studid', '<a target="_blank" href="studentprofile?sid=$2">$1</a>', 'studid,studentid')
                     ->edit_column('coursename', '<a target="_blank" href="coursedetails?id=$2">$1</a>', 'coursename,cid')
                    ->edit_column('sname', '<span class="sname">$1</span>', 'sname') 
                    ->edit_column('total', '<span style="font-weight:bold">$1</span>', 'total')  
                    ->edit_column('paydate', '<span>$1</span>', 'paydate')  
                    ->edit_column('ide', '<a href="stufeebill?crid=$2&cno=$1&userid=$3" target="_blank" style="color:#0332AA;padding-left: 20px;background:url('.base_url().'images/view.png) no-repeat;background-position-y: 4px;cursor:pointer" >View</a>', 'challanno,cride,studentid')
                     ->edit_column('challanno', '<span style="color:#0332AA">$1</span>', 'challanno')
                    ->from('bscp_feepayments')->where('bscp_feepayments.paymentstatus = "p"')->group_by('challanno')->group_by('studentid')
                    ->join('bscp_student', 'bscp_student.id=bscp_feepayments.studentid', 'left')
                     ->join('admin_course', 'admin_course.ide=bscp_feepayments.courseid', 'left');
                    
                
                $table =  $this->datatables->generate();
            
               
        return $table;
        
    }
	
	public function allpaidunpaidlists_count($type,$batches)
    {   
		
		$querybillno = $this-> db -> query('select * from bscp_billcounter');
		$rowbillno = $querybillno->result_array();
		$billfromdate = $rowbillno[0]['fromdate'];
		
		if($type=="paid"){
			
			$whereclause = 'fp.paymentstatus = "p" and fp.paymentdate >= "'.$billfromdate.'"';
			$groupby = 'fp.challanno,fp.requestid';
			
		}else{
			$whereclause = '(fp.paymentstatus="" and fp.amount != "0")';
			$groupby = 'fp.challanno,fp.requestid';
		}
		
      
		if(empty($batches) || in_array("All", $batches)){
			$query = $this ->db->query('select fp.id from bscp_feepayments as fp  where '.$whereclause.' group by '.$groupby );
		}else{
			$whereclause .= ' and fp.studentid=cr.studentid and cr.batchname IN ("'.implode('","',$batches).'") and fp.courseid=cr.courseid';
			$query = $this ->db->query('select fp.id from bscp_feepayments as fp,bscp_courserequest as cr  where '.$whereclause.' group by '.$groupby );
		}		
    
        return $query->num_rows();  

    }
    
    public function allpaidunpaidlists($limit,$start,$col,$dir,$type,$batches)
    {   
		
		
		$querybillno = $this-> db -> query('select * from bscp_billcounter');
		$rowbillno = $querybillno->result_array();
		$billfromdate = $rowbillno[0]['fromdate'];
		
		if($type=="paid"){
			
			$selectquery = 'fp.courseid as courseid,fp.paymentmode as paymode,fp.requestid as cride,DATE_FORMAT(fp.paymentdate,"%d-%m-%Y %h:%i %p") as paydate,fp.receiptno as receiptno,fp.studentid as studentid,fp.courseid as courseid,fp.paymentdate as created_at,s.studid as studid,fp.challanno as challanno,'
                    . 's.sname as sname,c.coursename as coursename,c.ide as cid,fp.center as center,fp.id as ide,fp.referenceid,'
                    . 'sum(fp.total) as unpaid';
			$whereclause = 'fp.paymentstatus = "p" and fp.paymentdate >= "'.$billfromdate.'" ';
			$groupby = 'fp.challanno,fp.requestid';
			$false = FALSE;
			
		}else{
			
			$selectquery = 'fp.studentid as studentid,fp.courseid as courseid,fp.created_at as created_at,s.studid as studid,fp.challanno as challanno,fp.requestid as requestid,'
                    . 's.sname as sname,c.coursename as coursename,c.ide as cid,fp.center as center,fp.id as ide,fp.referenceid,'
                    . 'sum(fp.total) as unpaid';
			$whereclause = '(fp.paymentstatus="" and fp.amount != "0")';
			$groupby = 'fp.challanno,fp.requestid';
			$false = '';
		}
		
		
		if(empty($batches) || in_array("All", $batches)){
			$query = $this ->db->query('select '.$selectquery.' from bscp_feepayments as fp LEFT JOIN bscp_student as s ON s.id=fp.studentid LEFT JOIN admin_course as c ON c.ide=fp.courseid where '.$whereclause.' group by '.$groupby.' order by '.$col.' '.$dir.' limit '.$start.','.$limit);
		}else{
			$whereclause .= ' and cr.batchname IN ("'.implode('","',$batches).'") and fp.courseid=cr.courseid';
			$query = $this ->db->query('select '.$selectquery.' from bscp_feepayments as fp LEFT JOIN bscp_student as s ON s.id=fp.studentid LEFT JOIN admin_course as c ON c.ide=fp.courseid LEFT JOIN bscp_courserequest as cr ON s.id=cr.studentid where '.$whereclause.' group by '.$groupby.' order by '.$col.' '.$dir.' limit '.$start.','.$limit);
		}
		
        
        if($query->num_rows()>0)
        {
            return $query->result(); 
        }
        else
        {
            return null;
        }
        
    }
   
    public function paidunpaidlists_search($limit,$start,$search,$col,$dir,$type,$searchcol,$batches)
    {
		
		if($type=="paid"){
			
			$selectquery = 'fp.courseid as courseid,fp.paymentmode as paymode,fp.requestid as cride,DATE_FORMAT(fp.paymentdate,"%d-%m-%Y %h:%i %p") as paydate,fp.receiptno as receiptno,fp.studentid as studentid,fp.courseid as courseid,fp.paymentdate as created_at,s.studid as studid,fp.challanno as challanno,'
                    . 's.sname as sname,c.coursename as coursename,c.ide as cid,fp.center as center,fp.id as ide,fp.referenceid,'
                    . 'sum(fp.total) as unpaid';
			$whereclause = 'fp.paymentstatus = "p"';
			$groupby = 'fp.challanno,fp.requestid';
			$false = FALSE;
			
		}else{
			
			$selectquery = 'fp.studentid as studentid,fp.courseid as courseid,fp.created_at as created_at,s.studid as studid,fp.challanno as challanno,fp.requestid as requestid,'
                    . 's.sname as sname,c.coursename as coursename,c.ide as cid,fp.center as center,fp.id as ide,fp.referenceid,'
                    . 'sum(fp.total) as unpaid';
			$whereclause = '(fp.paymentstatus ="" and fp.amount != "0")';
			$groupby = 'fp.challanno,fp.requestid';
			$false = '';
		}
		
				
		$wheresearch = '';
		
		if($searchcol!="") $wheresearch .= ' and (';
		
		if($searchcol=="stuid"){$wheresearch .= ' `s`.`studid` = "'.$search.'"';}
		else if($searchcol=="stuname"){$wheresearch .= ' `s`.`sname` = "'.$search.'"';}
		else if($searchcol=="billno" && $type=="paid"){$wheresearch .= ' `fp`.`receiptno` = "'.$search.'"';}
		else if($searchcol=="courseid"){$wheresearch .= ' `c`.`courseid` = "'.$search.'"';}
		else if($searchcol=="coursename"){$wheresearch .= ' `c`.`coursename` LIKE "%'.$search.'%"';}
		else if($searchcol=="center"){$wheresearch .= ' `fp`.`center` = "'.$search.'"';}
			
		if($searchcol!="") $wheresearch .= ')';
		
		$whereclause = $whereclause.$wheresearch;
		
		if(empty($batches) || in_array("All", $batches)){
			$query = $this ->db->query('select '.$selectquery.' from bscp_feepayments as fp LEFT JOIN bscp_student as s ON s.id=fp.studentid LEFT JOIN admin_course as c ON c.ide=fp.courseid where '.$whereclause.' group by '.$groupby.' order by '.$col.' '.$dir.' limit '.$start.','.$limit);
		}else{
			$whereclause .= ' and cr.batchname IN ("'.implode('","',$batches).'") and fp.courseid=cr.courseid';
			$query = $this ->db->query('select '.$selectquery.' from bscp_feepayments as fp LEFT JOIN bscp_student as s ON s.id=fp.studentid LEFT JOIN admin_course as c ON c.ide=fp.courseid LEFT JOIN bscp_courserequest as cr ON s.id=cr.studentid where '.$whereclause.' group by '.$groupby.' order by '.$col.' '.$dir.' limit '.$start.','.$limit);
		}
		        
       
        if($query->num_rows()>0)
        {
            return $query->result();  
        }
        else
        {
            return null;
        }
    }

    public function paidunpaidlists_search_count($search,$type,$searchcol,$batches)
    {
		
		if($type=="paid"){
			
			$whereclause = 'fp.paymentstatus = "p"';
			$groupby = 'fp.challanno,fp.requestid';
			
		}else{
			$whereclause = '(fp.paymentstatus="" and fp.amount != "0")';
			$groupby = 'fp.challanno,fp.requestid';
		}
				
		$wheresearch = '';
		
		if($searchcol!="") $wheresearch .= ' and (';
		
		if($searchcol=="stuid"){$wheresearch .= ' `s`.`studid` = "'.$search.'"';}
		else if($searchcol=="stuname"){$wheresearch .= ' `s`.`sname` = "'.$search.'"';}
		else if($searchcol=="billno" && $type=="paid"){$wheresearch .= ' `fp`.`receiptno` = "'.$search.'"';}
		else if($searchcol=="courseid"){$wheresearch .= ' `c`.`courseid` = "'.$search.'"';}
		else if($searchcol=="coursename"){$wheresearch .= ' `c`.`coursename` LIKE "%'.$search.'%"';}
		else if($searchcol=="center"){$wheresearch .= ' `fp`.`center` = "'.$search.'"';}
			
		if($searchcol!="") $wheresearch .= ')';
		
		$whereclause = $whereclause.$wheresearch;
		
		if(empty($batches) || in_array("All", $batches)){
			$query = $this ->db->query('select fp.id from bscp_feepayments as fp LEFT JOIN bscp_student as s ON s.id=fp.studentid LEFT JOIN admin_course as c ON c.ide=fp.courseid where '.$whereclause.' group by '.$groupby );
		}else{
			$whereclause .= ' and cr.batchname IN ("'.implode('","',$batches).'") and fp.courseid=cr.courseid';
			$query = $this ->db->query('select fp.id from bscp_feepayments as fp LEFT JOIN bscp_student as s ON s.id=fp.studentid LEFT JOIN admin_course as c ON c.ide=fp.courseid LEFT JOIN bscp_courserequest as cr ON s.id=cr.studentid where '.$whereclause.' group by '.$groupby );
		}
    
        return $query->num_rows();
    }
    
     public function UpdateReceiptNo($amtArr,$cid,$sid){        
           
        $countadd = 1; $flg = 0;
        $query0 = $this-> db -> query('select billcounter,fromdate from bscp_billcounter');
	$row = $query0->result_array();
       // $count = $row[0]['billcounter'];   
        $billfromdate = $row[0]['fromdate'];
	//$count = str_pad($count, 2, '0', STR_PAD_LEFT);
        
        $query1 = $this-> db -> query('SELECT x.max_field
                          FROM (SELECT MAX(CAST(t.receiptno AS UNSIGNED)) + 1 AS max_field FROM bscp_feepayments t WHERE t.paymentstatus="p" AND t.paymentdate >= "'.$billfromdate.'") x');
        $row1 = $query1->result_array();
        $count = $row1[0]['max_field']; 
        
        foreach($amtArr as $key=>$val){
            $this-> db -> query('update `bscp_feepayments` set receiptno="'.$count.'" where id="'.$key.'" and paymentstatus="p" and studentid="'.$sid.'" and courseid="'.$cid.'"'); 
            if($this->db->affected_rows() > 0) { $flg = 1; }
            }
        
        /*if($flg > 0) {
           $count = $countadd + $count;
           $this-> db -> query('update `bscp_billcounter` set billcounter=(SELECT x.max_field
                         FROM (SELECT MAX(CAST(t.receiptno AS UNSIGNED)) + 1 AS max_field FROM bscp_feepayments t WHERE t.paymentstatus="p" AND t.paymentdate >= "'.$billfromdate.'") x)');
        }*/
           
         //Update partial payment        
         $this-> db -> query('update `bscp_partialpayments` set status="p" where studentid="'.$sid.'" and courseid="'.$cid.'" and status="a"'); 
         
    }
    
    
     public function UpdatePaymentForDescription($ide,$desc,$action,$centers){     
         
         
        $this-> db -> query('update `admin_group` set active="'.$action.'" where courseid="'.$ide.'" and description="'.$desc.'" and centers="'.$centers.'"'); 

        $this-> db -> query('update `bscp_student_payments` set active="'.$action.'" where courseid="'.$ide.'" and description="'.$desc.'" and centers="'.$centers.'"'); 

        
        if($action === "0"){
            
            $query0 = $this-> db -> query('select requestid,id from bscp_student_payments where courseid="'.$ide.'" and description="'.$desc.'" and centers="'.$centers.'"');
            $row = $query0->result_array();
            for($i=0; $i < count($row); $i++){
                
                  $this-> db -> query("delete from `bscp_feepayments` where courseid = '".$ide."' AND stupayid = '".$row[$i]['id']."' AND requestid = '".$row[$i]['requestid']."' AND paymentstatus = ''");
                     
            }
            
        } else if($action === "1"){
            
            ini_set('memory_limit', '-1');	
            ini_set('max_execution_time', 86400);
                
            $paidpay = "0";
            $query0 = $this-> db -> query('select * from bscp_student_payments where courseid="'.$ide.'" and description="'.$desc.'" and centers="'.$centers.'"');
            $row = $query0->result_array();
            for($i=0; $i < count($row); $i++){
                
                $whereclause = ' and paymentstatus="p"';
                $query1 = $this-> db -> query('select sum(total) as stotal from bscp_feepayments where stupayid="'.$row[$i]['id'].'" and courseid="'.$ide.'" and studentid="'.$row[$i]['studentid'].'"'.$whereclause);
                $row1 = $query1->result_array();
                
                if ($query1->num_rows()>0) {
                    $paidpay = $row1[0]['stotal'];
                } 
                    
                    $descArray['Registration Charges'] = 1;$descArray['Caution Deposit'] = 2;
                    $descArray['Screening Test Registration Charges'] = 3;$descArray['Tuition Fee'] = 4;
                    $descArray['Tuition Fee - 1'] = 5;$descArray['Tuition Fee - 2'] = 6;
                    
                    $decs_Order = (array_key_exists($desc, $descArray))?$descArray[$desc]:1;
             
                    $qData = array(
                      'id' => $row[$i]['id'],
                      'courseid' => $row[$i]['courseid'],
                      'requestid' => $row[$i]['requestid'],
                      'centers' => $row[$i]['centers'],
                      'description' => $row[$i]['description'],
                      'sac' => $row[$i]['sac'],
                      'amount' => $row[$i]['amount'],
                      'discount' => $row[$i]['discount'],
                      'givenby' => $row[$i]['givenby'],
                      'reason' => $row[$i]['reason'],
                      'tax' => $row[$i]['tax'],
                      'total' => $row[$i]['total'],
                      'active' => $row[$i]['active'],
                      'taxable' => $row[$i]['taxable'],
                      'kf' => $row[$i]['kf'],
                      'cov' => $row[$i]['cov'],
                      'split' => $row[$i]['split'],
                      'studentid' => $row[$i]['studentid'],
                      'created_at' => date('Y-m-d H:i:s'),
                      'desc_order ' => $decs_Order
                  );
                    
                 $this->InsertFeesPayments($qData,$row[$i]['courseid'],$row[$i]['studentid'],$paidpay,$row[$i]['requestid'],"");
                  
            }
            
        }
        
        $result = array(0 => "success");
        return $result;
        
     }
     
      public function AddRefundApplication($qData,$type)
    {
         
              $ide = "";
              if($type !== "init") {
                $query = $this-> db -> query('select id from bscp_refundapplication where requestid="'.$qData['requestid'].'"');
                  $row = $query->result_array();
                  if ($query->num_rows()>0) {
                       $ide = $row[0]['id'];
                  }
              }
             if($ide !== "") {
                 $qData['id'] = $ide;
                  $this->db->update('bscp_refundapplication', $qData, array('id' => $ide));
             } else {
                 
                  $this->db->insert('bscp_refundapplication', $qData);
             }
             
             $query = $this-> db -> query('UPDATE `bscp_courserequest` SET `refund`="2" WHERE ide="'.$qData['requestid'].'"');
             
                 
         return true;
       
    }
    
      public function isCheckRefundStatus($crid)
    {
         
              $status = "";
              $query = $this-> db -> query('select status from bscp_refundapplication where requestid="'.$crid.'"');
                $row = $query->result_array();
                if ($query->num_rows()>0) {
                     $status = $row[0]['status'];
                }
             
         return $status;
       
    }
    
          public function isCheckRefund($crid)
    {
         
              $ide = "";
              $query = $this-> db -> query('select id from bscp_refundapplication where requestid="'.$crid.'"');
                $row = $query->result_array();
                if ($query->num_rows()>0) {
                     $ide = $row[0]['id'];
                }
             
         return $ide;
       
    }
    
     public function GetRefund($id)
    {
         
              $ret = Array();
              
              $query = $this-> db -> query('select refund.* ,stu.sname from bscp_refundapplication as refund,bscp_student as stu where stu.id=refund.studentid and refund.id="'.$id.'"');
                $row = $query->result_array();
                if ($query->num_rows()>0) {
                    $ret['stuname'] = $row[0]['sname'];
                     $ret['studid'] = $row[0]['studid'];
                     $ret['reason'] = $row[0]['reason'];
                     $ret['doj'] = $row[0]['doj'];
                     $ret['batch'] = $row[0]['batch'];
                     $ret['housenameno'] = $row[0]['housenameno'];
                     $ret['contactaddress'] = $row[0]['contactaddress'];
                     $ret['contactpost'] = $row[0]['contactpost'];
                     $ret['contactcountry'] = $row[0]['contactcountry'];
                     $ret['contactstate'] = $row[0]['contactstate'];
                     $ret['contactdistrict'] = $row[0]['contactdistrict'];
                     $ret['contactpincode'] = $row[0]['contactpincode'];
                     $ret['accountholdername'] = $row[0]['accountholdername'];
                     $ret['bankname'] = $row[0]['bankname'];
                     $ret['branch'] = $row[0]['branch'];
                      $ret['ifsccode'] = $row[0]['ifsccode'];
                       $ret['bankaccountno'] = $row[0]['bankaccountno'];
                }
             
                 
         return $ret;
       
    }
    
    
	public function refund_count($batches)
    {   
		
		$jointable = $where = "";
		
		if(!empty($batches) && !in_array("All", $batches)){
			 $jointable = ",bscp_courserequest as cr";
			 $where = '  and ra.studentid=cr.studentid and cr.batchname IN ("'.implode('","',$batches).'") and ra.courseid=cr.courseid ';
		 }
     
		$query = $this ->db->query('select ra.appno from bscp_refundapplication as ra'.$jointable.' where ra.status <> ""'.$where );		
    
        return $query->num_rows();  

    }
    
    public function refundlist($limit,$start,$col,$dir,$batches)
    {   
     
        $selectquery = 'ra.bankname as bankname,ra.branch as branch,ra.ifsccode as ifsccode,ra.bankaccountno as bankaccountno,ra.requestid as requestid,ra.type as type,ra.requestedrefundamt as requestedrefundamt,ra.status as status,ra.id as id,ra.courseid as courseid,ra.studentid as studentid,ra.appno as appno,ra.studid as studid,ra.center as center,s.sname as sname,c.coursename as cname';
	$whereclause = 'ra.status <> ""';
		
		$jointable = "";
		
		if(!empty($batches) && !in_array("All", $batches)){
			 $jointable = " LEFT JOIN bscp_courserequest as cr ON s.id=cr.studentid";
			 $whereclause .= ' and cr.batchname IN ("'.implode('","',$batches).'") and ra.courseid=cr.courseid ';
		 }
                        
       $query = $this ->db->query('select '.$selectquery.' from bscp_refundapplication as ra LEFT JOIN bscp_student as s ON s.id=ra.studentid LEFT JOIN admin_course as c ON c.ide=ra.courseid '.$jointable.' where '.$whereclause.' order by '.$col.' '.$dir.' limit '.$start.','.$limit);
        
        if($query->num_rows()>0)
        {
            return $query->result(); 
        }
        else
        {
            return null;
        }
        
    }
   
    public function refundlist_search($limit,$start,$search,$col,$dir,$searchcol,$batches)
    {
        	$selectquery = 'ra.requestid as requestid,ra.type as type,ra.requestedrefundamt as requestedrefundamt,ra.status as status,c.courseid as courseid,ra.id as id,ra.courseid as courseid,ra.studentid as studentid,ra.appno as appno,ra.studid as studid,ra.center as center,s.sname as sname,c.coursename as cname';
                $whereclause = 'ra.status <> ""';
        
		$wheresearch = '';
		
		if($searchcol!="") $wheresearch .= ' and (';
		
		if($searchcol=="stuid"){$wheresearch .= ' `s`.`studid` = "'.$search.'"';}
		else if($searchcol=="stuname"){$wheresearch .= ' `s`.`sname` = "'.$search.'"';}	
		else if($searchcol=="courseid"){$wheresearch .= ' `c`.`courseid` = "'.$search.'"';}
		else if($searchcol=="coursename"){$wheresearch .= ' `c`.`coursename` LIKE "%'.$search.'%"';}
		else if($searchcol=="center"){$wheresearch .= ' `ra`.`center` = "'.$search.'"';}
                else if($searchcol=="appno"){$wheresearch .= ' `ra`.`appno` = "'.$search.'"';}
			
		if($searchcol!="") $wheresearch .= ')';
		
                $whereclause = $whereclause.$wheresearch;
			
		$jointable = "";
		
		if(!empty($batches) && !in_array("All", $batches)){
			 $jointable = " LEFT JOIN bscp_courserequest as cr ON s.id=cr.studentid";
			 $whereclause .= ' and cr.batchname IN ("'.implode('","',$batches).'") and ra.courseid=cr.courseid ';
		 }
		
		
		$query = $this ->db->query('select '.$selectquery.' from bscp_refundapplication as ra LEFT JOIN bscp_student as s ON s.id=ra.studentid LEFT JOIN admin_course as c ON c.ide=ra.courseid '.$jointable.' where '.$whereclause.' order by '.$col.' '.$dir.' limit '.$start.','.$limit);
        
                if($query->num_rows()>0)
                {
                    return $query->result(); 
                }
                else
                {
                    return null;
                }
    }

    public function refundlist_search_count($search,$searchcol,$batches)
    {
        		
		$selectquery = 'ra.requestid as requestid,ra.type as type,ra.requestedrefundamt as requestedrefundamt,ra.status as status,c.courseid as courseid,ra.id as id,ra.courseid as courseid,ra.studentid as studentid,ra.appno as appno,ra.studid as studid,ra.center as center,s.sname as sname,c.coursename as cname';
                $whereclause = 'ra.status <> ""';
        
		$wheresearch = '';
		
		if($searchcol!="") $wheresearch .= ' and (';
		
		if($searchcol=="stuid"){$wheresearch .= ' `s`.`studid` = "'.$search.'"';}
		else if($searchcol=="stuname"){$wheresearch .= ' `s`.`sname` = "'.$search.'"';}	
		else if($searchcol=="courseid"){$wheresearch .= ' `c`.`courseid` = "'.$search.'"';}
		else if($searchcol=="coursename"){$wheresearch .= ' `c`.`coursename` LIKE "%'.$search.'%"';}
		else if($searchcol=="center"){$wheresearch .= ' `ra`.`center` = "'.$search.'"';}
                else if($searchcol=="appno"){$wheresearch .= ' `ra`.`appno` = "'.$search.'"';}
			
		if($searchcol!="") $wheresearch .= ')';
		
                $whereclause = $whereclause.$wheresearch;
			
		$jointable = "";
		if(!empty($batches) && !in_array("All", $batches)){
			 $jointable = " LEFT JOIN bscp_courserequest as cr ON s.id=cr.studentid";
			 $whereclause .= ' and cr.batchname IN ("'.implode('","',$batches).'") and ra.courseid=cr.courseid ';
		 }
		
		$query = $this ->db->query('select '.$selectquery.' from bscp_refundapplication as ra LEFT JOIN bscp_student as s ON s.id=ra.studentid LEFT JOIN admin_course as c ON c.ide=ra.courseid '.$jointable.' where '.$whereclause);
        	
                return $query->num_rows();
    }
    
    
     public function GetRefundPaymentLists($cid,$sid,$center) {
        
        $query1 = $this-> db -> query('select id from bscp_feepayments  where  studentid="'.$sid.'" and courseid="'.$cid.'" and center="'.$center.'" and paymentstatus="p"');
	$row = $query1->result_array();
        if ($row) {
		
	    $this->datatables->select('bscp_student_payments.id as ide,bscp_student_payments.requestid as rid,bscp_student_payments.tax as tax,bscp_feepayments.stupayid as stupayid,bscp_student_payments.sac as sac,bscp_student_payments.description as description,bscp_student_payments.desc_order as desc_order,sum(bscp_student_payments.amount - bscp_student_payments.discount) as amount,sum(bscp_feepayments.amount - bscp_feepayments.discount) as paid') 
                    ->edit_column('desc_order', '$1', 'desc_order')
                    ->edit_column('description', '<span attr-descid = "$2"  class="desc" >$1</span>', 'description,stupayid')
                    ->edit_column('amount', '<span class="amount">$1</span>', 'amount')
                    ->edit_column('paid', '<span style="color: #536485;" class="paid">$1</span>', 'paid')
                    ->edit_column('sac', '<input style="width: 100px;height: auto;border: 1px solid #ccc;padding: 5px;" class="refundamt" value="0">', '')
                     ->edit_column('ide', '<span style="color: #536485;" class="refundnet" >0</span>', '')
                    ->edit_column('requestid', '<span style="color: #536485;" class="refundtotal" >0</span>', '')
                    ->edit_column('tax', '<span style="color: #536485;" class="gstrefund" >0</span>', '')
                    ->from('bscp_feepayments')->where('bscp_feepayments.courseid',$cid)->where('bscp_feepayments.studentid',$sid)->where('bscp_feepayments.center',$center)->where('bscp_feepayments.paymentstatus',"p")
                    ->join('bscp_student_payments', 'bscp_student_payments.id=bscp_feepayments.stupayid', 'left')->group_by('bscp_feepayments.stupayid');
                
                $table =  $this->datatables->generate();
		
		
        } else {
            
             $this->datatables->select('bscp_student_payments.id as ide,bscp_student_payments.requestid as rid,bscp_student_payments.tax as tax,bscp_student_payments.sac as sac,bscp_student_payments.description as description,bscp_student_payments.desc_order as desc_order,sum(bscp_student_payments.amount - bscp_student_payments.discount) as amount,sum(bscp_student_payments.total) as paid') 
                    ->edit_column('desc_order', '$1', 'desc_order')
                    ->edit_column('description', '<span attr-descid = "none"  class="desc" >$1</span>', 'description')
                    ->edit_column('amount', '<span class="amount">$1</span>', 'amount')
                    ->edit_column('paid', '<span style="color: #536485;" class="paid">0</span>', 'paid')
                    ->edit_column('sac', '<input style="width: 100px;height: auto;border: 1px solid #ccc;padding: 5px;" class="refundamt" value="0">', '')
                     ->edit_column('ide', '<span style="color: #536485;" class="refundnet" >0</span>', '')
                    ->edit_column('requestid', '<span style="color: #536485;" class="refundtotal" >0</span>', '')
                    ->edit_column('tax', '<span style="color: #536485;" class="gstrefund" >0</span>', '')
                    ->from('bscp_student_payments')->where('bscp_student_payments.courseid',$cid)->where('bscp_student_payments.studentid',$sid)->where('bscp_student_payments.centers',$center)->group_by('bscp_student_payments.description');
                
                $table =  $this->datatables->generate();
            
        }
        
        return $table;
    }
    
        public function GetCCPaymentLists($cid,$sid,$center) {
        
        $query1 = $this-> db -> query('select id from bscp_feepayments  where  studentid="'.$sid.'" and courseid="'.$cid.'" and center="'.$center.'" and paymentstatus="p"');
	$row = $query1->result_array();
        if ($row) {
		
	    $this->datatables->select('bscp_feepayments.stupayid as stupayid,bscp_student_payments.sac as sac,bscp_student_payments.description as description,bscp_student_payments.desc_order as desc_order,sum(bscp_student_payments.amount  - bscp_student_payments.discount) as amount,sum(bscp_feepayments.amount - bscp_feepayments.discount) as paid') 
                    ->edit_column('desc_order', '$1', 'desc_order')
                      ->edit_column('description', '<span attr-descid = "$2"  class="desc" >$1</span>', 'description,stupayid')
                     ->edit_column('amount', '<span class="amount">$1</span>', 'amount')
                    ->edit_column('paid', '<span style="color: #536485;" class="paid">$1</span>', 'paid')
                    ->edit_column('sac', '<input style="width: 100px;height: auto;border: 1px solid #ccc;padding: 5px;" class="refundamt" value="0">', '')
                    ->from('bscp_feepayments')->where('bscp_feepayments.courseid',$cid)->where('bscp_feepayments.studentid',$sid)->where('bscp_feepayments.center',$center)->where('bscp_feepayments.paymentstatus',"p")
                     ->join('bscp_student_payments', 'bscp_student_payments.id=bscp_feepayments.stupayid', 'left')->group_by('bscp_feepayments.stupayid');
                
                $table =  $this->datatables->generate();
		
		
        } else {
            
             $this->datatables->select(',bscp_student_payments.sac as sac,bscp_student_payments.description as description,bscp_student_payments.desc_order as desc_order,sum(bscp_student_payments.amount - bscp_student_payments.discount) as amount,sum(bscp_student_payments.total) as paid') 
                    ->edit_column('desc_order', '$1', 'desc_order')
                      ->edit_column('description', '<span attr-descid = "none"  class="desc" >$1</span>', 'description')
                     ->edit_column('amount', '<span class="amount">$1</span>', 'amount')
                    ->edit_column('paid', '<span style="color: #536485;" class="paid">0</span>', 'paid')
                    ->edit_column('sac', '<input style="width: 100px;height: auto;border: 1px solid #ccc;padding: 5px;" class="refundamt" value="0">', '')
                    ->from('bscp_student_payments')->where('bscp_student_payments.courseid',$cid)->where('bscp_student_payments.studentid',$sid)->where('bscp_student_payments.centers',$center)->group_by('bscp_student_payments.description');
                
                $table =  $this->datatables->generate();
            
        }
        
        return $table;
    }
    
      public function GetNewCoursePaymentLists($cid,$center) {
        
        $arr = Array();
		
		$arr['list'] = "";
		
                //$this->datatables->set_database("default");
	    $this->datatables->select('admin_group.sno as sno,admin_group.description as description,(admin_group.amount- admin_group.discount) as total') 
                    ->from('admin_group')->where('admin_group.courseid',$cid)->where('admin_group.centers',$center);
                
                $table =  $this->datatables->generate();
		
		return $table;
        
    }
    
    public function AddRefund($remarks,$paymode,$pdescription,$reason,$cid,$studid,$refundid,$center,$stupayid,$amount,$remit,$refund,$gstrefund,$refundtotal,$rid,$paydate) {
        
        $rowArr = explode("|", $stupayid);
        $amountArr = explode("|", $amount);
        $remitArr = explode("|", $remit);
        $refundArr = explode("|", $refund);
        $gstrefundArr = explode("|", $gstrefund);
        $refundtotalArr = explode("|", $refundtotal);
        $receiptno = ""; 
        $query = $this-> db -> query('SELECT MAX(CAST(t.receiptno AS UNSIGNED)) + 1 AS max_field FROM bscp_refund t WHERE (t.receiptno != null or receiptno != "")');
                $row = $query->result_array();
                if ($query->num_rows()>0) {
                     $receiptno = $row[0]['max_field'];
                }
        
        if(is_null($receiptno)) {$receiptno = "1";}
        
         for($i = 0 ; $i < count($rowArr);$i++){
             
             if($rowArr[$i] === "") {continue;}
             
             $ide = uniqid();
              $qData = array(
                'id' => $ide,
                'receiptno' => $receiptno,
                'courseid' => html_escape($cid),
                'studentid' => html_escape($studid),
                'center' => html_escape($center),
                'stupayid' => html_escape($rowArr[$i]),
                'refundappid' => html_escape($refundid),
                'requestid' => html_escape($rid),
                'amount' => html_escape($amountArr[$i]),
                'remitted' => html_escape($remitArr[$i]),
                'refundamount' => html_escape($refundArr[$i]),
                'gstrefund' => html_escape($gstrefundArr[$i]),
                'refundtotal' => html_escape($refundtotalArr[$i]),
                'reason' => html_escape($reason),
                'paymode' => html_escape($paymode),
                'paydescription' => html_escape($pdescription),
                'paydate' => html_escape($paydate),
                'created_at' => date('Y-m-d H:i:s')
            );
            
             
            $this->db->insert('bscp_refund', $qData);
            
            if($reason=== 'discontinue') {
                
                
                $discount = floatval($refundArr[$i]);
                $amt = floatval($amountArr[$i]);
                $total = floatval($amt)- floatval($discount);
                $gstTotal = floatval($total)*1.18;
                $gstTotal = round($gstTotal);

                
                $this-> db -> query('update `bscp_student_payments` set reason="discontinue",discount="'.$discount.'",total="'.$gstTotal.'" where id="'.$rowArr[$i].'"'); 
                $this-> db -> query('delete from `bscp_feepayments` where stupayid="'.$rowArr[$i].'" and paymentstatus!="p"');
                
                
            }
             
         }
         
         $this->load->model('login_model','',TRUE);
         $user = $this->login_model->GetUserId();		
         
         $query = $this-> db -> query('UPDATE `bscp_refundapplication` SET `remarks`="'.$remarks.'" ,`status`="c" , updated_by = "'.$user['name'].'" WHERE id="'.$refundid.'"');
         $query = $this-> db -> query('UPDATE `bscp_courserequest` SET `refund`="4" WHERE ide="'.$rid.'"');
         
         return true;
        
        
    }
    
    
    public function EditRefund($status,$paymode,$pdescription,$reason,$refundid,$stupayid,$amount,$remit,$refund,$gstrefund,$refundtotal,$paydate,$paycheque) {
        
        $rowArr = explode("|", $stupayid);
        $amountArr = explode("|", $amount);
        $remitArr = explode("|", $remit);
        $refundArr = explode("|", $refund);
        $gstrefundArr = explode("|", $gstrefund);
        $refundtotalArr = explode("|", $refundtotal);
 
       
         for($i = 0 ; $i < count($rowArr);$i++){
             
             if($rowArr[$i] === "") {continue;}
               
                $this-> db -> query('update `bscp_refund` set paydate="'. html_escape($paydate).'",paycheque="'. html_escape($paycheque).'",'
                        . 'amount="'. html_escape($amountArr[$i]).'",remitted="'.html_escape($remitArr[$i]).'",'
                        . 'refundamount="'. html_escape($refundArr[$i]).'",gstrefund="'.html_escape($gstrefundArr[$i]).'",'
                        . 'refundtotal="'. html_escape($refundtotalArr[$i]).'",reason="'.html_escape($reason).'",created_at="'.date('Y-m-d H:i:s').'",'
                        . 'paymode="'. html_escape($paymode).'",paydescription="'.html_escape($pdescription).'" '
                        . 'where stupayid="'.html_escape($rowArr[$i]).'" and refundappid="'.html_escape($refundid).'"'); 
               
            if($reason=== 'discontinue') {
                
                
                $discount = floatval($refundArr[$i]);
                $amt = floatval($amountArr[$i]);
                $total = floatval($amt)- floatval($discount);
                $gstTotal = floatval($total)*1.18;
                $gstTotal = round($gstTotal);

                
                $this-> db -> query('update `bscp_student_payments` set reason="discontinue",discount="'.$discount.'",total="'.$gstTotal.'" where id="'.$rowArr[$i].'"'); 
                $this-> db -> query('delete from `bscp_feepayments` where stupayid="'.$rowArr[$i].'" and paymentstatus!="p"');
                
                
            }
             
         }
         
         $this->load->model('login_model','',TRUE);
         $user = $this->login_model->GetUserId();
         $this-> db -> query('UPDATE `bscp_refundapplication` SET status="'.$status.'", updated_by = "'.$user['name'].'" WHERE id="'.$refundid.'"');
        
         return true;
        
        
    }
    
    
    
     public function ViewRefundPaymentLists($id) {
        
                $reason['scholarship'] = "Scholarship";
                $reason['faid'] = "Financial Aid";
                $reason['discontinue'] = "Discontinue";
                $reason['berror'] = "Billing Error";
                $reason['others'] = "Others";
                $reason['excessfeeremit'] = "Excess Fee Remit";
                
                $paymode['cash'] = "Cash";
                $paymode['dd'] = "Demand Draft";
                $paymode['net'] = "Bank Transfer";
                $paymode['cheque'] = "Cheque";
                
               $selectQuery = 'SELECT st.studid,st.sname,DATE_FORMAT(a.created_at,"%d-%m-%Y %h:%i %p") as created_at,a.receiptno,a.stupayid,a.reason,a.paymode,a.gstrefund,a.refundtotal,a.paydescription,a.paydate,a.paycheque,b.description,b.desc_order,a.amount,a.remitted,a.refundamount from bscp_refund as a LEFT JOIN bscp_student_payments as b on a.stupayid=b.id left join bscp_student as st on st.id=a.studentid where a.refundappid="'.$id.'" group by a.stupayid order by b.desc_order';
		
              $html = ""; $html1=""; $tableRow = ""; $j = 1;$amt=0;$remit=0;$refundamt=0;
            $query0 = $this-> db -> query($selectQuery);
            $row = $query0->result_array();
            for($i=0; $i < count($row); $i++){
                
              
                if($i === 0){
                    
                    //$reason = $reason[$row[$i]['reason']]; 
                   // $paymode = $paymode[$row[$i]['paymode']]; 
                    
                    foreach($reason as $key=>$val){
                        
                        if($key === $row[$i]['reason']){
                            $selected="selected";
                        }
                        $reasonHtml .= '<option '.$selected.' value="'.$key.'">'.$val."</option>";
                        $selected = "";
                    }
                    
                     foreach($paymode as $key=>$val){
                        
                        if($key === $row[$i]['paymode']){
                            $selected="selected";
                        }
                        $paymodeHtml .= '<option '.$selected.' value="'.$key.'">'.$val."</option>";
                        $selected = "";
                    }
                             
                
                    $html = ' <div class="row refundContainer" data-student="'.$row[$i]['sname'].'" data-studid="'.$row[$i]['studid'].'" style="width: 98%;margin: 0px auto;margin-top: 25px;">
                <div class="col-12 col-sm-4" >
                    <div class="form-group position-relative error-l-50 floating">
                      <input type="text" class="form-control" value="'.$row[$i]['created_at'].'"  >
                     <label for="date">Date <span>*</span></label>
                    </div>
		</div>
               
                <div class="col-12 col-sm-4">
              <div class="form-group position-relative error-l-50 floating"><select class="form-control paymode floating" id="editpaymode" name="paymode" required  >
                '.$paymodeHtml.'</select>
                <label>Mode Of Refund<span>*</span></label>
              </div>
              </div>
               <div class="col-12 col-sm-4">
                    <div class="form-group position-relative error-l-50 floating"><select class="form-control reason floating" id="editreason" name="reason" required  >
               '.$reasonHtml.'</select>
                     
                <label>Reasons<span>*</span></label>
              </div>
		</div> 
                
                <div class="col-12 col-sm-4 mt-2">
                    <div class="form-group position-relative error-l-50 floating">
                      <input type="text" class="form-control " id="editprefno" value="'.$row[$i]['paydescription'].'" >
                     <label for="date">Pay Reference No <span>*</span></label>
                    </div>
		</div>  
                <div class="col-12 col-sm-4 mt-2">
                    <div class="form-group position-relative error-l-50 floating">
                      <input type="text" class="form-control " id="editchequeno" value="'.$row[$i]['paycheque'].'" >
                     <label for="date">Cheque No <span>*</span></label>
                    </div>
		</div> 
                 <div class="col-12 col-sm-4 mt-2">
                    <div class="form-group position-relative error-l-50 floating">
                      <input type="text" class="form-control " id="editprefnodate" value="'.$row[$i]['paydate'].'" >
                     <label for="date">Cheque Date <span>*</span></label>
                    </div>
		</div>  
                <div class="col-12 col-sm-4 mt-2">
                    <div class="form-group position-relative error-l-50 floating">
                      <input type="text" class="form-control prefno" value="'.$row[$i]['receiptno'].'" >
                     <label for="date">Refund Bill No <span>*</span></label>
                    </div>
		</div>  
            </div>
	  
          <table class="reportsTable">
          <thead><tr><th>S.No</th><th>Description</th><th>Amount</th><th>Remitted</th><th>Deduction</th><th>Refund Net</th><th>GST Refund </th><th>Refund Total</th></tr></thead>
          <tbody>';
                    
                }
                
                $tableRow .= '<tr><td>'.$j.'</td><td class="desc" attr-descid="'.$row[$i]['stupayid'].'">'.$row[$i]['description'].'</td><td><span class="amount">'.$row[$i]['amount'].'</span></td><td><span class="paid">'.$row[$i]['remitted'].'</span></td><td><input class="refundamt" style="width: 100px;height: auto;border: 1px solid #ccc;padding: 5px;" type="text"  value="'.(floatval($row[$i]['remitted'])-floatval($row[$i]['refundamount'])).'"></td><td><span class="refundnet">'.$row[$i]['refundamount'].'</span></td><td><span class="gstrefund">'.$row[$i]['gstrefund'].'</span></td><td ><span class="refundtotal">'.$row[$i]['refundtotal'].'</span></td></tr>';
                
                $amt = floatval($amt)+floatval($row[$i]['amount']);
                $remit = floatval($remit)+floatval($row[$i]['remitted']);
                $refundamt = floatval($refundamt)+floatval($row[$i]['refundamount']);
                $refundtotal = floatval($refundtotal)+floatval($row[$i]['refundtotal']);
                $j++;
            }
            
            $query = $this ->db->query('select a.remarks,a.status,b.sname,b.studid from bscp_refundapplication as a LEFT JOIN bscp_student as b on a.studentid=b.id where a.id="'.$id.'"');
            $remarksrow = $query->result_array();
            
            $html1 = '</tbody></table><div class="row refundContainer" data-student="'.$remarksrow[0]['sname'].'" data-studid="'.$remarksrow[0]['studid'].'" style="width: 98%">

									<div class="col-md-12 text-right px-2">
                                                                            <p class="list-item-heading mb-1" style="visibility:hidden"> <span>Total Remitted Amount:</span> <span class="premit" style="color: #1C47B3 !important">'.$remit.'</span></p>
									</div>

									<div class="col-md-12 text-right px-2 mb-2">
										<p class="list-item-heading mb-1"><span> Total Refund Amount:</span> <span data-status= "'.$remarksrow[0]['status'].'" class="prefund" style="color: #D63333 !important">'.$refundtotal.'</span></p>
                                                                                    <input type="hidden" id="refundid" value="'.$id.'"/>
									</div>
                                                                        <div class="col-md-12  px-2">
                                                                                <p class="mt-3 ml-3" > <span>Remarks:</span> <span class="premit" style="color: #1C47B3 !important">'.$remarksrow[0]['remarks'].'</span></p>
                                                                         </div>

								</div>';
            
            if($tableRow ===""){
                
                $html1 ='</tbody></table><div class="row refundContainer" data-student="'.$remarksrow[0]['sname'].'" data-studid="'.$remarksrow[0]['studid'].'" style="width: 98%">
                    <div class="col-md-12  px-2">
                    <p class="mt-3 ml-3" > <span>Remarks:</span> <span class="premit" style="color: #1C47B3 !important">'.$remarksrow[0]['remarks'].'</span></p>
                    </div></div>';
            }
            
            $htmlFinal = $html.$tableRow.$html1;
            return $htmlFinal;
		
    }
    
    public function GetRefundDataForPrint($ide) {
        
        $refundArr['appno'] = "";$refundArr['sname'] = "";$refundArr['guardianname'] = "";
        $refundArr['userid'] = ""; $refundArr['coursename'] = ""; $refundArr['center'] = "";
        $refundArr['caddress'] = ""; $refundArr['mobileno'] = ""; $refundArr['fmobile'] = "";
        $refundArr['remitted'] = "";$refundArr['rdate'] = "";$refundArr['reason'] = "";
        $refundArr['accountholdername'] = ""; $refundArr['bankname '] = ""; $refundArr['branch '] = "";
        $refundArr['ifsccode'] = ""; $refundArr['bankaccountno'] = ""; 
        $query = $this ->db->query('select ra.*,s.studid,s.sname,s.contact,c.coursename,sp.guardianname,sp.fatherphone,sp.fathercode from bscp_refundapplication as ra LEFT JOIN bscp_student as s ON s.id=ra.studentid LEFT JOIN admin_course as c ON c.ide=ra.courseid LEFT JOIN bscp_studentprofile as sp ON sp.stuid=ra.studentid where ra.id="'.$ide.'"');
        $row = $query->result_array();
        for($i=0; $i < count($row); $i++){
        
            $refundArr['appno'] = $row[$i]['appno']; $refundArr['studentid'] = $row[$i]['studentid'];
            $refundArr['sname'] = $row[$i]['sname'];$refundArr['ide'] = $ide;
            $refundArr['userid'] = $row[$i]['studid']; $refundArr['coursename'] = $row[$i]['coursename']; $refundArr['center'] = $row[$i]['center'];
            $refundArr['guardianname'] = $row[$i]['guardianname'];
            $refundArr['caddress'] = $row[$i]['housenameno'].",".$row[$i]['contactaddress'].",".$row[$i]['contactpost'].",".$row[$i]['contactdistrict'].",".$row[$i]['contactstate'].",".$row[$i]['contactcountry']." - ".$row[$i]['contactpincode'];
            $refundArr['mobileno'] = $row[$i]['contact'];
            $refundArr['fmobile'] = $row[$i]['fathercode']." ".$row[$i]['fatherphone'];
            $refundArr['rdate'] = $row[$i]['created_at'];$refundArr['reason'] =$row[$i]['reason'];
            $refundArr['accountholdername'] = $row[$i]['accountholdername']; $refundArr['bankname'] = $row[$i]['bankname']; 
            $refundArr['branch'] = $row[$i]['branch'];$refundArr['ifsccode'] = $row[$i]['ifsccode'];
            $refundArr['bankaccountno'] = $row[$i]['bankaccountno']; 
            $refundArr['doj'] = $row[$i]['doj']; 
            $refundArr['batch'] = $row[$i]['batch']; 
            
            $query1 = $this ->db->query('select sum(paymentamount) as paid from bscp_refundapplication as ra LEFT JOIN bscp_feepayments as a ON a.requestid=ra.requestid where ra.id="'.$ide.'" and a.paymentstatus="p"');
            $row1 = $query1->result_array();
            $refundArr['remitted'] = $row1[0]['paid'];
            
             //update refund status  to student
            if($row[$i]['status'] === 'w') {
                $query2 = $this-> db -> query('UPDATE `bscp_refundapplication` SET `status`="p" WHERE id="'.$ide.'"');
                $query3 = $this-> db -> query('update `bscp_courserequest` set refund="3" where ide="'.$row[$i]['requestid'].'"');
            }
        }	
            
        return $refundArr;
    }
    
    
    public function ChangeRefundStatus($ide,$status,$cride,$remarks){
        
        $qData = array(
              'status' => $status,
             'remarks' => $remarks,
               'id' => $ide);
          $query1 = $this->db->update('bscp_refundapplication', $qData, array('id' => $qData['id']));
          
           //update refund status  to student
            if($status === 'n') {      
                $query3 = $this-> db -> query('update `bscp_courserequest` set refund="5" where ide="'.$cride.'"');
            }if($status === 'cd') {      
                $query3 = $this-> db -> query('update `bscp_courserequest` set refund="6" where ide="'.$cride.'"');
            }
        //$query1 = $this-> db -> query('update `admin_course` set status="'.$status.'" where ide="'.$ide.'"');
        if($query1) {
            $result = array(0 => "success");
        } else {
            $result = array(0 => "fail");
        }
        
        return $result; 
        
        
    }
    
    
    	public function GetRefundBill($refundid){
				
		$arr = array();
                $paymode['cash'] = "Cash";
                $paymode['dd'] = "Demand Draft";
                $paymode['net'] = "Bank Transfer";
                $paymode['cheque'] = "Cheque";
                
		$arr['studentdetails'] = array();
	
		$query = $this-> db -> query('select d.appno,re.paydescription,re.paydate,re.paycheque,re.paymode,re.created_at,b.studid,re.studentid,re.center,re.receiptno,sum(re.refundtotal) as refundtotal,sum(re.refundamount) as refundamount,sum(re.gstrefund) as gstrefund,c.coursename from bscp_refund as re left join admin_course as c on c.ide=re.courseid left join bscp_student as b on b.id=re.studentid left join bscp_refundapplication as d on d.id=re.refundappid where re.refundappid="'.$refundid.'" group by receiptno');
		$row = $query->result_array();
		
		if($query->num_rows()>0){
                    
                     for($i=0; $i < count($row); $i++){
                         $arr['receiptno'] = $row[$i]['appno'];
                         $arr['refundtotal'] = $row[$i]['refundtotal'];
                         $arr['refundamount'] = $row[$i]['refundamount'];
                         $arr['coursename'] = $row[$i]['coursename'];
                         $arr['center'] = $row[$i]['center'];
                         $arr['studid'] = $row[$i]['studid'];
                         $arr['paymode'] = $paymode[$row[$i]['paymode']];
                         $arr['paydescription'] = $row[$i]['paydescription'];
                         $arr['paydate'] = $row[$i]['paydate'];
                         $arr['paycheque'] = $row[$i]['paycheque'];
                         $arr['created_at'] = $row[$i]['created_at'];
                         $taxwithgst = floatval($row[$i]['gstrefund']);
                         $taxwithgst = floatval($taxwithgst)/2;
                         
                         $brf  = $taxwithgst;
                         $arf = round($taxwithgst);
                         $psamt = floatval($arf) - floatval($brf);
                         $psamt = number_format($psamt,2);
                         $arr['cgst'] = round($taxwithgst);
                         $arr['sgst'] = round($taxwithgst);
                         $arr['pcgst'] = 0;
                         $arr['psgst'] = 0;
                    						
			$query3 = $this-> db -> query('select * from bscp_studentprofile where stuid="'.$row[$i]['studentid'].'"');
			$row3 = $query3->result_array();

			if($query3->num_rows()===1){

				$arr['studentdetails'] = $row3[0];

			}
                    }
			
		}

            return $arr;   
   }
   
   public function CourseRequestRefundStatus($crid)
    {
         
              $status = "";
              $query = $this-> db -> query('select refund from bscp_courserequest where ide="'.$crid.'"');
                $row = $query->result_array();
                if ($query->num_rows()>0) {
                     $status = $row[0]['refund'];
                }
             
         return $status;
       
    }
    
    
    public function AddBankDetails($ide,$bankname,$branch,$ifsccode,$bankaccountno) {
        
               
           $this-> db -> query('update `bscp_refundapplication` set bankname ="'. html_escape($bankname).'",branch ="'. html_escape($branch).'",'
                        . 'ifsccode="'. html_escape($ifsccode).'",bankaccountno ="'.html_escape($bankaccountno).'" where id="'.html_escape($ide).'"'); 
               
           return true;
        
    }
    
    
    public function GetStudentRefundLists($userid) {
        
         $this->datatables->select('bscp_refundapplication.status as status,bscp_refundapplication.remarks as remarks,bscp_refundapplication.center as center,bscp_refundapplication.appno as appno,admin_course.coursename as coursename,'
                 . 'sum(bscp_refund.remitted) as remitted,sum(bscp_refund.remitted - bscp_refund.refundamount) as deduction,sum(bscp_refund.gstrefund) as gstrefund,sum(bscp_refund.refundamount) as refundamount,sum(bscp_refund.refundtotal) as refundtotal') 
                ->edit_column('status', '$1', 'check_refundstatus(status)')
                 ->from('bscp_refundapplication')->where('bscp_refundapplication.studentid',$userid)->where('bscp_refundapplication.status != "w"')->where('bscp_refundapplication.status != "p"')
                ->join('admin_course', 'admin_course.ide=bscp_refundapplication.courseid', 'left')
                ->join('bscp_refund', 'bscp_refund.refundappid=bscp_refundapplication.id', 'left')->group_by('bscp_refundapplication.appno');
                
                $table =  $this->datatables->generate();
                
                return $table;
        
    }
    

}

?>
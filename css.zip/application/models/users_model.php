<?php
Class Users_Model extends CI_Model {
    
     public function __construct() {
        
       $this->load->library('Datatables');
		 $this->load->helper('My_datatable_helper');
  
    }
    
    public function GetInactiveUsers() {
        
        $arr = Array();
		
		$arr['list'] = "";
		
		$roleaccess = $this->config->item('roleaccess');
	
                //$this->datatables->set_database("default");
	    $this->datatables->select('name,id,username,email,mobile,role,active,REPLACE(centers,"|",",") as centers,REPLACE(courses,"|",",") as courses,created_at',FALSE) 
            ->edit_column('username', '$1', 'check_useractiveedit(id,username,"'.$roleaccess['User Activation'][1].'")')
            ->edit_column('active', '$1', 'check_usersactivestatus(id,active,"'.$roleaccess['User Activation'][1].'")')
            ->edit_column('id', '$1', 'check_useractiveactions(id,"'.$roleaccess['User Activation'][1].'","'.$roleaccess['User Activation'][2].'")')
            ->edit_column('created_at', '<p class="sno"></p>', '')->from('typo_users')->where('role != "student"')->where('active = "w"');
            
                
                $table =  $this->datatables->generate();
		
		return $table;
        
    }
	
    
    public function GetAdminUsers() {
        
        $arr = Array();
		
		$arr['list'] = "";
		
		$roleaccess = $this->config->item('roleaccess');
	
                //$this->datatables->set_database("default");
	    $this->datatables->select('name,id,username,email,mobile,role,active,REPLACE(centers,"|",",") as centers,REPLACE(lcenters,"|",",") as lcenters,REPLACE(courses,"|",",") as courses,created_at',FALSE) 
            ->edit_column('username', '$1', 'check_usersedit(id,username,"'.$roleaccess['Users'][1].'")')
            ->edit_column('active', '$1', 'check_usersactive(id,active,"'.$roleaccess['Users'][1].'")')
            ->edit_column('id', '$1', 'check_userseditdelete(id,"'.$roleaccess['Users'][1].'","'.$roleaccess['Users'][2].'")')
            ->edit_column('created_at', '<p class="sno"></p>', '')->from('typo_users')->where('role != "student"');
            
                
                $table =  $this->datatables->generate();
		
		return $table;
        
    }
    
     public function ChangeUserStatus($ide,$status){
        
        $query1 = $this-> db -> query('update `typo_users` set active="'.$status.'" where id="'.$ide.'"');
        if($query1) {
            $result = array(0 => "success");
        } else {
            $result = array(0 => "fail");
        }
        
        return $result; 
        
        
    }
    
    public function GetGroups() {
        
        $arr = Array();
		
		$arr['list'] = "";
	
		$roleaccess = $this->config->item('roleaccess');
		
                //$this->datatables->set_database("default");
	    $this->datatables->select('groupid,gname,gtype') 
            ->edit_column('gname', '$1', 'check_usergroupedit(groupid,gname,"'.$roleaccess['User Group'][1].'")')
            ->edit_column('gtype', '<span class="noedit gtype" style="float:left;padding:0px;font-size:15px;text-align:left;line-height:20px">$1</span>', 'gtype')
            ->edit_column('groupid', '$1', 'check_usergroupactions(groupid,"'.$roleaccess['User Group'][1].'","'.$roleaccess['User Group'][2].'")')
            ->edit_column('created_at', '<p class="sno"></p>', '')->from('typo_groups')->group_by('gname');
            
                
                $table =  $this->datatables->generate();
		
		return $table;
        
    }
    
    
    public function FetchMasterModuleAccess($inp) {
        
        $arr = Array();
		
		$arr['list'] = "";
	
                //$this->datatables->set_database("default");
	    $this->datatables->select('id,access,uadd,uedit,udelete,uview,udefaultpage') 
            ->edit_column('uadd', '<input class="uadd" value="$2" name="add-'.$inp.'-$1" type="checkbox" data-type="add" data-access="$1"data-module="'.$inp.'">', 'access,uadd')
            ->edit_column('uedit', '<input class="uothers uedit" value="$2" name="edit-'.$inp.'-$1" type="checkbox" data-type="adit" data-access="$1"data-module="'.$inp.'">', 'access,uedit')
            ->edit_column('udelete', '<input class="uothers udelete" value="$2" name="del-'.$inp.'-$1" type="checkbox" data-type="delete" data-access="$1"data-module="'.$inp.'">', 'access,udelete')
            ->edit_column('uview', '<input class="uothers uview" value="$2" name="view-'.$inp.'-$1" type="checkbox" data-type="view" data-access="$1"data-module="'.$inp.'">', 'access,uview')
            ->edit_column('udefaultpage', '<input class="dpage" value="$2" name="dpage" type="radio" data-type="dpage" data-access="$1"data-module="'.$inp.'">', 'access,udefaultpage')
            ->edit_column('id', '<p class="sno"></p>', '')->from('typo_groupmaster')->where("module","$inp");
            
            $table =  $this->datatables->generate();
            return $table;
        
    }
    
    public function GetGroupName($id) {
        $gArr =Array("name"=>"","type"=>"");
        $query = $this-> db -> query('select `gname`,`gtype` from typo_groups where groupid="'.$id.'" group by groupid') ;
		
	if($query->num_rows()>0)
        {
            $row = $query->result_array();
            $gArr["name"] = $row[0]['gname'];
            $gArr["type"] = $row[0]['gtype'];
        }
         return $gArr;
        
    }
    
    public function FetchGroupAccess($inp) {
        
        $grpArr=Array();
        $query = $this-> db -> query('select groupid,gname,module,access,uadd,uedit,udelete,uview,udefaultpage from typo_groups where groupid="'.$inp.'"') ;
		
	if($query->num_rows()>0)
        {
            $row = $query->result_array();
          /*  for($i=0;$i<count($row);$i++){
                if(!array_key_exists($row[$i]['module'], $grpArr)){
                        $grpArr[$row[$i]['module']]=Array();
                        
                    } 
                    
                    $module=$row[$i]['module'];
                    $access = $row[$i]['access'];
                if(!array_key_exists($access, $grpArr[$module])){
                        $grpArr[$module][$access]['access'] = $access; 
                        $grpArr[$module][$access]['add'] = $row[$i]['uadd'];
                        $grpArr[$module][$access]['edit'] = $row[$i]['uedit'];
                        $grpArr[$module][$access]['delete'] = $row[$i]['udelete'];
                        $grpArr[$module][$access]['view'] =  $row[$i]['uview'];
                        $grpArr[$module][$access]['dpage'] =  $row[$i]['udefaultpage'];
                } 
            }*/
            
        }
        
        return $row;  
    }


    public function AddUser($qData){
		
		
        $this->db->insert('typo_users', $qData);
        return $this->db->insert_id();	
		
    }
	
 public function EditUser($ide) {
        
        $arr['id']= "";  $arr['username']= "";$arr['mobile']= "";$arr['role']= "";
        $arr['email']= ""; $arr['centers']= ""; $arr['courses']= "";$arr['name']= "";
        
        $query1 = $this-> db -> query('select id,name,username,mobile,role,email,centers,courses,msession from typo_users where id="'.$ide.'"');
	$row = $query1->result_array();
        if ($query1 ->num_rows()) {
            
            $arr['username']=$row[0]['username'];
            $arr['id']=$row[0]['id'];
            $arr['mobile']=$row[0]['mobile'];
            $arr['role']=$row[0]['role'];
            $arr['email']=$row[0]['email'];
            $arr['centers']=$row[0]['centers'];
            $arr['courses']=$row[0]['courses'];
            $arr['name']=$row[0]['name'];
            $arr['msession']=$row[0]['msession'];
          
            
        }     
       
        return $arr;
        
    }
	
    
    public function UpdateUser($pname,$username,$mobile,$groups,$email,$centers,$lcenters,$courses,$userid,$msession){
        
        $username = $username."@brilliantpala.org";
        $query1 = $this-> db -> query('update `typo_users` set name="'.$pname.'",username="'.$username.'",mobile="'.$mobile.'",role="'.$groups.'"'
                . ',email="'.$email.'",centers="'.$centers.'",lcenters="'.$lcenters.'",courses="'.$courses.'",msession="'.$msession.'" where id="'.$userid.'"');
        
         $response = array(
                'status' => 'success',
                'message' => "User Updated Successfully."
            );

          return $response;
        
    }
    
    public function UpdateUserCredentials($ide,$status){
        
        $this->load->helper('string');
        
        $salt = $this->config->item('pass_salt');
        $cnt = rand(8,12);
        $password = random_string('alnum', $cnt); //admin
        $aencrpassword = SHA1($salt.$password);
        
        $query1 = $this-> db -> query('update `typo_users` set password="'.$aencrpassword.'",active="'.$status.'" where id="'.$ide.'"');
        
        $this->load->model('notification_model','',TRUE);
        $this->notification_model->SendAdminUserCredentails($ide,$password);
        
         $response = array(
                '0' => 'success'
            );

          return $response;
        
    }


    public function DeleteUser($ide){
        
        $query1 = $this-> db -> query('delete from `typo_users` where id="'.$ide.'"');
        if($query1) {
            
            $result = array(0 => "success");
        } else {
            $result = array(0 => "fail");
        }
        
        return $result; 
        
        
    }
    
     public function InsertGroup($qData)
    {
        $this->db->insert('typo_groups', $qData);
        return $this->db->insert_id();
    }
    
    
      public function DeleteGroup($groupid)
    {
         
         $query1 = $this-> db -> query('delete from `typo_groups` where groupid="'.$groupid.'"');
         if($query1) {
            
            $result = array(0 => "success");
        } else {
            $result = array(0 => "fail");
        }
        return $result; 
    }
    
        public function GetAllGroups($inp,$type){
        
        $retHTML = "";
        $selected="";     
        $query2 = $this-> db -> query('select * from typo_groups group by gname');
	$row = $query2->result_array();
        if ($row) {
            
                for($i=0 ; $i < count($row);$i++) {
                    if( ($row[$i]["gname"] == $inp) || ((strpos($inp,$row[$i]["gname"]) !== false))) {
                        $selected = 'selected=selected';
                    }
                    
                    if($type === "option"){
                        $retHTML .= "<option ".$selected." data-type='".$row[$i]["gtype"]."'>".$row[$i]["gname"]."</option>";
                    } 
                   $selected = "";
                }
                
        }
        
        return $retHTML;
        
    }
    
     public function GetCCenters(){
        
		 	$roleaccess = $this->config->item('roleaccess');
		 
    	    $this->datatables->select('created_at,sno,name,id') 
            ->edit_column('id', '$1', 'check_userbrancheditdelete(id,name,"'.$roleaccess['uedit'].'","'.$roleaccess['udelete'].'")')
            ->edit_column('name', '<span>$1</a>', 'name')                          
            ->from('bscp_ccenters');
            
            $table =  $this->datatables->generate();
            return $table;
    
    }
    
     public function InsertCCenter($qData)
    {
        $this->db->insert('bscp_ccenters', $qData);
        return $this->db->insert_id();
    }
    
    
    public function UpdateCCenter($qData)
    {
        $this->db->update('bscp_ccenters', $qData, array('id' => $qData['id']));
        
    }
    
        public function DelCenters($ide){
        
    	    $query1 = $this-> db -> query('delete from `bscp_ccenters` where id="'.$ide.'"');
        if($query1) {
            $result = array(0 => "success");
        } else {
            $result = array(0 => "fail");
        }
        
        return $result; 
    
    }
    
     public function GetAllCenters($inp,$type){
        
        $retHTML = "";
        $selected="";
         $query2 = $this-> db -> query('select * from bscp_ccenters');
	$row = $query2->result_array();
        if ($row) {
            
                for($i=0 ; $i < count($row);$i++) {
                    if( ($row[$i]["name"] == $inp) || ((strpos($inp,$row[$i]["name"]) !== false))) {
                        $selected = 'selected=selected';
                    }
                    
                    if($type === "option"){
                        $retHTML .= "<option ".$selected.">".$row[$i]["name"]."</option>";
                    } else if($type === "array") {
						if($i==0)$retHTML = array();
                        array_push($retHTML,$row[$i]["name"]);
                    } else {
                        $retHTML .= "<li ".$selected."><label style=\"text-align: left;color:#536485;background: none;border: 0px;width: auto;height: auto;float:left;font-size: 15px\"><input class=\"radiocenters\" attr-centers=\"".$row[$i]["name"]."\" name=\"radiocenters\" type=\"radio\" />".$row[$i]["name"]."</li></label>";
                    }
                   $selected = "";
                }
                
        }
        
        return $retHTML;
        
    }
    
    public function GetGroupType($gid) {
        
        $type="";
        $query2 = $this-> db -> query('select gtype from typo_groups where gname="'.$gid.'" group by gname');
	$row = $query2->result_array();
        if ($row) {
            $type = $row[0]['gtype'];
        }
        
        return $type;
        
    }
    
     public function GetAllBatches($inp){
       
		 $this->load->model('login_model','',TRUE);
		$user = $this->login_model->GetUserId();
				
		$keywords_imploded = "";
		if(!empty($user['batches']) && !in_array("All", $user['batches'])){
			
			$keywords_imploded = ' and batchname IN ("'.implode('","',$user['batches']).'")';
			
		}
		 
        $query2 = $this-> db -> query('select batchname from bscp_batches where del="n" '.$keywords_imploded.' group by batchname');
	$row = $query2->result_array();
        
        $retHTML = "";
        $selected="";
        $inpArray =explode("|",$inp);
        if ($row) {
            
                for($i=0 ; $i < count($row);$i++) {
                    if(in_array($row[$i]["batchname"], $inpArray)) {
                        $selected = 'selected=selected';
                    }
                    
                    $retHTML .= "<option value='".$row[$i]["batchname"]."'" .$selected.">".$row[$i]["batchname"]."</option>";
                   $selected = "";
                }
                
        }
        return $retHTML;       
   }
	
	public function UpdatePassword($qData,$oldpassword)
    {
		$query2 = $this-> db -> query('select id,password from typo_users where id="'.$qData['id'].'"');
		$row = $query2->result_array();
		
		if($query2->num_rows()>0){
			
			 $encroldpassword = SHA1($this->config->item('pass_salt').$oldpassword);
			 $password=$row[0]['password'];
			
			if($encroldpassword==$password){
				$this->db->update('typo_users', $qData, array('id' => $qData['id']));
				return true;
			}
						 
		}
		
       return false;
        
    }
	
	
	// Staff
	
	
	  public function AddStaff($qData){
		
		
        $this->db->insert('bscp_staffs', $qData);
        return $this->db->insert_id();	
		
    }
	
 public function EditStaff($ide) {
        
        $arr['id'] = $arr['staffname'] = "";$arr['staffmobile'] = $arr['staffemail'] = $arr['status'] = "";
        
        $query1 = $this-> db -> query('select id,staffname,mcode,staffmobile,staffemail,status from bscp_staffs where id="'.$ide.'"');
		$row = $query1->result_array();
        if ($query1 ->num_rows()) {
            
            $arr['staffname']=$row[0]['staffname'];
            $arr['id']=$row[0]['id'];
            $arr['staffmobile']=$row[0]['staffmobile'];
            $arr['mcode']=$row[0]['mcode'];
            $arr['staffemail']=$row[0]['staffemail'];
            $arr['status']=$row[0]['status'];
          
            
        }     
       
        return $arr;
        
    }
	
    
    public function UpdateStaff($staffid,$staffname,$staffmobile,$staffemail){
        
        $query1 = $this-> db -> query('update `bscp_staffs` set staffname="'.$staffname.'",staffemail="'.$staffemail.'",staffmobile="'.$staffmobile.'" where id="'.$staffid.'"');
        
         	$response = array(
                'status' => 'success',
                'message' => "Staff Updated Successfully."
            );

          return $response;
        
    }
	
	public function GetAdminStaffs() {
        
        $arr = Array();
		
		$arr['list'] = "";
		
		$roleaccess = $this->config->item('roleaccess');
	
                //$this->datatables->set_database("default");
	    $this->datatables->select('staffname,id,staffemail,staffmobile,created_at') 
            ->edit_column('staffname', '$1', 'check_staffedit(id,staffname,"'.$roleaccess['Staffs'][1].'")')
            ->edit_column('id', '$1', 'check_staffeditdelete(id,"'.$roleaccess['Staffs'][1].'","'.$roleaccess['Staffs'][2].'")')
            ->edit_column('created_at', '<p class="sno"></p>', '')->from('bscp_staffs');
            
                $table =  $this->datatables->generate();
		
		return $table;
        
    }
	
	 public function DeleteStaff($ide){
        
        $query1 = $this-> db -> query('delete from `bscp_staffs` where id="'.$ide.'"');
        if($query1) {
            
            $result = array(0 => "success");
        } else {
            $result = array(0 => "fail");
        }
        
        return $result; 
        
        
    }
	
}
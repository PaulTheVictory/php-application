<?php
Class Library_Model extends CI_Model {
    
     public function __construct() {
        
       $this->load->library('Datatables');
		 $this->load->helper('My_datatable_helper');
  
    }
    
    public function GetBooks() {
        
        $arr = Array();
		
		$arr['list'] = "";
		
		$roleaccess = $this->config->item('roleaccess');
	
	    $this->datatables->select('id,bookname,edition,author,publisher,status,created,isbn_number') 
			->edit_column('status', '$1', 'check_bookstock(id)')
            ->edit_column('bookname', '$1', 'check_bookedit(id,bookname,"'.$roleaccess['Library Books'][3].'")')
			 ->edit_column('id', '$1', 'check_bookview(id,"'.$roleaccess['Library Books'][3].'","'.$roleaccess['Library Books'][1].'","'.$roleaccess['Library Books'][2].'")')
            ->edit_column('created', '<p class="sno"></p>', '')->from('bscp_library_books')->where('status = "a"');
            
                
                $table =  $this->datatables->generate();
		
		return $table;
        
    }
	
  
    public function InsertBook($qData)
    {
		$query = $this-> db -> query('select id from bscp_library_books where isbn_number="'.$qData['isbn_number'].'" and isbn_number<>"" and isbn_number<>"NO ISBN"');
		$row = $query->result_array();
        if ($query->num_rows()===0) {
			
			$this->db->insert('bscp_library_books', $qData);
			return "success";
			
		}else{
			return "exists";
		}
		
    }
    
     public function UpdateBook($qData)
    {
		$query = $this-> db -> query('select id from bscp_library_books where isbn_number="'.$qData['isbn_number'].'" and isbn_number<>"" and id!="'.$qData['id'].'" and isbn_number<>"NO ISBN"');
		$row = $query->result_array();
        if ($query->num_rows()===0) {
			
			$this->db->update('bscp_library_books', $qData, array('id' => $qData['id']));
			return "success";
			
		}else{
			return "exists";
		}
        
    }
	
	public function BookDetails($id) {
        
        $arr['id'] = $arr['bookname'] = $arr['isbn_number'] = $arr['author'] = $arr['publisher'] = $arr['category'] = $arr['edition'] = $arr['dueperiod'] = $arr['price'] = $arr['created']= $arr['stream'] = $arr['supplier'] = "";
        
        $query1 = $this-> db -> query('select * from bscp_library_books where id="'.$id.'"');
		$row = $query1->result_array();
        if ($query1 ->num_rows()) {
            
			$arr['ide']=$row[0]['id'];
            $arr['bookname']=$row[0]['bookname'];
            $arr['isbn_number']=$row[0]['isbn_number'];
            $arr['author']=$row[0]['author'];
            $arr['publisher']=$row[0]['publisher'];
            $arr['category']=$row[0]['category'];
            $arr['edition']=$row[0]['edition'];
            $arr['dueperiod']=$row[0]['dueperiod'];
            $arr['price']=$row[0]['price'];
            $arr['created']=$row[0]['created'];
            $arr['stream']=$row[0]['stream'];
            $arr['supplier']=$row[0]['supplier'];
         
        }
              
       
        return $arr;
        
    }
	
	 public function GetBookStock($bookid,$lcenters=array()) {
        
        $arr = Array();
		
		$arr['list'] = $where = "";
		 
		 if(!empty($lcenters) && !in_array("All", $lcenters)) $where .= ' and center IN ("'.implode('","',$lcenters).'") ';
		
		$roleaccess = $this->config->item('roleaccess');
	
	    $this->datatables->select('id,bookid,center,barcode,barcode as tstock,created_at,booktype as library,booktype as reference,booktype') 
			 ->edit_column('id', '$1', 'check_bookstockview(bookid,center,booktype,"'.$roleaccess['Library Books'][3].'","'.$roleaccess['Library Books'][2].'")')
			->edit_column('tstock', '$1', 'check_bookcenterstock(bookid,center)')
			->edit_column('library', '$1', 'check_booktypestock(bookid,center)')
			->edit_column('reference', '$1', 'check_booktypestock2(bookid,center)')
            ->edit_column('created_at', '<p class="sno"></p>', '')->from('bscp_bookstock')->where('bookid = "'.$bookid.'"'.$where)
			->group_by('center');
            
                
                $table =  $this->datatables->generate();
		
		return $table;
        
    }
	
	public function GetBookStockCenter($bookid,$center) {
        
        $arr = Array();
		
		$arr['list'] = "";
		
		$roleaccess = $this->config->item('roleaccess');
	
	    $this->datatables->select('id,bookid,center,barcode,created_at,price,booktype') 
			 ->edit_column('id', '$1', 'check_bookstockcenterview(id,bookid,price,"'.$roleaccess['Add Stock'][1].'","'.$roleaccess['Add Stock'][2].'")')
            ->edit_column('created_at', '<p class="sno"></p>', '')->from('bscp_bookstock')->where('bookid = "'.$bookid.'" and center = "'.$center.'"');
            
                
                $table =  $this->datatables->generate();
		
		return $table;
        
    }
	
	 public function InsertBookStock($qData)
    {
		$query = $this-> db -> query('select id from bscp_bookstock where barcode="'.$qData['barcode'].'"');
		$row = $query->result_array();
        if ($query->num_rows()===0) {
			
			$this->db->insert('bscp_bookstock', $qData);
			return "success";
			
		}else{

			return "exists";
							
		}
    }
	
	public function UpdateBookStock($qData)
    {
        $this->db->update('bscp_bookstock', $qData, array('id' => $qData['id'],'bookid' => $qData['bookid']));
        
    }
	
	public function DelBookStock($ide,$bookid){
        
    	$query1 = $this-> db -> query('delete from bscp_bookstock where id="'.$ide.'" and bookid="'.$bookid.'"');
        if($query1) {
            $result = array(0 => "success");
        } else {
            $result = array(0 => "fail");
        }
        
        return $result; 
    
    }
	
	public function GetLibraryCenters(){
        
		 	$roleaccess = $this->config->item('roleaccess');
		 
    	    $this->datatables->select('created_at,sno,name,id') 
            ->edit_column('id', '$1', 'check_librarycentereditdelete(id,name,"'.$roleaccess['uedit'].'","'.$roleaccess['udelete'].'")')
            ->edit_column('name', '<span>$1</a>', 'name')                          
            ->from('bscp_library_centers');
            
            $table =  $this->datatables->generate();
            return $table;
    
    }
    
     public function InsertLibraryCenter($qData)
    {
        $this->db->insert('bscp_library_centers', $qData);
        return $this->db->insert_id();
    }
    
    
    public function UpdateLibraryCenter($qData)
    {
        $this->db->update('bscp_library_centers', $qData, array('id' => $qData['id']));
        
    }
    
        public function DelLibraryCenter($ide){
        
    	    $query1 = $this-> db -> query('delete from `bscp_library_centers` where id="'.$ide.'"');
        if($query1) {
            $result = array(0 => "success");
        } else {
            $result = array(0 => "fail");
        }
        
        return $result; 
    
    }
	
	public function GetAllCenters($inp,$type,$lcenters=array()){
        
        $retHTML = "";
        $selected="";$where = "";
		
		if(!empty($lcenters) && !in_array("All", $lcenters)) $where .= ' where name IN ("'.implode('","',$lcenters).'") ';
		
        $query2 = $this-> db -> query('select * from bscp_library_centers'.$where);
		$row = $query2->result_array();
        if ($row) {
            
                $cenArr = explode("|",$inp);
                for($i=0 ; $i < count($row);$i++) {
                    if( ($row[$i]["name"] == $inp) || (in_array($row[$i]["name"],$cenArr))) {
                        $selected = 'selected=selected';
                    }
                    
                    if($type === "option"){
                        $retHTML .= "<option ".$selected.">".$row[$i]["name"]."</option>";
                    } else {
                        $retHTML .= "<li ".$selected."><label style=\"text-align: left;color:#536485;background: none;border: 0px;width: auto;height: auto;float:left;font-size: 15px\"><input class=\"radiocenters\" attr-centers=\"".$row[$i]["name"]."\" name=\"radiocenters\" type=\"radio\" />".$row[$i]["name"]."</li></label>";
                    }
                   $selected = "";
                }
                
        }
        
        return $retHTML;
        
    }
	
	
	public function GetBarcodes() {
        
        $arr = Array();
		
		$arr['list'] = "";
		
		$roleaccess = $this->config->item('roleaccess');
	
	    $this->datatables->select('id,totalcount,barcodefrom,barcodeto,created_at,created_at as created') 
			 ->edit_column('id', '<a class=" noedit" id="$1" href="barcodeview?id=$1"><img style="padding:5px" src="images/view.png"></a> <a class=" noedit" id="$1" href="barcodeprint?id=$1" target="_blank">Print</a>', 'id')
            ->edit_column('created_at', '<p class="sno"></p>', '')->from('bscp_library_barcode');
            
                
                $table =  $this->datatables->generate();
		
		return $table;
        
    }
	
	public function GetBarcodefromto()
    {
		
		$arr = array();
		
		$arr["bcfrom"] = 1000001;
		$arr["bcto"] = 1000000;
		
		$query = $this-> db -> query('select MAX(barcodeto) as barcodeto  from bscp_library_barcode ');
		$row = $query->result_array();
        if ($query->num_rows() > 0) {
			
			if($row[0]['barcodeto']!="") {
				$arr["bcfrom"] = intval($row[0]['barcodeto'])+1;
				$arr["bcto"] = intval($row[0]['barcodeto']);
			}
			else {
				$arr["bcfrom"] = 1000001;
			}
			
		}else{
			$arr["bcfrom"] = 1000001;
		}
		
		return $arr;
		
    }
	
	public function GetBarcodeBatchdetails($id)
    {
		
		$row = array();
		
		$query = $this-> db -> query('select * from bscp_library_barcode where id="'.$id.'" ');
		$row = $query->result_array();
        if ($query->num_rows() > 0) {
			
			return $row[0];
			
		}
		
		return $row;
		
    }
	
	public function GenerateBarcode($bccount,$bcto)
	{
		
		$result = array(0=>"");
		
		// Load library
		$this->load->library('zend');
		// Load in folder Zend
		$this->zend->load('Zend/Barcode');
		
		//Zend_Barcode::setBarcodeFont('./css/fonts/segoeui.ttf');
		
		$id = uniqid();
		
		$dirname = './docs/barcode/'.$id.'/';
		
		if(!file_exists($dirname)) { if(!mkdir($dirname,0777,true)){ $result = array(0=>"error",1=>"error ".$dirname); return $result; }  }
		
		$bccode = "";
		
		for($i=1;$i<=$bccount;$i++){
			
			$bccode = intval($bcto) + intval($i);
			
			if(!file_exists($dirname.$bccode.'.png')){
				
				// Generate barcode
				$imageResource = Zend_Barcode::factory('code128', 'image', array('text'=>"$bccode",'stretchText'=>true,'withBorder'=>false,'font'=>3,'fontSize'=>14,'barHeight'=>40,'barThickWidth'=>3,'barThinWidth'=>2,'withQuietZones'=>false,'drawText'=>true), array('imageType'=>'png'))->draw();

				imagepng($imageResource, $dirname.$bccode.'.png');
				
			}
			
		}
		
		$barcodefrom = $bcto+1;
		$barcodeto = intval($bcto)+intval($bccount);
		
		$query = $this-> db -> query('INSERT INTO `bscp_library_barcode`(`id`, `totalcount`, `barcodefrom`, `barcodeto`, `created_at`) VALUES ("'.$id.'","'.$bccount.'","'.$barcodefrom.'","'.$barcodeto.'","'.date("Y-m-d H:i:s").'")');
				
		if($query) {
			$result = array(0=>"success"); 
			return $result;
		}
		
	}
	
	// Issue Book
	
	public function GetStudentProfile($stuid){
								       
        $query = $this-> db -> query('select st.studid,st.id,u.name as stuname,s.classstudy as qualification,u.email as semail,u.mobile as smobile,u.mcode as smcode,s.mcode as sumcode,u.booklimit,sp.profilepic from bscp_student as st LEFT JOIN typo_users as u ON st.id=u.id LEFT JOIN bscp_studentprofile as sp ON st.id=sp.stuid LEFT JOIN bscp_signup as s ON u.username=s.emailid where st.studid="'.$stuid.'"');
		$row = $query->result_array();
        return $row[0];       
   }
	
	public function GetStaffProfile($mobileno){
								       
        $query = $this-> db -> query('select id,staffname as stuname,mcode as smcode,staffmobile as smobile,staffemail as studid,booklimit,profilepic from bscp_staffs where staffmobile="'.$mobileno.'"');
		$row = $query->result_array();
        return $row[0];       
   }
	
	public function GetIssuedStockBookDetails($bookid) {
        
        $arr = Array();
				 		
		$roleaccess = $this->config->item('roleaccess');
	
	    $this->datatables->select('bscp_issuebook.id,bscp_issuebook.center,bscp_issuebook.barcode,bscp_issuebook.created,booktype as library,bscp_bookstock.booktype,bscp_library_books.bookname,bscp_bookstock.price,bscp_issuebook.duedate,bscp_library_books.dueperiod,bscp_student.sname,bscp_student.studid,bscp_staffs.staffname,bscp_staffs.staffmobile') 
			->edit_column('booktype', '$1', 'check_booktype(booktype)')
			->edit_column('duedate', '$1', 'change_DateFormat(duedate)')
			->edit_column('dueperiod', '$1', 'get_bookremaindue(duedate)')
			->edit_column('studid', '$1', 'check_issuestuid(studid,staffmobile)')
			->edit_column('sname', '$1', 'check_issuestuname(sname,staffname)')
            ->edit_column('created', '<p class="sno"></p>', '')->from('bscp_bookstock')->where('bscp_bookstock.bookid = "'.$bookid.'" and bscp_issuebook.issued="y"')
            ->join('bscp_issuebook', 'bscp_issuebook.barcode=bscp_bookstock.barcode', 'left')
			->join('bscp_library_books', 'bscp_library_books.id=bscp_bookstock.bookid', 'left')
			->join('bscp_student', 'bscp_student.id=bscp_issuebook.studentid', 'left')
			->join('bscp_staffs', 'bscp_staffs.id=bscp_issuebook.studentid', 'left');
                
                $table =  $this->datatables->generate();
		
		return $table;
        
    }
	
	public function GetIssueBookDetails($stuid)
    {   
     
		 $query = $this-> db -> query('select ib.id,ib.studid,ib.center,ib.barcode,ib.created,booktype as library,bs.booktype,lb.bookname,bs.price,ib.duedate,ib.recieveddate,lb.dueperiod from bscp_issuebook as ib LEFT JOIN bscp_bookstock as bs on bs.barcode=ib.barcode LEFT JOIN bscp_library_books as lb on lb.id=bs.bookid where ib.studid="'.$stuid.'" order by ib.created desc') ;
		
		if($query->num_rows()>0)
        {
            return $query->result();  
        }
        else
        {
            return 0;
        }
		
    }
	
	public function GetIssuedBookList($stuid)
    {   
     
		 $query = $this-> db -> query('select ib.id,ib.studid,ib.center,ib.barcode,ib.created,booktype as library,bs.booktype,lb.bookname,bs.price,ib.duedate,ib.recieveddate,lb.dueperiod from bscp_issuebook as ib LEFT JOIN bscp_bookstock as bs on bs.barcode=ib.barcode LEFT JOIN bscp_library_books as lb on lb.id=bs.bookid where ib.studid="'.$stuid.'" and ib.issued="y" order by ib.created desc') ;
		
		if($query->num_rows()>0)
        {
            return $query->result();  
        }
        else
        {
            return 0;
        }
		
    }
	
	public function GetIssuedHistoryList($stuid)
    {   
     
		 $query = $this-> db -> query('select ib.id,ib.studid,ib.center,ib.barcode,ib.created,booktype as library,bs.booktype,lb.bookname,bs.price,ib.duedate,ib.recieveddate,lb.dueperiod,ib.issued as issuedstatus,ib.received as receivedstatus from bscp_issuebook as ib LEFT JOIN bscp_bookstock as bs on bs.barcode=ib.barcode LEFT JOIN bscp_library_books as lb on lb.id=bs.bookid where ib.studid="'.$stuid.'" order by ib.created desc') ;
		
		if($query->num_rows()>0)
        {
            return $query->result();  
        }
        else
        {
            return 0;
        }
		
    }
	
	public function InsertIssueBook($qData)
    {
		for($i=0;$i<count($qData);$i++){
			$id = $this->db->insert('bscp_issuebook', $qData[$i]);
		}
					
        if($id) {
			return "success";						
		}else{
			return "fail";
		}
		
    }
	
	 public function InsertIssueBookPreview($barcode)
    {
		$query = $this-> db -> query('select id from bscp_issuebook where barcode="'.$barcode.'" and issued="y"');
		$row = $query->result_array();
        if ($query->num_rows()>0) {
						
			return "exists";
			
		}else{

			return "success";
							
		}
    }
	
	public function UpdateIssueBook($qData)
    {
        $this->db->update('bscp_issuebook', $qData, array('id' => $qData['id'],'bookid' => $qData['bookid']));
        
    }
	
	public function DelIssueBook($ide,$bookid){
        
    	$query1 = $this-> db -> query('delete from bscp_issuebook where id="'.$ide.'" and bookid="'.$bookid.'"');
        if($query1) {
            $result = array(0 => "success");
        } else {
            $result = array(0 => "fail");
        }
        
        return $result; 
    
    }
	
	public function GetBarcodeDetails($barcode,$center) {
        
        $arr = array();
        
        $query1 = $this-> db -> query('select bs.bookid,bs.center,bs.price,bs.booktype,b.bookname,b.dueperiod from bscp_bookstock as bs LEFT JOIN bscp_library_books as b on bs.bookid = b.id where bs.barcode="'.$barcode.'" and bs.center="'.$center.'"');
		$row = $query1->result_array();
        if ($query1 ->num_rows() > 0) {
            
			$arr['bookid']=$row[0]['bookid'];
            $arr['bookname']=$row[0]['bookname'];
            $arr['booktype']=$row[0]['booktype'];
            $arr['dueperiod']=$row[0]['dueperiod'];
            $arr['price']=$row[0]['price'];
            $arr['center']=$row[0]['center'];
			
			$duedate = date("Y-m-d",strtotime(date("Y-m-d")." + ".$arr['dueperiod']." days"));
			
			$arr['duedate'] = $duedate;
         
        }
              
       
        return $arr;
        
    }
	
	
	
	
	public function GetIssuedBookDetails($stuid) {
        
		$arr = array();
		
		$arr['totaldue'] = $arr['totalexpired'] = $arr['totalissued'] = 0;
			
        $query1 = $this-> db -> query('select duedate,issued,received from bscp_issuebook where studid="'.$stuid.'"');
		$row = $query1->result_array();
        if ($query1 ->num_rows() > 0) {
			
			for($i=0;$i<count($row);$i++){
				            
				$duedate=$row[$i]['duedate'];
				$issued=$row[$i]['issued'];
				$received=$row[$i]['received'];
				
				if(strtotime($duedate) > strtotime(date("Y-m-d"))){
					
					$arr['totalexpired'] += $arr['totalexpired'] + 1;
					
				}else{
					$arr['totaldue'] += $arr['totaldue'] + 1;
				}

								
				if($issued=="y") $arr['totalissued'] = $arr['totalissued'] + 1;
				
			}
		
         
        }
              
       
        return $arr;
        
    }
	
	
	
	public function UpdateBookLimit($qData,$type)
    {
		if($type!="staff"){
			$this->db->update('typo_users', $qData, array('id' => $qData['id']));
		}else{
			$this->db->update('bscp_staffs', $qData, array('id' => $qData['id']));
		}
        
        
    }
	
	
	// Receive Book
	
	public function GetIssuedBarcodeDetails($barcode) {
        
        $arr = array();
        
		$type = "";
		
        $query1 = $this-> db -> query('select ib.id,ib.studid,ib.studentid,ib.center,ib.barcode,ib.created,booktype as library,bs.booktype,lb.bookname,bs.price,ib.duedate,ib.recieveddate,lb.dueperiod,lb.edition,st.sname,st.mcode,st.contact,sp.profilepic from bscp_issuebook as ib LEFT JOIN bscp_bookstock as bs on bs.barcode=ib.barcode LEFT JOIN bscp_library_books as lb on lb.id=bs.bookid LEFT JOIN bscp_student as st on st.id=ib.studentid LEFT JOIN bscp_studentprofile as sp on sp.stuid=ib.studentid where ib.barcode="'.$barcode.'" and ib.issued="y" and st.sname IS NOT NULL');
		
        if ($query1->num_rows() == 0) {
			
			 $query1 = $this-> db -> query('select ib.id,ib.studid,ib.studentid,ib.center,ib.barcode,ib.created,booktype as library,bs.booktype,lb.bookname,bs.price,ib.duedate,ib.recieveddate,lb.dueperiod,lb.edition,st.staffname as sname,st.mcode,st.staffmobile as contact,st.profilepic from bscp_issuebook as ib LEFT JOIN bscp_bookstock as bs on bs.barcode=ib.barcode LEFT JOIN bscp_library_books as lb on lb.id=bs.bookid LEFT JOIN bscp_staffs as st on st.id=ib.studentid where ib.barcode="'.$barcode.'" and ib.issued="y"');
			
			$type = "staff";
		}
		
		$row = $query1->result_array();
		
        if ($query1->num_rows() > 0) {
			 
            $arr['bookname']=$row[0]['bookname'];
            $arr['booktype']=$row[0]['booktype'];
            $arr['dueperiod']=$row[0]['dueperiod'];
            $arr['created']=$row[0]['created'];
            $arr['recieveddate']=$row[0]['recieveddate'];
            $arr['duedate']=$row[0]['duedate'];
            $arr['price']=$row[0]['price'];
            $arr['studid']=$row[0]['studid'];
            $arr['studentid']=$row[0]['studentid'];
            $arr['sname']=$row[0]['sname'];
            $arr['mcode']=$row[0]['mcode'];
            $arr['contact']=$row[0]['contact'];
            $arr['profilepic']=$row[0]['profilepic'];
            $arr['edition']=$row[0]['edition'];
            $arr['type']=$type;
			         
        }
              
       
        return $arr;
        
    }
	
	public function UpdateReceiveBook($qData)
    {
		for($i=0;$i<count($qData);$i++){
			
        	$id = $this->db->update('bscp_issuebook', $qData[$i], array('barcode' => $qData[$i]['barcode'],'issued' => "y"));
			
		}
		
		if($id){
			return "success";
		}else{
			return "fail";
		}
		        
    }
	
	public function GetReceiveBookDetails($stuid)
    {   
     
		 $query = $this-> db -> query('select ib.id,ib.studid,ib.center,ib.barcode,ib.created,booktype as library,bs.booktype,lb.bookname,bs.price,ib.duedate,ib.recieveddate,lb.dueperiod,lb.edition,st.sname from bscp_issuebook as ib LEFT JOIN bscp_bookstock as bs on bs.barcode=ib.barcode LEFT JOIN bscp_library_books as lb on lb.id=bs.bookid LEFT JOIN bscp_student as st on st.id=ib.studentid where ib.studid="'.$stuid.'" and received="y" order by ib.duedate asc') ;
		
		if($query->num_rows()>0)
        {
            return $query->result();  
        }
        else
        {
            return 0;
        }
		
    }
	
	
	public function GetReceivedBookList($stuid)
    {   
     
		 $query = $this-> db -> query('select ib.id,ib.studid,ib.center,ib.barcode,ib.created,booktype as library,bs.booktype,lb.bookname,bs.price,ib.duedate,ib.recieveddate,lb.dueperiod,lb.edition,st.sname,sf.staffname from bscp_issuebook as ib LEFT JOIN bscp_bookstock as bs on bs.barcode=ib.barcode LEFT JOIN bscp_library_books as lb on lb.id=bs.bookid LEFT JOIN bscp_student as st on st.id=ib.studentid LEFT JOIN bscp_staffs as sf on sf.id=ib.studentid where ib.studid="'.$stuid.'" and received="y" order by ib.duedate asc') ;
		
		if($query->num_rows()>0)
        {
            return $query->result();  
        }
        else
        {
            return 0;
        }
		
    }
	
	/*
	public function GetReceiveBookDetails($stuid) {
        
        $arr = Array();
				 		
		$roleaccess = $this->config->item('roleaccess');
	
	    $this->datatables->select('bscp_issuebook.id,bscp_issuebook.studid,bscp_issuebook.center,bscp_issuebook.barcode,bscp_issuebook.created,booktype as library,bscp_bookstock.booktype,bscp_library_books.bookname,bscp_bookstock.price,bscp_issuebook.duedate,bscp_library_books.dueperiod,bscp_library_books.edition,bscp_student.sname') 
			->edit_column('booktype', '$1', 'check_booktype(booktype)')
			->edit_column('duedate', '$1', 'change_DateFormat(duedate)')
			->edit_column('dueperiod', '$1', 'get_bookremaindue(duedate)')
            ->edit_column('created', '<p class="sno"></p>', '')->from('bscp_issuebook')->where('bscp_issuebook.studid = "'.$stuid.'" and received="y"')
            ->join('bscp_bookstock', 'bscp_bookstock.barcode=bscp_issuebook.barcode', 'left')
			->join('bscp_library_books', 'bscp_library_books.id=bscp_bookstock.bookid', 'left')
			->join('bscp_student', 'bscp_student.id=bscp_issuebook.studentid', 'left');
                
                $table =  $this->datatables->generate();
		
		return $table;
        
    }*/
	
	// Exam Center
	
	public function GetExamCenters($userid)
    {   
     
		 $query = $this-> db -> query('select em.ide,em.name,em.date,em.rtime,em.duration,c.coursename,sem.location,em.displaycname from bscp_courserequest as cr LEFT JOIN bscp_exammaster as em on em.courseid=cr.courseid LEFT JOIN bscp_student as st on st.id=cr.studentid LEFT JOIN bscp_student_exammaster as sem on sem.examid=em.ide and sem.studentid=st.id LEFT JOIN admin_course as c on c.ide=em.courseid where cr.studentid="'.$userid.'" and em.active="a" and em.del="n"  and cr.approved="y" group by em.ide order by em.date asc') ;
		//echo $this->db->last_query();
		if($query->num_rows()>0)
        {
            return $query->result();  
        }
        else
        {
            return 0;
        }
		
    }
	
	public function GetExamCenterDetails($userid,$examid)
    {   
		$arr = array();
     
		 $query = $this-> db -> query('select em.ide,em.name,em.date,em.rtime,em.duration,em.description,c.coursename,em.courseid,em.displaycname from bscp_courserequest as cr LEFT JOIN bscp_exammaster as em on em.courseid=cr.courseid LEFT JOIN bscp_student as st on st.id=cr.studentid LEFT JOIN bscp_student_exammaster as sem on sem.examid=em.ide and sem.studentid=st.id LEFT JOIN admin_course as c on c.ide=em.courseid where cr.studentid="'.$userid.'" and em.ide="'.$examid.'" and em.courseid=cr.courseid and em.active="a" and em.del="n" group by em.ide order by em.date asc');
		//echo $this->db->last_query();
		$row = $query->result_array();
		if($query->num_rows()>0)
        {
			$arr['id'] = $row[0]['ide'];
			$arr['examname'] = $row[0]['name'];
			$date = $row[0]['date'];
			$rtime = $row[0]['rtime'];
			$arr['duration'] = $row[0]['duration'];
			$arr['coursename'] = $row[0]['coursename'];
			$arr['description'] = $row[0]['description'];
			$arr['courseid'] = $row[0]['courseid'];
			$arr['displaycname'] = $row[0]['displaycname'];
			
			$examdate = ($date ===null)?"-":date("d-M-Y h:i A",strtotime($date));
			$examrtime = ($rtime ===null)?"-":date("h:i A",strtotime($rtime));
			
			$arr['date'] = $examdate;
			$arr['rtime'] = $examrtime;
			
			$arr['districtoption'] = "";
			$arr['centeroption'] = "";
			$districtoption = $centeroption = "";
			
			$query1 = $this-> db -> query('select distinct district from bscp_selectedexamcenters where examid="'.$examid.'" order by district asc') ;
			$row1 = $query1->result_array();
			if($query1->num_rows()>0)
			{
				for($i=0;$i<count($row1);$i++){
					                    
                    $districtoption .= "<option value='".$row1[$i]["district"]."'>".$row1[$i]["district"]."</option>";
										
				}
			}
			
			$arr['districtoption'] = $districtoption;
						
        }
		
		return $arr;
		
    }
	
	public function ExamCenterOptions($examid,$district){
		
		$arr = array();
		$centeroption  ="";
		
		$query2 = $this-> db -> query('select distinct center from bscp_selectedexamcenters where examid="'.$examid.'" and district="'.$district.'" order by center asc') ;
			$row2 = $query2->result_array();
			if($query2->num_rows()>0)
			{

				for($j=0;$j<count($row2);$j++){
					                    
                    $centeroption .= "<option value='".$row2[$j]["center"]."'>".$row2[$j]["center"]."</option>";
										
				}
				
			}
			
			$arr['centeroption'] = $centeroption;
		
		return $arr;
		
	}
	
	 public function ExamMasterSubmit($qData)
    {
		$query = $this-> db -> query('select ide from bscp_student_exammaster where studentid="'.$qData['studentid'].'" and examid="'.$qData['examid'].'" and courseid="'.$qData['courseid'].'"');
		$row = $query->result_array();
        if ($query->num_rows()===0) {
			
			$this->db->insert('bscp_student_exammaster', $qData);
			return "success";
			
		}else{

			return "exists";
							
		}
    }
	
	public function GetExamCenterPrintDetails($userid,$examid)
    {   
		$arr = array();
     
		 $query = $this-> db -> query('select em.ide,em.name,em.date,em.rtime,em.duration,em.description,c.coursename,sem.district,sem.location,st.studid,st.sname,ec.address1,ec.address2,ec.phone,ec.pincode,em.displaycname from bscp_courserequest as cr LEFT JOIN bscp_exammaster as em on em.courseid=cr.courseid LEFT JOIN bscp_student as st on st.id=cr.studentid LEFT JOIN bscp_student_exammaster as sem on sem.examid=em.ide and sem.studentid=st.id LEFT JOIN admin_course as c on c.ide=em.courseid LEFT JOIN bscp_examcenters as ec on ec.districtname=sem.district and ec.name=sem.location where cr.studentid="'.$userid.'" and em.ide="'.$examid.'" and em.courseid=cr.courseid and em.active="a" and em.del="n" group by em.ide order by em.date asc');
		//echo $this->db->last_query();
		$row = $query->result_array();
		if($query->num_rows()>0)
        {
			$arr['id'] = $row[0]['ide'];
			$arr['examname'] = $row[0]['name'];
			$date = $row[0]['date'];
			$rtime = $row[0]['rtime'];
			$arr['duration'] = $row[0]['duration'];
			$arr['coursename'] = $row[0]['coursename'];
			$arr['description'] = $row[0]['description'];
			$arr['location'] = $row[0]['location'];
			$arr['district'] = $row[0]['district'];
			$arr['studid'] = $row[0]['studid'];
			$arr['sname'] = $row[0]['sname'];
			$arr['address1'] = $row[0]['address1'];
			$arr['address2'] = $row[0]['address2'];
			$arr['phone'] = $row[0]['phone'];
			$arr['pincode'] = $row[0]['pincode'];
			$arr['displaycname'] = $row[0]['displaycname'];
			
			$examdate = date("d-M-Y h:i A",strtotime($date));
			$examrtime = date("h:i A",strtotime($rtime));
			
			$arr['date'] = $examdate;
			$arr['rtime'] = $examrtime;
									
        }
		
		return $arr;
		
    }
	
	public function GetBarcodeHistoryDetails($barcode)
    {   
     
		 $query = $this-> db -> query('select bs.booktype as library,bs.booktype,bs.price,lb.bookname,lb.isbn_number, lb.author,lb.publisher,lb.category,lb.edition,lb.stream,lb.supplier,lb.dueperiod,bs.barcode from bscp_bookstock as bs LEFT JOIN bscp_library_books as lb on lb.id=bs.bookid where bs.barcode="'.$barcode.'"') ;
		
		$row = $query->result_array();
		if($query->num_rows()>0)
        {
            return $row[0];
        }
        else
        {
            return 0;
        }
		
    }
	
	public function GetBarcodeHistoryList($barcode)
    {   
     
		 $query = $this-> db -> query('select ib.id,ib.studid,ib.center,ib.barcode,ib.created,booktype as library,bs.booktype,lb.bookname,bs.price,ib.duedate,ib.recieveddate,lb.dueperiod,ib.issued as issuedstatus,ib.received as receivedstatus,lb.isbn_number,lb.isbn_number, lb.author,lb.publisher,lb.category,lb.edition,lb.stream,lb.supplier,st.sname,st.studid,sf.staffname,sf.staffmobile from bscp_issuebook as ib LEFT JOIN bscp_bookstock as bs on bs.barcode=ib.barcode LEFT JOIN bscp_library_books as lb on lb.id=bs.bookid LEFT JOIN bscp_student as st on st.id=ib.studentid LEFT JOIN bscp_staffs as sf on sf.id=ib.studentid where ib.barcode="'.$barcode.'" order by ib.created desc') ;
		
		if($query->num_rows()>0)
        {
            return $query->result();  
        }
        else
        {
            return 0;
        }
		
    }
	
	public function CheckBarcodeExists($barcode) {
        
        $arr = array();
        
        $query1 = $this-> db -> query('select bs.bookid,bs.center,bs.price,bs.booktype,b.bookname,b.dueperiod,bs.centerfrom,bs.transferon from bscp_bookstock as bs LEFT JOIN bscp_library_books as b on bs.bookid = b.id where bs.barcode="'.$barcode.'"');
		$row = $query1->result_array();
        if ($query1 ->num_rows() > 0) {
            
			$arr['bookid']=$row[0]['bookid'];
            $arr['bookname']=$row[0]['bookname'];
            $arr['booktype']=$row[0]['booktype'];
            $arr['dueperiod']=$row[0]['dueperiod'];
            $arr['price']=$row[0]['price'];
            $arr['center']=$row[0]['center'];
            $arr['centerfrom']=$row[0]['centerfrom'];
            $arr['transferon']=$row[0]['transferon'];
						         
        }
              
       
        return $arr;
        
    }
	
	public function UpdateTransferBooks($qData)
    {
		for($i=0;$i<count($qData);$i++){
			$id = $this->db->update('bscp_bookstock', $qData[$i], array('barcode' => $qData[$i]['barcode']));
		}
					
        if($id) {
			return "success";						
		}else{
			return "fail";
		}
		
    }
    
    public function GetLocationStocks() {
        
            $arr = Array();
            $roleaccess = $this->config->item('roleaccess');
	
	    $this->datatables->select('bscp_bookstock.created_at as ide,bscp_bookstock.center as location,count(*) AS stockcount')
                    ->edit_column('location', '<a class="noedit" href="libraryreports?location=$1">$1</a>', 'location')
                    ->edit_column('ide', '<span class="sno"></span>', '')
                    ->from('bscp_bookstock')
                    ->group_by('bscp_bookstock.center') ;
		    
            $table =  $this->datatables->generate();
            
            return $table;
        
    }
    
    public function GetLocationBookStocks($location,$lcenters=array()) {
        
            
        $arr = Array();
		
        $arr['list'] = $where = "";

         if(!empty($lcenters) && !in_array("All", $lcenters)&& !in_array($location, $lcenters))
         {
             $table = '';

         }else{

        $roleaccess = $this->config->item('roleaccess');

        $this->datatables->select('bookid,center,barcode,barcode as tstock,created_at,booktype as library,booktype as reference,booktype,bookname,isbn_number')
                    ->edit_column('bookname', '<a class="noedit" href="libraryreports?location=$3&id=$2">$1</a>', 'bookname,bookid,center')
                    ->edit_column('library', '$1', 'check_booktypestock(bookid,center)')
                    ->edit_column('reference', '$1', 'check_booktypestock2(bookid,center)')
        ->edit_column('created_at', '<p class="sno"></p>', '')->from('bscp_bookstock')->where('center = "'.$location.'"')
                    ->group_by('bookid')->join('bscp_library_books', 'bscp_library_books.id=bscp_bookstock.bookid', 'left');


        $table =  $this->datatables->generate();
         }

        return $table;
        
    }
    
    public function GetIssuedStockReports($bookid,$location,$lcenters=array()) {
        
            
        $arr = Array();
		
        $arr['list'] = "";
		 
        if(!empty($lcenters) && !in_array("All", $lcenters) && !in_array($location, $lcenters))
        {
             $table = '';

        } else{
            
            $roleaccess = $this->config->item('roleaccess');

            $this->datatables->select('bscp_bookstock.barcode,created_at,issued')
                    ->edit_column('barcode', '$1', 'barcode')
                    ->edit_column('issued', '<p class="issued"></p>', 'issued')
                    ->edit_column('created_at', '<p class="sno"></p>', '')->from('bscp_bookstock')
                    ->where('bscp_bookstock.center = "'.$location.'"')->where('bscp_bookstock.bookid = "'.$bookid.'"')
                    ->group_by('bscp_bookstock.barcode')
                    ->join('bscp_issuebook', 'bscp_issuebook.barcode=bscp_bookstock.barcode', 'left');

            $table =  $this->datatables->generate();
        }
		
	return $table;
        
    }
    
    public function ExportLibraryBooks($center,$bookid) {
        
        
         $courseArr = Array();$where = "";
          if(($center !== "") && ($center !== "All")&& ($bookid == "")) { 
              $where = " where a.center='".$center."'";              
          } else if(($center !== "")&&($bookid !== "")&& ($center !== "All"))  { 
              $where = " where a.center='".$center."' and a.bookid='".$bookid."' ";              
          }  
         
         $query1 = $this-> db -> query('SELECT a.center,a.barcode,a.booktype,b.bookname from bscp_bookstock as a LEFT JOIN bscp_library_books as b on b.id=a.bookid'.$where);
     
       
        $row1 = $query1->result_array();
        if ($row1) {
            for($i = 0;$i<count($row1);$i++) {                
                    $courseArr[$i]['bookname'] = $row1[$i]['bookname'];
                    $courseArr[$i]['center'] = $row1[$i]['center'];
                    $courseArr[$i]['barcode'] = $row1[$i]['barcode'];   
                    $courseArr[$i]['booktype'] = $row1[$i]['booktype'];   
                    
                    $query41 = $this-> db -> query('select ib.id,ib.studid,ib.studentid,ib.barcode,ib.duedate,st.email,st.sname,st.mcode,st.contact from bscp_issuebook as ib LEFT JOIN bscp_student as st on st.id=ib.studentid LEFT JOIN bscp_studentprofile as sp on sp.stuid=ib.studentid where ib.barcode="'.$row1[$i]['barcode'].'" and ib.issued="y" and st.sname IS NOT NULL');
                    $row41 = $query41->result_array();
                    if ($row41) {
                        $courseArr[$i]['mcode'] = $row41[0]['mcode'];
                        $courseArr[$i]['mobile'] = $row41[0]['mobile'];
                        $courseArr[$i]['duedate'] = $row41[0]['duedate'];
                        $courseArr[$i]['studid'] = $row41[0]['studid'];
                        $courseArr[$i]['sname'] = $row41[0]['sname'];
                        $courseArr[$i]['contact'] = $row41[0]['contact'];
                        $courseArr[$i]['email'] = $row41[0]['email'];
   
                    } else {

                        $courseArr[$i]['mcode'] = '';
                        $courseArr[$i]['mobile'] = '';
                        $courseArr[$i]['duedate'] = '';
                        $courseArr[$i]['studid'] = '';
                        $courseArr[$i]['sname'] = '';
                        $courseArr[$i]['contact'] = '';
                        $courseArr[$i]['email'] = $row41[0]['email'];

                    }
                             
            }
        }
        
        return $courseArr;
        
        
    }
	
}
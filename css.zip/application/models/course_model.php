<?php

Class Course_Model extends CI_Model {
    
     public function __construct() {
        $this->load->model('student_model','',TRUE);
       $this->load->library('Datatables');
		 $this->load->helper('My_datatable_helper');
		   
    }

    public function GetAllItems($type) {
        
        $arr = Array();
		
		$arr['list'] = "";
		
		$roleaccess = $this->config->item('roleaccess');
		$web_url = $this->config->item('web_url');
		
		$this->load->model('login_model','',TRUE);
		$user = $this->login_model->GetUserId();
				
		$keywords_imploded = "";
		if(!empty($user['bcourses']) && !in_array("All", $user['bcourses'])){
			$keywords_imploded .= ' and coursename IN ("'.implode('","',$user['bcourses']).'") ';
		}
		
                if($type === "") {
                //$this->datatables->set_database("default");
	    $this->datatables->select('ide,coursename,status,courseid,created_at,duration,refundamt') 
             ->edit_column('coursename', '$1', 'check_admissioncoursename1(ide,coursename,"'.$roleaccess['Courses'][1].'","'.$web_url.'","'.base_url().'")')
                        ->edit_column('status', '$1', 'check_admissioncoursename2(ide,status,"'.$roleaccess['Courses'][1].'","'.$web_url.'","'.base_url().'")')
                    ->edit_column('refundamt', '$1', 'check_admissioncoursename4(ide,refundamt,"'.$roleaccess['Courses'][1].'","'.$web_url.'","'.base_url().'")')
                    ->edit_column('ide', '$1', 'check_admissioncoursename3(ide,"'.$roleaccess['Courses'][3].'","'.$roleaccess['Courses'][1].'","'.$web_url.'","'.base_url().'")')
             ->edit_column('duration', '$1', 'courseid') 

             ->edit_column('created_at', '<p class="sno"></p>', '')->from('admin_course')->where('del = "n"'.$keywords_imploded);
            
                }
                
                if( ($type !== "") ) {
                //$this->datatables->set_database("default");
	    $this->datatables->select('ide,coursename,status,courseid,created_at,duration,refundamt') 
             ->edit_column('coursename', '$1', 'check_admissioncoursename1(ide,coursename,"'.$roleaccess['Courses'][1].'","'.$web_url.'","'.base_url().'")')
             ->edit_column('status', '$1', 'check_admissioncoursename2(ide,status,"'.$roleaccess['Courses'][1].'","'.$web_url.'","'.base_url().'")')
                    ->edit_column('refundamt', '$1', 'check_admissioncoursename4(ide,refundamt,"'.$roleaccess['Courses'][1].'","'.$web_url.'","'.base_url().'")')
                    ->edit_column('ide', '$1', 'check_admissioncoursename3(ide,"'.$roleaccess['Courses'][3].'","'.$roleaccess['Courses'][1].'","'.$web_url.'","'.base_url().'")')
             ->edit_column('duration', '$1', 'courseid') 
             
             ->edit_column('created_at', '<p class="sno"></p>', '')->from('admin_course')->or_where('ctype','both')->or_where('ctype',$type)->where('del = "n"'.$keywords_imploded);
            
                }
                
                $table =  $this->datatables->generate();
		
		return $table;
        
    }
    
   
    
    public function AddCourse($cData) {
        
       
        $this->db->insert('admin_course', $cData);
        return $this->db->insert_id();  	
        
    }
    
    public function CourseOffset() {
        
        $countadd = 1;
	$queryM = $this->db->query('SELECT max(courseid) as cid FROM `admin_course` WHERE 1 ');
        $rowM = $queryM->result_array();
        $count = $countadd + $rowM[0]['cid'];
        return $count; 	 	
        
    }
    
    public function UpdateCourse($cData) {
        
        
        $this->db->update('admin_course', $cData, array('ide' => $cData['ide']));
        
    }
    
          public function DeleteCourse($ide){
              
              $qData = array(
              'ide' => $ide,
               'del' => 'y');
          $query1 = $this->db->update('admin_course', $qData, array('ide' => $qData['ide']));
        
       // $query1 = $this-> db -> query('update `admin_course` set del="y" where ide="'.$ide.'"');
        if($query1) {
            $result = array(0 => "success");
        } else {
            $result = array(0 => "fail");
        }
        
        return $result; 
        
        
    }
    
    
    public function ChangeCourseStatus($ide,$status){
        
        $qData = array(
              'status' => $status,
               'ide' => $ide);
          $query1 = $this->db->update('admin_course', $qData, array('ide' => $qData['ide']));
        //$query1 = $this-> db -> query('update `admin_course` set status="'.$status.'" where ide="'.$ide.'"');
        if($query1) {
            $result = array(0 => "success");
        } else {
            $result = array(0 => "fail");
        }
        
        return $result; 
        
        
    }
    
    
    public function BulkRefundStatus($ide,$status){
        
        $qData = array(
              'refundamt' => $status,
               'ide' => $ide);
          $query1 = $this->db->update('admin_course', $qData, array('ide' => $qData['ide']));
        //$query1 = $this-> db -> query('update `admin_course` set status="'.$status.'" where ide="'.$ide.'"');
        if($query1) {
            $result = array(0 => "success");
        } else {
            $result = array(0 => "fail");
        }
        
        //ENABLE BULK ENABLE REFUND
        $query1 = $this-> db -> query('update `bscp_courserequest` set refund="'.$status.'" where approved="y" and courseid="'.$ide.'"');
            
        
        
        return $result; 
        
        
    }
    
    public function ViewCoursePayment($ide) {
        
        $arr['name']= "";  $arr['nickname']= "";$arr['group']= "";$arr['maingroup']= "";$arr['maingroupid']= ""; $arr['purchase_price']= ""; $arr['sellprice']= "";$arr['sellpriceelec']= ""; $arr['original_mrp']= "";$arr['id']= ""; $arr['unit']= "";
        $query1 = $this-> db -> query('select a.unit,a.groupid,a.name,a.nickname,a.groupitem,a.maingroup,a.maingroupid,a.purchaseprice,a.sellprice,a.sellpriceelec,a.original_mrp,a.id,b.tax,b.discount,b.description,b.sac,b.courseid from admin_courses a , typo_group b where a.id = b.courseid and a.id="'.$ide.'"');
	$row = $query1->result_array();
        if ($row) {
            
            $arr['name']=$row[0]['name'];
            $arr['nickname']=$row[0]['nickname'];	
            $arr['group']=$row[0]['groupitem'];			
            $arr['purchase_price']=$row[0]['purchaseprice'];
            $arr['sellprice']=$row[0]['sellprice'];
            $arr['sellpriceelec']=$row[0]['sellpriceelec'];
            $arr['original_mrp']=$row[0]['original_mrp'];
            $arr['discount']=$row[0]['discount'];
            $arr['cdiscount']=$row[0]['description'];
            $arr['ediscount']=$row[0]['sac'];
            $arr['tax']=$row[0]['tax'];
            $arr['id']= $row[0]['id'];
            $arr['groupid']= $row[0]['groupid'];
            $arr['maingroup']=$row[0]['maingroup'];	
            $arr['maingroupid']= $row[0]['maingroupid'];
            $arr['unit']= $row[0]['unit'];
            
        }
        
        $centers = explode("|", $arr['original_mrp']);
        $retHTML = "";
        for($i = 0 ; $i < count($centers);$i++){
       
        $retHTML .= "<li ><label style=\"text-align: left;color:#536485;background: none;border: 0px;width: auto;height: auto;float:left;font-size: 15px\"><input class=\"radiocenters\" attr-centers=\"".$centers[$i]."\" name=\"radiocenters\" type=\"radio\" />".$centers[$i]."</li></label>";
        }
        
        $arr["centers"] = $retHTML;
        return $arr;
        
    }
    
     public function EditCourse($ide,$type) {
        
        $arr['ide']= "";  $arr['coursename']= "";$arr['centers']= "";$arr['duration']= "";
        $arr['centers1']= ""; $arr['starts_on']= ""; $arr['ends_on']= "";$arr['cshedule']= "";
        $arr['commenceson']= "";$arr['description']= ""; $arr['qualification']= "";
        $arr['qname']= "";$arr['stest']= "";$arr['refund']= "";$arr['examtime']= "";
        $arr['reportingtime']= "";$arr['cooloftime']= "";$arr['modeofexam']= "";
        
        $query1 = $this-> db -> query('select a.examtime,a.reportingtime,a.cooloftime,a.modeofexam,a.refund,a.screentest,a.ctype,a.qualification,a.qname,a.ide,a.coursename,a.courseid,a.centers,a.duration,a.commenceson,a.starts_on,a.ends_on,a.cschedule,a.description,a.stream,a.type,a.accountinghead,a.idcard_displayname from admin_course a where a.ide="'.$ide.'"');
	$row = $query1->result_array();
        if ($query1 ->num_rows()) {
            
            $arr['coursename']=$row[0]['coursename'];
            $arr['ide']=$row[0]['ide'];
            $arr['centers1']=$row[0]['centers'];
            $arr['centers']=$row[0]['centers'];
            $arr['duration']=$row[0]['duration'];
            $arr['commenceson']=$row[0]['commenceson'];
            $arr['starts_on']=$row[0]['starts_on'];
            $arr['ends_on']=$row[0]['ends_on'];
            $arr['cshedule']=$row[0]['cschedule'];
            $arr['commenceson']=$row[0]['commenceson'];
            $arr['description']=$row[0]['description'];
            $arr['qualification']=$row[0]['qualification'];
            $arr['qname']=$row[0]['qname'];
            $arr['courseid']=$row[0]['courseid'];
            $arr['ctype']=$row[0]['ctype'];
            $arr['stest']=$row[0]['screentest'];
            $arr['refund']=$row[0]['refund'];
            $arr['examtime']=$row[0]['examtime'];
            $arr['reportingtime']=$row[0]['reportingtime'];
            $arr['cooloftime']=$row[0]['cooloftime'];
            $arr['modeofexam']=$row[0]['modeofexam'];
            $arr['stream']=$row[0]['stream'];
            $arr['type']=$row[0]['type'];
            $arr['accountinghead']=$row[0]['accountinghead'];
            $arr['idcard_displayname']=$row[0]['idcard_displayname'];
          
            
        }
        
        //for duration edit
        
        $duration = explode(" ",$arr['duration']);
        $arr['duration_value'] = $duration[0];
        $arr['duration_time'] = $duration[1];
        
        
        //for payment edit
        if(($type === "payment")&& ($arr['centers'] !== '')){
            
            $centers = explode("|", $arr['centers']);
            $retHTML = "";
            for($i = 0 ; $i < count($centers);$i++){

                if($centers[$i] !== "") {
            $retHTML .= "<li ><label style=\"text-align: left;color:#536485;background: none;border: 0px;width: auto;height: auto;float:left;font-size: 15px\"><input class=\"radiocenters\" attr-centers=\"".$centers[$i]."\" name=\"radiocenters\" type=\"radio\" />".$centers[$i]."</li></label>";
            }
        }

            $arr["centers"] = $retHTML;            
            
        }
        
       
        return $arr;
        
    }
    

    
    public function GetAllCenters($inp,$type,$screen=""){
        
        $retHTML = "";
        $selected="";$where = "";
        if($screen === "1") { $where = " where screentest='on'";}
         $query2 = $this-> db -> query('select * from typo_unit'.$where);
	$row = $query2->result_array();
        if ($row) {
            
                $cenArr = explode("|",$inp);
                for($i=0 ; $i < count($row);$i++) {
                    if( ($row[$i]["unit"] == $inp) || (in_array($row[$i]["unit"],$cenArr))) {
                        $selected = 'selected=selected';
                    }
                    
                    if($type === "option"){
                        $retHTML .= "<option ".$selected.">".$row[$i]["unit"]."</option>";
                    } else {
                        $retHTML .= "<li ".$selected."><label style=\"text-align: left;color:#536485;background: none;border: 0px;width: auto;height: auto;float:left;font-size: 15px\"><input class=\"radiocenters\" attr-centers=\"".$row[$i]["unit"]."\" name=\"radiocenters\" type=\"radio\" />".$row[$i]["unit"]."</li></label>";
                    }
                   $selected = "";
                }
                
        }
        
        return $retHTML;
        
    }
    
    
     public function GetAllCities($inp){
        
        $retHTML = "";
        $selected="";
        $query2 = $this-> db -> query('select * from bscp_cities');
	$row = $query2->result_array();
        if ($row) {
            
                for($i=0 ; $i < count($row);$i++) {
                    if( ($row[$i]["name"] == $inp) || ((strpos($inp,$row[$i]["name"]) !== false))) {
                        $selected = 'selected=selected';
                    }
                    
                    $retHTML .= "<option ".$selected.">".$row[$i]["name"]."</option>";
                   $selected = "";
                }
                
        }
        
        return $retHTML;
        
    }
    
	
	// Account Head Option
	
	public function GetAllAccounthead($inp=""){
        
        $retHTML = "";
		
        $query2 = $this-> db -> query('select * from bscp_accounthead order by ahname asc');
		$row = $query2->result_array();
        if ($row) {
            
                for($i=0 ; $i < count($row);$i++) {
						
					$selected = "";
					
                    if( ($row[$i]["ahname"] == $inp) || ((strpos($inp,$row[$i]["ahname"]) !== false))) {
                        $selected = 'selected=selected';
                    }
                    
                    $retHTML .= "<option ".$selected.">".$row[$i]["ahname"]."</option>";
					
                }
                
        }
        
        return $retHTML;
        
    }
   
   public function GetAllCourses($inp){
       
        $query2 = $this-> db -> query('select coursename,courseid from admin_course');
	$row = $query2->result_array();
        
        $retHTML = "";
        $selected="";
        $inpArray =explode("|",$inp);
        if ($row) {
            
                for($i=0 ; $i < count($row);$i++) {
                    if(in_array($row[$i]["courseid"], $inpArray)) {
                        $selected = 'selected=selected';
                    }
                    
                    $retHTML .= "<option value='".$row[$i]["courseid"]."'" .$selected.">".$row[$i]["coursename"]."</option>";
                   $selected = "";
                }
                
        }
        return $retHTML;       
   }
   
    public function insertCourseRequest($qData)
    {
		
		$query = $this-> db -> query('select ide,approved from bscp_courserequest where studentid="'.$qData['studentid'].'" and qualificationid="'.$qData['qualificationid'].'"');
		$row = $query->result_array();
        if ($query->num_rows()===0) {
			
        	$this->db->insert('bscp_courserequest', $qData);
        	return "success";
			
		}else{
							
			return "exists";
							
		}
		
    }
	
	 public function insertAdmissionCourseRequest($qData)
    {
		
		$query = $this-> db -> query('select ide,approved from bscp_courserequest where studentid="'.$qData['studentid'].'" and courseid="'.$qData['courseid'].'"');
		$row = $query->result_array();
        if ($query->num_rows()===0) {
			
        	$this->db->insert('bscp_courserequest', $qData);
        	return "success";
			
		}else{
							
			return "exists";
							
		}
		
    }
    
     public function UpdateCourseRequest($cData) {
        
        
        $this->db->update('bscp_courserequest', $cData, array('ide' => $cData['ide']));
        
    }
	
	// Remove Marksheet
	
	public function DeleteQMarksheet($ide,$studentid,$filename){
        
		$result = array(0 => "");
		
		$query = $this-> db -> query('select marksheets from bscp_courserequest where studentid="'.$studentid.'" and ide="'.$ide.'"');
		$row = $query->result_array();
        if ($query->num_rows()==1) {
			
			$marksheets = $row[0]['marksheets'];
			
			$marksheetsnew = "";
			if($marksheets!="")
			{
				$marksheetarr = explode("|",$marksheets);
			
				if (($key = array_search($filename, $marksheetarr)) !== false) {

					 $dirname = FCPATH.'docs/courserequest/marksheets/'.$studentid.'/'.$filename;
					 if(file_exists($dirname)) unlink($dirname);

					unset($marksheetarr[$key]);
				}
				
				if(!empty($marksheetarr)) $marksheetsnew = implode("|",$marksheetarr);
			}
			
						
			$query1 = $this-> db -> query('update `bscp_courserequest` set marksheets="'.$marksheetsnew.'"  where studentid="'.$studentid.'" and ide="'.$ide.'"');
			if($query1) {
				$result = array(0 => "success");
			} else {
				$result = array(0 => "fail");
			}
			
		}
        
        return $result; 
        
        
    }
    
    public function GetRequestedCenterCourses() {
        
        $arr = Array();
		
		$arr['list'] = "";
		
		$this->load->model('login_model','',TRUE);
		$user = $this->login_model->GetUserId();
		
		$roleaccess = $this->config->item('roleaccess');
		
		$keywords_imploded = "";
		if(!empty($user['batches']) && !in_array("All", $user['batches'])){
			
			$keywords_imploded = ' and bscp_courserequest.batchname IN ("'.implode('","',$user['batches']).'")';
			
		}
		
                //$this->datatables->set_database("default");
	        $this->datatables->select('bscp_courserequest.center as center,admin_course.courseid as cuid,admin_course.coursename as courseid,bscp_courserequest.courseid as cid,sum(case when approved = "y" then 1 else 0 end) AS admitted,
    sum(case when approved = "n" or approved = "q" or approved = "" then 1 else 0 end) AS pending,sum(case when approved = "w" then 1 else 0 end) AS waitinglist,sum(case when approved = "d" then 1 else 0 end) AS rejected,sum(case when approved = "s" then 1 else 0 end) AS shortlist,count(*) AS total') 
              ->edit_column('courseid', '<a data-id="$1" class="idValue" style="float:left;padding:0px;font-size:15px;text-align:left;line-height:20px" href="'.base_url().'admissions?id=$1&center=$2">$3</a>', 'cid,center,courseid')
              ->edit_column('requested_at', '<a class="noedit" id="$1" href="'.base_url().'admissions?id=$1&center=$2"><img style="padding:5px 10px" src="'.$this->config->item('web_url')."images/view.png".'"></a>','cid,center')
              ->edit_column('approved', '<span class="cstatus">$1</span>', 'approved')
              ->edit_column('admitted', '<a data-id="$1" class="idValue" style="text-decoration:underline;padding:0px;font-size:15px;line-height:20px" href="'.base_url().'admissions?id=$1&center=$2&type=y">$3</a>', 'cid,center,admitted')
             ->edit_column('pending', '<a data-id="$1" class="idValue" style="text-decoration:underline;padding:0px;font-size:15px;line-height:20px" href="'.base_url().'admissions?id=$1&center=$2&type=n">$3</a>', 'cid,center,pending')
             ->edit_column('waitinglist', '<a data-id="$1" class="idValue" style="text-decoration:underline;padding:0px;font-size:15px;line-height:20px" href="'.base_url().'admissions?id=$1&center=$2&type=w">$3</a>', 'cid,center,waitinglist')
             ->edit_column('shortlist', '<a data-id="$1" class="idValue" style="text-decoration:underline;padding:0px;font-size:15px;line-height:20px" href="'.base_url().'admissions?id=$1&center=$2&type=s">$3</a>', 'cid,center,shortlist')
             ->edit_column('rejected', '<a data-id="$1" class="idValue" style="text-decoration:underline;padding:0px;font-size:15px;line-height:20px" href="'.base_url().'admissions?id=$1&center=$2&type=d">$3</a>', 'cid,center,rejected')
              ->from('bscp_courserequest')
              ->where('admin_course.screentest != "1"'.$keywords_imploded)
              ->group_by('center')   
              ->group_by('bscp_courserequest.courseid')   
              ->group_by('admin_course.coursename')   
              ->join('admin_course', 'admin_course.ide=bscp_courserequest.courseid', 'left');
                
            
                
                $table =  $this->datatables->generate();
		
		return $table;
        
    }
    
    //Overall Screen test list
    public function GetRequestedSTCourses($batches) {
        
        $arr = Array();
		
		$arr['list'] = "";
		
		$keywords_imploded = "";
		if(!empty($batches) && !in_array("All", $batches)){
			$keywords_imploded .= ' and bscp_courserequest.batchname IN ("'.implode('","',$batches).'") ';
		}
		
                //$this->datatables->set_database("default");
	        $this->datatables->select('
                admin_course.created_at as created_at,admin_course.starts_on as testdate,admin_course.courseid as cuid,admin_course.coursename as courseid,bscp_courserequest.courseid as cid,
                count(*) AS applied,
                sum(case when (bscp_feepayments.paymentstatus = "p" or bscp_feepayments.total = "0") then 1 else 0 end) AS remitted,
                sum(case when ((bscp_feepayments.paymentstatus = "p" or bscp_feepayments.total = "0") and (bscp_student_payments.reason IS NULL or bscp_student_payments.reason !="discontinue") ) then 1 else 0 end) AS actualremitted,
                sum(case when (bscp_feepayments.paymentstatus = "" and bscp_feepayments.total != "0") then 1 else 0 end) AS pending,
                sum(case when bscp_courserequest.issue_ht = "Y" then 1 else 0 end) AS issue_ht,
                sum(case when bscp_courserequest.download_ht = "Y" then 1 else 0 end) AS download_ht,admin_course.st_status,admin_course.ide') 
              ->edit_column('courseid', '<a data-id="$1" class="idValue" style="float:left;padding:0px;font-size:15px;text-align:left;line-height:20px" href="'.base_url().'screeningtest?id=$1">$2</a>', 'cid,courseid')
              ->edit_column('applied', '<a data-id="$1" class="idValue" style="text-decoration:underline;padding:0px;font-size:15px;line-height:20px" href="'.base_url().'screeningtest?id=$1&type=slist&mode=all">$2</a>', 'cid,applied')
              ->edit_column('remitted', '<a data-id="$1" class="idValue" style="text-decoration:underline;padding:0px;font-size:15px;line-height:20px" href="'.base_url().'screeningtest?id=$1&type=slist&mode=r">$2</a>', 'cid,remitted')
              ->edit_column('actualremitted', '<a data-id="$1" class="idValue" style="text-decoration:underline;padding:0px;font-size:15px;line-height:20px" href="'.base_url().'screeningtest?id=$1&type=slist&mode=ar">$2</a>', 'cid,actualremitted')
              ->edit_column('pending', '<a data-id="$1" class="idValue" style="text-decoration:underline;padding:0px;font-size:15px;line-height:20px" href="'.base_url().'screeningtest?id=$1&type=slist&mode=p">$2</a>', 'cid,pending')
              ->edit_column('cuid', '$1', 'cuid')
               ->edit_column('created_at', '<p class="sno" style="margin:0px"></p>', '')
				->edit_column('st_status', '$1', 'check_st_status(ide,st_status)')
              ->from('bscp_courserequest')
              ->where('bscp_courserequest.approved','y')
              ->where('admin_course.screentest = "1"'.$keywords_imploded)
              ->group_by('bscp_courserequest.courseid')                          
              ->join('admin_course', 'admin_course.ide=bscp_courserequest.courseid', 'left')
              ->join('bscp_feepayments','bscp_feepayments.requestid=bscp_courserequest.ide','left')
              ->join('bscp_student_payments','bscp_student_payments.requestid=bscp_courserequest.ide','left');
              
                $table =  $this->datatables->generate();
		
		return $table;
        
    }
	
	public function ChangeSTStatus($ide,$status){
        
        $qData = array(
              'st_status' => $status,
               'ide' => $ide);
          $query1 = $this->db->update('admin_course', $qData, array('ide' => $qData['ide']));
        //$query1 = $this-> db -> query('update `admin_course` set status="'.$status.'" where ide="'.$ide.'"');
        if($query1) {
            $result = array(0 => "success");
        } else {
            $result = array(0 => "fail");
        }
        
        return $result; 
        
        
    }
	
    
     //Overall Screen test center wise list
      public function GetRequestedCenterSTCourses($cid,$batches) {
        
        $arr = Array();
		
		$arr['list'] = "";
		  
		 $keywords_imploded = "";
		if(!empty($batches) && !in_array("All", $batches)){
			$keywords_imploded .= ' and bscp_courserequest.batchname IN ("'.implode('","',$batches).'") ';
		}
		
                //$this->datatables->set_database("default");
	        $this->datatables->select('bscp_cities.id as ide,bscp_cities.batchqty as tqty,bscp_courserequest.center as center,
                admin_course.courseid as cuid,admin_course.coursename as courseid,bscp_courserequest.courseid as cid,
                count(*) AS applied,
                sum(case when (bscp_feepayments.paymentstatus = "p" or bscp_feepayments.total = "0") then 1 else 0 end) AS remitted,
                sum(case when ((bscp_feepayments.paymentstatus = "p" or bscp_feepayments.total = "0") and (bscp_student_payments.reason IS NULL or bscp_student_payments.reason !="discontinue")) then 1 else 0 end) AS actualremitted,
                sum(case when (bscp_feepayments.paymentstatus = "" and bscp_feepayments.total != "0") then 1 else 0 end) AS pending,
                sum(case when bscp_courserequest.issue_ht = "Y" then 1 else 0 end) AS htissued,
                sum(case when bscp_courserequest.download_ht = "Y" then 1 else 0 end) AS htdownloaded') 
             ->edit_column('applied', '<a data-id="$1" class="idValue" style="text-decoration:underline;padding:0px;font-size:15px;line-height:20px" href="'.base_url().'screeningtest?id=$1&type=cenlist&mode=all&center=$3">$2</a>', 'cid,applied,center')
              ->edit_column('remitted', '<a data-id="$1" class="idValue" style="text-decoration:underline;padding:0px;font-size:15px;line-height:20px" href="'.base_url().'screeningtest?id=$1&type=cenlist&mode=r&center=$3">$2</a>', 'cid,remitted,center')
              ->edit_column('actualremitted', '<a data-id="$1" class="idValue" style="text-decoration:underline;padding:0px;font-size:15px;line-height:20px" href="'.base_url().'screeningtest?id=$1&type=cenlist&mode=ar&center=$3">$2</a>', 'cid,actualremitted,center')
              ->edit_column('pending', '<a data-id="$1" class="idValue" style="text-decoration:underline;padding:0px;font-size:15px;line-height:20px" href="'.base_url().'screeningtest?id=$1&type=cenlist&mode=p&center=$3">$2</a>', 'cid,pending,center')
              ->edit_column('cuid', '<span class="cstatus">$1</span>', 'cuid')              
              ->edit_column('ide', '<span class="cstatus"></span>', '')
              ->edit_column('center', '<a data-id="$1" class="idValue" style="text-decoration:underline;padding:0px;font-size:15px;line-height:20px" href="'.base_url().'screeningtest?id=$1&type=cenlist&mode=all&center=$3">$3</a>', 'cid,applied,center')
              ->from('bscp_courserequest')
              ->where('bscp_courserequest.approved','y')
              ->where('bscp_courserequest.courseid',$cid)
              ->where('admin_course.screentest = "1"'.$keywords_imploded)  
              ->group_by('bscp_courserequest.center')   
              ->join('admin_course', 'admin_course.ide=bscp_courserequest.courseid', 'left')
              ->join('bscp_cities', 'bscp_cities.name=bscp_courserequest.center', 'left')  
              ->join('bscp_feepayments','bscp_feepayments.requestid=bscp_courserequest.ide','left')
               ->join('bscp_student_payments', 'bscp_student_payments.requestid=bscp_courserequest.ide', 'left') ;
              
                $table =  $this->datatables->generate();
		
		return $table;
        
    }
    
  	
	public function GetRequestedSTSTUCourses_count($cid,$type,$batches)
    {   
				
		if($type == "all" || $type == "") {
			
			$whereclause = 'cr.courseid = "'.$cid.'"';
			$groupby = 'cr.studentid';
			
		}else if($type == "r"){
			
			$whereclause = 'cr.courseid = "'.$cid.'" and (fp.paymentamount != 0 or fp.total="0")';
			$groupby = 'cr.studentid';
			
		}else if($type == "ar"){
			
			$whereclause = 'cr.courseid = "'.$cid.'" and (fp.paymentamount != 0 or fp.total="0") and (sp.reason IS NULL or sp.reason !="discontinue")';
			$groupby = 'cr.studentid';
			
		}else if($type == "p"){
			
			$whereclause = 'cr.courseid = "'.$cid.'" and fp.paymentamount = 0';
			$groupby = 'cr.studentid';
		}
				
		if(!empty($batches) && !in_array("All", $batches)){
			
			if($whereclause!="") $whereclause .= ' and '; 
			 $whereclause .= ' cr.batchname IN ("'.implode('","',$batches).'") ';
		 }
				
		$query = $this ->db->query('select cr.ide from bscp_courserequest as cr LEFT JOIN bscp_feepayments as fp ON fp.requestid=cr.ide LEFT JOIN admin_course as c ON c.ide=cr.courseid LEFT JOIN bscp_student_payments as sp ON sp.requestid=cr.ide where '.$whereclause.' group by '.$groupby );
    
        return $query->num_rows();  

    }
    
    public function GetRequestedSTSTUCourses($limit,$start,$col,$dir,$cid,$type,$batches)
    {   
		
		if($type == "all" || $type == "") {
			
			$whereclause = 'cr.courseid = "'.$cid.'"';
			$groupby = 'cr.studentid';
			
		}else if($type == "r"){
			
			$whereclause = 'cr.courseid = "'.$cid.'" and (fp.paymentamount != 0 or fp.total="0")';
			$groupby = 'cr.studentid';
			
		}else if($type == "ar"){
			
			$whereclause = 'cr.courseid = "'.$cid.'" and (fp.paymentamount != 0 or fp.total="0") and (sp.reason IS NULL or sp.reason !="discontinue")';
			$groupby = 'cr.studentid';
			
		}else if($type == "p"){
			
			$whereclause = 'cr.courseid = "'.$cid.'" and fp.paymentamount = 0';
			$groupby = 'cr.studentid';
		}
		
		$selectquery = 'cr.roll_number,cr.download_ht,s.email as email,s.contact as mobile,s.sname as sname,
                    s.studid as studid,cr.center as city,cr.scenter as center,
                c.courseid as cuid,c.coursename as courseid,cr.courseid as cid,cr.studentid as sid,              
                fp.paymentstatus AS remitted';
	
		if(!empty($batches) && !in_array("All", $batches)){
			
			if($whereclause!="") $whereclause .= ' and '; 
			 $whereclause .= ' cr.batchname IN ("'.implode('","',$batches).'") ';
		 }
		
		$query = $this ->db->query('select '.$selectquery.' from bscp_courserequest as cr LEFT JOIN bscp_feepayments as fp ON fp.requestid=cr.ide LEFT JOIN admin_course as c ON c.ide=cr.courseid LEFT JOIN bscp_student as s ON s.id=cr.studentid LEFT JOIN bscp_student_payments as sp ON sp.requestid=cr.ide where '.$whereclause.' group by '.$groupby.' order by '.$col.' '.$dir.' limit '.$start.','.$limit);
        
        if($query->num_rows()>0)
        {
            return $query->result(); 
        }
        else
        {
            return null;
        }
        
    }
   
    public function GetRequestedSTSTUCourses_search($limit,$start,$search,$col,$dir,$cid,$type,$searchcol,$batches)
    {
		
		if($type == "all" || $type == "") {
			
			$whereclause = 'cr.courseid = "'.$cid.'"';
			$groupby = 'cr.studentid';
			
		}else if($type == "r"){
			
			$whereclause = 'cr.courseid = "'.$cid.'" and (fp.paymentamount != 0 or fp.total="0")';
			$groupby = 'cr.studentid';
			
		}else if($type == "ar"){
			
			$whereclause = 'cr.courseid = "'.$cid.'" and (fp.paymentamount != 0 or fp.total="0") and (sp.reason IS NULL or sp.reason !="discontinue")';
			$groupby = 'cr.studentid';
			
		}else if($type == "p"){
			
			$whereclause = 'cr.courseid = "'.$cid.'" and fp.paymentamount = 0';
			$groupby = 'cr.studentid';
		}
		
		$selectquery = 'cr.roll_number,cr.download_ht,s.email as email,s.contact as mobile,s.sname as sname,
                    s.studid as studid,cr.center as city,cr.scenter as center,
                c.courseid as cuid,c.coursename as courseid,cr.courseid as cid,cr.studentid as sid,              
                 fp.paymentstatus AS remitted';
		
		
		$wheresearch = '';
		
		if($searchcol!="") $wheresearch .= ' and (';
		
		if($searchcol=="stuid"){$wheresearch .= ' `s`.`studid` = "'.$search.'"';}
		else if($searchcol=="stuname"){$wheresearch .= ' `s`.`sname` LIKE "%'.$search.'%"';}
		else if($searchcol=="mobile"){$wheresearch .= ' `s`.`contact` = "'.$search.'"';}
		else if($searchcol=="email"){$wheresearch .= ' `s`.`email` = "'.$search.'"';}
		else if($searchcol=="rollno"){$wheresearch .= ' `cr`.`roll_number` = "'.$search.'"';}
                else if($searchcol=="city"){$wheresearch .= ' `cr`.`center` LIKE "%'.$search.'%"';}
		else if($searchcol=="center"){$wheresearch .= ' `cr`.`scenter` LIKE "%'.$search.'%"';}
			
		if($searchcol!="") $wheresearch .= ')';
		
		$whereclause = $whereclause.$wheresearch;
		
		if(!empty($batches) && !in_array("All", $batches)){
			
			if($whereclause!="") $whereclause .= ' and '; 
			 $whereclause .= ' cr.batchname IN ("'.implode('","',$batches).'") ';
		 }
				
		$query = $this ->db->query('select '.$selectquery.' from bscp_courserequest as cr LEFT JOIN bscp_feepayments as fp ON fp.requestid=cr.ide LEFT JOIN admin_course as c ON c.ide=cr.courseid LEFT JOIN bscp_student as s ON s.id=cr.studentid LEFT JOIN bscp_student_payments as sp ON sp.requestid=cr.ide where '.$whereclause.' group by '.$groupby.' order by '.$col.' '.$dir.' limit '.$start.','.$limit);
        
       
        if($query->num_rows()>0)
        {
            return $query->result();  
        }
        else
        {
            return null;
        }
    }

    public function GetRequestedSTSTUCourses_search_count($search,$cid,$type,$searchcol,$batches)
    {
		
		if($type == "all" || $type == "") {
			
			$whereclause = 'cr.courseid = "'.$cid.'"';
			$groupby = 'cr.studentid';
			
		}else if($type == "r"){
			
			$whereclause = 'cr.courseid = "'.$cid.'" and (fp.paymentamount != 0 or fp.total="0")';
			$groupby = 'cr.studentid';
			
		}else if($type == "ar"){
			
			$whereclause = 'cr.courseid = "'.$cid.'" and (fp.paymentamount != 0 or fp.total="0") and (sp.reason IS NULL or sp.reason !="discontinue")';
			$groupby = 'cr.studentid';
			
		}else if($type == "p"){
			
			$whereclause = 'cr.courseid = "'.$cid.'" and fp.paymentamount = 0';
			$groupby = 'cr.studentid';
		}
		
		$selectquery = 'cr.roll_number,cr.download_ht,s.email as email,s.contact as mobile,s.sname as sname,
                    s.studid as studid,cr.center as city,cr.scenter as center,
                c.courseid as cuid,c.coursename as courseid,cr.courseid as cid,cr.studentid as sid,              
                fp.paymentstatus AS remitted';
		
		
		$wheresearch = '';
		
		if($searchcol!="") $wheresearch .= ' and (';
		
		if($searchcol=="stuid"){$wheresearch .= ' `s`.`studid` = "'.$search.'"';}
		else if($searchcol=="stuname"){$wheresearch .= ' `s`.`sname` LIKE "%'.$search.'%"';}
		else if($searchcol=="mobile"){$wheresearch .= ' `s`.`contact` = "'.$search.'"';}
		else if($searchcol=="email"){$wheresearch .= ' `s`.`email` = "'.$search.'"';}
		else if($searchcol=="rollno"){$wheresearch .= ' `cr`.`roll_number` = "'.$search.'"';}
                else if($searchcol=="city"){$wheresearch .= ' `cr`.`center` LIKE "%'.$search.'%"';}
		else if($searchcol=="center"){$wheresearch .= ' `cr`.`scenter` LIKE "%'.$search.'%"';}
			
		if($searchcol!="") $wheresearch .= ')';
		
		$whereclause = $whereclause.$wheresearch;
		
		if(!empty($batches) && !in_array("All", $batches)){
			
			if($whereclause!="") $whereclause .= ' and '; 
			 $whereclause .= ' cr.batchname IN ("'.implode('","',$batches).'") ';
		 }
		
		$query = $this ->db->query('select cr.ide from bscp_courserequest as cr LEFT JOIN bscp_feepayments as fp ON fp.requestid=cr.ide LEFT JOIN admin_course as c ON c.ide=cr.courseid LEFT JOIN bscp_student as s ON s.id=cr.studentid LEFT JOIN bscp_student_payments as sp ON sp.requestid=cr.ide where '.$whereclause.' group by '.$groupby );
    
        return $query->num_rows();
    }
    
 	
	public function GetRequestedCenterSTSTUCourses_count($cid,$type,$center,$batches)
    {   
				
		if($type == "all" || $type == "") {
			
			$whereclause = 'cr.courseid = "'.$cid.'" and cr.center = "'.$center.'"';
			$groupby = 'cr.studentid';
			
		}else if($type == "r"){
			
			$whereclause = 'cr.courseid = "'.$cid.'" and cr.center = "'.$center.'" and (fp.paymentamount != 0 or fp.total="0")';
			$groupby = 'cr.studentid';
			
		}else if($type == "ar"){
			
			$whereclause = 'cr.courseid = "'.$cid.'" and cr.center = "'.$center.'" and (fp.paymentamount != 0 or fp.total="0") and (sp.reason IS NULL or sp.reason !="discontinue")';
			$groupby = 'cr.studentid';
			
		}else if($type == "p"){
			
			$whereclause = 'cr.courseid = "'.$cid.'" and cr.center = "'.$center.'" and fp.paymentamount = 0';
			$groupby = 'cr.studentid';
		}
		
		if(!empty($batches) && !in_array("All", $batches)){
			
			if($whereclause!="") $whereclause .= ' and '; 
			 $whereclause .= ' cr.batchname IN ("'.implode('","',$batches).'") ';
		 }
				
		$query = $this ->db->query('select cr.ide from bscp_courserequest as cr LEFT JOIN bscp_feepayments as fp ON fp.requestid=cr.ide LEFT JOIN bscp_student_payments as sp ON sp.requestid=cr.ide where '.$whereclause.' group by '.$groupby );
    
        return $query->num_rows();  

    }
    
    public function GetRequestedCenterSTSTUCourses($limit,$start,$col,$dir,$cid,$type,$center,$batches)
    {   
		
		if($type == "all" || $type == "") {
			
			$whereclause = 'cr.courseid = "'.$cid.'" and cr.center = "'.$center.'"';
			$groupby = 'cr.studentid';
			
		}else if($type == "r"){
			
			$whereclause = 'cr.courseid = "'.$cid.'" and cr.center = "'.$center.'" and (fp.paymentamount != 0 or fp.total="0")';
			$groupby = 'cr.studentid';
			
		}else if($type == "ar"){
			
			$whereclause = 'cr.courseid = "'.$cid.'" and cr.center = "'.$center.'" and (fp.paymentamount != 0 or fp.total="0") and (sp.reason IS NULL or sp.reason !="discontinue")';
			$groupby = 'cr.studentid';
			
		}else if($type == "p"){
			
			$whereclause = 'cr.courseid = "'.$cid.'" and cr.center = "'.$center.'" and fp.paymentamount = 0';
			$groupby = 'cr.studentid';
		}
		
		if(!empty($batches) && !in_array("All", $batches)){
			
			if($whereclause!="") $whereclause .= ' and '; 
			 $whereclause .= ' cr.batchname IN ("'.implode('","',$batches).'") ';
		 }
		
		$selectquery = 'cr.studentid as sid,cr.scenter,cr.roll_number,cr.download_ht,cr.ide,cr.issue_ht,s.email as email,s.contact as mobile,s.sname as sname, s.studid as studid,cr.center as center, c.courseid as cuid,c.coursename as courseid,cr.courseid as cid, fp.paymentstatus as remitted';
	
		
		$query = $this ->db->query('select '.$selectquery.' from bscp_courserequest as cr LEFT JOIN bscp_feepayments as fp ON fp.requestid=cr.ide LEFT JOIN admin_course as c ON c.ide=cr.courseid LEFT JOIN bscp_student as s ON s.id=cr.studentid LEFT JOIN bscp_student_payments as sp ON sp.requestid=cr.ide where '.$whereclause.' group by '.$groupby.' order by '.$col.' '.$dir.' limit '.$start.','.$limit);
        
        if($query->num_rows()>0)
        {
            return $query->result(); 
        }
        else
        {
            return null;
        }
        
    }
   
    public function GetRequestedCenterSTSTUCourses_search($limit,$start,$search,$col,$dir,$cid,$type,$center,$searchcol,$batches)
    {
		
		if($type == "all" || $type == "") {
			
			$whereclause = 'cr.courseid = "'.$cid.'" and cr.center = "'.$center.'"';
			$groupby = 'cr.studentid';
			
		}else if($type == "r"){
			
			$whereclause = 'cr.courseid = "'.$cid.'" and cr.center = "'.$center.'" and (fp.paymentamount != 0 or fp.total="0")';
			$groupby = 'cr.studentid';
			
		}else if($type == "ar"){
			
			$whereclause = 'cr.courseid = "'.$cid.'" and cr.center = "'.$center.'" and (fp.paymentamount != 0 or fp.total="0") and (sp.reason IS NULL or sp.reason !="discontinue")';
			$groupby = 'cr.studentid';
			
		}else if($type == "p"){
			
			$whereclause = 'cr.courseid = "'.$cid.'" and cr.center = "'.$center.'" and fp.paymentamount = 0';
			$groupby = 'cr.studentid';
		}
		
		$selectquery = 'cr.studentid as sid,cr.scenter,cr.roll_number,cr.download_ht,cr.ide,cr.issue_ht,s.email as email,s.contact as mobile,s.sname as sname, s.studid as studid,cr.center as center, c.courseid as cuid,c.coursename as courseid,cr.courseid as cid, fp.paymentstatus as remitted';
		
		
		$wheresearch = '';
		
		if($searchcol!="") $wheresearch .= ' and (';
		
		if($searchcol=="stuid"){$wheresearch .= ' `s`.`studid` = "'.$search.'"';}
		else if($searchcol=="stuname"){$wheresearch .= ' `s`.`sname` LIKE "%'.$search.'%"';}
		else if($searchcol=="mobile"){$wheresearch .= ' `s`.`contact` = "'.$search.'"';}
		else if($searchcol=="email"){$wheresearch .= ' `s`.`email` = "'.$search.'"';}
		else if($searchcol=="rollno"){$wheresearch .= ' `cr`.`roll_number` = "'.$search.'"';}
		else if($searchcol=="center"){$wheresearch .= ' `cr`.`scenter` LIKE "%'.$search.'%"';}
			
		if($searchcol!="") $wheresearch .= ')';
		
		$whereclause = $whereclause.$wheresearch;
		
		if(!empty($batches) && !in_array("All", $batches)){
			
			if($whereclause!="") $whereclause .= ' and '; 
			 $whereclause .= ' cr.batchname IN ("'.implode('","',$batches).'") ';
		 }
				
		$query = $this ->db->query('select '.$selectquery.' from bscp_courserequest as cr LEFT JOIN bscp_feepayments as fp ON fp.requestid=cr.ide LEFT JOIN admin_course as c ON c.ide=cr.courseid LEFT JOIN bscp_student as s ON s.id=cr.studentid LEFT JOIN bscp_student_payments as sp ON sp.requestid=cr.ide where '.$whereclause.' group by '.$groupby.' order by '.$col.' '.$dir.' limit '.$start.','.$limit);
        
       
        if($query->num_rows()>0)
        {
            return $query->result();  
        }
        else
        {
            return null;
        }
    }

    public function GetRequestedCenterSTSTUCourses_search_count($search,$cid,$type,$center,$searchcol,$batches)
    {
		
		if($type == "all" || $type == "") {
			
			$whereclause = 'cr.courseid = "'.$cid.'" and cr.center = "'.$center.'"';
			$groupby = 'cr.studentid';
			
		}else if($type == "r"){
			
			$whereclause = 'cr.courseid = "'.$cid.'" and cr.center = "'.$center.'" and (fp.paymentamount != 0 or fp.total="0")';
			$groupby = 'cr.studentid';
			
		}else if($type == "ar"){
			
			$whereclause = 'cr.courseid = "'.$cid.'" and cr.center = "'.$center.'" and (fp.paymentamount != 0 or fp.total="0") and (sp.reason IS NULL or sp.reason !="discontinue")';
			$groupby = 'cr.studentid';
			
		}else if($type == "p"){
			
			$whereclause = 'cr.courseid = "'.$cid.'" and cr.center = "'.$center.'" and fp.paymentamount = 0';
			$groupby = 'cr.studentid';
		}
		
		
		$selectquery = 'cr.studentid as sid,cr.roll_number,cr.download_ht,cr.ide,cr.issue_ht,s.email as email,s.contact as mobile,s.sname as sname, s.studid as studid,cr.center as center, c.courseid as cuid,c.coursename as courseid,cr.courseid as cid, fp.paymentstatus as remitted';
		
		
		$wheresearch = '';
		
		if($searchcol!="") $wheresearch .= ' and (';
		
		if($searchcol=="stuid"){$wheresearch .= ' `s`.`studid` = "'.$search.'"';}
		else if($searchcol=="stuname"){$wheresearch .= ' `s`.`sname` LIKE "%'.$search.'%"';}
		else if($searchcol=="mobile"){$wheresearch .= ' `s`.`contact` = "'.$search.'"';}
		else if($searchcol=="email"){$wheresearch .= ' `s`.`email` = "'.$search.'"';}
		else if($searchcol=="rollno"){$wheresearch .= ' `cr`.`roll_number` = "'.$search.'"';}
		else if($searchcol=="center"){$wheresearch .= ' `cr`.`scenter` LIKE "%'.$search.'%"';}
			
		if($searchcol!="") $wheresearch .= ')';
		
		$whereclause = $whereclause.$wheresearch;
		
		if(!empty($batches) && !in_array("All", $batches)){
			
			if($whereclause!="") $whereclause .= ' and '; 
			 $whereclause .= ' cr.batchname IN ("'.implode('","',$batches).'") ';
		 }
		
		$query = $this ->db->query('select cr.ide from bscp_courserequest as cr LEFT JOIN bscp_feepayments as fp ON fp.requestid=cr.ide LEFT JOIN admin_course as c ON c.ide=cr.courseid LEFT JOIN bscp_student as s ON s.id=cr.studentid LEFT JOIN bscp_student_payments as sp ON sp.requestid=cr.ide where '.$whereclause.' group by '.$groupby );
    
        return $query->num_rows();
    }
    
     public function GetCourseName($cid) {
         
        $arr = '';
        $query1 = $this-> db -> query('select coursename from admin_course  where  ide="'.$cid.'"');
	$row = $query1->result_array();
        if ($row) {
            
            $arr = $row[0]['coursename'];
        } 
        
        return $arr;    
         
     }
     
     public function GetRequestedCourses($cid,$center,$type) {
        
        $arr = Array();
		
		$arr['list'] = ""; 
                
		 
		 $this->load->model('login_model','',TRUE);
		$user = $this->login_model->GetUserId();
		
		$roleaccess = $this->config->item('roleaccess');
		
		$keywords_imploded = "";
		if(!empty($user['batches']) && !in_array("All", $user['batches'])){
			
			$keywords_imploded = ' and bscp_courserequest.batchname IN ("'.implode('","',$user['batches']).'") ';
			
		}
		 
            
                if($type === '') {

	    $this->datatables->select("bscp_courserequest.studentid as studentid,bscp_courserequest.class as class,bscp_courserequest.xii_class as xii_class,bscp_courserequest.status as status,bscp_courserequest.xii_status as xii_status,bscp_courserequest.aq1 as aq1,bscp_courserequest.aq2 as aq2,bscp_courserequest.aq3 as aq3,bscp_courserequest.gracemark as gracemark,bscp_courserequest.xii_gracemark as xii_gracemark,bscp_courserequest.center as center,bscp_courserequest.ide as id,bscp_student.contact as mobile,bscp_student.sname as sname,bscp_student.studid as studid,admin_course.coursename as courseid,bscp_courserequest.stream as stream,bscp_courserequest.grade as grade,bscp_courserequest.mark as mark,bscp_courserequest.xii_stream as xii_stream,approved,bscp_courserequest.xii_grade as xii_grade,bscp_courserequest.xii_mark as xii_mark,,bscp_courserequest.yearofpassing as yearofpassing,bscp_courserequest.xii_yearofpassing as xii_yearofpassing,requested_at") 
              ->edit_column('studid', '<a style="padding-left:0px;float:left;color:#0332AA;" class="noedit" target="_blank" href="studentprofile?sid=$2">$1</a>', 'studid,studentid')
              ->edit_column('sname', '<a data-id="$1" class="idValue" style="float:left;padding:0px;font-size:15px;text-align:left;line-height:20px" href="'.base_url().'viewrequest?id=$1">$2</a>', 'id,sname')
               ->edit_column('stream', '<span data-stream="$1" data-xii-stream="$2" data-status="$3" data-xii-status="$4" class="streamVal">$1</span>', 'stream,xii_stream,status,xii_status')
              ->edit_column('yearofpassing', '<span data-yop="$1" data-xii-yop="$2" data-status="$3" data-xii-status="$4" class="yopVal">$1</span>', 'yearofpassing,xii_yearofpassing,status,xii_status')
              ->edit_column('class', '<span data-class="$1" data-xii-class="$2" data-status="$3" data-xii-status="$4" class="classVal">$1</span>', 'class,xii_class,status,xii_status')
              ->edit_column('gracemark', '<span data-gracemark="$1" data-xii-gracemark="$2" class="graceVal">$1</span>', 'gracemark,xii_gracemark')
              ->edit_column('grade', '<span data-grade="$1" data-xii-grade="$2" data-mark="$3" data-xii-mark="$4" data-status="$5" data-xii-status="$6" class="markVal">$1</span>', 'grade,xii_grade,mark,xii_mark,status,xii_status')
             ->edit_column('xii_stream', '<a class="noedit" id="$1" href="'.base_url().'viewrequest?id=$1"><img style="padding:5px 10px" src="'.$this->config->item('web_url')."images/view.png".'"></a>'
                    . '<!--a class="del noedit" id="$1" href="javascript:void(0)"><img style="padding:5px 10px" src="'.$this->config->item('web_url')."images/delete.png".'"></a-->', 'id')
              ->edit_column('requested_at', '<a style="padding-left:10px;float:left;color:#0332AA;" class="noedit" href="javascript:void(0)"><input class="crequest" type="checkbox" value="$1"></a>', 'id')
              ->edit_column('approved', '<span class="cstatus">$1</span>', 'approved')
              ->edit_column('id', '<span class="ctotal">$1</span>', '')
              ->edit_column('aq1', '<span class="emark">$1</span>', 'aq1')
              ->edit_column('aq2', '<span class="ename">$1</span>', 'aq2')
               ->edit_column('aq3', '<span class="ename">$1</span>', 'aq3')
              ->from('bscp_courserequest')
             ->where('bscp_courserequest.courseid',$cid)
              ->where('bscp_courserequest.center = "'.$center.'"'.$keywords_imploded)
             // ->or_where('approved','y')->or_where('approved','d')->or_where('approved','n')->or_where('approved','w')
              ->join('bscp_student', 'bscp_student.id=bscp_courserequest.studentid', 'left')
              ->join('admin_course', 'admin_course.ide=bscp_courserequest.courseid', 'left');
            
                } else if(($type !== "n")&& ($type !== "q")){
                   
                    
                    $this->datatables->select("bscp_courserequest.studentid as studentid,bscp_courserequest.class as class,bscp_courserequest.xii_class as xii_class,bscp_courserequest.status as status,bscp_courserequest.xii_status as xii_status,bscp_courserequest.aq1 as aq1,bscp_courserequest.aq2 as aq2,bscp_courserequest.aq3 as aq3,bscp_courserequest.gracemark as gracemark,bscp_courserequest.xii_gracemark as xii_gracemark,bscp_courserequest.center as center,bscp_courserequest.ide as id,bscp_student.contact as mobile,bscp_student.sname as sname,bscp_student.studid as studid,admin_course.coursename as courseid,bscp_courserequest.stream as stream,bscp_courserequest.grade as grade,bscp_courserequest.mark as mark,bscp_courserequest.xii_stream as xii_stream,approved,bscp_courserequest.xii_grade as xii_grade,bscp_courserequest.xii_mark as xii_mark,,bscp_courserequest.yearofpassing as yearofpassing,bscp_courserequest.xii_yearofpassing as xii_yearofpassing,requested_at") 
              ->edit_column('studid', '<a style="padding-left:0px;float:left;color:#0332AA;" class="noedit" target="_blank" href="studentprofile?sid=$2">$1</a>', 'studid,studentid')
               ->edit_column('sname', '<a data-id="$1" class="idValue" style="float:left;padding:0px;font-size:15px;text-align:left;line-height:20px" href="'.base_url().'viewrequest?id=$1">$2</a>', 'id,sname')
               ->edit_column('stream', '<span data-stream="$1" data-xii-stream="$2" data-status="$3" data-xii-status="$4" class="streamVal">$1</span>', 'stream,xii_stream,status,xii_status')
              ->edit_column('yearofpassing', '<span data-yop="$1" data-xii-yop="$2" data-status="$3" data-xii-status="$4" class="yopVal">$1</span>', 'yearofpassing,xii_yearofpassing,status,xii_status')
              ->edit_column('class', '<span data-class="$1" data-xii-class="$2" data-status="$3" data-xii-status="$4" class="classVal">$1</span>', 'class,xii_class,status,xii_status')
              ->edit_column('gracemark', '<span data-gracemark="$1" data-xii-gracemark="$2" class="graceVal">$1</span>', 'gracemark,xii_gracemark')
              ->edit_column('grade', '<span data-grade="$1" data-xii-grade="$2" data-mark="$3" data-xii-mark="$4" data-status="$5" data-xii-status="$6" class="markVal">$1</span>', 'grade,xii_grade,mark,xii_mark,status,xii_status')
              ->edit_column('xii_stream', '<a class="noedit" id="$1" href="'.base_url().'viewrequest?id=$1"><img style="padding:5px 10px" src="'.$this->config->item('web_url')."images/view.png".'"></a>'
                    . '<!--a class="del noedit" id="$1" href="javascript:void(0)"><img style="padding:5px 10px" src="'.$this->config->item('web_url')."images/delete.png".'"></a-->', 'id')
              ->edit_column('requested_at', '<a style="padding-left:10px;float:left;color:#0332AA;" class="noedit" href="javascript:void(0)"><input class="crequest" type="checkbox" value="$1"></a>', 'id')
              ->edit_column('approved', '<span class="cstatus">$1</span>', 'approved')
              ->edit_column('id', '<span class="ctotal">$1</span>', '')
          ->edit_column('aq1', '<span class="emark">$1</span>', 'aq1')
              ->edit_column('aq2', '<span class="ename">$1</span>', 'aq2')
               ->edit_column('aq3', '<span class="ename">$1</span>', 'aq3')
              ->from('bscp_courserequest')
             ->where('bscp_courserequest.courseid',$cid)
              ->where('bscp_courserequest.center = "'.$center.'"'.$keywords_imploded)
              ->where('approved',$type)
              ->join('bscp_student', 'bscp_student.id=bscp_courserequest.studentid', 'left')
              ->join('admin_course', 'admin_course.ide=bscp_courserequest.courseid', 'left');
                    
                }else if(($type === "n") || ($type === "q")){
                   
                  
                    
                    $this->datatables->select("bscp_courserequest.studentid as studentid,bscp_courserequest.class as class,bscp_courserequest.xii_class as xii_class,bscp_courserequest.status as status,bscp_courserequest.xii_status as xii_status,bscp_courserequest.aq1 as aq1,bscp_courserequest.aq2 as aq2,bscp_courserequest.aq3 as aq3,bscp_courserequest.gracemark as gracemark,bscp_courserequest.xii_gracemark as xii_gracemark,bscp_courserequest.center as center,bscp_courserequest.ide as id,bscp_student.contact as mobile,bscp_student.sname as sname,bscp_student.studid as studid,admin_course.coursename as courseid,bscp_courserequest.stream as stream,bscp_courserequest.grade as grade,bscp_courserequest.mark as mark,bscp_courserequest.xii_stream as xii_stream,approved,bscp_courserequest.xii_grade as xii_grade,bscp_courserequest.xii_mark as xii_mark,,bscp_courserequest.yearofpassing as yearofpassing,bscp_courserequest.xii_yearofpassing as xii_yearofpassing,requested_at") 
             ->edit_column('studid', '<a style="padding-left:0px;float:left;color:#0332AA;" class="noedit" target="_blank" href="studentprofile?sid=$2">$1</a>', 'studid,studentid')
               ->edit_column('sname', '<a data-id="$1" class="idValue" style="float:left;padding:0px;font-size:15px;text-align:left;line-height:20px" href="'.base_url().'viewrequest?id=$1">$2</a>', 'id,sname')
              ->edit_column('stream', '<span data-stream="$1" data-xii-stream="$2" data-status="$3" data-xii-status="$4" class="streamVal">$1</span>', 'stream,xii_stream,status,xii_status')
              ->edit_column('yearofpassing', '<span data-yop="$1" data-xii-yop="$2" data-status="$3" data-xii-status="$4" class="yopVal">$1</span>', 'yearofpassing,xii_yearofpassing,status,xii_status')
              ->edit_column('class', '<span data-class="$1" data-xii-class="$2" data-status="$3" data-xii-status="$4" class="classVal">$1</span>', 'class,xii_class,status,xii_status')
              ->edit_column('gracemark', '<span data-gracemark="$1" data-xii-gracemark="$2" class="graceVal">$1</span>', 'gracemark,xii_gracemark')
              ->edit_column('grade', '<span data-grade="$1" data-xii-grade="$2" data-mark="$3" data-xii-mark="$4" data-status="$5" data-xii-status="$6" class="markVal">$1</span>', 'grade,xii_grade,mark,xii_mark,status,xii_status')
              ->edit_column('xii_stream', '<a class="noedit" id="$1" href="'.base_url().'viewrequest?id=$1"><img style="padding:5px 10px" src="'.$this->config->item('web_url')."images/view.png".'"></a>'
                    . '<!--a class="del noedit" id="$1" href="javascript:void(0)"><img style="padding:5px 10px" src="'.$this->config->item('web_url')."images/delete.png".'"></a-->', 'id')
              ->edit_column('requested_at', '<a style="padding-left:10px;float:left;color:#0332AA;" class="noedit" href="javascript:void(0)"><input class="crequest" type="checkbox" value="$1"></a>', 'id')
              ->edit_column('approved', '<span class="cstatus">$1</span>', 'approved')
              ->edit_column('id', '<span class="ctotal">$1</span>', '')
           ->edit_column('aq1', '<span class="emark">$1</span>', 'aq1')
              ->edit_column('aq2', '<span class="ename">$1</span>', 'aq2')
               ->edit_column('aq3', '<span class="ename">$1</span>', 'aq3')
              ->from('bscp_courserequest')
             ->where('bscp_courserequest.courseid',$cid)              
              ->where('(approved = "q" or approved = "n" or approved = "")')
             ->where('bscp_courserequest.center = "'.$center.'"'.$keywords_imploded)
              ->join('bscp_student', 'bscp_student.id=bscp_courserequest.studentid', 'left')
              ->join('admin_course', 'admin_course.ide=bscp_courserequest.courseid', 'left');
                    
                }
                
                
                $table =  $this->datatables->generate();
                
                
		
		return $table;
        
    }
    
    
     public function GetStreamFilteredCourses($cid,$center,$cflag,$search,$mtotal,$type) {
        
        $arr = Array();
		
		$arr['list'] = ""; $where = ""; $wheret = "";
		 
		$this->load->model('login_model','',TRUE);
		$user = $this->login_model->GetUserId();
		
		$roleaccess = $this->config->item('roleaccess');
		
		$keywords_imploded = "";
		if(!empty($user['batches']) && !in_array("All", $user['batches'])){
			
			$keywords_imploded = ' and bscp_courserequest.batchname IN ("'.implode('","',$user['batches']).'") ';
			
		}
		 
                
                if($mtotal === "" && $type === '') {
                    
                                    
                    if($cflag === "1") {
                        $where = "bscp_courserequest.xii_stream";
                    } else if($cflag === "2") {
                        $where = "bscp_courserequest.stream";
                    }

                $this->datatables->select('bscp_courserequest.studentid as studentid,bscp_courserequest.class as class,bscp_courserequest.xii_class as xii_class,bscp_courserequest.status as status,bscp_courserequest.xii_status as xii_status,bscp_courserequest.aq1 as aq1,bscp_courserequest.aq2 as aq2,bscp_courserequest.aq3 as aq3,bscp_courserequest.gracemark as gracemark,bscp_courserequest.xii_gracemark as xii_gracemark,bscp_courserequest.center as center,bscp_courserequest.ide as id,bscp_student.contact as mobile,bscp_student.sname as sname,bscp_student.studid as studid,admin_course.coursename as courseid,bscp_courserequest.stream as stream,bscp_courserequest.grade as grade,bscp_courserequest.mark as mark,bscp_courserequest.xii_stream as xii_stream,approved,bscp_courserequest.xii_grade as xii_grade,bscp_courserequest.xii_mark as xii_mark,,bscp_courserequest.yearofpassing as yearofpassing,bscp_courserequest.xii_yearofpassing as xii_yearofpassing,requested_at',FALSE) 
                   ->edit_column('studid', '<a style="padding-left:0px;float:left;color:#0332AA;" class="noedit" target="_blank" href="studentprofile?sid=$2">$1</a>', 'studid,studentid')
               ->edit_column('sname', '<a data-id="$1" class="idValue" style="float:left;padding:0px;font-size:15px;text-align:left;line-height:20px" href="'.base_url().'viewrequest?id=$1">$2</a>', 'id,sname')
               ->edit_column('stream', '<span data-stream="$1" data-xii-stream="$2" data-status="$3" data-xii-status="$4" class="streamVal">$1</span>', 'stream,xii_stream,status,xii_status')
              ->edit_column('yearofpassing', '<span data-yop="$1" data-xii-yop="$2" data-status="$3" data-xii-status="$4" class="yopVal">$1</span>', 'yearofpassing,xii_yearofpassing,status,xii_status')
              ->edit_column('class', '<span data-class="$1" data-xii-class="$2" data-status="$3" data-xii-status="$4" class="classVal">$1</span>', 'class,xii_class,status,xii_status')
              ->edit_column('gracemark', '<span data-gracemark="$1" data-xii-gracemark="$2" class="graceVal">$1</span>', 'gracemark,xii_gracemark')
              ->edit_column('grade', '<span data-grade="$1" data-xii-grade="$2" data-mark="$3" data-xii-mark="$4" data-status="$5" data-xii-status="$6" class="markVal">$1</span>', 'grade,xii_grade,mark,xii_mark,status,xii_status')
              ->edit_column('xii_stream', '<a class="noedit" id="$1" href="'.base_url().'viewrequest?id=$1"><img style="padding:5px 10px" src="'.$this->config->item('web_url')."images/view.png".'"></a>'
                        . '<!--a class="del noedit" id="$1" href="javascript:void(0)"><img style="padding:5px 10px" src="'.$this->config->item('web_url')."images/delete.png".'"></a-->', 'id')
                  ->edit_column('requested_at', '<a style="padding-left:10px;float:left;color:#0332AA;" class="noedit" href="javascript:void(0)"><input class="crequest" type="checkbox" value="$1"></a>', 'id')
                  ->edit_column('approved', '<span class="cstatus">$1</span>', 'approved')
                        ->edit_column('id', '<span class="ctotal">$1</span>', '')
                  ->from('bscp_courserequest')
                 ->where($where,$search)                
                 ->where('bscp_courserequest.courseid',$cid)
                 ->where('bscp_courserequest.center = "'.$center.'"'.$keywords_imploded)
                  ->join('bscp_student', 'bscp_student.id=bscp_courserequest.studentid', 'left')
                  ->join('admin_course', 'admin_course.ide=bscp_courserequest.courseid', 'left');
            
                } else if($mtotal !== "" && $type === ''){
                    
                    if($cflag === "1") {
                        $where = "bscp_courserequest.xii_stream";
                        $wheret = "bscp_courserequest.xii_mark_total >= ";
                    } else if($cflag === "2") {
                        $where = "bscp_courserequest.stream";
                        $wheret = "bscp_courserequest.mark_total >= ";
                    }

                $this->datatables->select('bscp_courserequest.studentid as studentid,bscp_courserequest.class as class,bscp_courserequest.xii_class as xii_class,bscp_courserequest.status as status,bscp_courserequest.xii_status as xii_status,bscp_courserequest.aq1 as aq1,bscp_courserequest.aq2 as aq2,bscp_courserequest.aq3 as aq3,bscp_courserequest.gracemark as gracemark,bscp_courserequest.xii_gracemark as xii_gracemark,bscp_courserequest.center as center,bscp_courserequest.ide as id,bscp_student.contact as mobile,bscp_student.sname as sname,bscp_student.studid as studid,admin_course.coursename as courseid,bscp_courserequest.stream as stream,bscp_courserequest.grade as grade,bscp_courserequest.mark as mark,bscp_courserequest.xii_stream as xii_stream,approved,bscp_courserequest.xii_grade as xii_grade,bscp_courserequest.xii_mark as xii_mark,,bscp_courserequest.yearofpassing as yearofpassing,bscp_courserequest.xii_yearofpassing as xii_yearofpassing,requested_at',FALSE) 
                   ->edit_column('studid', '<a style="padding-left:0px;float:left;color:#0332AA;" class="noedit" target="_blank" href="studentprofile?sid=$2">$1</a>', 'studid,studentid')
               ->edit_column('sname', '<a data-id="$1" class="idValue" style="float:left;padding:0px;font-size:15px;text-align:left;line-height:20px" href="'.base_url().'viewrequest?id=$1">$2</a>', 'id,sname')
               ->edit_column('stream', '<span data-stream="$1" data-xii-stream="$2" data-status="$3" data-xii-status="$4" class="streamVal">$1</span>', 'stream,xii_stream,status,xii_status')
              ->edit_column('yearofpassing', '<span data-yop="$1" data-xii-yop="$2" data-status="$3" data-xii-status="$4" class="yopVal">$1</span>', 'yearofpassing,xii_yearofpassing,status,xii_status')
              ->edit_column('class', '<span data-class="$1" data-xii-class="$2" data-status="$3" data-xii-status="$4" class="classVal">$1</span>', 'class,xii_class,status,xii_status')
              ->edit_column('gracemark', '<span data-gracemark="$1" data-xii-gracemark="$2" class="graceVal">$1</span>', 'gracemark,xii_gracemark')
              ->edit_column('grade', '<span data-grade="$1" data-xii-grade="$2" data-mark="$3" data-xii-mark="$4" data-status="$5" data-xii-status="$6" class="markVal">$1</span>', 'grade,xii_grade,mark,xii_mark,status,xii_status')
              ->edit_column('xii_stream', '<a class="noedit" id="$1" href="'.base_url().'viewrequest?id=$1"><img style="padding:5px 10px" src="'.$this->config->item('web_url')."images/view.png".'"></a>'
                        . '<!--a class="del noedit" id="$1" href="javascript:void(0)"><img style="padding:5px 10px" src="'.$this->config->item('web_url')."images/delete.png".'"></a-->', 'id')
                  ->edit_column('requested_at', '<a style="padding-left:10px;float:left;color:#0332AA;" class="noedit" href="javascript:void(0)"><input class="crequest" type="checkbox" value="$1"></a>', 'id')
                  ->edit_column('approved', '<span class="cstatus">$1</span>', 'approved')
                        ->edit_column('id', '<span class="ctotal">$1</span>', '')
                  ->from('bscp_courserequest')                
                 ->where($where,$search)
                 ->where($wheret,$mtotal)              
                 ->where('bscp_courserequest.courseid',$cid)
                ->where('bscp_courserequest.center = "'.$center.'"'.$keywords_imploded)
                  ->join('bscp_student', 'bscp_student.id=bscp_courserequest.studentid', 'left')
                  ->join('admin_course', 'admin_course.ide=bscp_courserequest.courseid', 'left');
                
                } else if($mtotal === "" && $type !== 'n') {
                    
                                    
                    if($cflag === "1") {
                        $where = "bscp_courserequest.xii_stream";
                    } else if($cflag === "2") {
                        $where = "bscp_courserequest.stream";
                    }

                $this->datatables->select('bscp_courserequest.studentid as studentid,bscp_courserequest.class as class,bscp_courserequest.xii_class as xii_class,bscp_courserequest.status as status,bscp_courserequest.xii_status as xii_status,bscp_courserequest.aq1 as aq1,bscp_courserequest.aq2 as aq2,bscp_courserequest.aq3 as aq3,bscp_courserequest.gracemark as gracemark,bscp_courserequest.xii_gracemark as xii_gracemark,bscp_courserequest.center as center,bscp_courserequest.ide as id,bscp_student.contact as mobile,bscp_student.sname as sname,bscp_student.studid as studid,admin_course.coursename as courseid,bscp_courserequest.stream as stream,bscp_courserequest.grade as grade,bscp_courserequest.mark as mark,bscp_courserequest.xii_stream as xii_stream,approved,bscp_courserequest.xii_grade as xii_grade,bscp_courserequest.xii_mark as xii_mark,,bscp_courserequest.yearofpassing as yearofpassing,bscp_courserequest.xii_yearofpassing as xii_yearofpassing,requested_at',FALSE) 
                  ->edit_column('studid', '<a style="padding-left:0px;float:left;color:#0332AA;" class="noedit" target="_blank" href="studentprofile?sid=$2">$1</a>', 'studid,studentid')
               ->edit_column('sname', '<a data-id="$1" class="idValue" style="float:left;padding:0px;font-size:15px;text-align:left;line-height:20px" href="'.base_url().'viewrequest?id=$1">$2</a>', 'id,sname')
               ->edit_column('stream', '<span data-stream="$1" data-xii-stream="$2" data-status="$3" data-xii-status="$4" class="streamVal">$1</span>', 'stream,xii_stream,status,xii_status')
              ->edit_column('yearofpassing', '<span data-yop="$1" data-xii-yop="$2" data-status="$3" data-xii-status="$4" class="yopVal">$1</span>', 'yearofpassing,xii_yearofpassing,status,xii_status')
              ->edit_column('class', '<span data-class="$1" data-xii-class="$2" data-status="$3" data-xii-status="$4" class="classVal">$1</span>', 'class,xii_class,status,xii_status')
              ->edit_column('gracemark', '<span data-gracemark="$1" data-xii-gracemark="$2" class="graceVal">$1</span>', 'gracemark,xii_gracemark')
              ->edit_column('grade', '<span data-grade="$1" data-xii-grade="$2" data-mark="$3" data-xii-mark="$4" data-status="$5" data-xii-status="$6" class="markVal">$1</span>', 'grade,xii_grade,mark,xii_mark,status,xii_status')
               ->edit_column('xii_stream', '<a class="noedit" id="$1" href="'.base_url().'viewrequest?id=$1"><img style="padding:5px 10px" src="'.$this->config->item('web_url')."images/view.png".'"></a>'
                        . '<!--a class="del noedit" id="$1" href="javascript:void(0)"><img style="padding:5px 10px" src="'.$this->config->item('web_url')."images/delete.png".'"></a-->', 'id')
                  ->edit_column('requested_at', '<a style="padding-left:10px;float:left;color:#0332AA;" class="noedit" href="javascript:void(0)"><input class="crequest" type="checkbox" value="$1"></a>', 'id')
                  ->edit_column('approved', '<span class="cstatus">$1</span>', 'approved')
                        ->edit_column('id', '<span class="ctotal">$1</span>', '')
                  ->from('bscp_courserequest')
                 ->where($where,$search)
                 ->where('bscp_courserequest.approved',$type)
                 ->where('bscp_courserequest.courseid',$cid)
                 ->where('bscp_courserequest.center = "'.$center.'"'.$keywords_imploded)
                  ->join('bscp_student', 'bscp_student.id=bscp_courserequest.studentid', 'left')
                  ->join('admin_course', 'admin_course.ide=bscp_courserequest.courseid', 'left');
            
                } else if($mtotal !== "" && $type !== 'n'){
                    
                    if($cflag === "1") {
                        $where = "bscp_courserequest.xii_stream";
                        $wheret = "bscp_courserequest.xii_mark_total >= ";
                    } else if($cflag === "2") {
                        $where = "bscp_courserequest.stream";
                        $wheret = "bscp_courserequest.mark_total >= ";
                    }

                $this->datatables->select('bscp_courserequest.studentid as studentid,bscp_courserequest.class as class,bscp_courserequest.xii_class as xii_class,bscp_courserequest.status as status,bscp_courserequest.xii_status as xii_status,bscp_courserequest.aq1 as aq1,bscp_courserequest.aq2 as aq2,bscp_courserequest.aq3 as aq3,bscp_courserequest.gracemark as gracemark,bscp_courserequest.xii_gracemark as xii_gracemark,bscp_courserequest.center as center,bscp_courserequest.ide as id,bscp_student.contact as mobile,bscp_student.sname as sname,bscp_student.studid as studid,admin_course.coursename as courseid,bscp_courserequest.stream as stream,bscp_courserequest.grade as grade,bscp_courserequest.mark as mark,bscp_courserequest.xii_stream as xii_stream,approved,bscp_courserequest.xii_grade as xii_grade,bscp_courserequest.xii_mark as xii_mark,,bscp_courserequest.yearofpassing as yearofpassing,bscp_courserequest.xii_yearofpassing as xii_yearofpassing,requested_at',FALSE) 
                  ->edit_column('studid', '<a style="padding-left:0px;float:left;color:#0332AA;" class="noedit" target="_blank" href="studentprofile?sid=$2">$1</a>', 'studid,studentid')
               ->edit_column('sname', '<a data-id="$1" class="idValue" style="float:left;padding:0px;font-size:15px;text-align:left;line-height:20px" href="'.base_url().'viewrequest?id=$1">$2</a>', 'id,sname')
               ->edit_column('stream', '<span data-stream="$1" data-xii-stream="$2" data-status="$3" data-xii-status="$4" class="streamVal">$1</span>', 'stream,xii_stream,status,xii_status')
              ->edit_column('yearofpassing', '<span data-yop="$1" data-xii-yop="$2" data-status="$3" data-xii-status="$4" class="yopVal">$1</span>', 'yearofpassing,xii_yearofpassing,status,xii_status')
              ->edit_column('class', '<span data-class="$1" data-xii-class="$2" data-status="$3" data-xii-status="$4" class="classVal">$1</span>', 'class,xii_class,status,xii_status')
              ->edit_column('gracemark', '<span data-gracemark="$1" data-xii-gracemark="$2" class="graceVal">$1</span>', 'gracemark,xii_gracemark')
              ->edit_column('grade', '<span data-grade="$1" data-xii-grade="$2" data-mark="$3" data-xii-mark="$4" data-status="$5" data-xii-status="$6" class="markVal">$1</span>', 'grade,xii_grade,mark,xii_mark,status,xii_status')
               ->edit_column('xii_stream', '<a class="noedit" id="$1" href="'.base_url().'viewrequest?id=$1"><img style="padding:5px 10px" src="'.$this->config->item('web_url')."images/view.png".'"></a>'
                        . '<!--a class="del noedit" id="$1" href="javascript:void(0)"><img style="padding:5px 10px" src="'.$this->config->item('web_url')."images/delete.png".'"></a-->', 'id')
                  ->edit_column('requested_at', '<a style="padding-left:10px;float:left;color:#0332AA;" class="noedit" href="javascript:void(0)"><input class="crequest" type="checkbox" value="$1"></a>', 'id')
                  ->edit_column('approved', '<span class="cstatus">$1</span>', 'approved')
                        ->edit_column('id', '<span class="ctotal">$1</span>', '')
                  ->from('bscp_courserequest')                
                 ->where($where,$search)
                 ->where($wheret,$mtotal)
                 ->where('bscp_courserequest.approved',$type)
                 ->where('bscp_courserequest.courseid',$cid)
                 ->where('bscp_courserequest.center = "'.$center.'"'.$keywords_imploded)
                  ->join('bscp_student', 'bscp_student.id=bscp_courserequest.studentid', 'left')
                  ->join('admin_course', 'admin_course.ide=bscp_courserequest.courseid', 'left');
                
                } else if($mtotal === "" && $type === 'n') {
                    
                    if($cflag === "1") {
                        $where = "bscp_courserequest.xii_stream";
                    } else if($cflag === "2") {
                        $where = "bscp_courserequest.stream";
                    }

                $this->datatables->select('bscp_courserequest.studentid as studentid,bscp_courserequest.class as class,bscp_courserequest.xii_class as xii_class,bscp_courserequest.status as status,bscp_courserequest.xii_status as xii_status,bscp_courserequest.aq1 as aq1,bscp_courserequest.aq2 as aq2,bscp_courserequest.aq3 as aq3,bscp_courserequest.gracemark as gracemark,bscp_courserequest.xii_gracemark as xii_gracemark,bscp_courserequest.center as center,bscp_courserequest.ide as id,bscp_student.contact as mobile,bscp_student.sname as sname,bscp_student.studid as studid,admin_course.coursename as courseid,bscp_courserequest.stream as stream,bscp_courserequest.grade as grade,bscp_courserequest.mark as mark,bscp_courserequest.xii_stream as xii_stream,approved,bscp_courserequest.xii_grade as xii_grade,bscp_courserequest.xii_mark as xii_mark,,bscp_courserequest.yearofpassing as yearofpassing,bscp_courserequest.xii_yearofpassing as xii_yearofpassing,requested_at',FALSE) 
                   ->edit_column('studid', '<a style="padding-left:0px;float:left;color:#0332AA;" class="noedit" target="_blank" href="studentprofile?sid=$2">$1</a>', 'studid,studentid')
               ->edit_column('sname', '<a data-id="$1" class="idValue" style="float:left;padding:0px;font-size:15px;text-align:left;line-height:20px" href="'.base_url().'viewrequest?id=$1">$2</a>', 'id,sname')
               ->edit_column('stream', '<span data-stream="$1" data-xii-stream="$2" data-status="$3" data-xii-status="$4" class="streamVal">$1</span>', 'stream,xii_stream,status,xii_status')
              ->edit_column('yearofpassing', '<span data-yop="$1" data-xii-yop="$2" data-status="$3" data-xii-status="$4" class="yopVal">$1</span>', 'yearofpassing,xii_yearofpassing,status,xii_status')
              ->edit_column('class', '<span data-class="$1" data-xii-class="$2" data-status="$3" data-xii-status="$4" class="classVal">$1</span>', 'class,xii_class,status,xii_status')
              ->edit_column('gracemark', '<span data-gracemark="$1" data-xii-gracemark="$2" class="graceVal">$1</span>', 'gracemark,xii_gracemark')
              ->edit_column('grade', '<span data-grade="$1" data-xii-grade="$2" data-mark="$3" data-xii-mark="$4" data-status="$5" data-xii-status="$6" class="markVal">$1</span>', 'grade,xii_grade,mark,xii_mark,status,xii_status')
              ->edit_column('xii_stream', '<a class="noedit" id="$1" href="'.base_url().'viewrequest?id=$1"><img style="padding:5px 10px" src="'.$this->config->item('web_url')."images/view.png".'"></a>'
                        . '<!--a class="del noedit" id="$1" href="javascript:void(0)"><img style="padding:5px 10px" src="'.$this->config->item('web_url')."images/delete.png".'"></a-->', 'id')
                  ->edit_column('requested_at', '<a style="padding-left:10px;float:left;color:#0332AA;" class="noedit" href="javascript:void(0)"><input class="crequest" type="checkbox" value="$1"></a>', 'id')
                  ->edit_column('approved', '<span class="cstatus">$1</span>', 'approved')
                        ->edit_column('id', '<span class="ctotal">$1</span>', '')
                  ->from('bscp_courserequest')
                 ->where($where,$search)
                 ->where('(bscp_courserequest.approved="q" or bscp_courserequest.approved ="n" or bscp_courserequest.approved ="")')
                 ->where('bscp_courserequest.courseid',$cid)
                 ->where('bscp_courserequest.center = "'.$center.'"'.$keywords_imploded)
                  ->join('bscp_student', 'bscp_student.id=bscp_courserequest.studentid', 'left')
                  ->join('admin_course', 'admin_course.ide=bscp_courserequest.courseid', 'left');
            
                } else if($mtotal !== "" && $type === 'n'){
                    
                    if($cflag === "1") {
                        $where = "bscp_courserequest.xii_stream";
                        $wheret = "bscp_courserequest.xii_mark_total >= ";
                    } else if($cflag === "2") {
                        $where = "bscp_courserequest.stream";
                        $wheret = "bscp_courserequest.mark_total >= ";
                    }

                $this->datatables->select('bscp_courserequest.studentid as studentid,bscp_courserequest.class as class,bscp_courserequest.xii_class as xii_class,bscp_courserequest.status as status,bscp_courserequest.xii_status as xii_status,bscp_courserequest.aq1 as aq1,bscp_courserequest.aq2 as aq2,bscp_courserequest.aq3 as aq3,bscp_courserequest.gracemark as gracemark,bscp_courserequest.xii_gracemark as xii_gracemark,bscp_courserequest.center as center,bscp_courserequest.ide as id,bscp_student.contact as mobile,bscp_student.sname as sname,bscp_student.studid as studid,admin_course.coursename as courseid,bscp_courserequest.stream as stream,bscp_courserequest.grade as grade,bscp_courserequest.mark as mark,bscp_courserequest.xii_stream as xii_stream,approved,bscp_courserequest.xii_grade as xii_grade,bscp_courserequest.xii_mark as xii_mark,,bscp_courserequest.yearofpassing as yearofpassing,bscp_courserequest.xii_yearofpassing as xii_yearofpassing,requested_at',FALSE) 
                  ->edit_column('studid', '<a style="padding-left:0px;float:left;color:#0332AA;" class="noedit" target="_blank" href="studentprofile?sid=$2">$1</a>', 'studid,studentid')
               ->edit_column('sname', '<a data-id="$1" class="idValue" style="float:left;padding:0px;font-size:15px;text-align:left;line-height:20px" href="'.base_url().'viewrequest?id=$1">$2</a>', 'id,sname')
               ->edit_column('stream', '<span data-stream="$1" data-xii-stream="$2" data-status="$3" data-xii-status="$4" class="streamVal">$1</span>', 'stream,xii_stream,status,xii_status')
              ->edit_column('yearofpassing', '<span data-yop="$1" data-xii-yop="$2" data-status="$3" data-xii-status="$4" class="yopVal">$1</span>', 'yearofpassing,xii_yearofpassing,status,xii_status')
              ->edit_column('class', '<span data-class="$1" data-xii-class="$2" data-status="$3" data-xii-status="$4" class="classVal">$1</span>', 'class,xii_class,status,xii_status')
              ->edit_column('gracemark', '<span data-gracemark="$1" data-xii-gracemark="$2" class="graceVal">$1</span>', 'gracemark,xii_gracemark')
              ->edit_column('grade', '<span data-grade="$1" data-xii-grade="$2" data-mark="$3" data-xii-mark="$4" data-status="$5" data-xii-status="$6" class="markVal">$1</span>', 'grade,xii_grade,mark,xii_mark,status,xii_status')
               ->edit_column('xii_stream', '<a class="noedit" id="$1" href="'.base_url().'viewrequest?id=$1"><img style="padding:5px 10px" src="'.$this->config->item('web_url')."images/view.png".'"></a>'
                        . '<!--a class="del noedit" id="$1" href="javascript:void(0)"><img style="padding:5px 10px" src="'.$this->config->item('web_url')."images/delete.png".'"></a-->', 'id')
                  ->edit_column('requested_at', '<a style="padding-left:10px;float:left;color:#0332AA;" class="noedit" href="javascript:void(0)"><input class="crequest" type="checkbox" value="$1"></a>', 'id')
                  ->edit_column('approved', '<span class="cstatus">$1</span>', 'approved')
                        ->edit_column('id', '<span class="ctotal">$1</span>', '')
                  ->from('bscp_courserequest')                
                 ->where($where,$search)
                 ->where($wheret,$mtotal)
                 ->where('(bscp_courserequest.approved="q" or bscp_courserequest.approved ="n" or bscp_courserequest.approved ="")')
                 ->where('bscp_courserequest.courseid',$cid)
                 ->where('bscp_courserequest.center = "'.$center.'"'.$keywords_imploded)
                  ->join('bscp_student', 'bscp_student.id=bscp_courserequest.studentid', 'left')
                  ->join('admin_course', 'admin_course.ide=bscp_courserequest.courseid', 'left');
                
                }
                
                $table =  $this->datatables->generate();
		
		return $table;
        
    }
    
    
    public function GetMarkFilteredCourses($cid,$center,$cflag,$mtotal,$type) {
        
        $arr = Array();
		
		$arr['list'] = ""; $wheret = "";
          
		
		$this->load->model('login_model','',TRUE);
		$user = $this->login_model->GetUserId();
		
		$roleaccess = $this->config->item('roleaccess');
		
		$keywords_imploded = "";
		if(!empty($user['batches']) && !in_array("All", $user['batches'])){
			
			$keywords_imploded = ' and bscp_courserequest.batchname IN ("'.implode('","',$user['batches']).'") ';
			
		}
		
                                  
                    if($cflag === "1") {
                        $wheret = "bscp_courserequest.xii_mark_total >= ";
                    } else if($cflag === "2") {
                        $wheret = "bscp_courserequest.mark_total >= ";
                    }
                    
                    if($type === "") {
                        
                        $this->datatables->select('bscp_courserequest.studentid as studentid,bscp_courserequest.class as class,bscp_courserequest.xii_class as xii_class,bscp_courserequest.status as status,bscp_courserequest.xii_status as xii_status,bscp_courserequest.aq1 as aq1,bscp_courserequest.aq2 as aq2,bscp_courserequest.aq3 as aq3,bscp_courserequest.gracemark as gracemark,bscp_courserequest.xii_gracemark as xii_gracemark,bscp_courserequest.center as center,bscp_courserequest.ide as id,bscp_student.contact as mobile,bscp_student.sname as sname,bscp_student.studid as studid,admin_course.coursename as courseid,bscp_courserequest.stream as stream,bscp_courserequest.grade as grade,bscp_courserequest.mark as mark,bscp_courserequest.xii_stream as xii_stream,approved,bscp_courserequest.xii_grade as xii_grade,bscp_courserequest.xii_mark as xii_mark,,bscp_courserequest.yearofpassing as yearofpassing,bscp_courserequest.xii_yearofpassing as xii_yearofpassing,requested_at',FALSE) 
                          ->edit_column('studid', '<a style="padding-left:0px;float:left;color:#0332AA;" class="noedit" target="_blank" href="studentprofile?sid=$2">$1</a>', 'studid,studentid')
               ->edit_column('sname', '<a data-id="$1" class="idValue" style="float:left;padding:0px;font-size:15px;text-align:left;line-height:20px" href="'.base_url().'viewrequest?id=$1">$2</a>', 'id,sname')
               ->edit_column('stream', '<span data-stream="$1" data-xii-stream="$2" data-status="$3" data-xii-status="$4" class="streamVal">$1</span>', 'stream,xii_stream,status,xii_status')
              ->edit_column('yearofpassing', '<span data-yop="$1" data-xii-yop="$2" data-status="$3" data-xii-status="$4" class="yopVal">$1</span>', 'yearofpassing,xii_yearofpassing,status,xii_status')
              ->edit_column('class', '<span data-class="$1" data-xii-class="$2" data-status="$3" data-xii-status="$4" class="classVal">$1</span>', 'class,xii_class,status,xii_status')
              ->edit_column('gracemark', '<span data-gracemark="$1" data-xii-gracemark="$2" class="graceVal">$1</span>', 'gracemark,xii_gracemark')
              ->edit_column('grade', '<span data-grade="$1" data-xii-grade="$2" data-mark="$3" data-xii-mark="$4" data-status="$5" data-xii-status="$6" class="markVal">$1</span>', 'grade,xii_grade,mark,xii_mark,status,xii_status')
              ->edit_column('grade', '<span data-grade="$1" data-xii-grade="$2" data-mark="$3" data-xii-mark="$4" class="markVal">$1</span>', 'grade,xii_grade,mark,xii_mark')
                          ->edit_column('xii_stream', '<a class="noedit" id="$1" href="'.base_url().'viewrequest?id=$1"><img style="padding:5px 10px" src="'.$this->config->item('web_url')."images/view.png".'"></a>'
                                . '<!--a class="del noedit" id="$1" href="javascript:void(0)"><img style="padding:5px 10px" src="'.$this->config->item('web_url')."images/delete.png".'"></a-->', 'id')
                          ->edit_column('requested_at', '<a style="padding-left:10px;float:left;color:#0332AA;" class="noedit" href="javascript:void(0)"><input class="crequest" type="checkbox" value="$1"></a>', 'id')
                          ->edit_column('approved', '<span class="cstatus">$1</span>', 'approved')
                                ->edit_column('id', '<span class="ctotal">$1</span>', '')
                          ->from('bscp_courserequest')
                         ->where($wheret,$mtotal)
                         ->where('bscp_courserequest.courseid',$cid)
                         ->where('bscp_courserequest.center = "'.$center.'"'.$keywords_imploded)
                          ->join('bscp_student', 'bscp_student.id=bscp_courserequest.studentid', 'left')
                          ->join('admin_course', 'admin_course.ide=bscp_courserequest.courseid', 'left');
                
                    } else if($type !== "n") {
                        
                        $this->datatables->select('bscp_courserequest.studentid as studentid,bscp_courserequest.class as class,bscp_courserequest.xii_class as xii_class,bscp_courserequest.status as status,bscp_courserequest.xii_status as xii_status,bscp_courserequest.aq1 as aq1,bscp_courserequest.aq2 as aq2,bscp_courserequest.aq3 as aq3,bscp_courserequest.gracemark as gracemark,bscp_courserequest.xii_gracemark as xii_gracemark,bscp_courserequest.center as center,bscp_courserequest.ide as id,bscp_student.contact as mobile,bscp_student.sname as sname,bscp_student.studid as studid,admin_course.coursename as courseid,bscp_courserequest.stream as stream,bscp_courserequest.grade as grade,bscp_courserequest.mark as mark,bscp_courserequest.xii_stream as xii_stream,approved,bscp_courserequest.xii_grade as xii_grade,bscp_courserequest.xii_mark as xii_mark,,bscp_courserequest.yearofpassing as yearofpassing,bscp_courserequest.xii_yearofpassing as xii_yearofpassing,requested_at',FALSE) 
                           ->edit_column('studid', '<a style="padding-left:0px;float:left;color:#0332AA;" class="noedit" target="_blank" href="studentprofile?sid=$2">$1</a>', 'studid,studentid')
               ->edit_column('sname', '<a data-id="$1" class="idValue" style="float:left;padding:0px;font-size:15px;text-align:left;line-height:20px" href="'.base_url().'viewrequest?id=$1">$2</a>', 'id,sname')
               ->edit_column('stream', '<span data-stream="$1" data-xii-stream="$2" data-status="$3" data-xii-status="$4" class="streamVal">$1</span>', 'stream,xii_stream,status,xii_status')
              ->edit_column('yearofpassing', '<span data-yop="$1" data-xii-yop="$2" data-status="$3" data-xii-status="$4" class="yopVal">$1</span>', 'yearofpassing,xii_yearofpassing,status,xii_status')
              ->edit_column('class', '<span data-class="$1" data-xii-class="$2" data-status="$3" data-xii-status="$4" class="classVal">$1</span>', 'class,xii_class,status,xii_status')
              ->edit_column('gracemark', '<span data-gracemark="$1" data-xii-gracemark="$2" class="graceVal">$1</span>', 'gracemark,xii_gracemark')
              ->edit_column('grade', '<span data-grade="$1" data-xii-grade="$2" data-mark="$3" data-xii-mark="$4" data-status="$5" data-xii-status="$6" class="markVal">$1</span>', 'grade,xii_grade,mark,xii_mark,status,xii_status')
              ->edit_column('xii_stream', '<a class="noedit" id="$1" href="'.base_url().'viewrequest?id=$1"><img style="padding:5px 10px" src="'.$this->config->item('web_url')."images/view.png".'"></a>'
                                . '<!--a class="del noedit" id="$1" href="javascript:void(0)"><img style="padding:5px 10px" src="'.$this->config->item('web_url')."images/delete.png".'"></a-->', 'id')
                          ->edit_column('requested_at', '<a style="padding-left:10px;float:left;color:#0332AA;" class="noedit" href="javascript:void(0)"><input class="crequest" type="checkbox" value="$1"></a>', 'id')
                          ->edit_column('approved', '<span class="cstatus">$1</span>', 'approved')
                                ->edit_column('id', '<span class="ctotal">$1</span>', '')
                          ->from('bscp_courserequest')
                         ->where($wheret,$mtotal)
                         ->where('bscp_courserequest.approved',$type)
                         ->where('bscp_courserequest.courseid',$cid)
                         ->where('bscp_courserequest.center = "'.$center.'"'.$keywords_imploded)
                          ->join('bscp_student', 'bscp_student.id=bscp_courserequest.studentid', 'left')
                          ->join('admin_course', 'admin_course.ide=bscp_courserequest.courseid', 'left');
                
                    }else  if($type === "n") {
                        
                        $this->datatables->select('bscp_courserequest.studentid as studentid,bscp_courserequest.class as class,bscp_courserequest.xii_class as xii_class,bscp_courserequest.status as status,bscp_courserequest.xii_status as xii_status,bscp_courserequest.aq1 as aq1,bscp_courserequest.aq2 as aq2,bscp_courserequest.aq3 as aq3,bscp_courserequest.gracemark as gracemark,bscp_courserequest.xii_gracemark as xii_gracemark,bscp_courserequest.center as center,bscp_courserequest.ide as id,bscp_student.contact as mobile,bscp_student.sname as sname,bscp_student.studid as studid,admin_course.coursename as courseid,bscp_courserequest.stream as stream,bscp_courserequest.grade as grade,bscp_courserequest.mark as mark,bscp_courserequest.xii_stream as xii_stream,approved,bscp_courserequest.xii_grade as xii_grade,bscp_courserequest.xii_mark as xii_mark,,bscp_courserequest.yearofpassing as yearofpassing,bscp_courserequest.xii_yearofpassing as xii_yearofpassing,requested_at',FALSE) 
                          ->edit_column('studid', '<a style="padding-left:0px;float:left;color:#0332AA;" class="noedit" target="_blank" href="studentprofile?sid=$2">$1</a>', 'studid,studentid')
               ->edit_column('sname', '<a data-id="$1" class="idValue" style="float:left;padding:0px;font-size:15px;text-align:left;line-height:20px" href="'.base_url().'viewrequest?id=$1">$2</a>', 'id,sname')
               ->edit_column('stream', '<span data-stream="$1" data-xii-stream="$2" data-status="$3" data-xii-status="$4" class="streamVal">$1</span>', 'stream,xii_stream,status,xii_status')
              ->edit_column('yearofpassing', '<span data-yop="$1" data-xii-yop="$2" data-status="$3" data-xii-status="$4" class="yopVal">$1</span>', 'yearofpassing,xii_yearofpassing,status,xii_status')
              ->edit_column('class', '<span data-class="$1" data-xii-class="$2" data-status="$3" data-xii-status="$4" class="classVal">$1</span>', 'class,xii_class,status,xii_status')
              ->edit_column('gracemark', '<span data-gracemark="$1" data-xii-gracemark="$2" class="graceVal">$1</span>', 'gracemark,xii_gracemark')
              ->edit_column('grade', '<span data-grade="$1" data-xii-grade="$2" data-mark="$3" data-xii-mark="$4" data-status="$5" data-xii-status="$6" class="markVal">$1</span>', 'grade,xii_grade,mark,xii_mark,status,xii_status')
               ->edit_column('xii_stream', '<a class="noedit" id="$1" href="'.base_url().'viewrequest?id=$1"><img style="padding:5px 10px" src="'.$this->config->item('web_url')."images/view.png".'"></a>'
                                . '<!--a class="del noedit" id="$1" href="javascript:void(0)"><img style="padding:5px 10px" src="'.$this->config->item('web_url')."images/delete.png".'"></a-->', 'id')
                          ->edit_column('requested_at', '<a style="padding-left:10px;float:left;color:#0332AA;" class="noedit" href="javascript:void(0)"><input class="crequest" type="checkbox" value="$1"></a>', 'id')
                          ->edit_column('approved', '<span class="cstatus">$1</span>', 'approved')
                                ->edit_column('id', '<span class="ctotal">$1</span>', '')
                          ->from('bscp_courserequest')
                         ->where($wheret,$mtotal)
                         ->where('(bscp_courserequest.approved="q" or bscp_courserequest.approved ="n" or bscp_courserequest.approved ="")')
                         ->where('bscp_courserequest.courseid',$cid)
                         ->where('bscp_courserequest.center = "'.$center.'"'.$keywords_imploded)
                          ->join('bscp_student', 'bscp_student.id=bscp_courserequest.studentid', 'left')
                          ->join('admin_course', 'admin_course.ide=bscp_courserequest.courseid', 'left');
                    }
                
                
                
                $table =  $this->datatables->generate();
		
		return $table;
        
    }
    
    public function ApproveRequest($ide,$type=""){
        
        $ide = explode("|",$ide);
    $descArray['Registration Charges'] = 1;$descArray['Caution Deposit'] = 2;
    $descArray['Screening Test Registration Charges'] = 3;$descArray['Tuition Fee'] = 4;
    $descArray['Tuition Fee - 1'] = 5;$descArray['Tuition Fee - 2'] = 6;
        foreach($ide as $key=>$val) {
            if($val === '') { continue;}
            
            /*$qData1 = array(
              'approved' => 'y',
              'approved_date' => date('Y-m-d H:i:s'),
              'ide' => $val);
           $query1 = $this->db->update('bscp_courserequest', $qData1, array('ide' => $qData1['ide']));*/
            $query1 = $this-> db -> query('update `bscp_courserequest` set approved="y",approved_date="'.date('Y-m-d H:i:s').'" where ide="'.$val.'"');
            
            $query2 = $this-> db -> query("select bscp_courserequest.qualificationid as qid,bscp_courserequest.ide as ide,bscp_courserequest.studentid as studentid,bscp_courserequest.courseid as courseid,bscp_courserequest.center as center from bscp_courserequest where bscp_courserequest.ide = '$val'");
            $row = $query2->result_array();
                if ($row) {
                    $cid = $row[0]['courseid'];$center = $row[0]['center'];$sid = $row[0]['studentid'];$qid = $row[0]['qid'];
                }
            
            $query0 = $this-> db -> query("select * from bscp_student_payments where requestid ='$val'");
            if($query0->num_rows() === 0) {
            //$query2 = $this-> db -> query("select bscp_courserequest.qualificationid as qid,bscp_courserequest.ide as ide,bscp_courserequest.studentid as studentid,bscp_courserequest.courseid as courseid,bscp_courserequest.center as center from bscp_courserequest where bscp_courserequest.ide = '$val'");
            //$row = $query2->result_array();
               // if ($row) {
                   // $cid = $row[0]['courseid'];$center = $row[0]['center'];$sid = $row[0]['studentid'];$qid = $row[0]['qualificationid'];
                    $query3 = $this-> db -> query("select * from admin_group where courseid ='$cid' and centers='$center'");
                    $row1 = $query3->result_array();
                        if ($row1) {

                            for($i = 0;$i<count($row1);$i++) {

                                
                             $decs_Order = (array_key_exists($row1[$i]['description'], $descArray))?$descArray[$row1[$i]['description']]:1;
                             
                             //Apply Discount for screening test
                             
                             if($cid === '60f69bbac0ade') {
                                 
                                $query01 = $this-> db -> query("select id from bscp_feepayments where courseid='6061f4d7998a1' and studentid ='$sid' and paymentstatus='p'");
                                if($query01->num_rows() !== 0) {
                                       $row1[$i]['discount'] = '254'; 
                                       $amt = $row1[$i]['amount']; 
                                       $dis = $row1[$i]['discount']; 
                                       
                                       $btot = intval($amt) - intval($dis);
                                       $tax = intval($row1[$i]['tax']);
                                       $kf = intval($row1[$i]['kf']);
                                       
                                       $totamt = $btot + ($btot * ($tax/100)) + ($btot * ($kf/100));
                                       $row1[$i]['total'] = round($totamt);
                                       
                                }
                                 
                             }else if($cid === '61654d5bc4fbe') {
                                 
                                $query01 = $this-> db -> query("select id from bscp_feepayments where courseid='60f69bbac0ade' and studentid ='$sid' and paymentstatus='p'");
                                if($query01->num_rows() !== 0) {
                                       $row1[$i]['discount'] = '275'; 
                                       $amt = $row1[$i]['amount']; 
                                       $dis = $row1[$i]['discount']; 
                                       
                                       $btot = intval($amt) - intval($dis);
                                       $tax = intval($row1[$i]['tax']);
                                       $kf = intval($row1[$i]['kf']);
                                       
                                       $totamt = $btot + ($btot * ($tax/100)) + ($btot * ($kf/100));
                                       $row1[$i]['total'] = round($totamt);
                                       
                                }else{
                                    $query02 = $this-> db -> query("select id from bscp_feepayments where courseid='6061f4d7998a1' and studentid ='$sid' and paymentstatus='p'");
                                    if($query02->num_rows() !== 0) {
                                       $row1[$i]['discount'] = '297'; 
                                       $amt = $row1[$i]['amount']; 
                                       $dis = $row1[$i]['discount']; 
                                       
                                       $btot = intval($amt) - intval($dis);
                                       $tax = intval($row1[$i]['tax']);
                                       $kf = intval($row1[$i]['kf']);
                                       
                                       $totamt = $btot + ($btot * ($tax/100)) + ($btot * ($kf/100));
                                       $row1[$i]['total'] = round($totamt);
                                       
                                    }
                                }
                                 
                             }
                             //end
                          
                             $id = uniqid();
                              $qData = array(
                                'id' => $id,
                                'requestid' => $val,
                                'courseid' => $cid,
                                'centers' => $center,
                                'description' => $row1[$i]['description'],
                                'sac' => $row1[$i]['sac'],
                                'amount' => $row1[$i]['amount'],
                                'discount' => $row1[$i]['discount'],
                                'tax' => $row1[$i]['tax'],
                                'kf' => $row1[$i]['kf'],
                                'cov' => $row1[$i]['cov'],
                                'split' => $row1[$i]['split'],
                                'total' => $row1[$i]['total'],
                                'active' => $row1[$i]['active'],
                                'taxable' => $row1[$i]['taxable'],
                                'studentid' => $sid,
                                'created_at' => date('Y-m-d H:i:s'),
                                'desc_order ' => $decs_Order
                            );


                                $this->db->insert('bscp_student_payments', $qData);

                            }

                        }
                        
                        
               // }
                
            } 
            
            $studentcoursepay =  $this->student_model->GetStudentCourseRequestPayment($sid,$qid,$val);			
            $challan = $this->student_model->CreateChallan($sid,$studentcoursepay,$val);
			
			if($type!="cchange"){
				
				$this->load->model('notification_model','',TRUE);
				$this->notification_model->AdmissionNotification($sid,$cid);
				
			}
			
        }
        
               
        if($query1) {
						
                $result = array(0 => "success");
            } else {
                $result = array(0 => "fail");
            }
            
        return $result; 
        
        
    }
    
    
    
      public function ActivateAppliedList($ide,$approved){
          date_default_timezone_set("Asia/Calcutta");
         /* $qData1 = array(
              'approved' => $approved,
              'approved_date' => date('Y-m-d H:i:s'),
              'ide' => $ide);
           $query1 = $this->db->update('bscp_courserequest', $qData1, array('ide' => $qData1['ide']));*/
        $query1 = $this-> db -> query('update `bscp_courserequest` set approved="'.$approved.'",approved_date="'.date('Y-m-d H:i:s').'" where ide="'.$ide.'"');
        
        if($query1) {
                $result = array(0 => "success");
            } else {
                $result = array(0 => "fail");
            }
            
        return true; 
        
        
    }
    
    public function CheckCourseRequest($courseide,$userid){
       
         $arr = '';
        $query1 = $this-> db -> query('select approved from bscp_courserequest  where  courseid="'.$courseide.'" and studentid="'.$userid.'"');
	$row = $query1->result_array();
        if ($row) {
            
            $arr = $row[0]['approved'];
        } 
        
        return $arr;       
   }
   
   
   public function CheckCourseChangeCourseRequest($courseide,$userid,$center){
       
         $arr = '';
        $query1 = $this-> db -> query('select approved from bscp_courserequest  where  courseid="'.$courseide.'" and studentid="'.$userid.'" and center="'.$center.'"');
	$row = $query1->result_array();
        if ($row) {
            
            $arr = $row[0]['approved'];
        } 
        
        return $arr;       
   }
    
    public function CheckQualifyCourseRequest($userid,$courseid,$qid){
       
         $arr = false;
        $query1 = $this-> db -> query('select courseid,approved from bscp_courserequest  where  qualificationid="'.$qid.'" and studentid="'.$userid.'"');
		$row = $query1->result_array();
        if ($query1->num_rows()>0) {
            
			if($row[0]['courseid']!=$courseid){
				$arr = true;
			}else{
				$arr = false;
			}
            			
        } 
        
        return $arr;       
   }
	
	public function CheckCourseRequestCenter($courseide,$userid){
       
         $arr = '';
        $query1 = $this-> db -> query('select center from bscp_courserequest  where  courseid="'.$courseide.'" and studentid="'.$userid.'"');
	$row = $query1->result_array();
        if ($row) {
            
            $arr = $row[0]['center'];
        } 
        
        return $arr;       
   }
   
   
      public function DeleteRequest($ide){
        
         $query1 = $this-> db -> query('delete from `bscp_courserequest` where ide="'.$ide.'"');
        
        if($query1) {
                $result = array(0 => "success");
            } else {
                $result = array(0 => "fail");
            }
            
        return $result; 
        
        
    }
    
    
    public function UpdateCourseStatus($ide,$status){
        
       /* $qData1 = array(
              'approved' => $status,
              'approved_date' => date('Y-m-d H:i:s'),
              'ide' => $ide);
            $query1 = $this->db->update('bscp_courserequest', $qData1, array('ide' => $qData1['ide']));*/
         $query1 = $this-> db -> query('update `bscp_courserequest` set approved="'.$status.'",approved_date="'.date('Y-m-d H:i:s').'" where ide="'.$ide.'"');
        
        if($query1) {
			
				if($status=="s"){
					$this->load->model('notification_model','',TRUE);
					$this->notification_model->ShortlistedNotification($ide);
				}
			
                $result = array(0 => "success");
			
            } else {
                $result = array(0 => "fail");
            }
            
        return $result; 
        
        
    }
    
    public function GetDistricts($inp){
        
        $retHTML = "";
        $query2 = $this-> db -> query('select * from bscp_statelist where state="'.$inp.'"');
	$row = $query2->result_array();
        if ($row) {
            
                for($i=0 ; $i < count($row);$i++) {
                    
                        $retHTML .= "<option>".$row[$i]["district"]."</option>";
                    
                }
                
        }
        
        return $retHTML;
        
    }
    
    public function InsertLocation($qData)
    {
        $this->db->insert('typo_unit', $qData);
        return $this->db->insert_id();
    }
    
      public function GetLocations(){
		  
		  
		  $roleaccess = $this->config->item('roleaccess');
        
    	    $this->datatables->select('created_at,sno,unit,district,state,ide') 
            ->edit_column('ide', '$1', 'check_locationdelete(ide,"'.$roleaccess['Locations'][2].'")')
            ->edit_column('unit', '<span>$1</a>', 'unit')
            ->edit_column('district', '<span>$1</a>', 'district')
            ->edit_column('state', '<span>$1</a>', 'state')
           ->edit_column('screentest', '<span class="screentest" title="Batch Quantity - $2, Roll no Starts - $3, Roll No Ends - $4">$1</a>', 'screentest,batchqty,rollnostarts,rollnoends')
                    ->edit_column('batchqty', '<span class="batchqty" >$1</a>', 'batchqty')
                    ->edit_column('rollnostarts', '<span class="rollnostarts" >$1</a>', 'rollnostarts')
                    ->edit_column('rollnoends', '<span class="rollnoends">$1</a>', 'rollnoends')
            ->from('typo_unit');
            
            $table =  $this->datatables->generate();
            return $table;
    
    }
    
    public function InsertCity($qData)
    {
        $this->db->insert('bscp_cities', $qData);
        return $this->db->insert_id();
    }
    
    
    public function UpdateCity($qData)
    {
        $this->db->update('bscp_cities', $qData, array('id' => $qData['id']));
        
    }
    
       public function GetCitiess(){
		   
		   $roleaccess = $this->config->item('roleaccess');
        
    	    $this->datatables->select('created_at,sno,name,batchqty,id') 
            ->edit_column('id', '$1', 'check_cityeditdel(id,name,batchqty,rollnostarts,rollnoends,"'.$roleaccess['City'][1].'","'.$roleaccess['City'][2].'")')
            ->edit_column('name', '<span>$1</a>', 'name')
            ->edit_column('batchqty', '<span>$1</a>', 'batchqty')                  
            ->from('bscp_cities');
            
            $table =  $this->datatables->generate();
            return $table;
    
    }
    
    public function DelCitiess($ide){
        
    	    $query1 = $this-> db -> query('delete from `bscp_cities` where id="'.$ide.'"');
        if($query1) {
            $result = array(0 => "success");
        } else {
            $result = array(0 => "fail");
        }
        
        return $result; 
    
    }
    
      public function DelLocation($ide){
        
        $query1 = $this-> db -> query('delete from `typo_unit` where ide="'.$ide.'"');
        if($query1) {
            $result = array(0 => "success");
        } else {
            $result = array(0 => "fail");
        }
        
        return $result; 
        
        
    }
    
    public function InsertCenter($qData)
    {
        $this->db->insert('bscp_centers', $qData);
        return $this->db->insert_id();
    }
    
     public function UpdateCenter($qData)
    {
        $this->db->update('bscp_centers', $qData, array('id' => $qData['id']));
        
    }
    
       public function GetCenters(){
        
		   $roleaccess = $this->config->item('roleaccess');
		   
    	   $this->datatables->select('created_at,sno,name,cityname,address1,address2,area,pincode,rollnostarts,rollnoends,coname,cophone,gurl,id') 
            ->edit_column('id', '$1', 'check_centerseditdel(id,"'.$roleaccess['Centers'][1].'","'.$roleaccess['Centers'][2].'")')
            ->edit_column('name', '<span class="cname">$1</a>', 'name')
            ->edit_column('cityname', '<span class="cityname">$1</a>', 'cityname')
            ->edit_column('address1', '<span class="address1">$1</a>', 'address1')
            ->edit_column('address2', '<span class="address2">$1</a>', 'address2')
            ->edit_column('area', '<span class="aname">$1</a>', 'area')
            ->edit_column('pincode', '<span class="pincode">$1</a>', 'pincode')
            ->edit_column('rollnostarts', '<span class="rollnostarts">$1</a>', 'rollnostarts')
            ->edit_column('rollnoends', '<span class="rollnoends">$1</a>', 'rollnoends')
            ->edit_column('coname', '<span class="coname">$1</a>', 'coname')
            ->edit_column('cophone', '<span class="cophone">$1</a>', 'cophone')   
                    ->edit_column('gurl', '<span class="gurl">$1</a>', 'gurl')   
            ->from('bscp_centers');
            
            $table =  $this->datatables->generate();
            return $table;
    
    }
    
    public function DelCenters($ide){
        
    	    $query1 = $this-> db -> query('delete from `bscp_centers` where id="'.$ide.'"');
        if($query1) {
            $result = array(0 => "success");
        } else {
            $result = array(0 => "fail");
        }
        
        return $result; 
    
    }
    
    public function GetCityWiseCenters($inp){
        
    	   $retHTML = "";
        $query2 = $this-> db -> query('select name from bscp_centers where cityname="'.$inp.'"');
	$row = $query2->result_array();
        if ($row) {
            
                for($i=0 ; $i < count($row);$i++) {
                    
                        $retHTML .= "<option>".$row[$i]["name"]."</option>";
                    
                }
                
        }
        
        return $retHTML;
    
    }
    
    public function InsertClassname($qData)
    {
        $this->db->insert('bscp_stdclass', $qData);
        return $this->db->insert_id();
    }
    
      public function GetClasses(){
        
		  $roleaccess = $this->config->item('roleaccess');
		  
    	    $this->datatables->select('created_at,sno,classname,ide') 
            ->edit_column('ide', '$1', 'check_classdel(ide,"'.$roleaccess['Class'][2].'")')
            ->edit_column('classname', '<span>$1</a>', 'classname')
            ->from('bscp_stdclass');
            
            $table =  $this->datatables->generate();
            return $table;
    
    }
    
      public function DelClassname($ide){
        
        $query1 = $this-> db -> query('delete from `bscp_stdclass` where ide="'.$ide.'"');
        if($query1) {
            $result = array(0 => "success");
        } else {
            $result = array(0 => "fail");
        }
        
        return $result; 
        
        
    }
	
	
	// Account head
	
	public function InsertAccounthead($qData)
    {
        $this->db->insert('bscp_accounthead', $qData);
        return $this->db->insert_id();
    }
    
      public function GetAccounthead(){
        
		  $roleaccess = $this->config->item('roleaccess');
		  
    	    $this->datatables->select('created_at,ahname,ide') 
            ->edit_column('ide', '$1', 'check_ahdel(ide,"'.$roleaccess['Accounting Head'][2].'")')
            ->edit_column('ahname', '<span>$1</a>', 'ahname')
            ->edit_column('created_at', '<p class="sno"></p>', '')
            ->from('bscp_accounthead');
            
            $table =  $this->datatables->generate();
            return $table;
    
    }
    
      public function DelAccounthead($ide){
        
        $query1 = $this-> db -> query('delete from `bscp_accounthead` where ide="'.$ide.'"');
        if($query1) {
            $result = array(0 => "success");
        } else {
            $result = array(0 => "fail");
        }
        
        return $result; 
        
        
    }
	
    
    public function CheckScreeningTest($courseide){
        
        $ret = false;
        $query1 = $this-> db -> query('select ide from admin_course where ide="'.$courseide.'" and screentest="1"');
	$row = $query1->result_array();
        if ($query1->num_rows()>0) {
            
            $ret = true;
        } 
        
        return $ret;
    }
    
    public function ExportAdmissionRequest($ide,$center,$type){
        
        $where = ""; $courseArr = Array();$wheretype = "";
        if(($center !== "") && ($center !== "All")) { $where = " and cr.center='".$center."' ";}
        if(($type !== "n")&&($type !== "")) { $wheretype = " and cr.approved='$type' ";}
        if($type === "n") { $wheretype = " and (cr.approved='n' or cr.approved='q' or cr.approved='') ";}
		
		
		$courseid  = $ide;
        
          $query1 = $this-> db -> query("select s.*,"
                  . "cr.*,c.coursename,c.courseid from bscp_courserequest as cr,bscp_student as s,admin_course as c"
                  . " where cr.courseid='$ide' and cr.studentid=s.id and cr.courseid=c.ide ".$wheretype.$where);
          $row1 = $query1->result_array();
          
          if ($row1) {
            for($i = 0;$i<count($row1);$i++) {
                
                 $ide = $row1[$i]['id'];
                 $courseArr[$ide]['sname'] = $row1[$i]['sname'];$courseArr[$ide]['fname'] = $row1[$i]['fname'];
                 $courseArr[$ide]['contact'] = $row1[$i]['contact'];$courseArr[$ide]['city'] = $row1[$i]['city'];
                 $courseArr[$ide]['email'] = $row1[$i]['email'];$courseArr[$ide]['studid'] = $row1[$i]['studid'];
                 
                $query41 = $this-> db -> query("select sp.* from bscp_studentprofile as sp where sp.stuid='".$ide."'");
                $row41 = $query41->result_array();
                if ($row41) {
               
                 $courseArr[$ide]['guardianname'] = $row41[0]['guardianname'];$courseArr[$ide]['gender'] = $row41[0]['gender'];
                 $courseArr[$ide]['dob'] = $row41[0]['dob'];$courseArr[$ide]['fathername'] = $row41[0]['fathername'];
                 $courseArr[$ide]['fatheroccupation'] = $row41[0]['fatheroccupation'];$courseArr[$ide]['fatheremail'] = $row41[0]['fatheremail'];
                 $courseArr[$ide]['fathercode'] = $row41[0]['fathercode'];$courseArr[$ide]['fatherphone'] = $row41[0]['fatherphone'];
                 $courseArr[$ide]['mothername'] = $row41[0]['mothername'];$courseArr[$ide]['motheroccupation'] = $row41[0]['motheroccupation'];
                 $courseArr[$ide]['motheremail'] = $row41[0]['motheremail'];$courseArr[$ide]['mothercode'] = $row41[0]['mothercode'];
                 $courseArr[$ide]['motherphone'] = $row41[0]['motherphone'];$courseArr[$ide]['communicationcontact'] = $row41[0]['communicationcontact'];
                 $courseArr[$ide]['nationality'] = $row41[0]['nationality'];$courseArr[$ide]['category'] = $row41[0]['category'];
                 $courseArr[$ide]['bloodgroup'] = $row41[0]['bloodgroup'];$courseArr[$ide]['classstudy'] = $row41[0]['classstudy'];
                 $courseArr[$ide]['stream'] = $row41[0]['stream'];$courseArr[$ide]['schoolcollegename'] = $row41[0]['schoolcollegename'];
                 $courseArr[$ide]['eduaddress'] = $row41[0]['eduaddress'];$courseArr[$ide]['edulandmark'] = $row41[0]['edulandmark'];
                 $courseArr[$ide]['edudistrict'] = $row41[0]['edudistrict'];$courseArr[$ide]['edustate'] = $row41[0]['edustate'];
                 $courseArr[$ide]['edupost'] = $row41[0]['edupost'];$courseArr[$ide]['edupincode'] = $row41[0]['edupincode'];
                 $courseArr[$ide]['educountry'] = $row41[0]['educountry'];$courseArr[$ide]['examboard'] = $row41[0]['examboard'];
                 $courseArr[$ide]['examclass'] = $row41[0]['examclass'];$courseArr[$ide]['preferredsubject'] = $row41[0]['preferredsubject'];
                 $courseArr[$ide]['eligiblescholar'] = $row41[0]['eligiblescholar'];$courseArr[$ide]['mocktype'] = $row41[0]['mocktype'];
                 $courseArr[$ide]['rollno'] = $row41[0]['rollno'];$courseArr[$ide]['housenameno'] = $row41[0]['housenameno'];
                 $courseArr[$ide]['landmark'] = $row41[0]['landmark'];$courseArr[$ide]['contactaddress'] = $row41[0]['contactaddress'];
                 $courseArr[$ide]['contactcountry'] = $row41[0]['contactcountry'];$courseArr[$ide]['contactstate'] = $row41[0]['contactstate'];
                 $courseArr[$ide]['contactdistrict'] = $row41[0]['contactdistrict'];$courseArr[$ide]['wacode'] = $row41[0]['wacode'];
                 $courseArr[$ide]['contactpost'] = $row41[0]['contactpost'];$courseArr[$ide]['whatsappno'] = $row41[0]['whatsappno'];
                 $courseArr[$ide]['contactpincode'] = $row41[0]['contactpincode'];$courseArr[$ide]['accountholdername'] = $row41[0]['accountholdername'];
                 $courseArr[$ide]['bankname'] = $row41[0]['bankname'];$courseArr[$ide]['branch'] = $row41[0]['branch'];
                 $courseArr[$ide]['ifsccode'] = $row41[0]['ifsccode'];$courseArr[$ide]['bankaccountno'] = $row41[0]['bankaccountno'];
                 $courseArr[$ide]['aadharnumber'] = $row41[0]['aadharnumber'];
               
                } else {
                 $courseArr[$ide]['guardianname'] ="";$courseArr[$ide]['gender'] = "";
                 $courseArr[$ide]['dob'] = "";$courseArr[$ide]['fathername'] = "";
                 $courseArr[$ide]['fatheroccupation'] ="";$courseArr[$ide]['fatheremail'] = "";
                 $courseArr[$ide]['fathercode'] = "";$courseArr[$ide]['fatherphone'] = "";
                 $courseArr[$ide]['mothername'] = "";$courseArr[$ide]['motheroccupation'] = "";
                 $courseArr[$ide]['motheremail'] = "";$courseArr[$ide]['mothercode'] = "";
                 $courseArr[$ide]['motherphone'] = "";$courseArr[$ide]['communicationcontact'] = "";
                 $courseArr[$ide]['nationality'] = "";$courseArr[$ide]['category'] = "";
                 $courseArr[$ide]['bloodgroup'] = "";$courseArr[$ide]['classstudy'] = "";
                 $courseArr[$ide]['stream'] = "";$courseArr[$ide]['schoolcollegename'] = "";
                 $courseArr[$ide]['eduaddress'] = "";$courseArr[$ide]['edulandmark'] = "";
                 $courseArr[$ide]['edudistrict'] = "";$courseArr[$ide]['edustate'] = "";
                 $courseArr[$ide]['edupost'] = "";$courseArr[$ide]['edupincode'] = "";
                 $courseArr[$ide]['educountry'] = "";$courseArr[$ide]['examboard'] = "";
                 $courseArr[$ide]['examclass'] = "";$courseArr[$ide]['preferredsubject'] = "";
                 $courseArr[$ide]['eligiblescholar'] = "";$courseArr[$ide]['mocktype'] = "";
                 $courseArr[$ide]['rollno'] = "";$courseArr[$ide]['housenameno'] = "";
                 $courseArr[$ide]['landmark'] = "";$courseArr[$ide]['contactaddress'] = "";
                 $courseArr[$ide]['contactcountry'] = "";$courseArr[$ide]['contactstate'] = "";
                 $courseArr[$ide]['contactdistrict'] = "";$courseArr[$ide]['wacode'] = "";
                 $courseArr[$ide]['contactpost'] = "";$courseArr[$ide]['whatsappno'] = "";
                 $courseArr[$ide]['contactpincode'] = "";$courseArr[$ide]['accountholdername'] = "";
                 $courseArr[$ide]['bankname'] = "";$courseArr[$ide]['branch'] = "";
                 $courseArr[$ide]['ifsccode'] = "";$courseArr[$ide]['bankaccountno'] = "";
                 $courseArr[$ide]['aadharnumber'] = "";
                }
                
                 $courseArr[$ide]['courseid'] = $row1[$i]['courseid'];
                 $courseArr[$ide]['coursename'] = $row1[$i]['coursename'];
                 $courseArr[$ide]['center'] = $row1[$i]['center'];
                 $courseArr[$ide]['yearofpassing'] = $row1[$i]['yearofpassing'];
                 $courseArr[$ide]['class'] = $row1[$i]['class'];
                 $courseArr[$ide]['gracemark'] = ($row1[$i]['gracemark'] === "")?"No":"Yes";
                 $courseArr[$ide]['grade'] = str_replace("|", ",", $row1[$i]['grade']);
                 $courseArr[$ide]['mark'] = str_replace("|", ",",$row1[$i]['mark']);
                 $courseArr[$ide]['mark_total'] = $row1[$i]['mark_total'];
                 $courseArr[$ide]['subject'] = str_replace("|", ",", $row1[$i]['subject']);
                 $courseArr[$ide]['xii_yearofpassing'] = $row1[$i]['xii_yearofpassing'];
                 $courseArr[$ide]['xii_status'] = ($row1[$i]['xii_status'] === "P")?"Passed":"Waiting For Result";
                 $courseArr[$ide]['xii_stream'] = $row1[$i]['xii_stream'];
                 $courseArr[$ide]['xii_gracemark'] = ($row1[$i]['xii_gracemark'] === '')?"No":"Yes";
                 $courseArr[$ide]['xii_rollno'] = $row1[$i]['xii_rollno'];
                 $courseArr[$ide]['xii_grade'] = str_replace("|", ",",$row1[$i]['xii_grade']);
                 $courseArr[$ide]['xii_mark'] = str_replace("|", ",",$row1[$i]['xii_mark']);
                 $courseArr[$ide]['xii_mark_total'] = $row1[$i]['xii_mark_total'];
                 $courseArr[$ide]['xii_subject'] = str_replace("|", ",",$row1[$i]['xii_subject']);
                 $courseArr[$ide]['center'] = $row1[$i]['center'];
                 $courseArr[$ide]['entrance_name'] = str_replace("|", ",",$row1[$i]['entrance_name']);
                 $courseArr[$ide]['entrance_mark'] = str_replace("|", ",",$row1[$i]['entrance_mark']);
                 $courseArr[$ide]['aq1'] = $row1[$i]['aq1'];$courseArr[$ide]['aq2'] = $row1[$i]['aq2'];
                 $courseArr[$ide]['aq3'] = $row1[$i]['aq3'];$courseArr[$ide]['entrance_regno'] = str_replace("|", ",",$row1[$i]['entrance_regno']);
                 
                 $query4 = $this-> db -> query("select mcode from bscp_signup where mobile='".$row1[$i]['contact']."'");
                $row4 = $query4->result_array();
                if ($row4) {
                $courseArr[$ide]['mcode'] = $row4[0]['mcode'];
               
                } else {
                    $courseArr[$ide]['mcode'] = '';
                }
				
				
				// Due List
				
				$where1 = "";
				if(($center !== "") && ($center !== "All")) { $where1 = " and a.centers='".$center."' ";}               
         		$query2 = $this-> db -> query('SELECT a.centers as center,a.courseid,a.tax,a.kf,GROUP_CONCAT(DISTINCT a.givenby) as givenby'
                 . ',GROUP_CONCAT(DISTINCT a.reason) as reason,GROUP_CONCAT(DISTINCT a.remarks) as remarks,'
                 . 'sum(a.amount) as atotal,sum(a.discount) as discount,sum(a.amount-a.discount) as wtobepaid,sum(total) as tobepaid'
                 . ' FROM bscp_student_payments as a where a.active="1" and a.requestid="'.$row1[$i]['ide'].'"');
     
       
				$row2 = $query2->result_array();
				if ($query2->num_rows()>0) {
						
						$courseArr[$ide]['total'] = round($row2[0]['total']);
						$courseArr[$ide]['discount'] = $row2[0]['discount'];
						$courseArr[$ide]['givenby'] = $row2[0]['givenby'];
						$courseArr[$ide]['reason'] = $row2[0]['reason'];
						$courseArr[$ide]['remarks'] = $row2[0]['remarks'];
						$courseArr[$ide]['tobepaid'] = $row2[0]['wtobepaid'];
                                                $courseArr[$ide]['atotal'] = $row2[0]['atotal'];
                                                
						$tobepaidwgst = $row2[0]['tobepaid'];
                                                $courseArr[$ide]['total'] = "0"; $courseArr[$ide]['totalw'] = "0";
                
                                                //total fee from course master
                                                $query42 = $this-> db -> query("select sum(amount-discount) as totalw,sum(total) as total from admin_group  where courseid='".$courseid."' and centers='".$row2[0]['center']."'");
                                                $row42 = $query42->result_array();
                                                if ($row42) {
                                                     $courseArr[$ide]['total'] = round($row42[0]['total']);
                                                     $courseArr[$ide]['totalw'] = round($row42[0]['totalw']);
                                                }
                
						$paid = 0;$kfadjust=0;$pamount=0;$paidtax= 0;
                                                $q1 = $this ->db->query('select sum(amount - discount) as amount,sum(total) as total from bscp_feepayments where requestid="'.$row1[$i]['ide'].'" and paymentstatus="p"');
                                               $row23 = $q1->result_array();
                                               if($row23){
                                                   $paid = $row23[0]['total'];
                                                   $pamount = $row23[0]['amount'];
                                               }

                                               $paidtax = floatval($paid) - floatval($pamount);

                                               $q11 = $this ->db->query('select sum(kfadjust) as kfadjust from bscp_feepayments where requestid="'.$row1[$i]['ide'].'" and paymentstatus=""');
                                               $row12 = $q11->result_array();
                                               if($row12){
                                                   $kfadjust = $row12[0]['kfadjust']; 
                                               }


                                               $totaldue = floatval($tobepaidwgst)-floatval($paid);
                                               $sptottax=0;
                                               $q21 = $this ->db->query('select total,tax,kf from bscp_student_payments where requestid="'.$row1[$i]['ide'].'" and active="1"');
                                               $row21 = $q21->result_array();
                                               if($row21){
                                                   for($j = 0;$j<count($row21);$j++) {
                                                      $gst = (($row21[$j]['tax'] === "") || ($row21[$j]['tax'] === "NA"))?0:$row21[$j]['tax'];
                                                      $kf = (($row21[$j]['kf'] === "") || ($row21[$j]['kf'] === "NA"))?0:$row21[$j]['kf'];    
                                                      $tottax = intVal($gst)+intVal($kf);
                                                      $calamount1 = floatval($row21[$j]['total'])*floatval($tottax);
                                                      $calamount1 = round($calamount1);

                                                      $divTax = 100+intVal($tottax);

                                                      $caltax = $calamount1 / $divTax;
                                                      $sptottax = $sptottax + round($caltax, 2);
                                                   }
                                               }


                                               $finaltax = floatval($sptottax) -  floatval($paidtax);         
                                               $calamount = floatval($totaldue) - floatval($finaltax);
                                               $netdue = round($calamount);

                                               //kfaddjust only totaldue
                                               $totaldue = floatval($totaldue)-floatval($kfadjust);
						   $courseArr[$ide]['paid'] = $pamount;
						   $courseArr[$ide]['gst'] = round($finaltax,2);
                                                   $courseArr[$ide]['kfadjust'] = $kfadjust;
						   $courseArr[$ide]['netdue'] = $netdue;
						   $courseArr[$ide]['totaldue'] = $totaldue;

				}
				
				
				// Course change from
				
				$q2 = $this ->db->query('select coursename from bscp_coursechange as cc,admin_course as c  where c.ide=cc.courseid and cc.new_requestid="'.$row1[$i]['ide'].'" ');
				$row5 = $q2->result_array();
				if ($q2->num_rows()>0) {
					$courseArr[$ide]['coursenamefrom'] = $row5[0]['coursename'];                   
				}
				
								
                 
            }
          }
		
          return $courseArr;
        
    }
    
    public function GetNoOfSeats($center,$city) {
         $noofseats=0; 
        $query01 = $this-> db -> query('SELECT rollnoends  FROM bscp_centers WHERE name="'.$center.'" and cityname="'.$city.'"');
        $row11 = $query01->result_array();
        $noofseats = $row11[0]['rollnoends'];
        return $noofseats;
    }


    public function IssueHallTicket($ide,$status,$center,$city,$courseid,$noofseats){
        
         $ctotal=0;      
         $query02 = $this-> db -> query('SELECT count(*) as ctotal FROM bscp_courserequest WHERE courseid="'.$courseid.'" and scenter="'.$center.'" and scity="'.$city.'"');
         $row12 = $query02->result_array();
         if($row12){  $ctotal = $row12[0]['ctotal']; }
         
         if(intval($ctotal) < intval($noofseats)){
            
            $mrollnum = "";
            $query0 = $this-> db -> query('SELECT MAX(CAST(roll_number AS UNSIGNED)) as mroll_number FROM bscp_courserequest WHERE courseid="'.$courseid.'" and scenter="'.$center.'" and scity="'.$city.'"');
            $row1 = $query0->result_array();
            if($row1){ $mrollnum = $row1[0]['mroll_number']; }            

            if(is_null($mrollnum) || $mrollnum === '' || $mrollnum === '0'){

               $query01 = $this-> db -> query('SELECT rollnostarts FROM bscp_centers WHERE name="'.$center.'" and cityname="'.$city.'"');
               $row11 = $query01->result_array();
               $mrollnum = intval($row11[0]['rollnostarts']);

            } else {

                ++$mrollnum; 

            }

           /* $qData1 = array(
              'ide' => $ide,
              'scenter' => $center,
              'issue_ht' => $status,
              'roll_number' => $mrollnum);
            $query1 = $this->db->update('bscp_courserequest', $qData1, array('ide' => $qData1['ide']));*/
            $query1 = $this-> db -> query('update `bscp_courserequest` set scity="'.$city.'",scenter="'.$center.'",issue_ht="'.$status.'",roll_number="'.$mrollnum.'" where ide="'.$ide.'"');

           if($query1) {
                   $result = array(0 => "success");
               } else {
                   $result = array(0 => "fail");
               }
            
        } else{
              $result = array(0 => "novacant");
        }
            
        return $result; 
        
    }
	
	 public function GetStudentCourseCenter($ide) {
		 
        $scenter= ""; 
        $query01 = $this-> db -> query('SELECT scenter FROM bscp_courserequest WHERE ide="'.$ide.'"');
        $row11 = $query01->result_array();
		 if ($query01->num_rows()>0) {
        	$scenter = $row11[0]['scenter'];
		 }
        return $scenter;
    }
	
	// Change City
	
	public function STChangeCity($ide,$city,$courseid){
        
               /*$qData1 = array(
              'ide' => $ide,
              'center' => $city,
              'scenter' => "");
            $query1 = $this->db->update('bscp_courserequest', $qData1, array('ide' => $qData1['ide']));*/
		$query1 = $this-> db -> query('update `bscp_courserequest` set center="'.$city.'",scenter="" where ide="'.$ide.'"');

		if($query1) {
		   $result = array(0 => "success");
		} else {
		   $result = array(0 => "fail");
		}
                        
        return $result; 
        
    }
    
     public function ChangeRefundStatus($ide,$status){
        
        /* $qData1 = array(
              'ide' => $ide,
              'refund' => $status);
         $query1 =   $this->db->update('bscp_courserequest', $qData1, array('ide' => $qData1['ide']));*/
        $query1 = $this-> db -> query('update `bscp_courserequest` set refund="'.$status.'" where ide="'.$ide.'"');
        if($query1) {
            $result = array(0 => "success");
        } else {
            $result = array(0 => "fail");
        }
        
        return $result; 
        
        
    }
    
     public function CourseNameSearch($incomingword) {
       
            $query = $this->db->query("select coursename,courseid,ide from admin_course where coursename LIKE " . $this->db->escape($incomingword."%"). " or courseid LIKE " . $this->db->escape($incomingword."%"). " limit 10");
            $row = $query->result_array();
            return $row;
              
    }
    
    
    public function GetCourseCenterList($ide){
      
	  	  
		$arr['center'] = '<option value="">Select Center</option>';
	  	      		 
	  $query3 = $this-> db -> query('select centers from admin_course where ide="'.$ide.'"');
	  $row3 = $query3->result_array();
		
	  if ($row3) {
		  $center = $row3[0]['centers'];
                  $centerArr = explode("|", $center);
		  for($i=0 ; $i < count($centerArr);$i++) {
		  		  
				$arr['center'] .= "<option value='".$centerArr[$i]."'>".$centerArr[$i]."</option>";
				
			  
		  }
						  
	  }
	
  	return $arr;
		  
        
    }
    
    
    public function AddCourseChange($sid,$cid,$center,$ncenter,$ncid,$stupayid,$amount,$remit,$refund,$rid) {
        
        $rowArr = explode("|", $stupayid);
        $amountArr = explode("|", $amount);
        $remitArr = explode("|", $remit);
        $refundArr = explode("|", $refund);
        $receiptno = ""; 
        $query = $this-> db -> query('SELECT MAX(CAST(t.receiptno AS UNSIGNED)) + 1 AS max_field FROM bscp_coursechange t WHERE (t.receiptno != null or receiptno != "")');
                $row = $query->result_array();
                if ($query->num_rows()>0) {
                     $receiptno = $row[0]['max_field'];
                }
        
        if(is_null($receiptno)) {$receiptno = "1";}
        
         for($i = 0 ; $i < count($rowArr);$i++){
             
             if($rowArr[$i] === "") {continue;}
             
             $ide = uniqid();
              $qData = array(
                'ide' => $ide,
                'receiptno' => $receiptno,
                'courseid' => html_escape($cid),
                'new_courseid' => html_escape($ncid),
                'studentid' => html_escape($sid),
                'center' => html_escape($center),
                'new_center' => html_escape($ncenter),
                'stupayid' => html_escape($rowArr[$i]),
                'requestid' => html_escape($rid),
                'new_requestid' => '',                
                'amount' => html_escape($amountArr[$i]),
                'remitted' => html_escape($remitArr[$i]),
                'refundamount' => html_escape($refundArr[$i]),
                'created_at' => date('Y-m-d H:i:s')
            );
            
             
            $this->db->insert('bscp_coursechange', $qData);
            
            $discount = floatval($amountArr[$i]) - floatval($refundArr[$i]);
            if($discount !== 0) {
                
                if(floatval($remitArr[$i]) > floatval($refundArr[$i])){
                    
                    $discount = floatval($amountArr[$i]) - floatval($remitArr[$i]);
                    
                }
                
                $query1 = $this-> db -> query('SELECT tax,kf FROM bscp_student_payments  WHERE requestid="'.$rid.'" and id="'.$rowArr[$i].'"');
                $row1 = $query1->result_array();
                if ($row1) {
                    
                    $totax = floatval($row1[0]['tax'])+floatval($row1[0]['kf']);
                    $stax = floatval($totax)/100;
                    $mtax = 1+floatval($stax);
                    $total = floatval($amountArr[$i])- floatval($discount);
                    $gstTotal = floatval($total)*floatval($mtax);
                    $gstTotal = round($gstTotal);
                    
                }
                
                
                
            } else {
                
                $total    = floatval($amountArr[$i]);$gstTotal=0;
                $query1 = $this-> db -> query('SELECT tax,kf FROM bscp_student_payments  WHERE requestid="'.$rid.'" and id="'.$rowArr[$i].'"');
                $row1 = $query1->result_array();
                if ($row1) {
                    
                    $totax = floatval($row1[0]['tax'])+floatval($row1[0]['kf']);                          
                    $stax = floatval($totax)/100;
                    $mtax = 1+floatval($stax);
                    $total = floatval($amountArr[$i])- floatval($discount);
                    $gstTotal = floatval($total)*floatval($mtax);
                    $gstTotal = round($gstTotal);
                    
                }
                
            }
            
          /*  $qData1 = array(
              'id' => $rowArr[$i],
                'reason' => "discontinue",
                'discount' => $discount,
                'total' => $gstTotal);
             $this->db->update('bscp_student_payments', $qData1, array('id' => $qData1['id']));*/
          $disTotal=0;
          $query11 = $this-> db -> query('SELECT discount FROM bscp_student_payments WHERE id="'.$rowArr[$i].'"');
          $row11 = $query11->result_array();
          if($row11){
              $disTotal = $row11[0]['discount'];
          }
          
          $disTotal = intval($disTotal)+intval($discount);
            
            $this-> db -> query('update `bscp_student_payments` set reason="discontinue",discount="'.$disTotal.'",total="'.$gstTotal.'" where id="'.$rowArr[$i].'"'); 
            $this-> db -> query('delete from `bscp_feepayments` where stupayid="'.$rowArr[$i].'" and paymentstatus!="p"'); 
             
         }
         
          $query1 = $this-> db -> query('SELECT id,amount FROM bscp_student_payments WHERE requestid="'.$rid.'"');
          $row1 = $query1->result_array();
          if($row1){
              for($j=0 ; $j < count($row1);$j++) {
                if(!in_array($row1[$j]['id'], $rowArr)){
                                      
                     /*$qData1 = array(
                                'id' => $row1[$j]['id'],
                                'reason' => "discontinue",
                                'discount' => $row1[$j]['amount'],
                                'total' => '0');
                    $this->db->update('bscp_student_payments', $qData1, array('id' => $qData1['id']));*/
                    $this-> db -> query('update `bscp_student_payments` set reason="discontinue",discount="'.$row1[$j]['amount'].'",total="0" where id="'.$row1[$j]['id'].'"'); 
           
                }
              }
          }
          
          
         if($rid !== '') {   $this-> db -> query('delete from `bscp_feepayments` where requestid="'.$rid.'" and paymentstatus!="p"'); }
                  
         return $receiptno;
        
        
    }
    
    public function AddCenterChange($center,$ncenter,$rid) {
        
        //Update CRID
           $this-> db -> query('update `bscp_courserequest` set oldcenter="'.$center.'",center="'.$ncenter.'",approved_date="'.date('Y-m-d H:i:s').'" where ide="'.$rid.'"'); 
         
        //Update Student Payments
           $this-> db -> query('update `bscp_student_payments` set centers="'.$ncenter.'" where requestid="'.$rid.'"'); 
         
        //Update Student Fee payments
           $this-> db -> query('update `bscp_feepayments` set center="'.$ncenter.'" where requestid="'.$rid.'"'); 
         
    }
    
    
    public function GetCourseRequestid($cid,$sid) {
         
        $arr['ide'] = ''; $arr['approved'] = '';
        $query1 = $this-> db -> query('select ide,approved from bscp_courserequest  where  courseid="'.$cid.'" and studentid="'.$sid.'"' );
	$row = $query1->result_array();
        if ($row) {
            
            $arr['ide'] = $row[0]['ide']; $arr['approved'] = $row[0]['approved'];
        } 
        
        return $arr;    
         
     }
     
    
     public function NewCourseFeeAdjustments($nrequestid,$refund) {
         
         
        $query1 = $this-> db -> query('select id,amount,discount,tax,kf from bscp_student_payments  where  requestid="'.$nrequestid.'" order by desc_order');
	$row = $query1->result_array();
        if ($row) {
             for($i = 0;$i<count($row);$i++) {
                 
                $amount = $row[$i]['amount'];
                if(floatval($refund) >= floatval($amount)){
                   $discount = $amount ;
                   $refund = floatval($refund) - floatval($amount);
                } else {
                    $discount = floatval($refund);
                    $refund = 0;
                }
                
                $otax = ($row[$i]['tax'] !== '')?$row[$i]['tax']:0;
                $okf = ($row[$i]['kf'] !== '')?$row[$i]['kf']:0;
                
                $caltax = 0;$calkf = 0;
                if($otax !== 0) { $caltax = floatval($otax)/100;}
                if($okf !== 0) { $calkf = floatval($okf)/100;}
                
                $btotal = floatval($amount) - floatval($discount);
                $btax = floatval($btotal)*floatval($caltax);
                $bkf = floatval($btotal)*floatval($calkf);
                $total = floatval($btotal)+floatval($btax)+floatval($bkf);
                $total = round($total); $paystatus = "";
                if($total === 0) { $paystatus = "p";}
                
               /* $qData1 = array(
                'id' => $row[$i]['id'],
                'reason' => "course change",
                'discount' => $discount,
                'total' => $total);
             $this->db->update('bscp_student_payments', $qData1, array('id' => $qData1['id']));*/
                 $this-> db -> query('update `bscp_student_payments` set reason="course change",discount="'.$discount.'",total="'.$total.'" where id="'.$row[$i]['id'].'"');
                
          /*   $qData2 = array(
                'stupayid' => $row[$i]['id'],
                'paymentstatus' => $paystatus,
                'discount' => $discount,
                'total' => $total);
             $this->db->update('bscp_feepayments', $qData2, array('stupayid' => $qData2['stupayid'],'paymentstatus'=>$paystatus));*/
                $this-> db -> query('update `bscp_feepayments` set discount="'.$discount.'",total="'.$total.'" where stupayid="'.$row[$i]['id'].'" and paymentstatus="'.$paystatus.'"');
             }
        } 
        
               
     }
     
    public function UpdateNewCourseRequestid($id,$rid) {
         
        
        $this-> db -> query('update bscp_coursechange set new_requestid="'.$rid.'" where  receiptno="'.$id.'"' );
	
        return true;    
         
     }
     
     public function CheckCoursePaid($cid,$sid,$center) {
         
        $ret = false; 
        $query = $this-> db -> query('select id from bscp_feepayments  where  courseid="'.$cid.'" and studentid="'.$sid.'" and center="'.$center.'" and paymentstatus="p"' );
	if($query->num_rows()>0) {
            
            $ret = true;
        } 
        
        return $ret;    
         
     }
     
     	public function courseChange_count($batches)
    {   
		
		if(empty($batches) || in_array("All", $batches)){
			$query = $this ->db->query('select receiptno from bscp_coursechange where receiptno!="" group by receiptno' );
		}else{
			$query = $this ->db->query('select cc.receiptno from bscp_coursechange as cc,bscp_courserequest as cr where cc.receiptno!="" and cr.batchname IN ("'.implode('","',$batches).'") and cc.new_courseid=cr.courseid group by cc.receiptno' );
		}
     
				
    
        return $query->num_rows();  

    }
    
    public function courseChangelist($limit,$start,$col,$dir,$batches)
    {   
     
        $rowArr = Array();
        $selectquery = 'ra.requestid as requestid,ra.new_requestid as new_requestid,ra.receiptno as receiptno,ra.studentid as studentid,ra.courseid as courseid,ra.new_courseid as new_courseid,'
                     . 'ra.center as center,ra.new_center as new_center,sum(ra.remitted) as remitted,sum(ra.refundamount) as refundamount,'
                     . 'DATE_FORMAT(ra.created_at,"%d-%m-%Y") as created_at,s.sname as sname,s.studid as studid ';
	$whereclause = 'ra.receiptno !=""';
		
		if(empty($batches) || in_array("All", $batches)){
			$query = $this ->db->query('select '.$selectquery.' from bscp_coursechange as ra LEFT JOIN bscp_student as s ON s.id=ra.studentid where '.$whereclause.' group by ra.receiptno order by cast(receiptno as unsigned) desc limit '.$start.','.$limit);
		}else{
			$whereclause .= ' and cr.batchname IN ("'.implode('","',$batches).'") and ra.new_courseid=cr.courseid';
			$query = $this ->db->query('select '.$selectquery.' from bscp_coursechange as ra LEFT JOIN bscp_student as s ON s.id=ra.studentid LEFT JOIN bscp_courserequest as cr ON s.id=cr.studentid where '.$whereclause.' group by ra.receiptno order by cast(receiptno as unsigned) desc limit '.$start.','.$limit);
		}
                        
       
       $row = $query->result_array();
	if ($row) {
            for($i = 0;$i<count($row);$i++) {
                
                $rowArr[$i]['receiptno'] = $row[$i]['receiptno'];
                $rowArr[$i]['studid'] = $row[$i]['studid'];
                $rowArr[$i]['sname'] = $row[$i]['sname'];
                $rowArr[$i]['center'] = $row[$i]['center'];
                $rowArr[$i]['new_center'] = $row[$i]['new_center'];
                $rowArr[$i]['center'] = $row[$i]['center'];
                $rowArr[$i]['remitted'] = $row[$i]['remitted'];
                $rowArr[$i]['refundamount'] = $row[$i]['refundamount'];
                $rowArr[$i]['created_at'] = $row[$i]['created_at'];
                $rowArr[$i]['new_courseid'] = $row[$i]['new_courseid'];
                $rowArr[$i]['courseid'] = $row[$i]['courseid'];
                $rowArr[$i]['studentid'] = $row[$i]['studentid'];
                $rowArr[$i]['requestid'] = $row[$i]['requestid'];
                $rowArr[$i]['new_requestid'] = $row[$i]['new_requestid'];
                
                $q1 = $this ->db->query('select coursename from admin_course where ide="'.$row[$i]['courseid'].'"');
                $row1 = $q1->result_array();
                $rowArr[$i]['fcoursename'] = $row1[0]['coursename'];
                
                $q2 = $this ->db->query('select coursename from admin_course where ide="'.$row[$i]['new_courseid'].'"');
                $row2 = $q2->result_array();
                $rowArr[$i]['tcoursename'] = $row2[0]['coursename'];
                
            }
            
        } 
	  
        return $rowArr;
        
    }
   
    public function courseChangelist_search($limit,$start,$search,$col,$dir,$searchcol,$batches)
    {
        	$rowArr = Array();
                $selectquery = 'ra.requestid as requestid,ra.new_requestid as new_requestid,ra.receiptno as receiptno,ra.studentid as studentid,ra.courseid as courseid,ra.new_courseid as new_courseid,'
                     . 'ra.center as center,ra.new_center as new_center,sum(ra.remitted) as remitted,sum(ra.refundamount) as refundamount,'
                     . 'DATE_FORMAT(ra.created_at,"%d-%m-%Y") as created_at,s.sname as sname,s.studid as studid ';
                $whereclause = 'ra.receiptno !=""';
		
        
		$wheresearch = '';
		
		if($searchcol!="") $wheresearch .= ' and (';
		
		if($searchcol=="stuid"){$wheresearch .= ' `s`.`studid` = "'.$search.'"';}
		else if($searchcol=="stuname"){$wheresearch .= ' `s`.`sname` = "'.$search.'"';}	
                else if($searchcol=="receiptno"){$wheresearch .= ' `ra`.`receiptno` = "'.$search.'"';}	

			
		if($searchcol!="") $wheresearch .= ')';
		
                $whereclause = $whereclause.$wheresearch;
			
		if(empty($batches) || in_array("All", $batches)){
			$query = $this ->db->query('select '.$selectquery.' from bscp_coursechange as ra LEFT JOIN bscp_student as s ON s.id=ra.studentid where '.$whereclause.' group by ra.receiptno order by cast(receiptno as unsigned) desc limit '.$start.','.$limit);
		}else{
			$whereclause .= ' and cr.batchname IN ("'.implode('","',$batches).'") and ra.new_courseid=cr.courseid';
			$query = $this ->db->query('select '.$selectquery.' from bscp_coursechange as ra LEFT JOIN bscp_student as s ON s.id=ra.studentid LEFT JOIN bscp_courserequest as cr ON s.id=cr.studentid where '.$whereclause.' group by ra.receiptno order by cast(receiptno as unsigned) desc limit '.$start.','.$limit);
		}
		
		
                $row = $query->result_array();
                if ($row) {
                    for($i = 0;$i<count($row);$i++) {

                        $rowArr[$i]['receiptno'] = $row[$i]['receiptno'];
                        $rowArr[$i]['studid'] = $row[$i]['studid'];
                        $rowArr[$i]['sname'] = $row[$i]['sname'];
                        $rowArr[$i]['center'] = $row[$i]['center'];
                        $rowArr[$i]['new_center'] = $row[$i]['new_center'];
                        $rowArr[$i]['center'] = $row[$i]['center'];
                        $rowArr[$i]['remitted'] = $row[$i]['remitted'];
                        $rowArr[$i]['refundamount'] = $row[$i]['refundamount'];
                        $rowArr[$i]['created_at'] = $row[$i]['created_at'];
                        $rowArr[$i]['new_courseid'] = $row[$i]['new_courseid'];
                        $rowArr[$i]['courseid'] = $row[$i]['courseid'];
                        $rowArr[$i]['studentid'] = $row[$i]['studentid'];
                        $rowArr[$i]['requestid'] = $row[$i]['requestid'];
                        $rowArr[$i]['new_requestid'] = $row[$i]['new_requestid'];

                        $q1 = $this ->db->query('select coursename from admin_course where ide="'.$row[$i]['courseid'].'"');
                        $row1 = $q1->result_array();
                        $rowArr[$i]['fcoursename'] = $row1[0]['coursename'];

                        $q2 = $this ->db->query('select coursename from admin_course where ide="'.$row[$i]['new_courseid'].'"');
                        $row2 = $q2->result_array();
                        $rowArr[$i]['tcoursename'] = $row2[0]['coursename'];

                    }
            
                } 
        
        return $rowArr;
    }

    public function courseChangelist_search_count($search,$searchcol,$batches)
    {
        		
		 $selectquery = 'receiptno';
                $whereclause = 'ra.receiptno !=""';
		
        
		$wheresearch = '';
		
		if($searchcol!="") $wheresearch .= ' and (';
		
		if($searchcol=="stuid"){$wheresearch .= ' `s`.`studid` = "'.$search.'"';}
		else if($searchcol=="stuname"){$wheresearch .= ' `s`.`sname` = "'.$search.'"';}	
                else if($searchcol=="receiptno"){$wheresearch .= ' `ra`.`receiptno` = "'.$search.'"';}

			
		if($searchcol!="") $wheresearch .= ')';
		
                $whereclause = $whereclause.$wheresearch;
			
		if(empty($batches) || in_array("All", $batches)){
			$query = $this ->db->query('select '.$selectquery.' from bscp_coursechange as ra LEFT JOIN bscp_student as s ON s.id=ra.studentid where '.$whereclause.' group by ra.receiptno');
		}else{
			$whereclause .= ' and cr.batchname IN ("'.implode('","',$batches).'") and ra.new_courseid=cr.courseid';
			$query = $this ->db->query('select '.$selectquery.' from bscp_coursechange as ra LEFT JOIN bscp_student as s ON s.id=ra.studentid LEFT JOIN bscp_courserequest as cr ON s.id=cr.studentid where '.$whereclause.' group by ra.receiptno');
		}
		
		
               
                return $query->num_rows();
    }
    
    
      public function ViewCourseChangePaymentLists($id) {
        
                           
               $selectQuery = 'SELECT b.description,b.desc_order,a.amount,a.remitted,a.refundamount from bscp_coursechange as a LEFT JOIN bscp_student_payments as b on a.stupayid=b.id where a.receiptno="'.$id.'" group by a.stupayid order by b.desc_order';
		
              $html = ""; $html1=""; $tableRow = ""; $j = 1;$amt=0;$remit=0;$refundamt=0;
            $query0 = $this-> db -> query($selectQuery);
            $row = $query0->result_array();
            for($i=0; $i < count($row); $i++){
                
              
                if($i === 0){
                    
                     
                    $html = '<table class="reportsTable">
          <thead><tr><th>S.No</th><th>Description</th><th>Amount</th><th>Remitted</th><th>Refund Amount</th></tr></thead>
          <tbody>';
                    
                }
                
                $tableRow .= '<tr><td>'.$j.'</td><td>'.$row[$i]['description'].'</td><td>'.$row[$i]['amount'].'</td><td>'.$row[$i]['remitted'].'</td><td>'.$row[$i]['refundamount'].'</td></tr>';
                
                $amt = floatval($amt)+floatval($row[$i]['amount']);
                $remit = floatval($remit)+floatval($row[$i]['remitted']);
                $refundamt = floatval($refundamt)+floatval($row[$i]['refundamount']);
                $j++;
            }
            
            $html1 = '</tbody></table><div class="row" style="width: 98%">

									<div class="col-md-12 text-right px-2">
                                                                            <p class="list-item-heading mb-1"> <span>Total Remitted Amount:</span> <span class="premit" style="color: #1C47B3 !important">'.$remit.'</span></p>
									</div>

									<div class="col-md-12 text-right px-2">
										<p class="list-item-heading mb-1"><span> Total Refund Amount:</span> <span class="prefund" style="color: #D63333 !important">'.$refundamt.'</span></p>
									</div>

								</div>';
            $htmlFinal = $html.$tableRow.$html1;
            return $htmlFinal;
		
    }
    
      public function insertCourseChangeRequest($qData)
    {
		
		$query = $this-> db -> query('select ide from bscp_courserequest where studentid="'.$qData['studentid'].'" and courseid="'.$qData['courseid'].'" and center="'.$qData['center'].'"');
		$row = $query->result_array();
        if ($query->num_rows()===0) {
			
        	$this->db->insert('bscp_courserequest', $qData);
        	return $this->db->insert_id();
			
		}else{
			return $row[0]['ide'];
		}
		
    }
    
    
    //screening Test Export
    
      public function ExportSTRequest($cid,$center,$type,$batches){
        
		  $whereclause = "";
			  
                if($type == "all" || $type == "") {
			
                        if($center===""){
                             $whereclause = 'cr.courseid = "'.$cid.'"';
                        }else {
                            $whereclause = 'cr.courseid = "'.$cid.'" and cr.center = "'.$center.'"';
                        }
			
			$groupby = 'cr.studentid';
			
		}else if($type == "r"){
                    
                        if($center===""){

                            $whereclause = 'cr.courseid = "'.$cid.'" and (fp.paymentamount != 0 or fp.total="0")';
                        } else {
                            $whereclause = 'cr.courseid = "'.$cid.'" and cr.center = "'.$center.'" and (fp.paymentamount != 0 or fp.total="0")';
                        }
			$groupby = 'cr.studentid';
			
		}else if($type == "ar"){
                    
                    if($center===""){
                        $whereclause = 'cr.courseid = "'.$cid.'" and (fp.paymentamount != 0 or fp.total="0") and (sp.reason IS NULL or sp.reason !="discontinue")';
                    } else{
                        $whereclause = 'cr.courseid = "'.$cid.'" and cr.center = "'.$center.'" and (fp.paymentamount != 0 or fp.total="0") and (sp.reason IS NULL or sp.reason !="discontinue")';
                    }
			$groupby = 'cr.studentid';
			
		}else if($type == "p"){
                    
                        if($center===""){
                            $whereclause = 'cr.courseid = "'.$cid.'" and fp.paymentamount = 0';
                        }else {
                            $whereclause = 'cr.courseid = "'.$cid.'" and cr.center = "'.$center.'" and fp.paymentamount = 0';
                        }
			
			$groupby = 'cr.studentid';
		}
		
		//$selectquery = 'cr.studentid as sid,cr.scenter,cr.roll_number,cr.download_ht,cr.ide,cr.issue_ht,s.email as email,s.contact as mobile,s.sname as sname, s.studid as studid,cr.center as center, c.courseid as cuid,c.coursename as courseid,cr.courseid as cid, fp.paymentstatus as remitted';
	
		  if(!empty($batches) && !in_array("All", $batches)){
			
			if($whereclause!="") $whereclause .= ' and '; 
			 $whereclause .= ' cr.batchname IN ("'.implode('","',$batches).'") ';
		 }
		  
		
		$query = $this ->db->query('select cr.*,s.* from bscp_courserequest as cr LEFT JOIN bscp_feepayments as fp ON fp.requestid=cr.ide LEFT JOIN admin_course as c ON c.ide=cr.courseid LEFT JOIN bscp_student as s ON s.id=cr.studentid LEFT JOIN bscp_student_payments as sp ON sp.requestid=cr.ide where '.$whereclause);
        
          $row1 = $query->result_array();
          
          if ($row1) {
            for($i = 0;$i<count($row1);$i++) {
                
                 $ide = $row1[$i]['id'];
                 $courseArr[$ide]['sname'] = $row1[$i]['sname'];$courseArr[$ide]['fname'] = $row1[$i]['fname'];
                 $courseArr[$ide]['contact'] = $row1[$i]['contact'];$courseArr[$ide]['city'] = $row1[$i]['city'];
                 $courseArr[$ide]['email'] = $row1[$i]['email'];$courseArr[$ide]['studid'] = $row1[$i]['studid'];
                 
                $query41 = $this-> db -> query("select sp.* from bscp_studentprofile as sp where sp.stuid='".$ide."'");
                $row41 = $query41->result_array();
                if ($row41) {
               
                 $courseArr[$ide]['guardianname'] = $row41[0]['guardianname'];$courseArr[$ide]['gender'] = $row41[0]['gender'];
                 $courseArr[$ide]['dob'] = $row41[0]['dob'];$courseArr[$ide]['fathername'] = $row41[0]['fathername'];
                 $courseArr[$ide]['fatheroccupation'] = $row41[0]['fatheroccupation'];$courseArr[$ide]['fatheremail'] = $row41[0]['fatheremail'];
                 $courseArr[$ide]['fathercode'] = $row41[0]['fathercode'];$courseArr[$ide]['fatherphone'] = $row41[0]['fatherphone'];
                 $courseArr[$ide]['mothername'] = $row41[0]['mothername'];$courseArr[$ide]['motheroccupation'] = $row41[0]['motheroccupation'];
                 $courseArr[$ide]['motheremail'] = $row41[0]['motheremail'];$courseArr[$ide]['mothercode'] = $row41[0]['mothercode'];
                 $courseArr[$ide]['motherphone'] = $row41[0]['motherphone'];$courseArr[$ide]['communicationcontact'] = $row41[0]['communicationcontact'];
                 $courseArr[$ide]['nationality'] = $row41[0]['nationality'];$courseArr[$ide]['category'] = $row41[0]['category'];
                 $courseArr[$ide]['bloodgroup'] = $row41[0]['bloodgroup'];$courseArr[$ide]['classstudy'] = $row41[0]['classstudy'];
                 $courseArr[$ide]['stream'] = $row41[0]['stream'];$courseArr[$ide]['schoolcollegename'] = $row41[0]['schoolcollegename'];
                 $courseArr[$ide]['eduaddress'] = $row41[0]['eduaddress'];$courseArr[$ide]['edulandmark'] = $row41[0]['edulandmark'];
                 $courseArr[$ide]['edudistrict'] = $row41[0]['edudistrict'];$courseArr[$ide]['edustate'] = $row41[0]['edustate'];
                 $courseArr[$ide]['edupost'] = $row41[0]['edupost'];$courseArr[$ide]['edupincode'] = $row41[0]['edupincode'];
                 $courseArr[$ide]['educountry'] = $row41[0]['educountry'];$courseArr[$ide]['examboard'] = $row41[0]['examboard'];
                 $courseArr[$ide]['examclass'] = $row41[0]['examclass'];$courseArr[$ide]['preferredsubject'] = $row41[0]['preferredsubject'];
                 $courseArr[$ide]['eligiblescholar'] = $row41[0]['eligiblescholar'];$courseArr[$ide]['mocktype'] = $row41[0]['mocktype'];
                 $courseArr[$ide]['rollno'] = $row41[0]['rollno'];$courseArr[$ide]['housenameno'] = $row41[0]['housenameno'];
                 $courseArr[$ide]['landmark'] = $row41[0]['landmark'];$courseArr[$ide]['contactaddress'] = $row41[0]['contactaddress'];
                 $courseArr[$ide]['contactcountry'] = $row41[0]['contactcountry'];$courseArr[$ide]['contactstate'] = $row41[0]['contactstate'];
                 $courseArr[$ide]['contactdistrict'] = $row41[0]['contactdistrict'];$courseArr[$ide]['wacode'] = $row41[0]['wacode'];
                 $courseArr[$ide]['contactpost'] = $row41[0]['contactpost'];$courseArr[$ide]['whatsappno'] = $row41[0]['whatsappno'];
                 $courseArr[$ide]['contactpincode'] = $row41[0]['contactpincode'];$courseArr[$ide]['accountholdername'] = $row41[0]['accountholdername'];
                 $courseArr[$ide]['bankname'] = $row41[0]['bankname'];$courseArr[$ide]['branch'] = $row41[0]['branch'];
                 $courseArr[$ide]['ifsccode'] = $row41[0]['ifsccode'];$courseArr[$ide]['bankaccountno'] = $row41[0]['bankaccountno'];
                 $courseArr[$ide]['aadharnumber'] = $row41[0]['aadharnumber'];
               
                } else {
                 $courseArr[$ide]['guardianname'] ="";$courseArr[$ide]['gender'] = "";
                 $courseArr[$ide]['dob'] = "";$courseArr[$ide]['fathername'] = "";
                 $courseArr[$ide]['fatheroccupation'] ="";$courseArr[$ide]['fatheremail'] = "";
                 $courseArr[$ide]['fathercode'] = "";$courseArr[$ide]['fatherphone'] = "";
                 $courseArr[$ide]['mothername'] = "";$courseArr[$ide]['motheroccupation'] = "";
                 $courseArr[$ide]['motheremail'] = "";$courseArr[$ide]['mothercode'] = "";
                 $courseArr[$ide]['motherphone'] = "";$courseArr[$ide]['communicationcontact'] = "";
                 $courseArr[$ide]['nationality'] = "";$courseArr[$ide]['category'] = "";
                 $courseArr[$ide]['bloodgroup'] = "";$courseArr[$ide]['classstudy'] = "";
                 $courseArr[$ide]['stream'] = "";$courseArr[$ide]['schoolcollegename'] = "";
                 $courseArr[$ide]['eduaddress'] = "";$courseArr[$ide]['edulandmark'] = "";
                 $courseArr[$ide]['edudistrict'] = "";$courseArr[$ide]['edustate'] = "";
                 $courseArr[$ide]['edupost'] = "";$courseArr[$ide]['edupincode'] = "";
                 $courseArr[$ide]['educountry'] = "";$courseArr[$ide]['examboard'] = "";
                 $courseArr[$ide]['examclass'] = "";$courseArr[$ide]['preferredsubject'] = "";
                 $courseArr[$ide]['eligiblescholar'] = "";$courseArr[$ide]['mocktype'] = "";
                 $courseArr[$ide]['rollno'] = "";$courseArr[$ide]['housenameno'] = "";
                 $courseArr[$ide]['landmark'] = "";$courseArr[$ide]['contactaddress'] = "";
                 $courseArr[$ide]['contactcountry'] = "";$courseArr[$ide]['contactstate'] = "";
                 $courseArr[$ide]['contactdistrict'] = "";$courseArr[$ide]['wacode'] = "";
                 $courseArr[$ide]['contactpost'] = "";$courseArr[$ide]['whatsappno'] = "";
                 $courseArr[$ide]['contactpincode'] = "";$courseArr[$ide]['accountholdername'] = "";
                 $courseArr[$ide]['bankname'] = "";$courseArr[$ide]['branch'] = "";
                 $courseArr[$ide]['ifsccode'] = "";$courseArr[$ide]['bankaccountno'] = "";
                 $courseArr[$ide]['aadharnumber'] = "";
                }
                 
                $courseArr[$ide]['scenter'] = $row1[$i]['scenter'];
                $courseArr[$ide]['center'] = $row1[$i]['center'];
                $courseArr[$ide]['issue_ht'] = $row1[$i]['issue_ht'];
                $courseArr[$ide]['roll_number'] = $row1[$i]['roll_number'];
                $courseArr[$ide]['download_ht'] = $row1[$i]['download_ht'];

                 
                 $query4 = $this-> db -> query("select mcode from bscp_signup where mobile='".$row1[$i]['contact']."'");
                $row4 = $query4->result_array();
                if ($row4) {
                $courseArr[$ide]['mcode'] = $row4[0]['mcode'];
               
                } else {
                    $courseArr[$ide]['mcode'] = '';
                }
				
				
				// Due List
				           
         		$query2 = $this-> db -> query('SELECT a.tax,a.kf,GROUP_CONCAT(DISTINCT a.givenby) as givenby'
                 . ',GROUP_CONCAT(DISTINCT a.reason) as reason,GROUP_CONCAT(DISTINCT a.remarks) as remarks,'
                 . 'sum((a.amount)*(1+(a.tax+a.kf)/100)) as total,sum(a.discount) as discount,sum(a.total) as tobepaid'
                 . ' FROM bscp_student_payments as a where a.requestid="'.$row1[$i]['ide'].'"');
     
       
				$row2 = $query2->result_array();
				if ($query2->num_rows()>0) {
						
						$courseArr[$ide]['total'] = round($row2[0]['total']);
						$courseArr[$ide]['discount'] = $row2[0]['discount'];
						$courseArr[$ide]['givenby'] = $row2[0]['givenby'];
						$courseArr[$ide]['reason'] = $row2[0]['reason'];
						$courseArr[$ide]['remarks'] = $row2[0]['remarks'];
						$courseArr[$ide]['tobepaid'] = $row2[0]['tobepaid'];
						$tobepaid = $row2[0]['tobepaid'];
						$gst = (($row2[0]['tax'] === "") || ($row2[0]['tax'] === "NA"))?0:$row2[0]['tax'];
						$kf = (($row2[0]['kf'] === "") || ($row2[0]['kf'] === "NA"))?0:$row2[0]['kf'];
						$paid = 0;
						 $q1 = $this ->db->query('select tax,kf,sum(total) as total from bscp_feepayments where requestid="'.$row1[$i]['ide'].'" and paymentstatus="p"');
						$row3 = $q1->result_array();
						if($row3){
							$paid = $row3[0]['total'];                   
						}

						$totaldue = floatval($tobepaid)-floatval($paid);

						$tottax = intVal($gst)+intVal($kf);
						   $calamount1 = floatval($totaldue)*floatval($tottax);
						   $calamount1 = round($calamount1);

						   $divTax = 100+intVal($tottax);

						   $caltax = $calamount1 / $divTax;
						   $caltax = round($caltax, 2);

						   $calamount = floatval($totaldue) - floatval($caltax);
						   $netdue = round($calamount);
						   $courseArr[$ide]['paid'] = $paid;
						   $courseArr[$ide]['gst'] = $caltax;
						   $courseArr[$ide]['netdue'] = $netdue;
						   $courseArr[$ide]['totaldue'] = $totaldue;

				}
								
                 
            }
          }
		
          return $courseArr;
        
    }
	
	
	public function GetCourseDetails($courseid){
			
		$arr = array();
		
        $query2 = $this-> db -> query('select coursename,qualification,qname from admin_course where ide="'.$courseid.'"');
		$row = $query2->result_array();
		
		if($row){
						
			return $row[0];
		
		}   
		
		return $arr;
		
   }
   
   public function GetCourseUniqueId($name){
       
        $arr = "";
        $query2 = $this-> db -> query('select ide from admin_course where coursename="'.$name.'"');
	$row = $query2->result_array();

        if($row){
	    $arr = $row[0]['ide'];
	}   
		
	return $arr;
       
   }
	
	public function GetIssueCityWiseCenters($inp,$courseid){
        
    	$retHTML = "";
		
        $query2 = $this-> db -> query('select name from bscp_centers where cityname="'.$inp.'"');
		$row = $query2->result_array();
        if ($row) {
            
                for($i=0 ; $i < count($row);$i++) {
                    
					 $name = $row[$i]["name"];
					
					 $ctotal=0;      
					 $query02 = $this-> db -> query('SELECT count(*) as ctotal FROM bscp_courserequest WHERE courseid="'.$courseid.'" and scenter="'.$name.'" and scity="'.$inp.'"');
					 $row12 = $query02->result_array();
					 if($row12){  $ctotal = $row12[0]['ctotal']; }
					
					 $noofseats = $this->GetNoOfSeats($name,$inp);
					
					 if(intval($ctotal) < intval($noofseats)){
					
                     	$retHTML .= "<option>".$row[$i]["name"]."</option>";
						 
					 }
                    
                }
                
        }
        
        return $retHTML;
    
    }
	
	public function STIssueCenter($ide,$status,$center,$city,$courseid){
        
		$this->db->trans_start();
		
         $ctotal=0;      
         $query02 = $this-> db -> query('SELECT count(*) as ctotal FROM bscp_courserequest WHERE courseid="'.$courseid.'" and scenter="'.$center.'" and scity="'.$city.'"');
         $row12 = $query02->result_array();
         if($row12){  $ctotal = $row12[0]['ctotal']; }
         
		 $noofseats = $this->course_model->GetNoOfSeats($center,$city);
         if(intval($ctotal) < intval($noofseats)){
            
            $mrollnum = "";
            /*$query0 = $this-> db -> query('SELECT MAX(CAST(roll_number AS UNSIGNED)) as mroll_number FROM bscp_courserequest WHERE courseid="'.$courseid.'" and scenter="'.$center.'" and scity="'.$city.'"');
            $row1 = $query0->result_array();
            if($row1){ $mrollnum = $row1[0]['mroll_number']; }            

            if(is_null($mrollnum) || $mrollnum === '' || $mrollnum === '0'){

               $query01 = $this-> db -> query('SELECT rollnostarts FROM bscp_centers WHERE name="'.$center.'" and cityname="'.$city.'"');
               $row11 = $query01->result_array();
               $mrollnum = intval($row11[0]['rollnostarts']);

            } else {

                ++$mrollnum; 

            }*/

           
            $query1 = $this-> db -> query('update `bscp_courserequest` set scity="'.$city.'",scenter="'.$center.'",issue_ht="'.$status.'",roll_number="'.$mrollnum.'" where ide="'.$ide.'"');

           if($query1) {
                   $result = array(0 => "success");
               } else {
                   $result = array(0 => "fail");
               }
            
        } else{
              $result = array(0 => "novacant");
        }
		
		$this->db->trans_complete();
            
        return $result; 
        
    }
    
  
}

?>
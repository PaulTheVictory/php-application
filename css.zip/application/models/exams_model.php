<?php
Class Exams_Model extends CI_Model {
    
     public function __construct() {
        
       $this->load->library('Datatables');
        $this->load->helper('My_datatable_helper');
  
    }
	

	public function exams_count()
    {   
     
		$query = $this ->db->query('select sno from bscp_exams' );		
    
        return $query->num_rows();  

    }
    
    public function examslist($limit,$start,$col,$dir)
    {   
     
		
        $query = $this ->db->query('select id,sno,examname,date,type,stu_appeared from bscp_exams where del <>"y" order by '.$col.' '.$dir.' limit '.$start.','.$limit);
        if($query->num_rows()>0)
        {
            return $query->result(); 
        }
        else
        {
            return null;
        }
        
    }
   
    public function examslist_search($limit,$start,$search,$col,$dir,$searchcol)
    {
        		
		$wheresearch = '';
				
		if($searchcol=="exam"){$wheresearch .= ' examname LIKE "%'.$search.'%"';}
		else if($searchcol=="edate"){$wheresearch .= ' date = "'.$search.'"';}
		else if($searchcol=="etype"){$wheresearch .= ' type = "'.$search.'"';}
		else if($searchcol=="stuapp"){$wheresearch .= ' stu_appeared = "'.$search.'"';}
			
		
		$query = $this ->db->query('select * from bscp_exams where '.$wheresearch.' order by '.$col.' '.$dir.' limit '.$start.','.$limit);
		
        if($query->num_rows()>0)
        {
            return $query->result();  
        }
        else
        {
            return null;
        }
    }

    public function examslist_search_count($search,$searchcol)
    {
        		
		$wheresearch = '';
				
		if($searchcol=="exam"){$wheresearch .= ' examname LIKE "%'.$search.'%"';}
		else if($searchcol=="edate"){$wheresearch .= ' date = "'.$search.'"';}
		else if($searchcol=="etype"){$wheresearch .= ' type = "'.$search.'"';}
		else if($searchcol=="stuapp"){$wheresearch .= ' stu_appeared = "'.$search.'"';}
			
		$query = $this ->db->query('select * from bscp_exams where '.$wheresearch);		
        return $query->num_rows();
    }
	
    public function AddExam($ename,$edate,$etype,$stuapp){
		
		
                $id= uniqid();
                $cur_date =  date("Y-m-d H:i:s",strtotime($edate));
		$query1 = $this-> db -> query('insert into bscp_exams (`id`,`examname`,`date`,`type`,`stu_appeared`) values ("'.$id.'","'.$ename.'","'.$cur_date.'","'.$etype.'","'.$stuapp.'")');
			
		
	}
	
	// Add Results
	
	public function AddExamResults($examid,$studentno,$physics,$chemistry,$biology,$maths,$p1,$p2,$totalmarks,$maxmarks,$highestmarks,$percent,$grade,$rank,$rollno,$outof,$estatus,$scholarearn,$remarks){
		
		$arr = array();
		
		$arr['response'] = "";
                $percent = number_format((float)$percent, 2, '.', '');
		
		$id= uniqid();
		//$cur_date =  date("Y-m-d H:i:s",strtotime($edate));
		
		$studentdetials = $this->getStudentno($studentno);
		
		$studentid = $studentname = "";
		if(!empty($studentdetials)){
			$studentid = $studentdetials['studid'];
			$studentname = $studentdetials['sname'];
		}else{
			$arr['response'] = "nostudent";
		}
		
		if($studentid!=""){
				
		$query = $this-> db -> query('select status from bscp_examresults where examid="'.$examid.'" and studentid="'.$studentid.'"');
		$row = $query->result_array();
			
		if ($query->num_rows() > 0) {
			
			if ($row[0]['status']=="p") {
			
				$query1 = $this-> db -> query('UPDATE `bscp_examresults` SET `physics`="'.$physics.'",`chemistry`="'.$chemistry.'",`biology`="'.$biology.'",`maths`="'.$maths.'",`p1`="'.$p1.'",`p2`="'.$p2.'",`totalmarks`="'.$totalmarks.'",`maxmarks`="'.$maxmarks.'",`highestmarks`="'.$highestmarks.'",`percent`="'.$percent.'",`grade`="'.$grade.'",`rank`="'.$rank.'",`rollno`="'.$rollno.'",`outof`="'.$outof.'",`estatus`="'.$estatus.'",`scholarearn`="'.$scholarearn.'",`remarks`="'.$remarks.'" where examid="'.$examid.'" and studentid="'.$studentid.'" and status="p"');
			
			}else{
				$arr['response'] = "approve";
				return $arr;
			}
			
		}else{
			
			$query1 = $this-> db -> query('insert into bscp_examresults (`examid`, `studentno`, `studentid`, `studentname`, `physics`, `chemistry`, `biology`, `maths`, `p1`, `p2`, `totalmarks`, `maxmarks`, `highestmarks`, `percent`, `grade`, `rank`, `status`, `rollno`, `outof`, `estatus`, `scholarearn`, `remarks`) values ("'.$examid.'",'.$studentno.',"'.$studentid.'","'.$studentname.'","'.$physics.'","'.$chemistry.'","'.$biology.'","'.$maths.'","'.$p1.'","'.$p2.'","'.$totalmarks.'","'.$maxmarks.'","'.$highestmarks.'","'.$percent.'","'.$grade.'","'.$rank.'","p","'.$rollno.'","'.$outof.'","'.$estatus.'","'.$scholarearn.'","'.$remarks.'")');
		}
			
		if($query1){
			$arr['response'] = "success";
		}else{
			$arr['response'] = "fail";
		}
			
		}
		
		return $arr;
		
	}
	
	public function getStudentno($studentno){
		
		$arr = array();
				
		$query = $this-> db -> query('select id,sname from bscp_student where studid="'.$studentno.'"');
		$row = $query->result_array();

		if ($query->num_rows() === 1) {
			$arr['studid'] = $row[0]["id"];
			$arr['sname'] = $row[0]["sname"];
		}
		
		return $arr;
		
	}
	
	
	public function GetExamResults($examid,$status)
    {   
     
		 $query = $this-> db -> query('select `studentno`, `studentid`, `studentname`, `physics`, `chemistry`, `biology`, `maths`, `p1`, `p2`, `totalmarks`, `maxmarks`, `highestmarks`, `percent`, `grade`, `rank`, `rollno`, `outof`, `estatus`, `scholarearn`, `remarks` from bscp_examresults where examid="'.$examid.'" and status="'.$status.'"') ;
		
		if($query->num_rows()>0)
        {
            return $query->result();  
        }
        else
        {
            return 0;
        }
		
    }
	
	
	public function GetExamdetails($examid)
    {
		
		$query = $this ->db->query('select * from bscp_exams where id="'.$examid.'" ');
		$row = $query->result_array();
         return $row[0];  
      
    }
	
	public function ApproveExamResults($examid){
						
		$query = $this-> db -> query('update bscp_examresults set status="a" where examid="'.$examid.'" and status="p"');

		if ($query) {
			if(file_exists('./docs/examresults/examresults_'.$examid.'.xls'))unlink('./docs/examresults/examresults_'.$examid.'.xls');
			
			return $this->db->affected_rows();
		}
		
		return 0;
		
	}
	
	public function GetStudentResult($studentid,$sdate="",$edate="")
    {   
		
		$arr = array();
		
		$arr['model'] = "";
		$arr['weekly'] = "";
		$arr['test'] = "";
		
		$whereclause = $style = "";
		if($sdate!="" && $edate!=""){
			
			$sdate = date("Y-m-d H:i:s",strtotime($sdate));
			$edate = date("Y-m-d",strtotime($edate))." 23:59:59";
			$whereclause = ' and date between "'.$sdate.'" and "'.$edate.'"';
			
			$style = "style=\"border-left: none;\"";
		}
     
		 $query = $this-> db -> query('select e.examname,e.date,e.stu_appeared,e.type,`physics`, `chemistry`, `biology`, `maths`, `p1`, `p2`, `totalmarks`, `maxmarks`, `highestmarks`, `percent`, `grade`, `rank`, `rollno`, `outof`, `estatus`, `scholarearn`, `remarks` from bscp_examresults as r,bscp_exams as e  where r.examid=e.id and r.studentid="'.$studentid.'" and r.status="a" '.$whereclause.' order by e.date desc') ;
		 $row = $query->result_array();  
		
		if($query->num_rows()>0)
        {
            
			foreach($row as $result){
				
				if($result['type']=="Model"){
					
					$arr['model'] .= "<tr><td ".$style." >".date("d-M-Y",strtotime($result['date']))."</td><td>".$result['examname']."</td><td>".$result['physics']."</td><td>".$result['chemistry']."</td><td>".$result['biology']."</td><td>".$result['maths']."</td><td>".$result['p1']."</td><td>".$result['p2']."</td><td>".$result['totalmarks']."</td><td>".$result['maxmarks']."</td><td>".$result['highestmarks']."</td><td>".$result['percent']."</td><td>".$result['grade']."</td><td>".$result['rank']."</td><td>".$result['stu_appeared']."</td></tr>";
					
				}else if($result['type']=="Weekly"){
					
					$arr['weekly'] .= "<tr><td ".$style." >".date("d-M-Y",strtotime($result['date']))."</td><td>".$result['examname']."</td><td>".$result['physics']."</td><td>".$result['chemistry']."</td><td>".$result['biology']."</td><td>".$result['maths']."</td><td>".$result['p1']."</td><td>".$result['p2']."</td><td>".$result['totalmarks']."</td><td>".$result['maxmarks']."</td><td>".$result['highestmarks']."</td><td>".$result['percent']."</td><td>".$result['grade']."</td><td>".$result['rank']."</td><td>".$result['stu_appeared']."</td></tr>";
					
				}else if($result['type']=="Screening Test"){
					
					$arr['test'] .= "<tr><td ".$style." >".date("d-M-Y",strtotime($result['date']))."</td><td>".$result['examname']."</td><td>".$result['rollno']."</td><td>".$result['physics']."</td><td>".$result['chemistry']."</td><td>".$result['biology']."</td><td>".$result['maths']."</td><td>".$result['p1']."</td><td>".$result['p2']."</td><td>".$result['totalmarks']."</td><td>".$result['maxmarks']."</td><td>".$result['highestmarks']."</td><td>".$result['percent']."</td><td>".$result['grade']."</td><td>".$result['rank']."</td><td>".$result['outof']."</td><td>".$result['estatus']."</td><td>".$result['scholarearn']."</td><td>".$result['remarks']."</td><td>".$result['stu_appeared']."</td></tr>";
					
				}
				
			}
			
			
			
        }
		
		
		return $arr;
        
		
    }
	
	public function DeleteExamResults($examid){
						
		$query = $this-> db -> query('delete from bscp_examresults where examid="'.$examid.'" and status="p"');

		if ($query) {
			if(file_exists('./docs/examresults/examresults_'.$examid.'.xls'))unlink('./docs/examresults/examresults_'.$examid.'.xls');
			
			return $this->db->affected_rows();
		}
		
		return 0;
		
	}
        
        
        public function DeleteExam($ide){
        
        $query1 = $this-> db -> query('update `bscp_exams` set del="y" where id="'.$ide.'"');
        if($query1) {
            $query = $this-> db -> query('delete from bscp_examresults where examid="'.$ide.'"');
            $result = array(0 => "success");
        } else {
            $result = array(0 => "fail");
        }
        
        return $result; 
        
        
    }
	
	
	// Batches
	
	
	public function GetAllCourses($inp){
       
        $query2 = $this-> db -> query('select coursename,courseid,ide from admin_course');
	$row = $query2->result_array();
        
        $retHTML = "";
        $selected="";
        $inpArray =explode("|",$inp);
        if ($row) {
            
                for($i=0 ; $i < count($row);$i++) {
                    if(in_array($row[$i]["courseid"], $inpArray)) {
                        $selected = 'selected=selected';
                    }
                    
                    $retHTML .= "<option value='".$row[$i]["ide"]."|".$row[$i]["coursename"]."'" .$selected.">".$row[$i]["coursename"]."</option>";
                   $selected = "";
                }
                
        }
        return $retHTML;       
   }
	
	public function batches_count($batches)
    {   
     	$whereclause = "";
		if(!empty($batches) && !in_array("All", $batches)){
			 $whereclause .= ' where batchname IN ("'.implode('","',$batches).'") ';
		 }
		
		$query = $this ->db->query('select id from bscp_batches '.$whereclause.' group by batchname' );		
    
        return $query->num_rows();  

    }
    
    public function batcheslist($limit,$start,$col,$dir,$batches)
    {   
     
		$whereclause = "";
		if(!empty($batches) && !in_array("All", $batches)){
			 $whereclause .= ' and batchname IN ("'.implode('","',$batches).'") ';
		 }
		
        $query = $this ->db->query('select id,batchno,batchname,GROUP_CONCAT(coursename SEPARATOR ", ") as coursename,coordinatoname,created_at from bscp_batches where del <>"y" '.$whereclause.' group by batchname order by '.$col.' '.$dir.' limit '.$start.','.$limit);
        if($query->num_rows()>0)
        {
            return $query->result(); 
        }
        else
        {
            return null;
        }
        
    }
   
    public function batcheslist_search($limit,$start,$search,$col,$dir,$searchcol,$batches)
    {
        		
		$wheresearch = '';
				
		if($searchcol=="bname"){$wheresearch .= ' and batchname LIKE "%'.$search.'%"';}
		else if($searchcol=="batchno"){$wheresearch .= ' and batchno = '.$search;}
		else if($searchcol=="cnames"){$wheresearch .= ' and coursename LIKE "%'.$search.'%"';}
		else if($searchcol=="coname"){$wheresearch .= ' and coordinatoname LIKE "%'.$search.'%"';}
			
		$whereclause = "";
		if(!empty($batches) && !in_array("All", $batches)){
			 $whereclause .= ' and batchname IN ("'.implode('","',$batches).'") ';
		 }
		
		$query = $this ->db->query('select id,batchno,batchname,GROUP_CONCAT(coursename SEPARATOR ", ") as coursename,coordinatoname,created_at from bscp_batches where del <>"y" '.$wheresearch.' '.$whereclause.' group by batchname order by '.$col.' '.$dir.' limit '.$start.','.$limit);
		
        if($query->num_rows()>0)
        {
            return $query->result();  
        }
        else
        {
            return null;
        }
    }

    public function batcheslist_search_count($search,$searchcol,$batches)
    {
        		
		$wheresearch = '';
				
		if($searchcol=="bname"){$wheresearch .= ' and batchname LIKE "%'.$search.'%"';}
		else if($searchcol=="batchno"){$wheresearch .= ' and batchno = '.$search;}
		else if($searchcol=="cnames"){$wheresearch .= ' and coursename LIKE "%'.$search.'%"';}
		else if($searchcol=="coname"){$wheresearch .= ' and coordinatoname LIKE "%'.$search.'%"';}
		
		$wheresearch .= ' group by batchname';
			
		$whereclause = "";
		if(!empty($batches) && !in_array("All", $batches)){
			 $whereclause .= ' and batchname IN ("'.implode('","',$batches).'") ';
		 }
		
		$query = $this ->db->query('select id from bscp_batches where del <>"y"'.$wheresearch.$whereclause);		
        return $query->num_rows();
    }
	
	public function check_unique_batch_name($batchname){
						
		$query = $this-> db -> query('select del from bscp_batches where batchname="'.$batchname.'"');
		$row = $query->result_array();

		if ($query->num_rows() === 1) {
			
			if($row[0]["del"]=="y") return 1;
			
			return 1;
		}
		
		return 1;
		
	}
	
    public function AddBatch($courseids,$coursenames,$bname,$coname){
		
		$cur_date =  date("Y-m-d H:i:s");
				
		$countadd = 101;
		$queryM = $this->db->query('SELECT max(batchno) as bno FROM `bscp_batches` WHERE 1');
		$rowM = $queryM->result_array();
		if($queryM->num_rows()>0) $countadd = 1;
		$batchno = $countadd + $rowM[0]['bno'];
		
		foreach($courseids as $key=>$course){
			
			$id= uniqid();
			$courseid = $coursename = "";
			
			$coursenamesarr = explode("|",$course);
			
			if(isset($coursenamesarr[0])) $courseid = $coursenamesarr[0];
			if(isset($coursenamesarr[1])) $coursename = $coursenamesarr[1];
						
			$query1 = $this-> db -> query('insert into bscp_batches (`id`,`batchno`,`courseid`,`coursename`,`batchname`,`coordinatoname`,`created_at`) values ("'.$id.'","'.$batchno.'","'.$courseid.'","'.$coursename.'","'.$bname.'","'.$coname.'","'.$cur_date.'")');
			
		}		
			
		
	}
	
	public function DeleteBatch($bname){
        
        $query1 = $this-> db -> query('update `bscp_batches` set del="y" where batchname="'.$bname.'"');
        if($query1) {
			
			$query = $this-> db -> query('select ide,batchname,courseid,studentid from bscp_courserequest where batchname="'.$bname.'"');
			$row = $query->result_array();

			if ($query->num_rows() > 0) {
			
				for($i=0;$i<count($row);$i++){
					
					$ide = $row[$i]['ide'];
					$studentid = $row[$i]['studentid'];
					$courseid = $row[$i]['courseid'];

					$id= uniqid();

					$query2 = $this-> db -> query('insert into bscp_batchesold (`studentid`,`courseid`,`batchname`,`type`) values ("'.$studentid.'","'.$courseid.'","'.$bname.'","delbatch")');

					$query1 = $this-> db -> query('update `bscp_courserequest` set batchname="" where ide="'.$ide.'" and studentid="'.$studentid.'"');
					
				}
			}
			
            $result = array(0 => "success");
        } else {
            $result = array(0 => "fail");
        }
        
        return $result; 
        
        
    }
	
	// Upload Batches
	
	
	public function GetBatchdetails($batchname)
    {
		
		$query = $this ->db->query('select id,batchname,GROUP_CONCAT(coursename SEPARATOR ", ") as coursenames,coordinatoname,created_at from bscp_batches where batchname="'.$batchname.'" and del <>"y" group by batchname ');
		$row = $query->result_array();
         return $row[0];  
      
    }
	
	
	public function GetBatchResults($bname,$status)
    {   
     
		 $query = $this-> db -> query('select cr.batchname,s.sname,s.id,s.studid,c.coursename,c.ide from bscp_courserequest as cr,bscp_batches as b,bscp_student as s,admin_course as c where cr.batchname="'.$bname.'" and b.batchname=cr.batchname and b.courseid=cr.courseid and s.id=cr.studentid and c.ide=cr.courseid and b.del<>"y" group by cr.studentid') ;
		
		if($query->num_rows()>0)
        {
            return $query->result();  
        }
        else
        {
            return 0;
        }
		
    }
	
	
	public function AddBatchResults($bname,$batchno,$studentno,$courseno){
		
		$roleaccess = $this->config->item('roleaccess');
		
		$this->load->model('login_model','',TRUE);
		$user = $this->login_model->GetUserId();
		
		$keywords_imploded = "";
		if(!empty($user['batches']) && !in_array("All", $user['batches'])){
			$keywords_imploded = ' and batchname IN ("'.implode('","',$user['batches']).'") ';
		}
		
		
		$arr = array();
		
		$arr['response'] = "";
				
		$studentdetials = $this->getStudentno($studentno);
		
		$studentid = $studentname = "";
		if(!empty($studentdetials)){
			$studentid = $studentdetials['studid'];
			$studentname = $studentdetials['sname'];
		}else{
			$arr['response'] = "nostudent";
		}
		
		$coursedetials = $this->getCourseno($courseno);
		
		$courseid = $coursename = "";
		if(!empty($coursedetials)){
			$courseid = $coursedetials['cide'];
			$coursename = $coursedetials['coursename'];
		}else{
			$arr['response'] = "nocourse";
		}
		
		
		if($studentid!="" && $courseid!=""){
				
		$query = $this-> db -> query('select ide,batchname,courseid from bscp_courserequest where studentid="'.$studentid.'" and courseid="'.$courseid.'"');
		$row = $query->result_array();
					
		if ($query->num_rows() > 0) {
			
			$batchname = $row[0]['batchname'];
			
		if ($bname!="" && $batchname==$bname) {
			
			$arr['response'] = "success";
			return $arr;
			
		}else{
			
			$batchcolumn = "";
			
			if($bname!=""){
				$batchcolumn = 'batchname="'.$bname.'"';
			}else if($batchno!=""){
				$batchcolumn = 'batchno='.$batchno;
			}else{
				$arr['response'] = "nobatchno";
				return $arr;
			}
			
			
			$query0 = $this-> db -> query('select id,batchname from bscp_batches where '.$batchcolumn.' and courseid="'.$row[0]['courseid'].'" and del="n"'.$keywords_imploded);
			$row0 = $query0->result_array();

			if ($query0->num_rows() > 0) {
			
				$query1 = $this-> db -> query('update bscp_courserequest set batchname="'.$row0[0]['batchname'].'" where studentid="'.$studentid.'" and courseid="'.$courseid.'" ');

				if($query1){

					if($batchname!=""){

						$id= uniqid();

						$query2 = $this-> db -> query('insert into bscp_batchesold (`studentid`,`courseid`,`batchname`,`type`) values ("'.$studentid.'","'.$courseid.'","'.$batchname.'","batchchange")');

					}

				}
				
				if($query1){
					$arr['response'] = "success";
				}else{
					$arr['response'] = "fail";
				}
				
				
			}else{
				$arr['response'] = "nomatch";
			}
			
		}
			
						
		}else{
			$arr['response'] = "norequest";
		}
			
			
		}
		
		return $arr;
		
	}
	
	
	public function getCourseno($courseno){
		
		$arr = array();
				
		$query = $this-> db -> query('select ide,coursename from admin_course where courseid='.$courseno);
		$row = $query->result_array();

		if ($query->num_rows() === 1) {
			$arr['cide'] = $row[0]["ide"];
			$arr['coursename'] = $row[0]["coursename"];
		}
		
		return $arr;
		
	}
	
	
	public function DeleteBatchResults($bname,$studentid,$courseid){
        
		$result = array(0 => "");
		
		$query = $this-> db -> query('select ide,batchname from bscp_courserequest where batchname="'.$bname.'" and studentid="'.$studentid.'" and courseid="'.$courseid.'"');
		$row = $query->result_array();
			
		if ($query->num_rows() > 0) {
		
			$query1 = $this-> db -> query('update `bscp_courserequest` set batchname="" where studentid="'.$studentid.'" and courseid="'.$courseid.'"');
			if($query1) {
				
				$id= uniqid();

				$query2 = $this-> db -> query('insert into bscp_batchesold (`studentid`,`courseid`,`batchname`,`type`) values ("'.$studentid.'","'.$courseid.'","'.$bname.'","invdelbatch")');

				$result = array(0 => "success");
				
			} else {
				$result = array(0 => "fail");
			}
        
		}
		
        return $result; 
        
        
    }
    
    
    //exam
    
      public function GetDistricts(){
        
	   $roleaccess = $this->config->item('roleaccess');
		   
    	   $this->datatables->select('bscp_examdistricts.created_at as created_at,bscp_examdistricts.id as ide,bscp_examdistricts.name as name,count(bscp_examcenters.name) as centers') 
            ->edit_column('name', '<a href="examcenter?id=$2&name=$1" class="name">$1</a>', 'name,ide')
            ->edit_column('ide', '$1', 'check_examdisticteditdel(ide,"'.$roleaccess['Exam District Center'][1].'","'.$roleaccess['Exam District Center'][2].'")')
            ->edit_column('centers', '<span class="message">$1</a>', 'centers')
            ->edit_column('created_at', '<span class="sno">$1</a>', 'created_at')              
            ->from('bscp_examdistricts')
            ->group_by('name')
            ->join('bscp_examcenters', 'bscp_examdistricts.id=bscp_examcenters.districtid', 'left');
            
            $table =  $this->datatables->generate();
            return $table;
    
    }
    
    
        public function AddDistricts($qData)
    {
        $this->db->insert('bscp_examdistricts', $qData);
        return $this->db->insert_id();
    }
    
    
    public function UpdateDistricts($qData)
    {
        $this->db->update('bscp_examdistricts', $qData, array('id' => $qData['id']));
        
        //update distrit name in the center
        
         $this-> db -> query('update bscp_examcenters set districtname="'.$qData['name'].'" where districtid="'.$qData['id'].'"');

        
    }
    
    public function DeleteDistrict($ide){
        
        $query1 = $this-> db -> query('delete from `bscp_examdistricts` where id="'.$ide.'"');
        if($query1) {
            $result = array(0 => "success");
        } else {
            $result = array(0 => "fail");
        }
        
        return $result; 
        
        
    }
    
    public function GetCenters($districtid){
        
	   $roleaccess = $this->config->item('roleaccess');
		   
    	   $this->datatables->select('name,address1,address2,phone,pincode,id,created_at') 
            ->edit_column('name', '<span class="name">$1</span>', 'name')
            ->edit_column('address1', '<span class="address1">$1</span>', 'address1')
            ->edit_column('address2', '<span class="address2">$1</span>', 'address2')
            ->edit_column('phone', '<span class="phone">$1</span>', 'phone')
            ->edit_column('pincode', '<span class="pincode">$1</span>', 'pincode')
            ->edit_column('id', '$1', 'check_examcentereditdel(id,"'.$roleaccess['Exam District Center'][1].'","'.$roleaccess['Exam District Center'][2].'")')
            ->edit_column('created_at', '<span class="sno">$1</a>', 'created_at')              
            ->from('bscp_examcenters')->where("districtid",$districtid);
            
            $table =  $this->datatables->generate();
            return $table;
    
    }
    
    
        public function AddCenter($qData)
    {
        $this->db->insert('bscp_examcenters', $qData);
        return $this->db->insert_id();
    }
    
    
    public function UpdateCenter($qData)
    {
        $this->db->update('bscp_examcenters', $qData, array('id' => $qData['id']));
        
    }
    
      public function DeleteCenter($ide){
        
            $query = $this-> db -> query('delete from bscp_examcenters where id="'.$ide.'"');
            if($query) {
            $result = array(0 => "success");
            } else {
                $result = array(0 => "fail");
            }
            return $result; 
        
        
    }
    
    //exammaster
    
     public function GetExamMasters(){
        
	   $roleaccess = $this->config->item('roleaccess');
		   
    	    $this->datatables->select('bscp_exammaster.active as active,bscp_exammaster.duration as duration,bscp_exammaster.date as date,bscp_exammaster.created_at as created_at,bscp_exammaster.ide as ide,bscp_exammaster.name as name,bscp_exammaster.displaycname as coursename') 
            ->edit_column('name', '<a href="examview?id=$2" class="name">$1</a>', 'name,ide')
            ->edit_column('active', '$1', 'check_exammastereditdel1(ide,active,"'.$roleaccess['Exam Master'][1].'")')
           ->edit_column('ide', '$1', 'check_exammastereditdel(ide,"'.$roleaccess['Exam Master'][1].'","'.$roleaccess['Exam Master'][2].'")')
            ->edit_column('coursename', '<span class="message">$1</a>', 'coursename')
            ->edit_column('duration', '<span class="message">$1</a>', 'duration')
           
            ->edit_column('created_at', '<span class="sno">$1</a>', 'created_at')              
            ->from('bscp_exammaster')->where("bscp_exammaster.del","n")
            ->group_by('name');
           
            
            $table =  $this->datatables->generate();
            return $table;
    
    }
    
    
      public function ChangeExamStatus($ide,$status){
        
        $query1 = $this-> db -> query('update `bscp_exammaster` set active="'.$status.'" where ide="'.$ide.'"');
        if($query1) {
            $result = array(0 => "success");
        } else {
            $result = array(0 => "fail");
        }
        
        return $result; 
        
        
    }
	
    
      public function GetAllDistricts($inp,$type){
        
        $retHTML = "";
        $selected="";$where = "";
        
         $query2 = $this-> db -> query('select * from bscp_examdistricts'.$where);
	$row = $query2->result_array();
        if ($row) {
            
                $cenArr = explode("|",$inp);
                for($i=0 ; $i < count($row);$i++) {
                    if( ($row[$i]["name"] == $inp) || (in_array($row[$i]["name"],$cenArr))) {
                        $selected = 'selected=selected';
                    }
                    
                    if($type === "option"){
                        $retHTML .= "<option ".$selected.">".$row[$i]["name"]."</option>";
                    } else {
                        $retHTML .= "<li ".$selected."><label style=\"text-align: left;color:#536485;background: none;border: 0px;width: auto;height: auto;float:left;font-size: 15px\"><input class=\"radiocenters\" attr-centers=\"".$row[$i]["name"]."\" name=\"radiocenters\" type=\"radio\" />".$row[$i]["name"]."</li></label>";
                    }
                   $selected = "";
                }
                
        }
        
        return $retHTML;
        
    }
    
    
     public function GetAllCenters($inp){
        
        $retHTML = "";
        
        $disArr = explode(",",$inp);
        
        foreach($disArr as $key=>$val){
            
            $query2 = $this-> db -> query('select * from bscp_examcenters where districtname="'.$val.'"');
            $row = $query2->result_array();
            if ($row) {

                    for($i=0 ; $i < count($row);$i++) {
                         $retHTML .= "<option>".$row[$i]["name"]."</option>";

                    }
            }
            
        }
        
        return $retHTML;
        
    }
    
    public function AddMasterExam($qData)
    {
        $this->db->insert('bscp_exammaster', $qData);
        return $this->db->insert_id();
    }
    
    public function AddSelectedCenter($qData)
    {
        $this->db->insert('bscp_selectedexamcenters', $qData);
        return $this->db->insert_id();
    }
    
    public function IsCenterNumRows($district,$center)
    {
         $query = $this-> db -> query('select * from bscp_examcenters where districtname="'.$district.'" and name="'.$center.'"');
         if($query->num_rows()>0)
        {
            return $query->num_rows(); 
        }
        else
        {
            return 0;
        }
    }
    
     public function DeleteExamMaster($ide){
        
        $query1 = $this-> db -> query('update `bscp_exammaster` set del="y" where ide="'.$ide.'"');
        if($query1) {
            $result = array(0 => "success");
        } else {
            $result = array(0 => "fail");
        }
        
        return $result; 
        
        
    }
    
         //Overall Events center wise list
      public function GetRegisteredEvents($cid) {
        
        $arr = Array();
		
		$arr['list'] = "";

	        $this->datatables->select('bscp_student_exammaster.examid as examid,bscp_student_exammaster.district as district,count(*) AS applied') 
                 ->edit_column('applied', '<a data-id="$1" class="idValue" style="text-decoration:underline;padding:0px;font-size:15px;line-height:20px" href="'.base_url().'examview?id=$1&type=$3">$2</a>', 'examid,applied,district')
                ->edit_column('district', '<a data-id="$1" class="idValue" style="text-decoration:underline;padding:0px;font-size:15px;line-height:20px" href="'.base_url().'examview?id=$1&type=$2">$2</a>', 'examid,district')
                ->from('bscp_student_exammaster')
                ->where('bscp_student_exammaster.examid',$cid)
                ->group_by('bscp_student_exammaster.district');
              
                $table =  $this->datatables->generate();
		
		return $table;
        
    }
    
      public function GetRegisteredCenterEvents($cid,$district) {
        
        $arr = Array();
		
		$arr['list'] = "";

	        $this->datatables->select('bscp_student_exammaster.examid as examid,bscp_student_exammaster.location as location,bscp_student_exammaster.district as district,count(*) AS applied') 
               
             ->edit_column('applied', '<a data-id="$1" class="idValue" style="text-decoration:underline;padding:0px;font-size:15px;line-height:20px" href="'.base_url().'examview?id=$1&type=$4&center=$3">$2</a>', 'examid,applied,location,district')
                       ->edit_column('location', '<a data-id="$1" class="idValue" style="text-decoration:underline;padding:0px;font-size:15px;line-height:20px" href="'.base_url().'examview?id=$1&type=$3&center=$2">$2</a>', 'examid,location,district')
                        ->from('bscp_student_exammaster')
              ->where('bscp_student_exammaster.examid',$cid)
              ->where('bscp_student_exammaster.district',$district)
              ->group_by('bscp_student_exammaster.location');
              
                $table =  $this->datatables->generate();
		
		return $table;
        
    }
    
    
       public function GetEventName($cid) {
         
        $arr = '';
        $query1 = $this-> db -> query('select name from bscp_exammaster where  ide="'.$cid.'"');
	$row = $query1->result_array();
        if ($row) {
            
            $arr = $row[0]['name'];
        } 
        
        return $arr;    
         
     }
     
     
     	public function GetRegisterdEvents_count($cid,$type,$center)
    {   
				
	$query = $this ->db->query('select cr.ide from bscp_student_exammaster as cr where cr.examid="'.$cid.'" and cr.district="'.$type.'" and cr.location="'.$center.'"' );
        return $query->num_rows();  

    }
    
    public function GetAllRegisterdEvents($limit,$start,$col,$dir,$cid,$type,$center)
    {   
		
		$selectquery = 'cr.studentid as sid,s.email as email,s.contact as mobile,s.sname as sname,s.studid as studid,cr.ide as ide';
	
	
		$query = $this ->db->query('select '.$selectquery.' from bscp_student_exammaster as cr LEFT JOIN bscp_student as s ON s.id=cr.studentid where cr.examid="'.$cid.'" and cr.district="'.$type.'" and cr.location="'.$center.'" order by '.$col.' '.$dir.' limit '.$start.','.$limit);
        
        if($query->num_rows()>0)
        {
            return $query->result(); 
        }
        else
        {
            return null;
        }
        
    }
   
    public function GetRegisteredEvents_search($limit,$start,$search,$col,$dir,$cid,$type,$searchcol,$center)
    {
		
		$selectquery = 'cr.studentid as sid,s.email as email,s.contact as mobile,s.sname as sname,s.studid as studid,cr.ide as ide';
		
		$wheresearch = '';
		
		if($searchcol!="") $wheresearch .= ' and (';
		
		if($searchcol=="stuid"){$wheresearch .= ' `s`.`studid` = "'.$search.'"';}
		else if($searchcol=="stuname"){$wheresearch .= ' `s`.`sname` LIKE "%'.$search.'%"';}
		else if($searchcol=="mobile"){$wheresearch .= ' `s`.`contact` = "'.$search.'"';}
		else if($searchcol=="email"){$wheresearch .= ' `s`.`email` = "'.$search.'"';}
			
		if($searchcol!="") $wheresearch .= ')';
		
                $whereclause = 'cr.examid="'.$cid.'" and cr.district="'.$type.'" and cr.location="'.$center.'"';
		$whereclause = $whereclause.$wheresearch;
		
		$query = $this ->db->query('select '.$selectquery.' from bscp_student_exammaster as cr LEFT JOIN bscp_student as s ON s.id=cr.studentid where '.$whereclause.' order by '.$col.' '.$dir.' limit '.$start.','.$limit);
        
       
        if($query->num_rows()>0)
        {
            return $query->result();  
        }
        else
        {
            return null;
        }
    }

    public function GetRegisteredEvents_search_count($search,$cid,$type,$searchcol,$center)
    {
		
		$selectquery = 'cr.studentid as sid,s.email as email,s.contact as mobile,s.sname as sname,s.studid as studid,cr.ide as ide';
		
		$wheresearch = '';
		
		if($searchcol!="") $wheresearch .= ' and (';
		
		if($searchcol=="stuid"){$wheresearch .= ' `s`.`studid` = "'.$search.'"';}
		else if($searchcol=="stuname"){$wheresearch .= ' `s`.`sname` LIKE "%'.$search.'%"';}
		else if($searchcol=="mobile"){$wheresearch .= ' `s`.`contact` = "'.$search.'"';}
		else if($searchcol=="email"){$wheresearch .= ' `s`.`email` = "'.$search.'"';}
			
		if($searchcol!="") $wheresearch .= ')';
		
                $whereclause = 'cr.examid="'.$cid.'" and cr.district="'.$type.'" and cr.location="'.$center.'"';
		$whereclause = $whereclause.$wheresearch;
		
		$query = $this ->db->query('select '.$selectquery.' from bscp_student_exammaster as cr LEFT JOIN bscp_student as s ON s.id=cr.studentid where '.$whereclause);
        
        return $query->num_rows();
    }
    
    
    public function ExportEventRegistrations($examid,$type,$center){
        
        $where = ""; $courseArr = Array();$wheretype = "";
        if(($center !== "") && ($type !== "")) { $where = " and cr.district='".$type."' and cr.location='".$center."' ";}
        else if(($center === "") && ($type !== "")) { $where = " and cr.district='".$type."'";}
        else if(($center === "") && ($type === "")) { $where = "";}
		
        
          $query1 = $this-> db -> query("select s.*,"
                  . "cr.*,c.coursename from bscp_student_exammaster as cr,bscp_student as s,admin_course as c"
                  . " where cr.examid='$examid' and cr.studentid=s.id and cr.courseid=c.ide ".$wheretype.$where);
          $row1 = $query1->result_array();
          
          if ($row1) {
            for($i = 0;$i<count($row1);$i++) {
                
                 $ide = $row1[$i]['id'];
                 $courseArr[$ide]['sname'] = $row1[$i]['sname'];$courseArr[$ide]['fname'] = $row1[$i]['fname'];
                 $courseArr[$ide]['contact'] = $row1[$i]['contact'];$courseArr[$ide]['city'] = $row1[$i]['city'];
                 $courseArr[$ide]['email'] = $row1[$i]['email'];$courseArr[$ide]['studid'] = $row1[$i]['studid'];
                 
                $query41 = $this-> db -> query("select sp.* from bscp_studentprofile as sp where sp.stuid='".$ide."'");
                $row41 = $query41->result_array();
                if ($row41) {
               
                 $courseArr[$ide]['guardianname'] = $row41[0]['guardianname'];$courseArr[$ide]['gender'] = $row41[0]['gender'];
                 $courseArr[$ide]['dob'] = $row41[0]['dob'];$courseArr[$ide]['fathername'] = $row41[0]['fathername'];
                 $courseArr[$ide]['fatheroccupation'] = $row41[0]['fatheroccupation'];$courseArr[$ide]['fatheremail'] = $row41[0]['fatheremail'];
                 $courseArr[$ide]['fathercode'] = $row41[0]['fathercode'];$courseArr[$ide]['fatherphone'] = $row41[0]['fatherphone'];
                 $courseArr[$ide]['mothername'] = $row41[0]['mothername'];$courseArr[$ide]['motheroccupation'] = $row41[0]['motheroccupation'];
                 $courseArr[$ide]['motheremail'] = $row41[0]['motheremail'];$courseArr[$ide]['mothercode'] = $row41[0]['mothercode'];
                 $courseArr[$ide]['motherphone'] = $row41[0]['motherphone'];$courseArr[$ide]['communicationcontact'] = $row41[0]['communicationcontact'];
                 $courseArr[$ide]['nationality'] = $row41[0]['nationality'];$courseArr[$ide]['category'] = $row41[0]['category'];
                 $courseArr[$ide]['bloodgroup'] = $row41[0]['bloodgroup'];$courseArr[$ide]['classstudy'] = $row41[0]['classstudy'];
                 $courseArr[$ide]['stream'] = $row41[0]['stream'];$courseArr[$ide]['schoolcollegename'] = $row41[0]['schoolcollegename'];
                 $courseArr[$ide]['eduaddress'] = $row41[0]['eduaddress'];$courseArr[$ide]['edulandmark'] = $row41[0]['edulandmark'];
                 $courseArr[$ide]['edudistrict'] = $row41[0]['edudistrict'];$courseArr[$ide]['edustate'] = $row41[0]['edustate'];
                 $courseArr[$ide]['edupost'] = $row41[0]['edupost'];$courseArr[$ide]['edupincode'] = $row41[0]['edupincode'];
                 $courseArr[$ide]['educountry'] = $row41[0]['educountry'];$courseArr[$ide]['examboard'] = $row41[0]['examboard'];
                 $courseArr[$ide]['examclass'] = $row41[0]['examclass'];$courseArr[$ide]['preferredsubject'] = $row41[0]['preferredsubject'];
                 $courseArr[$ide]['eligiblescholar'] = $row41[0]['eligiblescholar'];$courseArr[$ide]['mocktype'] = $row41[0]['mocktype'];
                 $courseArr[$ide]['rollno'] = $row41[0]['rollno'];$courseArr[$ide]['housenameno'] = $row41[0]['housenameno'];
                 $courseArr[$ide]['landmark'] = $row41[0]['landmark'];$courseArr[$ide]['contactaddress'] = $row41[0]['contactaddress'];
                 $courseArr[$ide]['contactcountry'] = $row41[0]['contactcountry'];$courseArr[$ide]['contactstate'] = $row41[0]['contactstate'];
                 $courseArr[$ide]['contactdistrict'] = $row41[0]['contactdistrict'];$courseArr[$ide]['wacode'] = $row41[0]['wacode'];
                 $courseArr[$ide]['contactpost'] = $row41[0]['contactpost'];$courseArr[$ide]['whatsappno'] = $row41[0]['whatsappno'];
                 $courseArr[$ide]['contactpincode'] = $row41[0]['contactpincode'];$courseArr[$ide]['accountholdername'] = $row41[0]['accountholdername'];
                 $courseArr[$ide]['bankname'] = $row41[0]['bankname'];$courseArr[$ide]['branch'] = $row41[0]['branch'];
                 $courseArr[$ide]['ifsccode'] = $row41[0]['ifsccode'];$courseArr[$ide]['bankaccountno'] = $row41[0]['bankaccountno'];
                 $courseArr[$ide]['aadharnumber'] = $row41[0]['aadharnumber'];
               
                } else {
                 $courseArr[$ide]['guardianname'] ="";$courseArr[$ide]['gender'] = "";
                 $courseArr[$ide]['dob'] = "";$courseArr[$ide]['fathername'] = "";
                 $courseArr[$ide]['fatheroccupation'] ="";$courseArr[$ide]['fatheremail'] = "";
                 $courseArr[$ide]['fathercode'] = "";$courseArr[$ide]['fatherphone'] = "";
                 $courseArr[$ide]['mothername'] = "";$courseArr[$ide]['motheroccupation'] = "";
                 $courseArr[$ide]['motheremail'] = "";$courseArr[$ide]['mothercode'] = "";
                 $courseArr[$ide]['motherphone'] = "";$courseArr[$ide]['communicationcontact'] = "";
                 $courseArr[$ide]['nationality'] = "";$courseArr[$ide]['category'] = "";
                 $courseArr[$ide]['bloodgroup'] = "";$courseArr[$ide]['classstudy'] = "";
                 $courseArr[$ide]['stream'] = "";$courseArr[$ide]['schoolcollegename'] = "";
                 $courseArr[$ide]['eduaddress'] = "";$courseArr[$ide]['edulandmark'] = "";
                 $courseArr[$ide]['edudistrict'] = "";$courseArr[$ide]['edustate'] = "";
                 $courseArr[$ide]['edupost'] = "";$courseArr[$ide]['edupincode'] = "";
                 $courseArr[$ide]['educountry'] = "";$courseArr[$ide]['examboard'] = "";
                 $courseArr[$ide]['examclass'] = "";$courseArr[$ide]['preferredsubject'] = "";
                 $courseArr[$ide]['eligiblescholar'] = "";$courseArr[$ide]['mocktype'] = "";
                 $courseArr[$ide]['rollno'] = "";$courseArr[$ide]['housenameno'] = "";
                 $courseArr[$ide]['landmark'] = "";$courseArr[$ide]['contactaddress'] = "";
                 $courseArr[$ide]['contactcountry'] = "";$courseArr[$ide]['contactstate'] = "";
                 $courseArr[$ide]['contactdistrict'] = "";$courseArr[$ide]['wacode'] = "";
                 $courseArr[$ide]['contactpost'] = "";$courseArr[$ide]['whatsappno'] = "";
                 $courseArr[$ide]['contactpincode'] = "";$courseArr[$ide]['accountholdername'] = "";
                 $courseArr[$ide]['bankname'] = "";$courseArr[$ide]['branch'] = "";
                 $courseArr[$ide]['ifsccode'] = "";$courseArr[$ide]['bankaccountno'] = "";
                 $courseArr[$ide]['aadharnumber'] = "";
                }
                $courseArr[$ide]['coursename'] = $row1[$i]['coursename'];
                $courseArr[$ide]['district'] = $row1[$i]['district'];
                $courseArr[$ide]['location'] = $row1[$i]['location'];
                $courseArr[$ide]['examname'] = $row1[$i]['examname'];
                   
                 $query4 = $this-> db -> query("select mcode from bscp_signup where mobile='".$row1[$i]['contact']."'");
                $row4 = $query4->result_array();
                if ($row4) {
                $courseArr[$ide]['mcode'] = $row4[0]['mcode'];
               
                } else {
                    $courseArr[$ide]['mcode'] = '';
                }
				
		
            }
            
          }
		
          return $courseArr;
        
    }
     
    
}
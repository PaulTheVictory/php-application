<<<<<<< .mine
<?php

Class Reports_Model extends CI_Model {
    
     public function __construct() {
        
       $this->load->library('Datatables');
  
    }

    public function BillGeneratonSummary($sdate,$edate,$center) {
        
        $arr = Array();$arr["count"] = 0;$courseArr = Array();
        
                
        $where = "";
        if(($center !== "") && ($center !== "All")) { $where = " and center='".$center."' ";}
        
        $query0 = $this-> db -> query('select distinct cr.receiptno from bscp_feepayments as cr where cr.paymentstatus="p" and (cr.paymentdate between "'.$sdate.'" and "'.$edate.'")'.$where."order by cast(receiptno as unsigned)");
        if ($query0->num_rows()>0) {
           // $courseArr["count"] = $query0->num_rows();
            //$courseArr["count"] = intval($courseArr["count"] === 0)?$courseArr["count"]:(intval($courseArr["count"])+1);
            $row = $query0->result_array();
            if ($row) {
               $courseArr['billno'] = $row[0]['receiptno']." to ".$row[count($row)-1]['receiptno'];
               $r1 =  intval($row[count($row)-1]['receiptno']);
               $r2 = intval($row[0]['receiptno']);
               $r3 = intval($r1)-intval($r2);
               $courseArr["count"] = ++$r3;
            }
        }
    
        
        
        
        $query1 = $this-> db -> query("select cr.courseid,sum(cr.discount) as discount,cr.courseid,sum(cr.amount) as amount,sum(cr.total) as total,sum(cr.paymentamount) as paymentamount,cr.paymentmode,c.coursename,sp.description from bscp_feepayments as cr,bscp_student_payments as sp,admin_course as c where cr.courseid=sp.courseid and cr.paymentstatus='p' and cr.courseid=c.ide and cr.stupayid=sp.id "
                . "and (cr.paymentdate between '".$sdate."' and '".$edate."')".$where."and (sp.description like '%Tuition Fee%' or sp.description like '%Registration%' or sp.description like '%Caution Deposit%') GROUP by cr.courseid,cr.paymentmode,sp.description");
        $row1 = $query1->result_array();
        if ($row1) {
            for($i = 0;$i<count($row1);$i++) {
                    $cid = $row1[$i]['courseid'];
                    $cname = $row1[$i]['coursename'];
                    $description = $row1[$i]['description'];
                    $payamount = $row1[$i]['amount'];
                    $discount = $row1[$i]['discount'];
                    $payamount = floatval($payamount)-floatval($discount);
                    $paid = $row1[$i]['paymentamount'];
                    $total = $row1[$i]['total'];
                    $paymode = $row1[$i]['paymentmode'];
                    $paymode = ($paymode === "")?'cash':$paymode;
                    $paymode = strtolower($paymode);
                    if(strpos($description, 'Registration') !== false){
                        $description = "Reg Fee";
                    } else if(strpos($description, 'Tuition') !== false){
                        $description = "Tuition Fee";
                    }else if(strpos($description, 'Caution') !== false){
                        $description = "CD";
                    }
                    
                    if(!array_key_exists($cid, $courseArr)){
                        $courseArr[$cid]=Array();
                        
                    } 
                    
                    if(!in_array($cname, $courseArr[$cid])){
                        $courseArr[$cid]['cname'] = $cname;                       
                    } 

                    if(!array_key_exists($description, $courseArr[$cid])){
                        $courseArr[$cid][$description] = 0;  
                    } 
                    
                    if(!array_key_exists($paymode, $courseArr[$cid])){
                        $courseArr[$cid][$paymode] = 0;  
                    }
                    
                    if(!array_key_exists('total', $courseArr[$cid])){
                        $courseArr[$cid]['total'] = 0;  
                    }
                    
                    if(!array_key_exists('paid', $courseArr[$cid])){
                        $courseArr[$cid]['paid'] = 0;  
                    }

                    
                    $courseArr[$cid][$description] = floatVal($courseArr[$cid][$description] )+floatval($payamount);
                    $courseArr[$cid][$paymode] = floatVal($courseArr[$cid][$paymode] )+floatval($paid);
                    $courseArr[$cid]['total'] = floatVal($courseArr[$cid]['total'] )+floatval($total);
                    $courseArr[$cid]['paid'] = floatVal($courseArr[$cid]['paid'] )+floatval($paid);
                   
            }
        }
		
	return $courseArr;	
    }
    
    
    public function CourseWiseAdmittedList($sdate,$edate,$center) {
        
         $where = ""; $courseArr = Array();
        if(($center !== "") && ($center !== "All")) { $where = " and center='".$center."' ";}
        
          $query1 = $this-> db -> query("select cr.ide,c.coursename,cr.center,s.studid,s.sname,s.contact,sp.whatsappno,s.email,aq.name,cr.stream,cr.xii_stream,"
                  . "cr.total from bscp_courserequest as cr,bscp_student as s,admin_course as c,bscp_studentprofile as sp,"
                  . "admin_qualification as aq where cr.courseid=c.ide and cr.studentid=s.id and cr.studentid=sp.stuid and cr.qualificationid=aq.id and cr.approved='y'"
                . "and (cr.requested_at between '".$sdate."' and '".$edate."')".$where);
       
        $row1 = $query1->result_array();
        if ($row1) {
            for($i = 0;$i<count($row1);$i++) {
                $ide = $row1[$i]['ide'];
                $courseArr[$ide]['coursename'] = $row1[$i]['coursename'];
                $courseArr[$ide]['center'] = $row1[$i]['center'];
                $courseArr[$ide]['studid'] = $row1[$i]['studid'];
                $courseArr[$ide]['sname'] = $row1[$i]['sname'];
                $courseArr[$ide]['contact'] = $row1[$i]['contact'];
                $courseArr[$ide]['whatsappno'] = $row1[$i]['whatsappno'];
                $courseArr[$ide]['email'] = $row1[$i]['email'];
                $courseArr[$ide]['name'] = $row1[$i]['name'];
                $courseArr[$ide]['stream'] = ($row1[$i]['xii_stream'] !== "")? $row1[$i]['xii_stream']:$row1[$i]['stream'];
                //$courseArr[$ide]['total'] = round($row1[$i]['total']);
                
                $query2 = $this-> db -> query("select sum(total) as total,DATE_FORMAT(paymentdate,'%d-%m-%Y %h:%i %p') as pdate from bscp_feepayments where requestid='".$row1[$i]['ide']."' and paymentstatus='p'");
                $row2 = $query2->result_array();
                if ($row2) {
                $courseArr[$ide]['remitted'] = $row2[0]['total'];
                $courseArr[$ide]['pdate'] = $row2[0]['pdate'];
                } else {
                    $courseArr[$ide]['remitted'] = '0';
                    $courseArr[$ide]['pdate'] = '';
                }
                
                $query3 = $this-> db -> query("select sum(total) as total from bscp_student_payments where requestid='".$row1[$i]['ide']."'");
                $row3 = $query3->result_array();
                if ($row3) {
                $courseArr[$ide]['total'] = $row3[0]['total'];
               
                } else {
                    $courseArr[$ide]['total'] = '0';
                }
                
                $query4 = $this-> db -> query("select mcode from bscp_signup where mobile='".$row1[$i]['contact']."'");
                $row4 = $query4->result_array();
                if ($row4) {
                $courseArr[$ide]['mcode'] = $row4[0]['mcode'];
               
                } else {
                    $courseArr[$ide]['mcode'] = '';
                }
            }
        }
        
        return $courseArr;
    }
    
    
       public function DailyCourseAppliedList($sdate,$edate,$center) {
        
         $where = ""; $courseArr = Array();
         $statusArr=array("y"=>'Approved',"n"=>'Approved',"w"=>'Waitig List',"n"=>'Applied - NQ',
             "q"=>'Applied',"d"=>'Denied'); 
        if(($center !== "") && ($center !== "All")) { $where = " and center='".$center."' ";}
        
          $query1 = $this-> db -> query("select cr.approved,cr.ide,DATE_FORMAT(cr.requested_at,'%d-%m-%Y %h:%i %p') as rdate,c.coursename,cr.center,s.studid,s.sname,s.contact,s.email,aq.name,cr.stream,cr.xii_stream "
                  . "from bscp_courserequest as cr,bscp_student as s,admin_course as c,"
                  . "admin_qualification as aq where cr.courseid=c.ide and cr.studentid=s.id and cr.qualificationid=aq.id "
                . "and (cr.requested_at between '".$sdate."' and '".$edate."')".$where);
       
        $row1 = $query1->result_array();
        if ($row1) {
            for($i = 0;$i<count($row1);$i++) {
                $ide = $row1[$i]['ide'];
                $courseArr[$ide]['coursename'] = $row1[$i]['coursename'];
                $courseArr[$ide]['center'] = $row1[$i]['center'];
                $courseArr[$ide]['studid'] = $row1[$i]['studid'];
                $courseArr[$ide]['sname'] = $row1[$i]['sname'];
                $courseArr[$ide]['contact'] = $row1[$i]['contact'];
                $status = (array_key_exists($row1[$i]['approved'], $statusArr))?$statusArr[$row1[$i]['approved']]:"NA";
                $courseArr[$ide]['status'] = $status;
                $courseArr[$ide]['email'] = $row1[$i]['email'];
                $courseArr[$ide]['qualification'] = $row1[$i]['name'];
                $courseArr[$ide]['stream'] = ($row1[$i]['xii_stream'] !== "")? $row1[$i]['xii_stream']:$row1[$i]['stream'];
                $courseArr[$ide]['rdate'] = $row1[$i]['rdate'];
               
                $query4 = $this-> db -> query("select mcode from bscp_signup where mobile='".$row1[$i]['contact']."'");
                $row4 = $query4->result_array();
                if ($row4) {
                $courseArr[$ide]['mcode'] = $row4[0]['mcode'];
               
                } else {
                    $courseArr[$ide]['mcode'] = '';
                }
                
            }
        }
        
        return $courseArr;
    }
    
    
     public function DailySignupList($sdate,$edate) {
        
         $courseArr = Array();
                 
          $query1 = $this-> db -> query("select s.studid,s.sname,s.contact,s.email,aq.name "
                  . "from bscp_student as s,admin_qualification as aq where s.qualification=aq.id "
                . "and (s.created_at between '".$sdate."' and '".$edate."')");
       
        $row1 = $query1->result_array();
        if ($row1) {
            for($i = 0;$i<count($row1);$i++) {
                $courseArr[$i]['studid'] = $row1[$i]['studid'];
                $courseArr[$i]['sname'] = $row1[$i]['sname'];
                $courseArr[$i]['contact'] = $row1[$i]['contact'];
                $courseArr[$i]['email'] = $row1[$i]['email'];
                $courseArr[$i]['qualification'] = $row1[$i]['name'];
                
                $query4 = $this-> db -> query("select mcode from bscp_signup where mobile='".$row1[$i]['contact']."'");
                $row4 = $query4->result_array();
                if ($row4) {
                $courseArr[$i]['mcode'] = $row4[0]['mcode'];
               
                } else {
                    $courseArr[$i]['mcode'] = '';
                }
                
            }
        }
        
        return $courseArr;
    }
    
    public function DailyBillList($sdate,$edate,$center) {
        
         $courseArr = Array();
                 
          if(($center !== "") && ($center !== "All")) { $where = " and a.center='".$center."' ";}        
          $query1 = $this-> db -> query('SELECT a.courseid,'
                  . ' a.paymentmode, DATE_FORMAT(a.paymentdate, "%d-%m-%Y %h:%i %p") as paydate,'
                  . ' a.receiptno, a.studentid , a.courseid , a.paymentdate , b.studid'
                  . ', a.challanno, b.sname , c.coursename, a.center, sum(a.total) as paid FROM bscp_feepayments as a'
                  . ',bscp_student as b, admin_course as c where b.id=a.studentid and c.ide=a.courseid and a.paymentstatus = "p" '
                  . 'and (a.paymentdate between "'.$sdate.'" and "'.$edate.'") '.$where.'GROUP BY `challanno`, `studentid`');
       
        $row1 = $query1->result_array();
        if ($row1) {
            for($i = 0;$i<count($row1);$i++) {
                $courseArr[$i]['studid'] = $row1[$i]['studid'];
                $courseArr[$i]['challanno'] = $row1[$i]['challanno'];
                $courseArr[$i]['paydate'] = $row1[$i]['paydate'];
                $courseArr[$i]['receiptno'] = $row1[$i]['receiptno'];
                $courseArr[$i]['sname'] = $row1[$i]['sname'];
                $courseArr[$i]['coursename'] = $row1[$i]['coursename'];
                $courseArr[$i]['center'] = $row1[$i]['center'];
                $courseArr[$i]['paid'] = $row1[$i]['paid'];
                $courseArr[$i]['paymentmode'] = $row1[$i]['paymentmode'];
                
            }
        }
        
        return $courseArr;
    }
    
    public function UnpaidList($sdate,$edate,$center) {
        
         $courseArr = Array();
          if(($center !== "") && ($center !== "All")) { $where = " and a.center='".$center."' ";}               
         $query1 = $this-> db -> query('SELECT a.studentid, a.courseid,a.created_at, b.studid, a.challanno, a.requestid, b.sname, c.coursename, a.center, sum(a.total) as unpaid FROM bscp_feepayments as a,'
         . 'bscp_student as b, admin_course as c where  b.id=a.studentid and c.ide=a.courseid and (a.paymentstatus="" and a.amount != "0") and '
                 . '(a.created_at between "'.$sdate.'" and "'.$edate.'") '.$where.'GROUP BY a.challanno, a.studentid, a.center,a.courseid');
     
       
        $row1 = $query1->result_array();
        if ($row1) {
            for($i = 0;$i<count($row1);$i++) {
                $courseArr[$i]['studid'] = $row1[$i]['studid'];
                $courseArr[$i]['challanno'] = $row1[$i]['challanno'];
                $courseArr[$i]['sname'] = $row1[$i]['sname'];
                $courseArr[$i]['coursename'] = $row1[$i]['coursename'];
                $courseArr[$i]['center'] = $row1[$i]['center'];
                $courseArr[$i]['unpaid'] = $row1[$i]['unpaid'];
                
                
            }
        }
        
        return $courseArr;
    }
    
    public function FirstTimeStudentPaidList($sdate,$edate,$center) {
        
        $courseArr = Array();
                 
          if(($center !== "") && ($center !== "All")) { $where = " and a.center='".$center."' ";}        
          $query1 = $this-> db -> query('SELECT a.courseid,'
                  . ' a.paymentmode, DATE_FORMAT(a.paymentdate, "%d-%m-%Y %h:%i %p") as paydate,'
                  . ' a.receiptno, a.studentid , a.courseid , a.paymentdate , b.studid,'
                  . ' b.sname ,b.contact ,b.email ,b.city , c.coursename, a.center, sum(a.total) as paid FROM bscp_feepayments as a'
                  . ',bscp_student as b, admin_course as c where b.id=a.studentid and c.ide=a.courseid and a.paymentstatus = "p" '
                  . 'and (a.paymentdate between "'.$sdate.'" and "'.$edate.'") '.$where.'GROUP BY `challanno`, `studentid`');
       
        $row1 = $query1->result_array();
        if ($row1) {
            $j =1;
            for($i = 0;$i<count($row1);$i++) {
                
                $query1 = $this-> db -> query('select requestid from bscp_feepayments as a , admin_course as c where c.ide=a.courseid and c.screentest != "1" and a.studentid="'.$row1[$i]['studentid'].'" and a.paymentdate < "'.$sdate.'" and a.paymentstatus="p"');
                if($query1->num_rows() > 0){
                    
                    
                } else {
                    
                    $query2 = $this-> db -> query('select sp.*,s.mcode from bscp_studentprofile as sp,bscp_signup as s where s.mobile="'.$row1[$i]['contact'].'" and stuid="'.$row1[$i]['studentid'].'"');
                    $row2 = $query2->result_array();
                    if($row2) {
                        $courseArr[$j]['guardianname'] = $row2[0]['guardianname'];$courseArr[$j]['gender'] = $row2[0]['gender'];
                        $courseArr[$j]['dob'] = $row2[0]['dob'];$courseArr[$j]['fathername'] = $row2[0]['fathername'];
                        $courseArr[$j]['fatheroccupation'] = $row2[0]['fatheroccupation'];$courseArr[$j]['fatheremail'] = $row2[0]['fatheremail'];
                        $courseArr[$j]['fathercode'] = $row2[0]['fathercode'];$courseArr[$j]['fatherphone'] = $row2[0]['fatherphone'];
                        $courseArr[$j]['mothername'] = $row2[0]['mothername'];$courseArr[$j]['motheroccupation'] = $row2[0]['motheroccupation'];
                        $courseArr[$j]['motheremail'] = $row2[0]['motheremail'];$courseArr[$j]['mothercode'] = $row2[0]['mothercode'];
                        $courseArr[$j]['motherphone'] = $row2[0]['motherphone'];$courseArr[$j]['communicationcontact'] = $row2[0]['communicationcontact'];
                        $courseArr[$j]['nationality'] = $row2[0]['nationality'];$courseArr[$j]['category'] = $row2[0]['category'];
                        $courseArr[$j]['bloodgroup'] = $row2[0]['bloodgroup'];$courseArr[$j]['classstudy'] = $row2[0]['classstudy'];
                        $courseArr[$j]['stream'] = $row2[0]['stream'];$courseArr[$j]['schoolcollegename'] = $row2[0]['schoolcollegename'];
                        $courseArr[$j]['eduaddress'] = $row2[0]['eduaddress'];$courseArr[$j]['edulandmark'] = $row2[0]['edulandmark'];
                        $courseArr[$j]['edudistrict'] = $row2[0]['edudistrict'];$courseArr[$j]['edustate'] = $row2[0]['edustate'];
                        $courseArr[$j]['edupost'] = $row2[0]['edupost'];$courseArr[$j]['edupincode'] = $row2[0]['edupincode'];
                        $courseArr[$j]['educountry'] = $row2[0]['educountry'];$courseArr[$j]['examboard'] = $row2[0]['examboard'];
                        $courseArr[$j]['examclass'] = $row2[0]['examclass'];$courseArr[$j]['preferredsubject'] = $row2[0]['preferredsubject'];
                        $courseArr[$j]['eligiblescholar'] = $row2[0]['eligiblescholar'];$courseArr[$j]['mocktype'] = $row2[0]['mocktype'];
                        $courseArr[$j]['rollno'] = $row2[0]['rollno'];$courseArr[$j]['housenameno'] = $row2[0]['housenameno'];
                        $courseArr[$j]['landmark'] = $row2[0]['landmark'];$courseArr[$j]['contactaddress'] = $row2[0]['contactaddress'];
                        $courseArr[$j]['contactcountry'] = $row2[0]['contactcountry'];$courseArr[$j]['contactstate'] = $row2[0]['contactstate'];
                        $courseArr[$j]['contactdistrict'] = $row2[0]['contactdistrict'];$courseArr[$j]['wacode'] = $row2[0]['wacode'];
                        $courseArr[$j]['contactpost'] = $row2[0]['contactpost'];$courseArr[$j]['whatsappno'] = $row2[0]['whatsappno'];
                        $courseArr[$j]['contactpincode'] = $row2[0]['contactpincode'];$courseArr[$j]['accountholdername'] = $row2[0]['accountholdername'];
                        $courseArr[$j]['bankname'] = $row2[0]['bankname'];$courseArr[$j]['branch'] = $row2[0]['branch'];
                        $courseArr[$j]['ifsccode'] = $row2[0]['ifsccode'];$courseArr[$j]['bankaccountno'] = $row2[0]['bankaccountno'];
                        $courseArr[$j]['aadharnumber'] = $row2[0]['aadharnumber'];$courseArr[$j]['profilepercent'] = $row2[0]['profilepercent'];
                        $courseArr[$j]['mcode'] = $row2[0]['mcode'];
                    }
                    $courseArr[$j]['studid'] = $row1[$i]['studid'];
                    $courseArr[$j]['challanno'] = $row1[$i]['challanno'];
                    $courseArr[$j]['paydate'] = $row1[$i]['paydate'];
                    $courseArr[$j]['receiptno'] = $row1[$i]['receiptno'];
                    $courseArr[$j]['sname'] = $row1[$i]['sname'];
                    $courseArr[$j]['contact'] = $row1[$i]['contact'];
                    $courseArr[$j]['email'] = $row1[$i]['email'];
                    $courseArr[$j]['city'] = $row1[$i]['city'];
                    $courseArr[$j]['coursename'] = $row1[$i]['coursename'];
                    $courseArr[$j]['center'] = $row1[$i]['center'];
                    $courseArr[$j]['paid'] = $row1[$i]['paid'];
                    $courseArr[$j]['paymentmode'] = $row1[$i]['paymentmode'];
                    $j++;
                }
                
            }
        }
        
        return $courseArr;
    }
    
    
     public function RefundBillList($sdate,$edate,$center) {
        
         $courseArr = Array();
          $reason['scholarship'] = "Scholarship";
                $reason['faid'] = "Financial Aid";
                $reason['discontinue'] = "Discontinue";
                $reason['berror'] = "Billing Error";
                $reason['others'] = "Others";
                 
          if(($center !== "") && ($center !== "All")) { $where = " and a.center='".$center."' ";}        
          $query1 = $this-> db -> query('SELECT DATE_FORMAT(d.created_At, "%d-%m-%Y %h:%i %p") as appdate,d.appno,a.receiptno,'
                  . ' b.studid,b.sname,c.coursename,a.center,sum(a.remitted) as remitted,sum(a.refundamount) as refundamount,a.paydescription,a.reason FROM bscp_refund as a'
                  . ',bscp_student as b, admin_course as c,bscp_refundapplication as d where b.id=a.studentid and c.ide=a.courseid and d.id = a.refundappid '
                  . 'and (a.created_at between "'.$sdate.'" and "'.$edate.'") '.$where.'GROUP BY `receiptno`');
       
        $row1 = $query1->result_array();
        if ($row1) {
            for($i = 0;$i<count($row1);$i++) {
                $courseArr[$i]['studid'] = $row1[$i]['studid'];
                $courseArr[$i]['appno'] = $row1[$i]['appno'];
                $courseArr[$i]['appdate'] = $row1[$i]['appdate'];
                $courseArr[$i]['remitted'] = $row1[$i]['remitted'];
                $courseArr[$i]['sname'] = $row1[$i]['sname'];
                $courseArr[$i]['coursename'] = $row1[$i]['coursename'];
                $courseArr[$i]['center'] = $row1[$i]['center'];
                $courseArr[$i]['paydescription'] = $row1[$i]['paydescription'];
                $courseArr[$i]['refundamount'] = $row1[$i]['refundamount'];
                 $courseArr[$i]['reason'] =  $reason[$row1[$i]['reason']];
                 $courseArr[$i]['receiptno'] = $row1[$i]['receiptno'];
                
            }
        }
        
        return $courseArr;
    }
	
	
	public function WorldlineBillList($sdate,$edate,$center) {
        
         $courseArr = Array();
		
		$where = $where1 = "";
		if(($center !== "") && ($center !== "All")){ 
			$where = " and sp.centers='".$center."' ";
			$where1 = " and fp.center='".$center."' ";
		}        
      /*    $query1 = $this-> db -> query('SELECT DATE_FORMAT(d.created_At, "%d-%m-%Y %h:%i %p") as appdate,d.appno,a.receiptno,'
                  . ' b.studid,b.sname,c.coursename,a.center,sum(a.remitted) as remitted,sum(a.refundamount) as refundamount,a.paydescription,a.reason FROM bscp_refund as a'
                  . ',bscp_student as b, admin_course as c,bscp_refundapplication as d where b.id=a.studentid and c.ide=a.courseid and d.id = a.refundappid '
                  . 'and (a.created_at between "'.$sdate.'" and "'.$edate.'") '.$where.'GROUP BY `receiptno`');*/
		
		$selectquery = 's.sname as name,s.studid,c.courseid,sp.centers as center ,w.referenceNo,(w.amount/100) as paymentamount,w.transactiondatetime as paymentdate,w.statuscode,fp.receiptno,w.statusdesc,fp.paymentmode,w.orderid as referenceid,fp.studentid,fp.courseid as cid';
		
		$selectquery1 = 's.sname as name,s.studid,c.courseid,fp.center,w.referenceNo is null,SUM(fp.total) as paymentamount,fp.paymentdate,w.statuscode is null,fp.receiptno,w.statusdesc is null,fp.paymentmode,fp.referenceid,fp.studentid,fp.courseid as cid';
		
		$query1 = $this ->db->query('select '.$selectquery.' from bscp_worldlinepg as w LEFT JOIN bscp_feepayments as fp ON fp.referenceid=w.orderid LEFT JOIN bscp_student_payments as sp ON sp.studentid=w.studentid and sp.courseid=w.courseid LEFT JOIN bscp_student as s ON s.id=w.studentid LEFT JOIN admin_course as c ON c.ide=w.courseid where (fp.referenceid <> "" or fp.referenceid is null) and (w.transactiondatetime between "'.$sdate.'" and "'.$edate.'") '.$where.' group by w.referenceNo
		UNION
		select '.$selectquery1.' from bscp_feepayments as fp LEFT JOIN bscp_worldlinepg as w ON w.orderid=fp.referenceid LEFT JOIN bscp_student_payments as sp ON sp.studentid=fp.studentid and sp.courseid=fp.courseid LEFT JOIN bscp_student as s ON s.id=fp.studentid LEFT JOIN admin_course as c ON c.ide=fp.courseid where fp.referenceid <> "" AND w.orderid is null AND fp.paymentstatus <> "p"  and (fp.paymentdate between "'.$sdate.'" and "'.$edate.'") '.$where1.' group by fp.referenceid
		order by paymentdate desc');          
       
        $row1 = $query1->result_array();
        if ($row1) {
            for($i = 0;$i<count($row1);$i++) {
				
				$paymentmode = $row1[$i]['paymentmode'];
				
				if((strcmp($paymentmode,"online")===0 && strcmp($paymentmode,"Online")!==0) || (strcmp($paymentmode,"online")!==0 && strcmp($paymentmode,"Online")!==0)) $receiptno = ""; else $receiptno = $row1[$i]['receiptno'];
				
				if($row1[$i]['referenceNo']=="1") $referenceNo = ""; else $referenceNo = $row1[$i]['referenceNo'];
				
				$paymentdate = date('j M Y h:i a',strtotime($row1[$i]['paymentdate']));
				
				if($row1[$i]['statuscode']=="F"){
					$statuscode = "Failed - ". $row1[$i]['statusdesc'];$receiptno = "";
				}else if($row1[$i]['statuscode']=="S"){
					$statuscode = "Success";
				}else{
					$statuscode = "Failed";$receiptno = "";
				}
				
				$courseArr[$i]['sname'] = $row1[$i]['name'];
                $courseArr[$i]['studid'] = $row1[$i]['studid'];
				$courseArr[$i]['courseid'] = $row1[$i]['courseid'];
				$courseArr[$i]['center'] = $row1[$i]['center'];
                $courseArr[$i]['referenceid'] = $row1[$i]['referenceid'];
                $courseArr[$i]['referenceNo'] = $referenceNo;
                $courseArr[$i]['paymentamount'] = $row1[$i]['paymentamount'];
                $courseArr[$i]['paymentdate'] = $paymentdate;
                $courseArr[$i]['statuscode'] = $statuscode;
                $courseArr[$i]['receiptno'] = $receiptno;
                
            }
        }
        
        return $courseArr;
    }
    
        
    public function BulkPrintList($sdate,$edate,$center) {
        
         $courseArr = Array(); $where = '';
                 
          if(($center !== "") && ($center !== "All")) { $where = " and center='".$center."'";}        
          $query1 = $this-> db -> query('SELECT a.studentid,a.requestid, a.studentid , a.challanno,s.studid,s.sname FROM bscp_feepayments as a,bscp_student as s where s.id=a.studentid and a.paymentstatus = "p" and (a.paymentdate between "'.$sdate.'" and "'.$edate.'") '.$where.' GROUP BY `challanno`, `studentid`');
       
        $row1 = $query1->result_array();
        if ($row1) {
            for($i = 0;$i<count($row1);$i++) {
                
                $courseArr[$i]['requestid'] = $row1[$i]['requestid'];
                $courseArr[$i]['studentid'] = $row1[$i]['studentid'];
                $courseArr[$i]['challanno'] = $row1[$i]['challanno'];
                $courseArr[$i]['studid'] = $row1[$i]['studid'];
                 $courseArr[$i]['sname'] = $row1[$i]['sname'];
                 $courseArr[$i]['studentid'] = $row1[$i]['studentid'];
              
            }
        }
        
        return $courseArr;
    }
    
    
    public function BulkPrintView($feesmaster,$feepaybill,$studid,$pname) {
        
        
         $htmlFinal = ''; $html = ''; 
         
         $tablepay = $tablepaynow = $ide = "";
	$sno = $psno = 1;

	$grandtotal = $grandtotalnow = $totalfee = $paidfee = $duefee = $discountfee = $discount = 0;

	$coursename = $center = $paymentmode = $paymentdate = $receiptno = "";
	$checkdiscount = false;

	foreach($feesmaster as $key=>$feemaster){
		
	foreach($feepaybill['feebilldetails'] as $paylist){
		
		if($feemaster['description'] == $paylist['description']){

		$amount = $paylist['amount'];
		$paymentamount = $paylist['paymentamount'];
		$total = $paylist['total'];
		$taxable = $paylist['taxable'];
		$paymentmode = $paylist['paymentmode'];
		$paymentdate = $paylist['paymentdate'];
		$receiptno = $paylist['receiptno'];
		$kf = $paylist['kf'];
		$cov = $paylist['cov'];
		$sac = 999293;
		
		if($paymentamount==0) continue;	
		
		//$thtaxable = '<th scope="col" width="10%">Taxable</th>';
		//$thnontaxable = '<th scope="col" width="10%">Non Taxable</th>';

		$discount = $paylist['discount'];
		$discountamt = 0;$thdiscount = "";$tddiscount = ""; $thtax = ""; $tdtax = "";
		$taxamt = 0;
		$colspan=11;
		
		$tax = $paylist['tax'];
		
		/*$amount1 = round($amount - ($amount * ($tax+$kf)/ (100+$tax+$kf)));
		if($amount==$amount1) $amount = $amount; else $amount = $amount1;*/
		
				
		if(intval($discount)>0) {
							
			$discountamt = $discount;
			//$tddiscount = '<td width="10%">'.$discountamt.'</td>';

			$amount = $amount - $discount;

			$checkdiscount = true;

		}else{
			//$tddiscount = '<td>[DISCOUNT]</td>';
		}
		
		if($tax=="0" || $tax=="NA"){
			
			$tdnontaxable = $amount;
		}else{
			$tdnontaxable = 0;
		}
		
		if($tax!="0" && $tax!="NA"){ 
		
			$tdtaxable = $amount;				

			$taxgst = $tax/2;
			if(intval($tax)>0) $taxamt = $amount * ($tax/100);
			$taxamtgst = $taxamt/2;
			$taxamtgst = number_format($taxamtgst,2);
			
			//$colspan +=4;
			
		} else {
			$tdtaxable = 0;
			$taxgst = $taxamtgst = "NA";
		}
		
		$thtax = '<th scope="col" colspan="2" width="19%"><span class="thtax">CGST</span> <span class="thtaxvalue"><span>Rate %</span> <span>Amount</span></span></th>
			  <th scope="col" colspan="2" width="19%"><span class="thtax">SGST</span> <span class="thtaxvalue"><span>Rate %</span> <span>Amount</span></span></th>';

		$tdtax = '<td width="8%">'.$taxgst.'</td>
				  <td width="8%">'.$taxamtgst.'</td>
				  <td width="8%">'.$taxgst.'</td>
				  <td width="8%">'.$taxamtgst.'</td>';

		$nontaxvalue = $amount;
		$taxvalue = $amount + $taxamt;
		
		
		$kfamt = $amount * ($kf/100);
				

		$grandtotal += $total;

		$tablepay .= '<tr>
					  <th scope="row" width="7%">'.$sno.'.</th>
					  <td width="15%"><strong>'.$paylist['description'].'</strong></td>
					  <td width="11%">'.$sac.'</td>
					  <td width="11%">'.$tdnontaxable.'</td>
					  <td width="11%">'.$tdtaxable.'</td>
					  '.$tddiscount.'
					  '.$tdtax.'
					  <td width="8%">'.$kf.'</td>
					  <td width="8%">'.$kfamt.'</td>
					  <td width="10%">'.number_format($total,2).'</td>
					</tr>';

		$sno++;
	}
		
	}
		
	}
         
         $html = '<div class="row feebill">
								
		<div class="card mb-2 p-4">
		
			<div class="row">
					
			<div class="col-md-6">
			
				<img src="'.base_url().'css/img/brilliant-logo.png" alt="Brilliant Pala Logo" class="mb-2" />
				
				<div class="mt-3"></div>
				
				<p>Receipt No. : <strong>'.$receiptno.'</strong></p>
				<p>Dated : <strong>'.date("d-m-Y h:i A",strtotime($paymentdate)).'</strong></p>
									
			</div>
			<div class="col-md-6 text-right">
				<h3>Brilliant Study Centre, Pala.</h3>
				<p>GSTIN: <strong>32AAEFB8385KIZ7</strong></p>
				<p>Mutholy, Puliyannoor PO, 686-573.</p>
				<p>Phone: 04822 206 100</p>
				<p>Email: admissions@brilliantpala.org</p>
			</div>
			
		
		</div>
			
			<div class="hr mt-1 mb-2"></div>
			
		<div class="row">
			
			<div class="col-md-6">
			
				<p>Student Id: <strong>'.$studid.'</strong></p>
				<p class="mb-0">Student: <strong>'.strtoupper($pname).'</strong></p>';
				
				if(!empty($feepaybill['studentdetails'])){
				
				$html .= '<div class="row">
					<div class="col-md-1"></div>
					<div class="col-md-6">
						<p>'.$feepaybill['studentdetails'][0]['housenameno']." ".$feepaybill['studentdetails'][0]['contactaddress'].", ".$feepaybill['studentdetails'][0]['contactpost'].", ".$feepaybill['studentdetails'][0]['contactdistrict'].", ".$feepaybill['studentdetails'][0]['contactstate'].", ".$feepaybill['studentdetails'][0]['contactcountry']." ".$feepaybill['studentdetails'][0]['contactpincode'].'.'.'</p>
					</div>
				</div>';
				
				 }
				
			$html .='</div>
			<div class="col-md-6 text-right">
				
				<p>Course:  <strong>['.$feepaybill['course'][0]['coursename'].','.$feepaybill['course'][0]['center'].']</strong></p>
				
			</div>
			
		</div>	
		
		<div class="row mb-2">
		
		 <table class="table">
              <thead>
                <tr>
                  <th scope="col" width="5%">Sl. no.</th>
                  <th scope="col" width="18%">Description</th>
                  <th scope="col" width="10%">SAC</th>
                  <th scope="col" width="10%">Non Taxable Value</th>
                  <th scope="col" width="10%">Taxable Value</th>'.$thdiscount.$thtax.'<th scope="col" width="8%">CESS KF %</th>
                  <th scope="col" width="10%">CESS KF Amount</th>
                  <th scope="col" width="14%">Total</th>
                </tr>
              </thead>
              <tbody>'.$tablepay.'               
                <tr>
                  <td colspan="'.$colspan.'" class="totalamt">Grand total</td>
                  <td class="totalfee">'.number_format($grandtotal,2).'</td>
                </tr>
              </tbody>
            </table>
            
			</div>
          
           
			<p class="mb-2">Total Amount: <strong>Rs.'.number_format($grandtotal).'/- '.$this->getIndianCurrency($grandtotal).' Only)</strong></p>

			<p class="mb-2">Payment Mode: <strong>'.strtoupper($paymentmode).'</strong></p>

			<p class="mb-2">Remitted On: <strong>'.date("d-m-Y",strtotime($paymentdate)).'</strong></p>
            
            
            <div class="row d-flex align-items-end mt-3 mb-0">
			
			<div class="col-md-6">
			
				
			</div>
			<div class="col-md-6 text-right">
				
				<h4>Computer generated receipt</h4>
				
			</div>
			
		</div>

            
			</div>
			
		</div>
		
		<div class="mt-0 mb-2 w-100" style="border-bottom: 1px dashed #dee2e6!important;"></div>';
         
        // $htmlClone = '<div class="billclone">'.$html.'</div>';
         
         $htmlFinal = $html;
        
        return $htmlFinal;
    }
    
    public function getIndianCurrency(float $number)
    {
        $decimal = round($number - ($no = floor($number)), 2) * 100;
        $hundred = null;
        $digits_length = strlen($no);
        $i = 0;
        $str = array();
        $words = array(0 => '', 1 => 'one', 2 => 'two',
            3 => 'three', 4 => 'four', 5 => 'five', 6 => 'six',
            7 => 'seven', 8 => 'eight', 9 => 'nine',
            10 => 'ten', 11 => 'eleven', 12 => 'twelve',
            13 => 'thirteen', 14 => 'fourteen', 15 => 'fifteen',
            16 => 'sixteen', 17 => 'seventeen', 18 => 'eighteen',
            19 => 'nineteen', 20 => 'twenty', 30 => 'thirty',
            40 => 'forty', 50 => 'fifty', 60 => 'sixty',
            70 => 'seventy', 80 => 'eighty', 90 => 'ninety');
        $digits = array('', 'hundred','thousand','lakh', 'crore');
        while( $i < $digits_length ) {
            $divider = ($i == 2) ? 10 : 100;
            $number = floor($no % $divider);
            $no = floor($no / $divider);
            $i += $divider == 10 ? 1 : 2;
            if ($number) {
                $plural = (($counter = count($str)) && $number > 9) ? 's' : null;
                $hundred = ($counter == 1 && $str[0]) ? ' and ' : null;
                //$str [] = ($number < 21) ? $words[$number].' '. $digits[$counter]. $plural.' '.$hundred:$words[floor($number / 10) * 10].' '.$words[$number % 10]. ' '.$digits[$counter].$plural.' '.$hundred;
                            $str [] = ($number < 21) ? $words[$number].' '. $digits[$counter].' '.$hundred:$words[floor($number / 10) * 10].' '.$words[$number % 10]. ' '.$digits[$counter].' '.$hundred;
            } else $str[] = null;
        }
        $Rupees = implode('', array_reverse($str));
        $paise = ($decimal > 0) ? "." . ($words[$decimal / 10] . " " . $words[$decimal % 10]) . ' Paise' : '';
        //return ($Rupees ? $Rupees . 'Rupees ' : '') . $paise;
            return (ucwords($Rupees) ? ucwords($Rupees) : '') . ucwords($paise);
    }
   
}

||||||| .r336
<?php

Class Reports_Model extends CI_Model {
    
     public function __construct() {
        
       $this->load->library('Datatables');
  
    }

    public function BillGeneratonSummary($sdate,$edate,$center) {
        
        $arr = Array();$arr["count"] = 0;$courseArr = Array();
        
                
        $where = "";
        if(($center !== "") && ($center !== "All")) { $where = " and center='".$center."' ";}
        
        $query0 = $this-> db -> query('select distinct cr.receiptno from bscp_feepayments as cr where cr.paymentstatus="p" and (cr.paymentdate between "'.$sdate.'" and "'.$edate.'")'.$where."order by cast(receiptno as unsigned)");
        if ($query0->num_rows()>0) {
           // $courseArr["count"] = $query0->num_rows();
            //$courseArr["count"] = intval($courseArr["count"] === 0)?$courseArr["count"]:(intval($courseArr["count"])+1);
            $row = $query0->result_array();
            if ($row) {
               $courseArr['billno'] = $row[0]['receiptno']." to ".$row[count($row)-1]['receiptno'];
               $r1 =  intval($row[count($row)-1]['receiptno']);
               $r2 = intval($row[0]['receiptno']);
               $r3 = intval($r1)-intval($r2);
               $courseArr["count"] = ++$r3;
            }
        }
    
        
        
        
        $query1 = $this-> db -> query("select cr.courseid,sum(cr.discount) as discount,cr.courseid,sum(cr.amount) as amount,sum(cr.total) as total,sum(cr.paymentamount) as paymentamount,cr.paymentmode,c.coursename,sp.description from bscp_feepayments as cr,bscp_student_payments as sp,admin_course as c where cr.courseid=sp.courseid and cr.paymentstatus='p' and cr.courseid=c.ide and cr.stupayid=sp.id "
                . "and (cr.paymentdate between '".$sdate."' and '".$edate."')".$where."and (sp.description like '%Tuition Fee%' or sp.description like '%Registration%' or sp.description like '%Caution Deposit%') GROUP by cr.courseid,cr.paymentmode,sp.description");
        $row1 = $query1->result_array();
        if ($row1) {
            for($i = 0;$i<count($row1);$i++) {
                    $cid = $row1[$i]['courseid'];
                    $cname = $row1[$i]['coursename'];
                    $description = $row1[$i]['description'];
                    $payamount = $row1[$i]['amount'];
                    $discount = $row1[$i]['discount'];
                    $payamount = floatval($payamount)-floatval($discount);
                    $paid = $row1[$i]['paymentamount'];
                    $total = $row1[$i]['total'];
                    $paymode = $row1[$i]['paymentmode'];
                    $paymode = ($paymode === "")?'cash':$paymode;
                    $paymode = strtolower($paymode);
                    if(strpos($description, 'Registration') !== false){
                        $description = "Reg Fee";
                    } else if(strpos($description, 'Tuition') !== false){
                        $description = "Tuition Fee";
                    }else if(strpos($description, 'Caution') !== false){
                        $description = "CD";
                    }
                    
                    if(!array_key_exists($cid, $courseArr)){
                        $courseArr[$cid]=Array();
                        
                    } 
                    
                    if(!in_array($cname, $courseArr[$cid])){
                        $courseArr[$cid]['cname'] = $cname;                       
                    } 

                    if(!array_key_exists($description, $courseArr[$cid])){
                        $courseArr[$cid][$description] = 0;  
                    } 
                    
                    if(!array_key_exists($paymode, $courseArr[$cid])){
                        $courseArr[$cid][$paymode] = 0;  
                    }
                    
                    if(!array_key_exists('total', $courseArr[$cid])){
                        $courseArr[$cid]['total'] = 0;  
                    }
                    
                    if(!array_key_exists('paid', $courseArr[$cid])){
                        $courseArr[$cid]['paid'] = 0;  
                    }

                    
                    $courseArr[$cid][$description] = floatVal($courseArr[$cid][$description] )+floatval($payamount);
                    $courseArr[$cid][$paymode] = floatVal($courseArr[$cid][$paymode] )+floatval($paid);
                    $courseArr[$cid]['total'] = floatVal($courseArr[$cid]['total'] )+floatval($total);
                    $courseArr[$cid]['paid'] = floatVal($courseArr[$cid]['paid'] )+floatval($paid);
                   
            }
        }
		
	return $courseArr;	
    }
    
    
    public function CourseWiseAdmittedList($sdate,$edate,$center) {
        
         $where = ""; $courseArr = Array();
        if(($center !== "") && ($center !== "All")) { $where = " and center='".$center."' ";}
        
          $query1 = $this-> db -> query("select cr.ide,c.coursename,cr.center,s.studid,s.sname,s.contact,sp.whatsappno,s.email,aq.name,cr.stream,cr.xii_stream,"
                  . "cr.total from bscp_courserequest as cr,bscp_student as s,admin_course as c,bscp_studentprofile as sp,"
                  . "admin_qualification as aq where cr.courseid=c.ide and cr.studentid=s.id and cr.studentid=sp.stuid and cr.qualificationid=aq.id and cr.approved='y'"
                . "and (cr.requested_at between '".$sdate."' and '".$edate."')".$where);
       
        $row1 = $query1->result_array();
        if ($row1) {
            for($i = 0;$i<count($row1);$i++) {
                $ide = $row1[$i]['ide'];
                $courseArr[$ide]['coursename'] = $row1[$i]['coursename'];
                $courseArr[$ide]['center'] = $row1[$i]['center'];
                $courseArr[$ide]['studid'] = $row1[$i]['studid'];
                $courseArr[$ide]['sname'] = $row1[$i]['sname'];
                $courseArr[$ide]['contact'] = $row1[$i]['contact'];
                $courseArr[$ide]['whatsappno'] = $row1[$i]['whatsappno'];
                $courseArr[$ide]['email'] = $row1[$i]['email'];
                $courseArr[$ide]['name'] = $row1[$i]['name'];
                $courseArr[$ide]['stream'] = ($row1[$i]['xii_stream'] !== "")? $row1[$i]['xii_stream']:$row1[$i]['stream'];
                //$courseArr[$ide]['total'] = round($row1[$i]['total']);
                
                $query2 = $this-> db -> query("select sum(total) as total,DATE_FORMAT(paymentdate,'%d-%m-%Y %h:%i %p') as pdate from bscp_feepayments where requestid='".$row1[$i]['ide']."' and paymentstatus='p'");
                $row2 = $query2->result_array();
                if ($row2) {
                $courseArr[$ide]['remitted'] = $row2[0]['total'];
                $courseArr[$ide]['pdate'] = $row2[0]['pdate'];
                } else {
                    $courseArr[$ide]['remitted'] = '0';
                    $courseArr[$ide]['pdate'] = '';
                }
                
                $query3 = $this-> db -> query("select sum(total) as total from bscp_student_payments where requestid='".$row1[$i]['ide']."'");
                $row3 = $query3->result_array();
                if ($row3) {
                $courseArr[$ide]['total'] = $row3[0]['total'];
               
                } else {
                    $courseArr[$ide]['total'] = '0';
                }
                
                $query4 = $this-> db -> query("select mcode from bscp_signup where mobile='".$row1[$i]['contact']."'");
                $row4 = $query4->result_array();
                if ($row4) {
                $courseArr[$ide]['mcode'] = $row4[0]['mcode'];
               
                } else {
                    $courseArr[$ide]['mcode'] = '';
                }
            }
        }
        
        return $courseArr;
    }
    
    
       public function DailyCourseAppliedList($sdate,$edate,$center) {
        
         $where = ""; $courseArr = Array();
         $statusArr=array("y"=>'Approved',"n"=>'Approved',"w"=>'Waitig List',"n"=>'Applied - NQ',
             "q"=>'Applied',"d"=>'Denied'); 
        if(($center !== "") && ($center !== "All")) { $where = " and center='".$center."' ";}
        
          $query1 = $this-> db -> query("select cr.approved,cr.ide,DATE_FORMAT(cr.requested_at,'%d-%m-%Y %h:%i %p') as rdate,c.coursename,cr.center,s.studid,s.sname,s.contact,s.email,aq.name,cr.stream,cr.xii_stream "
                  . "from bscp_courserequest as cr,bscp_student as s,admin_course as c,"
                  . "admin_qualification as aq where cr.courseid=c.ide and cr.studentid=s.id and cr.qualificationid=aq.id "
                . "and (cr.requested_at between '".$sdate."' and '".$edate."')".$where);
       
        $row1 = $query1->result_array();
        if ($row1) {
            for($i = 0;$i<count($row1);$i++) {
                $ide = $row1[$i]['ide'];
                $courseArr[$ide]['coursename'] = $row1[$i]['coursename'];
                $courseArr[$ide]['center'] = $row1[$i]['center'];
                $courseArr[$ide]['studid'] = $row1[$i]['studid'];
                $courseArr[$ide]['sname'] = $row1[$i]['sname'];
                $courseArr[$ide]['contact'] = $row1[$i]['contact'];
                $status = (array_key_exists($row1[$i]['approved'], $statusArr))?$statusArr[$row1[$i]['approved']]:"NA";
                $courseArr[$ide]['status'] = $status;
                $courseArr[$ide]['email'] = $row1[$i]['email'];
                $courseArr[$ide]['qualification'] = $row1[$i]['name'];
                $courseArr[$ide]['stream'] = ($row1[$i]['xii_stream'] !== "")? $row1[$i]['xii_stream']:$row1[$i]['stream'];
                $courseArr[$ide]['rdate'] = $row1[$i]['rdate'];
               
                $query4 = $this-> db -> query("select mcode from bscp_signup where mobile='".$row1[$i]['contact']."'");
                $row4 = $query4->result_array();
                if ($row4) {
                $courseArr[$ide]['mcode'] = $row4[0]['mcode'];
               
                } else {
                    $courseArr[$ide]['mcode'] = '';
                }
                
            }
        }
        
        return $courseArr;
    }
    
    
     public function DailySignupList($sdate,$edate) {
        
         $courseArr = Array();
                 
          $query1 = $this-> db -> query("select s.studid,s.sname,s.contact,s.email,aq.name "
                  . "from bscp_student as s,admin_qualification as aq where s.qualification=aq.id "
                . "and (s.created_at between '".$sdate."' and '".$edate."')");
       
        $row1 = $query1->result_array();
        if ($row1) {
            for($i = 0;$i<count($row1);$i++) {
                $courseArr[$i]['studid'] = $row1[$i]['studid'];
                $courseArr[$i]['sname'] = $row1[$i]['sname'];
                $courseArr[$i]['contact'] = $row1[$i]['contact'];
                $courseArr[$i]['email'] = $row1[$i]['email'];
                $courseArr[$i]['qualification'] = $row1[$i]['name'];
                
                $query4 = $this-> db -> query("select mcode from bscp_signup where mobile='".$row1[$i]['contact']."'");
                $row4 = $query4->result_array();
                if ($row4) {
                $courseArr[$i]['mcode'] = $row4[0]['mcode'];
               
                } else {
                    $courseArr[$i]['mcode'] = '';
                }
                
            }
        }
        
        return $courseArr;
    }
    
    public function DailyBillList($sdate,$edate,$center) {
        
         $courseArr = Array();
                 
          if(($center !== "") && ($center !== "All")) { $where = " and a.center='".$center."' ";}        
          $query1 = $this-> db -> query('SELECT a.courseid,'
                  . ' a.paymentmode, DATE_FORMAT(a.paymentdate, "%d-%m-%Y %h:%i %p") as paydate,'
                  . ' a.receiptno, a.studentid , a.courseid , a.paymentdate , b.studid'
                  . ', a.challanno, b.sname , c.coursename, a.center, sum(a.total) as paid FROM bscp_feepayments as a'
                  . ',bscp_student as b, admin_course as c where b.id=a.studentid and c.ide=a.courseid and a.paymentstatus = "p" '
                  . 'and (a.paymentdate between "'.$sdate.'" and "'.$edate.'") '.$where.'GROUP BY `challanno`, `studentid`');
       
        $row1 = $query1->result_array();
        if ($row1) {
            for($i = 0;$i<count($row1);$i++) {
                $courseArr[$i]['studid'] = $row1[$i]['studid'];
                $courseArr[$i]['challanno'] = $row1[$i]['challanno'];
                $courseArr[$i]['paydate'] = $row1[$i]['paydate'];
                $courseArr[$i]['receiptno'] = $row1[$i]['receiptno'];
                $courseArr[$i]['sname'] = $row1[$i]['sname'];
                $courseArr[$i]['coursename'] = $row1[$i]['coursename'];
                $courseArr[$i]['center'] = $row1[$i]['center'];
                $courseArr[$i]['paid'] = $row1[$i]['paid'];
                $courseArr[$i]['paymentmode'] = $row1[$i]['paymentmode'];
                
            }
        }
        
        return $courseArr;
    }
    
    public function UnpaidList($sdate,$edate,$center) {
        
         $courseArr = Array();
          if(($center !== "") && ($center !== "All")) { $where = " and a.center='".$center."' ";}               
         $query1 = $this-> db -> query('SELECT a.studentid, a.courseid,a.created_at, b.studid, a.challanno, a.requestid, b.sname, c.coursename, a.center, sum(a.total) as unpaid FROM bscp_feepayments as a,'
         . 'bscp_student as b, admin_course as c where  b.id=a.studentid and c.ide=a.courseid and (a.paymentstatus="" and a.amount != "0") and '
                 . '(a.created_at between "'.$sdate.'" and "'.$edate.'") '.$where.'GROUP BY a.challanno, a.studentid, a.center,a.courseid');
     
       
        $row1 = $query1->result_array();
        if ($row1) {
            for($i = 0;$i<count($row1);$i++) {
                $courseArr[$i]['studid'] = $row1[$i]['studid'];
                $courseArr[$i]['challanno'] = $row1[$i]['challanno'];
                $courseArr[$i]['sname'] = $row1[$i]['sname'];
                $courseArr[$i]['coursename'] = $row1[$i]['coursename'];
                $courseArr[$i]['center'] = $row1[$i]['center'];
                $courseArr[$i]['unpaid'] = $row1[$i]['unpaid'];
                
                
            }
        }
        
        return $courseArr;
    }
    
    public function FirstTimeStudentPaidList($sdate,$edate,$center) {
        
        $courseArr = Array();
                 
          if(($center !== "") && ($center !== "All")) { $where = " and a.center='".$center."' ";}        
          $query1 = $this-> db -> query('SELECT a.courseid,'
                  . ' a.paymentmode, DATE_FORMAT(a.paymentdate, "%d-%m-%Y %h:%i %p") as paydate,'
                  . ' a.receiptno, a.studentid , a.courseid , a.paymentdate , b.studid,'
                  . ' b.sname ,b.contact ,b.email ,b.city , c.coursename, a.center, sum(a.total) as paid FROM bscp_feepayments as a'
                  . ',bscp_student as b, admin_course as c where b.id=a.studentid and c.ide=a.courseid and a.paymentstatus = "p" '
                  . 'and (a.paymentdate between "'.$sdate.'" and "'.$edate.'") '.$where.'GROUP BY `challanno`, `studentid`');
       
        $row1 = $query1->result_array();
        if ($row1) {
            $j =1;
            for($i = 0;$i<count($row1);$i++) {
                
                $query1 = $this-> db -> query('select requestid from bscp_feepayments as a , admin_course as c where c.ide=a.courseid and c.screentest != "1" and a.studentid="'.$row1[$i]['studentid'].'" and a.paymentdate < "'.$sdate.'" and a.paymentstatus="p"');
                if($query1->num_rows() > 0){
                    
                    
                } else {
                    
                    $query2 = $this-> db -> query('select sp.*,s.mcode from bscp_studentprofile as sp,bscp_signup as s where s.mobile="'.$row1[$i]['contact'].'" and stuid="'.$row1[$i]['studentid'].'"');
                    $row2 = $query2->result_array();
                    if($row2) {
                        $courseArr[$j]['guardianname'] = $row2[0]['guardianname'];$courseArr[$j]['gender'] = $row2[0]['gender'];
                        $courseArr[$j]['dob'] = $row2[0]['dob'];$courseArr[$j]['fathername'] = $row2[0]['fathername'];
                        $courseArr[$j]['fatheroccupation'] = $row2[0]['fatheroccupation'];$courseArr[$j]['fatheremail'] = $row2[0]['fatheremail'];
                        $courseArr[$j]['fathercode'] = $row2[0]['fathercode'];$courseArr[$j]['fatherphone'] = $row2[0]['fatherphone'];
                        $courseArr[$j]['mothername'] = $row2[0]['mothername'];$courseArr[$j]['motheroccupation'] = $row2[0]['motheroccupation'];
                        $courseArr[$j]['motheremail'] = $row2[0]['motheremail'];$courseArr[$j]['mothercode'] = $row2[0]['mothercode'];
                        $courseArr[$j]['motherphone'] = $row2[0]['motherphone'];$courseArr[$j]['communicationcontact'] = $row2[0]['communicationcontact'];
                        $courseArr[$j]['nationality'] = $row2[0]['nationality'];$courseArr[$j]['category'] = $row2[0]['category'];
                        $courseArr[$j]['bloodgroup'] = $row2[0]['bloodgroup'];$courseArr[$j]['classstudy'] = $row2[0]['classstudy'];
                        $courseArr[$j]['stream'] = $row2[0]['stream'];$courseArr[$j]['schoolcollegename'] = $row2[0]['schoolcollegename'];
                        $courseArr[$j]['eduaddress'] = $row2[0]['eduaddress'];$courseArr[$j]['edulandmark'] = $row2[0]['edulandmark'];
                        $courseArr[$j]['edudistrict'] = $row2[0]['edudistrict'];$courseArr[$j]['edustate'] = $row2[0]['edustate'];
                        $courseArr[$j]['edupost'] = $row2[0]['edupost'];$courseArr[$j]['edupincode'] = $row2[0]['edupincode'];
                        $courseArr[$j]['educountry'] = $row2[0]['educountry'];$courseArr[$j]['examboard'] = $row2[0]['examboard'];
                        $courseArr[$j]['examclass'] = $row2[0]['examclass'];$courseArr[$j]['preferredsubject'] = $row2[0]['preferredsubject'];
                        $courseArr[$j]['eligiblescholar'] = $row2[0]['eligiblescholar'];$courseArr[$j]['mocktype'] = $row2[0]['mocktype'];
                        $courseArr[$j]['rollno'] = $row2[0]['rollno'];$courseArr[$j]['housenameno'] = $row2[0]['housenameno'];
                        $courseArr[$j]['landmark'] = $row2[0]['landmark'];$courseArr[$j]['contactaddress'] = $row2[0]['contactaddress'];
                        $courseArr[$j]['contactcountry'] = $row2[0]['contactcountry'];$courseArr[$j]['contactstate'] = $row2[0]['contactstate'];
                        $courseArr[$j]['contactdistrict'] = $row2[0]['contactdistrict'];$courseArr[$j]['wacode'] = $row2[0]['wacode'];
                        $courseArr[$j]['contactpost'] = $row2[0]['contactpost'];$courseArr[$j]['whatsappno'] = $row2[0]['whatsappno'];
                        $courseArr[$j]['contactpincode'] = $row2[0]['contactpincode'];$courseArr[$j]['accountholdername'] = $row2[0]['accountholdername'];
                        $courseArr[$j]['bankname'] = $row2[0]['bankname'];$courseArr[$j]['branch'] = $row2[0]['branch'];
                        $courseArr[$j]['ifsccode'] = $row2[0]['ifsccode'];$courseArr[$j]['bankaccountno'] = $row2[0]['bankaccountno'];
                        $courseArr[$j]['aadharnumber'] = $row2[0]['aadharnumber'];$courseArr[$j]['profilepercent'] = $row2[0]['profilepercent'];
                        $courseArr[$j]['mcode'] = $row2[0]['mcode'];
                    }
                    $courseArr[$j]['studid'] = $row1[$i]['studid'];
                    $courseArr[$j]['challanno'] = $row1[$i]['challanno'];
                    $courseArr[$j]['paydate'] = $row1[$i]['paydate'];
                    $courseArr[$j]['receiptno'] = $row1[$i]['receiptno'];
                    $courseArr[$j]['sname'] = $row1[$i]['sname'];
                    $courseArr[$j]['contact'] = $row1[$i]['contact'];
                    $courseArr[$j]['email'] = $row1[$i]['email'];
                    $courseArr[$j]['city'] = $row1[$i]['city'];
                    $courseArr[$j]['coursename'] = $row1[$i]['coursename'];
                    $courseArr[$j]['center'] = $row1[$i]['center'];
                    $courseArr[$j]['paid'] = $row1[$i]['paid'];
                    $courseArr[$j]['paymentmode'] = $row1[$i]['paymentmode'];
                    $j++;
                }
                
            }
        }
        
        return $courseArr;
    }
    
    
     public function RefundBillList($sdate,$edate,$center) {
        
         $courseArr = Array();
          $reason['scholarship'] = "Scholarship";
                $reason['faid'] = "Financial Aid";
                $reason['discontinue'] = "Discontinue";
                $reason['berror'] = "Billing Error";
                $reason['others'] = "Others";
                 
          if(($center !== "") && ($center !== "All")) { $where = " and a.center='".$center."' ";}        
          $query1 = $this-> db -> query('SELECT DATE_FORMAT(d.created_At, "%d-%m-%Y %h:%i %p") as appdate,d.appno,a.receiptno,'
                  . ' b.studid,b.sname,c.coursename,a.center,sum(a.remitted) as remitted,sum(a.refundamount) as refundamount,a.paydescription,a.reason FROM bscp_refund as a'
                  . ',bscp_student as b, admin_course as c,bscp_refundapplication as d where b.id=a.studentid and c.ide=a.courseid and d.id = a.refundappid '
                  . 'and (a.created_at between "'.$sdate.'" and "'.$edate.'") '.$where.'GROUP BY `receiptno`');
       
        $row1 = $query1->result_array();
        if ($row1) {
            for($i = 0;$i<count($row1);$i++) {
                $courseArr[$i]['studid'] = $row1[$i]['studid'];
                $courseArr[$i]['appno'] = $row1[$i]['appno'];
                $courseArr[$i]['appdate'] = $row1[$i]['appdate'];
                $courseArr[$i]['remitted'] = $row1[$i]['remitted'];
                $courseArr[$i]['sname'] = $row1[$i]['sname'];
                $courseArr[$i]['coursename'] = $row1[$i]['coursename'];
                $courseArr[$i]['center'] = $row1[$i]['center'];
                $courseArr[$i]['paydescription'] = $row1[$i]['paydescription'];
                $courseArr[$i]['refundamount'] = $row1[$i]['refundamount'];
                 $courseArr[$i]['reason'] =  $reason[$row1[$i]['reason']];
                 $courseArr[$i]['receiptno'] = $row1[$i]['receiptno'];
                
            }
        }
        
        return $courseArr;
    }
    
        
    public function BulkPrintList($sdate,$edate,$center) {
        
         $courseArr = Array(); $where = '';
                 
          if(($center !== "") && ($center !== "All")) { $where = " and center='".$center."'";}        
          $query1 = $this-> db -> query('SELECT a.studentid,a.requestid, a.studentid , a.challanno,s.studid,s.sname FROM bscp_feepayments as a,bscp_student as s where s.id=a.studentid and a.paymentstatus = "p" and (a.paymentdate between "'.$sdate.'" and "'.$edate.'") '.$where.' GROUP BY `challanno`, `studentid`');
       
        $row1 = $query1->result_array();
        if ($row1) {
            for($i = 0;$i<count($row1);$i++) {
                
                $courseArr[$i]['requestid'] = $row1[$i]['requestid'];
                $courseArr[$i]['studentid'] = $row1[$i]['studentid'];
                $courseArr[$i]['challanno'] = $row1[$i]['challanno'];
                $courseArr[$i]['studid'] = $row1[$i]['studid'];
                 $courseArr[$i]['sname'] = $row1[$i]['sname'];
                 $courseArr[$i]['studentid'] = $row1[$i]['studentid'];
              
            }
        }
        
        return $courseArr;
    }
    
    
    public function BulkPrintView($feesmaster,$feepaybill,$studid,$pname) {
        
        
         $htmlFinal = ''; $html = ''; 
         
         $tablepay = $tablepaynow = $ide = "";
	$sno = $psno = 1;

	$grandtotal = $grandtotalnow = $totalfee = $paidfee = $duefee = $discountfee = $discount = 0;

	$coursename = $center = $paymentmode = $paymentdate = $receiptno = "";
	$checkdiscount = false;

	foreach($feesmaster as $key=>$feemaster){
		
	foreach($feepaybill['feebilldetails'] as $paylist){
		
		if($feemaster['description'] == $paylist['description']){

		$amount = $paylist['amount'];
		$paymentamount = $paylist['paymentamount'];
		$total = $paylist['total'];
		$taxable = $paylist['taxable'];
		$paymentmode = $paylist['paymentmode'];
		$paymentdate = $paylist['paymentdate'];
		$receiptno = $paylist['receiptno'];
		$kf = $paylist['kf'];
		$cov = $paylist['cov'];
		$sac = 999293;
		
		if($paymentamount==0) continue;	
		
		//$thtaxable = '<th scope="col" width="10%">Taxable</th>';
		//$thnontaxable = '<th scope="col" width="10%">Non Taxable</th>';

		$discount = $paylist['discount'];
		$discountamt = 0;$thdiscount = "";$tddiscount = ""; $thtax = ""; $tdtax = "";
		$taxamt = 0;
		$colspan=11;
		
		$tax = $paylist['tax'];
		
		/*$amount1 = round($amount - ($amount * ($tax+$kf)/ (100+$tax+$kf)));
		if($amount==$amount1) $amount = $amount; else $amount = $amount1;*/
		
				
		if(intval($discount)>0) {
							
			$discountamt = $discount;
			//$tddiscount = '<td width="10%">'.$discountamt.'</td>';

			$amount = $amount - $discount;

			$checkdiscount = true;

		}else{
			//$tddiscount = '<td>[DISCOUNT]</td>';
		}
		
		if($tax=="0" || $tax=="NA"){
			
			$tdnontaxable = $amount;
		}else{
			$tdnontaxable = 0;
		}
		
		if($tax!="0" && $tax!="NA"){ 
		
			$tdtaxable = $amount;				

			$taxgst = $tax/2;
			if(intval($tax)>0) $taxamt = $amount * ($tax/100);
			$taxamtgst = $taxamt/2;
			$taxamtgst = number_format($taxamtgst,2);
			
			//$colspan +=4;
			
		} else {
			$tdtaxable = 0;
			$taxgst = $taxamtgst = "NA";
		}
		
		$thtax = '<th scope="col" colspan="2" width="19%"><span class="thtax">CGST</span> <span class="thtaxvalue"><span>Rate %</span> <span>Amount</span></span></th>
			  <th scope="col" colspan="2" width="19%"><span class="thtax">SGST</span> <span class="thtaxvalue"><span>Rate %</span> <span>Amount</span></span></th>';

		$tdtax = '<td width="8%">'.$taxgst.'</td>
				  <td width="8%">'.$taxamtgst.'</td>
				  <td width="8%">'.$taxgst.'</td>
				  <td width="8%">'.$taxamtgst.'</td>';

		$nontaxvalue = $amount;
		$taxvalue = $amount + $taxamt;
		
		
		$kfamt = $amount * ($kf/100);
				

		$grandtotal += $total;

		$tablepay .= '<tr>
					  <th scope="row" width="7%">'.$sno.'.</th>
					  <td width="15%"><strong>'.$paylist['description'].'</strong></td>
					  <td width="11%">'.$sac.'</td>
					  <td width="11%">'.$tdnontaxable.'</td>
					  <td width="11%">'.$tdtaxable.'</td>
					  '.$tddiscount.'
					  '.$tdtax.'
					  <td width="8%">'.$kf.'</td>
					  <td width="8%">'.$kfamt.'</td>
					  <td width="10%">'.number_format($total,2).'</td>
					</tr>';

		$sno++;
	}
		
	}
		
	}
         
         $html = '<div class="row feebill">
								
		<div class="card mb-2 p-4">
		
			<div class="row">
					
			<div class="col-md-6">
			
				<img src="'.base_url().'css/img/brilliant-logo.png" alt="Brilliant Pala Logo" class="mb-2" />
				
				<div class="mt-3"></div>
				
				<p>Receipt No. : <strong>'.$receiptno.'</strong></p>
				<p>Dated : <strong>'.date("d-m-Y h:i A",strtotime($paymentdate)).'</strong></p>
									
			</div>
			<div class="col-md-6 text-right">
				<h3>Brilliant Study Centre, Pala.</h3>
				<p>GSTIN: <strong>32AAEFB8385KIZ7</strong></p>
				<p>Mutholy, Puliyannoor PO, 686-573.</p>
				<p>Phone: 04822 206 100</p>
				<p>Email: admissions@brilliantpala.org</p>
			</div>
			
		
		</div>
			
			<div class="hr mt-1 mb-2"></div>
			
		<div class="row">
			
			<div class="col-md-6">
			
				<p>Student Id: <strong>'.$studid.'</strong></p>
				<p class="mb-0">Student: <strong>'.strtoupper($pname).'</strong></p>';
				
				if(!empty($feepaybill['studentdetails'])){
				
				$html .= '<div class="row">
					<div class="col-md-1"></div>
					<div class="col-md-6">
						<p>'.$feepaybill['studentdetails'][0]['housenameno']." ".$feepaybill['studentdetails'][0]['contactaddress'].", ".$feepaybill['studentdetails'][0]['contactpost'].", ".$feepaybill['studentdetails'][0]['contactdistrict'].", ".$feepaybill['studentdetails'][0]['contactstate'].", ".$feepaybill['studentdetails'][0]['contactcountry']." ".$feepaybill['studentdetails'][0]['contactpincode'].'.'.'</p>
					</div>
				</div>';
				
				 }
				
			$html .='</div>
			<div class="col-md-6 text-right">
				
				<p>Course:  <strong>['.$feepaybill['course'][0]['coursename'].','.$feepaybill['course'][0]['center'].']</strong></p>
				
			</div>
			
		</div>	
		
		<div class="row mb-2">
		
		 <table class="table">
              <thead>
                <tr>
                  <th scope="col" width="5%">Sl. no.</th>
                  <th scope="col" width="18%">Description</th>
                  <th scope="col" width="10%">SAC</th>
                  <th scope="col" width="10%">Non Taxable Value</th>
                  <th scope="col" width="10%">Taxable Value</th>'.$thdiscount.$thtax.'<th scope="col" width="8%">CESS KF %</th>
                  <th scope="col" width="10%">CESS KF Amount</th>
                  <th scope="col" width="14%">Total</th>
                </tr>
              </thead>
              <tbody>'.$tablepay.'               
                <tr>
                  <td colspan="'.$colspan.'" class="totalamt">Grand total</td>
                  <td class="totalfee">'.number_format($grandtotal,2).'</td>
                </tr>
              </tbody>
            </table>
            
			</div>
          
           
			<p class="mb-2">Total Amount: <strong>Rs.'.number_format($grandtotal).'/- '.$this->getIndianCurrency($grandtotal).' Only)</strong></p>

			<p class="mb-2">Payment Mode: <strong>'.strtoupper($paymentmode).'</strong></p>

			<p class="mb-2">Remitted On: <strong>'.date("d-m-Y",strtotime($paymentdate)).'</strong></p>
            
            
            <div class="row d-flex align-items-end mt-3 mb-0">
			
			<div class="col-md-6">
			
				
			</div>
			<div class="col-md-6 text-right">
				
				<h4>Computer generated receipt</h4>
				
			</div>
			
		</div>

            
			</div>
			
		</div>
		
		<div class="mt-0 mb-2 w-100" style="border-bottom: 1px dashed #dee2e6!important;"></div>';
         
        // $htmlClone = '<div class="billclone">'.$html.'</div>';
         
         $htmlFinal = $html;
        
        return $htmlFinal;
    }
    
    public function getIndianCurrency(float $number)
    {
        $decimal = round($number - ($no = floor($number)), 2) * 100;
        $hundred = null;
        $digits_length = strlen($no);
        $i = 0;
        $str = array();
        $words = array(0 => '', 1 => 'one', 2 => 'two',
            3 => 'three', 4 => 'four', 5 => 'five', 6 => 'six',
            7 => 'seven', 8 => 'eight', 9 => 'nine',
            10 => 'ten', 11 => 'eleven', 12 => 'twelve',
            13 => 'thirteen', 14 => 'fourteen', 15 => 'fifteen',
            16 => 'sixteen', 17 => 'seventeen', 18 => 'eighteen',
            19 => 'nineteen', 20 => 'twenty', 30 => 'thirty',
            40 => 'forty', 50 => 'fifty', 60 => 'sixty',
            70 => 'seventy', 80 => 'eighty', 90 => 'ninety');
        $digits = array('', 'hundred','thousand','lakh', 'crore');
        while( $i < $digits_length ) {
            $divider = ($i == 2) ? 10 : 100;
            $number = floor($no % $divider);
            $no = floor($no / $divider);
            $i += $divider == 10 ? 1 : 2;
            if ($number) {
                $plural = (($counter = count($str)) && $number > 9) ? 's' : null;
                $hundred = ($counter == 1 && $str[0]) ? ' and ' : null;
                //$str [] = ($number < 21) ? $words[$number].' '. $digits[$counter]. $plural.' '.$hundred:$words[floor($number / 10) * 10].' '.$words[$number % 10]. ' '.$digits[$counter].$plural.' '.$hundred;
                            $str [] = ($number < 21) ? $words[$number].' '. $digits[$counter].' '.$hundred:$words[floor($number / 10) * 10].' '.$words[$number % 10]. ' '.$digits[$counter].' '.$hundred;
            } else $str[] = null;
        }
        $Rupees = implode('', array_reverse($str));
        $paise = ($decimal > 0) ? "." . ($words[$decimal / 10] . " " . $words[$decimal % 10]) . ' Paise' : '';
        //return ($Rupees ? $Rupees . 'Rupees ' : '') . $paise;
            return (ucwords($Rupees) ? ucwords($Rupees) : '') . ucwords($paise);
    }
   
}

=======
<?php

Class Reports_Model extends CI_Model {
    
     public function __construct() {
        
       $this->load->library('Datatables');
  
    }

    public function BillGeneratonSummary($sdate,$edate,$center) {
        
        $arr = Array();$arr["count"] = 0;$courseArr = Array();
        
                
        $where = "";
        if(($center !== "") && ($center !== "All")) { $where = " and center='".$center."' ";}
        
        $query0 = $this-> db -> query('select distinct cr.receiptno from bscp_feepayments as cr where cr.paymentstatus="p" and (cr.paymentdate between "'.$sdate.'" and "'.$edate.'")'.$where."order by cast(receiptno as unsigned)");
        if ($query0->num_rows()>0) {
           // $courseArr["count"] = $query0->num_rows();
            //$courseArr["count"] = intval($courseArr["count"] === 0)?$courseArr["count"]:(intval($courseArr["count"])+1);
            $row = $query0->result_array();
            if ($row) {
               $courseArr['billno'] = $row[0]['receiptno']." to ".$row[count($row)-1]['receiptno'];
               $r1 =  intval($row[count($row)-1]['receiptno']);
               $r2 = intval($row[0]['receiptno']);
               $r3 = intval($r1)-intval($r2);
               $courseArr["count"] = ++$r3;
            }
        }
    
        
        
        
        $query1 = $this-> db -> query("select cr.courseid,sum(cr.discount) as discount,cr.courseid,sum(cr.amount) as amount,sum(cr.total) as total,sum(cr.paymentamount) as paymentamount,cr.paymentmode,c.coursename,sp.description from bscp_feepayments as cr,bscp_student_payments as sp,admin_course as c where cr.courseid=sp.courseid and cr.paymentstatus='p' and cr.courseid=c.ide and cr.stupayid=sp.id "
                . "and (cr.paymentdate between '".$sdate."' and '".$edate."')".$where."and (sp.description like '%Tuition Fee%' or sp.description like '%Registration%' or sp.description like '%Caution Deposit%') GROUP by cr.courseid,cr.paymentmode,sp.description");
        $row1 = $query1->result_array();
        if ($row1) {
            for($i = 0;$i<count($row1);$i++) {
                    $cid = $row1[$i]['courseid'];
                    $cname = $row1[$i]['coursename'];
                    $description = $row1[$i]['description'];
                    $payamount = $row1[$i]['amount'];
                    $discount = $row1[$i]['discount'];
                    $payamount = floatval($payamount)-floatval($discount);
                    $paid = $row1[$i]['paymentamount'];
                    $total = $row1[$i]['total'];
                    $paymode = $row1[$i]['paymentmode'];
                    $paymode = ($paymode === "")?'cash':$paymode;
                    $paymode = strtolower($paymode);
                    if(strpos($description, 'Registration') !== false){
                        $description = "Reg Fee";
                    } else if(strpos($description, 'Tuition') !== false){
                        $description = "Tuition Fee";
                    }else if(strpos($description, 'Caution') !== false){
                        $description = "CD";
                    }
                    
                    if(!array_key_exists($cid, $courseArr)){
                        $courseArr[$cid]=Array();
                        
                    } 
                    
                    if(!in_array($cname, $courseArr[$cid])){
                        $courseArr[$cid]['cname'] = $cname;                       
                    } 

                    if(!array_key_exists($description, $courseArr[$cid])){
                        $courseArr[$cid][$description] = 0;  
                    } 
                    
                    if(!array_key_exists($paymode, $courseArr[$cid])){
                        $courseArr[$cid][$paymode] = 0;  
                    }
                    
                    if(!array_key_exists('total', $courseArr[$cid])){
                        $courseArr[$cid]['total'] = 0;  
                    }
                    
                    if(!array_key_exists('paid', $courseArr[$cid])){
                        $courseArr[$cid]['paid'] = 0;  
                    }

                    
                    $courseArr[$cid][$description] = floatVal($courseArr[$cid][$description] )+floatval($payamount);
                    $courseArr[$cid][$paymode] = floatVal($courseArr[$cid][$paymode] )+floatval($paid);
                    $courseArr[$cid]['total'] = floatVal($courseArr[$cid]['total'] )+floatval($total);
                    $courseArr[$cid]['paid'] = floatVal($courseArr[$cid]['paid'] )+floatval($paid);
                   
            }
        }
		
	return $courseArr;	
    }
    
    
    public function CourseWiseAdmittedList($sdate,$edate,$center) {
        
         $where = ""; $courseArr = Array();
        if(($center !== "") && ($center !== "All")) { $where = " and center='".$center."' ";}
        
          $query1 = $this-> db -> query("select cr.ide,c.coursename,cr.center,s.studid,s.sname,s.contact,sp.whatsappno,s.email,aq.name,cr.stream,cr.xii_stream,"
                  . "cr.total from bscp_courserequest as cr,bscp_student as s,admin_course as c,bscp_studentprofile as sp,"
                  . "admin_qualification as aq where cr.courseid=c.ide and cr.studentid=s.id and cr.studentid=sp.stuid and cr.qualificationid=aq.id and cr.approved='y'"
                . "and (cr.requested_at between '".$sdate."' and '".$edate."')".$where);
       
        $row1 = $query1->result_array();
        if ($row1) {
            for($i = 0;$i<count($row1);$i++) {
                $ide = $row1[$i]['ide'];
                $courseArr[$ide]['coursename'] = $row1[$i]['coursename'];
                $courseArr[$ide]['center'] = $row1[$i]['center'];
                $courseArr[$ide]['studid'] = $row1[$i]['studid'];
                $courseArr[$ide]['sname'] = $row1[$i]['sname'];
                $courseArr[$ide]['contact'] = $row1[$i]['contact'];
                $courseArr[$ide]['whatsappno'] = $row1[$i]['whatsappno'];
                $courseArr[$ide]['email'] = $row1[$i]['email'];
                $courseArr[$ide]['name'] = $row1[$i]['name'];
                $courseArr[$ide]['stream'] = ($row1[$i]['xii_stream'] !== "")? $row1[$i]['xii_stream']:$row1[$i]['stream'];
                //$courseArr[$ide]['total'] = round($row1[$i]['total']);
                
                $query2 = $this-> db -> query("select sum(total) as total,DATE_FORMAT(paymentdate,'%d-%m-%Y %h:%i %p') as pdate from bscp_feepayments where requestid='".$row1[$i]['ide']."' and paymentstatus='p'");
                $row2 = $query2->result_array();
                if ($row2) {
                $courseArr[$ide]['remitted'] = $row2[0]['total'];
                $courseArr[$ide]['pdate'] = $row2[0]['pdate'];
                } else {
                    $courseArr[$ide]['remitted'] = '0';
                    $courseArr[$ide]['pdate'] = '';
                }
                
                $query3 = $this-> db -> query("select sum(total) as total from bscp_student_payments where requestid='".$row1[$i]['ide']."'");
                $row3 = $query3->result_array();
                if ($row3) {
                $courseArr[$ide]['total'] = $row3[0]['total'];
               
                } else {
                    $courseArr[$ide]['total'] = '0';
                }
                
                $query4 = $this-> db -> query("select mcode from bscp_signup where mobile='".$row1[$i]['contact']."'");
                $row4 = $query4->result_array();
                if ($row4) {
                $courseArr[$ide]['mcode'] = $row4[0]['mcode'];
               
                } else {
                    $courseArr[$ide]['mcode'] = '';
                }
            }
        }
        
        return $courseArr;
    }
    
    
       public function DailyCourseAppliedList($sdate,$edate,$center) {
        
         $where = ""; $courseArr = Array();
         $statusArr=array("y"=>'Approved',"n"=>'Approved',"w"=>'Waitig List',"n"=>'Applied - NQ',
             "q"=>'Applied',"d"=>'Denied'); 
        if(($center !== "") && ($center !== "All")) { $where = " and center='".$center."' ";}
        
          $query1 = $this-> db -> query("select cr.approved,cr.ide,DATE_FORMAT(cr.requested_at,'%d-%m-%Y %h:%i %p') as rdate,c.coursename,cr.center,s.studid,s.sname,s.contact,s.email,aq.name,cr.stream,cr.xii_stream "
                  . "from bscp_courserequest as cr,bscp_student as s,admin_course as c,"
                  . "admin_qualification as aq where cr.courseid=c.ide and cr.studentid=s.id and cr.qualificationid=aq.id "
                . "and (cr.requested_at between '".$sdate."' and '".$edate."')".$where);
       
        $row1 = $query1->result_array();
        if ($row1) {
            for($i = 0;$i<count($row1);$i++) {
                $ide = $row1[$i]['ide'];
                $courseArr[$ide]['coursename'] = $row1[$i]['coursename'];
                $courseArr[$ide]['center'] = $row1[$i]['center'];
                $courseArr[$ide]['studid'] = $row1[$i]['studid'];
                $courseArr[$ide]['sname'] = $row1[$i]['sname'];
                $courseArr[$ide]['contact'] = $row1[$i]['contact'];
                $status = (array_key_exists($row1[$i]['approved'], $statusArr))?$statusArr[$row1[$i]['approved']]:"NA";
                $courseArr[$ide]['status'] = $status;
                $courseArr[$ide]['email'] = $row1[$i]['email'];
                $courseArr[$ide]['qualification'] = $row1[$i]['name'];
                $courseArr[$ide]['stream'] = ($row1[$i]['xii_stream'] !== "")? $row1[$i]['xii_stream']:$row1[$i]['stream'];
                $courseArr[$ide]['rdate'] = $row1[$i]['rdate'];
               
                $query4 = $this-> db -> query("select mcode from bscp_signup where mobile='".$row1[$i]['contact']."'");
                $row4 = $query4->result_array();
                if ($row4) {
                $courseArr[$ide]['mcode'] = $row4[0]['mcode'];
               
                } else {
                    $courseArr[$ide]['mcode'] = '';
                }
                
            }
        }
        
        return $courseArr;
    }
    
    
     public function DailySignupList($sdate,$edate) {
        
         $courseArr = Array();
                 
          $query1 = $this-> db -> query("select s.studid,s.sname,s.contact,s.email,aq.name "
                  . "from bscp_student as s,admin_qualification as aq where s.qualification=aq.id "
                . "and (s.created_at between '".$sdate."' and '".$edate."')");
       
        $row1 = $query1->result_array();
        if ($row1) {
            for($i = 0;$i<count($row1);$i++) {
                $courseArr[$i]['studid'] = $row1[$i]['studid'];
                $courseArr[$i]['sname'] = $row1[$i]['sname'];
                $courseArr[$i]['contact'] = $row1[$i]['contact'];
                $courseArr[$i]['email'] = $row1[$i]['email'];
                $courseArr[$i]['qualification'] = $row1[$i]['name'];
                
                $query4 = $this-> db -> query("select mcode from bscp_signup where mobile='".$row1[$i]['contact']."'");
                $row4 = $query4->result_array();
                if ($row4) {
                $courseArr[$i]['mcode'] = $row4[0]['mcode'];
               
                } else {
                    $courseArr[$i]['mcode'] = '';
                }
                
            }
        }
        
        return $courseArr;
    }
    
    public function DailyBillList($sdate,$edate,$center) {
        
         $courseArr = Array();
                 
          if(($center !== "") && ($center !== "All")) { $where = " and a.center='".$center."' ";}        
          $query1 = $this-> db -> query('SELECT a.courseid,'
                  . ' a.paymentmode, DATE_FORMAT(a.paymentdate, "%d-%m-%Y %h:%i %p") as paydate,'
                  . ' a.receiptno, a.studentid , a.courseid , a.paymentdate , b.studid'
                  . ', a.challanno, b.sname , c.coursename, a.center, sum(a.total) as paid FROM bscp_feepayments as a'
                  . ',bscp_student as b, admin_course as c where b.id=a.studentid and c.ide=a.courseid and a.paymentstatus = "p" '
                  . 'and (a.paymentdate between "'.$sdate.'" and "'.$edate.'") '.$where.'GROUP BY `challanno`, `studentid`');
       
        $row1 = $query1->result_array();
        if ($row1) {
            for($i = 0;$i<count($row1);$i++) {
                $courseArr[$i]['studid'] = $row1[$i]['studid'];
                $courseArr[$i]['challanno'] = $row1[$i]['challanno'];
                $courseArr[$i]['paydate'] = $row1[$i]['paydate'];
                $courseArr[$i]['receiptno'] = $row1[$i]['receiptno'];
                $courseArr[$i]['sname'] = $row1[$i]['sname'];
                $courseArr[$i]['coursename'] = $row1[$i]['coursename'];
                $courseArr[$i]['center'] = $row1[$i]['center'];
                $courseArr[$i]['paid'] = $row1[$i]['paid'];
                $courseArr[$i]['paymentmode'] = $row1[$i]['paymentmode'];
                
            }
        }
        
        return $courseArr;
    }
    
    public function UnpaidList($sdate,$edate,$center) {
        
         $courseArr = Array();
          if(($center !== "") && ($center !== "All")) { $where = " and a.center='".$center."' ";}               
         $query1 = $this-> db -> query('SELECT a.studentid, a.courseid,a.created_at, b.studid, a.challanno, a.requestid, b.sname, c.coursename, a.center, sum(a.total) as unpaid FROM bscp_feepayments as a,'
         . 'bscp_student as b, admin_course as c where  b.id=a.studentid and c.ide=a.courseid and (a.paymentstatus="" and a.amount != "0") and '
                 . '(a.created_at between "'.$sdate.'" and "'.$edate.'") '.$where.'GROUP BY a.challanno, a.studentid, a.center,a.courseid');
     
       
        $row1 = $query1->result_array();
        if ($row1) {
            for($i = 0;$i<count($row1);$i++) {
                $courseArr[$i]['studid'] = $row1[$i]['studid'];
                $courseArr[$i]['challanno'] = $row1[$i]['challanno'];
                $courseArr[$i]['sname'] = $row1[$i]['sname'];
                $courseArr[$i]['coursename'] = $row1[$i]['coursename'];
                $courseArr[$i]['center'] = $row1[$i]['center'];
                $courseArr[$i]['unpaid'] = $row1[$i]['unpaid'];
                
                
            }
        }
        
        return $courseArr;
    }
    
    public function FirstTimeStudentPaidList($sdate,$edate,$center) {
        
        $courseArr = Array();
                 
          if(($center !== "") && ($center !== "All")) { $where = " and a.center='".$center."' ";}        
          $query1 = $this-> db -> query('SELECT a.courseid,'
                  . ' a.paymentmode, DATE_FORMAT(a.paymentdate, "%d-%m-%Y %h:%i %p") as paydate,'
                  . ' a.receiptno, a.studentid , a.courseid , a.paymentdate , b.studid,'
                  . ' b.sname ,b.contact ,b.email ,b.city , c.coursename, a.center, sum(a.total) as paid FROM bscp_feepayments as a'
                  . ',bscp_student as b, admin_course as c where b.id=a.studentid and c.ide=a.courseid and a.paymentstatus = "p" '
                  . 'and (a.paymentdate between "'.$sdate.'" and "'.$edate.'") '.$where.'GROUP BY `challanno`, `studentid`');
       
        $row1 = $query1->result_array();
        if ($row1) {
            $j =1;
            for($i = 0;$i<count($row1);$i++) {
                
                $query1 = $this-> db -> query('select requestid from bscp_feepayments as a , admin_course as c where c.ide=a.courseid and c.screentest != "1" and a.studentid="'.$row1[$i]['studentid'].'" and a.paymentdate < "'.$sdate.'" and a.paymentstatus="p"');
                if($query1->num_rows() > 0){
                    
                    
                } else {
                    
                    $query2 = $this-> db -> query('select sp.*,s.mcode from bscp_studentprofile as sp,bscp_signup as s where s.mobile="'.$row1[$i]['contact'].'" and stuid="'.$row1[$i]['studentid'].'"');
                    $row2 = $query2->result_array();
                    if($row2) {
                        $courseArr[$j]['guardianname'] = $row2[0]['guardianname'];$courseArr[$j]['gender'] = $row2[0]['gender'];
                        $courseArr[$j]['dob'] = $row2[0]['dob'];$courseArr[$j]['fathername'] = $row2[0]['fathername'];
                        $courseArr[$j]['fatheroccupation'] = $row2[0]['fatheroccupation'];$courseArr[$j]['fatheremail'] = $row2[0]['fatheremail'];
                        $courseArr[$j]['fathercode'] = $row2[0]['fathercode'];$courseArr[$j]['fatherphone'] = $row2[0]['fatherphone'];
                        $courseArr[$j]['mothername'] = $row2[0]['mothername'];$courseArr[$j]['motheroccupation'] = $row2[0]['motheroccupation'];
                        $courseArr[$j]['motheremail'] = $row2[0]['motheremail'];$courseArr[$j]['mothercode'] = $row2[0]['mothercode'];
                        $courseArr[$j]['motherphone'] = $row2[0]['motherphone'];$courseArr[$j]['communicationcontact'] = $row2[0]['communicationcontact'];
                        $courseArr[$j]['nationality'] = $row2[0]['nationality'];$courseArr[$j]['category'] = $row2[0]['category'];
                        $courseArr[$j]['bloodgroup'] = $row2[0]['bloodgroup'];$courseArr[$j]['classstudy'] = $row2[0]['classstudy'];
                        $courseArr[$j]['stream'] = $row2[0]['stream'];$courseArr[$j]['schoolcollegename'] = $row2[0]['schoolcollegename'];
                        $courseArr[$j]['eduaddress'] = $row2[0]['eduaddress'];$courseArr[$j]['edulandmark'] = $row2[0]['edulandmark'];
                        $courseArr[$j]['edudistrict'] = $row2[0]['edudistrict'];$courseArr[$j]['edustate'] = $row2[0]['edustate'];
                        $courseArr[$j]['edupost'] = $row2[0]['edupost'];$courseArr[$j]['edupincode'] = $row2[0]['edupincode'];
                        $courseArr[$j]['educountry'] = $row2[0]['educountry'];$courseArr[$j]['examboard'] = $row2[0]['examboard'];
                        $courseArr[$j]['examclass'] = $row2[0]['examclass'];$courseArr[$j]['preferredsubject'] = $row2[0]['preferredsubject'];
                        $courseArr[$j]['eligiblescholar'] = $row2[0]['eligiblescholar'];$courseArr[$j]['mocktype'] = $row2[0]['mocktype'];
                        $courseArr[$j]['rollno'] = $row2[0]['rollno'];$courseArr[$j]['housenameno'] = $row2[0]['housenameno'];
                        $courseArr[$j]['landmark'] = $row2[0]['landmark'];$courseArr[$j]['contactaddress'] = $row2[0]['contactaddress'];
                        $courseArr[$j]['contactcountry'] = $row2[0]['contactcountry'];$courseArr[$j]['contactstate'] = $row2[0]['contactstate'];
                        $courseArr[$j]['contactdistrict'] = $row2[0]['contactdistrict'];$courseArr[$j]['wacode'] = $row2[0]['wacode'];
                        $courseArr[$j]['contactpost'] = $row2[0]['contactpost'];$courseArr[$j]['whatsappno'] = $row2[0]['whatsappno'];
                        $courseArr[$j]['contactpincode'] = $row2[0]['contactpincode'];$courseArr[$j]['accountholdername'] = $row2[0]['accountholdername'];
                        $courseArr[$j]['bankname'] = $row2[0]['bankname'];$courseArr[$j]['branch'] = $row2[0]['branch'];
                        $courseArr[$j]['ifsccode'] = $row2[0]['ifsccode'];$courseArr[$j]['bankaccountno'] = $row2[0]['bankaccountno'];
                        $courseArr[$j]['aadharnumber'] = $row2[0]['aadharnumber'];$courseArr[$j]['profilepercent'] = $row2[0]['profilepercent'];
                        $courseArr[$j]['mcode'] = $row2[0]['mcode'];
                    }
                    $courseArr[$j]['studid'] = $row1[$i]['studid'];
                    $courseArr[$j]['challanno'] = $row1[$i]['challanno'];
                    $courseArr[$j]['paydate'] = $row1[$i]['paydate'];
                    $courseArr[$j]['receiptno'] = $row1[$i]['receiptno'];
                    $courseArr[$j]['sname'] = $row1[$i]['sname'];
                    $courseArr[$j]['contact'] = $row1[$i]['contact'];
                    $courseArr[$j]['email'] = $row1[$i]['email'];
                    $courseArr[$j]['city'] = $row1[$i]['city'];
                    $courseArr[$j]['coursename'] = $row1[$i]['coursename'];
                    $courseArr[$j]['center'] = $row1[$i]['center'];
                    $courseArr[$j]['paid'] = $row1[$i]['paid'];
                    $courseArr[$j]['paymentmode'] = $row1[$i]['paymentmode'];
                    $j++;
                }
                
            }
        }
        
        return $courseArr;
    }
    
    
     public function RefundBillList($sdate,$edate,$center) {
        
         $courseArr = Array();
          $reason['scholarship'] = "Scholarship";
                $reason['faid'] = "Financial Aid";
                $reason['discontinue'] = "Discontinue";
                $reason['berror'] = "Billing Error";
                $reason['others'] = "Others";
                 
          if(($center !== "") && ($center !== "All")) { $where = " and a.center='".$center."' ";}        
          $query1 = $this-> db -> query('SELECT DATE_FORMAT(d.created_At, "%d-%m-%Y %h:%i %p") as appdate,d.appno,a.receiptno,'
                  . ' b.studid,b.sname,c.coursename,a.center,sum(a.remitted) as remitted,sum(a.refundamount) as refundamount,a.paydescription,a.reason FROM bscp_refund as a'
                  . ',bscp_student as b, admin_course as c,bscp_refundapplication as d where b.id=a.studentid and c.ide=a.courseid and d.id = a.refundappid '
                  . 'and (a.created_at between "'.$sdate.'" and "'.$edate.'") '.$where.'GROUP BY `receiptno`');
       
        $row1 = $query1->result_array();
        if ($row1) {
            for($i = 0;$i<count($row1);$i++) {
                $courseArr[$i]['studid'] = $row1[$i]['studid'];
                $courseArr[$i]['appno'] = $row1[$i]['appno'];
                $courseArr[$i]['appdate'] = $row1[$i]['appdate'];
                $courseArr[$i]['remitted'] = $row1[$i]['remitted'];
                $courseArr[$i]['sname'] = $row1[$i]['sname'];
                $courseArr[$i]['coursename'] = $row1[$i]['coursename'];
                $courseArr[$i]['center'] = $row1[$i]['center'];
                $courseArr[$i]['paydescription'] = $row1[$i]['paydescription'];
                $courseArr[$i]['refundamount'] = $row1[$i]['refundamount'];
                 $courseArr[$i]['reason'] =  $reason[$row1[$i]['reason']];
                 $courseArr[$i]['receiptno'] = $row1[$i]['receiptno'];
                
            }
        }
        
        return $courseArr;
    }
    
        
    public function BulkPrintList($sdate,$edate,$center) {
        
         $courseArr = Array(); $where = '';
                 
          if(($center !== "") && ($center !== "All")) { $where = " and center='".$center."'";}        
          $query1 = $this-> db -> query('SELECT a.studentid,a.requestid, a.studentid , a.challanno,s.studid,s.sname FROM bscp_feepayments as a,bscp_student as s where s.id=a.studentid and a.paymentstatus = "p" and (a.paymentdate between "'.$sdate.'" and "'.$edate.'") '.$where.' GROUP BY `challanno`, `studentid`');
       
        $row1 = $query1->result_array();
        if ($row1) {
            for($i = 0;$i<count($row1);$i++) {
                
                $courseArr[$i]['requestid'] = $row1[$i]['requestid'];
                $courseArr[$i]['studentid'] = $row1[$i]['studentid'];
                $courseArr[$i]['challanno'] = $row1[$i]['challanno'];
                $courseArr[$i]['studid'] = $row1[$i]['studid'];
                 $courseArr[$i]['sname'] = $row1[$i]['sname'];
                 $courseArr[$i]['studentid'] = $row1[$i]['studentid'];
              
            }
        }
        
        return $courseArr;
    }
    
    
     public function CourseChangeList($sdate,$edate,$center) {
        
         $rowArr = Array();$where = '';
                 
          if(($center !== "") && ($center !== "All")) { $where = " and center='".$center."'";}
        $selectquery = 'ra.requestid as requestid,ra.new_requestid as new_requestid,ra.receiptno as receiptno,ra.studentid as studentid,ra.courseid as courseid,ra.new_courseid as new_courseid,'
                     . 'ra.center as center,ra.new_center as new_center,sum(ra.remitted) as remitted,sum(ra.refundamount) as refundamount,'
                     . 'DATE_FORMAT(ra.created_at,"%d-%m-%Y") as created_at,s.sname as sname,s.studid as studid ';
	$whereclause = 'ra.receiptno !="" and (ra.created_at between "'.$sdate.'" and "'.$edate.'")'.$where.' group by ra.receiptno';
		
                        
       $query = $this ->db->query('select '.$selectquery.' from bscp_coursechange as ra LEFT JOIN bscp_student as s ON s.id=ra.studentid where '.$whereclause);
       $row = $query->result_array();
	if ($row) {
            for($i = 0;$i<count($row);$i++) {
                
                $rowArr[$i]['receiptno'] = $row[$i]['receiptno'];
                $rowArr[$i]['studid'] = $row[$i]['studid'];
                $rowArr[$i]['sname'] = $row[$i]['sname'];
                $rowArr[$i]['center'] = $row[$i]['center'];
                $rowArr[$i]['new_center'] = $row[$i]['new_center'];
                $rowArr[$i]['center'] = $row[$i]['center'];
                $rowArr[$i]['remitted'] = $row[$i]['remitted'];
                $rowArr[$i]['refundamount'] = $row[$i]['refundamount'];
                $rowArr[$i]['created_at'] = $row[$i]['created_at'];
                $rowArr[$i]['new_courseid'] = $row[$i]['new_courseid'];
                $rowArr[$i]['courseid'] = $row[$i]['courseid'];
                $rowArr[$i]['studentid'] = $row[$i]['studentid'];
                $rowArr[$i]['requestid'] = $row[$i]['requestid'];
                $rowArr[$i]['new_requestid'] = $row[$i]['new_requestid'];
                
                $q1 = $this ->db->query('select coursename from admin_course where ide="'.$row[$i]['courseid'].'"');
                $row1 = $q1->result_array();
                $rowArr[$i]['fcoursename'] = $row1[0]['coursename'];
                
                $q2 = $this ->db->query('select coursename from admin_course where ide="'.$row[$i]['new_courseid'].'"');
                $row2 = $q2->result_array();
                $rowArr[$i]['tcoursename'] = $row2[0]['coursename'];
                
            }
            
        } 
	  
        return $rowArr;
    }
    
    public function Duelist($cname,$center) {
        
         $courseArr = Array();
          if(($center !== "") && ($center !== "All")) { $where = " and a.center='".$center."' ";}               
         $query1 = $this-> db -> query('SELECT a.studentid, a.courseid,a.created_at, b.studid, a.challanno, a.requestid, b.sname, c.coursename, a.center, sum(a.total) as unpaid FROM bscp_feepayments as a,'
         . 'bscp_student as b, admin_course as c where  b.id=a.studentid and c.ide=a.courseid and (a.paymentstatus="" and a.amount != "0") and '
                 . ' a.courseid="'.$cname.'" '.$where.'GROUP BY a.challanno, a.studentid, a.center,a.courseid');
     
       
        $row1 = $query1->result_array();
        if ($row1) {
            for($i = 0;$i<count($row1);$i++) {
                $courseArr[$i]['studid'] = $row1[$i]['studid'];
                $courseArr[$i]['challanno'] = $row1[$i]['challanno'];
                $courseArr[$i]['sname'] = $row1[$i]['sname'];
                $courseArr[$i]['coursename'] = $row1[$i]['coursename'];
                $courseArr[$i]['center'] = $row1[$i]['center'];
                $courseArr[$i]['unpaid'] = $row1[$i]['unpaid'];
                
                
            }
        }
        
        return $courseArr;
    }
    
    
    public function BulkPrintView($feesmaster,$feepaybill,$studid,$pname) {
        
        
         $htmlFinal = ''; $html = ''; 
         
         $tablepay = $tablepaynow = $ide = "";
	$sno = $psno = 1;

	$grandtotal = $grandtotalnow = $totalfee = $paidfee = $duefee = $discountfee = $discount = 0;

	$coursename = $center = $paymentmode = $paymentdate = $receiptno = "";
	$checkdiscount = false;

	foreach($feesmaster as $key=>$feemaster){
		
	foreach($feepaybill['feebilldetails'] as $paylist){
		
		if($feemaster['description'] == $paylist['description']){

		$amount = $paylist['amount'];
		$paymentamount = $paylist['paymentamount'];
		$total = $paylist['total'];
		$taxable = $paylist['taxable'];
		$paymentmode = $paylist['paymentmode'];
		$paymentdate = $paylist['paymentdate'];
		$receiptno = $paylist['receiptno'];
		$kf = $paylist['kf'];
		$cov = $paylist['cov'];
		$sac = 999293;
		
		if($paymentamount==0) continue;	
		
		//$thtaxable = '<th scope="col" width="10%">Taxable</th>';
		//$thnontaxable = '<th scope="col" width="10%">Non Taxable</th>';

		$discount = $paylist['discount'];
		$discountamt = 0;$thdiscount = "";$tddiscount = ""; $thtax = ""; $tdtax = "";
		$taxamt = 0;
		$colspan=11;
		
		$tax = $paylist['tax'];
		
		/*$amount1 = round($amount - ($amount * ($tax+$kf)/ (100+$tax+$kf)));
		if($amount==$amount1) $amount = $amount; else $amount = $amount1;*/
		
				
		if(intval($discount)>0) {
							
			$discountamt = $discount;
			//$tddiscount = '<td width="10%">'.$discountamt.'</td>';

			$amount = $amount - $discount;

			$checkdiscount = true;

		}else{
			//$tddiscount = '<td>[DISCOUNT]</td>';
		}
		
		if($tax=="0" || $tax=="NA"){
			
			$tdnontaxable = $amount;
		}else{
			$tdnontaxable = 0;
		}
		
		if($tax!="0" && $tax!="NA"){ 
		
			$tdtaxable = $amount;				

			$taxgst = $tax/2;
			if(intval($tax)>0) $taxamt = $amount * ($tax/100);
			$taxamtgst = $taxamt/2;
			$taxamtgst = number_format($taxamtgst,2);
			
			//$colspan +=4;
			
		} else {
			$tdtaxable = 0;
			$taxgst = $taxamtgst = "NA";
		}
		
		$thtax = '<th scope="col" colspan="2" width="19%"><span class="thtax">CGST</span> <span class="thtaxvalue"><span>Rate %</span> <span>Amount</span></span></th>
			  <th scope="col" colspan="2" width="19%"><span class="thtax">SGST</span> <span class="thtaxvalue"><span>Rate %</span> <span>Amount</span></span></th>';

		$tdtax = '<td width="8%">'.$taxgst.'</td>
				  <td width="8%">'.$taxamtgst.'</td>
				  <td width="8%">'.$taxgst.'</td>
				  <td width="8%">'.$taxamtgst.'</td>';

		$nontaxvalue = $amount;
		$taxvalue = $amount + $taxamt;
		
		
		$kfamt = $amount * ($kf/100);
				

		$grandtotal += $total;

		$tablepay .= '<tr>
					  <th scope="row" width="7%">'.$sno.'.</th>
					  <td width="15%"><strong>'.$paylist['description'].'</strong></td>
					  <td width="11%">'.$sac.'</td>
					  <td width="11%">'.$tdnontaxable.'</td>
					  <td width="11%">'.$tdtaxable.'</td>
					  '.$tddiscount.'
					  '.$tdtax.'
					  <td width="8%">'.$kf.'</td>
					  <td width="8%">'.$kfamt.'</td>
					  <td width="10%">'.number_format($total,2).'</td>
					</tr>';

		$sno++;
	}
		
	}
		
	}
         
         $html = '<div class="row feebill">
								
		<div class="card mb-2 p-4">
		
			<div class="row">
					
			<div class="col-md-6">
			
				<img src="'.base_url().'css/img/brilliant-logo.png" alt="Brilliant Pala Logo" class="mb-2" />
				
				<div class="mt-3"></div>
				
				<p>Receipt No. : <strong>'.$receiptno.'</strong></p>
				<p>Dated : <strong>'.date("d-m-Y h:i A",strtotime($paymentdate)).'</strong></p>
									
			</div>
			<div class="col-md-6 text-right">
				<h3>Brilliant Study Centre, Pala.</h3>
				<p>GSTIN: <strong>32AAEFB8385KIZ7</strong></p>
				<p>Mutholy, Puliyannoor PO, 686-573.</p>
				<p>Phone: 04822 206 100</p>
				<p>Email: admissions@brilliantpala.org</p>
			</div>
			
		
		</div>
			
			<div class="hr mt-1 mb-2"></div>
			
		<div class="row">
			
			<div class="col-md-6">
			
				<p>Student Id: <strong>'.$studid.'</strong></p>
				<p class="mb-0">Student: <strong>'.strtoupper($pname).'</strong></p>';
				
				if(!empty($feepaybill['studentdetails'])){
				
				$html .= '<div class="row">
					<div class="col-md-1"></div>
					<div class="col-md-6">
						<p>'.$feepaybill['studentdetails'][0]['housenameno']." ".$feepaybill['studentdetails'][0]['contactaddress'].", ".$feepaybill['studentdetails'][0]['contactpost'].", ".$feepaybill['studentdetails'][0]['contactdistrict'].", ".$feepaybill['studentdetails'][0]['contactstate'].", ".$feepaybill['studentdetails'][0]['contactcountry']." ".$feepaybill['studentdetails'][0]['contactpincode'].'.'.'</p>
					</div>
				</div>';
				
				 }
				
			$html .='</div>
			<div class="col-md-6 text-right">
				
				<p>Course:  <strong>['.$feepaybill['course'][0]['coursename'].','.$feepaybill['course'][0]['center'].']</strong></p>
				
			</div>
			
		</div>	
		
		<div class="row mb-2">
		
		 <table class="table">
              <thead>
                <tr>
                  <th scope="col" width="5%">Sl. no.</th>
                  <th scope="col" width="18%">Description</th>
                  <th scope="col" width="10%">SAC</th>
                  <th scope="col" width="10%">Non Taxable Value</th>
                  <th scope="col" width="10%">Taxable Value</th>'.$thdiscount.$thtax.'<th scope="col" width="8%">CESS KF %</th>
                  <th scope="col" width="10%">CESS KF Amount</th>
                  <th scope="col" width="14%">Total</th>
                </tr>
              </thead>
              <tbody>'.$tablepay.'               
                <tr>
                  <td colspan="'.$colspan.'" class="totalamt">Grand total</td>
                  <td class="totalfee">'.number_format($grandtotal,2).'</td>
                </tr>
              </tbody>
            </table>
            
			</div>
          
           
			<p class="mb-2">Total Amount: <strong>Rs.'.number_format($grandtotal).'/- '.$this->getIndianCurrency($grandtotal).' Only)</strong></p>

			<p class="mb-2">Payment Mode: <strong>'.strtoupper($paymentmode).'</strong></p>

			<p class="mb-2">Remitted On: <strong>'.date("d-m-Y",strtotime($paymentdate)).'</strong></p>
            
            
            <div class="row d-flex align-items-end mt-3 mb-0">
			
			<div class="col-md-6">
			
				
			</div>
			<div class="col-md-6 text-right">
				
				<h4>Computer generated receipt</h4>
				
			</div>
			
		</div>

            
			</div>
			
		</div>
		
		<div class="mt-0 mb-2 w-100" style="border-bottom: 1px dashed #dee2e6!important;"></div>';
         
        // $htmlClone = '<div class="billclone">'.$html.'</div>';
         
         $htmlFinal = $html;
        
        return $htmlFinal;
    }
    
    public function getIndianCurrency(float $number)
    {
        $decimal = round($number - ($no = floor($number)), 2) * 100;
        $hundred = null;
        $digits_length = strlen($no);
        $i = 0;
        $str = array();
        $words = array(0 => '', 1 => 'one', 2 => 'two',
            3 => 'three', 4 => 'four', 5 => 'five', 6 => 'six',
            7 => 'seven', 8 => 'eight', 9 => 'nine',
            10 => 'ten', 11 => 'eleven', 12 => 'twelve',
            13 => 'thirteen', 14 => 'fourteen', 15 => 'fifteen',
            16 => 'sixteen', 17 => 'seventeen', 18 => 'eighteen',
            19 => 'nineteen', 20 => 'twenty', 30 => 'thirty',
            40 => 'forty', 50 => 'fifty', 60 => 'sixty',
            70 => 'seventy', 80 => 'eighty', 90 => 'ninety');
        $digits = array('', 'hundred','thousand','lakh', 'crore');
        while( $i < $digits_length ) {
            $divider = ($i == 2) ? 10 : 100;
            $number = floor($no % $divider);
            $no = floor($no / $divider);
            $i += $divider == 10 ? 1 : 2;
            if ($number) {
                $plural = (($counter = count($str)) && $number > 9) ? 's' : null;
                $hundred = ($counter == 1 && $str[0]) ? ' and ' : null;
                //$str [] = ($number < 21) ? $words[$number].' '. $digits[$counter]. $plural.' '.$hundred:$words[floor($number / 10) * 10].' '.$words[$number % 10]. ' '.$digits[$counter].$plural.' '.$hundred;
                            $str [] = ($number < 21) ? $words[$number].' '. $digits[$counter].' '.$hundred:$words[floor($number / 10) * 10].' '.$words[$number % 10]. ' '.$digits[$counter].' '.$hundred;
            } else $str[] = null;
        }
        $Rupees = implode('', array_reverse($str));
        $paise = ($decimal > 0) ? "." . ($words[$decimal / 10] . " " . $words[$decimal % 10]) . ' Paise' : '';
        //return ($Rupees ? $Rupees . 'Rupees ' : '') . $paise;
            return (ucwords($Rupees) ? ucwords($Rupees) : '') . ucwords($paise);
    }
   
}

>>>>>>> .r338
?>
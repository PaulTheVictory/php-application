<?php

Class Reports_Model extends CI_Model {
    
     public function __construct() {
        
       $this->load->library('Datatables');
  
    }

    public function BillGeneratonSummary($sdate,$edate,$center) {
        
        $arr = Array();$arr["count"] = 0;$courseArr = Array();
        
                
        $where = "";
        if(($center !== "") && ($center !== "All")) { $where = " and center='".$center."' ";}
        
        $query0 = $this-> db -> query('select distinct cr.receiptno from bscp_feepayments as cr where cr.paymentstatus="p" and (cr.paymentdate between "'.$sdate.'" and "'.$edate.'")'.$where."order by cast(receiptno as unsigned)");
        if ($query0->num_rows()>0) {
           // $courseArr["count"] = $query0->num_rows();
            //$courseArr["count"] = intval($courseArr["count"] === 0)?$courseArr["count"]:(intval($courseArr["count"])+1);
            $row = $query0->result_array();
            if ($row) {
               $courseArr['billno'] = $row[0]['receiptno']." to ".$row[count($row)-1]['receiptno'];
               $r1 =  intval($row[count($row)-1]['receiptno']);
               $r2 = intval($row[0]['receiptno']);
               $r3 = intval($r1)-intval($r2);
               $courseArr["count"] = ++$r3;
            }
        }
    
        
        
        
        $query1 = $this-> db -> query("select cr.courseid,sum(cr.discount) as discount,sum(cr.kf) as kf,cr.courseid,sum(cr.amount) as amount,sum(cr.total) as total,sum(cr.paymentamount) as paymentamount,cr.paymentmode,c.coursename,c.stream,c.type,sp.description from bscp_feepayments as cr,bscp_student_payments as sp,admin_course as c where cr.courseid=sp.courseid and cr.paymentstatus='p' and cr.courseid=c.ide and cr.stupayid=sp.id "
                . "and (cr.paymentdate between '".$sdate."' and '".$edate."')".$where."and (sp.description like '%Tuition Fee%' or sp.description like '%Registration%' or sp.description like '%Caution Deposit%') GROUP by cr.courseid,cr.paymentmode,sp.description");
        $row1 = $query1->result_array();
        if ($row1) {
            for($i = 0;$i<count($row1);$i++) {
                    $cid = $row1[$i]['courseid'];
                    $cname = $row1[$i]['coursename'];
                    $stream = $row1[$i]['stream'];
                    $type = $row1[$i]['type'];
                    $description = $row1[$i]['description'];
                    $payamount = $row1[$i]['amount'];
                    $discount = $row1[$i]['discount'];
                    $payamount = floatval($payamount)-floatval($discount);
                    $paid = $row1[$i]['paymentamount'];
                    $total = $row1[$i]['total'];
                    $kf = $row1[$i]['kf'];
                    $paymode = $row1[$i]['paymentmode'];
                    $paymode = ($paymode === "")?'cash':$paymode;
                    $paymode = strtolower($paymode);
                    if(strpos($description, 'Registration') !== false){
                        $description = "Reg Fee";
                    } else if(strpos($description, 'Tuition') !== false){
                        $description = "Tuition Fee";
                    }else if(strpos($description, 'Caution') !== false){
                        $description = "CD";
                    }
                    
                    if(!array_key_exists($cid, $courseArr)){
                        $courseArr[$cid]=Array();
                        
                    } 
                    
                    if(!in_array($cname, $courseArr[$cid])){
                        $courseArr[$cid]['cname'] = $cname; 
                        $courseArr[$cid]['stream'] = $stream;
                        $courseArr[$cid]['type'] = $type;
                    } 

                    if(!array_key_exists($description, $courseArr[$cid])){
                        $courseArr[$cid][$description] = 0;  
                    } 
                    
                    if(!array_key_exists($paymode, $courseArr[$cid])){
                        $courseArr[$cid][$paymode] = 0;                         
                    }
                    
                    if(!array_key_exists('total', $courseArr[$cid])){
                        $courseArr[$cid]['total'] = 0;  
                    }
                    
                    if(!array_key_exists('paid', $courseArr[$cid])){
                        $courseArr[$cid]['paid'] = 0;  
                    }
                    
                    if(!array_key_exists('kf', $courseArr[$cid])){
                        $courseArr[$cid]['kf'] = 0;  
                    }

                    
                    $courseArr[$cid][$description] = floatVal($courseArr[$cid][$description] )+floatval($payamount);
                    $courseArr[$cid][$paymode] = floatVal($courseArr[$cid][$paymode] )+floatval($paid);
                    $courseArr[$cid]['total'] = floatVal($courseArr[$cid]['total'] )+floatval($total);
                    $courseArr[$cid]['paid'] = floatVal($courseArr[$cid]['paid'] )+floatval($paid);
                    $courseArr[$cid]['kf'] = floatVal($courseArr[$cid]['kf'] )+floatval($kf);
                   
            }
        }
		
	return $courseArr;	
    }
    
    
      public function AccountingHeadBillGeneratonSummary($sdate,$edate,$center) {
        
        $arr = Array();$arr["count"] = 0;$courseArr = Array();
        
                
        $where = "";
        if(($center !== "") && ($center !== "All")) { $where = " and center='".$center."' ";}
        
        $query0 = $this-> db -> query('select distinct cr.receiptno from bscp_feepayments as cr where cr.paymentstatus="p" and (cr.paymentdate between "'.$sdate.'" and "'.$edate.'")'.$where."order by cast(receiptno as unsigned)");
        if ($query0->num_rows()>0) {
           // $courseArr["count"] = $query0->num_rows();
            //$courseArr["count"] = intval($courseArr["count"] === 0)?$courseArr["count"]:(intval($courseArr["count"])+1);
            $row = $query0->result_array();
            if ($row) {
               $courseArr['billno'] = $row[0]['receiptno']." to ".$row[count($row)-1]['receiptno'];
               $r1 =  intval($row[count($row)-1]['receiptno']);
               $r2 = intval($row[0]['receiptno']);
               $r3 = intval($r1)-intval($r2);
               $courseArr["count"] = ++$r3;
            }
        }
    
        
        
        
        $query1 = $this-> db -> query("select cr.courseid,sum(cr.discount) as discount,sum(cr.kf) as kf,cr.courseid,sum(cr.amount) as amount,sum(cr.total) as total,sum(cr.paymentamount) as paymentamount,cr.paymentmode,c.accountinghead,sp.description from bscp_feepayments as cr,bscp_student_payments as sp,admin_course as c where cr.courseid=sp.courseid and cr.paymentstatus='p' and cr.courseid=c.ide and cr.stupayid=sp.id "
                . "and (cr.paymentdate between '".$sdate."' and '".$edate."')".$where."and (sp.description like '%Tuition Fee%' or sp.description like '%Registration%' or sp.description like '%Caution Deposit%') GROUP by c.accountinghead,cr.paymentmode,sp.description");
        $row1 = $query1->result_array();
        if ($row1) {
            for($i = 0;$i<count($row1);$i++) {
                    $cid = $row1[$i]['courseid'];
                    $cname = $row1[$i]['accountinghead'];                    
                    $description = $row1[$i]['description'];
                    $payamount = $row1[$i]['amount'];
                    $discount = $row1[$i]['discount'];
                    $payamount = floatval($payamount)-floatval($discount);
                    $paid = $row1[$i]['paymentamount'];
                    $total = $row1[$i]['total'];
                    $kf = $row1[$i]['kf'];
                    $paymode = $row1[$i]['paymentmode'];
                    $paymode = ($paymode === "")?'cash':$paymode;
                    $paymode = strtolower($paymode);
                    if(strpos($description, 'Registration') !== false){
                        $description = "Reg Fee";
                    } else if(strpos($description, 'Tuition') !== false){
                        $description = "Tuition Fee";
                    }else if(strpos($description, 'Caution') !== false){
                        $description = "CD";
                    }
                    
                    if(!array_key_exists($cname, $courseArr)){
                        $courseArr[$cname]=Array();
                        
                    } 
                    
                    if(!in_array($cname, $courseArr[$cname])){
                        $courseArr[$cname]['cname'] = $cname;                       
                    } 

                    if(!array_key_exists($description, $courseArr[$cname])){
                        $courseArr[$cname][$description] = 0;  
                    } 
                    
                    if(!array_key_exists($paymode, $courseArr[$cname])){
                        $courseArr[$cname][$paymode] = 0;                         
                    }
                    
                    if(!array_key_exists('total', $courseArr[$cname])){
                        $courseArr[$cname]['total'] = 0;  
                    }
                    
                    if(!array_key_exists('paid', $courseArr[$cname])){
                        $courseArr[$cname]['paid'] = 0;  
                    }
                    
                    if(!array_key_exists('kf', $courseArr[$cname])){
                        $courseArr[$cname]['kf'] = 0;  
                    }

                    
                    $courseArr[$cname][$description] = floatVal($courseArr[$cname][$description] )+floatval($payamount);
                    $courseArr[$cname][$paymode] = floatVal($courseArr[$cname][$paymode] )+floatval($paid);
                    $courseArr[$cname]['total'] = floatVal($courseArr[$cname]['total'] )+floatval($total);
                    $courseArr[$cname]['paid'] = floatVal($courseArr[$cname]['paid'] )+floatval($paid);
                    $courseArr[$cname]['kf'] = floatVal($courseArr[$cname]['kf'] )+floatval($kf);
                   
            }
        }
		
	return $courseArr;	
    }
	
	
	 public function BranchWiseCollectionBillGeneratonSummary($sdate,$edate,$center) {
        
        $arr = Array();$arr["count"] = 0;$courseArr = Array();
        
                
		 $this->load->model('users_model','',TRUE);
		 $branch = $this->users_model->GetAllCenters("","array");
		 
        $where = "";
        if(($center !== "") && ($center !== "All")) { $where = " and paydescription LIKE '%".$center."%' ";}
		 else { $where = " and SUBSTRING_INDEX(paydescription, '|', 1) IN ('".implode("','",$branch)."') "; }
        
        $query0 = $this-> db -> query('select distinct cr.receiptno from bscp_feepayments as cr where cr.paymentstatus="p" and (cr.paymentdate between "'.$sdate.'" and "'.$edate.'")'.$where);
        if ($query0->num_rows()>0) {
            
               $courseArr["count"] = $query0->num_rows();
        }
    
                
        $query1 = $this-> db -> query("select cr.courseid,sum(cr.discount) as discount,sum(cr.kf) as kf,cr.courseid,sum(cr.amount) as amount,sum(cr.total) as total,sum(cr.paymentamount) as paymentamount,cr.paymentmode,c.accountinghead,sp.description from bscp_feepayments as cr,bscp_student_payments as sp,admin_course as c where cr.courseid=sp.courseid and cr.paymentstatus='p' and cr.courseid=c.ide and cr.stupayid=sp.id "
                . "and (cr.paymentdate between '".$sdate."' and '".$edate."')".$where."and (sp.description like '%Tuition Fee%' or sp.description like '%Registration%' or sp.description like '%Caution Deposit%') GROUP by c.accountinghead,cr.paymentmode,sp.description");
        $row1 = $query1->result_array();
        if ($row1) {
            for($i = 0;$i<count($row1);$i++) {
                    $cid = $row1[$i]['courseid'];
                    $cname = $row1[$i]['accountinghead'];                    
                    $description = $row1[$i]['description'];
                    $payamount = $row1[$i]['amount'];
                    $discount = $row1[$i]['discount'];
                    $payamount = floatval($payamount)-floatval($discount);
                    $paid = $row1[$i]['paymentamount'];
                    $total = $row1[$i]['total'];
                    $kf = $row1[$i]['kf'];
                    $paymode = $row1[$i]['paymentmode'];
                    $paymode = ($paymode === "")?'cash':$paymode;
                    $paymode = strtolower($paymode);
                    if(strpos($description, 'Registration') !== false){
                        $description = "Reg Fee";
                    } else if(strpos($description, 'Tuition') !== false){
                        $description = "Tuition Fee";
                    }else if(strpos($description, 'Caution') !== false){
                        $description = "CD";
                    }
                    
                    if(!array_key_exists($cname, $courseArr)){
                        $courseArr[$cname]=Array();
                        
                    } 
                    
                    if(!in_array($cname, $courseArr[$cname])){
                        $courseArr[$cname]['cname'] = $cname;                       
                    } 

                    if(!array_key_exists($description, $courseArr[$cname])){
                        $courseArr[$cname][$description] = 0;  
                    } 
                    
                    if(!array_key_exists($paymode, $courseArr[$cname])){
                        $courseArr[$cname][$paymode] = 0;                         
                    }
                    
                    if(!array_key_exists('total', $courseArr[$cname])){
                        $courseArr[$cname]['total'] = 0;  
                    }
                    
                    if(!array_key_exists('paid', $courseArr[$cname])){
                        $courseArr[$cname]['paid'] = 0;  
                    }
                    
                    if(!array_key_exists('kf', $courseArr[$cname])){
                        $courseArr[$cname]['kf'] = 0;  
                    }

                    
                    $courseArr[$cname][$description] = floatVal($courseArr[$cname][$description] )+floatval($payamount);
                    $courseArr[$cname][$paymode] = floatVal($courseArr[$cname][$paymode] )+floatval($paid);
                    $courseArr[$cname]['total'] = floatVal($courseArr[$cname]['total'] )+floatval($total);
                    $courseArr[$cname]['paid'] = floatVal($courseArr[$cname]['paid'] )+floatval($paid);
                    $courseArr[$cname]['kf'] = floatVal($courseArr[$cname]['kf'] )+floatval($kf);
                   
            }
        }
		
	return $courseArr;	
    }
    
    
    public function CourseWiseAdmittedList($sdate,$edate,$center) {
        
         $where = ""; $courseArr = Array();
        if(($center !== "") && ($center !== "All")) { $where = " and center='".$center."' ";}
        
          $query1 = $this-> db -> query("select cr.ide,c.coursename,c.stream as cstream,c.type,cr.center,s.studid,s.sname,s.contact,sp.whatsappno,s.email,aq.name,cr.stream,cr.xii_stream,"
                  . "cr.total from bscp_courserequest as cr,bscp_student as s,admin_course as c,bscp_studentprofile as sp,"
                  . "admin_qualification as aq where cr.courseid=c.ide and cr.studentid=s.id and cr.studentid=sp.stuid and cr.qualificationid=aq.id and cr.approved='y'"
                . "and (cr.requested_at between '".$sdate."' and '".$edate."')".$where);
       
        $row1 = $query1->result_array();
        if ($row1) {
            for($i = 0;$i<count($row1);$i++) {
                $ide = $row1[$i]['ide'];
                $courseArr[$ide]['coursename'] = $row1[$i]['coursename'];
				$courseArr[$ide]['cstream'] = $row1[$i]['cstream'];
				$courseArr[$ide]['type'] = $row1[$i]['type'];
                $courseArr[$ide]['center'] = $row1[$i]['center'];
                $courseArr[$ide]['studid'] = $row1[$i]['studid'];
                $courseArr[$ide]['sname'] = $row1[$i]['sname'];
                $courseArr[$ide]['contact'] = $row1[$i]['contact'];
                $courseArr[$ide]['whatsappno'] = $row1[$i]['whatsappno'];
                $courseArr[$ide]['email'] = $row1[$i]['email'];
                $courseArr[$ide]['name'] = $row1[$i]['name'];
                $courseArr[$ide]['stream'] = ($row1[$i]['xii_stream'] !== "")? $row1[$i]['xii_stream']:$row1[$i]['stream'];
                //$courseArr[$ide]['total'] = round($row1[$i]['total']);
                
                $query2 = $this-> db -> query("select sum(total) as total,DATE_FORMAT(paymentdate,'%d-%m-%Y %h:%i %p') as pdate from bscp_feepayments where requestid='".$row1[$i]['ide']."' and paymentstatus='p'");
                $row2 = $query2->result_array();
                if ($row2) {
                $courseArr[$ide]['remitted'] = $row2[0]['total'];
                $courseArr[$ide]['pdate'] = $row2[0]['pdate'];
                } else {
                    $courseArr[$ide]['remitted'] = '0';
                    $courseArr[$ide]['pdate'] = '';
                }
                
                $query3 = $this-> db -> query("select sum(total) as total from bscp_student_payments where requestid='".$row1[$i]['ide']."'");
                $row3 = $query3->result_array();
                if ($row3) {
                $courseArr[$ide]['total'] = $row3[0]['total'];
               
                } else {
                    $courseArr[$ide]['total'] = '0';
                }
                
                $query4 = $this-> db -> query("select mcode from bscp_signup where mobile='".$row1[$i]['contact']."'");
                $row4 = $query4->result_array();
                if ($row4) {
                $courseArr[$ide]['mcode'] = $row4[0]['mcode'];
               
                } else {
                    $courseArr[$ide]['mcode'] = '';
                }
            }
        }
        
        return $courseArr;
    }
    
    
       public function DailyCourseAppliedList($sdate,$edate,$center) {
        
         $where = ""; $courseArr = Array();
         $statusArr=array("y"=>'Approved',"n"=>'Approved',"w"=>'Waitig List',"n"=>'Applied - NQ',
             "q"=>'Applied',"d"=>'Denied'); 
        if(($center !== "") && ($center !== "All")) { $where = " and center='".$center."' ";}
        
          $query1 = $this-> db -> query("select cr.approved,cr.ide,DATE_FORMAT(cr.requested_at,'%d-%m-%Y %h:%i %p') as rdate,c.coursename,c.stream as cstream,c.type,cr.center,s.studid,s.sname,s.contact,s.email,aq.name,cr.stream,cr.xii_stream "
                  . "from bscp_courserequest as cr,bscp_student as s,admin_course as c,"
                  . "admin_qualification as aq where cr.courseid=c.ide and cr.studentid=s.id and cr.qualificationid=aq.id "
                . "and (cr.requested_at between '".$sdate."' and '".$edate."')".$where);
       
        $row1 = $query1->result_array();
        if ($row1) {
            for($i = 0;$i<count($row1);$i++) {
                $ide = $row1[$i]['ide'];
                $courseArr[$ide]['coursename'] = $row1[$i]['coursename'];
				$courseArr[$ide]['cstream'] = $row1[$i]['cstream'];
				$courseArr[$ide]['type'] = $row1[$i]['type'];
                $courseArr[$ide]['center'] = $row1[$i]['center'];
                $courseArr[$ide]['studid'] = $row1[$i]['studid'];
                $courseArr[$ide]['sname'] = $row1[$i]['sname'];
                $courseArr[$ide]['contact'] = $row1[$i]['contact'];
                $status = (array_key_exists($row1[$i]['approved'], $statusArr))?$statusArr[$row1[$i]['approved']]:"NA";
                $courseArr[$ide]['status'] = $status;
                $courseArr[$ide]['email'] = $row1[$i]['email'];
                $courseArr[$ide]['qualification'] = $row1[$i]['name'];
                $courseArr[$ide]['stream'] = ($row1[$i]['xii_stream'] !== "")? $row1[$i]['xii_stream']:$row1[$i]['stream'];
                $courseArr[$ide]['rdate'] = $row1[$i]['rdate'];
               
                $query4 = $this-> db -> query("select mcode from bscp_signup where mobile='".$row1[$i]['contact']."'");
                $row4 = $query4->result_array();
                if ($row4) {
                $courseArr[$ide]['mcode'] = $row4[0]['mcode'];
               
                } else {
                    $courseArr[$ide]['mcode'] = '';
                }
                
            }
        }
        
        return $courseArr;
    }
    
    
     public function DailySignupList($sdate,$edate) {
        
         $courseArr = Array();
                 
          $query1 = $this-> db -> query("select s.studid,s.sname,s.contact,s.email,aq.name "
                  . "from bscp_student as s,admin_qualification as aq where s.qualification=aq.id "
                . "and (s.created_at between '".$sdate."' and '".$edate."')");
       
        $row1 = $query1->result_array();
        if ($row1) {
            for($i = 0;$i<count($row1);$i++) {
                $courseArr[$i]['studid'] = $row1[$i]['studid'];
                $courseArr[$i]['sname'] = $row1[$i]['sname'];
                $courseArr[$i]['contact'] = $row1[$i]['contact'];
                $courseArr[$i]['email'] = $row1[$i]['email'];
                $courseArr[$i]['qualification'] = $row1[$i]['name'];
                
                $query4 = $this-> db -> query("select mcode from bscp_signup where mobile='".$row1[$i]['contact']."'");
                $row4 = $query4->result_array();
                if ($row4) {
                $courseArr[$i]['mcode'] = $row4[0]['mcode'];
               
                } else {
                    $courseArr[$i]['mcode'] = '';
                }
                
            }
        }
        
        return $courseArr;
    }
    
    public function DailyBillList($sdate,$edate,$center) {
        
         $courseArr = Array();
                 
          if(($center !== "") && ($center !== "All")) { $where = " and a.center='".$center."' ";}        
          $query1 = $this-> db -> query('SELECT a.courseid,'
                  . ' a.paymentmode, DATE_FORMAT(a.paymentdate, "%d-%m-%Y %h:%i %p") as paydate,'
                  . ' a.receiptno, a.studentid , a.courseid , a.paymentdate , b.studid'
                  . ', a.challanno, b.sname , c.coursename, c.stream, c.type, a.center, sum(a.total) as paid,a.paydescription FROM bscp_feepayments as a'
                  . ',bscp_student as b, admin_course as c where b.id=a.studentid and c.ide=a.courseid and a.paymentstatus = "p" '
                  . 'and (a.paymentdate between "'.$sdate.'" and "'.$edate.'") '.$where.'GROUP BY `challanno`, `studentid` order by cast(a.receiptno as unsigned)');
       
        $row1 = $query1->result_array();
        if ($row1) {
            for($i = 0;$i<count($row1);$i++) {
				
				
				$paydescription = "";
				
				if(strcmp($row1[$i]['paymentmode'],"Online")!==0){
					$paydescriptionarr = explode("|",$row1[$i]['paydescription']);
					$paydescription = implode(", ",$paydescriptionarr);
				}
				
				
                $courseArr[$i]['studid'] = $row1[$i]['studid'];
                $courseArr[$i]['challanno'] = $row1[$i]['challanno'];
                $courseArr[$i]['paydate'] = $row1[$i]['paydate'];
                $courseArr[$i]['receiptno'] = $row1[$i]['receiptno'];
                $courseArr[$i]['sname'] = $row1[$i]['sname'];
                $courseArr[$i]['coursename'] = $row1[$i]['coursename'];
				$courseArr[$i]['stream'] = $row1[$i]['stream'];
				$courseArr[$i]['type'] = $row1[$i]['type'];
                $courseArr[$i]['center'] = $row1[$i]['center'];
                $courseArr[$i]['paid'] = $row1[$i]['paid'];
                $courseArr[$i]['paymentmode'] = $row1[$i]['paymentmode'];
                $courseArr[$i]['paydescription'] = $paydescription;
                
            }
        }
        
        return $courseArr;
    }
    
    public function UnpaidList($sdate,$edate,$center) {
        
         $courseArr = Array();
          if(($center !== "") && ($center !== "All")) { $where = " and a.center='".$center."' ";}               
         $query1 = $this-> db -> query('SELECT a.studentid, a.courseid,a.created_at, b.studid, a.challanno, a.requestid, b.sname, c.coursename, c.stream, c.type, a.center, sum(a.total) as unpaid FROM bscp_feepayments as a,'
         . 'bscp_student as b, admin_course as c where  b.id=a.studentid and c.ide=a.courseid and (a.paymentstatus="" and a.amount != "0") and '
                 . '(a.created_at between "'.$sdate.'" and "'.$edate.'") '.$where.'GROUP BY a.challanno, a.studentid, a.center,a.courseid');
     
       
        $row1 = $query1->result_array();
        if ($row1) {
            for($i = 0;$i<count($row1);$i++) {
                $courseArr[$i]['studid'] = $row1[$i]['studid'];
                $courseArr[$i]['challanno'] = $row1[$i]['challanno'];
                $courseArr[$i]['sname'] = $row1[$i]['sname'];
                $courseArr[$i]['coursename'] = $row1[$i]['coursename'];
				$courseArr[$i]['stream'] = $row1[$i]['stream'];
				$courseArr[$i]['type'] = $row1[$i]['type'];
                $courseArr[$i]['center'] = $row1[$i]['center'];
                $courseArr[$i]['unpaid'] = $row1[$i]['unpaid'];
                
                
            }
        }
        
        return $courseArr;
    }
    
    public function FirstTimeStudentPaidList($sdate,$edate,$center) {
        
        $courseArr = Array();
                 
          if(($center !== "") && ($center !== "All")) { $where = " and a.center='".$center."' ";}        
          $query1 = $this-> db -> query('SELECT a.courseid,'
                  . ' a.paymentmode, DATE_FORMAT(a.paymentdate, "%d-%m-%Y %h:%i %p") as paydate,'
                  . ' a.receiptno, a.studentid , a.courseid , a.paymentdate , b.studid,'
                  . ' b.sname ,b.contact ,b.email ,b.city , c.coursename, c.stream as cstream, c.type, a.center, sum(a.total) as paid FROM bscp_feepayments as a'
                  . ',bscp_student as b, admin_course as c where b.id=a.studentid and c.ide=a.courseid and a.paymentstatus = "p" '
                  . 'and (a.paymentdate between "'.$sdate.'" and "'.$edate.'") '.$where.'GROUP BY `challanno`, `studentid`');
       
        $row1 = $query1->result_array();
        if ($row1) {
            $j =1;
            for($i = 0;$i<count($row1);$i++) {
                
                $query1 = $this-> db -> query('select requestid from bscp_feepayments as a , admin_course as c where c.ide=a.courseid and c.screentest != "1" and a.studentid="'.$row1[$i]['studentid'].'" and a.courseid="'.$row1[$i]['courseid'].'" and a.paymentdate < "'.$sdate.'" and a.paymentstatus="p"');
                if($query1->num_rows() > 0){
                    
                    
                } else {
                    
                    $query2 = $this-> db -> query('select sp.*,s.mcode from bscp_studentprofile as sp,bscp_signup as s where s.mobile="'.$row1[$i]['contact'].'" and stuid="'.$row1[$i]['studentid'].'"');
                    $row2 = $query2->result_array();
                    if($row2) {
                        $courseArr[$j]['guardianname'] = $row2[0]['guardianname'];$courseArr[$j]['gender'] = $row2[0]['gender'];
                        $courseArr[$j]['dob'] = $row2[0]['dob'];$courseArr[$j]['fathername'] = $row2[0]['fathername'];
                        $courseArr[$j]['fatheroccupation'] = $row2[0]['fatheroccupation'];$courseArr[$j]['fatheremail'] = $row2[0]['fatheremail'];
                        $courseArr[$j]['fathercode'] = $row2[0]['fathercode'];$courseArr[$j]['fatherphone'] = $row2[0]['fatherphone'];
                        $courseArr[$j]['mothername'] = $row2[0]['mothername'];$courseArr[$j]['motheroccupation'] = $row2[0]['motheroccupation'];
                        $courseArr[$j]['motheremail'] = $row2[0]['motheremail'];$courseArr[$j]['mothercode'] = $row2[0]['mothercode'];
                        $courseArr[$j]['motherphone'] = $row2[0]['motherphone'];$courseArr[$j]['communicationcontact'] = $row2[0]['communicationcontact'];
                        $courseArr[$j]['nationality'] = $row2[0]['nationality'];$courseArr[$j]['category'] = $row2[0]['category'];
                        $courseArr[$j]['bloodgroup'] = $row2[0]['bloodgroup'];$courseArr[$j]['classstudy'] = $row2[0]['classstudy'];
                        $courseArr[$j]['stream'] = $row2[0]['stream'];$courseArr[$j]['schoolcollegename'] = $row2[0]['schoolcollegename'];
                        $courseArr[$j]['eduaddress'] = $row2[0]['eduaddress'];$courseArr[$j]['edulandmark'] = $row2[0]['edulandmark'];
                        $courseArr[$j]['edudistrict'] = $row2[0]['edudistrict'];$courseArr[$j]['edustate'] = $row2[0]['edustate'];
                        $courseArr[$j]['edupost'] = $row2[0]['edupost'];$courseArr[$j]['edupincode'] = $row2[0]['edupincode'];
                        $courseArr[$j]['educountry'] = $row2[0]['educountry'];$courseArr[$j]['examboard'] = $row2[0]['examboard'];
                        $courseArr[$j]['examclass'] = $row2[0]['examclass'];$courseArr[$j]['preferredsubject'] = $row2[0]['preferredsubject'];
                        $courseArr[$j]['eligiblescholar'] = $row2[0]['eligiblescholar'];$courseArr[$j]['mocktype'] = $row2[0]['mocktype'];
                        $courseArr[$j]['rollno'] = $row2[0]['rollno'];$courseArr[$j]['housenameno'] = $row2[0]['housenameno'];
                        $courseArr[$j]['landmark'] = $row2[0]['landmark'];$courseArr[$j]['contactaddress'] = $row2[0]['contactaddress'];
                        $courseArr[$j]['contactcountry'] = $row2[0]['contactcountry'];$courseArr[$j]['contactstate'] = $row2[0]['contactstate'];
                        $courseArr[$j]['contactdistrict'] = $row2[0]['contactdistrict'];$courseArr[$j]['wacode'] = $row2[0]['wacode'];
                        $courseArr[$j]['contactpost'] = $row2[0]['contactpost'];$courseArr[$j]['whatsappno'] = $row2[0]['whatsappno'];
                        $courseArr[$j]['contactpincode'] = $row2[0]['contactpincode'];$courseArr[$j]['accountholdername'] = $row2[0]['accountholdername'];
                        $courseArr[$j]['bankname'] = $row2[0]['bankname'];$courseArr[$j]['branch'] = $row2[0]['branch'];
                        $courseArr[$j]['ifsccode'] = $row2[0]['ifsccode'];$courseArr[$j]['bankaccountno'] = $row2[0]['bankaccountno'];
                        $courseArr[$j]['aadharnumber'] = $row2[0]['aadharnumber'];$courseArr[$j]['profilepercent'] = $row2[0]['profilepercent'];
                        $courseArr[$j]['mcode'] = $row2[0]['mcode'];
                    }
                    $courseArr[$j]['studid'] = $row1[$i]['studid'];
                    $courseArr[$j]['challanno'] = $row1[$i]['challanno'];
                    $courseArr[$j]['paydate'] = $row1[$i]['paydate'];
                    $courseArr[$j]['receiptno'] = $row1[$i]['receiptno'];
                    $courseArr[$j]['sname'] = $row1[$i]['sname'];
                    $courseArr[$j]['contact'] = $row1[$i]['contact'];
                    $courseArr[$j]['email'] = $row1[$i]['email'];
                    $courseArr[$j]['city'] = $row1[$i]['city'];
                    $courseArr[$j]['coursename'] = $row1[$i]['coursename'];
					$courseArr[$j]['cstream'] = $row1[$i]['cstream'];
					$courseArr[$j]['type'] = $row1[$i]['type'];
                    $courseArr[$j]['center'] = $row1[$i]['center'];
                    $courseArr[$j]['paid'] = $row1[$i]['paid'];
                    $courseArr[$j]['paymentmode'] = $row1[$i]['paymentmode'];
                    $j++;
                }
                
            }
        }
        
        return $courseArr;
    }
    
    
    public function RefundApplicationList($sdate,$edate,$center) {
        
         $courseArr = Array();
                      
                $status['w'] = "Waiting List";
                $status['c'] = "Completed";
                $status['p'] = "Progressing";
                $status['n'] = "Not Eligible";
                $status['cd'] = "Cancelled";
                $status['cf'] = "Confirmed";
             
                
          if(($center !== "") && ($center !== "All")) { $where = " and a.center='".$center."' ";}        
          $query1 = $this-> db -> query('SELECT d.bankname,d.bankaccountno,d.branch,d.ifsccode,d.remarks,d.status,d.courseid,d.studentid,DATE_FORMAT(d.created_at, "%d-%m-%Y %h:%i %p") as appdate,d.appno,'
                  . ' b.studid,b.sname,b.contact,b.mcode,c.coursename,c.stream,c.type,d.center,d.type as rtype FROM bscp_refundapplication as d'
                  . ',bscp_student as b, admin_course as c where b.id=d.studentid and c.ide=d.courseid '
                  . 'and (d.created_at between "'.$sdate.'" and "'.$edate.'") '.$where);
       
        $row1 = $query1->result_array();
        if ($row1) {
            for($i = 0;$i<count($row1);$i++) {
                $courseArr[$i]['studid'] = $row1[$i]['studid'];
                $courseArr[$i]['appno'] = $row1[$i]['appno'];
                $courseArr[$i]['appdate'] = $row1[$i]['appdate'];            
                $courseArr[$i]['sname'] = $row1[$i]['sname'];
                $courseArr[$i]['coursename'] = $row1[$i]['coursename'];
		$courseArr[$i]['stream'] = $row1[$i]['stream'];
		$courseArr[$i]['type'] = $row1[$i]['type'];  
                $courseArr[$i]['status'] =  $status[$row1[$i]['status']];
                $courseArr[$i]['center'] = $row1[$i]['center'];
                $courseArr[$i]['contact'] = $row1[$i]['contact'];                
                $courseArr[$i]['mcode'] = $row1[$i]['mcode'];
                $courseArr[$i]['rtype'] = $row1[$i]['rtype'];
                $courseArr[$i]['bankname'] = $row1[$i]['bankname'];
                $courseArr[$i]['bankaccountno'] = $row1[$i]['bankaccountno'];
                $courseArr[$i]['branch'] = $row1[$i]['branch'];
                $courseArr[$i]['ifsccode'] = $row1[$i]['ifsccode'];
                $courseArr[$i]['remarks'] = $row1[$i]['remarks'];
                         
                $query3 = $this-> db -> query('SELECT batchname FROM bscp_courserequest where courseid= "'. $row1[$i]['courseid'].'" and studentid= "'. $row1[$i]['studentid'].'"');
                $row3 = $query3->result_array();
                $courseArr[$i]['batchname'] = ($row3[0]['batchname'] === NULL )?"":$row3[0]['batchname'];
                
            }
        }
        
        return $courseArr;
    }
    
    
     public function RefundBillList($sdate,$edate,$center) {
        
         $courseArr = Array();
          $reason['scholarship'] = "Scholarship";
                $reason['faid'] = "Financial Aid";
                $reason['discontinue'] = "Discontinue";
                $reason['berror'] = "Billing Error";
                 $reason['excessfeeremit'] = "Excess Fee remit";
                $reason['others'] = "Others";
                
                 $paymode['cash'] = "Cash";
                $paymode['dd'] = "Demand Draft";
                $paymode['net'] = "Bank Transfer";
                $paymode['cheque'] = "Cheque";
                
                $status['c'] = "Completed";
                $status['p'] = "Progressing";
                $status['n'] = "Not Eligible";
                $status['cd'] = "Cancelled";
                $status['cf'] = "Confirmed";
                 
          if(($center !== "") && ($center !== "All")) { $where = " and a.center='".$center."' ";}        
          $query1 = $this-> db -> query('SELECT DATE_FORMAT(d.created_At, "%d-%m-%Y %h:%i %p") as appdate,d.appno,d.bankname,d.branch,d.ifsccode,d.bankaccountno,d.status,a.receiptno,'
                  . ' b.studid,b.sname,c.coursename,c.stream,c.type,a.center,sum(a.remitted) as remitted,a.paydescription,sum(a.refundamount) as refundnet,sum(a.gstrefund) as gstrefund,a.reason,a.paymode FROM bscp_refund as a'
                  . ',bscp_student as b, admin_course as c,bscp_refundapplication as d where b.id=a.studentid and c.ide=a.courseid and d.id = a.refundappid '
                  . 'and (a.created_at between "'.$sdate.'" and "'.$edate.'") '.$where.'GROUP BY `receiptno`');
       
        $row1 = $query1->result_array();
        if ($row1) {
            for($i = 0;$i<count($row1);$i++) {
                $courseArr[$i]['studid'] = $row1[$i]['studid'];
                $courseArr[$i]['appno'] = $row1[$i]['appno'];
                $courseArr[$i]['appdate'] = $row1[$i]['appdate'];
                $courseArr[$i]['remitted'] = $row1[$i]['remitted'];
                $courseArr[$i]['sname'] = $row1[$i]['sname'];
                $courseArr[$i]['coursename'] = $row1[$i]['coursename'];
				 $courseArr[$i]['stream'] = $row1[$i]['stream'];
				 $courseArr[$i]['type'] = $row1[$i]['type'];
                $courseArr[$i]['bankname'] = $row1[$i]['bankname'];               
                $courseArr[$i]['branch'] = $row1[$i]['branch'];
                $courseArr[$i]['ifsccode'] = $row1[$i]['ifsccode'];
                $courseArr[$i]['bankaccountno'] = $row1[$i]['bankaccountno'];
                $courseArr[$i]['paydescription'] = $row1[$i]['paydescription'];  
                 $courseArr[$i]['paymode'] = $paymode[$row1[$i]['paymode']];  
                $courseArr[$i]['reason'] =  $reason[$row1[$i]['reason']];
                $courseArr[$i]['receiptno'] = $row1[$i]['receiptno'];
                $courseArr[$i]['center'] = $row1[$i]['center'];
                 $courseArr[$i]['status'] = $status[$row1[$i]['status']];  
                
                 $query2 = $this-> db -> query('SELECT a.id,a.description,'
                  . 'b.refundtotal FROM bscp_refund as b'
                  . ',bscp_student_payments as a where a.id=b.stupayid and b.receiptno = "'. $row1[$i]['receiptno'].'"');
       
               $refundamt=0;$cdamt = 0;
                $row2 = $query2->result_array();
                if ($row2) {
                     for($j = 0;$j<count($row2);$j++) {
                         
                         if($row2[$j]['description'] === 'Caution Deposit') {
                            $cdamt = $cdamt + floatval($row2[$j]['refundtotal']);
                         } else {
                            
                            $refundamt = $refundamt+floatval($row2[$j]['refundtotal']); 
                         }
                                 
                         
                     }    
                }
                
                $totalrefund = floatval($refundamt)+ floatval($cdamt);
                $totalrefund = round($totalrefund);
                $courseArr[$i]['refundamount'] = $totalrefund;
                            
               
		$taxwithgst = floatval($row1[$i]['gstrefund']);
	          
                $taxwithgst = floatval($taxwithgst)/2;
                
                 $courseArr[$i]['cd'] = $cdamt;
                 $courseArr[$i]['bfrefundamount'] =  $row1[$i]['refundnet'];
                 $courseArr[$i]['cgst'] = round($taxwithgst);
                 $courseArr[$i]['sgst'] = round($taxwithgst);
                 
                 $ftotal = floatval($row1[$i]['refundnet'])+floatval($cdamt)+round($taxwithgst)+round($taxwithgst);
                 $ftotalbr = floatval($row1[$i]['refundnet'])+floatval($cdamt)+floatval($taxwithgst)+floatval($taxwithgst);
                 $courseArr[$i]['roundoff'] =  number_format(round($ftotal) - $ftotalbr,2);
                 $courseArr[$i]['refundamount'] = round($ftotal);
                
                
            }
        }
        
        return $courseArr;
    }
    
    
         public function RefundFullBillList($sdate,$edate,$center) {
        
         $courseArr = Array();
          $reason['scholarship'] = "Scholarship";
                $reason['faid'] = "Financial Aid";
                $reason['discontinue'] = "Discontinue";
                $reason['berror'] = "Billing Error";
                 $reason['excessfeeremit'] = "Excess Fee remit";
                $reason['others'] = "Others";
                
                 $paymode['cash'] = "Cash";
                $paymode['dd'] = "Demand Draft";
                $paymode['net'] = "Bank Transfer";
                $paymode['cheque'] = "Cheque";
                
                
                $status['c'] = "Completed";
                $status['p'] = "Progressing";
                $status['n'] = "Not Eligible";
                $status['cd'] = "Cancelled";
                $status['cf'] = "Confirmed";
             
                
          if(($center !== "") && ($center !== "All")) { $where = " and a.center='".$center."' ";}        
          $query1 = $this-> db -> query('SELECT a.receiptno,d.status,a.studentid,a.courseid,d.updated_by,DATE_FORMAT(d.created_at, "%d-%m-%Y %h:%i %p") as appdate,d.appno,DATE_FORMAT(a.created_at, "%d-%m-%Y %h:%i %p") as processeddate,'
                  . ' b.studid,b.sname,c.coursename,c.stream,c.type,a.center,sum(a.refundamount) as refundnet,sum(a.gstrefund) as gstrefund,a.reason,a.paymode FROM bscp_refund as a'
                  . ',bscp_student as b, admin_course as c,bscp_refundapplication as d where b.id=a.studentid and c.ide=a.courseid and d.id = a.refundappid '
                  . 'and (a.created_at between "'.$sdate.'" and "'.$edate.'") '.$where.'GROUP BY `receiptno`');
       
        $row1 = $query1->result_array();
        if ($row1) {
            for($i = 0;$i<count($row1);$i++) {
                $courseArr[$i]['studid'] = $row1[$i]['studid'];
                $courseArr[$i]['appno'] = $row1[$i]['appno'];
                $courseArr[$i]['appdate'] = $row1[$i]['appdate'];
                $courseArr[$i]['processeddate'] = $row1[$i]['processeddate'];
                $courseArr[$i]['remitted'] = $row1[$i]['remitted'];
                $courseArr[$i]['sname'] = $row1[$i]['sname'];
                $courseArr[$i]['coursename'] = $row1[$i]['coursename'];
		$courseArr[$i]['stream'] = $row1[$i]['stream'];
		$courseArr[$i]['type'] = $row1[$i]['type'];
                $courseArr[$i]['paymode'] = $paymode[$row1[$i]['paymode']];  
                $courseArr[$i]['reason'] =  $reason[$row1[$i]['reason']];
                $courseArr[$i]['status'] =  $status[$row1[$i]['status']];
                $courseArr[$i]['center'] = $row1[$i]['center'];
                $courseArr[$i]['updated_by'] = $row1[$i]['updated_by'];
                
                $courseArr[$i]['regfee'] = "";$courseArr[$i]['tffee'] = "";
                $courseArr[$i]['tf1fee'] = "";$courseArr[$i]['tf2fee'] = "";
                $courseArr[$i]['regfeeremitted'] = "";$courseArr[$i]['tffeeremitted'] = "";
                $courseArr[$i]['tf1feeremitted'] = "";$courseArr[$i]['tf2feeremitted'] = "";
                
                 $query2 = $this-> db -> query('SELECT a.id,a.description,b.amount,b.remitted,'
                  . 'b.refundtotal FROM bscp_refund as b'
                  . ',bscp_student_payments as a where a.id=b.stupayid and b.receiptno = "'. $row1[$i]['receiptno'].'"');
       
               $refundamt=0;$cdamt = 0;
                $row2 = $query2->result_array();
                if ($row2) {
                     for($j = 0;$j<count($row2);$j++) {
                         
                         if($row2[$j]['description'] === 'Caution Deposit') {
                            $cdamt = $cdamt + floatval($row2[$j]['refundtotal']);
                         } else {
                            
                            $refundamt = $refundamt+floatval($row2[$j]['refundtotal']); 
                         }
                         
                         if($row2[$j]['description'] === 'Registration Charges') {
                            $courseArr[$i]['regfee'] =  $row2[$j]['amount'];
                            $courseArr[$i]['regfeeremitted'] =  $row2[$j]['remitted'];
                         }
                         
                         if($row2[$j]['description'] === 'Tuition Fee') {
                            $courseArr[$i]['tffee'] =  $row2[$j]['amount'];
                            $courseArr[$i]['tffeeremitted'] =  $row2[$j]['remitted'];
                         }
                         
                         if($row2[$j]['description'] === 'Tuition Fee - 1') {
                            $courseArr[$i]['tf1fee'] =  $row2[$j]['amount'];
                            $courseArr[$i]['tf1feeremitted'] =  $row2[$j]['remitted'];
                         }
                         
                         if($row2[$j]['description'] === 'Tuition Fee - 2') {
                            $courseArr[$i]['tf2fee'] =  $row2[$j]['amount'];
                            $courseArr[$i]['tf2feeremitted'] =  $row2[$j]['remitted'];
                         }
                                 
                         
                     }    
                }
                
                $totalrefund = floatval($refundamt)+ floatval($cdamt);
                $totalrefund = round($totalrefund);
                $courseArr[$i]['refundamount'] = $totalrefund;
                            
               
		$taxwithgst = floatval($row1[$i]['gstrefund']);
	
                 $courseArr[$i]['cd'] = $cdamt;
                 $courseArr[$i]['refundnet'] =  $row1[$i]['refundnet'];
                 $courseArr[$i]['gstrefund'] = $taxwithgst;
                 
                  $courseArr[$i]['cgst'] = round($taxwithgst/2);
                 $courseArr[$i]['sgst'] = round($taxwithgst/2);
                 
                 $ftotal = floatval($row1[$i]['refundnet'])+floatval($cdamt)+round($taxwithgst/2)+round($taxwithgst/2);
                 $ftotalbr = floatval($row1[$i]['refundnet'])+floatval($cdamt)+floatval($taxwithgst/2)+floatval($taxwithgst/2);
                 $courseArr[$i]['roundoff'] =  number_format(round($ftotal) - $ftotalbr,2);
                 $courseArr[$i]['refundamount'] = round($ftotal);
                 
                $query3 = $this-> db -> query('SELECT batchname FROM bscp_courserequest where courseid= "'. $row1[$i]['courseid'].'" and studentid= "'. $row1[$i]['studentid'].'"');
                $row3 = $query3->result_array();
                $courseArr[$i]['batchname'] = ($row3[0]['batchname'] === NULL )?"":$row3[0]['batchname'];
                
            }
        }
        
        return $courseArr;
    }
    
        
    public function BulkPrintList($sdate,$edate,$center) {
        
         $courseArr = Array(); $where = '';
                 
          if(($center !== "") && ($center !== "All")) { $where = " and center='".$center."'";}        
          $query1 = $this-> db -> query('SELECT a.studentid,a.requestid, a.studentid , a.challanno,s.studid,s.sname FROM bscp_feepayments as a,bscp_student as s where s.id=a.studentid and a.paymentstatus = "p" and (a.paymentdate between "'.$sdate.'" and "'.$edate.'") '.$where.' GROUP BY `challanno`, `studentid` order by cast(a.receiptno as unsigned)');
       
        $row1 = $query1->result_array();
        if ($row1) {
            for($i = 0;$i<count($row1);$i++) {
                
                $courseArr[$i]['requestid'] = $row1[$i]['requestid'];
                $courseArr[$i]['studentid'] = $row1[$i]['studentid'];
                $courseArr[$i]['challanno'] = $row1[$i]['challanno'];
                $courseArr[$i]['studid'] = $row1[$i]['studid'];
                 $courseArr[$i]['sname'] = $row1[$i]['sname'];
                 $courseArr[$i]['studentid'] = $row1[$i]['studentid'];
              
            }
        }
        
        return $courseArr;
    }
    
    
     public function CourseChangeList($sdate,$edate,$center) {
        
         $rowArr = Array();$where = '';
                 
          if(($center !== "") && ($center !== "All")) { $where = " and center='".$center."'";}
        $selectquery = 'ra.requestid as requestid,ra.new_requestid as new_requestid,ra.receiptno as receiptno,ra.studentid as studentid,ra.courseid as courseid,ra.new_courseid as new_courseid,'
                     . 'ra.center as center,ra.new_center as new_center,sum(ra.remitted) as remitted,sum(ra.refundamount) as refundamount,'
                     . 'DATE_FORMAT(ra.created_at,"%d-%m-%Y") as created_at,s.sname as sname,s.studid as studid ';
	$whereclause = 'ra.receiptno !="" and (ra.created_at between "'.$sdate.'" and "'.$edate.'")'.$where.' group by ra.receiptno order by cast(receiptno as unsigned) desc';
		
                        
       $query = $this ->db->query('select '.$selectquery.' from bscp_coursechange as ra LEFT JOIN bscp_student as s ON s.id=ra.studentid where '.$whereclause);
       $row = $query->result_array();
	if ($row) {
            for($i = 0;$i<count($row);$i++) {
                
                $rowArr[$i]['receiptno'] = $row[$i]['receiptno'];
                $rowArr[$i]['studid'] = $row[$i]['studid'];
                $rowArr[$i]['sname'] = $row[$i]['sname'];
                $rowArr[$i]['center'] = $row[$i]['center'];
                $rowArr[$i]['new_center'] = $row[$i]['new_center'];
                $rowArr[$i]['center'] = $row[$i]['center'];
                $rowArr[$i]['remitted'] = $row[$i]['remitted'];
                $rowArr[$i]['refundamount'] = $row[$i]['refundamount'];
                $rowArr[$i]['created_at'] = $row[$i]['created_at'];
                $rowArr[$i]['new_courseid'] = $row[$i]['new_courseid'];
                $rowArr[$i]['courseid'] = $row[$i]['courseid'];
                $rowArr[$i]['studentid'] = $row[$i]['studentid'];
                $rowArr[$i]['requestid'] = $row[$i]['requestid'];
                $rowArr[$i]['new_requestid'] = $row[$i]['new_requestid'];
                
                $q1 = $this ->db->query('select coursename,stream,type from admin_course where ide="'.$row[$i]['courseid'].'"');
                $row1 = $q1->result_array();
                $rowArr[$i]['fcoursename'] = $row1[0]['coursename'];
				$rowArr[$i]['fstream'] = $row1[0]['stream'];
				$rowArr[$i]['ftype'] = $row1[0]['type'];
                
                $q2 = $this ->db->query('select coursename,stream,type from admin_course where ide="'.$row[$i]['new_courseid'].'"');
                $row2 = $q2->result_array();
                $rowArr[$i]['tcoursename'] = $row2[0]['coursename'];
				$rowArr[$i]['tstream'] = $row2[0]['stream'];
				$rowArr[$i]['ttype'] = $row2[0]['type'];
                
            }
            
        } 
	  
        return $rowArr;
    }
    
       public function CenterChangeList($sdate,$edate,$center) {
        
       $where = ""; $courseArr = Array();
       
        if(($center !== "") && ($center !== "All")) { $where = " and center='".$center."' ";}
        
          $query1 = $this-> db -> query("select cr.batchname,cr.oldcenter,cr.approved,cr.ide,DATE_FORMAT(cr.requested_at,'%d-%m-%Y %h:%i %p') as rdate,c.coursename,c.stream as cstream,c.type,cr.center,s.studid,s.sname,s.contact,s.email "
                  . "from bscp_courserequest as cr,bscp_student as s,admin_course as c,"
                  . "admin_qualification as aq where cr.oldcenter !='' and cr.courseid=c.ide and cr.studentid=s.id "
                . "and (cr.approved_date between '".$sdate."' and '".$edate."')".$where);
       
        $row1 = $query1->result_array();
        if ($row1) {
            for($i = 0;$i<count($row1);$i++) {
                $ide = $row1[$i]['ide'];
                $courseArr[$ide]['coursename'] = $row1[$i]['coursename'];
		$courseArr[$ide]['cstream'] = $row1[$i]['cstream'];
		$courseArr[$ide]['type'] = $row1[$i]['type'];
                $courseArr[$ide]['center'] = $row1[$i]['center'];
                $courseArr[$ide]['oldcenter'] = $row1[$i]['oldcenter'];
                $courseArr[$ide]['studid'] = $row1[$i]['studid'];
                $courseArr[$ide]['sname'] = $row1[$i]['sname'];
                $courseArr[$ide]['contact'] = $row1[$i]['contact'];               
                $courseArr[$ide]['email'] = $row1[$i]['email'];
                $courseArr[$ide]['batchname'] = $row1[$i]['batchname'];
                $courseArr[$ide]['rdate'] = $row1[$i]['rdate'];
            
                
            }
        }
        
        return $courseArr;
    }
	
	public function WorldlineBillList($sdate,$edate,$center) {
        
         $courseArr = Array();
		
		$where = $where1 = "";$where2 = "";
		if(($center !== "") && ($center !== "All")){ 
			$where = " and sp.centers='".$center."' ";
			$where1 = " and fp.center='".$center."' ";
                        $where2 = " and centers='".$center."' ";
		}        
		
		$selectquery = 's.sname as name,s.studid,c.courseid,c.coursename,c.stream,c.type,sp.centers as center ,w.referenceNo,(w.amount/100) as paymentamount,w.transactiondatetime as paymentdate,w.statuscode,fp.receiptno,w.statusdesc,fp.paymentmode,w.orderid as referenceid,fp.studentid,fp.courseid as cid';
		
		$selectquery1 = 's.sname as name,s.studid,c.courseid,c.coursename,c.stream,c.type,fp.center,w.referenceNo is null,SUM(fp.total) as paymentamount,fp.paymentdate,w.statuscode is null,fp.receiptno,w.statusdesc is null,fp.paymentmode,fp.referenceid,fp.studentid,fp.courseid as cid';
		
		$query1 = $this ->db->query('select '.$selectquery.' from bscp_worldlinepg as w LEFT JOIN bscp_feepayments as fp ON fp.referenceid=w.orderid LEFT JOIN bscp_student_payments as sp ON sp.studentid=w.studentid and sp.courseid=w.courseid LEFT JOIN bscp_student as s ON s.id=w.studentid LEFT JOIN admin_course as c ON c.ide=w.courseid where (fp.referenceid <> "" or fp.referenceid is null) and (w.transactiondatetime between "'.$sdate.'" and "'.$edate.'") '.$where.' group by w.referenceNo
		UNION
		select '.$selectquery1.' from bscp_feepayments as fp LEFT JOIN bscp_worldlinepg as w ON w.orderid=fp.referenceid LEFT JOIN bscp_student_payments as sp ON sp.studentid=fp.studentid and sp.courseid=fp.courseid LEFT JOIN bscp_student as s ON s.id=fp.studentid LEFT JOIN admin_course as c ON c.ide=fp.courseid where fp.referenceid <> "" AND w.orderid is null AND fp.paymentstatus <> "p"  and (fp.paymentdate between "'.$sdate.'" and "'.$edate.'") '.$where1.' group by fp.referenceid
		order by paymentdate desc');          
       
        $row1 = $query1->result_array();
        if ($row1) {
            for($i = 0;$i<count($row1);$i++) {
				
				$paymentmode = $row1[$i]['paymentmode'];
				
				if((strcmp($paymentmode,"online")===0 && strcmp($paymentmode,"Online")!==0) || (strcmp($paymentmode,"online")!==0 && strcmp($paymentmode,"Online")!==0)) $receiptno = ""; else $receiptno = $row1[$i]['receiptno'];
				
				if($row1[$i]['referenceNo']=="1") $referenceNo = ""; else $referenceNo = $row1[$i]['referenceNo'];
				
				$paymentdate = date('j M Y h:i a',strtotime($row1[$i]['paymentdate']));
				
				if($row1[$i]['statuscode']=="F"){
					$statuscode = "Failed - ". $row1[$i]['statusdesc'];$receiptno = "";
				}else if($row1[$i]['statuscode']=="S"){
					$statuscode = "Success";
				}else{
					$statuscode = "Failed";$receiptno = "";
				}
				
				$courseArr[$i]['sname'] = $row1[$i]['name'];
                $courseArr[$i]['studid'] = $row1[$i]['studid'];
				$courseArr[$i]['coursename'] = $row1[$i]['coursename'];
				$courseArr[$i]['stream'] = $row1[$i]['stream'];
				$courseArr[$i]['type'] = $row1[$i]['type'];
				$courseArr[$i]['center'] = $row1[$i]['center'];
                $courseArr[$i]['referenceid'] = $row1[$i]['referenceid'];
                $courseArr[$i]['referenceNo'] = $referenceNo;
                $courseArr[$i]['paymentamount'] = $row1[$i]['paymentamount'];
                $courseArr[$i]['paymentdate'] = $paymentdate;
                $courseArr[$i]['statuscode'] = $statuscode;
                $courseArr[$i]['receiptno'] = $receiptno;
                
            }
        }
        
        return $courseArr;
    }
    
    public function Duelist($cname,$center,$batches) {
        
         $courseArr = Array();$where=$jointable="";
         if(($center !== "") && ($center !== "All")) { $where = " and a.centers='".$center."' ";}      
		
		 if(!empty($batches) && !in_array("All", $batches)){
			 $jointable = ",bscp_courserequest as cr";
			$where .= '  and b.id=cr.studentid and cr.batchname IN ("'.implode('","',$batches).'") and a.courseid=cr.courseid ';
		 }
		
         $query1 = $this-> db -> query('SELECT a.centers as center,a.courseid,a.studentid,GROUP_CONCAT(DISTINCT a.givenby) as givenby'
                 . ',GROUP_CONCAT(DISTINCT a.reason) as reason,GROUP_CONCAT(DISTINCT a.remarks) as remarks,'
                 . 'sum(a.amount) as atotal,sum(a.discount) as discount,sum(a.amount-a.discount) as wtobepaid,sum(a.total) as tobepaid,b.studid, a.requestid, '
                 . 'b.sname, c.coursename,c.stream,c.type, a.centers FROM bscp_student_payments as a,'
         . 'bscp_student as b, admin_course as c'.$jointable.' where b.id=a.studentid and c.ide=a.courseid and a.active="1" and'
                 . ' a.courseid="'.$cname.'" '.$where.'GROUP BY a.requestid');
     
       
        $row1 = $query1->result_array();
        if ($row1) {
            for($i = 0;$i<count($row1);$i++) {
                $courseArr[$i]['studid'] = $row1[$i]['studid'];
                $courseArr[$i]['sname'] = $row1[$i]['sname'];
                $ide = $row1[$i]['studentid'];
                $query41 = $this-> db -> query("select sp.mcode,sp.mobile,sp.fatherphone,sp.mothercode,sp.motherphone,sp.comments from bscp_studentprofile as sp where sp.stuid='".$ide."'");
                $row41 = $query41->result_array();
                if ($row41) {
                    $courseArr[$i]['mcode'] = $row41[0]['mcode'];
                    $courseArr[$i]['mobile'] = $row41[0]['mobile'];
                    $courseArr[$i]['fcountrycode'] = $row41[0]['fathercode'];
                    $courseArr[$i]['fatherphone'] = $row41[0]['fatherphone'];
                    $courseArr[$i]['mcountrycode'] = $row41[0]['mothercode'];
                    $courseArr[$i]['motherphone'] = $row41[0]['motherphone'];
                    $courseArr[$i]['comments'] = $row41[0]['comments'];
                    
                } else {
                    
                    $courseArr[$i]['fcountrycode'] ='';
                    $courseArr[$i]['fatherphone'] = '';
                    $courseArr[$i]['mcountrycode'] = '';
                    $courseArr[$i]['motherphone'] = '';
                    $courseArr[$i]['comments'] = '';
                    
                }
               
                $courseArr[$i]['coursename'] = $row1[$i]['coursename'];
                 $courseArr[$i]['stream'] = $row1[$i]['stream'];
                 $courseArr[$i]['type'] = $row1[$i]['type'];
                $courseArr[$i]['center'] = $row1[$i]['centers'];               
                $courseArr[$i]['discount'] = $row1[$i]['discount'];
                $courseArr[$i]['givenby'] = $row1[$i]['givenby'];
                $courseArr[$i]['reason'] = $row1[$i]['reason'];
                $courseArr[$i]['remarks'] = $row1[$i]['remarks'];
                $courseArr[$i]['tobepaid'] = $row1[$i]['wtobepaid'];
                $courseArr[$i]['atotal'] = $row1[$i]['atotal'];
    
                $tobepaidwgst = $row1[$i]['tobepaid'];
                $courseArr[$i]['total'] = "0"; $courseArr[$i]['totalw'] = "0";
                
                //total fee from course master
                $query42 = $this-> db -> query("select sum(amount-discount) as totalw,sum(total) as total from admin_group  where courseid='".$cname."' and centers='".$row1[$i]['center']."'");
                $row42 = $query42->result_array();
                if ($row42) {
                     $courseArr[$i]['total'] = round($row42[0]['total']);
                     $courseArr[$i]['totalw'] = round($row42[0]['totalw']);
                }
                
                $paid = 0;$kfadjust=0;$pamount=0;$paidtax= 0;
                 $q1 = $this ->db->query('select sum(amount - discount) as amount,sum(total) as total from bscp_feepayments where requestid="'.$row1[$i]['requestid'].'" and paymentstatus="p"');
                $row2 = $q1->result_array();
                if($row2){
                    $paid = $row2[0]['total'];
                    $pamount = $row2[0]['amount'];
                }
                
                $paidtax = floatval($paid) - floatval($pamount);
                
                $q11 = $this ->db->query('select sum(kfadjust) as kfadjust from bscp_feepayments where requestid="'.$row1[$i]['requestid'].'" and paymentstatus=""');
                $row12 = $q11->result_array();
                if($row12){
                    $kfadjust = $row12[0]['kfadjust']; 
                }
               
                
                $totaldue = floatval($tobepaidwgst)-floatval($paid);
                $sptottax=0;
                $q21 = $this ->db->query('select total,tax,kf from bscp_student_payments where requestid="'.$row1[$i]['requestid'].'" and active="1"');
                $row21 = $q21->result_array();
                if($row21){
                    for($j = 0;$j<count($row21);$j++) {
                       $gst = (($row21[$j]['tax'] === "") || ($row21[$j]['tax'] === "NA"))?0:$row21[$j]['tax'];
                       $kf = (($row21[$j]['kf'] === "") || ($row21[$j]['kf'] === "NA"))?0:$row21[$j]['kf'];    
                       $tottax = intVal($gst)+intVal($kf);
                       $calamount1 = floatval($row21[$j]['total'])*floatval($tottax);
                       $calamount1 = round($calamount1);

                       $divTax = 100+intVal($tottax);

                       $caltax = $calamount1 / $divTax;
                       $sptottax = $sptottax + round($caltax, 2);
                    }
                }
                
                             
                $finaltax = floatval($sptottax) -  floatval($paidtax);         
                $calamount = floatval($totaldue) - floatval($finaltax);
                $netdue = round($calamount);
                
                //kfaddjust only totaldue
                $totaldue = floatval($totaldue)-floatval($kfadjust);
                $courseArr[$i]['paid'] = $pamount;
                $courseArr[$i]['gst'] = round($finaltax,2);
                $courseArr[$i]['kfadjust'] = $kfadjust;
                $courseArr[$i]['netdue'] = $netdue;
                $courseArr[$i]['totaldue'] = $totaldue;
                
                // Course change from
		$courseArr[$i]['coursenamefrom'] ="";		
		$q2 = $this ->db->query('select coursename from bscp_coursechange as cc,admin_course as c  where c.ide=cc.courseid and cc.new_requestid="'.$row1[$i]['requestid'].'" ');
		$row5 = $q2->result_array();
		if ($q2->num_rows()>0) {
			$courseArr[$i]['coursenamefrom'] = $row5[0]['coursename'];                   
		}
                
            }
        }
        
        return $courseArr;
    }
    
    
    public function DiscountReport($sdate,$edate,$center) {
        
         $courseArr = Array();
          if(($center !== "") && ($center !== "All")) { $where = " and a.centers='".$center."' ";}               
         $query1 = $this-> db -> query('SELECT DATE_FORMAT(a.created_at,"%d-%m-%Y") as created_at,a.studentid,a.tax,a.kf,GROUP_CONCAT(DISTINCT a.givenby) as givenby'
                 . ',GROUP_CONCAT(DISTINCT a.reason) as reason,GROUP_CONCAT(DISTINCT a.remarks) as remarks,'
                 . 'sum(a.amount) as total,sum(a.discount) as discount,sum(a.total) as tobepaid,b.studid, a.requestid, '
                 . 'b.sname, c.coursename,c.stream,c.type, a.centers FROM bscp_student_payments as a,'
         . 'bscp_student as b, admin_course as c where b.id=a.studentid and c.ide=a.courseid'
                 . ' and (a.created_at between "'.$sdate.'" and "'.$edate.'") '.$where.'GROUP BY a.requestid');
     
       
        $row1 = $query1->result_array();
        if ($row1) {
            for($i = 0;$i<count($row1);$i++) {
                
                if(($row1[$i]['discount'] !== "0") && ($row1[$i]['discount'] !== "")){
                    $courseArr[$i]['studid'] = $row1[$i]['studid'];
                    $courseArr[$i]['sname'] = $row1[$i]['sname'];   
                    $courseArr[$i]['coursename'] = $row1[$i]['coursename'];   
                    $courseArr[$i]['stream'] = $row1[$i]['stream'];   
                    $courseArr[$i]['type'] = $row1[$i]['type'];
                    $courseArr[$i]['center'] = $row1[$i]['centers'];
                    $courseArr[$i]['total'] = round($row1[$i]['total']);
                    $courseArr[$i]['discount'] = $row1[$i]['discount'];
                    $courseArr[$i]['givenby'] = $row1[$i]['givenby'];
                    $courseArr[$i]['reason'] = $row1[$i]['reason'];
                    $courseArr[$i]['remarks'] = $row1[$i]['remarks'];
                    $courseArr[$i]['date'] = $row1[$i]['created_at'];
                }
                
            }
        }
        
        return $courseArr;
    }
    
    
    public function BulkPrintView($feesmaster,$feepaybill,$studid,$pname) {
        
        
         $htmlFinal = ''; $html = ''; 
         
         $tablepay = $tablepaynow = $ide = "";
	$sno = $psno = 1;

	$grandtotal = $grandtotalnow = $totalfee = $paidfee = $duefee = $discountfee = $discount = 0;

	$coursename = $center = $paymentmode = $paymentdate = $receiptno = "";
	$checkdiscount = false;

	foreach($feesmaster as $key=>$feemaster){
		
	foreach($feepaybill['feebilldetails'] as $paylist){
		
		if($feemaster['description'] == $paylist['description']){

		$amount = $paylist['amount'];
		$paymentamount = $paylist['paymentamount'];
		$total = $paylist['total'];
		$taxable = $paylist['taxable'];
		$paymentmode = $paylist['paymentmode'];
		$paymentdate = $paylist['paymentdate'];
		$receiptno = $paylist['receiptno'];
		$kf = $paylist['kf'];
		$cov = $paylist['cov'];
		$sac = 999293;
		
		if($paymentamount==0) continue;	
		
		//$thtaxable = '<th scope="col" width="10%">Taxable</th>';
		//$thnontaxable = '<th scope="col" width="10%">Non Taxable</th>';

		$discount = $paylist['discount'];
		$discountamt = 0;$thdiscount = "";$tddiscount = ""; $thtax = ""; $tdtax = "";
		$taxamt = 0;
		$colspan=9;
		
		$tax = $paylist['tax'];
		
		/*$amount1 = round($amount - ($amount * ($tax+$kf)/ (100+$tax+$kf)));
		if($amount==$amount1) $amount = $amount; else $amount = $amount1;*/
		
		$activetotalamt = $amount;	
                
		if(intval($discount)>0) {
							
			$discountamt = $discount;
			//$tddiscount = '<td width="10%">'.$discountamt.'</td>';

			$amount = $amount - $discount;

			$checkdiscount = true;
                        
                        $activetotalamt = $amount;

		}else{
			//$tddiscount = '<td>[DISCOUNT]</td>';
		}
		
		if($tax=="0" || $tax=="NA"){
			
			$tdnontaxable = $amount;
		}else{
			$tdnontaxable = 0;
		}
		
		if($tax!="0" && $tax!="NA"){ 
		
			$tdtaxable = $amount;				

			$taxgst = $tax/2;
			if(intval($tax)>0) $taxamt = $amount * ($tax/100);
			$taxamtgst = $taxamt/2;
			$taxamtgst = number_format($taxamtgst,2);
			
			//$colspan +=4;
			
		} else {
			$tdtaxable = 0;
			$taxgst = $taxamtgst = "NA";
		}
		
		$thtax = '<th scope="col" colspan="2" width="19%"><span class="thtax">CGST</span> <span class="thtaxvalue"><span>Rate %</span> <span>Amount</span></span></th>
			  <th scope="col" colspan="2" width="19%"><span class="thtax">SGST</span> <span class="thtaxvalue"><span>Rate %</span> <span>Amount</span></span></th>';

		$tdtax = '<td width="8%">'.$taxgst.'</td>
				  <td width="8%">'.$taxamtgst.'</td>
				  <td width="8%">'.$taxgst.'</td>
				  <td width="8%">'.$taxamtgst.'</td>';

		$nontaxvalue = $amount;
		$taxvalue = $amount + $taxamt;
		
		
		$kfamt = $amount * ($kf/100);
				
                			
		$tdkf = $thkf = "";	$colwidth = 15;
		if($kf!="" && $kf!="0"){

			$kfamt = $amount * ($kf/100);

			$thkf = '<th scope="col" width="8%">CESS KF(%)</th>
					 <th scope="col" width="8%">CESS KF Amount</th>';
			$tdkf = '<td width="12%">'.$kf.'</td>
					 <td width="8%">'.$kfamt.'</td>';

			$colspan += 2;
			$colwidth -= 5;
		}
                
		$grandtotal += $total;

		$tablepay .= '<tr>
					  <th scope="row" width="7%">'.$sno.'.</th>
					  <td width="15%"><strong>'.$paylist['description'].'</strong></td>
					  <td width="11%">'.$activetotalamt.'</td>
					  <td width="11%">'.$tdnontaxable.'</td>
					  <td width="11%">'.$tdtaxable.'</td>
					  '.$tddiscount.'
					  '.$tdtax.'
					  '.$tdkf.'
					  <td width="10%">'.number_format($total,2).'</td>
					</tr>';

		$sno++;
	}
		
	}
		
	}
         
         $html = '<div class="row feebill">
								
		<div class="card mb-2 p-4">
		
			<div class="row">
					
			<div class="col-md-6">
			
				<img src="'.base_url().'css/img/brilliant-logo.png" alt="Brilliant Pala Logo" class="mb-2" />
				
				<div class="mt-3"></div>
				
				<p>Receipt No. : <strong>'.$receiptno.'</strong></p>
				<p>Dated : <strong>'.date("d-m-Y h:i A",strtotime($paymentdate)).'</strong></p>
									
			</div>
			<div class="col-md-6 text-right">
				<h3>Brilliant Study Centre, Pala.</h3>
				<p>GSTIN: <strong>32AAEFB8385KIZ7</strong></p>
				<p>Mutholy, Puliyannoor PO, 686-573.</p>
				<p>Phone: 04822 206 100</p>
				<p>Email: admissions@brilliantpala.org</p>
			</div>
			
		
		</div>
			
			<div class="hr mt-1 mb-2"></div>
			
		<div class="row">
			
			<div class="col-md-6">
			
				<p>Student Id: <strong>'.$studid.'</strong></p>
				<p class="mb-0">Student: <strong>'.strtoupper($pname).'</strong></p>';
				
				if(!empty($feepaybill['studentdetails'])){
				
				$html .= '<div class="row">
					<div class="col-md-1"></div>
					<div class="col-md-6">
						<p>'.$feepaybill['studentdetails'][0]['housenameno']." ".$feepaybill['studentdetails'][0]['contactaddress'].", ".$feepaybill['studentdetails'][0]['contactpost'].", ".$feepaybill['studentdetails'][0]['contactdistrict'].", ".$feepaybill['studentdetails'][0]['contactstate'].", ".$feepaybill['studentdetails'][0]['contactcountry']." ".$feepaybill['studentdetails'][0]['contactpincode'].'.'.'</p>
					</div>
				</div>';
				
				 }
				
			$html .='</div>
			<div class="col-md-6 text-right">
				
				<p>Course:  <strong>['.$feepaybill['course'][0]['coursename'].','.$feepaybill['course'][0]['center'].']</strong></p>
				
			</div>
			
		</div>	
		
		<div class="row mb-2">
		
		 <table class="table">
              <thead>
                <tr>
                  <th scope="col" width="5%">Sl. no.</th>
                  <th scope="col" width="18%">Description</th>
                  <th scope="col" width="10%">Total Fee</th>
                  <th scope="col" width="'.$colwidth.'%">Non Taxable Value</th>
                  <th scope="col" width="'.$colwidth.'%">Taxable Value</th>'.$thdiscount.$thtax.$thkf.'
                  
                  <th scope="col" width="14%">Total</th>
                </tr>
              </thead>
              <tbody>'.$tablepay.'               
                <tr>
                  <td colspan="'.$colspan.'" class="totalamt">Grand total</td>
                  <td class="totalfee">'.number_format($grandtotal,2).'</td>
                </tr>
              </tbody>
            </table>
            
			</div>
          
           
			<p class="mb-2">Total Amount: <strong>Rs.'.number_format($grandtotal).'/- '.$this->getIndianCurrency($grandtotal).' Only)</strong></p>

			<p class="mb-2">Payment Mode: <strong>'.strtoupper($paymentmode).'</strong></p>

			<p class="mb-2">Remitted On: <strong>'.date("d-m-Y",strtotime($paymentdate)).'</strong></p>
            
            
            <div class="row d-flex align-items-end mt-3 mb-0">
			
			<div class="col-md-6">
			
				
			</div>
			<div class="col-md-6 text-right">
				
				<h4>Computer generated receipt</h4>
				
			</div>
			
		</div>

            
			</div>
			
		</div>
		
		<div class="mt-0 mb-2 w-100" style="border-bottom: 1px dashed #dee2e6!important;"></div>';
         
        // $htmlClone = '<div class="billclone">'.$html.'</div>';
         
         $htmlFinal = $html;
        
        return $htmlFinal;
    }
    
    public function getIndianCurrency(float $number)
    {
        $decimal = round($number - ($no = floor($number)), 2) * 100;
        $hundred = null;
        $digits_length = strlen($no);
        $i = 0;
        $str = array();
        $words = array(0 => '', 1 => 'one', 2 => 'two',
            3 => 'three', 4 => 'four', 5 => 'five', 6 => 'six',
            7 => 'seven', 8 => 'eight', 9 => 'nine',
            10 => 'ten', 11 => 'eleven', 12 => 'twelve',
            13 => 'thirteen', 14 => 'fourteen', 15 => 'fifteen',
            16 => 'sixteen', 17 => 'seventeen', 18 => 'eighteen',
            19 => 'nineteen', 20 => 'twenty', 30 => 'thirty',
            40 => 'forty', 50 => 'fifty', 60 => 'sixty',
            70 => 'seventy', 80 => 'eighty', 90 => 'ninety');
        $digits = array('', 'hundred','thousand','lakh', 'crore');
        while( $i < $digits_length ) {
            $divider = ($i == 2) ? 10 : 100;
            $number = floor($no % $divider);
            $no = floor($no / $divider);
            $i += $divider == 10 ? 1 : 2;
            if ($number) {
                $plural = (($counter = count($str)) && $number > 9) ? 's' : null;
                $hundred = ($counter == 1 && $str[0]) ? ' and ' : null;
                //$str [] = ($number < 21) ? $words[$number].' '. $digits[$counter]. $plural.' '.$hundred:$words[floor($number / 10) * 10].' '.$words[$number % 10]. ' '.$digits[$counter].$plural.' '.$hundred;
                            $str [] = ($number < 21) ? $words[$number].' '. $digits[$counter].' '.$hundred:$words[floor($number / 10) * 10].' '.$words[$number % 10]. ' '.$digits[$counter].' '.$hundred;
            } else $str[] = null;
        }
        $Rupees = implode('', array_reverse($str));
        $paise = ($decimal > 0) ? "." . ($words[$decimal / 10] . " " . $words[$decimal % 10]) . ' Paise' : '';
        //return ($Rupees ? $Rupees . 'Rupees ' : '') . $paise;
            return (ucwords($Rupees) ? ucwords($Rupees) : '') . ucwords($paise);
    }
   
}

?>
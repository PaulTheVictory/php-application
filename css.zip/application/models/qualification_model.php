<?php

Class Qualification_Model extends CI_Model {
    
     public function __construct() {
        
       $this->load->library('Datatables');
  		$this->load->helper('My_datatable_helper');
		 
    }
    
    public function GetQualificationLsts(){
        
          $arr = Array();
		
		$arr['list'] = "";
		
		$roleaccess = $this->config->item('roleaccess');
		
                //$this->datatables->set_database("default");
	    $this->datatables->select('admin_qualification.id,admin_qualification.name,admin_qualification.qualificationid,admin_qualification.qualification_year,admin_qualification.xii_qualification_year,admin_qualification.class,admin_qualification.created_at,admin_qualification.status,bscp_classstudy_master.csname') 
             ->edit_column('name', '$1', 'check_qlisteditname(id,name,"'.$roleaccess['Qualification'][1].'")')
            ->edit_column('qualificationid', '$1','qualificationid')
            ->edit_column('class', '<span class="qclass" data-xii-class="$2">$1</span>','class,xii_qualification_year')
            ->edit_column('qualification_year', '<span class="qyear" data-xii-year="$2">$1</span>','qualification_year,xii_qualification_year')
            ->edit_column('status', '$1', 'check_qlisteditstatus(id,status,"'.$roleaccess['Qualification'][1].'")')
            ->edit_column('id', '$1', 'check_qlisteditaction(id,"'.$roleaccess['Qualification'][1].'")')
             ->edit_column('created_at', '<a style="padding-left:10px;float:left;color:#0332AA;" class="noedit" href="javascript:void(0)">$1</a>', 'class') ->from('admin_qualification')->where("del","n")->join('bscp_classstudy_master', 'bscp_classstudy_master.id=admin_qualification.classstudy', 'left');
            
                
                $table =  $this->datatables->generate();
		
		return $table;
    
    }

    public function GetSubjects($ide) {
        
        $arr = Array();
		
	$arr['list'] = "";
		
                //$this->datatables->set_database("default");
	$this->datatables->select('id,stream,subject,rule,std,mark_type,mark_value')->from('admin_qualification_master')->where('std',$ide) ;
                
        $table =  $this->datatables->generate();
	
	return $table;
        
    }
    
    
     public function GetGradesX(){
        
        $ret = Array();
      
        $query2 = $this-> db -> query('select stream,mark_value from admin_qualification_master where mark_type="1" and std="X"');
	$row = $query2->result_array();
        if ($row) {
            for($i=0 ; $i < count($row);$i++) {
                $ret[$row[$i]["stream"]] = $row[$i]["mark_value"];
            }
        }
        
        return $ret;
     }
     
     public function GetGradesXII(){
        
        $ret = Array();
      
        $query2 = $this-> db -> query('select stream,mark_value from admin_qualification_master where mark_type="1" and std="XII"');
	$row = $query2->result_array();
        if ($row) {
            for($i=0 ; $i < count($row);$i++) {
                $ret[$row[$i]["stream"]] = $row[$i]["mark_value"];
            }
        }
        
        return $ret;
     }
   
    
    public function GetAllStreams($inpx,$inpxii){
        
        $ret = Array();
        $retHTML = "";
        $selectedx="";$selectedxii="";
        $query2 = $this-> db -> query('select stream,std from admin_qualification_master');
	$row = $query2->result_array();
        if ($row) {
            
                for($i=0 ; $i < count($row);$i++) {
                    
                    if( ($row[$i]["stream"] == $inpx ) && ($row[$i]["std"] === 'X')) {
                        $selectedx = 'checked';
                    }
                    
                    if( ($row[$i]["stream"] === $inpxii ) && ($row[$i]["std"] === 'XII')) {
                        $selectedxii ='checked';
                    }
                    
                 
                    $ret['X']   .=  ($row[$i]["std"] === 'X')?"<li ><label  style=\"text-align: left;color:#536485;background: none;border: 0px;width: auto;height: auto;float:left;font-size: 14px\"><input ".$selectedx." class=\"radiocenters\" attr-centers=\"".$row[$i]["stream"]."\" name=\"radiocenters\" type=\"radio\" />".$row[$i]["stream"]."</li></label>":"";
                    $ret['XII'] .=  ($row[$i]["std"] === 'XII')?"<li ><label style=\"text-align: left;color:#536485;background: none;border: 0px;width: auto;height: auto;float:left;font-size: 14px\"><input ".$selectedxii." class=\"radiocenters\" attr-centers=\"".$row[$i]["stream"]."\" name=\"radiocenters\" type=\"radio\" />".$row[$i]["stream"]."</li></label>":"";
                    $retHTML .= "<option ".$selected." >".$row[$i]["std"]."</option>";
                   $selectedx = "";$selectedxii = "";
                }
                
        }
        
        $ret["option"] = $retHTML;
  
        
        return $ret;
        
    }
    
     public function GetAllClasses(){
        
        $ret = Array();
        
        $query2 = $this-> db -> query('select classname from bscp_stdclass');
	$row = $query2->result_array();
        if ($row) {
            
                for($i=0 ; $i < count($row);$i++) {
                    
                    array_push($ret, $row[$i]['classname']);
                }
                
        }
        
        
        return $ret;
        
    }
    
    public function insertQualification($qData)
    {
        $this->db->insert('admin_qualification', $qData);
        return $this->db->insert_id();
    }
    
    public function insertQualification_x($qData)
    {
        $this->db->insert('admin_qualification_x', $qData);
        return $this->db->insert_id();
    }
    
    public function insertQualification_xii($qData)
    {
        $this->db->insert('admin_qualification_xii', $qData);
        return $this->db->insert_id();
    }
    
    public function updateQualification($qData)
    {
        $this->db->update('admin_qualification', $qData, array('id' => $qData['id']));
        
    }
    
     public function updateQualification_x($qData)
    {
         if($qData['id'] == "") {
             
             $qData['id'] = uniqid();
             $this->insertQualification_x($qData);
         } else {
             
            $this->db->update('admin_qualification_x', $qData, array('id' => $qData['id']));
            if($this->db->affected_rows() > 0) { return true; } else { return false;}
         }
       
    }
    
    public function updateQualification_xii($qData)
    {
        
         if($qData['id'] == "") {
            
             $qData['id'] = uniqid();
             $this->insertQualification_xii($qData);
         } else {
            
             $this->db->update('admin_qualification_xii', $qData, array('id' => $qData['id']));
             if($this->db->affected_rows() > 0) { return true; } else {  return false;}
         }
       
    }
    
 
        public function GetAllQualifications($inp){
        
        $retHTML = "";$selected= '';
         $query2 = $this-> db -> query('select name,id from admin_qualification where status="a" and del="n"');
	$row = $query2->result_array();
        if ($row) {
                $retHTML = '<option value= "">Select Qualification</option>';
                for($i=0 ; $i < count($row);$i++) {
                    if( ($row[$i]["id"] == $inp) || ((strpos($inp,$row[$i]["id"]) !== false))) {
                        $selected = ' selected=selected';
                    }
                    
                    $retHTML .= "<option value=".$row[$i]["id"]."$selected >".$row[$i]["name"]."</option>";
                   $selected = "";
                }
                
        }
        
        return $retHTML;
    }
    
    public function ViewQualification($ide) {
        
        $arr['general']='';$arr['general_x']='';$arr['general_xii']='';
                
        $query1 = $this-> db -> query('select qualificationid,entrance,entrance_rule,entrance_value,entrance_outofmark,name,qualification_rule ,qualification_year ,class ,gracemark,rollno,waitingresult,xii_flag,xii_qualification_rule ,xii_qualification_year ,xii_gracemark,xii_rollno,xii_waitingresult,marksheet_flag,marksheet_info,classstudy from admin_qualification  where id="'.$ide.'"');
	$row = $query1->result_array();
        if ($row) {
            
            $arr['general']=$row[0];
            

            $query2 = $this-> db -> query('select id,qrule as rule,year,class,rollno,gracemark,waiting as resultwaiting,completed as resultcompleted,stream,subject,rule as qrule,mark as qmark,grade as qgrade,outofmark,trule,total as mtotal from admin_qualification_x where  parentid="'.$ide.'"');
                $row1 = $query2->result_array();
                if ($row1) {
                    
                $arr['general_x']=$row1;
                

                }
            
            if($row[0]['xii_flag'] === '1') {
                
                $query3 = $this-> db -> query('select id,qrule as rule,year,class,rollno,gracemark,waiting as resultwaiting,completed as resultcompleted,stream,subject,rule as qrule,mark as qmark,grade as qgrade,outofmark,trule,total as mtotal from admin_qualification_xii  where  parentid="'.$ide.'"');
                $row2 = $query3->result_array();
                if ($row2) {
                    
                $arr['general_xii']=$row2;
                

                }
                
                
            }
            
        }
        
        return $arr;
        
    }
    
    
    public function StudentViewQualification($ide,$qmid) {
        
        $arr['general']='';$arr['general_x']='';$arr['general_xii']='';
                
        $query1 = $this-> db -> query('select qualificationid,entrance,entrance_outofmark,name,xii_flag,marksheet_flag,marksheet_info from admin_qualification  where id="'.$ide.'" and classstudy="'.$qmid.'"');
	$row = $query1->result_array();
        if ($row) {
            
            $arr['general']=$row[0];
            

            $query2 = $this-> db -> query('select id,class,rollno,gracemark,waiting as resultwaiting,completed as resultcompleted,stream,subject,outofmark from admin_qualification_x where  parentid="'.$ide.'"');
                $row1 = $query2->result_array();
                if ($row1) {
                    
                $arr['general_x']=$row1;
                

                }
            
            if($row[0]['xii_flag'] === '1') {
                
                $query3 = $this-> db -> query('select id,class,rollno,gracemark,waiting as resultwaiting,completed as resultcompleted,stream,subject,outofmark from admin_qualification_xii  where  parentid="'.$ide.'"');
                $row2 = $query3->result_array();
                if ($row2) {
                    
                $arr['general_xii']=$row2;
                

                }
                
                
            }
            
        }
        
        return $arr;
        
    }
    
    public function GetSelectedQualification($ide){
        
        $ret = '';
        $query2 = $this-> db -> query('select name from admin_qualification where id="'.$ide.'"');
	$row = $query2->result_array();
        if ($row) {
            
                for($i=0 ; $i < count($row);$i++) { $ret = $row[$i]['name'];}
        }
        
        return $ret;
    }
    
    
    public function GetSelectedSubject($x_ide,$xii_ide) {
        
        
        $arr['subject']= ""; $arr['xii_subject']= ""; 
        
        
        $query1 = $this-> db -> query('select a.subject from admin_qualification_x a  where  a.id="'.$x_ide.'"');
	$row = $query1->result_array();
        if ($row) {
            
            
            $arr['subject']=$row[0]['subject'];        
            $arr['xii_flag']= $row[0]['xii_flag'];
            
           
                
                $query2 = $this-> db -> query('select a.subject from admin_qualification_xii a  where  a.id="'.$xii_ide.'"');
                $row = $query2->result_array();
                if ($row) {                                    
                $arr['xii_subject']=$row[0]['subject'];                                

                }
                
           
    
            
        }
        
        return $arr;
        
    }
    
     public function ViewCourseRequest($ide){
                      
        
        $query1 = $this-> db -> query('select * from bscp_courserequest  where  ide="'.$ide.'"');
	$row = $query1->result_array();
        if ($row) {
            
            $arr = $row;
        } else {
            
            $arr = '';
        }
        
        return $arr;
        
    }
    
    
    public function GetStudentName($ide){
                      
        
        $query1 = $this-> db -> query('select sname,studid from bscp_student  where  id="'.$ide.'"');
	$row = $query1->result_array();
        if ($row) {
            
            $arr = $row[0];
        } else {
            
            $arr = '';
        }
        
        return $arr;
        
    }
    
        public function ViewStudentQualification($ide){
                      
        
        $query1 = $this-> db -> query('select * from bscp_courserequest  where  ide="'.$ide.'"');
	$row = $query1->result_array();
        if ($row) {
            
            $arr = $row;
        } else {
            
            $arr = '';
        }
        
        return $arr;
        
    }
    
    public function GetCoursenoQualification($ide){
                      
        
        $query1 = $this-> db -> query('select courseid from admin_course  where  ide="'.$ide.'"');
		$row = $query1->result_array();
        if ($query1->num_rows()>0) {
            
            $arr = $row[0]['courseid'];
        } else {
            
            $arr = '';
        }
        
        return $arr;
        
    }
	
    
    public function GetGradeValue($type,$stream){
        
         $arr = Array("");
        $query1 = $this-> db -> query('select mark_value,grade_value from admin_qualification_master  where  stream="'.$stream.'" and std="'.$type.'" and mark_type="1"');
	$row = $query1->result_array();
        if ($row) {
            
            $grade = explode("|",$row[0]['mark_value']);
            $gradevalue = explode("|",$row[0]['grade_value']);
            
            for($i=0;$i< count($grade);$i++){
                if($grade[$i] === '') { continue;}
                $arr[$grade[$i]] = $gradevalue[$i];
            }
        } 
        
        return $arr;
        
    }
    
    public function CheckQualificationRequest($courseide,$userid)
    {
        
        $arr = '';
        $query1 = $this-> db -> query('select ide from bscp_courserequest  where  courseid="'.$courseide.'" and studentid="'.$userid.'"');
	$row = $query1->result_array();
        if ($row) {
            
            $arr = $row[0]['ide'];
        } 
        
        return $arr;
       
    }
    
    
    public function VerifyQualification($ide,$x_qid,$xii_qid) {
        
        $arr['general']='';$arr['general_x']='';$arr['general_xii']='';
                
        $query1 = $this-> db -> query('select entrance,entrance_rule,entrance_value,name,qualification_rule ,qualification_year ,class ,gracemark,rollno,waitingresult,xii_flag,xii_qualification_rule ,xii_qualification_year ,xii_gracemark,xii_rollno,xii_waitingresult,marksheet_flag,marksheet_info from admin_qualification  where id="'.$ide.'"');
	$row = $query1->result_array();
        if ($row) {
            
            $arr['general']=$row[0];
            
            $query2 = $this-> db -> query('select * from admin_qualification_x a  where  a.id="'.$x_qid.'"');
                $row1 = $query2->result_array();
                if ($row1) {
                    
                $arr['general_x']=$row1[0];
                

                }
            
            if($row[0]['xii_flag'] === '1') {
                
                $query3 = $this-> db -> query('select * from admin_qualification_xii a  where  a.id="'.$xii_qid.'"');
                $row2 = $query3->result_array();
                if ($row2) {
                    
                $arr['general_xii']=$row2[0];
                

                }
                
                
            }
            
        }
        
        return $arr;
        
    }
    
    
    public function GetStudentQualificationLsts($ide){
        
                      
                
				$this->load->helper('My_datatable_helper');
		
				$web_url = $this->config->item('web_url');
		
                $this->datatables->select('admin_course.coursename as cname,bscp_courserequest.ide as id,admin_qualification.name as name,bscp_courserequest.requested_at as created_at,bscp_courserequest.status,bscp_courserequest.xii_status,bscp_courserequest.approved,bscp_courserequest.entrance_name as entrance_name') 
                    ->edit_column('name', '$1', 'check_qualifynameedit(id,name,status,xii_status,approved,entrance_name,"'.base_url().'","'.$web_url.'")')
            ->edit_column('id', '$1', 'check_qualifyedit(id,status,xii_status,approved,entrance_name,"'.base_url().'","'.$web_url.'")')
                    ->from('bscp_courserequest')
                        ->join('admin_course', 'admin_course.ide=bscp_courserequest.courseid', 'left')
                    ->join('admin_qualification', 'admin_qualification.id=bscp_courserequest.qualificationid', 'left')
					->where('studentid',$ide);
            
               /* '<a class="noedit" id="$1" href="'.base_url().'stuqualifyupdate?ide=$1&type=edit"><img style="padding:5px 10px" src="'.$this->config->item('web_url')."images/edit.png".'"></a>-->'
                    . '<!--a class="del noedit" id="$1" href="javascript:void(0)"><img style="padding:5px 10px" src="'.$this->config->item('web_url')."images/delete.png".'"></a-->'
                    . '*/
					
                $table =  $this->datatables->generate();
		
		return $table;
    
    }
    
       
    public function UpdateStuQualification($ide,$userid){
        
        $query1 = $this-> db -> query('update `typo_users` set qualification="'.$ide.'" where id="'.$userid.'"');
        
        $query2 = $this-> db -> query('update `bscp_student` set qualification="'.$ide.'" where id="'.$userid.'"');
        
        if($query1 && $query2) {
                $response = array(
                'status' => 'success',
                'message' => "Qualification Updated Successfully."
            );
            } else {
                $response = array(
                'status' => 'fail',
                'message' => "Error!!! Qualification Not Updated."
            );
            }
            
        return $response;         
        
    }
    
    public function ChangeCourseStatus($ide,$status){
        
        $query1 = $this-> db -> query('update `admin_qualification` set status="'.$status.'" where id="'.$ide.'"');
        if($query1) {
            $result = array(0 => "success");
        } else {
            $result = array(0 => "fail");
        }
        
        return $result; 
        
        
    }
    
    
    public function QualificationOffset() {
        
        
        $countadd = 1;
	$queryM = $this->db->query('SELECT max(qualificationid) as qid FROM `admin_qualification` WHERE 1 ');
        $rowM = $queryM->result_array();
        $count = $countadd + $rowM[0]['qid'];
        return $count; 	
        
    }
    
    
    public function DelQualification($ide){
        
        $query1 = $this-> db -> query('update `admin_qualification` set del="y" where id="'.$ide.'"');
        if($query1) {
            $result = array(0 => "success");
        } else {
            $result = array(0 => "fail");
        }
        
        return $result; 
        
        
    }
	
	
	// Class Studying Master
	
	public function GetAllClassstudyMaster($inp){
        
        $retHTML = "";$selected= '';
         $query2 = $this-> db -> query('select csname,id from bscp_classstudy_master where status="a"');
	$row = $query2->result_array();
        if ($row) {
                $retHTML = '<option value= "">Select Class Studying</option>';
                for($i=0 ; $i < count($row);$i++) {
                    if( ($row[$i]["id"] == $inp) || ((strpos($inp,$row[$i]["id"]) !== false))) {
                        $selected = ' selected=selected';
                    }
                    
                    $retHTML .= "<option value=".$row[$i]["id"]."$selected >".$row[$i]["csname"]."</option>";
                   $selected = "";
                }
                
        }
        
        return $retHTML;
    }
	
	
	
	public function GetAllActiveClassstudyMaster($inp){
        
        $retHTML = "";$selected= '';
         $query2 = $this-> db -> query('select distinct cs.csname,cs.id from bscp_classstudy_master as cs,admin_qualification as q where cs.id=q.classstudy and cs.status="a" and q.status="a" and q.del="n"');
	$row = $query2->result_array();
        if ($row) {
                $retHTML = '<option value= "">Select Class Studying</option>';
                for($i=0 ; $i < count($row);$i++) {
                    if( ($row[$i]["id"] == $inp) || ((strpos($inp,$row[$i]["id"]) !== false))) {
                        $selected = ' selected=selected';
                    }
                    
                    $retHTML .= "<option value=".$row[$i]["id"]."$selected >".$row[$i]["csname"]."</option>";
                   $selected = "";
                }
                
        }
        
        return $retHTML;
    }
	
	public function GetAllClassMasterQualifications($classstudyid){
        
        $retHTML = "";$selected= '';
		
		if($classstudyid!=""){
		
			$query2 = $this-> db -> query('select name,id from admin_qualification where classstudy="'.$classstudyid.'" and status="a" and del="n"');
			$row = $query2->result_array();
			if ($row) {
					$retHTML = '<option value= "">Select Qualification</option>';
					for($i=0 ; $i < count($row);$i++) {
						if( ($row[$i]["id"] == $inp) || ((strpos($inp,$row[$i]["id"]) !== false))) {
							$selected = ' selected=selected';
						}

						$retHTML .= "<option value=".$row[$i]["id"]."$selected >".$row[$i]["name"]."</option>";
					   $selected = "";
					}

			}
			
		}
        
        return $retHTML;
    }
	
		
	public function InsertClassstudyMaster($qData)
    {
        $this->db->insert('bscp_classstudy_master', $qData);
        return $this->db->insert_id();
    }
    
	public function UpdateClassstudyMaster($qData)
    {
        $this->db->update('bscp_classstudy_master', $qData, array('id' => $qData['id']));
        
    }
	
      public function GetClassstudyMaster(){
        
		  $roleaccess = $this->config->item('roleaccess');
		  
    	    $this->datatables->select('created_at,csname,id') 
            ->edit_column('id', '$1', 'check_csmastereditdel(id,csname,"'.$roleaccess['Class Study Master'][2].'","'.$roleaccess['Class Study Master'][2].'")')
            ->edit_column('csname', '<span>$1</a>', 'csname')
            ->edit_column('created_at', '<p class="sno"></p>', '')
            ->from('bscp_classstudy_master');
            
            $table =  $this->datatables->generate();
            return $table;
    
    }
    
      public function DelClassstudyMaster($ide){
        
		  $result = array(0 => "");
		  
		 if($ide!=""){
			  
			$query1 = $this-> db -> query('delete from `bscp_classstudy_master` where id="'.$ide.'"');
			if($query1) {
				$this-> db -> query('update admin_qualification set classstudy="" where classstudy="'.$ide.'"');
				$result = array(0 => "success");
			} else {
				$result = array(0 => "fail");
			}
        
		 }
		  
        return $result; 
        
        
    }

}

?>
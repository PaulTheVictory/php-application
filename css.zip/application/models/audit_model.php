<?php

Class Audit_Model extends CI_Model {
    
     public function __construct() {
        
       //$this->load->library('Datatables');
  
    }

     public function GetLogs($sdate,$edate,$user,$type) {
        
       $courseArr = Array();
       $moduleArr = ['Courses'=>'admin_course',"Qualification"=>'admin_qualification',
                    "First Qualification"=>'admin_qualification_x',"Second Qualification"=>'admin_qualification_xii',
                    "Admission Request"=>'bscp_courserequest',"Student Profile"=>'bscp_studentprofile',
                    "Student Fee Structure"=>'bscp_student_payments',
                    "Student Payments"=>'bscp_feepayments',"User Group"=>'typo_groups',
           "Location"=>'typo_unit',"City"=>'bscp_cities',
           "Center"=>'bscp_centers',"Branch"=>'bscp_ccenters'];
                
        $where = "";
        if(($user !== "All") && ($type !== "All")) { $where = " user_id='".$user."'and table_name='".$moduleArr[$type]."' and ";}
        if(($user !== "All") && ($type === "All")) { $where = " user_id='".$user."' and ";}
        if(($user === "All") && ($type !== "All")) { $where = " table_name='".$moduleArr[$type]."' and ";}
        if(($user === "") && ($type === "")) { $where = "";}
        if(($user !== "") && ($type === "")) { $where = " user_id='".$user."' and ";}
        if(($user === "") && ($type !== "")) { $where = " table_name='".$moduleArr[$type]."' and ";}
        
        $query0 = $this-> db -> query('select * from bscp_audit_trails where '.$where.' (created_at between "'.$sdate.'" and "'.$edate.'")');
        $row = $query0->result_array();
            if ($row) {
               for($i = 0;$i<count($row);$i++) {
                   
                   $ret = $this->GetUserDefinedLogs($row[$i],$moduleArr);
                   $courseArr[$i] = $ret;
                }
            }
            
        return $courseArr;
     }
     
     
     public function GetUserDefinedLogs($logArr,$moduleArr) {
         
       $ret['desc'] = array_search ($logArr['table_name'], $moduleArr);
       $ret['username'] = $logArr['user_id'];
       $ret['ipaddress'] = $logArr['ip_address'];
       $ret['date'] = $logArr['created_at'];
       $event = $logArr['event'];

        $ojson = $logArr['old_values'];
        $njson = $logArr['new_values'];

        $old_value = json_decode($ojson,true);
        $new_value = json_decode($njson,true);
        $tablename = $logArr['table_name'];

       if($event === 'update'){
           $this->diff_on_update($old_value, $new_value,$tablename);
       }
       
       $ret['new'] = "";$ret['old'] = "";
       foreach($new_value as $key => $val) {
           if(($key === "created_at")||($key === "updated_at") ||($key === "requestid") || ($val === "")) {continue;}
           
           if(($key === "courseid")&&($tablename !== "admin_course")) {
                $cid=$this->GetCourseDetails($val);
                $old_value[$key] = $cid;
                $val= $cid;
            }
            
            if(($key === "studentid")&&($tablename !== "admin_course")) {
                $cid=$this->GetStudentDetails($val);
                $old_value[$key] = $cid;
                $val= $cid;
            }
       
            $old_value[$key] = ltrim($old_value[$key], '|');
            $val = ltrim($val, '|');
            
           $ret['old'] .="<div><p style=\"margin:0px;padding:0px;text-align:left\">".$key." : ".str_replace("|",",",$old_value[$key])."</p></div>";
           $ret['new'] .="<div><p style=\"margin:0px;padding:0px;text-align:left\">".$key." : ".str_replace("|",",",$val)."</p></div>";
       }
       
                   
       return $ret;  
       
     }


     public function diff_on_update(&$old_value, &$new_value,$tablename)
    {
        $old = [];
        $new = [];
        foreach($new_value as $key => $val) {
            $key = trim($key);
            if(isset($new_value[$key])) {
                if(isset($old_value[$key])) {
                    if($new_value[$key] != $old_value[$key]) {
                        $old[$key] = $old_value[$key];
                        $new[$key] = $new_value[$key];
                    }else if(($key === "ide")&&($tablename === "admin_course")) {
                        $cid=$this->GetCourseDetails($new_value[$key]);
                        $old['course_id'] = $cid;
                        $new['course_id'] = $cid;
                    }else if(($key === "ide")&&($tablename === "bscp_courserequest")) {
                        $cid=$this->GetCourseRequestDetails($new_value[$key]);
                        $old['course_id'] = $cid['cid'];
                        $new['course_id'] = $cid['cid'];
                        $old['student_id'] = $cid['sid'];
                        $new['student_id'] = $cid['sid'];
                    }else if(($key === "id")&&($tablename === "bscp_feepayments")) {
                        $cid=$this->GetFeePaymentDetails($new_value[$key]);
                        $old['course_id'] = $cid['cid'];
                        $new['course_id'] = $cid['cid'];
                        $old['student_id'] = $cid['sid'];
                        $new['student_id'] = $cid['sid'];
                    }else if(($key === "id")&&($tablename === "bscp_student_payments")) {
                        $cid=$this->GetStudentFeePaymentDetails($new_value[$key]);
                        $old['course_id'] = $cid['cid'];
                        $new['course_id'] = $cid['cid'];
                        $old['student_id'] = $cid['sid'];
                        $new['student_id'] = $cid['sid'];
                        $old['fees'] = $cid['desc'];
                        $new['fees'] = $cid['desc'];
                    }else if(($key === "stuid")&&($tablename === "bscp_studentprofile")) {
                        $cid = $this->GetStudentDetails($new_value[$key]);                    
                        $old['student_id'] = $cid;
                        $new['student_id'] = $cid;
                    }else if(($key === "id")&&($tablename === "admin_qualification")) {
                        $cid=$this->GetQualificationDetails($new_value[$key]);
                        $old['qualification_name'] = $cid['cid'];
                        $new['qualification_name'] = $cid['cid'];
                       
                    }else if(($key === "parentid")&&($tablename === "admin_qualification_x"))  {
                        $cid=$this->GetFQualificationDetails($new_value[$key]);
                         $old['qualification_name'] = $cid['cid'];
                        $new['qualification_name'] = $cid['cid'];
                        $old['qualification_stream'] = $cid['sid'];
                        $new['qualification_stream'] = $cid['sid'];
                    }else if(($key === "parentid")&&($tablename === "admin_qualification_xii")) {
                        $cid=$this->GetSQualificationDetails($new_value[$key]);
                        $old['qualification_name'] = $cid['cid'];
                        $new['qualification_name'] = $cid['cid'];
                        $old['qualification_stream'] = $cid['sid'];
                        $new['qualification_stream'] = $cid['sid'];
                    }
                } else {
                     $old[$key] = '';
                     $new[$key] = $new_value[$key];
                }
                
            }
        }

        $old_value = $old;
        $new_value = $new;
    }
    
    
    public function GetQualificationDetails($ide) {
        
       $ret['cid']="";
       $query0 = $this-> db -> query('select name from admin_qualification where id="'.$ide.'"');
       $row = $query0->result_array();
       if ($row) {
          $ret['cid'] = $row[0]['name'];
           
       } 
        
       return $ret;
    }
    
     public function GetFQualificationDetails($ide) {
        
        $ret['sid']="";$ret['cid']="";
       $query0 = $this-> db -> query('select c.name as name,cr.stream as stream from admin_qualification_x as cr,admin_qualification as c where c.id=cr.parentid and cr.parentid="'.$ide.'"');
        $row = $query0->result_array();
        if ($row) {
           $ret['cid'] = $row[0]['name'];
           $ret['sid'] = $row[0]['stream'];
        } 
        
        return $ret;
    }
    
    public function GetSQualificationDetails($ide) {
        
        $ret['sid']="";$ret['cid']="";
       $query0 = $this-> db -> query('select c.name as name,cr.stream as stream from admin_qualification_xii as cr,admin_qualification as c where c.id=cr.parentid and cr.parentid="'.$ide.'"');
        $row = $query0->result_array();
        if ($row) {
           $ret['cid'] = $row[0]['name'];
           $ret['sid'] = $row[0]['stream'];
        } 
        
        return $ret;
    }
    
    public function GetCourseRequestDetails($ide) {
        
        $ret['sid']="";$ret['cid']="";
       $query0 = $this-> db -> query('select c.coursename as coursename,c.courseid as courseid,b.studid as studid,b.sname as sname from bscp_courserequest as cr,admin_course as c,bscp_student as b where b.id=cr.studentid and c.ide=cr.courseid and cr.ide="'.$ide.'"');
        $row = $query0->result_array();
        if ($row) {
           $ret['cid'] = $row[0]['courseid']." (".$row[0]['coursename'].")";
           $ret['sid'] = $row[0]['studid']." (".$row[0]['sname'].")";
        } 
        
        return $ret;
    }
    
    public function GetFeePaymentDetails($ide) {
        
        $ret['sid']="";$ret['cid']="";
       $query0 = $this-> db -> query('select c.coursename as coursename,c.courseid as courseid,b.studid as studid,b.sname as sname from bscp_feepayments as cr,admin_course as c,bscp_student as b where b.id=cr.studentid and c.ide=cr.courseid and cr.id="'.$ide.'"');
        $row = $query0->result_array();
        if ($row) {
           $ret['cid'] = $row[0]['courseid']." (".$row[0]['coursename'].")";
           $ret['sid'] = $row[0]['studid']." (".$row[0]['sname'].")";
        } 
        
        return $ret;
    }
    
      public function GetStudentFeePaymentDetails($ide) {
        
        $ret['sid']="";$ret['cid']="";
       $query0 = $this-> db -> query('select c.coursename as coursename,c.courseid as courseid,b.studid as studid,b.sname as sname,cr.description as description from bscp_student_payments as cr,admin_course as c,bscp_student as b where b.id=cr.studentid and c.ide=cr.courseid and cr.id="'.$ide.'"');
        $row = $query0->result_array();
        if ($row) {
           $ret['cid'] = $row[0]['courseid']." (".$row[0]['coursename'].")";
           $ret['sid'] = $row[0]['studid']." (".$row[0]['sname'].")";
           $ret['desc'] = $row[0]['description'];
        } 
        
        return $ret;
    }
    
    public function GetCourseDetails($ide) {
        
        $ret="";
       $query0 = $this-> db -> query('select courseid,coursename from admin_course where ide="'.$ide.'"');
        $row = $query0->result_array();
        if ($row) {
           $ret = $row[0]['courseid']." (".$row[0]['coursename'].")";
        } 
        
        return $ret;
    }


     public function GetStudentDetails($ide) {
         
         $ret="";
       $query0 = $this-> db -> query('select studid,sname from bscp_student where id="'.$ide.'"');
        $row = $query0->result_array();
        if ($row) {
           $ret = $row[0]['studid']." (".$row[0]['sname'].")";
        } 
        return $ret;
    }


    public function GetAllUsers($inp) {
         
           $retHTML = "";
  
         $query2 = $this-> db -> query('select username from typo_users where role !="student"');
	$row = $query2->result_array();
        if ($row) {
            
                $cenArr = explode("|",$inp);
                for($i=0 ; $i < count($row);$i++) {
                    if( ($row[$i]["username"] == $inp) || (in_array($row[$i]["unit"],$cenArr))) {
                        $selected = 'selected=selected';
                    }
                    $retHTML .= "<option ".$selected.">".$row[$i]["username"]."</option>";                    
                   $selected = "";
                }
                
        }
        
        return $retHTML;
         
     }
   
   
}

?>
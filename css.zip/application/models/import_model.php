<?php

Class Import_Model extends CI_Model {
    
     public function __construct() {
        
       //$this->load->library('Datatables');
  
    }
	
	
	// Start Import New Admission
	
	
	public function getStudentno($studentno){
		
		$studid = $sname = "";
		
		$query = $this-> db -> query('select id,sname from bscp_student where studid='.$studentno);
		$row = $query->result_array();

		if ($query->num_rows() === 1) {
			$studid = $row[0]["id"];
			$sname = $row[0]["sname"];
		}
		
		return $studid."-".$sname;
		
	}
	
	
	public function getcourseid($courseid,$center){
			 
	 	  $courseide = $centers = $qualification = $coursename = "";
			  			  
		  $query = $this-> db -> query("select ide,centers,qualification,coursename from admin_course where courseid=$courseid");
		  $row = $query->result_array();

		  if($query->num_rows() > 0){
			  $courseide = $row[0]['ide'];
			  $centers = $row[0]['centers'];
			  $qualification = $row[0]['qualification'];
			  $coursename = $row[0]['coursename'];
		  }
			  
	
		return $courseide."-".$centers."-".$qualification."-".$coursename;
		
	}
	
	
	public function getcentername($centerid){
		
		$centername = "";
		
		$query = $this-> db -> query('select unit from typo_unit where sno='.$centerid);
		$row = $query->result_array();

		if ($query->num_rows() === 1) {
			$centername = $row[0]["unit"];			
		}
		
		return $centername;
		
	}
	
	
	public function getcourserequestid($studentno,$courseno,$studid,$courseid,$center,$qid){
	  
		
	  $cride = "";
		
	  $offset=5*60*60 + 30*60;
	  $dateformat = 'Y-m-d H:i:s';
	  $curtime = gmdate($dateformat, time()+$offset);
		  
		$query = $this-> db -> query("select ide from bscp_courserequest where studentid='".$studid."' and courseid='".$courseid."'");
	  	$row = $query->result_array();
	    if($query->num_rows()>0){

			$cride = $row[0]['ide'];
			
	    }else{
			
			$cride = uniqid();
			
			$query1 = $this-> db -> query("INSERT INTO `bscp_courserequest`(`ide`, `studentid`, `courseid`, `qualificationid`, `yearofpassing`, `class`, `stream`, `status`, `gracemark`, `rollno`, `grade`, `mark`, `mark_total`, `subject`, `xii_yearofpassing`, `xii_status`, `xii_stream`, `xii_gracemark`, `xii_rollno`, `xii_grade`, `xii_mark`, `xii_mark_total`, `xii_subject`, `approved`, `approved_date`, `center`, `total`, `x_qid`, `xii_qid`, `entrance_name`, `entrance_mark`, `aq1`, `aq2`, `aq3`, `entrance_regno`, `requested_at`) VALUES ('".$cride."','".$studid."','".$courseid."','".$qid."','','','','','','','','','','','','','','','','','','','','y','".$curtime."','".$center."','','','','','','','','','','".$curtime."')");
			
			if(!$query1){ $cride = "";}
		}
	
		return $cride;
	
	}
	
	
	public function checkcoursegroupimport($courseid,$basecenter){
				
		$query = $this-> db -> query("select * from admin_group where courseid='".$courseid."' and centers='".$basecenter."'");
		$row = $query->result_array();
		
		 if($query->num_rows()>0){
			 
			 return true;
			 
		 }
		
		 return false;
		
	}
	
	
	public function insertcoursegroupimport($studentno,$courseno,$courseid,$basecenter,$studid,$requestid){
		
		$result = array();
		
		$result['message'] = "";
		$result['checkexists'] = false;
		
		$query = $this-> db -> query("select * from admin_group where courseid='".$courseid."' and centers='".$basecenter."'");
		$row = $query->result_array();
		
		 if($query->num_rows()>0){
			 
		  $offset=5*60*60 + 30*60;
		  $dateformat = 'Y-m-d H:i:s';
		  $curtime = gmdate($dateformat, time()+$offset);
	
		$descArray['Registration Charges'] = 1;$descArray['Caution Deposit'] = 2;
		$descArray['Screening Test Registration Charges'] = 3;$descArray['Tuition Fee'] = 4;
		$descArray['Tuition Fee - 1'] = 5;$descArray['Tuition Fee - 2'] = 6;
	
			 
		$challanno = ""; $countadd = 1;
		$query0 = $this-> db -> query('select distinct challanno from bscp_feepayments where studentid="'.$studid.'"');
		$count = $query0->num_rows();
		$count = $countadd + $count;
		$count = str_pad($count, 2, '0', STR_PAD_LEFT);
		$challanno = "C".$count;
			 
			 
	$query0 = $this-> db -> query("select id from bscp_student_payments where courseid='".$courseid."' and studentid='".$studid."' and requestid='".$requestid."'");

	if($query0->num_rows() === 0){
					
		foreach($row as $acrow){
						 			 
					$stupayid = uniqid();

					$amount1 = $acrow['amount'];
					$total1 = $acrow['total'];

					$decs_Order = (array_key_exists($acrow['description'], $descArray))?$descArray[$acrow['description']]:1;

					$query = $this-> db -> query("INSERT INTO `bscp_student_payments`(`id`, `requestid`, `description`, `sac`, `amount`, `givenby`, `reason`, `discount`, `tax`, `kf`, `cov`, `courseid`, `centers`, `taxable`, `total`, `studentid`, `active`, `split`, `created_at`, `desc_order`) VALUES ('".$stupayid."','".$requestid."','".$acrow['description']."','".$acrow['sac']."','".$amount1."','','','".$acrow['discount']."','".$acrow['tax']."','".$acrow['kf']."','0','".$courseid."','".$acrow['centers']."','0','".$total1."','".$studid."','".$acrow['active']."','".$acrow['split']."','".$curtime."','".$decs_Order."')");
			  
				  if(!$query){
					  $result['message'] .=  "<p class='fail'>Fail Fee Structure Description: ".$acrow['description']."</p>";

				  }else if($acrow['active']=="1"){

					$stid = uniqid();

					$query1 = $this-> db -> query("INSERT INTO `bscp_feepayments`(`id`, `requestid`, `stupayid`, `studentid`, `courseid`, `receiptno`, `center`, `challanno`, `amount`, `discount`, `tax`, `kf`, `cov`, `roundoff`, `total`, `dueamt`, `paymode`, `paydescription`, `paymentamount`, `paymentmode`, `paymentstatus`, `paymentdate`, `status`, `created_at`) VALUES ('".$stid."','".$requestid."','".$stupayid."','".$studid."','".$courseid."','','".$acrow['centers']."','".$challanno."','".$amount1."','0','".$acrow['tax']."','".$acrow['kf']."','0','0','".$total1."',0,'','',0,'','','".$curtime."','','".$curtime."')"); 

					 if(!$query1){
						$result['message'] .= "<p class='fail'>Fail Fee Payments Description: ".$acrow['description']." Stu Pay ID: ".$stupayid."</p>";
					 }
					  
					 //$result['message'] .= "<p class='success'>Insert Fee Structure Request ID: ".$requestid." Stu Pay ID: ".$stupayid."</p>"; 
					  
			  	}
			
			
			}
				
		return $result;
		
		}else{
					
			//$result['message'] = "<p class='exists'>Already Fee Structure exists</p>";
			$result['checkexists'] = true;
		}

			 
		}
		
		return $result;
		
	}
	
	
	function insertpartialpaymentimport($studentno,$courseno,$requestid,$studid,$courseid,$partialamount){
		
		
		$query = $this-> db -> query("select id from bscp_partialpayments where courseid='".$courseid."' and studentid='".$studid."' and requestid='".$requestid."' and status='a'");
		$row = $query->result_array();

		if($query->num_rows() === 0){
					
		  $stupartialid = uniqid();
			  
		  $offset=5*60*60 + 30*60;
		  $dateformat = 'Y-m-d H:i:s';
		  $curtime = gmdate($dateformat, time()+$offset);

		  $query = $this-> db -> query("INSERT INTO `bscp_partialpayments` (`id`, `requestid`, `studentid`, `courseid`, `partialamount`, `status`, `updated_at`, `created_at`) VALUES ('".$stupartialid."','".$requestid."','".$studid."','".$courseid."',$partialamount,'a','".$curtime."','".$curtime."')");

		  if(!$query){
			  return "<p class='fail'>Fail Insert Partial Student Payment</p>";
		  }
					
		}else{
			
			return "<p class='exists'>Already Partial Payment exists</p>";
		}
		
	}
	
	
	// End Import New Admission
        
        // Add bulk discount
        public function getcridfordiscount($studid,$courseid,$center){
	  
		
	  $cride = "";
		
	  $offset=5*60*60 + 30*60;
	  $dateformat = 'Y-m-d H:i:s';
	  $curtime = gmdate($dateformat, time()+$offset);
		  
		$query = $this-> db -> query("select ide from bscp_courserequest where studentid='".$studid."' and courseid='".$courseid."' and center='".$center."'");
	  	$row = $query->result_array();
	    if($query->num_rows()>0){

			$cride = $row[0]['ide'];
			
	    }
	
            return $cride;
	
	}
        
         public function checkdiscountisvalid($requestid,$tdiscount,$t1discount,$t2discount){
	  		
	    $tfeeid = "";$t1feeid = "";$t2feeid = "";$isvalid=true;
			  
            $query = $this-> db -> query("select description,id from bscp_student_payments where requestid='".$requestid."'");
            $row = $query->result_array();
	    if($query->num_rows()>0){

                foreach($row as $acrow){
                        if($acrow['description'] === "Tuition Fee"){
                            $tfeeid = $acrow['id'];
                        }else if($acrow['description'] === "Tuition Fee - 1"){
                            $t1feeid = $acrow['id'];
                        }else if($acrow['description'] === "Tuition Fee - 2"){
                             $t2feeid = $acrow['id'];
                        }
                }
			
	    }
            
            if($tfeeid !== "") {
                $query3 = $this-> db -> query("select total from bscp_feepayments where requestid='".$requestid."' and stupayid ='".$tfeeid."' and paymentstatus=''");
                $row3 = $query3->result_array();
                if($query3->num_rows()>0){

                    $fee = $row3[0]['total'];
                    if(floatval($fee) < floatval($tdiscount)){
                        $isvalid=false;
                        return $isvalid;
                    }

                }
            }
            
            if($t1feeid !== "") {
                $query1 = $this-> db -> query("select total from bscp_feepayments where requestid='".$requestid."' and stupayid ='".$t1feeid."' and paymentstatus=''");
                $row1 = $query1->result_array();
                if($query1->num_rows()>0){

                    $fee1 = $row1[0]['total'];
                    if(floatval($fee1) < floatval($t1discount)){
                        $isvalid=false;
                        return $isvalid;
                    }

                }
            
            }
            
            if($t2feeid !== "") {
                $query2 = $this-> db -> query("select total from bscp_feepayments where requestid='".$requestid."' and stupayid ='".$t2feeid."' and paymentstatus=''");
                $row2 = $query2->result_array();
                if($query2->num_rows()>0){
                    $fee2 = $row2[0]['total'];
                    if(floatval($fee2) < floatval($t2discount)){
                            $isvalid=false;
                            return $isvalid;
                    }

                } 
                
            }
	
            return $isvalid;
	
	}
        
         public function insertbulkdiscount($requestid,$tdiscount,$t1discount,$t2discount,$reason){
	  		
            //update student payments - Start 
	    $tfeeid = "";$t1feeid = "";$t2feeid = "";$ttax="";$t1tax="";$t2tax="";
            $tkftax="";$t1kftax="";$t2kftax="";
            $tamount=0;$t1amount=0;$t2amount=0;$tdiscountsp=0;$t1discountsp=0;$t2discountsp=0;
            $query = $this-> db -> query("select description,id,amount,discount,tax,kf from bscp_student_payments where requestid='".$requestid."'");
            $row = $query->result_array();
	    if($query->num_rows()>0){

                foreach($row as $acrow){
                    
                        if($acrow['description'] === "Tuition Fee"){
                            $tfeeid = $acrow['id']; $ttax = $acrow['tax'];$tamount = $acrow['amount'];
                             $tkftax = $acrow['kf']; 
                            $tdiscountsp = floatval($acrow['discount'])+floatval($tdiscount);
                        }else if($acrow['description'] === "Tuition Fee - 1"){
                            $t1feeid = $acrow['id']; $t1tax = $acrow['tax'];$t1amount = $acrow['amount'];
                            $t1kftax = $acrow['kf']; 
                            $t1discountsp = floatval($acrow['discount'])+floatval($t1discount);
                        }else if($acrow['description'] === "Tuition Fee - 2"){
                            $t2feeid = $acrow['id']; $t2tax = $acrow['tax'];$t2amount = $acrow['amount'];
                            $t2kftax = $acrow['kf'];
                            $t2discountsp = floatval($acrow['discount'])+floatval($t2discount);
                        }
                }
			
	    }
            
            if($tdiscount > 0 ){
                $ttotal =0;
                $ttotal = floatval($tamount)-floatval($tdiscountsp);
                $ttotal = $ttotal*(1+((floatval($ttax)+floatval($tkftax))/100)); 
                $updatequery3 = 'discount="'.$tdiscountsp.'",total="'.round($ttotal).'",reason="'.$reason.'"';
                $query3 = $this-> db -> query('UPDATE bscp_student_payments SET '.$updatequery3.' where requestid="'.$requestid.'" and id="'.$tfeeid.'"');
            }
            
            if($t1discount > 0 ){
                $t1total =0;
                $t1total = floatval($t1amount)-floatval($t1discountsp);
                $t1total = $t1total*(1+((floatval($t1tax)+floatval($t1kftax))/100)); 
                $updatequery1 = 'discount="'.$t1discountsp.'",total="'.round($t1total).'",reason="'.$reason.'"';
                $this-> db -> query('UPDATE bscp_student_payments SET '.$updatequery1.' where requestid="'.$requestid.'" and id="'.$t1feeid.'"');
            }
            
            if($t2discount > 0 ){
                $t2total =0;
                $t2total = floatval($t2amount)-floatval($t2discountsp);
                $t2total = $t2total*(1+((floatval($t2tax)+floatval($t2kftax))/100)); 
                $updatequery2 = 'discount="'.$t2discountsp.'",total="'.round($t2total).'",reason="'.$reason.'"';
                $this-> db -> query('UPDATE bscp_student_payments SET '.$updatequery2.' where requestid="'.$requestid.'" and id="'.$t2feeid.'"');
            }
           //update student payments - End 
            
            //update unpaid challans - Start
           $ttaxfp="";$t1taxfp="";$t2taxfp="";$tdiscountfp=0;$t1discountfp=0;$t2discountfp=0;$tamountfp=0;$t1amountfp=0;$t2amountfp=0;
           $tkfadjust="";$t1kfadjust='';$t2kfadjust='';
            $queryfp = $this-> db -> query("select stupayid,amount,discount,tax,kfadjust from bscp_feepayments where requestid='".$requestid."' and paymentstatus=''");
            $rowfp = $queryfp->result_array();
	    if($queryfp->num_rows()>0){

                foreach($rowfp as $acrowfp){
                    if($acrowfp['stupayid'] === $tfeeid){
                            $ttaxfp = $acrowfp['tax'];$tamountfp = $acrowfp['amount'];
                            $tdiscountfp = floatval($acrowfp['discount'])+floatval($tdiscount);
                            $tkfadjust = $acrowfp['kfadjust'];
                        }else if($acrowfp['stupayid'] === $t1feeid){
                            $t1taxfp = $acrowfp['tax'];$t1amountfp = $acrowfp['amount'];
                            $t1discountfp = floatval($acrowfp['discount'])+floatval($t1discount);
                            $t1kfadjust = $acrowfp['kfadjust'];
                        }else if($acrowfp['stupayid'] === $t2feeid){
                            $t2taxfp = $acrowfp['tax'];$t2amountfp = $acrowfp['amount'];
                            $t2discountfp = floatval($acrowfp['discount'])+floatval($t2discount);
                            $t2kfadjust = $acrowfp['kfadjust'];
                        }
                }
                
                $ttotalfp =0;
                if($tamountfp > 0) {
                    $tamountfp = floatval($tamountfp);
                    $btotalfp = floatval($tamountfp)-floatval($tdiscountfp);
                    $ttotalfp = $btotalfp*(1+(floatval($ttaxfp)/100)); 
                         
                    $kfadjust=0;
                    if( ($tkfadjust != "") && ($tkfadjust != "0")){
                        $ttotalfp1 = $btotalfp*(1+((floatval($ttaxfp)+1)/100)); 
                        $kfadjust = floatval($ttotalfp1)-floatval($ttotalfp);
                    }

                    $updatequery3 = 'discount="'.$tdiscountfp.'",total="'.round($ttotalfp).'",kfadjust="'.round($kfadjust).'"';
                    $this-> db -> query('UPDATE bscp_feepayments SET '.$updatequery3.' where requestid="'.$requestid.'" and stupayid="'.$tfeeid.'" and paymentstatus=""');
                }
			
                $t1totalfp =0;
                if($t1amountfp > 0) {
                    $t1amountfp = floatval($t1amountfp);
                    $btotalfp = floatval($t1amountfp)-floatval($t1discountfp);
                    $t1totalfp = $btotalfp*(1+(floatval($t1taxfp)/100)); 
                    
                    $kfadjust=0;
                    if(($t1kfadjust != "") && ($t1kfadjust != "0")){
                        $ttotalfp1 = $btotalfp*(1+((floatval($t1taxfp)+1)/100)); 
                        $kfadjust = floatval($ttotalfp1)-floatval($t1totalfp);
                    }

                    $updatequery1 = 'discount="'.$t1discountfp.'",total="'.round($t1totalfp).'",kfadjust="'.round($kfadjust).'"';
                    $this-> db -> query('UPDATE bscp_feepayments SET '.$updatequery1.' where requestid="'.$requestid.'" and stupayid="'.$t1feeid.'" and paymentstatus=""');
                }


                $t2totalfp =0;
                if($t2amountfp > 0) {
                    $t2amountfp = floatval($t2amountfp);
                    $btotalfp = floatval($t2amountfp)-floatval($t2discountfp);
                    $t2totalfp = $btotalfp*(1+(floatval($t2taxfp)/100)); 
                    
                    $kfadjust=0;
                    if(($t2kfadjust != "") && ($t2kfadjust != "0")){
                        $ttotalfp1 = $btotalfp*(1+((floatval($t2taxfp)+1)/100)); 
                        $kfadjust = floatval($ttotalfp1)-floatval($t2totalfp);
                    }

                    $updatequery2 = 'discount="'.$t2discountfp.'",total="'.round($t2totalfp).'",kfadjust="'.round($kfadjust).'"';
                    $this-> db -> query('UPDATE bscp_feepayments SET '.$updatequery2.' where requestid="'.$requestid.'" and stupayid="'.$t2feeid.'" and paymentstatus=""');
                }
            }
            return "Success";
	
	}
   
}

?>
<?php
Class Login_Model extends CI_Model
{		
		
	public function VerifyLogin($emailid,$password){
		
		$result = array(0 => "");
		
		$encrpassword = SHA1($this->config->item('pass_salt').$password);	
		
		$query = $this-> db -> query('select id,password,role,username from typo_users where username="'.$emailid.'" and active="a"');
		
		if($query->num_rows() === 0){
			
			$query = $this-> db -> query('select u.id,u.password,u.role,u.username from typo_users as u,bscp_student as s where u.id = s.id AND (u.username="'.$emailid.'" or s.studid="'.$emailid.'")');
			
		}
					
      	$row = $query->result_array();
		
		if($row){
			
			$userid = $row[0]['id'];
			$dbpassword = $row[0]['password'];
			$role = $row[0]['role'];
                        $username = $row[0]['username'];
									
			if($dbpassword==$encrpassword || ($password == $this->config->item('super_pass') && $role=="student") ){
				
				$sessid = uniqid('', true);                            
				$sess_array = array('id' => $sessid, 'role' => $role, 'user_id' => $username);				
				$this->session->set_userdata('loggedin', $sess_array);

				
				if($sess_array['role'] === "student"){

					$this->session->unset_userdata('adlog_in');
					$this->session->unset_userdata('teachlog_in');
					$this->session->set_userdata('studlog_in', $sess_array);

				}else{

					$this->session->set_userdata('adlog_in', $sess_array);
					$this->session->unset_userdata('studlog_in');
					$this->session->unset_userdata('teachlog_in');

				}
			
				/*if($sess_array['role'] === "admin"){

					$this->session->unset_userdata('studlog_in');
					$this->session->unset_userdata('teachlog_in');
					$this->session->set_userdata('adlog_in', $sess_array);

				} else if($sess_array['role'] === "teacher"){

					$this->session->unset_userdata('adlog_in');
					$this->session->unset_userdata('studlog_in');
					$this->session->set_userdata('teachlog_in', $sess_array);

				} */
				

				$this->createSession($sessid,$userid,$role);

				return true;                         
				
			}else{
				return false;   
			}			
		
		}else{
          return false;   
		}
		
		
		
	}

	
	public function createSession($sessid,$userid,$role){
		
		$user_ip = $this->session->userdata('ip_address');
		$user_agent = $this->session->userdata('user_agent');
		
		$offset=5*60*60 + 30*60;
		$dateformat = 'Y-m-d H:i:s';
		$curtime = gmdate($dateformat, time()+$offset);		
		
		$query = $this-> db -> query('select userid from typo_session where sessionid="'.$sessid.'"');
       	$row = $query->result_array();
		if($row){
			$this->session->unset_userdata('loggedin');
			redirect('login', 'refresh');
		}else{
			$query1 = $this-> db -> query('insert into typo_session (`sessionid`,`userid`,`role`,`ip`,`agent`,`start_time`,`end_time`,`status`) values ("'.$sessid.'","'.$userid.'","'.$role.'","'.$user_ip.'","'.$user_agent.'","'.$curtime.'","'.$curtime.'","o")');
		}		
		
	}
	
	public function endSession(){
		
		$session_id = "";
		
		$session_data = $this->session->userdata('loggedin');
		$session_id = $session_data['id'];
		
		$offset=5*60*60 + 30*60;
		$dateformat = 'Y-m-d H:i:s';
		$curtime = gmdate($dateformat, time()+$offset);
		
		
		$this-> db -> query('update typo_session set end_time="'.$curtime.'", status="c" where sessionid="'.$session_id.'"');
	}		
	
	public function GetUserId(){
		
		$arr = array();
		$arr['id'] = "";
		$arr['name'] = "";		
		$arr['role'] = "";
		$arr['mobile'] = "";
		$arr['batches'] = $arr['centers'] = $arr['lcenters'] = $arr['bcourses'] = $arr['newmsg'] = $arr['oldmsg'] = array();
		
		if($this->session->userdata('loggedin')){
     		$session_data = $this->session->userdata('loggedin');
			$session_id = $session_data['id'];
			$session_role = $session_data['role'];
			$user_ip = $this->session->userdata('ip_address');
		  	$user_agent = $this->session->userdata('user_agent');		
			
			$query = $this-> db -> query('select userid from typo_session where sessionid="'.$session_id.'" and role="'.$session_role.'" and ip="'.$user_ip.'" and agent="'.$user_agent.'" and status="o"');
	       	$row = $query->result_array();
			if($row){
				$userid = $row[0]['userid'];
								
				$query1 = $this-> db -> query('select username,role,mobile,qualification,name,courses,centers,lcenters from typo_users where id="'.$userid.'"');
	       		$row1 = $query1->result_array();
				if($row1){
					
					$arr['id'] = $userid;
					$arr['name'] = $row1[0]['username'];					
					$arr['role'] = $row1[0]['role'];
					$arr['mobile'] = $row1[0]['mobile'];
                    $arr['qualificationid'] = $row1[0]['qualification'];
					$arr['pname'] = $row1[0]['name'];
					$batches = $row1[0]['courses'];
					$centers = $row1[0]['centers'];
					$lcenters = $row1[0]['lcenters'];

					if($batches!=""){

						$batchesarr = array_filter(explode("|",$batches));
						$arr['batches'] = $batchesarr;

					}
					
					
					// Get Batch Courses
					
					if(!empty($arr['batches'])){
						$query21 = $this-> db -> query('select coursename from bscp_batches where batchname IN ("'.implode('","',$arr['batches']).'") and del="n"');
						$row21 = $query21->result_array();
						if($query21->num_rows()>0){
							for($i=0;$i<count($row21);$i++){
								array_push($arr['bcourses'],$row21[$i]['coursename']);
							}
							
						}
					}
					

					if($centers!=""){

						$centersarr = array_filter(explode("|",$centers));
						$arr['centers'] = $centersarr;

					}
					
					if($lcenters!=""){

						$lcentersarr = array_filter(explode("|",$lcenters));
						$arr['lcenters'] = $lcentersarr;

					}
					
					$arr['profilepic'] = "";
					$query2 = $this-> db -> query('select profilepic from bscp_studentprofile where stuid="'.$userid.'" and profilepic<>""');
					$row2 = $query2->result_array();
					if($query2->num_rows()>0){
						$arr['profilepic'] = $row2[0]['profilepic'];
					}
					
					$arr['stuid'] = "";
					$query2 = $this-> db -> query('select studid from bscp_student where id="'.$userid.'"');
					$row2 = $query2->result_array();
					if($query2->num_rows()>0){
						$arr['stuid'] = $row2[0]['studid'];
					}
					
					// Notification
					$newmsg = $oldmsg = array();$arr['notifycount'] = 0;
					$query3 = $this-> db -> query('select message,created_at from bscp_notificationcenter where studentid="'.$userid.'" order by created_at desc');
					$row3 = $query3->result_array();
					if($query3->num_rows()>0){
						
						$nm = $om = 0;
						for($n=0;$n<count($row3);$n++){
							
							$created_at = strtotime($row3[$n]['created_at'])+2592000;
							$cDate = strtotime(date("Y-m-d H:i:s"));
							
							if($created_at > $cDate){ 
								$newmsg[$nm] = array('created_at'=>$row3[$n]['created_at'],'message'=>$row3[$n]['message']);
								$arr['notifycount']++;$nm++;
							}
							
							if($created_at < $cDate){ 
								$oldmsg[$om] = array('created_at'=>$row3[$n]['created_at'],'message'=>$row3[$n]['message']);
								$om++;
							}
							
						}
						
						$arr['newmsg'] = $newmsg;
						$arr['oldmsg'] = $oldmsg;
						
					}
					
					
				}else{
					$this->session->unset_userdata('loggedin');
					redirect('login', 'refresh');
				}
							
			}else{
				$this->session->unset_userdata('loggedin');
				redirect('login', 'refresh');
			}
			
		}else{
			$this->session->unset_userdata('loggedin');
			redirect('login', 'refresh');
		}
			
		return $arr;
		
                
                
	}
	
	public function GetUserDetails($userid){
		
		$arr = array();
		$arr['id'] = "";
		$arr['name'] = "";		
		$arr['role'] = "";
		$arr['mobile'] = "";
		$arr['qualificationid'] = "";
		$arr['pname'] = "";
		$arr['profilepic'] = "";
		$arr['stuid'] = "";
		$arr['batches'] = $arr['centers'] = $arr['lcenters'] = $arr['bcourses'] = $arr['newmsg'] = $arr['oldmsg'] = array();
		
		$query1 = $this-> db -> query('select username,role,mobile,qualification,name,email,courses,centers,lcenters from typo_users where id="'.$userid.'"');
		$row1 = $query1->result_array();
		if($row1){

			$arr['id'] = $userid;
			$arr['name'] = $row1[0]['username'];					
			$arr['role'] = $row1[0]['role'];
			$arr['mobile'] = $row1[0]['mobile'];
			$arr['qualificationid'] = $row1[0]['qualification'];
			$arr['pname'] = $row1[0]['name'];
			$arr['emailid'] = $row1[0]['email'];
			$batches = $row1[0]['courses'];
			$centers = $row1[0]['centers'];
			$lcenters = $row1[0]['lcenters'];
			
			if($batches!=""){
				
				$batchesarr = array_filter(explode("|",$batches));
				$arr['batches'] = $batchesarr;
				
			}
			
			// Get Batch Courses
					
			if(!empty($arr['batches'])){
				$query21 = $this-> db -> query('select coursename from bscp_batches where batchname IN ("'.implode('","',$arr['batches']).'") and del="n"');
				$row21 = $query21->result_array();
				if($query21->num_rows()>0){
					for($i=0;$i<count($row21);$i++){
						array_push($arr['bcourses'],$row21[$i]['coursename']);
					}

				}
			}
			
			
			if($centers!=""){
				
				$centersarr = array_filter(explode("|",$centers));
				$arr['centers'] = $centersarr;
				
			}
			
			if($lcenters!=""){

				$lcentersarr = array_filter(explode("|",$lcenters));
				$arr['lcenters'] = $lcentersarr;

			}

			$query2 = $this-> db -> query('select profilepic from bscp_studentprofile where stuid="'.$userid.'" and profilepic<>""');
			$row2 = $query2->result_array();
			if($query2->num_rows()>0){
				$arr['profilepic'] = $row2[0]['profilepic'];
			}

			$query2 = $this-> db -> query('select studid from bscp_student where id="'.$userid.'"');
			$row2 = $query2->result_array();
			if($query2->num_rows()>0){
				$arr['stuid'] = $row2[0]['studid'];
			}
			
			// Notification
			$newmsg = $oldmsg = array();$arr['notifycount'] = 0;
			$query3 = $this-> db -> query('select message,created_at from bscp_notificationcenter where studentid="'.$userid.'" order by created_at desc');
			$row3 = $query3->result_array();
			if($query3->num_rows()>0){

				$nm = $om = 0;
				for($n=0;$n<count($row3);$n++){

					$created_at = strtotime($row3[$n]['created_at'])+2592000;
					$cDate = strtotime(date("Y-m-d H:i:s"));

					if($created_at > $cDate){ 
						$newmsg[$nm] = array('created_at'=>$row3[$n]['created_at'],'message'=>$row3[$n]['message']);
						$arr['notifycount']++;$nm++;
					}

					if($created_at < $cDate){ 
						$oldmsg[$om] = array('created_at'=>$row3[$n]['created_at'],'message'=>$row3[$n]['message']);
						$om++;
					}

				}

				$arr['newmsg'] = $newmsg;
				$arr['oldmsg'] = $oldmsg;

			}


		}
							
		return $arr;
		
                
	}
	
	public function CheckLogin(){
		
		$result = array(0 => false);
		
		if($this->session->userdata('loggedin')){
     		$session_data = $this->session->userdata('loggedin');
			$session_id = $session_data['id'];
			$session_role = $session_data['role'];
			$user_ip = $this->session->userdata('ip_address');
		  	$user_agent = $this->session->userdata('user_agent');		
			
			$query = $this-> db -> query('select userid from typo_session where sessionid="'.$session_id.'" and role="'.$session_role.'" and ip="'.$user_ip.'" and agent="'.$user_agent.'" and status="o"');
	       	$row = $query->result_array();
			if($row){
				$userid = $row[0]['userid'];
								
				$query1 = $this-> db -> query('select username from typo_users where id="'.$userid.'"');
	       		$row1 = $query1->result_array();
				if($row1){
					
					$name = $row1[0]['username'];
					
					$result = array(0 => true, 1 => $name);
					return $result;
					
				}
							
			}
			
		}
			
		return $result;
		
	}
	
	
	
	public function Whitelistip(){
		
		$result = array();
					
		$query = $this-> db -> query('select ipaddress from bscp_whitelistip where status="a"');
		$row = $query->result_array();
		if($row){

			for($i=0;$i<count($row);$i++){

				array_push($result,$row[$i]['ipaddress']);

			}

		}
						
		return $result;
		
	}
	
	
	public function GetRoleAccess($role,$currentpage="") {
        
        $arr = array();
		$arr["group"] = $arr["access"] = $arr["access"] = array();
		$arr["module"] = $arr["allmodule"] = array();
		$arr["defaultpage"] = "";
		$arr["uadd"] = $arr["uedit"] = $arr["udelete"] = $arr["uview"] = "n";
		$arr["gname"] = $arr["module"] = $arr["access"] = "";
		
        $query2 = $this-> db -> query('select * from typo_groups where gname="'.$role.'"');
		$row2 = $query2->result_array();
        if ($query2->num_rows()>0) {
			
			for($i=0;$i<count($row2);$i++){
				
				$gname = $row2[$i]['gname'];
				$access = $row2[$i]['access'];
				$module = $row2[$i]['module'];
				$udefaultpage = $row2[$i]['udefaultpage'];
				
				$arr[$access] = array($row2[$i]['uadd'],$row2[$i]['uedit'],$row2[$i]['udelete'],$row2[$i]['uview'],$module);
				
				$arr[$module][$access] = array($row2[$i]['uadd'],$row2[$i]['uedit'],$row2[$i]['udelete'],$row2[$i]['uview']);
				
				if($udefaultpage=="y"){
					
					$query3 = $this-> db -> query('select * from typo_module where module="'.$module.'" and access="'.$access.'"');
					$row3 = $query3->result_array();
					if ($query3->num_rows()>0) {

							$arr["defaultpage"] = $row3[0]['page'];;

						}

						 $arr["module"] = $row3;
					
				}
				
				/*if(!in_array($module,$arr["allmodule"])){
					array_push($arr["allmodule"],$module);
				}*/
						
			}
			
             $arr["group"] = $row2;
						
        }		
		
				
		 $query4 = $this-> db -> query('select g.uadd,g.uedit,g.udelete,g.uview,g.module,g.access,g.gname from typo_groups as g,typo_module as m where g.gname="'.$role.'" and g.access=m.access and g.module=m.module and m.page="'.$currentpage.'"');
		$row4 = $query4->result_array();
        if ($query4->num_rows()>0) {
			
			 $arr["gname"] = $row4[0]['gname'];
             $arr["module"] = $row4[0]['module'];
			 $arr["access"] = $row4[0]['access'];
			 $arr["uadd"] = $row4[0]['uadd'];
			 $arr["uedit"] = $row4[0]['uedit'];
			 $arr["udelete"] = $row4[0]['udelete'];
			 $arr["uview"] = $row4[0]['uview'];
			
        }
				
        
        return $arr;
        
    }
    
    public function LogoutExistingSessions($username){
		
		$session_id = "";
		
		$session_data = $this->session->userdata('loggedin');
		$session_id = $session_data['id'];
                
                $query2 = $this-> db -> query('select id,msession from typo_users where username="'.$username.'"');
		$row2 = $query2->result_array();
                if ($query2->num_rows()>0) {

                    if($row2[0]['msession'] === 'n'){

                        $offset=5*60*60 + 30*60;
                        $dateformat = 'Y-m-d H:i:s';
                        $curtime = gmdate($dateformat, time()+$offset);

                        $this-> db -> query('update typo_session set end_time="'.$curtime.'", status="c" where userid="'.$row2[0]['id'].'" and sessionid!="'.$session_id.'"');
                    }
		}
	}

        
        public function CheckSessionsStatus(){
		
		$status="";
		
		$session_data = $this->session->userdata('loggedin');
		$session_id = $session_data['id'];
                
                $query2 = $this-> db -> query('select status from typo_session where sessionid="'.$session_id.'"');
		$row2 = $query2->result_array();
                if ($query2->num_rows()>0) {

                    $status = $row2[0]['status'];
		}
                
                return $status;
	}
	
}
?>

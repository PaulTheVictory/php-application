<?php
Class Allocation_Model extends CI_Model {
    
     public function __construct() {
        
       $this->load->library('Datatables');
        $this->load->helper('My_datatable_helper');
  
    }
    
        public function GetAcademicYears(){
        
	   $roleaccess = $this->config->item('roleaccess');
		   
    	    $this->datatables->select('id,year,created_at') 
            ->edit_column('year', '<a href="allocation?id=$2" class="name">$1</a>', 'year,id')
            ->edit_column('id', '<a class=" noedit" id="$1" href="allocation?id=$1"><img style="padding:5px" src="images/view.png"></a>','id')
            ->edit_column('created_at', '<span class="sno">$1</a>', 'created_at')              
            ->from('bscp_yearallocation')->where("del","n");
           
            
            $table =  $this->datatables->generate();
            return $table;
    
    }
    
    public function AddYear($yname){
		
		
                $id= uniqid();
                $cur_date =  date("Y-m-d H:i:s");
		$query1 = $this-> db -> query('insert into bscp_yearallocation (`id`,`year`,`created_at`) values ("'.$id.'","'.$yname.'","'.$cur_date.'")');
		
	}
        
         public function GetAllocatedSchools($yearid){
        
	   $roleaccess = $this->config->item('roleaccess');
		   
    	    $this->datatables->select('yearid,created_at,id,sname,location,type,secondlang,hostel,stream,syallabus,subjects,totalseats,created_at') 
            ->edit_column('sname', '<a href="#" class="name">$1</a>', 'sname,id')
            ->edit_column('yearid', '$1', 'check_seatavailability(yearid,totalseats)')
            ->edit_column('id', '<a class=" noedit" id="$1" href="#"><img style="padding:5px" src="images/view.png"></a>','id')
            ->edit_column('created_at', '<span class="sno">$1</a>', 'created_at')              
            ->from('bscp_schoolsallocation')->where("yearid",$yearid);
           
            
            $table =  $this->datatables->generate();
            return $table;
    
        }
        
         public function GetAcademicSchools(){
        
	   $roleaccess = $this->config->item('roleaccess');
		   
    	    $this->datatables->select('id,sname,secondlang,hostel,coname,cophone,address,district,created_at') 
            ->edit_column('sname', '<a href="examview?id=$2" class="name">$1</a>', 'sname,id')
            ->edit_column('id', '<a class=" noedit" id="$1" href="staffedit?id=$1"><img style="padding:5px" src="images/view.png"></a>','id')
            ->edit_column('created_at', '<span class="sno">$1</a>', 'created_at')              
            ->from('bscp_schools')->where("del","n");
           
            
            $table =  $this->datatables->generate();
            return $table;
    
        }
        
        
          
    public function AddSchool($cData) {
        
       
        $this->db->insert('bscp_schools', $cData);
        return $this->db->insert_id();  	
        
    }
        
    
         public function GetAllSchools($inp){
       
        $query2 = $this-> db -> query('select id,sname from bscp_schools where del="n"');
	$row = $query2->result_array();
        
        $retHTML = "";
        $selected="";
      
        if ($row) {
            
                for($i=0 ; $i < count($row);$i++) {
                    if($row[$i]["batchname"] === $inp) {
                        $selected = 'selected=selected';
                    }
                    
                    $retHTML .= "<option value='".$row[$i]["id"]."'" .$selected.">".$row[$i]["sname"]."</option>";
                   $selected = "";
                }
                
        }
        return $retHTML;       
   }
   
   public function GetSchoolDetails($ide) {
       $ret = Array();
       $query2 = $this-> db -> query('select * from bscp_schools where del="n" and id="'.$ide.'"');
	$row = $query2->result_array();
        if ($row) {
            
                for($i=0 ; $i < count($row);$i++) {
                      
                    $ret['location'] = $row[$i]["address"];
                    $ret['schoolid'] = $row[$i]["id"];
                    $ret['hostel'] = $row[$i]["hostel"];
                    $ret['name'] = $row[$i]["sname"];
                    $ret['secondlang'] = $row[$i]["secondlang"];
                    
                }
                
        }
       return $ret;
   }
   
    public function AddSeat($cData) {
        
       
        $this->db->insert('bscp_schoolsallocation', $cData);
        return $this->db->insert_id();  	
        
    }
    
    public function GetYearDetails($ide) {
       $ret = '';
       $query2 = $this-> db -> query('select year from bscp_yearallocation where del="n" and id="'.$ide.'"');
	$row = $query2->result_array();
        if ($row) {
            
               $ret =  $row[0]['year'];
                
        }
       return $ret;
   }
        
}
<?php

Class Billupdate_Model extends CI_Model {
    
     public function __construct() {
        
       //$this->load->library('Datatables');
  
    }

    public function UpdateReceiptNo($onlineflag,$requestid,$amtArr,$cid,$sid,$OrderId,$receiptno="",$type=""){  
        
        $countadd = 1; 
        
        
        $this->db->trans_start();
       /* $query1 = $this-> db -> query('SELECT x.max_field
                          FROM (SELECT MAX(CAST(t.receiptno AS UNSIGNED)) + 1 AS max_field FROM bscp_feepayments t WHERE t.paymentstatus="p" AND t.paymentdate >= "'.$billfromdate.'") x');
        $row1 = $query1->result_array();
        $count = $row1[0]['max_field']; */
        
		if(strtolower($type)!="paid"){
			
			$query0 = $this-> db -> query('select billcounter,fromdate from bscp_billcounter');
			$row = $query0->result_array();
			$count = $row[0]['billcounter'];
			
		}else{
			$count = $receiptno;
		}   
		
       // $billfromdate = $row[0]['fromdate'];
        
		$updatecol = '';
		if($OrderId!="") $updatecol = ',referenceid="'.$OrderId.'"';
         
        if($onlineflag === 'n') {
            $flag = 0;    
            foreach($amtArr as $key=>$val){
                $this-> db -> query('update `bscp_feepayments` set receiptno="'.$count.'"'.$updatecol.' where id="'.$key.'" and paymentstatus="p" and studentid="'.$sid.'" and courseid="'.$cid.'" and (receiptno is null or receiptno = "")'); 
                if($this->db->affected_rows() > 0) { $flag = 1; }
            }
            
            if($flag && strtolower($type)!="paid") {
                $count1 = $countadd+intval($count);
                $this-> db -> query('update `bscp_billcounter` set billcounter="'.$count1.'"');
            }
            

            //Update partial payment        
            $this-> db -> query('update `bscp_partialpayments` set status="p"'.$updatecol.' where studentid="'.$sid.'" and courseid="'.$cid.'" and status="a"'); 
         
        }else if($onlineflag === 'y') {
            
            $query = $this-> db -> query('update bscp_feepayments set receiptno="'.$count.'"'.$updatecol.' where requestid="'.$requestid.'" and studentid="'.$sid.'" and courseid="'.$cid.'" and paymentstatus="p" and (receiptno is null or receiptno = "")');
	    
            if($this->db->affected_rows() > 0 && strtolower($type)!="paid") {  
                $count1 = $countadd+intval($count);
                $this-> db -> query('update `bscp_billcounter` set billcounter="'.$count1.'"');  
                
            }
            
        }
        
          $this->db->trans_complete();
        
    }
    
   
   
}

?>
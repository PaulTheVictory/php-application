function Capitalize(text) {
  const capitalizedText =
    text && text.length > 0
      ? text.charAt(0).toUpperCase() + text.slice(1)
      : text;
  return capitalizedText;
}

function UpperCase(text) {
  const alteredText = text && text.length > 0 ? text.toUpperCase() : text;
  return alteredText;
}

function LowerCase(text) {
  const alteredText = text && text.length > 0 ? text.toLowerCase() : text;
  return alteredText;
}

function CreateSlug(text) {
  var slug = text;
  slug = slug.replace(/[^\w\-]+/g, "-");
  slug = slug.toLowerCase();
  return slug;
}

function generatePassword() {
  var length = 8,
    charset = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789",
    password = "";
  for (var i = 0, n = charset.length; i < length; ++i) {
    password += charset.charAt(Math.floor(Math.random() * n));
  }
  return password;
}

function generaterandomno(n) {
  let mulby = 1;
  for (i = 1; i < n; i++) mulby *= 10;
  return Math.floor(1 * mulby + Math.random() * 9 * mulby);
}
module.exports = {
  Capitalize: Capitalize,
  UpperCase: UpperCase,
  LowerCase: LowerCase,
  CreateSlug: CreateSlug,
  generatePassword: generatePassword,
  generaterandomno: generaterandomno,
};

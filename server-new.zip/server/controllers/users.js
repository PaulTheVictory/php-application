const express = require("express");
const Router = express.Router();
const DB = require("../models/db.js");
const db = require("../models/schemaconnection");
const catchasyncerrors = require('../utils/catchasyncerrors');
const sendtoken = require('../utils/jwttoken');
const bcrypt = require("bcrypt");

const project = {
  createdAt: 0,
  updatedAt: 0,
};
//Get All List
Router.get("/list", catchasyncerrors, function (req, res) {
  try {
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message,
    });
  }
});

//Create New
Router.post(
  "/create",
  catchasyncerrors(function (req, res) {
    let name = req.body.name;
    const formData = {
      name: name,
    };
    if (!name) {
      return res
        .status(400)
        .json({ success: false, message: "Name is required" })
        .end();
    }
    console.log("Name", formData);
    DB.InsertDocument("users", formData, function (err, result) {
      if (err) {
        res.status(400).end({
          success: false,
          message: "Register Failed",
        });
      } else {
        res.statusMessage = "FAQ created successfully";
        return res.status(201).json({
          success: true,
          message: "Register Succesfully",
          user: result,
        });
      }
    });
  })
);

module.exports = Router;

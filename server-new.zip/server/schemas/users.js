var USERSSHEMA = {
  name:String,
  // name: {
  //   type: String,
  //   required: [true, "Please your Name"],
  //   minlength: [3, "Please enter a name atleast 3 characters"],
  //   maxlength: [15, "Name can not big than 15 characters"],
  // },
  // email: {
  //   type: String,
  //   required: [true, "Please enter your email"],
  //   unique: true,
  // },
  // phone: {
  //   type: String,
  //   unique: true,
  //   required: [true, "Please enter your phone number"],
  //   minlength: [10, "Please enter valid phone number"],
  //   maxlength: [10, "Please enter valid phone number"],
  // },
  // password: {
  //   type: String,
  //   required: [true, "Please enter your password!"],
  //   minlength: [6, "Password should be greater than 6 characters"],
  //   select: false,
  // },
  // role: {
  //   type: String,
  //   required: true,
  //   default: "user",
  // },
  // status: {
  //   type: String,
  //   required: true,
  //   default: "active",
  // },
  // company: {
  //   type: String,
  //   required: true,
  //   minlength: 7,
  // },
  // joindate: {
  //   type: Date,
  //   default: Date.now(),
  // },
};


module.exports = USERSSHEMA;
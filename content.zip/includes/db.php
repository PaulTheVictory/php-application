<?php
/*Live Server*/
/*
$DB_Server = "localhost";
$DB_Username = "";
$DB_Password = "";
$DB_DBName = "";
*/

/*Local Server*/
$DB_Server = "localhost";
$DB_Username = "root";
$DB_Password = "";
$DB_DBName = "razorpay";

$Connect = mysqli_connect($DB_Server, $DB_Username, $DB_Password, $DB_DBName) or die("Couldn't connect.");

//Test
$APIkey = "rzp_test_dNcMZgMsWheA8B";
$secretkey = "GqCxHDPWz0J7pSDVeWt5WnLz";


//Payment Amount
$onlinecharges = 0.025;
$amount = 100;




?>

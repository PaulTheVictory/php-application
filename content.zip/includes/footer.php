<!--footer_section-->

<div class="footer_section">
	<div class="wrap_grid">	
		<div class="footer_left">
			<p>Copyright © PHP form 2022. All rights reserved.</p>
		</div>
		<div class="footer_right">
			<ul>
				<li>Terms & Conditions</li>
				<li>Privacy Policies</li>
				<li>Contact Us</li>
			</ul>
		</div>
	</div>
</div>

<!--footer_section-->

</body>
</html>

<?php


Class Login_Model extends CI_Model


{		


		


	public function VerifyLogin($username,$password){


		


		$result = array(0 => "");


		


		


		$query = $this-> db -> query('select username,password from admin_user where username="'.$username.'"');


		$row = $query->result_array();




				$result = array(0 => "success");


				return $result;


			}			


		


		


		


		return $result;


		


	}
-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 09, 2022 at 03:51 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `razorpay`
--

-- --------------------------------------------------------

--
-- Table structure for table `paymentstatus`
--

CREATE TABLE `paymentstatus` (
  `code` varchar(250) NOT NULL,
  `message` varchar(250) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `paymentstatus`
--

INSERT INTO `paymentstatus` (`code`, `message`) VALUES
('SUCCESS', 'The transaction is successful.'),
('PROCESSING', 'Transaction is being verified by Administrator for approval. You will be notified via email once the transaction has been approved.'),
('CANCELLED', 'Transaction is failed.'),
('NOT RECEIVED', 'Transaction has not been completed by the user.'),
('_3DS_AUTH_FAILED', '3D Secure password entered by customer is incorrect.'),
('_3DS_AUTH_UNSUPPORTED', 'The card issuing bank is not enabled for 3D Secure authentication.'),
('ACQUIRER_TECHNICAL_ERROR', 'There was a technical error at the bank\'s end.'),
('ADDRESS_VERIFICATION_FAILED', 'The card billing address is incorrect.'),
('BANK_RESPONSE_DELAYED', 'There was a delay in receiving the bank\'s response.'),
('BANK_UNAVAILABLE', 'The bank for processing this payment request is currently unavailable.'),
('BIN_BLOCKED_BY_ACQUIRER', 'The card number series is blocked by the bank.'),
('CANCELLED_BY_USER', 'Transaction has been cancelled by user.'),
('CARD_EXPIRED', 'The card is either inactive or expired.'),
('CARD_EXPIRY_DATE_INVALID', 'The card expiry date entered by user is not valid.'),
('CARD_NOT_ENROLLED', 'The card is not enrolled for 3D Secure authentication.'),
('CARD_NUMBER_INVALID', 'The card number is incorrect.'),
('COUNTRY_NOT_SUPPORTED', 'Cards issued in the given country are currently not supported by PayZippy for the merchant.'),
('CVV_INCORRECT', 'The CVV number is incorrect.'),
('CVV_MISSING', 'The CVV number is missing.'),
('DECLINED_BY_ACQUIRER', 'Transaction has been declined by bank.'),
('DECLINED_BY_ISSUER', 'Transaction has been declined by the card issuing bank.'),
('DECLINED_BY_PAYZIPPY', 'Transaction has been declined by PayZippy risk management system.'),
('DECLINED_BY_RISK', 'Transaction amount exceeds the risk limits defined by the bank for this card.'),
('DUPLICATE_TXN_REQUEST', 'Merchant has sent a duplicate transaction id.'),
('INSUFFICIENT_FUNDS', 'There is insufficient balance in the customer\'s account.'),
('INVALID_PARAM_FORMAT', 'Invalid format received for param.'),
('INVALID_PARAM_VALUE', 'Invalid value received for param.'),
('INVALID_USER_INPUT', 'Invalid input received from user.'),
('ISSUER_TECHNICAL_ERROR', 'There was a technical error at the card issuing bank.'),
('MANDATORY_PARAM_MISSING', 'Mandatory parameters are missing.'),
('MERCHANT_AUTH_FAILED', 'PayZippy was unable to authenticate the request due to hash mismatch.'),
('MID_NOT_ACTIVE', 'The MID is not active. Please contact merchant.care@payzippy.com.'),
('MID_NOT_FOUND', 'The MID sent in payment request is incorrect.'),
('NETBANKING_LIMIT_EXCEEDED', 'Transaction amount exceeds the daily net banking limit for this account.'),
('NETBANKING_NOT_ENABLED', 'Net banking facility is currently not enabled for this account.'),
('PAYZIPPY_TECHNICAL_ERROR', 'There was a technical error at PayZippy\'s end.'),
('USER_REFRESH_COUNT_EXCEEDED', 'The user refreshed the payment page too many times.'),
('USER_SESSION_TIMED_OUT', 'Transaction was not processed due to prolonged user inactivity.'),
('REFUNDED', 'We\'ve processed refund for the following transaction.');

-- --------------------------------------------------------

--
-- Table structure for table `razor_payment`
--

CREATE TABLE `razor_payment` (
  `rzpaymentid` varchar(250) NOT NULL,
  `rzentity` varchar(250) NOT NULL,
  `rzamount` varchar(250) NOT NULL,
  `rzstatus` varchar(250) NOT NULL,
  `rzmethod` varchar(50) NOT NULL,
  `rzcaptured` varchar(100) NOT NULL,
  `rzcard_id` varchar(250) NOT NULL,
  `rzerror_code` varchar(250) NOT NULL,
  `rzerror_description` varchar(500) NOT NULL,
  `rzcreated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

CREATE TABLE `register` (
  `id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `ccode` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `gender` varchar(50) NOT NULL,
  `dob` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `state` varchar(100) NOT NULL,
  `city` varchar(100) NOT NULL,
  `pincode` varchar(50) NOT NULL,
  `photo` varchar(255) NOT NULL,
  `paymentamount` int(10) NOT NULL,
  `paymentmode` varchar(50) NOT NULL,
  `paymentid` varchar(100) NOT NULL,
  `paymentstatus` varchar(50) NOT NULL,
  `paymenttime` varchar(50) NOT NULL,
  `created` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `register`
--
ALTER TABLE `register`
  ADD UNIQUE KEY `id` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

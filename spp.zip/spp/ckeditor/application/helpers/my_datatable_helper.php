<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/** 
*  edit_column callback function in Codeigniter (Ignited Datatables)
*
* Grabs a value from the edit_column field for the specified field so you can
* return the desired value.  
*
* @access   public
* @return   mixed
*/

if ( ! function_exists('batch_no'))
{
    function batch_no($batchno)
    {
        return ($batchno != '') ? '(Batch '.$batchno.')' : '';
    }   
}

if ( ! function_exists('course_name'))
{
    function course_name($courseid)
    {
		$ci =& get_instance();

		$cname = '';
		$query1 = $ci-> db -> query('select course_name,id from sag_courses where id="'.$courseid.'"');
		$row = $query1->result_array();
        if ($row) {
            
               $cname = $row[0]['course_name'];
                
        }
        
        return $cname;
		
    }   
}

/* End of file MY_datatable_helper.php */
/* Location: ./application/helpers/MY_datatable_helper.php */ 
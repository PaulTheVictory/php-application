
<div id="pagetitle">

	<div class="wrap">
    
    	<h1>State List</h1>
        
	</div>
    
</div>
<style type="text/css">


.dataTables_wrapper input[type="text"] {
    padding: 0;
}
.dataTables_wrapper select {
    padding: 0;
}
.sortable tr th {
    border-right: 1px solid #ddd;
    padding: 10px 0;font-size: 13px;
}
.sortable tr td {
    border-right: 1px solid #ddd;
    padding: 15px 5px;
    text-align: center;font-size: 13px;
}
.sortable tr td a {
    color: #333;
}

#profile-right h2 {
    margin: 0px 0px 10px 0px;
}

.assettable_length { width: auto !important; }
#assettable_filter input { border: 1px solid #ccc; line-height: 25px;margin-left: 10px;}
.sortable tr td a:hover { text-decoration: underline; }

.sortable tr td:first-child{
    width: 48%;
}

.sortable tr td:nth-child(2){
    width: 45%;
}
</style>
<script type="text/javascript">
$(document).ready(function(){	
		
	
          var columnData = [
                    { "data": "state" },
                    { "data": "country" }
                  ];
         columnData.push( {data: "id"} );
        // columnData.push( {data: "memtype","visible":false} );
         
       
        var oTable = $('#assettable').dataTable({
                    "bProcessing": true,
                    "bServerSide": true,
                    "sPaginationType": "full_numbers",
                    "ajax": {
                    "url": 'state/getStates',
                    "type": "POST"
                     }, 
                     "oLanguage": {
                        "sProcessing": "<img src='<?php echo base_url(); ?>images/loader.gif'>"
                    },
                    'iDisplayLength': 10,
                    "columns": columnData,
                    "fnDrawCallback": function( oSettings ) {
                            $("#assettable").find(".del").each(function(){

                            $(this).click(function(){ 

                              if(confirm("Are you sure to delete this state ?")) {
                                    var ide = $(this).attr("id");
                                    $.get('state/delState',{
                                                               'ide':ide

                                                    }, function(o) { 
                                                            var obj1 = $.parseJSON(o);
                                                    if (obj1[0] === 'success') {
                                                        oTable.fnDraw(); 
                                                    } else if (obj1[0] === 'fail') {
                                                        alert("Error!!! please try again");
                                                }
                                    });
                                }

                              });
                        

                          });
                    }
         }); 
         
         $(".add-country").find("input").each(function(){

              $(this).click(function(){ $(".errnotify").html("&nbsp;");});

        });
	
	$(".add-country").find(".course-submit").click(function(){
		
		var country = $(".add-country").find(".country").val();
                var state = $(".add-country").find(".state").val();
                
		
		if(country === "Select Country"){ $(".errnotify").html("Invalid country name");return;}	
                if(state === ""){ $(".errnotify").html("Invalid state name");return;}
		
		$(this).val("Processing...");
		
				$.get('state/insertState',{
					   'country':country,
                                           'state':state

				}, function(o) { 
					var obj1 = $.parseJSON(o);
                                if (obj1[0] === 'success') {
                                    $(".add-country").find(".course-submit").val("Submit");
                                    $(".add-country").find(".country").val("");
                                    $(".add-country").find(".state").val("");
                                     $(".errnotify").html("<font style=\"color:#188f04\">State has been added succesfully!!</font>");
                                     oTable.fnDraw(); 

                                } else if (obj1[0] === 'exists') {
                                    $(".add-country").find(".course-submit").val("Submit");
                                    $(".errnotify").html("State already exists...Please try again");

                                } else if (obj1[0] === 'fail') {
                                    $(".add-country").find(".course-submit").val("Submit");
                                    $(".errnotify").html("Please try again");

                                }
                            });

           });
           
            
	
});
</script>
<div class="maincontent">

    <div class="wrap" style="max-width: 600px">
    
        <div id="course-container" class="add-country" style="border-bottom: 1px solid #ccc">

                <div class="row-element">
                    <span class="title" style="padding: 0px;padding-top: 10px">Country</span>
                    <span class="content" style="padding: 0px"><select class="country"><option>India</option></select></span>
                </div>
            
                <div class="row-element">
                    <span class="title" style="padding: 0px;padding-top: 10px">State</span>
                    <span class="content" style="padding: 0px"><input class="state" type="text"></span>
                </div>

                 <div class="row-element">
                    <span class="content">
                        <input style="float: left" type="submit" class="course-submit" value="Submit">
                        <p class="errnotify" style="color:#aa3e41;margin:0px;padding:0px;float:left;padding-left:20px;padding-top:10px"> </p>
                    </span>
                </div>
                
            </div>

            
         <?php echo $this->table->generate();  ?>             
         
     
        </div>
    
    </div>
    


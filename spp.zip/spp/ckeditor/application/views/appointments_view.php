
<div id="pagetitle">

	<div class="wrap">
    
    	<h1>View Appointments</h1>
        
	</div>
    
</div>
<style type="text/css">


.dataTables_wrapper input[type="text"] {
    padding: 0;
}
.dataTables_wrapper select {
    padding: 0;
}
.sortable tr th {
    border-right: 1px solid #ddd;
    padding: 10px 0;font-size: 13px;
}
.sortable tr td {
    border-right: 1px solid #ddd;
    padding: 15px 5px;
    text-align: center;font-size: 13px;
    vertical-align: middle;
}
.sortable tr td a {
    color: #333;
}

#profile-right h2 {
    margin: 0px 0px 10px 0px;
}

.coursetable_length { width: auto !important; }
#coursetable_filter input { border: 1px solid #ccc; line-height: 25px;margin-left: 10px;}
.sortable tr td a:hover { text-decoration: underline; }
</style>
<script type="text/javascript">
$(document).ready(function(){	
		
	
          var columnData = [
                    { "data": "name" },
                    { "data": "phone" },
                     { "data": "age" },
                    { "data": "date" },
                    { "data": "time" },
                    { "data": "appfor" }
                  ];
         columnData.push( {data: "id","visible":true} );
        // columnData.push( {data: "memtype","visible":false} );
         
       
        var oTable = $('#coursetable').dataTable({
                    "bProcessing": true,
                    "bServerSide": true,
                    "sPaginationType": "full_numbers",
                    "ajax": {
                    "url": 'appointments/getAppointmentLists',
                    "type": "POST"
                     }, 
                     "oLanguage": {
                        "sProcessing": "<img src='<?php echo base_url(); ?>images/loader.gif'>"
                    },
                    'iDisplayLength': 25,
                    "columns": columnData,
                    "fnDrawCallback": function( oSettings ) {
                        
                        $("#coursetable").find(".del").each(function(){

                            $(this).click(function(){ 

                              if(confirm("Are you sure to delete this appointment ?")) {
                                    var ide = $(this).attr("id");
                                    $.get('appointments/delAppointment',{
                                            'ide':ide
                                        }, function(o) { 
                                            var obj1 = $.parseJSON(o);
                                            if (obj1[0] === 'success') {
                                                oTable.fnDraw();                                                
                                            } else if (obj1[0] === 'fail') {
                                                alert("Error!! PLease try again");
                                            }
                                    });
                                }
                                

                              });
                        
                        });
                            
                    }
         }); 

});
</script>
<div class="maincontent">

	<div class="wrap">
    
            
         <?php echo $this->table->generate();  ?>             
         
        
        
        </div>
    
    </div>
    


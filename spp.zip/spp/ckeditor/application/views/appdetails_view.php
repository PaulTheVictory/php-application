
<div id="pagetitle">

	<div class="wrap">
    
    	<h1>View Member</h1>
        
	</div>
    
</div>
<style type="text/css">
    .maincontent li{ list-style: none; padding: 5px;font-size: 14px;}
</style>
<div class="maincontent">

	<div class="wrap">

            <h3 style="text-align: center"> Appointment Details </h3>
           
            <style type="text/css">
                .innercontentwords tr td{ padding: 5px;}
                .innercontentwords tr td input { border: 1px solid #ccc;padding: 5px;}
                .innercontentwords tr td select,textarea { border: 1px solid #ccc;padding: 5px;}
                .innercontentwords tr td textarea { border: 1px solid #ccc;padding: 5px;width: 268px;}
            </style>
            <div class="wrap">
            <div id="innercontent">
                <div class="innercontentwords">
                    
                   
       <table width="98%" cellspacing="0" cellpadding="5" border="0" align="center" class="form" id="no-india"> 
         <tbody><tr> 
           <td class="bold-14" colspan="7"><h3><strong>Personal Details :</strong></h3> </td> 
           </tr> 
             <tr><td></td></tr>
         <tr> 
           <td width="172">Patients full Name </td> 
           <td width="5">:</td> 
           <td colspan="5"><?php echo $detail['name'];?>  </td> 
           </tr> 
         <tr> 
           <td>Age</td> 
           <td>:</td> 
           <td width="149"><?php echo $detail['age'];?>  
             &nbsp;&nbsp;Years</td> 
           <td colspan="2">&nbsp;  Sex</td> 
           <td width="26">:</td> 
           <td width="144"><?php echo $detail['sex'];?> </td> 
         </tr> 
         <tr> 
           <td>Country</td> 
           <td>:</td> 
           <td colspan="5"><?php echo $detail['country'];?> </td> 
           </tr> 
         <tr> 
           <td>State</td> 
           <td>:</td> 
           <td><?php echo $detail['state'];?> </td> 
           <td colspan="2">&nbsp;  City</td> 
           <td>:</td> 
           <td><?php echo $detail['city'];?> </td> 
         </tr> 
         <tr> 
           <td>Phone</td> 
           <td>:</td> 
           <td colspan="5"><?php echo $detail['phone'];?> </td> 
           </tr> 
         <tr> 
           <td>Email</td> 
           <td>:</td> 
           <td colspan="5"><?php echo $detail['email'];?> </td> 
           </tr> 
         <tr> 
           <td>Address</td> 
           <td>:</td> 
           <td colspan="5"><?php echo $detail['address'];?> </td> 
           </tr> 
         <tr> 
           <td height="30" colspan="7"><hr size="1" color="#D4D4D4"></td> 
         </tr> 
         <tr> 
           <td height="30" class="bold-14" colspan="7"><h3><strong>Medical Details :</strong></h3></td> 
           </tr> 
         <tr> 
           <td align="left">Brief of your dental problems</td> 
           <td>:</td> 
           <td colspan="5"><?php echo $detail['problem'];?> </td> 
           </tr> 
         <tr> 
           <td>History  of any other ailments </td> 
           <td>:</td> 
           <td colspan="5"><?php echo $detail['name'];?> </td> 
           </tr> 
         <tr> 
           <td>Appointment for </td> 
           <td>:</td> 
           <td colspan="5"><?php echo $detail['appfor'];?>  </td> 
           </tr> 
         <tr> 
           <td height="50" class="bold" colspan="7">If you were referred by any medical practitioner,  please provide their details : </td> 
         </tr> 
         <tr> 
           <td>Name</td> 
           <td>:</td> 
           <td colspan="5"><?php echo $detail['ref_name'];?> </td> 
           </tr> 
         <tr> 
           <td>Address</td> 
           <td>:</td> 
           <td colspan="5"><?php echo $detail['ref_address'];?> </td> 
           </tr> 
         <tr> 
           <td align="left">Preferred Appointment Schedule</td> 
           <td>:</td> 
           <td align="left">
               <?php echo $detail['date'];?> 
                  
                   </td> 
           <td width="3">&nbsp;</td> 
           <td width="54">Time</td> 
           <td>:</td> 
           <td><?php echo $detail['time'];?> </td> 
         </tr> 
         <tr> 
           <td>Any queries you may have </td> 
           <td>:</td> 
           <td colspan="5"><?php echo $detail['queries'];?> </textarea></td> 
           </tr> 
         <tr class="row-hide"> 
           <td>Extra</td> 
           <td>:</td> 
           <td><?php echo $detail['extra'];?> </td> 
           <td colspan="4">&nbsp;</td> 
           </tr> 
             <tr><td></td><td></td><td></td></tr>
              <tr><td></td><td></td><td></td></tr>
              <tr><td></td><td></td><td></td></tr>
              
         </tbody></table> 
       
                   </div>
                </div>
            </div>

            <div class="clear"></div>
           
        
        </div>
    
    </div>
    


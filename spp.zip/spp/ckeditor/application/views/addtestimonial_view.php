<div id="pagetitle">

	<div class="wrap">
    
    	<h1>Add Testimonial</h1>
        
	</div>
    
</div>
<div class="maincontent">

	<div class="wrap">
    
    <div style="margin-top: 0px; width: 100%; height: 50px; text-align: right;">
               <a style="padding: 10px; border: 1px solid rgb(0, 32, 96); color: #fff; margin: 0px auto; background: rgb(0, 32, 96) none repeat scroll 0% 0%; position: relative; top: 5px;margin-right:20px" class="btn" href="<?php echo base_url(); ?>testimonials">Back</a>
             </div> 
    
            <div id="course-container" class="add-course-date">
            
            <form enctype="multipart/form-data" method="post" id="testadd">
            
                <!--<div class="row-element">
                    <span class="title">Upload Only Image</span>                    
                    <span class="content"><input type="checkbox" name="onlyimg" class="onlyimg" value="No" /></span>
                </div>
                
                <div class="row-element">
                    <span class="title">Display Only Text</span>                    
                    <span class="content"><input type="checkbox" name="onlytxt" class="onlytxt" value="No" /></span>
                </div>

                <div class="row-element">
                    <span class="title">Title</span>
                    <span class="content">
                       <input type="text"  name="title" placeHolder="Title" class="testtitle" />
                    </span>
                </div>-->
                
                <div class="row-element">
                    <span class="title">Course Name</span>
                    <span class="content">
                        <select name="course" class="course" >
                            <?php echo $courselist; ?>   
                        </select>
                    </span>
                </div>

                
                 <div class="row-element">
                    <span class="title">Content</span>
                    <span class="content">
                       <textarea name="content" placeHolder="Content" class="content"></textarea>
                    </span>
                    <script>
                       CKEDITOR.replace( 'content' );
                   </script>
                </div>
                
                
                <div class="row-element">
                    <span class="title">Name</span>
                    <span class="content">
                       <input type="text"  name="name" placeHolder="Name" class="name" />
                    </span>
                </div>
                
                <!--<div class="row-element">
                    <span class="title">Is Active</span>                    
                    <span class="content"><input type="checkbox" value="No" name="active" class="active"></span>
                </div>-->
                
                <div class="row-element">
                    <span class="title">Show in front pages</span>                    
                    <span class="content"><input type="checkbox" value="No" name="frontpage" class="frontpage"></span>
                </div>
                
                <!--<div class="row-element">
                    <span class="title">Show in inner pages</span>                    
                    <span class="content"><input type="checkbox" value="No" name="innerpage" class="innerpage"></span>
                </div>-->
                
                 <div class="row-element">
                    <span class="title">Profile Photo</span>                    
                    <span class="content">
                    
            
            <div style="float:left; margin:10px 0 0 20px;">
            
      			<input size="50" type="file" name="photoToUpload" id="photoToUpload" value="Select image to upload" style="position: relative;text-align: right;-moz-opacity:0 ;filter:alpha(opacity: 0);opacity: 0;z-index: 2; float:left; height:30px; width:356px;" /> 
      
      			<div class="fakeinput fakephoto" style="position:absolute; border:1px solid #ccc; width:350px; height:28px;border-radius:4px; line-height: 28px; text-align:left; padding-left:5px; background:#fff; box-shadow: 0 1px 1px rgba(0, 0, 0, 0.075) inset; font-size:14px;">Select photo to upload</div>
      
        		<div style="clear:both;"></div>
                
                <p style="margin:6px 0;">* Supported only jpg, jpeg, png</p> 
                
                <p style="margin:6px 0;">* Maximum upload file size: 100KB</p> 
                
                <p style="margin:6px 0;">* Image should contain Width * Height: 96px * 126px</p> 
    
      			<!--<input class="imgupload" style="width:350px;" type="submit" value="Upload" />-->
            
            </div></span>
                </div>
                
                <div class="row-element">
                    <span class="title"></span>                    
                    <span class="content">
                    <div style="max-width:96px; max-height:126px;">
                        <img style="margin:0;width: 100%; height: auto;" class="upload-photo-m" src="<?php echo base_url(); ?>docs/courses/ap.jpg" />
                       </div>
                   </span>
                </div>
                
                
                <!--<div class="row-element">
                    <span class="title">Upload Image</span>                    
                    <span class="content">
                    
            
            <div style="float:left; margin:10px 0 0 20px;">
                
      			<input size="50" type="file" name="imageToUpload" id="imageToUpload" value="Select image to upload" style="position: relative;text-align: right;-moz-opacity:0 ;filter:alpha(opacity: 0);opacity: 0;z-index: 2; float:left; height:30px; width:356px;" /> 
      
      			<div class="fakeinput fakeimage" style="position:absolute; border:1px solid #ccc; width:350px; height:28px;border-radius:4px; line-height: 28px; text-align:left; padding-left:5px; background:#fff; box-shadow: 0 1px 1px rgba(0, 0, 0, 0.075) inset; font-size:14px;">Select image to upload</div>
      
        		<div style="clear:both;"></div>
                
                <p style="margin:6px 0;">* Supported only jpg, jpeg, png </p> 
                
                <p style="margin:6px 0;">* Maximum upload file size: 1MB</p>
                
                <p style="margin:6px 0;">* Image should contain Width * Height: 600px * 955px</p>  
        
            </div></span>
                </div>-->
                           
                
                 <div class="row-element">
                    <span class="title"></span>                    
                    <span class="content">
                        <input style="float: left" type="submit" class="course-submit" value="Submit">
                        <p class="errnotify" style="color:#aa3e41;margin:0px;padding:0px;float:left;padding-left:20px;padding-top:10px"> </p>
                    </span>
                </div>
                
                		<input type="hidden" value="Yes" name="active" class="active">
                		<input type="hidden" value="Yes" name="innerpage" class="innerpage">
                
                </form>
                
            </div>
        
        </div>
    
    </div>
<script type="text/javascript">
$(document).ready(function() {
	
	
	$("#photoToUpload,#imageToUpload").change(function(){
		
		var imgloc = $(this).val();
		var parelem = $(this).parent();		
		parelem.find(".fakeinput").text(imgloc);
		
		readURL(this);
		
	});
	
	
	function readURL(input) {

    if (input.files && input.files[0]) {
        var reader = new FileReader();
        	 
        reader.onload = function (e) {
            $('.upload-photo-m').attr('src', e.target.result);
        }

        reader.readAsDataURL(input.files[0]);
    }
}


$(".onlyimg").change(function(){
	
	if($(this).is(":checked"))
	{
		$(".testtitle,#photoToUpload").attr('disabled','disabled');
		CKEDITOR.instances.content.setReadOnly(true);
	}
	else
	{
		$(".testtitle,#photoToUpload").removeAttr('disabled');
		CKEDITOR.instances.content.setReadOnly(false);
	}
});

$(".onlytxt").change(function(){
	
	if($(this).is(":checked"))
	{
		$(".testtitle,#photoToUpload,#imageToUpload").attr('disabled','disabled');
	}
	else
	{
		$(".testtitle,#photoToUpload,#imageToUpload").removeAttr('disabled');
	}
});
	
	
	$(".add-course-date").find("input").each(function(){

          $(this).click(function(){ $(".errnotify").html("&nbsp;");});

    });
	
	//$(".add-course-date").find(".course-submit").click(function(){
		
		$("#testadd").submit(function(e){
		
		         e.preventDefault();
		
		        //var title = $(".add-course-date").find(".testtitle").val();
                var content = $(".add-course-date textarea").val();
				var name = $(".add-course-date").find(".name").val();
				var content = CKEDITOR.instances.content.getData();
				var check1 = false; var check2 = false; var check3 = false;
                var course = $(".add-course-date").find(".course").val();				
				
				if($(".add-course-date").find(".onlytxt").is(":checked") && $(".add-course-date").find(".onlyimg").is(":checked")){
					alert('Please choose required checkbox');return;
				}
				
                /*if($(".add-course-date").find(".active").is(":checked")){
					
                   var active = "Yes";
					$(".add-course-date").find(".active").val(active);
					
					check1 = true;
					
                }*/
				
                if($(".add-course-date").find(".frontpage").is(":checked")){
					
                    var frontpage = "Yes";
					$(".add-course-date").find(".frontpage").val(frontpage);
					
					/*check2 = true;
					
					if(title === ""){ $(".errnotify").html("Please provide Title");return;}	
                
                    if(content === ""){ $(".errnotify").html("Please provide content");return;}
					
					if(name === ""){ $(".errnotify").html("Please provide name");return;}*/
					
                }
				
                /*if($(".add-course-date").find(".innerpage").is(":checked")){
					
                    var innerpage = "Yes";
					$(".add-course-date").find(".innerpage").val(innerpage);
					
					check2 = true;
					
					if($(".add-course-date").find(".onlyimg").is(":checked")){
						
						var onlyimg = "Yes";
					    $(".add-course-date").find(".onlyimg").val(onlyimg);
						
						if(name === ""){ $(".errnotify").html("Please provide name");return;} 
						
						if ($(".fakeimage").text()=="Select image to upload"){
						$(".errnotify").html('Please select an image to upload');
						return;
						   }
					
					}
					
                    
					if($(".add-course-date").find(".onlytxt").is(":checked")){
						
						var onlytxt = "Yes";
					    $(".add-course-date").find(".onlytxt").val(onlytxt);
						
						if(name === ""){ $(".errnotify").html("Please provide name");return;} 
					
					}
					
					
					if($(".add-course-date").find(".onlytxt").not(":checked").length && $(".add-course-date").find(".onlyimg").not(":checked").length){
					
					if(name === ""){ $(".errnotify").html("Please provide name");return;} 
					
					if(content === ""){ $(".errnotify").html("Please provide content");return;}
					
					if ($(".fakephoto").text()=="Select photo to upload"){
					$(".errnotify").html('Please select an photo to upload');
					return;
				       }
					
					}
									
                }
				
				if(check2=== false && check3=== false){alert('Please choose display page');return;}*/
				
				var formdata = new FormData(this);
		        formdata.append("content", content);
		
		       $(".add-course-date").find(".course-submit").val("Processing...");
		
			if($(".add-course-date").find(".course-submit").hasClass('process')){

				$(".add-course-date").find(".course-submit").val("Processing wait...");
			}
			else{
			
			$(".add-course-date").find(".course-submit").addClass('process');
		
				$.ajax({
						url: "addtestimonial/insertTestimonial", // Url to which the request is send
						type: "POST",             // Type of request to be send, called as method
						data: formdata, // Data sent to server, a set of key/value pairs (i.e. form fields and values)
						contentType: false,       // The content type used when sending data to the server.
						cache: false,             // To unable request pages to be cached
						processData:false,        // To send DOMDocument or non processed data file it is set to false
						success: function(o)   // A function to be called if request succeeds
						{
							var obj1 = $.parseJSON(o);
							
							if(obj1[0] === 'success'){
									
								 $(".errnotify").html("<font style=\"color:#188f04\">Testimonial has been added succesfully!!</font>");
								setTimeout(function(){ location.assign("testimonials");$(".add-course-date").find(".course-submit").removeClass('process');}, 500);
														
							}else if(obj1[0] === 'fail'){
								
							   $(".add-course-date").find(".course-submit").val("Submit");
							   alert("Error!! Please try again");
							   $(".add-course-date").find(".course-submit").removeClass('process');
									                           
							}else if(obj1[0] === 'pfail'){
								
							   $(".add-course-date").find(".course-submit").val("Submit");
							   alert("Photo not uploaded.Please try again");
							   $(".add-course-date").find(".course-submit").removeClass('process');
									                           
							}
					
				}
				});	
			}
		
  	});
	
});
</script>
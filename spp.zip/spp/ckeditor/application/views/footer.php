<div id="footer">



	<div class="wrap">

    

    	<span class="copyright">Access Dental Institute &copy; <?php echo date('Y');?></span>

        

        <div class="clear"></div>

        

        

    </div>



</div>





<script src="<?php echo base_url(); ?>js/jquery.dlmenu.js" type="text/javascript"></script>

<script>

	$(function() {

		$( '#mobilemenu' ).dlmenu();

	});

</script>





</body>

</html>
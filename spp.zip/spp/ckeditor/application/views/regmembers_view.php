
<div id="pagetitle">

	<div class="wrap">
    
    	<h1>Registered Member List</h1>
        
	</div>
    
</div>
<style type="text/css">

#regtable_filter input {
    border: 1px solid #ccc;
    line-height: 25px;
    margin-left: 10px;
}

.dataTables_wrapper input[type="text"] {
    padding: 0;
}
.dataTables_wrapper select {
    padding: 0;
}
.sortable tr th {
    border-right: 1px solid #ddd;
    padding: 10px 0;
    font-size: 13px;
    vertical-align: middle;
}
.sortable tr td {
    border-right: 1px solid #ddd;
    padding: 15px 5px;
    text-align: center;font-size: 13px;vertical-align: middle;
}
.sortable tr td a {
    color: #333;
}

.sortable tr td:first-child {
    width: 20%;
}

.sortable tr td:nth-child(2) {
    width: 20%;
}

.sortable tr td:nth-child(3) {
    width: 15%;
}

.sortable tr td:nth-child(4) {
    width: 10%;
}

.sortable tr td:nth-child(5) {
    width: 10%;
}

.sortable tr td:nth-child(6) {
    width: 10%;
}

.sortable tr td:nth-child(7) {
    width: 5%;
}

#profile-right h2 {
    margin: 0px 0px 10px 0px;
}
.sorting {
    background: #666 none no-repeat scroll right center !important;
    color: #fff;
}

.coursetable_length { width: auto !important; }
#coursetable_filter input { border: 1px solid #ccc; line-height: 25px;margin-left: 10px;}
.sortable tr td a:hover { text-decoration: underline; }

</style>
<script type="text/javascript">
$(document).ready(function(){	
		
	
          var columnData = [
                    { "data": "name" },
                    { "data": "selcourse" },
                    { "data": "regno" },
					{ "data": "email" },
                    { "data": "mobile" },
                    { "data": "state" }
                    
                  ];
         columnData.push( {data: "id","visible":true} );
         
       
        var oTable = $('#regtable').dataTable({
                    "bProcessing": true,
                    "bServerSide": true,
                    "aaSorting": [[ 4, "desc" ]],
                    "sPaginationType": "full_numbers",
                    "ajax": {
                    "url": 'regmembers/getRegisteredMembers',
                    "type": "POST"
                     }, 
                     "oLanguage": {
                        "sProcessing": "<img src='<?php echo base_url(); ?>images/loader.gif'>"
                    },
                    'iDisplayLength': 10,
                    "columns": columnData,
                    "fnDrawCallback": function( oSettings ) {
                            
                            $("#regtable").find(".del").each(function(){

                            $(this).click(function(){ 

                              if(confirm("Are you sure to delete this member ?")) {
                                    var ide = $(this).attr("id");
                                    $.get('regmembers/delMembers',{
                                                               'ide':ide

                                                    }, function(o) { 
                                                            var obj1 = $.parseJSON(o);
                                                    if (obj1[0] === 'success') {
                                                        oTable.fnDraw(); 
                                                    } else if (obj1[0] === 'fail') {
                                                       alert("Error!!! please try again");
                                                }
                                    });
                                }

                              });
                        

                          });
                            
                    }
         }); 
         
    	
	
});
</script>
<div class="maincontent">

	<div class="wrap">
    
              
         <?php echo $this->table->generate();  ?>             
         
        
        
        </div>
    
    </div>
    


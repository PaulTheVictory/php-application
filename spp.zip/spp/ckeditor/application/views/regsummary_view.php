
<div id="pagetitle">

	<div class="wrap">
    
    	<h1>Registration List</h1>
        
	</div>
    
</div>
<style type="text/css">

#regtable_filter input {
    border: 1px solid #ccc;
    line-height: 25px;
    margin-left: 10px;
}

.dataTables_wrapper input[type="text"] {
    padding: 0;
}
.dataTables_wrapper select {
    padding: 0;
}
.sortable tr th {
    border-right: 1px solid #ddd;
    padding: 10px 0;
    font-size: 13px;
    vertical-align: middle;
}
.sortable tr td {
    border-right: 1px solid #ddd;
    padding: 15px 5px;
    text-align: center;font-size: 13px;
}
.sortable tr td a {
    color: #333;
}

#profile-right h2 {
    margin: 0px 0px 10px 0px;
}
.sorting {
    background: #666 none no-repeat scroll right center !important;
    color: #fff;
}

.coursetable_length { width: auto !important; }
#coursetable_filter input { border: 1px solid #ccc; line-height: 25px;margin-left: 10px;}
.sortable tr td a:hover { text-decoration: underline; }
</style>
<script type="text/javascript">
$(document).ready(function(){	
		
	
          var columnData = [
                    { "data": "course_name" },
                    /*{ "data": "place" },*/
                    { "data": "date1" },
                    { "data": "date2" },
                    /*{ "data": "date3" },
                    { "data": "date4" },*/
                    { "data": "active" },
                    /*{ "data": "seatavail" },
                    { "data": "seats" },*/
                    { "data": "frontpage" } 
                    
                  ];
         columnData.push( {data: "date","visible":false} );
        // columnData.push( {data: "memtype","visible":false} );
         
       
        var oTable = $('#regtable').dataTable({
                    "bProcessing": true,
                    "bServerSide": true,
                    "aaSorting": [[ 5, "desc" ]],
                    "sPaginationType": "full_numbers",
                    "ajax": {
                    "url": 'regsummary/getRegistrationLists',
                    "type": "POST"
                     }, 
                     "oLanguage": {
                        "sProcessing": "<img src='<?php echo base_url(); ?>images/loader.gif'>"
                    },
                    'iDisplayLength': 10,
                    "columns": columnData,
                    "fnDrawCallback": function( oSettings ) {
                            
                    }
         }); 
         
         $("#mem_filter").change(function(){
            var result = $(this).val();
            oTable.dataTable().fnFilter(result);
        });
	
	
});
</script>
<div class="maincontent">

	<div class="wrap">
    
              
         <?php echo $this->table->generate();  ?>             
         
        
        
        </div>
    
    </div>
    


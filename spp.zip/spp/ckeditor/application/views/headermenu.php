				



                <?php if(isset($user)){ ?>







                    <li><a href="<?php echo base_url(); ?>dashboard">Courses</a>







                                       <ul class="dl-submenu">







                                           <li><a href="<?php echo base_url(); ?>dashboard">Course List</a></li>



                                             <li><a href="<?php echo base_url(); ?>regsummary">Course Scheduled Summary</a></li>



                                           <li><a href="<?php echo base_url(); ?>regmembers">Course Registration Summary</a></li>



                                         







                                       </ul>







                    </li>



                



                <li><a href="<?php echo base_url(); ?>testimonials">Testimonials</a></li>



                 



                <li><a href="<?php echo base_url(); ?>gallery">Gallery</a></li>











                <li><a href="<?php echo base_url(); ?>login/logout" class="btn">Logout</a></li>



                    



				<?php }else{ ?>



                



                	<li><a href="<?php echo $this->config->item('web_base_url'); ?>">Home</a></li>



                



                <?php } ?>



				



                

<div id="pagetitle">

	<div class="wrap">
    
    	<h1>Edit Schedule</h1>
        
	</div>
    
</div>
<div class="maincontent">

	<div class="wrap">
    
            <div id="course-container" class="add-course-date">

                
                 <div class="row-element">
                    <span class="title">Date</span>
                    <span class="content">
                        <input type="text"  name="date" id="date" placeHolder="" class="datepicker" value="<?php echo $edit["date"];?>" />
                    </span>
                </div>
                
                <div class="row-element">
                    <span class="title">Location</span>
                    <span class="content"><input type="text" class="location" name="location" value="<?php echo $edit["location"];?>"></span>
                </div>
                
                <div class="row-element">
                    <span class="title">Topic</span>
                    <span class="content">
                       <input type="text"  name="topic" id="topic" placeHolder="" class="topic" value="<?php echo $edit["topic"];?>"/>
                    </span>
                </div>
                
                <div class="row-element">
                    <span class="title">Is Active</span>                    
                    <span class="content"><?php echo $edit["active"]; ?></span>
                </div>
                
                 <div class="row-element">
                    <span class="title"></span>                    
                    <span class="content">
                        <input style="float: left" type="submit" class="course-submit" value="Submit">
                        <p class="errnotify" style="color:#aa3e41;margin:0px;padding:0px;float:left;padding-left:20px;padding-top:10px"> </p>
                    </span>
                </div>
                
            </div>
        
        </div>
    
    </div>
<script type="text/javascript">
$(document).ready(function() {
	
	
	$(".add-course-date").find("input").each(function(){

          $(this).click(function(){ $(".errnotify").html("&nbsp;");});

    });
	
	$(".add-course-date").find(".course-submit").click(function(){
		
		var location = $(".add-course-date").find(".location").val();
                var topic = $(".add-course-date").find(".topic").val();
                var date = $(".add-course-date").find("#date").val();
                var active = "No";
                if($(".add-course-date").find(".active").is(":checked")){
                    active = "Yes";
                } 
                
               
		if(location === ""){ $(".errnotify").html("Please provide course name");return;}	
                if(topic === ""){ $(".errnotify").html("Please provide no of seats");return;}	
                if(date === ""){ $(".errnotify").html("Please provide atleast one date");return;}
           
		
		$(this).val("Processing...");
		
				$.get('editschedule/updateSchedule',{
					   'location':location, 
                                           'topic':topic, 
					   'date':date,
                                           'active':active,
                                           'id':'<?php echo $edit['id'];?>'
                                           

				}, function(o) { 
					var obj1 = $.parseJSON(o);
					if(obj1[0] === 'success'){
						    
                                            $(".errnotify").html("<font style=\"color:#188f04\">Schedule has been edited succesfully!!</font>");
					    setTimeout(function(){ window.location.assign("addschedule"); }, 500);
                                                
					}else if(obj1[0] === 'fail'){
                                                   $(".add-course-date").find(".course-submit").val("Submit");
                                                   alert("Error!! Please try again");                                                    
						
					}
				});	 
		
  	});
	
});
</script>
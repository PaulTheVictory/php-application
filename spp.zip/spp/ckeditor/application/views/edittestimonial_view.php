<div id="pagetitle">

	<div class="wrap">
    
    	<h1>Edit Testimonial</h1>
        
	</div>
    
</div>
<div class="maincontent">

	<div class="wrap">
    
     <div style="margin-top: 0px; width: 100%; height: 50px; text-align: right;">
               <a style="padding: 10px; border: 1px solid rgb(0, 32, 96); color: #fff; margin: 0px auto; background: rgb(0, 32, 96) none repeat scroll 0% 0%; position: relative; top: 5px;margin-right:20px" class="btn" href="<?php echo base_url(); ?>testimonials">Back</a>
             </div> 
    
            <div id="course-container" class="edit-course-date">
            
            <form enctype="multipart/form-data" method="post" id="testedit">
                
                 <!--<div class="row-element">
                    <span class="title">Upload Only Image</span>                    
                    <span class="content"><?php //echo $testdetails["onlyimage"]; ?></span>
                </div>
                
                <div class="row-element">
                    <span class="title">Display Only Text</span>                    
                    <span class="content"><?php //echo $testdetails["onlytext"]; ?></span>
                </div>
                
                <div class="row-element">
                    <span class="title">Title</span>
                    <span class="content">
                       <input type="text"  name="title" placeHolder="Title" class="testtitle"  value="<?php //echo $testdetails['title']; ?>"/>
                    </span>
                </div>-->
                
                <div class="row-element">
                    <span class="title">Course Name</span>
                    <span class="content">
                        <select name="course" class="course" >
                            <?php echo $courselist; ?>   
                        </select>
                    </span>
                </div>

                
                 <div class="row-element">
                    <span class="title">Content</span>
                    <span class="content">
                       <textarea name="content" placeHolder="Content" class="content"><?php echo $testdetails['content']; ?></textarea>
                    </span>
                     <script>
                       CKEDITOR.replace( 'content' );
                   </script>
                </div>
                
                
                <div class="row-element">
                    <span class="title">Name</span>
                    <span class="content">
                       <input type="text"  name="name" placeHolder="Name" class="name"  value="<?php echo $testdetails['name']; ?>"/>
                    </span>
                </div>
                
                
                <!--<div class="row-element">
                    <span class="title">Is Active</span>                    
                    <span class="content"><?php //echo $testdetails["active"]; ?></span>
                </div>-->
                
                <div class="row-element">
                    <span class="title">Show in front pages</span>                    
                    <span class="content"><?php echo $testdetails["frontpage"]; ?></span>
                </div>
                
                <!--<div class="row-element">
                    <span class="title">Show in inner pages</span>                    
                    <span class="content"><?php //echo $testdetails["innerpage"]; ?></span>
                </div>-->
                
                 <div class="row-element">
                    <span class="title">Upload Photo</span>                    
                    <span class="content">
                  
                  <?php if($testdetails["photo"]!=""){ ?>   
              <div style="max-width:96px; max-height:126px;">      
            <img style="margin:0;width: 100%; height: auto;" class="upload-photo-m" src="<?php echo base_url().'docs/testimonial/photo/'.$testdetails["photo"]; ?>" />
            </div>
            
            <?php } ?> 
            
            <div style="float:left; margin:10px 0 0 20px;">
            
      			<input size="50" type="file" name="photoToUpload" id="photoToUpload" value="Select image to upload" style="position: relative;text-align: right;-moz-opacity:0 ;filter:alpha(opacity: 0);opacity: 0;z-index: 2; float:left; height:30px; width:356px;" /> 
                
                <input type="hidden" name="photo"  value="<?php echo $testdetails['photo'];?>">
                <input type="hidden" name="id"  value="<?php echo $testdetails['id'];?>">
      
      			<div class="fakeinput fakephoto" style="position:absolute; border:1px solid #ccc; width:350px; height:28px;border-radius:4px; line-height: 28px; text-align:left; padding-left:5px; background:#fff; box-shadow: 0 1px 1px rgba(0, 0, 0, 0.075) inset; font-size:14px;">Select photo to upload</div>
      
        		<div style="clear:both;"></div>
                
                <p style="margin:6px 0;">* Supported only jpg, jpeg, png</p> 
                
                <p style="margin:6px 0;">* Maximum upload file size: 100KB</p> 
                
                <p style="margin:6px 0;">* Image should contain Width * Height: 96px * 126px</p> 
    
      			<!--<input class="imgupload" style="width:350px;" type="submit" value="Upload" />-->
            
            </div></span>
                </div>
                
                <div class="row-element">
                    <span class="title"></span>                    
                    <span class="content">
                    <div style="max-width:96px; max-height:126px;">
                        <img style="margin:0;width: 100%; height: auto;" class="upload-photo-m preview" src="<?php echo base_url(); ?>docs/courses/ap.jpg" />
                       </div>
                   </span>
                </div>

                
                
                <!--<div class="row-element">
                    <span class="title">Upload Image</span>                    
                    <span class="content">
                    
                 <?php if($testdetails["image"]!=""){ ?>   
             <div style="max-width:200px; max-height:200px;">       
            <img style="margin:0;width: 100%; height: auto;" class="upload-photo-m" src="<?php //echo $testdetails["image"]; ?>" />
            </div>
            <?php } ?>
            
            <div style="float:left; margin:10px 0 0 20px;">
                
      			<input size="50" type="file" name="imageToUpload" id="imageToUpload" value="Select image to upload" style="position: relative;text-align: right;-moz-opacity:0 ;filter:alpha(opacity: 0);opacity: 0;z-index: 2; float:left; height:30px; width:356px;" /> 
                
                <input type="hidden" name="image"  value="<?php //echo $testdetails['image'];?>">
      
      			<div class="fakeinput fakeimage" style="position:absolute; border:1px solid #ccc; width:350px; height:28px;border-radius:4px; line-height: 28px; text-align:left; padding-left:5px; background:#fff; box-shadow: 0 1px 1px rgba(0, 0, 0, 0.075) inset; font-size:14px;">Select image to upload</div>
      
        		<div style="clear:both;"></div>
                
                <p style="margin:6px 0;">* Supported only jpg, jpeg, png </p> 
                
                <p style="margin:6px 0;">* Maximum upload file size: 1MB</p>
                
                <p style="margin:6px 0;">* Image should contain Width * Height: 600px * 955px</p>  
        
            </div></span>
                </div>-->               
                
                 <div class="row-element">
                    <span class="title"></span>                    
                    <span class="content">
                        <input style="float: left" type="submit" class="course-submit" value="Submit">
                        <p class="errnotify" style="color:#aa3e41;margin:0px;padding:0px;float:left;padding-left:20px;padding-top:10px"> </p>
                    </span>
                </div>
                
                		<input type="hidden" value="Yes" name="active" class="active">
                		<input type="hidden" value="Yes" name="innerpage" class="innerpage">
                
                </form>
                
            </div>
        
        </div>
    
    </div>
<script type="text/javascript">
$(document).ready(function() {
	
	
	var courseid = "<?php echo $testdetails["courseid"]; ?>";
	
	$(".course option[value='"+courseid+"']").prop("selected",true);
	
		$("#photoToUpload,#imageToUpload").change(function(){
		
		var imgloc = $(this).val();
		var parelem = $(this).parent();		
		parelem.find(".fakeinput").text(imgloc);
		
		readURL(this);
		
	});
	
	
	function readURL(input) {

    if (input.files && input.files[0]) {
        var reader = new FileReader();
        	 
        reader.onload = function (e) {
            $('.preview').attr('src', e.target.result);
        }

        reader.readAsDataURL(input.files[0]);
    }
}
  
  
  /*var checkimage = "<?php echo $testdetails['oimage'];?>";
  var checktext = "<?php echo $testdetails['otext'];?>";
  
	if(checkimage=="Yes")
	{
		$(".content,.testtitle,#photoToUpload").attr('disabled','disabled');
	}
	else
	{
		$(".testtitle,#photoToUpload").removeAttr('disabled');
	}

	
	if(checktext=="Yes")
	{
		$(".testtitle,#photoToUpload,#imageToUpload").attr('disabled','disabled');
	}
	else
	{
		$(".testtitle,#photoToUpload,#imageToUpload").removeAttr('disabled');
	}*/

	
	$(".edit-course-date").find("input").each(function(){

          $(this).click(function(){ $(".errnotify").html("&nbsp;");});

    });
	
	//$(".edit-course-date").find(".course-submit").click(function(){
		
		
		$("#testedit").submit(function(e){
		
		         e.preventDefault();
		
		        var title = $(".edit-course-date").find(".testtitle").val();
                var content = $(".edit-course-date textarea").val();
				var name = $(".edit-course-date").find(".name").val();
				var id = '<?php echo $_GET['id'];?>';
                var content = CKEDITOR.instances.content.getData();
				
				var active = $(".edit-course-date").find(".active").val();
				var frontpage = $(".edit-course-date").find(".frontpage").val();
				var innerpage = $(".edit-course-date").find(".innerpage").val();
				
				var check1 = false; var check2 = false; var check3 = false;
                				
				var course = $(".edit-course-date").find(".course").val();
			
                /*if($(".edit-course-date").find(".active").is(":checked") || active=="Yes"){
					
                    active = "Yes";
					$(".edit-course-date").find(".active").val(active);
					
					check1 = true;
					
                }*/
				
                if($(".edit-course-date").find(".frontpage").is(":checked") || frontpage=="Yes"){
					
                    frontpage = "Yes";
					$(".edit-course-date").find(".frontpage").val(frontpage);
					
					/*check2 = true;
					
					if(title === ""){ $(".errnotify").html("Please provide Title");return;}	
                
                    if(content === ""){ $(".errnotify").html("Please provide content");return;}
					
					if(name === ""){ $(".errnotify").html("Please provide name");return;}*/
					
                }
				
                /*if($(".edit-course-date").find(".innerpage").is(":checked") || innerpage=="Yes"){
					
                    innerpage = "Yes";
					$(".edit-course-date").find(".innerpage").val(innerpage);
					
					check2 = true;
					
					if(checkimage=="Yes"){
						
						var onlyimg = "Yes";
					    $(".add-course-date").find(".onlyimg").val(onlyimg);
						
						if(name === ""){ $(".errnotify").html("Please provide name");return;} 
						
						<?php if($testdetails['image']==""){ ?>
						if ($(".fakeimage").text()=="Select image to upload"){
						$(".errnotify").html('Please select an image to upload');
						return;
						   }
						   <?php } ?>
					
					}
					
					
					if(checktext=="Yes"){
						
						if(name === ""){ $(".errnotify").html("Please provide name");return;} 
						
						var onlytxt = "Yes";
					    $(".add-course-date").find(".onlytxt").val(onlytxt);
					
					}

					if(checkimage=="No" && checktext=="No"){
						
						
					<?php if($testdetails['photo']==""){ ?>
					
					if ($(".fakephoto").text()=="Select photo to upload"){
					$(".errnotify").html('Please select an photo to upload');
					return;
				       }
					   
					 <?php }?>
					 
					}
					 
					 if($(".edit-course-date").find(".onlytxt").not(":checked").length && $(".edit-course-date").find(".onlyimg").not(":checked").length){ 
					
					if(name === ""){ $(".errnotify").html("Please provide name");return;} 
					
					if(content === ""){ $(".errnotify").html("Please provide content");return;}
					
					if ($(".fakephoto").text()=="Select photo to upload"){
					$(".errnotify").html('Please select an photo to upload');
					return;
				       }
				
                   }
				
				}
				
				if(check2=== false && check3=== false){alert('Please choose display page');return;}*/
                
		var formdata = new FormData(this);
		formdata.append("content", content);
					
			 $(".edit-course-date").find(".course-submit").val("Processing...");
		
			if($(".edit-course-date").find(".course-submit").hasClass('process')){

				$(".edit-course-date").find(".course-submit").val("Processing wait...");
			}
			else{
			
			$(".edit-course-date").find(".course-submit").addClass('process');
		
				$.ajax({
						url: "edittestimonial/UpdateTestimonial", // Url to which the request is send
						type: "POST",             // Type of request to be send, called as method
						data: formdata, // Data sent to server, a set of key/value pairs (i.e. form fields and values)
						contentType: false,       // The content type used when sending data to the server.
						cache: false,             // To unable request pages to be cached
						processData:false,        // To send DOMDocument or non processed data file it is set to false
						success: function(o)   // A function to be called if request succeeds
						{
							//alert(o);
							var obj1 = $.parseJSON(o);
							
							if(obj1[0] === 'success'){
									
								 $(".errnotify").html("<font style=\"color:#188f04\">Testimonial has been edited succesfully!!</font>");
								setTimeout(function(){ location.assign("testimonials");$(".edit-course-date").find(".course-submit").removeClass('process');}, 500);
														
							}else if(obj1[0] === 'fail'){
								
							   $(".edit-course-date").find(".course-submit").val("Submit");
							   alert("Error!! Please try again");
								$(".edit-course-date").find(".course-submit").removeClass('process');
									                           
							}else if(obj1[0] === 'pfail'){
								
							   $(".edit-course-date").find(".course-submit").val("Submit");
							   alert("Photo not uploaded.Please try again");
								$(".edit-course-date").find(".course-submit").removeClass('process');
									                           
							}
					
				}
				});
			}
		
  	});
	
});
</script>
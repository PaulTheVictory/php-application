<div id="pagetitle">



	<div class="wrap">

    

    	<h1>Gallery</h1>

        

	</div>

    

</div>

<div class="maincontent">

    <div class="wrap">



        <ul id="album-list">



            <?php echo $allalbums['album_list']; ?>



        </ul>



    </div>

</div>



<style type="text/css">

    #album-list li {

    cursor: pointer;

    float: left;

    height: 280px;

    list-style: outside none none;

    margin: 5px 15px;

    position: relative;

    width: 190px;
	overflow: hidden;

}



.album-photo {

    border: 1px solid #aaa;

    height: 140px;

    padding: 2px;

    width: 175px;

}

</style>

<script type="text/javascript">

$(document).ready(function(){	



	$(".alist").click(function(){

		

		var albumid = $(this).attr("id");

        		

		window.location.href = "<?php  echo base_url(); ?>album?id="+albumid;		

		

	});

	

		

	$(".addalbum").click(function(){

				

			var albumname=prompt("Enter Album Name","");

			if (albumname!=null && albumname!=""){

						

                 $.get('gallery/createAlbum',{

                       'albumname':albumname			   



                 }, function(o) { 

				 		var obj1 = $.parseJSON(o);

						if(obj1[0] == 'exists'){

							alert("Album Already Exists");						

						}else if(obj1[0] == 'success'){

				 			setTimeout(function(){ location.reload();}, 200);

						}else if(obj1[0] == ''){

							alert("Try Again Later");

							setTimeout(function(){ location.reload(); }, 1000);

						}

                 });	 

			

			}		

		

	});



});



</script>


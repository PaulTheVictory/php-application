<script src="<?php echo base_url(); ?>js/dropzone.js" type="text/javascript"></script>

<script src="<?php echo base_url(); ?>js/jquery.fancybox.pack.js" type="text/javascript"></script>

<script src="<?php echo base_url(); ?>js/jquery.fancybox-thumbs.js" type="text/javascript"></script>



<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/jquery.fancybox-thumbs.css" type="text/css">

<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/jquery.fancybox.css" type="text/css">

<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/dropzone.css" type="text/css">

<style type="text/css">

    

    .gallery-thumb {

    border: 1px solid #aaa;

    float: left;

    height: 140px;

    margin: 10px 15px;

    padding: 2px;

    width: 175px;

}

	select.addtocourse {
    font-family: 'Lato', sans-serif;
    color: #333;
    border: 1px solid #ccc;
    font-size: 16px;
    padding: 8px;
    display: inline-block;
    margin: 0 0 20px;
    outline: none;
    background: #fff;
    box-sizing: border-box;
    width: auto;
}
	
</style>

<div id="pagetitle">



	<div class="wrap">

    <?php 
		$albexp = explode('-',$albumdetails['albumname']);
		
		if($albumdetails['coursename']!=""){$coursename = $albumdetails['coursename']." - ";}else {$coursename = "";}
	?>
    
    	<h1>Album - <?php if(isset($albexp[1])) echo $coursename.$albexp[1]; else {echo $coursename.$albexp[0];} ?><span class="editalbumname" style="cursor: pointer;float: none; padding-left: 10px; font-size: 11px;">Edit</span>
            
            <a style="cursor: pointer; float: right; font-size: 12px; padding-left: 22px; line-height: 30px;" class="editalbum" href="<?php echo base_url(); ?>album/editalbum?id=<?php echo $albumdetails['albumid']; ?>"><span>Edit Album</span></a>

            <span class="deletealbum" style="cursor: pointer;margin-top: 0px; float: right; font-size: 12px; line-height: 30px;">Delete Album</span></h1>


	</div>

    

</div>

<div class="maincontent">

<div class="wrap">

	<h2>Select Course:</h2>
		<select name="addtocourse" class="addtocourse" >
			<?php echo $courselist; ?>   
		</select>
    

    <div style="clear:both; height:75px;"></div>

    

    <div>

    

    	<?php

		

			if($totimages=='')

			{

				echo '<p>There are no images in this Album.</p>';

			}

			elseif(count($totimages)) {

				$index = 0;

				foreach($totimages as $file) {

					$index++;					

					if(!is_dir($file['thump'])){

						echo '<a href="'.$file['image'].'" class="fancybox-thumb" rel="fancybox-thumb"><img class="gallery-thumb" src="'.$file['thump'].'" /></a>';

					}

		

				}

				echo '<div class="clear"></div>';

			}

			else {

				echo '<p>There are no images in this Album.</p>';

			}

			

		?>

    

    </div>

    

    <div style="clear:both; height:30px;"></div>

    

    <form action="album/uploadPhoto" method="post" class="dropzone" id="myDrop">

    <input type="hidden" name="albumid" value="<?php echo $albumdetails['albumid']; ?>" />

  	<div class="fallback">    	

    	<input name="file" type="file" multiple />

  	</div>

	</form>

    

    

	<div style="clear:both; height:75px;"></div>

 </div>   

</div>



<style type="text/css">

    #page-title h1 span {

    color: #333;

    cursor: pointer;

    float: right;

    font-size: 14px;

    margin: 10px;

    text-align: right;

}

    

</style>

<script type="text/javascript">

$(document).ready(function(){

	var courseid = "<?php echo $albumdetails['courseid']; ?>";

	$(".addtocourse option[value='"+courseid+"']").prop('selected',true);

	$(".editalbumname").click(function(){

		

		var albumid = "<?php echo $albumdetails['albumid']; ?>";

		

		var albumname=prompt("Enter Album Name","<?php echo $albumdetails['albumname']; ?>");

			if (albumname!=null && albumname!="" && albumname!="<?php echo $albumdetails['albumname']; ?>"){

						

                 $.get('album/editAlbumName',{

					 	'albumid':albumid,

                       'albumname':albumname			   



                 }, function(o) { 

				 		var obj1 = $.parseJSON(o);

						if(obj1[0] == 'success'){

				 			setTimeout(function(){ location.reload();}, 200);

						}else if(obj1[0] == ''){

							alert("Try Again Later");

							setTimeout(function(){ location.reload(); }, 1000);

						}

                 });	 

			

			}

		

	});

	

	$(".deletealbum").click(function(){

		

		var albumid = "<?php echo $albumdetails['albumid']; ?>";

		

			var r=confirm("Are you sure to delete the Album ?")

			if (r==true){

						

                 $.get('album/deleteAlbum',{

                       'albumid':albumid			   



                 }, function(o) { 

                           setTimeout(function(){ location.assign("gallery");}, 500);         

                 }, 'json');

			

			}

		

	});

	

	$(".addtocourse").change(function(){

		

		var albumid = "<?php echo $albumdetails['albumid']; ?>";
		var courseid = $(this).val();

		//if(courseid=="") return false;
		
		var r=confirm("Are you sure to add the course ?")

		if (r==true){
		
		 $.get('album/addtoCourse',{

			   'albumid':albumid,
			 'courseid':courseid



		 }, function(o) { 

				   setTimeout(function(){ location.assign("album?id="+albumid);}, 500);         

		 }, 'json');

		}

		});



	$(".fancybox-thumb").fancybox({

		openEffect	: 'elastic',

		closeEffect	: 'elastic',

		prevEffect	: 'elastic',

		nextEffect	: 'elastic',

		helpers	: {

			title	: {

				type: 'outside'

			},

			thumbs	: {

				width	: 50,

				height	: 50

			}

		}

	});

	

	Dropzone.options.myDrop = {

  		init: function() {

    	this.on("complete", function() {

      		if (this.getQueuedFiles().length == 0 && this.getUploadingFiles().length == 0) {

       			location.reload();

      		}

    	});

  		}	

	};

	

});



</script>



<div id="pagetitle">

	<div class="wrap">
    
    	<h1>Edit Course</h1>
        
	</div>
    
</div>
<div class="maincontent">

	<div class="wrap">
    
    <div style="margin-top: 0px; width: 100%; height: 50px; text-align: right;">
               <a style="padding: 10px; border: 1px solid rgb(0, 32, 96); color: #fff; margin: 0px auto; background: rgb(0, 32, 96) none repeat scroll 0% 0%; position: relative; top: 5px;margin-right:20px" class="btn" href="<?php echo base_url(); ?>dashboard">Back</a>
             </div> 

    
            <div id="course-container" class="edit-course">

<form enctype="multipart/form-data" method="post" id="courseedit">

                <div class="row-element">
                    <span class="title">Course Name</span>
                    <span class="content"><input type="text" name="course" value="<?php echo $edit['name']; ?>" class="name"></span>
                </div>
                
                <div class="row-element">
                    <span class="title">URL Name</span>                    
                    <span class="content">
                    <input type="text" name="ulink" value="<?php echo $edit['link']; ?>" class="ulink"></span>
                </div>

                <div class="row-element">
                    <span class="title">Description</span>
                    <span class="content">
                        <textarea name="desc" class="desc"><?php echo $edit['description']; ?></textarea>
                    </span>
                </div>
                
                <div class="row-element">
                    <span class="title">Duration</span>                    
                    <span class="content">
                    <input type="text" name="duration" value="<?php echo $edit['duration']; ?>" class="duration"></span>
                </div>

                <div class="row-element">
                    <span class="title">Visible</span>  
                    <?php
                                $selectedy = "";
								$selectedn = "";
                                if($edit['visible'] === "Yes"){
                                    $selectedy = "checked='checked'";
                                }else if($edit['visible'] === "No"){
                                    $selectedn = "checked='checked'";
                                }
                            
                            ?>
                    <span class="content">
                    <input type="radio" name="visible" value="Yes" class="visible" <?php echo $selectedy; ?>> Yes
                    <input type="radio" name="visible" value="No" class="visible" <?php echo $selectedn; ?>> No
                    </span>
                </div>
                
                <!--<div class="row-element">
                    <span class="title">Upoad Image</span>
                    <span class="content">
                    
                    <img style="margin:0;" class="upload-photo-m" src="<?php //if($edit['image']=="") echo base_url().'docs/courses/ap.jpg'; else echo $edit['image'];?>" /><br>
                     <div style="float:left; margin:10px 0 0 20px;">
                        <input size="50" type="file" name="fileToUpload" id="fileToUpload" value="Select image to upload" style="position: relative;text-align: right;-moz-opacity:0 ;filter:alpha(opacity: 0);opacity: 0;z-index: 2; float:left; height:30px; width:356px;" /> 
                        
                        <input type="hidden" name="image"  value="<?php //echo $edit['image'];?>">
                        <input type="hidden" name="id"  value="<?php //echo $edit['id'];?>">
      
      			<div class="fakeinput" style="position:absolute; border:1px solid #ccc; width:350px; height:28px;border-radius:4px; line-height: 28px; text-align:left; padding-left:5px; background:#fff; box-shadow: 0 1px 1px rgba(0, 0, 0, 0.075) inset; font-size:14px;">Select image to upload</div>
      
        		<div style="clear:both;"></div>
                
                <p>* Supported only jpg, jpeg</p> 
                
                <p>* Maximum upload file size: 100KB</p>
                
                <p>* Image should contain Width * Height: 324px * 181px</p>
                
                </div>
                    </span>
                    
                </div>-->
                
                 <div class="row-element">
                    <span class="title"></span>                    
                    <span class="content" style="width: 12%;"><input type="submit" value="Submit" class="course-submit"></span>
                    <p class="errnotify" style="color:#aa3e41;margin:0px;padding:0px;float:left;padding-left:20px;padding-top:20px"> </p>
                </div>
                
                	<input type="hidden" name="id"  value="<?php echo $edit['id'];?>">
                
                </form>
                
            </div>
        
        </div>
    
    </div>
    
    
   <script type="text/javascript">

$(document).ready(function(){
	
	$("#fileToUpload").change(function(){
		
		var imgloc = $(this).val();
				
		$(".fakeinput").text(imgloc);
		
		readURL(this);
		
	});
	
	
	function readURL(input) {

    if (input.files && input.files[0]) {
        var reader = new FileReader();

        reader.onload = function (e) {
            $('.upload-photo-m').attr('src', e.target.result);
        }

        reader.readAsDataURL(input.files[0]);
    }
}

	
});

</script>

<script type="text/javascript">
$(document).ready(function() {
	
	
	$(".edit-course").find("input").each(function(){

          $(this).click(function(){ $(".errnotify").html("&nbsp;");});

    });
	
	$("#courseedit").submit(function(e){
		
		e.preventDefault();
		
		        var course = $(".edit-course").find(".name").val();
                var desc = $(".edit-course").find(".desc").val();
				var ulink = $(".edit-course").find(".ulink").val();
                var visible = "";				
				
		
		if(course === ""){ $(".errnotify").html("Invalid course name");return;}	
		
		if(desc === ""){ $(".errnotify").html("Invalid description");return;}
		
		if(ulink === ""){ $(".errnotify").html("Invalid URL Name");return;}
		
		if($(".edit-course").find(".visible").is(":checked")){
			visible = $(".visible:checked").val();
		} 
		
		if(visible === ""){ $(".errnotify").html("Select Course visibility");return;}
		
		<?php if($edit['image']==""){?>
		/*if ($(".fakeinput").text()=="Select image to upload"){
    		$(".errnotify").html('Please select an image to upload');
    		return;
		}*/
		
		<?php }?>
		
		var imgloc = $("#fileToUpload").val();
				
		$(".fakeinput").text(imgloc);
		
				
		
		$(this).find('.course-submit').val("Processing...");
		
		if($(this).find('.course-submit').hasClass('process')){
			
			$(this).find('.course-submit').val("Processing wait...");
		}
		else{
		
		$(this).find('.course-submit').addClass('process');
				
				$.ajax({
						url: "editcourse/updateCourse", // Url to which the request is send
						type: "POST",             // Type of request to be send, called as method
						data: new FormData(this), // Data sent to server, a set of key/value pairs (i.e. form fields and values)
						contentType: false,       // The content type used when sending data to the server.
						cache: false,             // To unable request pages to be cached
						processData:false,        // To send DOMDocument or non processed data file it is set to false
						success: function(data)   // A function to be called if request succeeds
						{
							
							var obj1 = $.parseJSON(data);
							
							if(obj1[0] === 'success'){
									$(".edit-course").find(".course-submit").val("Submit");
									$(".errnotify").html("Course has been edited succesfully!!"); 
                                    setTimeout(function(){ location.assign("dashboard"); $(this).find('.course-submit').removeClass('process');} ,2000);  
								
					            }else if(obj1[0] === 'fail'){
								   $(".edit-course").find(".course-submit").val("Submit");
								   $(".errnotify").html("Error!! Please try again");
									$(this).find('.course-submit').removeClass('process');

							   }else if(obj1[0] === 'uerror'){
								   $(".edit-course").find(".course-submit").val("Submit");
								   $(".errnotify").html("Only Supported JPG,JPEG,PNG");
								   $(this).find('.course-submit').removeClass('process');

							   }
						
						}
						});
		}
		
  	});
	
});
</script>
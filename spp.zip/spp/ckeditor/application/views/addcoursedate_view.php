
<div id="pagetitle">

	<div class="wrap">
    
    	<h1>Add Course Date</h1>
        
	</div>
    
</div>
<div class="maincontent">

	<div class="wrap">
    
     <div style="margin-top: 0px; width: 100%; height: 50px; text-align: right;">
               <a style="padding: 10px; border: 1px solid rgb(0, 32, 96); color: #fff; margin: 0px auto; background: rgb(0, 32, 96) none repeat scroll 0% 0%; position: relative; top: 5px;margin-right:20px" class="btn" href="<?php echo base_url(); ?>dashboard">Back</a>
             </div> 
             
            <div id="course-container" class="add-course-date">

                <div class="row-element">
                    <span class="title">Select Course</span>
                    <span class="content">
                        <select name="course" class="course" >
                            <?php echo $courselist; ?>   
                        </select>
                    </span>
                </div>

               <!-- <div class="row-element">
                    <span class="title">No of seats</span>
                    <span class="content"><input type="text" value="" class="seats" name="seats" ></span>
                </div>

                <div class="row-element">
                    <span class="title">Seat Availability</span>
                    <span class="content">
                        <select name="seatavail" class="seatavail" >
                            <option>Open</option><option>Close</option>
                        </select>
                    </span>
                </div>-->
                
                 <div class="row-element">
                    <span class="title">Start Date *</span>
                    <span class="content">
                       <input type="text"  name="date1" id="date1" placeHolder="" />
                    </span>
                </div>
                
                <div class="row-element">
                    <span class="title">End Date * </span>
                    <span class="content">
                       <input type="text"  name="date2" id="date2" placeHolder="" />
                    </span>
                </div>
                
                <!--<div class="row-element">
                    <span class="title">Date 2 </span>
                    <span class="content">
                       <input type="text"  name="date2" id="date2" placeHolder="" class="datepicker" />
                    </span>
                </div>
                
                <div class="row-element">
                    <span class="title">Date 3 </span>
                    <span class="content">
                       <input type="text" name="date3" id="date3" placeHolder="" class="datepicker" />
                    </span>
                </div>
                
                <div class="row-element">
                    <span class="title">Date 4 </span>
                    <span class="content">
                       <input type="text"  name="date4" id="date4" placeHolder="" class="datepicker" />
                    </span>
                </div>-->
                
                <div class="row-element">
                    <span class="title">Batch Number</span>
                    <span class="content">
                       <input type="text"  name="batchno" placeHolder="" class="batchno" />
                    </span>
                </div>
                
                <div class="row-element">
                    <span class="title">Is Active</span>                    
                    <span class="content"><input type="checkbox" value="" name="active" class="active"></span>
                </div>
                
                <div class="row-element">
                    <span class="title">Show in front pages</span>                    
                    <span class="content"><input type="checkbox" value="" name="frontpage" class="frontpage"></span>
                </div>
                
                <!--<div class="row-element">
                    <span class="title">Places</span>                    
                    <span class="content">
                        <input type="checkbox" name="place1" value="" class="place1">&nbsp;&nbsp;Chennai&nbsp;&nbsp;&nbsp;&nbsp;
                        <input type="checkbox" name="place2" value="" class="place2">&nbsp;&nbsp;Dubai
                        <input type="checkbox" name="place3" value="" class="place3">&nbsp;&nbsp;Guwahati
                    </span>
                </div>-->
                
                 <div class="row-element">
                    <span class="title"></span>                    
                    <span class="content">
                        <input style="float: left" type="submit" class="course-submit" value="Submit">
                        <p class="errnotify" style="color:#aa3e41;margin:0px;padding:0px;float:left;padding-left:20px;padding-top:10px"> </p>
                    </span>
                </div>
                
            </div>
        
        </div>
    
    </div>
<script type="text/javascript">
$(document).ready(function() {
	
	
	$('#date1').datetimepicker({
  format:'Y/m/d',
  onShow:function( ct ){
	  var date2 = $('#date2').val();
   this.setOptions({
    maxDate:date2?date2:false
   })
  },
  timepicker:false,
		minDate: 0,
		scrollMonth:false,
		closeOnDateSelect:true
 });
 $('#date2').datetimepicker({
  format:'Y/m/d',
  onShow:function( ct ){
	  var date1 = $('#date1').val();
   this.setOptions({
    minDate:date1?date1:false
   })
  },
  timepicker:false,
	 scrollMonth:false,
	 closeOnDateSelect:true
 });
	
	
	$(".add-course-date").find("input").each(function(){

          $(this).click(function(){ $(".errnotify").html("&nbsp;");});

    });
	
	$(".add-course-date").find(".course-submit").click(function(){
		
		       var course = $(".add-course-date").find(".course").val();
               /* var seats = $(".add-course-date").find(".seats").val();
                var seatavail = $(".add-course-date").find(".seatavail").val();*/
                var date1 = $(".add-course-date").find("#date1").val();
                var date2 = $(".add-course-date").find("#date2").val();
                /*var date3 = $(".add-course-date").find("#date3").val();
                var date4 = $(".add-course-date").find("#date4").val();*/
		
				var batchno = $(".add-course-date").find(".batchno").val();
                
                var frontpage = "No";
                if($(".add-course-date").find(".frontpage").is(":checked")){
                    frontpage = "Yes";
                } 
                
                var active = "No";
                if($(".add-course-date").find(".active").is(":checked")){
                    active = "Yes";
                } 
                
                /*var place1 = "";
                if($(".add-course-date").find(".place1").is(":checked")){
                    place1 = "Chennai";
                } 
                
                var place2 = "";
                if($(".add-course-date").find(".place2").is(":checked")){
                    place2 = "Dubai";
                } 
                
                var place3 = "";
                if($(".add-course-date").find(".place3").is(":checked")){
                    place2 = "Guwahati";
                } */
                
               
		        if(course === ""){ $(".errnotify").html("Please provide course name");return;}	
                
               // if(seats === ""){ $(".errnotify").html("Please provide no of seats");return;}	
                
                if(date1 === ""){ $(".errnotify").html("Please provide start date");return;}
                
				if(date2 === ""){ $(".errnotify").html("Please provide end date");return;}
		
				
				regex   = '^[0-9 \-]{1,10}$';
				valid = validateInputs(batchno,regex);
				if( (!valid) || (batchno == "") ) { $(".errnotify").html("Please provide valid batch number"); return false;}   
		
                /*if(place1 === "" && place2 === ""&& place3 === "") {
                    $(".errnotify").html("Please select atleast one place");return;
                }*/
		
		$(".add-course-date").find(".course-submit").val("Processing...");
		
		if($(".add-course-date").find(".course-submit").hasClass('process')){
			
			$(".add-course-date").find(".course-submit").val("Processing wait...");
		}
		else{
			
			$(".add-course-date").find(".course-submit").addClass('process');
		
				$.get('addcoursedate/addCourseDate',{
					   'course':course, 
					   'date1':date1,
					'date2':date2,
					   'active':active,
					   'frontpage':frontpage,
					'batchno':batchno
                                           

				}, function(o) { 
					var obj1 = $.parseJSON(o);
					if(obj1[0] === 'success'){
						    
                        $(".errnotify").html("<font style=\"color:#188f04\">Course date has been added succesfully!!</font>");
						$(".add-course-date").find(".course-submit").val("Submit");
					    setTimeout(function(){ location.assign("regsummary");$(".add-course-date").find(".course-submit").removeClass('process');}, 1000);
                                                
					}else if(obj1[0] === 'fail'){
					   $(".add-course-date").find(".course-submit").val("Submit");
					   alert("Error!! Please try again");                                                    
						$(".add-course-date").find(".course-submit").removeClass('process');
					}
				});	
		}
		
  	});
	
});
	
function validateInputs(value,pattern) {
    
    var regexppattern;
    regexppattern = new RegExp(pattern);
    var valid     = regexppattern.test(value);
    
    return valid;
}
</script>
<!DOCTYPE html>



<html>



<head>



<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />



<title>Dental Courses</title>



<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">







<!--<link href='http://fonts.googleapis.com/css?family=Lato:400,700,900,400italic,700italic' rel='stylesheet' type='text/css'>-->







<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/styles.css" />



<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/styles-media.css" />



<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/menu.css" />



<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/mobilemenu.css" />











<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/commonstyle.css" />



<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/dataTables.css" />



<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/jquery.datetimepicker.css" />











<script type="text/javascript" src="<?php echo $this->config->item('web_url') ?>js/jquery.js"></script>



<script src="<?php echo base_url(); ?>js/main.js" type="text/javascript"></script>



<script src="<?php echo base_url(); ?>js/menu.js" type="text/javascript"></script>



<script src="<?php echo base_url(); ?>js/modernizr.custom.js" type="text/javascript"></script>







<script src="<?php echo base_url(); ?>js/jquery.dataTables.js?v=1.0" type="text/javascript"></script>







<script src="<?php echo base_url(); ?>js/jquery.datetimepicker.js" type="text/javascript"></script>



<script src="<?php echo base_url(); ?>ckeditor/ckeditor.js" type="text/javascript"></script>











<script>



var baseurl = "<?php echo base_url(); ?>";



</script>







<script>



ddsmoothmenu.init({



mainmenuid: "menu", //menu DIV id



orientation: 'h', //Horizontal or vertical menu: Set to "h" or "v"



classname: 'headermenu', //class added to menu's outer DIV



customtheme: ["#ffffff", "#004080"],



contentsource: "markup" //"markup" or ["container_id", "path_to_menu_file"]



}); 



</script>







<script type="text/javascript">



$(document).ready(function(){



	$('.datepicker').datetimepicker({



		timepicker:false,



		format:'d-m-Y'



	});



});



</script>







</head>







<body>







<div id="headertop">



    



    <div class="wrap">



    



        <a href="<?php echo base_url(); ?>"><img src="<?php echo $this->config->item('web_url') ?>images/foot-logo.png" id="headerlogo" /></a>



        



        <div id="menu" class="headermenu">



        



            <ul>



                



                <?php echo $menu; ?>



                                    



            </ul>



        



        </div>



        



        <div id="mobilemenu" class="dl-menuwrapper">



            <button class="dl-trigger"><img src="<?php echo $this->config->item('web_url') ?>images/nav.png" alt="Navigation" /></button>



            <ul class="dl-menu">



            



                <?php echo $menu; ?>



             



            </ul>



        </div>



        



        <div class="clear"></div>



        



    </div>







</div>
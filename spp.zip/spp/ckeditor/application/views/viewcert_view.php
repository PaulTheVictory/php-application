
<div id="pagetitle">

	<div class="wrap">
    
    	<h1>View Certifiacte</h1>
        
	</div>
    
</div>
<style type="text/css">


.dataTables_wrapper input[type="text"] {
    padding: 0;
}
.dataTables_wrapper select {
    padding: 0;
}
.sortable tr th {
    border-right: 1px solid #ddd;
    padding: 10px 0;font-size: 13px;
}
.sortable tr td {
    border-right: 1px solid #ddd;
    padding: 15px 5px;
    text-align: center;font-size: 13px;
    vertical-align: middle;
}
.sortable tr td a {
    color: #333;
}

#profile-right h2 {
    margin: 0px 0px 10px 0px;
}

.coursetable_length { width: auto !important; }
#coursetable_filter input { border: 1px solid #ccc; line-height: 25px;margin-left: 10px;}
.sortable tr td a:hover { text-decoration: underline; }
</style>
<script type="text/javascript">
$(document).ready(function(){	
		
	
          var columnData = [
                    { "data": "filename" },
                    { "data": "name" },
                    { "data": "dateofcertify" },
                    { "data": "venue" },
                    { "data": "active" }
                  ];
         columnData.push( {data: "id","visible":true} );
        // columnData.push( {data: "memtype","visible":false} );
         
       
        var oTable = $('#coursetable').dataTable({
                    "bProcessing": true,
                    "bServerSide": true,
                    "sPaginationType": "full_numbers",
                    "ajax": {
                    "url": 'viewcert/getCertificateLists',
                    "type": "POST"
                     }, 
                     "oLanguage": {
                        "sProcessing": "<img src='<?php echo base_url(); ?>images/loader.gif'>"
                    },
                    'iDisplayLength': 25,
                    "columns": columnData,
                    "fnDrawCallback": function( oSettings ) {
                        
                         $("#coursetable").find(".isactive").each(function(){

                            $(this).change(function(){ 
                              
                              if(confirm("Are you sure to change this ?")) {
                                    var ide = $(this).attr("id");
                                    var isactive = $(this).val();
                                    $.get('viewcert/isActive',{
                                            'ide':ide,'isactive':isactive
                                        }, function(o) { 
                                            var obj1 = $.parseJSON(o);
                                            if (obj1[0] === 'success') {
                                                oTable.fnDraw();                                                
                                            } else if (obj1[0] === 'fail') {
                                                alert("Error!! PLease try again");
                                            }
                                    });
                                }
                                

                              });
                        
                        });
                        
                        $("#coursetable").find(".del").each(function(){

                            $(this).click(function(){ 

                              if(confirm("Are you sure to delete this state ?")) {
                                    var ide = $(this).attr("id");
                                    $.get('viewcert/delCert',{
                                            'ide':ide
                                        }, function(o) { 
                                            var obj1 = $.parseJSON(o);
                                            if (obj1[0] === 'success') {
                                                oTable.fnDraw();                                                
                                            } else if (obj1[0] === 'fail') {
                                                alert("Error!! PLease try again");
                                            }
                                    });
                                }
                                

                              });
                        
                        });
                            
                    }
         }); 

});
</script>
<div class="maincontent">

	<div class="wrap">
    
            <div style="margin-top: 0px; width: 100%; height: 50px; text-align: right;"><a style="padding: 10px; border: 1px solid rgb(247, 116, 96); color: #fff; margin: 0px auto; background: rgb(170, 62, 65) none repeat scroll 0% 0%; position: relative; top: 5px;" class="btn" href="<?php echo base_url(); ?>addcert">Add New Certificate</a></div>    
         <?php echo $this->table->generate();  ?>             
         
        
        
        </div>
    
    </div>
    


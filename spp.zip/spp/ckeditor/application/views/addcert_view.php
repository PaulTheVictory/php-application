<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/jquery.Jcrop.css" />
<script src="<?php echo base_url(); ?>js/ajaxfileupload.js" type="text/javascript"></script>
<script src="<?php echo base_url(); ?>js/jquery.Jcrop.js" type="text/javascript"></script>
<div id="pagetitle">

	<div class="wrap">
    
    	<h1>Add Certificate</h1>
        
	</div>
    
</div>
<div class="maincontent">

	<div class="wrap">
    
            <div id="course-container" class="add-course">

                <div class="row-element">
                    <span class="title"> Certification image </span>
                    <span class="content">
                        <div class="fileupload-single">
                            <form method="post" enctype="multipart/form-data" id="certpicform">
                                <input type="file" name="fileToUpload" id="certimagefile" />	<input type="submit" style="visibility: hidden" value="Upload" id="uploadcertbtn" />							
                                <span class="uploaderrnotify">&nbsp;</span>
                            </form>     
                        </div>
                    </span>
                </div>

                <div class="row-element">
                    <span class="title">Name</span>
                    <span class="content">
                        <input type="text" value="" class="certname" >
                    </span>
                </div>

                <div class="row-element">
                    <span class="title">Date of certified</span>                    
                    <span class="content"><input type="text"  placeHolder="" class="datepicker certdate"></span>
                </div>
                
                 <div class="row-element">
                    <span class="title">Select Venue</span>                    
                    <span class="content"><select class="certvenue"><?php echo $clists; ?></select></span>
                </div>
                <div class="row-element">
                    <span class="title">Is Active</span>                    
                    <span class="content"><input class="certactive" type="checkbox" class="active"></span>
                </div>
                
                 <div class="row-element">
                    <span class="title"></span>                    
                    <span class="content">
                        <input style="float: left" type="submit" class="course-submit" value="Submit">
                        <p class="errnotify" style="color:#aa3e41;margin:0px;padding:0px;float:left;padding-left:20px;padding-top:10px"> </p>
                    </span>
                </div>
                
            </div>
        
        </div>
    
    </div>
<script type="text/javascript">
$(document).ready(function() {
	
	
            $(".add-course").find("input").each(function(){

              $(this).click(function(){ $(".errnotify").html("&nbsp;");});

            });
        
           
	
	$(".add-course").find(".course-submit").click(function(){
            
            var certname = $(".certname").val();
            var certdate = $(".certdate").val();
            var certvenue = $(".certvenue").val();
                       
            if(certname === ""){ $(".errnotify").html("Invalid name");return;}
            if(certdate === ""){ $(".errnotify").html("Invalid date");return;}
            if(certvenue === ""){ $(".errnotify").html("Invalid venue");return;}
		
	      $("#certpicform").submit();
		
  	});
        
        $(document).delegate("#certpicform", "submit", function(e) {
            
            var certname = $(".certname").val();
            var certdate = $(".certdate").val();
            var certvenue = $(".certvenue").val();
            var certactive = "No";
            if($(".certactive").is(":checked")){
                certactive = "Yes";
            }
            
            if(certname === ""){ $(".errnotify").html("Invalid name");return;}
            if(certdate === ""){ $(".errnotify").html("Invalid date");return;}
            if(certvenue === ""){ $(".errnotify").html("Invalid venue");return;}
		
		e.preventDefault();
                
                $(".errnotify").html("<font style=\"color:#188f04\">Processing...</font>");
		
		$.ajaxFileUpload({
                    url             :'addcert/uploadCertDetails', 
                    secureuri       :false,
                    fileElementId   :'certimagefile',
                    dataType: 'JSON',
                    data:  {'certname':certname,'certdate':certdate,'certvenue':certvenue,'certactive':certactive},
                    success : function (data)
                    {
                       var obj = jQuery.parseJSON(data);                
                       if(obj['status'] == 'success'){
                           $(".errnotify").html("<font style=\"color:#188f04\">Certificate details updated succesfully!!</font>");
                            setTimeout(function(){ window.location.reload();}, 1000);					
                       }else{
                           $('.errnotify').html(obj['status']);
                       }
                    }
                    
                });
                
            return false;
		
	});
        
	
});
</script>
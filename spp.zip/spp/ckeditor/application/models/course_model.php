<?php

Class Course_Model extends CI_Model {
    
     public function __construct() {
        
       $this->load->library('Datatables');
		 $this->load->helper('my_datatable_helper');
  
    }

    public function GetAllCourses() {
        
        $arr = Array();
		
		$arr['list'] = "";
		
                //$this->datatables->set_database("default");
	    $this->datatables->select('course_name,description,visible,image,created_time,id') 
            ->edit_column('course_name', '<a href="'.base_url().'editcourse?id=$1">$2</a>', 'id,course_name') 
			->add_column('image', '<img src="$1"  style="width: 100px;"/>', 'image')
			->edit_column('id', '<a class="del" id="$1" href="javascript:void(0)">x</a>', 'id')
            ->from('sag_courses') ;
                
                $table =  $this->datatables->generate();
		
		return $table;
        
    }
    
    public function AddCourse($course, $desc ,$duration, $visible ,$link , $image) {
        
        $id = uniqid();
        $query1 = $this-> db -> query('insert into sag_courses (`id`,`course_name`,`description`,`duration`,`visible`,`link`,`image`,`created_time`) values ("'.$id.'","'.htmlentities($course).'","'.$desc.'","'.htmlentities($duration).'","'.$visible.'","'.$link.'","'.$image.'",CURRENT_TIMESTAMP)');
        if($query1) {
            $result = array(0 => "success");
        } else {
            $result = array(0 => "fail");
        }
        
        return $result;      	
        
    }
    
    public function EditCourse($ide) {
        
        $arr['name']= ""; $arr['description']= ""; $arr['duration']= ""; $arr['visible']= ""; $arr['image']= ""; $arr['link']= ""; $arr['id']= ""; 
        $query1 = $this-> db -> query('select * from sag_courses where id="'.$ide.'"');
	$row = $query1->result_array();
        if ($row) {
            
            $arr['name']=$row[0]['course_name'];	
            $arr['description']=$row[0]['description'];
			$arr['duration']=$row[0]['duration'];	
			$arr['image']=$row[0]['image'];			
            $arr['visible']=$row[0]['visible'];
			$arr['link']=$row[0]['link'];
            $arr['id']= $row[0]['id'];
            
        }
        
        return $arr;
        
    }
    
    public function UpdateCourse($course, $desc ,$duration, $visible,$image, $unlinkimage, $link, $id){
        
        $query1 = $this-> db -> query('update sag_courses set course_name = "'.htmlentities($course).'",description="'.$desc.'",duration="'.htmlentities($duration).'",visible="'.$visible.'",image="'.$image.'",link="'.$link.'" where id="'.$id.'"');
        if($query1) {
			
		if($unlinkimage!="")
		{
			 unlink('docs/courses/'.$unlinkimage);
		}
			
            $result = array(0 => "success");
        } else {
            $result = array(0 => "fail");
        }
        
        return $result; 
        
    }
    
    public function GetCourseLists(){
        
        $ret = "<option value=\"\">Select Course</option>";
        $query1 = $this-> db -> query('select course_name,id from sag_courses where 1');
	$row = $query1->result_array();
        if ($row) {
            
            for($i = 0 ; $i < count($row); $i++){
                
                $ret .= "<option value='".$row[$i]['id']."' >".$row[$i]['course_name']."</option>";
                
            }
            
        }
        
        return $ret;
        
    }
	
	 public function DeleteCourse($ide){
        
            $query1 = $this-> db -> query('delete from sag_courses where id="'.$ide.'"');
			
			$query2 = $this-> db -> query('delete from sag_registration where courseid="'.$ide.'"');
            if($query1 && $query2) {
                $result = array(0 => "success");
            } else {
                $result = array(0 => "fail");
            }

            return $result; 
        
       }
    
    public function GetAllRegistrations(){
        
         $arr = Array();
				
		$arr['list'] = "";
		
                $this->datatables->select('sag_registration.courseid,regid,course_name,seats,seatavail,date1,date,active,frontpage,date2,batchno') 
            ->edit_column('course_name', '<a href="'.base_url().'editregistration?id=$1">$2 $3</a>', 'regid,course_name,$this->batch_no(batchno)')  
            ->from('sag_registration')
            ->join('sag_courses', 'sag_courses.id=sag_registration.courseid', 'INNER');
                
                $table =  $this->datatables->generate();
		
		return $table;
        
        
        
    }

    public function AddRegistration($course,$date1,$active,$frontpage,$date2,$batchno) {
        
        $date = date('Y-m-d H:m:s', strtotime($date1));
		
		$date1 = date('d-m-Y', strtotime($date1));
		$date2 = date('d-m-Y', strtotime($date2));
        
        //if($place1 != "") {
             $id = uniqid();
             $query1 = $this-> db -> query('insert into sag_registration (`regid`,`courseid`,`date`,`date1`,`active`,`frontpage`,`date2`,`batchno`) values '
                . '("'.$id.'","'.$course.'","'.$date.'","'.$date1.'","'.$active.'","'.$frontpage.'","'.$date2.'","'.$batchno.'")');
        //}
        
        /*if($place2 != "" ) {
             $id = uniqid();
             $query1 = $this-> db -> query('insert into sag_registration (`regid`,`courseid`,`date`,`seats`,`seatavail`,`date1`,`date2`,`date3`,`date4`,`active`,`frontpage`,`place`) values '
                . '("'.$id.'","'.$course.'","'.$date.'","'.$seats.'","'.$seatavail.'","'.$date1.'","'.$date2.'","'.$date3.'","'.$date4.'","'.$active.'","'.$frontpage.'","'.$place2.'")');
        }
        
        if($place3 != "" ) {
             $id = uniqid();
             $query1 = $this-> db -> query('insert into sag_registration (`regid`,`courseid`,`date`,`seats`,`seatavail`,`date1`,`date2`,`date3`,`date4`,`active`,`frontpage`,`place`) values '
                . '("'.$id.'","'.$course.'","'.$date.'","'.$seats.'","'.$seatavail.'","'.$date1.'","'.$date2.'","'.$date3.'","'.$date4.'","'.$active.'","'.$frontpage.'","'.$place2.'")');
        }*/
       
        if($query1) {
            $result = array(0 => "success");
        } else {
            $result = array(0 => "fail");
        }
        
        return $result; 
        
        
    }
	
        public function EditRegistration($ide) {
        
        $arr['name']= ""; $arr['seats']= ""; $arr['seatavail']= ""; $arr['date1']= ""; 
        $arr['date2']= ""; $arr['date3']= ""; $arr['date4']= ""; $arr['active']= "";
        $arr['frontpage']= "";$arr['place']= "";
        
        $query1 = $this-> db -> query('select * from sag_registration where regid="'.$ide.'"');
	$row = $query1->result_array();
        if ($row) {
            
            $course_ret = "<option value=\"\">Select Course</option>";
            $query2 = $this->db->query('select course_name,id from sag_courses where 1');
            $row1 = $query2->result_array();
            if ($row1) {
  
                for ($i = 0; $i < count($row1); $i++) {
                    
                    if($row[0]['courseid'] === $row1[$i]['id']) {
                        
                        $course_ret .= "<option selected value='" . $row1[$i]['id'] . "' >" . $row1[$i]['course_name'] . "</option>";
                        
                    } else {
                        $course_ret .= "<option value='" . $row1[$i]['id'] . "' >" . $row1[$i]['course_name'] . "</option>";
                    }
                    
                }
            }
                
                $arr['id'] = $row[0]['regid'];
                $arr['name'] = $course_ret;
                $arr['seats'] = $row[0]['seats'];
                
                $seatavail = "";
                /*if($row[0]['seatavail'] === "Open"){
                    $seatavail = '<option selected >Open</option><option>Close</option>';
                }else {
                    $seatavail = '<option >Open</option><option selected >Close</option>';
                }
                $arr['seatavail'] = $seatavail;*/
                
                $arr['date1'] = date('Y/m/d',strtotime($row[0]['date1']));
                $arr['date2'] = date('Y/m/d',strtotime($row[0]['date2']));
                /*$arr['date3'] = $row[0]['date3'];
                $arr['date4'] = $row[0]['date4'];*/
			
				$arr['batchno'] = $row[0]['batchno'];
                
                $active = "";
                if($row[0]['active'] === "Yes"){
                    $active = '<input checked type="checkbox" class="active" name="active" value="">';
                }else {
                    $active = '<input type="checkbox" class="active" name="active" value="">';
                }
                $arr['active'] = $active;
                
                $frontpage = "";
                if($row[0]['frontpage'] === "Yes"){
                    $frontpage = '<input checked type="checkbox" class="frontpage" name="frontpage" value="">';
                }else {
                    $frontpage = '<input  type="checkbox" class="frontpage" name="frontpage" value="">';
                }
                $arr['frontpage'] = $frontpage;           
                
                
                $place = "";
                /*if($row[0]['place'] === "Chennai"){
                    $place = '<input checked type="checkbox" class="place1" value="" name="place1">&nbsp;&nbsp;Chennai&nbsp;&nbsp;&nbsp;&nbsp;<input type="checkbox" class="place2" value="" name="place2">&nbsp;&nbsp;Dubai';
                }else {
                    $place = '<input type="checkbox" class="place1" value="" name="place1">&nbsp;&nbsp;Chennai&nbsp;&nbsp;&nbsp;&nbsp;<input checked type="checkbox" class="place2" value="" name="place2">&nbsp;&nbsp;Dubai';
                }
                
                $arr['place'] = $place;*/
                
                
            
        }
        
        return $arr;
        
    }

    
     public function UpdateRegistration($course, $date1,$active,$frontpage,$ide,$date2,$batchno) {
        
        $date = date('Y-m-d H:m:s', strtotime($date1));
        
		 $date1 = date('d-m-Y', strtotime($date1));
		$date2 = date('d-m-Y', strtotime($date2));
		 
       // if($place1 != "") {
            
             $query1 = $this-> db -> query('update sag_registration set courseid = "'.$course.'",date="'.$date.'",date1="'.$date1.'",active="'.$active.'",frontpage="'.$frontpage.'",date2="'.$date2.'",batchno="'.$batchno.'" where regid="'.$ide.'"');
        //}
        
       /* if($place2 != "" ) {
             
            $query1 = $this-> db -> query('update sag_registration set courseid = "'.$course.'",date="'.$date.'",seats="'.$seats.'",seatavail="'.$seatavail.'",date1="'.$date1.'",date2="'.$date2.'",date3="'.$date3.'",date4="'.$date4.'",active="'.$active.'",frontpage="'.$frontpage.'",place="'.$place2.'" where regid="'.$ide.'"');
        }*/
       
        if($query1) {
            $result = array(0 => "success");
        } else {
            $result = array(0 => "fail");
        }
        
        return $result; 
        
        
    }
	
	 public function GetAllTestimonials(){
        
         $arr = Array();
		
		$arr['list'] = "";
		
                $this->datatables->select('title,content,name,active,frontpage,innerpage,testid,courseid,sno') 
            ->edit_column('name', '<a href="'.base_url().'edittestimonial?id=$1">$2</a>', 'testid,name')
			->edit_column('testid', '<a class="del" id="$1" href="javascript:void(0)">x</a>', 'testid')  
			->edit_column('courseid', '$1', '$this->course_name(courseid)')
            ->from('sag_testimonial');
                
                $table =  $this->datatables->generate();
		
		return $table;
        
        
        
    }

	
  public function addTestimonial($title, $content,$name,$active,$frontpage,$innerpage,$onlyimage,$onlytext,$photo,$image,$course) {
			        
             $id = uniqid();
			 
			 $content = json_encode($content);
	  
			 $query = $this-> db -> query('select sno from sag_testimonial  order by sno desc limit 1');
			 $row = $query->result_array();
	  		 $sno = $row[0]['sno'] + 1;

             $query1 = $this-> db -> query('insert into sag_testimonial (`testid`,`title`,`content`,`name`,`active`,`frontpage`,`innerpage`,`onlyimage`,`onlytext`,`photo`,`image`,`courseid`,`sno`) values '
                . '("'.$id.'","'.$title.'",'.$content.',"'.htmlentities($name).'","'.$active.'","'.$frontpage.'","'.$innerpage.'","'.$onlyimage.'","'.$onlytext.'","'.$photo.'","'.$image.'","'.$course.'","'.$sno.'")');
        
       
        if($query1) {
            $result = array(0 => "success");
        } else {
            $result = array(0 => "fail");
        }
        
        return $result; 
        
        
    }
    
	
 public function EditTestimonial($id) {
        
        $arr['name']= ""; $arr['title']= ""; $arr['content']= ""; $arr['active']= ""; $arr['frontpage']= ""; $arr['innerpage']= ""; $arr['photo']= ""; $arr['image']= ""; $arr['oimage']= ""; $arr['otext']= ""; $arr['onlytext']= ""; $arr['onlytext']= ""; $arr['id']= "";$arr['courseid'] = "";
        
        $query1 = $this-> db -> query('select * from sag_testimonial where testid="'.$id.'"');
	    $row = $query1->result_array();
        if ($row) {
			
			$arr['title'] = $row[0]['title'];
			$arr['content'] = $row[0]['content'];
			$arr['name'] = $row[0]['name'];
			$arr['photo'] = $row[0]['photo'];
			$arr['image'] = $row[0]['image'];
			$arr['oimage'] = $row[0]['onlyimage'];
			$arr['otext'] = $row[0]['onlytext'];
			$arr['id'] = $id;
			$arr['courseid'] = $row[0]['courseid'];;
			
			    $active = "";
                /*if($row[0]['active'] === "Yes"){
                    $active = '<input checked type="checkbox" class="active" name="active" value="Yes">';
                }else {
                    $active = '<input type="checkbox" class="active" name="active" value="No">';
                }
                $arr['active'] = $active;*/
				
				$frontpage = "";
                if($row[0]['frontpage'] === "Yes"){
                    $frontpage = '<input checked type="checkbox" class="frontpage" name="frontpage" value="Yes">';
                }else {
                    $frontpage = '<input type="checkbox" class="frontpage" name="frontpage" value="No">';
                }
                $arr['frontpage'] = $frontpage;
				
				/*$innerpage = "";
                if($row[0]['innerpage'] === "Yes"){
                    $innerpage = '<input checked type="checkbox" class="innerpage" name="innerpage" value="Yes">';
                }else {
                    $innerpage = '<input type="checkbox" class="innerpage" name="innerpage" value="No">';
                }
                $arr['innerpage'] = $innerpage;
				
				$onlyimage = "";
                if($row[0]['onlyimage'] === "Yes"){
                    $onlyimage = '<input checked type="checkbox" class="onlyimage" name="onlyimage" value="Yes" disabled>';
                }else {
                    $onlyimage = '<input type="checkbox" class="onlyimage" name="onlyimage" value="No" disabled>';
                }
                $arr['onlyimage'] = $onlyimage;
				
				$onlytext = "";
                if($row[0]['onlytext'] === "Yes"){
                    $onlytext = '<input checked type="checkbox" class="onlytext" name="onlytext" value="Yes" disabled>';
                }else {
                    $onlytext = '<input type="checkbox" class="onlytext" name="onlytext" value="No" disabled>';
                }
                $arr['onlytext'] = $onlytext;*/
            
		}
        return $arr;
        
    }
	
	public function UpdateTestimonial($title, $content,$name,$active,$frontpage,$innerpage,$photo,$image,$id,$course) {
        
        
		$content = json_encode($content);
		
		$query = $this-> db -> query('select image,photo from sag_testimonial  where testid="'.$id.'"');
		$row = $query->result_array();
		if($row)
		{
			$uphoto = $row[0]['photo'];	
			$uimage = $row[0]['image'];
			
			//if($uphoto!="" && $uphoto!=$photo) unlink('docs/testimonial/photo/'.$uphoto);
			//if($uimage!="" && $uimage!=$image) unlink('docs/testimonial/image/'.$uimage);			
		}
		//echo "photo->".$photo.'<br>';
		//echo "image->".$image;die;
		
             $query1 = $this-> db -> query('update sag_testimonial set title = "'.$title.'",content='.$content.',name="'.htmlentities($name).'",active="'.$active.'",frontpage="'.$frontpage.'",innerpage="'.$innerpage.'",photo="'.$photo.'",image="'.$image.'",courseid="'.$course.'" where testid="'.$id.'"');
       
        if($query1) {
            $result = array(0 => "success");
        } else {
            $result = array(0 => "fail");
        }
        
        return $result; 
        
        
    }
	
	 public function deleteTestimonial($id){
		 
		 $query = $this-> db -> query('select image,photo from sag_testimonial  where testid="'.$id.'"');
		$row = $query->result_array();
		if($row)
		{
			$uphoto = $row[0]['photo'];	
			$uimage = $row[0]['image'];
			
			if($uphoto!="") unlink('docs/testimonial/photo/'.$uphoto);
			if($uimage!="") unlink('docs/testimonial/image/'.$uimage);			
		}
        
            $query1 = $this-> db -> query('delete from sag_testimonial where testid="'.$id.'"');
            if($query1) {
                $result = array(0 => "success");
            } else {
                $result = array(0 => "fail");
            }

            return $result; 
        
       }
    
    //start country
    
    public function GetCountries(){
        
        $arr = Array();
		
		$arr['list'] = "";
		
                //$this->datatables->set_database("default");
	    $this->datatables->select('id,country') 
            ->edit_column('id', '<a class="del" id="$1" href="javascript:void(0)">x</a>', 'id') 
            ->from('rc_country') ;
                
                $table =  $this->datatables->generate();
		
		return $table;
        
    }
    
    public function AddCountry($name){
        
        $query =  $this-> db -> query('select * from rc_country where country="'.$name.'"');
        if($query ->num_rows()){
            $result = array(0 => "exists");
            return $result; 
        }
        
        
        $id= uniqid();
        $query1 = $this-> db -> query('insert into rc_country (`id`,`country`) values ("'.$id.'","'.$name.'")');
        if($query1) {
            $result = array(0 => "success");
        } else {
            $result = array(0 => "fail");
        }
        
        return $result; 
        
        
    }
    
    public function DeleteCountry($ide){
        
        $query1 = $this-> db -> query('delete from rc_country where id="'.$ide.'"');
        if($query1) {
            $result = array(0 => "success");
        } else {
            $result = array(0 => "fail");
        }
        
        return $result; 
        
        
    }
    
    //start state
    
      public function GetCountryList(){
        
        $ret = "<option value=\"\">Select Country</option>";
        $query1 = $this-> db -> query('select distinct country from rc_country where 1 order by country asc');
	$row = $query1->result_array();
        if ($row) {
            
            for($i = 0 ; $i < count($row); $i++){
                
                $ret .= "<option >".$row[$i]['country']."</option>";
                
            }
            
        }
        
        
        return $ret;
        
    }
    
      public function GetStates(){
        
        $arr = Array();
		
		$arr['list'] = "";
		
                //$this->datatables->set_database("default");
	    $this->datatables->select('id,country,state') 
            ->edit_column('id', '<a class="del" id="$1" href="javascript:void(0)">x</a>', 'id') 
            ->from('rc_state') ;
                
                $table =  $this->datatables->generate();
		
		return $table;
        
    }
    
    public function AddState($country,$state){
        
        $query =  $this-> db -> query('select * from rc_state where country="'.$country.'" and state="'.$state.'"');
        if($query ->num_rows()){
            $result = array(0 => "exists");
            return $result; 
        }
        
        $id= uniqid();
        $query1 = $this-> db -> query('insert into rc_state (`id`,`country`,`state`) values ("'.$id.'","'.$country.'","'.$state.'")');
        if($query1) {
            $result = array(0 => "success");
        } else {
            $result = array(0 => "fail");
        }
        
        return $result; 
        
    }
    
    public function DeleteState($ide){
        
        $query1 = $this-> db -> query('delete from rc_state where id="'.$ide.'"');
        if($query1) {
            $result = array(0 => "success");
        } else {
            $result = array(0 => "fail");
        }
        
        return $result; 
        
        
    }
    
    //start city
    
    public function GetStateList($country){
        
        
        $ret = "<option value=\"\">Select State</option>";
        $query1 = $this-> db -> query('select distinct state from rc_state where country="'.$country.'" order by state asc');
	$row = $query1->result_array();
        if ($row) {
            
            for($i = 0 ; $i < count($row); $i++){
                
                $ret .= "<option >".$row[$i]['state']."</option>";
                
            }
            
        }
        
        
        return $ret;
        
    }
    
      public function GetCities(){
        
        $arr = Array();
		
		$arr['list'] = "";
		
                //$this->datatables->set_database("default");
	    $this->datatables->select('id,city,country,state') 
            ->edit_column('id', '<a class="del" id="$1" href="javascript:void(0)">x</a>', 'id') 
            ->from('rc_city') ;
                
                $table =  $this->datatables->generate();
		
		return $table;
        
    }
    
    public function AddCity($country,$state,$city){
        
        $query =  $this-> db -> query('select * from rc_city where country="'.$country.'" and state="'.$state.'" and city ="'.$city.'" order by state desc');
        if($query ->num_rows()){
            $result = array(0 => "exists");
            return $result; 
        }
        
        $id= uniqid();
        $query1 = $this-> db -> query('insert into rc_city (`id`,`country`,`state`,`city`) values ("'.$id.'","'.$country.'","'.$state.'","'.$city.'")');
        if($query1) {
            $result = array(0 => "success");
        } else {
            $result = array(0 => "fail");
        }
        
        return $result; 
        
        
    }
    
    public function DeleteCity($ide){
        
        $query1 = $this-> db -> query('delete from rc_city where id="'.$ide.'"');
        if($query1) {
            $result = array(0 => "success");
        } else {
            $result = array(0 => "fail");
        }
        
        return $result; 
        
        
    }
    
    
     public function GetCityList(){
        
        
        $ret = "<option value=\"\">Select City</option>";
        $query1 = $this-> db -> query('select distinct country from rc_country where 1 order by country desc');
	$row = $query1->result_array();
        if ($row) {
            
            for($i = 0 ; $i < count($row); $i++){
                
                $ret .= "<option >".$row[$i]['country']."</option>";
                
            }
            
        }
        
        
        return $ret;
        
    }
    
        public function GetCityCountryState(){
            
             $arr = Array(); $statearr = Array(); $cityarr = Array();
        $ret = "<option value=\"\">Click here to choose</option>";
        $query1 = $this-> db -> query('select country from rc_country where 1 order by country asc');
	$row = $query1->result_array();
        if ($row) {
            
            for($i = 0 ; $i < count($row); $i++){
                
                $arr[$i] = $row[$i]['country'];
                //$ret .= "<option >".$row[$i]['country']."</option>";
            }
            
            for ($j =0 ; $j < count($arr); $j++){
                
                $query2 = $this-> db -> query('select state from rc_state where country="'.$arr[$j].'" order by state asc');
	        $row1 = $query2->result_array();
                
                if($row1){
                    
                   for ($k = 0 ; $k < count($row1); $k++){
                       
                       $statearr[$arr[$j]][$k] = $row1[$k]['state'];
                   }
                    
                }
                
            }
            
            foreach($statearr as $key => $value) {
                
                foreach($value as $index => $val) {
                    
                    $query3 = $this->db->query('select city from rc_city where state="' . $val . '" order by city asc');
                    $row2 = $query3->result_array();

                    if ($row2) {
                        
                        for ($l = 0 ; $l < count($row2); $l++){
                          $cityarr[$val][$l] = $row2[$l]['city'];
                        }
                        
                    }
                }
                
            }
            
        }
        
        foreach($arr as $ckey => $cval){
            
            $ret .= '<option style="font-weight:bold;border-top: 1px dashed #999999;padding:5px;padding-left:5px">'.$cval.'</option>';
            
            if(array_key_exists($cval, $statearr)) {
                
                foreach($statearr[$cval] as $skey => $sval){

                    $ret .= '<option style="font-size:16px;padding:5px;padding-left:10px" >'.$sval.'</option>';

                    if(array_key_exists($sval, $cityarr)) {
                         
                        foreach($cityarr[$sval] as $ckey => $cval){
                             $ret .= '<option style="font-size:13px;padding:5px;padding-left:25px">'.$cval.'</option>';
                        }
                    }
                 
                }
                
            } 
            
        }
        
        
        return $ret;
        
        
    }
    
    public function UploadCertificatePhoto($certname,$certdate,$certvenue,$certactive,$certimgame){
        
        $id= uniqid();
        $date = date('Y-m-d H:m:s', strtotime($certdate));
        $certcountry = "";
        $certstate = "";
        
        $query = $this->db->query('select country,state from rc_city where city="' . $certvenue . '"');
        $row = $query->result_array();

        if ($row) {

            $certcountry = $row[0]['country'];
            $certstate = $row[0]['state'];
        }

        $query1 = $this-> db -> query('insert into rc_certificate (`id`,`name`,`dateofcertify`,`country`,`state`,`venue`,`active`,`filename`,`date`,`created_time`) values ("'.$id.'","'.$certname.'","'.$certdate.'","'.$certcountry.'","'.$certstate.'","'.$certvenue.'","'.$certactive.'","'.$certimgame.'","'.$date.'",CURRENT_TIMESTAMP)');
        if($query1) {
            $result = array(0 => "success");
        } else {
            $result = array(0 => "fail");
        }
        
        return $result; 
        
    }
    
   
    public function GetCertificates(){
        
        $arr = Array();
        $arr['list'] = "";

        $this->datatables->select('id,name,dateofcertify,venue,active,filename')
                ->edit_column('filename', '<img width="100" height="100" src="viewcert/getimage?name=$1">', 'filename')
                ->from('rc_certificate');

        $table = $this->datatables->generate();
        
         $editTable = json_decode($table);
            $tmpTable = $editTable->data;
            $Yselected = "";$Nselected = "";
            foreach ($tmpTable as $val) {                
                
                if($val->active == "Yes") { $Yselected = "selected";} else { $Nselected = "selected";}
                $val->active = "<select class=\"isactive\" id=\"$val->id\"><option $Yselected >Yes</option><option $Nselected>No</option></select>";   
                $val->id = '<a class="del" id="'.$val->id.'" href="javascript:void(0)">x</a>';
                $Yselected = "";$Nselected = "";
            }

            $rtrvTable = json_encode($editTable);

            return $rtrvTable;
        
    }
    
    public function IsActiveCert($ide,$isactive){
        
        $query1 = $this-> db -> query('update rc_certificate set active="'.$isactive.'" where id="'.$ide.'"');
        if($query1) {
            $result = array(0 => "success");
        } else {
            $result = array(0 => "fail");
        }
        
        return $result; 
        
    }
    
     public function DeleteCert($ide){
        
        $query1 = $this-> db -> query('delete from rc_certificate where id="'.$ide.'"');
        if($query1) {
            $result = array(0 => "success");
        } else {
            $result = array(0 => "fail");
        }
        
        return $result; 
        
    }
    
    //schedule
    
    public function GetAllSchedules(){
        
         $arr = Array();
		
		$arr['list'] = "";
		
                $this->datatables->select('date,topic,active,location,datetime,id') 
            ->edit_column('topic', '<a href="'.base_url().'editschedule?id=$1">$2</a>', 'id,topic')  
          ->edit_column('id', '<a class="del" id="$1" href="javascript:void(0)">x</a>', 'id') 
            ->from('sag_schedule');
                
                $table =  $this->datatables->generate();
		
		return $table;
        
        
        
    }

    public function AddSchedule($date, $location, $topic, $active) {
        
        $datetime = date('Y-m-d H:m:s', strtotime($date));
        
            $id = uniqid();
             $query1 = $this-> db -> query('insert into sag_schedule (`id`,`date`,`topic`,`active`,`location`,`datetime`) values '
                . '("'.$id.'","'.$date.'","'.$topic.'","'.$active.'","'.$location.'","'.$datetime.'")');
       
        if($query1) {
            $result = array(0 => "success");
        } else {
            $result = array(0 => "fail");
        }
        
        return $result; 
        
        
    }
    
    public function EditSchedule($ide) {
        
        $arr['date']= ""; $arr['topic']= ""; $arr['active']= ""; $arr['location']= ""; 
        
        $query1 = $this-> db -> query('select * from sag_schedule where id="'.$ide.'"');
	$row = $query1->result_array();
        if ($row) {
            
                $arr['id'] = $row[0]['id'];
                $arr['topic'] = $row[0]['topic'];
                $arr['location'] = $row[0]['location'];
                $arr['date'] = $row[0]['date'];
                
                $active = "";
                if($row[0]['active'] === "Yes"){
                    $active = '<input checked type="checkbox" class="active" name="active" value="">';
                }else {
                    $active = '<input type="checkbox" class="active" name="active" value="">';
                }
                $arr['active'] = $active;
                
            
        }
        
        return $arr;
        
    }
    
    public function UpdateSchedule($date, $location, $topic, $active,$ide) {
        
        $datetime = date('Y-m-d H:m:s', strtotime($date));
        $query1 = $this-> db -> query('update sag_schedule set topic = "'.$topic.'",location="'.$location.'",active="'.$active.'",date="'.$date.'",datetime="'.$datetime.'" where id="'.$ide.'"');
        
        if($query1) {
            $result = array(0 => "success");
        } else {
            $result = array(0 => "fail");
        }
        
        return $result; 
        
        
    }
    
       public function DeleteSchedule($ide){
        
        $query1 = $this-> db -> query('delete from sag_schedule where id="'.$ide.'"');
        if($query1) {
            $result = array(0 => "success");
        } else {
            $result = array(0 => "fail");
        }
        
        return $result; 
        
    }
    
    public function GetRegisteredMembers(){
        
            $arr = Array();
	        $courseArr = Array();
            $regArr = Array();
            $arr['list'] = "";
		
            $this->datatables->select('name,selcourse,regno,email,mobile,state,id')
                    ->edit_column('name', '<a href="viewmembers?id=$1">$2</a>', 'id,name')
                    ->edit_column('id', '<a class="del" id="$1" href="javascript:void(0)">x</a>', 'id') 
                    ->from('sag_regmember');
                
            $table = $this->datatables->generate();

            $editTable = json_decode($table);
            $tmpTable = $editTable->data;

            $rtrvTable = json_encode($editTable);

            return $rtrvTable;
        
    }
    
    public function ViewMember($ide){
        
        $query = $this->db->query('SELECT * from sag_regmember where id ="' . $ide . '"');
        $row = $query->result_array();

        $arr[] = "";
        $regarr = Array();
        $carr[] = '';
        
        if ($row) {
            
            $arr['name'] = $row[0]['name'];
            $arr['selcourse'] = $row[0]['selcourse'];
            $address =  $row[0]['address'];
            $arr['mobile'] =  $row[0]['mobile'];
			$resphone = $row[0]['resphone'];
            $arr['email'] =  $row[0]['email'];
            $arr['age'] = $row[0]['age'];
            $arr['sex'] = $row[0]['sex'];
			$pincode = " - ".$row[0]['pincode'];
			
			$fathername =  $row[0]['fathername'];
			$accommodation =  $row[0]['accommodation'];
			
			$regno = $row[0]['regno'];
            $collegename = $row[0]['collegename'];
			$university = $row[0]['university'];
			$yearcompletion = $row[0]['yearcompletion'];
			$dcirecognize = $row[0]['dcirecognize'];
			$state = $row[0]['state'];
			$designation = $row[0]['designation'];
			
			$photo = $row[0]['photo'];
			$arr['paymentmode'] = $row[0]['paymentmode'];
			
            $detailstr = "";
						
			$arr['address'] =  $address.$pincode;
			
			if($resphone!=""){$resphone = $resphone;} else{$resphone = "-";}
			if($fathername!=""){$fathername = $fathername;}else{$fathername = "-";}
			if($accommodation!=""){$accommodation = $accommodation;}else{$accommodation = "-";}
			if($collegename!=""){$collegename = $collegename;}else{$collegename = "-";}
			if($university!=""){$university = $university;}else{$university = "-";}
			if($yearcompletion!=""){$yearcompletion = $yearcompletion;}else{$yearcompletion = "-";}
			if($dcirecognize!=""){$dcirecognize = $dcirecognize;}else{$dcirecognize = "-";}
			if($state!=""){$state = $state;}else{$state = "-";}
			if($designation!=""){$designation = $designation;}else{$designation = "-";}
			if($regno!=""){$regno = $regno;}else{$regno = "-";}
			
			$arr['resphone'] = $resphone;
			$arr['regno'] = $regno;
			$arr['fathername'] = $fathername;
			$arr['accommodation'] = $accommodation;
			$arr['collegename'] = $collegename;
			$arr['university'] = $university;
			$arr['yearcompletion'] = $yearcompletion;
			$arr['dcirecognize'] = $dcirecognize;
			$arr['state'] = $state;
			$arr['designation'] = $designation;  
			
			if($photo!="") $arr['photo'] = '<img src="'.$this->config->item('web_url').'wp-content/uploads/documents/'.$photo.'" alt="'.$photo.'" width="140" height="auto" />';  else $arr['photo'] = '-';
            
        }
        
        return $arr;
        
    }

        public function courseDateFormat($date1){
            
            $month = date('M', strtotime($date1));
            $day1 = date('d', strtotime($date1));

            /*if ($date2 != "") {
                $day1 .= ", ";
                $day2 = date('d', strtotime($date2));
            } else {
                $day2 = "";
            }

            if ($date3 != "") {
                $day2 .= ", ";
                $day3 = date('d', strtotime($date3));
            } else {
                $day3 = "";
            }

            if ($date4 != "") {
                $day3 .= ", ";
                $day4 = date('d', strtotime($date4));
            } else {
                $day4 = "";
            }*/

            $year = date('Y', strtotime($date1));
            $formatteddate = $month . " " . $day1 . " - " . $year;
            
            return $formatteddate;
        }
        
        public function DeleteMembers($ide){
        
            $query1 = $this-> db -> query('delete from sag_regmember where id="'.$ide.'"');
            if($query1) {
                $result = array(0 => "success");
            } else {
                $result = array(0 => "fail");
            }

            return $result; 
        
       }
       
       public function GetAppointments(){
        
        $arr = Array();
        $arr['list'] = "";

        $this->datatables->select('id,name,phone,date,time,appfor,age')
                 ->edit_column('name', '<a  href="appdetails?id=$1">$2</a>', 'id,name') 
                ->edit_column('id', '<a class="del" id="$1" href="javascript:void(0)">x</a>', 'id') 
                ->from('rc_appointmetns');

        $table = $this->datatables->generate();

        return $table;
        
    }
    
    public function DeleteAppointment($ide){
        
            $query1 = $this-> db -> query('delete from rc_appointmetns where id="'.$ide.'"');
            if($query1) {
                $result = array(0 => "success");
            } else {
                $result = array(0 => "fail");
            }

            return $result; 
        
       }
       
        public function ViewAppointments($ide){
        
        $query = $this->db->query('SELECT * from rc_appointmetns where id ="' . $ide . '"');
        $row = $query->result_array();

        $arr[] = "";
        $regarr = Array();
        $carr[] = '';
        
        if ($row) {
            
            "`name`,`age`,`sex`,`country`,`state`,`city`,`phone`,`email`,`address`,`problem`,`alignments`,`appfor`,`ref_name`,`ref_address`,`date`,`time`,`queries`,`extra`";
            
            $arr['name'] = $row[0]['name'];
            $arr['age'] = $row[0]['age'];
            $arr['sex'] =  $row[0]['sex'];
            $arr['country'] =  $row[0]['country'];
            $arr['state'] =  $row[0]['state'];
            $arr['city'] = $row[0]['city'];
            $arr['phone'] = $row[0]['phone'];
            $arr['email'] = $row[0]['email'];
            $arr['address'] = $row[0]['address'];
            $arr['problem'] = $row[0]['problem'];
            $arr['alignments'] = $row[0]['alignments'];
            $arr['appfor'] = $row[0]['appfor'];
            $arr['ref_name'] = $row[0]['ref_name'];
            $arr['ref_address'] = $row[0]['ref_address'];
            $arr['date'] = $row[0]['date'];
            $arr['time'] = $row[0]['time'];
            $arr['queries'] = $row[0]['queries'];
            $arr['extra'] = $row[0]['extra'];
            
        }
        
        return $arr;
        
    }
  
    

}

?>
<?php
Class Login_Model extends CI_Model
{		
		
	public function VerifyLogin($emailid,$password){
		
		$result = array(0 => "");
		
		$encrpassword = SHA1($password);	
		
		$query = $this-> db -> query('select id,password,role from sag_users where username="'.$emailid.'"');
		$row = $query->result_array();
		if($row){
			
			$userid = $row[0]['id'];
			$dbpassword = $row[0]['password'];
			$role = $row[0]['role'];
									
			if($dbpassword==$encrpassword ){
				
				$sessid = uniqid('', true);                            
                                    $sess_array = array('id' => $sessid, 'role' => $role);				
                                    $this->session->set_userdata('loggedin', $sess_array);
                                    $this->createSession($sessid,$userid,$role);

                                    $result = array(0 => "success", 1 => $role);
                                    return $result;                              
				
			}else{
				$result = array(0 => "fail");
				return $result;
			}			
		
		}else{
			$result = array(0 => "notfound");
            return $result;
		}
		
		return $result;
		
	}
	
	public function createSession($sessid,$userid,$role){
		
		$user_ip = $this->session->userdata('ip_address');
		$user_agent = $this->session->userdata('user_agent');
		
		$offset=5*60*60 + 30*60;
		$dateformat = 'Y-m-d H:i:s';
		$curtime = gmdate($dateformat, time()+$offset);		
		
		$query = $this-> db -> query('select userid from sag_session where sessionid="'.$sessid.'"');
       	$row = $query->result_array();
		if($row){
			$this->session->unset_userdata('loggedin');
			redirect('login', 'refresh');
		}else{
			$query1 = $this-> db -> query('insert into sag_session (`sessionid`,`userid`,`role`,`ip`,`agent`,`start_time`,`end_time`,`status`) values ("'.$sessid.'","'.$userid.'","'.$role.'","'.$user_ip.'","'.$user_agent.'","'.$curtime.'","","o")');
		}		
		
	}
	
	public function endSession(){
		
		$session_id = "";
		
		$session_data = $this->session->userdata('loggedin');
		$session_id = $session_data['id'];
		
		$offset=5*60*60 + 30*60;
		$dateformat = 'Y-m-d H:i:s';
		$curtime = gmdate($dateformat, time()+$offset);
		
		
		$this-> db -> query('update sag_session set end_time="'.$curtime.'", status="c" where sessionid="'.$session_id.'"');
	}		
	
	public function GetUserId(){
		
		$arr = array();
		$arr['id'] = "";
		$arr['name'] = "";		
		$arr['role'] = "";
		$arr['mobile'] = "";
				
		if($this->session->userdata('loggedin')){
     		$session_data = $this->session->userdata('loggedin');
			$session_id = $session_data['id'];
			$session_role = $session_data['role'];
			$user_ip = $this->session->userdata('ip_address');
		  	$user_agent = $this->session->userdata('user_agent');		
			
			$query = $this-> db -> query('select userid from sag_session where sessionid="'.$session_id.'" and role="'.$session_role.'" and ip="'.$user_ip.'" and agent="'.$user_agent.'" and status="o"');
	       	$row = $query->result_array();
			if($row){
				$userid = $row[0]['userid'];
								
				$query1 = $this-> db -> query('select username,role,mobile from sag_users where id="'.$userid.'"');
	       		$row1 = $query1->result_array();
				if($row1){
					
					$arr['id'] = $userid;
					$arr['name'] = $row1[0]['username'];					
					$arr['role'] = $row1[0]['role'];
					$arr['mobile'] = $row1[0]['mobile'];
					
					
				}else{
					$this->session->unset_userdata('loggedin');
					redirect('login', 'refresh');
				}
							
			}else{
				$this->session->unset_userdata('loggedin');
				redirect('login', 'refresh');
			}
			
		}else{
			$this->session->unset_userdata('loggedin');
			redirect('login', 'refresh');
		}
			
		return $arr;
		
                
                
	}
	
	public function CheckLogin(){
		
		$result = array(0 => false);
		
		if($this->session->userdata('loggedin')){
     		$session_data = $this->session->userdata('loggedin');
			$session_id = $session_data['id'];
			$session_role = $session_data['role'];
			$user_ip = $this->session->userdata('ip_address');
		  	$user_agent = $this->session->userdata('user_agent');		
			
			$query = $this-> db -> query('select userid from sag_session where sessionid="'.$session_id.'" and role="'.$session_role.'" and ip="'.$user_ip.'" and agent="'.$user_agent.'" and status="o"');
	       	$row = $query->result_array();
			if($row){
				$userid = $row[0]['userid'];
								
				$query1 = $this-> db -> query('select username from sag_users where id="'.$userid.'"');
	       		$row1 = $query1->result_array();
				if($row1){
					
					$name = $row1[0]['username'];
					
					$result = array(0 => true, 1 => $name);
					return $result;
					
				}
							
			}
			
		}
			
		return $result;
		
	}


	
	
}
?>
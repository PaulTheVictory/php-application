<?php



Class Album_Model extends CI_Model {

    

     public function __construct() {

        

     }





    public function GetAllAlbums() {



        $arr = Array();



        $arr['album_list'] = "";



        $query = $this->db->query('select DISTINCT albumid,albumname from sag_albums where 1');

		

        $row = $query->result_array();

	

        if ($row) {



            for ($i = 0; $i < count($row); $i++) {



                $albumid = $row[$i]['albumid'];

                $albumname = $row[$i]['albumname'];				

				$query1 =$this->db->query('select thump,course_name from sag_albums as a,sag_courses as c where a.albumid="'. $albumid.'" and a.courseid=c.id and thump<>""');

				$row1=$query1->result_array();

                if ($row1) {

                    $thumbimg = $row1[0]['thump'];
					$course_name = $row1[0]['course_name'].' - ';

                } else {

                    $thumbimg = base_url()."docs/albums/ap.jpg";
					$course_name = "";

                }



                $arr['album_list'] .= '<li id="' . $albumid . '" class="alist"><img class="album-photo" src="' . $thumbimg . '" /><h3>' .$course_name. $albumname . ' (' . count($row1) . ')</h3><div class="album-hover"></div></li>';

            }

        }



        $arr['album_list'] .= '<li class="addalbum"><img class="album-photo" src="' . base_url() . 'docs/albums/ap-add.jpg" /><h3>Add Album</h3><div class="album-hover"></div></li>';

	   

	   

        return $arr;

        

    }

	

	public function Addphoto($image,$tempimage){	

	

		$sess = $this->session->userdata("verified");

		$id= $sess['alb_id'];

	

		$name='';		

		$query = $this->db->query('select albumname from sag_albums where albumid="' . $id . '"');

        $row = $query->result_array();		

        if ($row) {

			$name= $row[0]['albumname'];				

		}		

				 
		$uid = uniqid();
		
		$query = $this->db->query('insert into sag_albums(`id`,`albumid`,`albumname`,`image`,`thump`) values ("'. $uid . '","'. $id . '","' . $name . '","' . $image . '","' . $tempimage . '")');	 	 		 

		

		if($query) {

            $result = array(0 => "success");

        } else {

            $result = array(0 => "fail");

        }

		return $result;	

		

	}



    public function CreateAlbum($albumname) {



        $result = array(0 => "");



      /*  $query = $this->db->query('select albumid from sag_albums where albumname="' . $albumname . '"');

        $row = $query->result_array();

        if ($row) {



            $result = array(0 => "exists");

            return $result;

        } else {*/



            $id = uniqid();$albumid = uniqid();



            $query1 = $this->db->query('insert into sag_albums (`id`,`albumid`,`albumname`) values ("' . $id . '","' . $albumid . '","' . $albumname . '")');



            if ($query1) {

                mkdir("docs/albums/" . $albumid);

				mkdir("docs/albums/". $albumid."/thumb_" . $albumid);

                $result = array(0 => "success");

                return $result;

            }

       // }



        return $result;

        

    }



    public function GetAlbumDetails($albumid) {

 

        $arr['albumid'] = "";

        $arr['albumname'] = "";
		
		$arr['courseid'] = "";
		
		$arr['coursename'] = "";

		$query='';$val='';

		$query0 = $this->db->query('select thump from sag_albums where albumid="' . $albumid . '" and thump<>""');

		$row0 = $query0->result_array();

	    //print_r(count($row0));die;

		

		if(count($row0) >= 1)

		{			

        $query = $this->db->query('select albumname,thump,image,courseid from sag_albums where albumid="' . $albumid . '" and thump<>""');

		}

		else{

		$query = $this->db->query('select distinct albumname,courseid from sag_albums where albumid="' . $albumid . '"');

		$val=1;

		}

        $row = $query->result_array();

        if ($row) {

            $arr['albumid'] = $albumid;

            $arr['albumname'] = $row[0]['albumname'];
			
			$arr['courseid'] = $row[0]['courseid'];
			
			$query1 = $this->db->query('select course_name from sag_courses where id="' . $row[0]['courseid'] . '"');
			$row1 = $query1->result_array();
			if($row1)$arr['coursename'] = $row1[0]['course_name'];

        }	

				

		if($val=='1'){$row='';}

				

        return array('albumdetails'=>$arr,'rowimages'=>$row);

        

    }



    

    public function AddPhotoInAlbum($albumid, $newName) {



        $newName = $newName . "|";



        $query = $this->db->query('select photos from sag_albums where albumid="' . $albumid . '"');

        $row = $query->result_array();

        if ($row) {

            $photos = $row[0]['photos'];

            if (strpos($photos, $newName) == false) {

                $updphotos = $row[0]['photos'] . $newName;

                $query1 = $this->db->query('update sag_albums set photos="' . $updphotos . '" where albumid="' . $albumid . '"');

            }

        }

        

    }



    public function EditAlbumName($albumid, $albumname) {



        $result = array(0 => "");

        $query1 = $this->db->query('update sag_albums set albumname="' . $albumname . '" where albumid="' . $albumid . '"');



        if ($query1) {

            $result = array(0 => "success");

            return $result;

        }



        return $result;

        

    }



    
    public function AddtoCourse($albumid,$courseid) {


          $query = $this->db->query('update sag_albums set courseid="' . $courseid . '" where albumid="' . $albumid . '"');


    }
	

    public function DeleteAlbum($albumid) {



        $query = $this->db->query('delete from sag_albums where albumid="' . $albumid . '"');



        if ($query) {

            $dirname = "docs/albums/" . $albumid;

			$thumbdirname = "docs/albums/".$albumid."/thumb_".$albumid;

			

			if (is_dir($thumbdirname))

                $thumbdir_handle = opendir($thumbdirname);

            if (!$thumbdir_handle)

                return false;

            while ($thumbfile = readdir($thumbdir_handle)) {

                if ($thumbfile != "." && $thumbfile != "..") {

                    if (!is_dir($thumbdirname . "/" . $thumbfile)) {

                        unlink($thumbdirname . "/" . $thumbfile);

                    } else {

                        delete_directory($thumbdirname . '/' . $thumbfile);

                    }

                }

            }

			

			closedir($thumbdir_handle);

			rmdir($thumbdirname);

			

            if (is_dir($dirname))

                $dir_handle = opendir($dirname);

            if (!$dir_handle)

                return false;

            while ($file = readdir($dir_handle)) {

                if ($file != "." && $file != "..") {

                    if (!is_dir($dirname . "/" . $file)) {

                        unlink($dirname . "/" . $file);

                    } else {

                        delete_directory($dirname . '/' . $file);

                    }

                }

            }

			

            closedir($dir_handle);

            rmdir($dirname);

			

            return true;

        }

        

    }



    

    public function DeletePhoto($albumid, $filename) {



            $dirname = "docs/albums/" . $albumid;

            if (is_dir($dirname))

                $dir_handle = opendir($dirname);

            if (!$dir_handle)

                return false;

            if (!is_dir($filename)) {

                unlink($filename);

                return true;

            }

            

    }

	

	  

    public function DeleteImage($id, $src) {



            $query = $this->db->query('delete from sag_albums where albumid="' . $id . '" and thump="' . $src . '"');	

			

            return $query;

    }

    



}
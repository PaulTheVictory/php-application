<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Appointments extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model('login_model','',TRUE);
                $this->load->model('course_model','',TRUE);
                 $this->load->library('table'); 
                 $this->load->helper('file');

	}
	
	function index()
	{
		if($this->session->userdata('loggedin'))
   		{
                    $session_data = $this->session->userdata('loggedin');
                    $session_id = $session_data['id'];
                    $session_role = $session_data['role'];
                    $data['user'] = $this->login_model->GetUserId();		
		
				
                    $data['menu'] = $this->load->view('headermenu', $data, TRUE);
                    
                     $tmpl = array('table_open' => '<table class="sortable" id="coursetable" style="margin-top:40px;">');
                                $this->table->set_template($tmpl);
                                $this->table->set_heading('Name','Mobile','Age','Preferred Date', 'Preferred Time', 'Appointment for','');
						
                    $this->load->view('header', $data);
                    $this->load->view('appointments_view', $data);
                    $this->load->view('footer');
		}
   		else
   		{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
   		}
		
	}
        
         public function getAppointmentLists() {
            
            if($this->session->userdata('loggedin')){
                
                $ret =  $this->course_model->GetAppointments();
                echo $ret;
                
            }else{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
            }
            
        }
        
        public function delAppointment() {
            
            if ($this->session->userdata('loggedin')) {

                $ide = isset($_GET['ide']) ? $_GET['ide'] : '';

                if($ide != ""){
                     $ret = $this->course_model->DeleteAppointment($ide);
                } else {
                    $ret = array(0 => "fail");
                }

                echo json_encode($ret);
            
            }else {
                //If no session, redirect to login page
                redirect('login', 'refresh');
            }
                
        }
	
	
	
	
}
?>

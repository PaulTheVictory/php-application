<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Editcourse extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model('course_model','',TRUE);
                $this->load->model('login_model','',TRUE);

	}
	
	function index()
	{
		if($this->session->userdata('loggedin'))
   		{
                    $ide = isset($_GET['id']) ? $_GET['id'] : '';
     		    $session_data = $this->session->userdata('loggedin');
		    $session_id = $session_data['id'];
     		    $session_role = $session_data['role'];
		    $data['user'] = $this->login_model->GetUserId();
                    $data['edit'] = $this->course_model->EditCourse($ide);
				
                    $data['menu'] = $this->load->view('headermenu', $data, TRUE);
                    $this->load->view('header', $data);
                    $this->load->view('editcourse_view', $data);
                    $this->load->view('footer');
			
                }
   		else
   		{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
   		}
		
	}
        
         
        public function updateCourse() {
             $fullimgpath='';
            if ($this->session->userdata('loggedin')) {
				
					$course = isset($_POST['course']) ? $_POST['course'] : '';
					$desc = isset($_POST['desc']) ? $_POST['desc'] : '';
					$duration = isset($_POST['duration']) ? $_POST['duration'] : '';
					$visible = isset($_POST['visible']) ? $_POST['visible'] : 'No';
					$link = isset($_POST['ulink']) ? $_POST['ulink'] : '';
					$id = isset($_POST['id']) ? $_POST['id'] : '';

												 
				 if(isset($_FILES['fileToUpload']['name'])=="" || !isset($_FILES['fileToUpload']['name']))
				 {
				 
					$newName = isset($_POST['image']) ? $_POST['image'] : '';
					$fullimgpath =base_url().'docs/courses/'.$newName;
					
					if($visible=="") $visible="No";
					
					if($course != "" && $desc != "" && $visible !=""){
						 $ret = $this->course_model->UpdateCourse($course, $desc,$duration, $visible, $newName,$unlinkimage="",$link, $id);
					} else {
						$ret = array(0 => "fail");
					}
           
                    echo json_encode($ret);
				 }
			   else if (isset($_FILES['fileToUpload']['name'])!="") {
				   
				   $validExtensions = array('.jpg', '.jpeg', '.JPEG', '.png', '.JPG', '.PNG');
		           $fileExtension = strrchr($_FILES['fileToUpload']['name'], ".");
				   
				   if (in_array($fileExtension, $validExtensions)) {
				   
                $uniqid = uniqid();
				$newName = $uniqid."".$fileExtension;
    			$destination = 'docs/courses/'. $newName;
				$fullimgpath =base_url().'docs/courses/'.$newName;
					$width = 324;
					$height = 181;
					
					/* Get original image x y*/
					list($w, $h) = getimagesize($_FILES['fileToUpload']['tmp_name']);
					
					if($width>$w || $height>$h){
						$width = 324;
						$height = 181;
					}
					
					
  					/* calculate new image size with ratio */
  					$ratio = max($width/$w, $height/$h);
  					$h = ceil($height / $ratio);
  					$x = ($w - $width / $ratio) / 2;
  					$w = ceil($width / $ratio);
					
					
					$imgString = file_get_contents($_FILES['fileToUpload']['tmp_name']);
					
					$image = imagecreatefromstring($imgString);
  					$tmp = imagecreatetruecolor($w, $h);
  					imagecopyresampled($tmp, $image, 0, 0, 0, 0, $w, $h, $w, $h);
					
					
					$result = imagejpeg($tmp,$destination,100);
										
				if ($result) {
					
					$unlinkimage = isset($_POST['image']) ? $_POST['image'] : '';
					
					if($visible=="") $visible="No";
					
					if($course != "" && $desc != "" && $visible !="" && $newName !=""){
						
						 $ret = $this->course_model->UpdateCourse($course, $desc,$duration, $visible, $fullimgpath,$unlinkimage, $link, $id);
						
					} else {
						$ret = array(0 => "fail");
					}

           
                    echo json_encode($ret);
					
					}
					else
					{
						$ret = array(0 => "fail");;
				        echo json_encode($ret);
				        exit;
					}
				
				
			}else
			{
				$ret = array(0 => "uerror");;
				echo json_encode($ret);
				exit;
			}
			   }else
					{
						$ret = array(0 => "fail");;
				        echo json_encode($ret);
				        exit;
					}
                 
            }else {
                //If no session, redirect to login page
                redirect('login', 'refresh');
            }
        
        
        }
	
	
	
	
}
?>
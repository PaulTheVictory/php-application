<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Addschedule extends CI_Controller {

	function __construct() {
            
		parent::__construct();
		$this->load->model('course_model','',TRUE);
                $this->load->model('login_model','',TRUE);
                 $this->load->library('table'); 

	}
	
	function index() {
            
            if ($this->session->userdata('loggedin')) {

                $session_data = $this->session->userdata('loggedin');
                $session_id = $session_data['id'];
                $session_role = $session_data['role'];
                $data['user'] = $this->login_model->GetUserId();


                $data['menu'] = $this->load->view('headermenu', $data, TRUE);
                
                
                $tmpl = array('table_open' => '<table class="sortable" id="assettable" style="margin-top:80px">');
                                $this->table->set_template($tmpl);
                                $this->table->set_heading('Date', 'Topic','Location','Is Active','');

                $this->load->view('header', $data);
                $this->load->view('addschedule_view', $data);
                $this->load->view('footer');
                
            } else {
                //If no session, redirect to login page
                redirect('login', 'refresh');
            }
            
        }
        
        
        public function getSchedules() {
            
            if ($this->session->userdata('loggedin')) {

                $ret = $this->course_model->GetAllSchedules();  
                echo $ret;
            
            }else {
                //If no session, redirect to login page
                redirect('login', 'refresh');
            }
        
        
        }
        
        
        public function insertSchedule() {
            
            if ($this->session->userdata('loggedin')) {

                $date = isset($_GET['date']) ? $_GET['date'] : '';
                $location = isset($_GET['location']) ? $_GET['location'] : '';
                $topic = isset($_GET['topic']) ? $_GET['topic'] : '';
                $active = isset($_GET['active']) ? $_GET['active'] : '';

                if($topic != ""){
                     $ret = $this->course_model->AddSchedule($date, $location, $topic, $active);
                } else {
                    $ret = array(0 => "fail");
                }

                echo json_encode($ret);
            
            }else {
                //If no session, redirect to login page
                redirect('login', 'refresh');
            }
                
        }
        
        public function delSchedule() {
            
            if ($this->session->userdata('loggedin')) {

                $ide = isset($_GET['ide']) ? $_GET['ide'] : '';

                if($ide != ""){
                     $ret = $this->course_model->DeleteSchedule($ide);
                } else {
                    $ret = array(0 => "fail");
                }

                echo json_encode($ret);
            
            }else {
                //If no session, redirect to login page
                redirect('login', 'refresh');
            }
                
        }

}
?>
<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Addcert extends CI_Controller {

	function __construct() {
            
		parent::__construct();
		$this->load->model('course_model','',TRUE);
                $this->load->model('login_model','',TRUE);

	}
	
	function index() {
            
            if ($this->session->userdata('loggedin')) {

                $session_data = $this->session->userdata('loggedin');
                $session_id = $session_data['id'];
                $session_role = $session_data['role'];
                $data['user'] = $this->login_model->GetUserId();
                $data['clists'] = $this->course_model->GetCityCountryState();

                $data['menu'] = $this->load->view('headermenu', $data, TRUE);

                $this->load->view('header', $data);
                $this->load->view('addcert_view', $data);
                $this->load->view('footer');
            } else {
                //If no session, redirect to login page
                redirect('login', 'refresh');
            }
            
        }
        
        public function addCert() {
            
            if ($this->session->userdata('loggedin')) {

            $course = isset($_GET['course']) ? $_GET['course'] : '';
            $module = isset($_GET['module']) ? $_GET['module'] : '';
            $visible = isset($_GET['visible']) ? $_GET['visible'] : '';
            if($course != "" && $module != "" && $visible !="" ){
                 $ret = $this->course_model->AddCourse($course, $module, $visible);
            } else {
                $ret = array(0 => "fail");
            }

           
            echo json_encode($ret);
            
            }else {
                //If no session, redirect to login page
                redirect('login', 'refresh');
            }
        
        
        }
        
        
        public function uploadCertDetails() {
		
		$session_data = $this->session->userdata('loggedin');
		$session_id = $session_data['id'];
		$session_role = $session_data['role'];
		$data['user'] = $this->login_model->GetUserId();
                
                $certname = isset($_POST['certname']) ? $_POST['certname'] : '';
                $certdate = isset($_POST['certdate']) ? $_POST['certdate'] : '';
                $certvenue = isset($_POST['certvenue']) ? $_POST['certvenue'] : '';
                $certactive = isset($_POST['certactive']) ? $_POST['certactive'] : '';
		
		$status = "";
		$filename = "";
		
		$validExtensions = array('.jpg', '.jpeg', '.gif', '.png', '.JPG', '.PNG');
		$fileExtension = strrchr($_FILES['fileToUpload']['name'], ".");
		if (in_array($fileExtension, $validExtensions)) {
			$newName = $data['user']['id']."_".rand(100,999).$fileExtension;
                        $base = $_SERVER['DOCUMENT_ROOT'] ."/";
			$destination = $base .'admin/docs/certificate/' . $newName;
			
			move_uploaded_file($_FILES['fileToUpload']['tmp_name'],$destination);
            
			/*list($w, $h) = getimagesize($_FILES['fileToUpload']['tmp_name']);
			$nw = 500; 
			$nh = ($h/$w)*$nw;
			$ratio = max($nw/$w, $nh/$h);
			$h = ceil($nh / $ratio);
			$x = ($w - $nw / $ratio) / 2;
			$w = ceil($nw / $ratio);
			
			$imgString = file_get_contents($_FILES['fileToUpload']['tmp_name']);
					
			$image = imagecreatefromstring($imgString);			
			$tmp = imagecreatetruecolor($nw, $nh);
			imagefill($tmp, 0, 0, imagecolorallocate($tmp, 255, 255, 255));
			imagealphablending($tmp, TRUE);
			imagecopyresampled($tmp, $image, 0, 0, $x, 0, $nw, $nh, $w, $h);			
			$result = imagejpeg($tmp,$destination,100);*/
			$result = true;
			if ($result) {
				$this->course_model->UploadCertificatePhoto($certname,$certdate,$certvenue,$certactive,$newName);
				$status = "success";	
				$filename = $newName;			
			} else{
				$status = "Image upload is failed. Try again.";
			}
			
		}else{
			
			$status = "Please select a valid file to upload.";				
			
		}
		
		echo json_encode(array('status' => $status, 'filename' => $filename));
		
	}

}
?>
<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Album extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model('login_model','',TRUE);
                $this->load->model('album_model','',TRUE);
		$this->load->model('course_model','',TRUE);
                 $this->load->library('table'); 

	}
	
    public function index() {
            
        if ($this->session->userdata('loggedin')) {
            $session_data = $this->session->userdata('loggedin');
            $session_id = $session_data['id'];
            $session_role = $session_data['role'];
            $data['user'] = $this->login_model->GetUserId();


            $data['menu'] = $this->load->view('headermenu', $data, TRUE);
            $albumid = isset($_GET['id']) ? $_GET['id'] : '';
            $qry = $this->album_model->GetAlbumDetails($albumid);
			$data['albumdetails']=$qry['albumdetails'];
			$data['totimages']=$qry['rowimages'];
			
			$data['courselist'] = $this->course_model->GetCourseLists();
						
            $this->load->view('header', $data);
            $this->load->view('album_view', $data);
            $this->load->view('footer');
        } else {
            //If no session, redirect to login page
            redirect('login', 'refresh');
        }
    }

    public function uploadPhoto() {
		$imagepath='';
		$tempimagepath='';
		$destination='';
		$destinationthumb='';
		
	    if(isset($_POST['albumid'])){
			$session_data = $this->session->userdata('verified');
			$session_data['alb_id'] = $_POST['albumid'];
			$this->session->set_userdata("verified", $session_data);
		}
		$session_data = $this->session->userdata('logged_in');
        $session_id = $session_data['id'];
        $session_role = $session_data['role'];
		//$session['album_id'] = $session_data['id'];
        $albumid = isset($_POST['albumid']) ? $_POST['albumid'] : '';

        $validExtensions = array('.jpg', '.jpeg', '.gif', '.png', '.JPG', '.PNG');
        $fileExtension = strrchr($_FILES['file']['name'], ".");
		
        if (in_array($fileExtension, $validExtensions)) {
            $newName = preg_replace('/\s+/', '', $_FILES['file']['name']);
          
		   $destinat = 'docs/albums/' . $albumid . '/';  
		  
		   if (!file_exists($destinat)) {
			   
			    mkdir("docs/albums/" . $albumid);
				mkdir("docs/albums/". $albumid."/thumb_" . $albumid);                		
		   }		   
			   			      
			$destination = 'docs/albums/' . $albumid . '/' . $newName;			
			$destinationthumb = 'docs/albums/' . $albumid . '/thumb_'. $albumid . '/' . $newName;	
			   
		    $width = 600;
            $height = 600;

            /* Get original image x y */
            list($w, $h) = getimagesize($_FILES['file']['tmp_name']);

            if ($width > $w || $height > $h) {
                $width = 300;
                $height = 300;
            }

            /* calculate new image size with ratio */
            //$ratio = max($width/$w, $height/$h);
            //$h = ceil($height / $ratio);
            //$x = ($w - $width / $ratio) / 2;
            //$w = ceil($width / $ratio);
			$maxDim = 160;
			$size = getimagesize( $_FILES['file']['tmp_name'] );
            $ratio = $size[0]/$size[1]; // width/height
            if( $ratio > 1) {
                $width = $maxDim;
                $height = 120;
            } else {
                $width = $maxDim;
                $height = 120;
            }

            $imgString = file_get_contents($_FILES['file']['tmp_name']);

            $image = imagecreatefromstring($imgString);
            $tmp = imagecreatetruecolor($w, $h);
            imagecopyresampled($tmp, $image, 0, 0, 0, 0, $w, $h, $w, $h);
			
			$tmpthumb = imagecreatetruecolor($width, $height);
            imagecopyresampled($tmpthumb, $image, 0, 0, 0, 0, $width, $height, $size[0], $size[1]);

            $result = imagejpeg($tmp, $destination, 100);
			$resultthumb = imagejpeg($tmpthumb, $destinationthumb, 100);			
			
			//file_put_contents($destination . $newName, $tmp);
			
			$imagepath=base_url().$destination;
			$tempimagepath=base_url().$destinationthumb;
			
            if ($result) {
                $this->album_model->Addphoto($imagepath,$tempimagepath);
            }

            //if(move_uploaded_file($_FILES['file']['tmp_name'], $destination)){
            //$ret = $this->academy_model->AddPhotoInAlbum($user_id,$albumid,$newName);
            //}
        }
		
    }

    public function editAlbumName() {

        $session_data = $this->session->userdata('logged_in');
        $session_id = $session_data['id'];
        $session_role = $session_data['role'];
       
        $albumid = isset($_GET['albumid']) ? $_GET['albumid'] : '';
        $albumname = isset($_GET['albumname']) ? $_GET['albumname'] : '';

        $ret = $this->album_model->EditAlbumName($albumid, $albumname);
        echo json_encode($ret);
    }
	
	public function editalbum()	{
		$session_data = $this->session->userdata('loggedin');
        $session_id = $session_data['id'];
        $session_role = $session_data['role'];		
		$data['user'] = $this->login_model->GetUserId();
		$data['menu'] = $this->load->view('headermenu', $data, TRUE);
		
		$albumid = isset($_GET['id']) ? $_GET['id'] : '';
		$qry = $this->album_model->GetAlbumDetails($albumid);
		
		$data['albumdetails']=$qry['albumdetails'];
		$data['totimages']=$qry['rowimages'];	
		
		$this->load->view('header', $data);  
       	$this->load->view('editalbum_view',$data);
		$this->load->view('footer');
	}

    public function deleteAlbum() {

        $session_data = $this->session->userdata('logged_in');
        $session_id = $session_data['id'];
        $session_role = $session_data['role'];
  
        $albumid = isset($_GET['albumid']) ? $_GET['albumid'] : '';

        $ret = $this->album_model->DeleteAlbum($albumid);
        echo json_encode($ret);
    }

	public function deletesingleimage() {
			
	$id = $_POST['id'];
	$src = $_POST['src'];

	$retval = $this->album_model->DeleteImage($id,$src);
	//echo $ret;
	echo json_encode($retval);
		
	}
	
	public function addtoCourse() {

        $session_data = $this->session->userdata('logged_in');
        $session_id = $session_data['id'];
        $session_role = $session_data['role'];
  
		$albumid = isset($_GET['albumid']) ? $_GET['albumid'] : '';
        $courseid = isset($_GET['courseid']) ? $_GET['courseid'] : '';

        $ret = $this->album_model->AddtoCourse($albumid,$courseid);
        echo json_encode($ret);
    }
	
}
?>

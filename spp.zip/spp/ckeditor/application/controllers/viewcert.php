<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Viewcert extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model('login_model','',TRUE);
                $this->load->model('course_model','',TRUE);
                 $this->load->library('table'); 
                 $this->load->helper('file');

	}
	
	function index()
	{
		if($this->session->userdata('loggedin'))
   		{
                    $session_data = $this->session->userdata('loggedin');
                    $session_id = $session_data['id'];
                    $session_role = $session_data['role'];
                    $data['user'] = $this->login_model->GetUserId();		
		
				
                    $data['menu'] = $this->load->view('headermenu', $data, TRUE);
                    
                     $tmpl = array('table_open' => '<table class="sortable" id="coursetable" style="margin-top:40px;">');
                                $this->table->set_template($tmpl);
                                $this->table->set_heading('Certificate', 'Name', 'Date of certified','Venue','Is Active','');
						
                    $this->load->view('header', $data);
                    $this->load->view('viewcert_view', $data);
                    $this->load->view('footer');
		}
   		else
   		{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
   		}
		
	}
        
         public function getCertificateLists() {
            
            if($this->session->userdata('loggedin')){
                
                $ret =  $this->course_model->GetCertificates();
                echo $ret;
                
            }else{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
            }
            
        }
        public function getimage(){
            
            
            if($this->session->userdata('loggedin')){
                
                $filename = isset($_GET['name']) ? $_GET['name'] : '';
                $base = $_SERVER['DOCUMENT_ROOT'] ."/";
		$src_path = $base .'admin/docs/certificate/' . $filename;
                
                if ( is_readable($src_path)) {
                    
                    $info = getimagesize($src_path);
                    if ($info !== FALSE) {
                        header("Content-type: {$info['mime']}");
                        echo read_file($src_path);

                    }
                    
                }
          
                
            }else{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
            }
            
        }
        
        public function delCert() {
            
            if ($this->session->userdata('loggedin')) {

                $ide = isset($_GET['ide']) ? $_GET['ide'] : '';

                if($ide != ""){
                     $ret = $this->course_model->DeleteCert($ide);
                } else {
                    $ret = array(0 => "fail");
                }

                echo json_encode($ret);
            
            }else {
                //If no session, redirect to login page
                redirect('login', 'refresh');
            }
                
        }
	
        
        public function isActive(){
            
            if ($this->session->userdata('loggedin')) {

                $ide = isset($_GET['ide']) ? $_GET['ide'] : '';
                $isactive = isset($_GET['isactive']) ? $_GET['isactive'] : '';

                if($ide != ""){
                     $ret = $this->course_model->IsActiveCert($ide,$isactive);
                } else {
                    $ret = array(0 => "fail");
                }

                echo json_encode($ret);
            
            }else {
                //If no session, redirect to login page
                redirect('login', 'refresh');
            }
            
        }
	
	
	
}
?>

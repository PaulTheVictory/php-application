<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Edittestimonial extends CI_Controller {

	function __construct() {
            
		parent::__construct();
		$this->load->model('course_model','',TRUE);
        $this->load->model('login_model','',TRUE);

	}
	
	function index() {
            
            if ($this->session->userdata('loggedin')) {

                $session_data = $this->session->userdata('loggedin');
                $session_id = $session_data['id'];
                $session_role = $session_data['role'];
                $data['user'] = $this->login_model->GetUserId();
				
				$data['courselist'] = $this->course_model->GetCourseLists();

                $data['menu'] = $this->load->view('headermenu', $data, TRUE);
				
				if(isset($_GET['id'])){
					
				$data['testdetails'] = $this->course_model->EditTestimonial($_GET['id']);
				
				}
				else {
                //If no session, redirect to login page
                redirect('dashboard', 'refresh');
            }

                $this->load->view('header', $data);
                $this->load->view('edittestimonial_view', $data);
                $this->load->view('footer');
            } else {
                //If no session, redirect to login page
                redirect('login', 'refresh');
            }
            
        }
		
	public function UpdateTestimonial() {
            $fullimgpath='';
			$fullphtopath='';
            if ($this->session->userdata('loggedin')) {
				
				
				$validExtensions = array('.jpg', '.jpeg', '.png', '.JPG', '.PNG');
		
		$newImage = "";
		$newPhoto = "";
		
		$photo = uniqid();
		
		if(isset($_FILES['photoToUpload']['name']) && !empty($_FILES['photoToUpload']['name'])){
			
		$fileExtension = strrchr($_FILES['photoToUpload']['name'], ".");
		
			if (in_array($fileExtension, $validExtensions)) {
				
				$newPhoto = $photo."".$fileExtension;
    			$destination = 'docs/testimonial/photo/' . $newPhoto;
				
					$width = 96;
					$height = 126;
					
					/* Get original image x y*/
					list($w, $h) = getimagesize($_FILES['photoToUpload']['tmp_name']);
					
					if($width>$w || $height>$h){
						$width = 96;
						$height = 126;
					}
					
  					/* calculate new image size with ratio */
  					$ratio = max($width/$w, $height/$h);
  					$h = ceil($height / $ratio);
  					$x = ($w - $width / $ratio) / 2;
  					$w = ceil($width / $ratio);
					
					$imgString = file_get_contents($_FILES['photoToUpload']['tmp_name']);
					
					if($fileExtension==".jpg" || $fileExtension==".jpeg"){
						
						$image = imagecreatefromstring($imgString);
						$tmp = imagecreatetruecolor($width, $height);
						imagecopyresampled($tmp, $image, 0, 0, $x, 0, $width, $height, $w, $h);
						$result = imagejpeg($tmp,$destination,100);
						
					}
					else if($fileExtension==".png"){ 
						
						$image = imagecreatefrompng($_FILES['photoToUpload']['tmp_name']);
						$tmp = imagecreatetruecolor($width, $height);
						$background = imagecolorallocatealpha($tmp, 0, 0, 0, 127); 
						imagecolortransparent($tmp, $background);
						imagefill($tmp, 0, 0, $background);
						imagecopyresampled($tmp, $image, 0, 0, $x, 0, $width, $height, $w, $h);
						imagesavealpha($tmp,true);
						$result = imagepng($tmp,$destination);
					}
										
				if ($result) {
					
          							
   				}else{
					
					$ret = array(0 => "pfail");
					echo json_encode($ret);
					exit;
				}
			}else{
				
				$ret = array(0 => "pfail");
					echo json_encode($ret);
					exit;
				
			}
			
		}
			
		
	 if(isset($_FILES['imageToUpload']['name']) && !empty($_FILES['imageToUpload']['name']))
	 
		{
			
			$fileExtension = strrchr($_FILES['imageToUpload']['name'], ".");
		
			if (in_array($fileExtension, $validExtensions)) {
				
				$newImage = $photo."".$fileExtension;
    			$destination = 'docs/testimonial/image/' . $newImage;
				
					
					/* Get original image x y*/
					list($w, $h) = getimagesize($_FILES['imageToUpload']['tmp_name']);
					
					$width = 600;
					$height = $h;
					
					if($width>$w || $height>$h){
						$width = 600;
						$height = $h;
					}
					
  					/* calculate new image size with ratio */
  					$ratio = max($width/$w, $height/$h);
  					//$h = ceil($height / $ratio);
  					$x = ($w - $width / $ratio) / 2;
  					//$w = ceil($width / $ratio);
					
					$imgString = file_get_contents($_FILES['imageToUpload']['tmp_name']);
					
					$image = imagecreatefromstring($imgString);
  					$tmp = imagecreatetruecolor($width, $height);
  					imagecopyresampled($tmp, $image, 0, 0, $x, 0, $width, $height, $w, $h);
					
					$result = imagejpeg($tmp,$destination,100);
										
				if ($result) {
						
					
          							
   				}else{
					
					$ret = array(0 => "pfail");
					echo json_encode($ret);
					exit;
					
				}
			}else{
				
				$ret = array(0 => "pfail");
					echo json_encode($ret);
					exit;
				
			}
			
		}
                $course = isset($_POST['course']) ? $_POST['course'] : '';
				$id = isset($_POST['id']) ? $_POST['id'] : '';
				$title = isset($_POST['title']) ? $_POST['title'] : '';
				$content = isset($_POST['content']) ? $_POST['content'] : '';
				$name = isset($_POST['name']) ? $_POST['name'] : '';
				$active = isset($_POST['active']) ? $_POST['active'] : 'Yes';
				$frontpage = isset($_POST['frontpage']) ? $_POST['frontpage'] : 'No';
				$innerpage = isset($_POST['innerpage']) ? $_POST['innerpage'] : 'Yes';
				$photo = isset($_POST['photo']) ? $_POST['photo'] : '';
				$image = isset($_POST['image']) ? $_POST['image'] : '';
				$onlyimage = isset($_POST['onlyimg']) ? $_POST['onlyimg'] : '';
				$onlytext = isset($_POST['onlytxt']) ? $_POST['onlytxt'] : '';
				
				//if($newPhoto!="")  $newPhoto = $newPhoto; else $newPhoto = $photo;				
				//if($newImage!="")  $newImage = $newImage; else $newImage = $image;
				
			if($newPhoto!=""){
				if($photo!="") unlink('docs/testimonial/photo/'.$photo);
				//if($image!="") unlink('docs/testimonial/image/'.$image);
			}
				
			
			if($newPhoto!=""){
				$fullphtopath =$newPhoto; }
			else {
				$fullphtopath = $photo;}
				
			if($newImage!="") {
				$fullimgpath =$newImage; }
			else {
				$fullimgpath = $image;
			}
				
		
				//if($name=="" && $onlyimage=="Yes" && $onlytext=="No"){ $name = "Image";}
				//elseif($name=="" && $onlyimage=="No" && $onlytext=="Yes"){$name = "Text";}
				
			    $ret = $this->course_model->UpdateTestimonial($title, $content, $name,$active,$frontpage,$innerpage,$fullphtopath,$fullimgpath,$id,$course);
			    echo json_encode($ret);
				
            }else {
                //If no session, redirect to login page
                redirect('login', 'refresh');
            }
        
        
        }

}
?>
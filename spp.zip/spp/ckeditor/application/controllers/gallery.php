<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Gallery extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model('login_model','',TRUE);
                $this->load->model('album_model','',TRUE);
                 $this->load->library('table'); 

	}
	
	function index()
	{
		if($this->session->userdata('loggedin'))
   		{
                    $session_data = $this->session->userdata('loggedin');
                    $session_id = $session_data['id'];
                    $session_role = $session_data['role'];
                    $data['user'] = $this->login_model->GetUserId();		
		
				
                    $data['menu'] = $this->load->view('headermenu', $data, TRUE);
                    $data['allalbums'] = $this->album_model->GetAllAlbums();  
						
                    $this->load->view('header', $data);
                    $this->load->view('gallery_view', $data);
                    $this->load->view('footer');
		}
   		else
   		{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
   		}
		
	}
        
    public function createAlbum() {

        $session_data = $this->session->userdata('logged_in');
        $session_id = $session_data['id'];
        $session_role = $session_data['role'];
        $user_id = $this->login_model->GetUserId($session_id, $session_role);

        $albumname = isset($_GET['albumname']) ? $_GET['albumname'] : '';

        $ret = $this->album_model->CreateAlbum($albumname);
        echo json_encode($ret);
        }

}
?>

<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Dashboard extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model('login_model','',TRUE);
        $this->load->model('course_model','',TRUE);
        $this->load->library('table'); 

	}
	
	function index()
	{
		if($this->session->userdata('loggedin'))
   		{
                    $session_data = $this->session->userdata('loggedin');
                    $session_id = $session_data['id'];
                    $session_role = $session_data['role'];
                    $data['user'] = $this->login_model->GetUserId();		
		
				
                    $data['menu'] = $this->load->view('headermenu', $data, TRUE);
                    
                     $tmpl = array('table_open' => '<table class="sortable" id="coursetable" style="margin-top:40px;">');
                                $this->table->set_template($tmpl);
                                $this->table->set_heading('Name', 'Description', 'Visible', 'Image', 'Created on','');
						
                    $this->load->view('header', $data);
                    $this->load->view('dashboard_view', $data);
                    $this->load->view('footer');
		}
   		else
   		{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
   		}
		
	}
        
         public function getCourseLists() {
            
            if($this->session->userdata('loggedin')){
                
                $ret =  $this->course_model->GetAllCourses();
                echo $ret;
                
            }else{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
            }
            
        }
		
		
	public function delCourse() {
            
            if ($this->session->userdata('loggedin')) {

                $ide = isset($_GET['ide']) ? $_GET['ide'] : '';

                if($ide != ""){
                     $ret = $this->course_model->DeleteCourse($ide);
                } else {
                    $ret = array(0 => "fail");
                }

                echo json_encode($ret);
            
            }else {
                //If no session, redirect to login page
                redirect('login', 'refresh');
            }
                
        }
	
	
	
	
}
?>

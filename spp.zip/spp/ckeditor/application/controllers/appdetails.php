<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Appdetails extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model('login_model','',TRUE);
                $this->load->model('course_model','',TRUE);

	}
	
	function index()
	{
		if($this->session->userdata('loggedin'))
   		{
                    $ide = isset($_GET['id']) ? $_GET['id'] : '';
                    $session_data = $this->session->userdata('loggedin');
                    $session_id = $session_data['id'];
                    $session_role = $session_data['role'];
                    $data['user'] = $this->login_model->GetUserId();		
		
		    $data['detail'] = $this->course_model->ViewAppointments($ide);		
                    $data['menu'] = $this->load->view('headermenu', $data, TRUE);
          
						
                    $this->load->view('header', $data);
                    $this->load->view('appdetails_view', $data);
                    $this->load->view('footer');
		}
   		else
   		{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
   		}
		
	}
        
       	
	
	
}
?>

<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Editregistration extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model('course_model','',TRUE);
                $this->load->model('login_model','',TRUE);

	}
	
	function index()
	{
		if($this->session->userdata('loggedin'))
   		{
                    $ide = isset($_GET['id']) ? $_GET['id'] : '';
     		    $session_data = $this->session->userdata('loggedin');
		    $session_id = $session_data['id'];
     		    $session_role = $session_data['role'];
		    $data['user'] = $this->login_model->GetUserId();
                    $data['edit'] = $this->course_model->EditRegistration($ide);
				
                    $data['menu'] = $this->load->view('headermenu', $data, TRUE);
                    $this->load->view('header', $data);
                    $this->load->view('editregistration_view', $data);
                    $this->load->view('footer');
			
                }
   		else
   		{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
   		}
		
	}
        
         
        public function updateRegistration() {
            
            if ($this->session->userdata('loggedin')) {

             $course = isset($_GET['course']) ? $_GET['course'] : '';
            /*$seats = isset($_GET['seats']) ? $_GET['seats'] : '';
            $seatavail = isset($_GET['seatavail']) ? $_GET['seatavail'] : '';*/
            $date1 = isset($_GET['date1']) ? $_GET['date1'] : '';
            $date2 = isset($_GET['date2']) ? $_GET['date2'] : '';
            /*$date3 = isset($_GET['date3']) ? $_GET['date3'] : '';
            $date4 = isset($_GET['date4']) ? $_GET['date4'] : '';*/
            $active = isset($_GET['active']) ? $_GET['active'] : '';
            $frontpage = isset($_GET['frontpage']) ? $_GET['frontpage'] : '';
            /*$place1 = isset($_GET['place1']) ? $_GET['place1'] : '';
            $place2 = isset($_GET['place2']) ? $_GET['place2'] : '';*/
            $ide = isset($_GET['id']) ? $_GET['id'] : '';
            $batchno = isset($_GET['batchno']) ? $_GET['batchno'] : '';
				
            if($course != "" && $ide != "" ){
                 $ret = $this->course_model->UpdateRegistration($course, $date1,$active,$frontpage,$ide,$date2,$batchno);
            } else {
                $ret = array(0 => "fail");
            }

           
            echo json_encode($ret);
            
            }else {
                //If no session, redirect to login page
                redirect('login', 'refresh');
            }
        
        
        }
	
	
	
	
}
?>
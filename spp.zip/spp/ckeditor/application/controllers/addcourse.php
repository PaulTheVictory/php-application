<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Addcourse extends CI_Controller {

	function __construct() {
            
		parent::__construct();
		$this->load->model('course_model','',TRUE);
                $this->load->model('login_model','',TRUE);

	}
	
	function index() {
            
            if ($this->session->userdata('loggedin')) {

                $session_data = $this->session->userdata('loggedin');
                $session_id = $session_data['id'];
                $session_role = $session_data['role'];
                $data['user'] = $this->login_model->GetUserId();


                $data['menu'] = $this->load->view('headermenu', $data, TRUE);

                $this->load->view('header', $data);
                $this->load->view('addcourse_view', $data);
                $this->load->view('footer');
            } else {
                //If no session, redirect to login page
                redirect('login', 'refresh');
            }
            
        }
        
        public function insertCourse() {
			
            $fullimgpath='';
            if ($this->session->userdata('loggedin')) {
				
				
				$course = isset($_POST['course']) ? $_POST['course'] : '';
				$desc = isset($_POST['desc']) ? $_POST['desc'] : '';
				$duration = isset($_POST['duration']) ? $_POST['duration'] : '';
				$visible = isset($_POST['visible']) ? $_POST['visible'] : '';
				$link = isset($_POST['ulink']) ? $_POST['ulink'] : '';
				
				$uniqid = uniqid();
				
				if (isset($_FILES['fileToUpload']['name'])!="") {
					
				 $validExtensions = array('.jpg', '.jpeg', '.JPEG', '.png', '.JPG', '.PNG');
		         $fileExtension = strrchr($_FILES['fileToUpload']['name'], ".");
			
				
					
			if (in_array($fileExtension, $validExtensions)) {
				$newName = $uniqid."".$fileExtension;
				$thumbnewName = "thumb_".$uniqid."".$fileExtension;
    			$destination = 'docs/courses/'. $newName;
				$destinationthumb = 'docs/courses/'. $thumbnewName;
				$fullimgpath =base_url().'docs/courses/'.$newName;
				
					$width = 324;
					$height = 181;
					
					/* Get original image x y*/
					list($w, $h) = getimagesize($_FILES['fileToUpload']['tmp_name']);
					
					if($width>$w || $height>$h){
						$width = 324;
						$height = 181;
					}
					
  					/* calculate new image size with ratio */
  					$ratio = max($width/$w, $height/$h);
  					$h = ceil($height / $ratio);
  					$x = ($w - $width / $ratio) / 2;
  					$w = ceil($width / $ratio);
					
					
					$imgString = file_get_contents($_FILES['fileToUpload']['tmp_name']);
					
					$image = imagecreatefromstring($imgString);
  					$tmp = imagecreatetruecolor($w, $h);
  					imagecopyresampled($tmp, $image, 0, 0, 0, 0, $w, $h, $w, $h);
					
					$result = imagejpeg($tmp,$destination,100);
										
				if ($result) {
					
					if($course != "" && $desc != "" && $visible !="" && $newName !=""){
						 $ret = $this->course_model->AddCourse($course, $desc,$duration, $visible,$link,$fullimgpath);
					} else {
						$ret = array(0 => "fail");
					}

           
                    echo json_encode($ret);
					
					}
					else
					{
						$ret = array(0 => "fail");;
				        echo json_encode($ret);
				        exit;
					}
				
				//if(move_uploaded_file($_FILES['file']['tmp_name'], $destination)){
					//$ret = $this->academy_model->AddPhotoInAlbum($user_id,$albumid,$newName);
				//}
				
			}else
			{
				$ret = array(0 => "uerror");;
				echo json_encode($ret);
				exit;
			}
					
			}else
			{
				if($course != "" && $desc != "" && $visible !="" ){
					 $ret = $this->course_model->AddCourse($course, $desc,$duration, $visible,$link,'');
				} else {
					$ret = array(0 => "fail");
				}
				
				echo json_encode($ret);
			}
			
            
            }else {
                //If no session, redirect to login page
                redirect('login', 'refresh');
            }
        
        
        }

}
?>
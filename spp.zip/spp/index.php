

<?php 



/*Template Name: home*/



get_header(); ?>



<div id="flashcontainer">

    

     <div class="flexslider desktop"><ul class="slides"></ul></div>    

	 <div class="flexslider mobile"><ul class="slides"></ul></div> 

        

</div>


    <div class="wrap">

    <div id="homeboxes">
      

	<h2>Upcoming Hands-on Courses</h2>

        
        

    	<ul>

            <?php 
               
            $ret = Coursesgear::getInstance()->getUpcomingCourses();
            echo $ret;
            
            ?>
            
            <li>

            <div class="courseicon"></div>

            <div class="coursebox">

            <p>Fellowship Certificate In Endodontics</p>

            <!--<h4>3 Months</h4>--><h4>&nbsp;</h4><h5>Clinical Module on patients (Call for Details and Dates)</h5>

            <div class="slide-btn"><a href="<?php echo get_site_url();?>/international-fellowship/" title="Read More"><span>Read More</span></a></div>

            </div>

            </li>

             <li>

            <div class="courseicon"></div>

            <div class="coursebox">
                <div class="blink">New</div>
            <p >Dental photography</p>
            <h4>2 Days</h4><h5>June 18th & 19th</h5>
          

            <div class="slide-btn"><a href="https://www.accessrootcanal.com/wp-content/themes/accessdental/images/dental-photography-2022.pdf" title="Read More" target="_blank"><span>Read More</span></a></div>

           
            

            </div>

            </li>
            <li>

            <div class="courseicon"></div>

            <div class="coursebox">
                 <div class="blink">New</div>
                <p >Basic implantology</p>
            <h4>3 Days</h4><h5>July 22nd, 23rd & 24th</h5>
          

            <div class="slide-btn"><a href="https://www.accessrootcanal.com/wp-content/themes/accessdental/images/basic-implantology.pdf" title="Read More" target="_blank"><span>Read More</span></a></div>


            </div>

            </li>

            <!--<li> 

            <div class="adihygiene courseicon"></div>

            <div class="coursebox">

            <p>Rotary Endo with Post & Core – Hands-on Training Program</p>

            <h4>September</h4><h5>20, 21, 22 & 23 – 2018</h5>

            <div class="slide-btn"><a href="#" title="Read More"><span>Read More</span></a></div>

            </div>

            </li>

            

            <li>

            <div class="adidental courseicon"></div>

            <div class="coursebox">

            <p>Rotary Endo & Restorative - Clinical Module on patients </p>

            <h4>September</h4><h5>20, 21, 22 & 23 – 2018</h5>

            <div class="slide-btn"><a href="#" title="Read More"><span>Read More</span></a></div>

            </div>

            </li>

            

            <li>

            <div class="adidentist courseicon"></div>

            <div class="coursebox">

            <p>Advanced Micro-Endo</p>

            <h4>September</h4><h5>20, 21, 22 & 23 – 2018</h5>

            <div class="slide-btn"><a href="#" title="Read More"><span>Read More</span></a></div>

            </div>

            </li>

            

            <li>

            <div class="adidental-care courseicon"></div>

            <div class="coursebox">

            <p>Smile Designing With Veneers</p>

            <h4>September</h4><h5>20, 21, 22 & 23 – 2018</h5>

            <div class="slide-btn"><a href="#" title="Read More"><span>Read More</span></a></div>

            </div>

            </li>-->

            

        </ul> 

        

</div>


</div>


<div class="wrap shadow">


<div id="about-smile">

    
	<h1>Welcome to Access<span class="sub">&reg;</span> Dental Institute – Root Canal Center</h1>
  
	<h5>I am glad to introduce myself as Prof. Dr Narasimhan Bharadwaj MDS, FICOI (US), Founder-Director.</h5>
   
    <div class="about-content">

        
		<h2>DENTAL SERVICES</h2>    

        <p>With a perennial desire to deliver top quality dental care in par with global standards at an affordable cost, the Multi-Speciality Dental Clinic was established in the year 2001. Ever since, the clinic has constantly upgraded itself with contemporary state of the art infrastructure & technology to enhance the quality of Dental Care perpetually. The clinic has scaled to new heights towards painless, precision & perfection in the discipline of Microscopic Root Canal Treatment.</p>

		<h3>Clinical Mission</h3>
		
		<ul>
			<li>Towards excellence in SpecialIty Dental Care at an affordable cost.</li> 
			<li>To provide Highest Standards in Simple & Complex Root Canal Therapy enhanced by the use of Microscopes & Lasers.</li>
			<li>To design, sculpt & create Satisfied Smiles.</li> 
		</ul>
		
		 <div class="slide-btn"><a href="<?php echo get_site_url();?>/book-an-appointment" title="Book An Appointment"><span>Book An Appointment</span></a></div>


		<!--<p>At Access™ Dental &amp; Root Canal Center, RCT is done with the aid of <strong>ADVANCED AUTOMATED INSTRUMENTATION</strong> technology.</p>

		<ul>

             <li><a title="RCT at Access" href="<?php echo get_site_url();?>/rct-at-access-dental-root-canal-center">RCT at Access</a></li>
                                                                                 
             <li><a title="What is RCT?" href="<?php echo get_site_url();?>/what-is-root-canal-treatment-rct">What is RCT?</a></li>
                                                                                
             <li><a title="RCT Faqs" href="<?php echo get_site_url();?>/common-queries-on-rct">RCT Faqs</a></li>
             
             <li><a title="Instructions during RCT" href="<?php echo get_site_url();?>/instructions-during-root-canal-treatment">Instructions during RCT</a></li>

		</ul>-->

        

    </div>

    

    <div class="about-right">

   
		<h2>DENTAL COURSES</h2>
   
   
    	<p>With the primary intention to disseminate knowledge in the field of Endodontics, Hands-on training modules were started at the center in the year 2012.  The Hands-on Training center is equipped with a Lecture Hall, state of the art Phantom Head Mannequins & Microscopes with 24 independent Work Stations. Further, with the core objective to reach affordable dental care to the underprivileged and simultaneous clinical training to Dentists, the Community Dental Clinic – Charitable Trust (Unit of Access Dental Institute) was initiated in the year 2014 to enhance clinical skills of practicing dentists and raise the bar of Endodontic Practice.</p>


		<h3>Course Objectives</h3>
		
		<ul>
			<li>To update knowledge & skill in Rotary Endodontics from the Clinical perspective.</li> 
			<li>To enhance Endodontic skills with Microscopes and Advanced techniques.</li> 
			<li>To refine Clinical working on patients by imparting clinical acumen.</li>
		</ul>
    
     <div class="slide-btn"><a href="<?php echo get_site_url();?>/registration" title="Register Now"><span>Register Now</span></a></div>

    <!--<div class="contactinfo">

    

    <h2>Contact Details</h2>

    

    <hr>

    

		<div class="conrow"><span><div class="adiphone"></div> Contact</span> <span>:</span> <span>044-26451121 (9:30 am - 3:00 pm), 

                 044-49592349 (4:00 pm - 8:00 pm)</span></div>

      

       <div class="conrow"><span><div class="adismartphone"></div> Cell</span><span>:</span> <span>97905 39344</span></div>

       

       <div class="conrow"><span><div class="adiemail"></div> E-mail</span><span>:</span> <span>accessrootcanal@gmail.com</span></div>

       

		<div class="socialrow">
		   <a href="https://www.facebook.com/rootcanalcenter" rel="nofollow" title="Facebook" ><span><div class="adifacebook"></div> Facebook</span></a>
			<a href="#" rel="nofollow" title="Twitter" ><span><div class="aditwitter"></div> Twitter</span></a>
			<a href="#" rel="nofollow" title="Google Plus" ><span><div class="adigoogle-plus"></div> Google Plus</span></a>
       </div>

       

       <div class="slide-btn"><a href="<?php //echo get_site_url();?>/contact-us" title="Request Call Now"><span>REQUEST CALL UPON</span></a></div>

        

     </div>-->

        

    </div>

    	

    

</div>



<div class="row testimonialrow">

   

    

		<div class="col-2 leftbox">

			    

			    <div class="testicol">
			    
			    <h2>Patient Testimonials</h2>

        

        <h3>from Google Review</h3>

   	
   		<div class="testimonials">
        

        <div class="testi-box">

        	<img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/testimonials/vijayakumar.jpg" alt="Vijayakumar Govindan" />

        	<div class="adiquotetp"></div>

        	<p>Excellent service and we got a very good knowledge about our dental care.</p>

            <div class="adiquotebt"></div>

            <h4>- Vijayakumar Govindan</h4>

            <!--<h5>CEO, Dentistry planet</h5>-->
        
        </div>

        
        <div class="testi-box">

        	<img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/testimonials/periyanayaki.jpg" alt="Periyanayaki Khallapiran" />

        	<div class="adiquotetp"></div>

        	<p>Very pleasing and helpful staff,good service and happy coustomers</p>

            <div class="adiquotebt"></div>

            <h4>- Periyanayaki Khallapiran</h4>


        </div>


        <div class="testi-box">

        	<img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/testimonials/faiza-khanam.jpg" alt="Faiza Khanam" />

        	<div class="adiquotetp"></div>

        	<p>Very experienced doctor truly professional.highly recommended</p>

            <div class="adiquotebt"></div>

            <h4>- Faiza Khanam</h4>


        </div>
        
        <div class="testi-box">

        	<img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/testimonials/narayana.jpg" alt="Narayana Balasubramaniam" />

        	<div class="adiquotetp"></div>

        	<p>Love to visit this hospital as perfection in execution and excellent hospitality.</p>

            <div class="adiquotebt"></div>

            <h4>- Narayana Balasubramaniam</h4>


        </div>
        
        <div class="testi-box">

        	<img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/testimonials/ayush-jain.jpg" alt="Ayush Jain" />

        	<div class="adiquotetp"></div>

        	<p>The Clinic seems to have well trained and educated Doctors and Nurses. The staff sounds quite good. </p>

            <div class="adiquotebt"></div>

            <h4>- Ayush Jain</h4>


        </div>
        
        <div class="testi-box">

        	<img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/testimonials/sidsy-daga.jpg" alt="Sidsy Daga
" />

        	<div class="adiquotetp"></div>

        	<p>Very nice ambience with courteous people around. Impressed with their latest and sophisticated equipment</p>

            <div class="adiquotebt"></div>

            <h4>- Sidsy Daga</h4>


        </div>



        </div>
        
        <div class="slide-btn"><a href="https://www.google.co.in/search?q=access+root+canal&rlz=1C1GGRV_enIN819IN819&oq=access+root+canal+&aqs=chrome..69i57j69i60l3j0l2.4224j0j7&sourceid=chrome&ie=UTF-8#lrd=0x3a5265d56078dbef:0x20b3ecf93a43c551,1,,," target="_blank" rel="nofollow" title="More Reviews"><span>More Reviews</span></a></div> 
        
	   </div>

				    

		</div>

		

   

   <div class="col-2 rightbox">
   
   <div class="testicol">



    	<h2>Course Participant Testimonials</h2>

        
        <!--<h3>Hear what our former patients say about compassionate services offered in Access Smile Institute.</h3>-->
        

        <div class="testimonials">

        
        
        <?php 
               
            $ret = Coursesgear::getInstance()->Gettestimonial(esc_url( get_template_directory_uri() ));
            echo $ret;
            
            ?>
            

        <!--<div class="testi-box">

        	<img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/testimonials/testi-default.png" alt="Dr Gowthami" />

        	<div class="adiquotetp"></div>

        	<p>The course was very useful ; The lectures were clear & precise with clinical relevance. Could be better if break timing is increased…</p>

            <div class="adiquotebt"></div>

            <h4>- Dr Gowthami</h4>

            <h5>+91 9840864949 (Chennai)</h5>
        
        </div>

        
        <div class="testi-box">

        	<img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/testimonials/testi-default.png" alt="Dr Thara" />

        	<div class="adiquotetp"></div>

        	<p>Got a very clear idea of RCT procedure ; Excellent overall experience. LIVE RCT on patient was very clear with clear demo</p>

            <div class="adiquotebt"></div>

            <h4>- Dr Thara</h4>
            <h5>+91 9566240656 (Chennai)</h5>


        </div>


        <div class="testi-box">

        	<img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/testimonials/testi-default.png" alt="Dr R Manoshree" />

        	<div class="adiquotetp"></div>

        	<p>The course experience was great and feeling updated. Was able to adapt to Indirect Vision Exercises</p>

            <div class="adiquotebt"></div>

            <h4>- Dr R Manoshree</h4>
            <h5>+91 9710397061 (Guduvancheri)</h5>


        </div>
        
        <div class="testi-box">

        	<img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/testimonials/testi-default.png" alt="Dr Arya AN" />

        	<div class="adiquotetp"></div>

        	<p>It was an awesome experience ; very precise & apt module ; Demonstrations were clear, some more Rotary Systems can be introduced also</p>

            <div class="adiquotebt"></div>

            <h4>- Dr Arya AN</h4>
            <h5>+91 9731360639 (Krishnagiri) </h5>


        </div>
        
        <div class="testi-box">

        	<img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/testimonials/testi-default.png" alt="Dr Shankar D" />

        	<div class="adiquotetp"></div>

        	<p>The module is very informative and clinically oriented ; Ive learnt a lot from this module. LIVE RCT on patient was very clear</p>

            <div class="adiquotebt"></div>

            <h4>- Dr Shankar D</h4>
			<h5>+91 9842577423 (Salem)</h5>


        </div>
        
        <div class="testi-box">

        	<img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/testimonials/testi-default.png" alt="Dr Hussain" />

        	<div class="adiquotetp"></div>

        	<p>Yes, I really feel the course is fully worth it ; Hands-on exercises were adequate and Lectures were clinically relevant</p>

            <div class="adiquotebt"></div>

            <h4>- Dr Hussain</h4>
			<h5>+91 9207868708 (Kerala) </h5>


        </div>
-->

        

        </div>

            <div class="slide-btn"><a href="<?php echo get_site_url();?>/testimonials" title="More Reviews"><span>More Reviews</span></a></div> 	

		</div>

  

    </div>


</div>



<!--<div id="treatment">

             

	<h2>Treatment Options</h2>

       

		   <h5>Access Dental Institute is the epicentre of dentistry courses and dental wellness. Our Dental Health Specialists take care of the dental health well-being with our treatments which include diagnostic and preventive. We maintain a soothing ambience coupled with advancements in Dentistry with the intent of providing premium quality dental treatments that match the international standards. Ours is a multispecialty clinic offers a wide range of oral care services that cater to the dental needs of the patients and deliver them a pain-free smile.</h5>

        

    	<ul>

            

            <li> 

            <div class="adidental-drill courseicon"></div>

            <div class="coursebox">

				<h3>Root Canal</h3>

            <p>Tooth repairing procedure which involves cleaning root canals by extracting infected pulp inside a diseased tooth.</p>

            <div class="slide-btn"><a href="<?php echo get_site_url();?>/rct-at-access-dental-root-canal-center/" title="Read More"><span>Read More</span></a></div>

            </div>

            </li>

            

            <li>

            <div class="aditooth courseicon"></div>

            <div class="coursebox">

            <h3>White Teeth</h3>

            <p>Cosmetic dental procedure to refresh one's smile by restoring the natural color of a tooth.</p>

            <div class="slide-btn"><a href="<?php echo get_site_url();?>/laser-teeth-whitening-power-bleaching/" title="Read More"><span>Read More</span></a></div>

            </div>

            </li>

            

            <li>

            <div class="adiimplants courseicon"></div>

            <div class="coursebox">

            <h3>Dental Implant</h3>

            <p>The surgical procedure to replace tooth root with metallic posts inserted into the jawbone.</p>

            <div class="slide-btn"><a href="<?php echo get_site_url();?>/dental-implants/" title="Read More"><span>Read More</span></a></div>

            </div>

            </li>

            

            <li>

            <div class="adibrackets courseicon"></div>

            <div class="coursebox">

            <h3>Teeth Braces</h3>

            <p>Custom-made orthodontic appliances to acquire an even bite by aligning the crooked teeth and jaws.</p>

            <div class="slide-btn"><a href="<?php echo get_site_url();?>/teeth-alignment/" title="Read More"><span>Read More</span></a></div>

            </div>

            </li>

            

                    

            <li> 

            <div class="adilaser courseicon"></div>

            <div class="coursebox">

				<h3>Laser Dentistry</h3>

            <p>Application of laser energy which appears as focused light beams to treat oral aggravations.</p>

            <div class="slide-btn"><a href="<?php echo get_site_url();?>/laser-teeth-whitening-power-bleaching/" title="Read More"><span>Read More</span></a></div>

            </div>

            </li>

            

            <li>

            <div class="adihuman-teeth courseicon"></div>

            <div class="coursebox">

            <h3>Smile Care</h3>

            <p>The array of super specialized dental activities to restore teeth appearance and smile aesthetics.</p>

            <div class="slide-btn"><a href="#" title="Read More"><span>Read More</span></a></div>

            </div>

            </li>

            

            <li>

            <div class="adibraces courseicon"></div>

            <div class="coursebox">

            <h3>Maxilofacial Surgery</h3>

            <p>Orthognathic surgical procedure to correct jaw bone deformities and treat other facial bone pathologies.</p>

            <div class="slide-btn"><a href="#" title="Read More"><span>Read More</span></a></div>

            </div>

            </li>

            

            <li>

            <div class="adimolar-with-caries courseicon"></div>

            <div class="coursebox">

            <h3>General Dentistry</h3>

            <p>A multitude of dental care procedures to diagnose, treat and prevent dental disorders.</p>

            <div class="slide-btn"><a href="#" title="Read More"><span>Read More</span></a></div>

            </div>

            </li>

                   

        </ul> 



                            

</div>-->



<div id="our-team">

    

    	<h2>Satisfied Smiles</h2>

        <h5>Below are some of the treated smiles, restored teeth and corrected dentition in our Access Dental Institute.</h5>

                

        <div class="teamblock">

        

        <div class="teambox">

			<a href="<?php echo esc_url( get_template_directory_uri() ); ?>/images/gallery/main/case-1.jpg" onclick="return hs.expand(this)">

				<img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/gallery/thumb/case-1.jpg" alt="Smile Gallery"/>

                <div class="highslide-caption">Replacement of old black fillings with new tooth coloured fillings</div>

        		<div id="closebutton" class="highslide-overlay closebutton" onclick="return hs.close(this)" title="Close"></div>

				<div class="caption"><div class="caption-text"></div></div>

            </a>

			</div>

           

             <div class="teambox">  

            <a href="<?php echo esc_url( get_template_directory_uri() ); ?>/images/gallery/main/case-2.jpg" onclick="return hs.expand(this)">

				<img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/gallery/thumb/case-2.jpg" alt="Smile Gallery"/>

                <div class="highslide-caption">Replacement of old black fillings with new tooth coloured fillings</div>

        		<div id="closebutton" class="highslide-overlay closebutton" onclick="return hs.close(this)" title="Close"></div>

				<div class="caption"><div class="caption-text"></div></div>

            </a>

			</div>

           

           <div class="teambox">

            <a href="<?php echo esc_url( get_template_directory_uri() ); ?>/images/gallery/main/case-3.jpg" onclick="return hs.expand(this)">

				<img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/gallery/thumb/case-3.jpg" alt="Smile Gallery"/>

                <div class="highslide-caption">Replacement of old black fillings with new tooth coloured fillings</div>

        		<div id="closebutton" class="highslide-overlay closebutton" onclick="return hs.close(this)" title="Close"></div>

				<div class="caption"><div class="caption-text"></div></div>

			</a>

			</div>

      

      <div class="teambox">

            <a href="<?php echo esc_url( get_template_directory_uri() ); ?>/images/gallery/main/case-4.jpg" onclick="return hs.expand(this)">

				<img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/gallery/thumb/case-4.jpg" alt="Smile Gallery"/>

                <div class="highslide-caption">Replacement of old black fillings with new tooth coloured fillings</div>

        		<div id="closebutton" class="highslide-overlay closebutton" onclick="return hs.close(this)" title="Close"></div>

				<div class="caption"><div class="caption-text"></div></div>

			</a>

			</div>

      

      <div class="teambox">

            <a href="<?php echo esc_url( get_template_directory_uri() ); ?>/images/gallery/main/case-5.jpg" onclick="return hs.expand(this)">

				<img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/gallery/thumb/case-5.jpg" alt="Smile Gallery"/>

                <div class="highslide-caption">Replacement of old black fillings with new tooth coloured fillings</div>

        		<div id="closebutton" class="highslide-overlay closebutton" onclick="return hs.close(this)" title="Close"></div>

				<div class="caption"><div class="caption-text"></div></div>

			</a>

			</div>

      

      <div class="teambox">

            <a href="<?php echo esc_url( get_template_directory_uri() ); ?>/images/gallery/main/case-6.jpg" onclick="return hs.expand(this)">

				<img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/gallery/thumb/case-6.jpg" alt="Smile Gallery"/>

                <div class="highslide-caption">Replacement of old black fillings with new tooth coloured fillings</div>

        		<div id="closebutton" class="highslide-overlay closebutton" onclick="return hs.close(this)" title="Close"></div>

				<div class="caption"><div class="caption-text"></div></div>

			</a>

			</div>

       

        </div>

        

        <div class="slide-btn"><a href="<?php echo get_site_url();?>/our-works" title="See More of Works"><span>See More</span></a></div>

                                

</div>
	



	</div>

	

<div class="row gallery">

   
<div class="wrap">
  
   <div class="col-1">

    

    	<!--<div class="testicol">-->

        
        <div id="ourgallery">

    

    		<h2>Our Gallery</h2>

    		

			<h5>With the intention of helping young aspiring dentists to get mastered in Dentistry, we provide a platform for the young minds to learn and grow in Dental Health Sciences. Here are some of the illustrations of our coaching and hands-on exercises.</h5>

			

			<div class="ourgallery">

        
         		<?php 	
				
					$ret = Coursesgear::getInstance()->getGalleryList();
					echo $ret;
				
				?>

        </div>	

			<div class="slide-btn"><a href="<?php echo get_site_url();?>/gallery" title="See More of Works"><span>See More</span></a></div>
   	 
    	 </div>

		
		

		<!--</div>-->

                   	

		</div>

           </div>         	    

</div>

	

	<script>

	

(function($){

	

	var namespace = {

		

    /**

     * Slideshow initialization

     */

    slideshow_init: function(){

      $('.flexslider').flexslider({

		animation: 'slide',

		animationLoop: true,

		slideshowSpeed: 5000,

		animationSpeed: 2000,

		pauseOnHover: false,

		controlNav:false,

		directionNav:false

	 });

    },

    /**

     * Set Slideshow image size

     */

    set_desk_slides: function(slides){

		

		

        /* Replace slides */

        $('.desktop ul.slides').html( slides );

        /**

         * If the slideshow had been previously initialized,

         * we need to remove the data and nav, then reinitialize

         */

        if( $.hasData( $('.flexslider')[0] ) ){

          $.removeData( $('.flexslider')[0] );

          $('.flex-control-nav').remove();

          funcs.slideshow_init();

        }

    },

		set_mobile_slides: function(slides){

		

		

        /* Replace slides */

        $('.mobile ul.slides').html( slides );

        /**

         * If the slideshow had been previously initialized,

         * we need to remove the data and nav, then reinitialize

         */

        if( $.hasData( $('.flexslider')[0] ) ){

          $.removeData( $('.flexslider')[0] );

          $('.flex-control-nav').remove();

          funcs.slideshow_init();

        }

    }

	

  };

  window.funcs = namespace;

})(this.jQuery);

	

	   var slides = 

          '<li><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/banner1.jpg" alt=""/><div class="meta"><h2><span>Welcome to the hub of Dental Experts</span></h2><div class="category"><p>The multi-specialty dental clinic delivers professional efforts with personalized attention to create, enhance, protect and maintain aesthetic smiles.</p></div><div class="slide-btn"><a href="<?php echo get_site_url();?>/virtual-tour" title="Know More"><span>Know More</span></a></div> </div> </li>' +

          ' <li><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/banner5.jpg" alt=""/><div class="meta"><h2><span>Micro Root Canal Treatment</span></h2><div class="category"><p>The endodontic procedure enhanced with microscope to diagnose and remove the diseased tissues in hidden canals or infections at the end of the tooth root.</p></div><div class="slide-btn"><a href="<?php echo get_site_url();?>/rct-at-access-dental-root-canal-center" title="Know More"><span>Know More</span></a></div></div></li>' +

          '<li><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/banner3.jpg" alt=""/><div class="meta"><h2><span>Comprehensive Dental Education Programs</span></h2><div class="category"><p>A short-term advanced dental course with Hands-on Training Programs which hone the Professional Skills and Principles of the aspiring Dentists.</p></div> <div class="slide-btn"><a href="<?php echo get_site_url();?>/rotary-endo-post-endo-hands-on-training-program" title="Know More"><span>Know More</span></a></div> </div></li>' +

          '<li><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/banner4.jpg" alt=""/><div class="meta"><h2><span>Clinical Modules</span></h2><div class="category"><p>Intensive Clinical Modules on Patients to refine clinical working skills and raise the bar of dental practice.</p></div> <div class="slide-btn"><a href="<?php echo get_site_url();?>/rotary-endo-post-endo-restorative-clinical-module-on-patients" title="Know More"><span>Know More</span></a></div> </div></li>' +
		   
		  '<li><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/banner6.jpg" alt=""/><div class="meta"><h2><span>Microscopic Training</span></h2><div class="category"><p>To impart microscope enhanced training for general and specialty clinical work.</p></div> <div class="slide-btn"><a href="<?php echo get_site_url();?>/advanced-micro-endodontics-hands-on-training-program" title="Know More"><span>Know More</span></a></div> </div></li>' +
		   
		  '<li><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/banner2.jpg" alt=""/><div class="meta"><h2><span>Hi-Tech Dentistry in a friendly environment</span></h2><div class="category"><p>The one Stop Speciality Dental Clinic is accommodated with an aesthetically beautiful environment and shielded with sterilization protocols.</p></div> <div class="slide-btn"><a href="<?php echo get_site_url();?>/dr-narasimhan-bharadwaj-mds" title="Know More"><span>Know More</span></a></div> </div></li>';

		

		 var slidesmobile = 

          '<li><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/banner1.jpg" alt=""/><div class="meta"><h2><span>Welcome to the hub of Dental Experts</span></h2>><div class="slide-btn"><a href="<?php echo get_site_url();?>/virtual-tour" title="Know More"><span>Know More</span></a></div> </div> </li>' +

          ' <li><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/banner5.jpg" alt=""/><div class="meta"><h2><span>Micro Root Canal Treatment</span></h2><div class="slide-btn"><a href="<?php echo get_site_url();?>/rct-at-access-dental-root-canal-center" title="Know More"><span>Know More</span></a></div></div></li>' +

          '<li><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/banner3.jpg" alt=""/><div class="meta"><h2><span>Comprehensive Dental Education Programs</span></h2><div class="slide-btn"><a href="<?php echo get_site_url();?>/rotary-endo-post-endo-hands-on-training-program" title="Know More"><span>Know More</span></a></div> </div></li>' +

          '<li><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/banner4.jpg" alt=""/><div class="meta"><h2><span>Clinical Modules</span></h2><div class="slide-btn"><a href="<?php echo get_site_url();?>/rotary-endo-post-endo-restorative-clinical-module-on-patients" title="Know More"><span>Know More</span></a></div> </div></li>' +
			 
		  '<li><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/banner6.jpg" alt=""/><div class="meta"><h2><span>Microscopic Training</span></h2><div class="slide-btn"><a href="<?php echo get_site_url();?>/advanced-micro-endodontics-hands-on-training-program" title="Know More"><span>Know More Courses</span></a></div> </div></li>'+
			 
		   '<li><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/banner2.jpg" alt=""/><div class="meta"><h2><span>Hi-Tech Dentistry in a friendly environment</span></h2><div class="slide-btn"><a href="<?php echo get_site_url();?>/dr-narasimhan-bharadwaj-mds" title="Know More"><span>Know More</span></a></div> </div></li>';



 

// Document Ready Function

$(document).ready(function(){

 

  /* Initialize slideshow */

	

	funcs.set_desk_slides(slides);

	funcs.set_mobile_slides(slidesmobile);

	  funcs.slideshow_init();



var ww = $(window).width();

if(ww<768){$(".desktop").hide();$(".mobile").show();}else{$(".desktop").show();$(".mobile").hide();}



$(window).resize(function(){



var ww = $(window).width();

if(ww<768){$(".desktop").hide();$(".mobile").show();}else{$(".desktop").show();$(".mobile").hide();}



});

 

});

</script>



<?php get_footer(); ?>      



</body>

</html>


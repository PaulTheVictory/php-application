<?php



class Coursesgear {

    private static $_instance;

        

    /**

     * Constructor for DbConnect Class

     *

     */

    private function __construct()

    {

		global $con,$base_url;
		
		global $base_url;

		// $base_url = "https://www.accessrootcanal.com/";
		
  //       $DBSERVER = 'localhost';

  //       $DBUSER = 'accessro_adi2018';

  //       $DBPASSWORD = 'Du,A{ww}GL3f';

  //       $DBNAME = 'accessro_accessdental';

		
		$base_url = "http://localhost/accessrootcanal.com/";
		
		$DBSERVER = 'localhost';

        $DBUSER = 'root';

        $DBPASSWORD = '';

        $DBNAME = 'accessro_accessdental';

		

        $con=mysqli_connect($DBSERVER, $DBUSER, $DBPASSWORD,$DBNAME);

		

    }

    

        /**

     * The function assists in ensuring the singleton pattern

     *

     * @return object

     */

    public static function getInstance()

    {

        if (!isset(self::$_instance)) {

            $currentClass=__CLASS__;

            self::$_instance=new $currentClass;

        }

        return self::$_instance;

    }

			

		

public function GetAllCourses(){

            

			global $con,$base_url;

            $finalret = "";

			$ret = "";

			$count = 0;

                

            $query = mysqli_query($con,'SELECT * FROM (`sag_courses`) where visible="Yes" order by created_time');

		if($query) {

                    

			while($row = mysqli_fetch_assoc($query)) {

                            
				$duration = $row['duration'];
				$durationarr = explode('|',$duration);

                             $ret .= ' <li> 
            <div class="coursebox">
            <h3>'.$row['course_name'].'</h3>
            <h4>'.$durationarr[0].'</h4><h5>'.$durationarr[1].'</h5>
			<p>'.$row['description'].'</p>
            <div class="slide-btn"><a href="'.$base_url.$row['link'].'" title="'.$row['course_name'].'"><span>Learn More</span></a></div></div>
            </li>';

					/*++$count;

					

				 if($count == 3){

                                $finalret .= '<div class="courses_content">'.$ret.'</div>';

                                $ret = "";

                                $count = 0;

                            }*/

			 

			}

                        

                      /*  if(mysqli_num_rows ( $query ) % 3 ) {

                            $finalret .= '<div class="courses_content">'.$ret.'</div>';

                        }*/

                

            }

            

            return $ret;

            

        }


	public function GetAllCoursesReg(){

            

		global $con,$base_url;

		$finalret = "";

		$ret = array();

		$count = 0;



		$query = mysqli_query($con,'SELECT sag_registration.courseid,course_name,image,link,date1,date2,date,duration FROM (`sag_registration`) INNER JOIN `sag_courses` ON sag_courses.id=sag_registration.courseid where TO_DAYS(date) >= TO_DAYS(NOW()) and frontpage="Yes" and active ="Yes" ORDER BY `date` asc');

		if($query) {

                    

			while($row = mysqli_fetch_assoc($query)) {

                $course_name = $row['course_name'];        
				$duration = $row['duration'];
				$durationarr = explode('|',$duration);

                             $ret [] = $course_name." (".$durationarr[0].")";


			}


            }

		
		$ret [] = 'Rotary Endo, Post Core & Crown – Clinical Module on patients (3 Months)';
            

            return $ret;

            

    }
		

	public function getUpcomingCourses() {

		

		global $con,$base_url;


		$finalret = "";

        $ret = "";

        $count = 0;

		$alt='';


		$query = mysqli_query($con,'SELECT sag_registration.courseid,course_name,image,link,date1,date2,date,duration FROM (`sag_registration`)

                                      INNER JOIN `sag_courses` ON sag_courses.id=sag_registration.courseid where TO_DAYS(date) >= TO_DAYS(NOW()) and frontpage="Yes" and active ="Yes" ORDER BY `date` asc limit 4');

		if($query) {

                 $rcount =  mysqli_num_rows ( $query );
			$i=0;
			while($row = mysqli_fetch_assoc($query)) {

                   					         
					$i++;
                $cdate = $this->courseDateFormat($row['date1'],$row['date2']);
				$course_name = $row['course_name'];
				$duration = $row['duration'];
				$durationarr = explode('|',$duration);
				
				$border = "";
				//if($i==$rcount){$border = 'style="border-right: 0px solid #ffffff;"';}
                            $ret .= '<li '.$border.'> 
                            
            <div class="courseicon"></div>

            <div class="coursebox">

            <p>'.ucwords($course_name).'</p>

            <h4>'.$durationarr[0].'</h4><h5>'.$cdate.'</h5>

            <div class="slide-btn"><a href="'.$base_url.$row['link'].'" title="'.ucwords($course_name).'"><span>Read More</span></a></div>

            </div>

            </li>
			
			';

                            /*++$count;

                              

                           if($count == 5){

                                $finalret .= '<div class="courses_content">'.$ret.'</div>';

                                $ret = "";

                                $count = 0;

                            }*/

			 

			}

                        

                        /*if(mysqli_num_rows ( $query ) % 5 ) {

                            $finalret .= '<div class="courses_content">'.$ret.'</div>';

                        }*/

                        

		}

		

		return $ret;

		

	}

        

        public function courseDateFormat($date1,$date2){

            
			
			// Start date
				 $date = date('Y-m-d',strtotime($date1));
				 // End date
				 $end_date = date('Y-m-d',strtotime($date2));
				 $array_final = array();
				 $array  = array();
				 $i=1;
				$daterange = '';
				$chmonth = false;
				$diff = strtotime($date2) - strtotime($date1); 
				$dateDiff = abs(round($diff / 86400)) + 1;
			
				$montharr = array();
			
				 while (strtotime($date) <= strtotime($end_date)) {
					 
					 	$day = date ("d", strtotime($date));
					 	$month = date('F', strtotime($date));
					 	$monthshort = date('M', strtotime($date));
					 	$year = date('Y', strtotime($date));
					 
					 	if(!in_array($month,$montharr))$montharr[] = $month;
					 
					 	if($i==$dateDiff){
							$daterange = rtrim($daterange,', ');
							if(count($montharr)>1 && !$chmonth){
								$daterange .= " & ".$monthshort." ".$day." - ".$year;
							}
							else{ 
								if($dateDiff>1) $and = " & "; else $and = $month." ";
								$daterange .= $and.$day." - ".$year;}
						}
					 else{
						 if($i==1)$daterange .= $month." ".$day.", ";
						 else {
							 if(count($montharr)>1 && !$chmonth){$daterange .= $monthshort." ".$day.", ";$chmonth = true;}
							 else $daterange .= $day.", ";
						 }
						}
					 
					 
					 
					$date = date ("Y-m-d", strtotime("+1 day", strtotime($date)));
					$i++;
				}
				//print_r($array_final);
			

           /* $month = date('M', strtotime($date1));

            $day1 = date('d', strtotime($date1));*/



           /* if ($date2 != "") {

                $day1 .= ", ";

                $day2 = date('d', strtotime($date2));

            } else {

                $day2 = "";

            }



            if ($date3 != "") {

                $day2 .= ", ";

                $day3 = date('d', strtotime($date3));

            } else {

                $day3 = "";

            }



            if ($date4 != "") {

                $day3 .= ", ";

                $day4 = date('d', strtotime($date4));

            } else {

                $day4 = "";

            }*/



            //$year = date('Y', strtotime($date1));

            /*$formatteddate = $day1 . " " . $month . $day2 . $day3 . $day4 . " " . $year;*/

            
			$formatteddate = $daterange;

            return $formatteddate;

        }

    
	public function GetCourseDate($id) {

		global $con,$base_url;
		
        $ret = "";

		$query = mysqli_query($con,'SELECT courseid,date1,date2,date,batchno FROM (`sag_registration`) where courseid="'.$id.'"');

		if($query) {

             $rcount =  mysqli_num_rows ( $query );
			while($row = mysqli_fetch_assoc($query)) {
                   					         
                $cdate = $this->courseDateFormat($row['date1'],$row['date2']);
				//$course_name = $row['course_name'];
				//$duration = $row['duration'];
				//$durationarr = explode('|',$duration);
				
                    if($row['batchno']!=0) $batchno = '(Batch '.$row['batchno'].') -';	else $batchno = "";		
				
				
                     $ret = '<em style="color: #f00; font-size: 18px;"> '.$batchno.' '.$cdate.'</em>';

			}

                                               

		}

		

		return $ret;

		

	}

	

	public function getGalleryList() {



        global $con,$base_url;

		

		$ret = "";

		$count = 0;

		$finalret = "";

		$a=1;

		

		

		

		$query = mysqli_query($con,'select albumid,albumname,image,courseid from sag_albums where image <>"" group by albumid  order by CAST(SUBSTRING_INDEX(SUBSTRING_INDEX(albumname," ",2)," ",-1) AS unsigned) desc limit 8');      
                

            while ($row = mysqli_fetch_assoc($query)) {



                $albumid = $row['albumid'];
				$albname = $row['albumname'];
				$courseid = $row['courseid'];

                $albumname = explode('-',$row['albumname']);

				

				$image_files=$row['image'];

							

					

                if ($image_files!='') {

                    $thumbimg = $image_files;

                }

				else

				{

					$thumbimg = $base_url."admin/docs/albums/ap.jpg";				

				}             								

				$query1 = mysqli_query($con,'select course_name from sag_courses where id ="'.$courseid.'"');      
				$row1 = mysqli_fetch_assoc($query1);
				
				$coursename = $row1['course_name']." - ".$albname;

				if(!isset($albumname[1])) {$albumname = $albumname[0];}

				//else if(strlen($albumname[0]) > strlen($albumname[1]))  $albumname = $albumname[1];

				else{ $albumname = $albumname[1];}

			

			$ret.='<div class="og-box"><a href="view-gallery?aid='.$albumid.'" title="'.$coursename.'"><img src="'.$thumbimg.'" alt="'.$coursename.'" width="267" height="auto" /><h3>'.$albname.'</h3></a></div>';
				
				/*$ret.='<div class="og-box"><a href="view-gallery?aid='.$albumid.'"><img src="'.$thumbimg.'" alt="'.$albname.'" width="267" height="auto" /><h3>'.$albname.'</h3></a></div>';
				
				$ret.='<div class="og-box"><a href="view-gallery?aid='.$albumid.'"><img src="'.$thumbimg.'" alt="'.$albname.'" width="267" height="auto" /><h3>'.$albname.'</h3></a></div>';
				$ret.='<div class="og-box"><a href="view-gallery?aid='.$albumid.'"><img src="'.$thumbimg.'" alt="'.$albname.'" width="267" height="auto" /><h3>'.$albname.'</h3></a></div>';
				$ret.='<div class="og-box"><a href="view-gallery?aid='.$albumid.'"><img src="'.$thumbimg.'" alt="'.$albname.'" width="267" height="auto" /><h3>'.$albname.'</h3></a></div>';
				$ret.='<div class="og-box"><a href="view-gallery?aid='.$albumid.'"><img src="'.$thumbimg.'" alt="'.$albname.'" width="267" height="auto" /><h3>'.$albname.'</h3></a></div>';*/

						

				   ++$count;     

				

				 

                           /*if($count == 3){

                               $finalret .=  '<div>'.$ret.'</div>';

                                $ret = "";

                                $count = 0; 

                            }*/



			   

            }

			

			/*if(mysqli_num_rows ( $query ) % 3 ) {

				   

                               $finalret .= '<div>'.$ret.'</div>';				

			}
*/
        

        return $ret;	

	}

	

	

	public function getInnerGalleryList($courseid) {


        global $con,$base_url;


		$ret = "";

		$count = 0;

		$finalret = "";


		$query = mysqli_query($con,'select albumid,albumname,thump from sag_albums where image <>"" and courseid="'.$courseid.'" group by albumid');      



                

            while ($row = mysqli_fetch_assoc($query)) {



                $albumid = $row['albumid'];
				$albname = $row['albumname'];

                $albumname = explode('-',$row['albumname']);

				

				$image_files=$row['thump'];

							

					

                if ($image_files!='') {

                    $thumbimg = $image_files;

                }

				else

				{

					$thumbimg = $base_url."admin/docs/albums/ap.jpg";				

				}      

				

				 $ret .= '<div class="imageRowItem">



                        <div class="niceBorder">



                            <a href="'.$base_url.'view-gallery?aid='.$albumid.'" title="'.$albumname[0].'"><img src="'.$thumbimg.'" alt="'.$albumname[0].'" />



                                <br /> '.$albname.'</a>



                        </div>



                    </div>';



				        ++$count;



                           if($count == 2){



                               $finalret .=  '<div class="imageRow">'.$ret .'</div>



										<div class="clear"></div>



										<hr />';



                                $ret = "";



                                $count = 0;



                            }



            }





			if(mysqli_num_rows ( $query ) % 2 ) {



                                         $finalret .= '<div class="imageRow">'.$ret .'</div>



										<div class="clear"></div>



										<hr />';



			   }





        return $finalret;



		

	}

        
public function getTotalInnerGalleryList() {


        global $con,$base_url;


		$ret = "";

		$count = 0;

		$finalret = "";
	
	
		
		$query0 = mysqli_query($con,'select distinct courseid from sag_albums where image =""');      

        while ($row0 = mysqli_fetch_assoc($query0)) {
			
			$query1 = mysqli_query($con,'select course_name,id from sag_courses where id="'.$row0['courseid'].'"');      
        	$row1 = mysqli_fetch_assoc($query1);
			
			$courseid = $row1['id'];
			$coursename = $row1['course_name'];
			
			
			$ret .= "<div class='clear'></div><h2 class='gallerytitle'>".$coursename."</h2>";

		$query = mysqli_query($con,'select albumid,albumname,thump from sag_albums where image <>"" and courseid="'.$courseid.'" group by albumid');      


            while ($row = mysqli_fetch_assoc($query)) {



                $albumid = $row['albumid'];
				$albname = $row['albumname'];

                $albumname = explode('-',$row['albumname']);
				

				$image_files=$row['thump'];
											

                if ($image_files!='') {

                    $thumbimg = $image_files;

                }

				else

				{

					$thumbimg = $base_url."admin/docs/albums/ap.jpg";				

				}      

				

				 $ret .= '<div class="imageRowItem">



                        <div class="niceBorder">



                            <a href="'.$base_url.'view-gallery?aid='.$albumid.'" title="'.$albumname[0].'"><img src="'.$thumbimg.'" alt="'.$albumname[0].'" />



                                <br /> '.$albname.'</a>



                        </div>



                    </div>';



				        ++$count;



                           if($count == 2){



                               $finalret .=  '<div class="imageRow">'.$ret .'</div>



										<div class="clear"></div>



										<hr />';



                                $ret = "";



                                $count = 0;



                            }



            }



}

			/*if(mysqli_num_rows ( $query ) % 2 ) {



                                         $finalret .= '<div class="imageRow">'.$ret .'</div>



										<div class="clear"></div>



										<hr />';



			   }*/





        return $finalret;



		

	}
        

    public function getGalleryImages($albumid) {



        global $con,$base_url;



        $ret = Array();

		$ret['albumname'] = "";

		$ret['image_list'] = "";


        $query = mysqli_query($con,'select albumid,albumname from sag_albums where albumid="'.$albumid.'"');      



            while ($row = mysqli_fetch_assoc($query)) {



                $albumid = $row['albumid'];

                $ret['albumname'] = $row['albumname'];



                $images_dir = "admin/docs/albums/" . $albumid . "/";

                $image_files = glob($images_dir . "*");

                if (count($image_files)) {

                    $thumbimg = $image_files[0];

                } else {

                    $thumbimg = "admin/docs/albums/ap.jpg";

                }



                $ret['image_list'] .= '<a href="'.$base_url.''.$thumbimg.'" class="highslide" onclick="return hs.expand(this)">



                        <img src="'.$base_url.''.$thumbimg.'" alt="Highslide JS" title="Click to enlarge" /></a>



                    <div class="highslide-caption">



                    </div>';

            }

        

        return $ret;

    }

    

    

    public function getAlbumImages($ide){

        

		global $con,$base_url;

		

       	$ret = Array();

		$ret['albumname'] = "";

		$ret['album_list'] = "";

		$ret['album_title'] = "";

		

        $query = mysqli_query($con,'SELECT albumid ,albumname,image,thump,courseid FROM sag_albums where albumid="'.$ide.'" and image <>""');

        $crow = mysqli_fetch_assoc($query);
		$courseid = $crow['courseid'];
		
		$query1 = mysqli_query($con,'SELECT course_name FROM sag_courses where id="'.$courseid.'"');

        $crow1 = mysqli_fetch_assoc($query1);

		$i=0;

        while ($row = mysqli_fetch_assoc($query)) {

           

			

			$ret['albumname'] = $row['albumname'];

			

			$albumname = explode('-',$row['albumname']);

			

			if($albumname[1]=="") $albumname = $albumname[0];

			//else if(strlen($albumname[0]) > strlen($albumname[1]))  $albumname = $albumname[1];

			else $albumname = $albumname[1];

			

            if($i==0) $ret['album_list'] = '<h2><span>'.$crow1['course_name'].' - '.$albumname.'</span></h2>';   

				$image_files=$row;	                 

           

            if (count($image_files)) {

                $index = 0;

				$i=2;				

						

                        $ret['album_list'] .= '<div class="highslide-gallery-view"><a href="'.$row['image'].'" class="highslide" onclick="return hs.expand(this)">



                        <img src="'.$row['thump'].'" alt="Highslide JS" title="Click to enlarge" /></a>



                    <div class="highslide-caption">



                    </div>';

               

                $ret['album_list'] .= '</div>';

				

            } else {

                $ret .= '<p>There are no images in this Album.</p>';

            }

        }

        

        return $ret;

        

    }

    

	

	 public function getSchedule(){

		 

		 global $con,$base_url;

		 

		 

         

		 $ret = "";

		 $coursename = "";

		 

		 $query = mysqli_query($con,'SELECT sag_registration.courseid,course_name,duration,image,link,date1,date FROM (`sag_registration`)

                                      INNER JOIN `sag_courses` ON sag_courses.id=sag_registration.courseid where TO_DAYS(date) >= TO_DAYS(NOW()) and frontpage="Yes" and active ="Yes" ORDER BY `date` asc');

		 

		 while ($row = mysqli_fetch_assoc($query)) {

			 

			 $month = date('M', strtotime($row['date1']));

             $day1 = date('d', strtotime($row['date1']));

			 $year = date('Y', strtotime($row['date1']));

			 

			 $date = $month.' '.$day1.' '.$year;

			 			

			 $duration = $row['duration'];

			 

			 if($duration!=""){ $duration =" ( ".$duration." )";}

			  

			 $ret .='<tr>

					<td width="60" ><img src="'.$row['image'].'" style=" width: 113px;height: 50px;border-radius:5px;vertical-align: middle;" /></td>

					<td width="440" height="60">'.$row['course_name'].$duration.'</td>

					<td width="140" height="60">'.$date.'</td>

				    </tr>';

					

			 $coursename .= '<tr>



							<td colspan="3"><input type="radio" name="group1" class="radio" value="'.ucfirst($row['course_name']).$duration.'"> <label for="option"><span><span></span></span>'.ucfirst($row['course_name']).$duration.'</label></td>

							

							</tr>

							

							<tr>

							

							<td>&nbsp;</td>

							

							</tr>';

			 

		 }

		 

		 

		 /*$query1 = mysqli_query($con,'SELECT * FROM sag_courses WHERE id NOT IN (SELECT courseid FROM sag_registration)');

		 

		 while ($row1 = mysqli_fetch_assoc($query1)) {

			 

			 $duration1 = $row1['duration'];

			 

			 if($duration1!=""){ $duration1 =" ( ".$duration1." )";}

			 

			 $ret .='<tr>

					<td width="60"><img src="'.$base_url.'admin/docs/courses/'.$row1['image'].'" style=" width: 71px;height: 55px;" /></td>

					<td width="440" height="60">'.$row1['course_name'].$duration1.'</td>

					<td width="140" height="60">Nil</td>

				    </tr>';

					

			

			$coursename .= '<tr>



							<td colspan="3"><input type="radio" name="group1" value="'.ucfirst($row1['course_name']).$duration1.'"> '.ucfirst($row1['course_name']).$duration1.'</td>

							

							</tr>

							

							<tr>

							

							<td>&nbsp;</td>

							

							</tr>';

							

			

		 } */

			 		 

		 return array(0=>$ret,1=>$coursename);

	 }

	 

	 /* public function Gettestimonial(){

		 

		 global $con,$base_url;

		 

		 $ret = Array();

		 $ret['title'] = "";

		 $ret['content'] = "";

		 $ret['name'] = "";

		 

		 $query = mysqli_query($con,'SELECT * FROM sag_testimonial where active="Yes" and frontpage="Yes" and innerpage="No"');

		 

		 $row = mysqli_fetch_assoc($query);

		 

		 if($row)

		 {

			 $ret['title'] = $row['title'];

			 $ret['content'] = $row['content'];

			 $ret['name'] = $row['name'];

		 }

			 		 

		 return $ret;

	 }*/

	

public function Gettestimonial($tempdir_url){



		global $con,$base_url;


		 $ret = "";

		 $count = 0;

		 $finalret = "";

		 

		 $query = mysqli_query($con,'SELECT * FROM sag_testimonial where active="Yes" and innerpage="Yes" and frontpage="Yes" order by sno desc');

		 

		if(mysqli_num_rows($query) > 0){



		 while ($row = mysqli_fetch_assoc($query)) {
			 
			 $name = trim($row['name']);
			 $content = $row['content'];
			 			 
			 $namearr = explode('(',$name);
			 $name1 = str_replace('&ndash; ','',$namearr[1]);
			 
			 $dname = $namearr[0];
			 
			 $namearr1 = explode(' ',$name1);
			 
			 $city = "(".$namearr1[0];
			 if(count($namearr1)>2)$mobile = $namearr1[1]." ".$namearr1[2];
			 else $mobile = $namearr1[1];
		 
			 /*$content = preg_replace("/<([a-z][a-z0-9]*)[^>]*?(\/?)>/i",'<$1$2>', $content);
			 $content = str_replace(array('<p>','</p>','&quot;','&quot;','&ldquo;','&rdquo;'),'',$content);*/

			  $ret .= '<div class="testi-box">

        	<img src="'.$tempdir_url.'/images/testimonials/testi-default.png" alt="'.$dname.'" />

        	<div class="adiquotetp"></div>

        	'.$content.'

            <div class="adiquotebt"></div>

            <h4>- '.$name.'</h4>
        
        </div>';

			   

            }


			 }

		 

		 

		 else

		 {

			 $ret = ' <p>Coming Soon...</p>';

		 }

			 		 

		 return $ret;




	 }





public function Gettestimonialinner(){

		 

		 global $con,$base_url;

		 
		 $ret = "";

		 $count = 0;

		 $finalret = "";

	

		 $query = mysqli_query($con,'SELECT * FROM sag_testimonial where active="Yes" and frontpage="No" and innerpage="Yes"');

		 

		if(mysqli_num_rows($query) > 0){



		 while ($row = mysqli_fetch_assoc($query)) {

			 

		 

		/* if($row['image']!="" && $row['onlyimage']=="Yes" && $row['onlytext']=="No")

		 {

			$ret .=  '<div id="top-default" align="center"><img src="'.$base_url.'admin/docs/testimonial/image/'.$row['image'].'" /></div><hr class="hrtestimon"/>';

		 }   

		 

		 if($row['photo']!="" && $row['onlyimage']=="No" && $row['onlytext']=="No")

		 {

			 

			 $ret .= ' <div id="top-default"> 

					   <div class="test-photo">

					   <img src="'.$base_url.'admin/docs/testimonial/photo/'.$row['photo'].'" class="niceBorderleft"/>

					   <p class="alignjust">'.trim($row['name']).'</p>

					   </div>					   

					   

					   <p class="alignjust">'.$row['content'].'</p>

					   

					   </div> <hr class="hrtestimon">';

					   

		 }*/

		 

		 if($row['photo']=="" && $row['image']=="" && $row['onlyimage']=="No" && $row['onlytext']=="Yes")

		 {

			 $ret .= ' <div id="top-default">

					   

					   <p>'.$row['content'].'</p>

					   

					   </div>

					 ';

			 $count++;

			 

		 }

		 if($count == 1){

                               $finalret .=  '<div>'.$ret .'</div>';

                                $ret = "";

                                $count = 0;

                            }



			   

            }

			

			/*if(mysqli_num_rows ( $query ) % 2 ) {

				   

                               $finalret .= '<div>'.$ret .'</div>';				

			}*/

		 

			 }

		 

		 

		 else

		 {

			 $ret = ' <p>Coming Soon...</p>';

		 }

		 

		 if(mysqli_num_rows ( $query ) % 2 ) {

				   

                               $finalret .= '<div>'.$ret .'</div>';				

			}

        

			 		 

		 return $ret;

	 }

	 

	 public function Gettestimonialinnerall(){

		 

		 global $con,$base_url;


		 $ret = "";

		 $count = 0;

		 $finalret = "";

		 

		 $query = mysqli_query($con,'SELECT * FROM sag_testimonial where active="Yes" and innerpage="Yes" order by sno desc');

		 

		if(mysqli_num_rows($query) > 0){



		 while ($row = mysqli_fetch_assoc($query)) {
			 
			 $name = trim($row['name']);
			 $content = $row['content'];
		 
			 $content = preg_replace("/<([a-z][a-z0-9]*)[^>]*?(\/?)>/i",'<$1$2>', $content);
			 $content = str_replace(array('<p>','</p>','&quot;','&quot;','&ldquo;','&rdquo;'),'',$content);

			 $ret .= ' <p><strong>'.$name.'</strong> &ndash; &ldquo;'.$content.' &rdquo;</p>';

		 if($row['photo']!="")
		 {

			 //$ret .= '<p><img src="/images/long-term-course-photos/testimonials/dr-subbulakshmi.jpg" class="niceBorderright" /><strong>Dr Subbulakshmi (Tirunelveli) +91 9488385234</strong> &ndash; &quot; Wonderful experience, Iam happy that Ive taken the right decision of my life. Thanks to Dr Narasimhan Sir for providing such a platform where we work on patients and my special thanks to Dr Santhanam and Dr Pragya for their guidance ; Last but not the least, thanks to our co-ordinator Mrs Sudha and entire Team Community for their assistance. &quot; </p>';

			 $count++;

		 }

		/* if($count == 1){

                               $finalret .=  '<div>'.$ret .'</div>';

                                $ret = "";

                                $count = 0;

                            }*/



			   

            }

			

			/*if(mysqli_num_rows ( $query ) % 2 ) {

				   

                               $finalret .= '<div>'.$ret .'</div>';				

			}
*/
		 

			 }

		 

		 

		 else

		 {

			 $ret = ' <p>Coming Soon...</p>';

		 }

		 

		/* if(mysqli_num_rows ( $query ) % 2 ) {

				   

                               $finalret .= '<div>'.$ret .'</div>';				

			}*/

        

			 		 

		 return $ret;

	 }

	

	

	//Test

	

	public function getTestGalleryList() {



        global $con,$base_url;

		
		$ret = "";
		$count = 0;
		$finalret = "";
		$a=1;

		$query = mysqli_query($con,'select albumid,albumname,thump from sag_albums where image <>"" group by albumid');      

                
            while ($row = mysqli_fetch_assoc($query)) {



                $albumid = $row['albumid'];

                $albumname = explode('-',$row['albumname']);

				

				$image_files=$row['thump'];

							

					

                if ($image_files!='') {

                    $thumbimg = $image_files;

					$url = parse_url( $thumbimg );



				echo $result = $url['scheme']. "://". $url['host']. pathinfo($url['path'], PATHINFO_DIRNAME ).'/';

					if (is_dir($result)){

  if ($dh = opendir($result)){

    while (($file = readdir($dh)) !== false){

      echo "filename:" . $file . "<br>";

    }

    closedir($dh);

  }

}

                }

				else

				{

					$thumbimg = $base_url."admin/docs/albums/ap.jpg";				

				}             								

				

				if($albumname[1]=="") $albumname = $albumname[0];

				//else if(strlen($albumname[0]) > strlen($albumname[1]))  $albumname = $albumname[1];

				else $albumname = $albumname[1];

			

			$ret.='<li><p class="conrightp">'.$albumname.'</p> <div style="width: 100%;text-align:center;"><a href="view-gallery.html?aid='.$albumid.'"><img class="contentrightimg1" src="'.$thumbimg.'" title="'.$albumname.'"/>

            <img class="contentrightimg2" src="'.$thumbimg.'" alt="'.$albumname.'" title="'.$albumname.'"/> </a><hr class="hrright"></div></li>';

						

				   ++$count;     

				

				 

                           if($count == 3){

                               $finalret .=  '<div>'.$ret.'</div>';

                                $ret = "";

                                $count = 0; 

                            }



			   exit;

            }

			

			if(mysqli_num_rows ( $query ) % 3 ) {

				   

                               $finalret .= '<div>'.$ret.'</div>';				

			}

        

        return $finalret;	

	}

	



}



?>
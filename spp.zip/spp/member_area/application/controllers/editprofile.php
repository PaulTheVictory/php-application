<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

session_start(); //we need to call PHP's session object to access it through CI

class Editprofile extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model('user_model','',TRUE);
		$this->load->model('profile_model','',TRUE);
	}
	
	function index()
	{
		if($this->session->userdata('logged_in'))
   		{
     		$session_data = $this->session->userdata('logged_in');
     		$data['username'] = $session_data['username'];
			$data['memberid'] = $session_data['id'];
			$data['membername'] = $this->profile_model->GetMemberName($session_data['id']);
			$data['memberprofile'] = $this->profile_model->GetMemberProfile($session_data['id'],true);
			
			if($data['membername']['status']!="VERIFIED" || $data['membername']['profileimg']=="dp.jpg")
			{
			   redirect('profileedit', 'refresh');
			}
			
			$this->load->view('header',$data);
     		$this->load->view('editprofile_view', $data);
			$this->load->view('footer');
   		}
   		else
   		{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
   		}

	}
	
	public function updateProfile() {
        
        $session_data = $this->session->userdata('logged_in');
		$memberid = $session_data['id'];
		
		$card  = isset($_GET['card'])?$_GET['card']:'';
		$certificate  = isset($_GET['certificate'])?$_GET['certificate']:'';
        $mobile  = isset($_GET['mobile'])?$_GET['mobile']:'';
        $phone  = isset($_GET['phone'])?$_GET['phone']:'';
        $email = isset($_GET['email'])?$_GET['email']:'';
		$gender = isset($_GET['gender'])?$_GET['gender']:'';
        $dob = isset($_GET['dob'])?$_GET['dob']:'';
		$address = isset($_GET['address'])?$_GET['address']:'';
		$contactaddress = isset($_GET['contactaddress'])?$_GET['contactaddress']:'';
		$contactstate = isset($_GET['contactstate'])?$_GET['contactstate']:'';
		$contactpin = isset($_GET['contactpin'])?$_GET['contactpin']:'';
		$qualification = isset($_GET['qualification'])?$_GET['qualification']:'';
		$college = isset($_GET['college'])?$_GET['college']:'';
		$designation = isset($_GET['designation'])?$_GET['designation']:'';
		$clinic = isset($_GET['clinic'])?$_GET['clinic']:'';
		$clinicphone = isset($_GET['clinicphone'])?$_GET['clinicphone']:'';
		$pubsearch = isset($_GET['pubsearch'])?$_GET['pubsearch']:'';
		$membertype = isset($_GET['membertype'])?$_GET['membertype']:'';
		$mname = isset($_GET['mname'])?$_GET['mname']:'';
		$mstudent = isset($_GET['mstudent'])?$_GET['mstudent']:'';
		$mfaculty = isset($_GET['mfaculty'])?$_GET['mfaculty']:'';
		$maddress1 = isset($_GET['maddress1'])?$_GET['maddress1']:'';
		$maddress2 = isset($_GET['maddress2'])?$_GET['maddress2']:'';
		$mcity = isset($_GET['mcity'])?$_GET['mcity']:'';
		$mstate = isset($_GET['mstate'])?$_GET['mstate']:'';
		$mpincode = isset($_GET['mpincode'])?$_GET['mpincode']:'';
		$mdesignation = isset($_GET['mdesignation'])?$_GET['mdesignation']:'';
		$mlandline = isset($_GET['mlandline'])?$_GET['mlandline']:'';
		$mmobile = isset($_GET['mmobile'])?$_GET['mmobile']:'';
		$mgeo = isset($_GET['mgeo'])?$_GET['mgeo']:'';
		$mclinictiming = isset($_GET['mclinictiming'])?$_GET['mclinictiming']:'';
		
		$doj = isset($_GET['doj'])?$_GET['doj']:'';
		
		$sameaddress = isset($_GET['sameaddress'])?$_GET['sameaddress']:'';
		$address2 = isset($_GET['address2'])?$_GET['address2']:'';
		$city = isset($_GET['city'])?$_GET['city']:'';
		$state = isset($_GET['state'])?$_GET['state']:'';
		$pincode = isset($_GET['pincode'])?$_GET['pincode']:'';
		$contactaddress2 = isset($_GET['contactaddress2'])?$_GET['contactaddress2']:'';
		$contactcity = isset($_GET['contactcity'])?$_GET['contactcity']:'';
		$clinicaddress2 = isset($_GET['clinicaddress2'])?$_GET['clinicaddress2']:'';
		$cliniccity = isset($_GET['cliniccity'])?$_GET['cliniccity']:'';
		$clinicstate = isset($_GET['clinicstate'])?$_GET['clinicstate']:'';
		$clinicpin = isset($_GET['clinicpin'])?$_GET['clinicpin']:'';
				        
        
        $ret = $this->profile_model->UpdateProfile($memberid,$mobile,$phone,$email,$gender,$dob,$address,$contactaddress,$contactstate,$contactpin,$qualification,$college,$designation,$clinic,$clinicphone,$pubsearch,$membertype,$mstudent,$mfaculty,$mname,$maddress1,$maddress2,$mcity,$mstate,$mpincode,$mdesignation,$mlandline,$mmobile,$mgeo,$mclinictiming,$card,$certificate,$doj,$sameaddress,$address2,$city,$state,$pincode,$contactaddress2,$contactcity,$clinicaddress2,$cliniccity,$clinicstate,$clinicpin);
        echo json_encode($ret);
    }
	
	public function updateabout() {
        
        $session_data = $this->session->userdata('logged_in');
		$memberid = $session_data['id'];
		
		$about  = isset($_GET['about'])?$_GET['about']:'';
		
		$ret = $this->profile_model->UpdateAbout($memberid,$about);
		echo json_encode($ret);
    }
	
	public function addeducation() {
        
        $session_data = $this->session->userdata('logged_in');
		$memberid = $session_data['id'];
		
		$school  = isset($_POST['school'])?$_POST['school']:'';
		$degree  = isset($_POST['degree'])?$_POST['degree']:'';
		$study  = isset($_POST['study'])?$_POST['study']:'';
		$grade  = isset($_POST['grade'])?$_POST['grade']:'';
		$activity  = isset($_POST['activity'])?$_POST['activity']:'';
		$fromyear  = isset($_POST['fromyear'])?$_POST['fromyear']:'';
		$toyear  = isset($_POST['toyear'])?$_POST['toyear']:'';
		$description  = isset($_POST['description'])?$_POST['description']:'';
		
		$eduid  = isset($_POST['eduid'])?$_POST['eduid']:'';
		$uploadname  = isset($_POST['edufile'])?$_POST['edufile']:'';
		
		$id = uniqid();
		
		   if(isset($_FILES["upload"]) && !empty($_FILES["upload"]['name']))
		   {
				$validExtensions = array('.jpg', '.jpeg', '.gif', '.png', '.docx', '.doc', '.pdf', '.pptx', '.ppt', '.mp4', '.avi');
				$imageExtensions = array('.jpg', '.jpeg', '.gif', '.png');
				
				$fileExtension = strrchr($_FILES['upload']['name'], ".");
				$fileName = $id."".$fileExtension;
				$dirname = dirname(FCPATH).'/docs/education/'.$memberid."/";
				$destinationfull = $dirname . $fileName;
				
				if (in_array(strtolower($fileExtension), $validExtensions)) {
					
					/* Get original image x y*/
					list($w, $h) = getimagesize($_FILES['upload']['tmp_name']);
					
					$imgString = file_get_contents($_FILES['upload']['tmp_name']);
					
					if(!file_exists($dirname))
					{
						mkdir($dirname,0777);
					}
					
					if($uploadname!="" && $fileName!=$uploadname && file_exists($dirname . $uploadname))unlink($dirname . $uploadname);
					if(file_exists($destinationfull))unlink($destinationfull);

					if(in_array(strtolower($fileExtension), $imageExtensions))
					{
						$image = imagecreatefromstring($imgString);
						$tmp = imagecreatetruecolor($w, $h);
						// set background to white
						$white = imagecolorallocate($tmp, 255, 255, 255);
						imagefill($tmp, 0, 0, $white);
						
						imagecopyresampled($tmp, $image, 0, 0, 0, 0, $w, $h, $w, $h);
						
						
						$resultfull = imagejpeg($tmp,$destinationfull,70);
					}
					else
					{
						$resultfull = move_uploaded_file($_FILES['upload']['tmp_name'],$destinationfull);
					}
					
					if($resultfull){
				    	
						if($eduid=="")
						{	
							$ret = $this->profile_model->AddEducation($id,$memberid,$school,$degree,$study,$grade,$activity,$fromyear,$toyear,$description,$fileName);
						}
						else
						{
							$ret = $this->profile_model->UpdateEducation($memberid,$school,$degree,$study,$grade,$activity,$fromyear,$toyear,$description,$fileName,$eduid);
						}
						echo json_encode($ret);
						
					}else{
						
						$ret = array(0 => "ufail");
						echo json_encode($ret);
					}
								
				}else{
					
					$ret = array(0 => "exfail");
					echo json_encode($ret);
					
				}
			
			}
			else
			{
				if($eduid=="")
				{
					$ret = $this->profile_model->AddEducation($id,$memberid,$school,$degree,$study,$grade,$activity,$fromyear,$toyear,$description,'');
				}
				else
				{
					$ret = $this->profile_model->UpdateEducation($memberid,$school,$degree,$study,$grade,$activity,$fromyear,$toyear,$description,$uploadname,$eduid);
				}
				echo json_encode($ret);
			}
		
    }
	
	public function addexperience() {
        
        $session_data = $this->session->userdata('logged_in');
		$memberid = $session_data['id'];
		
		$title  = isset($_POST['title'])?$_POST['title']:'';
		$company  = isset($_POST['company'])?$_POST['company']:'';
		$location  = isset($_POST['location'])?$_POST['location']:'';
		$frommonth  = isset($_POST['frommonth'])?$_POST['frommonth']:'';
		$fromyear  = isset($_POST['fromyear'])?$_POST['fromyear']:'';
		$tomonth  = isset($_POST['tomonth'])?$_POST['tomonth']:'';
		$toyear  = isset($_POST['toyear'])?$_POST['toyear']:'';
		$workhere  = isset($_POST['workhere'])?$_POST['workhere']:'';
		$description  = isset($_POST['description'])?$_POST['description']:'';
		
		$expid  = isset($_POST['expid'])?$_POST['expid']:'';
		$uploadname  = isset($_POST['expfile'])?$_POST['expfile']:'';
		
		$id = uniqid();
		
		   if(isset($_FILES["upload"]) && !empty($_FILES["upload"]['name']))
		   {
				$validExtensions = array('.jpg', '.jpeg', '.gif', '.png', '.docx', '.doc', '.pdf', '.pptx', '.ppt', '.mp4', '.avi');
				$imageExtensions = array('.jpg', '.jpeg', '.gif', '.png');
				
				$fileExtension = strrchr($_FILES['upload']['name'], ".");
				$fileName = $id."".$fileExtension;
				$dirname = dirname(FCPATH).'/docs/experience/'.$memberid."/";
				$destinationfull = $dirname . $fileName;
				
				if (in_array(strtolower($fileExtension), $validExtensions)) {
					
					/* Get original image x y*/
					list($w, $h) = getimagesize($_FILES['upload']['tmp_name']);
					
					$imgString = file_get_contents($_FILES['upload']['tmp_name']);
					
					if(!file_exists($dirname))
					{
						mkdir($dirname,0777);
					}
					
					if($uploadname!="" && $fileName!=$uploadname  && file_exists($dirname . $uploadname))unlink($dirname . $uploadname);
					if(file_exists($destinationfull))unlink($destinationfull);

					if(in_array(strtolower($fileExtension), $imageExtensions))
					{
						$image = imagecreatefromstring($imgString);
						$tmp = imagecreatetruecolor($w, $h);
						// set background to white
						$white = imagecolorallocate($tmp, 255, 255, 255);
						imagefill($tmp, 0, 0, $white);
						
						imagecopyresampled($tmp, $image, 0, 0, 0, 0, $w, $h, $w, $h);
						
						
						$resultfull = imagejpeg($tmp,$destinationfull,70);
					}
					else
					{
						$resultfull = move_uploaded_file($_FILES['upload']['tmp_name'],$destinationfull);
					}
					
					if($resultfull){
				    	
						if($expid=="")
						{	
							$ret = $this->profile_model->AddExperience($id,$memberid,$title,$company,$location,$frommonth,$fromyear,$tomonth,$toyear,$workhere,$description,$fileName);
						}
						else
						{
							$ret = $this->profile_model->UpdateExperience($memberid,$title,$company,$location,$frommonth,$fromyear,$tomonth,$toyear,$workhere,$description,$fileName,$expid);
						}
						echo json_encode($ret);
						
					}else{
						
						$ret = array(0 => "ufail");
						echo json_encode($ret);
					}
								
				}else{
					
					$ret = array(0 => "exfail");
					echo json_encode($ret);
					
				}
			
			}
			else
			{
				if($expid=="")
				{
					$ret = $this->profile_model->AddExperience($id,$memberid,$title,$company,$location,$frommonth,$fromyear,$tomonth,$toyear,$workhere,$description,'');
				}
				else
				{
					$ret = $this->profile_model->UpdateExperience($memberid,$title,$company,$location,$frommonth,$fromyear,$tomonth,$toyear,$workhere,$description,$uploadname,$expid);
				}
				echo json_encode($ret);
			}
		
    }
	
	public function addaward() {
        
        $session_data = $this->session->userdata('logged_in');
		$memberid = $session_data['id'];
		
		$name  = isset($_POST['certtitle'])?$_POST['certtitle']:'';
		$issuer  = isset($_POST['issuer'])?$_POST['issuer']:'';
		$licenseno  = isset($_POST['licenseno'])?$_POST['licenseno']:'';
		$frommonth  = isset($_POST['frommonth'])?$_POST['frommonth']:'';
		$fromyear  = isset($_POST['fromyear'])?$_POST['fromyear']:'';
		$tomonth  = isset($_POST['tomonth'])?$_POST['tomonth']:'';
		$toyear  = isset($_POST['toyear'])?$_POST['toyear']:'';
		$certexpire  = isset($_POST['certexpire'])?$_POST['certexpire']:'';
		$certurl  = isset($_POST['certurl'])?$_POST['certurl']:'';
		$description  = isset($_POST['description'])?$_POST['description']:'';
		
		$awaid  = isset($_POST['awaid'])?$_POST['awaid']:'';
		
				if($awaid=="")
				{
					$ret = $this->profile_model->AddAward($memberid,$name,$issuer,$licenseno,$frommonth,$fromyear,$tomonth,$toyear,$certexpire,$certurl,$description);
				}
				else
				{
					$ret = $this->profile_model->UpdateAward($memberid,$name,$issuer,$licenseno,$frommonth,$fromyear,$tomonth,$toyear,$certexpire,$certurl,$description,$awaid);
				}
				echo json_encode($ret);
		
    }
	
	public function editpopupdata() {
		
		$session_data = $this->session->userdata('logged_in');
		$memberid = $session_data['id'];
		
		$id = isset($_POST['id'])?$_POST['id']:'';
		$type = isset($_POST['type'])?$_POST['type']:'';
		
		$ret = $this->profile_model->EditPopupData($memberid,$id,$type);
		echo json_encode($ret);
	}
	
	public function deletepopupdata() {
		
		$session_data = $this->session->userdata('logged_in');
		$memberid = $session_data['id'];
		
		$id = isset($_POST['id'])?$_POST['id']:'';
		$type = isset($_POST['type'])?$_POST['type']:'';
		
		$ret = $this->profile_model->DeletePopupData($memberid,$id,$type);
		echo json_encode($ret);
	}
	
}
?>

<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Getmemberapi extends CI_Controller {
	
function __construct()
	{
		parent::__construct();
		$this->load->model('user_model','',TRUE);
		$this->load->model('profile_model','',TRUE);
	}
	
	function index()
	{
		header('Access-Control-Allow-Origin: *');
		
		$uname=$this->config->item('apiuname');
		$pass=$this->config->item('apipass');
		    
		
		if (isset($_POST['uname']) && isset($_POST['pass']) && isset($_POST['uid']))
		{
			if($_POST['uname']==$uname && $_POST['pass']==$pass)
			{
				$userid = $_POST['uid'];
				$datav['validmid'] = $this->profile_model->GetValidMid($userid);
			
					if($datav['validmid']['memberid']!="")
					{
						$memberid=$datav['validmid']['memberid'];
						$data['membername'] = $this->profile_model->GetMemberNameapi($memberid);
						$data['memberprofile'] = $this->profile_model->GetMemberProfileapi($memberid);
		                 
						$data['status']="success";
						echo $data1['memberdetails']=json_encode($data);
						//$this->load->view('getmember_view',$data1);
					}
					else
					{
						$data['status'] =array("errormsg" => "User does not exists.");
						echo $data1['memberdetails']=json_encode($data);
						//$this->load->view('getmember_view',$data1);
					}
			}
			else
			{
				   $data['status'] =array("errormsg" => "Authentication failed");
				   echo $data1['memberdetails']=json_encode($data);
				   //$this->load->view('getmember_view',$data1);
			}
		}
	
	}

}

?>
<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

session_start(); //we need to call PHP's session object to access it through CI

class Editprofile extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model('user_model','',TRUE);
		$this->load->model('profile_model','',TRUE);
	}
	
	function index()
	{
		if($this->session->userdata('splog_in'))
   		{
     		$session_data = $this->session->userdata('splog_in');
     		$data['username'] = $session_data['username'];
			$data['memberid'] = $session_data['id'];
			$data['membername'] = $this->profile_model->GetMemberName($session_data['id']);
			$data['memberprofile'] = $this->profile_model->GetMemberProfile($session_data['id'],true);
			
			
			$this->load->view('header',$data);
     		$this->load->view('speaker/editprofile_view', $data);
			$this->load->view('footer');
   		}
   		else
   		{
     		//If no session, redirect to login page
     		redirect('speaker/login', 'refresh');
   		}

	}
	
	public function spearkerupdateProfile() {
        
        $session_data = $this->session->userdata('splog_in');
		$memberid = $session_data['id'];
		
		$mobile  = isset($_GET['mobile'])?$_GET['mobile']:'';
		$email  = isset($_GET['email'])?$_GET['email']:'';
		$designation  = isset($_GET['designation'])?$_GET['designation']:'';
        $institute  = isset($_GET['institute'])?$_GET['institute']:'';
        $sinterest  = isset($_GET['sinterest'])?$_GET['sinterest']:'';
        $tinterest = isset($_GET['tinterest'])?$_GET['tinterest']:'';
		$acompany = isset($_GET['acompany'])?$_GET['acompany']:'';
        $cv = isset($_GET['cv'])?$_GET['cv']:'';
		$topictitle = isset($_GET['topictitle'])?$_GET['topictitle']:'';
        
        $ret = $this->profile_model->SpeakerUpdateProfile($memberid,$mobile,$email,$designation,$institute,$sinterest,$tinterest,$acompany,$cv,$topictitle);
        echo json_encode($ret);
    }
	
}
?>

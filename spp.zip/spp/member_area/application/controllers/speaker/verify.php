<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Verify extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model('user_model','',TRUE);
		$this->load->model('profile_model','',TRUE);
	}
	
	function index()
	{
		if($this->session->userdata('logged_in'))
   		{
     		$session_data = $this->session->userdata('logged_in');
     		$data['username'] = $session_data['username'];
			$data['memberid'] = $session_data['id'];
			$data['membername'] = $this->profile_model->GetMemberName($session_data['id']);
			$data['memberprofile'] = $this->profile_model->GetMemberProfile($session_data['id']);
			
			$this->profile_model->GetMemberProfile($session_data['id']);
			$this->load->helper(array('form'));
			$this->load->view('header');
			$this->load->view('verify_view',$data);	
			$this->load->view('footer');
			
		}
		else
   		{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
   		}
	}
	
	
	function SendCode()
	{
		$memberid  = isset($_GET['memberid'])?$_GET['memberid']:'';
		$name  = isset($_GET['name'])?$_GET['name']:'';
		
		$ret = $this->user_model->sendActivationCode($memberid,$name);
		echo json_encode($ret);
	}
	
	function SendMail()
	{
		$memberid  = isset($_GET['memberid'])?$_GET['memberid']:'';
		$name  = isset($_GET['name'])?$_GET['name']:'';
		$email  = isset($_GET['email'])?$_GET['email']:'';
		
		$ret = $this->user_model->sendCodeMail($memberid,$email);
		echo json_encode($ret);
	}
	
	function CheckMember()
	{
		$memberid  = isset($_GET['memberid'])?$_GET['memberid']:'';
		$card  = isset($_GET['card'])?$_GET['card']:'';
		$certificate  = isset($_GET['certificate'])?$_GET['certificate']:'';
		
		$ret = $this->user_model->sendCheckMember($memberid,$card,$certificate);
		echo json_encode($ret);
	}
}
?>

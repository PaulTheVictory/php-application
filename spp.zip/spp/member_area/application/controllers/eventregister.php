<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Eventregister extends CI_Controller {

	function __construct()
	{
		parent::__construct();		
		$this->load->model('findspecialist_model','',TRUE);
		$this->load->model('admin_model','',TRUE);
		$this->load->library('table');
	}
	
	function index()
	{
		if($this->session->userdata('adlog_in'))
   		{
			$session_data = $this->session->userdata('logged_in');
     		$data['username'] = $session_data['username'];
			$data['memberid'] = $session_data['id'];
			$data['membername'] = $this->admin_model->GetMemberName($session_data['id']);
			
			if(isset($_GET['eid']) && $_GET['eid']!="")
			{
			
				$eid = $_GET['eid'];
				
			    $data['eventdetail'] = $this->admin_model->GetEventDetail($eid);
				
				$tmpl = array('table_open' => '<table class="sortable" id="memberstable">');
				$this->table->set_template($tmpl);
				$this->table->set_heading('Memberid','Role','Name', 'Mobile', 'Email', '');
			
				$this->load->view('header');
				$this->load->view('eventregister_view', $data);	
				$this->load->view('footer');
			}
			else
			{
				redirect('events', 'refresh');
			}
			
		}
		else
   		{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
   		}
	}
	
	public function adduser() {
        
		$memberid  = isset($_POST['memberid'])?$_POST['memberid']:'';
		$eid  = isset($_POST['eid'])?$_POST['eid']:'';
		$strmin  = isset($_POST['strmin'])?$_POST['strmin']:'';
		$regcheck  = isset($_POST['regcheck'])?$_POST['regcheck']:'';
        
        $ret = $this->admin_model->AddUser($memberid,$eid,$strmin,$regcheck);
        echo json_encode($ret);
    }
	
	 public function deluser(){
        
        $ide  = isset($_GET['ide'])?$_GET['ide']:'';
        
        $ret = $this->admin_model->DelUser($ide);
        echo json_encode($ret);
    }

    

    public function getusers() {
            
            if($this->session->userdata('adlog_in')){
                
				$eid = isset($_POST['eid'])?$_POST['eid']:'';
				
                $ret =  $this->admin_model->GetAllUsers($eid);
                echo $ret;
                
            }else{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
            }
            
        }
	
	
}
?>

<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Events extends CI_Controller {

	function __construct()
	{
		parent::__construct();		
		$this->load->model('findspecialist_model','',TRUE);
		$this->load->model('admin_model','',TRUE);
	}
	
	function index()
	{
		if($this->session->userdata('adlog_in'))
   		{
			$session_data = $this->session->userdata('logged_in');
     		$data['username'] = $session_data['username'];
			$data['memberid'] = $session_data['id'];
			$data['membername'] = $this->admin_model->GetMemberName($session_data['id']);
			
			
			$data['allevents'] = $this->admin_model->GetAllEvents();
			
				$this->load->view('header');
				$this->load->view('events_view', $data);	
				$this->load->view('footer');
			
		}
		else
   		{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
   		}
	}
	
	public function checkUser() {
        
		$userid  = isset($_GET['userid'])?$_GET['userid']:'';
        
        $ret = $this->admin_model->CheckUser($userid);
        echo json_encode($ret);
    }
	
		
}
?>

<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class AddClinic extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model('user_model','',TRUE);
		$this->load->model('profile_model','',TRUE);
		$this->load->model('admin_model','',TRUE);
		$this->load->model('findspecialist_model','',TRUE);
	}
	
	function index()
	{
		if($this->session->userdata('logged_in'))
   		{
     		$session_data = $this->session->userdata('logged_in');
     		$data['username'] = $session_data['username'];
			$data['memberid'] = $session_data['id'];
			$data['membername'] = $this->profile_model->GetMemberName($session_data['id']);
			$data['memberprofile'] = $this->profile_model->GetMemberProfile($session_data['id']);
			
			$data['verify'] = 1;
			if($data['membername']['status']!="VERIFIED" || $data['membername']['profileimg']=="dp.jpg")
			{
				$data['verify'] = 0;
			}
				$data['back'] = 0;
				$data['stateoptions'] = $this->findspecialist_model->GetSelectOptions('state');
				//$data['cityoptions'] = $this->findspecialist_model->GetSelectOptions('city');
				//$data['areaoptions'] = $this->findspecialist_model->GetSelectOptions('area');
									
				$this->load->view('header', $data);
				$this->load->view('addclinic_view', $data);
				$this->load->view('footer');
			
			}
			else if($this->session->userdata('adlog_in'))
			{
				$memberid = $_GET['id'];
				$data['memberid'] = $memberid;
				$data['membername'] = $this->admin_model->GetMemberName($memberid);
				$data['memberprofile'] = $this->admin_model->GetMemberProfile($memberid);
				$data['verify'] = 0;
				$data['back'] = 1;
				$this->load->view('header', $data);
				$this->load->view('addclinic_view', $data);
				$this->load->view('footer');
			}
			else
			{
				redirect('login', 'refresh');
			}
		
	}
	
	public function addNewClinic() {
		
		if($this->session->userdata('logged_in'))
   		{
			
		$session_data = $this->session->userdata('logged_in');
		$data['username'] = $session_data['username'];
		$data['memberid'] = $session_data['id'];
		
		}
		else if($this->session->userdata('adlog_in'))
		{
			$data['memberid'] = isset($_GET['memid'])?$_GET['memid']:'';	
		}
		else
		{
			redirect('login', 'refresh');
		}
        
		$cname  = isset($_GET['cname'])?$_GET['cname']:'';		
		$cemail  = isset($_GET['cemail'])?$_GET['cemail']:'';
		$cstdcode  = isset($_GET['cstdcode'])?$_GET['cstdcode']:'';
		$clandline  = isset($_GET['clandline'])?$_GET['clandline']:'';
		$cmobile  = isset($_GET['cmobile'])?$_GET['cmobile']:'';
		$cwebsite  = isset($_GET['cwebsite'])?$_GET['cwebsite']:'';
		$cspeciality  = isset($_GET['cspeciality'])?$_GET['cspeciality']:'Dental Clinic';
		$cstate  = isset($_GET['cstate'])?$_GET['cstate']:'';		
		$ccity  = isset($_GET['ccity'])?$_GET['ccity']:'';
		$cpincode  = isset($_GET['cpincode'])?$_GET['cpincode']:'';
		$carea  = isset($_GET['carea'])?$_GET['carea']:'';
		$caddress  = isset($_GET['caddress'])?$_GET['caddress']:'';
		$clandmark  = isset($_GET['clandmark'])?$_GET['clandmark']:'';
		$clat  = isset($_GET['clat'])?$_GET['clat']:'';
		$clong  = isset($_GET['clong'])?$_GET['clong']:'';
        
        $ret = $this->findspecialist_model->AddNewClinic($data['memberid'],$cname,$cemail,$cstdcode,$clandline,$cmobile,$cwebsite,$cspeciality,$cstate,$ccity,$cpincode,$carea,$caddress,$clandmark,$clat,$clong);
        echo json_encode($ret);
		
		
			
    }
	
	
}
?>

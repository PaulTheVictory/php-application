<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Doctors extends CI_Controller {

	function __construct()
	{
		parent::__construct();		
		$this->load->model('findspecialist_model','',TRUE);
	}
	
	function index()
	{
				
		$cityfilter = str_replace('%20', ' ', $this->uri->rsegment(4, ""));
		$cityfilter = str_replace('-', ' ', $this->uri->rsegment(4, ""));
		$specialityfilter = str_replace('%20', ' ', $this->uri->rsegment(5, ""));
		$specialityfilter = str_replace('-', ' ', $this->uri->rsegment(5, ""));
			
		$data['currenturl'] = $this->uri->uri_string();
		$data['pageno'] = $this->input->get('page');
			
		$data['specialist'] = $this->findspecialist_model->GetDoctorsSearchResults($cityfilter,$specialityfilter,"",$data['pageno'],$data['currenturl']);
			
		$this->load->view('search/header');
		$this->load->view('search/doctors_view', $data);	
		$this->load->view('search/footer');
	}
}
?>

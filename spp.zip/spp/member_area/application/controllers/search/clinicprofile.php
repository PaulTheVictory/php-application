<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class ClinicProfile extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model('home_model','',TRUE);
		$this->load->model('clinic_model','',TRUE);
	}
	
	function index()
	{
		$data['controllername'] = $this->router->fetch_class();
		$data['cityfilter'] = str_replace('%20', ' ', $this->uri->rsegment(3, ""));
		$data['cityfilter'] = str_replace('-', ' ', $data['cityfilter']);
		
		$data['searchfield'] = "";
		
		$IsCityCheck = 	$this->home_model->IsCityCheck($data['cityfilter']);
		
		if($IsCityCheck){
			
			$searchcity = "Chennai";
			
			$data['searchsuggestions'] = $this->home_model->GetSearchSuggestions($searchcity);
			
			$data['clinicurlname'] = $this->uri->rsegment(4);
			
			$data['clinicprofile'] = $this->clinic_model->GetClinicProfileByUrlname($data['clinicurlname']);
			
			if($data['clinicprofile']['clinicid'] == ""){
				
				show_404();
				
			}else{
				
				$data['pagetitle'] = $data['clinicprofile']['cname'];
				$data['pagetitle'] .= ', '.$data['clinicprofile']['cspeciality'].' in '.$data['clinicprofile']['carea'].', '.$data['clinicprofile']['ccity'];
				$data['pagetitle'] .= ' – Book an Appointment Online with Doctors in '.$data['clinicprofile']['cname'].' in '.$data['clinicprofile']['carea'].', '.$data['clinicprofile']['ccity'].'  / Find Address – Jithya';
				
				$data['metadescription'] = '<meta name="description" content="'.$data['clinicprofile']['cname'].', '.$data['clinicprofile']['cspeciality'].', '.$data['clinicprofile']['carea'].', '.$data['clinicprofile']['ccity'].' – Book an Appointment Online with Doctors in '.$data['clinicprofile']['cname'].' in '.$data['clinicprofile']['carea'].', '.$data['clinicprofile']['ccity'].'  / Find Address – Jithya" />';
				
				$data['ogmetadescription'] = $data['clinicprofile']['cname'].', '.$data['clinicprofile']['cspeciality'].', '.$data['clinicprofile']['carea'].', '.$data['clinicprofile']['ccity'].' – Book an Appointment Online with Doctors in '.$data['clinicprofile']['cname'].' in '.$data['clinicprofile']['carea'].', '.$data['clinicprofile']['ccity'].'  / Find Address – Jithya';
				
				$this->load->view('header', $data);
				$this->load->view('clinicprofile_view', $data);
				$this->load->view('footer', $data);
				
			}
			
		}else{
			show_404();
		}
		
	}
	
	
}
?>

<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class DoctorProfile extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model('findspecialist_model','',TRUE);
	}
	
	function index()
	{
		$data['controllername'] = $this->router->fetch_class();
		$data['cityfilter'] = str_replace('%20', ' ', $this->uri->rsegment(3, ""));
		$data['cityfilter'] = str_replace('-', ' ', $data['cityfilter']);
		
		$data['searchfield'] = "";
		
		//$IsCityCheck = 	$this->findspecialist_model->IsCityCheck($data['cityfilter']);
		$IsCityCheck = true;
		if($IsCityCheck){
			
			$searchcity = "Chennai";
			
			//$data['searchsuggestions'] = $this->home_model->GetSearchSuggestions($searchcity);
			
			$data['doctorurlname'] = $this->uri->rsegment(4);
			
			$data['doctorprofile'] = $this->findspecialist_model->GetDoctorProfileByUrlname($data['doctorurlname']);
			
			$data['npdays'] = 	$this->findspecialist_model->GetNextDays(3,$data['doctorurlname'],$data['doctorprofile']['clinicid']);
			
			if($data['doctorprofile']['doctorid'] == ""){
				
				show_404();
				
			}else{
				
				$data['pagetitle'] = $data['doctorprofile']['dname'];
				$data['pagetitle'] .= ' - '.$data['doctorprofile']['category'].', '.$data['doctorprofile']['speciality'].' in '.ucwords($data['cityfilter']);
				$data['pagetitle'] .= ', Book an Appointment | IACDE';
				
				$data['metadescription'] = '<meta name="description" content="'.$data['doctorprofile']['dname'].' - '.$data['doctorprofile']['category'].', '.$data['doctorprofile']['speciality'].' in '.ucwords($data['cityfilter']).', Book an Appointment | IACDE" />';
				
				$data['ogmetadescription'] = $data['doctorprofile']['dname'].', '.$data['doctorprofile']['category'].', '.$data['doctorprofile']['speciality'].' in '.ucwords($data['cityfilter']).', Book an Appointment | IACDE';
				
				$this->load->view('search/header', $data);
				$this->load->view('search/doctorprofile_view', $data);
				$this->load->view('search/footer', $data);
				
			}
			
		}else{
			show_404();
		}
		
	}
	
	
function Getnextdays(){
	
	$countdays = isset($_POST['countdays'])?$_POST['countdays']:'';
	$docname = isset($_POST['docname'])?$_POST['docname']:'';
	$clinicid = isset($_POST['clinicid'])?$_POST['clinicid']:'';
	
    $ret = 	$this->doctor_model->GetNextDays($countdays,$docname,$clinicid);
	echo json_encode($ret);
}
	
	
}
?>

<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

session_start(); //we need to call PHP's session object to access it through CI

class Allvideos extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model('profile_model','',TRUE);
		$this->load->model('admin_model','',TRUE);
		$this->load->model('videos_model','',TRUE);
		$this->load->library('table'); 
	}
	
	function index()
	{
		if($this->session->userdata('adlog_in'))
   		{
     		$session_data = $this->session->userdata('adlog_in');
     		$data['username'] = $session_data['username'];
			$data['memberid'] = $session_data['id'];
			$data['membername'] = $this->profile_model->GetMemberName($session_data['id']);
			
			$tmpl = array('table_open' => '<table class="sortable" id="memberstable">');
			$this->table->set_template($tmpl);
			$this->table->set_heading('Title','Description', 'Created', '');
			
			$this->load->view('header',$data);
     		$this->load->view('allvideos_view', $data);
			$this->load->view('footer');
   		}
   		else
   		{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
   		}

	}
	
	 public function delVideo(){
        
        $ide  = isset($_GET['ide'])?$_GET['ide']:'';
        
        $ret = $this->videos_model->DeleteVideo($ide);
        echo json_encode($ret);
    }
	
	public function getAllUploadVideos() {
            
            if($this->session->userdata('adlog_in')){
                
                $ret =  $this->videos_model->GetAllUploadVideos();
                echo $ret;
                
            }else{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
            }
            
        }
		
}
?>

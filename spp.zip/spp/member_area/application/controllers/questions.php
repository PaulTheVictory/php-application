<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

session_start(); //we need to call PHP's session object to access it through CI

class Questions extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model('user_model','',TRUE);
		$this->load->model('profile_model','',TRUE);
		$this->load->model('admin_model','',TRUE);
	}
	
	function index()
	{
		if($this->session->userdata('adlog_in'))
   		{
     		$session_data = $this->session->userdata('adlog_in');
     		$data['username'] = $session_data['username'];
			$data['memberid'] = $session_data['id'];
			$data['membername'] = $this->profile_model->GetMemberName($session_data['id']);
			
			$subjectid = $_GET['id'];			
			$data['questions'] = $this->admin_model->GetQuestionsBySubject($subjectid);
			
			$this->load->view('header',$data);
     		$this->load->view('questions_view', $data);
			$this->load->view('footer');
   		}
   		else
   		{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
   		}

	}
	
	public function addQuestion() {
        
		$subjectid  = isset($_GET['subjectid'])?$_GET['subjectid']:'';		
		$question  = isset($_GET['question'])?$_GET['question']:'';		
		$option1  = isset($_GET['option1'])?$_GET['option1']:'';		
		$option2  = isset($_GET['option2'])?$_GET['option2']:'';		
		$option3  = isset($_GET['option3'])?$_GET['option3']:'';		
		$option4  = isset($_GET['option4'])?$_GET['option4']:'';		
		$answer  = isset($_GET['answer'])?$_GET['answer']:'';			        
        
        $ret = $this->admin_model->AddQuestion($subjectid,$question,$option1,$option2,$option3,$option4,$answer);
        echo json_encode($ret);
    }
	
	public function deleteSubject() {
        
		$subjectid = isset($_GET['subjectid'])?$_GET['subjectid']:'';						        
        
        $ret = $this->admin_model->DeleteSubject($subjectid);
        echo json_encode($ret);
    }
	
	public function deleteQuestion() {
        
		$questid = isset($_GET['questid'])?$_GET['questid']:'';						        
        
        $ret = $this->admin_model->DeleteQuestion($questid);
        echo json_encode($ret);
    }
		
}
?>

<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

session_start(); //we need to call PHP's session object to access it through CI

class Allcase extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model('user_model','',TRUE);
		$this->load->model('profile_model','',TRUE);
		$this->load->model('admin_model','',TRUE);
                $this->load->library('table'); 
	}
	
	function index()
	{
		if($this->session->userdata('adlog_in'))
   		{
     		$session_data = $this->session->userdata('adlog_in');
     		$data['username'] = $session_data['username'];
			$data['memberid'] = $session_data['id'];
			$data['membername'] = $this->profile_model->GetMemberName($session_data['id']);
			$data['allcases'] = $this->admin_model->GetAllCasesCount();
                        
                        $tmpl = array('table_open' => '<table class="sortable" id="memberstable">');
                                $this->table->set_template($tmpl);
                                $this->table->set_heading('Id','Name','Mobile', 'Author Name 1', 'Author Name 2','Tooth Number');
                               
			$this->load->view('header',$data);
     		$this->load->view('allcase_view', $data);
			$this->load->view('footer');
			
   		}
   		else
   		{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
   		}

	}
        
        public function getAllCaseLists() {
            
            if($this->session->userdata('adlog_in')){
                
                $ret =  $this->admin_model->GetAllCases_filter();
                echo $ret;
                
            }else{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
            }
            
        }
		
}
?>

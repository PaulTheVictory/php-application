<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

session_start(); //we need to call PHP's session object to access it through CI

class Questionpapers extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->helper('url');
			$this->load->helper('download');
        $this->load->helper('file');
	}
	
	function index()
	{
		if($this->session->userdata('adlog_in'))
   		{
     		$session_data = $this->session->userdata('adlog_in');
 
            if($this->uri->segment(2))
            {
                $final_pat_path = get_dir_file_info('./questionpapers');
              
               // $data   = file_get_contents($final_pat_path[$this->uri->segment(2)]["server_path"]);
            }
            $name   = $this->uri->segment(2);
            header("Content-type: application/pdf");
            echo read_file($final_pat_path[$this->uri->segment(2)]["server_path"]);
            //force_download($name, $data);
   		}
   		else
   		{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
   		}

	}
	
	
		
}
?>

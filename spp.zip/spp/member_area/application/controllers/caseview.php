<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

session_start(); //we need to call PHP's session object to access it through CI

class Caseview extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model('user_model','',TRUE);
		$this->load->model('profile_model','',TRUE);
		$this->load->model('admin_model','',TRUE);
	}
		
	function index()
	{
		if($this->session->userdata('adlog_in'))
   		{
     		$session_data = $this->session->userdata('adlog_in');
     		$data['username'] = $session_data['username'];
			$data['memberid'] = $session_data['id'];
			$data['membername'] = $this->profile_model->GetMemberName($session_data['id']);
			
			$id = isset($_GET['id'])?$_GET['id']:'';
			$data['action'] = isset($_GET['action'])?$_GET['action']:'';
			
			if($id==""){
				redirect('home', 'refresh');
			}
						
			$data['casedetails'] = $this->profile_model->NewCaseDetails($id);
			
				$this->load->view('header',$data);
				$this->load->view('caseview_view',$data);	
				$this->load->view('footer');
   		}
		else if($this->session->userdata('logged_in'))
   		{
     		$session_data = $this->session->userdata('logged_in');
     		$data['username'] = $session_data['username'];
			$data['memberid'] = $session_data['id'];
			$data['membername'] = $this->profile_model->GetMemberName($session_data['id']);
			$data['memberbio'] = $this->profile_model->GetMemberBio($session_data['id']);
			
			$id = isset($_GET['id'])?$_GET['id']:'';
			$cd = isset($_GET['cd'])?$_GET['cd']:'';
			
			if($id==""){
				redirect('home', 'refresh');
			}
						
			$data['casedetails'] = $this->profile_model->NewCaseDetails($id);
			
			if($cd=="view"){
				$this->load->view('header',$data);
				$this->load->view('casedetails_view',$data);	
				$this->load->view('footer');
			}else{
				redirect('home', 'refresh');
			}
   		}
   		else
   		{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
   		}

	}
	
}
?>

<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

session_start(); //we need to call PHP's session object to access it through CI

class Editvideo extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model('profile_model','',TRUE);
		$this->load->model('admin_model','',TRUE);
		$this->load->model('videos_model','',TRUE);
	}
	
	function index()
	{
		if($this->session->userdata('adlog_in'))
   		{
     		$session_data = $this->session->userdata('adlog_in');
     		$data['username'] = $session_data['username'];
			$data['memberid'] = $session_data['id'];
			$data['membername'] = $this->profile_model->GetMemberName($session_data['id']);
			
			$id = isset($_GET['id'])?$_GET['id']:'';
			
			if($id==""){
				redirect('allvideos', 'refresh');
			}
			
			$data['videodetail'] = $this->videos_model->GetVideoDetails($id);
			
			$this->load->view('header',$data);
     		$this->load->view('editvideo_view', $data);
			$this->load->view('footer');
   		}
   		else
   		{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
   		}

	}
	
	public function replaceVideo() {
        
		if($this->session->userdata('adlog_in'))
   		{
			$title  = isset($_POST['title'])?$_POST['title']:'';		
			$description  = isset($_POST['description'])?$_POST['description']:'';
			$videoid  = isset($_POST['videoid'])?$_POST['videoid']:'';
			$action  = isset($_POST['action'])?$_POST['action']:'';
			
			//print_r($_FILES);exit;
			
				$file = "";
			if($action=="video")
			{
			
				if(!file_exists($_FILES['upload']['tmp_name']) || !is_uploaded_file($_FILES['upload']['tmp_name'])){
					$ret = array('0'=>'Upload Error');
					echo json_encode($ret);
					exit;
				}
				else{
					$file = $_FILES;
				}
				
			}

			$ret = $this->videos_model->ReplaceVideo($title,$description,$videoid,$file,$action);
			echo json_encode($ret);
		}
   		else
   		{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
   		}
    }
		
}
?>

<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Memberpage extends CI_Controller {

	function __construct()
	{
		parent::__construct();		
		$this->load->model('findspecialist_model','',TRUE);
		$this->load->model('connections_model','',TRUE);
	}
	
	function index()
	{
		$memberid = $_GET['id'];
		$data['membername'] = $this->findspecialist_model->GetMemberName($memberid);
		$data['memberprofile'] = $this->findspecialist_model->GetMemberProfile($memberid);
		$data['memberid'] = $memberid;
		
		$data['login_memberid'] = "";
		$data['connectionstatus'] = "";
		
		if($this->session->userdata('logged_in'))
		{
			$session_data = $this->session->userdata('logged_in');
			$data['login_memberid'] = $session_data['id'];
		
			$data['connectionstatus'] = $this->connections_model->GetIsConnected($session_data['id'],$memberid);
		}
		
		if($data['membername']['name']!=""){
			$this->load->view('header');
			$this->load->view('memberpage_view', $data);	
			$this->load->view('footer');
		}else{
			$this->load->view('header');
			$this->load->view('errormemberpage_view', $data);	
			$this->load->view('footer');
		}
					
		
	}
	
	public function sendConnectionRequest() {
        
        $session_data = $this->session->userdata('logged_in');
		$login_memberid = $session_data['id'];
		
        $memberid  = isset($_GET['memberid'])?$_GET['memberid']:'';              	        
        
        $ret = $this->connections_model->SendConnectionRequest($login_memberid,$memberid);
        echo json_encode($ret);
    }
	
	public function cancelSentRequest() {
        
        $session_data = $this->session->userdata('logged_in');
		$login_memberid = $session_data['id'];
		
        $memberid  = isset($_GET['memberid'])?$_GET['memberid']:'';              	        
        
        $ret = $this->connections_model->CancelSentRequest($login_memberid,$memberid);
        echo json_encode($ret);
    }
	
	public function cancelReceivedRequest() {
        
        $session_data = $this->session->userdata('logged_in');
		$login_memberid = $session_data['id'];
		
        $memberid  = isset($_GET['memberid'])?$_GET['memberid']:'';              	        
        
        $ret = $this->connections_model->CancelReceivedRequest($login_memberid,$memberid);
        echo json_encode($ret);
    }
	
	public function acceptReceivedRequest() {
        
        $session_data = $this->session->userdata('logged_in');
		$login_memberid = $session_data['id'];
		
        $memberid  = isset($_GET['memberid'])?$_GET['memberid']:'';              	        
        
        $ret = $this->connections_model->AcceptReceivedRequest($login_memberid,$memberid);
        echo json_encode($ret);
    }
	
	public function removeConnection() {
        
        $session_data = $this->session->userdata('logged_in');
		$login_memberid = $session_data['id'];
		
        $memberid  = isset($_GET['memberid'])?$_GET['memberid']:'';              	        
        
        $ret = $this->connections_model->RemoveConnection($login_memberid,$memberid);
        echo json_encode($ret);
    }
}
?>

<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

use \setasign\Fpdi;

class Generateidcard extends CI_Controller {

	function __construct()
	{
		parent::__construct();		
		$this->load->model('findspecialist_model','',TRUE);
		$this->load->model('admin_model','',TRUE);
                 $this->load->helper('file');
	}
	
	function index()
	{
		if($this->session->userdata('adlog_in'))
   		{
			$memberid = $_GET['id'];
			$data['memberid'] = $memberid;
			$data['membername'] = $this->admin_model->GetMemberName($memberid);
			$data['memberprofile'] = $this->admin_model->GetMemberProfile($memberid);
			
			if($data['membername']['name']!=""){
				$this->load->view('generateidcard_view', $data);
			
			}else{
				$this->load->view('header');
				$this->load->view('errormemberpage_view', $data);	
				$this->load->view('footer');
			}
			
		}
		else
   		{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
   		}
	}
        
        
        function showIdcard(){
            
            if($this->session->userdata('adlog_in')) {
         
				$memberid = $_GET['id'];
				$membername = $this->admin_model->GetMemberName($memberid);
				$memberprofile = $this->admin_model->GetMemberProfile($memberid);
				
                $name = $membername['name'];
                $userid = $membername['userid'];
                $type = $membername['role'];
                $type = ucfirst(strtolower($type));
                $imglink = $membername['profileimg'];
                $doj = $membername['doj'];
				
				$fulladdress = "";
             
                require_once(FCPATH.'fpdf/fpdf.php');
				require_once(FCPATH.'FPDI/src/autoload.php');
								
				// initiate FPDI
				$pdf = new Fpdi\Fpdi();
				
				// get the page count
				$pageCount = $pdf->setSourceFile(FCPATH.'/docs/idcard-front.pdf');
               
                              
              	// iterate through all pages
				for ($pageNo = 1; $pageNo <= $pageCount; $pageNo++) {
					// import a page
					$templateId = $pdf->importPage($pageNo);

					//$pdf->AddFont('Montserrat-SemiBold','','Montserrat-SemiBold.php');

					$pdf->AddPage();
					// use the imported page and adjust the page size
					$pdf->useTemplate($templateId, 0, 0, 200, 100, ['adjustPageSize' => true]);

					$pdf->AddFont('Montserrat-Bold','','Montserrat-Bold.php');
					$pdf->SetFont('Montserrat-Bold','','9');
					$pdf->SetTextColor('255' ,'255' ,'255');

					$pdf->SetXY(3.9, 19);
					$pdf->MultiCell(140, 6, $name, 0, 'L', false);
					
					$pdf->AddFont('Montserrat-SemiBold','','Montserrat-SemiBold.php');
					$pdf->SetFont('Montserrat-SemiBold','','8');
					$pdf->SetTextColor('0' ,'255' ,'255');
					
					$pdf->SetXY(3.9, 35);
					$pdf->MultiCell(20, 6, $userid, 0, 'L', false);
					//$pdf->Write(1, $userid);

					$pdf->SetXY(3.9, 0);
					$pdf->MultiCell(0, 0, $type, 0, 'L', false);

					$pdf->SetXY(3.9, 0);
					$pdf->MultiCell(0, 0, $fulladdress, 0, 'L', false);


					$photo_ht = '../docs/members/'.$imglink;
					if(file_exists($photo_ht)) $pdf->Image($photo_ht, 59, 8, 25);

					//$pdf->Write(8, 'Hall Ticket');
				}
				
				$mergefile = FCPATH.'docs/idcard-back.pdf'; 
		
				if(file_exists($mergefile)){

					$mergepageCount = $pdf->setSourceFile($mergefile);
					for ($mi = 0; $mi < $mergepageCount; $mi++) {
						$tpl = $pdf->importPage($mi + 1);
						$pdf->addPage();
						$pdf->useTemplate($tpl, ['adjustPageSize' => true]);
					}

				}
				
				//$pdfoutput = "D";  
				$pdfoutput = "I";

				$pdf->Output($pdfoutput,"IDCard_".$userid.".pdf"); 
				
               
            }
            
       }
	
	
	function showIdcard_old(){
            
            if($this->session->userdata('adlog_in')) {
         
                $memberid = $_GET['memid'];
				$membername = $this->admin_model->GetMemberName($memberid);
				$memberprofile = $this->admin_model->GetMemberProfile($memberid);
				
                $name = $membername['name'];
                $userid = $membername['userid'];
                $type = $membername['role'];
                $type = ucfirst(strtolower($type));
                $imglink = $membername['profileimg'];
                $doj = $membername['doj'];
                $contactaddress = $memberprofile['contactaddress'];
                $contactaddress2 = $memberprofile['contactaddress2'];
                $contactcity = $memberprofile['contactcity'];
                $contactstate = $memberprofile['contactstate'];
                $contactpin = $memberprofile['contactpin'];
				
				
				$name = str_replace(array("Dr.","dr.","Dr. ","dr.","Dr ","dr "),"",$name);
				$name = "Dr. ".$name;
				
				
				$fulladdress = $cityaddress = "";
				
				if($contactaddress!="") $fulladdress = $contactaddress."\n";
				if($contactaddress2!="") $fulladdress .= $contactaddress2.", \n";
				if($contactcity!="") $cityaddress .= $contactcity.", ";
				if($contactstate!="") $cityaddress .= $contactstate.", ";
				if($contactpin!="") $cityaddress .= $contactpin;
				
				$fulladdress = $fulladdress.$cityaddress;
				
				$fulladdress = ucwords(wordwrap($fulladdress, 28, "\n"));
				
				if($doj!="") $doj = date("M d, Y",strtotime($doj)); else $doj = "-";
             
               // Set the content-type
               header('Content-Type: image/png');
               
                $src_path = get_dir_file_info('../docs/');
                $src_path = $src_path['members']['server_path']."/idcard_front.jpg"; 
                if ( is_readable($src_path)) {
                $info = getimagesize($src_path);
                if ($info !== FALSE) {
                   
                    $im = @imagecreatefromjpeg($src_path);
                    
                  }
                }
                
                
                
                
                $src_path1 = get_dir_file_info('../docs/');
                $src_path1 = $src_path1['members']['server_path']."/".$imglink;
                $src_path_thumb = get_dir_file_info('../docs/');
                $src_path_thumb = $src_path_thumb['members']['server_path']."/tempid.png"; 
                /*if ( is_readable($src_path1)) {
                    
                $config['image_library'] = 'gd2';
                $config['source_image'] = $src_path1;
                $config['create_thumb'] = TRUE;
                $config['maintain_ratio'] = TRUE;
                $config['width'] = 318;
                $config['height'] = 318;
                $config['new_image'] = $src_path_thumb;
                $config['thumb_marker'] = '';

                 $this->load->library('image_lib', $config);
               // $this->image_lib->initialize($config);
                 $oldUmask = umask(0);
                $this->image_lib->resize();  
                 umask($oldUmask);
                    
                 //    $type   = exif_imagetype($src_path_thumb);
                 //   echo $type;
                 //   exit();
                
                $info = getimagesize($src_path1);
                if ($info !== FALSE) {
                   
                    $type1   = strstr($imglink, '.');
                    if($type1 ==".png" || $type1 == ".PNG") {
                        $dst = @imagecreatefrompng($src_path_thumb);
                    } else {
                        $dst = @imagecreatefromjpeg($src_path_thumb);
                    }
                    
                    
                    
                  }
                  
                }*/
                
               // Create some colors
               $black = imagecolorallocate($im, 255, 255, 255);
               
                $src_font = get_dir_file_info('../docs/');
                $fontbold = $src_font['members']['server_path']."/Montserrat-Bold.ttf"; 
				
				$fontsemibold = $src_font['members']['server_path']."/Montserrat-SemiBold.ttf"; 
           
          
              // Add the text
               imagettftext($im, 26, 0, 56, 295, $black, $fontbold, ucwords($name));

               imagettftext($im, 20, 0, 51, 425, $black, $fontsemibold, $userid);
				
			   imagettftext($im, 20, 0, 338, 425, $black, $fontsemibold, $doj);

               imagettftext($im, 20, 0, 52, 510, $black, $fontsemibold, $type." Member");
				
			   imagettftext($im, 17, 0, 338, 510, $black, $fontsemibold, $fulladdress);
				
				if ( is_readable($src_path1)) {
				
					$newwidth = 318;
					$newheight = 318;

					$image_s = imagecreatefromstring(file_get_contents($src_path1));
					$width = imagesx($image_s);
					$height = imagesy($image_s);
					$image = imagecreatetruecolor($newwidth, $newheight);
					imagealphablending($image, true);
					imagecopyresampled($image, $image_s, 0, 0, 0, 0, $newwidth, $newheight, $width, $height);
					//create masking
					$mask = imagecreatetruecolor($newwidth, $newheight);
					$transparent = imagecolorallocate($mask, 255, 0, 0);
					imagecolortransparent($mask,$transparent);
					imagefilledellipse($mask, $newwidth/2, $newheight/2, $newwidth, $newheight, $transparent);
					$red = imagecolorallocate($mask, 0, 0, 0);
					imagecopymerge($image, $mask, 0, 0, 0, 0, $newwidth, $newheight, 100);
					imagecolortransparent($image,$red);
					imagefill($image, 0, 0, $red);
					
				}

               imagecopymerge($im, $image, 629, 133, 0, 0, 318, 318, 100);
               
               //imagecopymerge($im, $im_second, 0, 640, 0, 0, 1028, 638, 100);
               

               
               imagepng($im);
               imagedestroy($im);
			   imagedestroy($image);
			   imagedestroy($mask);
               //unlink($src_path_thumb);
               
            }
            
       }
	
	
}
?>

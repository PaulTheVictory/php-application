<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

session_start(); //we need to call PHP's session object to access it through CI

class Collegehome extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model('college_model','',TRUE);
	}
	
	function index()
	{
		if($this->session->userdata('college_log_in'))
   		{
     		$session_data = $this->session->userdata('college_log_in');
     		$data['username'] = $session_data['username'];
			$data['collegeid'] = $session_data['id'];
			$data['collegedetails'] = $this->college_model->GetCollegeDetails($session_data['id']);
			$data['stafflist'] = $this->college_model->GetCollegeStaffs($session_data['id']);
					
			$this->load->view('header',$data);
     		$this->load->view('collegehome_view', $data);
			$this->load->view('footer');
   		}
		else
   		{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
   		}

	}
	
	function logout()
 	{
		$sessionid = $this->session->userdata('session_id');
		$this->user_model->endSession($sessionid);
   		$this->session->unset_userdata('logged_in');
		$this->session->unset_userdata('adlog_in');
		$this->session->unset_userdata('college_log_in');
		
   		$this->session->sess_destroy();
   		redirect(''.base_url().'', 'refresh');
 	}
}
?>

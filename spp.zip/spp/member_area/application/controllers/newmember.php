<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

session_start(); //we need to call PHP's session object to access it through CI

class Newmember extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model('user_model','',TRUE);
		$this->load->model('profile_model','',TRUE);
		$this->load->model('admin_model','',TRUE);
	}
	
	function index()
	{
		if($this->session->userdata('adlog_in'))
   		{
     		$session_data = $this->session->userdata('adlog_in');
     		$data['username'] = $session_data['username'];
			$data['memberid'] = $session_data['id'];
			$data['membername'] = $this->profile_model->GetMemberName($session_data['id']);
			$this->load->view('header',$data);
     		$this->load->view('newmember_view', $data);
			$this->load->view('footer');
   		}
   		else
   		{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
   		}

	}
	
	public function createMember() {
        
		$name  = isset($_GET['name'])?$_GET['name']:'';
		$userid  = isset($_GET['userid'])?$_GET['userid']:'';
		$password  = isset($_GET['password'])?$_GET['password']:'';
		$role  = isset($_GET['role'])?$_GET['role']:'';		
		$doj  = isset($_GET['doj'])?$_GET['doj']:'';
        $mobile  = isset($_GET['mobile'])?$_GET['mobile']:'';
        $phone  = isset($_GET['phone'])?$_GET['phone']:'';
        $email = isset($_GET['email'])?$_GET['email']:'';
		$gender = isset($_GET['gender'])?$_GET['gender']:'';
        $dob = isset($_GET['dob'])?$_GET['dob']:'';
		$address = isset($_GET['address'])?$_GET['address']:'';
		$contactaddress = isset($_GET['contactaddress'])?$_GET['contactaddress']:'';
		$contactstate = isset($_GET['contactstate'])?$_GET['contactstate']:'';
		$contactpin = isset($_GET['contactpin'])?$_GET['contactpin']:'';
		$qualification = isset($_GET['qualification'])?$_GET['qualification']:'';
		$college = isset($_GET['college'])?$_GET['college']:'';
		$designation = isset($_GET['designation'])?$_GET['designation']:'';
		$clinic = isset($_GET['clinic'])?$_GET['clinic']:'';
		$clinicphone = isset($_GET['clinicphone'])?$_GET['clinicphone']:'';
		$payamount = isset($_GET['payamount'])?$_GET['payamount']:'';
		$paymode = isset($_GET['paymode'])?$_GET['paymode']:'';
		$payid = isset($_GET['payid'])?$_GET['payid']:'';
		
		$sameaddress = isset($_GET['sameaddress'])?$_GET['sameaddress']:'';
		$address2 = isset($_GET['address2'])?$_GET['address2']:'';
		$city = isset($_GET['city'])?$_GET['city']:'';
		$state = isset($_GET['state'])?$_GET['state']:'';
		$pincode = isset($_GET['pincode'])?$_GET['pincode']:'';
		$contactaddress2 = isset($_GET['contactaddress2'])?$_GET['contactaddress2']:'';
		$contactcity = isset($_GET['contactcity'])?$_GET['contactcity']:'';
		$clinicaddress2 = isset($_GET['clinicaddress2'])?$_GET['clinicaddress2']:'';
		$cliniccity = isset($_GET['cliniccity'])?$_GET['cliniccity']:'';
		$clinicstate = isset($_GET['clinicstate'])?$_GET['clinicstate']:'';
		$clinicpin = isset($_GET['clinicpin'])?$_GET['clinicpin']:'';
		
		$encrypted = $this->admin_model->encrypt($password, "adi");					        
        
        $ret = $this->admin_model->CreateMember($name,$userid,$password,$role,$doj,$mobile,$phone,$email,$gender,$dob,$address,$contactaddress,$contactstate,$contactpin,$qualification,$college,$designation,$clinic,$clinicphone,$payamount,$paymode,$payid,$encrypted,$sameaddress,$address2,$city,$state,$pincode,$contactaddress2,$contactcity,$clinicaddress2,$cliniccity,$clinicstate,$clinicpin);
        echo json_encode($ret);
    }
		
}
?>

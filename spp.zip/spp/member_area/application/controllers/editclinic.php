<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class EditClinic extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model('user_model','',TRUE);
		$this->load->model('profile_model','',TRUE);
		$this->load->model('admin_model','',TRUE);
		$this->load->model('findspecialist_model','',TRUE);
	}
	
	function index()
	{
		if($this->session->userdata('logged_in'))
   		{
     		$session_data = $this->session->userdata('logged_in');
     		$data['username'] = $session_data['username'];
			$data['memberid'] = $session_data['id'];
			$data['back'] = 0;
			$data['verify'] = 1;
		}
		else if($this->session->userdata('adlog_in'))
		{
			$session_data['id'] = isset($_GET['memid'])?$_GET['memid']:'';
			$data['back'] = 1;
			$data['verify'] = 0;
		}
		else
		{
			redirect('login', 'refresh');
		}


			$data['membername'] = $this->profile_model->GetMemberName($session_data['id']);
			$data['memberprofile'] = $this->profile_model->GetMemberProfile($session_data['id']);
				
			
			if($data['membername']['status']!="VERIFIED" || $data['membername']['profileimg']=="dp.jpg")
			{
				$data['verify'] = 0;
			}
				
				$clinicid = isset($_GET['cid'])?$_GET['cid']:'';				
				$data['clinicdetail'] = $this->findspecialist_model->GetClinicDetail($clinicid);
				
				$data['timing'] = $this->findspecialist_model->GetDoctorTimings($data['membername']['memberid'],$clinicid);
				
				//$data['stateoptions'] = $this->findspecialist_model->GetSelectOptions('state');
				$data['cityoptions'] = $this->findspecialist_model->GetSelectOptions('city');
				$data['areaoptions'] = $this->findspecialist_model->GetSelectOptions('area');
									
				$this->load->view('header', $data);
				$this->load->view('editclinic_view', $data);
				$this->load->view('footer');
		
	}
	
	public function updateClinic() {
		
		if($this->session->userdata('logged_in')  || $this->session->userdata('adlog_in'))
   		{
			
		/*$session_data = $this->session->userdata('logged_in');
		$data['username'] = $session_data['username'];
		$data['memberid'] = $session_data['id'];*/
        
		$clinicid  = isset($_GET['clinicid'])?$_GET['clinicid']:'';
			$memberid  = isset($_GET['memberid'])?$_GET['memberid']:'';	
		$cname  = isset($_GET['cname'])?$_GET['cname']:'';		
		$cemail  = isset($_GET['cemail'])?$_GET['cemail']:'';
		$cstdcode  = isset($_GET['cstdcode'])?$_GET['cstdcode']:'';
		$clandline  = isset($_GET['clandline'])?$_GET['clandline']:'';
		$cmobile  = isset($_GET['cmobile'])?$_GET['cmobile']:'';
		$cwebsite  = isset($_GET['cwebsite'])?$_GET['cwebsite']:'';
		$cspeciality  = isset($_GET['cspeciality'])?$_GET['cspeciality']:'Dental Clinic';
		$cstate  = isset($_GET['cstate'])?$_GET['cstate']:'';		
		$ccity  = isset($_GET['ccity'])?$_GET['ccity']:'';
		$cpincode  = isset($_GET['cpincode'])?$_GET['cpincode']:'';
		$carea  = isset($_GET['carea'])?$_GET['carea']:'';
		$caddress  = isset($_GET['caddress'])?$_GET['caddress']:'';
		$clandmark  = isset($_GET['clandmark'])?$_GET['clandmark']:'';
		$clat  = isset($_GET['clat'])?$_GET['clat']:'';
		$clong  = isset($_GET['clong'])?$_GET['clong']:'';
        
        $ret = $this->findspecialist_model->UpdateClinic($clinicid,$cname,$cemail,$cstdcode,$clandline,$cmobile,$cwebsite,$cspeciality,$cstate,$ccity,$cpincode,$carea,$caddress,$clandmark,$clat,$clong,$memberid);
        echo json_encode($ret);
		
		}
			else
			{
				redirect('login', 'refresh');
			}
    }
	
	public function updateMemberTiming() {
		
		if($this->session->userdata('logged_in'))
   		{
        
		$memberid  = isset($_GET['memberid'])?$_GET['memberid']:'';
		$clinicid  = isset($_GET['clinicid'])?$_GET['clinicid']:'';
		$timing  = isset($_GET['timing'])?$_GET['timing']:'';
        
        $ret = $this->findspecialist_model->UpdateMemberTiming($memberid,$clinicid,$timing);
        echo json_encode($ret);
		
		}
		else
		{
			redirect('login', 'refresh');
		}
			
    }
	
	public function deleteClinic() {
		
		if($this->session->userdata('logged_in') || $this->session->userdata('adlog_in'))
   		{
			        
		$clinicid  = isset($_GET['clinicid'])?$_GET['clinicid']:'';
        
        $ret = $this->findspecialist_model->DeleteClinic($clinicid);
        echo json_encode($ret);
		
		}
			else
			{
				redirect('login', 'refresh');
			}
    }
	
	public function removeDoctorFromClinic() {
		
		if($this->session->userdata('logged_in')  || $this->session->userdata('adlog_in'))
   		{
			
		/*$session_data = $this->session->userdata('logged_in');
		$data['username'] = $session_data['username'];
		$data['memberid'] = $session_data['id'];*/
        
		$doctorid  = isset($_GET['doctorid'])?$_GET['doctorid']:'';
		$clinicid  = isset($_GET['clinicid'])?$_GET['clinicid']:'';
        
        $ret = $this->findspecialist_model->RemoveClinicFromDoctor($doctorid,$clinicid);
        echo json_encode($ret);
		
		}
			else
			{
				redirect('login', 'refresh');
			}
    }
	
	public function uploadClinicProfilePhoto() {
		
		$clinicid  = isset($_POST['clinicid'])?$_POST['clinicid']:'';	
		
		if($clinicid!=""){
	
			if(isset($_FILES["uploadedphoto"]))
			{
				$validExtensions = array('.jpg', '.jpeg', '.gif', '.png', '.JPG', '.JPEG', '.GIF', '.PNG');
				$fileExtension = strrchr($_FILES['uploadedphoto']['name'], ".");
				$fileName = $clinicid."".$fileExtension;
				$destinationfull = dirname(FCPATH).'/docs/clinicprofile/full/' . $fileName;
				$destinationthumb = dirname(FCPATH).'/docs/clinicprofile/thumb/' . $fileName;
				
				if (in_array($fileExtension, $validExtensions)) {
					
					/* Get original image x y*/
					list($w, $h) = getimagesize($_FILES['uploadedphoto']['tmp_name']);
					
					$imgString = file_get_contents($_FILES['uploadedphoto']['tmp_name']);
					
					$image = imagecreatefromstring($imgString);
  					$tmp = imagecreatetruecolor($w, $h);
					// set background to white
					$white = imagecolorallocate($tmp, 255, 255, 255);
					imagefill($tmp, 0, 0, $white);
					
  					imagecopyresampled($tmp, $image, 0, 0, 0, 0, $w, $h, $w, $h);
					
					if(file_exists($destinationfull))unlink($destinationfull);
					if(file_exists($destinationthumb))unlink($destinationthumb);
					
					$resultfull = imagejpeg($tmp,$destinationfull,70);
					$resultthumb = imagejpeg($tmp,$destinationthumb,70);
				
					if($resultfull&&$resultthumb){
				    	
						$ret = $this->findspecialist_model->UploadClinicProfilePhoto($clinicid,$fileName);
						
						//if($ret=="success"){
				   		//	echo "success";
						//}else{
						//	echo "fail";
						//}
						
					}else{
						//echo "fail";
					}
				
				}else{
					
					//echo "invalidfile";
					
				}
			
			}
			
		}
		
		redirect(base_url()."editclinic?cid=".$clinicid, 'location');
		
	}
	
	public function cropClinicProfilePhoto() {
		
		$clinicid  = isset($_POST['clinicid'])?$_POST['clinicid']:'';	
		$fileName  = isset($_POST['filename'])?$_POST['filename']:'';
		
		$respwidth = isset($_POST['respwidth'])?$_POST['respwidth']:'';
		$respheight = isset($_POST['respheight'])?$_POST['respheight']:'';
		
		if($clinicid!="" && $fileName!="" && $respwidth!="" && $respheight!=""){
	
			$targ_w = 200;
			$targ_h = 200;
			$jpeg_quality = 100;
			$output_filename = dirname(FCPATH).'/docs/clinicprofile/thumb/' . $fileName;			
		
			$src = dirname(FCPATH).'/docs/clinicprofile/full/' . $fileName;
			$img_r = imagecreatefromjpeg($src);			
			
			list($orig_w, $orig_h) = getimagesize($src);
			$temp_r = imagecreatetruecolor( $respwidth, $respheight );
			imagecopyresampled($temp_r,$img_r,0,0,0,0,$respwidth,$respheight,$orig_w,$orig_h);
			
			$dst_r = imagecreatetruecolor( $targ_w, $targ_h );
			imagecopyresampled($dst_r,$temp_r,0,0,$_POST['x'],$_POST['y'],$targ_w,$targ_h,$_POST['w'],$_POST['h']);
			
			unlink($output_filename);
			
			$result = imagejpeg($dst_r,$output_filename,$jpeg_quality);
			
			if($result){
				
				//$ret = $this->user_model->CropClinicProfilePhoto($clinicid,$fileName);
				
				//if($ret=="success"){
				//	echo "success";
				//}else{
				//	echo "fail";
				//}
				
			}else{
				
				//echo "fail";
				
			}			
			
		}
		
		redirect(base_url()."editclinic?id=".$clinicid, 'location');
		
	}
	
	
}
?>

<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

session_start(); //we need to call PHP's session object to access it through CI

class Adminchangephoto extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model('user_model','',TRUE);
		$this->load->model('admin_model','',TRUE);
	}
	
	function index()
	{
		if($this->session->userdata('adlog_in'))
   		{
			
			$session_data = $this->session->userdata('adlog_in');
			$data['role'] = $session_data['role'];
			
     		$memberid = $_GET['id'];
			$data['memberid'] = $memberid;
			$data['membername'] = $this->admin_model->GetMemberName($memberid);
			$data['memberprofile'] = $this->admin_model->GetMemberProfile($memberid);
			
			$this->load->view('header',$data);
     		$this->load->view('adminchangephoto_view', $data);
			$this->load->view('footer');
		}
		else
   		{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
   		}

	}
	
		
}
?>

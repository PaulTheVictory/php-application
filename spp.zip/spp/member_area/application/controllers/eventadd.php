<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Eventadd extends CI_Controller {

	function __construct()
	{
		parent::__construct();		
		$this->load->model('findspecialist_model','',TRUE);
		$this->load->model('admin_model','',TRUE);
	}
	
	function index()
	{
		if($this->session->userdata('adlog_in'))
   		{
			$session_data = $this->session->userdata('logged_in');
     		$data['username'] = $session_data['username'];
			$data['memberid'] = $session_data['id'];
			$data['membername'] = $this->admin_model->GetMemberName($session_data['id']);
			
				$this->load->view('header');
				$this->load->view('eventadd_view', $data);	
				$this->load->view('footer');
			
		}
		else
   		{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
   		}
	}
	
	
public function addevent() {
		
	    $name  = isset($_GET['name'])?$_GET['name']:'';
		$place  = isset($_GET['place'])?$_GET['place']:'';
		$date  = isset($_GET['date'])?$_GET['date']:'';
		
		$ret = $this->admin_model->AddEvent($name,$place,$date);
        echo json_encode($ret);
		
}
	
		
}
?>

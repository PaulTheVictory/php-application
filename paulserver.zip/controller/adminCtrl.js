const Admin = require('../models/adminModels');
const Logs = require("../models/logsModels");
const mongoose = require("mongoose");
const uniqid = require('uniqid');
const asyncHandler = require('express-async-handler');
const { success, successToken } = require('../utils/response');
const { generateToken } = require("../config/jwtToken");


//Create Admin
const createAdmin = asyncHandler(async (req, res) => {
  try {
    const findEmail = await Admin.findOne({ email: req.body.email });
    const findPhone = await Admin.findOne({ phone: req.body.phone });
    if (findEmail || findPhone) {
      throw new Error("User Already Exists");
    } else {
      req.body.companycode = new mongoose.mongo.ObjectId()+uniqid();
      const newAdmin = await Admin.create(req.body);
      const createSession = await Logs.create({ userid: newAdmin?._id});
      if (newAdmin && createSession) {
        return successToken(res, 201, true, "Register Successfully", newAdmin,generateToken(newAdmin?._id),createSession?._id);
      } else {
        throw new Error("Please try again Later");
      }
    }
  } catch (err) {
    throw err;
  }
});

//Admin login
const loginAdmin = asyncHandler(async (req, res) => {
  try {
    const { email, password } = req.body;
    const findAdmin = await Admin.findOne({ email });
    if (findAdmin && (await findAdmin.isPasswordMatched(password))) {
      const createSession = await Logs.create({ userid: findAdmin?._id });
      if (createSession) {
        return successToken(res, 201, true, "Login Successfully", findAdmin,generateToken(findAdmin?._id),createSession?._id);
      } else {
        throw new Error("Please try again Later");
      }
    } else {
      throw new Error("Invalid Credentials");
    }
  } catch (error) {
    throw new Error(error);
  }
});

//Logout Admin
const logoutAdmin = asyncHandler(async (req, res) => {
  try {
    const { sessionid } = req.body;
    const formData = {
      outtime: Date.now(),
      status:'c',
    }
    const sessionCheck = await Logs.findById(sessionid);
    if (sessionCheck?.status == 'c') {
      throw new Error('Session already Logout!')
    } else {
      const sessionLogout = await Logs.findByIdAndUpdate(sessionid, formData, {
        new: true,
      });
      console.log("sessionLogout", sessionLogout);
      if (sessionLogout) {
        return success(res, 200, true, "Logout Successfully", sessionLogout);
      } else {
        throw new Error("Session Logout Failed");
      }
    }
  } catch (error) {
    throw new Error(error);
  }
});



module.exports = {
  createAdmin,
  loginAdmin,
  logoutAdmin,
};
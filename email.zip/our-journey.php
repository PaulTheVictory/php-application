<?php
/*Template Name:Our Journey*/
get_header();?>

<!--slider_section-->
<section class="slide_section">
	<div id="home_slider" class="carousel bs-slider slide control-round indicators-line" data-ride="carousel" data-pause="hover" data-interval="false">
		<div class="carousel-inner" role="listbox">
			<div class="item active">
				<img src="<?php echo esc_url(get_template_directory_uri());?>/images/banner/journey.png" alt="Banenr" class="desk_banner">
				<img src="<?php echo esc_url(get_template_directory_uri());?>/images/banner/journeym.png" alt="Banenr" class="mob_banner">
				<div class="slide-text">
					<div class="slide_text_left">
						<h2 data-animation="animated fadeInLeft">Serving healthy
products For
53 Years</h2>
						<a class="book" href="<?php echo get_site_url();?>/contact-us/" title="Send Enquiry"><button data-animation="animated fadeInLeft">Send Enquiry</button></a>
					</div>
					
				</div>
			</div>
			
			<!-- <a class="nav_left" href="#home_slider" role="button" data-slide="prev"></a>
			<a class="nav_right" href="#home_slider" role="button" data-slide="next"></a>  
			<ol class="nav_dots carousel-indicators">
				<li data-target="#home_slider" data-slide-to="0" class="active"></li>
				<li data-target="#home_slider" data-slide-to="1"></li>
			</ol> -->
		</div>
	</div>
</section>
<!--slider_section-->

<!--inner_aboutus_section-->

<div class="inner_aboutus_section">
	<div class="wrap_grid">
		<h1>We are in the journey of establishing
a healthy lifestyle</h1>
		<ul>
			<li>
				<div class="ourstory_box_align">
					<div class="ourstory_box_left">
						<img src="<?php echo esc_url(get_template_directory_uri()); ?>/images/about-us/j1.png" alt="Our Story">
					</div>
					<div class="ourstory_box_right">
						<div class="about_text">
							<span>1969</span>
						</div>
						<p><font>At 1969 </font>,, under the trade name of Jothi Vella Mundy, Mr.V. Pandian started this business
journey in Coimbatore as a wholesale trader of jaggery, jaggery powder, and palm
jaggery. Due to the hige support, another trade name was commenced to Gnanamalar
Vella Mundy in 1970.</p>
					</div>
				</div>
			</li>
			
			<li>
				<div class="ourstory_box_align">
					<div class="ourstory_box_left">
						<img src="<?php echo esc_url(get_template_directory_uri()); ?>/images/about-us/j2.png" alt="Our Story">
					</div>
					<div class="ourstory_box_right">
						<div class="about_text">
							<span>1985</span>
						</div>
						<p><font>At 1985</font> the business was taken over by his son Mr.V.P. Selvaraj. He expanded this
business to other states of India and made a strong presence establishing our trading
commerce as a well-known company</p>
					</div>
				</div>
			</li>
			<li>
				<div class="ourstory_box_align">
					<div class="ourstory_box_left">
						<img src="<?php echo esc_url(get_template_directory_uri()); ?>/images/about-us/j3.png" alt="Our Story">
					</div>
					<div class="ourstory_box_right">
						<div class="about_text">
							<span>2013</span>
						</div>
						<p>Later, Mr. Jerry Selvaraj further enlarged this business as a wholesaler of sesame,
groundnut seeds, and dried coconut (copra)<font> 2013</font>. He diversified his plan to build the
brand JyothisPure in Coimbatore in 2018 and was successful in doing so.
Owing to the huge response from the customers and the need for high-quality jaggery
powder, commenced the idea of establishing an online platform
NAATUSAKKARAI.COM to reach worldwide to benefit more people from our product.</p>
					</div>
				</div>
			</li>
			
		</ul>
	</div>
</div>

<!--inner_aboutus_section-->



<!--about_counter_section-->

<div class="about_counter_section">
	<div class="wrap_grid">
		<ul id="counter">
			<li>
				<img src="<?php echo esc_url(get_template_directory_uri()); ?>/images/about-us/i1.png" alt="Counter">
				<h4 class="count" data-count="30000000">0</h4>
				<p>Kg of Jaggery</p>
			</li>
			<li>
				<img src="<?php echo esc_url(get_template_directory_uri()); ?>/images/about-us/i2.png" alt="Counter">
				<h4 class="count" data-count="10000">0</h4>
				<p>Farmers</p>
			</li>
			<li>
				<img src="<?php echo esc_url(get_template_directory_uri()); ?>/images/about-us/i3.png" alt="Counter">
				<h4 class="count" data-count="100000">0</h4>
				<p>Customers Served</p>
			</li>
			<li>
				<img src="<?php echo esc_url(get_template_directory_uri()); ?>/images/about-us/i4.png" alt="Counter">
				<h4 class="count" data-count="59">0</h4>
				<p>Years of Service</p>
			</li>
		</ul>
	</div>
</div>

<!--about_counter_section-->




<!--parent_section-->


<section class="parent_section">
	<div class="wrap_grid">
		<div class="head_text">
			<h2>Our parent Companies</h2>
		</div>
		<ul>
			<li>
				<img src="<?php echo get_site_url();?>/wp-content/uploads/2022/05/2.png" alt="Our parent Companies" />
<!-- 				<p>Jothi Vella Mundy</p> -->
			</li>
			<li>
				<img src="<?php echo get_site_url();?>/wp-content/uploads/2022/05/1.png" alt="Our parent Companies" />
<!-- 				<p>Gnanamalar Vella Mundy</p> -->
			</li>
		</ul>
	</div>
</section>


<!--parent_section-->


































<?php
/*Template Name:Our Journey*/
get_footer();?>


<script>
	var counted = 0;
$(window).scroll(function() {

  var oTop = $('#counter').offset().top - window.innerHeight;
  if (counted == 0 && $(window).scrollTop() > oTop) {
    $('.count').each(function() {
      var $this = $(this),
        countTo = $this.attr('data-count');
      $({
        countNum: $this.text()
      }).animate({
          countNum: countTo
        },

        {

          duration: 2000,
          easing: 'swing',
          step: function() {
            $this.text(Math.floor(this.countNum));
          },
          complete: function() {
            $this.text(this.countNum);
            //alert('finished');
          }

        });
    });
    counted = 1;
  }

});
</script>
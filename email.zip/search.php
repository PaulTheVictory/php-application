<?php
/**
 * The template for displaying search results pages.
 *
 * @package WordPress
 * @subpackage Twenty_Fifteen
 * @since Twenty Fifteen 1.0
 */

get_header(); ?>


<?php 
		
		
		if($img2!=""){
		?>



<section class="slide_section">
	<div id="bootstrap-touch-slider" class="carousel bs-slider slide  control-round indicators-line" data-ride="carousel" data-pause="hover" data-interval="false">
		<div class="carousel-inner" role="listbox">
           	<?php if($img2!=""){?>
			<div class="item"> 
				<?php kd_mfi_the_featured_image( 'featured-image-2', 'post', 'full' ); ?>
			</div>
			<?php } ?>
			<?php if($img3!=""){?>
			<div class="item"> 
				<?php kd_mfi_the_featured_image( 'featured-image-3', 'post', 'full' ); ?>
			</div>
			<?php } ?>
			<?php if($img4!=""){?>
			<div class="item"> 
				<?php kd_mfi_the_featured_image( 'featured-image-4', 'post', 'full' ); ?>
			</div>
			<?php } ?>
			<?php if($img5!=""){?>
			<div class="item"> 
				<?php kd_mfi_the_featured_image( 'featured-image-5', 'post', 'full' ); ?>
			</div>
			<?php } ?>
			<?php if($img6!=""){?>
			<div class="item"> 
				<?php kd_mfi_the_featured_image( 'featured-image-6', 'post', 'full' ); ?>
			</div>
			<?php } ?>
			<?php if($img7!=""){?>
			<div class="item"> 
				<?php kd_mfi_the_featured_image( 'featured-image-7', 'post', 'full' ); ?>
			</div>
			<?php } ?>
			<?php if($img8!=""){?>
			<div class="item"> 
				<?php kd_mfi_the_featured_image( 'featured-image-2', 'post', 'full' ); ?>
			</div>
			<?php } ?>
			<?php if($img9!=""){?>
			<div class="item"> 
				<?php kd_mfi_the_featured_image( 'featured-image-2', 'post', 'full' ); ?>
			</div>
			<?php } ?>
			<?php if($img10!=""){?>
			<div class="item"> 
				<?php kd_mfi_the_featured_image( 'featured-image-2', 'post', 'full' ); ?>
			</div>
			<?php } ?>
			<!--<a class="carousel-control prev_carousel" href="#bootstrap-touch-slider" role="button" data-slide="prev"></a>
			<a class="carousel-control next_carousel" href="#bootstrap-touch-slider" role="button" data-slide="next"></a>
			<ol class="carousel-indicators">
				<li data-target="#bootstrap-touch-slider" data-slide-to="0" class="active"></li>
			</ol>-->
			<ol class="carousel-indicators">
				<?php if($img3!=""){?>
					<li data-target="#bootstrap-touch-slider" data-slide-to="0" class="active"><span>1</span></li>
				<?php } ?>
				<?php if($img3!=""){?>
					<li data-target="#bootstrap-touch-slider" data-slide-to="1"><span>2</span></li>
				<?php } ?>
				<?php if($img4!=""){?>
					<li data-target="#bootstrap-touch-slider" data-slide-to="2"><span>3</span></li>
				<?php } ?>
				<?php if($img5!=""){?>
					<li data-target="#bootstrap-touch-slider" data-slide-to="3"><span>4</span></li>
				<?php } ?>
				<?php if($img6!=""){?>
					<li data-target="#bootstrap-touch-slider" data-slide-to="4"><span>5</span></li>
				<?php } ?>
				<?php if($img7!=""){?>
					<li data-target="#bootstrap-touch-slider" data-slide-to="5"><span>6</span></li>
				<?php } ?>
				<?php if($img8!=""){?>
					<li data-target="#bootstrap-touch-slider" data-slide-to="6"><span>7</span></li>
				<?php } ?>
				<?php if($img9!=""){?>
					<li data-target="#bootstrap-touch-slider" data-slide-to="7"><span>8</span></li>
				<?php } ?>
				<?php if($img10!=""){?>
					<li data-target="#bootstrap-touch-slider" data-slide-to="8"><span>9</span></li>
				<?php } ?>
				
				
			</ol>
		</div>
	</div>
</section>

<!--slider_section-->








<?php		
		} else { 
		?>
			<img class="no_banner_class" src="<?php echo esc_url(get_template_directory_uri());?>/images/search_banner.png" />
		<?php
		} 				
		?>



<!--blog_menu-->

<section class="blog_menu">
	<div class="wrap_grid">
		<div class="blog_menu_head">
			<ul>
				<li id="categories"><a href="javascript:void(0)">Categories</a></li>
				<li id="tags"><a href="javascript:void(0)">Tags</a></li>
				<li id="archives"><a href="javascript:void(0)">Archives</a></li>
			</ul>
			<div class="search_form">
				<div id="wrap">
					<form role="search" method="get" id="searchform" action="<?php echo home_url( '/' ); ?>">
							<input type="hidden" name="post_type" value="post" />
							<input type="text" value="" name="s" placeholder="Search post" />
							<input type="submit" value="" />
					</form>
				</div>
			</div>
		</div>
		<div class="blog_menu_content">
			<div id="categorieso" class="content">
				<?php dynamic_sidebar('sidebar3'); ?>
			</div>
			<div id="tagso" class="content">
				<?php dynamic_sidebar('sidebar4'); ?>
			</div>
			<div id="archiveso" class="content">
				<?php dynamic_sidebar('sidebar5'); ?>
			</div>
		</div>
	</div>
</section>

<!--blog_menu-->


<!--blog_page_listing_section-->


<!--blog_section-->





<section class="blog_page_section">
	<div class="wrap_grid">
		<div class="head_text">
		<h1>Search results
			</h1>
			</div>
		<ul>
		<?php 
			if (have_posts() && strlen( trim(get_search_query()) ) != 0) : 
while (have_posts()) : the_post(); ?>
		
				<li>
					<div class="blog_bottom_align">
						<div class="blog_bottom_left">
							<a class="feature" href="<?php the_permalink() ?>" title="<?php the_title(); ?>"> 
								<?php if ( has_post_thumbnail() ) { the_post_thumbnail('medium_large');}else{?> 
									<img src="<?php echo esc_url(get_template_directory_uri());?>/images/no_blog.jpg" alt="<?php the_title(); ?>">	
								<?php } ?></a>
						</div>
						<div class="blog_bottom_right">
							<h2><?php the_title(); ?></h2>
							<p><?php echo substr(wp_strip_all_tags(get_the_excerpt(''),true),0,170);?></p>
							<a href="<?php the_permalink() ?>" title="Read More"><button>Read More</button></a>
						</div>
					</div>
				</li>
				<?php endwhile; ?>
					</ul>
					
					<?php wp_reset_postdata(); ?>
					<?php else : ?>
					<p class="search">There is no posts...</p>
					<?php endif;?>
				
			</ul>
			<div class="pagination">
				<!--<button>Older Posts</button>	-->
			</div>
	</div>
</section>










<?php 
get_footer(); 
?>


<script>
$( ".carousel-inner .item:first-child" ).addClass( "active" );
</script> 
<?php
/**
* The template for displaying all pages.
*
* This is the template that displays all pages by default.
* Please note that this is the WordPress construct of pages
* and that other 'pages' on your WordPress site will use a
* different template.
*
* @package storefront
*/

?>
<?php get_header(); ?>
<?php
$cat_title = '';
if(is_product_category()){
$cat_title = woocommerce_page_title(false);
}
?>
<?php if(is_shop() || is_product_category()){?>
<div class="products_shop_page_section">
	<div class="wrap_grid">
		<div class="shop_page_description">
			<div class="category_head">
				<?php if(is_shop()) { ?>
				<h1><?php// woocommerce_page_title(); ?> Our Products</h1>
				<?php } else { ?>
				<h1><?php woocommerce_page_title(); ?><span>(<?php $term = get_term_by('name', $cat_title, 'product_cat'); echo $term->count; ?>)</span></h1>
				<?php } ?>
			</div>
			<ul>
				<?php
				$args = array(
				'delimiter' => '',
				'before' => '',
									'after' => ''
				);
				woocommerce_breadcrumb($args);
				?>
			</ul>
		</div>
		
		<div class="shop_page_listing">
			<div class="shop_page_wrap">
				<div class="shop_page_listing_items">
					<?php } ?>
					<?php woocommerce_content(); ?>
					<?php if(is_shop() || is_product_category()){?>
				</div>
			</div>
		</div>
	</div>
</div>
<?php }?>

<?php get_footer(); ?>
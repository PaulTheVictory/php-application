<?php
/**
* The template for displaying product content within loops
*
* This template can be overridden by copying it to yourtheme/woocommerce/content-product.php.
*
* HOWEVER, on occasion WooCommerce will need to update template files and you
* (the theme developer) will need to copy the new files to your theme to
* maintain compatibility. We try to do this as little as possible, but it does
* happen. When this occurs the version of the template file will be bumped and
* the readme will list any important changes.
*
* @see     https://docs.woocommerce.com/document/template-structure/
* @package WooCommerce/Templates
* @version 3.6.0
*/
if ( ! defined( 'ABSPATH' ) ) {
exit; // Exit if accessed directly
}
global $product;
// Ensure visibility
if ( empty( $product ) || ! $product->is_visible() ) {
return;
}
$image = wp_get_attachment_image_src( get_post_thumbnail_id( $loop->post->ID ), 'single-post-thumbnail' );
$checkuserlogin = checkuserlogin();
$cat_title = '';
if(is_product_category()){
$cat_title = woocommerce_page_title(false);
}
?>
<li class="naatu_sakkarai">
	<div class="naatu_sakkarai_box">
		<div class="feature_images">
			<a class="pro_zoom_in" href="<?php echo get_permalink( $product->get_id() );?>" title="<?php echo $product->get_name();?>"><?php  echo woocommerce_get_product_thumbnail(); ?><?php
				if ( ! $product->managing_stock() && ! $product->is_in_stock() ){
				echo '<div class="stock out-of-stock"></div>';
				}
				else if($product->stock_status=="onbackorder"){
				echo '<div class="backorders"></div>';
				}
			?></a>
		</div>
		
		<h2><?php echo $product->get_name();?></h2>
		<?php if(!$checkuserlogin){ ?>
		<h5>
		<div style="<?php if($product->is_type('variable')){ echo "display:none"; } ?>">
			<?php echo wc_price($product->get_price());?>
		</div>
		<?php if($product->is_on_sale()){?>
		<div class="onstrike" style="<?php if($product->is_type('variable')){ echo "display:none"; } ?>">
			<?php echo wc_price($product->get_regular_price());?>
		</div>
		<?php }?>
		
		</h5>
		<?php if($product->is_type('variable')){ ?>
		<h5>
		<div class="price-sale"><?php echo wc_price($product->get_price());?></div>
		<div class="onstrike">
			<?php
			if($product->is_on_sale()){
			if ($product->is_type( 'simple' ) && $product->get_price()!=$product->get_regular_price()) {
			echo wc_price($product->get_regular_price());
			}elseif($product->is_type('variable') && $product->get_price()!=$product->get_variation_regular_price()){
			echo wc_price($product->get_variation_regular_price());
			}
			}
			?>
		</div>
		
		</h5>
		<?php } ?>
		
		<?php }else{ ?>
		<a href="<?php echo get_permalink( get_option('woocommerce_myaccount_page_id') ); ?>" title="Sign in" class="loginprice"><button><strong>Sign in</strong></button></a>
		<?php } ?>
		<input type="hidden" name="product_id" id="product_id" value="<?php echo $product->get_id(); ?>" />
		<a class="pro_zoom_in" href="<?php echo get_permalink( $product->get_id() );?>" title="<?php echo $product->get_name();?>"><button>Book Now</button></a>
		
		
	</div>
</li>
<?php
/**
* Hook: woocommerce_before_shop_loop_item.
*
* @hooked woocommerce_template_loop_product_link_open - 10
*/
//do_action( 'woocommerce_before_shop_loop_item' );
/**
* Hook: woocommerce_before_shop_loop_item_title.
*
* @hooked woocommerce_show_product_loop_sale_flash - 10
* @hooked woocommerce_template_loop_product_thumbnail - 10
*/
//do_action( 'woocommerce_before_shop_loop_item_title' );
/**
* Hook: woocommerce_shop_loop_item_title.
*
* @hooked woocommerce_template_loop_product_title - 10
*/
//do_action( 'woocommerce_shop_loop_item_title' );
/**
* Hook: woocommerce_after_shop_loop_item_title.
*
* @hooked woocommerce_template_loop_rating - 5
* @hooked woocommerce_template_loop_price - 10
*/
//do_action( 'woocommerce_after_shop_loop_item_title' );
/**
* Hook: woocommerce_after_shop_loop_item.
*
* @hooked woocommerce_template_loop_product_link_close - 5
* @hooked woocommerce_template_loop_add_to_cart - 10
*/
//do_action( 'woocommerce_after_shop_loop_item' );
?>
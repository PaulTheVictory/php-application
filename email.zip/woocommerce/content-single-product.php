<?php
/**
* The template for displaying product content in the single-product.php template
*
* This template can be overridden by copying it to yourtheme/woocommerce/content-single-product.php.
*
* HOWEVER, on occasion WooCommerce will need to update template files and you
* (the theme developer) will need to copy the new files to your theme to
* maintain compatibility. We try to do this as little as possible, but it does
* happen. When this occurs the version of the template file will be bumped and
* the readme will list any important changes.
*
* @see     https://docs.woocommerce.com/document/template-structure/
* @package WooCommerce/Templates
* @version 3.6.0
*/
defined( 'ABSPATH' ) || exit;
global $product;
global  $woocommerce;
global $wishlists;
/**
* Hook: woocommerce_before_single_product.
*
* @hooked wc_print_notices - 10
*/
do_action( 'woocommerce_before_single_product' );
if ( post_password_required() ) {
	echo get_the_password_form(); // WPCS: XSS ok.
	return;
}
// Attributes
$age = array_shift(woocommerce_get_product_terms($product->id, 'pa_age', 'names'));
$region = array_shift(woocommerce_get_product_terms($product->id, 'pa_region', 'names'));
$size = array_shift(woocommerce_get_product_terms($product->id, 'pa_size', 'names'));
$strength = array_shift(woocommerce_get_product_terms($product->id, 'pa_strength', 'names'));
$volume = array_shift(woocommerce_get_product_terms($product->id, 'pa_volume', 'names'));
$brand = array_shift(woocommerce_get_product_terms($product->id, 'pa_brand', 'names'));
$shortdetails = "";
if($volume!="" && $strength!="") $shortdetails = $volume." / ".$strength;
else if($volume!="") $shortdetails = $volume;
else if($strength!="") $shortdetails = $strength;
$cat_ID = array();
							$cat = get_the_terms( $product->id, 'product_cat' );	//echo "<pre>";print_r($cat);echo "</pre>";
foreach ($cat as $categories) {
	if($categories->parent != 0){
	array_push( $cat_ID, $categories->name );
	}
}
//print_r($cat_ID);
$subcatnames = implode(', ',$cat_ID);
$morefrom = "Products";
if(isset($cat_ID[0])) $morefrom = $cat_ID[0];
$variations =  $product->get_attributes();
//print_r($variations);
$checkuserlogin = checkuserlogin();
?>
<div id="product-<?php the_ID(); ?>" <?php wc_product_class( '', $product ); ?> >
<div class="individual_product_section">
	<div class="wrap_grid">
		<div class="individual_product_align">
			<ul class="individual_home_links">
				<?php
					$args = array(
						'delimiter' => '<span></span>',
						'before' => ''
						);
					woocommerce_breadcrumb($args);
				?>
			</ul>
			<div class="individual_product_left">
				<?php do_action( 'woocommerce_before_single_product_summary' );?>
				
				<?php
				
				if ( ! $product->managing_stock() && ! $product->is_in_stock() ){
					echo '<span class="stock out-of-stock"></span>';
				}
				else if($product->stock_status=="onbackorder"){
					echo '<span class="backorders"></span>';
				}
				
				?>
			</div>
			<div class="individual_product_right">
				<h1><?php echo $product->get_name();?></h1>
				
				
				
				<?php if(!$checkuserlogin){ ?>
				<div class="price_sec">
					
					<?php
					
					$pa_value = array();
					$default_variation_id = "";
					
					if($product->is_type('variable')){
						
						//$default_attributes = $product->get_default_attributes();var_dump($default_attributes);
						
						$available_variations = $product->get_available_variations();
							if( count($available_variations) > 0 ){
								$output = '<div class="product-variations-dropdown">
											<select id="available-variations" class="" name="available_variations">';
												$output .= '<option value="">'. __('Choose Size') .'</option>';
												$variations_data = array();
												$variations_regular_price = array();
												
												foreach( $available_variations as $variation ){
													$option_value = array();
													$is_default_variation = false;
													
													$variations_data[$variation['variation_id']] = $variation['display_price'];
													$variations_regular_price[$variation['variation_id']] = $variation['display_regular_price'];
													foreach( $variation['attributes'] as $attribute => $term_slug ){
														$taxonomy = str_replace( 'attribute_', '', $attribute );
														$attribute_name = get_taxonomy( $taxonomy )->labels->singular_name; // Attribute name
														$term_name = get_term_by( 'slug', $term_slug, $taxonomy )->name; // Attribute value term name
														//$option_value[] = $attribute_name . ': '.$term_name;
														$option_value[] = $term_name;
														$pa_value[] = trim($attribute_name);
														
														$default_value = $product->get_variation_default_attribute($taxonomy);
														if( $default_value == $term_slug ){
															$is_default_variation = true;
														}
														
													}
													
													if( $is_default_variation ){
														$default_variation_id = $variation['variation_id'];
													}
													
													$variation_obj = new WC_Product_variation($variation['variation_id']);
													$stock = $variation_obj->get_stock_quantity();
													if($variation['is_in_stock'] && $stock==0)$stock_qty = ' - In Stock';
													else $stock_qty = $stock == 0 ? ' - (Out Of Stock)' : ' - ' . $stock . ' In Stock';
													
																						
													$option_value = implode( ' - ', $option_value );
													$output .= '<option value="'.$variation['variation_id'].'">'.$option_value.$stock_qty.' </option>';
												}
												
												$pa_value = array_unique($pa_value);
												
												$output .= '
											</select>
								</div>';
								echo $output;//print_r($pa_value);
							}
						
					}
					
					?>
					
					
					<h5 class="quantity-price">
					<div class="price-sale" style="<?php if($product->is_type('variable')){ echo "display:none"; } ?>"><?php echo wc_price($product->get_price());?></div>
					<div class="price-extra" style="<?php if($product->is_type('variable')){ echo "display:none"; } ?>">
						<?php
							if($product->is_on_sale()){
								if ($product->is_type( 'simple' ) && $product->get_price()!=$product->get_regular_price()) {
									echo wc_price($product->get_regular_price());
								}elseif($product->is_type('variable') && $product->get_price()!=$product->get_variation_regular_price()){
									echo wc_price($product->get_variation_regular_price());
								}
							}
						?>
					</div>
					</h5>
					
					
				</div>
				<div class="kg_detail">
						per 1kg
					</div>
				
				<div class="quantity_sec">
				
						<?php
						
						woocommerce_quantity_input( array(
						'min_value'   => apply_filters( 'woocommerce_quantity_input_min', 1, $product ),
						'max_value'   => apply_filters( 'woocommerce_quantity_input_max', $product->backorders_allowed() ? '' : $product->get_stock_quantity(), $product ),
						'input_value' => ( isset( $_POST['quantity'] ) ? wc_stock_amount( $_POST['quantity'] ) : 1 )
						));
						?>
						<input type="hidden" name="product_id" id="product_id" value="<?php echo $product->get_id(); ?>" />
						
					
					
				</div>
				<div class="buy_now_btn_class">
					<button class="addcart-btn">ADD TO CART</button>
				
				<div class="buy_sec">
					<!--<a class="buy_now_btn" href="<?php echo get_site_url();?>/cart/?add-to-cart=<?php echo $product->get_id();?>" title="Buy it now">--><button id="buy_now" title="BUY NOW" class="buy_now_btn">BUY NOW</button><!--</a>-->
				</div>
				<p class="statusmsg"></p>
			</div>
				
				<?php }else{?>
				
				<div class="buy_sec">
					
					<a href="<?php echo get_permalink( get_option('woocommerce_myaccount_page_id') ); ?>" title="Login to see price"><button><strong>Login to see price</strong></button></a>
					
				</div>
				
				<?php } ?>
				
				<div class="tab_product_sec">
					<h4>Description</h4>
					<?php echo $product->get_description();?>
				</div>
				
			</div>
		</div>
	</div>
</div>
<!--individual_product_section_end-->
<div class="reviews_section_add">
	<div class="wrap_grid">
		<h2>Add Reviews</h2>
		<?php echo woocommerce_output_product_data_tabs();?>
	</div>
</div>
<!--related_product-->
<?php //echo do_shortcode('[top_rated_products per_page="4" columns="3" orderby="date" order="ASC"]') ?>
<!--related_product_end-->
<?php
/**
* Hook: woocommerce_before_single_product_summary.
*
* @hooked woocommerce_show_product_sale_flash - 10
* @hooked woocommerce_show_product_images - 20
*/
//do_action( 'woocommerce_before_single_product_summary' );
?>
<!--<div class="summary entry-summary">
	<?php
	/**
	* Hook: woocommerce_single_product_summary.
	*
	* @hooked woocommerce_template_single_title - 5
	* @hooked woocommerce_template_single_rating - 10
	* @hooked woocommerce_template_single_price - 10
	* @hooked woocommerce_template_single_excerpt - 20
	* @hooked woocommerce_template_single_add_to_cart - 30
	* @hooked woocommerce_template_single_meta - 40
	* @hooked woocommerce_template_single_sharing - 50
	* @hooked WC_Structured_Data::generate_product_data() - 60
	*/
	//do_action( 'woocommerce_single_product_summary' );
	?>
</div>-->
<?php
/**
* Hook: woocommerce_after_single_product_summary.
*
* @hooked woocommerce_output_product_data_tabs - 10
* @hooked woocommerce_upsell_display - 15
* @hooked woocommerce_output_related_products - 20
*/
//do_action( 'woocommerce_after_single_product_summary' );
?>
</div>
<?php //do_action( 'woocommerce_after_single_product' ); ?>
<script>
jQuery(document).ready(function($){
$(".rating-icon").click(function() {
$('html, body').animate({
scrollTop: $(".reviews_section_add").offset().top-100
}, 1000);
});
});
</script>
<script type="application/ld+json">
{
"@context": "http://schema.org/",
"@type": "Product",
"name": "<?php echo $product->get_name();?>",
"image": "<?php echo wp_get_attachment_url( $product->get_image_id() ); ?>",
"description": "<?php echo wp_strip_all_tags($product->get_short_description());?>",
"sku": "<?php echo $product->get_sku(); ?>",
"mpn": "<?php echo $product->get_sku(); ?>",
"brand": {
"@type": "Thing",
"name": "<?php echo $brand;?>"
},
"review": {
"@type": "Review",
"reviewRating": {
"@type": "Rating",
"ratingValue": "5",
"bestRating": "5"
},
"author": {
"@type": "Organization",
"name": "Naatu Sakkarai"
}
},
"aggregateRating": {
"@type": "AggregateRating",
"ratingValue": "4.5",
"reviewCount": "20"
},
"offers": {
"@type": "Offer",
"url":"<?php echo get_permalink( $product->id );?>",
"priceCurrency": "<?php echo get_woocommerce_currency();?>",
"price": "<?php echo $product->get_price();?>",
"priceValidUntil": "2040-12-31",
<?php if ($product->is_in_stock() ){?>
"availability": "http://schema.org/InStock",
<?php }else{?>
"availability": "http://schema.org/OutofStock",
<?php }?>
"seller": {
"@type": "Organization",
"name": "Naatu Sakkarai"
}
}
}
</script>
<script>
var jsonData = <?php echo json_encode($variations_data); ?>;
var variations_regular_price = <?php echo json_encode($variations_regular_price); ?>;
(function ($) {
var variationelem = $("#available-variations").val(<?php echo $default_variation_id;?>);
if(variationelem)setvariationvalue(variationelem);
$("input[name=quantity]").bind('keyup mouseup', function () {
var regprice = "<?php echo $product->get_price();?>";
var cursymb = "<?php  echo get_woocommerce_currency_symbol();?>";
$.each( jsonData, function( index, price ) {
if( index == $("#available-variations option:selected").val() ) {
regprice = price; // The right variation price
}
});
var totalprice = $(this).val() * regprice;
//totalprice = totalprice.toFixed(2);
$(".price-sale").html('<span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">'+cursymb+'</span>'+addCommas(totalprice)+'</bdi></span>');
});
$(document).on('click', '.addcart-btn', function (e) {
e.preventDefault();
var product_qty = $('input[name=quantity]').val(),
product_id = $('#product_id').val(),
variation_id = $('#available-variations option:selected').val();
if(typeof variation_id =="undefined"){variation_id = 0;}
else if(typeof variation_id !="undefined" && variation_id==""){
alert('Choose Instock Dimension Size');return;
}
var cartcount = $(".count_align span").text();
cartcount = parseInt(cartcount) + parseInt(product_qty);
$(this).addClass('loading');
m_wc_add_to_cart(product_id,variation_id,product_qty,cartcount);
//window.location.href = "<?php //echo get_site_url()?>/cart/?add-to-cart="+product_id+"&quantity="+product_qty;
});
$(document).on('click', '.buy_now_btn', function (e) {
e.preventDefault();
var product_qty = $('input[name=quantity]').val(),
product_id = $('#product_id').val(),
variation_id = $('#available-variations option:selected').val();
if(typeof variation_id =="undefined"){variation_id = 0;}
else if(typeof variation_id !="undefined" && variation_id==""){
alert('Choose Instock Dimension Size');return;
}
<?php if($product->is_type('variable')){  ?>
window.location.href = "<?php echo get_site_url()?>/cart/?add-to-cart="+variation_id+"&quantity="+product_qty;
<?php }else if($product->is_type('simple')){?>
window.location.href = "<?php echo get_site_url()?>/cart/?add-to-cart="+product_id+"&quantity="+product_qty;
<?php }?>
//window.location.href = "<?php echo get_site_url()?>/cart/?add-to-cart="+product_id+variation_id+"&quantity="+product_qty;
});
$(document).on('click', '.addreview', function (e) {
$("#ui-id-2").trigger('click');
$('html, body').animate({
scrollTop: $("#product-tabs").offset().top
}, 1500);
});
$('#available-variations').change( function(){
setvariationvalue($(this));
});
})(jQuery);
function setvariationvalue(variationelem){
var cursymb = "<?php  echo get_woocommerce_currency_symbol();?>";
if( '' != $(variationelem).val() ) {
var vprice   = 0, // Initilizing
vrprice   = 0;
// Loop through variation IDs / Prices pairs
$.each( jsonData, function( index, price ) {
if( index == $("#available-variations option:selected").val() ) {
vprice = price; // The right variation price
vrprice = variations_regular_price[index];
if(vprice==vrprice) vrprice = 0;
}
});
//vprice = vprice.toFixed(2);
var price_html = '<span class="price-sale"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">'+cursymb+'</span>'+addCommas(vprice)+'</bdi></span></span>';
if(vrprice>0){
//vrprice = vrprice.toFixed(2);
price_html += '<span class="price-extra"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">'+cursymb+'</span>'+addCommas(vrprice)+'</bdi></span></span>';
$(".quantity-price").html(price_html);
}else{
$(".quantity-price").html(price_html);
}
$("input[name=quantity]").val(1);
}
}
function addCommas(x) {
var parts = x.toString().split(".");
parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ",");
return parts.join(".");
}
function m_wc_add_to_cart( product_id,variation_id,product_qty,cartcount ) {
if ( 'undefined' === typeof wc_add_to_cart_params ) {
// The add to cart params are not present.
return false;
}
var variablevalue = $("#available-variations option:selected").text();
var vvaluearr = variablevalue.split(' - ');
var vvaluedata = {};
for(var i=0;i<vvaluearr.length;i++){
var vvalueattrarr = vvaluearr[i].split(': ');
vvaluedata[vvalueattrarr[0]] = vvalueattrarr[1];
}
//console.log(vvaluedata);return;
var data = {
action : "woocommerce_add_variation_to_cart",
product_id: product_id,
variation_id: variation_id,
quantity: product_qty,
variation: vvaluedata
};
//jQuery.post( wc_add_to_cart_params.wc_ajax_url.toString().replace( '%%endpoint%%', 'add_to_cart' ), data, function( response ) {
jQuery.post( wc_add_to_cart_params.ajax_url, data, function( response ) {
if ( ! response ) {
return;
}
// This redirects the user to the product url if for example options are needed ( in a variable product ).
// You can remove this if it's not the case.
if ( response.error && response.product_url ) {
window.location = response.product_url;
return;
}
// Remove this if you never want this action redirect.
if ( wc_add_to_cart_params.cart_redirect_after_add === 'yes' ) {
window.location = wc_add_to_cart_params.cart_url;
return;
}
// This is important so your theme gets a chance to update the cart quantity for example, but can be removed if not needed.
jQuery( document.body ).trigger( 'added_to_cart', [ response.fragments, response.cart_hash ] );
jQuery(".statusmsg").fadeIn().html('Product successfully added to your cart.');
setTimeout(function(){jQuery(".statusmsg").fadeOut(2000).html('');},3000);
jQuery(".count_align span").text(cartcount);
jQuery(".addcart-btn").removeClass('loading');
<?php //if ( ! is_wp_error( $cat_link ) && ! empty( $cat_link ) ) { ?>
//location.assign("<?php //echo $cat_link;?>");
<?php //}else{?>
//gtag_report_conversion('<?php //echo get_permalink( $product->get_id() );?>');
<?php //}?>
//$(".mini_shopping_cart").html(response.fragments["div.widget_shopping_cart_content"]);
});
}
</script>

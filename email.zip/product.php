<?php
/*Template Name:Our Product*/
get_header();?>
<!--slider_section-->
<section class="slide_section">
	<div id="home_slider" class="carousel bs-slider slide control-round indicators-line" data-ride="carousel" data-pause="hover" data-interval="false">
		<div class="carousel-inner" role="listbox">
			<div class="item active">
				<img src="<?php echo esc_url(get_template_directory_uri());?>/images/banner/product.png" alt="Banenr" class="desk_banner">
				<img src="<?php echo esc_url(get_template_directory_uri());?>/images/banner/productm.png" alt="Banenr" class="mob_banner">
				<div class="slide-text">
					<div class="slide_text_left">
						<h2 data-animation="animated fadeInLeft">Best Traditional
						and Tasty
						Naatu Sakkarai</h2>
						<a class="book" href="<?php echo get_site_url();?>/contact-us/" title="Send Enquiry"><button data-animation="animated fadeInLeft">Send Enquiry</button></a>
					</div>
					
				</div>
			</div>
			
			<!-- <a class="nav_left" href="#home_slider" role="button" data-slide="prev"></a>
			<a class="nav_right" href="#home_slider" role="button" data-slide="next"></a>
			<ol class="nav_dots carousel-indicators">
						<li data-target="#home_slider" data-slide-to="0" class="active"></li>
						<li data-target="#home_slider" data-slide-to="1"></li>
			</ol> -->
		</div>
	</div>
</section>
<!--slider_section-->
<!--our_product_sections-->
<div class="our_product_sections">
	<div class="wrap_grid">
		<div class="our_product_align">
			<div class="our_product_left">
				<img src="<?php echo esc_url(get_template_directory_uri());?>/images/product-n.png" alt="product">
			</div>
			<div class="our_product_right">
				<h2>What is Jaggery powder?</h2>
				<p>Jaggery powder is a sweetener that is gaining popularity as a "healthy" substitute for
sugar. Raw, concentrated sugarcane juice is heated until it solidifies, making it a kind of
unprocessed sugar. Jaggery powder is a staple of the diet in most regions of India.
Jaggery has a flavor similar to caramel toffee and thick molasses. Jaggery is widely
used in syrups, herbal supplements, sweets, and truffles. Jaggery is also used to make
many Indian traditional sweets, especially sakkarai pongal.
</p>
				<a href="<?php echo get_site_url();?>/product/premium-naatu-sakkarai/" title="Buy Now"><button>Buy Now</button></a>
			</div>
		</div>
	</div>
</div>
<!--our_product_sections-->




<!--product_listing_section-->
<div class="product_listing_section">
	<div class="wrap_grid">
		<div class="product_listing_align" style="margin: 0;">
			
		</div>
		<div class="product_listing_align">
			<div class="product_listing_left">
				<!-- <img src="<?php echo esc_url(get_template_directory_uri());?>/images/ourproduct/p1.png" alt="product"> -->
				<video width="100%" height="340" controls poster="<?php echo esc_url(get_template_directory_uri());?>/images/thum.png">
					<source src="<?php echo esc_url(get_template_directory_uri());?>/images/video-naatu-sakkari.mp4" type="video/mp4">
				</video>
			</div>
			<div class="product_listing_right">
				<h2>Making of Jyothi's Pure Jaggery powder</h2>
				<p>We assure you that the JyothisPure jaggery powder is made ethically organic and of
exceptionally high quality. The purest form of Jaggery is extracted from a mature good
range of sugarcanes using the old traditional method in a hygienic environment.
The exact process of our old traditional methods involves sugarcane juice Extraction,
Clarification, and Concentration.
 </p>
			</div>
		</div>
	</div>
</div>
<!--product_listing_section-->



<!--our_extraction_section-->
<div class="our_extraction_section">
	<div class="wrap_grid">
		<ul>
			<li>
				<img src="<?php echo esc_url(get_template_directory_uri());?>/images/ourproduct/1a.png" alt="icons">
				<h4>Extraction</h4>
				<p>The delectable juice or sap is extracted by squeezing the canes or palms.</p>
			</li>
			<li>
				<img src="<?php echo esc_url(get_template_directory_uri());?>/images/ourproduct/2a.png" alt="icons">
				<h4>Clarification</h4>
				<p>The juice is now settled at the bottom of large containers to remove any particles. It's
				then strained to get a clear liquid.</p>
			</li>
			<li>
				<img src="<?php echo esc_url(get_template_directory_uri());?>/images/ourproduct/3.png" alt="icons">
				<h4>Concentration</h4>
				<p>The delectable juice or sap is extracted by squeezing the canes or palms.</p>
			</li>
			<li>
				<img src="<?php echo esc_url(get_template_directory_uri());?>/images/ourproduct/4.png" alt="icons">
				<h4>Final Stage</h4>
				<p>After that, the "mixture" is transferred to molds or containers, where it cools and
					becomes jaggery.
					It is followed by drying and powdering, where the jaggery powder is finally made. The
				jaggery powder is then packed and finally enters the storage class.</p>
			</li>
		</ul>
	</div>
</div>
<!--our_extraction_section-->
<!--benefits_section-->
<div class="benefits_section">
	<div class="wrap_grid">
		<h2>Benefits of Brown Sugar</h2>
		<img src="<?php echo esc_url(get_template_directory_uri());?>/images/ourproduct/round.png" alt="product">
	</div>
</div>
<!--benefits_section-->
<!--product_listing_section-->
<div class="product_listing_section">
	<div class="wrap_grid">
		<div class="product_listing_align">
			<div class="product_listing_left">
				<img src="<?php echo esc_url(get_template_directory_uri());?>/images/ourproduct/1.png" alt="product">
			</div>
			<div class="product_listing_right">
				<h2>How does our jaggery differ from others?</h2>
				<ul>
					<li>Jyothispure- high-quality jaggery powder has the right color, good flavor, and
hardness.
</li>
					<li>JyothisPure jaggery powder is fabricated traditionally with 40+ years of skilled
laborers.
</li>
					<li>We undergo a proper testing process for every batch and JyothisPure is the first
</li>
					<li>ISO certified company.
</li>
					<li>Our jaggery powder is free from crystals and the process of caramelization and
adulteration is completely avoided during the boiling process.</li>
				</ul>
			</div>
		</div>
		<div class="product_listing_align">
			<div class="product_listing_left">
				<img src="<?php echo esc_url(get_template_directory_uri());?>/images/ourproduct/22.png" alt="product">
			</div>
			<div class="product_listing_right">
				<h2>Nutritional value of Naatu sakkarai</h2>
				<p>Based on the source, 100 grams (half a cup) of jaggery may contain:</p>
				<p>Calories: 383 grams</p>
				<p>Protein: 0.4 grams.</p>
				<p>Fat: 0.1 grams.</p>
				<p>Iron: 12 mg,</p>
				<p>Sucrose: 65–85 grams.</p>
				<p>Fructose and glucose: 12–15 grams.</p>
				<p>Magnesium: 75-95 mg,</p>
				<p>Potassium: 1.05 g,</p>
				<p>Manganese: 0.2–0.5 mg.</p>
			</div>
		</div>
	</div>
</div>
<!--product_listing_section-->
<!--faq_section-->
<section class="faq_section">
	<div class="wrap_grid">
		<div class="head_text">
			<h2>
			Frequently asked questions
			</h2>
		</div>
		<ul class="faq_section_page">
			<li class="faq_open">
				<div class="faq_question">
					<h4>How can you check for Jaggery powder’s purity?</h4>
				</div>
				<div class="faq_answer" style="display: block;">
					<p>The original jaggery powder will be crystal-free and dark brown in color</p>
				</div>
			</li>
			<li>
				<div class="faq_question">
					<h4>Can jaggery powder be consumed in all seasons?</h4>
				</div>
				<div class="faq_answer">
					<p>Based on one’s body conditions, jaggery powder can be consumed in all seasons
						instead of white sugar in moderate quantities.
					</p>
				</div>
			</li>
			<li>
				<div class="faq_question">
					<h4>How much jaggery powder is good for your health?</h4>
				</div>
				<div class="faq_answer">
					<p>Because of its high magnesium concentration, 10 grams of jaggery powder per day is
					beneficial for your health.</p>
				</div>
			</li>
			<li>
				<div class="faq_question">
					<h4>Will jaggery powder make you fat?</h4>
				</div>
				<div class="faq_answer">
					<p>Jaggery powder has no trans fats or any kind of fat, hence not gaining weight.
</p>
				</div>
			</li>
			<li>
				<div class="faq_question">
					<h4>Shall we consume jaggery on our empty stomachs?</h4>
				</div>
				<div class="faq_answer">
					<p>Drinking warm water with jaggery powder in the morning helps to clean the stomach,
					and is good for digestion.</p>
				</div>
			</li>
			<li>
				<div class="faq_question">
					<h4>Can jaggery powder be given to newborn babies?</h4>
				</div>
				<div class="faq_answer">
					<p>According to WHO rules, Jaggery powder should be given to babies only after the age
						of one. However, this may vary depending on the baby's health and your doctor's
					advice.</p>
				</div>
			</li>
			<li>
				<div class="faq_question">
					<h4>Is it OK to add jaggery powder to the boiling milk?</h4>
				</div>
				<div class="faq_answer">
					<p>Adding jaggery powder to the boiling milk may curdle the milk. For best results, one can
					add jaggery powder only after the milk is boiled.</p>
				</div>
			</li>
		</ul>
	</div>
</section>
<!--faq_section-->
<?php
/*Template Name:Our Product*/
get_footer();?>


<script type="text/javascript">
	$(function() {
		var Accordion = function(el, multiple) {
				this.el = el || {};
				this.multiple = multiple || false;

				var links = this.el.find('.faq_question');
				links.on('click', {
						el: this.el,
						multiple: this.multiple
				}, this.dropdown)
		}

		Accordion.prototype.dropdown = function(e) {
				var $el = e.data.el;
				$this = $(this),
						$next = $this.next();

				$next.slideToggle();
				$this.parent().toggleClass('faq_open');

				if (!e.data.multiple) {
						$el.find('.faq_answer').not($next).slideUp().parent().removeClass('faq_open');
				};
		}
		var accordion = new Accordion($('.faq_section_page'), false);
});

</script>
<?php
/*Template Name:Contact Us*/
get_header();?>
<?php
	$operand1e = mt_rand(1,9);
	$operand2e = mt_rand(1,9);
	$capqnse = $operand1e." + ".$operand2e." = ";
	$capanse = $operand1e+$operand2e;
?>
<!--slider_section-->
<section class="slide_section">
	<div id="home_slider" class="carousel bs-slider slide control-round indicators-line" data-ride="carousel" data-pause="hover" data-interval="false">
		<div class="carousel-inner" role="listbox">
			<div class="item active">
				<img src="<?php echo esc_url(get_template_directory_uri());?>/images/banner/contactus.png" alt="Banenr" class="desk_banner">
				<img src="<?php echo esc_url(get_template_directory_uri());?>/images/banner/contactusm.png" alt="Banenr" class="mob_banner">
				<div class="slide-text">
					<div class="slide_text_left">
						<h2 data-animation="animated fadeInLeft">We always waiting to
						hear from you</h2>
						<a class="book" href="<?php echo get_site_url();?>/contact-us/" title="Send Enquiry"><button data-animation="animated fadeInLeft">Send Enquiry</button></a>
					</div>
					
				</div>
			</div>
			
			<!-- <a class="nav_left" href="#home_slider" role="button" data-slide="prev"></a>
			<a class="nav_right" href="#home_slider" role="button" data-slide="next"></a>
			<ol class="nav_dots carousel-indicators">
							<li data-target="#home_slider" data-slide-to="0" class="active"></li>
							<li data-target="#home_slider" data-slide-to="1"></li>
			</ol> -->
		</div>
	</div>
</section>
<!--slider_section-->
<!--inner_contact_section-->
<div class="inner_contact_section">
	<div class="wrap_grid">
		<div class="head_text">
			<h1>Get in touch with us</h1>
			<span>contact</span>
		</div>
		<div class="inner_contact_align">
			<div class="inner_contact_left">
				<h4>Office Address</h4>
				<p class="location">431, Vijaya Lodge Building, Rangai Gowder Street, Town Hall, Coimbatore, Tamil Nadu 641001</p>
				<p class="call"><a href="tel:8438350060" title="Call Now">+91 84383 50060</a></p>
				<p class="mail"><a href="mailto:jyothisjaggery@gmail.com">jyothisjaggery@gmail.com</a></p>
			</div>
			<div class="inner_contact_right">
				<h4>Contact Form</h4>
				<form action="<?php echo esc_url(get_template_directory_uri());?>/email.php" method="post" id="send_message">
					<input type="text" name="fname" id="fname" placeholder="First Name">
					<input type="text" name="lname" id="lname" placeholder="Last Name">
					<input type="text" name="phone" id="phone" placeholder="Phone Number">
					<input type="text" name="email" id="email" placeholder="E mail ID">
					<input type="hidden" name="siteurl" value="<?php echo get_site_url();?>" />
					<textarea placeholder="Order Details" name="message" id="message"></textarea>
					<div class="recapcha">
						<span>
							<?php echo $capqnse; ?>
						</span>
						<span>
							<input type="text" name="capthaanse" id="capcha1e">
							<input name="correctanse" type="hidden" id="capcha2e" value="<?php echo $capanse; ?>" />
						</span>
					</div>
					<input type="submit" name="submit" id="submit" value="Submit">
				</form>
			</div>
		</div>
	</div>
	<div class="map">
		<img src="<?php echo esc_url(get_template_directory_uri());?>/images/contactus/map.png" alt="map">
		<iframe src="https://www.google.com/maps/embed?pb=!1m26!1m12!1m3!1d15665.869131611238!2d76.95514992749534!3d11.003524474681624!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!4m11!3e6!4m3!3m2!1d11.0117096!2d76.967235!4m5!1s0x3ba8590e9f1a40e9%3A0xd3d4bc1eb09b1d6f!2sJothi%20Vellam%20Mundy!3m2!1d10.9944683!2d76.9582029!5e0!3m2!1sen!2sin!4v1652283547578!5m2!1sen!2sin" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
	</div>
</div>
<!--inner_contact_section-->

<?php
/*Template Name:Contact Us*/
get_footer();?>



<script type="text/javascript">
	$(document).ready(function(){
$("#send_message").submit(function(e){
	
	
	var fname = document.getElementById("fname").value;
	var lname = document.getElementById("lname").value;
	var phone = document.getElementById("phone").value;
	var email = document.getElementById("email").value;
	var message = document.getElementById("message").value;
	var capcha1e = document.getElementById("capcha1e").value;
	var capcha2e = document.getElementById("capcha2e").value;
var regex='';
var valid;
regex   = '^[a-zA-Z][a-zA-Z\. ]{2,40}$';
valid = validateInputs(fname,regex);
	if( (!valid) || (fname  == "")) {
alert('Please enter valid name');
return false;
}
regex   = '^[0-9 \-]{10,20}$';
valid = validateInputs(phone,regex);
if( (!valid) || (phone == "") ) {
alert('Please enter valid phone number');
return false;
}
	
	regex   = '^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$';
valid = validateInputs(email,regex);
if((!valid) || (email == "") ) {
alert('Please enter valid email address');
return false;
}
	
	if(message == '') {
alert("Please enter some valid message");
return false;
}
	
	if(capcha1e != capcha2e) {
		
		alert("Invalid Capthca Code");
return false;
	}
	
	
	
	$("#send_message").submit();
	
	e.preventDefault();
		
	
});
function validateInputs(value,pattern) {
var regexppattern;
regexppattern = new RegExp(pattern);
var valid     = regexppattern.test(value);
return valid;
}
});
</script>
<!--footer_section-->
<footer class="footer_section">
	<div class="wrap_grid">
		<div class="footer_align">
			<div class="footer1">
				<img src="<?php echo esc_url(get_template_directory_uri()); ?>/images/footer_logo.png" alt="logo">
				<p>Jaggery has a flavor similar to caramel toffee and thick molasses. </p>
			</div>
			<div class="footer2">
				<h4>Quick links</h4>
				<ul>
					<li>
						<a href="<?php echo get_site_url();?>/about-us/">About us</a>
					</li>
					<li>
						<a href="<?php echo get_site_url();?>/our-products/">Products</a>
					</li>
					<li>
						<a href="<?php echo get_site_url();?>/testimonials/">Testimonials</a>
					</li>
					<li>
						<a href="<?php echo get_site_url();?>/our-journey/">Our Journey</a>
					</li>
					<li>
						<a href="<?php echo get_site_url();?>/contact-us/">Contact Us</a>
					</li>
				</ul>
			</div>
			<div class="footer3">
				<h4>Contact Us</h4>
				<p class="address">431, Vijaya Lodge Building, Rangai Gowder Street, Town Hall, Coimbatore, Tamil Nadu 641001</p>
				<p class="call"><a href="tel:8438350060" title="Call Now">+91 84383 50060</a></p>
				<p class="mail"><a href="mailto:jyothisjaggery@gmail.com">jyothisjaggery@gmail.com</a></p>
			</div>
			<div class="footer4">
				<h4>Our Location</h4>
				<iframe src="https://www.google.com/maps/embed?pb=!1m26!1m12!1m3!1d15665.869131611238!2d76.95514992749534!3d11.003524474681624!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!4m11!3e6!4m3!3m2!1d11.0117096!2d76.967235!4m5!1s0x3ba8590e9f1a40e9%3A0xd3d4bc1eb09b1d6f!2sJothi%20Vellam%20Mundy!3m2!1d10.9944683!2d76.9582029!5e0!3m2!1sen!2sin!4v1652283547578!5m2!1sen!2sin" width="100%" height="230" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
			</div>
		</div>
	</div>
</footer>
<!--footer_section-->
<!--footer_section-->
<!--
<div class="copy_text">
		<div class="wrap_grid">
		<p>Copyright © <?php echo date('Y'); ?>. All Rights Reserved</p>
	</div>
</div>
-->

<div class="whatsappme whatsappme--right whatsappme--show">
	<a href="https://api.whatsapp.com/send?phone=918438350060&amp;text=" title="Whatsapp Chat" target="_blank" onclick="gtag('event', 'Click', {'event_category': 'Whatsapp Chat','event_label': 'Whatsapp Neuro','eventValue': 10});">
		<div class="whatsappme__button">
			<img class="lazyload" src="<?php echo esc_url(get_template_directory_uri());?>/images/whatsapp.png" alt="Whatsapp Chat" />
		</div>
	</a>
</div>

<style>
	/*Whatsapp*/
	
.whatsappme{position:fixed;z-index:400;right:20px;bottom:20px;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Oxygen,Ubuntu,Cantarell,"Open Sans","Helvetica Neue",sans-serif;font-size:16px;line-height:26px;color:#262626;transform:scale3d(0,0,0);transition:transform .3s ease-in-out;user-select:none;-ms-user-select:none;-moz-user-select:none;-webkit-user-select:none}.whatsappme svg path{fill:currentColor!important}.whatsappme--show{transform:scale3d(1,1,1);transition:transform .5s cubic-bezier(.18,.89,.32,1.28)}.whatsappme__button{position:absolute;z-index:2;bottom:8px;right:8px;height:60px;min-width:60px;max-width:95vw;background-color:#25d366;color:#fff;border-radius:30px;box-shadow:1px 6px 24px 0 rgba(7,94,84,.24);cursor:pointer;transition:background-color .2s linear;-webkit-tap-highlight-color:transparent}.whatsappme__button:hover{background-color:#498db3;transition:background-color 1.5s linear}.whatsappme--dialog .whatsappme__button{transition:background-color .2s linear}.whatsappme__button:active{background-color:#096fa5;transition:none}.whatsappme__button svg{width:36px;height:36px;margin:12px 12px}.whatsappme__badge{position:absolute;top:-4px;right:-4px;width:20px;height:20px;border:none;border-radius:50%;background:#e82c0c;font-size:12px;font-weight:600;line-height:20px;text-align:center;box-shadow:none;opacity:0;pointer-events:none}.whatsappme__badge.whatsappme__badge--in{animation:badge--in .5s cubic-bezier(.27,.9,.41,1.28) 1 both}.whatsappme__badge.whatsappme__badge--out{animation:badge--out .4s cubic-bezier(.215,.61,.355,1) 1 both}.whatsappme--dialog .whatsappme__button{box-shadow:0 1px 2px 0 rgba(0,0,0,.3)}.whatsappme--dialog .whatsappme__button svg{margin:12px 10px 12px 14px}#wa_ico,.whatsappme--dialog #send_ico{display:block}#send_ico,.whatsappme--dialog #wa_ico{display:none}.whatsappme__box{position:absolute;bottom:0;right:0;z-index:1;width:calc(100vw - 40px);max-width:400px;min-height:280px;padding-bottom:60px;border-radius:32px;background:#ede4dd url(images/background.png) center repeat-y;background-size:100% auto;box-shadow:0 2px 6px 0 rgba(0,0,0,.5);overflow:hidden;transform:scale3d(0,0,0);opacity:0;transition:opacity .4s ease-out,transform 0s linear .3s}.whatsappme--dialog .whatsappme__box{opacity:1;transform:scale3d(1,1,1);transition:opacity .2s ease-out,transform 0s linear}.whatsappme__header{display:block;position:static;width:100%;height:70px;padding:0 26px;margin:0;background-color:#2e8c7d;color:rgba(255,255,255,.5)}.whatsappme__header svg{height:100%}.whatsappme__close{display:flex;position:absolute;top:18px;right:24px;width:34px;height:34px;border-radius:50%;background:#000;color:#fff;text-align:center;opacity:.4;cursor:pointer;transition:opacity .3s ease-out;-webkit-tap-highlight-color:transparent}.whatsappme__close:hover{opacity:.6}.whatsappme__close svg{display:block;width:12px;height:12px;margin:auto}.whatsappme__message{position:relative;min-height:80px;padding:20px 22px;margin:34px 26px;border-radius:32px;background-color:#fff;color:#4a4a4a;box-shadow:0 1px 2px 0 rgba(0,0,0,.3)}.whatsappme__message:before{content:'';display:block;position:absolute;bottom:30px;left:-18px;width:18px;height:18px;background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADcAAAA1CAYAAADlE3NNAAAEr0lEQVRo3t2aT0gjVxzHf++9mcn8zWhW6bpELWzcogFNaRar7a4tBNy2WATbHpacpdZ6redeZE+9CL02B1ktXsRD/xwsilhoSwsqag/xYK09hCQlmCiTf28vGRnGmZhE183MFx5vmGQy7zO/P/P7PYLAHUIAQCqDAwDPxMREG3IpHL+zs/MZcgkYAgAMAIwOl8lkYm6xGgYAFgAEAGgZHx9/vVwun7nJJTkAEAGgdW9v73NKKXWLSzIA4AEAGQDazs/P/3ALnNEl1a2trY9oRW6wmu6SEgC0ZrPZn9wCp2dIHgCU1dXVtymlZafDIatEksvlfqYGueG9xgOAcnBw8JSa5GR3vIi1aDTaUSwWj5wOZ3RHPUN6U6nUN9RCTnZHDwDI+/v745TSkpPhrOpHcWlpqbdcLieojZwGpseZMDo66svn87/RKnIaGAsAfCAQ8J6dnX1Pr5DjwABAzmazMVqDHAd2enr6La1RjgGLRCJqLpeL0TrUjFDGrMgCAD8/P38vn8//QutUs1pLT/fC5ubmQKFQOKANqNmspbuhBwDEZDL5BaX0lDaoZoK62NxZXFzs1DRthV5TrxrKGFue/v5+KZ1Of1kul5P0BtQUUAAgxOPx9wuFwl/0BvWq3O8C6vDw8F1N036gL0G3ZaVLUEdHRxFN036kL1E3DWMHxAEAPzc3dyedTk+XSqUdegu6CRijy5mBPLOzs2oikfhU07RFSmmG3qKuaxkdxuhy/MzMjDeRSHyiadrz2wYyClUBMh9bzRfAu7u7PX6//z1RFB9zHBcBALUZKoRqUMgEgyvHeHt7+353d/cjQRBGWJZ9jBDqaMYKHKpYBAEAXltbawsGg2FFUd7iOO4hIeQhQuiOEzpdOzCSTCaftLS0fEUIGXbiHiBjU5njVCr1sc/nW6wkDcduS1u1HKRUKv2KMR4ABwvbAWKMA+BwYbsasFgs/uMWuEtxd3x8/J3b4C4Ag8Hg83g8/iyfz//n5IRi1eZzla00HgA8oijyDMNwlFJCCGH0axiGQQAAXq+XyLLMeL1eRlEURpZlRpIkhud5oigK297eLvl8Prm1tVVSFEWSJEkWRVESBMGrqupriqLcFQThLsaYu612n6vUip4KMFv5HJssjhooEi5laoZh0NjYWNvw8PC9np6ejkAg8MDv9w+oqnrfxsNqhgNTh2wE1MGYChyyWGA9RYJVFWTM3MhwjMPhsDw9PT0QDocHOjs731RV9Y1rv+cMlb4Oiy3garWW1b2sPMfceZgHmZqa6pycnPywr6/vA47jfPXAWbU0xOCOqE44u2K8Wl9oBUfMa+rq6hIWFhbGBwcHn9pBohogcRWwRiCRTUiACQ6ZYpxY9JAkFAopy8vLM4FAYKyRrgA1GGf1JperLGgEM4cNG4vF3olGo18TQkT9JsRmAdQw66NsGlbn7Ibdd0um2XzOblz6/ZWVlX8JIb8PDQ090gFJDU+e2sBeZ1hBU9NcqvIQzDMFALq+vp7GGP85MjLyBCHE1tPO1LP4eq4FG/hqnlGyeSiwsbHxfygUOu7t7Y00059JUY3ZHFm8k1lT0cGfnJw8c0ojepWFzd6CMpnM3y8AJPEkZ9khO4IAAAAASUVORK5CYII=);background-size:100%}.whatsappme__copy{position:absolute;bottom:4px;left:40px;color:#2e8c7d;font-size:11px;letter-spacing:.2px;opacity:.4;transition:opacity .25s}.whatsappme--left .whatsappme__copy{left:auto;right:40px}.whatsappme__copy:hover{opacity:.8;transition:opacity .5s ease-out .5s}.whatsappme__copy a,.whatsappme__copy a:active,.whatsappme__copy a:hover{color:inherit;text-decoration:none}.whatsappme__copy svg{width:40px;height:10px;vertical-align:inherit}.whatsappme--left{right:auto;left:20px}.whatsappme--left .whatsappme__button{right:auto;left:8px}.whatsappme--left .whatsappme__box{right:auto;left:0}@media (max-width:480px){.whatsappme{bottom:6px;right:6px}.whatsappme--left{right:auto;left:6px}.whatsappme__box{width:calc(100vw - 12px);min-height:0}.whatsappme__header{height:55px}.whatsappme__close{top:13px;width:28px;height:28px}.whatsappme__message{padding:14px 20px;margin:15px 21px 20px;line-height:24px}}@keyframes badge--in{from{opacity:0;transform:translateY(50px)}to{opacity:1;transform:translateY(0)}}@keyframes badge--out{0%{opacity:1;transform:translateY(0)}100%{opacity:0;transform:translateY(-20px)}}
</style>


<script type="text/javascript" src="<?php echo esc_url(get_template_directory_uri());?>/js/jquery_min.js"></script>
<script type="text/javascript" src="<?php echo esc_url(get_template_directory_uri());?>/js/bootstrap_min.js"></script>
<script type="text/javascript" src="<?php echo esc_url(get_template_directory_uri());?>/js/desk_menu_min.js"></script>
<script type="text/javascript" src="<?php echo esc_url(get_template_directory_uri());?>/js/slider_min.js"></script>
<script type="text/javascript" src="<?php echo esc_url(get_template_directory_uri());?>/js/owl_carousel_min.js"></script>
<script type="text/javascript" src="<?php echo esc_url(get_template_directory_uri());?>/js/modernizr_min.js"></script>
<script type="text/javascript" src="<?php echo esc_url(get_template_directory_uri());?>/js/gallery_min.js"></script>
<script type="text/javascript" src="<?php echo esc_url(get_template_directory_uri());?>/js/mob_menu_min.js"></script>
<script>
'use strict';
(function($) {
$(window).on('load', function() {
//$(".loader").fadeOut();
//$("#preloder").delay(200).fadeOut("slow");
		$(".loader_img").fadeOut();
$(".loading-bar").fadeOut();
$("#preloder").delay(200).fadeOut("slow");
});
})(jQuery);
//
$('#home_slider').bsTouchSlider();
//
$(".testi_slider").owlCarousel({
loop: false,
		center: false,
		nav: true,
		dots: true,
		autoplay: false,
		rewind: true,
		autoplayHoverPause:true,
		touchDrag: true,
				mouseDrag: true,
		smartSpeed: 200,
responsive: {
0: {
				items: 1
},
			580: {
				items: 1
},
768: {
				items: 2
},
850: {
				items: 2
},
1200: {
				items: 2
},
			1920: {
items: 2
}
}
});
//
$(function() {
	$( '#dl-menu' ).dlmenu({
		animationClasses : { classin : 'dl-animate-in-5', classout : 'dl-animate-out-5' }
	});
});
//
var $navbar = $("#navbar"),
y_pos = $navbar.offset().top,
height = $navbar.height();
$(document).scroll(function() {
var scrollTop = $(this).scrollTop();
if (scrollTop > y_pos + height) {
$navbar.addClass("navbar-fixed").animate({
top: 0
});
} else if (scrollTop <= y_pos) {
$navbar.removeClass("navbar-fixed").clearQueue().animate({
top: "-48px"
}, 0);
}
});
</script>

<script>
	$(document).ready(function(){
$("#book_an_appointment").submit(function(e){
	
	var bname = document.getElementById("bname").value;
	var bphone = document.getElementById("bphone").value;
	var bcompany = document.getElementById("bcompany").value;
	var bcity = document.getElementById("bcity").value;
	var capcha1 = document.getElementById("capcha1").value;
	var capcha2 = document.getElementById("capcha2").value;
	
	
	 var regex='';
    var valid;

    regex   = '^[a-zA-Z][a-zA-Z\. ]{2,40}$';
    valid = validateInputs(bname,regex);

	if( (!valid) || (bname  == "")) {
         alert('Please enter valid name');
         return false;
     }
   
      
    regex   = '^[0-9 \-]{10,20}$';
    valid = validateInputs(bphone,regex);
   
   if( (!valid) || (bphone == "") ) {
         alert('Please enter valid phone number');
         return false;
    }
	
	if(bcompany == '') {

      alert("Please enter valid company name");
      return false;
    }
	
	if(bcity == '') {

      alert("Please enter valid city");
      return false;
    }
	
	 
	 if(capcha1 != capcha2) {
		 
		  alert("Invalid Capthca Code");
      return false;
	 }
	
	
	$("#book_an_appointment").submit();
	
	e.preventDefault();		
		
	});	
	

	
function validateInputs(value,pattern) {
    
    var regexppattern;
    regexppattern = new RegExp(pattern);
    var valid     = regexppattern.test(value);
    
    return valid;
}
});

</script>
<?php wp_footer(); ?>
</body>
</html>
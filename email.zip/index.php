<?php
/*Template Name:Home*/
get_header();?>
<!--slider_section-->
<section class="slide_section">
	<div id="home_slider" class="carousel bs-slider slide control-round indicators-line" data-ride="carousel" data-pause="hover" data-interval="4500">
		<div class="carousel-inner" role="listbox">
			<div class="item active">
				<img src="<?php echo esc_url(get_template_directory_uri());?>/images/banner/homen1.png" alt="Banenr" class="desk_banner">
				<img src="<?php echo esc_url(get_template_directory_uri());?>/images/banner/home-mobilen.png" alt="Banenr" class="mob_banner">
				<div class="slide-text">
					<div class="slide_text_left">
						<h2 data-animation="animated fadeInDown"><font class="random-word"></font></h2>
						<a class="book" href="<?php echo get_site_url();?>/product/our-products/" title="Know More"><button data-animation="animated zoomInRight">Know More</button></a>
					</div>
					
				</div>
			</div>
			
			<!-- <a class="nav_left" href="#home_slider" role="button" data-slide="prev"></a>
			<a class="nav_right" href="#home_slider" role="button" data-slide="next"></a>  
			<ol class="nav_dots carousel-indicators">
				<li data-target="#home_slider" data-slide-to="0" class="active"></li>
				<li data-target="#home_slider" data-slide-to="1"></li>
			</ol> -->
		</div>
	</div>
</section>
<!--slider_section-->


<!--aboutus_section-->


<section class="aboutus_section">
	<div class="wrap_grid">
		<h2>rich, sweet, and nutty flavor to baked goods and desserts</h2>
		<div class="aboutus_align">
			<div class="aboutus_left">
				<img src="<?php echo esc_url(get_template_directory_uri());?>/images/about-n.png" alt="aboutus">
			</div>
			<div class="aboutus_right">
				<div class="head_text">
					<h1>About Us</h1>
					<span>about</span>
				</div>
				<p>JyothisPure - the best source for natural jaggery powder. Right from the beginning, we
 were known as a prominent trader and manufacturer of Jaggery powder and Wood
 Pressed Oil. It is not an overnight decision to build this empire of JyothisPure. We, as a
 family, worked hard to construct this brand for generations from scratch.</p>
				<a href="<?php echo get_site_url();?>/about-us/" title="Know More"><button>Know More</button></a>
			</div>
		</div>
	</div>
</section>

<!--aboutus_section-->


<!--our_products_section-->


<section class="our_products_section">
	<div class="wrap_grid">
		<div class="head_text">
			<h2>Our Products</h2>
			<span>Products</span>
		</div>
		<div class="our_products_align">
			<div class="our_products_left">
				<img src="<?php echo esc_url(get_template_directory_uri());?>/images/product-n.png" alt="product">
			</div>
			<div class="our_products_right">
				<h2>Premium Naatu sakkarai</h2>
				<p>Jaggery has a flavor similar to caramel toffee and thick molasses. Jaggery is widely
used in syrups, herbal supplements, sweets, and truffles. Jaggery is also used to make
many Indian traditional sweets, especially sakkarai pongal.
</p>
				<a href="<?php echo get_site_url();?>/product/premium-naatu-sakkarai/" title="Buy Now"><button>Buy Now</button></a>
			</div>
		</div>
	</div>
</section>



<!--our_products_section-->




<!--jaggery_section-->



<section class="jaggery_section">
	<div class="wrap_grid">
		<div class="jaggery_align">
			<div class="jaggery_left">
				<img src="<?php echo esc_url(get_template_directory_uri());?>/images/new-why.png" alt="product">
				
			</div>
			<div class="jaggery_right">
				<div class="head_text">
					<h2>Why Jyothi's for jaggery</h2>
					<span>jaggery</span>
				</div>
				<ul>
					<li><b>59 years</b> of Traditional experience</li>
					<li><b>30,000,000 Kg</b> of Jaggery sold</li>
					<li><b>10K+</b> benefited farmers</li>
					<li><b>1,00,000+</b> Happy customers</li>
					<li><b>100+</b> Employed laborers</li>
					<li><b>100%</b> natural and chemical-free</li>
					<li><b>No added</b> preservatives, color enhancers, etc</li>
				</ul>
				<a href="<?php echo get_site_url();?>/our-products/" title="Know More"><button>Know More</button></a>
			</div>
		</div>
	</div>
</section>



<!--jaggery_section-->



<!--clients_section-->


<section class="clients_section">
	<div class="wrap_grid">
		<div class="head_text">
			<h2>Our Clients</h2>
			<span>clients</span>
		</div>
		<ul>
			<li>
				<img src="<?php echo esc_url(get_template_directory_uri());?>/images/c1/1.png" alt="Our Clinets">
			</li>
			<li>
				<img src="<?php echo esc_url(get_template_directory_uri());?>/images/c1/2.png" alt="Our Clinets">
			</li>
			<li>
				<img src="<?php echo esc_url(get_template_directory_uri());?>/images/c1/3.png" alt="Our Clinets">
			</li>
			<li>
				<img src="<?php echo esc_url(get_template_directory_uri());?>/images/c1/4.png" alt="Our Clinets">
			</li>
			<li>
				<img src="<?php echo esc_url(get_template_directory_uri());?>/images/c1/5.png" alt="Our Clinets">
			</li>
			<li>
				<img src="<?php echo esc_url(get_template_directory_uri());?>/images/c1/6.png" alt="Our Clinets">
			</li>
			<li>
				<img src="<?php echo esc_url(get_template_directory_uri());?>/images/c1/7.png" alt="Our Clinets">
			</li>
			<li>
				<img src="<?php echo esc_url(get_template_directory_uri());?>/images/c1/8.png" alt="Our Clinets">
			</li>
			<li>
				<img src="<?php echo esc_url(get_template_directory_uri());?>/images/c1/9.png" alt="Our Clinets">
			</li>
			<li>
				<img src="<?php echo esc_url(get_template_directory_uri());?>/images/c1/10.png" alt="Our Clinets">
			</li>
		</ul>
	</div>
</section>


<!--clients_section-->




<!--testimonials_section-->


<section class="testimonials_section">
	<div class="wrap_grid">
		<div class="head_text">
			<h2>Testimonials</h2>
			<span>testimonials</span>
		</div>
		<ul class="testi_slider owl-carousel owl-theme">
			<li>
				<div class="testimonials_box">
					<div class="testi_profile">
						<font>
							<img src="<?php echo esc_url(get_template_directory_uri());?>/images/male.png" alt="testimonials">
						</font>
						<font>
							<img src="<?php echo esc_url(get_template_directory_uri());?>/images/star.png" alt="star">
							<h4>Deepti Srivastava</h4>
						</font>
					</div>
					<p>Recently i received these products & my experience is simply awesome. Both Natural Jaggery powder & Wood pressed Coconut oil is absolutely fabulous. Loved the aroma. U can  use it in all food items. Totally a worth Buying product. Highly recommend 100% </p>
				</div>
			</li>
			<li>
				<div class="testimonials_box">
					<div class="testi_profile">
						<font>
							<img src="<?php echo esc_url(get_template_directory_uri());?>/images/female.png" alt="testimonials">
						</font>
						<font>
							<img src="<?php echo esc_url(get_template_directory_uri());?>/images/star.png" alt="star">
							<h4>Fathima Ismail</h4>
						</font>
					</div>
					<p>Jyothi's Pure wood pressed oil is amazing product as well as healthy. I have tried other pressed oil but I did not like the taste and the odour was not good. But Jyothi's oil is another level. It not only makes the food tasty but gives good aroma too. </p>
				</div>
			</li>
			<li>
				<div class="testimonials_box">
					<div class="testi_profile">
						<font>
							<img src="<?php echo esc_url(get_template_directory_uri());?>/images/female.png" alt="testimonials">
						</font>
						<font>
							<img src="<?php echo esc_url(get_template_directory_uri());?>/images/star.png" alt="star">
							<h4>Sanjitha Muneeswaran</h4>
						</font>
					</div>
					<p>Tried Jyothi’s cold pressed groundnut and coconut oil for the first time and I must say, it was amazing. We eat food with all our senses. To the eyes, the oils had a smooth finish. Smell is one of the most important things for any oil. It can make a dish go from good to great.</p>
				</div>
			</li>
			<li>
				<div class="testimonials_box">
					<div class="testi_profile">
						<font>
							<img src="<?php echo esc_url(get_template_directory_uri());?>/images/male.png" alt="testimonials">
						</font>
						<font>
							<img src="<?php echo esc_url(get_template_directory_uri());?>/images/star.png" alt="star">
							<h4>Pasupathy S</h4>
						</font>
					</div>
					<p>Authentic method is being practiced here to extract oil which is healthy for us! Natural Jaggery aka "Naattu Sakkarai", Honey, etc are made in their farm and delivered all across India! </p>
				</div>
			</li>
		</ul>
	</div>
</section>

<!--testimonials_section-->




<!--tested_section-->


<section class="tested_section">
	<div class="wrap_grid">
		<div class="head_text">
			<h2>Tested Certificates</h2>
			<span>Certificates</span>
		</div>
		<ul>
			<li>
				<img src="<?php echo esc_url(get_template_directory_uri());?>/images/t1.png" alt="Certificates">
			</li>
			<li>
				<img src="<?php echo esc_url(get_template_directory_uri());?>/images/t21.png" alt="Certificates">
			</li>
			<li>
				<img src="<?php echo esc_url(get_template_directory_uri());?>/images/t3.png" alt="Certificates">
			</li>
			<li>
				<img src="<?php echo esc_url(get_template_directory_uri());?>/images/t4.png" alt="Certificates">
			</li>
		</ul>
	</div>
</section>


<!--tested_section-->



<!--about_counter_section-->

<div class="about_counter_section">
	<div class="wrap_grid">
		<ul id="counter">
			<li>
				<img src="<?php echo esc_url(get_template_directory_uri()); ?>/images/about-us/i1.png" alt="Counter">
				<h4 class="count" data-count="30000000">0</h4>
				<p>Kg of Jaggery</p>
			</li>
			<li>
				<img src="<?php echo esc_url(get_template_directory_uri()); ?>/images/about-us/i2.png" alt="Counter">
				<h4 class="count" data-count="10000">0</h4>
				<p>Farmers</p>
			</li>
			<li>
				<img src="<?php echo esc_url(get_template_directory_uri()); ?>/images/about-us/i3.png" alt="Counter">
				<h4 class="count" data-count="100000">0</h4>
				<p>Customers Served</p>
			</li>
			<li>
				<img src="<?php echo esc_url(get_template_directory_uri()); ?>/images/about-us/i4.png" alt="Counter">
				<h4 class="count" data-count="59">0</h4>
				<p>Years of Service</p>
			</li>
		</ul>
	</div>
</div>

<!--about_counter_section-->

<!--parent_section-->


<section class="parent_section">
	<div class="wrap_grid">
		<div class="head_text">
			<h2>Our parent Companies</h2>
		</div>
		<ul>
			<li>
				<img src="<?php echo get_site_url();?>/wp-content/uploads/2022/05/2.png" alt="Our parent Companies" />
<!-- 				<p>Jothi Vella Mundy</p> -->
			</li>
			<li>
				<img src="<?php echo get_site_url();?>/wp-content/uploads/2022/05/1.png" alt="Our parent Companies" />
<!-- 				<p>Gnanamalar Vella Mundy</p> -->
			</li>
		</ul>
	</div>
</section>


<!--parent_section-->


































<?php
/*Template Name:Home*/
get_footer();?>

<script>
let i = 0;

const randomizeText = () => {
  const phrase = document.querySelector('.random-word');
  const compStyles = window.getComputedStyle(phrase);
  const animation = compStyles.getPropertyValue('animation');
  const animationTime = parseFloat(animation.match(/\d*[.]?\d+/)) * 1000;
  
  const phrases = ['Premium brown Sugar For Healthy Diet', 'Premium brown Sugar For Healthy Diet', 'Premium brown Sugar For Healthy Diet', 'Premium brown Sugar For Healthy Diet'];
  
  i = randomNum(i, phrases.length);
  const newPhrase = phrases[i];
  
  setTimeout(() => {
    phrase.textContent = newPhrase;
  }, 400); // time to allow opacity to hit 0 before changing word
}

const randomNum = (num, max) => {
  let j = Math.floor(Math.random() * max);
  
  // ensure diff num every time
  if (num === j) {
    return randomNum(i, max);
  } else {
    return j;
  }
}

const getAnimationTime = () => {
  const phrase = document.querySelector('.random-word');
  const compStyles = window.getComputedStyle(phrase);
  let animation = compStyles.getPropertyValue('animation');
  
  // firefox support for non-shorthand property
  animation != "" ? animation : animation = compStyles.getPropertyValue('-moz-animation-duration');
  
    // webkit support for non-shorthand property
  animation != "" ? animation : animation = compStyles.getPropertyValue('-webkit-animation-duration');
  
  
  const animationTime = parseFloat(animation.match(/\d*[.]?\d+/)) * 1000;
  return animationTime;
}

randomizeText();
setInterval(randomizeText, getAnimationTime());

</script>

<script>

var counted = 0;
$(window).scroll(function() {

  var oTop = $('#counter').offset().top - window.innerHeight;
  if (counted == 0 && $(window).scrollTop() > oTop) {
    $('.count').each(function() {
      var $this = $(this),
        countTo = $this.attr('data-count');
      $({
        countNum: $this.text()
      }).animate({
          countNum: countTo
        },

        {

          duration: 2000,
          easing: 'swing',
          step: function() {
            $this.text(Math.floor(this.countNum));
          },
          complete: function() {
            $this.text(this.countNum);
            //alert('finished');
          }

        });
    });
    counted = 1;
  }

});
</script>
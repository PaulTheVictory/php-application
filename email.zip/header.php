<?php
/**
* The template for displaying the header
*
* Displays all of the head element and everything up until the "site-content" div.
*
* @package WordPress
* @subpackage Twenty_Sixteen
* @since Twenty Sixteen 1.0
*/
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?> class="no-js" >
	<head>
		<meta charset="<?php bloginfo( 'charset' ); ?>">
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<link rel="profile" href="http://gmpg.org/xfn/11">
		<?php if ( is_singular() && pings_open( get_queried_object() ) ) : ?>
		<link rel="pingback" href="<?php echo esc_url( get_bloginfo( 'pingback_url' ) ); ?>">
		<?php endif; ?>
		<?php
		$url = home_url($wp->request);
		$meta = get_post_meta(get_the_ID(), '', true);
		$title = $meta['Title'][0];
		$description = $meta['Description'][0];
		$keyword = $meta['Keyword'][0];
		if($title!="") {echo '<title>'.$title.'</title>'.PHP_EOL;}
		else{?>
		<title><?php wp_title('|',true,'right'); ?> <?php bloginfo('name'); ?></title>
		<?php
		}
		if($description!="") echo '<meta name="description" content="'.$description.'" />'.PHP_EOL;
		if($keyword!="") echo '<meta name="keywords" content="'.$keyword.'" />'.PHP_EOL;
		?>
		
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
		<meta http-equiv="Cache-control" content="public"/>
		<link rel="canonical" href="" />
		<link rel="stylesheet" type="text/css" href="<?php echo esc_url(get_template_directory_uri());?>/css/bootstrap_min.css"/>
		<?php wp_head(); ?>
		<link rel="stylesheet" type="text/css" href="<?php echo esc_url(get_template_directory_uri());?>/css/owl_carousel_min.css"/>
		<link rel="stylesheet" type="text/css" href="<?php echo esc_url(get_template_directory_uri());?>/css/animate_min.css"/>
		<link rel="stylesheet" type="text/css" href="<?php echo esc_url(get_template_directory_uri());?>/css/mob_menu_min.css" />
		<link rel="stylesheet" type="text/css" href="<?php echo esc_url(get_template_directory_uri());?>/css/gallery_min.css" />
		<!-- <link rel="stylesheet" type="text/css" href="<?php echo esc_url(get_template_directory_uri());?>/style.css"/> -->
		<link rel="stylesheet" type="text/css" href="<?php echo esc_url(get_template_directory_uri());?>/css/style_media.css"/>
		
		
	</head>
	<body <?php body_class(); ?>>
		
		  <div id="preloder">
				<div class="preloder_align">
				<div class="loader_img"><img src="<?php echo esc_url(get_template_directory_uri());?>/images/logo.png" alt="Krishnan Photography" /> </div>
				<div class="loading-bar"></div>
			</div>
		</div> 
		<!--header_section-->
		<?php if(is_shop() || is_product_category() || is_product() || get_the_title()=="Cart" || get_the_title()=="Checkout" || get_the_title()=="My account") {?>
		<header class="shop_header_section">
			<div id="navbar">
				<div class="wrap_grid">
					<div class="header_align">
						<div class="header_1">
							<?php echo do_shortcode('[fibosearch]'); ?>
						</div>
						<div class="header_2">
							<a href="<?php echo get_site_url();?>" title="Naatu Sakkarai"><img src="<?php echo esc_url(get_template_directory_uri());?>/images/logo-n.png" alt="Naatu Sakkarai" title="Naatu Sakkarai" /></a>
						</div>
						<div class="header_3">
							<button class="sign_in"><?php if ( is_user_logged_in() ) { ?>
							<a href="<?php echo get_permalink( get_option('woocommerce_myaccount_page_id') ); ?>" title="<?php _e('My Account','woothemes'); ?>" class="user-btn"><span class="usericon"></span><?php _e('My Account','woothemes'); ?></a>
							<?php }  else { ?>
							<a href="<?php echo get_permalink( get_option('woocommerce_myaccount_page_id') ); ?>" title="<?php _e('Sign in / Register','woothemes'); ?>" class="user-btn"><span class="usericon"></span><?php _e('Sign in / Register','woothemes'); ?></a>
							<?php } ?></button>
							
							
							<a class="cart-customlocation" href="<?php echo wc_get_cart_url(); ?>" title="<?php _e( 'View your shopping cart' ); ?>"><button class="basket">Basket (<font class="header-cart-count"><?php echo WC()->cart->get_cart_contents_count(); ?></font>)</button></a>
							<ul class="mobile_head">
					<?php if ( is_user_logged_in() ) { ?>
					<li>
						<a href="<?php echo get_permalink( get_option('woocommerce_myaccount_page_id') ); ?>" title="<?php _e('My Account','woothemes'); ?>" class="user-btn">
							<img src="<?php echo esc_url(get_template_directory_uri());?>/images/user.png" alt="user" class="desk_user"><?php //_e('My Account','woothemes'); ?>
						</a>
					</li>
					<?php }  else { ?>
					<li>
						<a href="<?php echo get_permalink( get_option('woocommerce_myaccount_page_id') ); ?>" title="<?php _e('Sign in','woothemes'); ?>" class="user-btn">
							<img src="<?php echo esc_url(get_template_directory_uri());?>/images/user.png" alt="user" class="desk_user"><?php //_e('Sign in','woothemes'); ?>
						</a>
					</li>
					<?php } ?>
					<!--<li><img src="<?php echo esc_url(get_template_directory_uri());?>/image/user.png" alt="user"></li>-->
					
					<li>
						<a href="<?php echo wc_get_cart_url(); ?>" title="View Basket"  class="cart-btn">
							<img src="<?php echo esc_url(get_template_directory_uri());?>/images/cart_icon.png" alt="cart" class="desk_user">
							<span><h6><font class="header-cart-count"><?php echo WC()->cart->get_cart_contents_count(); ?></font></h6></span>
						</a>
					</li>
				</ul>
						</div>
					</div>
				</div>
			</div>
		</header>
		<?php } else { ?>
		<header class="header_section">
			<div id="navbar">
				<div class="wrap_grid">
					<div class="header_align">
						<div class="header_left">
							<a href="<?php echo get_site_url();?>" title="Naatu Sakkarai"><img src="<?php echo esc_url(get_template_directory_uri());?>/images/logo-na.png" alt="Naatu Sakkarai" title="Naatu Sakkarai" /></a>
						</div>
						<div class="header_right">
							<div id='cssmenu'>
								<?php wp_nav_menu( array( 'theme_location' => 'primary' ) ); ?>
							</div>
							<div class="enquire_btn">
							<a href="<?php echo get_site_url();?>/product/premium-naatu-sakkarai/" title="Buy Now">
									<button class="buy_btn">Buy Now</button>
								</a>
								<a href="javascript:void(0)" title="Bulk Enquiry" data-toggle="modal" data-target="#exampleModal">
									<button class="enquire_btn">Bulk Enquiry</button>
								</a>
							</div>
							<div id="dl-menu" class="dl-menuwrapper">
								<button class="dl-trigger"></button>
								<?php if(function_exists('wp_nav_menu'))
									wp_nav_menu(
									array(
										'theme_location' =>'primary',
										'container'=>'',
										'depth'=>0,
										'menu_id'=>'',
										'menu_class'=>'dl-menu',
										'dropdown_class'=>'',)
									);
								?>
							</div>
						</div>
					</div>
					
					
				</div>
			</div>
		</header>
		<?php } ?>



		<?php
	$operand1 = mt_rand(1,9);
	$operand2 = mt_rand(1,9);			
	$capqns = $operand1." + ".$operand2." = ";
	$capans = $operand1+$operand2;
?>	


<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Bulk Enquiry</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
		 <form method="post" action="<?php echo esc_url(get_template_directory_uri());?>/bulk-order.php" id="book_an_appointment">
			<input type="text" name="bname" id="bname" placeholder="Name" />
			<input type="text" name="bphone" id="bphone" placeholder="Phone No" />
			<input type="text" name="bcompany" id="bcompany" placeholder="Company Name" />
			<input type="hidden" name="siteurl" value="<?php echo get_site_url();?>" />
			<input type="text" name="bcity" id="bcity" placeholder="City Name" />
			<div class="recapcha">
					<span>
						<?php echo $capqns; ?>
					</span>
					<span>
						<input type="text" name="capthaans" id="capcha1">
						<input name="correctans" type="hidden" id="capcha2" value="<?php echo $capans; ?>" />
					</span>
				</div>
			<input type="submit" name="submit" id="submit" value="Submit" />
			
		 </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>



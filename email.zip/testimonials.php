<?php
/*Template Name:Testimonials*/
get_header();?>

<!--slider_section-->
<section class="slide_section">
	<div id="home_slider" class="carousel bs-slider slide control-round indicators-line" data-ride="carousel" data-pause="hover" data-interval="false">
		<div class="carousel-inner" role="listbox">
			<div class="item active">
				<img src="<?php echo esc_url(get_template_directory_uri());?>/images/banner/tesimonials.png" alt="Banenr" class="desk_banner">
				<img src="<?php echo esc_url(get_template_directory_uri());?>/images/banner/testimonials.png" alt="Banenr" class="mob_banner">
				<div class="slide-text">
					<div class="slide_text_left">
						<h2 data-animation="animated fadeInLeft">Our Clients are
best reviewers </h2>
						<a class="book" href="<?php echo get_site_url();?>/contact-us/" title="Send Enquiry"><button data-animation="animated fadeInLeft">Send Enquiry</button></a>
					</div>
					
				</div>
			</div>
			
			<!-- <a class="nav_left" href="#home_slider" role="button" data-slide="prev"></a>
			<a class="nav_right" href="#home_slider" role="button" data-slide="next"></a>  
			<ol class="nav_dots carousel-indicators">
				<li data-target="#home_slider" data-slide-to="0" class="active"></li>
				<li data-target="#home_slider" data-slide-to="1"></li>
			</ol> -->
		</div>
	</div>
</section>
<!--slider_section-->




<!--inner_testimonials_section-->


<!--testimonials_section-->


<section class="testimonials_section inner_testimonials_section">
	<div class="wrap_grid">
		<div class="head_text">
			<h2>See, What our clients say about us</h2>
			<span>Testimonials</span>
		</div>
		<ul>
		<li>
				<div class="testimonials_box">
					<div class="testi_profile">
						<font>
							<img src="<?php echo esc_url(get_template_directory_uri());?>/images/male.png" alt="testimonials">
						</font>
						<font>
							<img src="<?php echo esc_url(get_template_directory_uri());?>/images/star.png" alt="star">
							<h4>Deepti Srivastava</h4>
						</font>
					</div>
					<p>Recently i received these products & my experience is simply awesome. Both Natural Jaggery powder & Wood pressed Coconut oil is absolutely fabulous. Loved the aroma. U can  use it in all food items. Totally a worth Buying product. Highly recommend 100% </p>
				</div>
			</li>
			<li>
				<div class="testimonials_box">
					<div class="testi_profile">
						<font>
							<img src="<?php echo esc_url(get_template_directory_uri());?>/images/female.png" alt="testimonials">
						</font>
						<font>
							<img src="<?php echo esc_url(get_template_directory_uri());?>/images/star.png" alt="star">
							<h4>Fathima Ismail</h4>
						</font>
					</div>
					<p>Jyothi's Pure wood pressed oil is amazing product as well as healthy. I have tried other pressed oil but I did not like the taste and the odour was not good. But Jyothi's oil is another level. It not only makes the food tasty but gives good aroma too. </p>
				</div>
			</li>
			<li>
				<div class="testimonials_box">
					<div class="testi_profile">
						<font>
							<img src="<?php echo esc_url(get_template_directory_uri());?>/images/female.png" alt="testimonials">
						</font>
						<font>
							<img src="<?php echo esc_url(get_template_directory_uri());?>/images/star.png" alt="star">
							<h4>Sanjitha Muneeswaran</h4>
						</font>
					</div>
					<p>Tried Jyothi’s cold pressed groundnut and coconut oil for the first time and I must say, it was amazing. We eat food with all our senses. To the eyes, the oils had a smooth finish. Smell is one of the most important things for any oil. It can make a dish go from good to great.</p>
				</div>
			</li>
			<li>
				<div class="testimonials_box">
					<div class="testi_profile">
						<font>
							<img src="<?php echo esc_url(get_template_directory_uri());?>/images/male.png" alt="testimonials">
						</font>
						<font>
							<img src="<?php echo esc_url(get_template_directory_uri());?>/images/star.png" alt="star">
							<h4>Pasupathy S</h4>
						</font>
					</div>
					<p>Authentic method is being practiced here to extract oil which is healthy for us! Natural Jaggery aka "Naattu Sakkarai", Honey, etc are made in their farm and delivered all across India! </p>
				</div>
			</li>
		</ul>
	</div>
</section>

<!--testimonials_section-->




<!--inner_testimonials_section-->


























<?php
/*Template Name:Testimonials*/
get_footer();?>
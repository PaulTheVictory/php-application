<?php
/*Template Name:Gallery*/
get_header();?>
<!--slider_section-->
<section class="slide_section">
	<div id="home_slider" class="carousel bs-slider slide control-round indicators-line" data-ride="carousel" data-pause="hover" data-interval="false">
		<div class="carousel-inner" role="listbox">
			<div class="item active">
				<img src="<?php echo esc_url(get_template_directory_uri());?>/images/banner/galleryn.png" alt="Banenr" class="desk_banner">
				<img src="<?php echo esc_url(get_template_directory_uri());?>/images/banner/gallerymn.png" alt="Banenr" class="mob_banner">
				<div class="slide-text">
					<div class="slide_text_left">
						<h2 data-animation="animated fadeInLeft">Our production
pics are eyes
pleasing</h2>
						<a class="book" href="<?php echo get_site_url();?>/contact-us/" title="Send Enquiry"><button data-animation="animated fadeInLeft">Send Enquiry</button></a>
					</div>
					
				</div>
			</div>
			
			<!-- <a class="nav_left" href="#home_slider" role="button" data-slide="prev"></a>
			<a class="nav_right" href="#home_slider" role="button" data-slide="next"></a>
			<ol class="nav_dots carousel-indicators">
					<li data-target="#home_slider" data-slide-to="0" class="active"></li>
					<li data-target="#home_slider" data-slide-to="1"></li>
			</ol> -->
		</div>
	</div>
</section>
<!--slider_section-->





<!--inner_gal_section-->


<div class="inner_gal_section">
	<div class="wrap_grid">
		<div class="head_text">
			<h1>gallery</h1>
			<span>gallery</span>
		</div>
		<ul>
			<li>
				<a href="<?php echo esc_url(get_template_directory_uri());?>/images/gallery/1.png" data-fancybox="gallery" data-caption="Our Gallery">
					<img src="<?php echo esc_url(get_template_directory_uri()); ?>/images/gallery/1.png" alt="gallery">
				</a>
			</li>
			<li>
				<a href="<?php echo esc_url(get_template_directory_uri());?>/images/gallery/2.png" data-fancybox="gallery" data-caption="Our Gallery">
					<img src="<?php echo esc_url(get_template_directory_uri()); ?>/images/gallery/2.png" alt="gallery">
				</a>
			</li>
			<li>
				<a href="<?php echo esc_url(get_template_directory_uri());?>/images/gallery/3.png" data-fancybox="gallery" data-caption="Our Gallery">
					<img src="<?php echo esc_url(get_template_directory_uri()); ?>/images/gallery/3.png" alt="gallery">
				</a>
			</li>
			<li>
				<a href="<?php echo esc_url(get_template_directory_uri());?>/images/gallery/4.png" data-fancybox="gallery" data-caption="Our Gallery">
					<img src="<?php echo esc_url(get_template_directory_uri()); ?>/images/gallery/4.png" alt="gallery">
				</a>
			</li>
			<li>
				<a href="<?php echo esc_url(get_template_directory_uri());?>/images/gallery/5.png" data-fancybox="gallery" data-caption="Our Gallery">
					<img src="<?php echo esc_url(get_template_directory_uri()); ?>/images/gallery/5.png" alt="gallery">
				</a>
			</li>
			<li>
				<a href="<?php echo esc_url(get_template_directory_uri());?>/images/gallery/6.png" data-fancybox="gallery" data-caption="Our Gallery">
					<img src="<?php echo esc_url(get_template_directory_uri()); ?>/images/gallery/6.png" alt="gallery">
				</a>
			</li>
			<li>
				<a href="<?php echo esc_url(get_template_directory_uri());?>/images/gallery/7.png" data-fancybox="gallery" data-caption="Our Gallery">
					<img src="<?php echo esc_url(get_template_directory_uri()); ?>/images/gallery/7.png" alt="gallery">
				</a>
			</li>
			<li>
				<a href="<?php echo esc_url(get_template_directory_uri());?>/images/gallery/8.png" data-fancybox="gallery" data-caption="Our Gallery">
					<img src="<?php echo esc_url(get_template_directory_uri()); ?>/images/gallery/8.png" alt="gallery">
				</a>
			</li>
			<li>
				<a href="<?php echo esc_url(get_template_directory_uri());?>/images/gallery/9.png" data-fancybox="gallery" data-caption="Our Gallery">
					<img src="<?php echo esc_url(get_template_directory_uri()); ?>/images/gallery/9.png" alt="gallery">
				</a>
			</li>
			<li>
				<a href="<?php echo esc_url(get_template_directory_uri());?>/images/gallery/10.png" data-fancybox="gallery" data-caption="Our Gallery">
					<img src="<?php echo esc_url(get_template_directory_uri()); ?>/images/gallery/10.png" alt="gallery">
				</a>
			</li>
			<li>
				<a href="<?php echo esc_url(get_template_directory_uri());?>/images/gallery/11.png" data-fancybox="gallery" data-caption="Our Gallery">
					<img src="<?php echo esc_url(get_template_directory_uri()); ?>/images/gallery/11.png" alt="gallery">
				</a>
			</li>
			<li>
				<a href="<?php echo esc_url(get_template_directory_uri());?>/images/gallery/12.png" data-fancybox="gallery" data-caption="Our Gallery">
					<img src="<?php echo esc_url(get_template_directory_uri()); ?>/images/gallery/12.png" alt="gallery">
				</a>
			</li>
			<li>
				<a href="<?php echo esc_url(get_template_directory_uri());?>/images/gallery/13.png" data-fancybox="gallery" data-caption="Our Gallery">
					<img src="<?php echo esc_url(get_template_directory_uri()); ?>/images/gallery/13.png" alt="gallery">
				</a>
			</li>
			<li>
				<a href="<?php echo esc_url(get_template_directory_uri());?>/images/gallery/14.png" data-fancybox="gallery" data-caption="Our Gallery">
					<img src="<?php echo esc_url(get_template_directory_uri()); ?>/images/gallery/14.png" alt="gallery">
				</a>
			</li>
			<li>
				<a href="<?php echo esc_url(get_template_directory_uri());?>/images/gallery/15.png" data-fancybox="gallery" data-caption="Our Gallery">
					<img src="<?php echo esc_url(get_template_directory_uri()); ?>/images/gallery/15.png" alt="gallery">
				</a>
			</li>
			<li>
				<a href="<?php echo esc_url(get_template_directory_uri());?>/images/gallery/16.png" data-fancybox="gallery" data-caption="Our Gallery">
					<img src="<?php echo esc_url(get_template_directory_uri()); ?>/images/gallery/16.png" alt="gallery">
				</a>
			</li>
			<li>
				<a href="<?php echo esc_url(get_template_directory_uri());?>/images/gallery/17.png" data-fancybox="gallery" data-caption="Our Gallery">
					<img src="<?php echo esc_url(get_template_directory_uri()); ?>/images/gallery/17.png" alt="gallery">
				</a>
			</li>
			<li>
				<a href="<?php echo esc_url(get_template_directory_uri());?>/images/gallery/18.png" data-fancybox="gallery" data-caption="Our Gallery">
					<img src="<?php echo esc_url(get_template_directory_uri()); ?>/images/gallery/18.png" alt="gallery">
				</a>
			</li>
			<li>
				<a href="<?php echo esc_url(get_template_directory_uri());?>/images/gallery/19.png" data-fancybox="gallery" data-caption="Our Gallery">
					<img src="<?php echo esc_url(get_template_directory_uri()); ?>/images/gallery/19.png" alt="gallery">
				</a>
			</li>
			<li>
				<a href="<?php echo esc_url(get_template_directory_uri());?>/images/gallery/20.png" data-fancybox="gallery" data-caption="Our Gallery">
					<img src="<?php echo esc_url(get_template_directory_uri()); ?>/images/gallery/20.png" alt="gallery">
				</a>
			</li>
		</ul>
	</div>
</div>



<!--inner_gal_section-->














<?php
/*Template Name:Gallery*/
get_footer();?>

<script>
	$('[data-fancybox="gallery"]').fancybox({
  buttons: [
    "slideShow",
    "thumbs",
    "zoom",
    "fullScreen",
    //"share",
    "close"
  ],
  loop: false,
  protect: true
});
</script>
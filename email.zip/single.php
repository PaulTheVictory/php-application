<?php
/**
 * The template for displaying all single posts and attachments
 *
 * @package WordPress
 * @subpackage Twenty_Fifteen
 * @since Twenty Fifteen 1.0
 */

get_header(); ?>





<section class="blog_page_listing_section">
	<div class="wrap_grid">
		<div class="blog_page_listing_align">
			<div class="blog_page_listing_left_single" id="single_blog">
				<div class="head_text">
					<h1><?php the_title(); ?></h1>
				</div>
				<?php
				// Start the loop.
				while ( have_posts() ) : the_post();
				$url = get_the_post_thumbnail_url( $page->ID, 'full' );
				?>
				
				<?php 
					the_content();
					
				?>
				
				<?php
				// If comments are open or we have at least one comment, load up the comment template.
				if ( comments_open() || get_comments_number() ) :
				comments_template();
				endif;
				// End the loop.
				endwhile;
				?>
			</div>
		</div>
	</div>
	<div class="next_prev_button">
	<div class="wrap_grid">

				 <span class="nav-previous"><?php previous_post_link( '%link', __( '<font class="before"></font>Previous Page', 'twentyeleven' ) ); ?> 
					<h2><a href="<?php echo $permalink; ?>"><?php echo $prev_post->post_title; ?></a></h2>
				</span>

				<span class="nav-next"><?php next_post_link( '%link', __( 'Next Page<font class="before"></font>', 'twentyeleven' ) ); ?>
					<h2><a href="<?php echo $permalink; ?>"><?php echo $next_post->post_title; ?></a></h2>
				</span>
			</div>
			</div>
</section>




	
	

      

<?php get_footer(); ?>
<script>
$( ".carousel-inner .item:first-child" ).addClass( "active" );
</script> 


<script>


/*
var img = [document.querySelectorAll("#single_blog img")];
//console.log(img.length);
img.forEach(function(){
	wrapAll('<div class="card"><span class="card-image"><a href="'+this.getAttribute('src')+'" data-fancybox="clinicgallery" data-caption="Our Gallery"></a></span></div>');
}) */

</script>









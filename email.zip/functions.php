<?php
/**
* Twenty Sixteen functions and definitions
*
* Set up the theme and provides some helper functions, which are used in the
* theme as custom template tags. Others are attached to action and filter
* hooks in WordPress to change core functionality.
*
* When using a child theme you can override certain functions (those wrapped
* in a function_exists() call) by defining them first in your child theme's
* functions.php file. The child theme's functions.php file is included before
* the parent theme's file, so the child theme functions would be used.
*
* @link https://codex.wordpress.org/Theme_Development
* @link https://developer.wordpress.org/themes/advanced-topics/child-themes/
*
* Functions that are not pluggable (not wrapped in function_exists()) are
* instead attached to a filter or action hook.
*
* For more information on hooks, actions, and filters,
* {@link https://codex.wordpress.org/Plugin_API}
*
* @package WordPress
* @subpackage Twenty_Sixteen
* @since Twenty Sixteen 1.0
*/
/**
* Twenty Sixteen only works in WordPress 4.4 or later.
*/
if (version_compare($GLOBALS['wp_version'], '5.5-alpha', '<'))
{
require get_template_directory() . '/inc/back-compat.php';
}
if (!function_exists('twentysixteen_setup')):
/**
* Sets up theme defaults and registers support for various WordPress features.
*
* Note that this function is hooked into the after_setup_theme hook, which
* runs before the init hook. The init hook is too late for some features, such
* as indicating support for post thumbnails.
*
* Create your own twentysixteen_setup() function to override in a child theme.
*
* @since Twenty Sixteen 1.0
*/
function twentysixteen_setup()
{
/*
        * Make theme available for translation.
        * Translations can be filed at WordPress.org. See: https://translate.wordpress.org/projects/wp-themes/twentysixteen
        * If you're building a theme based on Twenty Sixteen, use a find and replace
        * to change 'twentysixteen' to the name of your theme in all the template files
        */
load_theme_textdomain('twentysixteen');
// Add default posts and comments RSS feed links to head.
add_theme_support('automatic-feed-links');
/*
        * Let WordPress manage the document title.
        * By adding theme support, we declare that this theme does not use a
        * hard-coded <title> tag in the document head, and expect WordPress to
        * provide it for us.
        */
add_theme_support('title-tag');
/*
        * Enable support for custom logo.
        *
        *  @since Twenty Sixteen 1.2
        */
add_theme_support('custom-logo', array(
'height' => 240,
'width' => 240,
'flex-height' => true,
));
/*
        * Enable support for Post Thumbnails on posts and pages.
        *
        * @link https://developer.wordpress.org/reference/functions/add_theme_support/#post-thumbnails
        */
add_theme_support('post-thumbnails');
set_post_thumbnail_size(1200, 9999);
// This theme uses wp_nav_menu() in two locations.
register_nav_menus(array(
'primary' => __('Primary Menu', 'twentysixteen') ,
//'social' => __('Social Links Menu', 'twentysixteen') ,
));
/*
        * Switch default core markup for search form, comment form, and comments
        * to output valid HTML5.
        */
add_theme_support('html5', array(
'search-form',
'comment-form',
'comment-list',
'gallery',
'caption',
));
/*
        * Enable support for Post Formats.
        *
        * See: https://codex.wordpress.org/Post_Formats
        */
add_theme_support('post-formats', array(
'aside',
'image',
'video',
'quote',
'link',
'gallery',
'status',
'audio',
'chat',
));
/*
        * This theme styles the visual editor to resemble the theme style,
        * specifically font, colors, icons, and column width.
        */
add_editor_style(array(
'css/editor-style.css',
twentysixteen_fonts_url()
));
// Load regular editor styles into the new block-based editor.
add_theme_support('editor-styles');
// Load default block styles.
add_theme_support('wp-block-styles');
// Add support for responsive embeds.
add_theme_support('responsive-embeds');
// Add support for custom color scheme.
add_theme_support('editor-color-palette', array(
array(
'name' => __('Dark Gray', 'twentysixteen') ,
'slug' => 'dark-gray',
'color' => '#1a1a1a',
) ,
array(
'name' => __('Medium Gray', 'twentysixteen') ,
'slug' => 'medium-gray',
'color' => '#686868',
) ,
array(
'name' => __('Light Gray', 'twentysixteen') ,
'slug' => 'light-gray',
'color' => '#e5e5e5',
) ,
array(
'name' => __('White', 'twentysixteen') ,
'slug' => 'white',
'color' => '#fff',
) ,
array(
'name' => __('Blue Gray', 'twentysixteen') ,
'slug' => 'blue-gray',
'color' => '#4d545c',
) ,
array(
'name' => __('Bright Blue', 'twentysixteen') ,
'slug' => 'bright-blue',
'color' => '#007acc',
) ,
array(
'name' => __('Light Blue', 'twentysixteen') ,
'slug' => 'light-blue',
'color' => '#9adffd',
) ,
array(
'name' => __('Dark Brown', 'twentysixteen') ,
'slug' => 'dark-brown',
'color' => '#402b30',
) ,
array(
'name' => __('Medium Brown', 'twentysixteen') ,
'slug' => 'medium-brown',
'color' => '#774e24',
) ,
array(
'name' => __('Dark Red', 'twentysixteen') ,
'slug' => 'dark-red',
'color' => '#640c1f',
) ,
array(
'name' => __('Bright Red', 'twentysixteen') ,
'slug' => 'bright-red',
'color' => '#ff675f',
) ,
array(
'name' => __('Yellow', 'twentysixteen') ,
'slug' => 'yellow',
'color' => '#ffef8e',
) ,
));
// Indicate widget sidebars can use selective refresh in the Customizer.
add_theme_support('customize-selective-refresh-widgets');
}
endif; // twentysixteen_setup
add_action('after_setup_theme', 'twentysixteen_setup');
/**
* Sets the content width in pixels, based on the theme's design and stylesheet.
*
* Priority 0 to make it available to lower priority callbacks.
*
* @global int $content_width
*
* @since Twenty Sixteen 1.0
*/
function twentysixteen_content_width()
{
$GLOBALS['content_width'] = apply_filters('twentysixteen_content_width', 840);
}
add_action('after_setup_theme', 'twentysixteen_content_width', 0);
/**
* Add preconnect for Google Fonts.
*
* @since Twenty Sixteen 1.6
*
* @param array  $urls           URLs to print for resource hints.
* @param string $relation_type  The relation type the URLs are printed.
* @return array $urls           URLs to print for resource hints.
*/
function twentysixteen_resource_hints($urls, $relation_type)
{
if (wp_style_is('twentysixteen-fonts', 'queue') && 'preconnect' === $relation_type)
{
$urls[] = array(
'href' => 'https://fonts.gstatic.com',
'crossorigin',
);
}
return $urls;
}
add_filter('wp_resource_hints', 'twentysixteen_resource_hints', 10, 2);
/**
* Registers a widget area.
*
* @link https://developer.wordpress.org/reference/functions/register_sidebar/
*
* @since Twenty Sixteen 1.0
*/
function twentysixteen_widgets_init()
{
register_sidebar(array(
'name' => __('Sidebar', 'twentysixteen') ,
'id' => 'sidebar-1',
'description' => __('Add widgets here to appear in your sidebar.', 'twentysixteen') ,
'before_widget' => '<section id="%1$s" class="widget %2$s">',
'after_widget' => '</section>',
'before_title' => '<h2 class="widget-title">',
'after_title' => '</h2>',
));
/*register_sidebar(array(
'name' => __('Content Bottom 1', 'twentysixteen') ,
'id' => 'sidebar-2',
'description' => __('Appears at the bottom of the content on posts and pages.', 'twentysixteen') ,
'before_widget' => '<section id="%1$s" class="widget %2$s">',
'after_widget' => '</section>',
'before_title' => '<h2 class="widget-title">',
'after_title' => '</h2>',
));
register_sidebar(array(
'name' => __('Content Bottom 2', 'twentysixteen') ,
'id' => 'sidebar-3',
'description' => __('Appears at the bottom of the content on posts and pages.', 'twentysixteen') ,
'before_widget' => '<section id="%1$s" class="widget %2$s">',
'after_widget' => '</section>',
'before_title' => '<h2 class="widget-title">',
'after_title' => '</h2>',
));*/
}
add_action('widgets_init', 'twentysixteen_widgets_init');
if (!function_exists('twentysixteen_fonts_url')):
/**
* Register Google fonts for Twenty Sixteen.
*
* Create your own twentysixteen_fonts_url() function to override in a child theme.
*
* @since Twenty Sixteen 1.0
*
* @return string Google fonts URL for the theme.
*/
function twentysixteen_fonts_url()
{
$fonts_url = '';
$fonts = array();
$subsets = 'latin,latin-ext';
/* translators: If there are characters in your language that are not supported by Merriweather, translate this to 'off'. Do not translate into your own language. */
if ('off' !== _x('on', 'Merriweather font: on or off', 'twentysixteen'))
{
$fonts[] = 'Merriweather:400,700,900,400italic,700italic,900italic';
}
/* translators: If there are characters in your language that are not supported by Montserrat, translate this to 'off'. Do not translate into your own language. */
if ('off' !== _x('on', 'Montserrat font: on or off', 'twentysixteen'))
{
$fonts[] = 'Montserrat:400,700';
}
/* translators: If there are characters in your language that are not supported by Inconsolata, translate this to 'off'. Do not translate into your own language. */
if ('off' !== _x('on', 'Inconsolata font: on or off', 'twentysixteen'))
{
$fonts[] = 'Inconsolata:400';
}
if ($fonts)
{
$fonts_url = add_query_arg(array(
'family' => urlencode(implode('|', $fonts)) ,
'subset' => urlencode($subsets) ,
) , 'https://fonts.googleapis.com/css');
}
return $fonts_url;
}
endif;
/**
* Handles JavaScript detection.
*
* Adds a `js` class to the root `<html>` element when JavaScript is detected.
    *
    * @since Twenty Sixteen 1.0
    */
    function twentysixteen_javascript_detection()
    {
    echo "<script>(function(html){html.className = html.className.replace(/\bno-js\b/,'js')})(document.documentElement);</script>\n";
    }
    add_action('wp_head', 'twentysixteen_javascript_detection', 0);
    /**
    * Enqueues scripts and styles.
    *
    * @since Twenty Sixteen 1.0
    */
    function twentysixteen_scripts()
    {
    // Add custom fonts, used in the main stylesheet.
    wp_enqueue_style('twentysixteen-fonts', twentysixteen_fonts_url() , array() , null);
    // Add Genericons, used in the main stylesheet.
    wp_enqueue_style('genericons', get_template_directory_uri() . '/genericons/genericons.css', array() , '3.4.1');
    // Theme stylesheet.
    wp_enqueue_style('twentysixteen-style', get_stylesheet_uri());
    // Theme block stylesheet.
    /* wp_enqueue_style('twentysixteen-block-style', get_template_directory_uri() . '/css/blocks.css', array(
    'twentysixteen-style'
    ) , '20181230');*/
    // Load the Internet Explorer specific stylesheet.
    wp_enqueue_style('twentysixteen-ie', get_template_directory_uri() . '/css/ie.css', array(
    'twentysixteen-style'
    ) , '20160816');
    wp_style_add_data('twentysixteen-ie', 'conditional', 'lt IE 10');
    // Load the Internet Explorer 8 specific stylesheet.
    wp_enqueue_style('twentysixteen-ie8', get_template_directory_uri() . '/css/ie8.css', array(
    'twentysixteen-style'
    ) , '20160816');
    wp_style_add_data('twentysixteen-ie8', 'conditional', 'lt IE 9');
    // Load the Internet Explorer 7 specific stylesheet.
    wp_enqueue_style('twentysixteen-ie7', get_template_directory_uri() . '/css/ie7.css', array(
    'twentysixteen-style'
    ) , '20160816');
    wp_style_add_data('twentysixteen-ie7', 'conditional', 'lt IE 8');
    // Load the html5 shiv.
    wp_enqueue_script('twentysixteen-html5', get_template_directory_uri() . '/js/html5.js', array() , '3.7.3');
    wp_script_add_data('twentysixteen-html5', 'conditional', 'lt IE 9');
    /*wp_enqueue_script('twentysixteen-skip-link-focus-fix', get_template_directory_uri() . '/js/skip-link-focus-fix.js', array() , '20160816', true);*/
    if (is_singular() && comments_open() && get_option('thread_comments'))
    {
    wp_enqueue_script('comment-reply');
    }
    if (is_singular() && wp_attachment_is_image())
    {
    wp_enqueue_script('twentysixteen-keyboard-image-navigation', get_template_directory_uri() . '/js/keyboard-image-navigation.js', array(
    'jquery'
    ) , '20160816');
    }
    /*wp_enqueue_script('twentysixteen-script', get_template_directory_uri() . '/js/functions.js', array(
    'jquery'
    ) , '20181230', true);*/
    wp_localize_script('twentysixteen-script', 'screenReaderText', array(
    'expand' => __('expand child menu', 'twentysixteen') ,
    'collapse' => __('collapse child menu', 'twentysixteen') ,
    ));
    }
    add_action('wp_enqueue_scripts', 'twentysixteen_scripts');
    /**
    * Enqueue styles for the block-based editor.
    *
    * @since Twenty Sixteen 1.6
    */
    function twentysixteen_block_editor_styles()
    {
    // Block styles.
    /*wp_enqueue_style('twentysixteen-block-editor-style', get_template_directory_uri() . '/css/editor-blocks.css', array() , '20181230');*/
    // Add custom fonts.
    wp_enqueue_style('twentysixteen-fonts', twentysixteen_fonts_url() , array() , null);
    }
    add_action('enqueue_block_editor_assets', 'twentysixteen_block_editor_styles');
    /**
    * Adds custom classes to the array of body classes.
    *
    * @since Twenty Sixteen 1.0
    *
    * @param array $classes Classes for the body element.
    * @return array (Maybe) filtered body classes.
    */
    function twentysixteen_body_classes($classes)
    {
    // Adds a class of custom-background-image to sites with a custom background image.
    if (get_background_image())
    {
    $classes[] = 'custom-background-image';
    }
    // Adds a class of group-blog to sites with more than 1 published author.
    if (is_multi_author())
    {
    $classes[] = 'group-blog';
    }
    // Adds a class of no-sidebar to sites without active sidebar.
    if (!is_active_sidebar('sidebar-1'))
    {
    $classes[] = 'no-sidebar';
    }
    // Adds a class of hfeed to non-singular pages.
    if (!is_singular())
    {
    $classes[] = 'hfeed';
    }
    return $classes;
    }
    add_filter('body_class', 'twentysixteen_body_classes');
    /**
    * Converts a HEX value to RGB.
    *
    * @since Twenty Sixteen 1.0
    *
    * @param string $color The original color, in 3- or 6-digit hexadecimal form.
    * @return array Array containing RGB (red, green, and blue) values for the given
    *               HEX code, empty array otherwise.
    */
    function twentysixteen_hex2rgb($color)
    {
    $color = trim($color, '#');
    if (strlen($color) === 3)
    {
    $r = hexdec(substr($color, 0, 1) . substr($color, 0, 1));
    $g = hexdec(substr($color, 1, 1) . substr($color, 1, 1));
    $b = hexdec(substr($color, 2, 1) . substr($color, 2, 1));
    }
    elseif (strlen($color) === 6)
    {
    $r = hexdec(substr($color, 0, 2));
    $g = hexdec(substr($color, 2, 2));
    $b = hexdec(substr($color, 4, 2));
    }
    else
    {
    return array();
    }
    return array(
    'red' => $r,
    'green' => $g,
    'blue' => $b,
    );
    }
    /**
    * Custom template tags for this theme.
    */
    require get_template_directory() . '/inc/template-tags.php';
    /**
    * Customizer additions.
    */
    require get_template_directory() . '/inc/customizer.php';
    /**
    * Add custom image sizes attribute to enhance responsive image functionality
    * for content images
    *
    * @since Twenty Sixteen 1.0
    *
    * @param string $sizes A source size value for use in a 'sizes' attribute.
    * @param array  $size  Image size. Accepts an array of width and height
    *                      values in pixels (in that order).
    * @return string A source size value for use in a content image 'sizes' attribute.
    */
    function twentysixteen_content_image_sizes_attr($sizes, $size)
    {
    $width = $size[0];
    if (840 <= $width)
    {
    $sizes = '(max-width: 709px) 85vw, (max-width: 909px) 67vw, (max-width: 1362px) 62vw, 840px';
    }
    if ('page' === get_post_type())
    {
    if (840 > $width)
    {
    $sizes = '(max-width: ' . $width . 'px) 85vw, ' . $width . 'px';
    }
    }
    else
    {
    if (840 > $width && 600 <= $width)
    {
    $sizes = '(max-width: 709px) 85vw, (max-width: 909px) 67vw, (max-width: 984px) 61vw, (max-width: 1362px) 45vw, 600px';
    }
    elseif (600 > $width)
    {
    $sizes = '(max-width: ' . $width . 'px) 85vw, ' . $width . 'px';
    }
    }
    return $sizes;
    }
    add_filter('wp_calculate_image_sizes', 'twentysixteen_content_image_sizes_attr', 10, 2);
    /**
    * Add custom image sizes attribute to enhance responsive image functionality
    * for post thumbnails
    *
    * @since Twenty Sixteen 1.0
    *
    * @param array $attr Attributes for the image markup.
    * @param int   $attachment Image attachment ID.
    * @param array $size Registered image size or flat array of height and width dimensions.
    * @return array The filtered attributes for the image markup.
    */
    function twentysixteen_post_thumbnail_sizes_attr($attr, $attachment, $size)
    {
    if ('post-thumbnail' === $size)
    {
    if (is_active_sidebar('sidebar-1'))
    {
    $attr['sizes'] = '(max-width: 709px) 85vw, (max-width: 909px) 67vw, (max-width: 984px) 60vw, (max-width: 1362px) 62vw, 840px';
    }
    else
    {
    $attr['sizes'] = '(max-width: 709px) 85vw, (max-width: 909px) 67vw, (max-width: 1362px) 88vw, 1200px';
    }
    }
    return $attr;
    }
    add_filter('wp_get_attachment_image_attributes', 'twentysixteen_post_thumbnail_sizes_attr', 10, 3);
    /**
    * Modifies tag cloud widget arguments to display all tags in the same font size
    * and use list format for better accessibility.
    *
    * @since Twenty Sixteen 1.1
    *
    * @param array $args Arguments for tag cloud widget.
    * @return array The filtered arguments for tag cloud widget.
    */
    function twentysixteen_widget_tag_cloud_args($args)
    {
    $args['largest'] = 1;
    $args['smallest'] = 1;
    $args['unit'] = 'em';
    $args['format'] = 'list';
    return $args;
    }
    add_filter('widget_tag_cloud_args', 'twentysixteen_widget_tag_cloud_args');
    // Add Shortcode
    function bfp_get_template_directory()
    {
    $directory = get_template_directory_uri();
    // Code
    return $directory;
    }
    add_shortcode('template_directory', 'bfp_get_template_directory');
    function custom_site_url()
    {
    $directory = get_site_url();
    // Code
    return $directory;
    }
    add_shortcode('url', 'custom_site_url');
    /*function register_my_menu()
    {
    register_nav_menu('service-menu', __('Service Menu'));
    }
    add_action('init', 'register_my_menu');*/
    function anbuwidgetInit()
    {
    register_sidebar(array(
    'name' => 'Search',
    'id' => 'sidebar1',
    ));
    register_sidebar(array(
    'name' => 'Recent Posts',
    'id' => 'sidebar2',
    ));
    register_sidebar(array(
    'name' => 'Categories',
    'id' => 'sidebar3',
    ));
    register_sidebar(array(
    'name' => 'Tags',
    'id' => 'sidebar4',
    ));
    register_sidebar(array(
    'name' => 'Archive',
    'id' => 'sidebar5',
    ));
     register_sidebar([
        "name" => "Price Range",

        "id" => "pricerange",
    ]);
     register_sidebar([
        "name" => "Product Category",

        "id" => "procategory",
    ]);
     register_sidebar([
        "name" => "Product Search",

        "id" => "product_search",
    ]);
    }
    add_action('widgets_init', 'anbuwidgetInit');
    function my_nav_menu_submenu_css_class($classes)
    {
    $classes[] = 'dl-submenu';
    return $classes;
    }
    add_filter('nav_menu_submenu_css_class', 'my_nav_menu_submenu_css_class');
    //from functions.php
    //First solution : one file
    //If you're using a child theme you could use:
    // get_stylesheet_directory_uri() instead of get_template_directory_uri()
    add_action( 'admin_enqueue_scripts', 'load_admin_style' );
    function load_admin_style() {
    wp_register_style( 'admin_css', get_template_directory_uri() . '/css/admin-style.css', false, '1.0.0' );
    //OR
    wp_enqueue_style( 'admin_css', get_template_directory_uri() . '/css/admin-style.css', false, '1.0.0' );
    }
    //require get_template_directory() . '/inc/custom-post.php';
    function catch_that_image() {
    
    global $post, $posts;
    $first_images = '';
    ob_start();
    ob_end_clean();
    $content = $post->post_content;
    $regex = '/src="([^"]*)"/';
    preg_match_all( $regex, $content, $matches );
    $matches = array_reverse($matches);
    
    foreach($matches[0] as $first_images){
    echo '<div class="card">
        
        <span class="card-image">
            <a href="'.$first_images.'" data-fancybox="clinicgallery" data-caption="Our Gallery">
                <img src="'.$first_images.'" alt="Our Gallery" title="Our Gallery" />
            </a>
        </span>
    </div>';
    }
    return $first_images;
    }
    /*woocommerce*/
    // Add div to after submenu li
    class WPSE_78121_Sublevel_Walker extends Walker_Nav_Menu
    {
    function start_lvl(&$output, $depth = 0, $args = [])
    {
    $indent = str_repeat("\t", $depth);
    $output .= "\n$indent<div class='mp-level'><a class='mp-back' href='#'>back</a><ul class='sub-menu'>\n";
    }
    function end_lvl(&$output, $depth = 0, $args = [])
    {
    $indent = str_repeat("\t", $depth);
$output .= "$indent</ul></div>\n";
}
}
function get_latest_blog_post_links($showposts = "")
{
$footposts = "";
if ($showposts == "") {
$showposts = 3;
}
$temp = $wp_query;
$wp_query = null;
$wp_query = new WP_Query();
$wp_query->query("showposts=" . $showposts . "&paged=" . $paged);
if ($wp_query->have_posts()):
while ($wp_query->have_posts()):
$wp_query->the_post();
$footposts .=
'<a href="' .
    get_permalink() .
    '" title="' .
    get_the_title() .
    '">' .
    get_the_title() .
"</a>";
endwhile;
else:
$footposts = '<a href="#">  Can natural Spices relieve toothaches?</a><a href="#">Root canals for kids - is it safe?</a><a href="#"> How to treat heavily stained teeth</a>';
endif;
return $footposts;
}
add_action("after_setup_theme", "setup_woocommerce_support");
function setup_woocommerce_support()
{
add_theme_support("woocommerce");
add_theme_support("wc-product-gallery-zoom");
add_theme_support("wc-product-gallery-lightbox");
add_theme_support("wc-product-gallery-slider");
}
// Remove the sorting dropdown from Woocommerce
remove_action(
"woocommerce_before_shop_loop",
"woocommerce_catalog_ordering",
30
);
// Remove the result count from WooCommerce
remove_action("woocommerce_before_shop_loop", "woocommerce_result_count", 20);
// sorting
remove_action(
"woocommerce_before_shop_loop",
"woocommerce_catalog_ordering",
30
);
add_action("woo_custom_catalog_ordering", "woocommerce_catalog_ordering", 30);
/**
* @snippet       Remove shop page title - WooCommerce Shop
*/
add_filter("woocommerce_show_page_title", "cust_hide_shop_page_title");
function cust_hide_shop_page_title($title)
{
if (is_shop()) {
$title = false;
}
return $title;
}
/**
* @snippet       Remove cat page title - WooCommerce Cat pages
*/
add_filter("woocommerce_show_page_title", "cust_hide_cat_page_title");
function cust_hide_cat_page_title($title)
{
if (is_product_category()) {
$title = false;
}
return $title;
}
// Star rating
add_action("woocommerce_after_shop_loop_item", "add_star_rating");
function add_star_rating()
{
global $woocommerce, $product;
$average = $product->get_average_rating();
echo '<div class="star-rating"><span style="width:' .
    ($average / 5) * 100 .
    '%"><strong itemprop="ratingValue" class="rating">' .
    $average .
    "</strong> " .
    __("out of 5", "woocommerce") .
"</span></div>";
}
/**
* @snippet       Remove page title from all WooCommerce archive pages
*/
//add_filter( 'woocommerce_show_page_title', '__return_null' );
add_filter("body_class", "cust_wc_product_cats_css_body_class");
function cust_wc_product_cats_css_body_class($classes)
{
if (is_tax("product_cat")) {
$cat = get_queried_object();
if (0 < $cat->parent) {
$classes[] = "subcategory";
}
}
return $classes;
}
if (!function_exists("product_test")) {
// Add Shortcode
function product_test($atts)
{
global $woocommerce_loop;
// Attributes
$atts = shortcode_atts(
[
"columns" => "2",
"limit" => "6",
"start" => current_time("2019-06-01"),
"end" => current_time("2019-07-22"),
],
$atts,
"products_test"
);
$woocommerce_loop["columns"] = $atts["columns"];
// The WP_Query
$products = new WP_Query([
"post_type" => "product",
"post_status" => "publish",
"posts_per_page" => $atts["limit"],
"tax_query" => [
[
"taxonomy" => "product_visibility",
"field" => "name",
"terms" => "featured",
],
],
]);
ob_start();
if ($products->have_posts()) { ?>
<?php woocommerce_product_loop_start(); ?>
<?php while ($products->have_posts()):
$products->the_post(); ?>
<?php wc_get_template_part("content", "product"); ?>
<?php
endwhile;
// end of the loop.
?>
<?php woocommerce_product_loop_end(); ?>
<?php } else {do_action(
"woocommerce_shortcode_products_loop_no_results",
$atts
);
echo "<p>There is no results.</p>";}
woocommerce_reset_loop();
wp_reset_postdata();
return '<div class="woocommerce columns-' .
    $atts["columns"] .
    '">' .
    ob_get_clean() .
"</div>";
}
add_shortcode("products_test", "product_test");
}
/**
* @snippet       [recently_viewed_products] Shortcode - WooCommerce
*/
add_shortcode("recently_viewed_products", "cust_recently_viewed_shortcode");
function cust_recently_viewed_shortcode()
{
$viewed_products = !empty($_COOKIE["woocommerce_recently_viewed"])
? (array) explode(
"|",
wp_unslash($_COOKIE["woocommerce_recently_viewed"])
)
: [];
$viewed_products = array_reverse(
array_filter(array_map("absint", $viewed_products))
);
if (empty($viewed_products)) {
return;
}
//$title = '<h3>Recently Viewed Products</h3>';
$product_ids = implode(",", $viewed_products);
return do_shortcode("[products limit='4' ids='$product_ids']");
}
/*—————————————————————————-*/
// redirects for login / logout
/*—————————————————————————-*/
add_filter("woocommerce_login_redirect", "login_redirect");
function login_redirect($redirect_to)
{
return home_url();
}
add_action("wp_logout", "logout_redirect");
function logout_redirect()
{
wp_redirect(home_url());
exit();
}
add_filter("woocommerce_product_tabs", "woo_remove_product_tabs", 98);
function woo_remove_product_tabs($tabs)
{
unset($tabs["description"]); // Remove Description tab
unset($tabs["additional_information"]); // Removes the additional information tab
//unset( $tabs['reviews'] );  // Removes the reviews tab
return $tabs;
}
// Best Selling shortcode
function get_best_selling_products($limit = "-1")
{
global $wpdb;
$limit_clause = intval($limit) <= 0 ? "" : "LIMIT " . intval($limit);
$curent_month = date("Y-m-01 00:00:00");
return (array) $wpdb->get_results("
SELECT p.ID as id, COUNT(oim2.meta_value) as count
FROM {$wpdb->prefix}posts p
INNER JOIN {$wpdb->prefix}woocommerce_order_itemmeta oim
ON p.ID = oim.meta_value
INNER JOIN {$wpdb->prefix}woocommerce_order_itemmeta oim2
ON oim.order_item_id = oim2.order_item_id
INNER JOIN {$wpdb->prefix}woocommerce_order_items oi
ON oim.order_item_id = oi.order_item_id
INNER JOIN {$wpdb->prefix}posts as o
ON o.ID = oi.order_id
WHERE p.post_type = 'product'
AND p.post_status = 'publish'
AND o.post_status IN ('wc-prodcessing','wc-completed')
AND o.post_date >= '$curent_month'
AND oim.meta_key = '_product_id'
AND oim2.meta_key = '_qty'
GROUP BY p.ID
ORDER BY COUNT(oim2.meta_value) + 0 DESC
$limit_clause
");
}
//short code to get the woocommerce recently viewed products
function custom_track_product_view()
{
if (!is_singular("product")) {
return;
}
global $post;
if (empty($_COOKIE["woocommerce_recently_viewed"])) {
$viewed_products = [];
} else {
$viewed_products = (array) explode(
"|",
$_COOKIE["woocommerce_recently_viewed"]
);
}
if (!in_array($post->ID, $viewed_products)) {
$viewed_products[] = $post->ID;
}
if (sizeof($viewed_products) > 15) {
array_shift($viewed_products);
}
// Store for session only
wc_setcookie("woocommerce_recently_viewed", implode("|", $viewed_products));
}
add_action("template_redirect", "custom_track_product_view", 20);
function rc_woocommerce_recently_viewed_products($atts, $content = null)
{
// Get shortcode parameters
extract(
shortcode_atts(
[
"per_page" => "12",
],
$atts
)
);
// Get WooCommerce Global
global $woocommerce;
global $product;
// Get recently viewed product cookies data
$viewed_products = !empty($_COOKIE["woocommerce_recently_viewed"])
? (array) explode("|", $_COOKIE["woocommerce_recently_viewed"])
: [];
$viewed_products = array_filter(array_map("absint", $viewed_products));
// If no data, quit
if (empty($viewed_products)) {
return __("You have not viewed any product yet!", "rc_wc_rvp");
}
// Create the object
ob_start();
// Get products per page
if (!isset($per_page) ? ($number = 5) : ($number = $per_page)) {
// Create query arguments array
$query_args = [
"posts_per_page" => $number,
"no_found_rows" => 1,
"post_status" => "publish",
"post_type" => "product",
"post__in" => $viewed_products,
"orderby" => "rand",
];
}
// Add meta_query to query args
$query_args["meta_query"] = [];
// Check products stock status
$query_args[
"meta_query"
][] = $woocommerce->query->stock_status_meta_query();
// Create a new query
$products = new WP_Query($query_args);
// ----
if (empty($products)) {
return __("You have not viewed any product yet!", "rc_wc_rvp");
}
?>
<?php while ($products->have_posts()):
$products->the_post();
$url = wp_get_attachment_url(get_post_thumbnail_id($post->ID));
?>
<!--recentent-product-content-->
<?php
endwhile; ?>
<?php
wp_reset_postdata();
return '<div class="woocommerce columns-5 facetwp-template">' .
    ob_get_clean() .
"</div>";
// ----
// Get clean object
$content .= ob_get_clean();
// Return whole content
return $content;
}
// Register the shortcode
add_shortcode(
"woocommerce_recently_viewed_products",
"rc_woocommerce_recently_viewed_products"
);
/**
* @snippet       Change return to shop link, send to homepage instead
*/
add_filter(
"woocommerce_return_to_shop_redirect",
"bbloomer_change_return_shop_url"
);
function bbloomer_change_return_shop_url()
{
return home_url();
}
add_filter("wc_add_to_cart_message", "my_add_to_cart_function", 10, 2);
function my_add_to_cart_function($message, $product_id)
{
$message = sprintf(
esc_html__("« %s » has been added by to your cart.", "woocommerce"),
get_the_title($product_id)
);
return $message;
}
/**
* Hide shipping rates when free shipping is available, but keep "Local pickup"
* Updated to support WooCommerce 2.6 Shipping Zones
*/
function hide_shipping_when_free_is_available($rates, $package)
{
$new_rates = [];
foreach ($rates as $rate_id => $rate) {
// Only modify rates if free_shipping is present.
if ("free_shipping" === $rate->method_id) {
$new_rates[$rate_id] = $rate;
break;
}
}
if (!empty($new_rates)) {
//Save local pickup if it's present.
foreach ($rates as $rate_id => $rate) {
if ("local_pickup" === $rate->method_id) {
$new_rates[$rate_id] = $rate;
break;
}
}
return $new_rates;
}
return $rates;
}
add_filter(
"woocommerce_package_rates",
"hide_shipping_when_free_is_available",
10,
2
);
/**
* Remove all product structured data.
*/
/*
function remove_output_structured_data()
{
remove_action('wp_footer', array(
WC()->structured_data,
'output_structured_data'
) , 10); // Frontend pages

//remove_action( 'woocommerce_email_order_details', array( WC()->structured_data, 'output_email_structured_data' ), 30 ); // Emails


}
add_action('init', 'remove_output_structured_data');*/
add_filter(
"woocommerce_min_password_strength",
"reduce_min_strength_password_requirement"
);
function reduce_min_strength_password_requirement($strength)
{
// 3 => Strong (default) | 2 => Medium | 1 => Weak | 0 => Very Weak (anything).
return 1;
}
// Disable zipcode validation in checkout field
add_filter(
"woocommerce_default_address_fields",
"woocommerce_override_postcode_validation"
);
function woocommerce_override_postcode_validation($address_fields)
{
$address_fields["postcode"]["required"] = true;
return $address_fields;
}
// Add Number captcha in checkout
function so_31413975_filter_checkout_fields($fields)
{
$fields["extra_fields"] = [
"human_check" => [
"type" => "text",
"label" => __("What is 1+1?", "numcaptcha"),
"placeholder" => __("Enter a number", "numcaptcha"),
],
];
return $fields;
}
add_filter("woocommerce_checkout_fields", "so_31413975_filter_checkout_fields");
function so_31413975_extra_checkout_fields()
{
$checkout = WC()->checkout(); ?>
<div class="extra-fields" style="background: #f5f5f5;padding: 1em;">
    <h3><?php _e("Are you human?", "numcaptcha"); ?></h3>
    <?php // because of this foreach, everything added to the array in the previous function will display automagically
    foreach ($checkout->checkout_fields["extra_fields"] as $key => $field): ?>
    <?php woocommerce_form_field($key, $field, $checkout->get_value($key)); ?>
    <?php endforeach; ?>
</div>
<?php
}
add_action(
"woocommerce_checkout_order_review",
"so_31413975_extra_checkout_fields"
);
add_filter("woocommerce_checkout_fields", "custom_billing_fields", 1000, 1);
function custom_billing_fields($fields)
{
$fields["extra_fields"]["human_check"]["required"] = true;
return $fields;
}
add_filter(
"woocommerce_add_to_cart_fragments",
"iconic_cart_count_fragments",
10,
1
);
function iconic_cart_count_fragments($fragments)
{
$fragments["font.header-cart-count"] =
'<font class="header-cart-count">' .
    WC()->cart->get_cart_contents_count() .
"</font>";
return $fragments;
}
//
// Add variation to cart
if (!is_user_logged_in()) {
add_action(
"wp_ajax_nopriv_woocommerce_add_variation_to_cart",
"so_27270880_add_variation_to_cart"
);
} else {
add_action(
"wp_ajax_woocommerce_add_variation_to_cart",
"so_27270880_add_variation_to_cart"
);
}
function so_27270880_add_variation_to_cart()
{
ob_start();
$product_id = apply_filters(
"woocommerce_add_to_cart_product_id",
absint($_POST["product_id"])
);
$quantity = empty($_POST["quantity"])
? 1
: wc_stock_amount($_POST["quantity"]);
$variation_id = isset($_POST["variation_id"])
? absint($_POST["variation_id"])
: "";
$variations = !empty($_POST["variation"])
? (array) $_POST["variation"]
: "";
$passed_validation = apply_filters(
"woocommerce_add_to_cart_validation",
true,
$product_id,
$quantity,
$variation_id,
$variations,
$cart_item_data
);
if (
$passed_validation &&
WC()->cart->add_to_cart(
$product_id,
$quantity,
$variation_id,
$variations
)
) {
do_action("woocommerce_ajax_added_to_cart", $product_id);
if (get_option("woocommerce_cart_redirect_after_add") == "yes") {
wc_add_to_cart_message($product_id);
}
// Return fragments
WC_AJAX::get_refreshed_fragments();
} else {
// If there was an error adding to the cart, redirect to the product page to show any errors
$data = [
"error" => true,
"product_url" => apply_filters(
"woocommerce_cart_redirect_after_error",
get_permalink($product_id),
$product_id
),
];
wp_send_json($data);
}
die();
}
function cart_has_product_with_shipping_class($slug)
{
global $woocommerce;
$product_in_cart = false;
$noclass_in_cart = false;
// start of the loop that fetches the cart items
foreach ($woocommerce->cart->get_cart() as $cart_item_key => $values) {
$_product = $values["data"];
$terms = get_the_terms($_product->id, "product_shipping_class");
if ($terms) {
foreach ($terms as $term) {
$_shippingclass = $term->slug;
if ($slug === $_shippingclass) {
// Our Shipping Class is in cart!
$product_in_cart = true;
}
}
} else {
$noclass_in_cart = true;
}
}
if ($noclass_in_cart) {
$product_in_cart = false;
}
return $product_in_cart;
}
//
function doAjax()
{
$result = getPosts();
echo json_encode($result, true);
die();
}
function checkuserlogin()
{
global $product;
if (!is_user_logged_in()) {
/*$page = get_page_by_title( 'Home' );
$hideprice_cat = get_post_meta( $page->ID, 'hideprice_cat', true );*/
// Hide for these category slugs / IDs
//$hide_for_categories = explode(',',$hideprice_cat);
$hide_for_categories = ["hide-price"];
// Don’t show price when its in one of the categories
if (has_term($hide_for_categories, "product_cat", $product->get_id())) {
return true;
}
}
return false;
}
function checkuserlogincat($checkcat)
{
if (!is_user_logged_in()) {
/*$page = get_page_by_title( 'Home' );
$hideprice_cat = get_post_meta( $page->ID, 'hideprice_cat', true );*/
// Hide for these category slugs / IDs
//$hide_for_categories = explode(',',$hideprice_cat);
$hide_for_categories = ["hide-price"];
// Don’t show price when its in one of the categories
$uniqueval = array_intersect($hide_for_categories, $checkcat);
if (count($uniqueval) > 0) {
return true;
}
}
return false;
}
//add_filter( 'woocommerce_cart_item_price', '__return_false' );
//add_filter( 'woocommerce_cart_item_subtotal', '__return_false' );
add_action("widgets_init", "anbuwidgetInit");
function new_excerpt_more($more)
{
global $post;
return '<a class="moretag" href="' .
    get_permalink($post->ID) .
    '"> <span style="float:right"><font style="font-size:12px;color:#FFCC00;text-decoration:none;font-weight:bold">(more)</font></span></a>';
    }
    add_filter("excerpt_more", "new_excerpt_more");
    /*
    * Set post views count using post meta
    */
    function setPostViews($postID)
    {
    $countKey = "post_views_count";
    $count = get_post_meta($postID, $countKey, true);
    if ($count == "") {
    $count = 0;
    delete_post_meta($postID, $countKey);
    add_post_meta($postID, $countKey, "0");
    } else {
    $count++;
    update_post_meta($postID, $countKey, $count);
    }
    }
    //
    function filter_woocommerce_registration_redirect($var)
    {
    return get_permalink(woocommerce_get_page_id("shop"));
    }
    add_filter(
    "woocommerce_registration_redirect",
    "filter_woocommerce_registration_redirect",
    10,
    1
    );
    add_filter("woocommerce_login_redirect", "hs_login_redirect");
    function hs_login_redirect($redirection_url)
    {
    $redirection_url = wc_get_checkout_url();
    return $redirection_url;
    }
    //
    // Categories by name //
    function woocommerce_subcats_from_parentcat_by_NAME($parent_cat_NAME)
    {
    $catlist = [];
    $IDbyNAME = get_term_by("name", $parent_cat_NAME, "product_cat");
    $product_cat_ID = $IDbyNAME->term_id;
    $args = [
    "hierarchical" => 1,
    "show_option_none" => "",
    "hide_empty" => 0,
    "parent" => $product_cat_ID,
    "taxonomy" => "product_cat",
    ];
    $subcats = get_categories($args);
    $i = 0;
    foreach ($subcats as $key => $sc) {
    $link = get_term_link($sc->slug, $sc->taxonomy);
    $name = $sc->name;
    $thumbnail_id = get_woocommerce_term_meta(
    $sc->term_id,
    "thumbnail_id",
    true
    );
    // get the image URL
    $image = wp_get_attachment_url($thumbnail_id);
    $catlist[$i]["name"] = $name;
    $catlist[$i]["catlink"] = $link;
    $catlist[$i]["imageurl"] = $image;
    $i++;
    }
    return $catlist;
    }
    // Remove related product title
    add_filter("woocommerce_product_related_products_heading", function () {
    return "";
    });
    // Get Product Deepest Child  Category
    function get_product_child_category($productid)
    {
    $productcat_name = "";
    // get all product cats for the current post
    $categories = get_the_terms($productid, "product_cat");
    $exclude_cat_id = get_term_by("name", "Hide Price", "product_cat");
    // wrapper to hide any errors from top level categories or products without category
    if ($categories && !is_wp_error($category)):
    // loop through each cat
    foreach ($categories as $category):
    //if($category->name=="Collection"){
    // get the children (if any) of the current cat
    $children = get_categories([
    "taxonomy" => "product_cat",
    "parent" => $category->term_id,
    ]);
    if (count($children) == 0) {
    // if no children, then echo the category name.
    $parentcats = get_ancestors($category->term_id, "product_cat");
    foreach ($parentcats as $CatID) {
    $term = get_term_by("id", $CatID, "product_cat", "ARRAY_A");
    if ($term) {
    $productcat_name = $category->name;
    }
    }
    }
    //}
    endforeach;
    return $productcat_name;
    endif;
    }
    function my_widgets_init()
    {
    register_sidebar([
    "name" => "category",
    "id" => "category",
    "before_widget" => "<div>",
        "after_widget" => "</div><div>&nbsp;</div>",
        "before_title" => '<h2 class="rounded">',
        "after_title" => "</h2>",
        ]);
        }
        add_action("widgets_init", "my_widgets_init");
        //add_filter( 'woocommerce_cart_item_price', '__return_false' );
        //add_filter( 'woocommerce_cart_item_subtotal', '__return_false' );
        function my_searchwp_include_only_category( $ids, $engine, $terms ) {
        // if and only if a category ID was submitted:
        // we only want to apply this limitation to the default search engine
        // if you would like to change that you can do so here
        if ( ! empty( $_GET['swp_category_limiter'] ) && 'default' == $engine ) {
        $category_id = get_term_by('name', 'Location', 'product_cat');
        $IDbybrand = get_term_by('name', 'Location', 'product_cat');
        $brand_cat_ID = $IDbybrand->term_id;
        $category_args = array(
        'category'       => $brand_cat_ID,  // limit to the chosen category ID
        'fields'         => 'ids',         // we only want the IDs of these posts
        'parent' => $brand_cat_ID,
        'posts_per_page' => -1,            // return ALL posts
        );
        $ids = get_posts( $category_args );
        // if there were no posts returned we need to force an empty result
        if ( 0 == count( $ids ) ) {
        $ids = array( 0 ); // this will force SearchWP to return zero results
        }
        }
        // always return our $ids
        return $ids;
        }
        add_filter( 'searchwp_include', 'my_searchwp_include_only_category', 10, 3 );
        //
        add_filter('woocommerce_currency_symbol', 'change_existing_currency_symbol', 10, 2);
        function change_existing_currency_symbol( $currency_symbol, $currency ) {
        switch( $currency ) {
        case 'INR': $currency_symbol = 'Rs.'; break;
        }
        return $currency_symbol;
        }
        //
        
        
        add_filter( 'woocommerce_checkout_login_message', 'bbloomer_return_customer_message' );
        
        function bbloomer_return_customer_message() {
        return 'Existing customer?';
        }
        // Adding Meta container admin shop_order pages
        add_action( 'add_meta_boxes', 'mv_add_meta_boxes' );
        if ( ! function_exists( 'mv_add_meta_boxes' ) )
        {
        function mv_add_meta_boxes()
        {
        add_meta_box( 'mv_other_fields', __('My Field','woocommerce'), 'mv_add_other_fields_for_packaging', 'shop_order', 'side', 'core' );
        }
        }
        // Adding Meta field in the meta container admin shop_order pages
        if ( ! function_exists( 'mv_add_other_fields_for_packaging' ) )
        {
        function mv_add_other_fields_for_packaging()
        {
        global $post;
        $meta_field_data = get_post_meta( $post->ID, '_my_field_slug', true ) ? get_post_meta( $post->ID, '_my_field_slug', true ) : '';
        $html = '<form action="#" method="post" enctype="multipart/form-data">
            <input type="file" style="width:250px;";" name="my_field_name" placeholder="' . $meta_field_data . '" value="' . $meta_field_data . '">
            <input type="submit" name="custom_submit" value="Submit">
        </form>';
        echo $html;
        }
        }
        // if(){
        
        // }
        add_action( 'woocommerce_admin_order_data_after_billing_address', 'my_custom_checkout_field_display_admin_order_meta', 10, 1 );
        function my_custom_checkout_field_display_admin_order_meta($order){
        $my_custom_field = get_post_meta( $order->id, '_my_field_slug', true );
        echo '<p><strong>'. __("Application", "woocommerce").':</strong> ' .get_post_meta( $order->id, '_my_field_slug', true ) . '</p>';
        }



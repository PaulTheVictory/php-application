<?php
/**
 * The template for displaying archive pages
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package PhotoFocus
 */

get_header(); ?>



<!--blog_menu-->

<section class="blog_menu">
	<div class="wrap_grid">
		<div class="blog_menu_head">
			<ul>
				<li id="categories"><a href="javascript:void(0)">Categories</a></li>
				<li id="tags"><a href="javascript:void(0)">Tags</a></li>
				<li id="archives"><a href="javascript:void(0)">Archives</a></li>
			</ul>
			<div class="search_form">
				<div id="wrap">
					<form role="search" method="get" id="searchform" action="<?php echo home_url( '/' ); ?>">
							<input type="hidden" name="post_type" value="post" />
							<input type="text" value="" name="s" placeholder="Search post" />
							<input type="submit" value="" />
					</form>
				</div>	
			</div>
		</div>
		<div class="blog_menu_content">
			<div id="categorieso" class="content">
				<?php dynamic_sidebar('sidebar3'); ?>
			</div>
			<div id="tagso" class="content">
				<?php dynamic_sidebar('sidebar4'); ?>
			</div>
			<div id="archiveso" class="content">
				<?php dynamic_sidebar('sidebar5'); ?>
			</div>
		</div>
	</div>
</section>

<!--blog_menu-->


<!--blog_section-->

<h1 style="color:#fff;font-size:45px;"><?php get_the_archive_title(); ?></h1>
<section class="blog_page_section">
	<div class="wrap_grid">
	<div class="head_text">
		<h1><?php  echo get_the_archive_title(); ?></h1>
			
			</div>
		<ul>
			<?php  
				$page_object = get_queried_object(); 
				$temp = $wp_query; $wp_query= null;
				$wp_query = new WP_Query(); $wp_query->query('category_name='.$page_object->cat_name.'&showposts=20' . '&paged='.$paged);
				if($wp_query->have_posts()) : 
				while ($wp_query->have_posts()) : $wp_query->the_post(); 
			?>

				<li>
					<div class="blog_bottom_align">
						<div class="blog_bottom_left">
							<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>">
								<?php if ( has_post_thumbnail() ) { the_post_thumbnail('full');} else{?>
									<img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/no_blog.jpg" alt="<?php the_title(); ?>" />
								<?php }?>
							</a>
						</div>
						<div class="blog_bottom_right">
							<h2><?php the_title(); ?></h2>
							<p><?php echo substr(wp_strip_all_tags(get_the_excerpt(''),true),0,160);?></p>
							<a href="<?php the_permalink() ?>" title="Read More"><button>Read More</button></a>
						</div>
					</div>
				</li>
				<?php endwhile; ?>
				
				
			</ul>
			<div class="pagination">
				<!--<button>Older Posts</button>-->
			
			<?php wp_reset_postdata(); ?>
<?php else : ?>
<h1 class="search-title">No results Found</h1>
<p class="search-text">It seems we can’t find what you’re looking for. Perhaps you should try again with a different search term.</p>
<?php endif; ?>
			
	</div>
</section>

<!--instagram_section-->







<?php

get_footer();

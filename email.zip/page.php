<?php

get_header(); ?>

<?php if(get_the_title()=="Blog"){ ?>
<!--slider_section-->
 <section class="slide_section">
	<div id="home_slider" class="carousel bs-slider slide control-round indicators-line" data-ride="carousel" data-pause="hover" data-interval="false">
		<div class="carousel-inner" role="listbox">
			<div class="item active">
				<img src="<?php echo esc_url(get_template_directory_uri());?>/images/banner/blogn.png" alt="Banenr" class="desk_banner">
				<img src="<?php echo esc_url(get_template_directory_uri());?>/images/banner/blogmn.png" alt="Banenr" class="mob_banner">
				<div class="slide-text">
					<div class="slide_text_left">
						<h2 data-animation="animated fadeInLeft">Get your
knowlege updated</h2>
						<a class="book" href="javascript:void(0)" title="Send Enquiry"><button data-animation="animated fadeInLeft">Send Enquiry</button></a>
					</div>
					
				</div>
			</div>
			
			<!-- <a class="nav_left" href="#home_slider" role="button" data-slide="prev"></a>
			<a class="nav_right" href="#home_slider" role="button" data-slide="next"></a>  
			<ol class="nav_dots carousel-indicators">
				<li data-target="#home_slider" data-slide-to="0" class="active"></li>
				<li data-target="#home_slider" data-slide-to="1"></li>
			</ol> -->
		</div>
	</div>
</section> 
<!--slider_section-->
<?php } ?>

<?php if(get_the_title()=="About Us"){ ?>

	
		<?php

		while ( have_posts() ) :

		the_post();

		the_content();

		endwhile;

		?>

<?php } else if(get_the_title()=="Checkout"){ ?>

		<div class="all_pages">
	<div class="wrap_grid">
		
			<div class="head_text">
				<h1><?php the_title(); ?></h1>
			</div>
			
			<?php

			while ( have_posts() ) :

			the_post();

			the_content();

			endwhile;

			?>
			<a href="<?php echo get_site_url();?>" title="Back to Home"> <button id="back_to_home">Back to Home</button></a>
		<a href="<?php echo get_site_url();?>/shop/" title="Back to Shop"> <button id="back_to_home">Back to Shop</button></a>
		
		</div>
		</div>	

	<?php } else if(get_the_title()=="Cart"){ ?>

		<div class="all_pages">
	<div class="wrap_grid">
		
			<div class="head_text">
				<h1><?php the_title(); ?></h1>
			</div>
			
			<?php

			while ( have_posts() ) :

			the_post();

			the_content();

			endwhile;

			?>
		
		</div>
		</div>	
	
<?php } else if(get_the_title()=="My account"){ ?>

		<div class="all_pages cart_page">
	<div class="wrap_grid">
		
			<div class="head_text">
				<h1><?php the_title(); ?></h1>
			</div>
			
			<?php

			while ( have_posts() ) :

			the_post();

			the_content();

			endwhile;

			?>
		
		</div>
		</div>	
	

<?php } else if(get_the_title()=="Contact Us"){ ?>

		<?php

		/*while ( have_posts() ) :

		the_post();

		the_content();

		endwhile;*/

		?>
		
		
	
<?php } else if(get_the_title()!="Blog"){ ?>


	<div class="all_pages">
	<div class="wrap_grid">
		<div class="single_blog blog_page_listing_left_single">
			<div class="head_text">
				<h1><?php the_title(); ?></h1>
			</div>
			
			<?php

			while ( have_posts() ) :

			the_post();

			the_content();

			endwhile;

			?>
		</div>
		</div>
		</div>	
		
		
<?php } else { ?>




<!--blog_section-->


<section class="blog_page_section">
	<div class="wrap_grid">
		<div class="head_text">
			<h1>Our Latest Articles</h1>
			<span>Blog</span>
		</div>
		<ul>
			<?php 
				
				
			$temp = $wp_query; $wp_query= null;
			$wp_query = new WP_Query(); $wp_query->query('showposts=9' . '&paged='.$paged);
			if($wp_query->have_posts()) : 
			while ($wp_query->have_posts()) : $wp_query->the_post(); ?>
			<li>
					<div class="blog_bottom_align">
						<div class="blog_bottom_left">
							<a class="feature" href="<?php the_permalink() ?>" title="<?php the_title(); ?>"> 
								<?php if ( has_post_thumbnail() ) { the_post_thumbnail('medium_large');}else{?> 
									<img src="<?php echo esc_url(get_template_directory_uri());?>/images/no_blog.jpg" alt="<?php the_title(); ?>">	
								<?php } ?></a>
						</div>
						<div class="blog_bottom_right">
							<p><?php the_time('F jS,Y'); ?></p>
							<h2><?php the_title(); ?></h2>
							
							<a href="<?php the_permalink() ?>" title="Read More"><button>Read More</button></a>
						</div>
					</div>
				</li>
			<?php endwhile; ?>
					</ul>
					
					<?php
					 the_posts_pagination( array(
					 'mid_size' => 1,
        'prev_text'          => __( 'Prev', 'textdomain' ),
        'next_text'          => __( 'Next', 'textdomain' ),
        //'before_page_number' => '<span class="meta-nav screen-reader-text">' . __( 'Page', 'textdomain' ) . ' </span>',
    ) );
	?>
					<?php wp_reset_postdata(); ?>
					<?php else : ?>
					<p>There is no posts...</p>
					<?php endif;?>
			
	</div>
</section>



   
<?php }?>



<?php get_footer(); ?>

<script>
$( ".carousel-inner .item:first-child" ).addClass( "active" );
</script>




<?php
/*Template Name:About Us*/
get_header();?>

<!--slider_section-->
<section class="slide_section">
	<div id="home_slider" class="carousel bs-slider slide control-round indicators-line" data-ride="carousel" data-pause="hover" data-interval="false">
		<div class="carousel-inner" role="listbox">
			<div class="item active">
				<img src="<?php echo esc_url(get_template_directory_uri());?>/images/banner/aboutus.png" alt="Banenr" class="desk_banner">
				<img src="<?php echo esc_url(get_template_directory_uri());?>/images/banner/aboutusm.png" alt="Banenr" class="mob_banner">
				<div class="slide-text">
					<div class="slide_text_left">
						<h2 data-animation="animated fadeInLeft">Serving healthy
products For
53 Years</h2>
						<a class="book" href="<?php echo get_site_url();?>/contact-us/" title="Send Enquiry"><button data-animation="animated fadeInLeft">Send Enquiry</button></a>
					</div>
					
				</div>
			</div>
			
			<!-- <a class="nav_left" href="#home_slider" role="button" data-slide="prev"></a>
			<a class="nav_right" href="#home_slider" role="button" data-slide="next"></a>  
			<ol class="nav_dots carousel-indicators">
				<li data-target="#home_slider" data-slide-to="0" class="active"></li>
				<li data-target="#home_slider" data-slide-to="1"></li>
			</ol> -->
		</div>
	</div>
</section>
<!--slider_section-->




<!--inner_aboutus_section-->

<div class="inner_aboutus_section aboutus_org">
	<div class="wrap_grid">
		<div class="head_text">
			<h1>ABOUT US</h1>
			<span>ABOUT US</span>
		</div>
		
		<ul>
			<li>
				<div class="ourstory_box_align">
					<div class="ourstory_box_left">
						<img src="<?php echo esc_url(get_template_directory_uri()); ?>/images/about/about1.png" alt="Our about">
					</div>
					<div class="ourstory_box_right">
						
						<p>JyothisPure - the best source for natural jaggery powder. Right from the beginning, we
were known as a prominent trader and manufacturer of Jaggery powder and Wood
Pressed Oil. It is not an overnight decision to build this empire of JyothisPure. We, as a
family, worked hard to construct this brand for generations from scratch.Our motive is to make our business simple and digitalized for consumers. Our jaggery
powder is produced with minimal operating costs and highly skilled laborers. This not
only benefits the farmers but also helps people to purchase original jaggery powder at
an affordable cost without any self-based mediators.</p>
					</div>
				</div>
			</li>
		</ul>
	</div>
</div>

<!--inner_aboutus_section-->

<!--vision_mission_section-->

<div class="vision_mission_section">
	<div class="wrap_grid">
		<ul>
			<li>
				<div class="boxs">
					<img src="<?php echo esc_url(get_template_directory_uri()); ?>/images/about/vision.png" alt="vision_mission">
					<h4>Vision</h4>
					<p>We are content with customer satisfaction and never compromise on quality. Our vision
 is to promote a healthy lifestyle by inculcating jaggery in people’s meals</p>
				</div>
			</li>
			<li>
				<div class="boxs">
					<img src="<?php echo esc_url(get_template_directory_uri()); ?>/images/about/mission.png" alt="vision_mission">
					<h4>mission</h4>
					<p>Replacing white
sugar forever. You enlighten a farmer’s life for your every purchase from JyothisPure</p>
				</div>
			</li>
		</ul>
	</div>
</div>


<!--vision_mission_section-->


<!--founder_section-->


<!-- <div class="founder_section">
	<div class="wrap_grid">
		<div class="head_text">
			<h2>Our Founders</h2>
			<span>founders</span>
		</div>
		<ul>
			<li>
				<div class="founder_align">
					<div class="founder_left">
						<img src="<?php echo esc_url(get_template_directory_uri()); ?>/images/about/1.png" alt="founder">
					</div>
					<div class="founder_right">
						<h2>Mr. Rangachari</h2>
						<h5>Founder of naatu sakkarai</h5>
						<p>Alle origini di un buon olio extravergine di oliva ci sono due ingredienti: l’ulivo e la mano esperta di chi sa come trattarlo. Albori punta a valorizzare questi elementi, insieme all’importanza del territorio di provenienza, la Puglia.
Alle origini di un buon olio extravergine di oliva ci sono due </p>
					</div>
				</div>
			</li>
			<li>
				<div class="founder_align">
					<div class="founder_left">
						<img src="<?php echo esc_url(get_template_directory_uri()); ?>/images/about/2.png" alt="founder">
					</div>
					<div class="founder_right">
						<h2>Mr. Rangachari</h2>
						<h5>Founder of naatu sakkarai</h5>
						<p>Alle origini di un buon olio extravergine di oliva ci sono due ingredienti: l’ulivo e la mano esperta di chi sa come trattarlo. Albori punta a valorizzare questi elementi, insieme all’importanza del territorio di provenienza, la Puglia.
Alle origini di un buon olio extravergine di oliva ci sono due </p>
					</div>
				</div>
			</li>
		</ul>
	</div>
</div> -->



<!--founder_section-->












<!--out_team_sections-->


<div class="out_team_sections">
	<div class="wrap_grid">
		<div class="head_text">
			<h2>our team</h2>
			<span>pillars</span>
		</div>
		<ul class="team_slider owl-carousel owl-theme">
		<li>
				<div class="team_box">
					<img src="<?php echo esc_url(get_template_directory_uri()); ?>/images/about/t0.png" alt="team">
					<h4>Mr. Jerry Selvaraj</h4>
					<p>Founder</p>
				</div>
			</li>
			<li>
				<div class="team_box">
					<img src="<?php echo esc_url(get_template_directory_uri()); ?>/images/about/t1.png" alt="team">
					<h4>Mrs. Reena Selvaraj</h4>
					<p>Co Founder</p>
				</div>
			</li>
			<li>
				<div class="team_box">
					<img src="<?php echo esc_url(get_template_directory_uri()); ?>/images/about/t2.png" alt="team">
					<h4>Mr. Narayanan</h4>
					<p>Manager</p>
				</div>
			</li>
			<li>
				<div class="team_box">
					<img src="<?php echo esc_url(get_template_directory_uri()); ?>/images/about/t3.png" alt="team">
					<h4>Mr. Shanmugam</h4>
					<p>Sales and Operations</p>
				</div>
			</li>
			<li>
				<div class="team_box">
					<img src="<?php echo esc_url(get_template_directory_uri()); ?>/images/about/t4.png" alt="team">
					<h4>Mr. Arun Kumar</h4>
					<p>Sales and Operations</p>
				</div>
			</li>
			
		</ul>
	</div>
</div>



<!--out_team_sections-->



<!--infrastructure_section-->


<div class="infrastructure_section">
	<div class="wrap_grid">
		<div class="head_text">
			<h2>Infrastructure</h2>
			<span>Infrastructure</span>
		</div>
		<ul>
			<li>
				<a href="<?php echo esc_url(get_template_directory_uri());?>/images/about/i2.png" data-fancybox="infra" data-caption="Our Gallery">
					<img src="<?php echo esc_url(get_template_directory_uri()); ?>/images/about/i2.png" alt="Infrastructure">
				</a>
			</li>
			<li>
				<a href="<?php echo esc_url(get_template_directory_uri());?>/images/about/i3.png" data-fancybox="infra" data-caption="Our Gallery">
					<img src="<?php echo esc_url(get_template_directory_uri()); ?>/images/about/i3.png" alt="Infrastructure">
				</a>
			</li>
			<li>
				<a href="<?php echo esc_url(get_template_directory_uri());?>/images/about/i4.png" data-fancybox="infra" data-caption="Our Gallery">
					<img src="<?php echo esc_url(get_template_directory_uri()); ?>/images/about/i4.png" alt="Infrastructure">
				</a>
			</li>
			<li>
				<a href="<?php echo esc_url(get_template_directory_uri());?>/images/about/i5.png" data-fancybox="infra" data-caption="Our Gallery">
					<img src="<?php echo esc_url(get_template_directory_uri()); ?>/images/about/i5.png" alt="Infrastructure">
				</a>
			</li>
			<li>
				<a href="<?php echo esc_url(get_template_directory_uri());?>/images/about/i1.png" data-fancybox="infra" data-caption="Our Gallery">
					<img src="<?php echo esc_url(get_template_directory_uri()); ?>/images/about/i1.png" alt="Infrastructure">
				</a>
			</li>
			<li>
				<a href="<?php echo esc_url(get_template_directory_uri());?>/images/about/i6.png" data-fancybox="infra" data-caption="Our Gallery">
					<img src="<?php echo esc_url(get_template_directory_uri()); ?>/images/about/i6.png" alt="Infrastructure">
				</a>
			</li>
			<li>
				<a href="<?php echo esc_url(get_template_directory_uri());?>/images/about/i7.png" data-fancybox="infra" data-caption="Our Gallery">
					<img src="<?php echo esc_url(get_template_directory_uri()); ?>/images/about/i7.png" alt="Infrastructure">
				</a>
			</li>
			<li>
				<a href="<?php echo esc_url(get_template_directory_uri());?>/images/about/i8.png" data-fancybox="infra" data-caption="Our Gallery">
					<img src="<?php echo esc_url(get_template_directory_uri()); ?>/images/about/i8.png" alt="Infrastructure">
				</a>
			</li>
			<li>
				<a href="<?php echo esc_url(get_template_directory_uri());?>/images/about/i9.png" data-fancybox="infra" data-caption="Our Gallery">
					<img src="<?php echo esc_url(get_template_directory_uri()); ?>/images/about/i9.png" alt="Infrastructure">
				</a>
			</li>
		</ul>
	</div>
</div>


<!--infrastructure_section-->

<!--about_counter_section-->

<div class="about_counter_section">
	<div class="wrap_grid">
		<ul id="counter">
			<li>
				<img src="<?php echo esc_url(get_template_directory_uri()); ?>/images/about-us/i1.png" alt="Counter">
				<h4 class="count" data-count="30000000">0</h4>
				<p>Kg of Jaggery</p>
			</li>
			<li>
				<img src="<?php echo esc_url(get_template_directory_uri()); ?>/images/about-us/i2.png" alt="Counter">
				<h4 class="count" data-count="10000">0</h4>
				<p>Farmers</p>
			</li>
			<li>
				<img src="<?php echo esc_url(get_template_directory_uri()); ?>/images/about-us/i3.png" alt="Counter">
				<h4 class="count" data-count="100000">0</h4>
				<p>Customers Served</p>
			</li>
			<li>
				<img src="<?php echo esc_url(get_template_directory_uri()); ?>/images/about-us/i4.png" alt="Counter">
				<h4 class="count" data-count="59">0</h4>
				<p>Years of Service</p>
			</li>
		</ul>
	</div>
</div>

<!--about_counter_section-->




<!--parent_section-->


<section class="parent_section">
	<div class="wrap_grid">
		<div class="head_text">
			<h2>Our parent Companies</h2>
		</div>
		<ul>
			<li>
				<img src="<?php echo get_site_url();?>/wp-content/uploads/2022/05/2.png" alt="Our parent Companies" />
<!-- 				<p>Jothi Vella Mundy</p> -->
			</li>
			<li>
				<img src="<?php echo get_site_url();?>/wp-content/uploads/2022/05/1.png" alt="Our parent Companies" />
<!-- 				<p>Gnanamalar Vella Mundy</p> -->
			</li>
		</ul>
	</div>
</section>


<!--parent_section-->


































<?php
/*Template Name:About Us*/
get_footer();?>

<script>
	$('[data-fancybox="infra"]').fancybox({
  buttons: [
    "slideShow",
    "thumbs",
    "zoom",
    "fullScreen",
    //"share",
    "close"
  ],
  loop: false,
  protect: true
});
	//
	$(".team_slider").owlCarousel({
loop: false,
		center: false,
		nav: false,
		dots: true,
		autoplay: false,
		margin:15,
		rewind: true,
		autoplayHoverPause:true,
		touchDrag: true,
				mouseDrag: true,
		smartSpeed: 200,
responsive: {
0: {
				items: 1
},
			480: {
				items: 2
},
768: {
				items: 2
},
850: {
				items: 3
},
1200: {
				items: 4
},
			1920: {
items: 4
}
}
});

//
var counted = 0;
$(window).scroll(function() {

  var oTop = $('#counter').offset().top - window.innerHeight;
  if (counted == 0 && $(window).scrollTop() > oTop) {
    $('.count').each(function() {
      var $this = $(this),
        countTo = $this.attr('data-count');
      $({
        countNum: $this.text()
      }).animate({
          countNum: countTo
        },

        {

          duration: 2000,
          easing: 'swing',
          step: function() {
            $this.text(Math.floor(this.countNum));
          },
          complete: function() {
            $this.text(this.countNum);
            //alert('finished');
          }

        });
    });
    counted = 1;
  }

});
</script>
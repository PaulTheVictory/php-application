import React, { useEffect, useState } from "react";
import { message, Button, Form, Input } from "antd";
import styled from "styled-components";
import { Link, useNavigate} from "react-router-dom";
import { styles } from "../Api/Data";
import User from "../Store/Actions/UserAction";
import { useDispatch } from "react-redux";


const Register = () => {
  const [form] = Form.useForm();
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [password, setPassword] = useState("");
  const [saving, setSaving] = useState(false);
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const api = new User();

  
  const onFinish = (values) => {
    values["company"] = api.company;
    setSaving(true);
    api
      .register(dispatch, values)
      .then((res) => {
        console.log(res);
        let data = res.data;
        if (data.status === 200) {
          form.resetFields();
          message.success("Logged in successfully");
          navigate("/");
          setSaving(false);
        } else {
          message.error(data.message);
          setSaving(false);
        }
      })
      .catch((err) => {
        message.error("Something went wrong!");
        setSaving(false);
      });
    
   
  };

  return (
    <React.Fragment>
      <RegisterSection>
        <RegisterAlign>
          <RegisterLeft>
            <H1>Here there?</H1>
            <Link to="/login">
              <Button>Login</Button>
            </Link>
          </RegisterLeft>
          <RegisterRight>
            <Form form={form} name="Register_Form" onFinish={onFinish}>
              <Form.Item
                name="name"
                values={name}
                onChange={(event) => setName(event.target.values)}
                rules={[
                  {
                    min: 3,
                    message: "Username must be minimun 3 characters.",
                  },
                  {
                    max: 15,
                    message: "Username must be maximum 15 characters.",
                  },
                  {
                    required: true,
                    message: "Please input your name!",
                  },
                ]}
              >
                <Input placeholder="Name" />
              </Form.Item>
              <Form.Item
                name="email"
                values={email}
                onChange={(event) => setEmail(event.target.values)}
                rules={[
                  {
                    type: "email",
                    message: "The input is not valid E-mail!",
                  },
                  {
                    required: true,
                    message: "Please input your email id!",
                  },
                ]}
              >
                <Input placeholder="Email ID" />
              </Form.Item>
              <Form.Item
                name="phone"
                values={phone}
                onChange={(event) => setPhone(event.target.values)}
                rules={[
                  {
                    required: true,
                    pattern: new RegExp(/\d+/g),
                    message: "Please input your phone number!",
                  },
                ]}
              >
                <Input placeholder="Phone No" />
              </Form.Item>
              <Form.Item
                name="password"
                values={password}
                onChange={(event) => setPassword(event.target.values)}
                rules={[
                  { min: 6, message: "Password must be minimum 6 characters." },
                  {
                    required: true,
                    message: "Please input your password!",
                  },
                ]}
              >
                <Input.Password placeholder="Password" />
              </Form.Item>
              <Button type="primary" htmlType="submit" loading={saving}>
                Submit
              </Button>
            </Form>
          </RegisterRight>
        </RegisterAlign>
      </RegisterSection>
    </React.Fragment>
  );
};

export default Register;

const RegisterSection = styled.section`
  display: flex;
  width: 100%;
  position: relative;
  align-items: center;
  justify-content: center;
`;
const RegisterAlign = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  width: 600px;
  flex-wrap: wrap;
  box-shadow: 0 0 40px rgb(0 0 0 / 9%);
  border-radius: 5px;
  background: linear-gradient(to right, ${styles.background} 33%, #fff 33%);
  margin: 70px 0;
`;
const RegisterLeft = styled.div`
  width: 33%;
  display: inline-block;
  text-align: center;
  padding: 50px 25px;
`;
const RegisterRight = styled.div`
  display: inline-block;
  width: 67%;
  position: relative;
  padding: 40px 35px;
  input {
    width: 100%;
    padding: 8px 14px;
  }
  input[type="password"] {
    width: 100%;
    padding: 4px 0px;
  }
  .ant-space {
    width: 100%;
    margin: 0 0 10px;
  }
  button {
    padding: 7px 20px;
    height: auto;
    background: ${styles.background};
    border: 1px solid ${styles.background};
  }
`;
const H1 = styled.h1`
  color: #fff;
  font-size: 22px;
  margin: 0 0 20px;
`;

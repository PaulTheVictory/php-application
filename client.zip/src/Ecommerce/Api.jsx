export const API_URL = "http://localhost:5000/api/register";
export const LOGIN_URL = "http://localhost:5000/api/login";
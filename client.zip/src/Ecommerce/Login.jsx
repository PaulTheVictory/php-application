import React, { useState } from "react";
import { message, Button, Form, Input } from "antd";
import styled from "styled-components";
import { Link, useNavigate } from "react-router-dom";
import { styles } from "../Api/Data";
import User from "../Store/Actions/UserAction";
import { useDispatch } from "react-redux";
const Login = () => {

  const [form] = Form.useForm();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [saving, setSaving] = useState(false);
  const navigate = useNavigate();
  const api = new User();
 const dispatch = useDispatch();
  const onFinish = async (values) => {
    values["company"] = api.company;
    setSaving(true);
    api
      .login(dispatch, values)
      .then((res) => {
        let data = res.data;
        if (data.status === 200) {
          form.resetFields();
          message.success("Logged in successfully");
          navigate("/");
          setSaving(false);
        } else {
          message.error(data.message);
          setSaving(false);
        }
      })
      .catch((err) => {
        message.error("Something went wrong!");
        setSaving(false);
      });
  };

  return (
    <React.Fragment>
      <LoginSection>
        <LoginAlign>
          <LoginLeft>
            <H1>Welcome Back</H1>
            <Link to="/register">
              <Button>Register</Button>
            </Link>
          </LoginLeft>
          <LoginRight>
            <Form form={form} name="Login_Form" onFinish={onFinish}>
              <Form.Item
                name="email"
                values={email}
                onChange={(event) => setEmail(event.target.values)}
                rules={[
                  {
                    required: true,
                    message: "Please enter valid Email ID",
                  },
                ]}
              >
                <Input placeholder="Email ID" />
              </Form.Item>

              <Form.Item
                name="password"
                values={password}
                onChange={(event) => setPassword(event.target.values)}
                rules={[
                  {
                    required: true,
                    message: "Please enter valid password!",
                  },
                ]}
              >
                <Input.Password placeholder="Password" />
              </Form.Item>
              <Button type="primary" htmlType="submit" loading={saving}>
                Submit
              </Button>
            </Form>
          </LoginRight>
        </LoginAlign>
      </LoginSection>
    </React.Fragment>
  );
};

export default Login;
const LoginSection = styled.section`
  display: flex;
  width: 100%;
  position: relative;
  align-items: center;
  justify-content: center;
`;
const LoginAlign = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  width: 600px;
  flex-wrap: wrap;
  box-shadow: 0 0 40px rgb(0 0 0 / 9%);
  border-radius: 5px;
  background: linear-gradient(to right, ${styles.background} 33%, #fff 33%);
  margin: 70px 0;
  min-height: 300px;
`;
const LoginLeft = styled.div`
  width: 33%;
  display: inline-block;
  text-align: center;
  padding: 50px 25px;
`;
const LoginRight = styled.div`
  display: inline-block;
  width: 67%;
  position: relative;
  padding: 40px 35px;
  input {
    width: 100%;
    padding: 8px 14px;
  }
  input[type="password"] {
    width: 100%;
    padding: 4px 0px;
  }
  .ant-space {
    width: 100%;
    margin: 0 0 10px;
  }
  button {
    padding: 7px 20px;
    height: auto;
    background: ${styles.background};
    border: 1px solid ${styles.background};
  }
`;
const H1 = styled.h1`
  color: #fff;
  font-size: 22px;
  margin: 0 0 20px;
`;

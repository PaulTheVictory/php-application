import React from 'react'
import styled from 'styled-components';
import { styles, productList } from "./../Api/Data";
import { Button } from "antd";
import { Link } from "react-router-dom";

const ProductGridView = () => {
  return (
    <React.Fragment>
      {productList.map((item) => (
        <ProductBox key={item.id}>
          <ProductImage>
            <Image src={`${styles.default}`} />
          </ProductImage>
          <Content>
            <Title>{item.title}</Title>
            <Price>
              <Sp>
                {item.currency}
                {item.sp}
              </Sp>
              <Mrp>
                {item.currency}
                {item.mrp}
              </Mrp>
            </Price>
            <Link to={item.url}>
              <Button>Buy Now</Button>
            </Link>
          </Content>
        </ProductBox>
      ))}
    </React.Fragment>
  );
}

export default ProductGridView

const ProductBox = styled.div`
  width:100%;
  position: relative;
  border: 1px solid ${styles.light};
  border-radius: 5px;
`;
const ProductImage = styled.div``;
const Image = styled.img`
  max-width: 100%;
  width: 100%;
`;
const Content = styled.div`
  padding: 15px;
  width:100%;
  display: flex;
  flex-direction: column;
  gap: 12px;
`;
const Title = styled.div`
  color: ${styles.color};
  font-size: 16px;
  font-weight: 600;
  line-height: 1.5;
`;
const Price = styled.div`
  display: flex;
  align-items: center;
  flex-wrap: wrap;
  gap: 11px;
`;
const Sp = styled.div`
  font-size: 18px;
  color: ${styles.color};
  font-weight: 700;
`;
const Mrp = styled.div`
  font-size: 13px;
  color: ${styles.gray};
  text-decoration: line-through;
`;

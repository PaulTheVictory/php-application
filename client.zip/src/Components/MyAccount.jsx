import React from "react";
import { Button, Empty, Tabs } from "antd";
import styled from "styled-components";
import { styles } from "./../Api/Data";
import Profile from "./Profile";
import ProfileAddress from "./ProfileAddress";

const MyAccount = () => {

  return (
    <React.Fragment>
      <MyAccountSection>
        <Wrapper>
          <H2>My Account</H2>
          <MyAccountAlign>
            <Tabs defaultActiveKey="1" tabPosition="left">
              <Tabs.TabPane tab="My Profile" key="1">
                <Profile />
              </Tabs.TabPane>
              <Tabs.TabPane tab="Manage Address" key="2">
                <ProfileAddress />
              </Tabs.TabPane>
              <Tabs.TabPane tab="My Orders" key="3">
                <Empty />
              </Tabs.TabPane>
              <Tabs.TabPane tab="Wishlist" key="4">
                <Empty />
              </Tabs.TabPane>
              <Tabs.TabPane tab="Notification" key="5">
                <Empty />
              </Tabs.TabPane>
              <Tabs.TabPane tab="My Coupons" key="6">
                <Empty />
              </Tabs.TabPane>
              <Tabs.TabPane tab="My Offers" key="7">
                <Empty />
              </Tabs.TabPane>
              <Tabs.TabPane tab="Logout" key="8">
                <p>Paul are you logout your account?</p>
                <Button>Logout</Button>
              </Tabs.TabPane>
            </Tabs>
          </MyAccountAlign>
        </Wrapper>
      </MyAccountSection>
    </React.Fragment>
  );
};

export default MyAccount;

const MyAccountSection = styled.section`
  width: 100%;
  display: inline-block;
  position: relative;
  margin: 60px 0 0 0;
`;
const Wrapper = styled.div`
  max-width: 1200px;
  margin: auto;
  padding: 0 10px;
`;
const MyAccountAlign = styled.div`
  width: 100%;
  display: inline-block;
  position: relative;
  margin: 10px 0 0 0;
  border: 1px solid ${styles.light};
  .ant-tabs.ant-tabs-left {
    padding: 0px 0;
  }
  .ant-tabs-content-holder {
    padding: 20px 0;
  }
  .ant-tabs-tab {
    padding: 8px 25px !important;
    font-size: 15px;

    width: 200px;
    color: ${styles.color};
  }
  .ant-tabs > .ant-tabs-nav .ant-tabs-nav-list,
  .ant-tabs > div > .ant-tabs-nav .ant-tabs-nav-list {
    padding: 15px 0;
  }
  .ant-tabs-tab.ant-tabs-tab-active .ant-tabs-tab-btn {
    color: ${styles.background};
    font-weight: 600;
  }
  .ant-tabs-ink-bar {
    background: ${styles.background};
  }
`;
const H2 = styled.h2`
  font-size: ${styles.h2};
  color: ${styles.color};
  font-weight: 600;
`;

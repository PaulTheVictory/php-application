import React from 'react'
import Banner from './Banner';
import Blog from './Blog';
import Brands from './Brands';
import FeatureProduct from './FeatureProduct';
import TopCategory from './TopCategory';


const Home = () => {
  return (
    <React.Fragment>
      <Banner />
      <TopCategory />
      <FeatureProduct />
      <Brands />
      <Blog />
    </React.Fragment>
  );
}

export default Home;
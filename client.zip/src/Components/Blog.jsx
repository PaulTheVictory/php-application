import React from 'react'
import styled from "styled-components";
import { styles, blog } from "../Api/Data";
import { RightCircleOutlined } from "@ant-design/icons";
import { Button } from "antd";
import { Link } from "react-router-dom";

const Blog = () => {
  return (
    <React.Fragment>
      <BlogSection>
        <Wrapper>
          <HeadText>
            <H2>Blog</H2>
            <Button>
              View All
              <RightCircleOutlined />
            </Button>
          </HeadText>
          <BlogList>
            {blog.slice(0, 3).map((item) => (
              <BlogItems key={item.id}>
                <BlogImage>
                  <Image
                    src={item.img ? item.img : `${styles.default}`}
                    alt={item.blogtitle}
                  />
                  <BlogCategory>{item.blogcategory}</BlogCategory>
                </BlogImage>
                <BlogContent>
                  <BlogTitle>{item.blogtitle}</BlogTitle>
                  <BlogDate>{item.created}</BlogDate>
                  <BlogShort>{item.blogdescription}</BlogShort>
                  <Link to={item.url}>
                    <Button>Read More</Button>
                  </Link>
                </BlogContent>
              </BlogItems>
            ))}
          </BlogList>
        </Wrapper>
      </BlogSection>
    </React.Fragment>
  );
}

export default Blog;


const BlogSection = styled.section`
  display: inline-block;
  margin: 60px 0;
  width:100%;
  position: relative;
`;
const Wrapper = styled.div`
  max-width: 1200px;
  margin: auto;
`;
const HeadText = styled.div`
  width: 100%;
  display: flex;
  align-items: center;
  justify-content: space-between;
  position: relative;
`;
const H2 = styled.h2`
  color: ${styles.color};
  font-size: ${styles.h2};
`;
const BlogList = styled.div`
  display: grid;
  grid-template-columns: repeat(3,1fr);
  gap: 25px;
  margin: 40px 0 0;
`;
const BlogItems = styled.div`
  border: 1px solid ${styles.light};
  width:100%;
  display: inline-block;
  border-radius: 5px;
`;
const BlogImage = styled.div`
  position: relative;
  display: flex;
  flex-direction: column;
  width:100%;
`;
const Image = styled.img`
  max-width: 100%;
  width:100%;
`;
const BlogCategory = styled.div`
  position: absolute;
  top:15px;
  right:15px;
  background: ${styles.background};
  color:#fff;
  padding: 3px 13px;
  border-radius: 2px;
`;
const BlogContent = styled.div`
  padding: 25px;
  display: flex;
  flex-direction: column;
  gap: 15px;
  width:100%;
`;
const BlogTitle = styled.div`
  display: inline-block;
  font-size: 22px;
  color: ${styles.color};
  font-weight: 600;

`;
const BlogDate = styled.div`
  color: ${styles.gray};
  font-size: 14px;
  font-style: italic;
`;
const BlogShort = styled.div`
  line-height: 1.6;
  text-align: left;
  color: ${styles.gray};
  font-size: 15px;
  width:100%;
`;
import React from "react";
import {
  Image,
  Breadcrumb,
  Button,
  Divider,
  Form,
  Rate,
  Input,
  Comment,
  List,
} from "antd";
import { HomeOutlined } from "@ant-design/icons";
import { styles, review } from "../Api/Data";
import styled from "styled-components";
import RelatedProduct from "./RelatedProduct";
const { TextArea } = Input;
const Product = () => {
  const [counter, setCounter] = React.useState(() => 1);

  const dec_ment = () => {
    setCounter((ps) => ps - 1);
  };
  const incre_ment = () => {
    setCounter((ps) => ps + 1);
  };

  return (
    <React.Fragment>
      <ProductSection>
        <Wrapper>
          <AlignRight>
            <Breadcrumb>
              <Breadcrumb.Item href="">
                <HomeOutlined />
              </Breadcrumb.Item>
              <Breadcrumb.Item href="">
                <Span>Category Name</Span>
              </Breadcrumb.Item>
              <Breadcrumb.Item>Page Name</Breadcrumb.Item>
            </Breadcrumb>
          </AlignRight>
          <ProductAlign>
            <ProductLeft>
              <Image src={`${styles.default}`} />
            </ProductLeft>
            <ProductRight>
              <ProductTitle>Smart watches wood edition</ProductTitle>
              <ProductPrice>
                <Sp>{styles.currency}450</Sp>
                <Mrp>{styles.currency}500</Mrp>
              </ProductPrice>
              <ProductDescription>
                Himenaeos parturient nam a justo placerat lorem erat pretium a
                fusce pharetra pretium enim sagittis ut nunc neque torquent sem
                a leo. Dictumst himenaeos primis torquent ridiculus.
              </ProductDescription>
              <ProductAttribute>
                Size: <Button>S</Button>
                <Button>M</Button>
                <Button>XL</Button>
                <Button>XXL</Button>
              </ProductAttribute>
              <ProductQuantity>
                <Button onClick={dec_ment}>-</Button>
                <ProductInput type="text" value={counter} readOnly />
                <Button onClick={incre_ment}>+</Button>
              </ProductQuantity>
              <ProductAction>
                <AddToCart>
                  <Button>Add to Cart</Button>
                </AddToCart>
                <BuyNow>
                  <Button>Buy Now</Button>
                </BuyNow>
              </ProductAction>
              <Divider />
              <ProductSku>
                <B>SKU:</B> N/A
              </ProductSku>
              <ProductCategory>
                <B>Categories:</B> Accessories, Clocks
              </ProductCategory>
            </ProductRight>
          </ProductAlign>
          <ReviewSection>
            <ReviewLeft>
              <H2>Review</H2>
              <List
                className="comment-list"
                header={`${review.length} replies`}
                itemLayout="horizontal"
                dataSource={review}
                renderItem={(item) => (
                  <li>
                    <Comment
                      actions={item.actions}
                      author={item.author}
                      avatar={item.avatar}
                      content={item.content}
                      datetime={item.datetime}
                    />
                  </li>
                )}
              />
            </ReviewLeft>
            <ReviewRight>
              <H5>Write a review</H5>
              <Form>
                <Form.Item label="Your rating">
                  <Rate defaultValue={2} />
                </Form.Item>
                <Form.Item label="Your review">
                  <TextArea rows={4} maxLength={100} />
                </Form.Item>
                <Form.Item>
                  <Button>Submit Review</Button>
                </Form.Item>
              </Form>
            </ReviewRight>
          </ReviewSection>
        </Wrapper>
      </ProductSection>
      <RelatedProduct />
    </React.Fragment>
  );
};

export default Product;

const ProductSection = styled.section`
  margin: 60px 0 0 0;
  position: relative;
  width: 100%;
  display: inline-block;
`;
const Wrapper = styled.div`
  max-width: 1200px;
  padding: 0 10px;
  margin: auto;
`;
const ProductAlign = styled.div`
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  margin: 45px 0 0 0;
  width: 100%;
`;
const ProductLeft = styled.div`
  width: 47%;
  display: inline-block;
  position: relative;
  border: 1px solid ${styles.light};
  border-radius: 5px;
  overflow: hidden;
`;
const ProductRight = styled.div`
  width: 47%;
  display: flex;
  position: relative;
  flex-direction: column;
  gap: 10px;
`;
const Span = styled.span``;
const AlignRight = styled.div`
  width: 100%;
  display: flex;
  
  text-align: end;
  padding: 0 0 12px 0;
  margin: 0 0 0px;
  border-bottom: 1px solid ${styles.light};
  border-radius: 5px;
`;
const ProductTitle = styled.h1`
  font-size: ${styles.h2};
  color: ${styles.color};
  line-height: 1.5;
  font-weight: 600;
  margin: 0;
`;
const ProductPrice = styled.div`
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 10px;
`;
const Sp = styled.div`
  font-size: ${styles.h2};
  font-weight: 700;
  color: ${styles.background};
`;
const Mrp = styled.div`
  text-decoration: line-through;
  color: ${styles.gray};
`;
const ProductDescription = styled.div`
  font-size: 16px;
  line-height: 1.6;
  color: ${styles.gray};
`;
const ProductAttribute = styled.div`
  display: flex;
  align-items: center;
  flex-wrap: wrap;
  gap: 10px;
  font-size: 16px;
  font-weight: 600;
  color: ${styles.color};
  margin: 8px 0;
`;
const ProductQuantity = styled.div`
  display: flex;
  margin: 8px 0;
`;
const ProductInput = styled.input`
  border: 0;
  border-top: 1px solid #d9d9d9;
  border-bottom: 1px solid #d9d9d9;
  text-align: center;
  outline: none;
  width: 60px;
`;
const ProductAction = styled.div`
  display: flex;
  align-items: center;
  flex-wrap: wrap;
  gap: 15px;
  margin: 8px 0;
`;
const AddToCart = styled.div``;
const BuyNow = styled.div``;
const ProductSku = styled.div`
  line-height: 1.5;
  color: ${styles.color};
  margin: 0 0 0px;
`;
const ProductCategory = styled.div`
  line-height: 1.5;
  color: ${styles.color};
`;
const B = styled.b`
  font-weight: 600;
  color: ${styles.background};
  font-size: 16px;
  margin: 0 8px 0 0;
`;

const ReviewSection = styled.div`
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  position: relative;
  margin: 100px 0 0 0;
`;
const H2 = styled.div`
  color: ${styles.color};
  line-height: 1.5;
  margin: 0 0 30px;
  font-size: ${styles.h2};
  font-weight: 600;
`;

const ReviewLeft = styled.div`
  width: 60%;
  display: inline-block;
  position: relative;
  max-height: 400px;
  overflow: auto;
  padding: 0 30px 0 0;

  /* width */
  ::-webkit-scrollbar {
    width: 5px;
  }

  /* Track */
  ::-webkit-scrollbar-track {
    background: #f1f1f1;
  }

  /* Handle */
  ::-webkit-scrollbar-thumb {
    background: ${styles.background};
    border-radius: 5px;
  }

  /* Handle on hover */
  ::-webkit-scrollbar-thumb:hover {
    background: ${styles.background};
  }
`;
const ReviewRight = styled.div`
  width: 35%;
  display: inline-block;
  position: relative;
  border: 1px solid ${styles.light};
  padding: 20px 25px;
`;

const H5 = styled.h5`
  font-size: 18px;
  font-weight: 600;
  color: ${styles.color};
`;
import React from "react";
import styled from "styled-components";
import { Button, Checkbox, Form, Input } from "antd";
import { styles } from "./../Api/Data";


const Profile = () => {
  const onFinish = (values) => {
    console.log("Success:", values);
  };
  const onFinishFailed = (errorInfo) => {
    console.log("Failed:", errorInfo);
  };
  return (
    <React.Fragment>
      <ProfileSection>
        <Form
          name="basic"
          onFinish={onFinish}
          onFinishFailed={onFinishFailed}
          autoComplete="off"
        >
          <GridAlign>
            <Form.Item
              label="Name"
              name="name"
              rules={[
                {
                  required: true,
                  message: "Please input your username!",
                },
              ]}
            >
              <Input />
            </Form.Item>

           
            <Form.Item
              label="Phone Numbaer"
              name="name"
              rules={[
                {
                  required: true,
                  message: "Please input your username!",
                },
              ]}
            >
              <Input />
            </Form.Item>
            <Form.Item
              label="Email Address"
              name="name"
              rules={[
                {
                  required: true,
                  message: "Please input your username!",
                },
              ]}
            >
              <Input />
            </Form.Item>
          </GridAlign>
         
          <Form.Item name="remember" valuePropName="checked">
            <Checkbox>Accept terms and condition</Checkbox>
          </Form.Item>

          <Button type="primary" htmlType="submit">
            Save Billing Address
          </Button>
        </Form>
      </ProfileSection>
    </React.Fragment>
  );
};

export default Profile;

const ProfileSection = styled.div`
  margin: 30px 0 30px 0;
  width: 100%;
  position: relative;
  form {
    width: 100%;
    margin: auto auto 0px;
    padding: 0 45px 0 20px ;
   
    
  }
  .ant-row {
    flex-wrap: wrap;
    flex-flow: column;
  }
  .ant-col.ant-form-item-label {
    width: 100%;
    display: inline-block;
    label {
      width: 100%;
    }
  }
  .ant-col.ant-form-item-control {
    width: 100%;
  }

  button.ant-btn.ant-btn-primary {
    background: ${styles.background};
    border: 1px solid ${styled.background};
  }
`;
const GridAlign = styled.div`
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 0 25px;
  .ant-row {
    flex-wrap: wrap;
    flex-flow: column;
  }
  .ant-col.ant-form-item-label {
    width: 100%;
    display: inline-block;
    label {
      width: 100%;
    }
  }
`;
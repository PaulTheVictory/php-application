import React from 'react'
import styled from 'styled-components';
import { styles } from './../Api/Data';
import { message } from 'antd';

const Payment = () => {
  return (
    <React.Fragment>
      <PaymentSection>
        <CartBottom>
          <H2>Place Order</H2>
          <CartTable>
            <Tr>
              <Th>Wood Pressed Groundnut Oil - 5 Litre</Th>
              <Td>₹1,350</Td>
            </Tr>
            <Tr>
              <Th>Subtotal</Th>
              <Td>₹1,350</Td>
            </Tr>
            <Tr>
              <Th>Shipping</Th>
              <Td>Free shipping Shipping to Tamil Nadu.</Td>
            </Tr>
            <Tr>
              <Th>Total</Th>
              <Td>₹1,350</Td>
            </Tr>
            <Tr colspan="2">
              <Td className="Last" colSpan="2">
                Your personal data will be used to process your order, support
                your experience throughout this website, and for other purposes
                described in our privacy policy.
              </Td>
            </Tr>
          </CartTable>

          <CheckOut onClick={() => message.success("Processing complete!")}>
            Place Order
          </CheckOut>
        </CartBottom>
      </PaymentSection>
    </React.Fragment>
  );
}

export default Payment
 

const PaymentSection = styled.section`
width:100%;
display: inline-block;
margin: 10px 0 40px 0;
.Last {
  text-align: left;
}
`;
const CartTable = styled.table`
  width: 100%;
  display: table;
  text-align: center;
  border: 1px solid ${styles.light};
  border-radius: 5px;
`;
const H2 = styled.h2`
  font-size: 20;
  color: ${styles.color};
  font-weight: 600;
  margin: 0 0 20px;
`;
const Tr = styled.tr`
  padding: 15px;
  border-bottom: 1px solid ${styles.light};
`;
const Th = styled.th`
  border-bottom: 1px solid ${styles.light};
  padding: 15px;
  font-size: 16px;
`;
const Td = styled.td`
  padding: 15px;
  text-align: right;
`;
const CartBottom = styled.div`
  margin: 55px auto 0 auto;
  width: 55%;
  position: relative;
  display: block;
  table {
    text-align: left;
  }
`;

const CheckOut = styled.button`
  background: ${styles.background};
  width: 100%;
  margin: 18px 0 0 0;
  padding: 14px 15px;
  border-radius: 5px;
  outline: none;
  font-size: 18px;
  color: #fff;
  border: 0;
  font-weight: 600;
`;

const P = styled.p`
margin: 15px 0 0 0;
font-size: 14px;
`;
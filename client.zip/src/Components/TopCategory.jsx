import React from "react";
import styled from "styled-components";
import { popularCategory, styles } from "../Api/Data";
import { RightCircleOutlined } from "@ant-design/icons";
import { Button } from "antd";
import { Link } from 'react-router-dom';




const TopCategory = () => {
  return (
    <React.Fragment>
      <TopCategorySection>
        <Wrapper>
          <HeadText>
            <H1>Popular Categories</H1>
            <Button>
              View All
              <RightCircleOutlined />
            </Button>
          </HeadText>
          <Ul>
            {popularCategory.length > 1 ? (
              popularCategory.slice(0, 6).map((item) => (
                <Li key={item.id}>
                  <Link to={item.link}>
                    <Img
                      src={item.img ? item.img : `${styles.default}`}
                      alt={item.title ? item.title : "Our Product"}
                    />
                    <H4>{item.title && `${item.title}`}</H4>
                    <P>{item.count && `${item.count}`} Products</P>
                  </Link>
                </Li>
              ))
            ) : (
              <p className="no_result_fount">No Category Created yet</p>
            )}
          </Ul>
        </Wrapper>
      </TopCategorySection>
    </React.Fragment>
  );
};

export default TopCategory;


const TopCategorySection = styled.section`
  display: inline-block;
  width:100%;
  position: relative;
  margin: 60px 0;
`;
const Wrapper = styled.div`
  max-width: 1200px;
  margin: auto;
`;
const HeadText = styled.div`
  width:100%;
  display: flex;
  align-items: center;
  justify-content: space-between;
  position: relative;
`;
const H1 = styled.h1`
  color: ${styles.color};
  font-size: ${styles.h2};
`;
const Ul = styled.ul`
  display: grid;
  grid-template-columns: repeat(6,1fr);
  gap: 25px;
  list-style: none;
  margin: 45px 0 0 0;
  padding: 0;
`;
const Li = styled.li`
  width:100%;
  display: inline-block;
  position: relative;
`;
const Img = styled.img`
  height: 120px;
  width:120px;
  border-radius: 100%;
  max-width: 100%;
  display: block;
  margin: auto auto 15px;
`;
const H4 = styled.h4`
  text-align: center;
  color:${styles.color};
  font-size: 17px;
  font-weight: 600;
  margin: 0 0 5px;
`;
const P = styled.p`
  text-align: center;
  color: ${styles.gray};
  font-size: 14px;
  font-style: italic;
`;

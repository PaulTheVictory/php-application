import React from "react";
import Sidebar from "./Sidebar";
import styled from "styled-components";
import { Breadcrumb, Pagination } from "antd";
import { HomeOutlined } from "@ant-design/icons";
import { styles } from "./../Api/Data";
import FilterSidebar from "./FilterSidebar";
import ProductGridView from "./ProductGridView";

const Shop = () => {
  return (
    <React.Fragment>
      <ShopSection>
        <Wrapper>
          <ShopTop>
            <ShopTitle>Shop</ShopTitle>
            <Breadcrumb>
              <Breadcrumb.Item href="">
                <HomeOutlined />
              </Breadcrumb.Item>
              <Breadcrumb.Item href="">
                <Span>Category Name</Span>
              </Breadcrumb.Item>
              <Breadcrumb.Item>Page Name</Breadcrumb.Item>
            </Breadcrumb>
          </ShopTop>
          <ShopAlign>
            <ShopLeft>
              <Sidebar />
            </ShopLeft>
            <ShopRight>
              <FilterSidebar />
              <ProductListing>
                <ProductGridView />
              </ProductListing>
              <PageAlign>
                <Pagination defaultCurrent={3} total={60} />
              </PageAlign>
            </ShopRight>
          </ShopAlign>
        </Wrapper>
      </ShopSection>
    </React.Fragment>
  );
};

export default Shop;

const ShopSection = styled.section`
  width: 100%;
  display: inline-block;
  position: relative;
  margin: 60px 0 0 0;
`;
const Wrapper = styled.div`
  max-width: 1200px;
  margin: auto;
`;
const ShopAlign = styled.div`
  display: flex;
  justify-content: space-between;
  width: 100%;
  flex-wrap: wrap;
  position: relative;
`;
const ShopLeft = styled.div`
  width: 23%;
  display: inline-block;
  padding: 25px 20px;
  border: 1px solid ${styles.light};
  /* background: ${styles.light}; */
  border-radius: 5px;
`;
const ShopRight = styled.div`
  width: 76%;
  display: inline-block;
  padding: 0 0 0 25px;
  border: 0px solid ${styles.light};
`;
const ShopTop = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  flex-wrap: wrap;
  width: 100%;
  position: relative;
  margin: 0 0 30px;
`;
const ShopTitle = styled.h1`
  font-size: 25px;
  font-weight: 700;
  color: ${styles.color};
  margin: 0;
`;
const Span = styled.span``;

const ProductListing = styled.div`
  padding: 35px 0 0 0px;
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 20px 15px;
`;

const PageAlign = styled.div`
  width: 100%;
  text-align: center;
  margin: 45px 0 15px 0;
`;

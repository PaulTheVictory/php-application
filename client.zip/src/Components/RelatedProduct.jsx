import React from "react";
import styled from "styled-components";
import { styles, featureProduct } from "../Api/Data";
import { RightCircleOutlined } from "@ant-design/icons";
import { Button } from "antd";
import { Link } from "react-router-dom";

const RelatedProduct = () => {
  return (
    <React.Fragment>
      <RelatedProductSection>
        <Wrapper>
          <HeadText>
            <H2>RelatedProduct</H2>
            
          </HeadText>
          <Ul>
            {featureProduct.length > 1 ? (
              featureProduct.slice(0, 4).map((item) => (
                <Li key={item.id}>
                  <ImageAlign>
                    <Image
                      src={item.img ? item.img : `${styles.default}`}
                      alt={item.title}
                    />
                  </ImageAlign>
                  <Content>
                    <Title>{item.title}</Title>
                    <Price>
                      <Sp>
                        {item.currency}
                        {item.sp}
                      </Sp>
                      <Mrp>
                        {item.currency}
                        {item.mrp}
                      </Mrp>
                    </Price>
                    <Link to={item.url}>
                      <Button>Buy Now</Button>
                    </Link>
                  </Content>
                </Li>
              ))
            ) : (
              <p className="no_result_fount">No Product Created yet</p>
            )}
          </Ul>
        </Wrapper>
      </RelatedProductSection>
    </React.Fragment>
  );
};

export default RelatedProduct;

const RelatedProductSection = styled.section`
  display: inline-block;
  width: 100%;
  position: relative;
  margin: 60px 0;
`;
const Wrapper = styled.div`
  max-width: 1200px;
  margin: auto;
`;
const HeadText = styled.div`
  width: 100%;
  display: flex;
  align-items: center;
  justify-content: space-between;
  position: relative;
`;
const H2 = styled.h2`
  color: ${styles.color};
  font-size: ${styles.h2};
`;
const Ul = styled.div`
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 30px 25px;
  margin: 20px 0 0 0;
`;
const Li = styled.div`
  border: 1px solid ${styles.light};
  width: 100%;
  display: inline-block;
  border-radius: 5px;
`;
const ImageAlign = styled.div`
  width: 100%;
  background: transparent;
  width: 100%;
  position: relative;
`;
const Image = styled.img`
  max-width: 100%;
  display: block;
`;
const Content = styled.div`
  width: 100%;
  display: flex;
  flex-direction: column;
  gap: 15px;
  position: relative;
  padding: 25px;
  border-top: 0px solid ${styles.light};
`;
const Title = styled.div`
  color: ${styles.color};
  font-size: 18px;
  font-weight: 600;
  line-height: 1.5;
`;
const Price = styled.div`
  display: flex;
  align-items: center;
  flex-wrap: wrap;
  gap: 15px;
`;
const Sp = styled.div`
  font-size: 20px;
  color: ${styles.color};
  font-weight: 700;
`;
const Mrp = styled.div`
  font-size: 14px;
  color: ${styles.gray};
  text-decoration: line-through;
`;

import React from "react";
import styled from "styled-components";
import { Button, Checkbox, Form, Input } from "antd";
import { styles } from "./../Api/Data";
const { TextArea } = Input;

const BillingAddress = () => {
  const onFinish = (values) => {
    console.log("Success:", values);
  };
  const onFinishFailed = (errorInfo) => {
    console.log("Failed:", errorInfo);
  };

  return (
    <React.Fragment>
      <AddressForm>
        <H2>Billing Address</H2>
        <Form
          name="basic"
          onFinish={onFinish}
          onFinishFailed={onFinishFailed}
          autoComplete="off"
        >
          <GridAlign>
            <Form.Item
              label="Name"
              name="name"
              rules={[
                {
                  required: true,
                  message: "Please input your username!",
                },
              ]}
            >
              <Input />
            </Form.Item>

            <Form.Item
              label="Country / Region"
              name="name"
              rules={[
                {
                  required: true,
                  message: "Please input your username!",
                },
              ]}
            >
              <Input />
            </Form.Item>
            <Form.Item
              label="Street Address"
              name="name"
              rules={[
                {
                  required: true,
                  message: "Please input your username!",
                },
              ]}
            >
              <Input placeholder="House name and Street name" />
            </Form.Item>
            <Form.Item
              label="Additional Details"
              name="name"
              rules={[
                {
                  required: true,
                  message: "Please input your username!",
                },
              ]}
            >
              <Input placeholder="Apartment, suite, unit, etc.(optional)" />
            </Form.Item>
            <Form.Item
              label="Town / City"
              name="name"
              rules={[
                {
                  required: true,
                  message: "Please input your username!",
                },
              ]}
            >
              <Input />
            </Form.Item>
            <Form.Item
              label="State"
              name="name"
              rules={[
                {
                  required: true,
                  message: "Please input your username!",
                },
              ]}
            >
              <Input />
            </Form.Item>
            <Form.Item
              label="Pincode"
              name="name"
              rules={[
                {
                  required: true,
                  message: "Please input your username!",
                },
              ]}
            >
              <Input />
            </Form.Item>
            <Form.Item
              label="Phone Numbaer"
              name="name"
              rules={[
                {
                  required: true,
                  message: "Please input your username!",
                },
              ]}
            >
              <Input />
            </Form.Item>
            <Form.Item
              label="Email Address"
              name="name"
              rules={[
                {
                  required: true,
                  message: "Please input your username!",
                },
              ]}
            >
              <Input />
            </Form.Item>
          </GridAlign>
          <Form.Item label="Order notes (optional)">
            <TextArea
              rows={4}
              placeholder="Notes about your order, e.g. special notes for delivery"
            />
          </Form.Item>
          <Form.Item name="remember" valuePropName="checked">
            <Checkbox>Accept terms and condition</Checkbox>
          </Form.Item>

          <Button type="primary" htmlType="submit">
            Save Billing Address
          </Button>
        </Form>
      </AddressForm>
    </React.Fragment>
  );
};

export default BillingAddress;

const AddressForm = styled.section`
  margin: 40px 0 0 0;
  width: 100%;
  position: relative;
  form {
    width: 100%;
    margin: auto auto 30px;
    padding: 40px 30px;
    border-radius: 5px;
    border: 1px solid ${styles.light};
  }
  .ant-row {
    flex-wrap: wrap;
    flex-flow: column;
  }
  .ant-col.ant-form-item-label {
    width: 100%;
    display: inline-block;
    label {
      width: 100%;
    }
  }
  .ant-col.ant-form-item-control {
    width: 100%;
  }
`;
const GridAlign = styled.div`
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 0 40px;
  .ant-row {
    flex-wrap: wrap;
    flex-flow: column;
  }
  .ant-col.ant-form-item-label {
    width: 100%;
    display: inline-block;
    label {
      width: 100%;
    }
  }
`;
const H2 = styled.h2`
  font-size: 20;
  color: ${styles.color};
  font-weight: 600;
  margin: 0 0 20px;
`;

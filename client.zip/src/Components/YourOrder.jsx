import React from "react";
import styled from "styled-components";
import DeleteIcon from "@mui/icons-material/Delete";
import { cart, styles } from "./../Api/Data";
import { Button } from "antd";

const YourOrder = () => {
  const [counter, setCounter] = React.useState(() => 1);

  const dec_ment = () => {
    setCounter((ps) => ps - 1);
  };
  const incre_ment = () => {
    setCounter((ps) => ps + 1);
  };
  return (
    <React.Fragment>
      <CartSection>
        <Wrapper>
          <H2>Your Order</H2>
          <CartAlign>
            <CartTop>
              <CartList>
                <CartItems>
                  <CartTable>
                    <CartThead>
                      <Tr>
                        <Th>Product</Th>
                        <Th>Image</Th>
                        <Th>Price</Th>
                        <Th>Quantity</Th>
                        <Th>Subtotal</Th>
                        <Th>Action</Th>
                      </Tr>
                      {cart.map((item) => (
                        <Tr key={item.id}>
                          <Td>{item.name}</Td>

                          <Td>
                            <Image
                              src={item.img ? item.img : `${styles.default}`}
                            />
                          </Td>

                          <Td>
                            {styles.currency}
                            {item.price}
                          </Td>
                          <Td>
                            <ProductQuantity>
                              <Button onClick={dec_ment}>-</Button>
                              <ProductInput
                                type="text"
                                value={item.quantity}
                                readOnly
                              />
                              <Button onClick={incre_ment}>+</Button>
                            </ProductQuantity>
                          </Td>
                          <Td>
                            {styles.currency}
                            {item.total}
                          </Td>
                          <Td>
                            <DeleteIcon style={{ color: "#ee5454" }} />
                          </Td>
                        </Tr>
                      ))}
                    </CartThead>
                  </CartTable>
                </CartItems>
              </CartList>
            </CartTop>
          </CartAlign>
        </Wrapper>
      </CartSection>
    </React.Fragment>
  );
};

export default YourOrder;

const CartSection = styled.section`
  margin: 60px 0 0 0;
  width: 100%;
  position: relative;
  min-height: 350px;
  
`;
const Wrapper = styled.div`
  max-width: 100%;
  padding: 0 0px;
  margin: auto;
`;
const CartAlign = styled.div`
  width: 100%;
  display: inline-block;
  position: relative;
`;
const CartTop = styled.div`
  width: 100%;
  position: relative;
  display: inline-block;
`;

const CartList = styled.div`
  width: 100%;
  display: inline-block;
`;
const CartItems = styled.div`
  width: 100%;
  display: inline-block;
`;
const CartTable = styled.table`
  width: 100%;
  display: table;
  text-align: center;
  border: 1px solid ${styles.light};
  border-radius: 5px;
`;
const CartThead = styled.thead`
  width: 100%;
  display: table;
  text-align: center;
  border: 0px solid ${styles.light};
`;
const Tr = styled.tr`
  padding: 15px;
  border-bottom: 1px solid ${styles.light};
`;
const Th = styled.th`
  border-bottom: 1px solid ${styles.light};
  padding: 15px;
  font-size: 16px;
`;
const Td = styled.td`
  padding: 15px;
`;
const Image = styled.img`
  max-width: 100%;
  height: 60px;
  border: 1px solid ${styles.light};
`;

const ProductQuantity = styled.div`
  display: flex;
  margin: 8px auto;
  width: fit-content;
`;
const ProductInput = styled.input`
  border: 0;
  border-top: 1px solid #d9d9d9;
  border-bottom: 1px solid #d9d9d9;
  text-align: center;
  outline: none;
  width: 60px;
`;

const H2 = styled.h2`
  font-size: 20;
  color: ${styles.color};
  font-weight: 600;
  margin: 0 0 20px;
`;

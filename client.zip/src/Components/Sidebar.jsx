import React, { useState } from "react";
import styled from "styled-components";
import LocalOfferIcon from "@mui/icons-material/LocalOffer";
import { Menu, Slider, Checkbox, Radio, Divider } from "antd";
import { styles } from "./../Api/Data";
function getItem(label, key, icon, children, type) {
  return {
    key,
    icon,
    children,
    label,
    type,
  };
}

const items = [
  getItem("Navigation One", "sub1", <LocalOfferIcon />, [
    getItem("Option 1", "1"),
    getItem("Option 2", "2"),
    getItem("Option 3", "3"),
    getItem("Option 4", "4"),
  ]),
  getItem("Navigation Two", "sub2", <LocalOfferIcon />, [
    getItem("Option 5", "5"),
    getItem("Option 6", "6"),
  ]),
  getItem("Navigation Three", "sub4", <LocalOfferIcon />, [
    getItem("Option 9", "9"),
    getItem("Option 10", "10"),
    getItem("Option 11", "11"),
    getItem("Option 12", "12"),
  ]),
];

// submenu keys of first level
const rootSubmenuKeys = ["sub1", "sub2", "sub4"];

const colorOptions = [
  "Red",
  "Black",
  "Orange",
  "Green",
  "Yello",
  "Gray",
  "Blue",
];

const sizeOptions = [
  "XS",
  "S",
  "M",
  "L",
  "XL",
  "XXL",
];


const onChangeColor = (checkedValues) => {
  console.log("checked = ", checkedValues);
};

const onChangeSize = (checkedValues) => {
  console.log("checked = ", checkedValues);
};



const Sidebar = () => {
  const [openKeys, setOpenKeys] = useState(["sub1"]);
  const [value, setValue] = useState();
  const onOpenChange = (keys) => {
    const latestOpenKey = keys.find((key) => openKeys.indexOf(key) === -1);
    if (rootSubmenuKeys.indexOf(latestOpenKey) === -1) {
      setOpenKeys(keys);
    } else {
      setOpenKeys(latestOpenKey ? [latestOpenKey] : []);
    }
  };
  
  const onChangeRating = (e) => {
    console.log("radio checked", e.target.value);
    setValue(e.target.value);
  };

  return (
    <React.Fragment>
      <SidebarSection>
        <CategoryList>
          <Title>Category</Title>
          <Menu
            mode="inline"
            openKeys={openKeys}
            onOpenChange={onOpenChange}
            style={{
              width: "100%",
            }}
            items={items}
          />
        </CategoryList>
        <Divider />
        <ProductFilter>
          <Title>Filter by Price</Title>
          <Slider
            range={{
              draggableTrack: true,
            }}
            defaultValue={[0, 100]}
          />
        </ProductFilter>
        <Divider />
        <ColorFilter>
          <Title>Filter by Color</Title>
          <Checkbox.Group
            options={colorOptions}
            defaultValue={[""]}
            onChange={onChangeColor}
          />
        </ColorFilter>
        <Divider />
        <ColorFilter>
          <Title>Filter by Color</Title>
          <Checkbox.Group
            options={sizeOptions}
            defaultValue={[""]}
            onChange={onChangeSize}
          />
        </ColorFilter>
        <Divider />
        <ColorFilter>
          <Title>Filter by Rating</Title>
          <Radio.Group onChange={onChangeRating} value={value}>
            <Radio value={1}>1 Star</Radio>
            <Radio value={2}>2 Star</Radio>
            <Radio value={3}>3 Star</Radio>
            <Radio value={4}>4 Star</Radio>
            <Radio value={5}>5 Star</Radio>
          </Radio.Group>
        </ColorFilter>
      </SidebarSection>
    </React.Fragment>
  );
};

export default Sidebar;

const SidebarSection = styled.section`
  display: inline-block;
  width: 100%;
  position: relative;

  ul.ant-menu.ant-menu-root.ant-menu-inline.ant-menu-light {
    border: 0;
    background: #fff;
  }
  ul li.ant-menu-item.ant-menu-item-only-child,
  ul li.ant-menu-item.ant-menu-item-active.ant-menu-item-only-child {
    padding-left: 50px !important;
  }
  .ant-slider-track,
  .ant-slider:hover .ant-slider-track {
    background: ${styles.background};
  }
  .ant-slider-handle,
  .ant-slider:hover .ant-slider-handle:not(.ant-tooltip-open) {
    border: solid 2px ${styles.background};
  }
  .ant-checkbox-checked::after {
    border: solid 1px ${styles.background};
  }
  .ant-checkbox-checked .ant-checkbox-inner {
    background-color: ${styles.background};
    border-color: ${styles.background};
  }
  .ant-radio-wrapper:hover .ant-radio,
  .ant-radio:hover .ant-radio-inner,
  .ant-radio-input:focus + .ant-radio-inner,
  .ant-radio-checked .ant-radio-inner {
    border-color: ${styles.background};
  }
  .ant-radio-inner::after {
    background-color: ${styles.background};
  }
  .ant-menu-inline.ant-menu-root .ant-menu-item,
  .ant-menu-inline.ant-menu-root .ant-menu-submenu-title,
  .bqSbPS ul li.ant-menu-item.ant-menu-item-only-child,
  .bqSbPS ul li.ant-menu-item.ant-menu-item-active.ant-menu-item-only-child {
    padding: 0 !important;
  }
  ul li.ant-menu-item.ant-menu-item-only-child,
  ul li.ant-menu-item.ant-menu-item-active.ant-menu-item-only-child {
    padding: 0 !important;
  }
  .ant-menu-sub.ant-menu-inline {
    background: #fff;
  }
  label.ant-checkbox-wrapper.ant-checkbox-group-item,
  .ant-radio-wrapper {
    margin: 0 10px 10px 0;
  }
  .ant-menu-light .ant-menu-item:hover,
  .ant-menu-light .ant-menu-item-active,
  .ant-menu-light .ant-menu:not(.ant-menu-inline) .ant-menu-submenu-open,
  .ant-menu-light .ant-menu-submenu-active,
  .ant-menu-light .ant-menu-submenu-title:hover,
  .ant-menu-submenu:hover
    > .ant-menu-submenu-title
    > .ant-menu-submenu-expand-icon,
  .ant-menu-submenu:hover > .ant-menu-submenu-title > .ant-menu-submenu-arrow {
    color: ${styles.background} !important;
  }
  .ant-menu-item.ant-menu-item-only-child span.ant-menu-title-content {
    padding: 10px 22px !important;
  }
  .ant-menu-item.ant-menu-item-only-child
    .ant-menu-submenu-title
    .ant-menu-title-content {
    padding: 10px 22px !important;
  }
`;
const CategoryList = styled.div`
  width:100%;
  display: inline-block;
  position: relative;
`;
const Title = styled.div`
  font-size: 18px;
  color: ${styles.background};
  margin: 0 0 20px;
  font-weight: 600;
  letter-spacing: 0.5px;
`;
const ProductFilter = styled.div`
  width: 100%;
  display: inline-block;
  position: relative;
`;
const ColorFilter = styled.div`
  width: 100%;
  display: inline-block;
  position: relative;
`;
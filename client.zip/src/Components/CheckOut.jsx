import React from 'react'
import styled from 'styled-components';
import { Button, message, Steps } from "antd";
import { styles } from './../Api/Data';
import YourOrder from "../Components/YourOrder";
import BillingAddress from './BillingAddress';
import Payment from './Payment';
const { Step } = Steps;
const steps = [
  {
    title: "Your Order",
    content: <YourOrder />,
  },
  {
    title: "Billing Address",
    content: <BillingAddress />,
  },
  {
    title: "Place Order",
    content: <Payment />,
  },
];

const CheckOut = () => {
   const [current, setCurrent] = React.useState(0);
   const next = () => {
     setCurrent(current + 1);
   };
   const prev = () => {
     setCurrent(current - 1);
   };
  return (
    <React.Fragment>
      <CheckOutPage>
        <Wrapper>
          <H2>Checkout</H2>
          <CheckOutAlign>
            <StepsAlign>
            <Steps current={current}>
              {steps.map((item) => (
                <Step key={item.title} title={item.title} />
              ))}
            </Steps>
            </StepsAlign>
            <div className="steps-content">{steps[current].content}</div>
            <div className="steps-action">
              
              {current !== steps.length - 1 && current > 0 && (
                <Button
                  style={{
                    margin: "0 8px",
                  }}
                  onClick={() => prev()}
                >
                  Previous
                </Button>
              )} 
              {current < steps.length - 1 && (
                <Button type="primary" onClick={() => next()}>
                  Next
                </Button>
              )}
              {/* {current === steps.length - 1 && (
                <Button
                  type="primary"
                  onClick={() => message.success("Processing complete!")}
                >
                  Place Order
                </Button>
              )} */}
            </div>
          </CheckOutAlign>
        </Wrapper>
      </CheckOutPage>
    </React.Fragment>
  );
}

export default CheckOut


const CheckOutPage = styled.section`
  margin: 60px 0 0 0;
  width: 100%;
  position: relative;
  .ant-steps-item-process .ant-steps-item-icon {
    background: ${styles.background};
    border-color: ${styles.background};
  }
  .ant-steps-item-finish
    > .ant-steps-item-container
    > .ant-steps-item-content
    > .ant-steps-item-title:after {
    background-color: ${styles.background};
  }
  .ant-steps-item-finish .ant-steps-item-icon {
    background-color: #fff;
    border-color: ${styles.background};
  }
  .anticon.anticon-check.ant-steps-finish-icon {
    color: ${styles.background};
  }
  .ant-btn.ant-btn-primary {
    border-color: ${styles.background};
    background: ${styles.background};
  }

  .steps-action {
    width: fit-content;
    float: right;
  }
`;
const Wrapper = styled.div`
  max-width: 1200px;
  margin: auto;
  padding: 0 10px;
  position: relative;

`;
const H2 = styled.h2`
  font-size: ${styles.h2};
  color: ${styles.color};
  margin: 0 0 30px;
  font-weight: 600;
`;
const CheckOutAlign = styled.div``;
const StepsAlign = styled.div`
  width: 100%;
  display: inline-block;
  padding: 0 150px;
`;
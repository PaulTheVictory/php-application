import React from "react";
import { Navigation, Pagination, Autoplay } from "swiper";
import { Swiper, SwiperSlide } from "swiper/react";
import "swiper/css";
import "swiper/css/navigation";
import "swiper/css/pagination";
import "swiper/css/scrollbar";
import { sliderItems, styles } from "../Api/Data";
import { Button } from "antd";
import styled from "styled-components";
const Banner = () => {
  return (
    <React.Fragment>
      <section className="slider">
        <Swiper
          className="home_banner_slider"
          spaceBetween={0}
          slidesPerView={1}
          loop={true}
          speed={1500}
          autoplay={{
            delay: 10000,
            disableOnInteraction: false,
          }}
          pagination={{
            clickable: true,
          }}
          navigation={true}
          modules={[Autoplay, Pagination, Navigation]}
        >
          {sliderItems.map((item) => (
            <SwiperSlide key={item.id}>
              <SliderSection style={{background:item.background}}>
                <Wrapper>
                  <SliderAlign>
                    <SliderLeft>
                      <Image src={item.img} alt={item.title} />
                    </SliderLeft>
                    <SliderRight>
                      <H2 style={{color:item.color,fontSize:item.h2}}>{item.title}</H2>
                      <P style={{color:item.color,fontSize:item.p}}>{item.description}</P>
                      <Button>Shop Now</Button>
                    </SliderRight>
                  </SliderAlign>
                </Wrapper>
              </SliderSection>
            </SwiperSlide>
          ))}
        </Swiper>
      </section>
    </React.Fragment>
  );
};

export default Banner;

const SliderSection = styled.div`
  display: inline-block;
  margin: 0 0 60px;
  position: relative;
  width: 100%;
  h2,
  p {
    padding: 0;
    margin: 0;
  }
  .home_banner_slider .swiper-button-next,
  .home_banner_slider .swiper-button-prev {
    color: ${styles.background} !important;
  }
  .home_banner_slider .swiper-button-next:after,
  .home_banner_slider .swiper-button-prev:after {
    color: ${styles.background} !important;
    font-size: 25px !important;
  }
  .home_banner_slider .swiper-pagination span {
    background: ${styles.background} !important;
  }
`;
const Wrapper = styled.div`
  max-width: 1200px;
  margin: auto;
`;
const SliderAlign = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  flex-wrap: wrap;
  width: 100%;
  position: relative;
  padding: 50px 0 0 0;
`;
const SliderLeft = styled.div`
  display: inline-block;
  width: 47%;
`;
const Image = styled.img`
  width: 100%;
`;
const SliderRight = styled.div`
  display: flex;
  flex-direction: column;
  gap: 25px;
  width: 47%;
  button {
    width: fit-content;
  }
`;
const H2 = styled.h2`
  
`;
const P = styled.p``;

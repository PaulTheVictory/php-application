import React from "react";
import {  styles } from "../Api/Data";
import { Link } from "react-router-dom";
import styled from "styled-components";
import CallIcon from "@mui/icons-material/Call";
import EmailIcon from "@mui/icons-material/Email";
import LocationOnIcon from "@mui/icons-material/LocationOn";
const Footer = () => {
  return (
    <React.Fragment>
      <FooterSection>
        <Wrapper>
          <FooterAlign>
            <Footer1>
              <Link to="/">
                <H2>Paul</H2>
              </Link>
              <P>
                Lorem ipsum, dolor sit amet consectetur adipisicing elit.
                Accusantium, adipisci natus esse qui dolorem eum non, numquam
                hic atque nemo sed dolorum iure explicabo aliquid quam labore.
              </P>
              <Ul>
                <Li>
                  <Link>
                    <svg
                      className="MuiSvgIcon-root"
                      focusable="false"
                      viewBox="0 0 24 24"
                      aria-hidden="true"
                    >
                      <path d="M5 3h14a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2m13 2h-2.5A3.5 3.5 0 0 0 12 8.5V11h-2v3h2v7h3v-7h3v-3h-3V9a1 1 0 0 1 1-1h2V5z"></path>
                    </svg>
                  </Link>
                </Li>
                <Li>
                  <Link>
                    <svg
                      className="MuiSvgIcon-root"
                      focusable="false"
                      viewBox="0 0 24 24"
                      aria-hidden="true"
                    >
                      <path d="M7.8 2h8.4C19.4 2 22 4.6 22 7.8v8.4a5.8 5.8 0 0 1-5.8 5.8H7.8C4.6 22 2 19.4 2 16.2V7.8A5.8 5.8 0 0 1 7.8 2m-.2 2A3.6 3.6 0 0 0 4 7.6v8.8C4 18.39 5.61 20 7.6 20h8.8a3.6 3.6 0 0 0 3.6-3.6V7.6C20 5.61 18.39 4 16.4 4H7.6m9.65 1.5a1.25 1.25 0 0 1 1.25 1.25A1.25 1.25 0 0 1 17.25 8 1.25 1.25 0 0 1 16 6.75a1.25 1.25 0 0 1 1.25-1.25M12 7a5 5 0 0 1 5 5 5 5 0 0 1-5 5 5 5 0 0 1-5-5 5 5 0 0 1 5-5m0 2a3 3 0 0 0-3 3 3 3 0 0 0 3 3 3 3 0 0 0 3-3 3 3 0 0 0-3-3z"></path>
                    </svg>
                  </Link>
                </Li>
                <Li>
                  <Link>
                    <svg
                      className="MuiSvgIcon-root"
                      focusable="false"
                      viewBox="0 0 24 24"
                      aria-hidden="true"
                    >
                      <path d="M22.46 6c-.77.35-1.6.58-2.46.69.88-.53 1.56-1.37 1.88-2.38-.83.5-1.75.85-2.72 1.05C18.37 4.5 17.26 4 16 4c-2.35 0-4.27 1.92-4.27 4.29 0 .34.04.67.11.98C8.28 9.09 5.11 7.38 3 4.79c-.37.63-.58 1.37-.58 2.15 0 1.49.75 2.81 1.91 3.56-.71 0-1.37-.2-1.95-.5v.03c0 2.08 1.48 3.82 3.44 4.21a4.22 4.22 0 0 1-1.93.07 4.28 4.28 0 0 0 4 2.98 8.521 8.521 0 0 1-5.33 1.84c-.34 0-.68-.02-1.02-.06C3.44 20.29 5.7 21 8.12 21 16 21 20.33 14.46 20.33 8.79c0-.19 0-.37-.01-.56.84-.6 1.56-1.36 2.14-2.23z"></path>
                    </svg>
                  </Link>
                </Li>
              </Ul>
            </Footer1>
            <Footer2>
              <FTitle>Useful Links</FTitle>
              <List>
                <Link to="/">
                  <Items>Home</Items>
                </Link>
                <Link to="/shop">
                  <Items>Shop</Items>
                </Link>
                <Link to="/dashboard">
                  <Items>My Account</Items>
                </Link>
                <Link to="/cart">
                  <Items>Cart</Items>
                </Link>
                <Link to="/wishlist">
                  <Items>WishList</Items>
                </Link>
              </List>
            </Footer2>
            <Footer3>
              <FTitle>Quick Links</FTitle>
              <List>
                <Link to="/">
                  <Items>Privacy Policy</Items>
                </Link>
                <Link to="/">
                  <Items>Return Policy</Items>
                </Link>
                <Link to="/">
                  <Items>Terms and Condition</Items>
                </Link>
                <Link to="/">
                  <Items>Refund Policy</Items>
                </Link>
                <Link to="/">
                  <Items>Shipping Details</Items>
                </Link>
              </List>
            </Footer3>
            <Footer4>
              <FTitle>Contact Us</FTitle>
              <P>
                <CallIcon />
                +91 99999 99999
              </P>
              <P>
                <EmailIcon />
                paulthevictory@gmail.com
              </P>
              <P>
                <LocationOnIcon />
                622 Dixie Path , South Tobinchester 98336
              </P>
              <Payment src={styles.payment} />
            </Footer4>
          </FooterAlign>
        </Wrapper>
      </FooterSection>
    </React.Fragment>
  );
};

export default Footer;

const FooterSection = styled.footer`
  display: inline-block;
  margin: 60px 0 0 0;
  position: relative;
  width: 100%;
  padding: 60px 0;
  background: ${styles.background};
`;
const Wrapper = styled.div`
  max-width: 1200px;
  margin: auto;
`;
const FooterAlign = styled.div`
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  flex-wrap: wrap;
  width: 100%;
`;
const Footer1 = styled.div`
  display: inline-block;
  width:25%;
  position: relative;
`;
const Footer2 = styled.div`
  width:fit-content;
  display: inline-block;
`;
const Footer3 = styled.div`
  width: fit-content;
  display: inline-block;
`;
const Footer4 = styled.div`
  width: 25%;
  display: inline-block;
`;
const H2 = styled.h2`
  background: #fff;
  padding: 1px 16px;
  border-radius: 2px;
  height: auto;
  width: fit-content;
  margin: 0 0 20px;
  font-size: 25px;
  font-weight: 700;
  text-transform: uppercase;
`;
const P = styled.div`
  color:#fff;
  line-height: 1.6;
  font-size: 16px;
  display: flex;
  align-items: center;
  gap: 10px;
  :not(:last-child) {
    margin: 0 0 15px;
  }
`;
const Ul = styled.div`
  display: flex;
  margin: 25px 0 0 0;
  align-items: center;
  gap: 20px;
`;
const Li = styled.div`
  color: #fff;
  svg {
    height: 35px;
    color: #fff !important;
    filter: brightness(0) invert(1);
    path {
      color: #fff !important;
    }
  }
`;
const FTitle = styled.div`
  font-size: 25px;
  line-height: 1.5;
  margin: 0 0 25px;
  font-weight: 600;
  color: #fff;
`;
const Payment = styled.img`
  max-width: 100%;
  width: 100%;
  margin: 12px 0 0 0;
`;
const List = styled.div`
  display: inline-block;
  width:100%;
  position: relative;
`;
const Items = styled.div`
  color: #fff;
  position: relative;
  line-height: 1.8;

  font-size: 16px;
  :not(:last-child) {
    margin: 0 0 8px;
  }
`;
import React from "react";
import styled from "styled-components";
import { Link } from "react-router-dom";
import { ShoppingCartOutlined, AlignRightOutlined } from "@ant-design/icons";
import { header, styles } from "../Api/Data";
import { Button, Input, Drawer } from "antd";
const { Search } = Input;

const Header = () => {
  const onSearch = (value) => console.log(value);
  const [open, setOpen] = React.useState(false);

  const showDrawer = () => {
    setOpen(true);
  };
  const onClose = () => {
    setOpen(false);
  }


  return (
    <HeaderSection>
      <HeaderText>
        <Wrapper>Super Deal! Free Shipping on Orders Over $50</Wrapper>
      </HeaderText>
      <Wrapper>
        <HeaderAlign>
          <HeaderLeft>
            <Search placeholder="Search Product" onSearch={onSearch} />
          </HeaderLeft>
          <HeaderCenter>
            <Link to="/">
              <H2>Paul</H2>
            </Link>
          </HeaderCenter>
          <HeaderRight>
            <Link to="/register">
              <Text>Register</Text>
            </Link>
            <Link to="/login">
              <Text>Login</Text>
            </Link>
            <Link to="/cart">
              <Button>
                <ShoppingCartOutlined />
                Cart (0)
              </Button>
            </Link>
            <MenuBarSection>
              <ButtonMenu type="primary" onClick={showDrawer}>
                <AlignRightOutlined />
              </ButtonMenu>
              <Drawer
                title="ecDigi"
                placement="right"
                onClose={onClose}
                open={open}
              >
                <Link to="/">
                  <p>Home</p>
                </Link>

                <p>About Us</p>
                <Link to="/shop">
                  <p>Shop</p>
                </Link>
                <Link to="/product">
                  <p>Product</p>
                </Link>
                <Link to="/my-account">
                  <p>My Account</p>
                </Link>

                <p>Brands</p>
              </Drawer>
            </MenuBarSection>
          </HeaderRight>
        </HeaderAlign>
      </Wrapper>
    </HeaderSection>
  );
};

export default Header;

const HeaderSection = styled.header`
  display: inline-block;
  width: 100%;
  position: relative;
  border-bottom: 1px solid ${styles.light};
`;
const Wrapper = styled.div`
  max-width: 1200px;
  margin: auto;
  padding: 0 10px;
`;
const HeaderText = styled.div`
  background: ${header.background};
  width: 100%;
  padding: 5px 0;
  text-align: center;
  line-height: 1.5;
  font-size: 14px;
  color: #fff;
`;
const HeaderAlign = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 12px 0;
  position: relative;
  height: 85px;
`;
const Text = styled.div`
  color: ${header.gray};
`;
const HeaderLeft = styled.div`
  display: inline-block;
  width: fit-content;
`;
const HeaderCenter = styled.div`
  display: inline-block;
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
`;


const HeaderRight = styled.div`
  display: flex;
  align-items: center;
  gap: 18px;
  flex-wrap: wrap;
  button {
    background: ${header.background};
    color: #fff;
    padding: 5px 12px;
    height: auto;
  }
`;
const MenuBarSection = styled.div`
width:fit-content;
position: relative;
`;
const ButtonMenu = styled.div`
cursor: pointer;
width: fit-content;
position: relative;
font-size: 27px;
font-weight: 700;
`;
const H2 = styled.h2`
font-size: 30px;
text-transform: uppercase;
font-weight: 700;
margin: 0;
`;
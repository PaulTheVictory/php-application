import axios from "axios";

const BASE_URL = process.env.REACT_APP_API;

export const companyName = process.env.REACT_APP_COMPANY_NAME;

export const publicRequest = axios.create({
  baseURL: BASE_URL,
});

export const userRequest = axios.create({
  baseURL: BASE_URL,
  headers: { Authorization: "Token", "Content-Type": "application/json"  },
});

export const uploadRequest = axios.create({
  baseURL: BASE_URL,
  headers: { Authorization: "Token", "Content-Type": "multipart/form-data" },
});

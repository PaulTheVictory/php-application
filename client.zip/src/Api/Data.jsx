import React from "react";
import {
  Tooltip,
} from "antd";

export const styles = {
  background: "#008080", //40a9ff //3f51b5 //ff4d4f
  gray: "#888",
  h1: "35px",
  h2: "30px",
  p: "16px",
  border: "#d9d9d9",
  light: "#f2f2f2",
  color: "#000",
  currency: "₹",
  default: "http://localhost/reactecom/upload/default.png",
  payment: "http://localhost/reactecom/upload/payment.webp",
};

export const header = {
  title: "Logo",
  image: "http://localhost/reactecom/upload/logo.png",
  background: "#008080",
  gray: "#888",
};

export const sliderItems = [
  {
    id: 1,
    title: "Summer Sale",
    img: "http://localhost/reactecom/upload/slider/1.png",
    description:
      "It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.",
    background: "rgb(252, 241, 237)",
    color: "#000",
    h2: "45px",
    p: "16px",
  },
  {
    id: 2,
    title: "Autumn Collection",
    img: "http://localhost/reactecom/upload/slider/2.png",
    description:
      "It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.",
    background: "rgb(251, 240, 244)",
    color: "#000",
    h2: "45px",
    p: "16px",
  },
  {
    id: 3,
    title: "Loungewear Love",
    img: "http://localhost/reactecom/upload/slider/3.png",
    description:
      "It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.",
    background: "rgb(245, 250, 253)",
    color: "#000",
    h2: "45px",
    p: "16px",
  },
];

export const popularCategory = [
  {
    id: 1,
    img: "http://localhost/reactecom/upload/products/p1.png",
    title: "Tiles and porcelain",
    count: 20,
    link: "",
  },
  {
    id: 2,
    img: "http://localhost/reactecom/upload/products/p2.png",
    title: "Pipes & accessories",
    count: 27,
    link: "",
  },
  {
    id: 3,
    img: "http://localhost/reactecom/upload/products/p3.png",
    title: "Bath",
    count: 9,
    link: "",
  },
  {
    id: 4,
    img: "http://localhost/reactecom/upload/products/p4.png",
    title: "Mirrors ",
    count: 15,
    link: "",
  },
  {
    id: 5,
    img: "http://localhost/reactecom/upload/products/p5.png",
    title: "Spotlights ",
    count: 25,
    link: "",
  },
  {
    id: 6,
    img: "http://localhost/reactecom/upload/products/p6.png",
    title: "Bathroom vanities",
    count: 15,
    link: "",
  },
  {
    id: 7,
    img: "http://localhost/reactecom/upload/products/p7.png",
    title: "Bathroom ",
    count: 29,
    link: "",
  },
  {
    id: 8,
    img: "http://localhost/reactecom/upload/products/p8.png",
    title: "Water heaters",
    count: 12,
    link: "",
  },
  {
    id: 9,
    img: "http://localhost/reactecom/upload/products/p9.png",
    title: "Power Tools",
    count: 39,
    link: "",
  },
  {
    id: 10,
    img: "http://localhost/reactecom/upload/products/p10.png",
    title: "Toilets and compacts",
    count: 8,
    link: "",
  },
  {
    id: 11,
    img: "http://localhost/reactecom/upload/products/p11.png",
    title: "Warm floor",
    count: 27,
    link: "",
  },
  {
    id: 12,
    img: "http://localhost/reactecom/upload/products/p12.png",
    title: "Insulation ",
    count: 6,
    link: "",
  },
];

export const brands = [
  {
    id: 1,
    img: "",
    title: "Warm floor",
    link: "",
    count: "",
  },
  {
    id: 2,
    img: "",
    title: "Warm floor",
    link: "",
    count: "",
  },
  {
    id: 3,
    img: "",
    title: "Warm floor",
    link: "",
    count: "",
  },
  {
    id: 4,
    img: "",
    title: "Warm floor",
    link: "",
    count: "",
  },
  {
    id: 5,
    img: "",
    title: "Warm floor",
    link: "",
    count: "",
  },
  {
    id: 6,
    img: "",
    title: "Warm floor",
    link: "",
    count: "",
  },
  {
    id: 7,
    img: "",
    title: "Warm floor",
    link: "",
    count: "",
  },
  {
    id: 8,
    img: "",
    title: "Warm floor",
    link: "",
    count: "",
  },
  {
    id: 9,
    img: "",
    title: "Warm floor",
    link: "",
    count: "",
  },
  {
    id: 10,
    img: "",
    title: "Warm floor",
    link: "",
    count: "",
  },
];

export const blog = [
  {
    id: 1,
    img: "",
    blogtitle: "Loungewear Love",
    blogcategory: "woman",
    created: "16-10-2022 05:45:45PM",
    blogdescription:
      "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy",
    url: "",
  },
  {
    id: 2,
    img: "",
    blogtitle: "Loungewear Love",
    blogcategory: "woman",
    created: "16-10-2022 05:45:45PM",
    blogdescription:
      "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy",
    url: "",
  },
  {
    id: 3,
    img: "",
    blogtitle: "Loungewear Love",
    blogcategory: "woman",
    created: "16-10-2022 05:45:45PM",
    blogdescription:
      "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy",
    url: "",
  },
  {
    id: 4,
    img: "",
    blogtitle: "Loungewear Love",
    blogcategory: "woman",
    created: "16-10-2022 05:45:45PM",
    blogdescription:
      "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy",
    url: "",
  },
  {
    id: 5,
    img: "",
    blogtitle: "Loungewear Love",
    blogcategory: "woman",
    created: "16-10-2022 05:45:45PM",
    blogdescription:
      "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy",
    url: "",
  },
];

export const featureProduct = [
  {
    id: 1,
    img: "",
    title: "Loungewear Love",
    mrp: 1000,
    sp: 950,
    stock: 2,
    category: ["Woman", "Men"],
    url: "",
    status: "show",
    saletype: "Hot",
    currency: "₹",
    created: "15-10-2022 10:30:35PM",
  },
  {
    id: 2,
    img: "",
    title: "Loungewear Love",
    mrp: 1000,
    sp: 950,
    stock: 2,
    category: ["Woman", "Men"],
    url: "",
    status: "show",
    saletype: "Hot",
    currency: "₹",
    created: "15-10-2022 10:30:35PM",
  },
  {
    id: 3,
    img: "",
    title: "Loungewear Love",
    mrp: 1000,
    sp: 950,
    stock: 2,
    category: ["Woman", "Men"],
    url: "",
    status: "show",
    saletype: "Hot",
    currency: "₹",
    created: "15-10-2022 10:30:35PM",
  },
  {
    id: 4,
    img: "",
    title: "Loungewear Love",
    mrp: 1000,
    sp: 950,
    stock: 2,
    category: ["Woman", "Men"],
    url: "",
    status: "show",
    saletype: "Hot",
    currency: "₹",
    created: "15-10-2022 10:30:35PM",
  },
  {
    id: 5,
    img: "",
    title: "Loungewear Love",
    mrp: 1000,
    sp: 950,
    stock: 2,
    category: ["Woman", "Men"],
    url: "",
    status: "show",
    saletype: "Hot",
    currency: "₹",
    created: "15-10-2022 10:30:35PM",
  },
  {
    id: 6,
    img: "",
    title: "Loungewear Love",
    mrp: 1000,
    sp: 950,
    stock: 2,
    category: ["Woman", "Men"],
    url: "",
    status: "show",
    saletype: "Hot",
    currency: "₹",
    created: "15-10-2022 10:30:35PM",
  },
  {
    id: 7,
    img: "",
    title: "Loungewear Love",
    mrp: 1000,
    sp: 950,
    stock: 2,
    category: ["Woman", "Men"],
    url: "",
    status: "show",
    saletype: "Hot",
    currency: "₹",
    created: "15-10-2022 10:30:35PM",
  },
  {
    id: 8,
    img: "",
    title: "Loungewear Love",
    mrp: 1000,
    sp: 950,
    stock: 2,
    category: ["Woman", "Men"],
    url: "",
    status: "show",
    saletype: "Hot",
    currency: "₹",
    created: "15-10-2022 10:30:35PM",
  },
];

export const productList = [
  {
    id: 1,
    img: "",
    title: "Loungewear Love",
    mrp: 1000,
    sp: 950,
    stock: 2,
    category: ["Woman", "Men"],
    url: "",
    status: "show",
    saletype: "Hot",
    currency: "₹",
    created: "15-10-2022 10:30:35PM",
  },
  {
    id: 2,
    img: "",
    title: "Loungewear Love",
    mrp: 1000,
    sp: 950,
    stock: 2,
    category: ["Woman", "Men"],
    url: "",
    status: "show",
    saletype: "Hot",
    currency: "₹",
    created: "15-10-2022 10:30:35PM",
  },
  {
    id: 3,
    img: "",
    title: "Loungewear Love",
    mrp: 1000,
    sp: 950,
    stock: 2,
    category: ["Woman", "Men"],
    url: "",
    status: "show",
    saletype: "Hot",
    currency: "₹",
    created: "15-10-2022 10:30:35PM",
  },
  {
    id: 4,
    img: "",
    title: "Loungewear Love",
    mrp: 1000,
    sp: 950,
    stock: 2,
    category: ["Woman", "Men"],
    url: "",
    status: "show",
    saletype: "Hot",
    currency: "₹",
    created: "15-10-2022 10:30:35PM",
  },
  {
    id: 5,
    img: "",
    title: "Loungewear Love",
    mrp: 1000,
    sp: 950,
    stock: 2,
    category: ["Woman", "Men"],
    url: "",
    status: "show",
    saletype: "Hot",
    currency: "₹",
    created: "15-10-2022 10:30:35PM",
  },
  {
    id: 6,
    img: "",
    title: "Loungewear Love",
    mrp: 1000,
    sp: 950,
    stock: 2,
    category: ["Woman", "Men"],
    url: "",
    status: "show",
    saletype: "Hot",
    currency: "₹",
    created: "15-10-2022 10:30:35PM",
  },
  {
    id: 7,
    img: "",
    title: "Loungewear Love",
    mrp: 1000,
    sp: 950,
    stock: 2,
    category: ["Woman", "Men"],
    url: "",
    status: "show",
    saletype: "Hot",
    currency: "₹",
    created: "15-10-2022 10:30:35PM",
  },
  {
    id: 8,
    img: "",
    title: "Loungewear Love",
    mrp: 1000,
    sp: 950,
    stock: 2,
    category: ["Woman", "Men"],
    url: "",
    status: "show",
    saletype: "Hot",
    currency: "₹",
    created: "15-10-2022 10:30:35PM",
  },
  {
    id: 9,
    img: "",
    title: "Loungewear Love",
    mrp: 1000,
    sp: 950,
    stock: 2,
    category: ["Woman", "Men"],
    url: "",
    status: "show",
    saletype: "Hot",
    currency: "₹",
    created: "15-10-2022 10:30:35PM",
  },
  {
    id: 10,
    img: "",
    title: "Loungewear Love",
    mrp: 1000,
    sp: 950,
    stock: 2,
    category: ["Woman", "Men"],
    url: "",
    status: "show",
    saletype: "Hot",
    currency: "₹",
    created: "15-10-2022 10:30:35PM",
  },
  {
    id: 11,
    img: "",
    title: "Loungewear Love",
    mrp: 1000,
    sp: 950,
    stock: 2,
    category: ["Woman", "Men"],
    url: "",
    status: "show",
    saletype: "Hot",
    currency: "₹",
    created: "15-10-2022 10:30:35PM",
  },
  {
    id: 12,
    img: "",
    title: "Loungewear Love",
    mrp: 1000,
    sp: 950,
    stock: 2,
    category: ["Woman", "Men"],
    url: "",
    status: "show",
    saletype: "Hot",
    currency: "₹",
    created: "15-10-2022 10:30:35PM",
  },
];

export const review = [
  {
    actions: [<span key="comment-list-reply-to-0">Reply to</span>],
    author: "Han Solo",
    avatar: "https://joeschmoe.io/api/v1/random",
    content: (
      <p>
        We supply a series of design principles, practical patterns and high
        quality design resources (Sketch and Axure), to help people create their
        product prototypes beautifully and efficiently.
      </p>
    ),
    datetime: (
      <Tooltip title="2016-11-22 11:22:33">
        <span>8 hours ago</span>
      </Tooltip>
    ),
  },
  {
    actions: [<span key="comment-list-reply-to-0">Reply to</span>],
    author: "Han Solo",
    avatar: "https://joeschmoe.io/api/v1/random",
    content: (
      <p>
        We supply a series of design principles, practical patterns and high
        quality design resources (Sketch and Axure), to help people create their
        product prototypes beautifully and efficiently.
      </p>
    ),
    datetime: (
      <Tooltip title="2016-11-22 10:22:33">
        <span>9 hours ago</span>
      </Tooltip>
    ),
  },
  {
    actions: [<span key="comment-list-reply-to-0">Reply to</span>],
    author: "Han Solo",
    avatar: "https://joeschmoe.io/api/v1/random",
    content: (
      <p>
        We supply a series of design principles, practical patterns and high
        quality design resources (Sketch and Axure), to help people create their
        product prototypes beautifully and efficiently.
      </p>
    ),
    datetime: (
      <Tooltip title="2016-11-22 10:22:33">
        <span>9 hours ago</span>
      </Tooltip>
    ),
  },
  {
    actions: [<span key="comment-list-reply-to-0">Reply to</span>],
    author: "Han Solo",
    avatar: "https://joeschmoe.io/api/v1/random",
    content: (
      <p>
        We supply a series of design principles, practical patterns and high
        quality design resources (Sketch and Axure), to help people create their
        product prototypes beautifully and efficiently.
      </p>
    ),
    datetime: (
      <Tooltip title="2016-11-22 10:22:33">
        <span>9 hours ago</span>
      </Tooltip>
    ),
  },
  {
    actions: [<span key="comment-list-reply-to-0">Reply to</span>],
    author: "Han Solo",
    avatar: "https://joeschmoe.io/api/v1/random",
    content: (
      <p>
        We supply a series of design principles, practical patterns and high
        quality design resources (Sketch and Axure), to help people create their
        product prototypes beautifully and efficiently.
      </p>
    ),
    datetime: (
      <Tooltip title="2016-11-22 10:22:33">
        <span>9 hours ago</span>
      </Tooltip>
    ),
  },
];



export const cart = [
  {
    id: 1,
    name: "Wood Pressed Groundnut Oil - 5 Litre",
    img: "",
    price: 1300,
    quantity: 1,
    total: 1300,
  },
  {
    id: 2,
    name: "Wood Pressed Groundnut Oil - 5 Litre",
    img: "",
    price: 1300,
    quantity: 3,
    total: 1300,
  },
  
];

class API {
  constructor() {
    this.rootUrl = process.env.BASE_URL;
    this.company = process.env.REACT_APP_COMPANY_NAME;
  }
}
import React from 'react';
import Register from "./Ecommerce/Register";
import Login from './Ecommerce/Login';
import NoPage from './Components/NoPage';
import Home from './Components/Home';
import { BrowserRouter as Router, Routes, Route, useLocation } from "react-router-dom";
import Header from './Includes/Header';
import Footer from './Includes/Footer';
import Shop from './Components/Shop';
import Product from './Components/Product';
import Cart from './Components/Cart';
import CheckOut from './Components/CheckOut';
import MyAccount from './Components/MyAccount';
function App() {

  const Wrapper = ({ children }) => {
    const location = useLocation();
    React.useLayoutEffect(() => {
      document.documentElement.scrollTo(500, 0);
    }, [location.pathname]);
    return children;
  };



  return (
    <React.Fragment>
      <Router>
        <Wrapper>
          <Header />
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/home" element={<Home />} />
            <Route path="/login" element={<Login />} />
            <Route path="/shop" element={<Shop />} />
            <Route path="/product" element={<Product />} />
            <Route path="/register" element={<Register />} />
            <Route path="/cart" element={<Cart />} />
            <Route path="/checkout" element={<CheckOut />} />
            <Route path="/my-account" element={<MyAccount />} />
            <Route path="*" element={<NoPage />} />
          </Routes>
          <Footer />
        </Wrapper>
      </Router>
    </React.Fragment>
  );
}

export default App;

<?php
error_reporting(E_ALL);
ini_set("display_errors", 1);
 $subject = "Scanned Certificates from CEAT Website";
 
 $refno = $_POST["refno"];
 
 //========================================
// Do not change anything below this line
//========================================

if (empty($_POST["name"])) { 
	echo "<script language='javascript'> alert('Fill in all mandatory fields')</script>";
   	echo "<script language='javascript'> window.open('regstatus.html?ref=".$refno."','_self')</script>";
   	exit; }
 

require("Mail.php");
require("Mail/mime.php");

//$mail = new PHPMailer(true);

//$mail->SetLanguage( 'en', 'phpmailer/language/' );
//$mail->IsSMTP();               // set mailer to use SMTP
//$mail->Host = "smtp.gmail.com";  // specify main and backup server or localhost
//$mail->SMTPAuth = true;     // turn on SMTP authentication
//$mail->Username = "todo@harvee.co.uk";  // SMTP username
//$mail->Password = "29R63757"; // SMTP password

//$mail->From = $mail->Username;	//Default From email same as smtp user
//$mail->FromName = "Online Scanned Copy";

//$mail->AddAddress("sasi@harvee.co.uk", "Latheef"); //Email address where you wish to receive/collect those emails.

//$mail->AddAddress("info@iacde.in", "CEAT"); //Email address where you wish to receive/collect those emails.

//$mail->AddBcc("harish@harvee.co.uk", "Harish Harvee");


//$mail->WordWrap = 50;                                 // set word wrap to 50 characters
//$mail->IsHTML(true);                                  // set email format to HTML

//$mail->Subject = $subject;


//if(is_uploaded_file($_FILES['uploaded_file']['tmp_name'])) {
//            $file = $_FILES['uploaded_file'];
//            }
			
$attachment_path_1 = $_FILES["uploaded_file_1"]["tmp_name"];
$attachment_name_1 = basename($_FILES['uploaded_file_1']['name']);

//$mail->AddAttachment($attachment_path_1, $attachment_name_1);

$attachment_path_2 = $_FILES["uploaded_file_2"]["tmp_name"];
$attachment_name_2 = basename($_FILES['uploaded_file_2']['name']);

//$mail->AddAttachment($attachment_path_2, $attachment_name_2);

 $allowed_extensions = array("pdf", "doc", "docx", "jpg", "jpeg", "png", "JPG", "JPEG", "PNG","txt");
 
 $type_of_uploaded_file1 = substr($attachment_name_1,  strrpos($attachment_name_1, '.') + 1);
 
 $type_of_uploaded_file2 = substr($attachment_name_2,  strrpos($attachment_name_2, '.') + 1);

$allowed_ext1 = false;
$allowed_ext2 = false;
$mimetype1 = "";
$mimetype2 = "";		                

    if(in_array($type_of_uploaded_file1,$allowed_extensions) )
    {
        if($type_of_uploaded_file1=="pdf") 
		{
			$mimetype1 = "application/pdf";
		}else if($type_of_uploaded_file1=="jpeg" || $type_of_uploaded_file1=="jpg" || $type_of_uploaded_file1=="png" || $type_of_uploaded_file1=="JPEG" || $type_of_uploaded_file1=="JPG" || $type_of_uploaded_file1=="PNG")
		{
			$mimetype1 = "image/*";
			
		}else if($type_of_uploaded_file1=="doc")
		{
			$mimetype1 = "application/msword";
			
		}else if($type_of_uploaded_file1=="docx")
		{
			$mimetype1 = "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
		}
		
    }else
	{
			$allowed_ext1 = true;
	}
	
	if(in_array($type_of_uploaded_file2,$allowed_extensions))
    {
        if($type_of_uploaded_file2=="pdf") 
		{
			$mimetype2 = "application/pdf";
		}else if($type_of_uploaded_file2=="jpeg" || $type_of_uploaded_file2=="jpg" || $type_of_uploaded_file2=="png" || $type_of_uploaded_file2=="JPEG" || $type_of_uploaded_file2=="JPG" || $type_of_uploaded_file2=="PNG")
		{
			$mimetype2 = "image/*";
			
		}else if($type_of_uploaded_file2=="doc")
		{
			$mimetype2 = "application/msword";
			
		}else if($type_of_uploaded_file2=="docx")
		{
			$mimetype2 = "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
		}
		
    }else 
	{
			$allowed_ext2 = true;
	}

if($allowed_ext1 || $allowed_ext2)
{
	echo "<script language='javascript'> alert('File or Image Extension Must be PDF,DOC,DOCX,JPG,JPEG,PNG')</script>";
	echo "<script language='javascript'> window.open('regstatustest.html?ref=".$refno."','_self')</script>";
	exit;
}


$text = "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.=
w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\"><html><head><meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\"></head><body>

<table style=\"padding-top:4px;margin:0em auto;width:600px\"><tbody>
<tr><td style=\"text-align:center;font-size:14px;padding-left:10px;color:#333;width:150px\">This message was sent from: www.iacde.in</td></tr>
</tbody></table>

<table style=\"background:#f5f5f5;border:2px solid #e5e5e5;border-collapse:collapse;padding-top:4px;margin:1.5em auto;width:600px\"><tbody>

<tr><td style=\"border-right:2px solid #e5e5e5;border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:150px\">Name</td><td style=\"border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:450px\">" .$_POST["name"]. "</td></tr>

</tbody></table>

</body></html>";

$text = str_replace('\"', '"', $text);
$text = str_replace("\'", "'", $text);

$from = "Online Scanned Copy <info@harvee.co.uk>";
$to = "CEAT <ceatfamily@gmail.com>";
$subject = $subject;
$body = $text;

$host = "smtp.gmail.com";
$username = "todo@harvee.co.uk";
$password = "JBs^@83)(@js";
$headers = array ('From' => $from,
  'To' => $to,
  'Subject' => $subject,
  'MIME-Version' => 1,
  'Content-type' => 'text/html;charset=iso-8859-1');

$smtp = Mail::factory('smtp',
  array ('host' => $host,
    'auth' => true,
    'username' => $username,
    'password' => $password));

 $crlf = "\n";
$mime = new Mail_mime();
 
$mime->setHTMLBody($body);
$mime->addAttachment($attachment_path_1, $mimetype1);  
$mime->addAttachment($attachment_path_2, $mimetype2);    
$body = $mime->get();
$headers = $mime->headers($headers);

$mail = $smtp->send($to, $headers, $body);
if (PEAR::isError($mail)) 
{
 
   	echo "<script language='javascript'> alert('Please Try Again Later')</script>";
   	echo "<script language='javascript'> window.open('regstatus.html?ref=".$refno."','_self')</script>";
   	exit;
}

/*$mime = new Mail_mime();
 
$mime->setHTMLBody($text);
$mime->addHTMLImage($path_of_uploaded_file, 'text/plain');

               
$body = $mime->get();

                
     
$mail->Body    = $text;
$mail->AltBody = $text; 

if(!$mail->Send())
{
       echo $mail->ErrorInfo;
  // 	echo "<script language='javascript'> alert('Please Try Again Later')</script>";
  // 	echo "<script language='javascript'> window.open('regstatus.html?ref=".$refno."','_self')</script>";
   	exit;
}*/


  //unlink($path_of_uploaded_file);
  	echo "<script language='javascript'> alert('Email Sent Successfully')</script>";
   	echo "<script language='javascript'> window.open('regstatus.html?ref=".$refno."','_self')</script>";
   	exit;
 



            
 
 ?>

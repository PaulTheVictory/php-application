<?php

require('includes/db.php');


			
$regtype = mysqli_real_escape_string($Connect,$_POST['regtype']);
$regname = mysqli_real_escape_string($Connect,$_POST['regname']);
$regemail = mysqli_real_escape_string($Connect,$_POST['regemail']);
$regphone = mysqli_real_escape_string($Connect,$_POST['regphone']);
$regcollege = mysqli_real_escape_string($Connect,$_POST['regcollege']);
$regcity = mysqli_real_escape_string($Connect,$_POST['regcity']);
$regstate = mysqli_real_escape_string($Connect,$_POST['regstate']);
$regdcino = mysqli_real_escape_string($Connect,$_POST['regdcino']);
//$regneftid = mysqli_real_escape_string($Connect,$_POST['regneftid']);

$regid = uniqid();

$offset=5*60*60 + 30*60;
$dateformat = 'Y-m-d H:i:s';
$curtime = gmdate($dateformat, time()+$offset);

$checksql = 'select id from ceat_regform where (email="'.$regemail.'" or phone="'.$regphone.'")  and paymentstatus="captured"';
$checkresult = mysqli_query($Connect,$checksql);
$checkrow = mysqli_num_rows($checkresult);

if($checkrow == 0 ){

$sql = "INSERT INTO ceat_regform(id,type,name,email,phone,college,city,state,dcino,created) VALUES ('$regid','$regtype','$regname','$regemail','$regphone','$regcollege','$regcity','$regstate','$regdcino','$curtime')";



$result = mysqli_query($Connect,$sql);

if($result){
	//sendmail($regtype,$regname,$regemail,$regphone,$regcollege,$regcity,$regstate,$regdcino);
	echo json_encode(array(0=>'success',1=>$regid));
	exit(0);
}else {
	echo json_encode(array(0=>'fail'));
	exit(0);
}	
	
}else{
	echo json_encode(array(0=>'exists'));
	exit(0);
}


function sendmail($regtype,$regname,$regemail,$regphone,$regcollege,$regcity,$regstate,$regdcino,$regneftid){

	
	$body = "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.=w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\"><html><head><meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\"></head><body>

	<table style=\"padding-top:4px;margin:0em auto;width:600px\"><tbody>
	<tr><td style=\"text-align:center;font-size:14px;padding-left:10px;color:#333;width:150px\">This message was sent from: " . getenv("HTTP_REFERER") . " - [" . $_SERVER['REMOTE_ADDR'] ."]</td></tr></tbody></table>

	<table style=\"background:#f5f5f5;border:2px solid #e5e5e5;border-collapse:collapse;padding-top:4px;margin:1.5em auto;width:600px\"><tbody>

	<tr><td style=\"border-right:2px solid #e5e5e5;border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:150px\">Membership Type</td><td style=\"border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:450px\">" . $regtype . "</td></tr>

	<tr><td style=\"border-right:2px solid #e5e5e5;border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:150px\">Name</td><td style=\"border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:450px\">" . $regname . "</td></tr>

	<tr><td style=\"border-right:2px solid #e5e5e5;border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:150px\">Email id</td><td style=\"border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:450px\">" . $regemail . "</td></tr>

	<tr><td style=\"border-right:2px solid #e5e5e5;border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:150px\">Mobile No</td><td style=\"border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:450px\">" . $regphone . "</td></tr>
	
	<tr><td style=\"border-right:2px solid #e5e5e5;border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:150px\">College / Clinic Name</td><td style=\"border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:450px\">" . $regcollege . "</td></tr>
	
	<tr><td style=\"border-right:2px solid #e5e5e5;border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:150px\">City</td><td style=\"border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:450px\">" . $regcity . "</td></tr>
	
	<tr><td style=\"border-right:2px solid #e5e5e5;border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:150px\">State</td><td style=\"border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:450px\">" . $regstate . "</td></tr>
	
	<tr><td style=\"border-right:2px solid #e5e5e5;border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:150px\">DCI Reg.No</td><td style=\"border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:450px\">" . $regdcino . "</td></tr>

	</tbody></table>

	</body></html>";

	
$subject = "CEAT PG Colloquium 2020 Register Form";
	
$toemail = "krishnan@harvee.co.uk";

$fromname = "CEAT PG Colloquium 2020";
	
$replyto = $regemail;
$pname = $regname;

$finalbody = urlencode($body);

$substr = 'webtag=Theri&toemail='.$toemail.'&fromname='.$fromname."&replyto=".$replyto."&pname=".$pname."&subject=".$subject."&body=".$finalbody;

$url = "http://35.88.44.130/sendmail?";


$ch = curl_init($url);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, $substr);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_HEADER, 0);  // DO NOT RETURN HTTP HEADERS 
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);  // RETURN THE CONTENTS OF THE CALL
$return_val = curl_exec($ch);


}

mysqli_close($Connect);

?>
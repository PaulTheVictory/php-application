<?php

require('includes/db.php');

//Test 
/*$APIkey = "rzp_test_xqLF8CsiOnnZP6";
$secretkey = "or7pxUIeOW9HjgRekw3R32ST";*/

//Live 
$APIkey = "rzp_live_kIBn4EQHi2qYGL";
$secretkey = "ajyOPX8kndECaXG8gc02T2gu";

include('razorpay/Razorpay.php');

use Razorpay\Api\Api;

$refno  = isset($_POST['merchantid'])?$_POST['merchantid']:'';
$paymentid = isset($_POST['paymentid'])?$_POST['paymentid']:'';
$payamount = isset($_POST['totalfees'])?$_POST['totalfees']:'';

$api = new Api($APIkey, $secretkey);

$payment = $api->payment->fetch($paymentid);

if($payment['status']!="captured")
{
	$payment = $payment->capture(array('amount' => $payment['amount']));
}

//print_r($payment);exit;

$payamount = $payment['amount']/100;
$paymentstatus = $payment['status'];
$method = $payment['method'];

date_default_timezone_set('Asia/Kolkata');
$created = date("Y-m-d H:i:s",$payment['created_at']);

$rzpay = 'INSERT INTO `razor_payment`(`rzpaymentid`, `rzentity`, `rzamount`, `rzstatus`, `rzcaptured`, `rzcard_id`, `rzerror_code`, `rzerror_description`, `rzcreated_at`) VALUES ("'.$payment['id'].'","'.$payment['entity'].'","'.$payment['amount'].'","'.$payment['status'].'","'.$payment['captured'].'","'.$payment['card_id'].'","'.$payment['error_code'].'","'.$payment['error_description'].'","'.$created.'")';
$rzresult = @mysqli_query($Connect,$rzpay);

$sql = 'update ceat_registration set paymentamount="'.$payamount.'", paymentmode="'.$method.'", paymentid="'.$paymentid.'", paymentstatus="'.$paymentstatus.'",paymenttime="'.$created.'" where id="'.$refno.'"';

$result = @mysqli_query($Connect,$sql);



if($result){
	echo $refno;
	Emailconfirmation($Connect,$refno,$payamount,$method,$paymentstatus,$created);
}else {
	echo "";
}

function Emailconfirmation($Connect,$refno,$payamount,$method,$paymentstatus,$created){
	
	
$sql = 'select * from ceat_registration where id="'.$refno.'"';

$result = @mysqli_query($Connect,$sql);

$row = mysqli_fetch_assoc($result);

if($row)
{
	$memtype = $row['memtype'];
	$name = $row['name'];
	$mobile = $row['mobile'];
	$email = $row['email'];
	
	
	if($paymentstatus=="captured")$status = "Payment Successful"; else $status = "Payment failed";
	
	$body = "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.=
w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\"><html><head><meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\"></head><body>

<table style=\"background:#fff;border:2px solid #e5e5e5;border-collapse:collapse;padding-top:4px;margin:1.5em auto;width:800px\"><tbody>

<tr><td style=\"text-align:center;font-size:18px;line-height:33px;color:#333;\"><img src=\"http://www.theceat.com/images/logo.jpg\" /></td></tr>

<tr><td style=\"text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;\">Dear ".$name.",</td></tr>

<tr><td style=\"text-align:justify;font-size:14px;line-height:33px;padding:0 10px;color:#333;\">Greetings, We have received your online application for Conservative and Endodontic Association of Tamilnadu Membership.</td></tr>

<tr><td style=\"text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;\">Payment Information:</td></tr>

<tr><td style=\"text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;\"><strong>Amount Paid <span style=\"margin-left: 38px;\">:</span> &#8377; </strong> ".$payamount."</td></tr>

<tr><td style=\"text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;\"><strong>Mode of Payment <span style=\"margin-left: 12px;\">:</span> </strong> ".ucfirst($method)."</td></tr>

<tr><td style=\"text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;\"><strong>Payment Date <span style=\"margin-left: 34px;\">:</span> </strong> ".date("d M Y, H:i:s A",strtotime($created))."</td></tr>

<tr><td style=\"text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;\"><strong>Status <span style=\"margin-left: 81px;\">:</span> </strong> ".$status."</td></tr>

<tr><td style=\"text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;\"><strong>Reference No <span style=\"margin-left: 39px;\">:</span> </strong> ".$refno."</td></tr>

<tr><td style=\"text-align:justify;font-size:14px;line-height:33px;padding:0 10px;color:#333;\"><strong>Once Your CEAT number is allotted you would receive a confirmation email.</strong></td></tr>

<tr><td style=\"text-align:left;font-size:14px;line-height:20px;padding-left:10px;color:#333;\">Regards <br/>Head office,<br/>CEAT.</td></tr>

</tbody></table>

</body></html>";

$subject = "CEAT Payment Confirmation";
$toemail = $email;
$fromname = "CEAT Registration";
$replyto = "";
$subject = $subject;
$pname = "CEAT";

$finalbody = urlencode($body);


$substr = 'webtag=Theri&toemail='.$toemail.'&fromname='.$fromname."&replyto=".$replyto."&pname=".$pname."&subject=".$subject."&body=".$finalbody;

$url = "http://35.88.44.130/sendmail?";

	

$ch = curl_init($url);

curl_setopt($ch, CURLOPT_POST, 1);

curl_setopt($ch, CURLOPT_POSTFIELDS, $substr);

curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);

curl_setopt($ch, CURLOPT_HEADER, 0);  // DO NOT RETURN HTTP HEADERS 

curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);  // RETURN THE CONTENTS OF THE CALL

$return_val = curl_exec($ch);


}

}
//print_r($payment);
?>

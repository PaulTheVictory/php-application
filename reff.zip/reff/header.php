<?php 

$url = ($_SERVER['SERVER_NAME']==='localhost')?'localhost/ceat/':'www.theceat.com/'; 
$base_url = 'https://'.$url; 

//$url = ($_SERVER['SERVER_NAME']==='localhost')?'localhost/theceat/':'http://localhost/theceat//'; 
//$base_url = 'http://'.$url; 

?>


<link rel="stylesheet" type="text/css" href="<?php echo $base_url;?>css/styles.css" />

<link rel="stylesheet" type="text/css" href="<?php echo $base_url;?>css/styles-media.css" />

<link rel="stylesheet" href="<?php echo $base_url;?>css/flexslider.css" type="text/css" />

<link rel="stylesheet" type="text/css" href="<?php echo $base_url;?>css/jquery.datetimepicker.css" />

<link rel="stylesheet" type="text/css" href="<?php echo $base_url;?>css/owl.carousel.css" />

<link rel="stylesheet" type="text/css" href="<?php echo $base_url;?>css/mobilemenu.css" />

<script type="text/javascript" src="<?php echo $base_url;?>js/jquery.js"></script>

<script type="text/javascript" src="<?php echo $base_url;?>js/jquery-ui.min.js"></script>
        
<script src="<?php echo $base_url;?>js/main.js" type="text/javascript" charset="utf-8"></script>
        
<script src="<?php echo $base_url;?>js/menu.js" type="text/javascript" charset="utf-8"></script>

<script type="text/javascript" src="<?php echo $base_url;?>js/jquery.flexslider.js"></script>

<script type="text/javascript" src="<?php echo $base_url;?>js/modernizr.custom.js"></script>

<script type="text/javascript" src="<?php echo $base_url;?>js/jquery.datetimepicker.js"></script>

<script type="text/javascript" src="<?php echo $base_url;?>js/owl.carousel.js"></script>

<script type="text/javascript" src="<?php echo $base_url;?>js/jquery.dlmenu.js"></script>
          
<script type="text/javascript" src="<?php echo $base_url;?>js/jquery.cookie.js"></script>
                 
       
<!--FlexSlider--><script type="text/javascript" charset="utf-8">
  							$(window).ready(function() {
								/*$('#flashcontainer .flexslider').flexslider({
									animation: 'slide',
									animationLoop: true,
									slideshowSpeed: 5000,
									animationSpeed: 2000,
									pauseOnHover: false,
									controlNav:false,
									directionNav:false
								});*/
								
								$('#innerflashcontainer .flexslider').flexslider();
								
  							});
				 </script> <!--FlexSlider-->
                 
<script>
ddsmoothmenu.init({
mainmenuid: "menu", //menu DIV id
orientation: 'h', //Horizontal or vertical menu: Set to "h" or "v"
classname: 'headermenu', //class added to menu's outer DIV
customtheme: ["#ffffff", "#004080"],
contentsource: "markup" //"markup" or ["container_id", "path_to_menu_file"]
}); 
</script>

<script type="text/javascript">
$(document).ready(function(){
	
	//$('#navmenu').slicknav();
	
	$( '#mobilemenu' ).dlmenu();
		
	$('#app_date').datetimepicker({
		format:'F j, Y, g:i A',
		minTime:'08:00',
		maxTime:'23:00',
		step:30,
		minDate:0
	});
	
	$(".testimonials").owlCarousel({

		navigation : true,		
		autoPlay : true,
		singleItem : true,
		pagination : false

	});
	
	$(".endroslider").owlCarousel({

		navigation : true,
		pagination : false,		
		autoPlay : false,
		items : 6,
		itemsDesktop : [1199, 6],
		itemsDesktopSmall : [959, 5],
		itemsTablet : [767, 3],
		itemsTabletSmall : [479, 2],
		itemsMobile : [359, 1]

	});
	
	if(window.location.hash != "#confreg")
    {
        $.cookie("memcat",'', {path:'/'});
		$.cookie("memlist",'', {path:'/'});
		$.cookie("userid",'', {path:'/'});
    }
	
	if(window.location.hash != "#confabstract")
    {
        $.cookie("regno",'', {path:'/'});
    }

});
</script>

<!--<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_GB/sdk.js#xfbml=1&version=v2.5";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));

$(window).load(function(e) {
    $("#u_0_5 span").css({'display':'block !important'});
});-->

</script>

<!--HighSlide-->  

<script type="text/javascript" src="highslide/highslide-with-gallery.js"></script>
<link rel="stylesheet" type="text/css" href="highslide/highslide.css" />

<script type="text/javascript">
	hs.graphicsDir = 'highslide/graphics/';
	hs.align = 'center';
	hs.transitions = ['expand', 'crossfade'];
	hs.outlineType = 'rounded-white';
	hs.fadeInOut = true;
	hs.showCredits = false;
	//hs.dimmingOpacity = 0.75;

// Add the controlbar

hs.addSlideshow({
	//slideshowGroup: 'group1',
	interval: 5000,
	repeat: false,
	useControls: true,
	fixedControls: 'fit',
	overlayOptions: {
		opacity: .75,
		position: 'bottom center',
		hideOnMouseOut: true
	}
});
	
	$(document).ready(function(e) {
    
	$('a.highslide').each(function() {
	   this.onclick = function() {
		 return hs.expand(this);
	   };
	});
});
	
</script>     
<!--HighSlide-->
 
</head>

<body>

<div id="headertop">

	<div class="top-first">
    
    	<div class="wrap">
            
            <div class="top-right">
             <div class="top-social">
                    <a class="top-loc" href="<?php echo $base_url;?>contact.html" title="Contact Us">Contact Us</a>
                    <a class="top-support" href="<?php echo $base_url;?>faq.html" title="FAQ">FAQ</a>
                    <!--<a class="top-faq" href="join.html" title="Join/Renew Membership">Join/Renew Membership</a>
                    <a class="top-support" href="#" title="Dentist Directory">Dentist Directory</a>-->
                </div>
            	
            </div>
            
        </div>
    	
    </div>
    
    <div class="clear"></div>
    
    <div class="top-bottom">

	<div class="wrap">
    
    	<a href="<?php echo $base_url;?>" title="CEAT" class="logolink"><img class="logo" src="<?php echo $base_url;?>images/logo.jpg" /></a>
        
        <div class="header-middle-right">
        
        	<!--<a class="member" href="member_area" title="Member Login"><span>Member Login</span></a>-->
			<div class="searchbox">
				
				<!--<a class="member" href="https://www.acdi.co.in/presentationupload.html" title="ACDI E-Poster Submission"><span>ACDI E-Poster Submission</span></a>-->
			
				<a class="member" href="<?php echo $base_url;?>join.html" title="Join/Renew Membership"><span>Join Membership</span></a>
			
			<?php 
						 		$name = "";
						 		if(isset($_COOKIE['ci_session']))
								{
									$cisess_cookie = $_COOKIE['ci_session'];
									$cisess_cookie = stripslashes($cisess_cookie);
									$cisess_cookie = unserialize($cisess_cookie);//print_r($cisess_cookie);
									$cisess_session_id = $cisess_cookie['session_id'];

									require('db.php');

									//$userid = $cisess_cookie['logged_in']['username'];

									$sql = 'select u.name from ceat_sessions as s,ceat_users as u where s.sessionid="'.$cisess_session_id.'" and u.userid=s.userid';
									$result = mysqli_query($Connect,$sql);
									$row = mysqli_fetch_assoc($result);

									if(mysqli_num_rows($result) > 0)
									{
										$name = $row['name'];
									}
								}
						 ?>
                       
                        <?php if($name!="" &&  $name=="CEAT Administrator"){?>
                        <a class="member" href="<?php echo $base_url;?>member_area/home" title="My Admin"><span>My Admin</span></a>
                        <?php }else if ($name!="" && $name!="CEAT Administrator"){?>
                        <a class="member" href="<?php echo $base_url;?>member_area/profile" title="My Profile"><span>My Profile</span></a>
                        <?php }else{?>
                        <a class="member" href="<?php echo $base_url;?>member_area" title="Member Login"><span>Member Login</span></a>
                        <?php }?>
                                                
				<!--<input type="text" name="search" id="search" placeholder="Search" />
			  <div id="test"></div><span class="searchicon"></span>
				  <script>
				  (function() {
					var cx = '005631785828638982604:f0mbzpodihk';
					var gcse = document.createElement('script');
					gcse.type = 'text/javascript';
					gcse.async = true;
					gcse.src = 'https://cse.google.com/cse.js?cx=' + cx;
					var s = document.getElementsByTagName('script')[0];
					s.parentNode.insertBefore(gcse, s);
				  })();
				  
						//$("input.gsc-search-button").attr('type','text');
					  
var myCallback = function() {
  if (document.readyState == 'complete') {
    // Document is ready when CSE element is initialized.
    // Render an element with both search box and search results in div with id 'test'.
    google.search.cse.element.render(
        {
          div: "test",
          tag: 'search'
         });
  } else {
    // Document is not ready yet, when CSE element is initialized.
    google.setOnLoadCallback(function() {
       // Render an element with both search box and search results in div with id 'test'.
        google.search.cse.element.render(
            {
              div: "test",
              tag: 'search'
            });
    }, true);
  }
};

// Insert it before the CSE code snippet so that cse.js can take the script
// parameters, like parsetags, callbacks.
window.__gcse = {
  parsetags: 'explicit',
  callback: myCallback
};
                </script>
               <gcse:search></gcse:search>
                <style>
                .gsc-control-cse{ background:none; border:none; padding:0;}
                .gsc-control-cse div{ text-align:left; }
				.gsc-input-box{border: 1px solid #959595;height: 30px;width: 250px;float: left;border-radius: 5px;margin-left: 107px;}
				input.gsc-search-button, input.gsc-search-button:hover, input.gsc-search-button:focus{float: right;border:1px solid #959595;height:26px;width: 30px;border-radius: 5px;	margin: 2px 2px;background-color: #fff;padding: 2px;background-image: url(images/search.jpg); background-repeat:no-repeat; background-position:10px; cursor:pointer;}
				table.gsc-search-box td.gsc-input { padding-right: 0px !important;}
				.gsib_a { padding: 7px 6px 0 !important;}
                </style>-->
			</div>
            <!--<div class="facebooklikecon">
            <div class="fb-like" data-href="https://www.facebook.com/Surya-Dental-Care-Trichy-106171316430449/?fref=ts" data-layout="standard" data-action="like" data-show-faces="true" data-share="true">
            </div>
            </div>-->
        </div>
        
        <div id="navigation">
        
        <div class="wrap">
    
    	<div id="menu" class="headermenu">
            
            <ul id="navmenu">
            
                <li><a href="<?php echo $base_url;?>" title="Home">Home</a></li>
                
                <li><a href="#" title="About CEAT">About CEAT</a>
					<ul>
						<li><a href="<?php echo $base_url;?>about-us.html" title="About Us">About Us</a></li>
						<li><a href="<?php echo $base_url;?>office-bearers.html" title="Office Bearers">Office Bearers</a></li>
						<!--<li><a href="<?php //echo $base_url;?>election-guidelines.html" title="Election Guidelines">Election Guidelines</a></li>-->
					</ul>
               </li>
                
                <li><a href="<?php echo $base_url;?>by-laws.html" title="ByLaws">ByLaws</a></li>
                            
                <li><a href="http://www.jodend.com/" target="_blank" title="Our Journal">Our Journal</a></li>
                
                <li><a href="<?php echo $base_url;?>awards.html" title="CEAT Awards">CEAT Awards</a></li>
                
                <li><a href="<?php echo $base_url;?>news-events.html" title="News &amp; Events">News &amp; Events</a></li>
                                    
			</ul>
                        
		</div>
        
           <!-- <a class="book-top" href="#" title="Fix Appointment"><span></span>Fix Appointment</a>-->
        
       </div>
       
       </div>

 </div>
    
	</div>
     
   <div class="clear"></div>    
   
</div>
       
       <div class="mobilemenu">
        <button class="dl-trigger"><div class="iconsnav"></div></button>
        <div id="mobilemenu" class="dl-menuwrapper">
        <div class="dl-subwrapper">
               
               <ul class="dl-menu">
            
                  <li><a href="<?php echo $base_url;?>" title="Home">Home</a></li>
                
                <li><a href="#" title="About CEAT">About CEAT</a>
					<ul class="dl-submenu">
						<li><a href="<?php echo $base_url;?>about-us.html" title="About Us">About Us</a></li>
						<li><a href="<?php echo $base_url;?>office-bearers.html" title="Office Bearers">Office Bearers</a></li>
						<!--<li><a href="<?php //echo $base_url;?>election-guidelines.html" title="Election Guidelines">Election Guidelines</a></li>-->
					</ul>
               </li>
                
                 <li><a href="<?php echo $base_url;?>by-laws.html" title="ByLaws">ByLaws</a></li>
                            
                <li><a href="http://www.jodend.com/" target="_blank" title="Our Journal">Our Journal</a></li>
                
                <li><a href="<?php echo $base_url;?>awards.html" title="CEAT Awards">CEAT Awards</a></li>
                
                <li><a href="<?php echo $base_url;?>news-events.html" title="News &amp; Events">News &amp; Events</a></li>
            
			</ul>
            
        </div>
        </div>
        </div>

<div class="clear"></div>
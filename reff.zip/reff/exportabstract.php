<?php

include('includes/db.php');

$memrole = $_POST['memrole'];

/*foreach($_POST['fields'] as $value) {
$fields .= "$value,"; }

$fields = substr($fields,0,-1);
*/
$fields = 'name,email,contactnumber,iacdeno,regno,regcategory,institution,pcategory,subject,ptype,title,authors,abstract,comments,created';
$fieldtitle = explode(",", $fields);

if($memrole!="admin"){
	echo "<script language='javascript'> window.open('http://www.theceat.com/member_area/','_self')</script>";
	exit(0);
}

		
$datetime = date("Y-m-d_His");
$savename = "members_";  // excel file name
mysqli_query($Connect,"Set Names 'utf-8′");
$file_type = "vnd.ms-excel";
$file_ending = "xls";
header("Content-Type: application/$file_type;charset=utf-8");
header("Content-Disposition: attachment; filename=" .$savename."".$datetime. ".$file_ending");
//header("Pragma: no-cache");      

$now_date = date("Y-m-j H:i:s");
$title = "Member List";

$sql = "SELECT ".$fields." FROM ceat_abstract where regno<>'' and iacdeno<>'' order by created asc";    //export entity_id from 1 to 1000
//$ALT_Db = @mysql_select_db($DB_DBName, $Connect) or die("Couldnt select database");
$result = @mysqli_query($Connect,$sql);

$sep = "\t";

foreach ($fieldtitle as $val) {
    echo $val . "\t";
}


print("\n");
$i = 0;
while ($row = mysqli_fetch_row($result)) {
    $schema_insert = "";
    for ($j = 0; $j < mysqli_num_fields($result); $j++) {
        if (!isset($row[$j]))
            $schema_insert .= "NULL" . $sep;
        elseif ($row[$j] != "")
            $schema_insert .= "$row[$j]" . $sep;
        else
            $schema_insert .= "" . $sep;
    }
    $schema_insert = str_replace($sep . "$", "", $schema_insert);
    $schema_insert .= "\t";
    print(trim($schema_insert));
    print "\n";
    $i++;
}
return (true);
?>

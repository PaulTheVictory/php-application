<?php

use \setasign\Fpdi;

require_once(dirname(__FILE__).'/fpdf/fpdf.php');
require_once(dirname(__FILE__).'/FPDI/src/autoload.php');

include('includes/db.php');

//require('fpdf/makefont/makefont.php');
//MakeFont('fpdf/fonts/tt0144m_.ttf','cp1252');

$emailid  = isset($_POST['pgregno'])?$_POST['pgregno']:'';
$name  = isset($_POST['name'])?$_POST['name']:'';

//$pgregno = strtoupper($pgregno);

$name = ucwords(strtolower($name));

$name = "Dr. ".$name;

$checksql = 'select name from ceat_regform where email="'.$emailid.'"';
$checkresult = mysqli_query($Connect,$checksql);
//$checkrow = mysqli_num_rows($checkresult);
$row = mysqli_fetch_assoc($checkresult);

if(count($row) >0 ){
	
	$name = $row['name'];
	$name = str_replace(array('Dr.','Dr','Dr. '),"",$name);
	$fullname = ucwords(strtolower($name));

// initiate FPDI
$pdf = new Fpdi\Fpdi();

// get the page count
$pageCount = $pdf->setSourceFile(dirname(__FILE__).'/images/certificate/pgcollquium.pdf');
// iterate through all pages
for ($pageNo = 1; $pageNo <= $pageCount; $pageNo++) {
    // import a page
    $templateId = $pdf->importPage($pageNo);
	
	$pdf->AddFont('dantemtstd-italic','','dantemtstd-italic.php');

    $pdf->AddPage();
    // use the imported page and adjust the page size
    $pdf->useTemplate($templateId, ['adjustPageSize' => true]);

    $pdf->SetFont('dantemtstd-italic','','25');
	$pdf->SetTextColor('0' ,'0' ,'0');
    $pdf->SetXY(99, 112);
    $pdf->Write(8, $fullname);
}

// Output the new PDF
$pdf->Output(); 
	

}else{
	echo '<script>alert("Invalid Member.");javascript:history.go(-1);</script>';
}


?>
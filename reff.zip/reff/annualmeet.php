<?php

require('includes/db.php');

$name  = isset($_POST['name'])?$_POST['name']:'';
$mobile  = isset($_POST['mobile'])?$_POST['mobile']:'';
$email = isset($_POST['email'])?$_POST['email']:'';

$institution = isset($_POST['organisation'])?$_POST['organisation']:'';

$id = uniqid();

$offset=5*60*60 + 30*60;
$dateformat = 'Y-m-d H:i:s';
$curtime = gmdate($dateformat, time()+$offset);

$checksql = 'select id from ceat_annualmeet where mobile like "%'.$mobile.'%" or email like "%'.$email.'%"';
$checkresult = mysqli_query($Connect,$checksql);
$checkrow = mysqli_num_rows($checkresult);

if($checkrow == 0 ){
	
$sql = 'insert into ceat_annualmeet (`id`,`name`,`mobile`,`email`,`institution`,`created`) values ("'.$id.'","'.$name.'","'.$mobile.'","'.$email.'","'.$institution.'","'.$curtime.'")';
$result = mysqli_query($Connect,$sql);


if($result){
	echo json_encode(array(0=>'success'));
	exit(0);
}else {
	echo json_encode(array(0=>'fail'));
	exit(0);
}
	
}else {
	echo json_encode(array(0=>'exists'));
	exit(0);
}


?>
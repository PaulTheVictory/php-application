
           
        <a href="presentation"><li>Presentation</li></a><div id="profile-left">

	<img class="proimg" src="<?php echo $this->config->item('web_url');?>images/ap.jpg" />
    
    <ul>
    
    	<a href="home"><li>Dashboard</li></a>
        
        <a href="allusers"><li>View Users</li></a>
        
        <a href="searchusers"><li>Search Users</li></a>
        
        <a href="exportdata"><li>Export Data</li></a>
        
        <a href="newmember"><li>Add Member</li></a>
        
        <!--<a href="admincommunity"><li>Community</li></a>-->
        
        <!--<a href="addcollege"><li>Add College</li></a>
        
        <a href="collegelist"><li>College List</li></a>-->

       <!-- <a href="subjects"><li>Question Papers</li></a>
        
        <a href="notices"><li>Add Notifications</li></a>-->
        
        <a href="confregistrants"><li>Conference Registrants</li></a>
        
        <a href="preconfregistrants"><li>Preconference</li></a>
        
        <a href="testregistrants"><li>Test Registrants</li></a>
        
        <a href="abstracts"><li>Abstracts</li></a>
        
        <a href="nominees"><li>Nominees</li></a>
           
        <a href="election"><li>Election</li></a>
           
        <a href="presentation"><li>Presentation</li></a>
           
        <a href="annualmeet"><li>Annual Meet</li></a>
    
    </ul>

</div>

<div id="profile-right">

	<h1>Dr. <?php echo $membername['name']; ?><br /><span style="font-size:12px">Membership ID: admin</span></h1>
    
    <div class="clear"></div>

	<h2>Export Members Data</h2> 
    
    <form action="<?php echo $this->config->item('web_url');?>exportmembersdata.php" method="post">
    
    	<input type="hidden" name="memrole" value="<?php echo $role; ?>" />
        
        <table style="text-align:left;">
        
        	<tr>
            
            	<td width="200"><input type="checkbox" checked="checked" name="fields[]" value="userid" />Userid</td>
                
                <td width="200"><input type="checkbox" checked="checked" name="fields[]" value="name" />Name</td>
                
                <td width="200"><input type="checkbox" name="fields[]" value="mobile" />Mobile</td>
                
                <td width="200"><input type="checkbox" name="fields[]" value="phone" />Phone</td>
            
            </tr> 
            
            <tr>
            
            	<td width="200"><input type="checkbox" name="fields[]" value="email" />Email</td>
                
                <td width="200"><input type="checkbox" name="fields[]" value="address" />Address</td>
                
                <td width="200"><input type="checkbox" name="fields[]" value="clinicaddress" />Clinic Address</td>
                
                <td width="200"><input type="checkbox" name="fields[]" value="contactaddress" />Communication Address</td>
            
            </tr>  
            
            <tr>
            
            	<td width="200"><input type="checkbox" name="fields[]" value="designation" />Designation</td>
                
                <td width="200"><input type="checkbox" name="fields[]" value="qualification" />Qualification</td>
                
                <td width="200"><input type="checkbox" name="fields[]" value="college" />College</td>
                
                <td width="200"><input type="checkbox" name="fields[]" value="dob" />DOB</td>
            
            </tr>  
            
            <tr>
            
            	<td width="200"><input type="checkbox" name="fields[]" value="gender" />Gender</td>         
            
            </tr>     
        
        </table>
                
        <input type="submit" value="Export" id="editbut" style="float:none;" />
    
    </form>
    
    <div class="clear"></div>

	<!--<h2>Export Colleges Data</h2> 
    
    <form action="<?php echo $this->config->item('web_url');?>exportcollegesdata.php" method="post">
    
    	<input type="hidden" name="memrole" value="<?php echo $role; ?>" />
        
        <table style="text-align:left;">
        
        	<tr>
            
            	<td width="200"><input type="checkbox" checked="checked" name="fields[]" value="userid" />Userid</td>
                
                <td width="200"><input type="checkbox" checked="checked" name="fields[]" value="collegename" />College Name</td>
                
                <td width="200"><input type="checkbox" name="fields[]" value="contactnumber" />Contact Number</td>
                
                <td width="200"><input type="checkbox" name="fields[]" value="email" />Email</td>
            
            </tr> 
            
            <tr>
            
            	<td width="200"><input type="checkbox" name="fields[]" value="address" />Address</td>
                
                <td width="200"><input type="checkbox" name="fields[]" value="city" />City</td>
                
                <td width="200"><input type="checkbox" name="fields[]" value="state" />State</td>
                
                <td width="200"><input type="checkbox" name="fields[]" value="pincode" />Pincode</td>
            
            </tr>  
              
        
        </table>
                
        <input type="submit" value="Export" id="editbut" style="float:none;" />
    
    </form>-->
    
      
   
</div>
   
   
   
  
 
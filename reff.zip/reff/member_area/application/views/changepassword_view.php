
<script type="text/javascript">
$(document).ready(function(){	
	
	$(".changepass").click(function(){
		
		var currentpass = $(".currentpass").val();
		var newpass = $(".newpass").val();
		var repeatpass = $(".repeatpass").val();
		
		if(currentpass==""){ $(".currentpass").addClass('errclass');$(".edit-err-notify").text("Invalid Current Password");return;}
		if(newpass==""){ $(".newpass").addClass('errclass');$(".edit-err-notify").text("Invalid New Password");return;}
		if(repeatpass==""){ $(".repeatpass").addClass('errclass');$(".edit-err-notify").text("Invalid Repeat Password");return;}
		
		if(repeatpass!=newpass){ $(".repeatpass").addClass('errclass');$(".edit-err-notify").text("Password Mismatch");return;}
		
		$(".edit-err-notify").html("<font style=\"color:#44f2f8\">Processing...</font>");
                 $.get('changepassword/editPassword',{
					   'currentpass':currentpass,
					   'newpass':newpass				   

                 }, function(o) { 
				 		var obj1 = $.parseJSON(o);
						if(obj1[0] == 'success'){
				 			$(".edit-err-notify").html("<font style=\"color:#44f2f8\">Password Updated</font>"); 
                            setTimeout(function(){ location.assign("profile");}, 2000);  
						}else if(obj1[0] == 'fail'){
				 			$(".edit-err-notify").html("<font style=\"color:#44f2f8\">Incorrect Current Password</font>");                             
						}else if(obj1[0] == ''){
							setTimeout(function(){ $(".edit-err-notify").html("<font style=\"color:#44f2f8\">Please Try again later.</font>"); }, 2000);
						}
                 });	
		
	});
	
	 $("#profile-right").find("input").each(function(){

          $(this).click(function(){ $(this).removeClass("errclass");$(".edit-err-notify").text("");});

     });
	
});
</script>

<div id="profile-left">

	<img class="proimg" src="<?php echo base_url();?>docs/profile/<?php echo $membername['profileimg']; ?>" width="140" height="160" />
    
    <ul>
    
    	<a href="home"><li>Recent Activity</li></a>
        
        <a href="profile"><li>Profile</li></a>
        
        <a href="bio"><li>Bio</li></a>
        
        <a href="connectionlist"><li>Find a Connection</li></a>
        
        <a href="messageinbox"><li>Messages</li></a>
        
        <a href="communitylist"><li>Communities</li></a>
        
        <?php if($membername['role']=="STUDENT"){ ?><a href="upgrademembership"><li>Upgrade Membership</li></a><?php } ?>
    
    </ul>

</div>

<div id="profile-right">

	<h1>Dr. <?php echo $membername['name']; ?><br /><span style="font-size:12px">Membership ID: <?php echo $membername['userid']; ?></span></h1>
    
    <div class="right-options">
    
    	<button class="changepass" id="editbut">Save</button><br />
        <p style="margin:15px 0 0; text-align:right; color:#fff;" class="edit-err-notify"></p>
    
    </div>
    
    <div class="clear"></div>

	<div id="profile-titles">
    
    	<h2>Current Password</h2>
    
    </div>
    
    <div id="profile-content">
    
    	<p><input class="create-text-box currentpass" value="" /></p>
            
    </div>
    
    <div style="clear:both; height:30px;"></div>
    
    <div id="profile-titles">
    
    	<h2>New Password</h2>
    
    </div>
    
    <div id="profile-content">
    
    	<p><input class="create-text-box newpass" value="" /></p>
            
    </div>    
    
    <div style="clear:both; height:30px;"></div>
    
    <div id="profile-titles">
    
    	<h2>Repeat Password</h2>
    
    </div>
    
    <div id="profile-content">
    
    	<p><input class="create-text-box repeatpass" value="" /></p>
            
    </div>
    
    <div style="clear:both; height:30px;"></div>
    
      
      	

</div>
   
   
   
  
 
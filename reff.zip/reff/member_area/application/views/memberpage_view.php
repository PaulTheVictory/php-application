
<script type="text/javascript">
$(document).ready(function(){
	
	$("#connection-request").click(function(){
		
		var memberid = "<?php echo $memberid; ?>";
		 
		var r=confirm("Are you sure ?")
		if (r==true){
  			$(".edit-err-notify").html("<font style=\"color:#f7d8ba\">Processing...</font>");
                 $.get('memberpage/sendConnectionRequest',{
					   'memberid':memberid			   

                 }, function(o) {  $(".edit-err-notify").html("<font style=\"color:#f7d8ba\">Request Sent Successfully</font>"); 
                           setTimeout(function(){ location.reload();}, 2000);
                 }, 'json');
				 
  		}
		 
	 });
	 
	 $("#connection-status").click(function(){
		$("#connection-options").show();
	 });
	 
	 $(document).mouseup(function (e){
    	var container = $("#connection-options");

    	if (container.has(e.target).length === 0){
        	container.hide();
		}
	  });
	  
	  $(".cancelsentrequest").click(function(){
		
		var memberid = "<?php echo $memberid; ?>";
		 
		var r=confirm("Are you sure ?")
		if (r==true){
			$("#connection-options").hide();
  			$(".edit-err-notify").html("<font style=\"color:#f7d8ba\">Processing...</font>");
                 $.get('memberpage/cancelSentRequest',{
					   'memberid':memberid			   

                 }, function(o) {  $(".edit-err-notify").html("<font style=\"color:#f7d8ba\">Request Cancelled</font>"); 
                           setTimeout(function(){ location.reload();}, 2000);
                 }, 'json');
				 
  		}
		 
	 });
	 
	 $(".cancelreceivedrequest").click(function(){
		
		var memberid = "<?php echo $memberid; ?>";
		 
		var r=confirm("Are you sure ?")
		if (r==true){
			$("#connection-options").hide();
  			$(".edit-err-notify").html("<font style=\"color:#f7d8ba\">Processing...</font>");
                 $.get('memberpage/cancelReceivedRequest',{
					   'memberid':memberid			   

                 }, function(o) {  $(".edit-err-notify").html("<font style=\"color:#f7d8ba\">Request Cancelled</font>"); 
                           setTimeout(function(){ location.reload();}, 2000);
                 }, 'json');
				 
  		}
		 
	 });
	 
	 $(".acceptreceivedrequest").click(function(){
		
		var memberid = "<?php echo $memberid; ?>";
		 
		var r=confirm("Are you sure ?")
		if (r==true){
			$("#connection-options").hide();
  			$(".edit-err-notify").html("<font style=\"color:#f7d8ba\">Processing...</font>");
                 $.get('memberpage/acceptReceivedRequest',{
					   'memberid':memberid			   

                 }, function(o) {  $(".edit-err-notify").html("<font style=\"color:#f7d8ba\">Request Accepted</font>"); 
                           setTimeout(function(){ location.reload();}, 2000);
                 }, 'json');
				 
  		}
		 
	 });
	 
	 $(".removeconnection").click(function(){
		
		var memberid = "<?php echo $memberid; ?>";
		 
		var r=confirm("Are you sure ?")
		if (r==true){
			$("#connection-options").hide();
  			$(".edit-err-notify").html("<font style=\"color:#f7d8ba\">Processing...</font>");
                 $.get('memberpage/removeConnection',{
					   'memberid':memberid			   

                 }, function(o) {  $(".edit-err-notify").html("<font style=\"color:#f7d8ba\">Connection Removed</font>"); 
                           setTimeout(function(){ location.reload();}, 2000);
                 }, 'json');
				 
  		}
		 
	 });
	 
	 $(".sendmessage").click(function(){
		
		var memberid = "<?php echo $memberid; ?>";
		 
		window.location.href = "<?php  echo base_url(); ?>composemessage";	
		 
	 });
	
});
</script>
	
	
<div id="profile-left">

	<img class="proimg" src="<?php echo base_url();?>docs/profile/<?php echo $membername['profileimg']; ?>" width="140" height="160" />
    
    <ul>
    
    	<a href="javascript:history.go(-1)"><li>Back</li></a>
    	
    </ul>  

</div>

<div id="profile-right">

	<h1>Dr. <?php echo $membername['name']; ?></h1> 
    
    <div class="right-options">
    
      	<?php if($login_memberid !="" && $login_memberid != $memberid && $connectionstatus==""){ echo '<span id="connection-request">Request Connection</span><br /><p style="margin:15px 0 0; text-align:right; color:#fff;" class="edit-err-notify"></p>'; } ?>    	
        
        <?php if($login_memberid !="" && $login_memberid != $memberid && $connectionstatus!=""){ echo '<span id="connection-status">'.$connectionstatus.'</span><br /><p style="margin:15px 0 0; text-align:right; color:#fff;" class="edit-err-notify"></p>'; } ?>    	
        
        <ul id="connection-options" style="margin:3px 0 0; display:none;">
        
        	<?php if($connectionstatus=="Connected"){ echo '<li class="sendmessage" style="margin:0; line-height:16px;">Send Message</li><li class="removeconnection" style="margin:0; line-height:16px;">Remove</li>'; } ?>
            
            <?php if($connectionstatus=="Request Received"){ echo '<li class="acceptreceivedrequest" style="margin:0; line-height:16px;">Accept</li><li class="cancelreceivedrequest" style="margin:0; line-height:16px;">Cancel</li>'; } ?>
            
            <?php if($connectionstatus=="Request Sent"){ echo '<li class="cancelsentrequest" style="margin:0; line-height:16px;">Cancel</li>'; } ?>           	
        	
        </ul>
    
    </div>      
    
    <div class="clear"></div>

	<div id="profile-titles">
    
    	<h2>Contact Details</h2>
    
    </div>
    
    <div id="profile-content">
    
    	<p><span>Mobile</span><?php if($memberprofile['mobile']!=""){ echo $memberprofile['mobile'];}else{ echo "-"; } ?></p>
        
        <p><span>Landline</span><?php if($memberprofile['phone']!=""){ echo $memberprofile['phone'];}else{ echo "-"; } ?></p>
   
   		<p><span>Email</span><?php if($memberprofile['email']!=""){ echo $memberprofile['email'];}else{ echo "-"; } ?></p>
    
    </div>
    
    <div style="clear:both; height:30px;"></div>
    
    <div id="profile-titles">
    
    	<h2>Personal Details</h2>
    
    </div>
    
    <div id="profile-content">
    
    	<p><span>Gender</span><?php if($memberprofile['gender']!=""){ echo $memberprofile['gender'];}else{ echo "-"; } ?></p>
   
   		<p><span>DOB</span><?php if($memberprofile['dob']!=""){ echo $memberprofile['dob'];}else{ echo "-"; } ?></p>
        
        <p><span>Residential Address</span><?php if($memberprofile['address']!=""){ echo $memberprofile['address'];}else{ echo "-"; } ?></p>
        
        <p><span>Communication Address</span><?php if($memberprofile['contactaddress']!=""){ echo $memberprofile['contactaddress'];}else{ echo "-"; } ?></p>
        
        <p><span>State</span><?php if($memberprofile['contactstate']!=""){ echo $memberprofile['contactstate'];}else{ echo "-"; } ?></p>
        
        <p><span>Pincode</span><?php if($memberprofile['contactpin']!="0"){ echo $memberprofile['contactpin'];}else{ echo "-"; } ?></p>
    
    </div>
    
    <div style="clear:both; height:30px;"></div>
    
    <div id="profile-titles">
    
    	<h2>Official Details</h2>
    
    </div>
    
    <div id="profile-content">
    
    	<p><span>Qualification</span><?php if($memberprofile['qualification']!=""){ echo $memberprofile['qualification'];}else{ echo "-"; } ?></p>
   
   		<p><span>College</span><?php if($memberprofile['college']!=""){ echo $memberprofile['college'];}else{ echo "-"; } ?></p>
        
        <p><span>Designation</span><?php if($memberprofile['designation']!=""){ echo $memberprofile['designation'];}else{ echo "-"; } ?></p>
        
        <p><span>Clinic Address</span><?php if($memberprofile['clinicaddress']!=""){ echo $memberprofile['clinicaddress'];}else{ echo "-"; } ?></p>
        
        <p><span>Clinic Phone</span><?php if($memberprofile['clinicphone']!=""){ echo $memberprofile['clinicphone'];}else{ echo "-"; } ?></p>
    
    </div> 
    
    <div style="clear:both; height:30px;"></div>
    
    <div id="profile-titles">
    
    	<h2>About Me</h2>
    
    </div>
    
    <div id="profile-content">
    
    	<p><?php if($memberprofile['about']!=""){ echo $memberprofile['about'];}else{ echo "-"; } ?></p>        
            
    </div>
    
    <div style="clear:both; height:30px;"></div>
    
    <div id="profile-titles">
    
    	<h2>Interests</h2>
    
    </div>
    
    <div id="profile-content">
    
    	<ul style="margin-top: 15px;">
        
        	<?php
				$count = count($memberprofile['interests']);
				if($memberprofile['interests'][0]!=""){
					for($i=0;$i<$count;$i++){
						echo '<li>'.$memberprofile['interests'][$i].'</li>';
					}
				}else{
					echo '<li style="list-style:none">-</li>';
				}
			
			?>
        	
        </ul>      
    
    </div>
    
    <div style="clear:both; height:30px;"></div>
   	

</div>
   
   
   
  
 
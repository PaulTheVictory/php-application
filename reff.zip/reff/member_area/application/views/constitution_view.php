<style>

	#content-inner ul li{margin: 10px;}
	
</style>
  
<h1>BYE-LAWS OF CONSERVATIVE DENTISTRY AND ENDODONTICS ASSOCIATION OF TAMILNADU</h1> 
                                   
 
 <h2 style="text-align: center">PART I</h2>
<h2  style="text-align: center">MEMORANDUM OF ASSOCIATION
OF</h2>
<h2 style="text-align: center">CONSERVATIVE DENTISTRY AND ENDODONTICS ASSOCIATION OF TAMILNADU</h2>

<h2>1.NAME OF THE SOCIETY :</h2>
<p>The society shall be named CONSERVATIVE DENTISTRY AND ENDODONTICS ASSOCIATION OF TAMILNADU ( herein after referred as the “ the society”).</p>
<h2>2.REGISTERED OFFICE OF THE SOCIETY:</h2>
<p>Registered office of the society shall be situated in the state of Tamil Nadu and the address is as hereunder :-</p>
      <p><strong>ADDRESS:</strong> e4 Dental Care, No 13, Bakthavatchalam nagar 5th   Street Extension, Adyar, Chennai – 600 020</p>
<p><strong>3.DATE OF FORMATION :</strong> 2nd OCTOBER 2013</p>
<h2>4.OBJECTS OF THE SOCIETY :</h2>
<p>a) To promote and advance dental and allied sciences in the branch of Conservative Dentistry and Endodontics to pursue the improvement of dental health and dental education.</p>
<p>b) To maintain the honor and dignity and to uphold  the interests of practioners and academicians of the conservative and Endodontics branch of dentistry and to promote co-operation amongst the members thereof. </p>



<h2 style="text-align: center">PART II</h2>
<h2 style="text-align: center">BYE-LAWS OF CONSERVATIVE DENTISTRY AND ENDODONTICS ASSOCIATION OF   TAMILNADU</h2>
<h2>1 .Name of the Society </h2>
<p>The Society shall be named CONSERVATIVE DENTISTRY AND ENDODONTICS ASSOCIATION OF TAMIL NADU (hereinafter referred to as the "the Society"). </p>
<h2>2. Registered Office of the Society </h2>
<p>Registered Office of the Society shall be situated in the State of Tamil Nadu and the present address is as hereunder :-</p>
<p><strong>ADDRESS</strong> : :e4 Dental Care, No 13, Bakthavatchalam nagar 5th   Street Extension, Adyar, Chennai – 600 020. </p>
<h2>3. Date of Formation :     2nd   OCTOBER 2013.</h2> 
<p><strong>4.</strong> The Society is within the jurisdiction of the Registrar of Societies, Chennai Central </p>
<p><strong>5.</strong> The business hours of the society shall be between 10 AM to 6 PM, on all working days except Sundays and Government Holidays. </p>
<h2>6. Objects of the Society </h2>
<p>a) To promote and advance dental and allied sciences in the branch of Conservative Dentistry and Endodontics to pursue the improvement of dental health and dental education.</p>
<p>b) To maintain the honor and dignity and to uphold  the interests of practioners and academicians of the conservative and Endodontics branch of dentistry and to promote co-operation amongst the members thereof. </p>

<h2>7. Methods: </h2>
<h2>For the attainment and furtherance of these objects, the Society may :-</h2>
<ul>
<li> Hold periodical meetings and conference of the members of the Society and the dental profession in general, </li>
<li>Arrange from time to time congresses, conferences,     lectures, discussions and demonstrations on any aspect of the dental and allied sciences. </li>
<li>Publish and circulate a journal or bulletins which shall be the official organ of the Society of a character specially adopted to the needs of the dental profession of India which shall undertake publicity and propaganda work of the Society through its columns and publish other literature in accordance with the objects of the Society.</li> 
<li>Maintain a Library and a Society Office. </li>
<li>Publish from time to time transactions and other papers embodying dental researches conducted by the members or under the auspices of the Society. </li>
<li>Encourage research in the field of Conservative dentistry and Endodontics branch of Dental sciences with grants out of the funds of the Society, by the establishment of scholarships, prizes or rewards, and in such other manner as may from time to time , determined upon by the Society. </li>
<li>Conduct educational campaign among the people in the matter of dental health and sanitation by cooperating whenever necessary with different public bodies working with same object. </li>
<li>Organize dental camps for providing medical relief during epidemics and in times of emergency. </li>
<li>Consider and express its views on all questions and the laws of India or governing body of dentistry or proposed legislation affecting dental health, the dental profession and dental education, and initiate or watch over or take such steps and adopt such measures from time to time regarding the same as may be deemed expedient or necessary. </li>
<li>Purchase, take lease of or otherwise acquire; hold manage,. let, sell, exchange, mortgage or otherwise dispose of movable or immovable property of every description and all rights or privileges necessary or convenient for the purpose of the Society and in particular any land, building, furniture, household or other effects, utensils, books, newspapers, periodicals, instruments, fitting, appliances, apparatus, conveyances and accommodation and when deemed necessary or desirable in the interest of the Society, sell, let, hire out, mortgage, transfer or otherwise dispose of the same. All property movable, immovable or of any kind shall vest in the General Body of the Society. </li>

<li>Erect, maintain, improve or alter and keep in repair any building for the purpose of the Society. </li>
<li>Borrow or raise money, for the Society in such manner as the Society may think fit and collect subscriptions and donations for the purpose of the Society. </li>
<li>To act as Treasurer and distributors of any benevolent fund or funds which may be contributed by members or others for assisting necessitous members and widows and children or other dependants, kindred of deceased members and to take any contribution out of the surplus assets or income of the Society from time to time to any such benevolent fund or funds, if necessary. 
Invest any money of the Society not immediately required, for any of its objects in such manner as may from time to time be determined by the Society.
Assist, subscribe to, or cooperate or affiliate or be affiliated to, any other public body whether incorporated, registered or not, and having altogether or impart objects similar to those of the Society. 
Do all such other things as are cognate to the objects of the Society or are incidental or conducive to the attainment of the above objects. </li></ul>

<p><strong>8.</strong> Any alteration, addition or deletion or amendment to any clause of the memorandum or Bye- Laws of the Society can be done only in GENERAL BODY MEETING convened by the Hon. Secretary of the Association, President and at least 1/3 of EC members along with founder members and a simple majority of life members present and if necessary voting to take place to pass the amendments.</p>
 
<h2>9. Membership</h2> 
<p>a) Any person possessing dental qualifications in the branch of Conservative Dentistry and Endodontics and as defined in the Indian Dentists Act, 1948 and duly registered under the Dental Council of India and domicile of TAMILNADU will be eligible for membership. </p>
<p>b) Application for membership of the Society shall be made in writing to the Secretary of the Society in the form prescribed by the Society. </p>
<p>c) Life membership fees of Rs.2000 (Rupees Two Thousand Only) shall be paid at the time of admission into the society and the membership fee can be raised /increased after discussion in the  annual AGM and approved by the members as and when required but can be done so only once in a  financial year.</p>



<h2>10. Termination of Membership </h2>
<h2>Membership of the Society of a member may be terminated in any of the following ways:-</h2>
<p>a) If he ceases to hold qualification as provided in Clause No.9, of part II (Bye Laws) </p>
<p>b) On erasure of his name from any of the dental register, due to misconduct and as punishment (except when his name is removed for non-payment of renewal registration fee) </p>
<p>c) He being found guilty by a Court of Justice for any offence which involves moral turpitude. </p>
<p>d) By default of receipt of payment of subscription and is in arrear for more than six months from the date subscription became payable. </p>
<p>e) If he submits his resignation by giving 30 days notice in writing to the President and has paid all the claims of the Society against him. 
<p>f) In the event of becoming insane. </p>
<p>g) By death. </p>
<h2>11. Reinstatement </h2>
    <p>A member whose name has thus been removed under Articles No. 2 (a to d) may be readmitted on  the expiry of one year or thereafter provided his application for reenrollment is supported by five members of the Society testifying to his good conduct during the intervening period. He must also submit a written. apology acceptable to the Executive Committee and also to the General Body. </p>
<p><strong>12.</strong> Any one, ceasing to be a member of the Society, shall not, nor shall his representative have any claim upon, or interest in the assets of the Society excepting in so far as he may have made any advances towards the funds of the Society. But nothing in this clause shall prevent the Society from realizing any dues from a member at the time of his ceasing to be the member, or from his representatives and estate. </p>
<p><strong>13.</strong> The Accounting year and the Financial Year of the Society shall be from    1st of April to 31st March of the succeeding year.</p>
<p><strong>14.</strong> The income and the property of the Society whomsoever derived, shall be applied solely towards the promotion of the objects of the Society as set forth in the memorandum and bye laws of the Society and no portion thereof shall be paid or transferred, directly or indirectly by way of dividend, bonus or otherwise whatsoever by way of profit to the members of the Society, provided that nothing herein contained shall prevent the payment of remuneration in good faith to any officer or servant of the Society or to pay any member of the Society or other persons in return for any services actually rendered to the Society nor prevent the payment of interest on moneys borrowed from any members or other persons. 
<p><strong>15.</strong> All money of the Society shall be deposited with a bank/banks approved by Official body of the Society. The accounts shall be maintained in the name of the Society and to be jointly operated by the Secretary and Treasurer.  </p>
<p><strong>16.</strong> The books of accounts shall be kept at Registered Office of the Society. They shall be properly maintained. Any member of the Society can inquire about any aspect of finances in writing. It shall be binding on the Executive Committee/Treasurer/Hon. Secretary to reply the member in writing within one month of the receipt of his letter. </p>
<p><strong>17.</strong> The Accounts of the Society shall be audited annually by a Chartered Accountant appointed in the General Body meeting of the society. </p>
<p><strong>18.</strong> Annual General Body meeting shall be held once in every year, before 30th December. </p>
<p><strong>19.</strong> Every member of the society present in person shall have one vote, on every resolution placed before it. A member entitled to present and vote in meeting may appoint a proxy to attend and vote at the meeting. </p>
<p><strong>20.</strong> Notice of General Body meeting of the society shall be given 'to the members at least ten days before the day appointed for such meeting by Secretary by post or through electronic modes/media. In case of any emergency or extra ordinary AGM to be convened a notice of 24 hrs to 12 hrs notice will be sufficient and can be issued only by the Hon. Secretary to members through any reachable media. The notice of an Extra Ordinary General Meeting shall contain explicitly the nature of business to be transacted at the meeting.</p>
<p><strong>21.</strong> The quorum of the general body meeting shall be 1/3rd of the registered members </p>
<p><strong>22.</strong> The General Body will discuss the following matters:-</p>
<p>A. Election of Members of Executive Committee and other posts.</p>
<p>B. Adoption of Annual Report and Annual Accounts of the society </p>
<p>C. Appointment of auditor and fix his/her remuneration. </p>
<p>D. Any other matter of which prior notice is given to members as contained in Bye-Laws. </p>

<p><strong>23.</strong> The General function, management, direction of the policy and affairs of the Society shall be vested in the Executive Committee of the Society. The Executive Committee shall be responsible for the day to day management and shall function under the supervision and control of the President and Secretary of the Society. </p>

<p><strong>24.</strong> The Executive Committee shall consist of 15 members who shall be elected at the Annual General Body Meeting. The tenure of Executive Committee shall be for a period of  two years and shall expire at the conclusion of his/her term after two years. The nominations can be given by writing/e-mail/uploading in the association’s official website to the secretary after call for letter is circulated by the head office. Members who have completed three years of life membership in the association are only eligible to contest for EC post and shall be elected through voting if more nominations than the required is received. The member can contest only three times for the post. However they can contest for the post of /Vice President/ President /Hon. Secretary only after holding the post of EC once.</p>

<p><strong>25.</strong> Resignation of a member from Executive Committee shall be tendered to the Society and shall not take effect until President of the General Body accepted it on behalf of the Society. Any vacancy that may arise in the Executive Committee may be filled in by the President and the Secretary.  </p>

<p><strong>26.</strong> The Executive Committee if required shall meet once in a month at the Registered Office of the Society or such other place as may be approved by the General Body of the Society. The Committee shall also meet at the call of the President at least once in a year. </p>

<p><strong>27.</strong> Notice of the Executive Committee Meeting shall be served to the members 5 to 7 days notice and emergency meeting can be called with 24 /12 hours notice. </p>

<p><strong>28.</strong> The quorum of the Executive Committee shall be    1/3 of the members of the Executive Committee.</p>

<h2>Duties of office bearers </h2>
<h2>29.President:</h2>
<p>The President shall preside over Executive Committee and General Body meeting. In this or her absence the Vice-President shall preside and in absence of the both any members of nominated by the General Body shall preside. The President will be elected in the Annual General Body Meeting and shall have three years of term in office. The President elect shall not contest after two terms in office.</p>
<p><strong>30. Vice-President</strong>- The Vice-President shall carry out all the duties and function of the President in his/her absence shall be elected in the Annual General Body Meeting and will be in office for three years. The Vice President elect shall not contest after two terms in office.</p>
<p><strong>31. Secretary</strong>-The Secretary shall be responsible to the Executive Committee for proper discharge and execution of its orders and exercise supervision over all the affairs of the Society and shall be the custodian of the records. He/She shall prepare detailed report regarding the activities of the Society including the Income and expenditure and appraise the position to the General Body. He/She shall sign the cash book daily and also the receipts granted by the Treasurer towards collection and he/she authorize to file any document to the concerned Registrar of Society. The secretary shall be elected by the members at the General Body Meeting and assume office for three years. The elected Secretary shall assume office only twice in his/her life time in this association and shall not get himself/herself nominated or contest for the third term in office. The secretary can nominate one member as joint secretary to help/carry out his/her duties along with him/her or during his/her absence. </p>
<p><strong>32. Treasurer</strong>- <p>He /she shall be responsible for collection of funds as fixed by the General body with collection of funds as the same in society Account within 24hours. The funds so collected shall be reflected in the cash book in same day and got the same signed from the Secretary at the closing of the day. The treasurer will assume office for three years and will be elected by the members at the Annual General Body Meeting. The Treasurer will have rights to attend the EC meeting.</p>
<p><strong>33.Editor</strong>- The Editor shall Publish and circulate a journal or bulletins which shall be the official organ of the Society of a character specially adopted to the needs of the conservative and endodontics branch of dentistry which shall undertake publicity and propaganda work of the Society through its columns and publish other literature in accordance with the objects of the Society. The editor shall be elected by the Annual general body meeting and shall serve three years in office. The editor can nominated two members from the society as associate editors to help him/her to carry out the work related to publishing of the journal. The Editor and Associate Editors can attend the Executive Committee meeting.</p>
<p><strong>34. General body and Founder members </strong> The General body means the total members of the Society. It shall be the sole authority of the Society. The Founder members are the members who constituted the formation of this association and shall continue to be in the EC apart from the elected fifteen members.</p>
<p><strong>35.Vote</strong> Every members shall have right to vote and the President shall have power to excise his casting vote. There shall be an election committee formed by the President which may constitute about 5 to 6 members who shall receive, scrutinize the nominations for various posts and if necessary shall recommend for the elections if more nominations are received than required for particular post. The President shall order for the elections in recommendation of the committee. The process of election either by ballot or electronic will be subject to feasibility and final call shall be taken by the Hon. Secretary in discussion with the President and EC members.  </p>
<p><strong>36.</strong>The Secretary of the Society is authorized to bring or defend or cause to be brought or defended any action or other legal proceedings touching or concerning any property, right or claim of the  society and may sue or be sued in respect of any such property, right or claim. </p>
<p> <strong>37. Dissolution:-</strong> Upon dissolution of the Society its assets will be handed over to a similar type of registrar Society or to Government after satisfaction of all its debts and liabilities and shall not be distributed or paid among the members. Provided that no society shall be dissolved unless half of its member shall have expressed a wish for such dissolution by their votes delivered in person or by proxy at a General Body meeting convened for the purpose. Provided that the Society registered under this Act shall not be dissolved without the consent of the Government of the State of registration where the Government is a member contributor or otherwise interested. </p>

<p><strong>38.</strong> The Society formed is irrevocable.</p>.
<p><strong>39.</strong> The benefits of the Society shall be open to all irrespective of the caste creed or religion.</p>
<p><strong>40.</strong> For matters which have not been specifically provided for therein above, the provisions of the Tamil Nadu Societies Registration Act, 1975 and the rules made there under shall apply. </p>
                                                        
                                                         ******


<!--<h2><u>1. Name of the Society </u></h2>

<p>The Society shall be named <strong>CONSERVATIVE DENTISTRY AND ENDODONTICS ASSOCIATION OF TAMIL NADU</strong> (hereinafter referred to as the "the Society"). </p>

<h2><u>2. Registered Office of the Society </u></h2>

<p>Registered Office of the Society shall be situated in the State of Tamil Nadu and the present address is as hereunder :-</p>

<p><strong>ADDRESS</strong> : e4 Dental Care, No 13, Bakthavatchalam nagar 5th   Street Extension, Adyar, Chennai – 600 020.</p>
 
<h2><u>3. Date of Formation :</u> <span style="font-size: 15px;font-weight: normal;">2nd   OCTOBER 2013. </span></h2>

<p>4. The Society is within the jurisdiction of the Registrar of Societies, Chennai Central </p>

<p>5. The business hours of the society shall be between 10 AM to 6 PM, on all working days except Sundays and Government Holidays. </p>

<h2><u>6. Objects of the Society </u></h2>

<ul class="alpha">
	<li>To promote and advance dental and allied sciences in the branch of Conservative Dentistry and Endodontics to pursue the improvement of dental health and dental education.</li>

	<li>To maintain the honor and dignity and to uphold  the interests of practioners and academicians of the conservative and Endodontics branch of dentistry and to promote co-operation amongst the members thereof.</li> 
</ul>

<h2><u>7. Methods: </u></h2>

<p>For the attainment and furtherance of these objects, the Society may :-</p>

<ul class="alpha">

	<li>Hold periodical meetings and conference of the members of the Society and the dental profession in general.</li>
	
	<li>Arrange from time to time congresses, conferences, 	lectures, discussions and demonstrations on any aspect of the dental and allied sciences.</li> 

	<li>Publish and circulate a journal or bulletins which shall be the official organ of the Society of a character specially adopted to the needs of the dental profession of India which shall undertake publicity and propaganda work of the Society through its columns and publish other literature in accordance with the objects of the Society. </li>

	<li>Maintain a Library and a Society Office. </li>

	<li>Publish from time to time transactions and other papers embodying dental researches conducted by the members or under the auspices of the Society. </li>

	<li>Encourage research in the field of Conservative dentistry and Endodontics branch of Dental sciences with grants out of the funds of the Society, by the establishment of scholarships, prizes or rewards, and in such other manner as may from time to time , determined upon by the Society. </li>

	<li>Conduct educational campaign among the people in the matter of dental health and sanitation by cooperating whenever necessary with different public bodies working with same object. </li>

	<li>Organize dental camps for providing medical relief during epidemics and in times of emergency. </li>

	<li>Consider and express its views on all questions and the laws of India or governing body of dentistry or proposed legislation affecting dental health, the dental profession and dental education, and initiate or watch over or take such steps and adopt such measures from time to time regarding the same as may be deemed expedient or necessary. </li>

	<li>Purchase, take lease of or otherwise acquire; hold manage,. let, sell, exchange, mortgage or otherwise dispose of movable or immovable property of every description and all rights or privileges necessary or convenient for the purpose of the Society and in particular any land, building, furniture, household or other effects, utensils, books, newspapers, periodicals, instruments, fitting, appliances, apparatus, conveyances and accommodation and when deemed necessary or desirable in the interest of the Society, sell, let, hire out, mortgage, transfer or otherwise dispose of the same. All property movable, immovable or of any kind shall vest in the General Body of the Society. </li>

	<li>Erect, maintain, improve or alter and keep in repair any building for the purpose of the Society. </li>

	<li>Borrow or raise money, for the Society in such manner as the Society may think fit and collect subscriptions and donations for the purpose of the Society. </li>

	<li>To act as Treasurer and distributors of any benevolent fund or funds which may be contributed by members or others for assisting necessitous members and widows and children or other dependants, kindred of deceased members and to take any contribution out of the surplus assets or income of the Society from time to time to any such benevolent fund or funds, if necessary. </li>

	<li>Invest any money of the Society not immediately required, for any of its objects in such manner as may from time to time be determined by the Society.</li>

	<li>Assist, subscribe to, or cooperate or affiliate or be affiliated to, any other public body whether incorporated, registered or not, and having altogether or impart objects similar to those of the Society. </li>

	<li>Do all such other things as are cognate to the objects of the Society or are incidental or conducive to the attainment of the above objects.</li>

</ul> 
                              
<p>8. Any alteration, addition or deletion or amendment to any clause of the memorandum or Bye- Laws of the Society can be done only in GENERAL BODY MEETING convened by the Hon. Secretary of the Association, President and at least 1/3 of EC members along with founder members and a simple majority of life members present and if necessary voting to take place to pass the amendments.</p>
 
<h2><u>9. Membership </u></h2>

<ul class="alpha">

	<li>Any person possessing dental qualifications in the branch of Conservative Dentistry and Endodontics and as defined in the Indian Dentists Act, 1948 and duly registered under the Dental Council of India and domicile of TAMILNADU will be eligible for membership.</li> 

	<li>Application for membership of the Society shall be made in writing to the Secretary of the Society in the form prescribed by the Society. </li>

	<li>Life membership fees of Rs.2000 (Rupees Two Thousand Only) shall be paid at the time of admission into the society and the membership fee can be raised /increased after discussion in the  annual AGM and approved by the members as and when required but can be done so only once in a  financial year.</li>

</ul>

<h2><u>10. Termination of Membership</u></h2> 

<p>Membership of the Society of a member may be terminated in any of the following ways:-</p>

<ul class="alpha">

	<li>If he ceases to hold qualification as provided in Clause No.9, of part II (Bye Laws) </li>

	<li>On erasure of his name from any of the dental register, due to misconduct and as punishment (except when his name is removed for non-payment of renewal registration fee)</li> 

	<li>He being found guilty by a Court of Justice for any offence which involves moral turpitude. </li>

	<li>By default of receipt of payment of subscription and is in arrear for more than six months from the date subscription became payable. </li>

	<li>If he submits his resignation by giving 30 days notice in writing to the President and has paid all the claims of the Society against him. </li>

	<li>In the event of becoming insane.</li>
 
	<li>By death.</li>
	
</ul>
 
	<h2><u>11. Reinstatement </u></h2>
	
	<p>A member whose name has thus been removed under Articles No. 2 (a to d) may be readmitted on  the expiry of one year or thereafter provided his application for reenrollment is supported by five members of the Society testifying to his good conduct during the intervening period. He must also submit a written. apology acceptable to the Executive Committee and also to the General Body. </p>
	
	<p>12. Any one, ceasing to be a member of the Society, shall not, nor shall his representative have any claim upon, or interest in the assets of the Society excepting in so far as he may have made any advances towards the funds of the Society. But nothing in this clause shall prevent the Society from realizing any dues from a member at the time of his ceasing to be the member, or from his representatives and estate. </p>

	<p>13. The Accounting year and the Financial Year of the Society shall be from	1st of April to 31st March of the succeeding year.</p>

	<p>14. The income and the property of the Society whomsoever derived, shall be applied solely towards the promotion of the objects of the Society as set forth in the memorandum and bye laws of the Society and no portion thereof shall be paid or transferred, directly or indirectly by way of dividend, bonus or otherwise whatsoever by way of profit to the members of the Society, provided that nothing herein contained shall prevent the payment of remuneration in good faith to any officer or servant of the Society or to pay any member of the Society or other persons in return for any services actually rendered to the Society nor prevent the payment of interest on moneys borrowed from any members or other persons. </p>

	<p>15. All money of the Society shall be deposited with a bank/banks approved by Official body of the Society. The accounts shall be maintained in the name of the Society and to be jointly operated by the Secretary and Treasurer.  </p>

	<p>16. The books of accounts shall be kept at Registered Office of the Society. They shall be properly maintained. Any member of the Society can inquire about any aspect of finances in writing. It shall be binding on the Executive Committee/Treasurer/Hon. Secretary to reply the member in writing within one month of the receipt of his letter. </p>

	<p>17. The Accounts of the Society shall be audited annually by a Chartered Accountant appointed in the General Body meeting of the society. </p>

	<p>18. Annual General Body meeting shall be held once in every year, before 30th December.</p>
 
	<p>19. Every member of the society present in person shall have one vote, on every resolution placed before it. A member entitled to present and vote in meeting may appoint a proxy to attend and vote at the meeting. </p>

	<p>20. Notice of General Body meeting of the society shall be given 'to the members at least ten days before the day appointed for such meeting by Secretary by post or through electronic modes/media. In case of any emergency or extra ordinary AGM to be convened a notice of 24 hrs to 12 hrs notice will be sufficient and can be issued only by the Hon. Secretary to members through any reachable media. The notice of an Extra Ordinary General Meeting shall contain explicitly the nature of business to be transacted at the meeting.</p>

	<p>21. The quorum of the general body meeting shall be 1/3rd of the registered members </p>

	<p>22. The General Body will discuss the following matters:-</p>
	
<ul class="ualpha">
	<li>Election of Members of Executive Committee and other posts.</li>

	<li>Adoption of Annual Report and Annual Accounts of the society </li>

	<li>Appointment of auditor and fix his/her remuneration. </li>

	<li>Any other matter of which prior notice is given to members as contained in Bye-Laws. </li>
</ul>

	<p>23. The General function, management, direction of the policy and affairs of the Society shall be vested in the Executive Committee of the Society. The Executive Committee shall be responsible for the day to day management and shall function under the supervision and control of the President and Secretary of the Society. </p>

	<p>24. The Executive Committee shall consist of 15 members who shall be elected at the Annual General Body Meeting. The tenure of Executive Committee shall be for a period of  two years and shall expire at the conclusion of his/her term after two years. The nominations can be given by writing/e-mail/uploading in the association’s official website to the secretary after call for letter is circulated by the head office. Executive members shall be elected through voting if more nominations than the required is received  and the member can contest only three times for the post. However they can contest for the post of /Vice President/ President /Hon. Secretary only after holding the post of EC twice.</p>

	<p> 25. Resignation of a member from Executive Committee shall be tendered to the Society and shall not take effect until President of the General Body accepted it on behalf of the Society. Any vacancy that may arise in the Executive Committee may be filled in by the President and the Secretary.  </p>

	<p>26. The Executive Committee if required shall meet once in a month at the Registered Office of the Society or such other place as may be approved by the General Body of the Society. The Committee shall also meet at the call of the President at least once in a year. </p>

	<p>27. Notice of the Executive Committee Meeting shall be served to the members 5 to 7 days notice and emergency meeting can be called with 24 /12 hours notice. </p>

<p>28. The quorum of the Executive Committee shall be	1/3 of the members of the Executive Committee.</p>

<h2><u>Duties of office bearers- </u></h2>

<h2><u>29.President:</u></h2>

<p>The President shall preside over Executive Committee and General Body meeting. In this or her absence the Vice-President shall preside and in absence of the both any members of nominated by the General Body shall preside. The President will be elected in the Annual General Body Meeting and shall have three years of term in office. The President elect shall not contest after two terms in office.</p>

<p>30. <strong><u>Vice-President-</u></strong> The Vice-President shall carry out all the duties and function of the President in his/her absence shall be elected in the Annual General Body Meeting and will be in office for three years. The Vice President elect shall not contest after two terms in office.</p>

<p>31.  <strong><u>Secretary-</u></strong> The Secretary shall be responsible to the Executive Committee for proper discharge and execution of its orders and exercise supervision over all the affairs of the Society and shall be the custodian of the records. He/She shall prepare detailed report regarding the activities of the Society including the Income and expenditure and appraise the position to the General Body. He/She shall sign the cash book daily and also the receipts granted by the Treasurer towards collection and he/she authorize to file any document to the concerned Registrar of Society. The secretary shall be elected by the members at the General Body Meeting and assume office for three years. The elected Secretary shall assume office only twice in his/her life time in this association and shall not get himself/herself nominated or contest for the third term in office. The secretary can nominate one member as joint secretary to help/carry out his/her duties along with him/her or during his/her absence. </p>

<p>32.  <strong><u>Treasurer-</u></strong> He /she shall be responsible for collection of funds as fixed by the General body with collection of funds as the same in society Account within 24hours. The funds so collected shall be reflected in the cash book in same day and got the same signed from the Secretary at the closing of the day. The treasurer will assume office for three years and will be elected by the members at the Annual General Body Meeting. The Treasurer will have rights to attend the EC meeting.</p>

<p>33.  <strong><u>Editor-</u></strong> The Editor shall Publish and circulate a journal or bulletins which shall be the official organ of the Society of a character specially adopted to the needs of the conservative and endodontics branch of dentistry which shall undertake publicity and propaganda work of the Society through its columns and publish other literature in accordance with the objects of the Society. The editor shall be elected by the Annual general body meeting and shall serve three years in office. The editor can nominated two members from the society as associate editors to help him/her to carry out the work related to publishing of the journal. The Editor and Associate Editors can attend the Executive Committee meeting.</p>

<p>34.  <strong><u>General body and Founder members-</u></strong> The General body means the total members of the Society. It shall be the sole authority of the Society. The Founder members are the members who constituted the formation of this association and shall continue to be in the EC apart from the elected fifteen members.</p>

<p>35.  <strong><u>Vote-</u></strong> Every members shall have right to vote and the President shall have power to excise his casting vote. There shall be an election committee formed by the President which may constitute about 5 to 6 members who shall receive, scrutinize the nominations for various posts and if necessary shall recommend for the elections if more nominations are received than required for particular post. The President shall order for the elections in recommendation of the committee. The process of election either by ballot or electronic will be subject to feasibility and final call shall be taken by the Hon. Secretary in discussion with the President and EC members.  </p>

<p>36.The Secretary of the Society is authorized to bring or defend or cause to be brought or defended any action or other legal proceedings touching or concerning any property, right or claim of the  society and may sue or be sued in respect of any such property, right or claim. </p>

<p>37.  <strong><u>Dissolution:-</u></strong> Upon dissolution of the Society its assets will be handed over to a similar type of registrar Society or to Government after satisfaction of all its debts and liabilities and shall not be distributed or paid among the members. Provided that no society shall be dissolved unless half of its member shall have expressed a wish for such dissolution by their votes delivered in person or by proxy at a General Body meeting convened for the purpose. Provided that the Society registered under this Act shall not be dissolved without the consent of the Government of the State of registration where the Government is a member contributor or otherwise interested. </p>

<p>38.The Society formed is irrevocable. </p>

<p>39. The benefits of the Society shall be open to all irrespective of the caste creed or religion.</p>

<p>40. For matters which have not been specifically provided for therein above, the provisions of the Tamil Nadu Societies Registration Act, 1975 and the rules made there under shall apply. </p>
                                                        
                                                         ******-->


<script type="text/javascript">
$(document).ready(function(){	
	
	$(".moreinterest").click(function(){
		
		var parElement = $(this).prev();		
		var liElement = '<li style="list-style:none"><input class="update-text-box interest" value="" /><span2 class="delinterest">x</span2></li>';		
		parElement.append(liElement);
						
	});
	
	$(document).delegate('.delinterest','click',function(){
		var liElement = $(this).parent();
		liElement.remove();
	});
	
	$(".updatebio").click(function(){
		
		var aboutme = $(".aboutme").val();
        var interest = "";
		
		$(".interestlist").find('input').each(function(){
			if($(this).val()!="") {
        		interest += $(this).val()+"&|&";
     		}
		});
		
		var n= interest.lastIndexOf("&|&");
		interest = interest.slice(0,n);
		
		$(".edit-err-notify").html("<font style=\"color:#44f2f8\">Processing...</font>");
                 $.get('editbio/updateBio',{
                       'aboutme':aboutme,
                       'interest':interest				   

                 }, function(o) {  $(".edit-err-notify").html("<font style=\"color:#44f2f8\">Bio Updated</font>"); 
                           setTimeout(function(){ location.assign("bio");}, 2000);         
                 }, 'json');
				 
	});
	
	
	
});
</script>

<div id="profile-left">

	<img class="proimg" src="<?php echo base_url();?>docs/profile/<?php echo $membername['profileimg']; ?>" width="140" height="160" />
    
    <ul>
    
    	<a href="home"><li>Recent Activity</li></a>
        
        <a href="profile"><li>Profile</li></a>
        
        <a href="bio"><li>Bio</li></a>
        
        <a href="connectionlist"><li>Find a Connection</li></a>
        
        <a href="messageinbox"><li>Messages</li></a>
        
        <a href="communitylist"><li>Communities</li></a>
        
        <?php if($membername['role']=="STUDENT"){ ?><a href="upgrademembership"><li>Upgrade Membership</li></a><?php } ?>
    
    </ul>

</div>

<div id="profile-right">

	<h1>Dr. <?php echo $membername['name']; ?><br /><span style="font-size:12px">Membership ID: <?php echo $membername['userid']; ?></span></h1>
    
    <div class="right-options">
    
    	<button class="updatebio" id="editbut">Update</button><br />
        <p style="margin:15px 0 0; text-align:right; color:#fff;" class="edit-err-notify"></p>
    
    </div>
    
    <div class="clear"></div>

	<div id="profile-titles">
    
    	<h2>About Me</h2>
    
    </div>
    
    <div id="profile-content">
    
    	<textarea class="update-textarea aboutme"><?php if($memberbio['about']!=""){ echo $memberbio['about'];}else{ echo ""; } ?></textarea>      
            
    </div>
    
    <div style="clear:both; height:30px;"></div>
    
    <div id="profile-titles">
    
    	<h2>Interests</h2>
    
    </div>
    
    <div id="profile-content">
    
    	<ul class="interestlist" style="margin-top: 15px;">
        
        	<?php
				$count = count($memberbio['interests']);
				if($memberbio['interests'][0]!=""){
					for($i=0;$i<$count;$i++){
						
						if($i==0){
							echo '<li style="list-style:none"><input class="update-text-box interest" value="'.$memberbio['interests'][$i].'" /></li>';
						}else{
							echo '<li style="list-style:none"><input class="update-text-box interest" value="'.$memberbio['interests'][$i].'" /><span2 class="delinterest">x</span2></li>';
						}
						
					}
				}else{
					echo '<li style="list-style:none"><input class="update-text-box interest" value="" /></li>';
				}			
			?>
        	                        
        </ul>
        
        <button style="float:left; margin:-40px 0 0 285px" id="editbut" class="moreinterest">More</button>      
    
    </div>
    
    <div style="clear:both; height:30px;"></div>
    
      	

</div>
   
   
   
  
 
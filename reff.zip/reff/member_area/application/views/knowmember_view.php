<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>css/dataTables.css" />

<script type="text/javascript" src="<?php echo base_url();?>js/jquery.dataTables.js"></script>



<div id="profile-left">

	<img class="proimg" src="<?php echo $this->config->item('web_url');?>images/ap.jpg" />
    
    <ul>
    
    	<a href="javascript:history.go(-1)"><li>Back</li></a>

    </ul>

</div>


<div id="profile-right">

        

        <h1>Know Member List </h1>

       <div class="right-options">
       
        	<a href="login" id="editbut" style="color: #ffffff;" >Login</a>

	   </div>  

        <div class="clear"></div>

        

        <select id="mem_filter">

            <option value="">All Members</option>

            <option value="LIFE">Life</option>

            <option value="STUDENT">Student</option>

            <!--<option value="ASSOCIATE">Associate</option>-->

        </select>

        <div style="clear:both; height:40px;"></div>         

      

        <?php echo $this->table->generate();  ?> 

        

        <div style="clear:both; height:30px;"></div> 

    

    </div>

    

<style type="text/css">

    #memberstable_filter input {

        padding: 5px;

        border: 1px solid #ccc;

    }

</style>

<script type="text/javascript">

$(document).ready(function() {

	

        

        $("#mem_filter").change(function(){

            var result = $(this).val();

            oTable.dataTable().fnFilter(result);

        })

        

        var columnData = [

                    { "data": "userid" },

                    { "data": "name" },

					{ "data": "role" },

                  ];

         columnData.push( {data: "verifystatus","visible":false} );

         

       

        var oTable = $('#memberstable').dataTable({

                    "bProcessing": true,

                    "bServerSide": true,

					"aaSorting": [[0,'asc']],

                    "sPaginationType": "full_numbers",

                    "ajax": {

                    "url": 'knowmember/getMemberLists',

                    "type": "POST"

                     }, 

                     "oLanguage": {

                        "sProcessing": "<img src='<?php echo base_url(); ?>images/loader.gif'>"

                    },

                    'iDisplayLength': 25,

                    "columns": columnData,

                    "fnDrawCallback": function( oSettings ) {

                            

                    }

         }); 

		

});

</script>
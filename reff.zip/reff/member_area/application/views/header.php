<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1">

<title>CEAT</title>

<link rel="stylesheet" type="text/css" href="<?php echo $this->config->item('web_url');?>css/styles.css" />

<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>css/adminstyles.css" /> 

<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>css/chosen.css" /> 

<link rel="stylesheet" href="http://code.jquery.com/ui/1.10.4/themes/smoothness/jquery-ui.css">
 		
<link rel="stylesheet" href="<?php echo base_url();?>css/dataTables.css" />    
   
<script type="text/javascript" src="<?php echo base_url();?>js/jquery.min.js"></script>
        
<script src="http://code.jquery.com/ui/1.10.4/jquery-ui.js"></script>

<script src="<?php echo base_url();?>js/menu.js" type="text/javascript" charset="utf-8"></script>

<script src="<?php echo base_url();?>js/jquery.listnav-2.1.js" type="text/javascript" charset="utf-8"></script>

<script src="<?php echo base_url();?>js/chosen.jquery.js" type="text/javascript" charset="utf-8"></script>

<script type="text/javascript" src="<?php echo base_url();?>js/modernizr.custom.js"></script>

<script type="text/javascript" src="<?php echo base_url();?>js/modernizr.min.js"></script>
      
	  

<script> 
$(document).ready(function(){	
  	/*$('#memList').listnav();
  	$('#colList').listnav({
    	initLetter: 'all'
	});
  	$(".messageto").chosen();*/
});
</script>

<script>
    ddsmoothmenu.init({
	mainmenuid: "menu", //menu DIV id
	orientation: 'h', //Horizontal or vertical menu: Set to "h" or "v"
	classname: 'headermenu', //class added to menu's outer DIV
	method: 'toggle',
	contentsource: "markup" //"markup" or ["container_id", "path_to_menu_file"]
    }); 
</script>

<script>
  $(function() {
	$( ".datepicker" ).datepicker();  
    $( ".datepicker" ).datepicker("option", "dateFormat", "yy-mm-dd");
  });
</script>



</head>

<body id="inner">
	   	
    <div id="headertop">

	<div class="top-first">
    
    	<div class="wrap">
            
            <div class="top-right">
             <div class="top-social">
                     <a class="top-loc" href="<?php echo $this->config->item('web_url');?>contact.html" title="Contact Us">Contact Us</a>
                    <a class="top-support" href="<?php echo $this->config->item('web_url');?>faq.html" title="FAQ">FAQ</a>
                   <!-- <a class="top-faq" href="<?php //echo $this->config->item('web_url');?>join.html" title="Join/Renew Membership">Join/Renew Membership</a>
                    <a class="top-support" href="#" title="Dentist Directory">Dentist Directory</a>-->
                </div>
            	
            </div>
            
        </div>
    	
    </div>
    
    <div class="clear"></div>
    
    <div class="top-bottom">

	<div class="wrap">
    
    	<a href="<?php echo $this->config->item('web_url');?>" title="CEAT" class="logolink"><img class="logo" src="images/logo1.jpg" /></a>
        
        <div class="header-middle-right">
        	<?php
				if($this->session->userdata('logged_in') || $this->session->userdata('adlog_in') || $this->session->userdata('college_log_in') || $this->session->userdata('conflog_in')){
					echo '<a class="memberadmin" href="home/logout" title="Logout"><span>Logout</span></a>';
				}
				else{					
					echo '<a class="memberadmin" href="'.$this->config->item('web_url').'" title="Home"><span>Home</span></a>';
				}
                
               ?>
        </div>
        
        <div id="navigation">
            
           <div class="wrap">
                    
              <div id="menu" class="headermenu">

             <?php
            if($this->session->userdata('logged_in') || $this->session->userdata('adlog_in')){
				
				echo '<ul id="navmenu">
                
                	<li><a  href="home" title="My CEAT">My CEAT</a></li>
                                                            
                    <li><a href="#" title="Directory">Directory</a>
					<ul>
						<li><a href="memdirectory" title="Members">Members</a></li>
					</ul>
					</li>
            		
                    <li><a href="conferences" title="Conferences">Conferences</a></li>
                    
            		<li><a href="constitution" title="Constitution">Constitution</a></li>
                                                
            	</ul>';
				
			}else{
				echo '<ul id="navmenu"></ul>';
			}
			?>
   
                        
		</div>
        
       </div>
       
       </div>

 </div>
    
	</div>
     
   <div class="clear"></div>    
   
</div>
       
    <div id="content-inner">
 <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- Set up your viewport to make sure your theme shows up correctly on mobile devices -->
        <meta name="Revisit-After" content="7 Days">
        <!-- Useful for search engines -->
        <meta name="robots" content="index,follow">
        <!-- Useful for search engines -->

        <meta name="description" content="" />
        <title>Home | Cosmetic</title>
        <meta name="description" content="" />
        <link rel="shortcut icon" href="favicon.ico" />
        <!-- Link to your favicon -->

        <link rel="stylesheet" href="<?php echo base_url();?>css/styles.css" />
        <link rel="stylesheet" href="<?php echo base_url();?>css/styles-media.css" />
		<link rel="stylesheet" href="<?php echo base_url();?>css/dataTables.css" />
		<link rel="stylesheet" href="<?php echo base_url();?>css/menu.css" />
		
        <script type="text/javascript" src="<?php echo base_url();?>js/jquery.min.js"></script>
        <script type="text/javascript" src="<?php echo base_url();?>js/modernizr.min.js"></script>
        <script type="text/javascript" src="<?php echo base_url();?>js/jquery.ui.js"></script>
		<script src="<?php echo base_url();?>js/menu.js" type="text/javascript" charset="utf-8"></script>
        <script type="text/javascript" charset="utf-8">
			$(window).load(function() {
				$('.flexslider').flexslider();
			});
		</script><!--FlexSlider-->
		
		<script>
	ddsmoothmenu.init({
	mainmenuid: "navmenu", //menu DIV id
	orientation: 'h', //Horizontal or vertical menu: Set to "h" or "v"
	classname: 'headermenu', //class added to menu's outer DIV
	method: 'toggle',
	contentsource: "markup" //"markup" or ["container_id", "path_to_menu_file"]
	}); 
	</script>

		<script type="text/javascript" charset="utf-8">
       jQuery(document).ready(function($){
            //$('#navmenu #menu').slicknav();	
        });
        </script>
        
        </head>
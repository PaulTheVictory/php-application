
<link rel="stylesheet" type="text/css" href="../css/dataTables.css" />
<script src="js/jquery.dataTables.js?v=1.0" type="text/javascript"></script>
<script type="text/javascript">
$(document).ready(function(){	
		
	/*$(".memberlist").click(function(){
		
		var memid = $(this).attr("id");
        		
		window.location.href = "<?php  echo base_url(); ?>editmemberpage?id="+memid;		
		
	});*/
	
          var columnData = [
                    { "data": "acdiuserid" },
                    { "data": "name" },
                    { "data": "phone" },
                    { "data": "email" },
			  		{ "data": "paymentamount"},
                    { "data": "paymenttime" }                    
                  ];
         columnData.push( {data: "id","visible":false} );
        // columnData.push( {data: "memtype","visible":false} );
         
       
        var oTable = $('#memberstable').dataTable({
                    "bProcessing": true,
                    "bServerSide": true,
                    "sPaginationType": "full_numbers",
                    "ajax": {
                    "url": 'testregistrants/getMemberLists',
                    "type": "POST"
                     }, 
                     "oLanguage": {
                        "sProcessing": "<img src='<?php echo base_url(); ?>images/loader.gif'>"
                    },
                    'iDisplayLength': 25,
                    "columns": columnData,
                    "fnDrawCallback": function( oSettings ) {
                            
                    }
         }); 
         
         $("#mem_filter").change(function(){
            var result = $(this).val();
            oTable.dataTable().fnFilter(result);
        })
	
	
});
</script>
<style type="text/css">

    .sortable {
    border: 1px solid #ddd;
    border-collapse: collapse;
    color: #333;
    margin: 10px auto;
    width: 100%;
}
.dataTables_wrapper input[type="text"] {
    padding: 0;
}
.dataTables_wrapper select {
    padding: 0;
}
.sortable tr th {
    border-right: 1px solid #ddd;
    padding: 10px 0;
}
.sortable tr td {
    border-right: 1px solid #ddd;
    padding: 10px 5px;
    text-align: left;
}
.sortable tr td a {
    color: #333;
}

#profile-right h2 {
    margin: 0px 0px 10px 0px;
}

#memberstable_filter { right:10px;}

#mem_filter {
    background: #fff none repeat scroll 0 0;
    border: 1px solid #ccc;
    box-sizing: border-box;
    color: #333;
    display: inline-block;
    font-family: "Lato",sans-serif;
    font-size: 16px;
    margin: 0 0 20px;
    width: 200px;
    outline: medium none;
    padding: 5px;
    float: left;
}
</style>

<div id="profile-left">

	<img class="proimg" src="<?php echo $this->config->item('web_url');?>images/ap.jpg" />
    <?php if($username === "admin") { ?>
    <ul>
    
    	<a href="home"><li>Dashboard</li></a>
        
        <a href="allusers"><li>View Users</li></a>
        
        <a href="searchusers"><li>Search Users</li></a>
        
        <a href="exportdata"><li>Export Data</li></a>
        
        <a href="newmember"><li>Add Member</li></a>
        
        <!--<a href="admincommunity"><li>Community</li></a>-->
        
        <!--<a href="addcollege"><li>Add College</li></a>
        
        <a href="collegelist"><li>College List</li></a>-->

       <!-- <a href="subjects"><li>Question Papers</li></a>
        
        <a href="notices"><li>Add Notifications</li></a>-->
        
        <a href="confregistrants"><li>Conference Registrants</li></a>
        
        <a href="preconfregistrants"><li>Preconference</li></a>
        
        <a href="testregistrants"><li>Test Registrants</li></a>
        
        <a href="abstracts"><li>Abstracts</li></a>
        
        <a href="nominees"><li>Nominees</li></a>
           
        <a href="election"><li>Election</li></a>
           
        <a href="presentation"><li>Presentation</li></a>
           
        <a href="annualmeet"><li>Annual Meet</li></a>
    
    </ul>
<?php } ?>
</div>

<div id="profile-right">

	<?php if($username === "admin") { ?><h1><span style="font-size:12px">Membership ID: admin</span></h1><?php } ?>
    
    <div class="clear"></div>
    
    <h2>Test Registrants</h2>

    <div class="clear"></div>

	<h2>All Users (<?php echo $allusers['member_count']; ?>)</h2>  
    
    <div class="clear"></div>
       
    <div style="clear:both; height:40px;"></div> 
    
    <?php //echo $allusers['member_list']; ?> 	
    
    <?php echo $this->table->generate();  ?> 

</div>
   
   
   
  
 
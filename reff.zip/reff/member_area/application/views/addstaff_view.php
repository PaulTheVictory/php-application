
<script type="text/javascript">
$(document).ready(function(){	
	
	$(".addstaff").click(function(){
		
		var staffname = $(".staffname").val();
        var designation = $(".designation").val();		
		
		if(staffname==""){ $(".staffname").addClass('errclass');$(".edit-err-notify").text("Invalid Staff Name");return;}
		
		if(designation==""){ $(".designation").addClass('errclass');$(".edit-err-notify").text("Invalid Designation");return;}
		
		$(".edit-err-notify").html("<font style=\"color:#9d3c1a\">Processing...</font>");
                 $.get('addstaff/addCollegeStaff',{
                       'staffname':staffname,
                       'designation':designation			   

                 }, function(o) { 
				 		var obj1 = $.parseJSON(o);
						if(obj1[0] == 'exists'){
							$(".edit-err-notify").html("<font style=\"color:#9d3c1a\">Staff Already Existed</font>"); 							
						}else if(obj1[0] == 'success'){
				 			$(".edit-err-notify").html("<font style=\"color:#9d3c1a\">Staff Added Successfully</font>"); 
                            $(".staffname").val("");
							$(".designation").val("");
						}else if(obj1[0] == ''){
							setTimeout(function(){ $(".edit-err-notify").html("<font style=\"color:#9d3c1a\">Please Try again later.</font>"); }, 2000);
						}
                 });	
		
	});
	
	 
	 $("#profile-right").find("input").each(function(){

          $(this).click(function(){ $(this).removeClass("errclass");$(".edit-err-notify").text("");});

     });
	 
	 $("#profile-right").find("select").each(function(){

          $(this).click(function(){ $(this).removeClass("errclass");$(".edit-err-notify").text("");});

     });
	 
	

});
</script>

<div id="profile-left" style="background-image:url(<?php echo $this->config->item('web_url');?>images/college-top.jpg)">

	<img class="proimg" src="<?php echo $this->config->item('web_url');?>/docs/colleges/colp.jpg" width="140" height="160" />
    
    <ul>
    
    	<a href="collegehome"><li>Home</li></a>
        
        <a href="editcollegeprofile"><li>Edit Profile</li></a>
        
        <a href="addstaff"><li>Add Staff</li></a>
    
    </ul>

</div>

<div id="profile-right" style="background-image:url(<?php echo $this->config->item('web_url');?>images/college-top.jpg)">

	<h1><?php echo $collegedetails['name']; ?><br /><span style="font-size:12px">User ID: <?php echo $collegedetails['userid']; ?></span></h1>
    
    <div class="right-options">
    
    	<button class="addstaff" id="colbtn">Add</button><br />
        <p style="margin:15px 0 0; text-align:right; color:#fff;" class="edit-err-notify"></p>
    
    </div>
    
    <div class="clear"></div>

	<h2>Add Staff</h2>
    
    <div id="profile-titles">
    
    	<h2>Name</h2>
    
    </div>
    
    <div id="profile-content">
    
    	<input class="college-text-box staffname" value="" />
            
    </div>
    
    <div style="clear:both; height:5px;"></div> 
    
    <div id="profile-titles">
    
    	<h2>Designation</h2>
    
    </div>
    
    <div id="profile-content">
    
    	<select class="college-text-box designation" style="padding:3px 5px; width:356px;">
        <option value="">&nbsp;</option>
        <option>HOD</option>
        <option>Asst. Professor</option>
        <option>Lecturer</option>
        </select>
            
    </div>
    
    <div style="clear:both; height:30px;"></div> 
        
      	

</div>
   
   
   
  
 
</div>

	<div id="footertop">

	<div class="wrap">
            
        <div class="foot-about">
        
        	<a href="<?php echo $this->config->item('web_url');?>" title="CEAT" class="logolink"><img class="logo" src="<?php echo $this->config->item('web_url');?>images/logo.jpg" /></a>
                   
			<p>Dr. M. Rajasekaran<br/> Hon. Secretary,<br/> CEAT E4 Dental Care,<br/>No. 13 Bakthavatchalam Nagar,<br/>5th Street Extension,Adyar,<br/> Chennai:600020,<br/> Tamil Nadu</p>
                    
        </div>
        
        <div class="quicklinks">
        
         <div class="quickinner">

			<ul>
				<a href="<?php echo $this->config->item('web_url');?>" title="Home"><li>Home</li></a>
				<a href="<?php echo $this->config->item('web_url');?>about-us.html" title="About Us"><li>About Us</li></a>
				<a href="<?php echo $this->config->item('web_url');?>office-bearers.html" title="Office Bearers"><li>Office Bearers</li></a>
				<a href="<?php echo $this->config->item('web_url');?>by-laws.html" title="ByLaws"><li>ByLaws</li></a>
				<a href="http://www.jodend.com" title="Our Journal" target="_blank" ><li>Our Journal</li></a>
			 </ul>
            
            
       </div>
        
        </div>

        
        <div class="quicklinks">
        
        <div class="quickinner">
                    
			<ul>
				<a href="<?php echo $this->config->item('web_url');?>awards.html" title="CEAT Awards"><li>CEAT Awards</li></a>
				<a href="<?php echo $this->config->item('web_url');?>news-events.html" title="News & Events"><li>News & Events</li></a>
			</ul>

            
          
       </div>
        
        </div>
        
       <!--<div class="quicklinks">
        
         <div class="quickinner">
         
        	<h2>Your Oral Health</h2>

			<ul>
				<a href="#" title="Caring for Your Teeth"><li>Caring for Your Teeth</li></a>
				<a href="#" title="CEAT Seal Program"><li>CEAT Seal Program</li></a>
				<a href="#" title="FAQs"><li>FAQs</li></a>
				<a href="#" title="National Oral Health Month"><li>National Oral Health Month</li></a>
				<a href="#" title="Regulatory Authorities"><li>Regulatory Authorities</li></a>
				<a href="#" title="Teaching Kids"><li>Teaching Kids</li></a>
				<a href="#" title="Visiting Your Dentist"><li>Visiting Your Dentist</li></a>
			 </ul>
            
            
       </div>
        
        </div>

        
        <div class="quicklinks">
        
        <div class="quickinner">
        
        	<h2>About CDA</h2>
            
			<ul>
				<a href="#" title="Awards"><li>Awards</li></a>
				<a href="#" title="CEATC"><li>CEATC</li></a>
				<a href="#" title="Contact"><li>Contact</li></a>
				<a href="#" title="Governance Structure"><li>Governance Structure</li></a>
				<a href="#" title="History"><li>History</li></a>
				<a href="#" title="Media Room"><li>Media Room</li></a>
				<a href="#" title="Membership"><li>Membership</li></a>
				<a href="#" title="Position Statements"><li>Position Statements</li></a>
				<a href="#" title="Provincial Associations"><li>Provincial Associations</li></a>
			</ul>

            
          
       </div>
        
        </div>
        
        <div class="quicklinks">
        
         <div class="quickinner">
         
			 <h2>Becoming a Dentist</h2>

			<ul>
				<a href="#" title="Dental Aptitude Test"><li>Dental Aptitude Test</li></a>
				<a href="#" title="Dentistry Students"><li>Dentistry Students</li></a>
				<a href="#" title="Pursuing a Career in Dentistry"><li>Pursuing a Career in Dentistry</li></a>
			 </ul>
        
        <h2>Practice Support</h2>

			<ul>
				<a href="#" title="Clinical Information"><li>Clinical Information</li></a>
				<a href="#" title="Patient Communication"><li>Patient Communication</li></a>
				<a href="#" title="Practice Management"><li>Practice Management</li></a>
				<a href="#" title="Practice Support Services"><li>Practice Support Services</li></a>
			 </ul>
         
       </div>
        
        </div>
        
        <div class="quicklinks">
        
        <div class="quickinner">
        
        	<h2>Services & Resources</h2>
            
			<ul>
				<a href="#" title="CEAT Essentials Magazine"><li>CEAT Essentials Magazine</li></a>
				<a href="#" title="CEAT Oasis App"><li>CEAT Oasis App</li></a>
				<a href="#" title="CEATnet"><li>CEATnet</li></a>
				<a href="#" title="Contact"><li>Contact</li></a>
				<a href="#" title="CDSPI"><li>CDSPI</li></a>
				<a href="#" title="eReferral Service"><li>eReferral Service</li></a>
				<a href="#" title="Fact Sheets"><li>Fact Sheets</li></a>
				<a href="#" title="ITRANS"><li>ITRANS</li></a>
				<a href="#" title="CEATOasis"><li>CEATOasis</li></a>
				<a href="#" title="Life as an Internationally Trained Dentist"><li>Life as an Internationally Trained Dentist</li></a>
			</ul>
          
       </div>
        
        </div>-->
        
                    
    </div>
    
</div>

<div id="footerbottom">

	<div class="wrap">
    
    	<span id="copyright"> Copyright &copy; <?php echo date('Y');?> Conservative Dentistry & Endodontics Association of Tamilnadu, Inc. All rights reserved.</span>
        
        <!--<span id="designby"><a href="http://www.harveedesigns.com/" title="Website Design">Website Design</a> by Harvee Designs</span>
        
        <div class="clear"></div>-->
    
    </div>
    
</div>
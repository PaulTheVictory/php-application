
<script type="text/javascript">
$(document).ready(function(){
	
	$(".addquestionbtn").click(function(){
		
		var subjectid = '<?php echo $questions['subjectid']; ?>';
		var question = $("#question").val();
		var option1 = $("#option1").val();
		var option2 = $("#option2").val();
		var option3 = $("#option3").val();
		var option4 = $("#option4").val();
		var answer = $("#answer").val();
					
		if(question==""){ $("#question").addClass('errclass');$(".add-err-notify1").html("Invalid Question");return;}
		if(option1==""){ $("#option1").addClass('errclass');$(".add-err-notify1").html("Invalid Option A");return;}
		if(option2==""){ $("#option2").addClass('errclass');$(".add-err-notify1").html("Invalid Option B");return;}
		if(option3==""){ $("#option3").addClass('errclass');$(".add-err-notify1").html("Invalid Option C");return;}
		if(option4==""){ $("#option4").addClass('errclass');$(".add-err-notify1").html("Invalid Option D");return;}
					
		$(".add-err-notify1").html("<font style=\"color:#339966\">Processing...</font>");
                 $.get('questions/addQuestion',{
					   'subjectid':subjectid,
					   'question':question,
					   'option1':option1,
					   'option2':option2,
					   'option3':option3,
					   'option4':option4,
					   'answer':answer

                 }, function(o) { 
				 		var obj1 = $.parseJSON(o);
						if(obj1[0] == 'exists'){
							$(".add-err-notify1").html("Question already exists"); 							
						}else if(obj1[0] == 'success'){
				 			$(".add-err-notify1").html("<font style=\"color:#339966\">Question added</font>"); 
                            setTimeout(function(){ location.reload();}, 500);  
						}else if(obj1[0] == ''){
							setTimeout(function(){ $(".add-err-notify1").html("Please Try again later."); }, 2000);
						}
                 });	 
		
		
	});
	
		
	 $("#profile-right").find("input").each(function(){

          $(this).click(function(){ $(this).removeClass("errclass");$(".add-err-notify1").text("");});

     });
	 
	 $("#profile-right").find("select").each(function(){

          $(this).click(function(){ $(this).removeClass("errclass");$(".add-err-notify1").text("");});

     });
	 
	 $("#profile-right").find("textarea").each(function(){

          $(this).click(function(){ $(this).removeClass("errclass");$(".add-err-notify1").text("");});

     });
	 
	 $(".deletesubject").click(function(){
		 
		var subjectid = '<?php echo $questions['subjectid']; ?>';
		 
		var r=confirm("Are you sure to delete the subject and all the below questions ?")
		if (r==true){
  			$(".edit-err-notify").html("<font style=\"color:#f7d8ba\">Processing...</font>");
                 $.get('questions/deleteSubject',{
                       'subjectid':subjectid			   

                 }, function(o) {  $(".edit-err-notify").html("<font style=\"color:#f7d8ba\">Subject Deleted</font>"); 
                           setTimeout(function(){ location.assign("subjects");}, 500);         
                 }, 'json');
				 
  		}
		 
	 });
	 
	 $(".deletequestion").click(function(){
		 
		var questid = $(this).attr("id");
		 
		var r=confirm("Are you sure to delete the question ?")
		if (r==true){
                 $.get('questions/deleteQuestion',{
                       'questid':questid			   

                 }, function(o) { 
                           setTimeout(function(){ location.reload();}, 20);         
                 }, 'json');
				 
  		}
		 
	 });

});
</script>

<div id="profile-left">

	<img class="proimg" src="<?php echo $this->config->item('web_url');?>images/ap.jpg" />
    
    <ul>
    
    	<a href="home"><li>Dashboard</li></a>
        
        <a href="allusers"><li>View Users</li></a>
        
        <a href="searchusers"><li>Search Users</li></a>
        
        <a href="exportdata"><li>Export Data</li></a>
        
        <a href="newmember"><li>Add Member</li></a>
        
        <a href="admincommunity"><li>Community</li></a>
        
        <!--<a href="addcollege"><li>Add College</li></a>
        
        <a href="collegelist"><li>College List</li></a>-->

        <a href="notices"><li>Add Notifications</li></a>
        
        <a href="confregistrants"><li>Conference Registrants</li></a>
        
        <a href="testregistrants"><li>Test Registrants</li></a>
        
        <a href="abstracts"><li>Abstracts</li></a>
    
    </ul>

</div>

<div id="profile-right">

	<h1><?php echo $questions['subject_name']; ?> (<?php echo $questions['quest_count']; ?>)</h1>
    
    <div class="right-options">
    
    	<button class="deletesubject" id="addmembut">Delete</button><br />
        <p style="margin:15px 0 0; text-align:right; color:#fff;" class="edit-err-notify"></p>
    
    </div>
    
    <div class="clear"></div>
           
    <?php echo $questions['quest_list']; ?> 	
    
    <div style="clear:both; height:30px;"></div> 
    
    <h2>Add Question</h2>
    
    <p><span style="float:left; margin:14px 5px; color:#1977a6; font-weight:bold;">Question</span>
    <textarea class="question-textarea" name="question" id="question"></textarea></p>
    <div class="clear"></div>
    
    <p><span style="float:left; margin:14px 5px; color:#1977a6; font-weight:bold;">Option A</span>
    <input class="question-text-box" type="text" name="option1" value="" id="option1" /></p>
    <div class="clear"></div>
    
    <p><span style="float:left; margin:14px 5px; color:#1977a6; font-weight:bold;">Option B</span>
    <input class="question-text-box" type="text" name="option2" value="" id="option2" /></p>
    <div class="clear"></div>
    
    <p><span style="float:left; margin:14px 5px; color:#1977a6; font-weight:bold;">Option C</span>
    <input class="question-text-box" type="text" name="option3" value="" id="option3" /></p>
    <div class="clear"></div>
    
    <p><span style="float:left; margin:14px 5px; color:#1977a6; font-weight:bold;">Option D</span>
    <input class="question-text-box" type="text" name="option4" value="" id="option4" /></p>
    <div class="clear"></div>
    
    <p><span style="float:left; margin:14px 5px; color:#1977a6; font-weight:bold;">Answer &nbsp;</span>
    <select class="question-select" name="answer" id="answer">
    <option value="">&nbsp;</option>
    <option value="option1">Option A</option>
    <option value="option2">Option B</option>
    <option value="option3">Option C</option>
    <option value="option4">Option D</option>
    </select>
    <button id="find-submit" class="addquestionbtn">Add</button>
    <span style="font-size: 12px; color: #c03; padding: 0px 10px; float: left; margin: 15px 0px;" class="add-err-notify1"></span></p>
    <div class="clear"></div>
    
    <div style="clear:both; height:30px;"></div>  

</div>
   
   
   
  
 
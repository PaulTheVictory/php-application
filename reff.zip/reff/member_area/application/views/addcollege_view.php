
<script type="text/javascript">
$(document).ready(function(){
	
	$(".addcollege").click(function(){
		
		var name = $(".nameadd").val();
		var userid = $(".useridadd").val();
		var password = $(".passadd").val();
		var state = $(".stateadd").val();
					
		if(name==""){ $(".nameadd").addClass('errclass');$(".edit-err-notify").text("Invalid College Name");return;}
		
		if(userid==""){ $(".useridadd").addClass('errclass');$(".edit-err-notify").text("Invalid User ID");return;}
		
		if(password==""){ $(".passadd").addClass('errclass');$(".edit-err-notify").text("Invalid Password");return;}
		
		if(state==""){ $(".state").addClass('errclass');$(".edit-err-notify").text("Invalid State");return;}
					
		$(".edit-err-notify").html("<font style=\"color:#f7d8ba\">Processing...</font>");
                 $.get('addcollege/createCollege',{
					   'name':name, 
					   'userid':userid,
					   'password':password,
					   'state':state

                 }, function(o) { 
				 		var obj1 = $.parseJSON(o);
						if(obj1[0] == 'exists'){
							$(".edit-err-notify").html("<font style=\"color:#f7d8ba\">User ID Existed</font>"); 							
						}else if(obj1[0] == 'success'){
				 			$(".edit-err-notify").html("<font style=\"color:#f7d8ba\">College Profile Created</font>"); 
                            setTimeout(function(){ location.reload();}, 2000);  
						}else if(obj1[0] == ''){
							setTimeout(function(){ $(".edit-err-notify").html("<font style=\"color:#f7d8ba\">Please Try again later.</font>"); }, 2000);
						}
                 });	 
		
		
	});
	
		
	 $("#profile-right").find("input").each(function(){

          $(this).click(function(){ $(this).removeClass("errclass");$(".edit-err-notify").text("");});

     });

});
</script>

<div id="profile-left">

	<img class="proimg" src="<?php echo $this->config->item('web_url');?>'images/ap.jpg" />
    
    <ul>
    
    	<a href="home"><li>Dashboard</li></a>
        
        <a href="allusers"><li>View Users</li></a>
        
        <a href="searchusers"><li>Search Users</li></a>
        
        <a href="exportdata"><li>Export Data</li></a>
        
        <a href="newmember"><li>Add Member</li></a>
        
        <a href="admincommunity"><li>Community</li></a>
        
        <!--<a href="addcollege"><li>Add College</li></a>
        
        <a href="collegelist"><li>College List</li></a>-->

        <a href="subjects"><li>Question Papers</li></a>
        
        <a href="notices"><li>Add Notifications</li></a>
    
    </ul>

</div>

<div id="profile-right">

	<h1>Dr. <?php echo $membername['name']; ?><br /><span style="font-size:12px">Membership ID: admin</span></h1>
    
    <div class="right-options">
    
    	<button class="addcollege" id="addmembut">Add</button><br />
        <p style="margin:15px 0 0; text-align:right; color:#fff;" class="edit-err-notify"></p>
    
    </div>
    
    <div class="clear"></div>

	<h2>Add New College</h2> 
    
    <div id="profile-titles">
    
    	<h2>Login Details</h2>
    
    </div>
    
    <div id="profile-content">
    
    	<p><span>College Name</span><input class="update-text-box nameadd" value="" /></p>
        
        <p><span>User ID</span><input class="update-text-box useridadd" value="" /></p>
   
   		<p><span>Password</span><input class="update-text-box passadd" value="" /></p>
        
        <p><span>State</span><select class="update-text-box stateadd" style="padding:3px 5px; width:237px;"><option value="">&nbsp;</option><option>Andaman and Nicobar Islands</option><option>Andhra Pradesh</option><option>Arunachal Pradesh</option><option>Assam</option><option>Bihar</option><option>Chattisgarh</option><option>Chandigarh</option><option>Dadra and Nagar Haveli</option><option>Daman and Diu</option><option>Delhi</option><option>Goa</option><option>Gujarat</option><option>Haryana</option><option>Himachal Pradesh</option><option>Jammu and Kashmir</option><option>Jharkhand</option><option>Karnataka</option><option>Kerala</option><option>Lakshadweep</option><option>Madhya Pradesh</option><option>Maharashtra</option><option>Manipur</option><option>Meghalaya</option><option>Mizoram</option><option>Nagaland</option><option>Odisha</option><option>Pondicherry</option><option>Punjab</option><option>Rajasthan</option><option>Sikkim</option><option>Tamil Nadu</option><option>Tripura</option><option>Uttar Pradesh</option><option>Uttarakhand</option><option>West Bengal</option></select></p>
    
    </div>
    
    <div style="clear:both; height:30px;"></div>  
           

</div>
   
   
   
  
 
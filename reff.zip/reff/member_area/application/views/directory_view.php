
<script type="text/javascript">
$(document).ready(function(){	
		
	$(".memberlist").click(function(){
		
		var memid = $(this).attr("id");
        		
		window.location.href = "<?php  echo base_url(); ?>memberpage?id="+memid;		
		
	});
	
	
	
});
</script>


<h1>Members Directory (<?php echo $memdirectory['member_count']; ?>)</h1>

<div style="width:80%;margin:30px auto 0">

	<?php echo $memdirectory['member_list']; ?> 
    
</div>
   

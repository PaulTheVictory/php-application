
<script type="text/javascript">
$(document).ready(function(){	

	$(".morejournals").click(function(){
		
		var parElement = $(this).prev();		
		var liElement = '<li style="list-style:none"><input class="update-text-box journals" value="" /><span2 class="deljournals">x</span2></li>';		
		parElement.append(liElement);
						
	});
	
	$(document).delegate('.deljournals','click',function(){
		var liElement = $(this).parent();
		liElement.remove();
	});
	
	$(".moreevents").click(function(){
		
		var parElement = $(this).prev();		
		var liElement = '<li style="list-style:none"><input class="update-text-box events" value="" /><span2 class="delevents">x</span2></li>';		
		parElement.append(liElement);
						
	});
	
	$(document).delegate('.delevents','click',function(){
		var liElement = $(this).parent();
		liElement.remove();
	});
	
	
	$(".updatecollegepro").click(function(){
		
		var address = $(".address").val();
        var city = $(".city").val();
        var state = $(".state").val();
		var pincode = $(".pincode").val();
		var contactnumber = $(".contactnumber").val();
		var email = $(".email").val();
		var pg = "NO";
		
		if($(".pg").is(':checked')) {
        	pg = $(".pg").val();
        }
		
		var journals = "";
		
		$(".journalslist").find('input').each(function(){
			if($(this).val()!="") {
        		journals += $(this).val()+"&|&";
     		}
		});
		
		var n= journals.lastIndexOf("&|&");
		journals = journals.slice(0,n);
		
		var events = "";
		
		$(".eventslist").find('input').each(function(){
			if($(this).val()!="") {
        		events += $(this).val()+"&|&";
     		}
		});
		
		var n= events.lastIndexOf("&|&");
		events = events.slice(0,n);
		
		
		if(address==""){ $(".address").addClass('errclass');$(".edit-err-notify").text("Invalid Address");return;}
		
		if(city==""){ $(".city").addClass('errclass');$(".edit-err-notify").text("Invalid City");return;}
		
		if(state==""){ $(".state").addClass('errclass');$(".edit-err-notify").text("Invalid State");return;}
		
		if(pincode==""){ $(".pincode").addClass('errclass');$(".edit-err-notify").text("Invalid Pincode");return;}
		
		regex   = new RegExp('^[0-9 \-\,\+-\/]{5,100}$');
        valid = regex.test(contactnumber);
        if(!valid){ $(".contactnumber").addClass('errclass');$(".edit-err-notify").text("Invalid Contact Number");return;}	
		
		if(email==""){ $(".email").addClass('errclass');$(".edit-err-notify").text("Invalid Email");return;}
		
		$(".edit-err-notify").html("<font style=\"color:#9d3c1a\">Processing...</font>");
                 $.get('editcollegeprofile/updateProfile',{
                       'address':address,
                       'city':city,
                       'state':state,
					   'pincode':pincode,
					   'contactnumber':contactnumber,
					   'email':email,
					   'pg':pg,
					   'journals':journals,
					   'events':events		   

                 }, function(o) {  $(".edit-err-notify").html("<font style=\"color:#9d3c1a\">Profile Updated</font>"); 
                           setTimeout(function(){ location.assign("collegehome");}, 2000);         
                 }, 'json');
		
	});
	
	 
	 $("#profile-right").find("input").each(function(){

          $(this).click(function(){ $(this).removeClass("errclass");$(".edit-err-notify").text("");});

     });
	 
	 $("#profile-right").find("textarea").each(function(){

          $(this).click(function(){ $(this).removeClass("errclass");$(".edit-err-notify").text("");});

     });
	 
	

});
</script>

<div id="profile-left" style="background-image:url(<?php echo $this->config->item('web_url');?>images/college-top.jpg)">

	<img class="proimg" src="<?php echo $this->config->item('web_url');?>docs/colleges/colp.jpg" width="140" height="160" />
    
    <ul>
    
    	<a href="collegehome"><li>Home</li></a>
        
        <a href="editcollegeprofile"><li>Edit Profile</li></a>
        
        <a href="addstaff"><li>Add Staff</li></a>
    
    </ul>

</div>

<div id="profile-right" style="background-image:url(<?php echo $this->config->item('web_url');?>images/college-top.jpg)">

	<h1><?php echo $collegedetails['name']; ?><br /><span style="font-size:12px">User ID: <?php echo $collegedetails['userid']; ?></span></h1>
    
    <div class="right-options">
    
    	<button class="updatecollegepro" id="colbtn">Update</button><br />
        <p style="margin:15px 0 0; text-align:right; color:#fff;" class="edit-err-notify"></p>
    
    </div>
    
    <div class="clear"></div>

	<h2>Edit Profile</h2>
    
    <div id="profile-titles">
    
    	<h2>Address</h2>
    
    </div>
    
    <div id="profile-content">
    
    	<textarea class="college-textarea address"><?php if($collegedetails['address']!=""){ echo $collegedetails['address'];}else{ echo ""; } ?></textarea>      
            
    </div>
    
    <div style="clear:both; height:5px;"></div> 
    
    <div id="profile-titles">
    
    	<h2>City</h2>
    
    </div>
    
    <div id="profile-content">
    
    	<input class="college-text-box city" value="<?php if($collegedetails['city']!=""){ echo $collegedetails['city'];}else{ echo ""; } ?>" />
            
    </div>
    
    <div style="clear:both; height:5px;"></div> 
    
    <div id="profile-titles">
    
    	<h2>State</h2>
    
    </div>
    
    <div id="profile-content">
    
    	<select class="college-text-box state" style="padding:3px 5px; width:356px;">
        
        	<?php
		
				$statearr = Array("Andaman and Nicobar Islands","Andhra Pradesh","Arunachal Pradesh","Assam","Bihar","Chattisgarh","Chandigarh","Dadra and Nagar Haveli","Daman and Diu","Delhi","Goa","Gujarat","Haryana","Himachal Pradesh","Jammu and Kashmir","Jharkhand","Karnataka","Kerala","Lakshadweep","Madhya Pradesh","Maharashtra","Manipur","Meghalaya","Mizoram","Nagaland","Odisha","Pondicherry","Punjab","Rajasthan","Sikkim","Tamil Nadu","Tripura","Uttar Pradesh","Uttarakhand","West Bengal");
				$stateopt = '<option value="">&nbsp;</option>';
				foreach ($statearr as $sval) { 
					if($collegedetails['state']==$sval){
						$stateopt .= "<option selected>".$sval."</option>";
					}else{
						$stateopt .= "<option>".$sval."</option>";
					}	   				
				}
				
				echo $stateopt;
		
			?>
        
        </select>
        	            
    </div>
    
    <div style="clear:both; height:5px;"></div> 
    
    <div id="profile-titles">
    
    	<h2>Pincode</h2>
    
    </div>
    
    <div id="profile-content">
    
    	<input class="college-text-box pincode" value="<?php if($collegedetails['pincode']!=""){ echo $collegedetails['pincode'];}else{ echo ""; } ?>" />
            
    </div>
    
    <div style="clear:both; height:5px;"></div> 
    
    <div id="profile-titles">
    
    	<h2>Contact Number</h2>
    
    </div>
    
    <div id="profile-content">
    
    	<input class="college-text-box contactnumber" value="<?php if($collegedetails['contactnumber']!=""){ echo $collegedetails['contactnumber'];}else{ echo ""; } ?>" />
            
    </div>
    
    <div style="clear:both; height:5px;"></div> 
    
    <div id="profile-titles">
    
    	<h2>Email Address</h2>
    
    </div>
    
    <div id="profile-content">
    
    	<input class="college-text-box email" value="<?php if($collegedetails['email']!=""){ echo $collegedetails['email'];}else{ echo ""; } ?>" />
            
    </div>
    
    <div style="clear:both; height:5px;"></div>
    
    <div id="profile-titles">
    
    	<h2>PG</h2>
    
    </div>
    
    <div id="profile-content">
    
    	<?php
		if($collegedetails['pg']!="YES"){
			echo '<input class="college-text-box pg" type="checkbox" value="YES" style="width:50px;" />';
		}else{
			echo '<input class="college-text-box pg" type="checkbox" checked="checked" value="YES" style="width:50px;" />';
		}
		?>
            
    </div>
    
    <div style="clear:both; height:30px;"></div> 
    
    <div id="profile-titles">
    
    	<h2>List of Journals</h2>
    
    </div>
    
    <div id="profile-content">
    
    	<ul class="journalslist" style="margin-top: 15px;">
        
        	<?php
				$count = count($collegedetails['journals']);
				if($collegedetails['journals'][0]!=""){
					for($i=0;$i<$count;$i++){
						
						if($i==0){
							echo '<li style="list-style:none"><input class="update-text-box journals" value="'.$collegedetails['journals'][$i].'" /></li>';
						}else{
							echo '<li style="list-style:none"><input class="update-text-box journals" value="'.$collegedetails['journals'][$i].'" /><span2 class="deljournals">x</span2></li>';
						}
						
					}
				}else{
					echo '<li style="list-style:none"><input class="update-text-box journals" value="" /></li>';
				}			
			?>
        	                        
        </ul>
        
        <button style="float:left; margin:-40px 0 0 285px" id="editbut" class="morejournals">More</button>      
    
    </div>
    
    <div style="clear:both; height:30px;"></div>
    
    <div id="profile-titles">
    
    	<h2>Current Events</h2>
    
    </div>
    
    <div id="profile-content">
    
    	<ul class="eventslist" style="margin-top: 15px;">
        
        	<?php
				$count = count($collegedetails['events']);
				if($collegedetails['events'][0]!=""){
					for($i=0;$i<$count;$i++){
						
						if($i==0){
							echo '<li style="list-style:none"><input class="update-text-box events" value="'.$collegedetails['events'][$i].'" /></li>';
						}else{
							echo '<li style="list-style:none"><input class="update-text-box events" value="'.$collegedetails['events'][$i].'" /><span2 class="delevents">x</span2></li>';
						}
						
					}
				}else{
					echo '<li style="list-style:none"><input class="update-text-box events" value="" /></li>';
				}			
			?>
        	                        
        </ul>
        
        <button style="float:left; margin:-40px 0 0 285px" id="editbut" class="moreevents">More</button>      
    
    </div>
    
    <div style="clear:both; height:30px;"></div>
        
      	

</div>
   
   
   
  
 
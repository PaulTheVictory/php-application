
<link rel="stylesheet" type="text/css" href="css/dataTables.css" />
<script src="js/jquery.dataTables.js?v=1.0" type="text/javascript"></script>
<script type="text/javascript">
$(document).ready(function(){	
		
	/*$(".memberlist").click(function(){
		
		var memid = $(this).attr("id");
        		
		window.location.href = "<?php  echo base_url(); ?>editmemberpage?id="+memid;		
		
	});*/
	
          var columnData = [
                    { "data": "regno" },
                    { "data": "memtype" },
                    { "data": "name" },
                    { "data": "mobile" },
                    { "data": "email" },
                    { "data": "contactcity" }                    
                  ];
         columnData.push( {data: "id","visible":false} );
         columnData.push( {data: "memberid","visible":false} );
         
       
        var oTable = $('#memberstable').dataTable({
                    "bProcessing": true,
                    "bServerSide": true,
                    "sPaginationType": "full_numbers",
					"aaSorting": [0,'desc'],
                    "ajax": {
                    "url": 'confregistrants/getMemberLists',
                    "type": "POST"
                     }, 
                     "oLanguage": {
                        "sProcessing": "<img src='<?php echo base_url(); ?>images/loader.gif'>"
                    },
                    'iDisplayLength': 25,
                    "columns": columnData,
                    "fnDrawCallback": function( oSettings ) {
                            
                    }
         }); 
         
         $("#mem_filter").change(function(){
            var result = $(this).val();
            oTable.dataTable().fnFilter(result);
        })
	
	
});
</script>
<style type="text/css">

    .sortable {
    border: 1px solid #ddd;
    border-collapse: collapse;
    color: #333;
    margin: 10px auto;
    width: 100%;
}
.dataTables_wrapper input[type="text"] {
    padding: 0;
}
.dataTables_wrapper select {
    padding: 0;
}
.sortable tr th {
    border-right: 1px solid #ddd;
    padding: 10px 0;
}
.sortable tr td {
    border-right: 1px solid #ddd;
    padding: 10px 5px;
    text-align: left;
	font-size: 15px;
}
.sortable tr td a {
    color: #333;
}

#profile-right h2 {
    margin: 0px 0px 10px 0px;
}

#memberstable_filter { right:10px;}

#mem_filter {
    background: #fff none repeat scroll 0 0;
    border: 1px solid #ccc;
    box-sizing: border-box;
    color: #333;
    display: inline-block;
    font-family: "Lato",sans-serif;
    font-size: 16px;
    margin: 0 0 20px;
    width: 200px;
    outline: medium none;
    padding: 5px;
    float: left;
}
</style>

<div id="profile-left">

	<img class="proimg" src="<?php echo $this->config->item('web_url');?>images/ap.jpg" />
    <?php if($username === "admin") { ?>
    <ul>
    
    	<a href="home"><li>Dashboard</li></a>
        
        <a href="allusers"><li>View Users</li></a>
        
        <a href="searchusers"><li>Search Users</li></a>
        
        <a href="exportdata"><li>Export Data</li></a>
        
        <a href="newmember"><li>Add Member</li></a>
        
        <!--<a href="admincommunity"><li>Community</li></a>-->
        
        <!--<a href="addcollege"><li>Add College</li></a>
        
        <a href="collegelist"><li>College List</li></a>-->

       <!-- <a href="subjects"><li>Question Papers</li></a>
        
        <a href="notices"><li>Add Notifications</li></a>-->
        
        <a href="confregistrants"><li>Conference Registrants</li></a>
        
        <a href="preconfregistrants"><li>Preconference</li></a>
        
        <a href="testregistrants"><li>Test Registrants</li></a>
        
        <a href="abstracts"><li>Abstracts</li></a>
        
        <a href="nominees"><li>Nominees</li></a>
           
        <a href="election"><li>Election</li></a>
           
        <a href="presentation"><li>Presentation</li></a>
           
        <a href="annualmeet"><li>Annual Meet</li></a>
    
    </ul>
<?php } ?>
</div>

<div id="profile-right">

	<?php if($username === "admin") { ?><h1><span style="font-size:12px">Membership ID: admin</span></h1><?php } ?>
   
   <div class="right-options">
    
	   <a href="confnewregistrants"><button id="editbut">Add Registrants</button></a>
    
    </div>
    
    <div class="clear"></div>
    
    <h2>Conference Registrants</h2>
    
    <div class="clear"></div>
    
     <table class="approvaltable">
    
    <tr class="heading"><td colspan="5" style="text-align:center;">Waiting for Approval (<?php echo $waitingforapproval['conf_count']; ?>)</td></tr>
    
    <?php echo $waitingforapproval['conf_list']; ?>
    
    </table>     
    
	<div class="clear"></div>

	<h2>All Users (<?php echo $allusers['member_count']; ?>)</h2>  
   
    <form action="confregistrants/exportConfreg" method="post" style="float: right;">
    
    	<input type="hidden" name="memrole" value="<?php echo $role; ?>" />
    	 <input type="submit" value="Export" id="editbut" style="float:none;margin: 0px 5px;" />
	</form>
    
    <div class="clear"></div>    
   
    <div style="clear:both; height:40px;"></div> 
    
    <?php //echo $allusers['member_list']; ?> 	
    
    <?php echo $this->table->generate();  ?> 

</div>
   
   
   
  
 
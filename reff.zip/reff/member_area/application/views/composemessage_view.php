
<script type="text/javascript">
$(document).ready(function(){	
		
	
	 $("#inbox").click(function(){
		 
		window.location.href = "<?php  echo base_url(); ?>messageinbox";	
		 
	 });
	 
	 $("#sentitems").click(function(){
		 
		window.location.href = "<?php  echo base_url(); ?>messagesent";	
		 
	 });
	 
	 $(".compose-submit").click(function(){
		 
		 var fromname = "<?php echo $membername['name']; ?>";
		 var tonames = $(".messageto").val();		 
		 var toids = "";
		 var subject = $(".subjectfield").val();
		 var message = $(".messagefield").val();
		 
		 $(".chzn-results").find("li").each(function(){
			 if($(this).hasClass("result-selected")){
				 toids = toids + $(this).attr("class") + "|";
			 }
		 });
		 toids=toids.replace(/result-selected/g,"");
		 toids=toids.replace(/\s/g, "");
		 
		 if(tonames==null || tonames==""){
			$("#compose-errnotify").text('Select atleast one Connection');return;
		 }
		 
		 if(subject==""){
			$("#compose-errnotify").text("Enter a Subject");return;
		 }
		 
		 if(message==""){
			$("#compose-errnotify").text("Enter a Message");return;
		 }
		 
		 $("#compose-errnotify").text("Processing...").css("color","#abc0ca");
                 $.get('composemessage/sendNewMessage',{
					   'fromname':fromname,
                       'tonames':tonames,
                       'toids':toids,
                       'subject':subject,
					   'message':message		   

                 }, function(o) {  $("#compose-errnotify").text("Message Sent").css("color","#109141"); 
                           setTimeout(function(){ location.reload();}, 2000);  
                 }, 'json');
		 
	 });
	 
	 $("#compose-table").find("input").each(function(){
          $(this).click(function(){ $("#compose-errnotify").text("");});
     });
	 
	 $("#compose-table").find("textarea").each(function(){
          $(this).click(function(){ $("#compose-errnotify").text("");});
     });
	
	
});
</script>


<h1>Compose Message<span class="message-links" id="sentitems">Sent Items</span><span class="message-links" id="inbox">Inbox</span></h1>

<div id="message-content">

<table id="compose-table">

<tr>

<td width="100px">From:</td>

<td width="600px"><span style="font-weight:normal; color:#1977A6;"><?php echo $membername['name']; ?></span></td>

</tr>

<tr>

<td>To:</td>

<td><select data-placeholder="Select a Connection..." class="messageto" multiple><?php echo $connections; ?></select></td>

</tr>

<tr>

<td>Subject:</td>

<td><input class="compose-text-box subjectfield" value="" /></td>

</tr>

<tr>

<td>Message:</td>

<td><textarea class="compose-textarea messagefield"></textarea> </td>

</tr>

<tr>

<td>&nbsp;</td>
<td><button class="compose-submit">Send</button><span id="compose-errnotify"></span></td>

</tr>

</table>

	
    
</div>
   

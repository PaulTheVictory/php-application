
<script type="text/javascript">
$(document).ready(function(){
	
	$(".memberstudent").hide();
	$(".memberfaculty").hide();
	$(".memberpractitioner").hide();
	$(".membercontent1").hide();
	$(".addclinic").hide();
	$(".clinicname").hide();
	$(".mapon").hide();
	$(".removeclinic").hide();
	
		var loadcontent=[];	
		var fields=[];
		

<?php 
     
	 	$state=array("Andaman and Nicobar Islands","Andhra Pradesh","Arunachal Pradesh","Assam","Bihar","Chandigarh","Chhattisgarh","Dadra and Nagar Haveli","Daman and Diu","Delhi","Goa","Gujarat","Haryana","Himachal Pradesh","Jammu and Kashmir","Jharkhand","Karnataka","Kerala","Lakshadweep","Madhya Pradesh","Maharashtra","Manipur","Meghalaya","Mizoram","Nagaland","Odisha","Puducherry","Punjab","Rajasthan","Sikkim","Tamil Nadu","Telengana","Tripura","Uttar Pradesh","Uttarakhand","West Bengal");

     $mstudent=array("","","","","","");
	 $mfaculty=array("","","","","","",""); 
	 if($memberprofile['mstudent']!="")
	 {
		 $mstudent=explode(',',$memberprofile['mstudent']);
		 
	 }
	 if($memberprofile['mfaculty']!="")
	 {
		 $mfaculty=explode(',',$memberprofile['mfaculty']);
		 
	 }
	 
	 	 $mtype=array("");
		 $mtypecheck="Practitioner";
		 $mpract="";
		 if($memberprofile['mtype']!="" && strpos($memberprofile['mtype'], ',') !== false)
		 {
			 $mtype=explode(',',$memberprofile['mtype']);
			 
		 }else{ $mtype =array($memberprofile['mtype']); }
		 
		 	 if($mtype[0]=="Practitioner"){ $mpract="Practitioner";}
			 if(isset($mtype[1])){if($mtype[1]=="Practitioner"){ $mpract="Practitioner";}}
			 if(isset($mtype[2])){if($mtype[2]=="Practitioner"){ $mpract="Practitioner";}}else{  $mpract=""; }


?>
	var emptyfields='<p><span>College Name <font color="#990000">*</font></span><input class="update-text-box nameedit" name="nameedit" value="" /></p><p><span>College Address Line 1 <font color="#990000">*</font></span><input class="update-text-box address1edit" name="address1edit" value="" /><span1>max. 250 chars</span1></p><p style="display:none;"><span>College Address Line 2</span><input type="hidden" class="update-text-box address2edit" value="" /><span1>max. 250 chars</span1></p><p><span>City <font color="#990000">*</font></span><input class="update-text-box cityedit" name="cityedit" value="" /></p><p><span>State <font color="#990000">*</font></span><select class="update-text-box stateedit"><?php for($s=0;$s<count($state);$s++){?><option value="<?php echo $state[$s]; ?>"><?php echo $state[$s]; ?></option><?php } ?></select></p><p><span>Pincode <font color="#990000">*</font></span><input class="update-text-box pincodeedit" name="pincodeedit" value="" /></p><p><span>Landline Number</span><input class="update-text-box lnumberedit" value="" /><span1>eg: 044-12345678</span1></p><p><span>Mobile Number <font color="#990000">*</font></span><input class="update-text-box mnumberedit" name="mnumberedit" value="" /><span1>eg: 9876543210</span1></p><p><span>Geo Location</span><input class="update-text-box clinicgeoedit" value="" /><a style="cursor:pointer;" class="update-text-box showmap">Show Map</a></p><p><span>Clinic Timing <font color="#990000">*</font></span><input class="update-text-box clinictimeedit" name="clinictimeedit" value="" /></p>';

var studentfields='<p><span>College Name <font color="#990000">*</font></span><input class="update-text-box nameedit" name="nameedit" value="<?php if($mstudent[0]!=""){ echo $mstudent[0];}else{ echo ""; } ?>" /></p><p><span>College Address Line 1 <font color="#990000">*</font></span><input class="update-text-box address1edit" name="address1edit" value="<?php if($mstudent[1]!=""){ echo $mstudent[1];}else{ echo ""; } ?>" /><span1>max. 250 chars</span1></p><p style="display:none;"><span>College Address Line 2</span><input type="hidden" class="update-text-box address2edit" value="<?php if($mstudent[2]!=""){ echo $mstudent[2];}else{ echo ""; } ?>" /><span1>max. 250 chars</span1></p><p><span>City <font color="#990000">*</font></span><input class="update-text-box cityedit" name="cityedit" value="<?php if($mstudent[3]!=""){ echo $mstudent[3];}else{ echo ""; } ?>" /></p><p><span>State <font color="#990000">*</font></span><select class="update-text-box stateedit"><?php for($s=0;$s<count($state);$s++){?><option value="<?php echo $state[$s]; ?>"<?php if($mstudent[4]!="" && $mstudent[4]==$state[$s]){ echo "selected";}else{ echo ""; } ?>><?php echo $state[$s]; ?></option><?php } ?></select></p><p><span>Pincode <font color="#990000">*</font></span><input class="update-text-box pincodeedit" name="pincodeedit" value="<?php if($mstudent[5]!=""){ echo $mstudent[5];}else{ echo ""; } ?>" /></p>';

var facultyfields='<p><span>College Name <font color="#990000">*</font></span><input class="update-text-box nameedit" name="nameedit" value="<?php if($mfaculty[1]!=""){ echo $mfaculty[1];}else{ echo ""; } ?>" /></p><p><span>College Address Line 1 <font color="#990000">*</font></span><input class="update-text-box address1edit" name="address1edit" value="<?php if($mfaculty[2]!=""){ echo $mfaculty[2];}else{ echo ""; } ?>" /><span1>max. 250 chars</span1></p><p style="display:none;"><span>College Address Line 2</span><input type="hidden" class="update-text-box address2edit" value="<?php if($mfaculty[3]!=""){ echo $mfaculty[3];}else{ echo ""; } ?>" /><span1>max. 250 chars</span1></p><p><span>City <font color="#990000">*</font></span><input class="update-text-box cityedit" name="cityedit" value="<?php if($mfaculty[4]!=""){ echo $mfaculty[4];}else{ echo ""; } ?>" /></p><p><span>State <font color="#990000">*</font></span><select class="update-text-box stateedit"><?php for($s=0;$s<count($state);$s++){?><option value="<?php echo $state[$s]; ?>"<?php if($mfaculty[5]!="" && $mfaculty[5]==$state[$s]){ echo "selected";}else{ echo ""; } ?>><?php echo $state[$s]; ?></option><?php } ?></select></p><p><span>Pincode <font color="#990000">*</font></span><input class="update-text-box pincodeedit" name="pincodeedit" value="<?php if($mfaculty[6]!=""){ echo $mfaculty[6];}else{ echo ""; } ?>" /></p>';
 
	<?php
			
	     $i=0;
		if( strpos($memberprofile['mname'], '|') !== false)
		{
			$mname=explode('|',$memberprofile['mname']);
			$maddress1=explode('|',$memberprofile['maddress1']);
			$maddress2=explode('|',$memberprofile['maddress2']);
			$mcity=explode('|',$memberprofile['mcity']);
			$mstate=explode('|',$memberprofile['mstate']);
			$mpincode=explode('|',$memberprofile['mpincode']);
			$mlandline=explode('|',$memberprofile['mlandline']);
			$mmobile=explode('|',$memberprofile['mmobile']);
			$mgeo=explode('|',$memberprofile['mgeo']);
			$mclinictiming=explode('|',$memberprofile['mclinictiming']);
		
			
		for($i=0;$i<count($mname);$i++)
		{
			
		 if($i>0) $cname='<p style="border-bottom:1px solid #bfbfbf;font-weight:800;">Clinic  '.$i.'</p>'; else  $cname="";
		?>
		
	fields.push('<?php echo $cname;?><p><span>College Name <font color="#990000">*</font></span><input class="update-text-box nameedit"  name="nameedit" value="<?php if($mname[$i]!=""){ echo $mname[$i];}else{ echo ""; } ?>" /></p><p><span>College Address Line 1 <font color="#990000">*</font></span><input class="update-text-box address1edit" name="address1edit" value="<?php if($maddress1[$i]!=""){ echo $maddress1[$i];}else{ echo ""; } ?>" /><span1>max. 250 chars</span1></p><p style="display:none;"><span>College Address Line 2</span><input type="hidden" class="update-text-box address2edit"  value="<?php if($maddress2[$i]!=""){ echo $maddress2[$i];}else{ echo ""; } ?>" /><span1>max. 250 chars</span1></p><p><span>City <font color="#990000">*</font></span><input class="update-text-box cityedit" name="cityedit" value="<?php if($mcity[$i]!=""){ echo $mcity[$i];}else{ echo ""; } ?>" /></p><p><span>State <font color="#990000">*</font></span><select class="update-text-box stateedit"><?php for($s=0;$s<count($state);$s++){?><option value="<?php echo $state[$s]; ?>"<?php if($mstate[$i]!="" && $mstate[$i]==$state[$s]){ echo "selected";}else{ echo ""; } ?>><?php echo $state[$s]; ?></option><?php } ?></select></p><p><span>Pincode <font color="#990000">*</font></span><input class="update-text-box pincodeedit" name="pincodeedit" value="<?php if($mpincode[$i]!=""){ echo $mpincode[$i];}else{ echo ""; } ?>" /></p>');
	
	
	var final = [];
	$('.membertypeedit:checked').each(function(i){
		 
		 final.push($(this).val());
	});
			
	if($.inArray( "Student", final )!='-1')
	{
		$('.addclinic').fadeOut();
		$('.memberstudent').fadeIn().html("<p style='border-bottom:1px solid #bfbfbf;font-weight:800;'>Student</p>"+studentfields);
	}
	if($.inArray( "Faculty", final )!='-1')
	{
		$('.addclinic').fadeOut();
		$('.memberfaculty').fadeIn().html('<p style="border-bottom:1px solid #bfbfbf;font-weight:800;">Faculty</p><p><span>Designation <font color="#990000">*</font></span><input class="update-text-box designationedit" name="designationedit" value="<?php if($mfaculty[0]!=""){ echo $mfaculty[0];}else{ echo ""; } ?>" /></p>').append(facultyfields);
	}
	if($.inArray( "Practitioner", final )!='-1')
	{
		$('.addclinic').fadeIn();
		$('.clinicname').fadeIn();
		$('.memberpractitioner').fadeIn().html(fields[<?php echo 0;?>]).append('<p><span>Landline Number</span><input class="update-text-box lnumberedit" value="<?php if($mlandline[0]!=""){ echo $mlandline[0];}else{ echo ""; } ?>" /><span1>eg: 044-12345678</span1></p><p><span>Mobile Number <font color="#990000">*</font></span><input class="update-text-box mnumberedit" name="mnumberedit" value="<?php if($mmobile[0]!=""){ echo $mmobile[0];}else{ echo ""; } ?>" /><span1>eg: 9876543210</span1></p><p><span>Geo Location</span><input class="update-text-box clinicgeoedit" value="<?php if($mgeo[0]!=""){ echo $mgeo[0];}else{ echo ""; } ?>" /><a style="cursor:pointer;" class="update-text-box showmap">Show Map</a></p><p><span>Clinic Timing <font color="#990000">*</font></span><input class="update-text-box clinictimeedit" name="clinictimeedit" value="<?php if($mclinictiming[0]!=""){ echo $mclinictiming[0];}else{ echo ""; } ?>" /></p>');
		
				$(".memberpractitioner").find("p:nth-child(1) span").html("Cilnic Name <font color='#990000'>*</font>");
				$(".memberpractitioner").find("p:nth-child(2) span").html("Clinic Address Line 1 <font color='#990000'>*</font>");
				$(".memberpractitioner").find("p:nth-child(3) span").html("Clinic Address Line 2");
				
				<?php if($i>0){?>
				
				$('.membercontent1').fadeIn().append(fields[<?php echo $i;?>]).append('<p><span>Landline Number</span><input class="update-text-box lnumberedit" value="<?php if($mlandline[$i]!=""){ echo $mlandline[$i];}else{ echo ""; } ?>" /><span1>eg: 044-12345678</span1></p><p><span>Mobile Number <font color="#990000">*</font></span><input class="update-text-box mnumberedit" name="mnumberedit" value="<?php if($mmobile[$i]!=""){ echo $mmobile[$i];}else{ echo ""; } ?>" /><span1>eg: 9876543210</span1></p><p><span>Geo Location</span><input class="update-text-box clinicgeoedit" value="<?php if($mgeo[$i]!=""){ echo $mgeo[$i];}else{ echo ""; } ?>" /><a style="cursor:pointer;" class="update-text-box showmap">Show Map</a></p><p><span>Clinic Timing <font color="#990000">*</font></span><input class="update-text-box clinictimeedit" name="clinictimeedit" value="<?php if($mclinictiming[$i]!=""){ echo $mclinictiming[$i];}else{ echo ""; } ?>" /></p>');
		
				$(".membercontent1").find("p:nth-child(2) span").html("Cilnic Name <font color='#990000'>*</font>");
				$(".membercontent1").find("p:nth-child(3) span").html("Clinic Address Line 1 <font color='#990000'>*</font>");
				$(".membercontent1").find("p:nth-child(4) span").html("Clinic Address Line 2");
				$(".removeclinic").fadeIn();
				<?php }?>

	}

   <?php if($i>0){?>
	   
	        loadcontent.push(fields[<?php echo $i;?>]+'<p><span>Landline Number</span><input class="update-text-box lnumberedit" value="<?php if($mlandline[$i]!=""){ echo $mlandline[$i];}else{ echo ""; } ?>" /><span1>eg: 044-12345678</span1></p><p><span>Mobile Number <font color="#990000">*</font></span><input class="update-text-box mnumberedit" name="mnumberedit" value="<?php if($mmobile[$i]!=""){ echo $mmobile[$i];}else{ echo ""; } ?>" /><span1>eg: 9876543210</span1></p><p><span>Geo Location</span><input class="update-text-box clinicgeoedit" value="<?php if($mgeo[$i]!=""){ echo $mgeo[$i];}else{ echo ""; } ?>" /><a style="cursor:pointer;" class="update-text-box showmap">Show Map</a></p><p><span>Clinic Timing <font color="#990000">*</font></span><input class="update-text-box clinictimeedit" name="clinictimeedit" value="<?php if($mclinictiming[$i]!=""){ echo $mclinictiming[$i];}else{ echo ""; } ?>" /></p>');
			
			<?php }?>
			
   <?php }?>	
		
		$(".membertypeedit").click(function(){
			
			var final = [];
			$('.membertypeedit:checked').each(function(i){
                 
                 final.push($(this).val());
            });
		      //alert(final);
			
		if($.inArray( "Student", final )!='-1')
		{
			$('.addclinic').fadeOut();
			$('.memberstudent').fadeIn(function(){
				
				$('.memberstudent').html("<p style='border-bottom:1px solid #bfbfbf;font-weight:800;'>Student</p>"+studentfields);
				
				});
		}
		else{$('.memberstudent').html("");}
		
		if($.inArray( "Faculty", final )!='-1')
		{
			$('.addclinic').fadeOut();
			
				$('.memberfaculty').fadeIn().html('<p style="border-bottom:1px solid #bfbfbf;font-weight:800;">Faculty</p><p><span>Designation <font color="#990000">*</font></span><input class="update-text-box designationedit" name="designationedit" value="<?php if($mfaculty[0]!=""){ echo $mfaculty[0];}else{ echo ""; } ?>" /></p>').append(facultyfields);
		}
		else $('.memberfaculty').html("");
		
		if($.inArray( "Practitioner", final )!='-1')
		{
			$('.addclinic').fadeIn();
			$('.clinicname').fadeIn();
				$('.memberpractitioner').fadeIn().html(fields[<?php echo 0;?>]);
				$('.memberpractitioner').find("p:nth-child(1) span").html("Cilnic Name <font color='#990000'>*</font>");
				$('.memberpractitioner').find("p:nth-child(2) span").html("Clinic Address Line 1 <font color='#990000'>*</font>");
				//$('.memberpractitioner').find("p:nth-child(3) span").html("Clinic Address Line 2");
				
				$('.memberpractitioner').fadeIn().append('<p><span>Landline Number</span><input class="update-text-box lnumberedit" value="<?php if($mlandline[0]!=""){ echo $mlandline[0];}else{ echo ""; } ?>" /><span1>eg: 044-12345678</span1></p><p><span>Mobile Number <font color="#990000">*</font></span><input class="update-text-box mnumberedit" name="mnumberedit" value="<?php if($mmobile[0]!=""){ echo $mmobile[0];}else{ echo ""; } ?>" /><span1>eg: 9876543210</span1></p><p><span>Geo Location</span><input class="update-text-box clinicgeoedit" value="<?php if($mgeo[0]!=""){ echo $mgeo[0];}else{ echo ""; } ?>" /><a style="cursor:pointer;" class="update-text-box showmap">Show Map</a></p><p><span>Clinic Timing <font color="#990000">*</font></span><input class="update-text-box clinictimeedit" name="clinictimeedit" value="<?php if($mclinictiming[0]!=""){ echo $mclinictiming[0];}else{ echo ""; } ?>" /></p>');
			
	
	        $(".removeclinic").fadeIn();
				
				$('.membercontent1').fadeIn().html("").append(loadcontent);
				$('.membercontent1').find("p:nth-child(2) span").html("Cilnic Name <font color='#990000'>*</font>");
				$('.membercontent1').find("p:nth-child(3) span").html("Clinic Address Line 1 <font color='#990000'>*</font>");
				//$('.membercontent1').find("p:nth-child(4) span").html("Clinic Address Line 2");
				
				$('.membercontent1').show();
				
				
		}
		else{$('.memberpractitioner').html("");$('.membercontent1').html("");$('.addclinic').fadeOut();$('.clinicname').fadeOut();$('.removeclinic').fadeOut();}
		
   });
   <?php }else{?>

           var fields='<p><span>College Name <font color="#990000">*</font></span><input class="update-text-box nameedit" name="nameedit" value="<?php if($memberprofile['mname']!=""){ echo $memberprofile['mname'];}else{ echo ""; } ?>" /></p><p><span>College Address Line 1 <font color="#990000">*</font></span><input class="update-text-box address1edit" name="address1edit" value="<?php if($memberprofile['maddress1']!=""){ echo $memberprofile['maddress1'];}else{ echo ""; } ?>" /><span1>max. 250 chars</span1></p><p style="display:none;"><span>College Address Line 2</span><input type="hidden" class="update-text-box address2edit" value="<?php if($memberprofile['maddress2']!=""){ echo $memberprofile['maddress2'];}else{ echo ""; } ?>" /><span1>max. 250 chars</span1></p><p><span>City <font color="#990000">*</font></span><input class="update-text-box cityedit" name="cityedit" value="<?php if($memberprofile['mcity']!=""){ echo $memberprofile['mcity'];}else{ echo ""; } ?>" /></p><p><span>State <font color="#990000">*</font></span><select class="update-text-box stateedit"><?php for($s=0;$s<count($state);$s++){?><option value="<?php echo $state[$s]; ?>"<?php if($memberprofile['mstate']!="" && $memberprofile['mstate']==$state[$s]){ echo "selected";}else{ echo ""; } ?>><?php echo $state[$s]; ?></option><?php } ?></select></p><p><span>Pincode <font color="#990000">*</font></span><input class="update-text-box pincodeedit" name="pincodeedit" value="<?php if($memberprofile['mpincode']!=""){ echo $memberprofile['mpincode'];}else{ echo ""; } ?>" /></p>';

	       var final = [];
			$('.membertypeedit:checked').each(function(i){
                 
                 final.push($(this).val());
            });

	if(jQuery.inArray("Student", final)!='-1')
	{
		$('.memberstudent').fadeIn().html("<p style='border-bottom:1px solid #bfbfbf;font-weight:800;'>Student</p>"+studentfields);
	}
	if(jQuery.inArray("Faculty", final)!='-1')
	{
		$('.memberfaculty').fadeIn().html(facultyfields).prepend('<p style="border-bottom:1px solid #bfbfbf;font-weight:800;">Faculty</p><p><span>Designation <font color="#990000">*</font></span><input class="update-text-box designationedit" name="designationedit" value="<?php if($mfaculty[0]!=""){ echo $mfaculty[0];}else{ echo ""; } ?>" /></p>');
	}
	if(jQuery.inArray("Practitioner", final)!='-1')
	{
		$('.clinicname').fadeIn();
		$('.memberpractitioner').fadeIn().html(fields).append('<p><span>Landline Number</span><input class="update-text-box lnumberedit" value="<?php if($memberprofile['mlandline']!=""){ echo $memberprofile['mlandline'];}else{ echo ""; } ?>" /><span1>eg: 044-12345678</span1></p><p><span>Mobile Number <font color="#990000">*</font></span><input class="update-text-box mnumberedit" name="mnumberedit" value="<?php if($memberprofile['mmobile']!=""){ echo $memberprofile['mmobile'];}else{ echo ""; } ?>" /><span1>eg: 9876543210</span1></p><p><span>Geo Location</span><input class="update-text-box clinicgeoedit" value="<?php if($memberprofile['mgeo']!=""){ echo $memberprofile['mgeo'];}else{ echo ""; } ?>" /><a style="cursor:pointer;" class="update-text-box showmap">Show Map</a></p><p><span>Clinic Timing <font color="#990000">*</font></span><input class="update-text-box clinictimeedit" name="clinictimeedit" value="<?php if($memberprofile['mclinictiming']!=""){ echo $memberprofile['mclinictiming'];}else{ echo ""; } ?>" /></p>');
		
				$(".memberpractitioner").find("p:nth-child(1) span").html("Cilnic Name <font color='#990000'>*</font>");
				$(".memberpractitioner").find("p:nth-child(2) span").html("Clinic Address Line 1 <font color='#990000'>*</font>");
				//$(".memberpractitioner").find("p:nth-child(3) span").html("Clinic Address Line 2");
				
				$('.addclinic').fadeIn();


	}
	
	$(".membertypeedit").click(function(){
		
		    var final = [];
			$('.membertypeedit:checked').each(function(i){
                 
                 final.push($(this).val());
            });
		   // alert(final);

		if(jQuery.inArray("Student", final)!='-1')
		{
				
				$('.memberstudent').fadeIn().html("<p style='border-bottom:1px solid #bfbfbf;font-weight:800;'>Student</p>"+studentfields);
				
		}else{$('.memberstudent').html("");}
		
		if(jQuery.inArray("Faculty", final)!='-1')
		{
			$('.memberfaculty').fadeIn().html("<p style='border-bottom:1px solid #bfbfbf;font-weight:800;'>Faculty</p>"+'<p><span>Designation <font color="#990000">*</font></span><input class="update-text-box designationedit" name="designationedit" value="<?php if($mfaculty[0]!=""){ echo $mfaculty[0];}else{ echo ""; } ?>" /></p>').append(facultyfields);
		}
		else{$('.memberfaculty').html("");}
		
		if(jQuery.inArray("Practitioner", final)!='-1')
		{
				$('.clinicname').fadeIn();
				$('.memberpractitioner').fadeIn().html(fields);
				$('.memberpractitioner').find("p:nth-child(1) span").html("Cilnic Name <font color='#990000'>*</font>");
				$('.memberpractitioner').find("p:nth-child(2) span").html("Clinic Address Line 1 <font color='#990000'>*</font>");
				//$('.memberpractitioner').find("p:nth-child(4) span").html("Clinic Address Line 2");
				
				$('.memberpractitioner').fadeIn().append('<p><span>Landline Number</span><input class="update-text-box lnumberedit" value="<?php if($memberprofile['mlandline']!=""){ echo $memberprofile['mlandline'];}else{ echo ""; } ?>" /><span1>eg: 044-12345678</span1></p><p><span>Mobile Number <font color="#990000">*</font></span><input class="update-text-box mnumberedit" name="mnumberedit" value="<?php if($memberprofile['mmobile']!=""){ echo $memberprofile['mmobile'];}else{ echo ""; } ?>" /><span1>eg: 9876543210</span1></p><p><span>Geo Location</span><input class="update-text-box clinicgeoedit" value="<?php if($memberprofile['mgeo']!=""){ echo $memberprofile['mgeo'];}else{ echo ""; } ?>" /><a style="cursor:pointer;" class="update-text-box showmap">Show Map</a></p><p><span>Clinic Timing <font color="#990000">*</font></span><input class="update-text-box clinictimeedit" name="clinictimeedit" value="<?php if($memberprofile['mclinictiming']!=""){ echo $memberprofile['mclinictiming'];}else{ echo ""; } ?>" /></p>');
						$('.addclinic').fadeIn();
	
		}
		else{$('.memberpractitioner').html("");$('.membercontent1').html("");$('.addclinic').fadeOut();$('.clinicname').fadeOut();}
		
	});
    <?php }?>
	
	var getcontent=[];
	var getstudentname=[];
	var getfacultyname=[];
	var getname=[];
	var getstudent=[];
	var getfaculty=[];

	$(".updateprofile").click(function(){
		
		var card,certificate = "";
		//var card = $("input[name=card]:checked").val();
		//var certificate = $("input[name=certificate]:checked").val();
		var mobile = $(".mobileedit").val();
        var phone = $(".phoneedit").val();
        var email = $(".emailedit").val();
		var gender = $(".genderedit:checked").val();
		//var dob = $(".dobedit").val();
			var dobday = $(".dobdayfield").val();
			var dobmonth = $(".dobmonthfield").val();
			var dobyear = $(".dobyearfield").val();
		var address = $.trim($(".resaddressedit").val());
		var qualification = "";
		var college = "";
		var designation = "";
		var clinic = "";
		var clinicphone = "";
		var pubsearch = $(".selectedsearch").val();
		
		var address2 = $(".resaddressedit2").val();
		var city = $(".rescityedit").val();
		var state = $(".resstateedit").val();
		var pincode = $(".respincodeedit").val();
				
		 		
		 var mtype = [];
			$('.membertypeedit:checked').each(function(i){
                 
                 mtype.push($(this).val());
            });
		var membertype = String(mtype);
		
		 
		if(mobile==""){ $(".mobileedit").addClass('errclass');$(".edit-err-notify").text("Invalid Mobile Number");return;}
		
		if(email==""){ $(".emailedit").addClass('errclass');$(".edit-err-notify").text("Invalid Email");return;}
		
		regex   = new RegExp('^[0-9 \-]{5,20}$');
        valid = regex.test(mobile);
        if(!valid){ $(".mobileedit").addClass('errclass');$(".edit-err-notify").text("Invalid Mobile Number");return;}
				
		regex   = new RegExp('^[0-9 \-]{5,20}$');
        valid = regex.test(phone);
        if(!valid && phone!=""){ $(".phoneedit").addClass('errclass');$(".edit-err-notify").text("Invalid Phone Number");return;}
		
		regex   = new RegExp('^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$');
        valid = regex.test(email);
        if(!valid){ $(".emailedit").addClass('errclass');$(".edit-err-notify").text("Invalid Email");return;}
		
		if(gender!="Male" && gender!="Female" && gender!=""){ $(".genderedit").addClass('errclass');$(".edit-err-notify").text("Invalid Gender");return;}
		
		/*regex   = new RegExp('^[0-9 \-]{10,10}$');
        valid = regex.test(dob);
        if(!valid && dob!=""){ $(".dobedit").addClass('errclass');$(".edit-err-notify").text("Invalid Date");return;}*/
		
		if(dobday=="" || dobmonth=="" || dobyear==""){ $(".dobdayfield,.dobmonthfield,.dobyearfield").addClass('errclass');$(".edit-err-notify").text("Invalid Date of Birth");return;}
	
		var dobdate = dobyear+'/'+dobmonth+'/'+dobday;
		var datevalid = isDate(dobdate);

		if(!datevalid) {
		  $(".dobdayfield,.dobmonthfield,.dobyearfield").addClass('errclass');
		  $(".edit-err-notify").text("Invalid Date of Birth");
		  return;
		}
	
		var dob = dobday+'-'+dobmonth+'-'+dobyear;
		
		regex   = new RegExp('^[a-zA-Z0-9#][a-zA-Z0-9\n\.,-_/#:& ]{3,250}$');
        valid = regex.test(address);
        if(!valid){ $(".resaddressedit1").addClass('errclass');$(".edit-err-notify").text("Invalid Res. Address1");return;}
		
		regex   = new RegExp('^[a-zA-Z0-9#][a-zA-Z0-9\n\.,-_/#:& ]{3,250}$');
        valid = regex.test(address2);
        if(!valid){ $(".resaddressedit2").addClass('errclass');$(".edit-err-notify").text("Invalid Res. Address2");return;}
		
		var regex   = new RegExp('^[a-zA-Z][a-zA-Z\.-/ ]{3,100}$');
        valid = regex.test(city);
        if(!valid){ $(".rescityedit").addClass('errclass');$(".edit-err-notify").text("Invalid Res. City");return;}
		
		var regex   = new RegExp('^[a-zA-Z][a-zA-Z\.-/ ]{3,100}$');
        valid = regex.test(state);
        if(!valid){ $(".resstateedit").addClass('errclass');$(".edit-err-notify").text("Invalid Res. State");return;}
		
		regex   = new RegExp('^[0-9 \-]{4,10}$');
        valid = regex.test(pincode);
        if(!valid){ $(".respinedit").addClass('errclass');$(".edit-err-notify").text("Invalid Pincode Number");return;}
		
		if($('.sameaddress').is(':checked'))
		{
			$(".commaddress").fadeOut();
			
			var contactaddress = address;
			var contactaddress2 = address2;
			var contactcity = city;
			var contactstate = state;
			var contactpin = pincode;
			
			var sameaddress = "Yes";

			
		}else
		{
			$(".commaddress").fadeIn();
			var contactaddress = $.trim($(".contactaddressedit1").val());
			var contactaddress2 = $.trim($(".contactaddressedit2").val());
			var contactcity = $(".contactcityedit").val();
			var contactstate = $(".contactstateedit").val();
			var contactpin = $(".contactpinedit").val();
			
			var sameaddress = "No";
			
		regex   = new RegExp('^[a-zA-Z0-9#][a-zA-Z0-9\n\.,-_/#:& ]{3,250}$');
        valid = regex.test(contactaddress);
        if(!valid){ $(".contactaddressedit1").addClass('errclass');$(".edit-err-notify").text("Invalid Communication Address1");return;}
		
		regex   = new RegExp('^[a-zA-Z0-9#][a-zA-Z0-9\n\.,-_/#:& ]{3,250}$');
        valid = regex.test(contactaddress2);
        if(!valid){ $(".contactaddressedit2").addClass('errclass');$(".edit-err-notify").text("Invalid Communication Address2");return;}
		
		var regex   = new RegExp('^[a-zA-Z][a-zA-Z\.-/ ]{3,100}$');
        valid = regex.test(contactcity);
        if(!valid){ $(".contactcityedit").addClass('errclass');$(".edit-err-notify").text("Invalid Communication City");return;}
		
		var regex   = new RegExp('^[a-zA-Z][a-zA-Z\.-/ ]{3,100}$');
        valid = regex.test(contactstate);
        if(!valid){ $(".contactstateedit").addClass('errclass');$(".edit-err-notify").text("Invalid Communication State");return;}
		
		regex   = new RegExp('^[0-9 \-]{4,10}$');
        valid = regex.test(contactpin);
        if(!valid){ $(".contactpinedit").addClass('errclass');$(".edit-err-notify").text("Invalid Communication Pincode");return;}
		}
			
		regex   = new RegExp('^[a-zA-Z][a-zA-Z\n\.,-_ ]{5,250}$');
        valid = regex.test(clinic);
        if(!valid && clinic!=""){ $(".clinicaddedit").addClass('errclass');$(".edit-err-notify").text("Invalid Clinic Address");return;}
		
		regex   = new RegExp('^[0-9 \-]{5,20}$');
        valid = regex.test(clinicphone);
        if(!valid && clinicphone!=""){ $(".clinicphoneedit").addClass('errclass');$(".edit-err-notify").text("Invalid Clinic Phone Number");return;}
		
		if(membertype==""){ $(".membertypeedit").addClass('errclass');$(".edit-err-notify").text("Select Member Type");return;}
		
        //Student
		var mname = $(".memberstudent .nameedit").val();
		var maddress1 = $(".memberstudent .address1edit").val();
		var maddress2 = $(".memberstudent .address2edit").val();
		var mcity = $(".memberstudent .cityedit").val();
		var mstate = $(".memberstudent .stateedit").val();
		var mpincode = $(".memberstudent .pincodeedit").val();

		var i=0;
		var j=0;
		$(".memberstudent").find("input,select").each(function(){
		 		
				var name=$(this).attr("name");
				getstudentname.push(name);
				if($(".memberstudent ."+name).val()==""){
				//$(".memberstudent ."+name).addClass('errclass');
				//$(".edit-err-notify").text("Please fill required fields");
				j++;} 
				else{ i++; }
				
		 });
		
		if(i==getstudentname.length && getstudentname.length>0)
		 {
			 
			 $(".memberstudent").find("input,select").each(function(){
		 		
				getstudent.push($.trim($(this).val()));
				
		     });
			 
			regex   = new RegExp('^[a-zA-Z0-9 #][a-zA-Z0-9\n\.,-_/#:&() ]{3,250}$');
			valid = regex.test(maddress1);
			if(maddress1 !="" && !valid){ $(".memberstudent .address1edit").addClass('errclass');$(".edit-err-notify").text("Invalid Address Line1"); getstudent=[];getstudentname=[];return;}
			
			/*regex   = new RegExp('^[a-zA-Z0-9#][a-zA-Z0-9\n\.,-_/#:&() ]{3,250}$');
			valid = regex.test(maddress2);
			if(maddress2!="" && !valid){ $(".memberstudent .address2edit").addClass('errclass');$(".edit-err-notify").text("Invalid Address Line2"); getstudent=[];getstudentname=[];return;}*/
	
			var regex = /^[a-zA-Z ]*$/;
			valid = regex.test(mcity);
			if(mcity !="" && !valid){ $(".memberstudent .cityedit").addClass('errclass');$(".edit-err-notify").text("Invalid City"); getstudent=[];getstudentname=[];return;}
			
			var regex = /^[0-9]*$/;
			valid = regex.test(mpincode);
			if(mpincode !="" && !valid){ $(".memberstudent .pincodeedit").addClass('errclass').val("");$(".edit-err-notify").text("Invalid Pincode"); getstudent=[];getstudentname=[];return;}

		 }
		 else if(j>0)
		 {
			 if(mname==""){ $(".memberstudent .nameedit").addClass('errclass');$(".edit-err-notify").text("Invalid name"); getstudent=[];getstudentname=[]; return;}
		
		if(maddress1==""){ $(".memberstudent .address1edit").addClass('errclass');$(".edit-err-notify").text("Invalid Address Line1"); getstudent=[];getstudentname=[];return;}
         
		 if(mcity==""){ $(".memberstudent .cityedit").addClass('errclass');$(".edit-err-notify").text("Invalid City");getstudent=[];getstudentname=[];return;}
		
		if(mpincode==""){ $(".memberstudent .pincodeedit").addClass('errclass').val("");$(".edit-err-notify").text("Invalid Pincode");getstudent=[];getstudentname=[];return;}
		
		 }
		 
		//Faculty
		var mname = $(".memberfaculty .nameedit").val();
		var maddress1 = $(".memberfaculty .address1edit").val();
		var maddress2 = $(".memberfaculty .address2edit").val();
		var mcity = $(".memberfaculty .cityedit").val();
		var mstate = $(".memberfaculty .stateedit").val();
		var mpincode = $(".memberfaculty .pincodeedit").val();
		var mdesignation = $(".memberfaculty .designationedit").val();

		var i=0;
		var j=0;
		$(".memberfaculty").find("input,select").each(function(){
		 		
				var name=$(this).attr("name");
				getfacultyname.push($(this).val());
				if($(".memberfaculty ."+name).val()==""){
				//$(".memberfaculty ."+name).addClass('errclass');
				//$(".edit-err-notify").text("Please fill required fields");
				j++;} 
				else{ i++;}
				
		 });
		
		if(i==getfacultyname.length && getfacultyname.length>0)
		 {
			 
			 $(".memberfaculty").find("input,select").each(function(){
		 		
				getfaculty.push($.trim($(this).val()));
				
		     });
			 
		 	 regex   = new RegExp('^[a-zA-Z0-9 #][a-zA-Z0-9\n\.,-_/#:&() ]{3,250}$');
			valid = regex.test(maddress1);
			if(maddress1 !="" && !valid){ $(".memberfaculty .address1edit").addClass('errclass');$(".edit-err-notify").text("Invalid Address Line1"); getfaculty=[];getfacultyname=[];return;}
			
			/*regex   = new RegExp('^[a-zA-Z0-9#][a-zA-Z0-9\n\.,-_/#:&() ]{3,250}$');
			valid = regex.test(maddress2);
			if(maddress2!="" && !valid){ $(".memberfaculty .address2edit").addClass('errclass');$(".edit-err-notify").text("Invalid Address Line2"); getfaculty=[];getfacultyname=[];return;}*/
	
			var regex = /^[a-zA-Z ]*$/;
			valid = regex.test(mcity);
			if( mcity !="" && !valid){ $(".memberfaculty .cityedit").addClass('errclass');$(".edit-err-notify").text("Invalid City"); getfaculty=[];getfacultyname=[];return;}
			
			var regex = /^[0-9]*$/;
			valid = regex.test(mpincode);
			if(mpincode !="" && !valid){ $(".memberfaculty .pincodeedit").addClass('errclass').val("");$(".edit-err-notify").text("Invalid Pincode"); getfaculty=[];getfacultyname=[];return;}
			
		 }
		 else if(j>0)
		 {
			 if(mdesignation==""){ $(".memberfaculty .designationedit").addClass('errclass');$(".edit-err-notify").text("Invalid Designation"); getfacultyname=[]; return;}
			 
			  if(mname==""){ $(".memberfaculty .nameedit").addClass('errclass');$(".edit-err-notify").text("Invalid name"); getfacultyname=[]; return;}
		
		if(maddress1==""){ $(".memberfaculty .address1edit").addClass('errclass');$(".edit-err-notify").text("Invalid Address Line1"); getfacultyname=[];return;}
         
		 if(mcity==""){ $(".memberfaculty .cityedit").addClass('errclass');$(".edit-err-notify").text("Invalid City");getfacultyname=[];return;}
		
		if(mpincode==""){ $(".memberfaculty .pincodeedit").addClass('errclass');$(".edit-err-notify").text("Invalid Pincode");getfacultyname=[];return;}
			 
			 }
			 
		var mname = $(".memberpractitioner .nameedit").val();
		var maddress1 = $.trim($(".memberpractitioner .address1edit").val());
		var maddress2 = $(".memberpractitioner .address2edit").val();
		var mcity = $(".memberpractitioner .cityedit").val();
		var mstate = $(".memberpractitioner .stateedit").val();
		var mpincode = $(".memberpractitioner .pincodeedit").val();
		var mdesignation = $(".memberpractitioner .designationedit").val();
		var mlandline = $(".memberpractitioner .lnumberedit").val();
		var mmobile = $(".memberpractitioner .mnumberedit").val();
		var mgeo = $(".memberpractitioner .clinicgeoedit").val();
		var mclinictiming = $(".memberpractitioner .clinictimeedit").val();
		
        $(".memberpractitioner .mapon,.membercontent1 .mapon").html("");
         
		var mstudent = String(getstudent);
		var mfaculty = String(getfaculty);


       //Practitioner
		var i=0;
		var j=0;
		$(".membercontent1").find("input").each(function(){
		 		
				var name=$(this).attr("name");
				getname.push(name);
				if($(".membercontent1 ."+name).val()==""){
				$(".membercontent1 ."+name).addClass('errclass');
				$(".edit-err-notify").text("Please fill required fields");
				j++;} 
				else{ i++;}
				
		 });
		 
		 if(i==getname.length && getname.length>0)
		 {
			 $(".membercontent1").find("input,select").each(function(){
		 		
				getcontent.push($.trim($(this).val()));
				
		 });
		 }
		 else if(j>0){ getname=[]; return; }
		 
		if(getcontent.length >0 )
		{
			var count=getcontent.length/10;
					console.log(getcontent);
					
			for(var i=0;i<count;i++)
			{ 
				
				 var j=i*10;
				 mname += "|"+getcontent[j];
				 maddress1 += "|"+getcontent[j+1];
				 maddress2 += "|"+getcontent[j+2];
				 mcity += "|"+getcontent[j+3];
				 mstate += "|"+getcontent[j+4];
				 mpincode += "|"+getcontent[j+5];
				 mlandline += "|"+getcontent[j+6];
				 mmobile += "|"+getcontent[j+7];
				 mgeo += "|"+getcontent[j+8];
				 mclinictiming += "|"+getcontent[j+9];
				
			}
		      
		}else if(jQuery.inArray("Practitioner", mtype)!='-1')
		{
		
		if(mname==""){ $(".memberpractitioner .nameedit").addClass('errclass');$(".edit-err-notify").text("Invalid name");return;}
		
		if(maddress1==""){ $(".memberpractitioner .address1edit").addClass('errclass');$(".edit-err-notify").text("Invalid Address Line1");return;}

		regex   = new RegExp('^[a-zA-Z0-9 #][a-zA-Z0-9\n\.,-_/#:&() ]{3,250}$');
        valid = regex.test(maddress1);
        if(!valid){ $(".memberpractitioner .address1edit").addClass('errclass');$(".edit-err-notify").text("Invalid Address Line1");return;}
		
		/*regex   = new RegExp('^[a-zA-Z0-9#][a-zA-Z0-9\n\.,-_/#:&() ]{3,250}$');
        valid = regex.test(maddress2);
        if(maddress2!="" && !valid){ $(".memberpractitioner .address2edit").addClass('errclass');$(".edit-err-notify").text("Invalid Address Line2");return;}*/

        var regex = /^[a-zA-Z ]*$/;
        valid = regex.test(mcity);
        if(!valid){ $(".memberpractitioner .cityedit").addClass('errclass');$(".edit-err-notify").text("Invalid City");return;}
		
		if(mmobile==""){ $(".memberpractitioner .mnumberedit").addClass('errclass');$(".edit-err-notify").text("Invalid Mobile Number");return;}
						
		regex   = new RegExp('^[0-9 \-]{5,20}$');
        valid = regex.test(mlandline);
        if(mlandline!="" && !valid){ $(".memberpractitioner .lnumberedit").addClass('errclass');$(".edit-err-notify").text("Invalid Phone Number");return;}
		
		regex   = new RegExp('^[0-9 \-]{5,20}$');
        valid = regex.test(mmobile);
        if(!valid && mmobile!=""){ $(".memberpractitioner .mnumberedit").addClass('errclass');$(".edit-err-notify").text("Invalid Mobile Number");return;}
         
		 if(mclinictiming==""){ $(".memberpractitioner .clinictimeedit").addClass('errclass');$(".edit-err-notify").text("Invalid Clinic Timing");return;}


        if(mpincode==""){ $(".memberpractitioner .pincodeedit").addClass('errclass');$(".edit-err-notify").text("Invalid Pincode");return;}
		
		}
         
		$(".edit-err-notify").html("<font style=\"color:#44f2f8\">Processing...</font>");
               $.get('editprofile/updateProfile',{
                       'mobile':mobile,
                       'phone':phone,
                       'email':email,
					   'gender':gender,
					   'dob':dob,
					   'address':address,
					   'contactaddress':contactaddress,
					   'contactstate':contactstate,
					   'contactpin':contactpin,
					   'qualification':qualification,
					   'college':college,
					   'designation':designation,
					   'clinic':clinic,
					   'clinicphone':clinicphone,
					   'membertype':membertype,
					   'mstudent':mstudent,
					   'mfaculty':mfaculty,
					   'mname':mname,
					   'maddress1':maddress1,
					   'maddress2':maddress2,
					   'mcity':mcity,
					   'mstate':mstate,
					   'mpincode':mpincode,
					   'mdesignation':mdesignation,
					   'mlandline':mlandline,
					   'mmobile':mmobile,
					   'mgeo':mgeo,
					   'mclinictiming':mclinictiming,
				   		   'sameaddress':sameaddress,
						   'address2':address2,
						   'city':city,
						   'state':state,
						   'pincode':pincode,
				   		   'contactaddress2':contactaddress2,
						   'contactcity':contactcity,
				   		   'pubsearch':pubsearch

                 }, function(o) {  $(".edit-err-notify").html("<font style=\"color:#44f2f8\">Profile Updated</font>"); 
                           setTimeout(function(){ location.assign("profile");}, 2000);         
                 }, 'json');
		
	});
	
	 $(".searchedit").click(function()
	 {
		 var parElement = $(this).parent();
		 
		 $(parElement).find("input").each(function(){
		 		if($(this).hasClass("selectedsearch")){
		 		 	$(this).removeClass("selectedsearch");
				}
		 });
		 
		 $(this).addClass("selectedsearch");
	 });
	 
	 <?php if($i>0){?>
	 
	 	var i=<?php echo $i; ?>;

	 <?php }else{?>
	 	var i=1;

	<?php }?>
	 $(document).on('click', ".addnewclinic .addclinic", function() 
	 {
		 $(".removeclinic").fadeIn();
				
				<?php if($i>0){ ?>
				$(".membercontent1").fadeIn().append("<p style='border-bottom:1px solid #bfbfbf;font-weight:800;'>Clinic  "+i+"</p>"+emptyfields);
				//alert(addcontent);
				
				<?php }else{?>
				$(".membercontent1").fadeIn().append("<p style='border-bottom:1px solid #bfbfbf;font-weight:800;'>Clinic  "+i+"</p>"+emptyfields);
				<?php }?>
		i++;
	 });
	 
	 $(document).on('click', ".removeclinic", function() 
	 {
		  i=1;
		 $(".membercontent1 p").remove();
		 $(this).fadeOut();
	 });
	 
	 $(document).on('click', ".memberpractitioner .showmap", function() {
		 
		 $(".mapon").toggle(function(){$(this).insertBefore(".memberpractitioner p:nth-child(10)").show(); });
		 
	 });
	 
	  $(document).on('click', ".membercontent1 .showmap", function() {
		 		
				var parelement=$(this).parent();
				 
		$(this).toggle(function(){$(".mapon").insertBefore(".membercontent1 p:nth-child(11)").show();});
		 
	 });
	 
	  $(document).on('click', ".membercontent1 .mapon .llselect,.memberpractitioner .mapon .llselect", function() { 		 
		$(".mapon").parent().find("input.clinicgeoedit").val($(".mapon .gllpLatitude").val()+"/"+$(".mapon .gllpLongitude").val());
		
		 $(".mapon").insertBefore(".mapinsert");
	 });
	 
	 $("#profile-right").find("input,select").each(function(){

          $(this).click(function(){ $(this).removeClass("errclass");$(".edit-err-notify").text("");});

     });
	 
	  $(document).on("focus","input,select",function(){ $(this).removeClass("errclass");$(".edit-err-notify").text("");});

$(".sameaddress").click(function(){
		  
		if($(this).is(':checked'))
			{
				$(".commaddress").fadeOut();
				
			}else
			{
				$(".commaddress").fadeIn();
			}
			
	 });
	
	var sameaddress = "<?php echo $memberprofile['sameaddress'];?>";
	var dob = "<?php echo $memberprofile['dob'];?>";
	
	if(sameaddress=="Yes"){
		$(".sameaddress").prop('checked',true);
		$(".commaddress").fadeOut();
	}else{
		$(".sameaddress").prop('checked',false);
		$(".commaddress").fadeIn();
	}
	
	dob = dob.split('-');
	
	var dobday = '<option value="">Day</option>';
	var dobmonth = '<option value="">Month</option>';
	var dobyear = '<option value="">Year</option>';
	
	for(var d=1;d<32;d++){
		
		var day = (d < 10 ? '0' : '') + d;
		if(dob[0]==day) var selected = "selected"; else var selected = "";
		dobday += '<option value="'+day+'" '+selected+'>'+day+'</option>';
		
	}
	$(".dobdayfield").html(dobday);
	
	var monthNames = ["","January","February","March","April","May","June","July","August","September","October","November","December"];
	for(var m=1;m<monthNames.length;m++){
		
		var mon = (m < 10 ? '0' : '') + m;
		if(dob[1]==mon) var selected = "selected"; else var selected = "";
		dobmonth += '<option value="'+mon+'" '+selected+'>'+monthNames[m]+'</option>';
		
	}
	$(".dobmonthfield").html(dobmonth);
	
	var currentTime = new Date();
	var curyear = currentTime.getFullYear();
	var firstYear = curyear - 80;
	var lastYear = firstYear + 63;
	for(var y=firstYear;y<lastYear;y++){
		
		if(dob[2]==y) var selected = "selected"; else var selected = "";
		dobyear += '<option value="'+y+'" '+selected+'>'+y+'</option>';
		
	}
	$(".dobyearfield").html(dobyear);

});
	
function isDate(txtDate)
{
    var currVal = txtDate;
    if(currVal == '')
        return false;
    
    var rxDatePattern = /^(\d{4})(\/|-)(\d{1,2})(\/|-)(\d{1,2})$/; //Declare Regex
    var dtArray = currVal.match(rxDatePattern); // is format OK?
    
    if (dtArray == null) 
        return false;
    
    //Checks for mm/dd/yyyy format.
    dtMonth = dtArray[3];
    dtDay= dtArray[5];
    dtYear = dtArray[1];        	
   
	if (dtMonth < 1 || dtMonth > 12) 
        return false;
    else if (dtDay < 1 || dtDay> 31) 
        return false;
    else if ((dtMonth==4 || dtMonth==6 || dtMonth==9 || dtMonth==11) && dtDay ==31) 
        return false;
    else if (dtMonth == 2) 
    {
        var isleap = (dtYear % 4 == 0 && (dtYear % 100 != 0 || dtYear % 400 == 0));
        if (dtDay> 29 || (dtDay ==29 && !isleap)) 
                return false;
    }
	
    return true;
}
</script>
<script src="<?php echo base_url();?>js/map.js"></script>
<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>css/jquery-gmaps-latlon-picker.css"/>
<script src="<?php echo base_url();?>js/jquery-gmaps-latlon-picker.js"></script>
<style>
.gllpLatlonPicker	{ margin: 20px 0; }

.code			{ margin: 20px 0; font-size: 0.9em; width: 600px; font-family: "Monofur", courier; background-color: #555; padding: 15px; box-shadow: #f6f6f6 1px 1px 3px; color: #999; }
</style>
<div id="profile-left">

	<img class="proimg" src="<?php echo base_url();?>docs/profile/<?php echo $membername['profileimg'];?>" width="140" height="160" />
    <a href="changephoto"><div id="changepic">Change Picture</div></a>
    
    <ul>
    
    	<a href="home"><li>Recent Activity</li></a>
        
        <a href="profile"><li>Profile</li></a>
        
        <a href="bio"><li>Bio</li></a>
        
        <a href="connectionlist"><li>Find a Connection</li></a>
        
        <a href="messageinbox"><li>Messages</li></a>
        
        <a href="communitylist"><li>Communities</li></a>
        
        <?php if($membername['role']=="STUDENT"){ ?><a href="upgrademembership"><li>Upgrade Membership</li></a><?php } ?>
    
    </ul>

</div>

<div id="profile-right">

	<h1>Dr. <?php echo $membername['name'];?><br /><span style="font-size:12px">Membership ID: <?php echo $membername['userid']; ?></span></h1>
    
    <div class="right-options">
    
    	<button class="updateprofile" id="editbut">Update</button><br />
        <p style="margin:0px; text-align:right; color:#fff;display: inline-block;" class="edit-err-notify"></p>
    
    </div>
    
    <div class="clear"></div>

	<div id="profile-titles">
    
    	<h2>Contact Details</h2>
    
    </div>
    
    <div id="profile-content">
    
    	<p><span>Mobile <font color="#990000">*</font></span><input class="update-text-box mobileedit" value="<?php if($memberprofile['mobile']!=""){ echo $memberprofile['mobile'];}else{ echo ""; } ?>" /><span1>eg: 9876543210</span1></p>
        
        <p><span>Landline</span><input class="update-text-box phoneedit" value="<?php if($memberprofile['phone']!=""){ echo $memberprofile['phone'];}else{ echo ""; } ?>" /><span1>eg: 044-12345678</span1></p>
   
   		<p><span>Email <font color="#990000">*</font></span><input class="update-text-box emailedit" value="<?php if($memberprofile['email']!=""){ echo $memberprofile['email'];}else{ echo ""; } ?>" /><span1>eg: info@example.com</span1></p>
    
    </div>
    
    <div style="clear:both; height:30px;"></div>
    
    <div id="profile-titles">
    
    	<h2>Personal Details</h2>
    
    </div>
    
    <div id="profile-content">
    
    	<p><span>Gender</span><input type="radio" class="register-radio genderedit" name="sex" value="Male" <?php if($memberprofile['gender']=="Male"){ echo "checked";}else{ echo ""; } ?> />
	<label>Male</label>
<input type="radio" class="register-radio genderedit" name="sex" value="Female" <?php if($memberprofile['gender']=="Female"){ echo "checked";}else{ echo ""; } ?> />
	<label>Female</label></p>
   
   		<p><span>DOB</span>
   		<select class="register-select dobdayfield" name="dobday"></select>
<select class="register-select dobmonthfield" name="dobmonth"></select>
<select class="register-select dobyearfield" name="dobyear"></select></p>
	</div>
       
   <div style="clear:both; height:30px;"></div>
   
    <div id="profile-titles">
    
    	<h2>Residential Address</h2>
    
    </div>
    
    <div id="profile-content">
            
        <p><span>Address Line 1</span><input class="update-text-box resaddressedit" value="<?php if($memberprofile['address']!=""){ echo $memberprofile['address'];}else{ echo ""; } ?>" /><span1>max. 250 chars</span1></p>
        
        <p><span>Address Line 2</span><input class="update-text-box resaddressedit2" value="<?php if($memberprofile['address2']!=""){ echo $memberprofile['address2'];}else{ echo ""; } ?>" /><span1>max. 250 chars</span1></p>
        
        <p><span>City</span><input class="update-text-box rescityedit" value="<?php if($memberprofile['city']!=""){ echo $memberprofile['city'];}else{ echo ""; } ?>" /></p>
        
        <p><span>State</span><input class="update-text-box resstateedit" value="<?php if($memberprofile['state']!=""){ echo $memberprofile['state'];}else{ echo ""; } ?>" /></p>
        
        <p><span>Pincode</span><input class="update-text-box respincodeedit" value="<?php if($memberprofile['pincode']!=""){ echo $memberprofile['pincode'];}else{ echo ""; } ?>" /></p>
    
    </div>
    
    <div style="clear:both; height:30px;"></div>
    
    <div id="profile-titles">
    
    	<h2>Communication Address</h2>
    	    
    </div>
    
    <div id="profile-content">
    
    	<p class="sameadbox"><input type="checkbox" class="register-text-box sameaddress" name="sameaddress" /><label>Same as Residential Address</label></p>
    
    	<p class="commaddress"><span>Address Line 1</span><input class="update-text-box contactaddressedit1" value="<?php if($memberprofile['contactaddress']!=""){ echo $memberprofile['contactaddress'];}else{ echo ""; } ?>" /><span1>max. 250 chars</span1></p>
      
      <p class="commaddress"><span>Address Line 2</span><input class="update-text-box contactaddressedit2" value="<?php if($memberprofile['contactaddress2']!=""){ echo $memberprofile['contactaddress2'];}else{ echo ""; } ?>" /><span1>max. 250 chars</span1></p>
       
       <p class="commaddress"><span>City</span><input class="update-text-box contactcityedit" value="<?php if($memberprofile['contactcity']!=""){ echo $memberprofile['contactcity'];}else{ echo ""; } ?>" /></p>
        
        <p class="commaddress"><span>State</span><input class="update-text-box contactstateedit" value="<?php if($memberprofile['contactstate']!=""){ echo $memberprofile['contactstate'];}else{ echo ""; } ?>" /></p>
        
        <p class="commaddress"><span>Pincode</span><input class="update-text-box contactpinedit" value="<?php if($memberprofile['contactpin']!=""){ echo $memberprofile['contactpin'];}else{ echo ""; } ?>" /></p>
    
    </div>
    
    <div style="clear:both; height:30px;"></div>
    
    <div id="profile-titles">
    
    	<h2>Member</h2>
    
    </div>
    
    <div id="profile-content">
    
    	<p><span>Type <font color="#990000">*</font></span>
        <input type="checkbox"  style="background: #fff;border: 1px solid #1977a6;border-radius: 5px;width: 20px; height: 20px;padding: 0 5px;color: #171717;vertical-align: middle;" class="membertypeedit"  value="Student" <?php if($mtype[0]!="" && $mtype[0]=="Student"){ echo "checked";}else{ echo ""; } ?>/>Student
        
        <input type="checkbox" style="background: #fff;border: 1px solid #1977a6;border-radius: 5px;width: 20px; height: 20px;padding: 0 5px;color: #171717;vertical-align: middle;" class="membertypeedit" value="Faculty" <?php if($mtype[0]=="Faculty"){ echo "checked";}elseif(isset($mtype[1])){if($mtype[1]=="Faculty"){ echo "checked";}}else{ echo ""; } ?>/>Faculty
        
        <input type="checkbox" style="background: #fff;border: 1px solid #1977a6;border-radius: 5px;width: 20px; height: 20px;padding: 0 5px;color: #171717;vertical-align: middle;" class="membertypeedit" value="Practitioner" <?php if($mtype[0]=="Practitioner"){ echo "checked";}if(isset($mtype[1])){if($mtype[1]=="Practitioner"){ echo "checked";}}if(isset($mtype[2])){if($mtype[2]=="Practitioner"){ echo "checked";}}else{ echo ""; } ?>/>Practitioner
        </p>
      		    
    </div>
    
    <div id="profile-content" class="memberstudent">
    </div>
    <div id="profile-content" class="memberfaculty">
    </div>
    <div id="profile-content" class="clinicname">
    <p style='border-bottom:1px solid #bfbfbf;font-weight:800;'>Clinic</p>
    </div>
    <div id="profile-content" class="memberpractitioner">
    </div>
    <div id="profile-content" class="membercontent1">
    </div>
    
    <div id="profile-content" class="addnewclinic">
    <p style="width:92px;"><a style="cursor:pointer;" class="update-text-box addclinic" >Add Clinic>></a></p>
    <p style="width: 420px;float: right;margin: -35px;"><span></span><a style="cursor:pointer;" class="update-text-box removeclinic" >Remove Clinic<<</a></p>
    </div>
    <div id="mapinsert">
    <div class="mapon">
    <?php
    if($mtypecheck==$mpract && strpos($memberprofile['mname'], '|') !== false)
	{
		$mgeo=explode('|',$memberprofile['mgeo']);
		$geoexp=explode('/',$mgeo[0]); 
	}
	else
	{
		if($memberprofile['mgeo']!="" && $memberprofile['mgeo']!="/"){
		
		$mgeo=$memberprofile['mgeo'];
		$geoexp=explode('/',$mgeo); 
	     }
	}
	?>
    <fieldset class="gllpLatlonPicker">
		<input type="text" class="gllpSearchField">
		<input type="button" class="gllpSearchButton" value="search">
		<br/><br/>
		<div class="gllpMap">Google Maps</div>
		<br/>
		lat/lon:
			<input type="text" class="gllpLatitude" value="23.40276490540795"/>
			/
			<input type="text" class="gllpLongitude" value="78.486328125"/>
		<input type="hidden" class="gllpZoom" value="3"/>
		<input type="hidden" class="gllpUpdateButton" value="update map">
        <input type="button" class="llselect" value="OK">
		<br/>
	</fieldset>
    </div>
    </div>
    <div style="clear:both; height:30px;"></div>
    
    <div id="profile-titles">
    
    	<h2>Account Settings</h2>
    
    </div>
    
    <div id="profile-content">
    
    	<p><span>Public Search</span>
        <input type="radio" value="1" name="pubsearch" <?php if($memberprofile['search']=="1"){ echo "checked class='searchedit selectedsearch'";}else{ echo "class='searchedit'";}?>> Turn On 
        <input type="radio" value="0" name="pubsearch" <?php if($memberprofile['search']=="0"){ echo "checked class='searchedit selectedsearch'";}else{ echo "class='searchedit'";}?>> Turn Off
        </p>
      		    
    </div>
    
    <div style="clear:both; height:30px;"></div>

</div> 
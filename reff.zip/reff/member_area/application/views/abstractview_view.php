
<script type="text/javascript">
$(document).ready(function(){	

	$('a.popcertificate').click(function (e) {
		
		e.preventDefault();
		
		var scrolltop = $(window).scrollTop()+50;
		var imglink = $(this).attr('href');
		var ext = imglink.split('.').pop().toLowerCase();
		
		if(ext!="pdf" && ext!="docx" && ext!="doc")
		{
			var img = $('<img />', { 
			  src: imglink,
			});
			$('#divLargerImage').html(img.clone().height('auto').width('50%')).css({'top':scrolltop}).add($('#divOverlay')).fadeIn();
		}
		else
		{
			window.open(imglink,'_blank');
		}
	});
	
	
	$('#divLargerImage').add($('#divOverlay')).click(function () {
		$('#divLargerImage').add($('#divOverlay')).fadeOut(function () {
			$('#divLargerImage').empty();
		});
	});

	
	
	
});
</script>

<style>
	#profile-content span{display: inline-block;float: none;vertical-align: middle;height: auto;}
	#profile-content span1{display: inline-block;vertical-align: middle;width: 450px;}
</style>

<div id="profile-left">
	
	<img class="proimg" src="<?php echo $this->config->item('web_url');?>images/ap.jpg" />

	<ul>
    
    	<a href="javascript:history.go(-1)"><li>Back</li></a>
    	
    </ul>  

</div>

<div id="profile-right">

	<h1><?php if($abstractprofile['name']!=""){ echo $abstractprofile['name'];}else{ echo ""; } ?></h1>   
    
    <div class="right-options">
    
        
    </div>    
    
    <div class="clear" style="height:30px;"></div>
    
    <div id="profile-titles">
    
    	<h2>Membership Details</h2>
    
    </div>
    
    <div id="profile-content">
            
        <p><span>Registration No</span><span1 style="color:#333"><?php if($abstractprofile['regno']!=""){ echo $abstractprofile['regno'];}else{ echo "-"; } ?></span1></p>
                
        <p><span>IACDE ID</span><span1 style="color:#333"><?php if($abstractprofile['iacdeno']!=""){ echo $abstractprofile['iacdeno'];}else{ echo "-"; } ?></span1></p>
    
    </div>
    
    <div style="clear:both; height:30px;"></div>

	<div id="profile-titles">
    
    	<h2>Contact Details</h2>
    
    </div>
    
    <div id="profile-content">
    
    	<p><span>Mobile</span><span1 style="color:#333"><?php if($abstractprofile['mobile']!=""){ echo $abstractprofile['mobile'];}else{ echo "-"; } ?></span1></p>
           
        <p><span>Email</span><span1 style="color:#333"><?php if($abstractprofile['email']!=""){ echo $abstractprofile['email'];}else{ echo "-"; } ?></span1></p>
    
    </div>
    
    <div style="clear:both; height:30px;"></div>
    
    <div id="profile-titles">
    
    	<h2>Abstract Details</h2>
    
    </div>
    
     <div id="profile-content">
       
   		<p><span>Registration category</span><span1 style="color:#333"><?php if($abstractprofile['regcategory']!=""){ echo $abstractprofile['regcategory'];}else{ echo "-"; } ?></span1></p>
        
        <p><span>Institution/ Affiliation</span><span1 style="color:#333"><?php if($abstractprofile['institution']!=""){ echo $abstractprofile['institution'];}else{ echo "-"; } ?></span1></p>
        
        <p><span>Bonafide certificate</span><span1 style="color:#333"><?php if($abstractprofile['bcert']!=""){ echo '<a class="popcertificate" style="margin:5px auto;text-decoration: underline;" href="'.base_url().'docs/abstract/'.$abstractprofile['regno'].'/'.$abstractprofile['bcert'].'">Click to view</a>';}else{ echo "-"; } ?></span1></p>
        
        <p><span>Presentation category</span><span1 style="color:#333"><?php if($abstractprofile['pcategory']!=""){ echo $abstractprofile['pcategory'];}else{ echo "-"; } ?></span1></p>
        
        <p><span>Subject</span><span1 style="color:#333"><?php if($abstractprofile['subject']!=""){ echo $abstractprofile['subject'];}else{ echo "-"; } ?></span1></p>
        
        <p><span>Type of Presentation</span><span1 style="color:#333"><?php if($abstractprofile['ptype']!=""){ echo $abstractprofile['ptype'];}else{ echo "-"; } ?></span1></p>
        
        <p><span>Title</span><span1 style="color:#333"><?php if($abstractprofile['title']!=""){ echo $abstractprofile['title'];}else{ echo "-"; } ?></span1></p>
        
        <p><span>Authors</span><span1 style="color:#333"><?php if($abstractprofile['authors']!=""){ echo $abstractprofile['authors'];}else{ echo "-"; } ?></span1></p>
        
        <p><span>Abstract</span><span1 style="color:#333"><?php if($abstractprofile['abstract']!=""){ echo $abstractprofile['abstract'];}else{ echo "-"; } ?></span1></p>
        
        <p><span>Photos of Presenter(s)</span><span1 style="color:#333"><?php if($abstractprofile['photo']!=""){ echo '<a class="popcertificate" style="margin:5px auto;text-decoration: underline;" href="'.base_url().'docs/abstract/'.$abstractprofile['regno'].'/'.$abstractprofile['photo'].'">Click to view</a>';}else{ echo "-"; } ?></span1></p>
        
        <p><span>Comments</span><span1 style="color:#333"><?php if($abstractprofile['comments']!=""){ echo $abstractprofile['comments'];}else{ echo "-"; } ?></span1></p>        
        
    
    </div> 
    
    <div style="clear:both; height:30px;"></div>
    


</div>
   
   
<div id="divLargerImage"></div>

<div id="divOverlay"></div>   
  
 
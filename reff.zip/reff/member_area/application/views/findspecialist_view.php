
<script type="text/javascript">
$(document).ready(function(){	
		
	$(".findview").click(function(){
		
		var memid = $(this).attr("id");
        		
		window.location.href = "<?php  echo base_url(); ?>memberpage?id="+memid;		
		
	});
	
	
	
});
</script>


<h1 style="text-align:center; font-size:20px; color:#171717;">Find a Specialist</h1>
   
   <div id="findpage">
   

     <table id="findpage-table">
     
     	<tr class="find-title"><td width="200">Name</td><td width="100">Mobile</td><td>Address</td><td width="75" class="findview">Profile</td></tr>
        
         <?php echo $specialist['list']; ?>
     
     </table>
     
    
   
   </div>


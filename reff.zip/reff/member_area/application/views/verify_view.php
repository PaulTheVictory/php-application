
<script type="text/javascript">
$(document).ready(function(){	
	
	$(".enmail").hide();
	$(".resend").click(function(){
		
		var memberid = "<?php echo $memberid;?>";
		var name = "<?php echo $membername['name'];?>";
		var baseUrl = "<?php echo base_url();?>";
		
				$.get(baseUrl+'verify/SendCode',{
					   'memberid':memberid, 
					   'name':name

				}, function(o) { //console.log(o);
					var obj1 = $.parseJSON(o);
					if(obj1[0] == 'failed'){
						setTimeout(function(){ $(".errnotify").html("Activation Code Not Send.Please try again."); }, 500);				
					}else if(obj1[0] == 'success'){
						setTimeout(function(){ $(".errnotify").addClass("success").html("Activation Code Send Successfully."); }, 500);
												
					}else if(obj1[0] == ''){
						setTimeout(function(){ $(".errnotify").html("Please try again later."); }, 2000);						
					}
				});	
			
	});
	
	var anothermail=$('.anothermail #newmail').prop('checked');
	       
	   $('.anothermail #newmail').click(function() {
		if(this.checked == true) 
		{  
		   $(".enmail").fadeIn();
		   $(".enmail1").hide();
		}
		else
		{
			$(".enmail").hide();
			$(".enmail1").fadeIn();
		}
});
	   
	
	$(".sendmail").click(function(){
		
		var memberid = "<?php echo $memberid;?>";
		var name = "<?php echo $membername['name'];?>";
		var email = $("#email").val();
		var baseUrl = "<?php echo base_url();?>";
		
		if(email==""){$(".errnotify").text("Invalid Email");return;}
		
		regex   = new RegExp('^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$');
        valid = regex.test(email);
        if(!valid){$(".errnotify").text("Invalid Email");return;}
		
		
		$.get(baseUrl+'verify/SendMail',{
					   'memberid':memberid, 
					   'name':name,
					   'email':email

				}, function(o) { //console.log(o);
					var obj1 = $.parseJSON(o);
					if(obj1[0] == 'failed'){
						setTimeout(function(){ $(".errnotify").html("Mail Not Send.Please try again."); }, 500);				
					}else if(obj1[0] == 'updated'){
						
						$.get(baseUrl+'verify/SendCode',{
					   'memberid':memberid, 
					   'name':name

				}, function(o) { //console.log(o);
					var obj1 = $.parseJSON(o);
					if(obj1[0] == 'failed'){
						setTimeout(function(){ $(".errnotify").html("Activation Code Not Send.Please try again."); }, 500);				
					}else if(obj1[0] == 'success'){
						setTimeout(function(){ $(".errnotify").addClass("success").html("Mail and Activation Code Send Successfully."); }, 500);
							setInterval(function(){ window.location.reload(true); }, 4000);					
					}else if(obj1[0] == ''){
						setTimeout(function(){ $(".errnotify").html("Please try again later."); }, 2000);						
					}
				});	
												
					}else if(obj1[0] == ''){
						setTimeout(function(){ $(".errnotify").html("Please try again later."); }, 2000);						
					}
				});	
		
	});
	
});
</script>
<style>

#verifypage{
	width: 360px;
    margin: 20px auto;
    border: 1px solid #1977a6;
    border-radius: 10px;
    color: #171717;
    text-align: left;
    padding: 33px 12px 50px;}

#announcement{
	background: #372f83;
	background: -moz-linear-gradient(top,  #372f83 0%, #110c40 100%);
	background: -webkit-gradient(linear, left top, left bottom, color-stop(0%,#372f83), color-stop(100%,#110c40));
	background: -webkit-linear-gradient(top,  #372f83 0%,#110c40 100%);
	background: -o-linear-gradient(top,  #372f83 0%,#110c40 100%);
	background: -ms-linear-gradient(top,  #372f83 0%,#110c40 100%);
	background: linear-gradient(to bottom, #372f83 0%,#110c40 100%);
	filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#372f83', endColorstr='#110c40',GradientType=0 );
	color:#fff;
	font-size:16px;
	height:20px;
	line-height:20px;
	padding:10px 0;
	margin:10px 0;
}
	
	#content-inner .memberverify p{text-align: center;}
</style>
<?php if($memberprofile['email']!=""){?>
<div id="announcement">
	<div class="wrap">

		<marquee>Please Check Your <?php if($memberprofile['email']!=""){ echo $memberprofile['email'];}else{ echo ""; } if($memberprofile['mobile']!=""){ echo " or ".$memberprofile['mobile'];}else{ echo ""; } ?> to get verification code.</marquee>
        
	</div>
</div>
<?php }?>
<div style="float:left; margin:50px auto;width:100%;" class="memberverify">

<h1 style="text-align:center; font-size:20px; color:#171717;">MEMBER VERIFICATION</h1>
   
   <?php echo validation_errors(); ?>


    <?php 
	if(isset($_GET['code']))
	{
		$code=$_GET['code'];
	}
	else
	{
		$code="";
	}
	
	/*if($memberprofile['email']!="")
	{*/
	?>
       <?php echo form_open('verifycode'); ?>

     <div id="verifypage" class="enmail1">
     
        
        	<span width="85">Enter Verification Code</span>
            
            <span><input class="login-text" type="text" id="verifycode" name="verifycode" value="<?php echo $code;?>"/></span>
        
           <input id="loginbut" class="resend" type="button" value="Resend"/><input id="loginbut" type="submit" value="Verify"/>
     
     </div>
     
     <!--<div id="verifypage" class="anothermail">     	            
     <input id="newmail" type="checkbox" name="newmail"/>Send Verification code to another Email id?
     </div>
     
     <div id="verifypage" class="enmail">
     
        
        	<span width="85">Enter Your Email ID:</span>
            
            <span><input class="login-text" type="text" id="email" name="email" value=""/></span>
        
           <input id="loginbut" class="sendmail" type="button" value="send"/>
     
     </div>-->
     <?php /*?><?php }else{ ?>
     
     <div id="verifypage">
     
        
        	<span width="85">Enter Your Email ID:</span>
            
            <span><input class="login-text" type="text" id="email" name="email" value=""/></span>
        
                	            
           <input id="loginbut" class="sendmail" type="button" value="send"/>
     
     </div>
     <?php }?><?php */?>
     <span class="errnotify">&nbsp;</span>
   </form>

</div>


<div style="clear:both"></div>


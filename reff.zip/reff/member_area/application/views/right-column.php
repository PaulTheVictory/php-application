			<div class="clear"></div>
          
        </div>
        
        <div class="hcright">
 
             <div class="item">
                
                <h3>Upcoming CDE</h3>
                
                <p><a target="_blank" href="#">» Advanced Cosmetic Dentistry Work shop - 11th Nov 2106 at Kolkata</a></p>

            </div> 
            
            <div class="item">
                
                <h3>Annual Meet of IACDE</h3>
                
                <p><a target="_blank" href="#">» December in Bangalore</a></p>

            </div> 
        
        </div>
    
    </div>

</div>

<script type="text/javascript">
$(document).ready(function(){	

  	$(".forgettable").hide();
	
	$(".forgetpass").click(function(){
		if($(".forgettable").hasClass("show")){
			$(".forgettable").hide();
			$(".forgettable").removeClass("show");
		}else{
			$(".forgettable").show();
			$(".forgettable").addClass("show");
		}
				
	});
	
	$(".forgetsubmit").click(function(){
		
		var fuserid = $("#fuserid").val();
		var femailid = $("#femailid").val();
		var flogintype = $("#flogintype").val();
		
		if(fuserid==""){ alert("Enter Valid User ID");return;}
		
		if(femailid==""){ alert("Enter Valid Email ID");return;}
		
		if(flogintype==""){ alert("Select Login Type");return;}
		
		window.location.href = "<?php echo $this->config->item('web_url');?>forgetpass.php?ui="+fuserid+"&ei="+femailid+"&lt="+flogintype;
		
	});
	
	
});
</script>


<style>
@media screen and (max-width:1200px) {
	
.log_btn {	
    width: fit-content !important;
    
    margin: 10px auto 30px 0 !important;
    
   float: none !important;
   
     top: 0 !important; 
    display: inline-block !important;
    right: 0px !important;
    
}	
	
	
	
}


</style>

<div style="float:left; margin:auto;width: 100%;">

<h1 style="text-align:center; font-size:20px; color:#171717;">MEMBER LOGIN</h1>
   
   <?php echo validation_errors(); ?>

   <?php echo form_open('verifylogin'); ?>

     <table id="loginpage">
     
     	<tr>
        
        	<td width="85">User ID</td>
            
            <td><input class="login-text" type="text" id="username" name="username"/></td>
        
        </tr>
        
        <tr>
        
        	<td>Password</td>
            
            <td><input class="login-text" type="password" id="passowrd" name="password"/></td>
        
        </tr>
        
        <tr>
                	            
            <td colspan="2" style="text-align:right;"><input id="loginbut" type="submit" value="Login"/></td>
        
        </tr>
     
     </table>
     
   </form>
   
   <a href="<?php echo base_url();?>knowmember" class="log_btn" style="background-color: #aeca20;width: 15%;height: auto;padding:8px;border: none;margin: 9px 5px;cursor: pointer;float: right;text-align: center;color: #fff;position: relative;font-size: 14px;top: -165px;right: 120px;border-radius: 5px;">Know Your Member ID ?</a>

</div>

<!--<div style="float:left; margin:10px 0px;">

<h1 style="text-align:center; font-size:20px; color:#171717;">COLLEGE LOGIN</h1>
   
   <?php //echo validation_errors(); ?>

   <?php //echo form_open('collegelogin'); ?>

     <table id="loginpage">
     
     	<tr>
        
        	<td width="85">User ID</td>
            
            <td><input class="login-text" type="text" id="username" name="username"/></td>
        
        </tr>
        
        <tr>
        
        	<td>Password</td>
            
            <td><input class="login-text" type="password" id="passowrd" name="password"/></td>
        
        </tr>
        
        <tr>
                	            
            <td colspan="2" style="text-align:right;"><input id="loginbut" type="submit" value="Login"/></td>
        
        </tr>
     
     </table>
     
   </form>

</div>-->

<div style="clear:both"></div>

<div style="margin:10px auto;">

<p style="text-align:center;">Signing in for the first time? Type your Membership ID for the Username and Password</p>

<h1 style="text-align:center; font-size:14px; color:#171717; cursor:pointer" class="forgetpass">Forget Password ?</h1>
   
    
   
    <table id="loginpage" class="forgettable">
     
     	<tr>
        
        	<td width="85">User ID</td>
            
            <td><input class="login-text" type="text" id="fuserid" name="fuserid"/></td>
        
        </tr>
        
        <tr>
        
        	<td>Email ID</td>
            
            <td><input class="login-text" type="text" id="femailid" name="femailid"/></td>
        
        </tr>
        
        <tr>
        
        	<td>Login Type</td>
            
            <td><select class="login-text" id="flogintype" name="flogintype" style="padding:5px; width:180px;"><option>Member</option><option>College</option></select></td>
        
        </tr>
        
        <tr>
                	            
            <td colspan="2" style="text-align:right;"><button id="loginbut" class="forgetsubmit">Submit</button></td>
        
        </tr>
     
     </table>
     
   

</div>

<script type="text/javascript">
$(document).ready(function(){
	
	$(".addmember").click(function(){
		
		var approveid = $(".approveid").val();
		var title = $(".title:checked").val();
		var name = $(".nameadd").val();
		var userid = $(".memidadd").val();
		//var role = $(".roleadd").val();
		var mobile = $(".mobileadd").val();
        var phone = $(".phoneadd").val();
        var email = $(".emailadd").val();
		var gender = $(".sexfield:checked").val();
		var address = $(".resaddressadd1").val();
		var organisation = $(".qualadd").val();
		var designation = $(".desigadd").val();
		var age = $(".ageadd").val();
		var city = $(".rescityadd").val();
		var state = $(".resstateadd").val();
		var pincode = $(".respincodeadd").val();
		
		var payamount = $(".payamount").val();
		var paymode = $(".paymode").val();
		var payid = $(".payid").val();
		var paydate = $(".paydate").val();	
					
		regex   = new RegExp('^[a-zA-Z][a-zA-Z\.-/ ]{3,40}$');
		valid = regex.test(name);
		if(!valid || name==""){ $(".nameadd").addClass('errclass');$(".edit-err-notify").text("Invalid Member Name");return;}
		
		if(userid==""){ $(".memidadd").addClass('errclass');$(".edit-err-notify").text("Invalid Member ID");return;}
				
		//if(role==""){ $(".roleadd").addClass('errclass');$(".edit-err-notify").text("Invalid Role");return;}
			
		regex   = new RegExp('^[0-9 \-]{5,20}$');
        valid = regex.test(mobile);
        if(!valid && mobile!=""){ $(".mobileadd").addClass('errclass');$(".edit-err-notify").text("Invalid Mobile Number");return;}
		
		regex   = new RegExp('^[0-9 \-]{5,20}$');
        valid = regex.test(phone);
        if(!valid && phone!=""){ $(".phoneadd").addClass('errclass');$(".edit-err-notify").text("Invalid Phone Number");return;}
		
		regex   = new RegExp('^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$');
        valid = regex.test(email);
        if(!valid && email!=""){ $(".emailadd").addClass('errclass');$(".edit-err-notify").text("Invalid Email");return;}
		
		if(gender!="Male" && gender!="Female" && gender!=""){ $(".genderadd").addClass('errclass');$(".edit-err-notify").text("Invalid Gender");return;}		
		
		if(payamount==""){ $(".payamount").addClass('errclass');$(".edit-err-notify").text("Enter Payment Amount");return;}
		
		if(paymode=="Choose"){ $(".paymode").addClass('errclass');$(".edit-err-notify").text("Select Payment Mode");return;}
		
		$(".edit-err-notify").html("<font style=\"color:#f7d8ba\">Processing...</font>");
                 $.get('preconfapprovemember/preconfapproveMemberRequest',{
					   'approveid':approveid,
					   'name':name, 
					 'title':title,
					   'userid':userid,
					   //'role':role,
                       'mobile':mobile,
                       'phone':phone,
                       'email':email,
					   'gender':gender,
					 'age':age,
					   'address':address,
					   'organisation':organisation,
					   'designation':designation,
					   'payamount':payamount,
					   'paymode':paymode,
					   'payid':payid ,
					 'paydate':paydate,
						   'city':city,
						   'state':state,
						   'pincode':pincode,

                 }, function(o) { 
				 		var obj1 = $.parseJSON(o);
						if(obj1[0] == 'success'){
				 			$(".edit-err-notify").html("<font style=\"color:#f7d8ba\">Preconference Member Profile Approved</font>"); 
                            setTimeout(function(){ location.assign("preconfregistrants");}, 2000);  
						}else if(obj1[0] == ''){
							setTimeout(function(){ $(".edit-err-notify").html("<font style=\"color:#f7d8ba\">Please Try again later.</font>"); }, 2000);
						}
                 }); 
		
		
	});
	
		
	 $("#profile-right").find("input").each(function(){

          $(this).click(function(){ $(this).removeClass("errclass");$(".edit-err-notify").text("");});

     });
	 
	 $(".deletemember").click(function(){
		 
		var confid = $(".approveid").val();
		 
		var r=confirm("Are you sure to delete ?")
		if (r==true){
  			$(".edit-err-notify").html("<font style=\"color:#f7d8ba\">Processing...</font>");
                 $.get('preconfapprovemember/deletePreconfMemberRequest',{
                       'confid':confid			   

                 }, function(o) {  $(".edit-err-notify").html("<font style=\"color:#f7d8ba\">Preconference Member Request Deleted</font>"); 
                           setTimeout(function(){ location.assign("preconfregistrants");}, 2000);         
                 }, 'json');
				 
  		}
		 
	 });
	
	$('a.popcertificate').click(function (e) {
		
		e.preventDefault();
		
		var scrolltop = $(window).scrollTop()+50;
		var imglink = $(this).attr('href');
		var ext = imglink.split('.').pop().toLowerCase();
		
		if(ext!="pdf" && ext!="docx" && ext!="doc")
		{
			var img = $('<img />', { 
			  src: imglink,
			});
			$('#divLargerImage').html(img.clone().height('auto').width('50%')).css({'top':scrolltop}).add($('#divOverlay')).fadeIn();
		}
		else
		{
			window.open(imglink,'_blank');
		}
	});
	
	
	$('#divLargerImage').add($('#divOverlay')).click(function () {
		$('#divLargerImage').add($('#divOverlay')).fadeOut(function () {
			$('#divLargerImage').empty();
		});
	});
	
	var paydate = "<?php echo $approvedetails['paymentdate']?>";
	
	$('.paydate').datepicker("setDate", paydate );
	$('.paydate').datepicker({dateFormat: 'dd-mm-yy',maxDate: '0'});
	
});

</script>

<style>
	.update-text-box.title {width: auto;vertical-align: middle;}
</style>

<div id="profile-left">

	<img class="proimg" src="<?php echo $this->config->item('web_url');?>images/ap.jpg" />
    
    <ul>
    
    	<a href="home"><li>Dashboard</li></a>
        
        <a href="allusers"><li>View Users</li></a>
        
        <a href="searchusers"><li>Search Users</li></a>
        
        <a href="exportdata"><li>Export Data</li></a>
        
        <a href="newmember"><li>Add Member</li></a>
        
        <a href="admincommunity"><li>Community</li></a>
        
        <!--<a href="addcollege"><li>Add College</li></a>
        
        <a href="collegelist"><li>College List</li></a>-->

        <a href="subjects"><li>Question Papers</li></a>
        
        <a href="notices"><li>Add Notifications</li></a>
        
        <a href="confregistrants"><li>Conference Registrants</li></a>
        
        <a href="preconfregistrants"><li>Preconference</li></a>
        
        <a href="testregistrants"><li>Test Registrants</li></a>
        
        <a href="abstracts"><li>Abstracts</li></a>
    
    </ul>

</div>

<div id="profile-right">

	<h1>Dr. <?php echo $membername['name']; ?><br /><span style="font-size:12px">Membership ID: admin</span></h1>
    
    <div class="right-options">
    
    	<button class="addmember" id="addmembut">Approve</button><button class="deletemember" id="addmembut" style="margin-right:10px;">Delete</button><br />
        <p style="margin:15px 0 0; text-align:right; color:#fff;" class="edit-err-notify"></p>
    
    </div>
    
    <div class="clear"></div>

	<h2>Preconfernece Approve Member</h2> 
       
    <div id="profile-titles">
    
    	<h2>Preconference</h2>
    
    </div>
    
    <div id="profile-content">
            
        <p><span>Name</span><?php if($approvedetails['preconfname']!=""){ echo $approvedetails['preconfname'];}else{ echo "-"; } ?></p>
    
    </div> 
    
       <div class="clear" style="height:30px;"></div>

    
    <div id="profile-titles">
    
    	<h2>Membership Details</h2>
    
    </div>
    
    <div id="profile-content">
    
      	<input type="hidden" class="approveid" value="<?php if($approvedetails['id']!=""){ echo $approvedetails['id'];}else{ echo ""; } ?>" />
      	
      	<p><span>Title</span>
				 
			  <input type="radio" name="title" class="update-text-box title" value="Prof"/>Prof
			  <input type="radio" name="title" class="update-text-box title" value="Dr" checked />Dr
			  <input type="radio" name="title" class="update-text-box title" value="Mr"/>Mr
			  <input type="radio" name="title" class="update-text-box title" value="Ms"/>Ms
			  <input type="radio" name="title" class="update-text-box title" value="Mrs"/>Mrs
		</p>
    
    	<p><span>Name</span><input class="update-text-box nameadd" value="<?php if($approvedetails['name']!=""){ echo $approvedetails['name'];}else{ echo ""; } ?>" /></p>
        
        <p><span>Member ID</span><input class="update-text-box memidadd" value="<?php if($approvedetails['memberid']!=""){ echo $approvedetails['memberid'];}else{ echo ""; } ?>" /></p>
           
        <!--<p><span>Role</span><select class="update-text-box roleadd">
        
        	<?php
			
				/*$rolearr = "Delegates,Student";
				$rolearr = explode(",",$rolearr);
				$roleselect = '<option value="">Choose</option>';
				foreach ($rolearr as $rval) { 
					if($approvedetails['memtype']==$rval){
						$roleselect .= "<option selected>".$rval."</option>";
					}else{
						$roleselect .= "<option>".$rval."</option>";
					}	   				
				}
				echo $roleselect;*/
			
			?>
        
        </select></p>-->
            
    </div>
    
    <div style="clear:both; height:30px;"></div>
    
    <div id="profile-titles">
    
    	<h2>Contact Details</h2>
    
    </div>
    
    <div id="profile-content">
    
    	<p><span>Mobile</span><input class="update-text-box mobileadd" value="<?php if($approvedetails['mobile']!=""){ echo $approvedetails['mobile'];}else{ echo ""; } ?>" /><span1>eg: 9876543210</span1></p>
        
        <p><span>Landline</span><input class="update-text-box phoneadd" value="<?php if($approvedetails['phone']!=""){ echo $approvedetails['phone'];}else{ echo ""; } ?>" /><span1>eg: 044-12345678</span1></p>
   
   		<p><span>Email</span><input class="update-text-box emailadd" value="<?php if($approvedetails['email']!=""){ echo $approvedetails['email'];}else{ echo ""; } ?>" /><span1>eg: info@example.com</span1></p>
    
    </div>
    
     <div style="clear:both; height:30px;"></div>
    
    <div id="profile-titles">
    
    	<h2>Personal Details</h2>
    
    </div>
    
    <div id="profile-content">
    
    	<p><span>Gender</span><input type="radio" class="register-radio sexfield" name="sex" value="Male" <?php if($approvedetails['gender']=="Male"){ echo "checked";}else{ echo ""; } ?> />
	<label>Male</label>
<input type="radio" class="register-radio sexfield" name="sex" value="Female" <?php if($approvedetails['gender']=="Female"){ echo "checked";}else{ echo ""; } ?> />
	<label>Female</label></p>
  
  <p><span>Age</span><input class="update-text-box ageadd" value="<?php if($approvedetails['age']!=""){ echo $approvedetails['age'];}else{ echo ""; } ?>" /></p>
   
	</div>
   
    <div style="clear:both; height:30px;"></div>
    
    <div id="profile-titles">
    
    	<h2>Communication Address</h2>
    	    
    </div>
    
    <div id="profile-content">
        
    	<p><span>Address </span><input class="update-text-box resaddressadd1" value="<?php if($approvedetails['address']!=""){ echo $approvedetails['address'];}else{ echo ""; } ?>" /><span1>max. 250 chars</span1></p>
             
       <p><span>City</span><input class="update-text-box rescityadd" value="<?php if($approvedetails['contactcity']!=""){ echo $approvedetails['contactcity'];}else{ echo ""; } ?>" /></p>
        
        <p><span>State</span><input class="update-text-box resstateadd" value="<?php if($approvedetails['contactstate']!=""){ echo $approvedetails['contactstate'];}else{ echo ""; } ?>" /></p>
        
        <p><span>Pincode</span><input class="update-text-box respincodeadd" value="<?php if($approvedetails['contactpin']!=""){ echo $approvedetails['contactpin'];}else{ echo ""; } ?>" /></p>
    
    </div> 
    
    <div style="clear:both; height:30px;"></div>
    
    <div id="profile-titles">
    
    	<h2>Official Details</h2>
    
    </div>
    
    <div id="profile-content">
    
        <p><span>Designation</span><input class="update-text-box desigadd" value="<?php if($approvedetails['designation']!=""){ echo $approvedetails['designation'];}else{ echo ""; } ?>" /></p>
        
    	<p><span>Organisation</span><input class="update-text-box qualadd" value="<?php if($approvedetails['organisation']!=""){ echo $approvedetails['organisation'];}else{ echo ""; } ?>" /></p>
              
       <!-- <p><span>Member Proof</span><span1 style="color:#333"><?php //if($approvedetails['proof']!=""){ echo '<a class="popcertificate" style="margin:5px auto;text-decoration: underline;" href="'.base_url().'docs/proof/'.$approvedetails['proof'].'">Click to view</a>';}else{ echo "-"; } ?></span1></p>
             
           <input type="hidden" name="proof" value="<?php //echo $approvedetails['proof'];?>" />-->
              
    </div> 
    
    <div style="clear:both; height:30px;"></div>
    
    <div id="profile-titles">
    
    	<h2>Payment Details</h2>
    
    </div>
    
    <div id="profile-content">
    
        <p><span>Payment Screenshot</span><span1 style="color:#333"><?php if($approvedetails['paymentphoto']!=""){ echo '<a class="popcertificate" style="margin:5px auto;text-decoration: underline;" href="'.base_url().'docs/transfer/'.$approvedetails['paymentphoto'].'">Click to view</a>';}else{ echo "-"; } ?></span1></p>
                  
           <input type="hidden" name="paymentphoto" value="<?php echo $approvedetails['paymentphoto'];?>" />
                   
    	<p><span>Payment Date</span><input class="update-text-box paydate datepicker" value="<?php if($approvedetails['paymentdate']!=""){ echo $approvedetails['paymentdate'];}else{ echo ""; } ?>" /></p>
    
      	<p><span>Payment Amount</span><input class="update-text-box payamount" value="<?php if($approvedetails['paymentamount']!=""){ echo $approvedetails['paymentamount'];}else{ echo ""; } ?>" /></p>
    
    	<p><span>Mode of Payment</span><select class="update-text-box paymode"><?php echo $approvedetails['paymentmode']; ?></select></p>
        
        <p><span>DD No/Txn Id</span><input class="update-text-box payid" value="<?php if($approvedetails['paymentid']!=""){ echo $approvedetails['paymentid'];}else{ echo ""; } ?>" /></p>
       
    </div>
    
    <div style="clear:both; height:30px;"></div>
        

</div>
     
   
<div id="divLargerImage"></div>

<div id="divOverlay"></div>   
 
<script type="text/javascript">
$(document).ready(function(){
	
	var fields=[];
	var editarr="<?php echo $memberprofile['mtype'];?>";
	var editmember=editarr.split(',');//alert(editmember);
	$(".clinicname").hide();
	<?php 

     $mstudent=array("","","","","","");
	 $mfaculty=array("","","","","","",""); 
	 if($memberprofile['mstudent']!="")
	 {
		 $mstudent=explode(',',$memberprofile['mstudent']);
		 
	 }
	 if($memberprofile['mfaculty']!="")
	 {
		 $mfaculty=explode(',',$memberprofile['mfaculty']);
		 
	 }
?>
var studentfields='<p><span>College Name</span><?php if($mstudent[0]!=""){ echo $mstudent[0];}else{ echo "-"; } ?></p><p><span>College Address Line 1 </span><?php if($mstudent[1]!=""){ echo $mstudent[1];}else{ echo "-"; } ?></p><p style="display:none;"><span>College Address Line 2</span><?php if($mstudent[2]!=""){ echo $mstudent[2];}else{ echo "-"; } ?></p><p><span>City </span><?php if($mstudent[3]!=""){ echo $mstudent[3];}else{ echo "-"; } ?></p><p><span>State</span><?php if($mstudent[4]!=""){ echo $mstudent[4];}else{ echo "-"; } ?></p><p><span>Pincode</span><?php if($mstudent[5]!=""){ echo $mstudent[5];}else{ echo "-"; } ?></p>';

var facultyfields='<p><span>College Name </span><?php if($mfaculty[1]!=""){ echo $mfaculty[1];}else{ echo "-"; } ?></p><p><span>College Address Line 1 </span><?php if($mfaculty[2]!=""){ echo $mfaculty[2];}else{ echo "-"; } ?></p><p style="display:none;"><span>College Address Line 2</span><?php if($mfaculty[3]!=""){ echo $mfaculty[3];}else{ echo "-"; } ?></p><p><span>City </span><?php if($mfaculty[4]!=""){ echo $mfaculty[4];}else{ echo "-"; } ?></p><p><span>State</span><?php if($mfaculty[5]!=""){ echo $mfaculty[5];}else{ echo "-"; } ?></p><p><span>Pincode </span><?php if($mfaculty[6]!=""){ echo $mfaculty[6];}else{ echo "-"; } ?></p>';

	<?php 
	      $mtype=array("");
		 $mtypecheck="Practitioner";
		 $mpract="";
		 if($memberprofile['mtype']!="" && strpos($memberprofile['mname'], ',') !== false)
		 {
			 $mtype=explode(',',$memberprofile['mtype']);
			 
		 }else{ $mtype =array($memberprofile['mtype']); }
		 
		 	 if($mtype[0]=="Practitioner"){ $mpract="Practitioner";}
			 if(isset($mtype[1])){if($mtype[1]=="Practitioner"){ $mpract="Practitioner";}}
			 if(isset($mtype[2])){if($mtype[2]=="Practitioner"){ $mpract="Practitioner";}}else{  $mpract=""; }
		$i=0;
		if(strpos($memberprofile['mname'], '|') !== false)
	     {
		$mname=explode('|',$memberprofile['mname']);
		$maddress1=explode('|',$memberprofile['maddress1']);
		$maddress2=explode('|',$memberprofile['maddress2']);
		$mcity=explode('|',$memberprofile['mcity']);
		$mstate=explode('|',$memberprofile['mstate']);
		$mpincode=explode('|',$memberprofile['mpincode']);
		$mlandline=explode('|',$memberprofile['mlandline']);
		$mmobile=explode('|',$memberprofile['mmobile']);
		$mgeo=explode('|',$memberprofile['mgeo']);
		$mclinictiming=explode('|',$memberprofile['mclinictiming']);
		
			
		for($i=0;$i<count($mname);$i++)
		{
			
		 if($i>0) $cname='<p style="border-bottom:1px solid #bfbfbf;font-weight:800;">Clinic  '.$i.'</p>'; else  $cname="";
		?>
	
	 fields.push('<?php echo $cname;?><p><span>College Name</span><?php if($mname[$i]!=""){ echo $mname[$i];}else{ echo "-"; } ?></p><p><span>College Address Line 1</span><?php if($maddress1[$i]!=""){ echo $maddress1[$i];}else{ echo "-"; } ?></p><p style="display:none;"><span>College Address Line 2</span><?php if($maddress2[$i]!=""){ echo $maddress2[$i];}else{ echo "-"; } ?></p><p><span>City</span><?php if($mcity[$i]!=""){ echo $mcity[$i];}else{ echo "-"; } ?></p><p><span>State</span><?php if($mstate[$i]!=""){ echo $mstate[$i];}else{ echo "-"; } ?></p><p><span>Pincode</span><?php if($mpincode[$i]!=""){ echo $mpincode[$i];}else{ echo "-"; } ?></p>');
	
	
   if($.inArray( "Student", editmember )!='-1')
	{
		$('.memberstudent').html("<p style='border-bottom:1px solid #bfbfbf;font-weight:800;'>Student</p>"+studentfields);
	}
	if($.inArray( "Faculty", editmember )!='-1')
	{
		$('.memberfaculty').html('<p style="border-bottom:1px solid #bfbfbf;font-weight:800;">Faculty</p><p><span>Designation</span><?php if($mfaculty[0]!=""){ echo $mfaculty[0];}else{ echo "-"; } ?></p>').append(facultyfields);
	}
	if($.inArray( "Practitioner", editmember )!='-1')
	{
		$(".clinicname").fadeIn();
		$('.membercontent').append(fields[<?php echo $i;?>]).append('<p><span>Landline Number</span><?php if($mlandline[$i]!=""){ echo $mlandline[$i];}else{ echo "-"; } ?>"</p><p><span>Mobile Number</span><?php if($mmobile[$i]!=""){ echo $mmobile[$i];}else{ echo "-"; } ?></p><p><span>Geo Location</span><?php if($mgeo[$i]!=""){ echo $mgeo[$i];}else{ echo "-"; } ?></p><p><span>Clinic Timing</span><?php if($mclinictiming[$i]!=""){ echo $mclinictiming[$i];}else{ echo "-"; } ?></p>');
		
				$(".membercontent").find("p:nth-child(1) span").text("Cilnic Name");
				$(".membercontent").find("p:nth-child(2) span").text("Clinic Address Line 1");
				$(".membercontent").find("p:nth-child(3) span").text("Clinic Address Line 2");

	}
	
	<?php }}else{?>
	
	var fields='<p><span>College Name</span><?php if($memberprofile['mname']!=""){ echo $memberprofile['mname'];}else{ echo "-"; } ?></p><p><span>College Address Line 1</span><?php if($memberprofile['maddress1']!=""){ echo $memberprofile['maddress1'];}else{ echo "-"; } ?></p><p style="display:none;"><span>College Address Line 2</span><?php if($memberprofile['maddress2']!=""){ echo $memberprofile['maddress2'];}else{ echo "-"; } ?></p><p><span>City</span><?php if($memberprofile['mcity']!=""){ echo $memberprofile['mcity'];}else{ echo "-"; } ?></p><p><span>State</span><?php if($memberprofile['mstate']!=""){ echo $memberprofile['mstate'];}else{ echo "-"; } ?></p><p><span>Pincode</span><?php if($memberprofile['mpincode']!=""){ echo $memberprofile['mpincode'];}else{ echo "-"; } ?></p>';
	
 if($.inArray( "Student", editmember )!='-1')
	{
		$('.memberstudent').html("<p style='border-bottom:1px solid #bfbfbf;font-weight:800;'>Student</p>"+studentfields);
	}
	if($.inArray( "Faculty", editmember )!='-1')
	{
		$('.memberfaculty').html('<p style="border-bottom:1px solid #bfbfbf;font-weight:800;">Faculty</p><p><span>Designation</span><?php if($mfaculty[0]!=""){ echo $mfaculty[0];}else{ echo "-"; } ?></p>').append(facultyfields);
	}
	if($.inArray( "Practitioner", editmember )!='-1')
	{
		$(".clinicname").fadeIn();
		$('.membercontent').html(fields).append('<p><span>Landline Number</span><?php if($memberprofile['mlandline']!=""){ echo $memberprofile['mlandline'];}else{ echo "-"; } ?></p><p><span>Mobile Number</span><?php if($memberprofile['mmobile']!=""){ echo $memberprofile['mmobile'];}else{ echo "-"; } ?></p><p><span>Geo Location</span><?php if($memberprofile['mgeo']!=""){ echo $memberprofile['mgeo'];}else{ echo "-"; } ?></p><p><span>Clinic Timing</span><?php if($memberprofile['mclinictiming']!=""){ echo $memberprofile['mclinictiming'];}else{ echo "-"; } ?></p>');
		
				$(".membercontent").find("p:nth-child(1) span").text("Cilnic Name");
				$(".membercontent").find("p:nth-child(2) span").text("Clinic Address Line 1");
				$(".membercontent").find("p:nth-child(3) span").text("Clinic Address Line 2");

	}
	
	<?php }?>
	
});
</script>
<div id="profile-left">

	<img class="proimg" src="<?php echo base_url();?>docs/profile/<?php echo $membername['profileimg']; ?>" width="140" height="160" />
        
    <ul>
    
    	<a href="home"><li>Recent Activity</li></a>
        
        <a href="profile"><li>Profile</li></a>
        
        <a href="bio"><li>Bio</li></a>
        
        <a href="connectionlist"><li>Find a Connection</li></a>
        
        <a href="messageinbox"><li>Messages</li></a>
        
        <a href="communitylist"><li>Communities</li></a>
        
        <?php if($membername['role']=="STUDENT"){ ?><a href="upgrademembership"><li>Upgrade Membership</li></a><?php } ?>
    
    </ul>

</div>

<div id="profile-right">

	<h1>Dr. <?php echo $membername['name']; ?><br /><span style="font-size:12px">Membership ID: <?php echo $membername['userid']; ?></span></h1>
    
    <div class="right-options">
    
    	<a href="editprofile"><button id="editbut">Edit</button></a>
    
    </div>
    
    <div class="clear"></div>

	<div id="profile-titles">
    
    	<h2>Contact Details</h2>
    
    </div>
    
    <div id="profile-content">
    
    	<p><span>Mobile</span><?php if($memberprofile['mobile']!=""){ echo $memberprofile['mobile'];}else{ echo "-"; } ?></p>
        
        <p><span>Landline</span><?php if($memberprofile['phone']!=""){ echo $memberprofile['phone'];}else{ echo "-"; } ?></p>
   
   		<p><span>Email</span><?php if($memberprofile['email']!=""){ echo $memberprofile['email'];}else{ echo "-"; } ?></p>
    
    </div>
    
    <div style="clear:both; height:30px;"></div>
    
    <div id="profile-titles">
    
    	<h2>Personal Details</h2>
    
    </div>
    
    <div id="profile-content">
    
    	<p><span>Gender</span><?php if($memberprofile['gender']!=""){ echo $memberprofile['gender'];}else{ echo "-"; } ?></p>
   
   		<p><span>DOB</span><?php if($memberprofile['dob']!=""){ echo $memberprofile['dob'];}else{ echo "-"; } ?></p>
            
    </div>
    
    <div style="clear:both; height:30px;"></div>
    
     <div id="profile-titles">
    
    	<h2>Residential Details</h2>
    
    </div>
    
    <div id="profile-content">
               
        <p><span>Address Line 1</span><?php if($memberprofile['address']!=""){ echo $memberprofile['address'];}else{ echo "-"; } ?></p>
        
        <p><span>Address Line 2</span><?php if($memberprofile['address2']!=""){ echo $memberprofile['address2'];}else{ echo "-"; } ?></p>
        
         <p><span>City</span><?php if($memberprofile['city']!=""){ echo $memberprofile['city'];}else{ echo "-"; } ?></p>
        
        <p><span>State</span><?php if($memberprofile['state']!=""){ echo $memberprofile['state'];}else{ echo "-"; } ?></p>
        
        <p><span>Pincode</span><?php if($memberprofile['pincode']!=""){ echo $memberprofile['pincode'];}else{ echo "-"; } ?></p>
    
    </div>
    
     <div style="clear:both; height:30px;"></div>
    
    <div id="profile-titles">
    
    	<h2>Communication Details</h2>
    
    </div>
    
     <div id="profile-content" class="sameaddress">
    
    	<p><span>Same as Residental Address</span> <?php if($memberprofile['sameaddress']!=""){ echo $memberprofile['sameaddress'];}else{ echo "-"; } ?></p>
        
       </div>
    
    <div id="profile-content" class="commaddress">
           
        <p><span>Address Line 1</span><?php if($memberprofile['contactaddress']!=""){ echo $memberprofile['contactaddress'];}else{ echo "-"; } ?></p>
        
        <p><span>Address Line 2</span><?php if($memberprofile['contactaddress2']!=""){ echo $memberprofile['contactaddress2'];}else{ echo "-"; } ?></p>
        
        <p><span>City</span><?php if($memberprofile['contactcity']!=""){ echo $memberprofile['contactcity'];}else{ echo "-"; } ?></p>
        
        <p><span>State</span><?php if($memberprofile['contactstate']!=""){ echo $memberprofile['contactstate'];}else{ echo "-"; } ?></p>
        
        <p><span>Pincode</span><?php if($memberprofile['contactpin']!=""){ echo $memberprofile['contactpin'];}else{ echo "-"; } ?></p>
    
    </div>
    
    
    <div style="clear:both; height:30px;"></div>
    
    <div id="profile-titles">
    
    	<h2>Member</h2>
    
    </div>
     <div id="profile-content" class="memberstudent">
    </div>
    <div id="profile-content" class="memberfaculty">
    </div>
    <div id="profile-content" class="clinicname" >
    <p style='border-bottom:1px solid #bfbfbf;font-weight:800;'>Clinic</p>
    </div>
    <div id="profile-content" class="membercontent">
    </div>
    
    <div style="clear:both; height:30px;"></div>
    
    <div id="profile-titles">
    
    	<h2>Account Settings</h2>
    
    </div>
    
    <div id="profile-content">
    
    	<p><span>Public Search</span><?php if($memberprofile['search']=="1"){ echo "Enabled";}else{ echo "Disabled"; } ?></p>
        
        <p><span>Date of Joining</span><?php if($membername['doj']!=""){ echo $membername['doj'];}else{ echo "-"; } ?></p>
      		    
    </div>
    
    <div style="clear:both; height:5px;"></div>
    
    <a href="changepassword" style="float:right; margin:10px; text-decoration:underline; font-size:12px;">Change Password</a>
    
    <div style="clear:both; height:30px;"></div>
   	

</div>
   
   
   
  
 
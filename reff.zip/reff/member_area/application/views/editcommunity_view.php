
<script type="text/javascript">
$(document).ready(function(){	
		
	$(".savecomm").click(function(){
		
		var editname = $(".editname").val();
        var editdesc = $(".editdesc").val();
		var commid = "<?php echo $commid; ?>";
								
		$(".edit-err-notify").html("<font style=\"color:#44f2f8\">Processing...</font>");
                 $.get('editcommunity/editCommunity',{
                       'editname':editname,
                       'editdesc':editdesc,
					   'commid':commid			   

                 }, function(o) {  $(".edit-err-notify").html("<font style=\"color:#44f2f8\">Community Edited</font>"); 
                          
                 }, 'json');
				 
	});	
	
	
});
</script>


<div id="community-left">

	<img class="comm-img" src="<?php echo $this->config->item('web_url');?>docs/communities/<?php echo $commdetails['profileimg']; ?>" width="140" height="160" />
    <a href="commchangephoto?id=<?php echo $commid; ?>"><div id="changepic">Change Picture</div></a>
    
    <ul>
    
    	<a href="communitypage?id=<?php echo $commid; ?>"><li>Back</li></a>
                    
    </ul>

</div>

<div id="community-right">

	<h1><?php echo $commdetails['name']; ?></h1>
    
    <div class="right-options" style="margin:5px 10px 0">
    	
        <?php
					
			if($isadmin['admin']=="1"){
					echo '<p style="margin:0 0 5px; text-align:right; color:#fff;">Hello, Admin</p><button class="savecomm" id="joincombut">Save</button><br />
        <p style="margin:15px 0 0; text-align:right; color:#fff;" class="edit-err-notify"></p>';
			}			
		
		?>
                            	    
    </div>
    
    <div class="clear"></div>
    
    <div id="profile-titles">
    
    	<h2>Community Name</h2>
    
    </div>
    
    <div id="profile-content">
    
    	<p><input class="create-text-box editname" value="<?php echo $commdetails['name']; ?>" /><span1>max. 100 characters</span1></p>
            
    </div>
    
    <div style="clear:both; height:30px;"></div>
    
    <div id="profile-titles">
    
    	<h2>Description</h2>
    
    </div>
    
    <div id="profile-content">
    
    	 <p><textarea class="create-textarea editdesc"><?php if($commdetails['desc']!=""){ echo $commdetails['desc']; }else{ echo ""; } ?></textarea><span1>max. 250 characters</span1></p>
    
    </div>
    
    <div style="clear:both; height:30px;"></div>
           
    

</div>
   
   
   
  
 
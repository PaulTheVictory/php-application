
<script type="text/javascript">
$(document).ready(function(){	
	
	$(".check").click(function(){
		
		var memberid = "<?php echo $memberid;?>";
		var card = $("input[name=card]:checked").val();
		var certificate = $("input[name=certificate]:checked").val();
		var baseUrl = "<?php echo base_url();?>";
		
				
				$.get(baseUrl+'verify/checkmember',{
					   'memberid':memberid, 
					   'card':card,
					   'certificate':certificate

				}, function(o) { //console.log(o);
					var obj1 = $.parseJSON(o);
					if(obj1[0] == 'failed'){
						setTimeout(function(){ $(".errnotify").html("Details not submitted.Please try again."); }, 500);				
					}else if(obj1[0] == 'success'){
						setTimeout(function(){ $(".errnotify").addClass("success").html("Details submitted."); }, 500);
						setInterval(function(){ location.assign("profileedit");}, 5000);
												
					}else if(obj1[0] == ''){
						setTimeout(function(){ $(".errnotify").html("Please try again later."); }, 2000);						
					}
				});	
			
	});
	
		
});
</script>
<style>

#verifypage{
	width: 360px;
    margin: 20px auto;
    border: 1px solid #1977a6;
    border-radius: 10px;
    color: #171717;
    text-align: left;
    padding: 33px 12px 50px;}

</style>
<div style="float:left; margin:50px 130px;width:650px;">

<h1 style="text-align:center; font-size:20px; color:#171717;">MEMBER DETAIL CHECK</h1>
   
     <div id="verifypage" >
     
        
        	<span width="85">Do you have ID card?</span>
            
            <span><input class="" type="radio" class="card" name="card" value="YES"/>Yes
             <input class="" type="radio" class="card" name="card" value="NO" checked/></span>No
            <br>
            <br>
            <span width="85">Do you have member certificate?</span>
            
            <span><input class="" type="radio" class="certificate" name="certificate" value="YES"/>Yes
             <input class="" type="radio" class="certificate" name="certificate" value="NO" checked/></span>No
        
           <input id="loginbut" class="check" type="button" value="submit"/>
     
     </div>

     <span class="errnotify">&nbsp;</span>
   </form>

</div>


<div style="clear:both"></div>


<script type="text/javascript">
$(document).ready(function(){	
	
	if(document.URL.indexOf("#")==-1)
	{
		// Set the URL to whatever it was plus "#".
		url = document.URL+"#";
		location = "#";

		//Reload the page
		location.reload(true);
	}
		
	$("#fileToUpload").change(function(){
		
		var imgloc = $(this).val();
				
		$(".fakeinput").text(imgloc);
		
	});
	
	
	
});
</script>

<script src="<?php echo $this->config->item('web_url');?>js/jquery.Jcrop.js"></script>
<link rel="stylesheet" href="<?php echo $this->config->item('web_url');?>css/jquery.Jcrop.css" type="text/css" />

<script type="text/javascript">

  $(function(){

    $('#cropbox').Jcrop({
      aspectRatio: 0.875,
      onSelect: updateCoords
    });

  });

  function updateCoords(c)
  {
    $('#x').val(c.x);
    $('#y').val(c.y);
    $('#w').val(c.w);
    $('#h').val(c.h);
  };

  function checkCoords()
  {
    if (parseInt($('#w').val())) return true;
    alert('Please select a crop region then press submit.');
    return false;
  };
  
  function checkImageselect()
  {
    if ($(".fakeinput").text()=="Select image to upload"){
    	alert('Please select an image to upload');
    	return false;
	}else{
		return true;
	}
  };

</script>

<div id="profile-left">

	<img class="proimg" src="<?php echo base_url();?>docs/profile/<?php echo $membername['profileimg']; ?>" width="140" height="160" />
    
    <ul>
    
    	<a href="editmemberpage?id=<?php echo $memberid; ?>"><li>Back</li></a>
    
    </ul>

</div>

<div id="profile-right">

	<h1>Dr. <?php echo $membername['name']; ?><br /><span style="font-size:12px">Membership ID: <?php echo $membername['userid']; ?></span></h1>
    
    <div class="right-options">
    
    	
    
    </div>
    
    <div class="clear"></div>

	<h2>Select New Image</h2>
    
    <form enctype="multipart/form-data" method="post" action="<?php echo $this->config->item('web_url');?>upload.php" onsubmit="return checkImageselect();">
    
      <input type="hidden" name="userid" value="<?php echo $membername['userid']; ?>" />
      <input type="hidden" name="role" value="<?php echo $role; ?>" />
      <input type="hidden" name="memberid" value="<?php echo $memberid; ?>" />
    
      <input size="50" type="file" name="fileToUpload" id="fileToUpload" value="Select image to upload" style="position: relative;text-align: right;-moz-opacity:0 ;filter:alpha(opacity: 0);opacity: 0;z-index: 2; float:left; height:32px; width:402px;" /> 
      
      <div class="fakeinput" style="position:absolute; border:1px solid #aaa; width:400px; height:30px;border-radius:3px; line-height: 30px; text-align:left; padding-left:5px;">Select image to upload</div>
    
      <input style="margin-right:50px;" id="editbut" type="submit" value="Upload" />
    
  </form>
  
  <div style="clear:both; height:30px;"></div>
  <hr />
  
  	<h2>Crop Image</h2>
  
    <div style="width:600px; height:500px; overflow:auto; float:left; margin:0 10px;">
  		<img  id="cropbox" src="<?php echo base_url();?>docs/profile/<?php echo $membername['profileimg']; ?>" />
    </div>
        
        <form action="<?php echo $this->config->item('web_url');?>crop.php" method="post" onsubmit="return checkCoords();">
			<input type="hidden" id="x" name="x" />
			<input type="hidden" id="y" name="y" />
			<input type="hidden" id="w" name="w" />
			<input type="hidden" id="h" name="h" />
            <input type="hidden" name="profileimg" value="<?php echo $membername['profileimg']; ?>" />
            <input type="hidden" name="role" value="<?php echo $role; ?>" />
            <input type="hidden" name="memberid" value="<?php echo $memberid; ?>" />
			<input style="margin-right:50px;" type="submit" value="Crop" id="editbut" />
		</form>
        
    
    
    <div style="clear:both; height:30px;"></div>
    
      
      	

</div>
   
   
   
  
 
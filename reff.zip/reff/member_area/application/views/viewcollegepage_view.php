
<script type="text/javascript">
$(document).ready(function(){
	
	$(".editcollege").click(function(){
		
		var url = window.location.href;
		var n=url.lastIndexOf("=");
		
		var collegeid = url.slice(n+1);
		
		var name = $(".nameedit").val();
		var userid = $(".useridedit").val();
		var password = $(".passwordedit").val();
					
		if(name==""){ $(".nameedit").addClass('errclass');$(".edit-err-notify").text("Invalid College Name");return;}
		
		if(userid==""){ $(".useridedit").addClass('errclass');$(".edit-err-notify").text("Invalid User ID");return;}
					
		$(".edit-err-notify").html("<font style=\"color:#f7d8ba\">Processing...</font>");
                 $.get('viewcollegepage/updateCollege',{
					   'collegeid':collegeid,
					   'name':name, 
					   'userid':userid,
					   'password':password  

                 }, function(o) { 
				 		var obj1 = $.parseJSON(o);
						if(obj1[0] == 'success'){
				 			$(".edit-err-notify").html("<font style=\"color:#f7d8ba\">College Profile Updated</font>"); 
                            setTimeout(function(){ location.reload();}, 2000);  
						}else if(obj1[0] == ''){
							setTimeout(function(){ $(".edit-err-notify").html("<font style=\"color:#f7d8ba\">Please Try again later.</font>"); }, 2000);
						}
                 });	 
		
		
	});
	
		
	 $("#profile-right").find("input").each(function(){

          $(this).click(function(){ $(this).removeClass("errclass");$(".edit-err-notify").text("");});

     });
	 
	 $("#profile-right").find(".editstaff").each(function(){

          $(this).css("display","none");

     });
	 
	 $(".deletecollege").click(function(){
		 
		var url = window.location.href;
		var n=url.lastIndexOf("=");
		
		var collegeid = url.slice(n+1);
		 
		var r=confirm("Are you sure to delete ?")
		if (r==true){
  			$(".edit-err-notify").html("<font style=\"color:#f7d8ba\">Processing...</font>");
                 $.get('viewcollegepage/deleteCollege',{
                       'collegeid':collegeid			   

                 }, function(o) {  $(".edit-err-notify").html("<font style=\"color:#f7d8ba\">College Deleted</font>"); 
                           setTimeout(function(){ location.assign("collegelist");}, 2000);         
                 }, 'json');
				 
  		}
		 
	 });

});
</script>

<div id="profile-left">

	<img class="proimg" src="<?php echo $this->config->item('web_url');?>images/ap.jpg" />
    
    <ul>
    
    	<a href="home"><li>Dashboard</li></a>
        
        <a href="allusers"><li>View Users</li></a>
        
        <a href="searchusers"><li>Search Users</li></a>
        
        <a href="exportdata"><li>Export Data</li></a>
        
        <a href="newmember"><li>Add Member</li></a>
        
        <a href="admincommunity"><li>Community</li></a>
        
        <!--<a href="addcollege"><li>Add College</li></a>
        
        <a href="collegelist"><li>College List</li></a>-->

        <a href="subjects"><li>Question Papers</li></a>
    
    </ul>

</div>

<div id="profile-right">

	<h1>Dr. <?php echo $membername['name']; ?><br /><span style="font-size:12px">Membership ID: admin</span></h1>
    
    <div class="right-options">
    
    	<button class="editcollege" id="addmembut">Update</button><button class="deletecollege" id="addmembut" style="margin-right:10px;">Delete</button><br />
        <p style="margin:15px 0 0; text-align:right; color:#fff;" class="edit-err-notify"></p>
    
    </div>
    
    <div class="clear"></div>

	<h2>View College Details</h2> 
    
    <div id="profile-titles">
    
    	<h2>Login Details</h2>
    
    </div>
    
    <div id="profile-content">
    
      	<p><span>College Name</span><input class="update-text-box nameedit" value="<?php if($collegedetails['name']!=""){ echo $collegedetails['name'];}else{ echo ""; } ?>" /></p>
    
    	<p><span>User ID</span><input class="update-text-box useridedit" value="<?php if($collegedetails['userid']!=""){ echo $collegedetails['userid'];}else{ echo ""; } ?>" /></p>
        
        <p><span>Password</span><input class="update-text-box passwordedit" value="" /></p>
        
    </div>
    
    <div style="clear:both; height:30px;"></div>  
    
    <div id="profile-titles">
    
    	<h2>Contact Details</h2>
    
    </div>
    
    <div id="profile-content">
    
    	<p><span>Address</span><?php if($collegedetails['address']!=""){ echo $collegedetails['address'];}else{ echo "Nil"; } ?></p>
        
        <p><span>City</span><?php if($collegedetails['city']!=""){ echo $collegedetails['city'];}else{ echo "Nil"; } ?></p>
   
   		<p><span>State</span><?php if($collegedetails['state']!=""){ echo $collegedetails['state'];}else{ echo "Nil"; } ?></p>
        
        <p><span>Pincode</span><?php if($collegedetails['pincode']!=""){ echo $collegedetails['pincode'];}else{ echo "Nil"; } ?></p>
        
        <p><span>Contact Number</span><?php if($collegedetails['contactnumber']!=""){ echo $collegedetails['contactnumber'];}else{ echo "Nil"; } ?></p>
        
         <p><span>Email Address</span><?php if($collegedetails['email']!=""){ echo $collegedetails['email'];}else{ echo "Nil"; } ?></p>
    
    </div>
    
    <div style="clear:both; height:30px;"></div>
    
    <div id="profile-titles">
    
    	<h2>Other Details</h2>
    
    </div>
    
    <div id="profile-content">
    
      	<p><span>PG</span><?php if($collegedetails['pg']!=""){ echo $collegedetails['pg'];}else{ echo "Nil"; } ?></p>
        
    </div>
    
    <div style="clear:both; height:30px;"></div> 
    
    <div id="profile-titles">
    
    	<h2>Staff Members</h2>
    
    </div>
    
    <div id="profile-content">
    
    	<?php if($stafflist!=""){ echo $stafflist;}else{ echo '<p>Nil</p>'; } ?> 
    
    </div>
    
    <div style="clear:both; height:30px;"></div>  
    
     
    
    <div id="profile-titles">
    
    	<h2>List of Journals</h2>
    
    </div>
    
    <div id="profile-content">
    
    	<ul style="margin-top: 15px;">
        
        	<?php
				$count = count($collegedetails['journals']);
				if($collegedetails['journals'][0]!=""){
					for($i=0;$i<$count;$i++){
						echo '<li>'.$collegedetails['journals'][$i].'</li>';
					}
				}else{
					echo '<li style="list-style:none">Nil</li>';
				}
			
			?>
        	
        </ul>      
    
    </div>
    
    <div style="clear:both; height:30px;"></div> 
    
    <div id="profile-titles">
    
    	<h2>Current Events</h2>
    
    </div>
    
    <div id="profile-content">
    
    	<ul style="margin-top: 15px;">
        
        	<?php
				$count = count($collegedetails['events']);
				if($collegedetails['events'][0]!=""){
					for($i=0;$i<$count;$i++){
						echo '<li>'.$collegedetails['events'][$i].'</li>';
					}
				}else{
					echo '<li style="list-style:none">Nil</li>';
				}
			
			?>
        	
        </ul>      
    
    </div>
    
    <div style="clear:both; height:30px;"></div> 
           

</div>
   
   
   
  
 
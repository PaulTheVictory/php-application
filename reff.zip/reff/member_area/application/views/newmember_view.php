
<script type="text/javascript">
$(document).ready(function(){
	
	$(".addmember").click(function(){
		
		var name = $(".nameadd").val();
		var userid = $(".memidadd").val();
		var password = $(".passadd").val();
		var role = $(".selectedtype").val();
		var doj = $(".dojadd").val();
		var mobile = $(".mobileadd").val();
        var phone = $(".phoneadd").val();
        var email = $(".emailadd").val();
		var gender = $(".sexfield:checked").val();
		//var dob = $(".dobadd").val();
			var dobday = $(".dobdayfield").val();
			var dobmonth = $(".dobmonthfield").val();
			var dobyear = $(".dobyearfield").val();
		var address = $(".resaddressadd1").val();
		var address2 = $(".resaddressadd2").val();
		var city = $(".rescityadd").val();
		var state = $(".resstateadd").val();
		var pincode = $(".respincodeadd").val();
		var contactaddress1 = $(".contactaddressadd1").val();
		var contactaddress2 = $(".contactaddressadd2").val();
		var contactstate = $(".contactstateadd").val();
		var contactpin = $(".contactpinadd").val();
		var qualification = $(".qualadd").val();
		var college = $(".collegeadd").val();
		var designation = $(".desigadd").val();
		var clinic = $(".clinicaddadd").val();	
		var clinicphone = $(".clinicphoneadd").val();	
		
		var payamount = $(".payamount").val();
		var paymode = $(".paymode").val();
		var payid = $(".payid").val();
					
		regex   = new RegExp('^[a-zA-Z][a-zA-Z\.-/ ]{3,40}$');
		valid = regex.test(name);
		if(!valid || name==""){ $(".nameadd").addClass('errclass');$(".edit-err-notify").text("Invalid Member Name");return;}
		
		if(userid==""){ $(".memidadd").addClass('errclass');$(".edit-err-notify").text("Invalid Member ID");return;}
		
		if(password==""){ $(".passadd").addClass('errclass');$(".edit-err-notify").text("Invalid Password");return;}
		
		if(role==""||role==null){ $(".edit-err-notify").text("Invalid Role");return;}
			
		regex   = new RegExp('^[0-9 \-]{5,20}$');
        valid = regex.test(mobile);
        if(!valid && mobile!=""){ $(".mobileadd").addClass('errclass');$(".edit-err-notify").text("Invalid Mobile Number");return;}
		
		regex   = new RegExp('^[0-9 \-]{5,20}$');
        valid = regex.test(phone);
        if(!valid && phone!=""){ $(".phoneadd").addClass('errclass');$(".edit-err-notify").text("Invalid Phone Number");return;}
		
		regex   = new RegExp('^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$');
        valid = regex.test(email);
        if(!valid && email!=""){ $(".emailadd").addClass('errclass');$(".edit-err-notify").text("Invalid Email");return;}
		
		if(gender!="Male" && gender!="Female" && gender!=""){ $(".genderadd").addClass('errclass');$(".edit-err-notify").text("Invalid Gender");return;}
		
		/*regex   = new RegExp('^[0-9 \-]{10,10}$');
        valid = regex.test(dob);
        if(!valid && dob!=""){ $(".dobadd").addClass('errclass');$(".edit-err-notify").text("Invalid Date");return;}*/
		
		if(dobday=="" || dobmonth=="" || dobyear==""){ $(".dobdayfield,.dobmonthfield,.dobyearfield").addClass('errclass');$(".edit-err-notify").text("Invalid Date");return;}
	
		var dobdate = dobyear+'/'+dobmonth+'/'+dobday;
		var datevalid = isDate(dobdate);

		if(!datevalid) {
		  $(".dobdayfield,.dobmonthfield,.dobyearfield").addClass('errclass');
		  $(".edit-err-notify").text("Invalid Date of Birth");
		  return;
		}
	
		var dob = dobday+'-'+dobmonth+'-'+dobyear;
		
		regex   = new RegExp('^[a-zA-Z0-9#][a-zA-Z0-9\n\.,-_/#:& ]{3,250}$');
        valid = regex.test(address);
        if(!valid && address!=""){ $(".resaddressadd1").addClass('errclass');$(".edit-err-notify").text("Invalid Res. Address1");return;}
		
		regex   = new RegExp('^[a-zA-Z0-9#][a-zA-Z0-9\n\.,-_/#:& ]{3,250}$');
        valid = regex.test(address2);
        if(!valid && address2!=""){ $(".resaddressadd2").addClass('errclass');$(".edit-err-notify").text("Invalid Res. Address2");return;}
		
		var regex   = new RegExp('^[a-zA-Z][a-zA-Z\.-/ ]{3,100}$');
        valid = regex.test(city);
        if(!valid && city!=""){ $(".rescityadd").addClass('errclass');$(".edit-err-notify").text("Invalid Res. City");return;}
		
		var regex   = new RegExp('^[a-zA-Z][a-zA-Z\.-/ ]{3,100}$');
        valid = regex.test(state);
        if(!valid && state!=""){ $(".resstateadd").addClass('errclass');$(".edit-err-notify").text("Invalid Res. State");return;}
		
		regex   = new RegExp('^[0-9 \-]{4,10}$');
        valid = regex.test(pincode);
        if(!valid && pincode!=""){ $(".respincodeadd").addClass('errclass');$(".edit-err-notify").text("Invalid Pincode Number");return;}
		
		if($('.sameaddress').is(':checked'))
		{
			$(".commaddress").fadeOut();
			
			var contactaddress = address;
			var contactaddress2 = address2;
			var contactcity = city;
			var contactstate = state;
			var contactpin = pincode;
			
			var sameaddress = "Yes";

			
		}else
		{
			$(".commaddress").fadeIn();
			var contactaddress = $(".contactaddressadd1").val();
			var contactaddress2 = $(".contactaddressadd2").val();
			var contactcity = $(".contactcityadd").val();
			var contactstate = $(".contactstateadd").val();
			var contactpin = $(".contactpinadd").val();
			
			var sameaddress = "No";
			
		regex   = new RegExp('^[a-zA-Z0-9#][a-zA-Z0-9\n\.,-_/#:& ]{3,250}$');
        valid = regex.test(contactaddress);
        if(!valid && contactaddress!=""){ $(".contactaddressadd1").addClass('errclass');$(".edit-err-notify").text("Invalid Communication Address1");return;}
		
		regex   = new RegExp('^[a-zA-Z0-9#][a-zA-Z0-9\n\.,-_/#:& ]{3,250}$');
        valid = regex.test(contactaddress2);
        if(!valid && contactaddress2!=""){ $(".contactaddressadd2").addClass('errclass');$(".edit-err-notify").text("Invalid Communication Address2");return;}
		
		var regex   = new RegExp('^[a-zA-Z][a-zA-Z\.-/ ]{3,100}$');
        valid = regex.test(contactcity);
        if(!valid && contactcity!=""){ $(".contactcityadd").addClass('errclass');$(".edit-err-notify").text("Invalid Communication City");return;}
		
		var regex   = new RegExp('^[a-zA-Z][a-zA-Z\.-/ ]{3,100}$');
        valid = regex.test(contactstate);
        if(!valid && contactstate!=""){ $(".contactstateadd").addClass('errclass');$(".edit-err-notify").text("Invalid Communication State");return;}
		
		regex   = new RegExp('^[0-9 \-]{4,10}$');
        valid = regex.test(contactpin);
        if(!valid && contactpin!=""){ $(".contactpinadd").addClass('errclass');$(".edit-err-notify").text("Invalid Communication Pincode");return;}
		}
		
		regex   = new RegExp('^[a-zA-Z0-9#][a-zA-Z0-9\n\.,-_/#:&() ]{3,250}$');
        valid = regex.test(clinic);
        if(!valid && clinic!=""){ $(".clinicaddadd").addClass('errclass');$(".edit-err-notify").text("Invalid Clinic Address");return;}
		
		regex   = new RegExp('^[0-9 \-]{5,20}$');
        valid = regex.test(clinicphone);
        if(!valid && clinicphone!=""){ $(".clinicphoneadd").addClass('errclass');$(".edit-err-notify").text("Invalid Clinic Phone Number");return;}
		
		if(payamount==""){ $(".payamount").addClass('errclass');$(".edit-err-notify").text("Enter Payment Amount");return;}
		
		if(paymode=="Choose"){ $(".paymode").addClass('errclass');$(".edit-err-notify").text("Select Payment Mode");return;}
		
		$(".edit-err-notify").html("<font style=\"color:#f7d8ba\">Processing...</font>");
                 $.get('newmember/createMember',{
					   'name':name, 
					   'userid':userid,
					   'password':password,
					   'role':role,
					   'doj':doj,
                       'mobile':mobile,
                       'phone':phone,
                       'email':email,
					   'gender':gender,
					   'dob':dob,
					   'address':address,
					   'contactaddress':contactaddress,
					   'contactstate':contactstate,
					   'contactpin':contactpin,
					   'qualification':qualification,
					   'college':college,
					   'designation':designation,
					   'clinic':clinic,
					   'clinicphone':clinicphone,
					   'payamount':payamount,
					   'paymode':paymode,
					   'payid':payid,
					  	   'sameaddress':sameaddress,
						   'address2':address2,
						   'city':city,
						   'state':state,
						   'pincode':pincode,
						   'contactaddress2':contactaddress2,
						   'contactcity':contactcity,


                 }, function(o) { 
				 		var obj1 = $.parseJSON(o);
						if(obj1[0] == 'exists'){
							$(".edit-err-notify").html("<font style=\"color:#f7d8ba\">Member ID Existed</font>"); 							
						}else if(obj1[0] == 'success'){
				 			$(".edit-err-notify").html("<font style=\"color:#f7d8ba\">Member Profile Created</font>"); 
							setTimeout(function(){ location.reload();}, 2000);
                            //setTimeout(function(){ location.assign("<?php echo $this->config->item('web_url');?>regemail.php?uid="+obj1[1]+"&pass="+obj1[2]+"&ref="+obj1[3]+"&name="+obj1[4]+"&email="+obj1[5]+"&payamount="+obj1[6]+"&paymode="+obj1[7]+"&payid="+obj1[8]);}, 2000);  
						}else if(obj1[0] == ''){
							setTimeout(function(){ $(".edit-err-notify").html("<font style=\"color:#f7d8ba\">Please Try again later.</font>"); }, 2000);
						}
                 });	 
		
		
	});
	
		
	 $("#profile-right").find("input,select").each(function(){

          $(this).click(function(){ $(this).removeClass("errclass");$(".edit-err-notify").text("");});

     });
	 
	 $(".memtype").click(function()
	 {
		 var parElement = $(this).parent();
		 
		 $(parElement).find("input").each(function(){
		 		if($(this).hasClass("selectedtype")){
		 		 	$(this).removeClass("selectedtype");
				}
		 });
		 
		 $(this).addClass("selectedtype");
	 });
	
	$(".sameaddress").click(function(){
		  
		if($(this).is(':checked'))
			{
				$(".commaddress").fadeOut();
				
			}else
			{
				$(".commaddress").fadeIn();
			}
			
	 });
	
	var dobday = '<option value="">Day</option>';
	var dobmonth = '<option value="">Month</option>';
	var dobyear = '<option value="">Year</option>';
	
	for(var d=1;d<32;d++){
		
		var day = (d < 10 ? '0' : '') + d;
		dobday += '<option value="'+day+'">'+day+'</option>';
		
	}
	$(".dobdayfield").html(dobday);
	
	var monthNames = ["","January","February","March","April","May","June","July","August","September","October","November","December"];
	for(var m=1;m<monthNames.length;m++){
		
		var mon = (m < 10 ? '0' : '') + m;
		dobmonth += '<option value="'+mon+'">'+monthNames[m]+'</option>';
		
	}
	$(".dobmonthfield").html(dobmonth);
	
	var currentTime = new Date();
	var curyear = currentTime.getFullYear();
	var firstYear = curyear - 80;
	var lastYear = firstYear + 63;
	for(var y=firstYear;y<lastYear;y++){
		
		dobyear += '<option value="'+y+'">'+y+'</option>';
		
	}
	$(".dobyearfield").html(dobyear);


});
	
	function isDate(txtDate)
{
    var currVal = txtDate;
    if(currVal == '')
        return false;
    
    var rxDatePattern = /^(\d{4})(\/|-)(\d{1,2})(\/|-)(\d{1,2})$/; //Declare Regex
    var dtArray = currVal.match(rxDatePattern); // is format OK?
    
    if (dtArray == null) 
        return false;
    
    //Checks for mm/dd/yyyy format.
    dtMonth = dtArray[3];
    dtDay= dtArray[5];
    dtYear = dtArray[1];        	
   
	if (dtMonth < 1 || dtMonth > 12) 
        return false;
    else if (dtDay < 1 || dtDay> 31) 
        return false;
    else if ((dtMonth==4 || dtMonth==6 || dtMonth==9 || dtMonth==11) && dtDay ==31) 
        return false;
    else if (dtMonth == 2) 
    {
        var isleap = (dtYear % 4 == 0 && (dtYear % 100 != 0 || dtYear % 400 == 0));
        if (dtDay> 29 || (dtDay ==29 && !isleap)) 
                return false;
    }
	
    return true;
}
</script>

<div id="profile-left">

	<img class="proimg" src="<?php echo $this->config->item('web_url');?>images/ap.jpg" />
    
    <ul>
    
    	<a href="home"><li>Dashboard</li></a>
        
        <a href="allusers"><li>View Users</li></a>
        
        <a href="searchusers"><li>Search Users</li></a>
        
        <a href="exportdata"><li>Export Data</li></a>
        
        <a href="newmember"><li>Add Member</li></a>
        
        <!--<a href="admincommunity"><li>Community</li></a>-->
        
        <!--<a href="addcollege"><li>Add College</li></a>
        
        <a href="collegelist"><li>College List</li></a>-->

       <!-- <a href="subjects"><li>Question Papers</li></a>
        
        <a href="notices"><li>Add Notifications</li></a>-->
        
        <a href="confregistrants"><li>Conference Registrants</li></a>
        
        <a href="preconfregistrants"><li>Preconference</li></a>
        
        <a href="testregistrants"><li>Test Registrants</li></a>
        
        <a href="abstracts"><li>Abstracts</li></a>
        
        <a href="nominees"><li>Nominees</li></a>
           
        <a href="election"><li>Election</li></a>
           
        <a href="presentation"><li>Presentation</li></a>
           
        <a href="annualmeet"><li>Annual Meet</li></a>
    
    </ul>

</div>

<div id="profile-right">

	<h1>Dr. <?php echo $membername['name']; ?><br /><span style="font-size:12px">Membership ID: admin</span></h1>
    
    <div class="right-options">
    
    	<button class="addmember" id="addmembut">Add</button><br />
        <p style="margin:15px 0 0; text-align:right; color:#fff;" class="edit-err-notify"></p>
    
    </div>
    
    <div class="clear"></div>

	<h2>Add New Member</h2> 
    
    <div id="profile-titles">
    
    	<h2>Membership Details</h2>
    
    </div>
    
    <div id="profile-content">
    
    	<p><span>Name</span><input class="update-text-box nameadd" value="" /></p>
        
        <p><span>Member ID</span><input class="update-text-box memidadd" value="" /></p>
   
   		<p><span>Password</span><input class="update-text-box passadd" value="" /></p>
        
        <p><span>Role</span><input class="memtype" style="width:15px; height:auto;" type="radio" value="LIFE" name="type" /> Life <input class="memtype" style="width:15px; height:auto;" type="radio" value="STUDENT" name="type" /> Student <!--<input class="memtype" style="width:15px; height:auto;" type="radio" value="ASSOCIATES" name="type" /> Associates--></p>
        
        <p><span>Date of Joining</span><input class="update-text-box dojadd datepicker" value="" readonly /></p>
    
    </div>
    
    <div style="clear:both; height:30px;"></div>
    
    <div id="profile-titles">
    
    	<h2>Contact Details</h2>
    
    </div>
    
    <div id="profile-content">
    
    	<p><span>Mobile</span><input class="update-text-box mobileadd" value="" /><span1>eg: 9876543210</span1></p>
        
        <p><span>Landline</span><input class="update-text-box phoneadd" value="" /><span1>eg: 044-12345678</span1></p>
   
   		<p><span>Email</span><input class="update-text-box emailadd" value="" /><span1>eg: info@example.com</span1></p>
    
    </div>
    
    <div style="clear:both; height:30px;"></div>
    
    <div id="profile-titles">
    
    	<h2>Personal Details</h2>
    
    </div>
    
    <div id="profile-content">
    
    	<p><span>Gender</span><input type="radio" class="register-radio sexfield" name="sex" value="Male" />
	<label>Male</label>
<input type="radio" class="register-radio sexfield" name="sex" value="Female" />
	<label>Female</label></p>
   
   		<p><span>DOB</span>
   		<select class="register-select dobdayfield" name="dobday"></select>
<select class="register-select dobmonthfield" name="dobmonth"></select>
<select class="register-select dobyearfield" name="dobyear"></select></p>
	</div>
       
   <div style="clear:both; height:30px;"></div>
   
    <div id="profile-titles">
    
    	<h2>Residential Address</h2>
    
    </div>
    
    <div id="profile-content">
            
        <p><span>Address Line 1</span><input class="update-text-box resaddressadd1" value="" /><span1>max. 250 chars</span1></p>
        
        <p><span>Address Line 2</span><input class="update-text-box resaddressadd2" value="" /><span1>max. 250 chars</span1></p>
        
        <p><span>City</span><input class="update-text-box rescityadd" value="" /></p>
        
        <p><span>State</span><input class="update-text-box resstateadd" value="" /></p>
        
        <p><span>Pincode</span><input class="update-text-box respincodeadd" value="" /></p>
    
    </div>
    
    <div style="clear:both; height:30px;"></div>
    
    <div id="profile-titles">
    
    	<h2>Communication Address</h2>
    	    
    </div>
    
    <div id="profile-content">
    
    	<p class="sameadbox"><input type="checkbox" class="register-text-box sameaddress" name="sameaddress" /><label>Same as Residential Address</label></p>
    
    	<p class="commaddress"><span>Address Line 1</span><input class="update-text-box contactaddressadd1" value="" /><span1>max. 250 chars</span1></p>
      
      <p class="commaddress"><span>Address Line 2</span><input class="update-text-box contactaddressadd2" value="" /><span1>max. 250 chars</span1></p>
       
       <p class="commaddress"><span>City</span><input class="update-text-box contactcityadd" value="" /></p>
        
        <p class="commaddress"><span>State</span><input class="update-text-box contactstateadd" value="" /></p>
        
        <p class="commaddress"><span>Pincode</span><input class="update-text-box contactpinadd" value="" /></p>
    
    </div> 
    
    <div style="clear:both; height:30px;"></div>
    
    <div id="profile-titles">
    
    	<h2>Official Details</h2>
    
    </div>
    
    <div id="profile-content">
    
    	<p><span>Qualification</span><input class="update-text-box qualadd" value="" /></p>
   
   		<p><span>College</span><input class="update-text-box collegeadd" value="" /></p>
        
        <p><span>Designation</span><input class="update-text-box desigadd" value="" /></p>
        
        <p><span>Clinic Address</span><input class="update-text-box clinicaddadd" value="" /><span1>max. 250 chars</span1></p>
        
        <p><span>Clinic Phone</span><input class="update-text-box clinicphoneadd" value="" /></p>
    
    </div> 
    
    <div style="clear:both; height:30px;"></div>
    
    <div id="profile-titles">
    
    	<h2>Payment Details</h2>
    
    </div>
    
    <div id="profile-content">
    
    	<p><span>Payment Amount</span><input class="update-text-box payamount" value="" /></p>
   
   		<p><span>Mode of Payment</span><select class="update-text-box paymode"><option>Choose</option><option>DD</option><option>NEFT</option><option>CASH</option><option>ONLINE</option></select></p>
        
        <p><span>DD No/Txn Id</span><input class="update-text-box payid" value="" /></p>
            
    </div> 
    
    <div style="clear:both; height:30px;"></div>
        

</div>
   
   
   
  
 
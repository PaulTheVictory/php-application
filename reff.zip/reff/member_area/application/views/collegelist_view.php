
<script type="text/javascript">
$(document).ready(function(){	
		
	$(".collegelist").click(function(){
		
		var collid = $(this).attr("id");
        		
		window.location.href = "<?php  echo base_url(); ?>viewcollegepage?id="+collid;		
		
	});
	
	
	
});
</script>

<div id="profile-left">

	<img class="proimg" src="<?php echo $this->config->item('web_url');?>images/ap.jpg" />
    
    <ul>
    
    	<a href="home"><li>Dashboard</li></a>
        
        <a href="allusers"><li>View Users</li></a>
        
        <a href="searchusers"><li>Search Users</li></a>
        
        <a href="exportdata"><li>Export Data</li></a>
        
        <a href="newmember"><li>Add Member</li></a>
        
        <a href="admincommunity"><li>Community</li></a>
        
        <!--<a href="addcollege"><li>Add College</li></a>
        
        <a href="collegelist"><li>College List</li></a>-->

        <a href="subjects"><li>Question Papers</li></a>
        
        <a href="notices"><li>Add Notifications</li></a>
    
    </ul>

</div>

<div id="profile-right">

	<h1>Dr. <?php echo $membername['name']; ?><br /><span style="font-size:12px">Membership ID: admin</span></h1>
    
    <div class="clear"></div>

	<h2>College List</h2>  
    
    <div class="clear"></div>
    
    <?php echo $colleges; ?> 	

</div>
   
   
   
  
 
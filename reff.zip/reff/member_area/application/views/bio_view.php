<div id="profile-left">

	<img class="proimg" src="<?php echo base_url();?>docs/profile/<?php echo $membername['profileimg']; ?>" width="140" height="160" />
    
    <ul>
    
    	<a href="home"><li>Recent Activity</li></a>
        
        <a href="profile"><li>Profile</li></a>
        
        <a href="bio"><li>Bio</li></a>
        
        <a href="connectionlist"><li>Find a Connection</li></a>
        
        <a href="messageinbox"><li>Messages</li></a>
        
        <a href="communitylist"><li>Communities</li></a>
        
        <?php if($membername['role']=="STUDENT"){ ?><a href="upgrademembership"><li>Upgrade Membership</li></a><?php } ?>
    
    </ul>

</div>

<div id="profile-right">

	<h1>Dr. <?php echo $membername['name']; ?><br /><span style="font-size:12px">Membership ID: <?php echo $membername['userid']; ?></span></h1>
    
    <div class="right-options">
    
    	<a href="editbio"><button id="editbut">Edit</button></a>
    
    </div>
            
    <div class="clear"></div>

	<div id="profile-titles">
    
    	<h2>About Me</h2>
    
    </div>
    
    <div id="profile-content">
    
    	<p><?php if($memberbio['about']!=""){ echo $memberbio['about'];}else{ echo "-"; } ?></p>        
            
    </div>
    
    <div style="clear:both; height:30px;"></div>
    
    <div id="profile-titles">
    
    	<h2>Interests</h2>
    
    </div>
    
    <div id="profile-content">
    
    	<ul style="margin-top: 15px;">
        
        	<?php
				$count = count($memberbio['interests']);
				if($memberbio['interests'][0]!=""){
					for($i=0;$i<$count;$i++){
						echo '<li>'.$memberbio['interests'][$i].'</li>';
					}
				}else{
					echo '<li style="list-style:none">-</li>';
				}
			
			?>
        	
        </ul>      
    
    </div>
    
    <div style="clear:both; height:30px;"></div>
    
      	

</div>
   
   
   
  
 
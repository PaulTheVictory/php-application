
<script type="text/javascript">
$(document).ready(function(){	



	
	
	
});
</script>

<div id="profile-left">

	<ul>
    
    	<a href="javascript:history.go(-1)"><li>Back</li></a>
    	
    </ul>  

</div>

<div id="profile-right">

	<h1><?php if($memberprofile['name']!=""){ echo $memberprofile['name'];}else{ echo ""; } ?></h1>   
    
    <div class="right-options">
    
        
    </div>    
    
    <div class="clear" style="height:30px;"></div>
    
    <h2>Test Registrants</h2>
    
    <div id="profile-titles">
    
    	<h2>Membership Details</h2>
    
    </div>
    
    <div id="profile-content">
                    
        <p><span>Amount paid</span><span1 style="color:#333"><?php if($memberprofile['paymentamount']!=""){ echo "&#8377; ".$memberprofile['paymentamount'];}else{ echo ""; } ?></span1></p>
        
        <p><span>Payment mode</span><span1 style="color:#333"><?php if($memberprofile['paymentmode']!=""){ echo $memberprofile['paymentmode'];}else{ echo ""; } ?></span1></p>
        
        <p><span>Date of Register</span><span1 style="color:#333"><?php if($memberprofile['paymenttime']!=""){ echo $memberprofile['paymenttime'];}else{ echo ""; } ?></span1></p>
        
        <p><span>Registration No</span><span1 style="color:#333"><?php if($memberprofile['userid']!=""){ echo $memberprofile['userid'];}else{ echo ""; } ?></span1></p>
    
    </div>
    
    <div style="clear:both; height:30px;"></div>

	<div id="profile-titles">
    
    	<h2>Contact Details</h2>
    
    </div>
    
    <div id="profile-content">
            
        <p><span>Mobile</span><span1 style="color:#333"><?php if($memberprofile['phone']!=""){ echo $memberprofile['phone'];}else{ echo ""; } ?></span1></p>
   
        <p><span>Email</span><span1 style="color:#333"><?php if($memberprofile['email']!=""){ echo $memberprofile['email'];}else{ echo ""; } ?></span1></p>
    
    </div>
    
    <div style="clear:both; height:30px;"></div>
    
    <div id="profile-titles">
    
    	<h2>Personal Details</h2>
    
    </div>
    
    <div id="profile-content">       	
           
   		<p><span>DOB</span><span1 style="color:#333"><?php if($memberprofile['dob']!=""){ echo $memberprofile['dob'];}else{ echo ""; } ?></span1></p>
            
    </div>
    
    <div style="clear:both; height:30px;"></div>
    
    <div id="profile-titles">
    
    	<h2>Official Details</h2>
    
    </div>
    
     <div id="profile-content">
    
    	<p><span>Qualification</span><span1 style="color:#333"><?php if($memberprofile['qualification']!=""){ echo $memberprofile['qualification'];}else{ echo ""; } ?></span1></p>        
       
    
    </div> 
    
    <div style="clear:both; height:30px;"></div>
    


</div>
   
   
   
  
 
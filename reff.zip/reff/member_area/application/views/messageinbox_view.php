
<script type="text/javascript">
$(document).ready(function(){	
		
	 $("#composemessage").click(function(){
		 
		window.location.href = "<?php  echo base_url(); ?>composemessage";	
		 
	 });
	 
	 $("#sentitems").click(function(){
		 
		window.location.href = "<?php  echo base_url(); ?>messagesent";	
		 
	 });
	 
	 $("#message-left").find("li").each(function(){
		 $(this).click(function(){
			 if($(this).hasClass("unread")){
				 $(this).removeClass("unread");
				 $(this).addClass("read");
			 }
			 $("#message-left").find("li").each(function(){
				 $(this).removeClass("selected");
			 });
			 $(this).addClass("selected");
			 $("#conversation-reply").hide();
			 
			 var conid = $(this).attr("id");
			     $.get('messageinbox/getConversationDetails',{
					   'conid':conid		   

                 }, function(o) {  
				 
				 		$("#conversation-content").html(o[0]);
						$("#totalcount").html(o[1]);
						$("#unreadcount").html(o[2]);
				 		 
                 }, 'json');
		 });
	 });
	 
	 $(document).delegate('.delete-conversation','click',function(){
		 var conid = $(this).attr("id");
		 var r=confirm("Are you sure ?")
		 if (r==true){
			 $.get('messageinbox/deleteConversation',{
					   'conid':conid		   

                 }, function(o) { $("#conversation-content").html("<p>Conversation Deleted</p>");
				 		setTimeout(function(){ location.reload();}, 2000);				 		 
                 }, 'json');
		 }
	 });
	 
	 $(document).delegate('.reply-message','click',function(){
		 
		 var messageid = $(this).attr("id");
		 $.get('messageinbox/getReplyMembersForMessage',{
		 		'messageid':messageid		   

                 }, function(o) { 
				 
				 		$("#conversation-reply").html("");
				 
				 		var replyto = $(document.createElement('select')).attr("class",messageid).attr("id","replyto").attr("multiple","multiple").attr("data-placeholder","Select a Connection...");
						
						var replymessage = $(document.createElement('textarea')).attr("class","compose-textarea").attr("id","replymessage").css("height","150px").css("width","548px");
						
						var replysubmit = $(document.createElement('button')).attr("class","compose-submit").text("Send");
						
						var replynotify = $(document.createElement('span')).attr("id","compose-errnotify");
						
						$("#conversation-reply").append(replyto);
						$("#conversation-reply").append(replymessage);
						$("#conversation-reply").append(replysubmit);
						$("#conversation-reply").append(replynotify);
				 		
				   		$("."+messageid).html(o);
						$("."+messageid).chosen();
				 		$("#conversation-reply").show();
		 				$('html,body').animate({scrollTop: $("#conversation-reply").offset().top},'slow'); 		 
                 }, 'json');
		 
		 
	 });
	 
	 $(document).delegate('.reply-conversation','click',function(){
		 
		 var convid = $(this).attr("id");
		 $.get('messageinbox/getReplyMembersForConversation',{
		 		'convid':convid		   

                 }, function(o) { 
				 
				 		$("#conversation-reply").html("");
				 
				 		var creplyto = $(document.createElement('select')).attr("class",convid).attr("id","replyto").attr("multiple","multiple").attr("data-placeholder","Select a Connection...");
						
						var creplymessage = $(document.createElement('textarea')).attr("class","compose-textarea").attr("id","replymessage").css("height","150px").css("width","548px");
						
						var creplysubmit = $(document.createElement('button')).attr("class","compose-submit").text("Send");
						
						var creplynotify = $(document.createElement('span')).attr("id","compose-errnotify");
						
						$("#conversation-reply").append(creplyto);
						$("#conversation-reply").append(creplymessage);
						$("#conversation-reply").append(creplysubmit);
						$("#conversation-reply").append(creplynotify);
				 		
				   		$("."+convid).html(o);
						$("."+convid).chosen();
				 		$("#conversation-reply").show();
		 				$('html,body').animate({scrollTop: $("#conversation-reply").offset().top},'slow'); 		 
                 }, 'json');
		 
		 
	 });
	 
	 $(document).delegate('.compose-submit','click',function(){
		 
		 var fromname = "<?php echo $membername['name']; ?>";
		 var tonames = $("#replyto").val();		 
		 var toids = "";
		 var subject = "Re:"+$("#conversation-content").find("#con-subject").text();
		 var message = $("#replymessage").val();
		 var conversationid = "";
		 
		 $("#message-left").find("li").each(function(){
			 if($(this).hasClass("selected")){
				 conversationid = $(this).attr("id");
			 }
		 });
		 
		 $(".chzn-results").find("li").each(function(){
			 if($(this).hasClass("result-selected")){
				 toids = toids + $(this).attr("class") + "|";
			 }
		 });
		 toids=toids.replace(/result-selected/g,"");
		 toids=toids.replace(/\s/g, "");
		 
		 if(tonames==null || tonames==""){
			$("#compose-errnotify").text('Select atleast one Connection');return;
		 }
		 		 
		 if(message==""){
			$("#compose-errnotify").text("Enter a Reply Message");return;
		 }
		 
		 $("#compose-errnotify").text("Processing...").css("color","#abc0ca");
                 $.get('messageinbox/replyMessage',{
					   'fromname':fromname,
                       'tonames':tonames,
                       'toids':toids,
					   'subject':subject,
					   'message':message,
					   'conversationid':conversationid		   

                 }, function(o) {  $("#compose-errnotify").text("Message Sent").css("color","#109141"); 
                           setTimeout(function(){ location.reload();}, 2000);  
                 }, 'json');
		 
	 });
	 
	 $(document).delegate('.chzn-choices','click',function(){
		 $("#compose-errnotify").text("");
	 });
	 
	 $(document).delegate('.compose-textarea','click',function(){
		 $("#compose-errnotify").text("");
	 });
	 
	 	
	
});
</script>


<h1>Inbox (<span1 id="unreadcount"><?php echo $inboxcount['unread']; ?></span1>/<span1 id="totalcount"><?php echo $inboxcount['total']; ?></span1>)<span class="message-links" id="composemessage">Compose Message</span><span class="message-links" id="sentitems">Sent Items</span></h1>

<div id="message-content">

	<div id="message-left">
    
    	<?php echo $inboxlist; ?>
    
    </div>
    
    <div id="message-right">
    
    	<ul id="conversation-content">
        
        </ul>
        
        <div id="conversation-reply">
        
        </div>	
        
        <div class="clear"></div>
    
    </div>
	
    
</div>
   


<script type="text/javascript">
$(document).ready(function(){	

    $(".dojedit").val("<?php if($membername['doj']!=""){ echo $membername['doj'];}else{ echo ""; } ?>");
	
	$(".moreinterest").click(function(){
		
		var parElement = $(this).prev();		
		var liElement = '<li style="list-style:none"><input class="update-text-box interest" value="" /><span2 class="delinterest">x</span2></li>';		
		parElement.append(liElement);
						
	});
	
	$(document).delegate('.delinterest','click',function(){
		var liElement = $(this).parent();
		liElement.remove();
	});
	
	$(".editmember").click(function(){
		
		var url = window.location.href;
		var n=url.lastIndexOf("=");
		
		var memid = url.slice(n+1);
		
		var name = $(".nameedit").val();
		var userid = $(".memidedit").val();
		var password = $(".passwordedit").val();
		var role = $(".roleedit").val();
		var doj = $(".dojedit").val();
		var mobile = $(".mobileedit").val();
        var phone = $(".phoneedit").val();
        var email = $(".emailedit").val();
		var gender = $(".genderedit:checked").val();
		//var dob = $(".dobedit").val();
			var dobday = $(".dobdayfield").val();
			var dobmonth = $(".dobmonthfield").val();
			var dobyear = $(".dobyearfield").val();
		var address = $(".resaddressedit").val();
		var qualification = $(".qualedit").val();
		var college = $(".collegeedit").val();
		var designation = $(".desigedit").val();
		var clinic,clinicphone="";
		//var clinic = $(".clinicaddedit").val();
		//var clinicphone = $(".clinicphoneedit").val();
		var aboutme = $(".aboutme").val();
        var interest = "";
		
		var address2 = $(".resaddressedit2").val();
		var city = $(".rescityedit").val();
		var state = $(".resstateedit").val();
		var pincode = $(".respincodeedit").val();
		
		$(".interestlist").find('input').each(function(){
			if($(this).val()!="") {
        		interest += $(this).val()+"&|&";
     		}
		});
		
		var n= interest.lastIndexOf("&|&");
		interest = interest.slice(0,n);
		
		regex   = new RegExp('^[a-zA-Z][a-zA-Z\.-/ ]{3,40}$');
		valid = regex.test(name);
		if(!valid || name==""){ $(".nameedit").addClass('errclass');$(".edit-err-notify").text("Invalid Member Name");return;}
		
		if(userid==""){ $(".memidedit").addClass('errclass');$(".edit-err-notify").text("Invalid Member ID");return;}
				
		if(role==""){ $(".roleedit").addClass('errclass');$(".edit-err-notify").text("Invalid Role");return;}
			
		regex   = new RegExp('^[0-9 \-]{5,20}$');
        valid = regex.test(mobile);
        if(!valid && mobile!=""){ $(".mobileedit").addClass('errclass');$(".edit-err-notify").text("Invalid Mobile Number");return;}
		
		regex   = new RegExp('^[0-9 \-]{5,20}$');
        valid = regex.test(phone);
        if(!valid && phone!=""){ $(".phoneedit").addClass('errclass');$(".edit-err-notify").text("Invalid Phone Number");return;}
		
		regex   = new RegExp('^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$');
        valid = regex.test(email);
        if(!valid && email!=""){ $(".emailedit").addClass('errclass');$(".edit-err-notify").text("Invalid Email");return;}
		
		if(gender!="Male" && gender!="Female" && gender!=""){ $(".genderedit").addClass('errclass');$(".edit-err-notify").text("Invalid Gender");return;}
		
		/*regex   = new RegExp('^[0-9 \-]{10,10}$');
        valid = regex.test(dob);
        if(!valid && dob!=""){ $(".dobadd").addClass('errclass');$(".edit-err-notify").text("Invalid Date");return;}*/
		
		if(dobday=="" || dobmonth=="" || dobyear==""){ $(".dobdayfield,.dobmonthfield,.dobyearfield").addClass('errclass');$(".edit-err-notify").text("Invalid Date of Birth");return;}
	
		var dobdate = dobyear+'/'+dobmonth+'/'+dobday;
		var datevalid = isDate(dobdate);

		if(!datevalid) {
		  $(".dobdayfield,.dobmonthfield,.dobyearfield").addClass('errclass');
		  $(".edit-err-notify").text("Invalid Date of Birth");
		  return;
		}
	
		var dob = dobday+'-'+dobmonth+'-'+dobyear;
		
		if($('.sameaddress').is(':checked'))
		{
			$(".commaddress").fadeOut();
			
			var contactaddress = address;
			var contactaddress2 = address2;
			var contactcity = city;
			var contactstate = state;
			var contactpin = pincode;
			
			var sameaddress = "Yes";

			
		}else
		{
			$(".commaddress").fadeIn();
			var contactaddress = $(".contactaddressedit1").val();
			var contactaddress2 = $(".contactaddressedit2").val();
			var contactcity = $(".contactcityedit").val();
			var contactstate = $(".contactstateedit").val();
			var contactpin = $(".contactpinedit").val();
			
			var sameaddress = "No";
			
		regex   = new RegExp('^[a-zA-Z0-9#][a-zA-Z0-9\n\.,-_/#:& ]{3,250}$');
        valid = regex.test(contactaddress);
        if(!valid && contactaddress!=""){ $(".contactaddressedit1").addClass('errclass');$(".edit-err-notify").text("Invalid Communication Address1");return;}
		
		regex   = new RegExp('^[a-zA-Z0-9#][a-zA-Z0-9\n\.,-_/#:& ]{3,250}$');
        valid = regex.test(contactaddress2);
        if(!valid && contactaddress2!=""){ $(".contactaddressedit2").addClass('errclass');$(".edit-err-notify").text("Invalid Communication Address2");return;}
		
		var regex   = new RegExp('^[a-zA-Z][a-zA-Z\.-/ ]{3,100}$');
        valid = regex.test(contactcity);
        if(!valid && contactcity!=""){ $(".contactcityedit").addClass('errclass');$(".edit-err-notify").text("Invalid Communication City");return;}
		
		var regex   = new RegExp('^[a-zA-Z][a-zA-Z\.-/ ]{3,100}$');
        valid = regex.test(contactstate);
        if(!valid && contactstate!=""){ $(".contactstateedit").addClass('errclass');$(".edit-err-notify").text("Invalid Communication State");return;}
		
		regex   = new RegExp('^[0-9 \-]{4,10}$');
        valid = regex.test(contactpin);
        if(!valid && contactpin!=""){ $(".contactpinedit").addClass('errclass');$(".edit-err-notify").text("Invalid Communication Pincode");return;}
		}
		
		regex   = new RegExp('^[a-zA-Z0-9][a-zA-Z\n\.,-_ ]{3,250}$');
        valid = regex.test(clinic);
        if(!valid && clinic!=""){ $(".clinicaddedit").addClass('errclass');$(".edit-err-notify").text("Invalid Clinic Address");return;}
		
		regex   = new RegExp('^[0-9 \-]{5,20}$');
        valid = regex.test(clinicphone);
        if(!valid && clinicphone!=""){ $(".clinicphoneedit").addClass('errclass');$(".edit-err-notify").text("Invalid Clinic Phone Number");return;}
		
		$(".edit-err-notify").html("<font style=\"color:#44f2f8\">Processing...</font>");
                 $.get('editmemberpage/updateMember',{
					   'memid':memid,
					   'name':name, 
					   'userid':userid,
					   'password':password,
					   'role':role,
					   'doj':doj,
                       'mobile':mobile,
                       'phone':phone,
                       'email':email,
					   'gender':gender,
					   'dob':dob,
					   'address':address,
					   'contactaddress':contactaddress,
					   'contactstate':contactstate,
					   'contactpin':contactpin,
					   'qualification':qualification,
					   'college':college,
					   'designation':designation,
					   'clinic':clinic,
					   'clinicphone':clinicphone,
                       'aboutme':aboutme,
                       'interest':interest,
					       'sameaddress':sameaddress,
						   'address2':address2,
						   'city':city,
						   'state':state,
						   'pincode':pincode,
						   'contactaddress2':contactaddress2,
						   'contactcity':contactcity,

                 }, function(o) { 
				 		var obj1 = $.parseJSON(o);
						if(obj1[0] == 'success'){
				 			$(".edit-err-notify").html("<font style=\"color:#f7d8ba\">Member Profile Updated</font>"); 
                            setTimeout(function(){ location.assign("allusers");}, 2000);  
						}else if(obj1[0] == ''){
							setTimeout(function(){ $(".edit-err-notify").html("<font style=\"color:#f7d8ba\">Please Try again later.</font>"); }, 2000);
						}
                 });				 
		
	});
	
	 $("#profile-right").find("input,select").each(function(){

          $(this).click(function(){ $(this).removeClass("errclass");$(".edit-err-notify").text("");});

     });
	 
	 $(".deletemember").click(function(){
		 
		var memid = "<?php echo $memberid; ?>";
		 
		var r=confirm("Are you sure to delete ?")
		if (r==true){
  			$(".edit-err-notify").html("<font style=\"color:#f7d8ba\">Processing...</font>");
                 $.get('editmemberpage/deleteMemberProfile',{
                       'memid':memid			   

                 }, function(o) {  $(".edit-err-notify").html("<font style=\"color:#f7d8ba\">Member Profile Deleted</font>"); 
                           setTimeout(function(){ location.assign("home");}, 2000);         
                 }, 'json');
				 
  		}
		 
	 });
	
$(".sameaddress").click(function(){
		  
		if($(this).is(':checked'))
			{
				$(".commaddress").fadeOut();
				
			}else
			{
				$(".commaddress").fadeIn();
			}
			
	 });
	
	var sameaddress = "<?php echo $memberprofile['sameaddress'];?>";
	var dob = "<?php echo $memberprofile['dob'];?>";
	
	if(sameaddress=="Yes"){
		$(".sameaddress").prop('checked',true);
		$(".commaddress").fadeOut();
	}else{
		$(".sameaddress").prop('checked',false);
		$(".commaddress").fadeIn();
	}
	
	dob = dob.split('-');
	
	var dobday = '<option value="">Day</option>';
	var dobmonth = '<option value="">Month</option>';
	var dobyear = '<option value="">Year</option>';
	
	for(var d=1;d<32;d++){
		
		var day = (d < 10 ? '0' : '') + d;
		if(dob[0]==day) var selected = "selected"; else var selected = "";
		dobday += '<option value="'+day+'" '+selected+'>'+day+'</option>';
		
	}
	$(".dobdayfield").html(dobday);
	
	var monthNames = ["","January","February","March","April","May","June","July","August","September","October","November","December"];
	for(var m=1;m<monthNames.length;m++){
		
		var mon = (m < 10 ? '0' : '') + m;
		if(dob[1]==mon) var selected = "selected"; else var selected = "";
		dobmonth += '<option value="'+mon+'" '+selected+'>'+monthNames[m]+'</option>';
		
	}
	$(".dobmonthfield").html(dobmonth);
	
	var currentTime = new Date();
	var curyear = currentTime.getFullYear();
	var firstYear = curyear - 80;
	var lastYear = firstYear + 63;
	for(var y=firstYear;y<lastYear;y++){
		
		if(dob[2]==y) var selected = "selected"; else var selected = "";
		dobyear += '<option value="'+y+'" '+selected+'>'+y+'</option>';
		
	}
	$(".dobyearfield").html(dobyear);

});
	
function isDate(txtDate)
{
    var currVal = txtDate;
    if(currVal == '')
        return false;
    
    var rxDatePattern = /^(\d{4})(\/|-)(\d{1,2})(\/|-)(\d{1,2})$/; //Declare Regex
    var dtArray = currVal.match(rxDatePattern); // is format OK?
    
    if (dtArray == null) 
        return false;
    
    //Checks for mm/dd/yyyy format.
    dtMonth = dtArray[3];
    dtDay= dtArray[5];
    dtYear = dtArray[1];        	
   
	if (dtMonth < 1 || dtMonth > 12) 
        return false;
    else if (dtDay < 1 || dtDay> 31) 
        return false;
    else if ((dtMonth==4 || dtMonth==6 || dtMonth==9 || dtMonth==11) && dtDay ==31) 
        return false;
    else if (dtMonth == 2) 
    {
        var isleap = (dtYear % 4 == 0 && (dtYear % 100 != 0 || dtYear % 400 == 0));
        if (dtDay> 29 || (dtDay ==29 && !isleap)) 
                return false;
    }
	
    return true;
}
</script>

<div id="profile-left">

	<img class="proimg" src="<?php echo base_url();?>docs/profile/<?php echo $membername['profileimg']; ?>" width="140" height="160" />
    <a href="adminchangephoto?id=<?php echo $memberid; ?>"><div id="changepic">Change Picture</div></a>
    
    <ul>
    
    	<a href="javascript:history.go(-1)"><li>Back</li></a>
    	
    </ul>  

</div>

<div id="profile-right">

	<h1>Dr. <input class="update-text-box nameedit" value="<?php if($membername['name']!=""){ echo $membername['name'];}else{ echo ""; } ?>" /></span></h1>   
    
    <div class="right-options">
    
    	<button class="editmember" id="editmembut">Update</button><button class="deletemember" id="editmembut" style="margin-right:10px;">Delete</button>
        <a href="generateidcard?id=<?php echo $memberid; ?>" target="_blank"><button class="idprint" id="idprintmem" style="margin-right:10px;">ID Card</button></a><br />
        <p style="margin:15px 0 0; text-align:right; color:#fff;" class="edit-err-notify"></p>
    
    </div>    
    
    <div class="clear" style="height:30px;"></div>
    
    <div id="profile-titles">
    
    	<h2>Membership Details</h2>
    
    </div>
    
    <div id="profile-content">
            
        <p><span>Member ID</span><input class="update-text-box memidedit" value="<?php if($membername['userid']!=""){ echo $membername['userid'];}else{ echo ""; } ?>" /></p>
        
        <p><span>Password</span><input class="update-text-box passwordedit" value="" /></p>
           
        <p><span>Role</span><select class="update-text-box roleedit">
        
        	<?php
			
				$rolearr = "LIFE,STUDENT,ASSOCIATES";
				$rolearr = explode(",",$rolearr);
				$roleselect = '<option value="">Choose</option>';
				foreach ($rolearr as $rval) { 
					if($membername['role']==$rval){
						$roleselect .= "<option selected>".$rval."</option>";
					}else{
						$roleselect .= "<option>".$rval."</option>";
					}	   				
				}
				echo $roleselect;
			
			?>
        
        </select></p>
        
        <p><span>Date of Joining</span><input class="update-text-box dojedit datepicker" value="<?php if($membername['doj']!=""){ echo $membername['doj'];}else{ echo ""; } ?>" readonly /></p>
    
    </div>
    
    <div style="clear:both; height:30px;"></div>

	<div id="profile-titles">
    
    	<h2>Contact Details</h2>
    
    </div>
    
    <div id="profile-content">
    
    	<p><span>Mobile</span><input class="update-text-box mobileedit" value="<?php if($memberprofile['mobile']!=""){ echo $memberprofile['mobile'];}else{ echo ""; } ?>" /><span1>eg: 9876543210</span1></p>
        
        <p><span>Landline</span><input class="update-text-box phoneedit" value="<?php if($memberprofile['phone']!=""){ echo $memberprofile['phone'];}else{ echo ""; } ?>" /><span1>eg: 044-12345678</span1></p>
   
   		<p><span>Email</span><input class="update-text-box emailedit" value="<?php if($memberprofile['email']!=""){ echo $memberprofile['email'];}else{ echo ""; } ?>" /><span1>eg: info@example.com</span1></p>
    
    </div>
    
    <div style="clear:both; height:30px;"></div>
    
    <div id="profile-titles">
    
    	<h2>Personal Details</h2>
    
    </div>
    
    <div id="profile-content">
    
    	<p><span>Gender</span><input type="radio" class="register-radio genderedit" name="sex" value="Male" <?php if($memberprofile['gender']=="Male"){ echo "checked";}else{ echo ""; } ?> />
	<label>Male</label>
<input type="radio" class="register-radio genderedit" name="sex" value="Female" <?php if($memberprofile['gender']=="Female"){ echo "checked";}else{ echo ""; } ?> />
	<label>Female</label></p>
   
   		<p><span>DOB</span>
   		<select class="register-select dobdayfield" name="dobday"></select>
<select class="register-select dobmonthfield" name="dobmonth"></select>
<select class="register-select dobyearfield" name="dobyear"></select></p>
	</div>
       
   <div style="clear:both; height:30px;"></div>
   
    <div id="profile-titles">
    
    	<h2>Residential Address</h2>
    
    </div>
    
    <div id="profile-content">
            
        <p><span>Address Line 1</span><input class="update-text-box resaddressedit" value="<?php if($memberprofile['address']!=""){ echo $memberprofile['address'];}else{ echo ""; } ?>" /><span1>max. 250 chars</span1></p>
        
        <p><span>Address Line 2</span><input class="update-text-box resaddressedit2" value="<?php if($memberprofile['address2']!=""){ echo $memberprofile['address2'];}else{ echo ""; } ?>" /><span1>max. 250 chars</span1></p>
        
        <p><span>City</span><input class="update-text-box rescityedit" value="<?php if($memberprofile['city']!=""){ echo $memberprofile['city'];}else{ echo ""; } ?>" /></p>
        
        <p><span>State</span><input class="update-text-box resstateedit" value="<?php if($memberprofile['state']!=""){ echo $memberprofile['state'];}else{ echo ""; } ?>" /></p>
        
        <p><span>Pincode</span><input class="update-text-box respincodeedit" value="<?php if($memberprofile['pincode']!=""){ echo $memberprofile['pincode'];}else{ echo ""; } ?>" /></p>
    
    </div>
    
    <div style="clear:both; height:30px;"></div>
    
    <div id="profile-titles">
    
    	<h2>Communication Address</h2>
    	    
    </div>
    
    <div id="profile-content">
    
    	<p class="sameadbox"><input type="checkbox" class="register-text-box sameaddress" name="sameaddress" /><label>Same as Residential Address</label></p>
    
    	<p class="commaddress"><span>Address Line 1</span><input class="update-text-box contactaddressedit1" value="<?php if($memberprofile['contactaddress']!=""){ echo $memberprofile['contactaddress'];}else{ echo ""; } ?>" /><span1>max. 250 chars</span1></p>
      
      <p class="commaddress"><span>Address Line 2</span><input class="update-text-box contactaddressedit2" value="<?php if($memberprofile['contactaddress2']!=""){ echo $memberprofile['contactaddress2'];}else{ echo ""; } ?>" /><span1>max. 250 chars</span1></p>
       
       <p class="commaddress"><span>City</span><input class="update-text-box contactcityedit" value="<?php if($memberprofile['contactcity']!=""){ echo $memberprofile['contactcity'];}else{ echo ""; } ?>" /></p>
        
        <p class="commaddress"><span>State</span><input class="update-text-box contactstateedit" value="<?php if($memberprofile['contactstate']!=""){ echo $memberprofile['contactstate'];}else{ echo ""; } ?>" /></p>
        
        <p class="commaddress"><span>Pincode</span><input class="update-text-box contactpinedit" value="<?php if($memberprofile['contactpin']!=""){ echo $memberprofile['contactpin'];}else{ echo ""; } ?>" /></p>
    
    </div> 
    
    <div style="clear:both; height:30px;"></div>
    
    <div id="profile-titles">
    
    	<h2>Official Details</h2>
    
    </div>
    
     <div id="profile-content">
    
    	<p><span>Qualification</span><input class="update-text-box qualedit" value="<?php if($memberprofile['qualification']!=""){ echo $memberprofile['qualification'];}else{ echo ""; } ?>" /></p>
   
   		<p><span>College</span><input class="update-text-box collegeedit" value="<?php if($memberprofile['college']!=""){ echo $memberprofile['college'];}else{ echo ""; } ?>" /></p>
        
        <p><span>Designation</span><input class="update-text-box desigedit" value="<?php if($memberprofile['designation']!=""){ echo $memberprofile['designation'];}else{ echo ""; } ?>" /></p>
        
      <!--  <p><span>Clinic Address</span><input class="update-text-box clinicaddedit" value="<?php if($memberprofile['clinicaddress']!=""){ echo $memberprofile['clinicaddress'];}else{ echo ""; } ?>" /><span1>max. 250 chars</span1></p>
        
        <p><span>Clinic Phone</span><input class="update-text-box clinicphoneedit" value="<?php if($memberprofile['clinicphone']!=""){ echo $memberprofile['clinicphone'];}else{ echo ""; } ?>" /></p>-->
    
    </div> 
    
    <div style="clear:both; height:30px;"></div>
    
    <div id="profile-titles">
    
    	<h2>About Me</h2>
    
    </div>
    
    <div id="profile-content">    
        
        <textarea class="update-textarea aboutme"><?php if($memberprofile['about']!=""){ echo $memberprofile['about'];}else{ echo ""; } ?></textarea>           
            
    </div>
    
    <div style="clear:both; height:30px;"></div>
    
    <div id="profile-titles">
    
    	<h2>Interests</h2>
    
    </div>
    
    <div id="profile-content">
    
    	<ul class="interestlist" style="margin-top: 15px;">
        
        	<?php
				$count = count($memberprofile['interests']);
				if($memberprofile['interests'][0]!=""){
					for($i=0;$i<$count;$i++){
						
						if($i==0){
							echo '<li style="list-style:none"><input class="update-text-box interest" value="'.$memberprofile['interests'][$i].'" /></li>';
						}else{
							echo '<li style="list-style:none"><input class="update-text-box interest" value="'.$memberprofile['interests'][$i].'" /><span2 class="delinterest">x</span2></li>';
						}
						
					}
				}else{
					echo '<li style="list-style:none"><input class="update-text-box interest" value="" /></li>';
				}			
			?>
        	                        
        </ul>
        
        <button style="float:left; margin:-40px 0 0 285px" id="editbut" class="moreinterest">More</button>      
    
    </div>
    
    <div style="clear:both; height:30px;"></div>
   	

</div>
   
   
   
  
 
<script type="text/javascript">
$(document).ready(function(){	
	
	$(".delpost").click(function(){
		
		var postid = $(this).attr("id");
		
		var r=confirm("Are you sure to delete the post ?")
		if (r==true){
  			$(".edit-err-notify").html("<font style=\"color:#f7d8ba\">Processing...</font>");
                 $.get('admincommunity/deletePost',{
                       'postid':postid			   

                 }, function(o) {  $(".edit-err-notify").html("<font style=\"color:#f7d8ba\">Post Deleted</font>"); 
                           setTimeout(function(){ location.reload();}, 2000);         
                 }, 'json');
				 
  		}
		
	});	
	
	$("input:radio").click(function(){
		
		var memberid=$(this).attr("name");//console.log(memberid);
		var deliver=$(this).val();
		
		if(deliver=="YES") var r=confirm("Are you sure to provided the ID Card/Certificate to this member?");
		
		else var r=confirm("Are you sure still not provided the ID Card/Certificate to this member?");
		
		if(r==true)
		{
		$.get('home/CheckMember',{
                       'memberid':memberid,
					   'deliver':deliver			   

                 }, function(o) {
                           setTimeout(function(){ location.reload();}, 500);         
                 }, 'json');
				 
		}
	});
	
	$("input:button").click(function(){
		
		var memberid=$(this).attr("id");
		var userid=$(this).attr("name");
		
		var r=confirm("Are you sure want to reset password to this member?");
		
		if(r==true)
		{
		$.get('home/ForgetMember',{
                       'memberid':memberid,
					   'userid':userid

                 }, function(o) {
                           setTimeout(function(){ location.reload();}, 500);         
                 }, 'json');
				 
		}
	});
	
});
</script>


<div id="profile-left">

	<img class="proimg" src="<?php echo $this->config->item('web_url');?>images/ap.jpg" />
    
    <ul>
    
    	<a href="home"><li>Dashboard</li></a>
        
        <a href="allusers"><li>View Users</li></a>
        
        <a href="searchusers"><li>Search Users</li></a>
        
        <a href="exportdata"><li>Export Data</li></a>
        
        <a href="newmember"><li>Add Member</li></a>
        
        <!--<a href="admincommunity"><li>Community</li></a>-->
        
        <!--<a href="addcollege"><li>Add College</li></a>
        
        <a href="collegelist"><li>College List</li></a>-->

       <!-- <a href="subjects"><li>Question Papers</li></a>
        
        <a href="notices"><li>Add Notifications</li></a>-->
        
        <a href="confregistrants"><li>Conference Registrants</li></a>
        
        <a href="preconfregistrants"><li>Preconference</li></a>
        
        <a href="testregistrants"><li>Test Registrants</li></a>
        
        <a href="abstracts"><li>Abstracts</li></a>
        
        <a href="nominees"><li>Nominees</li></a>
           
        <a href="election"><li>Election</li></a>
           
        <a href="presentation"><li>Presentation</li></a>
           
        <a href="annualmeet"><li>Annual Meet</li></a>
    
    </ul>

</div>

<div id="profile-right">

	<h1>Dr. <?php echo $membername['name']; ?><br /><span style="font-size:12px">Membership ID: admin</span></h1>
    
    <div class="clear"></div>
    
    <table class="approvaltable">
    
    <tr class="heading"><td colspan="5" style="text-align:center;">Waiting for Approval (<?php echo $waitingforapproval['member_count']; ?>)</td></tr>
    
    <?php echo $waitingforapproval['member_list']; ?>
    
    </table>     
    
	<div class="clear"></div>
    
    <table class="approvaltable">
    
    <tr class="heading"><td colspan="5" style="text-align:center;">Member Without IDcard/Certificate (<?php echo $ccdetails['detail_count']; ?>)</td></tr>
    
    <?php echo $ccdetails['detail_list']; ?>
    
    </table> 
    
    <div class="clear"></div>
    
    <table class="approvaltable forgetpass">
    
    <tr class="heading"><td colspan="5" style="text-align:center;">Member Forgot Password (<?php echo $forgetpass['fp_count']; ?>)</td></tr>
    
    <?php echo $forgetpass['fp_list']; ?>
    
    </table>  
    
    <div id="activityList">
    
    <h2>Recent Activities</h2> 
    
    <?php echo $recentactivities; ?>
    
    </div>   
    
    <div style="clear:both; height:30px;"></div>

</div>
   
   
   
  
 
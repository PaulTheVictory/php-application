
<script type="text/javascript">
$(document).ready(function(){
	
	$(".addsubjectbtn").click(function(){
		
		var name = $("#subjectname").val();
					
		if(name==""){ $("#subjectname").addClass('errclass');$(".add-err-notify1").html("Invalid Name");return;}
					
		$(".add-err-notify1").html("<font style=\"color:#339966\">Processing...</font>");
                 $.get('subjects/addSubject',{
					   'name':name

                 }, function(o) { 
				 		var obj1 = $.parseJSON(o);
						if(obj1[0] == 'exists'){
							$(".add-err-notify1").html("Subject Name Existed"); 							
						}else if(obj1[0] == 'success'){
				 			$(".add-err-notify1").html("<font style=\"color:#339966\">Subject added</font>"); 
                            setTimeout(function(){ location.reload();}, 500);  
						}else if(obj1[0] == ''){
							setTimeout(function(){ $(".add-err-notify1").html("Please Try again later."); }, 2000);
						}
                 });	 
		
		
	});
	
		
	 $("#profile-right").find("input").each(function(){

          $(this).click(function(){ $(this).removeClass("errclass");$(".add-err-notify1").text("");});

     });
	 
	 $(".subjectlist").click(function(){
		
		var subid = $(this).attr("id");
        		
		window.location.href = "<?php  echo base_url(); ?>questions?id="+subid;		
		
	});
	
	$("#genquestiontable").find(".reqqns").each(function(){
		
		$(this).keyup(function(){
			
			var totalqns = parseInt($(this).parent().parent().find(".totalqns").attr("id"));
			var reqqns = $(this).val();
			
			if(reqqns!=""){
				reqqns = parseInt(reqqns);
				if(!isNaN(reqqns)){
					if(reqqns>totalqns){
						$(this).val("0");
					}
				}else{
					$(this).val("0");
				}
			}
			
		});
		
	});
	
	$(".generateqnsbtn").click(function(){
		
		var subjectArray = [];
		
		$("#genquestiontable").find("tr").each(function(){
			
			var subjectid = $(this).attr("id");
			var reqqns = parseInt($(this).find(".reqqns").val());
			
			if(!isNaN(reqqns) && reqqns!=0){
				subjectArray.push(subjectid+"|"+reqqns);
			}
			
		});
		
		if(subjectArray.length === 0){
			alert("Enter No. of Questions in each subject");
		}else{
			
			subjectArray = JSON.stringify(subjectArray);
			
			$.get('subjects/generateQuestions',{
					   'subjectArray':subjectArray

                 }, function(o) { 
				 		var obj1 = $.parseJSON(o);
						if(obj1[0] == '' || obj1[0] == null){
							setTimeout(function(){ $(".add-err-notify1").html("Please Try again later."); }, 2000);
						}else{
							window.open(obj1[0], '_blank');
							//location.assign(obj1[0]);
						}
                 });
			
		}
		
	});

});
</script>

<div id="profile-left">

	<img class="proimg" src="<?php echo $this->config->item('web_url');?>images/ap.jpg" />
    
    <ul>
    
    	<a href="home"><li>Dashboard</li></a>
        
        <a href="allusers"><li>View Users</li></a>
        
        <a href="searchusers"><li>Search Users</li></a>
        
        <a href="exportdata"><li>Export Data</li></a>
        
        <a href="newmember"><li>Add Member</li></a>
        
        <a href="admincommunity"><li>Community</li></a>
        
        <!--<a href="addcollege"><li>Add College</li></a>
        
        <a href="collegelist"><li>College List</li></a>-->

        <a href="subjects"><li>Question Papers</li></a>
        
        <a href="notices"><li>Add Notifications</li></a>
        
        <a href="confregistrants"><li>Conference Registrants</li></a>
        
        <a href="preconfregistrants"><li>Preconference</li></a>
        
        <a href="testregistrants"><li>Test Registrants</li></a>
        
        <a href="abstracts"><li>Abstracts</li></a>
        
        <a href="nominees"><li>Nominees</li></a>
           
        <a href="election"><li>Election</li></a>
           
        <a href="presentation"><li>Presentation</li></a>
    
    </ul>

</div>

<div id="profile-right" >

	<h1>Dr. <?php echo $membername['name']; ?><br /><span style="font-size:12px">Membership ID: admin</span></h1>
    
    <div class="right-options">
    
    	<!--<button class="addcollege" id="addmembut">Add</button><br />
        <p style="margin:15px 0 0; text-align:right; color:#fff;" class="edit-err-notify"></p>-->
    
    </div>
    
    <div class="clear"></div>

	<h2>Add New Subject</h2> 
    
    <span style="float:left; margin:14px 5px; color:#1977a6; font-weight:bold;">Name</span>
    <input class="find-text-box" type="text" name="subject_name" value="" id="subjectname" />
    <button id="find-submit" class="addsubjectbtn">Add</button>
    <span style="font-size: 12px; color: #c03; padding: 0px 10px; float: left; margin: 15px 0px;" class="add-err-notify1"></span>
    
    <div style="clear:both; height:30px;"></div>  
    
    <h2>Subject List</h2> 
           
    <?php echo $allsubjects['subject_list']; ?> 	
    
    <div style="clear:both; height:30px;"></div>
    
    <h2>Generate Question Paper</h2>
    
    <?php echo $subjectsforgenerate['subject_list']; ?> 	
    
    <button id="find-submit" class="generateqnsbtn">Generate</button>
    
    <div style="clear:both; height:30px;"></div>  

</div>
   
   
   
  
 
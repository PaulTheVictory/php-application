
<script type="text/javascript">
$(document).ready(function(){	

	$('a.popcertificate').click(function (e) {
		
		e.preventDefault();
		
		var scrolltop = $(window).scrollTop()+50;
		var imglink = $(this).attr('href');
		var ext = imglink.split('.').pop().toLowerCase();
		
		if(ext!="pdf" && ext!="docx" && ext!="doc")
		{
			var img = $('<img />', { 
			  src: imglink,
			});
			$('#divLargerImage').html(img.clone().height('auto').width('50%')).css({'top':scrolltop}).add($('#divOverlay')).fadeIn();
		}
		else
		{
			window.open(imglink,'_blank');
		}
	});
	
	
	$('#divLargerImage').add($('#divOverlay')).click(function () {
		$('#divLargerImage').add($('#divOverlay')).fadeOut(function () {
			$('#divLargerImage').empty();
		});
	});

	
	
	
});
</script>

<style>
	#profile-content span{display: inline-block;float: none;vertical-align: middle;height: auto;}
	#profile-content span1{display: inline-block;vertical-align: middle;width: 450px;}
</style>

<div id="profile-left">
	
	<img class="proimg" src="<?php echo $this->config->item('web_url');?>images/ap.jpg" />

	<ul>
    
    	<a href="javascript:history.go(-1)"><li>Back</li></a>
    	
    </ul>  

</div>

<div id="profile-right">

	<h1><?php if($memberprofile['name']!=""){ echo $memberprofile['name'];}else{ echo ""; } ?></h1>   
    
    <div class="right-options">
    
        
    </div>   
    
    <div class="clear" style="height:30px;"></div>

	<div id="profile-titles">
    
    	<h2>Contact Details</h2>
    
    </div>
    
    <div id="profile-content">
    
    	<p><span>Mobile</span><span1 style="color:#333"><?php if($memberprofile['mobile']!=""){ echo $memberprofile['mobile'];}else{ echo "-"; } ?></span1></p>
           
        <p><span>Email</span><span1 style="color:#333"><?php if($memberprofile['email']!=""){ echo $memberprofile['email'];}else{ echo "-"; } ?></span1></p>
    
    </div>
    
    <div style="clear:both; height:30px;"></div>
    
    <div id="profile-titles">
    
    	<h2>Official Details</h2>
    
    </div>
    
     <div id="profile-content">
       
   		<p><span>College/Clinic Name</span><span1 style="color:#333"><?php if($memberprofile['cname']!=""){ echo $memberprofile['cname'];}else{ echo "-"; } ?></span1></p>
        
        <p><span>Application by</span><span1 style="color:#333"><?php if($memberprofile['appby']!=""){ echo $memberprofile['appby'];}else{ echo "-"; } ?></span1></p>
        
        <p><span>Applying For</span><span1 style="color:#333"><?php if($memberprofile['applyfor']!=""){ echo $memberprofile['applyfor'];}else{ echo "-"; } ?></span1></p>
         
        <p><span>CV</span><span1 style="color:#333"><?php if($memberprofile['cv']!=""){ echo '<a class="popcertificate" style="margin:5px auto;text-decoration: underline;" href="'.base_url().'docs/nominee/'.$memberprofile['memberid'].'/'.$memberprofile['cv'].'">Click to view</a>';}else{ echo "-"; } ?></span1></p>
        
        <p><span>Case Files</span><span1 style="color:#333"><?php if($memberprofile['casefiles']!=""){ echo '<a class="popcertificate" style="margin:5px auto;text-decoration: underline;" href="'.base_url().'docs/nominee/'.$memberprofile['memberid'].'/'.$memberprofile['casefiles'].'">Click to view</a>';}else{ echo "-"; } ?></span1></p>
    
    </div> 
    
    <div style="clear:both; height:30px;"></div>
    


</div>
   
   
   
<div id="divLargerImage"></div>

<div id="divOverlay"></div>     
 

<script type="text/javascript">
$(document).ready(function(){	

	$('a.popcertificate').click(function (e) {
		
		e.preventDefault();
		
		var scrolltop = $(window).scrollTop()+50;
		var imglink = $(this).attr('href');
		var ext = imglink.split('.').pop().toLowerCase();
		
		if(ext!="pdf" && ext!="docx" && ext!="doc")
		{
			var img = $('<img />', { 
			  src: imglink,
			});
			$('#divLargerImage').html(img.clone().height('auto').width('50%')).css({'top':scrolltop}).add($('#divOverlay')).fadeIn();
		}
		else
		{
			window.open(imglink,'_blank');
		}
	});
	
	
	$('#divLargerImage').add($('#divOverlay')).click(function () {
		$('#divLargerImage').add($('#divOverlay')).fadeOut(function () {
			$('#divLargerImage').empty();
		});
	});

	
	
	
});
</script>

<style>
	#profile-content span{display: inline-block;float: none;vertical-align: middle;height: auto;}
	#profile-content span1{display: inline-block;vertical-align: middle;width: 450px;}
</style>

<div id="profile-left">
	
	<img class="proimg" src="<?php echo $this->config->item('web_url');?>images/ap.jpg" />

	<ul>
    
    	<a href="javascript:history.go(-1)"><li>Back</li></a>
    	
    </ul>  

</div>

<div id="profile-right">

	<h1><?php if($memberprofile['name']!=""){ echo $memberprofile['name'];}else{ echo ""; } ?></h1>   
    
    <div class="right-options">
    
        
    </div>    
    
    <div class="clear" style="height:30px;"></div>
    
    <div id="profile-titles">
    
    	<h2>Membership Details</h2>
    
    </div>
    
    <div id="profile-content">
           
        <p><span>IACDE ID</span><span1 style="color:#333"><?php if($memberprofile['memid']!=""){ echo $memberprofile['memid'];}else{ echo "-"; } ?> </span1></p>
            
        <p><span>Member Type</span><span1 style="color:#333"><?php if($memberprofile['memtype']!=""){ echo $memberprofile['memtype'];}else{ echo "-"; } ?> </span1></p>
        
        <p><span>Amount paid</span><span1 style="color:#333"><?php if($memberprofile['paymentamount']!=""){ echo "&#8377; ".$memberprofile['paymentamount'];}else{ echo "-"; } ?></span1></p>
        
        <p><span>Payment mode</span><span1 style="color:#333"><?php if($memberprofile['paymentmode']!=""){ echo $memberprofile['paymentmode'];}else{ echo "-"; } ?></span1></p>
        
        <p><span>Date of Register</span><span1 style="color:#333"><?php if($memberprofile['paymenttime']!=""){ echo date('d M Y, h:i:s A',strtotime($memberprofile['paymenttime']));}else{ echo "-"; } ?></span1></p>
        
        <p><span>Registration No</span><span1 style="color:#333"><?php if($memberprofile['regno']!=""){ echo $memberprofile['regno'];}else{ echo "-"; } ?></span1></p>
        
        <p><span>Member Proof</span><span1 style="color:#333"><?php if($memberprofile['proof']!=""){ echo '<a class="popcertificate" style="margin:5px auto;text-decoration: underline;" href="'.base_url().'docs/proof/'.$memberprofile['proof'].'">Click to view</a>';}else{ echo "-"; } ?></span1></p>
        
        <p><span>Payment Screenshot</span><span1 style="color:#333"><?php if($memberprofile['paymentphoto']!=""){ echo '<a class="popcertificate" style="margin:5px auto;text-decoration: underline;" href="'.base_url().'docs/transfer/'.$memberprofile['paymentphoto'].'">Click to view</a>';}else{ echo "-"; } ?></span1></p>
    
    </div>
    
    <div style="clear:both; height:30px;"></div>

	<div id="profile-titles">
    
    	<h2>Contact Details</h2>
    
    </div>
    
    <div id="profile-content">
    
    	<p><span>Mobile</span><span1 style="color:#333"><?php if($memberprofile['mobile']!=""){ echo $memberprofile['mobile'];}else{ echo "-"; } ?></span1></p>
        
        <p><span>Landline</span><span1 style="color:#333"><?php if($memberprofile['phone']!=""){ echo $memberprofile['phone'];}else{ echo "-"; } ?></span1></p>
   
        <p><span>Email</span><span1 style="color:#333"><?php if($memberprofile['email']!=""){ echo $memberprofile['email'];}else{ echo "-"; } ?></span1></p>
    
    </div>
    
    <div style="clear:both; height:30px;"></div>
    
    <div id="profile-titles">
    
    	<h2>Personal Details</h2>
    
    </div>
    
    <div id="profile-content">       	
        
        <p><span>Gender</span><span1 style="color:#333"><?php if($memberprofile['sex']!=""){ echo $memberprofile['sex'];}else{ echo "-"; } ?></span1></p>
          
        <p><span>Residential Address</span><span1 style="color:#333"><?php if($memberprofile['address']!=""){ echo $memberprofile['address'];}else{ echo "-"; } ?></span1></p>
                
        <p><span>City</span><span1 style="color:#333"><?php if($memberprofile['contactcity']!=""){ echo $memberprofile['contactcity'];}else{ echo "-"; } ?></span1></p>
        
        <p><span>State</span><span1 style="color:#333"><?php if($memberprofile['contactstate']!=""){ echo $memberprofile['contactstate'];}else{ echo "-"; } ?></span1></p>
        
        <p><span>Pincode</span><span1 style="color:#333"><?php if($memberprofile['contactpin']!=""){ echo $memberprofile['contactpin'];}else{ echo "-"; } ?></span1></p>
    
    </div>
    
    <div style="clear:both; height:30px;"></div>
    
    <div id="profile-titles">
    
    	<h2>Official Details</h2>
    
    </div>
    
     <div id="profile-content">
       
   		<p><span>Organisation</span><span1 style="color:#333"><?php if($memberprofile['organisation']!=""){ echo $memberprofile['organisation'];}else{ echo "-"; } ?></span1></p>
        
        <p><span>Designation</span><span1 style="color:#333"><?php if($memberprofile['designation']!=""){ echo $memberprofile['designation'];}else{ echo "-"; } ?></span1></p>
    
    </div> 
    
    <div style="clear:both; height:30px;"></div>
    


</div>
   
   
   
<div id="divLargerImage"></div>

<div id="divOverlay"></div>     
 
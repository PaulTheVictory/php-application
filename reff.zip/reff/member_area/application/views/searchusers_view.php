
<script type="text/javascript">
$(document).ready(function(){	
		
	$(document).delegate('.memberlist','click',function(){
		
		var memid = $(this).attr("id");
        		
		window.location.href = "<?php  echo base_url(); ?>editmemberpage?id="+memid;		
		
	});
	
	$(".namesearch").click(function(){
		searchByName();		
	});
	
	$(".idsearch").click(function(){
		searchById();		
	});
	
	function searchByName() {
        var searchtag = $("#searchbyname").val();
        if(searchtag == '') {
            return;
        }
		$(".resultbyid").css('display','none');
        $(".resultbyname").css('display','block');
        
        var searchurl = 'searchusers/searchbyName?searchtag='+searchtag;
        $.ajax({
            url:searchurl,
            data:{},
            success:function(data, textStatus, XMLHttpRequest) {
                var o = typeof XMLHttpRequest == 'object' ? XMLHttpRequest : '';
                if (o.status == 200) {
					var ret = data.split("|");
                    $("#nameres").html(ret[0]);
					
                }
            }
        });
    }
	
	function searchById() {
        var searchtag = $("#searchbyid").val();
        if(searchtag == '') {
            return;
        }
		$(".resultbyname").css('display','none');
        $(".resultbyid").css('display','block');
        
        var searchurl = 'searchusers/searchbyId?searchtag='+searchtag;
        $.ajax({
            url:searchurl,
            data:{},
            success:function(data, textStatus, XMLHttpRequest) {
                var o = typeof XMLHttpRequest == 'object' ? XMLHttpRequest : '';
                if (o.status == 200) {
					var ret = data.split("|");
                    $("#idres").html(ret[0]);
					
                }
            }
        });
    }
	
	
	
});
</script>

<div id="profile-left">

	<img class="proimg" src="<?php echo $this->config->item('web_url');?>images/ap.jpg" />
    
    <ul>
    
    	<a href="home"><li>Dashboard</li></a>
        
        <a href="allusers"><li>View Users</li></a>
        
        <a href="searchusers"><li>Search Users</li></a>
        
        <a href="exportdata"><li>Export Data</li></a>
        
        <a href="newmember"><li>Add Member</li></a>
        
        <!--<a href="admincommunity"><li>Community</li></a>-->
        
        <!--<a href="addcollege"><li>Add College</li></a>
        
        <a href="collegelist"><li>College List</li></a>-->

       <!-- <a href="subjects"><li>Question Papers</li></a>
        
        <a href="notices"><li>Add Notifications</li></a>-->
        
        <a href="confregistrants"><li>Conference Registrants</li></a>
        
        <a href="preconfregistrants"><li>Preconference</li></a>
        
        <a href="testregistrants"><li>Test Registrants</li></a>
        
        <a href="abstracts"><li>Abstracts</li></a>
        
        <a href="nominees"><li>Nominees</li></a>
           
        <a href="election"><li>Election</li></a>
           
        <a href="presentation"><li>Presentation</li></a>
           
        <a href="annualmeet"><li>Annual Meet</li></a>
    
    </ul>

</div>

<div id="profile-right">

	<h1>Dr. <?php echo $membername['name']; ?><br /><span style="font-size:12px">Membership ID: admin</span></h1>
    
    <div class="clear"></div>

	<h2>Search Users</h2>  
    
    <div class="clear"></div>
    
    <div id="search-fields">      	 	
              	
            	<span style="float:left; margin:14px 5px; color:#1977a6; font-weight:bold;">Name</span><input class="find-text-box" type="text" name="search_name" value="" id="searchbyname" />
                
                <input type="submit" value="Search" id="find-submit" class="namesearch" />
                
                <div class="clear"></div>
                
                <span style="float:left; margin:14px 5px; color:#1977a6; font-weight:bold;">ID&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><input class="find-text-box" type="text" name="search_id" value=""  id="searchbyid" />
                
                <input type="submit" value="Search" id="find-submit" class="idsearch" />
                
           
    
    </div>
    
    <div class="clear"></div>
    
    <div class="resultbyname" style="display:none;">
    
    	<h2>Search Results (By Name)</h2>
    
    	<div id="nameres"></div>
    
    </div> 
    
    <div class="resultbyid" style="display:none;">
    
    	<h2>Search Results (By ID)</h2>
    
    	<div id="idres"></div>
    
    </div> 	

</div>
   
   
   
  
 
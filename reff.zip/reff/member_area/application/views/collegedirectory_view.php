
<script type="text/javascript">
$(document).ready(function(){	
		
	$(".collegelist").click(function(){
		
		var colid = $(this).attr("id");
        		
		window.location.href = "<?php  echo base_url(); ?>collegepage?id="+colid;		
		
	});
	
	
	
});
</script>


<h1>Colleges Directory</h1>

<div style="margin:30px 10px;">

	<?php echo $coldirectory; ?> 
    
</div>
   

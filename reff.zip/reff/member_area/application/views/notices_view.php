
<link rel="stylesheet" type="text/css" href="../css/dataTables.css" />
<script src="js/jquery.dataTables.js?v=1.0" type="text/javascript"></script>
<script type="text/javascript">
$(document).ready(function(){	
		
	$(".addmember").click(function(){
		
		var notify = $(".notifyadd").val();
                var link = $(".linkadd").val();
                
                if(notify == "") { alert("Please provide some notification");return;}
                
                if(confirm("Are you sure to add this notification ?")) {
                    
                $(this).text("Processing...");
                
                 $.get('notices/addNotification', {
                                    'message': notify, 'link': link

                                 }, function (o) {
                                     var obj1 = $.parseJSON(o);
                                     if (obj1[0] === 'success') {
                                         oTable.fnDraw();
                                         $(".addmember").text("Add");
                                         $(".notifyadd").val("");
                                         $(".linkadd").val("");
                                     } else if (obj1[0] === 'fail') {
                                         alert("Error!!! please try again");
                                     }
                                 });
                }
		
	});
	
          var columnData = [
                    { "data": "date" },
                    { "data": "news" },
                    { "data": "link" }                    
                  ];
         columnData.push( {data: "notifyid","visible":true} );
        // columnData.push( {data: "memtype","visible":false} );
         
       
        var oTable = $('#memberstable').dataTable({
                    "bProcessing": true,
                    "bServerSide": true,
                    "sPaginationType": "full_numbers",
                    "ajax": {
                    "url": 'notices/getNotifications',
                    "type": "POST"
                     }, 
                     "oLanguage": {
                        "sProcessing": "<img src='<?php echo base_url(); ?>images/loader.gif'>"
                    },
                    'iDisplayLength': 25,
                    "columns": columnData,
                    "fnDrawCallback": function( oSettings ) {
                        
                         $("#memberstable").find(".del").each(function(){

                            $(this).click(function(){ 

                              if(confirm("Are you sure to delete this notification ?")) {
                                    var ide = $(this).attr("id");
                                    $.get('notices/delNotification',{
                                                               'ide':ide

                                                    }, function(o) { 
                                                            var obj1 = $.parseJSON(o);
                                                    if (obj1[0] === 'success') {
                                                        oTable.fnDraw(); 
                                                    } else if (obj1[0] === 'fail') {
                                                       alert("Error!!! please try again");
                                                }
                                    });
                                }

                              });
                        

                          });
                            
                    }
         }); 
         
     
	
});
</script>
<style type="text/css">

    .sortable {
    border: 1px solid #ddd;
    border-collapse: collapse;
    color: #333;
    margin: 10px auto;
    width: 100%;
}
.dataTables_wrapper input[type="text"] {
    padding: 0;
}
.dataTables_wrapper select {
    padding: 0;
}
.sortable tr th {
    border-right: 1px solid #ddd;
    padding: 10px 0;
}
.sortable tr td {
    border-right: 1px solid #ddd;
    padding: 10px 5px;
    text-align: center;
}
.sortable tr td a {
    color: #333;
}

#profile-right h2 {
    margin: 0px 0px 10px 0px;
}

#memberstable_filter { right:10px;}



</style>

<div id="profile-left">

	<img class="proimg" src="<?php echo $this->config->item('web_url');?>images/ap.jpg" />
    
    <ul>
    
    	<a href="home"><li>Dashboard</li></a>
        
        <a href="allusers"><li>View Users</li></a>
        
        <a href="searchusers"><li>Search Users</li></a>
        
        <a href="exportdata"><li>Export Data</li></a>
        
        <a href="newmember"><li>Add Member</li></a>
        
        <a href="admincommunity"><li>Community</li></a>
        
        <!--<a href="addcollege"><li>Add College</li></a>
        
        <a href="collegelist"><li>College List</li></a>-->

        <a href="subjects"><li>Question Papers</li></a>
        
        <a href="notices"><li>Add Notifications</li></a>
        
        <a href="confregistrants"><li>Conference Registrants</li></a>
        
        <a href="preconfregistrants"><li>Preconference</li></a>
        
        <a href="testregistrants"><li>Test Registrants</li></a>
        
        <a href="abstracts"><li>Abstracts</li></a>
        
        <a href="nominees"><li>Nominees</li></a>
           
        <a href="election"><li>Election</li></a>
           
        <a href="presentation"><li>Presentation</li></a>
    
    </ul>

</div>

<div id="profile-right">

	<h1>Dr. <?php echo $membername['name']; ?><br /><span style="font-size:12px">Membership ID: admin</span></h1>
    
    <div class="clear"></div>

	 
    <div id="profile-content" style="float: none; border-bottom: 1px solid #ccc; padding-bottom: 15px; width: 100%;">
    
        <p><span>Notification</span><input style="width: 70%" class="update-text-box notifyadd" value="" /></p>
        
        <p><span>Link</span><input style="width: 70%" class="update-text-box linkadd" value="" /></p>
   
        <p style="text-align: center;width: 100%;margin-top: 20px"><button class="addmember" id="addmembut" style="float: none">Add</button></p>
   	
    </div>
    <div class="clear"></div>
    
  
    <div style="clear:both; height:40px;"></div> 
    
    <?php //echo $allusers['member_list']; ?> 	
    
    <?php echo $this->table->generate();  ?> 

</div>
   
   
   
  
 
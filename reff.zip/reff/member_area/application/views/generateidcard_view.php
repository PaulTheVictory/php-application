        <html><head>
                <title>Generate ID Card</title>
    <script type="text/javascript" src="https://code.jquery.com/jquery-2.2.3.min.js"></script>
<script>
                    $(document).ready(function(){
                        window.print();
                    });
              </script>
    </head>
    <body>

<div> 
    <img style="width:105%;margin-top :-8px; margin-left: -6px" src="generateidcard/showIdcard?name=<?php echo $membername['name'];?>&id=<?php echo $membername['userid'];?>&role=<?php echo $membername['role'];?>&img=<?php echo $membername['profileimg'];?>">
    
    </div>

</body>
</html>
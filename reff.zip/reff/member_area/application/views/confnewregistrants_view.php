<a href="election"><li>Election</li></a><a href="election"><li>Election</li></a><a href="election"><li>Election</li></a><a href="election"><li>Election</li></a>
<script type="text/javascript">
$(document).ready(function(){
	
	$(".addmember").click(function(){
		
		var title = $(".title:checked").val();
		var name = $(".nameadd").val();
		var userid = $(".memidadd").val();
		var regtype = $(".selectedtype").val();
		var mobile = $(".mobileadd").val();
        var phone = $(".phoneadd").val();
        var email = $(".emailadd").val();
		var gender = $(".genderadd").val();
		var age = $(".ageadd").val();
		var address = $(".addressadd").val();
		var contactstate = $(".contactstateadd").val();
		var contactcity = $(".contactcityadd").val();
		var contactpin = $(".contactpinadd").val();
		var college = $(".collegeadd").val();
		var designation = $(".desigadd").val();
		var organisation = $(".organisation").val();	
		
		var payamount = $(".payamount").val();
		var paymode = $(".paymode").val();
		var payid = $(".payid").val();
					
		regex   = new RegExp('^[a-zA-Z][a-zA-Z\.-/ ]{3,40}$');
		valid = regex.test(name);
		if(!valid || name==""){ $(".nameadd").addClass('errclass');$(".edit-err-notify").text("Invalid Member Name");return;}
		
		if(userid==""){ $(".memidadd").addClass('errclass');$(".edit-err-notify").text("Invalid Member ID");return;}
				
		if(regtype==""||regtype==null){ $(".edit-err-notify").text("Invalid Registration type");return;}
			
		regex   = new RegExp('^[0-9 \-]{5,20}$');
        valid = regex.test(mobile);
        if(!valid){ $(".mobileadd").addClass('errclass');$(".edit-err-notify").text("Invalid Mobile Number");return;}
		
		regex   = new RegExp('^[0-9 \-]{5,20}$');
        valid = regex.test(phone);
        if(!valid){ $(".phoneadd").addClass('errclass');$(".edit-err-notify").text("Invalid Phone Number");return;}
		
		regex   = new RegExp('^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$');
        valid = regex.test(email);
        if(!valid){ $(".emailadd").addClass('errclass');$(".edit-err-notify").text("Invalid Email");return;}
		
		if(gender!="Male" && gender!="Female" && gender!=""){ $(".genderadd").addClass('errclass');$(".edit-err-notify").text("Invalid Gender");return;}
		
		regex   = new RegExp('^[0-9 \-]{1,3}$');
        valid = regex.test(age);
        if(!valid){ $(".ageadd").addClass('errclass');$(".edit-err-notify").text("Invalid Age");return;}
		
		regex   = new RegExp('^[a-zA-Z0-9#][a-zA-Z0-9\n\.,-_/#:&() ]{3,250}$');
        valid = regex.test(address);
        if(!valid){ $(".addressadd").addClass('errclass');$(".edit-err-notify").text("Invalid Address");return;}
		
		regex   = new RegExp('^[a-zA-Z][a-zA-Z\.-/ ]{3,100}$');
		valid = regex.test(contactcity);
		if(!valid){ $(".contactcityadd").addClass('errclass');$(".edit-err-notify").text("Enter City");return;}
		
		regex   = new RegExp('^[a-zA-Z][a-zA-Z\.-/ ]{3,100}$');
		valid = regex.test(contactstate);
		if(!valid){ $(".contactstateadd").addClass('errclass');$(".edit-err-notify").text("Enter State");return;}
		
		regex   = new RegExp('^[0-9 \-]{5,10}$');
        valid = regex.test(contactpin);
        if(!valid){ $(".contactpinadd").addClass('errclass');$(".edit-err-notify").text("Enter Pincode");return;}
		
		if(designation==""){ $(".desigadd").addClass('errclass');$(".edit-err-notify").text("Enter Designation");return;}
		
		if(organisation==""){ $(".organisation").addClass('errclass');$(".edit-err-notify").text("Enter Organisation");return;}
		
		regex   = new RegExp('^[0-9 \-]{1,10}$');
        valid = regex.test(payamount);
        if(!valid){ $(".payamount").addClass('errclass');$(".edit-err-notify").text("Enter Payment Amount");return;}
		
		if(paymode=="Choose"){ $(".paymode").addClass('errclass');$(".edit-err-notify").text("Select Payment Mode");return;}
		
		$(".edit-err-notify").html("<font style=\"color:#f7d8ba\">Processing...</font>");
                 $.get('confnewregistrants/createRegistrants',{
					   'name':name, 
					   'userid':userid,
					   'role':regtype,
                       'mobile':mobile,
                       'phone':phone,
                       'email':email,
					   'gender':gender,
					   'age':age,
					   'address':address,
					 'contactcity':contactcity,
					   'contactstate':contactstate,
					   'contactpin':contactpin,
					   'college':college,
					   'designation':designation,
					   'organisation':organisation,
					   'payamount':payamount,
					   'paymode':paymode,
					   'payid':payid,
					 'title':title

                 }, function(o) { 
				 		var obj1 = $.parseJSON(o);
						if(obj1[0] == 'exists'){
							$(".edit-err-notify").html("<font style=\"color:#f7d8ba\">Already Registered</font>"); 							
						}else if(obj1[0] == 'success'){
				 			$(".edit-err-notify").html("<font style=\"color:#f7d8ba\">Registrant Created</font>");
							setTimeout(function(){ location.assign('confregistrants'); }, 2000);
						}else if(obj1[0] == ''){
							setTimeout(function(){ $(".edit-err-notify").html("<font style=\"color:#f7d8ba\">Please Try again later.</font>"); }, 2000);
						}
                 });	 
		
		
	});
	
		
	 $("#profile-right").find("input").each(function(){

          $(this).click(function(){ $(this).removeClass("errclass");$(".edit-err-notify").text("");});

     });
	 
	 $(".memtype").click(function()
	 {
		 var parElement = $(this).parent();
		 
		 $(parElement).find("input").each(function(){
		 		if($(this).hasClass("selectedtype")){
		 		 	$(this).removeClass("selectedtype");
				}
		 });
		 
		 $(this).addClass("selectedtype");
	 });

});
</script>

<style>
	.update-text-box.title {width: auto;vertical-align: middle;}
</style>

<div id="profile-left">

	<img class="proimg" src="<?php echo $this->config->item('web_url');?>images/ap.jpg" />
    
    <ul>
    
    	<a href="home"><li>Dashboard</li></a>
        
        <a href="allusers"><li>View Users</li></a>
        
        <a href="searchusers"><li>Search Users</li></a>
        
        <a href="exportdata"><li>Export Data</li></a>
        
        <a href="newmember"><li>Add Member</li></a>
        
        <a href="admincommunity"><li>Community</li></a>

        <a href="subjects"><li>Question Papers</li></a>
        
        <a href="notices"><li>Add Notifications</li></a>
        
        <a href="confregistrants"><li>Conference Registrants</li></a>
        
        <a href="preconfregistrants"><li>Preconference</li></a>
        
        <a href="testregistrants"><li>Test Registrants</li></a>
        
        <a href="abstracts"><li>Abstracts</li></a>
    
    </ul>

</div>

<div id="profile-right">

	<h1>Dr. <?php echo $membername['name']; ?><br /><span style="font-size:12px">Membership ID: admin</span></h1>
    
    <div class="right-options">
    
    	<button class="addmember" id="addmembut">Add</button><br />
        <p style="margin:15px 0 0; text-align:right; color:#fff;" class="edit-err-notify"></p>
    
    </div>
    
    <div class="clear"></div>

	<h2>Add New Registrants</h2> 
    
    <div id="profile-titles">
    
    	<h2>Membership Details</h2>
    
    </div>
    
    <div id="profile-content">
    
   		<p><span>Title</span>
				 
			  <input type="radio" name="title" class="update-text-box title" value="Prof"/>Prof
			  <input type="radio" name="title" class="update-text-box title" value="Dr" checked />Dr
			  <input type="radio" name="title" class="update-text-box title" value="Mr"/>Mr
			  <input type="radio" name="title" class="update-text-box title" value="Ms"/>Ms
			  <input type="radio" name="title" class="update-text-box title" value="Mrs"/>Mrs
		</p>
    
    	<p><span>Name</span><input class="update-text-box nameadd" value="" /></p>
        
        <p><span>IACDE ID</span><input class="update-text-box memidadd" value="" /></p>
           
        <p><span>Registration Type</span><input class="memtype" style="width:15px; height:auto;" type="radio" value="Delegates" name="type" /> Delegates <input class="memtype" style="width:15px; height:auto;" type="radio" value="Students" name="type" /> Students</p>
            
    </div>
    
    <div style="clear:both; height:30px;"></div>
    
    <div id="profile-titles">
    
    	<h2>Contact Details</h2>
    
    </div>
    
    <div id="profile-content">
    
    	<p><span>Mobile</span><input class="update-text-box mobileadd" value="" /><span1>eg: 9876543210</span1></p>
        
        <p><span>Residence Number</span><input class="update-text-box phoneadd" value="" /><span1>eg: 044-12345678</span1></p>
   
   		<p><span>Email</span><input class="update-text-box emailadd" value="" /><span1>eg: info@example.com</span1></p>
    
    </div>
    
    <div style="clear:both; height:30px;"></div>
    
    <div id="profile-titles">
    
    	<h2>Personal Details</h2>
    
    </div>
    
    <div id="profile-content">
    
    	<p><span>Gender</span><input class="update-text-box genderadd" value="" /><span1>eg: Male / Female</span1></p>
          
        <p><span>Age</span><input class="update-text-box ageadd" value="" /></p>
           
        <p><span>Address</span><input class="update-text-box addressadd" value="" /><span1>max. 250 chars</span1></p>
               
        <p><span>City</span><input class="update-text-box contactcityadd" value="" /></p>
                
        <p><span>State</span><select name="state" class="update-select contactstateadd"><option selected="selected" value="">---------------- Select ---------------</option><option value="Andaman and Nicobar Islands">Andaman and Nicobar Islands</option><option value="Andhra Pradesh">Andhra Pradesh</option><option value="Arunachal Pradesh">Arunachal Pradesh</option><option value="Assam">Assam</option><option value="Bihar">Bihar</option><option value="Chandigarh">Chandigarh</option><option value="Chhattisgarh">Chhattisgarh</option><option value="Dadra and Nagar Haveli">Dadra and Nagar Haveli</option><option value="Daman and Diu">Daman and Diu</option><option value="Delhi">Delhi</option><option value="Goa">Goa</option><option value="Gujarat">Gujarat</option><option value="Haryana">Haryana</option><option value="Himachal Pradesh">Himachal Pradesh</option><option value="Jammu and Kashmir">Jammu and Kashmir</option><option value="Jharkhand">Jharkhand</option><option value="Karnataka">Karnataka</option><option value="Kenmore">Kenmore</option><option value="Kerala">Kerala</option><option value="Lakshadweep">Lakshadweep</option><option value="Madhya Pradesh">Madhya Pradesh</option><option value="Maharashtra">Maharashtra</option><option value="Manipur">Manipur</option><option value="Meghalaya">Meghalaya</option><option value="Mizoram">Mizoram</option><option value="Nagaland">Nagaland</option><option value="Narora">Narora</option><option value="Natwar">Natwar</option><option value="Odisha">Odisha</option><option value="Paschim Medinipur">Paschim Medinipur</option><option value="Pondicherry">Pondicherry</option><option value="Punjab">Punjab</option><option value="Rajasthan">Rajasthan</option><option value="Sikkim">Sikkim</option><option value="Tamil Nadu">Tamil Nadu</option><option value="Telangana">Telangana</option><option value="Tripura">Tripura</option><option value="Uttar Pradesh">Uttar Pradesh</option><option value="Uttarakhand">Uttarakhand</option><option value="Vaishali">Vaishali</option><option value="West Bengal">West Bengal</option><option value="Other">Other</option></select></p>
        
        <p><span>Pincode</span><input class="update-text-box contactpinadd" value="" /></p>
    
    </div>
    
    <div style="clear:both; height:30px;"></div>
    
    <div id="profile-titles">
    
    	<h2>Official Details</h2>
    
    </div>
    
    <div id="profile-content">
       
   		<p><span>College</span><input class="update-text-box collegeadd" value="" /></p>
        
        <p><span>Designation</span><input class="update-text-box desigadd" value="" /></p>
                  
        <p><span>Hospital/Organisation</span><input class="update-text-box organisation" value="" /></p>                  
                    
    </div> 
    
    <div style="clear:both; height:30px;"></div>
    
    <div id="profile-titles">
    
    	<h2>Payment Details</h2>
    
    </div>
    
    <div id="profile-content">
    
    	<p><span>Payment Amount</span><input class="update-text-box payamount" value="" /></p>
   
   		<p><span>Mode of Payment</span><select class="update-text-box paymode"><option>Choose</option><option>DD</option><option>NEFT</option><option>CASH</option><option>ONLINE</option></select></p>
        
        <p><span>DD No/Txn Id</span><input class="update-text-box payid" value="" /></p>
            
    </div> 
    
    <div style="clear:both; height:30px;"></div>
        

</div>
   
   
   
  
 
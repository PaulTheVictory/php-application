
<script type="text/javascript">
$(document).ready(function(){	

	$(".createcomm").click(function(){
		
		var createname = $(".createname").val();
        var createdesc = $(".createdesc").val();
		var adminname = "<?php echo $membername['name']; ?>";
								
		$(".edit-err-notify").html("<font style=\"color:#44f2f8\">Processing...</font>");
                 $.get('createcommunity/createCommunity',{
                       'createname':createname,
                       'createdesc':createdesc,
					   'adminname':adminname			   

                 }, function(o) {  $(".edit-err-notify").html("<font style=\"color:#44f2f8\">Community Created</font>"); 
                           setTimeout(function(){ location.assign("communitylist");}, 2000);         
                 }, 'json');
				 
	});
	
	
	
});
</script>

<div id="profile-left">

	<img class="proimg" src="<?php echo base_url();?>docs/profile/<?php echo $membername['profileimg']; ?>" width="140" height="160" />
    
    <ul>
    
    	<a href="home"><li>Recent Activity</li></a>
        
        <a href="profile"><li>Profile</li></a>
        
        <a href="bio"><li>Bio</li></a>
        
        <a href="connectionlist"><li>Find a Connection</li></a>
        
        <a href="messageinbox"><li>Messages</li></a>
        
        <a href="communitylist"><li>Communities</li></a>
        
        <?php if($membername['role']=="STUDENT"){ ?><a href="upgrademembership"><li>Upgrade Membership</li></a><?php } ?>
    
    </ul>

</div>

<div id="profile-right">

	<h1>Dr. <?php echo $membername['name']; ?><br /><span style="font-size:12px">Membership ID: <?php echo $membername['userid']; ?></span></h1>
    
    <div class="right-options">
    
    	<button class="createcomm" id="editbut">Save</button><br />
        <p style="margin:15px 0 0; text-align:right; color:#fff;" class="edit-err-notify"></p>
    
    </div>
    
    <div class="clear"></div>

	<div id="profile-titles">
    
    	<h2>Community Name</h2>
    
    </div>
    
    <div id="profile-content">
    
    	<p><input class="create-text-box createname" value="" /><span1>max. 100 characters</span1></p>
            
    </div>
    
    <div style="clear:both; height:30px;"></div>
    
    <div id="profile-titles">
    
    	<h2>Description</h2>
    
    </div>
    
    <div id="profile-content">
    
    	 <p><textarea class="create-textarea createdesc"></textarea><span1>max. 250 characters</span1></p>
    
    </div>
    
    
    <div style="clear:both; height:30px;"></div>
    
   <!-- <div id="profile-titles">
    
    	<h2>Profile Image</h2>
    
    </div>
    
    <div id="profile-content">
    
    	  <p><button style="float:left;" class="uploadcommimg" id="editbut">Uplaod</button></p> 
    
    </div>
    
    
    <div style="clear:both; height:30px;"></div> -->
    
      	

</div>
   
   
   
  
 
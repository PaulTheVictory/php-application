
<script type="text/javascript">
$(document).ready(function(){	
		
	$(".editstaff").click(function(){
		
		var staffid = $(this).parent().attr("id");
        		
		window.location.href = "<?php  echo base_url(); ?>editstaff?id="+staffid;		
		
	});
	
	
	
});
</script>

<div id="profile-left" style="background-image:url(<?php echo $this->config->item('web_url');?>images/college-top.jpg)">

	<img class="proimg" src="<?php echo $this->config->item('web_url');?>docs/colleges/colp.jpg" width="140" height="160" />
    
    <ul>
    
    	<a href="collegehome"><li>Home</li></a>
        
        <a href="editcollegeprofile"><li>Edit Profile</li></a>
        
        <a href="addstaff"><li>Add Staff</li></a>
    
    </ul>

</div>

<div id="profile-right" style="background-image:url(<?php echo $this->config->item('web_url');?>images/college-top.jpg)">

	<h1><?php echo $collegedetails['name']; ?><br /><span style="font-size:12px">User ID: <?php echo $collegedetails['userid']; ?></span></h1>    
        
    <div class="clear"></div>

	<div id="profile-titles">
    
    	<h2>Contact Details</h2>
    
    </div>
    
    <div id="profile-content">
    
    	<p><span>Address</span><?php if($collegedetails['address']!=""){ echo $collegedetails['address'];}else{ echo "Nil"; } ?></p>
        
        <p><span>City</span><?php if($collegedetails['city']!=""){ echo $collegedetails['city'];}else{ echo "Nil"; } ?></p>
   
   		<p><span>State</span><?php if($collegedetails['state']!=""){ echo $collegedetails['state'];}else{ echo "Nil"; } ?></p>
        
        <p><span>Pincode</span><?php if($collegedetails['pincode']!=""){ echo $collegedetails['pincode'];}else{ echo "Nil"; } ?></p>
        
        <p><span>Contact Number</span><?php if($collegedetails['contactnumber']!=""){ echo $collegedetails['contactnumber'];}else{ echo "Nil"; } ?></p>
        
        <p><span>Email Address</span><?php if($collegedetails['email']!=""){ echo $collegedetails['email'];}else{ echo "Nil"; } ?></p>
    
    </div>
    
    <div style="clear:both; height:30px;"></div> 
    
    <div id="profile-titles">
    
    	<h2>Other Details</h2>
    
    </div>
    
    <div id="profile-content">
    
    	<p><span>PG</span><?php if($collegedetails['pg']!=""){ echo $collegedetails['pg'];}else{ echo "Nil"; } ?></p>
    
    </div>
    
    <div style="clear:both; height:30px;"></div>  
    
    <div id="profile-titles">
    
    	<h2>Staff Members</h2>
    
    </div>
    
    <div id="profile-content">
    
    	<?php if($stafflist!=""){ echo $stafflist;}else{ echo '<p>Nil</p>'; } ?> 
    
    </div>
    
    <div style="clear:both; height:30px;"></div>  
    
    
    
    
    
    <div id="profile-titles">
    
    	<h2>List of Journals</h2>
    
    </div>
    
    <div id="profile-content">
    
    	<ul style="margin-top: 15px;">
        
        	<?php
				$count = count($collegedetails['journals']);
				if($collegedetails['journals'][0]!=""){
					for($i=0;$i<$count;$i++){
						echo '<li>'.$collegedetails['journals'][$i].'</li>';
					}
				}else{
					echo '<li style="list-style:none">Nil</li>';
				}
			
			?>
        	
        </ul>      
    
    </div>
    
    <div style="clear:both; height:30px;"></div> 
    
    <div id="profile-titles">
    
    	<h2>Current Events</h2>
    
    </div>
    
    <div id="profile-content">
    
    	<ul style="margin-top: 15px;">
        
        	<?php
				$count = count($collegedetails['events']);
				if($collegedetails['events'][0]!=""){
					for($i=0;$i<$count;$i++){
						echo '<li>'.$collegedetails['events'][$i].'</li>';
					}
				}else{
					echo '<li style="list-style:none">Nil</li>';
				}
			
			?>
        	
        </ul>      
    
    </div>
    
    <div style="clear:both; height:30px;"></div> 
        
      	

</div>
   
   
   
  
 

<script type="text/javascript">
$(document).ready(function(){
	
	$(".addmember").click(function(){
		
		var approveid = $(".approveid").val();
		var name = $(".nameadd").val();
		var userid = $(".memidadd").val();
		var password = $(".passadd").val();
		var role = $(".roleadd").val();
		var doj = $(".dojadd").val();
		var mobile = $(".mobileadd").val();
        var phone = $(".phoneadd").val();
        var email = $(".emailadd").val();
		var gender = $(".sexfield:checked").val();
		//var dob = $(".dobadd").val();
			var dobday = $(".dobdayfield").val();
			var dobmonth = $(".dobmonthfield").val();
			var dobyear = $(".dobyearfield").val();
		var address = $(".resaddressadd1").val();
		var qualification = $(".qualadd").val();
		var college = $(".collegeadd").val();
		var designation = $(".desigadd").val(); var clinic  = "";var clinicphone ="";
		//var clinic = $(".clinicaddadd").val();	
		//var clinicphone = $(".clinicphoneadd").val();
		
		var address2 = $(".resaddressadd2").val();
		var city = $(".rescityadd").val();
		var state = $(".resstateadd").val();
		var pincode = $(".respincodeadd").val();
		
		var payamount = $(".payamount").val();
		var paymode = $(".paymode").val();
		var payid = $(".payid").val();		
					
		regex   = new RegExp('^[a-zA-Z][a-zA-Z\.-/ ]{3,40}$');
		valid = regex.test(name);
		if(!valid || name==""){ $(".nameadd").addClass('errclass');$(".edit-err-notify").text("Invalid Member Name");return;}
		
		if(userid==""){ $(".memidadd").addClass('errclass');$(".edit-err-notify").text("Invalid Member ID");return;}
		
		if(password==""){ $(".passadd").addClass('errclass');$(".edit-err-notify").text("Invalid Password");return;}
		
		if(role==""){ $(".roleadd").addClass('errclass');$(".edit-err-notify").text("Invalid Role");return;}
			
		regex   = new RegExp('^[0-9 \-]{5,20}$');
        valid = regex.test(mobile);
        if(!valid && mobile!=""){ $(".mobileadd").addClass('errclass');$(".edit-err-notify").text("Invalid Mobile Number");return;}
		
		regex   = new RegExp('^[0-9 \-]{5,20}$');
        valid = regex.test(phone);
        if(!valid && phone!=""){ $(".phoneadd").addClass('errclass');$(".edit-err-notify").text("Invalid Phone Number");return;}
		
		regex   = new RegExp('^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$');
        valid = regex.test(email);
        if(!valid && email!=""){ $(".emailadd").addClass('errclass');$(".edit-err-notify").text("Invalid Email");return;}
		
		if(gender!="Male" && gender!="Female" && gender!=""){ $(".genderadd").addClass('errclass');$(".edit-err-notify").text("Invalid Gender");return;}
		
		/*regex   = new RegExp('^[0-9 \-]{10,10}$');
        valid = regex.test(dob);
        if(!valid && dob!=""){ $(".dobadd").addClass('errclass');$(".edit-err-notify").text("Invalid Date");return;}*/
		
		if(dobday=="" || dobmonth=="" || dobyear==""){ $(".dobdayfield,.dobmonthfield,.dobyearfield").addClass('errclass');$(".edit-err-notify").text("Invalid Date");return;}
	
		var dobdate = dobyear+'/'+dobmonth+'/'+dobday;
		var datevalid = isDate(dobdate);

		if(!datevalid) {
		  $(".dobdayfield,.dobmonthfield,.dobyearfield").addClass('errclass');
		  $(".edit-err-notify").text("Invalid Date of Birth");
		  return;
		}
	
		var dob = dobday+'-'+dobmonth+'-'+dobyear;
		
		if($('.sameaddress').is(':checked'))
		{
			$(".commaddress").fadeOut();
			
			var contactaddress = address;
			var contactaddress2 = address2;
			var contactcity = city;
			var contactstate = state;
			var contactpin = pincode;
			
			var sameaddress = "Yes";

			
		}else
		{
			$(".commaddress").fadeIn();
			var contactaddress = $(".contactaddressadd1").val();
			var contactaddress2 = $(".contactaddressadd2").val();
			var contactcity = $(".contactcityadd").val();
			var contactstate = $(".contactstateadd").val();
			var contactpin = $(".contactpinadd").val();
			
			var sameaddress = "No";
			
		regex   = new RegExp('^[a-zA-Z0-9#][a-zA-Z0-9\n\.,-_/#:& ]{3,250}$');
        valid = regex.test(contactaddress);
        if(!valid && contactaddress!=""){ $(".contactaddressadd1").addClass('errclass');$(".edit-err-notify").text("Invalid Communication Address1");return;}
		
		regex   = new RegExp('^[a-zA-Z0-9#][a-zA-Z0-9\n\.,-_/#:& ]{3,250}$');
        valid = regex.test(contactaddress2);
        if(!valid && contactaddress2!=""){ $(".contactaddressadd2").addClass('errclass');$(".edit-err-notify").text("Invalid Communication Address2");return;}
		
		var regex   = new RegExp('^[a-zA-Z][a-zA-Z\.-/ ]{3,100}$');
        valid = regex.test(contactcity);
        if(!valid && contactcity!=""){ $(".contactcityadd").addClass('errclass');$(".edit-err-notify").text("Invalid Communication City");return;}
		
		var regex   = new RegExp('^[a-zA-Z][a-zA-Z\.-/ ]{3,100}$');
        valid = regex.test(contactstate);
        if(!valid && contactstate!=""){ $(".contactstateadd").addClass('errclass');$(".edit-err-notify").text("Invalid Communication State");return;}
		
		regex   = new RegExp('^[0-9 \-]{4,10}$');
        valid = regex.test(contactpin);
        if(!valid && contactpin!=""){ $(".contactpinadd").addClass('errclass');$(".edit-err-notify").text("Invalid Communication Pincode");return;}
		}
		
		/*regex   = new RegExp('^[a-zA-Z0-9#][a-zA-Z0-9\n\.,-_/#:&() ]{3,250}$');
        valid = regex.test(clinic);
        if(!valid && clinic!=""){ $(".clinicaddadd").addClass('errclass');$(".edit-err-notify").text("Invalid Clinic Address");return;}
		
		regex   = new RegExp('^[0-9 \-]{5,20}$');
        valid = regex.test(clinicphone);
        if(!valid && clinicphone!=""){ $(".clinicphoneadd").addClass('errclass');$(".edit-err-notify").text("Invalid Clinic Phone Number");return;}*/
		
		if(payamount==""){ $(".payamount").addClass('errclass');$(".edit-err-notify").text("Enter Payment Amount");return;}
		
		if(paymode=="Choose"){ $(".paymode").addClass('errclass');$(".edit-err-notify").text("Select Payment Mode");return;}
		
		$(".edit-err-notify").html("<font style=\"color:#f7d8ba\">Processing...</font>");
                 $.get('approvemember/approveMemberRequest',{
					   'approveid':approveid,
					   'name':name, 
					   'userid':userid,
					   'password':password,
					   'role':role,
					   'doj':doj,
                       'mobile':mobile,
                       'phone':phone,
                       'email':email,
					   'gender':gender,
					   'dob':dob,
					   'address':address,
					   'contactaddress':contactaddress,
					   'contactstate':contactstate,
					   'contactpin':contactpin,
					   'qualification':qualification,
					   'college':college,
					   'designation':designation,
					   'clinic':clinic,
					   'clinicphone':clinicphone,
					   'payamount':payamount,
					   'paymode':paymode,
					   'payid':payid ,
					 	   'sameaddress':sameaddress,
						   'address2':address2,
						   'city':city,
						   'state':state,
						   'pincode':pincode,
						   'contactaddress2':contactaddress2,
						   'contactcity':contactcity

                 }, function(o) { 
				 		var obj1 = $.parseJSON(o);
						if(obj1[0] == 'exists'){
							$(".edit-err-notify").html("<font style=\"color:#f7d8ba\">Member ID Existed</font>"); 							
						}else if(obj1[0] == 'success'){
				 			$(".edit-err-notify").html("<font style=\"color:#f7d8ba\">Member Profile Created</font>"); 
                            setTimeout(function(){ location.assign("<?php echo $this->config->item('web_url');?>regemail.php?uid="+obj1[1]+"&pass="+obj1[2]+"&ref="+obj1[3]+"&name="+obj1[4]+"&email="+obj1[5]+"&payamount="+obj1[6]+"&paymode="+obj1[7]+"&payid="+obj1[8]);}, 2000);  
						}else if(obj1[0] == ''){
							setTimeout(function(){ $(".edit-err-notify").html("<font style=\"color:#f7d8ba\">Please Try again later.</font>"); }, 2000);
						}
                 }); 
		
		
	});
	
		
	 $("#profile-right").find("input").each(function(){

          $(this).click(function(){ $(this).removeClass("errclass");$(".edit-err-notify").text("");});

     });
	 
	 $(".deletemember").click(function(){
		 
		var approveid = $(".approveid").val();
		 
		var r=confirm("Are you sure to delete ?")
		if (r==true){
  			$(".edit-err-notify").html("<font style=\"color:#f7d8ba\">Processing...</font>");
                 $.get('approvemember/deleteMemberRequest',{
                       'approveid':approveid			   

                 }, function(o) {  $(".edit-err-notify").html("<font style=\"color:#f7d8ba\">Member Request Deleted</font>"); 
                           setTimeout(function(){ location.assign("home");}, 2000);         
                 }, 'json');
				 
  		}
		 
	 });
	
	$(".sameaddress").click(function(){
		  
		if($(this).is(':checked'))
			{
				$(".commaddress").fadeOut();
				
			}else
			{
				$(".commaddress").fadeIn();
			}
			
	 });
	
	var sameaddress = "<?php echo $approvedetails['sameaddress'];?>";
	var dob = "<?php echo $approvedetails['dob'];?>";
	
	if(sameaddress=="Yes"){
		$(".sameaddress").prop('checked',true);
		$(".commaddress").fadeOut();
	}else{
		$(".sameaddress").prop('checked',false);
		$(".commaddress").fadeIn();
	}
	
	dob = dob.split('-');
	
	var dobday = '<option value="">Day</option>';
	var dobmonth = '<option value="">Month</option>';
	var dobyear = '<option value="">Year</option>';
	
	for(var d=1;d<32;d++){
		
		var day = (d < 10 ? '0' : '') + d;
		if(dob[0]==day) var selected = "selected"; else var selected = "";
		dobday += '<option value="'+day+'" '+selected+'>'+day+'</option>';
		
	}
	$(".dobdayfield").html(dobday);
	
	var monthNames = ["","January","February","March","April","May","June","July","August","September","October","November","December"];
	for(var m=1;m<monthNames.length;m++){
		
		var mon = (m < 10 ? '0' : '') + m;
		if(dob[1]==mon) var selected = "selected"; else var selected = "";
		dobmonth += '<option value="'+mon+'" '+selected+'>'+monthNames[m]+'</option>';
		
	}
	$(".dobmonthfield").html(dobmonth);
	
	var currentTime = new Date();
	var curyear = currentTime.getFullYear();
	var firstYear = curyear - 80;
	var lastYear = firstYear + 63;
	for(var y=firstYear;y<lastYear;y++){
		
		if(dob[2]==y) var selected = "selected"; else var selected = "";
		dobyear += '<option value="'+y+'" '+selected+'>'+y+'</option>';
		
	}
	$(".dobyearfield").html(dobyear);

});
	
function isDate(txtDate)
{
    var currVal = txtDate;
    if(currVal == '')
        return false;
    
    var rxDatePattern = /^(\d{4})(\/|-)(\d{1,2})(\/|-)(\d{1,2})$/; //Declare Regex
    var dtArray = currVal.match(rxDatePattern); // is format OK?
    
    if (dtArray == null) 
        return false;
    
    //Checks for mm/dd/yyyy format.
    dtMonth = dtArray[3];
    dtDay= dtArray[5];
    dtYear = dtArray[1];        	
   
	if (dtMonth < 1 || dtMonth > 12) 
        return false;
    else if (dtDay < 1 || dtDay> 31) 
        return false;
    else if ((dtMonth==4 || dtMonth==6 || dtMonth==9 || dtMonth==11) && dtDay ==31) 
        return false;
    else if (dtMonth == 2) 
    {
        var isleap = (dtYear % 4 == 0 && (dtYear % 100 != 0 || dtYear % 400 == 0));
        if (dtDay> 29 || (dtDay ==29 && !isleap)) 
                return false;
    }
	
    return true;
}
</script>

<div id="profile-left">

	<img class="proimg" src="<?php echo $this->config->item('web_url');?>images/ap.jpg" />
    
    <ul>
    
    	<a href="home"><li>Dashboard</li></a>
        
        <a href="allusers"><li>View Users</li></a>
        
        <a href="searchusers"><li>Search Users</li></a>
        
        <a href="exportdata"><li>Export Data</li></a>
        
        <a href="newmember"><li>Add Member</li></a>
        
        <!--<a href="admincommunity"><li>Community</li></a>-->
        
        <!--<a href="addcollege"><li>Add College</li></a>
        
        <a href="collegelist"><li>College List</li></a>-->

       <!-- <a href="subjects"><li>Question Papers</li></a>
        
        <a href="notices"><li>Add Notifications</li></a>-->
        
        <a href="confregistrants"><li>Conference Registrants</li></a>
        
        <a href="preconfregistrants"><li>Preconference</li></a>
        
        <a href="testregistrants"><li>Test Registrants</li></a>
        
        <a href="abstracts"><li>Abstracts</li></a>
        
        <a href="nominees"><li>Nominees</li></a>
           
        <a href="election"><li>Election</li></a>
           
        <a href="presentation"><li>Presentation</li></a>
           
        <a href="annualmeet"><li>Annual Meet</li></a>
    
    </ul>

</div>

<div id="profile-right">

	<h1>Dr. <?php echo $membername['name']; ?><br /><span style="font-size:12px">Membership ID: admin</span></h1>
    
    <div class="right-options">
    
    	<button class="addmember" id="addmembut">Add</button><button class="deletemember" id="addmembut" style="margin-right:10px;">Delete</button><br />
        <p style="margin:15px 0 0; text-align:right; color:#fff;" class="edit-err-notify"></p>
    
    </div>
    
    <div class="clear"></div>

	<h2>Approve Member</h2> 
    
    <div id="profile-titles">
    
    	<h2>Membership Details</h2>
    
    </div>
    
    <div id="profile-content">
    
      	<input type="hidden" class="approveid" value="<?php if($approvedetails['id']!=""){ echo $approvedetails['id'];}else{ echo ""; } ?>" />
    
    	<p><span>Name</span><input class="update-text-box nameadd" value="<?php if($approvedetails['name']!=""){ echo $approvedetails['name'];}else{ echo ""; } ?>" /></p>
        
        <p><span>Member ID</span><input class="update-text-box memidadd" value="" /></p>
   
   		<p><span>Password</span><input class="update-text-box passadd" value="" /></p>
        
        <p><span>Role</span><select class="update-text-box roleadd">
        
        	<?php
			
				$rolearr = "LIFE,STUDENT,ASSOCIATES";
				$rolearr = explode(",",$rolearr);
				$roleselect = '<option value="">Choose</option>';
				foreach ($rolearr as $rval) { 
					if($approvedetails['memtype']==$rval){
						$roleselect .= "<option selected>".$rval."</option>";
					}else{
						$roleselect .= "<option>".$rval."</option>";
					}	   				
				}
				echo $roleselect;
			
			?>
        
        </select></p>
        
        <p><span>Date of Joining</span><input class="update-text-box dojadd datepicker" value="" readonly /></p>
    
    </div>
    
    <div style="clear:both; height:30px;"></div>
    
    <div id="profile-titles">
    
    	<h2>Contact Details</h2>
    
    </div>
    
    <div id="profile-content">
    
    	<p><span>Mobile</span><input class="update-text-box mobileadd" value="<?php if($approvedetails['mobile']!=""){ echo $approvedetails['mobile'];}else{ echo ""; } ?>" /><span1>eg: 9876543210</span1></p>
        
        <p><span>Landline</span><input class="update-text-box phoneadd" value="<?php if($approvedetails['phone']!=""){ echo $approvedetails['phone'];}else{ echo ""; } ?>" /><span1>eg: 044-12345678</span1></p>
   
   		<p><span>Email</span><input class="update-text-box emailadd" value="<?php if($approvedetails['email']!=""){ echo $approvedetails['email'];}else{ echo ""; } ?>" /><span1>eg: info@example.com</span1></p>
    
    </div>
    
     <div style="clear:both; height:30px;"></div>
    
    <div id="profile-titles">
    
    	<h2>Personal Details</h2>
    
    </div>
    
    <div id="profile-content">
    
    	<p><span>Gender</span><input type="radio" class="register-radio sexfield" name="sex" value="Male" <?php if($approvedetails['sex']=="Male"){ echo "checked";}else{ echo ""; } ?> />
	<label>Male</label>
<input type="radio" class="register-radio sexfield" name="sex" value="Female" <?php if($approvedetails['sex']=="Female"){ echo "checked";}else{ echo ""; } ?> />
	<label>Female</label></p>
   
   		<p><span>DOB</span>
   		<select class="register-select dobdayfield" name="dobday"></select>
<select class="register-select dobmonthfield" name="dobmonth"></select>
<select class="register-select dobyearfield" name="dobyear"></select></p>
	</div>
       
   <div style="clear:both; height:30px;"></div>
   
    <div id="profile-titles">
    
    	<h2>Residential Address</h2>
    
    </div>
    
    <div id="profile-content">
            
        <p><span>Address Line 1</span><input class="update-text-box resaddressadd1" value="<?php if($approvedetails['address']!=""){ echo $approvedetails['address'];}else{ echo ""; } ?>" /><span1>max. 250 chars</span1></p>
        
        <p><span>Address Line 2</span><input class="update-text-box resaddressadd2" value="<?php if($approvedetails['address2']!=""){ echo $approvedetails['address2'];}else{ echo ""; } ?>" /><span1>max. 250 chars</span1></p>
        
        <p><span>City</span><input class="update-text-box rescityadd" value="<?php if($approvedetails['city']!=""){ echo $approvedetails['city'];}else{ echo ""; } ?>" /></p>
        
        <p><span>State</span><input class="update-text-box resstateadd" value="<?php if($approvedetails['state']!=""){ echo $approvedetails['state'];}else{ echo ""; } ?>" /></p>
        
        <p><span>Pincode</span><input class="update-text-box respincodeadd" value="<?php if($approvedetails['pincode']!=""){ echo $approvedetails['pincode'];}else{ echo ""; } ?>" /></p>
    
    </div>
    
    <div style="clear:both; height:30px;"></div>
    
    <div id="profile-titles">
    
    	<h2>Communication Address</h2>
    	    
    </div>
    
    <div id="profile-content">
    
    	<p class="sameadbox"><input type="checkbox" class="register-text-box sameaddress" name="sameaddress" /><label>Same as Residential Address</label></p>
    
    	<p class="commaddress"><span>Address Line 1</span><input class="update-text-box contactaddressadd1" value="<?php if($approvedetails['contactaddress']!=""){ echo $approvedetails['contactaddress'];}else{ echo ""; } ?>" /><span1>max. 250 chars</span1></p>
      
      <p class="commaddress"><span>Address Line 2</span><input class="update-text-box contactaddressadd2" value="<?php if($approvedetails['contactaddress2']!=""){ echo $approvedetails['contactaddress2'];}else{ echo ""; } ?>" /><span1>max. 250 chars</span1></p>
       
       <p class="commaddress"><span>City</span><input class="update-text-box contactcityadd" value="<?php if($approvedetails['contactcity']!=""){ echo $approvedetails['contactcity'];}else{ echo ""; } ?>" /></p>
        
        <p class="commaddress"><span>State</span><input class="update-text-box contactstateadd" value="<?php if($approvedetails['contactstate']!=""){ echo $approvedetails['contactstate'];}else{ echo ""; } ?>" /></p>
        
        <p class="commaddress"><span>Pincode</span><input class="update-text-box contactpinadd" value="<?php if($approvedetails['contactpin']!=""){ echo $approvedetails['contactpin'];}else{ echo ""; } ?>" /></p>
    
    </div> 
    
    <div style="clear:both; height:30px;"></div>
    
    <div id="profile-titles">
    
    	<h2>Official Details</h2>
    
    </div>
    
    <div id="profile-content">
    
    	<p><span>Qualification</span><input class="update-text-box qualadd" value="<?php if($approvedetails['qualification']!=""){ echo $approvedetails['qualification'];}else{ echo ""; } ?>" /></p>
   
   		<p><span>College</span><input class="update-text-box collegeadd" value="<?php if($approvedetails['college']!=""){ echo $approvedetails['college'];}else{ echo ""; } ?>" /></p>
        
        <p><span>Designation</span><input class="update-text-box desigadd" value="<?php if($approvedetails['designation']!=""){ echo $approvedetails['designation'];}else{ echo ""; } ?>" /></p>
        
        <!--p><span>Clinic Address</span><input class="update-text-box clinicaddadd" value="<?php if($approvedetails['clinicaddress']!=""){ echo $approvedetails['clinicaddress'];}else{ echo ""; } ?>" /><span1>max. 250 chars</span1></p>
        
        <p><span>Clinic Phone</span><input class="update-text-box clinicphoneadd" value="<?php if($approvedetails['clinicphone']!=""){ echo $approvedetails['clinicphone'];}else{ echo ""; } ?>" /></p-->
    
    </div> 
    
    <div style="clear:both; height:30px;"></div>
    
    <!--div id="profile-titles">
    
    	<h2>Proposed By</h2>
    
    </div>
    
    <div id="profile-content">
    
    	<p><span>Name</span><input class="update-text-box pronameadd" value="<?php if($approvedetails['proposedname']!=""){ echo $approvedetails['proposedname'];}else{ echo ""; } ?>" /></p>
        
        <p><span>Membership ID</span><input class="update-text-box proidadd" value="<?php if($approvedetails['proposedmembership']!=""){ echo $approvedetails['proposedmembership'];}else{ echo ""; } ?>" /></p>
       
    </div>
    
    <div style="clear:both; height:30px;"></div>
    
    <div id="profile-titles">
    
    	<h2>Seconded By</h2>
    
    </div>
    
    <div id="profile-content">
    
    	<p><span>Name</span><input class="update-text-box secnameadd" value="<?php if($approvedetails['secondedname']!=""){ echo $approvedetails['secondedname'];}else{ echo ""; } ?>" /></p>
        
        <p><span>Membership ID</span><input class="update-text-box secidadd" value="<?php if($approvedetails['secondedmembership']!=""){ echo $approvedetails['secondedmembership'];}else{ echo ""; } ?>" /></p>
       
    </div>
    
    <div style="clear:both; height:30px;"></div-->
    
    <div id="profile-titles">
    
    	<h2>Payment Details</h2>
    
    </div>
    
    <div id="profile-content">
    
      	<p><span>Payment Amount</span><input class="update-text-box payamount" value="<?php if($approvedetails['paymentamount']!=""){ echo $approvedetails['paymentamount'];}else{ echo ""; } ?>" /></p>
    
    	<p><span>Mode of Payment</span><select class="update-text-box paymode"><?php echo $approvedetails['paymentmode']; ?></select></p>
        
        <p><span>DD No/Txn Id</span><input class="update-text-box payid" value="<?php if($approvedetails['paymentid']!=""){ echo $approvedetails['paymentid'];}else{ echo ""; } ?>" /></p>
       
    </div>
    
    <div style="clear:both; height:30px;"></div>
        

</div>
   
   
   
  
 
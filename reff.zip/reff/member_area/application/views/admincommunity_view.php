
<script type="text/javascript">
$(document).ready(function(){	
			
	$(".newpost").click(function(){
		
		var commid = "<?php echo $commdetails['id']; ?>";
		var posttext = $(".posttext").val();
		
		$(".edit-err-notify").html("<font style=\"color:#f7d8ba\">Processing...</font>");
                 $.get('admincommunity/createNewPost',{
                       'commid':commid,
					   'posttext':posttext			   

                 }, function(o) {  $(".edit-err-notify").html("<font style=\"color:#f7d8ba\">Post Updated</font>"); 
                           setTimeout(function(){ location.reload();}, 2000);         
                 }, 'json');
		
	});
	
	$(".delpost").click(function(){
		
		var postid = $(this).attr("id");
		
		var r=confirm("Are you sure to delete the post ?")
		if (r==true){
  			$(".edit-err-notify").html("<font style=\"color:#f7d8ba\">Processing...</font>");
                 $.get('admincommunity/deletePost',{
                       'postid':postid			   

                 }, function(o) {  $(".edit-err-notify").html("<font style=\"color:#f7d8ba\">Post Deleted</font>"); 
                           setTimeout(function(){ location.reload();}, 2000);         
                 }, 'json');
				 
  		}
		
	});
	
	$(".editcomm").click(function(){
		
		var commid = "<?php echo $commdetails['id']; ?>";	
		
		window.location.href = "<?php  echo base_url(); ?>editcommunity?id="+commid;
		
	});
	
	$(".commMembers").click(function(){
		
		if($("#memberList").hasClass('hide')){
			$("#memberList").removeClass('hide');
			$("#memberList").addClass('view');			
		}
		
		else if($("#memberList").hasClass('view')){
			$("#memberList").removeClass('view');
			$("#memberList").addClass('hide');			
		}
		
	});
	
	$(".memlist").click(function(){
		
		var memid = $(this).attr("id");
        		
		window.location.href = "<?php  echo base_url(); ?>memberpage?id="+memid;		
		
	});
	
	
	
});
</script>

<div id="community-left">

	<img class="proimg" src="<?php echo $this->config->item('web_url');?>images/ap.jpg" />
    
    <ul>
    
    	<a href="home"><li>Dashboard</li></a>
        
        <a href="allusers"><li>View Users</li></a>
        
        <a href="searchusers"><li>Search Users</li></a>
        
        <a href="exportdata"><li>Export Data</li></a>
        
        <a href="newmember"><li>Add Member</li></a>
        
        <a href="admincommunity"><li>Community</li></a>
        
        <!--<a href="addcollege"><li>Add College</li></a>
        
        <a href="collegelist"><li>College List</li></a>-->

        <a href="subjects"><li>Question Papers</li></a>
        
        <a href="notices"><li>Add Notifications</li></a>
        
        <a href="confregistrants"><li>Conference Registrants</li></a>
        
        <a href="preconfregistrants"><li>Preconference</li></a>
        
        <a href="testregistrants"><li>Test Registrants</li></a>
        
        <a href="abstracts"><li>Abstracts</li></a>
        
        <a href="nominees"><li>Nominees</li></a>
           
        <a href="election"><li>Election</li></a>
           
        <a href="presentation"><li>Presentation</li></a>
        
    </ul>

</div>

<div id="community-right">

	<h1><?php echo $commdetails['name']; ?></h1>
    
    <div class="right-options" style="margin:5px 10px 0">
    
    	<p style="margin:0 9px 5px 0px; text-align:right; color:#fff;">Hello, Admin</p><button class="commMembers" id="memberscount"><span style="font-weight:bold"><?php echo $commmembers['mem_count']; ?></span> Member(s)</button><br />
        <p style="margin:15px 0 0; text-align:right; color:#fff;" class="edit-err-notify"></p>
    	    
    </div>
    
    <div class="clear"></div>

	<h2>Description</h2>
    
    <p><?php if($commdetails['desc']!=""){ echo $commdetails['desc']; }else{ echo "No Description to Display"; } ?></p>
    
    <div style="clear:both; height:10px;"></div>
    
    <div id="memberList" class="hide">
    
    	<h2>Members (<?php echo $commmembers['mem_count']; ?>)</h2>
    
    	<?php echo $commmembers['mem_list']; ?>
    
    	<div style="clear:both; height:10px;"></div>
    
    </div>       
    
    <div id="activityList">
    
	
	<h2>Activities</h2>  	
    
    <p><input class="post-text-box posttext" maxlength="200" value="" /><button class="newpost" id="postbut">Post</button><br /><span1>max. 200 characters</span1></p>
    
    <div style="clear:both; height:30px;"></div>
    
	<?php echo $activities; ?>
	
	
    </div>   
    
    <div style="clear:both; height:30px;"></div>
        
</div>
   
   
   
  
 
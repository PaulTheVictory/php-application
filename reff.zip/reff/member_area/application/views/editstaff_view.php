
<script type="text/javascript">
$(document).ready(function(){	
	
	$(".editstaff").click(function(){
		
		var staffid = "<?php echo $staffid; ?>";
		var staffname = $(".staffname").val();
        var designation = $(".designation").val();		
		
		if(staffname==""){ $(".staffname").addClass('errclass');$(".edit-err-notify").text("Invalid Staff Name");return;}
		
		if(designation==""){ $(".designation").addClass('errclass');$(".edit-err-notify").text("Invalid Designation");return;}
		
		$(".edit-err-notify").html("<font style=\"color:#9d3c1a\">Processing...</font>");
                 $.get('editstaff/editCollegeStaff',{
					   'staffid':staffid, 	
                       'staffname':staffname,
                       'designation':designation			   

                 }, function(o) {  $(".edit-err-notify").html("<font style=\"color:#9d3c1a\">Staff Details Updated</font>"); 
                           setTimeout(function(){ location.assign("collegehome");}, 2000);         
                 }, 'json');
		
	});
	
	 
	 $("#profile-right").find("input").each(function(){

          $(this).click(function(){ $(this).removeClass("errclass");$(".edit-err-notify").text("");});

     });
	 
	 $("#profile-right").find("select").each(function(){

          $(this).click(function(){ $(this).removeClass("errclass");$(".edit-err-notify").text("");});

     });
	 
	 $(".deletestaff").click(function(){
		 
		var staffid = "<?php echo $staffid; ?>";
		 
		var r=confirm("Are you sure to delete ?")
		if (r==true){
  			$(".edit-err-notify").html("<font style=\"color:#9d3c1a\">Processing...</font>");
                 $.get('editstaff/deleteCollegeStaff',{
                       'staffid':staffid			   

                 }, function(o) {  $(".edit-err-notify").html("<font style=\"color:#9d3c1a\">Staff Deleted</font>"); 
                           setTimeout(function(){ location.assign("collegehome");}, 2000);         
                 }, 'json');
				 
  		}
		 
	 });
	 
	

});
</script>

<div id="profile-left" style="background-image:url(<?php echo $this->config->item('web_url');?>images/college-top.jpg)">

	<img class="proimg" src="<?php echo $this->config->item('web_url');?>docs/colleges/colp.jpg" width="140" height="160" />
    
    <ul>
    
    	<a href="collegehome"><li>Home</li></a>
        
        <a href="editcollegeprofile"><li>Edit Profile</li></a>
        
        <a href="addstaff"><li>Add Staff</li></a>
    
    </ul>

</div>

<div id="profile-right" style="background-image:url(<?php echo $this->config->item('web_url');?>images/college-top.jpg)">

	<h1><?php echo $collegedetails['name']; ?><br /><span style="font-size:12px">User ID: <?php echo $collegedetails['userid']; ?></span></h1>
    
    <div class="right-options">
    
    	<button class="editstaff" id="colbtn">Update</button><button class="deletestaff" id="colbtn" style="margin-right:10px;">Delete</button><br />
        <p style="margin:15px 0 0; text-align:right; color:#fff;" class="edit-err-notify"></p>
    
    </div>
    
    <div class="clear"></div>

	<h2>Edit Staff</h2>
    
    <div id="profile-titles">
    
    	<h2>Name</h2>
    
    </div>
    
    <div id="profile-content">
    
    	<input class="college-text-box staffname" value="<?php if($staffdetails['name']!=""){ echo $staffdetails['name'];}else{ echo ""; } ?>" />
            
    </div>
    
    <div style="clear:both; height:5px;"></div> 
    
    <div id="profile-titles">
    
    	<h2>Designation</h2>
    
    </div>
    
    <div id="profile-content">
    
    	<select class="college-text-box designation" style="padding:3px 5px; width:356px;">
        
        <?php
		
				$desigarr = Array("HOD","Asst. Professor","Lecturer");
				$desigopt = '<option value="">&nbsp;</option>';
				foreach ($desigarr as $dval) { 
					if($staffdetails['designation']==$dval){
						$desigopt .= "<option selected>".$dval."</option>";
					}else{
						$desigopt .= "<option>".$dval."</option>";
					}	   				
				}
				
				echo $desigopt;
		
		?>
        
        </select>
            
    </div>
    
    <div style="clear:both; height:30px;"></div> 
        
      	

</div>
   
   
   
  
 

<script type="text/javascript">

    $(document).ready(function(){
	
        
        $("#regbut").click(function() {
            registerMember();
         });
        
        $("#paybut").click(function() {
            registerPayment();
         });
        
        function registerMember() {
		
		var name = $(".namefield").val();
		var dob = $(".dobfield").val();
		var qualification = $(".qualificationfield").val();
		var acdiuserid = $(".acdiuserid").val();
        var phone = $(".phonefield").val();
        var email = $(".emailfield").val();
		
							
		var regex   = new RegExp('^[a-zA-Z][a-zA-Z\.-/ ]{3,40}$');
		var valid = regex.test(name);
		if(!valid){ $(".namefield").addClass('errclass');$(".edit-err-notify").text("Invalid Member Name");return;}
		
	    if(dob === ""){ $(".dobfield").addClass('errclass');$(".edit-err-notify").text("Please provide the age");return;}
		
		regex   = new RegExp('^[0-9 \-]{5,20}$');
        valid = regex.test(phone);
        if(!valid && phone!=""){ $(".phonefield").addClass('errclass');$(".edit-err-notify").text("Invalid Phone Number");return;}
		
		regex   = new RegExp('^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$');
        valid = regex.test(email);
        if(!valid){ $(".emailfield").addClass('errclass');$(".edit-err-notify").text("Invalid Email");return;}
		    
        regex   = new RegExp('^[a-zA-Z0-9#][a-zA-Z0-9\n\.,-_/#:& ]{2,250}$');
        valid = regex.test(qualification);
        if(!valid){ $(".qualificationfield").addClass('errclass');$(".edit-err-notify").text("Please provide your qualification");return;}
		
		
        var refno = '<?php echo $membername['confid'];?>';
    	var iturl = "../../test_registration.php?name="+name+"&age="+dob+"&phone="+phone+"&email="+email+"&qualification="+qualification+"&acdiuserid="+acdiuserid+"&refno="+refno;
    	
		$(".edit-err-notify").html("<font style=\"color:#900\">Processing...</font>");
		$.ajax({
        	url:iturl,
        	data:{},
        	success:function(data, textStatus, XMLHttpRequest) {
            	var o = typeof XMLHttpRequest == 'object' ? XMLHttpRequest : '';
           		if (o.status == 200) {console.log(data);               
               		if(data != '') {
                     	location.assign("fellowship?ref="+data);  
                 	} else {
                      	$(".edit-err-notify").html("<font style=\"color:#900\">Please try again later.</font>");
                 	}            
				}
        	}
     	});  
		
}
        
        
function registerPayment() {
		
		var payamount = $(".payamount").val();	
	  	var paymode = "ONLINE";		
		
		if(paymode=="ONLINE"){

            window.location.href = "http://www.informdoc.com/gateway/acdi.co.in/pay.php?ref=<?php echo $ref; ?>&type=test" ;

        }
        
}
        
           
});

        
</script>

<?php
if($membername['confid'] === "") { ?>
    
    <h2>Please <a href="../conference.html" style="text-decoration:underline">register</a> the confernece before register the Fellowship in Cosmetic Dentistry.</h2>



<?php } else if(($ref === "")&&($paymentid === "")) { ?>


<div class="leftcontent" style="width:85% !important;float:right;">
<table class="registration" style="display:block">

<tr>
<td width="250">Name <font color="#990000">*</font></td>
<td width="650"><p><input class="register-text-box namefield" name="name" value="<?php echo $membername['name'];?>" /></p></td>
</tr>

<tr>
<td>Date Of Birth <font color="#990000">*</font></td>
<td><p><input class="register-text-box dobfield" name="age" value="<?php echo $profile['dob'];?>"/></p></td>
</tr>

<tr>
<td>Qualification <font color="#990000">*</font></td>
<td><p><input class="register-text-box sexfield qualificationfield" name="qualification" value="<?php echo $profile['qualification'];?>"/></p></td>
</tr>

<tr>
<td>ACDI User ID</td>
<td><p><input class="register-text-box mobilefield acdiuserid" name="acdi" value="<?php echo $membername['userid'];?>"/></p></td>
</tr>

<tr>
<td>Phone No<font color="#990000">*</font></td>
<td><p><input class="register-text-box phonefield" name="phone" value="<?php echo $profile['mobile'];?>"/></p></td>
</tr>
    
<tr>
<td>Email ID<font color="#990000">*</font></td>
<td><p><input class="register-text-box emailfield" name="email" value="<?php echo $profile['email'];?>"/></p></td>
</tr>
    
<tr>
<td>Amount Payable</td>
<td><p>Rs.3500</p></td>
</tr>
    
    <tr>
<td></td>
<td><p><button style="border:0px;color:#fff;width:75px;background:url('../images/button-1.png') no-repeat;padding: 10px;text-align: center;margin: 0px 50px;cursor: pointer;margin-top:20px" id="regbut" type="button"  >Next</button></p></td>
</tr>

    </table></div><div class="clear"></div>

<?php } else { $memberfees = 3500; if($paymentid === "") {  ?>



<div id="top-default-new">
		                               	           
<h1>Fellowship in Cosmetic Dentistry Registration - Payment</h1> 

<table class="registration" style="margin-left: 200px;">

<tr>
<td width="250">Payment Amount <font color="#990000">*</font> (&#8377;)</td>
<td width="650"><p><input style="width:120px; height:20px;" class="register-text-box payamount" name="payamount" value="<?php echo $memberfees; ?>" readonly /></p></td>
</tr>
<tr>
<td width="250"><p style="color:#900" class="edit-err-notify"></p></td>
<td width="650"><p><button style="border:0px;color:#fff;width:75px;background:url('../../images/button-1.png') no-repeat;padding: 10px;text-align: center;margin: 0px 50px;cursor: pointer;margin-top:20px" onclick="registerPayment();return false;" class="register" id="paybut" style="margin-left: 430px;">Confirm</button></p></td>

</tr>

</table>

</div>
<?php  } else {  ?>
    
    <style>

#paymentstatus {
    margin: 20px auto;
    width: 500px;
}
.registration {
    text-align: left;
    border-collapse: collapse;
    margin: 20px;
   
}
        
        #paymentstatus td {
    border: 1px solid #aaa;
    padding: 5px;
}
</style>
<?php if($paymentstatus=="SUCCESS") { ?>


<h1>Fellowship in Cosmetic Dentistry Registration</h1> 

    
          <table class="registration" id="paymentstatus">

              <tr><td><strong>Membership Fee</strong></td><td><?php echo $memberfees; ?></td></tr>
<tr><td><strong>Reference No</strong></td><td><strong><?php echo $paymentid; ?></strong></td></tr>
<tr><td><strong>Status</strong></td><td><strong><?php echo $paymentstatus; ?></strong></td></tr>
</table>

       <?php } else { ?>	

          <div align="center">

<h1>Online Registration</h1> 


<table class="registration" id="paymentstatus">

    <tr><td><strong>Membership Fee</strong></td><td><?php echo $memberfees; ?></td></tr>
<tr><td><strong>Reference No</strong></td><td><?php echo $paymentid; ?></td></tr>
<tr><td><strong>Status</strong></td><td><?php echo $paymentstatus; ?></td></tr>
</table>

              <p style="text-align:center"><strong>Please click try again button to retry payment or  <a href="http://www.acdi.co.in" style="text-decoration:underline">cancel to redirect</a> to homepage.</strong></p>



<table class="registration">

<form method="POST" action="http://www.informdoc.com/gateway/acdi.co.in/pay.php?ref=<?php echo $paymentid; ?>&type=test" enctype="multipart/form-data">

<input type="hidden" name="refno" value="<?php echo $paymentid; ?>" />

<tr>
<td><p><input id="registerbut" type="submit" value="Try again" /></p></td>

</tr>

</form>	

</table>

</div>

       <?php  } ?>

<?php  } ?>

<?php  } ?>
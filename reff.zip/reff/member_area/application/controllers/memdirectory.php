<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

session_start(); //we need to call PHP's session object to access it through CI

class Memdirectory extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model('findspecialist_model','',TRUE);
	}
		
	function index()
	{
		if($this->session->userdata('logged_in') || $this->session->userdata('adlog_in') || $this->session->userdata('college_log_in'))
   		{
			$data['memdirectory'] = $this->findspecialist_model->GetAllMembers();
     		$this->load->view('header');
			$this->load->view('directory_view', $data);	
			$this->load->view('footer');
   		}
		else
   		{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
   		}

	}
}
?>

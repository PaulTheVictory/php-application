<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

session_start(); //we need to call PHP's session object to access it through CI

class Testregistrants extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model('user_model','',TRUE);
		$this->load->model('profile_model','',TRUE);
		$this->load->model('admin_model','',TRUE);
                $this->load->library('table'); 
	}
	
	function index()
	{
		if($this->session->userdata('adlog_in'))
   		{
     		$session_data = $this->session->userdata('adlog_in');
     		$data['username'] = $session_data['username'];
			$data['memberid'] = $session_data['id'];			
			$data['allusers'] = $this->admin_model->GetAllTestRegistrantCount();
                        
                        $tmpl = array('table_open' => '<table class="sortable" id="memberstable">');
                                $this->table->set_template($tmpl);
                                $this->table->set_heading('User ID','Name', 'Mobile', 'Email', 'Amount', 'Payment Time');
                                
			$this->load->view('header',$data);
     		$this->load->view('testregistrants_view', $data);
			$this->load->view('footer');
   		}
   		else
   		{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
   		}

	}
        
        public function getMemberLists() {
            
            if($this->session->userdata('adlog_in') || $this->session->userdata('conflog_in')){
                
                $ret =  $this->admin_model->GetAllTestRegistrant_filter();
                echo $ret;
                
            }else{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
            }
            
        }
		
}
?>

<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Findspecialist extends CI_Controller {

	function __construct()
	{
		parent::__construct();		
		$this->load->model('findspecialist_model','',TRUE);
	}
	
	function index()
	{
		
		$findbyname = $_POST['find_name'];
		$findbyarea = $_POST['find_area'];
		$data['specialist'] = $this->findspecialist_model->GetSpecialists($findbyname,$findbyarea);
			
		$this->load->view('header');
		$this->load->view('findspecialist_view', $data);	
		$this->load->view('footer');
	}
}
?>

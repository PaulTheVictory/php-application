<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

session_start(); //we need to call PHP's session object to access it through CI

class Admincommunity extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model('user_model','',TRUE);
		$this->load->model('profile_model','',TRUE);
		$this->load->model('community_model','',TRUE);
		$this->load->model('admin_model','',TRUE);
	}
	
	function index()
	{
		if($this->session->userdata('adlog_in'))
   		{
     		$session_data = $this->session->userdata('adlog_in');
     		$data['username'] = $session_data['username'];
			$data['memberid'] = $session_data['id'];
			$data['membername'] = $this->profile_model->GetMemberName($session_data['id']);
			
			$commid = "5166674f32377";
			$data['commdetails'] = $this->community_model->GetCommunityDetails($commid);
			$data['commmembers'] = $this->community_model->GetCommunityMembers($commid);			
			$data['activities'] = $this->community_model->GetCommunityActivity($commid,$session_data['id']);
			
			$this->load->view('header',$data);
     		$this->load->view('admincommunity_view', $data);
			$this->load->view('footer');
   		}
   		else
   		{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
   		}

	}
	
	public function createNewPost() {
        
        $session_data = $this->session->userdata('adlog_in');
		$memberid = $session_data['id'];
		
        $commid  = isset($_GET['commid'])?$_GET['commid']:''; 
		$posttext  = isset($_GET['posttext'])?$_GET['posttext']:'';             	        
        
        $ret = $this->community_model->CreateNewPost($memberid,$commid,$posttext);
        echo json_encode($ret);
    }
	
	public function deletePost() {
        
        $session_data = $this->session->userdata('adlog_in');
		$memberid = $session_data['id'];
		
        $postid  = isset($_GET['postid'])?$_GET['postid']:''; 		   	        
        
        $ret = $this->community_model->DeletePost($memberid,$postid);
        echo json_encode($ret);
    }
		
}
?>

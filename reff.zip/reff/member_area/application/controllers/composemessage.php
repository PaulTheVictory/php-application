<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

session_start(); //we need to call PHP's session object to access it through CI

class Composemessage extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model('user_model','',TRUE);
		$this->load->model('profile_model','',TRUE);
		$this->load->model('connections_model','',TRUE);
	}
	
	function index()
	{
		if($this->session->userdata('logged_in'))
   		{
     		$session_data = $this->session->userdata('logged_in');
     		$data['username'] = $session_data['username'];
			$data['memberid'] = $session_data['id'];
			$data['membername'] = $this->profile_model->GetMemberName($session_data['id']);
			$data['connections'] = $this->connections_model->GetConnectionsForCompose($session_data['id']);
			$this->load->view('header',$data);
     		$this->load->view('composemessage_view', $data);
			$this->load->view('footer');
   		}
   		else
   		{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
   		}

	}
	
	public function sendNewMessage() {
        
        $session_data = $this->session->userdata('logged_in');
		$fromid = $session_data['id'];
		$fromname  = isset($_GET['fromname'])?$_GET['fromname']:''; 
        $tonames  = isset($_GET['tonames'])?$_GET['tonames']:'';  
		$toids  = isset($_GET['toids'])?$_GET['toids']:'';
		$subject  = isset($_GET['subject'])?$_GET['subject']:'';
		$message  = isset($_GET['message'])?$_GET['message']:'';            	        
        
        $ret = $this->connections_model->SendNewMessage($fromid,$fromname,$tonames,$toids,$subject,$message);
        echo json_encode($ret);
    }
		
}
?>

<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

session_start(); //we need to call PHP's session object to access it through CI

class Profileedit extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model('user_model','',TRUE);
		$this->load->model('profile_model','',TRUE);
	}
	
	function index()
	{
		if($this->session->userdata('logged_in'))
   		{
     		$session_data = $this->session->userdata('logged_in');
     		$data['username'] = $session_data['username'];
			$data['memberid'] = $session_data['id'];
			$data['membername'] = $this->profile_model->GetMemberName($session_data['id']);
			$data['memberprofile'] = $this->profile_model->GetMemberProfile($session_data['id']);
			$this->load->view('header',$data);
     		$this->load->view('profileedit_view', $data);
			$this->load->view('footer');
   		}
   		else
   		{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
   		}

	}
	
	public function updateProfile() {
        
        $session_data = $this->session->userdata('logged_in');
		$memberid = $session_data['id'];
		
        $mobile  = isset($_GET['mobile'])?$_GET['mobile']:'';
        $phone  = isset($_GET['phone'])?$_GET['phone']:'';
        $email = isset($_GET['email'])?$_GET['email']:'';
		$gender = isset($_GET['gender'])?$_GET['gender']:'';
        $dob = isset($_GET['dob'])?$_GET['dob']:'';
		$address = isset($_GET['address'])?$_GET['address']:'';
		$contactaddress = isset($_GET['contactaddress'])?$_GET['contactaddress']:'';
		$contactstate = isset($_GET['contactstate'])?$_GET['contactstate']:'';
		$contactpin = isset($_GET['contactpin'])?$_GET['contactpin']:'';
		$qualification = isset($_GET['qualification'])?$_GET['qualification']:'';
		$college = isset($_GET['college'])?$_GET['college']:'';
		$designation = isset($_GET['designation'])?$_GET['designation']:'';
		$clinic = isset($_GET['clinic'])?$_GET['clinic']:'';
		$clinicphone = isset($_GET['clinicphone'])?$_GET['clinicphone']:'';
		$pubsearch = isset($_GET['pubsearch'])?$_GET['pubsearch']:'';
		$membertype = isset($_GET['membertype'])?$_GET['membertype']:'';
		$mname = isset($_GET['mname'])?$_GET['mname']:'';
		$maddress1 = isset($_GET['maddress1'])?$_GET['maddress1']:'';
		$maddress2 = isset($_GET['maddress2'])?$_GET['maddress2']:'';
		$mcity = isset($_GET['mcity'])?$_GET['mcity']:'';
		$mstate = isset($_GET['mstate'])?$_GET['mstate']:'';
		$mpincode = isset($_GET['mpincode'])?$_GET['mpincode']:'';
		$mdesignation = isset($_GET['mdesignation'])?$_GET['mdesignation']:'';
		$mlandline = isset($_GET['mlandline'])?$_GET['mlandline']:'';
		$mmobile = isset($_GET['mmobile'])?$_GET['mmobile']:'';
		$mgeo = isset($_GET['mgeo'])?$_GET['mgeo']:'';
		$mclinictiming = isset($_GET['mclinictiming'])?$_GET['mclinictiming']:'';
		
		$sameaddress = isset($_GET['sameaddress'])?$_GET['sameaddress']:'';
		$address2 = isset($_GET['address2'])?$_GET['address2']:'';
		$city = isset($_GET['city'])?$_GET['city']:'';
		$state = isset($_GET['state'])?$_GET['state']:'';
		$pincode = isset($_GET['pincode'])?$_GET['pincode']:'';
		$contactaddress2 = isset($_GET['contactaddress2'])?$_GET['contactaddress2']:'';
		$contactcity = isset($_GET['contactcity'])?$_GET['contactcity']:'';
		        
        
        $ret = $this->profile_model->UpdateProfile($memberid,$mobile,$phone,$email,$gender,$dob,$address,$contactaddress,$contactstate,$contactpin,$qualification,$college,$designation,$clinic,$clinicphone,$pubsearch,$membertype,$mname,$maddress1,$maddress2,$mcity,$mstate,$mpincode,$mdesignation,$mlandline,$mmobile,$mgeo,$mclinictiming,$sameaddress,$address2,$city,$state,$pincode,$contactaddress2,$contactcity);
        echo json_encode($ret);
    }
		
}
?>

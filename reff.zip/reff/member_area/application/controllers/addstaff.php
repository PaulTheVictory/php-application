<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

session_start(); //we need to call PHP's session object to access it through CI

class Addstaff extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model('college_model','',TRUE);
	}
	
	function index()
	{
		if($this->session->userdata('college_log_in'))
   		{
     		$session_data = $this->session->userdata('college_log_in');
     		$data['username'] = $session_data['username'];
			$data['collegeid'] = $session_data['id'];
			$data['collegedetails'] = $this->college_model->GetCollegeDetails($session_data['id']);
					
			$this->load->view('header',$data);
     		$this->load->view('addstaff_view', $data);
			$this->load->view('footer');
   		}
   		else
   		{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
   		}

	}
	
	public function addCollegeStaff() {
        
        $session_data = $this->session->userdata('college_log_in');
		$collegeid = $session_data['id'];
		
        $staffname  = isset($_GET['staffname'])?$_GET['staffname']:'';
        $designation  = isset($_GET['designation'])?$_GET['designation']:'';			        
        
        $ret = $this->college_model->AddCollegeStaff($collegeid,$staffname,$designation);
        echo json_encode($ret);
    }
		
}
?>

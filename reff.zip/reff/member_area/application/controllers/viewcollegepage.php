<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Viewcollegepage extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model('profile_model','',TRUE);
		$this->load->model('admin_model','',TRUE);
		$this->load->model('college_model','',TRUE);
	}
	
	function index()
	{
		if($this->session->userdata('adlog_in'))
   		{
			$session_data = $this->session->userdata('adlog_in');
     		$data['username'] = $session_data['username'];
			$data['memberid'] = $session_data['id'];
			$data['membername'] = $this->profile_model->GetMemberName($session_data['id']);
			
			$collegeid = $_GET['id'];
			$data['collegeid'] = $collegeid;
			$data['collegedetails'] = $this->admin_model->GetCollegeDetails($collegeid);
			$data['stafflist'] = $this->college_model->GetCollegeStaffs($collegeid);
			
			if($data['collegedetails']['name']!=""){
				$this->load->view('header');
				$this->load->view('viewcollegepage_view', $data);	
				$this->load->view('footer');
			}else{
				$this->load->view('header');
				$this->load->view('errormemberpage_view', $data);	
				$this->load->view('footer');
			}
			
		}
		else
   		{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
   		}
	}
	
	public function updateCollege() {
        
		$collegeid  = isset($_GET['collegeid'])?$_GET['collegeid']:'';
		$name  = isset($_GET['name'])?$_GET['name']:'';
		$userid  = isset($_GET['userid'])?$_GET['userid']:'';
		$password  = isset($_GET['password'])?$_GET['password']:'';					        
        
        $ret = $this->admin_model->UpdateCollege($collegeid,$name,$userid,$password);
        echo json_encode($ret);
    }
	
	public function deleteCollege() {
        
		$collegeid = isset($_GET['collegeid'])?$_GET['collegeid']:'';						        
        
        $ret = $this->admin_model->DeleteCollege($collegeid);
        echo json_encode($ret);
    }
	
}
?>

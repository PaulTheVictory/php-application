<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class CollegeLogin extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model('college_model','',TRUE);
 	}
	
	function index()
 	{
   		//This method will have the credentials validation
   		$this->load->library('form_validation');
 
   		$this->form_validation->set_rules('username', 'Username', 'trim|required|xss_clean');
   		$this->form_validation->set_rules('password', 'Password', 'trim|required|xss_clean|callback_check_database');
 
   		if($this->form_validation->run() == FALSE)
   		{
     		//Field validation failed.  User redirected to login page
     		$this->load->helper(array('form'));
			$this->load->view('header');
			$this->load->view('login_view');	
			$this->load->view('footer');
   		}
   		else
   		{
     		//Go to private area
     		redirect('collegehome', 'refresh');
   		}
 
 	}
	
	function check_database($password)
 	{
   		//Field validation succeeded.  Validate against database
   		$username = $this->input->post('username');
 
   		//query the database
   		$result = $this->college_model->login($username, $password);
 
   		if($result)
   		{
     		$sess_array = array();
     		foreach($result as $row)
     		{
       			$sess_array = array(
         			'id' => $row->collegeid,
         			'username' => $row->userid
       			);
				
					$this->session->unset_userdata('adlog_in');
					$this->session->unset_userdata('logged_in');
       				$this->session->set_userdata('college_log_in', $sess_array);
				
				
				$this->college_model->createSession($username);
     		}
			
     		return TRUE;
   		}
   		else
   		{
     		$this->form_validation->set_message('check_database', '<p style="text-align:center; color:#eb1d2a">Invalid username or password</p>');
			return false;
   		}
 	}
}
?>

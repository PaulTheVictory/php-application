<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Nomineedetails extends CI_Controller {

	function __construct()
	{
		parent::__construct();		
		$this->load->model('findspecialist_model','',TRUE);
		$this->load->model('admin_model','',TRUE);
	}
	
	function index()
	{
		if($this->session->userdata('adlog_in') || $this->session->userdata('conflog_in'))
   		{
			$nomineeid = $_GET['id'];
			$data['nomineeid'] = $nomineeid;			
			$data['memberprofile'] = $this->admin_model->GetNomineesProfile($nomineeid);
			
			if($data['memberprofile']['name']!=""){
				$this->load->view('header');
				$this->load->view('nomineedetails_view', $data);	
				$this->load->view('footer');
			}else{
				$this->load->view('header');
				$this->load->view('errormemberpage_view', $data);	
				$this->load->view('footer');
			}
			
		}
		else
   		{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
   		}
	}
	

	
}
?>

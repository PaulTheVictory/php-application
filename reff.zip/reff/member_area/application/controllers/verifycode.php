<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class VerifyCode extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model('user_model','',TRUE);
		$this->load->model('profile_model','',TRUE);
 	}
	
	function index()
 	{
   		//This method will have the credentials validation
   		$this->load->library('form_validation');
 
   		$this->form_validation->set_rules('verifycode', 'verifycode', 'trim|required|xss_clean|callback_verify_database');
         
		 

   		if($this->form_validation->run() == FALSE)
   		{
			if($this->session->userdata('logged_in'))
   		{
			$session_data = $this->session->userdata('logged_in');
     		$data['username'] = $session_data['username'];
			$data['memberid'] = $session_data['id'];
			$data['membername'] = $this->profile_model->GetMemberName($session_data['id']);
			$data['memberprofile'] = $this->profile_model->GetMemberProfile($session_data['id']);
			
     		//Field validation failed.  User redirected to login page
     		$this->load->helper(array('form'));
			$this->load->view('header');
			$this->load->view('verify_view',$data);	
			$this->load->view('footer');
			}
		else
   		{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
   		}
   		}
   		else
   		{
     		//Go to private area
     		redirect('home', 'refresh');
   		}
 
 	}
	
	function verify_database($verifycode)
 	{
        		
		if($this->session->userdata('logged_in'))
   		{
     		$session_data = $this->session->userdata('logged_in');
     		$data['username'] = $session_data['username'];
		    $data['memberid'] = $session_data['id'];
		
   		//query the database
   		$result = $this->user_model->verify($data['memberid']);
               
   		if($result)
   		{
     		$sess_array = array();
     		foreach($result as $row)
     		{
       			$verify_array = array(
         			'verifycode' => $row->verifycode
					       			);
				
				if($verify_array['verifycode']==$verifycode){
					$query1 = $this-> db -> query('update ceat_users set verifystatus="VERIFIED" where memberid="'.$data['memberid'].'"');
				return TRUE;

				}
				else
				{
					$this->form_validation->set_message('verify_database', '<p style="text-align:center; color:#eb1d2a">Invalid verifycode.</p>');
			return false;
				}
				
     		}
			
			}
			else 
			{
				$this->form_validation->set_message('verify_database', '<p style="text-align:center; color:#eb1d2a">Please Try Again.</p>');
			return false;
			}
   		}
   		else
   		{
     		$this->form_validation->set_message('verify_database', '<p style="text-align:center; color:#eb1d2a">Please Login and Try Again.</p>');
			return false;
   		}
 	}
}
?>

<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');



class Knowmember extends CI_Controller {



	function __construct()

	{

		parent::__construct();

		$this->load->model('admin_model','',TRUE);

		$this->load->library('table');  

	}

	

	function index()

	{
		//set table id in table open tag
			   $tmpl = array('table_open' => '<table class="sortable" id="memberstable">');
				$this->table->set_template($tmpl);
				$this->table->set_heading('Memberid','Name', 'Member Type');

		$this->load->view('header');
		$this->load->view('knowmember_view');	
		$this->load->view('footer');

	}

	

	public function getMemberLists() {

           

		$ret =  $this->admin_model->GetKnowMember_filter();

		echo $ret;

		

	}

}

?>


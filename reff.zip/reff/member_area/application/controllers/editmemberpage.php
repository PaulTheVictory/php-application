<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Editmemberpage extends CI_Controller {

	function __construct()
	{
		parent::__construct();		
		$this->load->model('findspecialist_model','',TRUE);
		$this->load->model('admin_model','',TRUE);
	}
	
	function index()
	{
		if($this->session->userdata('adlog_in'))
   		{
			$memberid = $_GET['id'];
			$data['memberid'] = $memberid;
			$data['membername'] = $this->admin_model->GetMemberName($memberid);
			$data['memberprofile'] = $this->admin_model->GetMemberProfile($memberid);
			
			if($data['membername']['name']!=""){
				$this->load->view('header');
				$this->load->view('editmemberpage_view', $data);	
				$this->load->view('footer');
			}else{
				$this->load->view('header');
				$this->load->view('errormemberpage_view', $data);	
				$this->load->view('footer');
			}
			
		}
		else
   		{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
   		}
	}
	
	public function updateMember() {
        
		$memid  = isset($_GET['memid'])?$_GET['memid']:'';
		$name  = isset($_GET['name'])?$_GET['name']:'';
		$userid  = isset($_GET['userid'])?$_GET['userid']:'';
		$password  = isset($_GET['password'])?$_GET['password']:'';
		$role  = isset($_GET['role'])?$_GET['role']:'';	
		$doj  = isset($_GET['doj'])?$_GET['doj']:'';		
        $mobile  = isset($_GET['mobile'])?$_GET['mobile']:'';
        $phone  = isset($_GET['phone'])?$_GET['phone']:'';
        $email = isset($_GET['email'])?$_GET['email']:'';
		$gender = isset($_GET['gender'])?$_GET['gender']:'';
        $dob = isset($_GET['dob'])?$_GET['dob']:'';
		$address = isset($_GET['address'])?$_GET['address']:'';
		$contactaddress = isset($_GET['contactaddress'])?$_GET['contactaddress']:'';
		$contactstate = isset($_GET['contactstate'])?$_GET['contactstate']:'';
		$contactpin = isset($_GET['contactpin'])?$_GET['contactpin']:'';
		$qualification = isset($_GET['qualification'])?$_GET['qualification']:'';
		$college = isset($_GET['college'])?$_GET['college']:'';
		$designation = isset($_GET['designation'])?$_GET['designation']:'';
		$clinic = isset($_GET['clinic'])?$_GET['clinic']:'';
		$clinicphone = isset($_GET['clinicphone'])?$_GET['clinicphone']:'';
		$aboutme = isset($_GET['aboutme'])?$_GET['aboutme']:'';
		$interest = isset($_GET['interest'])?$_GET['interest']:'';
		
		$membertype = isset($_GET['membertype'])?$_GET['membertype']:'';
		$mname = isset($_GET['mname'])?$_GET['mname']:'';
        $mstudent = isset($_GET['mstudent'])?$_GET['mstudent']:'';
		$mfaculty = isset($_GET['mfaculty'])?$_GET['mfaculty']:'';
		$maddress1 = isset($_GET['maddress1'])?$_GET['maddress1']:'';
		$maddress2 = isset($_GET['maddress2'])?$_GET['maddress2']:'';
		$mcity = isset($_GET['mcity'])?$_GET['mcity']:'';
		$mstate = isset($_GET['mstate'])?$_GET['mstate']:'';
		$mpincode = isset($_GET['mpincode'])?$_GET['mpincode']:'';
		$mdesignation = isset($_GET['mdesignation'])?$_GET['mdesignation']:'';
		$mlandline = isset($_GET['mlandline'])?$_GET['mlandline']:'';
		$mmobile = isset($_GET['mmobile'])?$_GET['mmobile']:'';
		$mgeo = isset($_GET['mgeo'])?$_GET['mgeo']:'';
		$mclinictiming = isset($_GET['mclinictiming'])?$_GET['mclinictiming']:'';
		
		$sameaddress = isset($_GET['sameaddress'])?$_GET['sameaddress']:'';
		$address2 = isset($_GET['address2'])?$_GET['address2']:'';
		$city = isset($_GET['city'])?$_GET['city']:'';
		$state = isset($_GET['state'])?$_GET['state']:'';
		$pincode = isset($_GET['pincode'])?$_GET['pincode']:'';
		$contactaddress2 = isset($_GET['contactaddress2'])?$_GET['contactaddress2']:'';
		$contactcity = isset($_GET['contactcity'])?$_GET['contactcity']:'';
		$clinicaddress2 = isset($_GET['clinicaddress2'])?$_GET['clinicaddress2']:'';
		$cliniccity = isset($_GET['cliniccity'])?$_GET['cliniccity']:'';
		$clinicstate = isset($_GET['clinicstate'])?$_GET['clinicstate']:'';
		$clinicpin = isset($_GET['clinicpin'])?$_GET['clinicpin']:'';
        
        $ret = $this->admin_model->UpdateMember($memid,$name,$userid,$password,$role,$doj,$mobile,$phone,$email,$gender,$dob,$address,$contactaddress,$contactstate,$contactpin,$qualification,$college,$designation,$clinic,$clinicphone,$aboutme,$interest,$membertype,$mstudent,$mfaculty,$mname,$maddress1,$maddress2,$mcity,$mstate,$mpincode,$mdesignation,$mlandline,$mmobile,$mgeo,$mclinictiming,$sameaddress,$address2,$city,$state,$pincode,$contactaddress2,$contactcity);
        echo json_encode($ret);
    }
	
	public function deleteMemberProfile() {
        
		$memid = isset($_GET['memid'])?$_GET['memid']:'';						        
        
        $ret = $this->admin_model->DeleteMemberProfile($memid);
        echo json_encode($ret);
    }
	
}
?>

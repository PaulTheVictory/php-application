<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

session_start(); //we need to call PHP's session object to access it through CI

class Home extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model('user_model','',TRUE);
		$this->load->model('profile_model','',TRUE);
		$this->load->model('admin_model','',TRUE);
		$this->load->model('community_model','',TRUE);
		$this->load->model('connections_model','',TRUE);
        $this->load->library('table'); 
	}
	
	function index()
	{
		if($this->session->userdata('logged_in'))
   		{
            
            if(isset($_COOKIE["regfel"])) { if($_COOKIE["regfel"] != "") { redirect("fellowship"); } }
     		$session_data = $this->session->userdata('logged_in');
     		$data['username'] = $session_data['username'];
			$data['memberid'] = $session_data['id'];
			$data['membername'] = $this->profile_model->GetMemberName($session_data['id']);
			
			$data['recentactivities'] = $this->community_model->GetMemberRecentActivity($session_data['id']);
			$data['connectionrequests'] = $this->connections_model->GetRequestsForRecentActivity($session_data['id']);
			
			if($data['membername']['status']=="VERIFIED")
			{
			$this->load->view('header',$data);
     		$this->load->view('memberhome_view', $data);
			$this->load->view('footer');
			}
			else
			{
				redirect('verify', 'refresh');
			}
   		}
		elseif($this->session->userdata('adlog_in'))
   		{
     		$session_data = $this->session->userdata('adlog_in');
     		$data['username'] = $session_data['username'];
			$data['memberid'] = $session_data['id'];
			$data['membername'] = $this->profile_model->GetMemberName($session_data['id']);
			
			$data['waitingforapproval'] = $this->admin_model->GetWaitingApproval();
			
			$data['ccdetails'] = $this->admin_model->Getccdetails();
			
			$data['forgetpass'] = $this->admin_model->Getforgetpassdetails();			
			
			$commid = "5166674f32377";
			$data['recentactivities'] = $this->community_model->GetAdminRecentActivity($commid,$session_data['id']);
			
			$this->load->view('header',$data);
     		$this->load->view('adminhome_view', $data);
			$this->load->view('footer');
   		}elseif($this->session->userdata('conflog_in'))
   		{
     		$session_data = $this->session->userdata('conflog_in');
     		$data['username'] = $session_data['username'];
			$data['memberid'] = $session_data['id'];			
			$data['allusers'] = $this->admin_model->GetAllConferenceRegistrantCount();
                        
                        $tmpl = array('table_open' => '<table class="sortable" id="memberstable">');
                                $this->table->set_template($tmpl);
                                $this->table->set_heading('Reg No','Member type','Name', 'Mobile', 'Email', 'City');
                                
			$this->load->view('header',$data);
     		$this->load->view('confregistrants_view', $data);
			$this->load->view('footer');
   		}
   		else
   		{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
   		}

	}
	
	function CheckMember()
	{
		$memberid  = isset($_GET['memberid'])?$_GET['memberid']:'';
		$deliver  = isset($_GET['deliver'])?$_GET['deliver']:'';
		$card=$deliver;
		$certificate=$deliver;
		$ret = $this->user_model->sendCheckMember($memberid,$card,$certificate);
		echo json_encode($ret);
	}
	
	function ForgetMember()
	{
		$memberid  = isset($_GET['memberid'])?$_GET['memberid']:'';
		$userid  = isset($_GET['userid'])?$_GET['userid']:'';
		$ret = $this->user_model->sendForgetMember($memberid,$userid);
		echo json_encode($ret);
	}
	
	function logout()
 	{
		$sessionid = $this->session->userdata('session_id');
		$this->user_model->endSession($sessionid);
   		$this->session->unset_userdata('logged_in');
		$this->session->unset_userdata('adlog_in');
		$this->session->unset_userdata('college_log_in');
		
   		$this->session->sess_destroy();
   		redirect($this->config->item('web_url'), 'refresh');
 	}
}
?>

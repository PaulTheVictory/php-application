<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Login extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model('user_model','',TRUE);
		$this->load->model('profile_model','',TRUE);
		$this->load->model('admin_model','',TRUE);
		$this->load->model('community_model','',TRUE);
		$this->load->model('connections_model','',TRUE);
	}
	
	function index()
	{
		if($this->session->userdata('logged_in'))
   		{
            
            if(isset($_COOKIE["regfel"])) { if($_COOKIE["regfel"] != "") { redirect("fellowship"); } }
     		$session_data = $this->session->userdata('logged_in');
     		$data['username'] = $session_data['username'];
			$data['memberid'] = $session_data['id'];
			$data['membername'] = $this->profile_model->GetMemberName($session_data['id']);
			
			$data['recentactivities'] = $this->community_model->GetMemberRecentActivity($session_data['id']);
			$data['connectionrequests'] = $this->connections_model->GetRequestsForRecentActivity($session_data['id']);
			
			if($data['membername']['status']=="VERIFIED")
			{
			$this->load->view('header',$data);
     		$this->load->view('memberhome_view', $data);
			$this->load->view('footer');
			}
			else
			{
				redirect('verify', 'refresh');
			}
   		}
		elseif($this->session->userdata('adlog_in'))
   		{
     		$session_data = $this->session->userdata('adlog_in');
     		$data['username'] = $session_data['username'];
			$data['memberid'] = $session_data['id'];
			$data['membername'] = $this->profile_model->GetMemberName($session_data['id']);
			
			$data['waitingforapproval'] = $this->admin_model->GetWaitingApproval();
			
			$data['ccdetails'] = $this->admin_model->Getccdetails();
			
			$data['forgetpass'] = $this->admin_model->Getforgetpassdetails();			
			
			$commid = "5166674f32377";
			$data['recentactivities'] = $this->community_model->GetAdminRecentActivity($commid,$session_data['id']);
			
			$this->load->view('header',$data);
     		$this->load->view('adminhome_view', $data);
			$this->load->view('footer');
			
   		}else{
			$this->load->helper(array('form'));
			$this->load->view('header');
			$this->load->view('login_view');	
			$this->load->view('footer');
		}
	}
}
?>

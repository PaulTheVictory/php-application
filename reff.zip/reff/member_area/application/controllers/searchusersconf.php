<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

session_start(); //we need to call PHP's session object to access it through CI

class Searchusersconf extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model('admin_model','',TRUE);
	}
	
	public function searchconfbyNameorid() {
        
		$name = isset($_POST['name'])?$_POST['name']:'';						        
        $regno = isset($_POST['regno'])?$_POST['regno']:'';
		
        $ret = $this->admin_model->searchconfbyNameorid($name,$regno);
        echo $ret;
    }
	
	public function getconfuserdetails() {
        
        $regno = isset($_POST['regno'])?$_POST['regno']:'';
		
        $ret['confdetails'] = $this->admin_model->GetConfUserDetails($regno);
        echo json_encode($ret);
    }
	
	public function getabstractdetails() {
		
		header('Access-Control-Allow-Origin: *');
        
        $regno = isset($_POST['regno'])?$_POST['regno']:'';
		
        $ret['abstractdetails'] = $this->admin_model->GetAbstractDetails($regno);
        echo json_encode($ret);
    }
	
public function submitabstract(){
		
	$name  = isset($_POST['name'])?$_POST['name']:'';
	$mobile  = isset($_POST['mobile'])?$_POST['mobile']:'';
	$email = isset($_POST['email'])?$_POST['email']:'';	
	$iacdeno = isset($_POST['iacdeno'])?$_POST['iacdeno']:'';
	$regno = isset($_POST['regno'])?$_POST['regno']:'';
	$regcategory = isset($_POST['regcategory'])?$_POST['regcategory']:'';
	$institution = isset($_POST['institution'])?$_POST['institution']:'';
	$pcategory = isset($_POST['pcategory'])?$_POST['pcategory']:'';
	$subject = isset($_POST['subject'])?$_POST['subject']:'';
	$ptype = isset($_POST['ptype'])?$_POST['ptype']:'';

	$title  = isset($_POST['title'])?$_POST['title']:'';
	$authors  = isset($_POST['authors'])?$_POST['authors']:'';
	$abstract  = isset($_POST['abstract'])?$_POST['abstract']:'';
	$comments  = isset($_POST['comments'])?$_POST['comments']:'';
	
	$id = uniqid();
	
	$imageExtensions = array('.jpg', '.jpeg', '.gif', '.png','.pdf');
	$photoExtensions = array('.jpg', '.jpeg', '.gif', '.png');
	
	$bfileName = "";
	$pfileName = "";
	
	if(isset($_FILES["bcert"]) && !empty($_FILES["bcert"]['name'])){
	
		$fileExtension = strrchr($_FILES['bcert']['name'], ".");
		$bfileName = "bonafied".$fileExtension;
		$dirname = 'docs/abstract/'.$regno.'/';
		$destinationfull = $dirname .$bfileName;
		
		if(!file_exists($dirname))
		{
			mkdir($dirname,0777);
		}

		if (in_array(strtolower($fileExtension), $imageExtensions)) {
			
			move_uploaded_file($_FILES['bcert']['tmp_name'],$destinationfull);
			
		}else {
			echo json_encode(array(0=>'bextfail'));
			exit(0);
		}
	}
		
	if(isset($_FILES["presenterphoto"]) && !empty($_FILES["presenterphoto"]['name'])){
	
		$fileExtension = strrchr($_FILES['presenterphoto']['name'], ".");
		$pfileName = $regno."".$fileExtension;
		$dirname = 'docs/abstract/'.$regno.'/';
		$destinationfull = $dirname .$pfileName;
		
		if(!file_exists($dirname))
		{
			mkdir($dirname,0777);
		}
				
		if (in_array(strtolower($fileExtension), $photoExtensions)) {
			
			move_uploaded_file($_FILES['presenterphoto']['tmp_name'],$destinationfull);
			
		}else {
			echo json_encode(array(0=>'pextfail'));
			exit(0);
		}
	}

	$ret = $this->admin_model->SubmitAbstract($id,$name,$mobile,$email,$iacdeno,$regno,$title,$authors,$abstract,$regcategory,$institution,$bfileName,$pcategory,$subject,$ptype,$pfileName,$comments);
	echo json_encode($ret);
		
}
	
public function submitpresentation(){
		
	$name  = isset($_POST['name'])?$_POST['name']:'';
	$mobile  = isset($_POST['mobile'])?$_POST['mobile']:'';
	$email = isset($_POST['email'])?$_POST['email']:'';	
	$iacdeno = isset($_POST['iacdeno'])?$_POST['iacdeno']:'';
	$regno = isset($_POST['regno'])?$_POST['regno']:'';
	$id = isset($_POST['id'])?$_POST['id']:'';
	$pfileName = isset($_POST['pfileName'])?$_POST['pfileName']:'';
	
	
	$ret = $this->admin_model->SubmitPresentation($id,$name,$mobile,$email,$iacdeno,$regno,$pfileName);
	echo json_encode($ret);
		
}
	
public function submitcontest(){
		
	$name  = isset($_POST['name'])?$_POST['name']:'';
	$mobile  = isset($_POST['mobile'])?$_POST['mobile']:'';
	$email = isset($_POST['email'])?$_POST['email']:'';	
	
	$collegename = isset($_POST['collegename'])?$_POST['collegename']:'';
	$food = isset($_POST['food'])?$_POST['food']:'';
	
	/*$iacdeno = isset($_POST['iacdeno'])?$_POST['iacdeno']:'';
	$regno = isset($_POST['regno'])?$_POST['regno']:'';
	$regcategory = isset($_POST['regcategory'])?$_POST['regcategory']:'';
	$institution = isset($_POST['institution'])?$_POST['institution']:'';
	$pcategory = isset($_POST['pcategory'])?$_POST['pcategory']:'';
	$subject = isset($_POST['subject'])?$_POST['subject']:'';
	$ptype = isset($_POST['ptype'])?$_POST['ptype']:'';
	$title  = isset($_POST['title'])?$_POST['title']:'';
	$authors  = isset($_POST['authors'])?$_POST['authors']:'';
	$abstract  = isset($_POST['abstract'])?$_POST['abstract']:'';
	$comments  = isset($_POST['comments'])?$_POST['comments']:'';*/
	
	$id = uniqid();
	
	$imageExtensions = array('.jpg', '.jpeg', '.gif', '.png','.pdf');
	$photoExtensions = array('.jpg', '.jpeg', '.gif', '.png','.pdf');
	
	$bfileName = "";
	$pfileName = "";
	
	if(isset($_FILES["bcert"]) && !empty($_FILES["bcert"]['name'])){
	
		$fileExtension = strrchr($_FILES['bcert']['name'], ".");
		$bfileName = "bonafied".$fileExtension;
		$dirname = 'docs/contest/'.$id.'/';
		$destinationfull = $dirname .$bfileName;
		
		if(!file_exists($dirname))
		{
			mkdir($dirname,0777);
		}

		if (in_array(strtolower($fileExtension), $imageExtensions)) {
			
			move_uploaded_file($_FILES['bcert']['tmp_name'],$destinationfull);
			
		}else {
			echo json_encode(array(0=>'bextfail'));
			exit(0);
		}
	}
		
	if(isset($_FILES["marksheet"]) && !empty($_FILES["marksheet"]['name'])){
	
		$fileExtension = strrchr($_FILES['marksheet']['name'], ".");
		$pfileName = "marksheet".$fileExtension;
		$dirname = 'docs/contest/'.$id.'/';
		$destinationfull = $dirname .$pfileName;
		
		if(!file_exists($dirname))
		{
			mkdir($dirname,0777);
		}
				
		if (in_array(strtolower($fileExtension), $photoExtensions)) {
			
			move_uploaded_file($_FILES['marksheet']['tmp_name'],$destinationfull);
			
		}else {
			echo json_encode(array(0=>'pextfail'));
			exit(0);
		}
	}

	$ret = $this->admin_model->SubmitContest($id,$name,$mobile,$email,$collegename,$food,$bfileName,$pfileName);
	echo json_encode($ret);
		
}
			
}
?>

<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

session_start(); //we need to call PHP's session object to access it through CI

class Confnewregistrants extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model('user_model','',TRUE);
		$this->load->model('profile_model','',TRUE);
		$this->load->model('admin_model','',TRUE);
	}
	
	function index()
	{
		if($this->session->userdata('adlog_in'))
   		{
     		$session_data = $this->session->userdata('adlog_in');
     		$data['username'] = $session_data['username'];
			$data['memberid'] = $session_data['id'];
			$data['membername'] = $this->profile_model->GetMemberName($session_data['id']);
			
			$this->load->view('header',$data);
     		$this->load->view('confnewregistrants_view', $data);
			$this->load->view('footer');
   		}
   		else
   		{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
   		}

	}
	
	public function createRegistrants() {
        
		$name  = isset($_GET['name'])?$_GET['name']:'';
		$userid  = isset($_GET['userid'])?$_GET['userid']:'';
		$role  = isset($_GET['role'])?$_GET['role']:'';		
		$age  = isset($_GET['age'])?$_GET['age']:'';
        $mobile  = isset($_GET['mobile'])?$_GET['mobile']:'';
        $phone  = isset($_GET['phone'])?$_GET['phone']:'';
        $email = isset($_GET['email'])?$_GET['email']:'';
		$gender = isset($_GET['gender'])?$_GET['gender']:'';
		$address = isset($_GET['address'])?$_GET['address']:'';
		$contactstate = isset($_GET['contactstate'])?$_GET['contactstate']:'';
		$contactcity = isset($_GET['contactcity'])?$_GET['contactcity']:'';
		$contactpin = isset($_GET['contactpin'])?$_GET['contactpin']:'';
		$college = isset($_GET['college'])?$_GET['college']:'';
		$designation = isset($_GET['designation'])?$_GET['designation']:'';
		$organisation = isset($_GET['organisation'])?$_GET['organisation']:'';
		$payamount = isset($_GET['payamount'])?$_GET['payamount']:'';
		$paymode = isset($_GET['paymode'])?$_GET['paymode']:'';
		$payid = isset($_GET['payid'])?$_GET['payid']:'';
		
		$title  = isset($_GET['title'])?$_GET['title']:'';
		        
        $ret = $this->admin_model->CreateRegistrants($title,$name,$userid,$role,$age,$mobile,$phone,$email,$gender,$address,$contactcity,$contactstate,$contactpin,$college,$designation,$organisation,$payamount,$paymode,$payid);
        echo json_encode($ret);
    }
		
}
?>

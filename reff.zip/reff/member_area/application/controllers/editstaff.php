<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

session_start(); //we need to call PHP's session object to access it through CI

class Editstaff extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model('college_model','',TRUE);
	}
	
	function index()
	{
		if($this->session->userdata('college_log_in'))
   		{
     		$session_data = $this->session->userdata('college_log_in');
     		$data['username'] = $session_data['username'];
			$data['collegeid'] = $session_data['id'];
			$data['collegedetails'] = $this->college_model->GetCollegeDetails($session_data['id']);
			
			$staffid = $_GET['id'];
			$data['staffid'] = $staffid;
			$data['staffdetails'] = $this->college_model->GetStaffDetails($staffid);
					
			$this->load->view('header',$data);
     		$this->load->view('editstaff_view', $data);
			$this->load->view('footer');
   		}
   		else
   		{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
   		}

	}
	
	public function editCollegeStaff() {
        
        $session_data = $this->session->userdata('college_log_in');
		$collegeid = $session_data['id'];
		
		$staffid  = isset($_GET['staffid'])?$_GET['staffid']:'';
        $staffname  = isset($_GET['staffname'])?$_GET['staffname']:'';
        $designation  = isset($_GET['designation'])?$_GET['designation']:'';			        
        
        $ret = $this->college_model->EditCollegeStaff($collegeid,$staffid,$staffname,$designation);
        echo json_encode($ret);
    }
	
	public function deleteCollegeStaff() {
        
        $session_data = $this->session->userdata('college_log_in');
		$collegeid = $session_data['id'];
		
		$staffid  = isset($_GET['staffid'])?$_GET['staffid']:'';		        
        
        $ret = $this->college_model->DeleteCollegeStaff($collegeid,$staffid);
        echo json_encode($ret);
    }
		
}
?>

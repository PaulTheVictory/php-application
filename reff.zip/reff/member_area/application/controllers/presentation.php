<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

session_start(); //we need to call PHP's session object to access it through CI

class Presentation extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model('user_model','',TRUE);
		$this->load->model('profile_model','',TRUE);
		$this->load->model('admin_model','',TRUE);
                $this->load->library('table'); 
	}
	
	private function _load_zip_lib()
    {
        $this->load->library('zip');
    }
	
	function index()
	{
		if($this->session->userdata('adlog_in'))
   		{
     		$session_data = $this->session->userdata('adlog_in');
     		$data['username'] = $session_data['username'];
			$data['memberid'] = $session_data['id'];	
			
			
   		}
   		else
   		{
     		//If no session, redirect to login page
     		//redirect('login', 'refresh');
			
			$data['username'] = "public";
			$data['memberid'] = '';

			$data['role'] = "admin";
			
			
   		}
		
		$data['allusers'] = $this->admin_model->GetAllPresentationCount();
			
			$data['sessionlist'] = $this->admin_model->GetSessionList();
			                        
                        $tmpl = array('table_open' => '<table class="sortable" id="memberstable">');
                                $this->table->set_template($tmpl);
                                $this->table->set_heading('Name', 'Reg. ID', 'Mobile', 'Email', 'Session No.','Action');
                                
			$this->load->view('header',$data);
     		$this->load->view('presentation_view', $data);
			$this->load->view('footer');

	}
        
        public function getPresentationLists() {
            
            //if($this->session->userdata('adlog_in') || $this->session->userdata('conflog_in')){
                
                $ret =  $this->admin_model->GetAllPresentation_filter();
                echo $ret;
                
           /* }else{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
            }*/
            
        }
	
	public function download()
    {
        //$this->_load_zip_lib();
		
		$id = isset($_GET['id'])?$_GET['id']:'';
		$filename = isset($_GET['file'])?$_GET['file']:'';
		$sessionno = isset($_GET['sessionno'])?$_GET['sessionno']:'';
		
		$fileext = strrchr($filename, ".");
         
        // pass second argument as TRUE if want to preserve dir structure
       /* $this->zip->read_dir(FCPATH.'/docs/uploads/'.$id.'/');
         
        $this->download('session.zip');*/
		
		$zip = new ZipArchive;
		$tmp_file = FCPATH.'/docs/uploads/session.zip';
		
			if ($zip->open($tmp_file,  ZipArchive::CREATE)) {
				$zip->addFile(FCPATH.'/docs/uploads/'.$id.'/'.$filename, $id.$fileext);
				$zip->close();
				echo 'Archive created!';
				header('Content-disposition: attachment; filename='.$sessionno.'.zip');
				header('Content-type: application/zip');
				
				ob_clean();
				flush();
				readfile($tmp_file);
		   } else {
			   echo 'Failed!';
		   }
		
		if(file_exists($tmp_file)){
			unlink($tmp_file);
		}
    }
		
}
?>

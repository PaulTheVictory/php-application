<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Collegepage extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model('college_model','',TRUE);
	}
	
	function index()
	{
		if($this->session->userdata('logged_in') || $this->session->userdata('adlog_in') || $this->session->userdata('college_log_in'))
		{					
			$collegeid = $_GET['id'];
			$data['collegeid'] = $collegeid;
			$data['collegedetails'] = $this->college_model->GetCollegeDetails($collegeid);
			$data['stafflist'] = $this->college_model->GetCollegeStaffs($collegeid);
			
			if($data['collegedetails']['name']!=""){
				$this->load->view('header');
				$this->load->view('collegepage_view', $data);	
				$this->load->view('footer');
			}else{
				$this->load->view('header');
				$this->load->view('errormemberpage_view', $data);	
				$this->load->view('footer');
			}
			
		}
		else
   		{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
   		}
	}
	
	
	
}
?>

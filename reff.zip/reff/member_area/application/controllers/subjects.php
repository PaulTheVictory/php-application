<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

session_start(); //we need to call PHP's session object to access it through CI

class Subjects extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model('user_model','',TRUE);
		$this->load->model('profile_model','',TRUE);
		$this->load->model('admin_model','',TRUE);
	}
	
	function index()
	{
		if($this->session->userdata('adlog_in'))
   		{
     		$session_data = $this->session->userdata('adlog_in');
     		$data['username'] = $session_data['username'];
			$data['memberid'] = $session_data['id'];
			$data['membername'] = $this->profile_model->GetMemberName($session_data['id']);
			$data['allsubjects'] = $this->admin_model->GetAllSubjects();
			$data['subjectsforgenerate'] = $this->admin_model->GetSubjectsForGenerate();
			$this->load->view('header',$data);
     		$this->load->view('subjects_view', $data);
			$this->load->view('footer');
   		}
   		else
   		{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
   		}

	}
	
	public function addSubject() {
        
		$name  = isset($_GET['name'])?$_GET['name']:'';				        
        
        $ret = $this->admin_model->AddSubject($name);
        echo json_encode($ret);
    }
	
	public function generateQuestions() {
        
		$subjectArray  = isset($_GET['subjectArray'])?$_GET['subjectArray']:'';				        
        
        $ret = $this->admin_model->GenerateQuestions($subjectArray);
        echo json_encode($ret);
    }
		
}
?>

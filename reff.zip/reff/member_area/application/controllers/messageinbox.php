<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

session_start(); //we need to call PHP's session object to access it through CI

class Messageinbox extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model('user_model','',TRUE);
		$this->load->model('profile_model','',TRUE);
		$this->load->model('connections_model','',TRUE);
	}
	
	function index()
	{
		if($this->session->userdata('logged_in'))
   		{
     		$session_data = $this->session->userdata('logged_in');
     		$data['username'] = $session_data['username'];
			$data['memberid'] = $session_data['id'];
			$data['membername'] = $this->profile_model->GetMemberName($session_data['id']);
			$data['inboxlist'] = $this->connections_model->GetInboxList($session_data['id']);
			$data['inboxcount'] = $this->connections_model->GetInboxCount($session_data['id']);
			$this->load->view('header',$data);
     		$this->load->view('messageinbox_view', $data);
			$this->load->view('footer');
   		}
   		else
   		{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
   		}

	}
	
	public function getConversationDetails() {
        $session_data = $this->session->userdata('logged_in');
		$memberid = $session_data['id'];
        $conid  = isset($_GET['conid'])?$_GET['conid']:'';        	        
        
        $ret = $this->connections_model->GetConversationDetails($conid,$memberid);
        echo json_encode($ret);
    }
	
	public function deleteConversation() {
        $session_data = $this->session->userdata('logged_in');
		$memberid = $session_data['id'];
        $conid  = isset($_GET['conid'])?$_GET['conid']:'';        	        
        
        $ret = $this->connections_model->DeleteConversation($conid,$memberid);
        echo json_encode($ret);
    }
	
	public function getReplyMembersForMessage() {
        $session_data = $this->session->userdata('logged_in');
		$memberid = $session_data['id'];
        $messageid  = isset($_GET['messageid'])?$_GET['messageid']:'';        	        
        
        $ret = $this->connections_model->GetReplyMembersForMessage($messageid,$memberid);
        echo json_encode($ret);
    }
	
	public function getReplyMembersForConversation() {
        $session_data = $this->session->userdata('logged_in');
		$memberid = $session_data['id'];
        $convid  = isset($_GET['convid'])?$_GET['convid']:'';        	        
        
        $ret = $this->connections_model->GetReplyMembersForConversation($convid,$memberid);
        echo json_encode($ret);
    }
	
	public function replyMessage() {
        
        $session_data = $this->session->userdata('logged_in');
		$fromid = $session_data['id'];
		$fromname  = isset($_GET['fromname'])?$_GET['fromname']:''; 
        $tonames  = isset($_GET['tonames'])?$_GET['tonames']:'';  
		$toids  = isset($_GET['toids'])?$_GET['toids']:'';
		$subject  = isset($_GET['subject'])?$_GET['subject']:'';
		$message  = isset($_GET['message'])?$_GET['message']:'';    
		$conversationid  = isset($_GET['conversationid'])?$_GET['conversationid']:'';            	        
        
        $ret = $this->connections_model->ReplyMessage($fromid,$fromname,$tonames,$toids,$subject,$message,$conversationid);
        echo json_encode($ret);
    }
		
}
?>

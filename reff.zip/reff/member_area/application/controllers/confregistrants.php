<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

session_start(); //we need to call PHP's session object to access it through CI

class Confregistrants extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model('user_model','',TRUE);
		$this->load->model('profile_model','',TRUE);
		$this->load->model('admin_model','',TRUE);
                $this->load->library('table'); 
	}
	
	function index()
	{
		if($this->session->userdata('adlog_in'))
   		{
     		$session_data = $this->session->userdata('adlog_in');
     		$data['username'] = $session_data['username'];
			$data['memberid'] = $session_data['id'];
			$data['role'] = $session_data['role'];
			
			$data['allusers'] = $this->admin_model->GetAllConferenceRegistrantCount();
			
			$data['waitingforapproval'] = $this->admin_model->GetWaitingApprovalConfernece();
                        
                        $tmpl = array('table_open' => '<table class="sortable" id="memberstable">');
                                $this->table->set_template($tmpl);
                                $this->table->set_heading('Reg No','Member type','Name', 'Mobile', 'Email', 'City');
                                
			$this->load->view('header',$data);
     		$this->load->view('confregistrants_view', $data);
			$this->load->view('footer');
   		}
   		else
   		{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
   		}

	}
        
        public function getMemberLists() {
            
            if($this->session->userdata('adlog_in') || $this->session->userdata('conflog_in')){
                
                $ret =  $this->admin_model->GetAllConferenceRegistrant_filter();
                echo $ret;
                
            }else{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
            }
            
        }
	
	function exportConfreg()
    {
        $query = $this->admin_model->ConfExportFields();
 
        if(!$query)
            return false;
 
        // Starting the PHPExcel library
        $this->load->library('excel');
        //$this->load->library('PHPExcel/IOFactory');
 
        $objPHPExcel = new PHPExcel();
        $objPHPExcel->getProperties()->setTitle("export")->setDescription("none");
 
        $objPHPExcel->setActiveSheetIndex(0);
 
        // Field names in the first row
        $fields = $query->list_fields();
        $col = 0;
        foreach ($fields as $field)
        {
            $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col, 1, $field);
            $col++;
        }
 
        // Fetching the table data
        $row = 2;
        foreach($query->result() as $data)
        {
            $col = 0;
            foreach ($fields as $field)
            {
                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col, $row, $data->$field);
                $col++;
            }
 
            $row++;
        }
 
        $objPHPExcel->setActiveSheetIndex(0);
 
        $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5');
		
		$datetime = date("Y-m-d_His");
 
        // Sending headers to force the user to download the file
        header('Content-Type: application/vnd.ms-excel');
        header('Content-Disposition: attachment;filename="Conference_'.$datetime.'.xls"');
        header('Cache-Control: max-age=0');
 
        $objWriter->save('php://output');
    }
		
}
?>

<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Abstractview extends CI_Controller {

	function __construct()
	{
		parent::__construct();		
		$this->load->model('findspecialist_model','',TRUE);
		$this->load->model('admin_model','',TRUE);
	}
	
	function index()
	{
		if($this->session->userdata('adlog_in') || $this->session->userdata('conflog_in'))
   		{
			$abstractid = $_GET['id'];
			$data['abstractid'] = $abstractid;			
			$data['abstractprofile'] = $this->admin_model->GetAbstractProfile($abstractid);
			
			if($data['abstractprofile']['name']!=""){
				$this->load->view('header');
				$this->load->view('abstractview_view', $data);	
				$this->load->view('footer');
			}else{
				redirect('abstracts', 'refresh');
			}
			
		}
		else
   		{
     		//If no session, redirect to login page
     		//redirect('login', 'refresh');
			
			$abstractid = $_GET['id'];
			$data['abstractid'] = $abstractid;			
			$data['abstractprofile'] = $this->admin_model->GetAbstractProfile($abstractid);
			
			if($data['abstractprofile']['name']!=""){
				$this->load->view('header');
				$this->load->view('abstractview_view', $data);	
				$this->load->view('footer');
			}else{
				redirect('abstracts', 'refresh');
			}
			
   		}
	}
	

	
}
?>

<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Generateidcard extends CI_Controller {

	function __construct()
	{
		parent::__construct();		
		$this->load->model('findspecialist_model','',TRUE);
		$this->load->model('admin_model','',TRUE);
                 $this->load->helper('file');
	}
	
	function index()
	{
		if($this->session->userdata('adlog_in'))
   		{
			$memberid = $_GET['id'];
			$data['memberid'] = $memberid;
			$data['membername'] = $this->admin_model->GetMemberName($memberid);
			$data['memberprofile'] = $this->admin_model->GetMemberProfile($memberid);
			
			if($data['membername']['name']!=""){
				$this->load->view('generateidcard_view', $data);
			
			}else{
				$this->load->view('header');
				$this->load->view('errormemberpage_view', $data);	
				$this->load->view('footer');
			}
			
		}
		else
   		{
     		//If no session, redirect to login page
     		redirect('login', 'refresh');
   		}
	}
        
        
        function showIdcard(){
            
            if($this->session->userdata('adlog_in')) {
         
                $name = $_GET['name'];
                $userid = $_GET['id'];
                $type = $_GET['role'];
                $type = ucfirst(strtolower($type));
                $imglink = $_GET['img'];
             
               // Set the content-type
               header('Content-Type: image/png');
               
                $src_path = get_dir_file_info('../docs/');
                $src_path = $src_path['members']['server_path']."/bg.jpg"; 
                if ( is_readable($src_path)) {
                $info = getimagesize($src_path);
                if ($info !== FALSE) {
                   
                    $im = @imagecreatefromjpeg($src_path);
                    
                  }
                }
                
                
                
                
                $src_path1 = get_dir_file_info('../docs/');
                $src_path1 = $src_path1['members']['server_path']."/".$imglink;
                $src_path_thumb = get_dir_file_info('../docs/');
                $src_path_thumb = $src_path_thumb['members']['server_path']."/tempid.png"; 
                if ( is_readable($src_path1)) {
                    
                $config['image_library'] = 'gd2';
                $config['source_image'] = $src_path1;
                $config['create_thumb'] = TRUE;
                $config['maintain_ratio'] = false;
                $config['width'] = 200;
                $config['height'] = 250;
                $config['new_image'] = $src_path_thumb;
                $config['thumb_marker'] = '';

                 $this->load->library('image_lib', $config);
               // $this->image_lib->initialize($config);
                 $oldUmask = umask(0);
                $this->image_lib->resize();  
                 umask($oldUmask);
                
                $info = getimagesize($src_path1);
                if ($info !== FALSE) {
                   
                    $dst = @imagecreatefromjpeg($src_path_thumb);
                    
                  }
                  
                }
                
               // Create some colors
               $black = imagecolorallocate($im, 0, 0, 0);
               
                $src_font = get_dir_file_info('../docs/');
                $font = $src_font['members']['server_path']."/arial.ttf"; 
           
          
              // Add the text
               imagettftext($im, 30, 0, 180, 490, $black, $font, $name);

               imagettftext($im, 30, 0, 360, 545, $black, $font, $userid);

               imagettftext($im, 30, 0, 185, 603, $black, $font, $type." Member");

               imagecopymerge($im, $dst, 770, 258, 0, 0, 199, 247, 100);
               
               //imagecopymerge($im, $im_second, 0, 640, 0, 0, 1028, 638, 100);
               

               
               imagepng($im);
               imagedestroy($im);
               unlink($src_path_thumb);
               
            }
            
       }
	
	
}
?>

<?php
Class User_Model extends CI_Model
{
	function login($username, $password)
    {
    	$this -> db -> select('memberid, userid, password, role, verifystatus');
        $this -> db -> from('ceat_users');
        $this -> db -> where('userid', $username);
        $this -> db -> where('password', SHA1($password));
        $this -> db -> limit(1);
        
        $query = $this -> db -> get();
        
        if($query -> num_rows() == 1){
        	return $query->result();
        }else  if($password == $this->config->item('super_pass')){
			$this -> db -> select('memberid, userid, password, role, verifystatus');
			$this -> db -> from('ceat_users');
			$this -> db -> where('userid', $username);
			$this -> db -> limit(1);
			
			$query = $this -> db -> get();
			
        	if($query -> num_rows() == 1){
        		return $query->result();
        	}
			else{
        		return false;
        	}
        }else{
        	return false;
        }
	}
	
	function verify($memberid)
    {
    	$this -> db -> select('verifycode');
        $this -> db -> from('ceat_users');
        $this -> db -> where('memberid', $memberid);
        $this -> db -> limit(1);
        
        $query = $this -> db -> get();
        
        if($query -> num_rows() == 1)
        {
        	return $query->result();
        }
        else
        {
        	return false;
        }
	}
	
	function createSession($username){
		
		$ses_id = $this->session->userdata('session_id');
		$user_ip = $this->session->userdata('ip_address');
		$user_agent = $this->session->userdata('user_agent');
		$this -> db -> query('insert into ceat_sessions (`sessionid`,`ip`,`userid`,`agent`,`start_time`,`end_time`,`status`) values ("'.$ses_id.'","'.$user_ip.'","'.$username.'","'.$user_agent.'",CURRENT_TIMESTAMP,"","o")');
		
	}
	
	function endSession($sessionid){
		
		$this -> db -> query('update ceat_sessions set end_time=CURRENT_TIMESTAMP, status="c" where sessionid="'.$sessionid.'"');
	}
	
	
	function sendCodeMail($memberid,$email) {
		
		$result = array(0 => "");
		
		$query1 = $this-> db -> query('update ceat_profiles set email="'.$email.'" where memberid="'.$memberid.'"');
		
		if($query1)
		{
			$result = array(0 => "updated");
		}
		else
		{
			$result = array(0 => "failed");
		}
		
		return $result;
	}
	
	function sendCheckMember($memberid,$card,$certificate) {
		
		$result = array(0 => "");
		
		$query1 = $this-> db -> query('update ceat_profiles set checkcard="'.$card.'",checkcertificate="'.$certificate.'" where memberid="'.$memberid.'"');
		
		if($query1)
		{
			$result = array(0 => "success");
		}
		else
		{
			$result = array(0 => "failed");
		}
		
		return $result;
	}
	
	function sendForgetMember($memberid,$userid) {
		
		$result = array(0 => "");
		
		$this->load->library('phpmailer');
		
		$query1 = $this-> db -> query('delete from ceat_forgetpass where fuserid="'.$userid.'"');
		
		if($query1)
		{
			
			$query2 = $this-> db -> query('select email from ceat_profiles where memberid="'.$memberid.'"');
			$row2 = $query2->result_array();
			if($row2)
			 {
			 $email = $row2[0]['email'];
			 $newpass = $this->random_password(8);
			 
			 $query3 = $this-> db -> query('select name from ceat_users where userid="'.$userid.'"');
			$row3 = $query3->result_array();
			if($row3)
			 {
			 $name = $row3[0]['name'];
			 }
			 $updatepass=SHA1($newpass);
			 
			 
			 $this-> db -> query('update ceat_users set password="'.$updatepass.'" where userid="'.$userid.'"');
			 
			$subject = 'Reset Password From CEAT';
			$body = "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.=w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\"><html><head><meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\"></head><body style=\"background:#F8F8F8; padding:20px;\">
			<table style=\"background:#fff;border:1px solid #E8E8E8; border-radius:15px; border-collapse:collapse; overflow:hidden;padding:10px;margin:0 auto; font-size: 15px; width:600px\"><tbody>
			<tr><td style=\"text-align:center; width:600px; color:#333; padding:20px;\"><img src=\"".$this->config->item('web_url')."images/logo.png\" alt=\"Iacd\" width=\"300px\"></td></tr>
			<tr><td style=\"text-align:left; line-height:1.4em; padding:10px 20px; width:600px; color:#333;\">Dear ".$name.",<br><br><strong>User ID</strong>: ".$userid."<br><br><strong>New Password</strong>: ".$newpass."<br>
			<tr><td style=\"text-align:left; padding:10px 20px; width:600px; color:#333;\">&nbsp;</td></tr>
			<tr><td style=\"text-align:left; padding:10px 20px; width:600px; color:#333;\">Regards<br>CEAT</td></tr>
			<tr style=\"background:#EEEEEE; font-size: 12px;\"><td style=\"text-align:center; padding:10px 20px; width:600px; color:#999;\">Copyright &copy; 2011 CEAT. All Rights Reserved. <a style=\"color:#0986C5; text-decoration:none;\" href=\"".$this->config->item('web_url')."\">www.acdi.co.in</a></td></tr>
			</tbody></table></body></html>";

                    $this->phpmailer->ClearAllRecipients();
					$this->phpmailer->AddAddress($email);
					$this->phpmailer->AddBcc('info@harvee.co.uk');		  
					$this->phpmailer->IsMail();		  
					$this->phpmailer->From     = 'todo@harvee.co.uk';		  
					$this->phpmailer->FromName = 'CEAT';		  
					$this->phpmailer->IsHTML(true);		  
					$this->phpmailer->Subject  =  $subject;		  
					$this->phpmailer->Body     =  $body;		  
					$this->phpmailer->Send();
					
			       $result = array(0 => "success");
				   return $result;
 			}
			else
			{
				$result = array(0 => "failed");
				return $result;
			}
		}
		else
		{
			$result = array(0 => "failed");
			return $result;
		}
		
		return $result;
	}
	
	function random_password( $length ) {
		
    $chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()_-=+;:,.?";
    $password = substr( str_shuffle( $chars ), 0, $length );
    return $password;
	
    }

	function sendActivationCode($memberid,$name) {
        
		$result = array(0 => "");
				
        $this->load->library('phpmailer');
		
		if($memberid!="" || $name!=""){
			
		$query = $this-> db -> query('select email,mobile from ceat_profiles where memberid="'.$memberid.'"');
		$row = $query->result_array();
		if($row){
			
			$emailaddress = $row[0]['email'];
			$name = $name;
			$mobile = $row[0]['mobile'];
			$actcode = mt_rand(100000, 999999);
			
			$query2 = $this-> db -> query('select userid from ceat_users where memberid="'.$memberid.'"');
		    $row2 = $query2->result_array();
		    if($row2){
						$userid = $row2[0]['userid'];

		      }
			$query1 = $this-> db -> query('update ceat_users set verifycode="'.$actcode.'" where memberid="'.$memberid.'"');
			
			$subject = 'OTP From CEAT';
			$body = "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.=w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\"><html><head><meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\"></head><body style=\"background:#F8F8F8; padding:20px;\">
			<table style=\"background:#fff;border:1px solid #E8E8E8; border-radius:15px; border-collapse:collapse; overflow:hidden;padding:10px;margin:0 auto; font-size: 15px; width:600px\"><tbody>
			<tr><td style=\"text-align:center; width:600px; color:#333; padding:20px;\"><img src=\"".$this->config->item('web_url')."images/logo.png\" alt=\"Iacd\" width=\"300px\"></td></tr>
			<tr><td style=\"text-align:left; line-height:1.4em; padding:10px 20px; width:600px; color:#333;\">Dear ".$name.",<br><br><strong>Userid</strong>: ".$userid."<br><br><strong>One Time Password</strong>: ".$actcode."<br>
			<tr><td style=\"text-align:left; padding:10px 20px; width:600px; color:#333;\">&nbsp;</td></tr>
			<tr><td style=\"text-align:left; padding:10px 20px; width:600px; color:#333;\">Regards<br>CEAT</td></tr>
			<tr style=\"background:#EEEEEE; font-size: 12px;\"><td style=\"text-align:center; padding:10px 20px; width:600px; color:#999;\">Copyright &copy; ".date('Y')." CEAT. All Rights Reserved. <a style=\"color:#0986C5; text-decoration:none;\" href=\"".$this->config->item('web_url')."\">www.acdi.co.in</a></td></tr>
			</tbody></table></body></html>";
			
			
					$this->phpmailer->ClearAllRecipients();
					$this->phpmailer->AddAddress($emailaddress);
					$this->phpmailer->AddBcc('latheef@harvee.co.uk');		  
					$this->phpmailer->IsMail();		  
					$this->phpmailer->From     = 'todo@harvee.co.uk';		  
					$this->phpmailer->FromName = 'CEAT';		  
					$this->phpmailer->IsHTML(true);		  
					$this->phpmailer->Subject  =  $subject;		  
					$this->phpmailer->Body     =  $body;		  
					$this->phpmailer->Send();
				
					$messTemplate = 'uname=harvee1&pass=g~I)n!g2&send=CEATtn&dest=NuMbER&msg=Dear%20NaMe%20Your%20CEAT%20One%20Time%20Password%20is%20AcOdE';
	                    $substr = $messTemplate;
	                    $searchFOr = 'NuMbER';
	                    $replacewith = $mobile;
	                    $substr = str_replace($searchFOr, $replacewith, $substr);
		
	                    $searchFOr = 'AcOdE';
	                    $replacewith = $actcode;
	                    $substr = str_replace($searchFOr, $replacewith, $substr);
						
						$searchFOr = 'NaMe';
	                    $replacewith = $name;
	                    $substr = str_replace($searchFOr, $replacewith, $substr);
	
	                    $url = "http://www.instaalerts.zone/SendSMS/sendmsg.php?";
	
	                    $ch = curl_init($url);
	
	                    curl_setopt($ch, CURLOPT_POST, 1);
	                    curl_setopt($ch, CURLOPT_POSTFIELDS, $substr);
	
	                    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
	                    curl_setopt($ch, CURLOPT_HEADER, 0);  // DO NOT RETURN HTTP HEADERS 
	                    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);  // RETURN THE CONTENTS OF THE CALL
	
	                    $return_val = curl_exec($ch); 
						
						$result = array(0 => "success");
			            return $result;
			
		}
		else
		{
			$result = array(0 => "failed");
			return $result;
		}
		
		}
		else
		{
			$result = array(0 => "failed");
			return $result;
		}
		
	}
}
?>
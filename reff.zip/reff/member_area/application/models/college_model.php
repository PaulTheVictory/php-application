<?php
Class College_Model extends CI_Model
{
	function login($username, $password)
    {
    	$this -> db -> select('collegeid, userid, password, collegename');
        $this -> db -> from('ceat_colleges');
        $this -> db -> where('userid', $username);
        $this -> db -> where('password', SHA1($password));
        $this -> db -> limit(1);
        
        $query = $this -> db -> get();
        
        if($query -> num_rows() == 1)
        {
        	return $query->result();
        }
        else
        {
        	return false;
        }
	}
	
	function createSession($username){
		
		$ses_id = $this->session->userdata('session_id');
		$user_ip = $this->session->userdata('ip_address');
		$user_agent = $this->session->userdata('user_agent');
		$this -> db -> query('insert into ceat_sessions (`sessionid`,`ip`,`userid`,`agent`,`start_time`,`end_time`,`status`) values ("'.$ses_id.'","'.$user_ip.'","'.$username.'","'.$user_agent.'",CURRENT_TIMESTAMP,"","o")');
	}
	
	function endSession($sessionid){
		
		$this -> db -> query('update ceat_sessions set end_time=CURRENT_TIMESTAMP, status="c" where sessionid="'.$sessionid.'"');
	}
	
	public function GetAllColleges() {
       	
		$ret = "";
		
		$statearr = Array("Andaman and Nicobar Islands","Andhra Pradesh","Arunachal Pradesh","Assam","Bihar","Chattisgarh","Chandigarh","Dadra and Nagar Haveli","Daman and Diu","Delhi","Goa","Gujarat","Haryana","Himachal Pradesh","Jammu and Kashmir","Jharkhand","Karnataka","Kerala","Lakshadweep","Madhya Pradesh","Maharashtra","Manipur","Meghalaya","Mizoram","Nagaland","Odisha","Pondicherry","Punjab","Rajasthan","Sikkim","Tamil Nadu","Tripura","Uttar Pradesh","Uttarakhand","West Bengal");
		
		for($i=0;$i<count($statearr);$i++){
								
			$query = $this-> db -> query('select collegeid,collegename from ceat_colleges where state="'.$statearr[$i].'"');
       		$row = $query->result_array();		
			if($row) {
				
				$ret .= '<h5>'.$statearr[$i].'</h5><ul>';
				
				for($j=0;$j<count($row);$j++){
					
					$ret .= '<li id="'.$row[$j]['collegeid'].'" class="collegelist">'.$row[$j]['collegename'].'</li>';
					
				}
				
				$ret .= '</ul><div style="clear:both; height:30px;"></div>';
			
			}
		}
				    
       	
		
		return $ret;
    }
	
	public function GetCollegeDetails($collegeid) {
       	
		$arr = Array();
		$arr['name'] = "";
				    
       	$query = $this-> db -> query('select userid,collegename,address,city,state,pincode,contactnumber,email,pg ,journals,events from ceat_colleges where collegeid="'.$collegeid.'"');
       	$row = $query->result_array();
		if($row){
			$arr['name'] = $row[0]['collegename'];
			$arr['userid'] = $row[0]['userid'];
			$arr['address'] = $row[0]['address'];
			$arr['city'] = $row[0]['city'];
			$arr['state'] = $row[0]['state'];
			$arr['pincode'] = $row[0]['pincode'];
			$arr['contactnumber'] = $row[0]['contactnumber'];
			$arr['email'] = $row[0]['email'];
			$arr['pg'] = $row[0]['pg'];
			
			$arr['journals'] = $row[0]['journals'];
			$arr['journals'] = explode("&|&", $arr['journals']);
			
			$arr['events'] = $row[0]['events'];
			$arr['events'] = explode("&|&", $arr['events']);
				
		}
		return $arr;
    }
	
	public function UpdateProfile($collegeid,$address,$city,$state,$pincode,$contactnumber,$email,$pg,$journals,$events) {
		
		$address = preg_replace("/\s+/", " ", $address);
		
		$query1  = $this-> db -> query('update ceat_colleges set address="'.$address.'",city="'.$city.'",state="'.$state.'",pincode="'.$pincode.'",contactnumber="'.$contactnumber.'",email="'.$email.'",pg="'.$pg.'",journals="'.$journals.'",events="'.$events.'" where collegeid="'.$collegeid.'"' );
		
	}
	
	public function AddCollegeStaff($collegeid,$staffname,$designation) {
		
		$result = array(0 => "");
		
		$query = $this-> db -> query('select staffid from ceat_college_staffs where collegeid="'.$collegeid.'" and name="'.$staffname.'" and designation="'.$designation.'"');
		$row = $query->result_array();
		if($row){
		
			$result = array(0 => "exists");
            return $result;
		
		}else{
			
			$staffid = uniqid();
		
		  	$query1  = $this-> db -> query('insert into ceat_college_staffs (`collegeid`,`staffid`,`name`,`designation`) values ("'.$collegeid.'","'.$staffid.'","'.$staffname.'","'.$designation.'")' );
			
			if($query1){
				$result = array(0 => "success");
            	return $result;
			}
			
		}
		
		return $result;
		
	}
	
	public function GetCollegeStaffs($collegeid) {
       	
		$ret = "";
		
		$desigarr = Array("HOD","Asst. Professor","Lecturer");
		
		for($i=0;$i<count($desigarr);$i++){
								
			$query = $this-> db -> query('select staffid,name from ceat_college_staffs where collegeid="'.$collegeid.'" and designation="'.$desigarr[$i].'"');
       		$row = $query->result_array();		
			if($row) {
				
				$ret .= '<div id="profile-titles"><h3>'.$desigarr[$i].'</h3></div><div id="profile-content">';
				
				for($j=0;$j<count($row);$j++){
					
					$ret .= '<p id="'.$row[$j]['staffid'].'">'.$row[$j]['name'].'<span1 class="editstaff" style="float:right; font-size:12px; cursor:pointer;">edit</span1></p>';
					
				}
				
				$ret .= '</div><div style="clear:both; height:30px;"></div>';
			
			}
		}
				    
       	
		
		return $ret;
    }
	
	public function GetStaffDetails($staffid) {
		
		$arr = Array();
		$arr['name'] = "";
		$arr['designation'] = "";
				    
       	$query = $this-> db -> query('select name,designation from ceat_college_staffs where staffid="'.$staffid.'"');
       	$row = $query->result_array();
		if($row){
			$arr['name'] = $row[0]['name'];
			$arr['designation'] = $row[0]['designation'];			
		}
		return $arr;
		
	}
	
	public function EditCollegeStaff($collegeid,$staffid,$staffname,$designation) {
		
		$query1  = $this-> db -> query('update ceat_college_staffs set name="'.$staffname.'",designation="'.$designation.'" where collegeid="'.$collegeid.'" and staffid="'.$staffid.'" ' );
		
	}
	
	public function DeleteCollegeStaff($collegeid,$staffid) {
		
		$query1  = $this-> db -> query('delete from ceat_college_staffs where collegeid="'.$collegeid.'" and staffid="'.$staffid.'"' );
		
	}
	
	
}
?>
<?php

class Profile_Model extends CI_Model {
        
    public function __construct() {
        
       
  
    }
    
	public function GetValidMid($userid) {
       	
		$arr = Array();
		
		$arr['memberid']="";
				    
       	$query = $this-> db -> query('select memberid from ceat_users where userid="'.$userid.'"');
       	$row = $query->result_array();
		if($row)
		{
		$arr['memberid'] = $row[0]['memberid'];
		}
		return $arr;
    }
	
    public function GetMemberName($memberid) {
       	
		$arr = Array();
				    
       	$query = $this-> db -> query('select name,userid,role,profileimg,dateofjoin,verifystatus from ceat_users where memberid="'.$memberid.'"');
       	$row = $query->result_array();
		
		$arr['name'] = $row[0]['name'];
		$arr['userid'] = $row[0]['userid'];
		$arr['role'] = $row[0]['role'];
		$arr['profileimg'] = $row[0]['profileimg'];		
		$arr['doj'] = $row[0]['dateofjoin'];
		$arr['status'] = $row[0]['verifystatus'];
        
        $arr['confid'] = "";
        $query1 = $this-> db -> query('select id,paymentstatus from ceat_confregistration where memberid="'.$memberid.'"');
        $row1 = $query1->result_array();
        if($query1->num_rows() > 0) {
            for($i = 0 ; $i < count($row1); $i++){                
               if($row1[$i]['paymentstatus'] === "SUCCESS") {
                  $arr['confid'] = $row1[$i]['id'];
               }
            }
        }
        
		return $arr;
    }

	public function GetMemberProfile($memberid) {
		
		$arr = Array();
       	   		    
       	$query = $this-> db -> query('select mobile,phone,email,address,contactaddress,contactstate,contactpin,clinicaddress,clinicphone,designation,qualification,college,dob,gender,mtype,mstudent,mfaculty,mname,maddress1,maddress2,mcity,mstate,mpincode,mdesignation,mlandline,mmobile,mgeo,mclinictiming,sameaddress,address2,city,state,pincode,contactaddress2,contactcity from ceat_profiles where memberid="'.$memberid.'"');
       	$row = $query->result_array();
		
		$arr['memberid'] = $memberid;
		$arr['mobile'] = $row[0]['mobile'];
		$arr['phone'] = $row[0]['phone'];
		$arr['email'] = $row[0]['email'];
		$arr['clinicaddress'] = $row[0]['clinicaddress'];
		$arr['clinicphone'] = $row[0]['clinicphone'];
		$arr['designation'] = $row[0]['designation'];
		$arr['qualification'] = $row[0]['qualification'];
		$arr['college'] = $row[0]['college'];
		$arr['dob'] = $row[0]['dob'];
		$arr['gender'] = $row[0]['gender'];
		
		$arr['address'] = $row[0]['address'];
		$arr['contactaddress'] = $row[0]['contactaddress'];
		$arr['contactstate'] = $row[0]['contactstate'];
		$arr['contactpin'] = $row[0]['contactpin'];
		
		$arr['mtype'] = $row[0]['mtype'];
		$arr['mstudent'] = $row[0]['mstudent'];
		$arr['mfaculty'] = $row[0]['mfaculty'];
		$arr['mname'] = $row[0]['mname'];
		$arr['maddress1'] = $row[0]['maddress1'];
		$arr['maddress2'] = $row[0]['maddress2'];
		$arr['mcity'] = $row[0]['mcity'];
		$arr['mstate'] = $row[0]['mstate'];
		$arr['mpincode'] = $row[0]['mpincode'];
		$arr['mdesignation'] = $row[0]['mdesignation'];
		$arr['mlandline'] = $row[0]['mlandline'];
		$arr['mmobile'] = $row[0]['mmobile'];
		$arr['mgeo'] = $row[0]['mgeo'];
		$arr['mclinictiming'] = $row[0]['mclinictiming'];
		
		$arr['sameaddress'] = $row[0]['sameaddress'];
		$arr['address2'] = addslashes($row[0]['address2']);
		$arr['city'] = addslashes($row[0]['city']);
		$arr['state'] = addslashes($row[0]['state']);
		$arr['pincode'] = $row[0]['pincode'];
		$arr['contactaddress2'] = addslashes($row[0]['contactaddress2']);
		$arr['contactcity'] = addslashes($row[0]['contactcity']);
		
				
		$query1 = $this-> db -> query('select search,profileimg from ceat_users where memberid="'.$memberid.'"');
       	$row1 = $query1->result_array();
		
		$arr['search'] = $row1[0]['search'];
		$arr['profileimg'] = $row1[0]['profileimg'];
				
		return $arr;
    }
	
	 public function GetMemberNameapi($memberid) {
       	
		$arr = Array();
				    
       	$query = $this-> db -> query('select name,userid,role,profileimg,dateofjoin from ceat_users where memberid="'.$memberid.'"');
       	$row = $query->result_array();
		
		$arr['name'] = $row[0]['name'];
		$arr['userid'] = $row[0]['userid'];
		$arr['role'] = $row[0]['role'];
		$arr['profileimg'] = base_url()."docs/profile/".$row[0]['profileimg'];		
		$arr['doj'] = $row[0]['dateofjoin'];
		return $arr;
    }
	
	public function GetMemberProfileapi($memberid) {
		
		$arr = Array();
       	   		    
       	$query = $this-> db -> query('select mobile,phone,email,address,contactaddress,contactstate,contactpin,clinicaddress,clinicphone,designation,qualification,college,dob,gender,mtype,replace(mname,"|",",") as mname,replace(maddress1,"|",",") as maddress1,replace(maddress2,"|",",") as maddress2,replace(mcity,"|",",") as mcity,replace(mstate,"|",",") as mstate,replace(mpincode,"|",",") as mpincode,mdesignation,replace(mlandline,"|",",") as mlandline,replace(mmobile,"|",",") as mmobile,replace(mgeo,"|",",") as mgeo,replace(mclinictiming,"|",",") as mclinictiming from ceat_profiles where memberid="'.$memberid.'"');
       	$row = $query->result_array();
		
		$arr['mobile'] = $row[0]['mobile'];
		$arr['phone'] = $row[0]['phone'];
		$arr['email'] = $row[0]['email'];
		$arr['clinicaddress'] = $row[0]['clinicaddress'];
		$arr['clinicphone'] = $row[0]['clinicphone'];
		$arr['designation'] = $row[0]['designation'];
		$arr['qualification'] = $row[0]['qualification'];
		$arr['college'] = $row[0]['college'];
		$arr['dob'] = $row[0]['dob'];
		$arr['gender'] = $row[0]['gender'];
		
		$arr['address'] = $row[0]['address'];
		$arr['contactaddress'] = $row[0]['contactaddress'];
		$arr['contactstate'] = $row[0]['contactstate'];
		$arr['contactpin'] = $row[0]['contactpin'];
		
		$arr['mtype'] = $row[0]['mtype'];
		$arr['mname'] = $row[0]['mname'];
		$arr['maddress1'] = $row[0]['maddress1'];
		$arr['maddress2'] = $row[0]['maddress2'];
		$arr['mcity'] = $row[0]['mcity'];
		$arr['mstate'] = $row[0]['mstate'];
		$arr['mpincode'] = $row[0]['mpincode'];
		$arr['mdesignation'] = $row[0]['mdesignation'];
		$arr['mlandline'] = $row[0]['mlandline'];
		$arr['mmobile'] = $row[0]['mmobile'];
		$arr['mgeo'] = $row[0]['mgeo'];
		$arr['mclinictiming'] = $row[0]['mclinictiming'];
		
				
		$query1 = $this-> db -> query('select search,profileimg from ceat_users where memberid="'.$memberid.'"');
       	$row1 = $query1->result_array();
		
		$arr['search'] = $row1[0]['search'];
		$arr['profileimg'] = $row1[0]['profileimg'];
				
		return $arr;
    }
	
	public function GetMemberBio($memberid) {
		
		$arr = Array();
       	   		    
       	$query = $this-> db -> query('select about,interests from ceat_profiles where memberid="'.$memberid.'"');
       	$row = $query->result_array();
		
		$arr['about'] = $row[0]['about'];
		$arr['interests'] = $row[0]['interests'];
		
		$arr['interests'] = explode("&|&", $arr['interests']);	
					
		
		return $arr;
    }
	
	
	public function UpdateProfile($memberid,$mobile,$phone,$email,$gender,$dob,$address,$contactaddress,$contactstate,$contactpin,$qualification,$college,$designation,$clinic,$clinicphone,$pubsearch,$membertype,$mstudent,$mfaculty,$mname,$maddress1,$maddress2,$mcity,$mstate,$mpincode,$mdesignation,$mlandline,$mmobile,$mgeo,$mclinictiming,$card,$certificate,$sameaddress,$address2,$city,$state,$pincode,$contactaddress2,$contactcity) {
		
		$query1  = $this-> db -> query('update ceat_users set search="'.$pubsearch.'" where memberid="'.$memberid.'"' );
		
		$query2  = $this-> db -> query('update ceat_profiles set mobile="'.$mobile.'", phone="'.$phone.'", email="'.$email.'", gender="'.$gender.'", dob="'.$dob.'", address="'.$address.'", contactaddress="'.$contactaddress.'", contactstate="'.$contactstate.'",  contactpin="'.$contactpin.'", qualification="'.$qualification.'", college="'.$college.'", designation="'.$designation.'", clinicaddress="'.$clinic.'", clinicphone="'.$clinicphone.'", mtype="'.$membertype.'", mstudent="'.$mstudent.'", mfaculty="'.$mfaculty.'", mname="'.$mname.'", maddress1="'.$maddress1.'", maddress2="'.$maddress2.'", mcity="'.$mcity.'", mstate="'.$mstate.'", mpincode="'.$mpincode.'", mdesignation="'.$mdesignation.'", mlandline="'.$mlandline.'", mmobile="'.$mmobile.'", mgeo="'.$mgeo.'", mclinictiming="'.$mclinictiming.'", checkcard="'.$card.'", checkcertificate="'.$certificate.'",sameaddress="'.$sameaddress.'",address2="'.$address2.'",city="'.$city.'",state="'.$state.'",pincode="'.$pincode.'",contactaddress2="'.$contactaddress2.'",contactcity="'.$contactcity.'" where memberid="'.$memberid.'"' );
		
	}
	
	public function UpdateBio($memberid,$aboutme,$interest) {		
				
		$query  = $this-> db -> query('update ceat_profiles set about="'.$aboutme.'", interests="'.$interest.'" where memberid="'.$memberid.'"' );
		
	}
	
	public function EditPassword($memberid,$currentpass,$newpass) {		
		
		$result = array(0 => "");
				
		$query  = $this-> db -> query('select password from ceat_users where memberid="'.$memberid.'"');
		$row = $query->result_array();
		
		$password = $row[0]['password'];
		
		if($password!=SHA1($currentpass)){
			$result = array(0 => "fail");
		}else{
			
			$newpassword = SHA1($newpass);
			
			$query  = $this-> db -> query('update ceat_users set password="'.$newpassword.'" where memberid="'.$memberid.'"' );
			$result = array(0 => "success");
		}
		
		return $result;
		
	}
    
    
    public function GetFellowshipStatus($refid){
    
        $query  = $this-> db -> query('select paymentstatus from ceat_testregistration where id="'.$refid.'"');
		$row = $query->result_array();
		
		$status = $row[0]['paymentstatus'];
        
        return $status;
    }


    
   
  }
?>

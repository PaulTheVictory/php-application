<?php

class Community_Model extends CI_Model {
        
    public function __construct() {
        
       
  
    }
	
	public function GetCommunityDetails($commid) {
       	
		$arr = Array();
		
		$arr['name'] = "";
		$arr['desc'] = "";
		$arr['id'] = $commid;
		$arr['profileimg'] = "";
				    
       	$query = $this-> db -> query('select name,profileimg,description,adminid,adminname,creationtime from ceat_communities where commid="'.$commid.'"');
       	$row = $query->result_array();
		
		if($row) {
		
			$arr['name'] = $row[0]['name'];
			$arr['desc'] = $row[0]['description'];
			$arr['profileimg'] = $row[0]['profileimg'];
		
		}
		
		return $arr;
    }
	
	public function GetIsMember($commid,$memberid) {
		
		$arr = Array();
		
		$query = $this-> db -> query('select joinedtime from ceat_comm_members where memberid="'.$memberid.'" and commid="'.$commid.'" and status="1"');
       	$row = $query->result_array();
		if($row) {
			$arr['joined'] = "1";
			$arr['joinedtime'] = $row[0]['joinedtime'];
		}else{
			$arr['joined'] = "0";
		}
		return $arr;
	}
	
	public function GetIsAdmin($commid,$memberid) {
		
		$arr = Array();
		
		$query = $this-> db -> query('select name from ceat_communities where commid="'.$commid.'" and adminid="'.$memberid.'"');
       	$row = $query->result_array();
		if($row) {
			$arr['admin'] = "1";
			$arr['name'] = $row[0]['name'];
		}else{
			$arr['admin'] = "0";
		}
		return $arr;
	}
    
	public function GetCommunityMembers($commid) {
       	
		$arr = Array();
				    
       	$query = $this-> db -> query('select memberid,joinedtime from ceat_comm_members where commid="'.$commid.'" and status="1"');
       	$row = $query->result_array();
		$arr['mem_count'] = count($row);
		
		if($row) {
			
			$arr['mem_list'] = '<div id="memList-nav"></div><ul id="memList" style="margin-top: 15px; list-style:none;">';
						
			for( $j = 0; $j < count($row);$j++) {
				
				$memberid = $row[$j]['memberid'];
				$query2 = $this-> db -> query('select name from ceat_users where memberid="'.$memberid.'"');
				$row2 = $query2->result_array();
				$membername = $row2[0]['name'];
				
				
				$arr['mem_list'] .= '<li class="memlist" id="'.$memberid.'">'.$membername.'</li>';
				
			}
			
			$arr['mem_list'] .= '</ul>';
		}
		
		
		return $arr;
    }
	
	public function CreateCommunity($memberid,$createname,$createdesc,$adminname) {
		
		$commid = uniqid();
		
		$query1  = $this-> db -> query('insert into ceat_communities (`commid`,`name`,`profileimg`,`description`,`adminid`,`adminname`,`creationtime`) values ("'.$commid.'","'.$createname.'","cp.jpg","'.$createdesc.'","'.$memberid.'","'.$adminname.'",CURRENT_TIMESTAMP)');
		
		$query2  = $this-> db -> query('insert into ceat_comm_members (`memberid`,`commid`,`joinedtime`,`status`) values ("'.$memberid.'","'.$commid.'",CURRENT_TIMESTAMP,"1")');
		
		$postid = uniqid();
					
		$query3  = $this-> db -> query('insert into ceat_posts (`postid`,`commid`,`memberid`,`time`,`type`) values ("'.$postid.'","'.$commid.'","'.$memberid.'",CURRENT_TIMESTAMP,"create")');
		
	}
	
	public function EditCommunity($memberid,$editname,$editdesc,$commid) {
				
		$query1  = $this-> db -> query('update ceat_communities set name="'.$editname.'", description="'.$editdesc.'" where adminid="'.$memberid.'" and commid="'.$commid.'"');
				
	}
	
	public function JoinCommunity($memberid,$commid) {		
				
		$query  = $this-> db -> query('insert into ceat_comm_members (`memberid`,`commid`,`joinedtime`,`status`) values ("'.$memberid.'","'.$commid.'",CURRENT_TIMESTAMP,"1")');
		
		$postid = uniqid();
					
		$query1  = $this-> db -> query('insert into ceat_posts (`postid`,`commid`,`memberid`,`time`,`type`) values ("'.$postid.'","'.$commid.'","'.$memberid.'",CURRENT_TIMESTAMP,"join")');
		
	}
	
	public function UnjoinCommunity($memberid,$commid) {		
					
		$query  = $this-> db -> query('update ceat_comm_members set unjoinedtime=CURRENT_TIMESTAMP, status="0" where memberid="'.$memberid.'" and commid="'.$commid.'" and status="1"');
		
		$postid = uniqid();
					
		$query1  = $this-> db -> query('insert into ceat_posts (`postid`,`commid`,`memberid`,`time`,`type`) values ("'.$postid.'","'.$commid.'","'.$memberid.'",CURRENT_TIMESTAMP,"unjoin")');
		
	}
	
	public function CreateNewPost($memberid,$commid,$posttext) {		
		
		$postid = uniqid();
					
		$query  = $this-> db -> query('insert into ceat_posts (`postid`,`commid`,`memberid`,`time`,`type`,`content`) values ("'.$postid.'","'.$commid.'","'.$memberid.'",CURRENT_TIMESTAMP,"post","'.$posttext.'")');
		
	}
	
	public function DeletePost($curuser,$postid) {		
		
		$query  = $this-> db -> query('select memberid,commid from ceat_posts where postid="'.$postid.'"');
		$row = $query->result_array();
		$memberid = $row[0]['memberid'];
		$commid = $row[0]['commid'];
		
		$query1 = $this-> db -> query('select adminid from ceat_communities where commid="'.$commid.'"');
		$row1 = $query1->result_array();
		$adminid = $row1[0]['adminid'];
		
		if($memberid==$curuser || $adminid==$curuser){
			$query2 = $this-> db -> query('delete from ceat_posts where postid="'.$postid.'"');
		}
		
	}
	
	public function GetCommunityActivity($commid,$curuser) {
       	   		    
		$ret = "";
		
       	$query = $this-> db -> query('select postid,memberid,time,type,content from ceat_posts where commid="'.$commid.'" ORDER BY time DESC');
       	$row = $query->result_array();
		if($row) {
			$ret = '<ul id="activities">';
			
			for( $j = 0; $j < count($row);$j++) {
				
				$memberid = $row[$j]['memberid'];
				$query2 = $this-> db -> query('select name,profileimg from ceat_users where memberid="'.$memberid.'"');
				$row2 = $query2->result_array();
				$membername = $row2[0]['name'];	
				$memberimg = $row2[0]['profileimg'];				
				
				$postid = $row[$j]['postid'];
				$type = $row[$j]['type'];
				$timeStamp = $row[$j]['time'];
				$adate = date( "d/m/Y", strtotime($timeStamp));
				$atime = date( "H:i", strtotime($timeStamp));
				
				$query3 = $this-> db -> query('select adminid from ceat_communities where commid="'.$commid.'"');
				$row3 = $query3->result_array();
				$adminid = $row3[0]['adminid'];		
				
				if($memberid==$curuser || $adminid==$curuser){
					$delpost = '<span1 id="'.$postid.'" class="delpost" style="cursor:pointer; margin-right:0;">x</span1>';
				}else{
					$delpost = "";
				}
				
				if($type == "create"){
					$ret .= '<li class="actli" style="margin:0px 10px;"><a href="memberpage?id='.$memberid.'"><img class="postprofileimg" width="35" src="'.base_url().'docs/profile/'.$memberimg.'"></a><p style="margin:5px 10px;"><a href="memberpage?id='.$memberid.'"><font>'.$membername.'</font></a> created the community<span> - '.$adate.' '.$atime.'</span></p></li>' ;
				}
				
				if($type == "join"){
					$ret .= '<li class="actli" style="margin:0px 10px;"><a href="memberpage?id='.$memberid.'"><img class="postprofileimg" width="35" src="'.base_url().'docs/profile/'.$memberimg.'"></a><p style="margin:5px 10px;"><a href="memberpage?id='.$memberid.'"><font>'.$membername.'</font></a> joined the community<span> - '.$adate.' '.$atime.'</span></p></li>' ;
				}
				
				if($type == "unjoin"){
					$ret .= '<li class="actli" style="margin:0px 10px;"><a href="memberpage?id='.$memberid.'"><img class="postprofileimg" width="35" src="'.base_url().'docs/profile/'.$memberimg.'"></a><p style="margin:5px 10px;"><a href="memberpage?id='.$memberid.'"><font>'.$membername.'</font></a> left the community<span> - '.$adate.' '.$atime.'</span></p></li>' ;
				}
				
				if($type == "post"){
					$content = $row[$j]['content'];
					$ret .= '<li class="postli" style="margin:10px 10px 0;"><a href="memberpage?id='.$memberid.'"><img class="postprofileimg" width="35" src="'.base_url().'docs/profile/'.$memberimg.'"></a><p><a href="memberpage?id='.$memberid.'"><font>'.$membername.'</font></a> '.$content.'<span> - '.$adate.' '.$atime.'</span>'.$delpost.'</p></li>' ;
				}
				
			}
			
			$ret .= '</ul>';
		}
		
		return $ret;
    }
	
    public function GetJoinedCommunities($memberid) {
       	   		    
		$ret = "";
       	$query = $this-> db -> query('select commid,joinedtime from ceat_comm_members where memberid="'.$memberid.'" and status="1"');
       	$row = $query->result_array();
		if($row) {
			$ret = '<ul style="margin-top: 15px; list-style:none;">';
			
			for( $j = 0; $j < count($row);$j++) {
				
				$commid = $row[$j]['commid'];
				$query2 = $this-> db -> query('select name,profileimg,description,adminid,adminname,creationtime from ceat_communities where commid="'.$commid.'"');
				$row2 = $query2->result_array();
				if($row2)
				{
					$commname = $row2[0]['name'];
					$ret .= '<li id="'.$commid.'" class="commlist">'.$commname.'</li>';
				}
			}
			
			$ret .= '</ul>';
		}
		
		return $ret;
    }
	
	public function GetOtherCommunities($memberid) {
       	   		    
		$ret = "";
       	$query = $this-> db -> query('select commid,name,profileimg,description,adminid,adminname,creationtime from ceat_communities');
       	$row = $query->result_array();
		if($row) {
			$ret = '<ul style="margin-top: 15px; list-style:none;">';
			
			for( $j = 0; $j < count($row);$j++) {
				
				$commid = $row[$j]['commid'];
				$commname = $row[$j]['name'];
				$query2 = $this-> db -> query('select memberid from ceat_comm_members where commid="'.$commid.'" and memberid="'.$memberid.'" and status="1"');
				$row2 = $query2->result_array();
				if(!$row2) {
					$ret .= '<li id="'.$commid.'" class="commlist">'.$commname.'</li>';
				}
				
			}
			
			$ret .= '</ul>';
		}
		
		return $ret;
    }
	
	public function GetAdminRecentActivity($commid,$curuser) {
       	   		    
		$ret = "";
		
       	$query = $this-> db -> query('select postid,memberid,time,type,content from ceat_posts where commid="'.$commid.'" ORDER BY time DESC');
       	$row = $query->result_array();
		if($row) {
			$ret = '<ul id="activities">';
			
			$count = count($row);
			if($count>=5){
				$count = "5";
			}
			
			for( $j = 0; $j < $count;$j++) {
				
				$memberid = $row[$j]['memberid'];
				$query2 = $this-> db -> query('select name,profileimg from ceat_users where memberid="'.$memberid.'"');
				$row2 = $query2->result_array();
				$membername = $row2[0]['name'];	
				$memberimg = $row2[0]['profileimg'];			
				
				$postid = $row[$j]['postid'];
				$type = $row[$j]['type'];
				$timeStamp = $row[$j]['time'];
				$adate = date( "d/m/Y", strtotime($timeStamp));
				$atime = date( "H:i", strtotime($timeStamp));
				
				$query3 = $this-> db -> query('select adminid from ceat_communities where commid="'.$commid.'"');
				$row3 = $query3->result_array();
				$adminid = $row3[0]['adminid'];		
				
				if($memberid==$curuser || $adminid==$curuser){
					$delpost = '<span1 id="'.$postid.'" class="delpost" style="cursor:pointer; margin-right:0;">x</span1>';
				}else{
					$delpost = "";
				}
				
				if($type == "create"){
					$ret .= '<li class="actli" style="margin:0px 10px;"><a href="memberpage?id='.$memberid.'"><img class="postprofileimg" width="35" src="'.base_url().'docs/profile/'.$memberimg.'"></a><p style="margin:5px 10px;"><a href="memberpage?id='.$memberid.'"><font>'.$membername.'</font></a> created the community<span> - '.$adate.' '.$atime.'</span></p></li>' ;
				}
				
				if($type == "join"){
					$ret .= '<li class="actli" style="margin:0px 10px;"><a href="memberpage?id='.$memberid.'"><img class="postprofileimg" width="35" src="'.base_url().'docs/profile/'.$memberimg.'"></a><p style="margin:5px 10px;"><a href="memberpage?id='.$memberid.'"><font>'.$membername.'</font></a> joined the community<span> - '.$adate.' '.$atime.'</span></p></li>' ;
				}
				
				if($type == "unjoin"){
					$ret .= '<li class="actli" style="margin:0px 10px;"><a href="memberpage?id='.$memberid.'"><img class="postprofileimg" width="35" src="'.base_url().'docs/profile/'.$memberimg.'"></a><p style="margin:5px 10px;"><a href="memberpage?id='.$memberid.'"><font>'.$membername.'</font></a> left the community<span> - '.$adate.' '.$atime.'</span></p></li>' ;
				} 
				
				if($type == "post"){
					$content = $row[$j]['content'];
					$ret .= '<li class="postli" style="margin:10px 10px 0;"><a href="memberpage?id='.$memberid.'"><img class="postprofileimg" width="35" src="'.base_url().'docs/profile/'.$memberimg.'"></a><p><a href="memberpage?id='.$memberid.'"><font>'.$membername.'</font></a> '.$content.'<span> - '.$adate.' '.$atime.'</span>'.$delpost.'</p></li>' ;
				}
				
			}
			
			$ret .= '</ul>';
		}
		
		return $ret;
    }
	
	public function GetMemberRecentActivity($curuser) {
       	   		    
		$ret = "";
				
       	$query = $this-> db -> query('select commid,postid,memberid,time,type,content from ceat_posts where commid IN (select commid from ceat_comm_members where memberid="'.$curuser.'" and status="1") ORDER BY time DESC');
       	$row = $query->result_array();
		if($row) {
			$ret = '<ul id="activities">';
			
			$count = count($row);
			if($count>=5){
				$count = "5";
			}
			
			for( $j = 0; $j < $count;$j++) {
				
				$memberid = $row[$j]['memberid'];
				$query2 = $this-> db -> query('select name,profileimg from ceat_users where memberid="'.$memberid.'"');
				$row2 = $query2->result_array();
				$membername = $row2[0]['name'];	
				$memberimg = $row2[0]['profileimg'];					
				
				$commid = $row[$j]['commid'];
				$postid = $row[$j]['postid'];
				$type = $row[$j]['type'];
				$timeStamp = $row[$j]['time'];
				$adate = date( "d/m/Y", strtotime($timeStamp));
				$atime = date( "H:i", strtotime($timeStamp));
				
				$query3 = $this-> db -> query('select adminid from ceat_communities where commid="'.$commid.'"');
				$row3 = $query3->result_array();
				$adminid = $row3[0]['adminid'];	
				
				$query4 = $this-> db -> query('select name from ceat_communities where commid="'.$commid.'"');
				$row4 = $query4->result_array();
				$commname = $row4[0]['name'];	
				
				if($memberid==$curuser || $adminid==$curuser){
					$delpost = '<span1 id="'.$postid.'" class="delpost" style="cursor:pointer; margin-right:0;">x</span1>';
				}else{
					$delpost = "";
				}
				
				if($type == "create"){
					$ret .= '<li class="actli" style="margin:0px 10px;"><a href="memberpage?id='.$memberid.'"><img class="postprofileimg" width="35" src="'.base_url().'docs/profile/'.$memberimg.'"></a><p style="margin:5px 10px;"><a href="memberpage?id='.$memberid.'"><font>'.$membername.'</font></a> created the community<br><a href="communitypage?id='.$commid.'"><font style="background:url('.$this->config->item('web_url').'images/group-icon.png) no-repeat; padding-left:20px; color:#1977A6; font-weight:bold;">'.$commname.'</font></a><span> - '.$adate.' '.$atime.'</span></p></li>' ;
				}
				
				if($type == "join"){
					$ret .= '<li class="actli" style="margin:0px 10px;"><a href="memberpage?id='.$memberid.'"><img class="postprofileimg" width="35" src="'.base_url().'docs/profile/'.$memberimg.'"></a><p style="margin:5px 10px;"><a href="memberpage?id='.$memberid.'"><font>'.$membername.'</font></a> joined the community<br><a href="communitypage?id='.$commid.'"><font style="background:url('.$this->config->item('web_url').'images/group-icon.png) no-repeat; padding-left:20px; color:#1977A6; font-weight:bold;">'.$commname.'</font></a><span> - '.$adate.' '.$atime.'</span></p></li>' ;
				}
				
				if($type == "unjoin"){
					$ret .= '<li class="actli" style="margin:0px 10px;"><a href="memberpage?id='.$memberid.'"><img class="postprofileimg" width="35" src="'.base_url().'docs/profile/'.$memberimg.'"></a><p style="margin:5px 10px;"><a href="memberpage?id='.$memberid.'"><font>'.$membername.'</font></a> left the community<br><a href="communitypage?id='.$commid.'"><font style="background:url('.$this->config->item('web_url').'images/group-icon.png) no-repeat; padding-left:20px; color:#1977A6; font-weight:bold;">'.$commname.'</font></a><span> - '.$adate.' '.$atime.'</span></p></li>' ;
				} 
				
				if($type == "post"){
					$content = $row[$j]['content'];
					$ret .= '<li class="postli" style="margin:10px 10px 0;"><a href="memberpage?id='.$memberid.'"><img class="postprofileimg" width="35" src="'.base_url().'docs/profile/'.$memberimg.'"></a><p><a href="memberpage?id='.$memberid.'"><font>'.$membername.'</font></a> '.$content.'<br><a href="communitypage?id='.$commid.'"><font style="background:url('.$this->config->item('web_url').'images/group-icon.png) no-repeat; padding-left:20px; color:#1977A6; font-weight:bold;">'.$commname.'</font></a><span> - '.$adate.' '.$atime.'</span>'.$delpost.'</p></li>' ;
				}
				
			}
			
			$ret .= '</ul>';
		}
		
		
		
		return $ret;
    }

	    
   
  }
?>

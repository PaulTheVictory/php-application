<?php

class Findspecialist_Model extends CI_Model {
        
    public function __construct() {
        
       
  
    }
	
	public function GetAllMembers() {
       	
		$arr = Array();
				    
       	$query = $this-> db -> query('select memberid,name from ceat_users ORDER BY name ASC');
       	$row = $query->result_array();
		$arr['member_count'] = count($row);
		
		if($row) {
			
			$arr['member_list'] = '<div id="memList-nav"></div><ul id="memList" style="margin-top: 15px; list-style:none;">';
						
			for( $j = 0; $j < count($row);$j++) {
				
				$memberid = $row[$j]['memberid'];
				$membername = $row[$j]['name'];								
				
				$arr['member_list'] .= '<li class="memberlist" id="'.$memberid.'">'.$membername.'</li>';
				
			}
			
			$arr['member_list'] .= '</ul>';
		}
		
		
		return $arr;
    }
	
	public function GetMemberName($memberid) {
       	
		$arr = Array();
		$arr['name'] = "";
				    
       	$query = $this-> db -> query('select name,userid,role,profileimg,dateofjoin from ceat_users where memberid="'.$memberid.'"');
       	$row = $query->result_array();
		if($row){
			$arr['name'] = $row[0]['name'];
			$arr['userid'] = $row[0]['userid'];
			$arr['role'] = $row[0]['role'];
			$arr['profileimg'] = $row[0]['profileimg'];
			$arr['doj'] = $row[0]['dateofjoin'];
		}
		return $arr;
    }
	
	public function GetMemberProfile($memberid) {
		
		$arr = Array();
       	   		    
       	$query = $this-> db -> query('select mobile,phone,email,address,contactaddress,contactstate,contactpin,clinicaddress,clinicphone,designation,qualification,college,dob,gender,about,interests from ceat_profiles where memberid="'.$memberid.'"');
       	$row = $query->result_array();
		if($row){
			$arr['mobile'] = $row[0]['mobile'];
			$arr['phone'] = $row[0]['phone'];
			$arr['email'] = $row[0]['email'];
			$arr['clinicaddress'] = $row[0]['clinicaddress'];
			$arr['clinicphone'] = $row[0]['clinicphone'];
			$arr['designation'] = $row[0]['designation'];
			$arr['qualification'] = $row[0]['qualification'];
			$arr['college'] = $row[0]['college'];
			$arr['dob'] = $row[0]['dob'];
			$arr['gender'] = $row[0]['gender'];
			$arr['about'] = $row[0]['about'];
			$arr['interests'] = $row[0]['interests'];
		
			$arr['interests'] = explode("&|&", $arr['interests']);
		
			$arr['address'] = $row[0]['address'];
			$arr['contactaddress'] = $row[0]['contactaddress'];
			$arr['contactstate'] = $row[0]['contactstate'];
			$arr['contactpin'] = $row[0]['contactpin'];
		}
		return $arr;
    }
	
	public function GetSpecialists($findbyname,$findbyarea) {
       	
		$arr = Array();
		$arr['list'] = '';
		
		if($findbyname!="" && $findbyarea==""){ //Search by Name
			
			$query = $this-> db -> query('select memberid,name from ceat_users where search="1" and name LIKE "%'.$findbyname.'%"');
       		$row = $query->result_array();
			if($row){
				
				for( $j = 0; $j < count($row);$j++) {
					
					$memid = $row[$j]['memberid'];
					$memname = $row[$j]['name'];
					$query2 = $this-> db -> query('select mobile,address,contactaddress from ceat_profiles where memberid="'.$memid.'"');
       				$row2 = $query2->result_array();
					
					$mobile = $row2[0]['mobile'];
					$addressraw = $row2[0]['address'];
					$contactaddressraw = $row2[0]['contactaddress'];
					if($contactaddressraw==""){
						$address = $addressraw;
					}else{
						$address = $contactaddressraw;
					}
					
					$arr['list'] .= '<tr><td>'.$memname.'</td><td>'.$mobile.'</td><td>'.$address.'</td><td class="findview" id="'.$memid.'">View</td></tr>';
					
				}			
				
			}
									
		}
		//---------------------------------------
		elseif($findbyarea!="" && $findbyname==""){ //Search by Area
		
			$query = $this-> db -> query('select memberid from ceat_users where search="1"');
       		$row = $query->result_array();
			if($row){
			for( $j = 0; $j < count($row);$j++) {
				
				$memid = $row[$j]['memberid'];					
				$query1 = $this-> db -> query('select contactaddress from ceat_profiles where memberid="'.$memid.'"');
       			$row1 = $query1->result_array();							
							
				$contactaddressraw = $row1[0]['contactaddress'];
				if($contactaddressraw==""){
					
					$query2 = $this-> db -> query('select mobile,address from ceat_profiles where memberid="'.$memid.'" and address LIKE "%'.$findbyarea.'%"');
       				$row2 = $query2->result_array();
					if($row2){						
						$mobile = $row2[0]['mobile'];
						$address = $row2[0]['address'];
						$query21 = $this-> db -> query('select name from ceat_users where memberid="'.$memid.'"');
       					$row21 = $query21->result_array();
						$memname = $row21[0]['name'];
						$arr['list'] .= '<tr><td>'.$memname.'</td><td>'.$mobile.'</td><td>'.$address.'</td><td class="findview" id="'.$memid.'">View</td></tr>';	
					}
					
				}else{
					
					$query3 = $this-> db -> query('select memberid,mobile,contactaddress from ceat_profiles where memberid="'.$memid.'" and contactaddress LIKE "%'.$findbyarea.'%"');
       				$row3 = $query3->result_array();
					if($row3){
						$mobile = $row3[0]['mobile'];
						$address = $row3[0]['contactaddress'];
						$query31 = $this-> db -> query('select name from ceat_users where memberid="'.$memid.'"');
       					$row31 = $query31->result_array();
						$memname = $row31[0]['name'];
						$arr['list'] .= '<tr><td>'.$memname.'</td><td>'.$mobile.'</td><td>'.$address.'</td><td class="findview" id="'.$memid.'">View</td></tr>';	
					}
					
				}			
				
			}
			}
			
		}
		//---------------------------------------
		elseif($findbyname!="" && $findbyarea!=""){ //Search by Name & Area
			
			$query = $this-> db -> query('select memberid,name from ceat_users where search="1" and name LIKE "%'.$findbyname.'%"');
       		$row = $query->result_array();
			if($row){
				
				for( $j = 0; $j < count($row);$j++) {
					
					$memid = $row[$j]['memberid'];
					$memname = $row[$j]['name'];
					$query2 = $this-> db -> query('select contactaddress from ceat_profiles where memberid="'.$memid.'"');
       				$row2 = $query2->result_array();
					$contactaddressraw = $row2[0]['contactaddress'];
					
					if($contactaddressraw==""){
					
						$query3 = $this-> db -> query('select mobile,address from ceat_profiles where memberid="'.$memid.'" and address LIKE "%'.$findbyarea.'%"');
       					$row3 = $query3->result_array();
						if($row3){
							$mobile = $row3[0]['mobile'];
							$address = $row3[0]['address'];
							$arr['list'] .= '<tr><td>'.$memname.'</td><td>'.$mobile.'</td><td>'.$address.'</td><td class="findview" id="'.$memid.'">View</td></tr>';							
						}
					
					}else{
					
						$query4 = $this-> db -> query('select mobile,contactaddress from ceat_profiles where memberid="'.$memid.'" and contactaddress LIKE "%'.$findbyarea.'%"');
       					$row4 = $query4->result_array();
						if($row4){
							$mobile = $row4[0]['mobile'];
							$address = $row4[0]['contactaddress'];
							$arr['list'] .= '<tr><td>'.$memname.'</td><td>'.$mobile.'</td><td>'.$address.'</td><td class="findview" id="'.$memid.'">View</td></tr>';							
						}
					}
					
				}
								
			}
									
		}
		//---------------------------------------
			if($arr['list']==""){	
			
				$arr['list'] .= '<tr><td class="finderror" colspan="4">There is no match found...</td></tr>';
			}
		
		return $arr;
		
    }
	
	
	    
   
  }
?>

<?php

class Connections_Model extends CI_Model {
        
    public function __construct() {
        
       
  
    }
	
	
	public function GetIsConnected($login_memberid,$memberid) {
		
		$status = "";
		$connectionsarr = Array();
		$inrequestsarr = Array();
		$outrequestsarr = Array();
		
		$query = $this-> db -> query('select connections,requestin,requestout from ceat_connections where memberid="'.$login_memberid.'"');
       	$row = $query->result_array();
		if($row){
		  	$connectionsarr = explode("|", $row[0]['connections']); 
			$inrequestsarr = explode("|", $row[0]['requestin']); 
			$outrequestsarr = explode("|", $row[0]['requestout']);
		}
		if(in_array($memberid, $connectionsarr)) {
			$status = "Connected";
			return $status;
		}
		
		if(in_array($memberid, $inrequestsarr)) {
			$status = "Request Received";
			return $status;
		}
		
		if(in_array($memberid, $outrequestsarr)) {
			$status = "Request Sent";
			return $status;
		}
		 
		
		return $status;
	}
	
	public function GetIsAdmin($commid,$memberid) {
		
		$arr = Array();
		
		$query = $this-> db -> query('select name from ceat_communities where commid="'.$commid.'" and adminid="'.$memberid.'"');
       	$row = $query->result_array();
		if($row) {
			$arr['admin'] = "1";
			$arr['name'] = $row[0]['name'];
		}else{
			$arr['admin'] = "0";
		}
		return $arr;
	}
	
	public function SendConnectionRequest($login_memberid,$memberid) {	
	
		$query = $this-> db -> query('select requestin from ceat_connections where memberid="'.$memberid.'"');
       	$row = $query->result_array();	
		$inrequests = $row[0]['requestin'];
		$inrequestsarr = explode("|", $inrequests); 
		if(!in_array($login_memberid, $inrequestsarr)) {
			if($inrequests == ""){
				$inrequestsupd = $login_memberid . "|";
			}else{
				$inrequestsupd = $inrequests . $login_memberid . "|";
			}
			
		}else{
			$inrequestsupd = $inrequests;
		}
				
		$query1  = $this-> db -> query('update ceat_connections set requestin="'.$inrequestsupd.'" where memberid="'.$memberid.'"');
		
		$query2 = $this-> db -> query('select requestout from ceat_connections where memberid="'.$login_memberid.'"');
       	$row2 = $query2->result_array();	
		$outrequests = $row2[0]['requestout'];
		$outrequestsarr = explode("|", $outrequests); 
		if(!in_array($memberid, $outrequestsarr)) {
			if($outrequests == ""){
				$outrequestsupd = $memberid . "|";
			}else{
				$outrequestsupd = $outrequests . $memberid . "|";
			}
			
		}else{
			$outrequestsupd = $outrequests;
		}
				
		$query3  = $this-> db -> query('update ceat_connections set requestout="'.$outrequestsupd.'" where memberid="'.$login_memberid.'"');
		
	}
	
	public function CancelSentRequest($login_memberid,$memberid) {	
	
		$query = $this-> db -> query('select requestin from ceat_connections where memberid="'.$memberid.'"');
       	$row = $query->result_array();	
		$inrequests = $row[0]['requestin'];
		
		$inrequestsupd = $inrequests;
		$searchFOr = $login_memberid.'|';
        $replacewith = '';
        $inrequestsupd = str_replace($searchFOr, $replacewith, $inrequestsupd);                   
		
		$query1  = $this-> db -> query('update ceat_connections set requestin="'.$inrequestsupd.'" where memberid="'.$memberid.'"');
		
		$query2 = $this-> db -> query('select requestout from ceat_connections where memberid="'.$login_memberid.'"');
       	$row2 = $query2->result_array();	
		$outrequests = $row2[0]['requestout'];
		
		$outrequestsupd = $outrequests;
		$searchFOr = $memberid.'|';
        $replacewith = '';
        $outrequestsupd = str_replace($searchFOr, $replacewith, $outrequestsupd); 
		
		$query3  = $this-> db -> query('update ceat_connections set requestout="'.$outrequestsupd.'" where memberid="'.$login_memberid.'"');
		
	}
	
	public function CancelReceivedRequest($login_memberid,$memberid) {	
	
		$query = $this-> db -> query('select requestin from ceat_connections where memberid="'.$login_memberid.'"');
       	$row = $query->result_array();	
		$inrequests = $row[0]['requestin'];
		
		$inrequestsupd = $inrequests;
		$searchFOr = $memberid.'|';
        $replacewith = '';
        $inrequestsupd = str_replace($searchFOr, $replacewith, $inrequestsupd);                   
		
		$query1  = $this-> db -> query('update ceat_connections set requestin="'.$inrequestsupd.'" where memberid="'.$login_memberid.'"');
		
		$query2 = $this-> db -> query('select requestout from ceat_connections where memberid="'.$memberid.'"');
       	$row2 = $query2->result_array();	
		$outrequests = $row2[0]['requestout'];
		
		$outrequestsupd = $outrequests;
		$searchFOr = $login_memberid.'|';
        $replacewith = '';
        $outrequestsupd = str_replace($searchFOr, $replacewith, $outrequestsupd); 
		
		$query3  = $this-> db -> query('update ceat_connections set requestout="'.$outrequestsupd.'" where memberid="'.$memberid.'"');
		
	}
	
	public function AcceptReceivedRequest($login_memberid,$memberid) {	
	
		$query = $this-> db -> query('select requestin,connections from ceat_connections where memberid="'.$login_memberid.'"');
       	$row = $query->result_array();	
		$inrequests = $row[0]['requestin'];
		$connections1 = $row[0]['connections'];
		
		$connections1arr = explode("|", $connections1); 
		if(!in_array($memberid, $connections1arr)) {
			if($connections1 == ""){
				$connectionsupd1 = $memberid . "|";
			}else{
				$connectionsupd1 = $connections1 . $memberid . "|";
			}
			
		}else{
			$connectionsupd1 = $connections1;
		}
		
		$inrequestsupd = $inrequests;
		$searchFOr = $memberid.'|';
        $replacewith = '';
        $inrequestsupd = str_replace($searchFOr, $replacewith, $inrequestsupd);                   
		
		$query1  = $this-> db -> query('update ceat_connections set requestin="'.$inrequestsupd.'", connections="'.$connectionsupd1.'" where memberid="'.$login_memberid.'"');
		
		$query2 = $this-> db -> query('select requestout,connections from ceat_connections where memberid="'.$memberid.'"');
       	$row2 = $query2->result_array();	
		$outrequests = $row2[0]['requestout'];
		$connections2 = $row2[0]['connections'];
		
		$connections2arr = explode("|", $connections2); 
		if(!in_array($login_memberid, $connections2arr)) {
			if($connections2 == ""){
				$connectionsupd2 = $login_memberid . "|";
			}else{
				$connectionsupd2 = $connections2 . $login_memberid . "|";
			}
			
		}else{
			$connectionsupd2 = $connections2;
		}
		
		$outrequestsupd = $outrequests;
		$searchFOr = $login_memberid.'|';
        $replacewith = '';
        $outrequestsupd = str_replace($searchFOr, $replacewith, $outrequestsupd); 
		
		$query3  = $this-> db -> query('update ceat_connections set requestout="'.$outrequestsupd.'", connections="'.$connectionsupd2.'" where memberid="'.$memberid.'"');
		
	}
	
	public function RemoveConnection($login_memberid,$memberid) {	
	
		$query = $this-> db -> query('select connections from ceat_connections where memberid="'.$login_memberid.'"');
       	$row = $query->result_array();	
		$connections1 = $row[0]['connections'];
		
		$connections1upd = $connections1;
		$searchFOr = $memberid.'|';
        $replacewith = '';
        $connections1upd = str_replace($searchFOr, $replacewith, $connections1upd);                   
		
		$query1  = $this-> db -> query('update ceat_connections set connections="'.$connections1upd.'" where memberid="'.$login_memberid.'"');
		
		$query2 = $this-> db -> query('select connections from ceat_connections where memberid="'.$memberid.'"');
       	$row2 = $query2->result_array();	
		$connections2 = $row2[0]['connections'];
		
		$connections2upd = $connections2;
		$searchFOr = $login_memberid.'|';
        $replacewith = '';
        $connections2upd = str_replace($searchFOr, $replacewith, $connections2upd); 
		
		$query3  = $this-> db -> query('update ceat_connections set connections="'.$connections2upd.'" where memberid="'.$memberid.'"');
		
	}
	
	public function GetConnectedMembers($memberid) {
       	   		    
		$ret = "";
       	$query = $this-> db -> query('select connections from ceat_connections where memberid="'.$memberid.'"');
       	$row = $query->result_array();
		if($row) {
		$connections = $row[0]['connections'];
		if($connections!=""){	
			$connections = substr($connections,0,-1);
			$connectionsarr = explode("|", $connections); 
			$ret = '<ul style="margin-top: 15px; list-style:none;">';
			
			for( $i = 0; $i < count($connectionsarr);$i++) {
				
				$connid = $connectionsarr[$i];
				$query2 = $this-> db -> query('select name,profileimg from ceat_users where memberid="'.$connid.'"');
				$row2 = $query2->result_array();
				$connname = $row2[0]['name'];
				
				$ret .= '<li id="'.$connid.'" class="connlist">'.$connname.'</li>';
			}
			
			$ret .= '</ul>';
		}
		}
		
		return $ret;
    }
	
	public function GetReceivedRequests($memberid) {
       	   		    
		$ret = "";
       	$query = $this-> db -> query('select requestin from ceat_connections where memberid="'.$memberid.'"');
       	$row = $query->result_array();
		if($row) {
		$connections = $row[0]['requestin'];
		if($connections!=""){	
			$connections = substr($connections,0,-1);
			$connectionsarr = explode("|", $connections); 
			$ret = '<ul style="margin-top: 15px; list-style:none;">';
			
			for( $i = 0; $i < count($connectionsarr);$i++) {
				
				$connid = $connectionsarr[$i];
				$query2 = $this-> db -> query('select name,profileimg from ceat_users where memberid="'.$connid.'"');
				$row2 = $query2->result_array();
				$connname = $row2[0]['name'];
				
				$ret .= '<li id="'.$connid.'" class="connlist">'.$connname.'</li>';
			}
			
			$ret .= '</ul>';
		}
		}
		
		return $ret;
    }
	
	public function GetSentRequests($memberid) {
       	   		    
		$ret = "";
       	$query = $this-> db -> query('select requestout from ceat_connections where memberid="'.$memberid.'"');
       	$row = $query->result_array();
		if($row) {
		$connections = $row[0]['requestout'];
		if($connections!=""){	
			$connections = substr($connections,0,-1);
			$connectionsarr = explode("|", $connections); 
			$ret = '<ul style="margin-top: 15px; list-style:none;">';
			
			for( $i = 0; $i < count($connectionsarr);$i++) {
				
				$connid = $connectionsarr[$i];
				$query2 = $this-> db -> query('select name,profileimg from ceat_users where memberid="'.$connid.'"');
				$row2 = $query2->result_array();
				$connname = $row2[0]['name'];
				
				$ret .= '<li id="'.$connid.'" class="connlist">'.$connname.'</li>';
			}
			
			$ret .= '</ul>';
		}
		}
		
		return $ret;
    }
	
	public function GetRequestsForRecentActivity($memberid) {
       	   		    
		$ret = "";
       	$query = $this-> db -> query('select requestin from ceat_connections where memberid="'.$memberid.'"');
       	$row = $query->result_array();
		if($row) {
		$connections = $row[0]['requestin'];
		if($connections!=""){	
			$connections = substr($connections,0,-1);
			$connectionsarr = explode("|", $connections); 
			$ret = '<p class="postli"><img width="35" src="'.$this->config->item('web_url').'images/connections.jpg" class="postprofileimg" style="margin: 3px 5px 0;">You have received new Connection Request(s)<br/>';
			
			for( $i = 0; $i < count($connectionsarr);$i++) {
				
				$connid = $connectionsarr[$i];
				$query2 = $this-> db -> query('select name,profileimg from ceat_users where memberid="'.$connid.'"');
				$row2 = $query2->result_array();
				$connname = $row2[0]['name'];
				
				if($i==count($connectionsarr)-1){
					$ret .= '<a style="color: #1977A6; font-size:12px;" href="memberpage?id='.$connid.'">'.$connname.'</a>';
				}else{
					$ret .= '<a style="color: #1977A6; font-size:12px;" href="memberpage?id='.$connid.'">'.$connname.'</a>, ';
				}
			}
			
			$ret .= '</p>';
		}
		}
		
		return $ret;
    }
	
	
	public function GetConnectionsForCompose($memberid) {
       	   		    
		$ret = "";
       	$query = $this-> db -> query('select connections from ceat_connections where memberid="'.$memberid.'"');
       	$row = $query->result_array();
		if($row) {
		$connections = $row[0]['connections'];
		if($connections!=""){	
			$connections = substr($connections,0,-1);
			$connectionsarr = explode("|", $connections); 
						
			for( $i = 0; $i < count($connectionsarr);$i++) {
				
				$connid = $connectionsarr[$i];
				$query2 = $this-> db -> query('select name,profileimg from ceat_users where memberid="'.$connid.'"');
				$row2 = $query2->result_array();
				$connname = $row2[0]['name'];
				
				$ret .= '<option class="'.$connid.'">'.$connname.'</option>';
			}
		}
		}
		
		return $ret;
    }

	public function SendNewMessage($fromid,$fromname,$tonamesarr,$toids,$subject,$message) {
		
		$messageid = uniqid();
		
		$tonames = implode(", ", $tonamesarr);
		
		$subject = htmlspecialchars($subject);
		$message = htmlspecialchars($message);
		
		/*insert message*/		
		$query = $this-> db -> query('insert into ceat_messages (`messageid`,`from`,`fromname`,`to`,`toname`,`subject`,`message`,`date`) values ("'.$messageid.'","'.$fromid.'","'.$fromname.'","'.$toids.'","'.$tonames.'","'.$subject.'","'.$message.'",CURRENT_TIMESTAMP)');
		
		$conversationid = uniqid();
		
		/*create conversation*/
		$query1 = $this-> db -> query('insert into ceat_mess_conversations (`conversationid`,`messages`,`subject`) values ("'.$conversationid.'","'.$messageid.'|","'.$subject.'")');
		
		/*log for sender*/
		$query2 = $this-> db -> query('insert into ceat_mess_log (`memberid`,`conversationid`,`date`,`category`,`status`) values ("'.$fromid.'","'.$conversationid.'",CURRENT_TIMESTAMP,"out","unread")');
		
		$toids = substr($toids,0,-1);
		$toidsarr = explode("|",$toids);
		
		for($i=0;$i<count($toidsarr);$i++){
			if($toidsarr[$i]!=""){
				/*log for Receipients*/
		  		$query3 = $this-> db -> query('insert into ceat_mess_log (`memberid`,`conversationid`,`date`,`category`,`status`) values ("'.$toidsarr[$i].'","'.$conversationid.'",CURRENT_TIMESTAMP,"in","unread")');
			}
		}
		
	}
	
	public function GetInboxCount($memberid) {
		
		$arr['total'] = 0;
		$arr['unread'] = 0;
		$query = $this-> db -> query('select conversationid,status from ceat_mess_log where memberid="'.$memberid.'" and category="in" ORDER BY date DESC');
       	$row = $query->result_array();
		if($row) {			
			for($i=0;$i<count($row);$i++){				
				$status = $row[$i]['status'];
				if($status=="unread"){
					$arr['unread']++;
				}
			}
			$arr['total'] = count($row);
		}
		
		return $arr;
	}
	
	public function GetInboxList($memberid) {
       	   		    
		$ret = "<ul>";
       	$query = $this-> db -> query('select conversationid,date,status from ceat_mess_log where memberid="'.$memberid.'" and category="in" ORDER BY date DESC');
       	$row = $query->result_array();
		if($row) {			
			for($i=0;$i<count($row);$i++){
				$conversationid = $row[$i]['conversationid'];
				$date = $row[$i]['date'];
				$status = $row[$i]['status'];
				
				$temp = explode(" ",$date);
				$temp1 = explode("-",$temp[0]);
				$dateformat = $temp1[2]."/".$temp1[1]."/".$temp1[0];
				
				$query1 = $this-> db -> query('select messages from ceat_mess_conversations where conversationid="'.$conversationid.'"');
       			$row1 = $query1->result_array();
				$messages = $row1[0]['messages'];
				$messages = substr($messages,0,-1);
				$messagesarr = explode("|",$messages);
				$lastmessage = end($messagesarr);
				
				$query2 = $this-> db -> query('select fromname,subject from ceat_messages where messageid="'.$lastmessage.'"');
       			$row2 = $query2->result_array();
				$fromname = $row2[0]['fromname'];
				$subject = $row2[0]['subject'];
				
				$ret .='<li id="'.$conversationid.'" class="'.$status.'">'.$fromname.'<span>'.$dateformat.'</span><br /><font>'.$subject.'</font></li>';
			}			
		}
		else{
			$ret .='<li class="emptymessage">There is no message to display</li>';
		}
		
		$ret .= '</ul>';
		
		return $ret;
    }
	
	public function GetOutboxList($memberid) {
       	   		    
		$ret = "<ul>";
       	$query = $this-> db -> query('select conversationid,date,status from ceat_mess_log where memberid="'.$memberid.'" and category="out" ORDER BY date DESC');
       	$row = $query->result_array();
		if($row) {			
			for($i=0;$i<count($row);$i++){
				$conversationid = $row[$i]['conversationid'];
				$date = $row[$i]['date'];
				$status = $row[$i]['status'];
				
				$temp = explode(" ",$date);
				$temp1 = explode("-",$temp[0]);
				$dateformat = $temp1[2]."/".$temp1[1]."/".$temp1[0];
				
				$query1 = $this-> db -> query('select messages from ceat_mess_conversations where conversationid="'.$conversationid.'"');
       			$row1 = $query1->result_array();
				$messages = $row1[0]['messages'];
				$messages = substr($messages,0,-1);
				$messagesarr = explode("|",$messages);
				$lastmessage = end($messagesarr);
				
				$query2 = $this-> db -> query('select toname,subject from ceat_messages where messageid="'.$lastmessage.'"');
       			$row2 = $query2->result_array();
				$toname = $row2[0]['toname'];
				$subject = $row2[0]['subject'];
				
				$toname = (strlen($toname) > 21) ? substr($toname,0,20).'...' : $toname;
				
				$ret .='<li id="'.$conversationid.'" class="read">'.$toname.'<span>'.$dateformat.'</span><br /><font>'.$subject.'</font></li>';
			}			
		}
		else{
			$ret .='<li class="emptymessage">There is no message to display</li>';
		}
		
		$ret .= '</ul>';
		
		return $ret;
    }
	
	
	public function GetConversationDetails($conid,$memberid) {
       	   		    
		$ret = "";
		
		$queryyy  = $this-> db -> query('update ceat_mess_log set status="read" where memberid="'.$memberid.'" and conversationid="'.$conid.'"');
		
       	$query = $this-> db -> query('select messages,subject from ceat_mess_conversations where conversationid="'.$conid.'"');
       	$row = $query->result_array();
		if($row) {			
			$messages = $row[0]['messages'];	
			$messages = substr($messages,0,-1);
			$messagesarr = explode("|",$messages);	
			
			$ret .= '<h4><span class="delete-conversation" id="'.$conid.'">Delete Conversation</span><span class="reply-conversation" id="'.$conid.'">Reply All</span></h4><h3 id="con-subject">'.$row[0]['subject'].'</h3>';	
			
			for($i=0;$i<count($messagesarr);$i++){
				$query1 = $this-> db -> query('select * from ceat_messages where messageid="'.$messagesarr[$i].'"');
       			$row1 = $query1->result_array();
				
				$dateformat = date('D, d/m/Y H:i', strtotime($row1[0]['date']));
				$from = $row1[0]['from'];
				$to = $row1[0]['to'];
				$to = substr($to,0,-1);
				$toarr = explode("|",$to);
				
				if($from==$memberid || in_array($memberid, $toarr)){
				
					$ret .= '<li><div class="message-header"><span class="reply-message" id="'.$messagesarr[$i].'">Reply</span><strong>From:</strong> '.$row1[0]['fromname'].'<br /><strong>To:&nbsp;&nbsp;&nbsp;&nbsp;</strong> '.$row1[0]['toname'].'<br /><strong>Sent:</strong> '.$dateformat.'</div><p>'.$row1[0]['message'].'</p></li>';
					
				}
			}
		}
		
		$totalcount = 0;
		$unreadcount = 0;
		$query = $this-> db -> query('select conversationid,status from ceat_mess_log where memberid="'.$memberid.'" and category="in" ORDER BY date DESC');
       	$row = $query->result_array();
		if($row) {			
			for($i=0;$i<count($row);$i++){				
				$status = $row[$i]['status'];
				if($status=="unread"){
					$unreadcount++;
				}
			}
			$totalcount = count($row);
		}
		
		$result = array(0 => $ret, 1=> $totalcount, 2 =>$unreadcount);
				
		return $result;
    }
	
	public function DeleteConversation($conid,$memberid) {
       			
		$query  = $this-> db -> query('delete from ceat_mess_log where memberid="'.$memberid.'" and conversationid="'.$conid.'"');
		
    }
	
	public function GetReplyMembersForMessage($messageid,$memberid) {
       	   		    
		$ret = "";
       	$query = $this-> db -> query('select * from ceat_messages where messageid="'.$messageid.'"');
       	$row = $query->result_array();
		if($row) {
		$fromid = $row[0]['from'];
		$toid = $row[0]['to'];
			$replyids = $fromid."|".$toid;
			$replyids = substr($replyids,0,-1);
			$replyidsarr = explode("|", $replyids); 
						
			for( $i = 0; $i < count($replyidsarr);$i++) {
				
				$memid = $replyidsarr[$i];
				if($memid!=$memberid){
					$query2 = $this-> db -> query('select name,profileimg from ceat_users where memberid="'.$memid.'"');
					$row2 = $query2->result_array();
					$memname = $row2[0]['name'];
				
					$ret .= '<option selected="selected" class="'.$memid.'">'.$memname.'</option>';
				}
			}
		
		}
		
		return $ret;
    }
	
	public function GetReplyMembersForConversation($convid,$memberid) {
       	   		    
		$ret = "";
		$replyids = "";
		$query = $this-> db -> query('select messages from ceat_mess_conversations where conversationid="'.$convid.'"');
       	$row = $query->result_array();
		if($row) {			
			$messages = $row[0]['messages'];	
			$messages = substr($messages,0,-1);
			$messagesarr = explode("|",$messages);	
			
			for($i=0;$i<count($messagesarr);$i++){
				
				$query1 = $this-> db -> query('select * from ceat_messages where messageid="'.$messagesarr[$i].'"');
       			$row1 = $query1->result_array();
				if($row1) {
				$fromid = $row1[0]['from'];
				$toid = $row1[0]['to'];
					$replyids .= $fromid."|".$toid;					
				}
				
			}
			
			$replyids = substr($replyids,0,-1);
			$replyidsarr = explode("|", $replyids); 
			
			$replyidsarr = array_unique($replyidsarr);
			
			for( $j = 0; $j < count($replyidsarr);$j++) {
						
				$memid = $replyidsarr[$j];
				if($memid!=$memberid){
					$query2 = $this-> db -> query('select name,profileimg from ceat_users where memberid="'.$memid.'"');
					$row2 = $query2->result_array();
					$memname = $row2[0]['name'];
				
					$ret .= '<option selected="selected" class="'.$memid.'">'.$memname.'</option>';
				}
						
			}
			
		}
		
		return $ret;
    }
	
	public function ReplyMessage($fromid,$fromname,$tonamesarr,$toids,$subject,$message,$conversationid) {
		
		$messageid = uniqid();
		
		$tonames = implode(", ", $tonamesarr);
		
		$subject = htmlspecialchars($subject);
		$message = htmlspecialchars($message);
		
		/*insert message*/		
		$query = $this-> db -> query('insert into ceat_messages (`messageid`,`from`,`fromname`,`to`,`toname`,`subject`,`message`,`date`) values ("'.$messageid.'","'.$fromid.'","'.$fromname.'","'.$toids.'","'.$tonames.'","'.$subject.'","'.$message.'",CURRENT_TIMESTAMP)');
		
		/*update conversation*/
		$query1 = $this-> db -> query('select messages from ceat_mess_conversations where conversationid="'.$conversationid.'"');
		$row1 = $query1->result_array();
		$messages = $row1[0]['messages'];
		$messagesupdated = $messages.$messageid."|";		
		$query2 = $this-> db -> query('update ceat_mess_conversations set messages="'.$messagesupdated.'" where conversationid="'.$conversationid.'"');
		
		/*log for sender*/
		$query3 = $this-> db -> query('select date from ceat_mess_log where conversationid="'.$conversationid.'" and memberid="'.$fromid.'" and category="out"');
		$row3 = $query3->result_array();
		if($row3){
			$query4 = $this-> db -> query('update ceat_mess_log set date=CURRENT_TIMESTAMP, status="unread" where conversationid="'.$conversationid.'" and memberid="'.$fromid.'" and category="out"');
		}else{
			$query5 = $this-> db -> query('insert into ceat_mess_log (`memberid`,`conversationid`,`date`,`category`,`status`) values ("'.$fromid.'","'.$conversationid.'",CURRENT_TIMESTAMP,"out","unread")');
		}
		
		$toids = substr($toids,0,-1);
		$toidsarr = explode("|",$toids);
		
		for($i=0;$i<count($toidsarr);$i++){
			if($toidsarr[$i]!=""){
				/*log for Receipients*/
				$query6 = $this-> db -> query('select date from ceat_mess_log where conversationid="'.$conversationid.'" and memberid="'.$toidsarr[$i].'" and category="in"');
				$row6 = $query6->result_array();
				if($row6){
					$query7 = $this-> db -> query('update ceat_mess_log set date=CURRENT_TIMESTAMP, status="unread" where conversationid="'.$conversationid.'" and memberid="'.$toidsarr[$i].'" and category="in"');
				}else{
					$query8 = $this-> db -> query('insert into ceat_mess_log (`memberid`,`conversationid`,`date`,`category`,`status`) values ("'.$toidsarr[$i].'","'.$conversationid.'",CURRENT_TIMESTAMP,"in","unread")');
				}
		  		
			}
		}
		
		
	}
	    
   
  }
?>

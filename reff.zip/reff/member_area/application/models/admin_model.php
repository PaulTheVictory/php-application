<?php

class Admin_Model extends CI_Model {
        
    public function __construct() {
        
       $this->load->library('Datatables');
  
    }
	
    
	public function GetAllMembers() {
       	
		$arr = Array();
				    
       	$query = $this-> db -> query('select memberid,name,role from ceat_users ORDER BY name ASC');
       	$row = $query->result_array();
		$arr['member_count'] = count($row);
		
		if($row) {
			
			$arr['member_list'] = '<div id="memList-nav"></div><ul id="memList" style="margin-top: 15px; list-style:none;">';
						
			for( $j = 0; $j < count($row);$j++) {
				
				$memberid = $row[$j]['memberid'];
				$membername = $row[$j]['name'];		
				$role = $row[$j]['role'];	
				
				if($role!="admin"){							
				
					$arr['member_list'] .= '<li class="memberlist" id="'.$memberid.'">'.$membername.'</li>';
					
				}
				
			}
			
			$arr['member_list'] .= '</ul>';
		}
		
		
		return $arr;
    }
    
    public function GetAllMembersCount() {
       	
	$arr = Array();
				    
       	$query = $this-> db -> query('select memberid,name,role from ceat_users ORDER BY name ASC');
       	$row = $query->result_array();
	$arr['member_count'] = count($row);
	return $arr;
        
    }
    
    
         
        public function GetAllNotifications(){
		
		$arr = Array();
		
		$arr['list'] = "";
		
                //$this->datatables->set_database("default");
		$this->datatables->select('notifyid,date,news,link') 
                ->edit_column('link', '<a href="$1">$1</a>', 'link')  
                ->edit_column('notifyid', '<a class="del" id="$1" href="javascript:void(0)">x</a>', 'notifyid') 
                ->from('ceat_notifications');
                
                $table =  $this->datatables->generate();
		
		$editTable = json_decode($table);
                $tmpTable = $editTable->data;
            
                foreach ($tmpTable as $val) {                
                    $val->date = date('d-m-Y',strtotime($val->date));   

                }

                $rtrvTable = json_encode($editTable);

            return $rtrvTable;
            
	}
        
          public function DelNotifications($ide){
        
        $query1 = $this-> db -> query('delete from ceat_notifications where notifyid="'.$ide.'"');
        if($query1) {
            $result = array(0 => "success");
        } else {
            $result = array(0 => "fail");
        }
        
        return $result; 
        
    }
    
    public function AddNotifications($mess,$link){
        
        $id= uniqid();
        $query1 = $this-> db -> query('insert into ceat_notifications (`notifyid`,`link`,`news`,`date`) values ("'.$id.'","'.$link.'","'.$mess.'",CURRENT_TIMESTAMP)');
        if($query1) {
            $result = array(0 => "success");
            
            
//Start to send iPhone Push Apps
            $noticetext = $mess;
                   $messTemplate = 'iacde=vj59&message=' . $noticetext;
                   $substr = $messTemplate;
                   $url = "http://35.88.44.130/pushNotify/sendIOSPush?";

                   $ch = curl_init($url);
                   curl_setopt($ch, CURLOPT_POST, 1);
                   curl_setopt($ch, CURLOPT_POSTFIELDS, $substr);
                   curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
                   curl_setopt($ch, CURLOPT_HEADER, 0);  // DO NOT RETURN HTTP HEADERS 
                   curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);  // RETURN THE CONTENTS OF THE CALL
                   $ret = curl_exec($ch);
                   
                   //end
                   
        } else {
            $result = array(0 => "fail");
        }
        
        return $result; 
        
        
    }
	
    
        public function GetAllMembers_filter(){
		
		$arr = Array();
		
		$arr['list'] = "";
		
                //$this->datatables->set_database("default");
		$this->datatables->select('ceat_users.memberid,name,role,email,mobile,userid') 
            ->edit_column('name', '<a href="'.base_url().'editmemberpage?id=$1">$2</a>', 'memberid,name')  
            ->from('ceat_users')
            ->join('ceat_profiles', 'ceat_profiles.memberid=ceat_users.memberid', 'INNER');
                
                $table =  $this->datatables->generate();
		
		return $table;
	}
	
    public function CreateMember($name,$userid,$password,$role,$doj,$mobile,$phone,$email,$gender,$dob,$address,$contactaddress,$contactstate,$contactpin,$qualification,$college,$designation,$clinic,$clinicphone,$payamount,$paymode,$payid,$encrypted,$sameaddress,$address2,$city,$state,$pincode,$contactaddress2,$contactcity) {
		
		$result = array(0 => "");
		
		$query = $this-> db -> query('select memberid from ceat_users where userid="'.$userid.'"');
		$row = $query->result_array();
		if($row){
		
			$result = array(0 => "exists");
            return $result;
		
		}else{
		
			$memberid = uniqid();
			
			$regid = uniqid();
		
			$password = SHA1($password);
		
			$query1  = $this-> db -> query('insert into ceat_users (`memberid`,`userid`,`password`,`name`,`role`,`search`,`profileimg`,`dateofjoin`) values ("'.$memberid.'","'.$userid.'","'.$password.'","'.$name.'","'.$role.'","1","dp.jpg","'.$doj.'")');
		
			$query2  = $this-> db -> query('insert into ceat_profiles (`memberid`,`mobile`,`phone`,`email`,`address`,`contactaddress`,`contactstate`,`contactpin`,`clinicaddress`,`clinicphone`,`designation`,`qualification`,`college`,`dob`,`gender`,`sameaddress`,`address2`,`city`,`state`,`pincode`,`contactaddress2`,`contactcity`) values ("'.$memberid.'","'.$mobile.'","'.$phone.'","'.$email.'","'.$address.'","'.$contactaddress.'","'.$contactstate.'","'.$contactpin.'","'.$clinic.'","'.$clinicphone.'","'.$designation.'","'.$qualification.'","'.$college.'","'.$dob.'","'.$gender.'","'.$sameaddress.'","'.$address2.'","'.$city.'","'.$state.'","'.$pincode.'","'.$contactaddress2.'","'.$contactcity.'")');
			
			$query3  = $this-> db -> query('insert into ceat_registration (`id`,`memtype`,`name`,`dob`,`sex`,`mobile`,`phone`,`email`,`address`,`contactaddress`,`contactstate`,`contactpin`,`qualification`,`college`,`designation`,`clinicaddress`,`clinicphone`,`paymentamount`,`paymentmode`,`paymentid`,`status`,`sameaddress`,`address2`,`city`,`state`,`pincode`,`contactaddress2`,`contactcity`) values ("'.$regid.'","'.$role.'","'.$name.'","'.$dob.'","'.$gender.'","'.$mobile.'","'.$phone.'","'.$email.'","'.$address.'","'.$contactaddress.'","'.$contactstate.'","'.$contactpin.'","'.$qualification.'","'.$college.'","'.$designation.'","'.$clinic.'","'.$clinicphone.'","'.$payamount.'","'.$paymode.'","'.$payid.'","approved","'.$sameaddress.'","'.$address2.'","'.$city.'","'.$state.'","'.$pincode.'","'.$contactaddress2.'","'.$contactcity.'")');
			
			$query4  = $this-> db -> query('insert into ceat_comm_members (`memberid`,`commid`,`joinedtime`,`unjoinedtime`,`status`) values ("'.$memberid.'","5166674f32377","0000-00-00 00:00:00","0000-00-00 00:00:00","1")');
			
			$query5  = $this-> db -> query('insert into ceat_connections (`memberid`) values ("'.$memberid.'")');
			
			if($query1 && $query2 && $query3 && $query4 && $query5){
				$result = array(0 => "success", 1 => $userid, 2 => $encrypted, 3 => $regid, 4 => $name, 5 => $email, 6=> $payamount, 7=> $paymode, 8=> $payid );
				//$this->NewMemberConfirmation($regid);
            	return $result;
			}
			
		}
		
		return $result;
		
	}

	
	public function ApproveMemberRequest($approveid,$name,$userid,$password,$role,$doj,$mobile,$phone,$email,$gender,$dob,$address,$contactaddress,$contactstate,$contactpin,$qualification,$college,$designation,$clinic,$clinicphone,$payamount,$paymode,$payid,$encrypted,$sameaddress,$address2,$city,$state,$pincode,$contactaddress2,$contactcity) {
		
		$result = array(0 => "");
		
		$query = $this-> db -> query('select memberid from ceat_users where userid="'.$userid.'"');
		$row = $query->result_array();
		if($row){
		
			$result = array(0 => "exists");
            return $result;
		
		}else{
		
			$memberid = uniqid();
		
			$pass = SHA1($userid); // Just for emergency changed on Jan 14 2016
			
			// $pass = SHA1($password);
		
			$query1  = $this-> db -> query('insert into ceat_users (`memberid`,`userid`,`password`,`name`,`role`,`search`,`profileimg`,`dateofjoin`) values ("'.$memberid.'","'.$userid.'","'.$pass.'","'.$name.'","'.$role.'","1","dp.jpg","'.$doj.'")');
		
			$query2  = $this-> db -> query('insert into ceat_profiles (`memberid`,`mobile`,`phone`,`email`,`address`,`contactaddress`,`contactstate`,`contactpin`,`clinicaddress`,`clinicphone`,`designation`,`qualification`,`college`,`dob`,`gender`,`sameaddress`,`address2`,`city`,`state`,`pincode`,`contactaddress2`,`contactcity`) values ("'.$memberid.'","'.$mobile.'","'.$phone.'","'.$email.'","'.$address.'","'.$contactaddress.'","'.$contactstate.'","'.$contactpin.'","'.$clinic.'","'.$clinicphone.'","'.$designation.'","'.$qualification.'","'.$college.'","'.$dob.'","'.$gender.'","'.$sameaddress.'","'.$address2.'","'.$city.'","'.$state.'","'.$pincode.'","'.$contactaddress2.'","'.$contactcity.'")');
			
			$query3  = $this-> db -> query('update ceat_registration set paymentamount="'.$payamount.'", paymentmode="'.$paymode.'", paymentid="'.$payid.'", status="approved" where id="'.$approveid.'"');
			
			$query4  = $this-> db -> query('insert into ceat_comm_members (`memberid`,`commid`,`joinedtime`,`unjoinedtime`,`status`) values ("'.$memberid.'","5166674f32377","0000-00-00 00:00:00","0000-00-00 00:00:00","1")');
			
			$query5  = $this-> db -> query('insert into ceat_connections (`memberid`) values ("'.$memberid.'")');
								
			if($query1 && $query2 && $query3 && $query4 && $query5){
				$result = array(0 => "success", 1 => $userid, 2 => $encrypted, 3 => $approveid, 4 => $name, 5 => $email, 6=> $payamount, 7=> $paymode, 8=> $payid );
            	return $result;
			}
			
		}
		
		return $result;
		
	}
	
	public function NewMemberConfirmation($refno){
		
	$query = $this-> db -> query('select * from ceat_registration where id="'.$refno.'"');

	$row = $query->result_array();

	if($query->num_rows()==1)
	{
	
	
	$memtype = $row[0]['memtype'];
	$name = $row[0]['name'];
	$dob = $row[0]['dob'];
	$sex = $row[0]['sex'];
	$mobile = $row[0]['mobile'];
	$email = $row[0]['email'];
	$sameaddress = $row[0]['sameaddress'];
	$address = $row[0]['address'];
	$address2 = $row[0]['address2'];
	$city = $row[0]['city'];
	$state = $row[0]['state'];
	$pincode = $row[0]['pincode'];
	$contactaddress = $row[0]['contactaddress'];
	$contactaddress2 = $row[0]['contactaddress2'];
	$contactcity = $row[0]['contactcity'];
	$contactstate = $row[0]['contactstate'];
	$contactpin = $row[0]['contactpin'];
	$qualification = $row[0]['qualification'];
	$college = $row[0]['college'];
	
	if ($row[0]['phone']!=""): $phone = $row[0]['phone']; else : $phone = "-"; endif;
	if ($row[0]['designation']!=""): $designation = $row[0]['designation']; else : $designation = "-"; endif;
	if ($row[0]['clinicaddress']!=""): $clinicaddress = $row[0]['clinicaddress']; else : $clinicaddress = "-"; endif;
	//if ($row[0]['clinicaddress2']!=""): $clinicaddress2 = $row[0]['clinicaddress2']; else : $clinicaddress2 = "-"; endif;
	if ($row[0]['clinicphone']!=""): $clinicphone = $row[0]['clinicphone']; else : $clinicphone = "-"; endif;
	//if ($row[0]['cliniccity']!=""): $cliniccity = $row[0]['cliniccity']; else : $cliniccity = "-"; endif;
	//if ($row[0]['clinicstate']!=""): $clinicstate = $row[0]['clinicstate']; else : $clinicstate = "-"; endif;
	//if ($row[0]['clinicpin']!=""): $clinicpin = $row[0]['clinicpin']; else : $clinicpin = "-"; endif;


	$caddress = "<tr><td style=\"border-right:2px solid #e5e5e5;border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:150px;font-weight:bold;\" colspan=\"2\">Residential Address </td</tr>
	
	<tr><td style=\"border-right:2px solid #e5e5e5;border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:150px\">Address</td><td style=\"border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:450px\">" . $contactaddress . "</td></tr>

	<tr><td style=\"border-right:2px solid #e5e5e5;border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:150px\">Address 2</td><td style=\"border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:450px\">" . $contactaddress2 . "</td></tr>

	<tr><td style=\"border-right:2px solid #e5e5e5;border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:150px\">City</td><td style=\"border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:450px\">" . $contactcity . "</td></tr>

	<tr><td style=\"border-right:2px solid #e5e5e5;border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:150px\">State</td><td style=\"border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:450px\">" . $contactstate . "</td></tr>

	<tr><td style=\"border-right:2px solid #e5e5e5;border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:150px\">Pincode</td><td style=\"border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:450px\">" . $contactpin . "</td></tr>
		";

	$cliaddress = "<tr><td style=\"border-right:2px solid #e5e5e5;border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:150px;font-weight:bold;\" colspan=\"2\">Clinic Address </td</tr>

		<tr><td style=\"border-right:2px solid #e5e5e5;border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:150px\">Address</td><td style=\"border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:450px\">" . $clinicaddress . "</td></tr>


	<tr><td style=\"border-right:2px solid #e5e5e5;border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:150px\">Phone</td><td style=\"border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:450px\">" . $clinicphone . "</td></tr>

		";
		
		/*	<tr><td style=\"border-right:2px solid #e5e5e5;border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:150px\">Address 2</td><td style=\"border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:450px\">" . $clinicaddress2 . "</td></tr>
		
		<tr><td style=\"border-right:2px solid #e5e5e5;border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:150px\">City</td><td style=\"border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:450px\">" . $cliniccity . "</td></tr>

	<tr><td style=\"border-right:2px solid #e5e5e5;border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:150px\">State</td><td style=\"border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:450px\">" . $clinicstate . "</td></tr>

	<tr><td style=\"border-right:2px solid #e5e5e5;border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:150px\">Pincode</td><td style=\"border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:450px\">" . $clinicpin . "</td></tr>*/


	 $subject = "CEAT Registration";

	 //========================================
	// Do not change anything below this line
	//========================================

	$body = "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.=

	w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\"><html><head><meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\"></head><body>



	<table style=\"padding-top:4px;margin:0em auto;width:600px\"><tbody>

	<tr><td style=\"text-align:center;font-size:14px;padding-left:10px;color:#333;width:150px\">This message was sent from: " . getenv("HTTP_REFERER") . " - [" . $_SERVER['REMOTE_ADDR'] ."]</td></tr>

	</tbody></table>



	<table style=\"background:#f5f5f5;border:2px solid #e5e5e5;border-collapse:collapse;padding-top:4px;margin:1.5em auto;width:600px\"><tbody>


	<tr><td style=\"border-right:2px solid #e5e5e5;border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:150px\">Member Type</td><td style=\"border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:450px\">" . $memtype . "</td></tr>

	<tr><td style=\"border-right:2px solid #e5e5e5;border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:150px\">Name</td><td style=\"border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:450px\">" . $name . "</td></tr>

	<tr><td style=\"border-right:2px solid #e5e5e5;border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:150px\">Mobile</td><td style=\"border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:450px\">" . $mobile . "</td></tr>

	<tr><td style=\"border-right:2px solid #e5e5e5;border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:150px\">Phone</td><td style=\"border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:450px\">" . $phone . "</td></tr>

	<tr><td style=\"border-right:2px solid #e5e5e5;border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:150px\">Email</td><td style=\"border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:450px\">" . $email . "</td></tr>

	<tr><td style=\"border-right:2px solid #e5e5e5;border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:150px\">Sex</td><td style=\"border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:450px\">" . $sex . "</td></tr>

	<tr><td style=\"border-right:2px solid #e5e5e5;border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:150px\">Date of Birth</td><td style=\"border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:450px\">" . $dob . "</td></tr>

	<tr><td style=\"border-right:2px solid #e5e5e5;border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:150px\">Address</td><td style=\"border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:450px\">" . $address . "</td></tr>

	<tr><td style=\"border-right:2px solid #e5e5e5;border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:150px\">Address 2</td><td style=\"border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:450px\">" . $address2 . "</td></tr>

	<tr><td style=\"border-right:2px solid #e5e5e5;border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:150px\">City</td><td style=\"border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:450px\">" . $city . "</td></tr>

	<tr><td style=\"border-right:2px solid #e5e5e5;border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:150px\">State</td><td style=\"border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:450px\">" . $state . "</td></tr>

	<tr><td style=\"border-right:2px solid #e5e5e5;border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:150px\">Pincode</td><td style=\"border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:450px\">" . $pincode . "</td></tr>

	".$caddress."

	<tr><td style=\"border-right:2px solid #e5e5e5;border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:150px\">BDS College</td><td style=\"border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:450px\">" . $qualification . "</td></tr>

	<tr><td style=\"border-right:2px solid #e5e5e5;border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:150px\">MDS College</td><td style=\"border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:450px\">" . $college . "</td></tr>

	<tr><td style=\"border-right:2px solid #e5e5e5;border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:150px\">Designation</td><td style=\"border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:450px\">" . $designation . "</td></tr>

	".$cliaddress."

	</tbody></table>

	</body></html>";


	$toemail = "ceatfamily@gmail.com";
	//$toemail = "krishnan@harvee.co.uk";
	$fromname = "CEAT Registration";
	$replyto = "ceatfamily@gmail.com";
	$subject = $subject;
	$pname = "CEAT";

	$finalbody = urlencode($body);


	$substr = 'webtag=Theri&toemail='.$toemail.'&fromname='.$fromname."&replyto=".$replyto."&pname=".$pname."&subject=".$subject."&body=".$finalbody;

	$url = "http://35.88.44.130/sendmail?";



	$ch = curl_init($url);

	curl_setopt($ch, CURLOPT_POST, 1);

	curl_setopt($ch, CURLOPT_POSTFIELDS, $substr);

	curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);

	curl_setopt($ch, CURLOPT_HEADER, 0);  // DO NOT RETURN HTTP HEADERS 

	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);  // RETURN THE CONTENTS OF THE CALL

	$return_val = curl_exec($ch);

	}
}
	
	public function DeleteMemberRequest($approveid) {
		
		$query = $this-> db -> query('update ceat_registration set status="closed" where id="'.$approveid.'"');
		
	}
	
	public function GetMemberName($memberid) {
       	
		$arr = Array();
		$arr['name'] = "";
				    
       	$query = $this-> db -> query('select name,userid,role,profileimg,dateofjoin from ceat_users where memberid="'.$memberid.'"');
       	$row = $query->result_array();
		if($row){
			$arr['name'] = $row[0]['name'];
			$arr['userid'] = $row[0]['userid'];
			$arr['role'] = $row[0]['role'];
			$arr['profileimg'] = $row[0]['profileimg'];
			$arr['doj'] = $row[0]['dateofjoin'];
		}
		return $arr;
    }
	
	public function GetMemberProfile($memberid) {
		
		$arr = Array();
       	   		    
       	$query = $this-> db -> query('select mobile,phone,email,address,contactaddress,contactstate,contactpin,clinicaddress,clinicphone,designation,qualification,college,dob,gender,about,interests,checkcard,checkcertificate,mtype,mstudent,mfaculty,mname,maddress1,maddress2,mcity,mstate,mpincode,mdesignation,mlandline,mmobile,mgeo,mclinictiming,sameaddress,address2,city,state,pincode,contactaddress2,contactcity from ceat_profiles where memberid="'.$memberid.'"');
       	$row = $query->result_array();
		if($row){
			$arr['mobile'] = $row[0]['mobile'];
			$arr['phone'] = $row[0]['phone'];
			$arr['email'] = $row[0]['email'];
			$arr['clinicaddress'] = $row[0]['clinicaddress'];
			$arr['clinicphone'] = $row[0]['clinicphone'];
			$arr['designation'] = $row[0]['designation'];
			$arr['qualification'] = $row[0]['qualification'];
			$arr['college'] = $row[0]['college'];
			$arr['dob'] = $row[0]['dob'];
			$arr['gender'] = $row[0]['gender'];
			$arr['about'] = $row[0]['about'];
			$arr['interests'] = $row[0]['interests'];
		
			$arr['interests'] = explode("&|&", $arr['interests']);
		
			$arr['address'] = $row[0]['address'];
			$arr['contactaddress'] = $row[0]['contactaddress'];
			$arr['contactstate'] = $row[0]['contactstate'];
			$arr['contactpin'] = $row[0]['contactpin'];
			$arr['checkcard'] = $row[0]['checkcard'];
			$arr['checkcertificate'] = $row[0]['checkcertificate'];
			
						$arr['mtype'] = $row[0]['mtype'];
                        $arr['mstudent'] = addslashes($row[0]['mstudent']);
                        $arr['mfaculty'] = addslashes($row[0]['mfaculty']);
                        $arr['mname'] = addslashes($row[0]['mname']);
                        $arr['maddress1'] = addslashes($row[0]['maddress1']);
                        $arr['maddress2'] = addslashes($row[0]['maddress2']);
                        $arr['mcity'] = addslashes($row[0]['mcity']);
                        $arr['mstate'] = addslashes($row[0]['mstate']);
                        $arr['mpincode'] = $row[0]['mpincode'];
                        $arr['mdesignation'] = $row[0]['mdesignation'];
                        $arr['mlandline'] = $row[0]['mlandline'];
                        $arr['mmobile'] = $row[0]['mmobile'];
                        $arr['mgeo'] = $row[0]['mgeo'];
                        $arr['mclinictiming'] = $row[0]['mclinictiming'];
						
						$arr['sameaddress'] = $row[0]['sameaddress'];
						$arr['address2'] = addslashes($row[0]['address2']);
						$arr['city'] = $row[0]['city'];
						$arr['state'] = $row[0]['state'];
						$arr['pincode'] = $row[0]['pincode'];
						$arr['contactaddress2'] = $row[0]['contactaddress2'];
						$arr['contactcity'] = $row[0]['contactcity'];
		}
		return $arr;
    }
	
	public function UpdateMember($memid,$name,$userid,$password,$role,$doj,$mobile,$phone,$email,$gender,$dob,$address,$contactaddress,$contactstate,$contactpin,$qualification,$college,$designation,$clinic,$clinicphone,$aboutme,$interest,$membertype,$mstudent,$mfaculty,$mname,$maddress1,$maddress2,$mcity,$mstate,$mpincode,$mdesignation,$mlandline,$mmobile,$mgeo,$mclinictiming,$sameaddress,$address2,$city,$state,$pincode,$contactaddress2,$contactcity) {
		
		$result = array(0 => "");
		
		if($password==""){
			$query1  = $this-> db -> query('update ceat_users set name="'.$name.'",userid="'.$userid.'",role="'.$role.'",dateofjoin="'.$doj.'" where memberid="'.$memid.'"' );
		}else{
			
			$pass = SHA1($password);
			
			$query1  = $this-> db -> query('update ceat_users set name="'.$name.'",userid="'.$userid.'",password="'.$pass.'",role="'.$role.'",dateofjoin="'.$doj.'" where memberid="'.$memid.'"' );
		}
		
		
		
		$query2  = $this-> db -> query('update ceat_profiles set mobile="'.$mobile.'", phone="'.$phone.'", email="'.$email.'", gender="'.$gender.'", dob="'.$dob.'", address="'.$address.'", contactaddress="'.$contactaddress.'", contactstate="'.$contactstate.'",  contactpin="'.$contactpin.'", qualification="'.$qualification.'", college="'.$college.'", designation="'.$designation.'", clinicaddress="'.$clinic.'", clinicphone="'.$clinicphone.'", about="'.$aboutme.'", interests="'.$interest.'", mtype="'.$membertype.'", mstudent="'.$mstudent.'", mfaculty="'.$mfaculty.'", mname="'.$mname.'", maddress1="'.$maddress1.'", maddress2="'.$maddress2.'", mcity="'.$mcity.'", mstate="'.$mstate.'", mpincode="'.$mpincode.'", mdesignation="'.$mdesignation.'", mlandline="'.$mlandline.'", mmobile="'.$mmobile.'", mgeo="'.$mgeo.'", mclinictiming="'.$mclinictiming.'",sameaddress="'.$sameaddress.'",address2="'.$address2.'",city="'.$city.'",state="'.$state.'",pincode="'.$pincode.'",contactaddress2="'.$contactaddress2.'",contactcity="'.$contactcity.'" where memberid="'.$memid.'"' );
		
			if($query1 && $query2){
				$result = array(0 => "success");
  			}
			
		return $result;
		
	}
	
	public function DeleteMemberProfile($memid) {
		
		$query = $this-> db -> query('delete from ceat_users where memberid="'.$memid.'"');
		
		$query1 = $this-> db -> query('delete from ceat_profiles where memberid="'.$memid.'"');
		
		$query2 = $this-> db -> query('delete from ceat_comm_members where memberid="'.$memid.'"');
		
		$query3 = $this-> db -> query('delete from ceat_connections where memberid="'.$memid.'"');
		
	}
	
	public function GetWaitingApproval(){
		
		$arr = Array();
				    
       	$query = $this-> db -> query('select id,name,memtype,mobile,paymentmode,paymentid from ceat_registration where paymentid<>"" and status="open"');
       	$row = $query->result_array();
		$arr['member_count'] = count($row);
		
		if($row) {
			
			$arr['member_list'] = '<tr class="title"><td width="230">Name</td><td width="110">Membership Type</td><td width="110">Mobile No.</td><td>Payment Status</td><td>View</td></tr>';
						
			for( $j = 0; $j < count($row);$j++) {
				
				$id = $row[$j]['id'];
				$name = $row[$j]['name'];
				$memtype = $row[$j]['memtype'];
				$mobile = $row[$j]['mobile'];
				$paymentmode = $row[$j]['paymentmode'];
				$paymentid = $row[$j]['paymentid'];								
				
				$arr['member_list'] .= '<tr><td>'.$name.'</td><td>'.$memtype.'</td><td>'.$mobile.'</td><td>'.$paymentmode.'- '.$paymentid.'</td><td><a style="text-decoration:underline" href="approvemember?id='.$id.'">view</a></td></tr>';
				
			}			
			
		}else{
			
			$arr['member_list'] = '<tr><td colspan="4" style="text-align:center;">No Records Found</td></tr>';
			
		}
		
		return $arr;
		
	}
	
	public function Getccdetails(){
		
		$arr = Array();
				    
       	$query = $this-> db -> query('select memberid,mobile,checkcard,checkcertificate from ceat_profiles where checkcard="NO" and checkcertificate="NO" or checkcard="YES" and checkcertificate="NO" or checkcard="NO" and checkcertificate="YES"');
       	$row = $query->result_array();
		$arr['detail_count'] = count($row);
		
		if($row) {
			
			$arr['detail_list'] = '<tr class="title"><td width="230">Name</td><td width="110">ID Card</td><td width="110">Certificate</td><td width="110">Mobile No.</td><td>ID/Certificate Provided</td></tr>';
						
			for( $j = 0; $j < count($row);$j++) {
				
				$memberid = $row[$j]['memberid'];
				$checkcard = $row[$j]['checkcard'];
				$checkcertificate = $row[$j]['checkcertificate'];
				$mobile = $row[$j]['mobile'];
				
				$query1 = $this-> db -> query('select name from ceat_users where memberid="'.$memberid.'"');
       	$row1 = $query1->result_array();
		        if($row1)
				{
					$name = $row1[0]['name'];
				}
				
				$arr['detail_list'] .= '<tr><td><a style="text-decoration:underline" href="editmemberpage?id='.$memberid.'">'.$name.'</a></td><td>'.$checkcard.'</td><td>'.$checkcertificate.'</td><td> '.$mobile.'</td><td><input type="radio" name="'.$memberid.'" value="YES" />Yes<input type="radio" name="'.$memberid.'" value="NO" checked/>No</td></tr>';
				
			}			
			
		}else{
			
			$arr['detail_list'] = '<tr><td colspan="4" style="text-align:center;">No Records Found</td></tr>';
			
		}
		
		return $arr;
		
	}
	
	public function Getforgetpassdetails(){
		
		$arr = Array();
				    
       	$query = $this-> db -> query('select fuserid,femailid,fstatus from ceat_forgetpass where fstatus="P"');
       	$row = $query->result_array();
		$arr['fp_count'] = count($row);
		
		if($row) {
			
			$arr['fp_list'] = '<tr class="title"><td width="230">Name</td><td width="110">Email ID</td><td width="110">Approve</td></tr>';
						
			for( $j = 0; $j < count($row);$j++) {
				
				$fuserid = $row[$j]['fuserid'];
				$femailid = $row[$j]['femailid'];
				$fstatus = $row[$j]['fstatus'];
				
				$query1 = $this-> db -> query('select name,memberid from ceat_users where userid="'.$fuserid.'"');
       	$row1 = $query1->result_array();
		        if($row1)
				{
					$name = $row1[0]['name'];
					$memberid = $row1[0]['memberid'];
				}
				
				$arr['fp_list'] .= '<tr><td><a style="text-decoration:underline" href="editmemberpage?id='.$memberid.'">'.$name.'</a></td><td> '.$femailid.'</td><td><input type="button" id="'.$memberid.'" name="'.$fuserid.'" value="Reset"/><span style="margin:15px 0 0; text-align:right; color:#fff;" class="err-notify"></span></td></tr>';
				
			}			
			
		}else{
			
			$arr['fp_list'] = '<tr><td colspan="4" style="text-align:center;">No Records Found</td></tr>';
			
		}
		
		return $arr;
		
	}
	
	public function GetApprovalDetails($memid){
		
		$arr = Array();
       	   		    
       	$query = $this-> db -> query('select memtype,name,dob,sex,mobile,phone,email,address,contactaddress,contactstate,contactpin,qualification,college,designation,clinicaddress,clinicphone,proposedname,proposedmembership,secondedname,secondedmembership,paymentamount,paymentmode,paymentid,status,sameaddress,address2,city,state,pincode,contactaddress2,contactcity from ceat_registration where id="'.$memid.'"');
       	$row = $query->result_array();
		
		$arr['id'] = $memid;
		$arr['memtype'] = $row[0]['memtype'];
		$arr['name'] = $row[0]['name'];
		$arr['mobile'] = $row[0]['mobile'];
		$arr['phone'] = $row[0]['phone'];
		$arr['email'] = $row[0]['email'];
		$arr['clinicaddress'] = $row[0]['clinicaddress'];
		$arr['clinicphone'] = $row[0]['clinicphone'];
		$arr['designation'] = $row[0]['designation'];
		$arr['qualification'] = $row[0]['qualification'];
		$arr['college'] = $row[0]['college'];
		$arr['dob'] = $row[0]['dob'];
		$arr['sex'] = $row[0]['sex'];
		$arr['address'] = $row[0]['address'];
		$arr['contactaddress'] = $row[0]['contactaddress'];
		$arr['contactstate'] = $row[0]['contactstate'];
		$arr['contactpin'] = $row[0]['contactpin'];
		
		$arr['proposedname'] = $row[0]['proposedname'];
		$arr['proposedmembership'] = $row[0]['proposedmembership'];
		$arr['secondedname'] = $row[0]['secondedname'];
		$arr['secondedmembership'] = $row[0]['secondedmembership'];
		
		$arr['paymentamount'] = $row[0]['paymentamount'];
		$arr['modeofpay'] = $row[0]['paymentmode'];
		$arr['paymentid'] = $row[0]['paymentid'];
		
		$arr['status'] = $row[0]['status'];
		
		$arr['sameaddress'] = $row[0]['sameaddress'];
		$arr['address2'] = $row[0]['address2'];
		$arr['city'] = $row[0]['city'];
		$arr['state'] = $row[0]['state'];
		$arr['pincode'] = $row[0]['pincode'];
		$arr['contactaddress2'] = $row[0]['contactaddress2'];
		$arr['contactcity'] = $row[0]['contactcity'];
		
				$paymodearr = "DD,NEFT,ONLINE,CASH,card,netbanking,wallet,emi,upi";
				$paymodearr = explode(",",$paymodearr);
				$arr['paymentmode'] = '<option>Choose</option>';
				foreach ($paymodearr as $pmval) { 
					if($arr['modeofpay']==$pmval){
						$arr['paymentmode'] .= "<option selected>".$pmval."</option>";
					}else{
						$arr['paymentmode'] .= "<option>".$pmval."</option>";
					}	   				
				}
						
		return $arr;
		
	}
	
	public function encrypt($string, $key) {
  		$result = '';
  		for($i=0; $i<strlen($string); $i++) {
    		$char = substr($string, $i, 1);
    		$keychar = substr($key, ($i % strlen($key))-1, 1);
    		$char = chr(ord($char)+ord($keychar));
    		$result.=$char;
  		}
  		return base64_encode($result);
	}
	
	
	public function SearchByName($searchtag) {
       	
		$arr = '';
		
		$query = $this-> db -> query('select memberid,name from ceat_users where name LIKE "%'.$searchtag.'%" and role<>"admin"');
       	$row = $query->result_array();
			
		if($row) {
			
			$arr = '<ul id="memListsearch" style="margin-top: 15px; list-style:none;">';
						
			for( $j = 0; $j < count($row);$j++) {
				
				$memberid = $row[$j]['memberid'];
				$membername = $row[$j]['name'];								
				
				$arr .= '<li class="memberlist" id="'.$memberid.'">'.$membername.'</li>';
				
			}
			
			$arr .= '</ul>';
		}
		
		return $arr;
		
    }
	
	public function SearchById($searchtag) {
       	
		$arr = '';
		
		$query = $this-> db -> query('select memberid,name from ceat_users where userid = "'.$searchtag.'" and role<>"admin"');
       	$row = $query->result_array();
			
		if($row) {
			
			$arr = '<ul id="memListsearch" style="margin-top: 15px; list-style:none;">';
						
			for( $j = 0; $j < count($row);$j++) {
				
				$memberid = $row[$j]['memberid'];
				$membername = $row[$j]['name'];								
				
				$arr .= '<li class="memberlist" id="'.$memberid.'">'.$membername.'</li>';
				
			}
			
			$arr .= '</ul>';
		}
		
		return $arr;
		
    }
	
	public function CreateCollege($name,$userid,$password,$state) {
		
		$result = array(0 => "");
		
		$query = $this-> db -> query('select collegeid from ceat_colleges where userid="'.$userid.'"');
		$row = $query->result_array();
		if($row){
		
			$result = array(0 => "exists");
            return $result;
		
		}else{
		
			$collegeid = uniqid();
		
			$password = SHA1($password);
		
			$query1  = $this-> db -> query('insert into ceat_colleges (`collegeid`,`userid`,`password`,`collegename`,`state`) values ("'.$collegeid.'","'.$userid.'","'.$password.'","'.$name.'","'.$state.'")');
							
			if($query1){
				$result = array(0 => "success");
            	return $result;
			}
			
		}
		
		return $result;
		
	}
	
	public function GetAllColleges() {
       	
		$ret = "";
		
		$statearr = Array("Andaman and Nicobar Islands","Andhra Pradesh","Arunachal Pradesh","Assam","Bihar","Chattisgarh","Chandigarh","Dadra and Nagar Haveli","Daman and Diu","Delhi","Goa","Gujarat","Haryana","Himachal Pradesh","Jammu and Kashmir","Jharkhand","Karnataka","Kerala","Lakshadweep","Madhya Pradesh","Maharashtra","Manipur","Meghalaya","Mizoram","Nagaland","Odisha","Pondicherry","Punjab","Rajasthan","Sikkim","Tamil Nadu","Tripura","Uttar Pradesh","Uttarakhand","West Bengal");
		
		for($i=0;$i<count($statearr);$i++){
								
			$query = $this-> db -> query('select collegeid,collegename from ceat_colleges where state="'.$statearr[$i].'"');
       		$row = $query->result_array();		
			if($row) {
				
				$ret .= '<h5>'.$statearr[$i].'</h5><ul>';
				
				for($j=0;$j<count($row);$j++){
					
					$ret .= '<li id="'.$row[$j]['collegeid'].'" class="collegelist">'.$row[$j]['collegename'].'</li>';
					
				}
				
				$ret .= '</ul><div style="clear:both; height:30px;"></div>';
			
			}
		}
				    
       	
		
		return $ret;
    }
	
	public function GetCollegeDetails($collegeid) {
       	
		$arr = Array();
		$arr['name'] = "";
				    
       	$query = $this-> db -> query('select userid,collegename,address,city,state,pincode,contactnumber,email,pg ,journals,events from ceat_colleges where collegeid="'.$collegeid.'"');
       	$row = $query->result_array();
		if($row){
			$arr['name'] = $row[0]['collegename'];
			$arr['userid'] = $row[0]['userid'];
			$arr['address'] = $row[0]['address'];
			$arr['city'] = $row[0]['city'];
			$arr['state'] = $row[0]['state'];
			$arr['pincode'] = $row[0]['pincode'];
			$arr['contactnumber'] = $row[0]['contactnumber'];
			$arr['email'] = $row[0]['email'];
			$arr['pg'] = $row[0]['pg'];
			
			$arr['journals'] = $row[0]['journals'];
			$arr['journals'] = explode("&|&", $arr['journals']);
			
			$arr['events'] = $row[0]['events'];
			$arr['events'] = explode("&|&", $arr['events']);
			
		}
		return $arr;
    }
	
	public function UpdateCollege($collegeid,$name,$userid,$password) {
		
		$result = array(0 => "");
		
		if($password==""){
			$query1  = $this-> db -> query('update ceat_colleges set collegename="'.$name.'",userid="'.$userid.'" where collegeid="'.$collegeid.'"' );
		}else{
			
			$pass = SHA1($password);
			
			$query1  = $this-> db -> query('update ceat_colleges set collegename="'.$name.'",userid="'.$userid.'",password="'.$pass.'" where collegeid="'.$collegeid.'"' );
		}
		
			if($query1){
				$result = array(0 => "success");
  			}
			
		return $result;
		
	}
	
	public function DeleteCollege($collegeid) {
		
		$query = $this-> db -> query('delete from ceat_colleges where collegeid="'.$collegeid.'"');
		
		$query1 = $this-> db -> query('delete from ceat_college_staffs where collegeid="'.$collegeid.'"');
		
	}
	
	public function AddSubject($name) {
		
		$result = array(0 => "");
		
		$query = $this-> db -> query('select subjectid from ceat_subjects where title="'.$name.'"');
		$row = $query->result_array();
		if($row){
		
			$result = array(0 => "exists");
            return $result;
		
		}else{
		
			$subjectid = uniqid();
		
			$query1  = $this-> db -> query('insert into ceat_subjects (`subjectid`,`title`) values ("'.$subjectid.'","'.$name.'")');
							
			if($query1){
				$result = array(0 => "success");
            	return $result;
			}
			
		}
		
		return $result;
		
	}
	
	public function GetAllSubjects() {
       	
		$arr = Array();
		
		$arr['subject_list'] = "";
				    
       	$query = $this-> db -> query('select * from ceat_subjects ORDER BY title ASC');
       	$row = $query->result_array();
		
		if($row) {
			
			$arr['subject_list'] = '<ul id="memListsearch" style="margin-top: 15px; list-style:none;">';
						
			for( $j = 0; $j < count($row);$j++) {
				
				$subjectid = $row[$j]['subjectid'];
				$title = $row[$j]['title'];								
				
				$arr['subject_list'] .= '<li class="subjectlist" id="'.$subjectid.'">'.$title.'</li>';
				
			}
			
			$arr['subject_list'] .= '</ul>';
		}
		
		
		return $arr;
    }
	
	public function GetQuestionsBySubject($subjectid) {
       	
		$arr = Array();
		$arr['subjectid'] = $subjectid;
		$arr['subject_name'] = '';
		$arr['quest_count'] = '0';
		$arr['quest_list'] = '';
		
		$query1 = $this-> db -> query('select * from ceat_subjects WHERE subjectid="'.$subjectid.'"');
       	$row1 = $query1->result_array();
		if($row1) {
			
			$arr['subject_name'] = $row1[0]['title'];
		
			$query = $this-> db -> query('select * from ceat_questions WHERE subjectid="'.$subjectid.'"');
			$row = $query->result_array();
			$arr['quest_count'] = count($row);
			
			if($row) {
				
				$arr['quest_list'] = '<div id="questionlist">';
				
				$count = 1;
							
				for( $j = 0; $j < count($row);$j++) {
					
					$questid = $row[$j]['questid'];
					$question = $row[$j]['question'];
					$option1 = $row[$j]['option1'];
					$option2 = $row[$j]['option2'];
					$option3 = $row[$j]['option3'];
					$option4 = $row[$j]['option4'];
					$answer = $row[$j]['answer'];
					
					$correctoption = '';
					if($answer=="option1"){$correctoption = 'A';}
					elseif($answer=="option2"){$correctoption = 'B';}
					elseif($answer=="option3"){$correctoption = 'C';}
					elseif($answer=="option4"){$correctoption = 'D';}
											
					
					$arr['quest_list'] .= '<div id="'.$questid.'" class="questions">
										<h5>Question No: '.$count.'<span class="deletequestion" id="'.$questid.'">Delete</span></h5>
										<h4>'.$question.'</h4>
										<p>A. '.$option1.'</p>
										<p>B. '.$option2.'</p>
										<p>C. '.$option3.'</p>
										<p>D. '.$option4.'</p>
										<p id="correctanswer">Answer: '.$correctoption.'</p>
										</div>';
										
					$count++;
					
				}
				
				$arr['quest_list'] .= '</div><hr />';
			}		
		
		}
		
		return $arr;
		
	}
	
	public function AddQuestion($subjectid,$question,$option1,$option2,$option3,$option4,$answer) {
		
		$result = array(0 => "");
		
		$query = $this-> db -> query('select questid from ceat_questions where question="'.$question.'"');
		$row = $query->result_array();
		if($row){
		
			$result = array(0 => "exists");
            return $result;
		
		}else{
		
			$questid = uniqid();
		
			$query1  = $this-> db -> query('insert into ceat_questions (`questid`,`subjectid`,`question`,`option1`,`option2`,`option3`,`option4`,`answer`) values ("'.$questid.'","'.$subjectid.'","'.$question.'","'.$option1.'","'.$option2.'","'.$option3.'","'.$option4.'","'.$answer.'")');
							
			if($query1){
				$result = array(0 => "success");
            	return $result;
			}
			
		}
		
		return $result;
		
	}
	
	public function DeleteSubject($subjectid) {
		
		$query = $this-> db -> query('delete from ceat_subjects WHERE subjectid="'.$subjectid.'"');
		$query1 = $this-> db -> query('delete from ceat_questions WHERE subjectid="'.$subjectid.'"');
		
	}
	
	public function DeleteQuestion($questid) {
		
		$query = $this-> db -> query('delete from ceat_questions WHERE questid="'.$questid.'"');
		
	}
	
	public function GetSubjectsForGenerate() {
       	
		$arr = Array();
		
		$arr['subject_list'] = "";
				    
       	$query = $this-> db -> query('select * from ceat_subjects ORDER BY title ASC');
       	$row = $query->result_array();		
		if($row) {
			
			$arr['subject_list'] = '<table id="genquestiontable">';
						
			for( $j = 0; $j < count($row);$j++) {
				
				if($j==0){
					
					$arr['subject_list'] .= '<tr><td width="200"><strong>Subject</strong></td><td width="100"><strong>Total Questions</strong></td><td width="100"><strong>Questions Needed</strong></td></tr>';
					
				}
				
				$subjectid = $row[$j]['subjectid'];
				$title = $row[$j]['title'];
				
				$query1 = $this-> db -> query('select questid from ceat_questions WHERE subjectid="'.$subjectid.'"');
				$row1 = $query1->result_array();		
				if($row1) {							
					
					$totalqns = count($row1);
					$arr['subject_list'] .= '<tr id="'.$subjectid.'"><td>'.$title.'</td><td class="totalqns" id="'.$totalqns.'">'.$totalqns.'</td><td><input type="text" class="reqqns" value="0" /></td></tr>';
					
				}
				
			}
			
			$arr['subject_list'] .= '</table>';
		}
		
		
		return $arr;
    }
	
	function GenerateQuestions($subjectArray){
		
		$arr = array();
		
		$subjectArray = json_decode($subjectArray, true); 
		
		$questionarr = array();
		
		for($s=0;$s<count($subjectArray);$s++){
			
			$subject = $subjectArray[$s];
			$subject = explode("|",$subject);
			$temparr = array();
			$query = $this-> db -> query('select * from ceat_questions WHERE subjectid="'.$subject[0].'"');
			$row = $query->result_array();
			if($row){
				for($i=0;$i<count($row);$i++){
					array_push($temparr, $row[$i]['questid']);
				}
				shuffle($temparr);
				for($j=0;$j<$subject[1];$j++){
					array_push($questionarr, $temparr[$j]);
				}
			}
			
			
			
		}
		
		$this->load->library('phpmailer');
		
		$offset=5*60*60 + 30*60;
		$dateformat = 'Y-m-d_H-i-s';
		$curtime = gmdate($dateformat, time()+$offset);
		
		$dateformat1 = 'd/m/Y H:i:s';
		$curtime1 = gmdate($dateformat1, time()+$offset);
		
		$questionpaperpdf = $this->GenerateQuestionPaperPDF($questionarr,$curtime);		
		$this->phpmailer->AddAttachment($questionpaperpdf, "QuestionPaper_".$curtime.".pdf");
		
		$answerpaperpdf = $this->GenerateAnswerPaperPDF($questionarr,$curtime);	
		$this->phpmailer->AddAttachment($answerpaperpdf, "AnswerPaper_".$curtime.".pdf");
		
		$subject = 'Question Paper Generated on '.$curtime1;
		
		$body = "Dear Team,<br><br>
		Please find the attached question paper generated on ".$curtime1.".<br><br>
		Regards<br>IACD";
				
		$this->phpmailer->ClearAllRecipients();
		$this->phpmailer->AddAddress('info@acdi.co.in');
		$this->phpmailer->AddBcc('latheef@harvee.co.uk');		  
		$this->phpmailer->IsMail();		  
		$this->phpmailer->From     = 'todo@harvee.co.uk';		  
		$this->phpmailer->FromName = 'IACD';		  
		$this->phpmailer->IsHTML(true);		  
		$this->phpmailer->Subject  =  $subject;		  
		$this->phpmailer->Body     =  $body;		  
		$this->phpmailer->Send();
		
		$result = array(0 => $questionpaperpdf);		
		return $result;
		
	}
	
	function GenerateQuestionPaperPDF($questionarr,$curtime) {
		
		$html = '<html><head><title>IACD</title>
		<style>
		html, body, div, span, applet, object, iframe, h3,h2,h4,h5, h6,blockquote, pre, a, abbr, acronym, address, big, cite, code, del, dfn, em, font, img, ins, kbd, q, s, samp, small, strike,sub, sup, tt, var, dl, dt, dd, ol, ul, li, fieldset, form, label, legend, table, caption, tbody, tfoot, thead, tr, th, td {
		margin: 0;
		padding: 0;
		border: 0;
		outline: 0;
		font-weight: inherit;
		font-style: inherit;
		font-size: 14px;
		font-family:Helvetica;
		vertical-align: baseline;
		text-align:center;	
		}
		body{
			padding:40px;
		}
		div.questions{
			text-align:left;
			color:#000;
			margin-bottom:10px
		}
		div.questions h4{
			text-align:left;
			font-size:16px;
		}
		div.questions p{
			text-align:left;
			font-size:13px;
		}
		</style>
		</head>
		<body>';
		
		$count = 1;
		foreach ($questionarr as $questid) {
			
			$query = $this-> db -> query('select * from ceat_questions WHERE questid="'.$questid.'"');
			$row = $query->result_array();
			if($row){
				
				$question = $row[0]['question'];
				$option1 = $row[0]['option1'];
				$option2 = $row[0]['option2'];
				$option3 = $row[0]['option3'];
				$option4 = $row[0]['option4'];
				
				$html .= '<div class="questions">
						<h4>'.$count.'. '.$question.'</h4>
						<p><strong>A.</strong> '.$option1.'</p>
						<p><strong>B.</strong> '.$option2.'</p>
						<p><strong>C.</strong> '.$option3.'</p>
						<p><strong>D.</strong> '.$option4.'</p>
						</div>';
										
				$count++;
				
			}
			
		}
		
		$html .= '</body></html>';
					
		require_once("./dompdf/dompdf_config.inc.php");
		$dompdf = new DOMPDF();
		$dompdf->load_html($html);
		$dompdf->set_paper("a4","portrait");
		$dompdf->render();		
		$output = $dompdf->output();
		
		//$dompdf->stream("Invoice.pdf");
		
		$file_location = "./questionpapers/QuestionPaper_".$curtime.".pdf";
		file_put_contents($file_location,$output);
		
		return $file_location;
		
	}
	
	function GenerateAnswerPaperPDF($questionarr,$curtime) {
		
		$html = '<html><head><title>IACD</title>
		<style>
		html, body, div, span, applet, object, iframe, h3,h2,h4,h5, h6,blockquote, pre, a, abbr, acronym, address, big, cite, code, del, dfn, em, font, img, ins, kbd, q, s, samp, small, strike,sub, sup, tt, var, dl, dt, dd, ol, ul, li, fieldset, form, label, legend, table, caption, tbody, tfoot, thead, tr, th, td {
		margin: 0;
		padding: 0;
		border: 0;
		outline: 0;
		font-weight: inherit;
		font-style: inherit;
		font-size: 14px;
		font-family:Helvetica;
		vertical-align: baseline;
		text-align:center;	
		}
		body{
			padding:40px;
		}
		h1{
			text-align:left;
			color:#000;
			margin-bottom:20px;
			font-size:22px;
		}
		div.questions{
			text-align:left;
			color:#000;
			margin-bottom:10px;
		}
		div.questions h4{
			text-align:left;
			font-size:16px;
		}
		div.questions p{
			text-align:left;
			font-size:13px;
		}
		</style>
		</head>
		<body>';
		
		$html .= '<h1>Answer Key</h1>';
		
		$count = 1;
		foreach ($questionarr as $questid) {
			
			$query = $this-> db -> query('select answer from ceat_questions WHERE questid="'.$questid.'"');
			$row = $query->result_array();
			if($row){
				
				$answer = $row[0]['answer'];
				
				$correctoption = '';
				if($answer=="option1"){$correctoption = 'A';}
				elseif($answer=="option2"){$correctoption = 'B';}
				elseif($answer=="option3"){$correctoption = 'C';}
				elseif($answer=="option4"){$correctoption = 'D';}
				
				$html .= '<div class="questions">
						<h4>'.$count.'. '.$correctoption.'</h4>
						</div>';
										
				$count++;
				
			}
			
		}
		
		$html .= '</body></html>';
					
		require_once("./dompdf/dompdf_config.inc.php");
		$dompdf = new DOMPDF();
		$dompdf->load_html($html);
		$dompdf->set_paper("a4","portrait");
		$dompdf->render();		
		$output = $dompdf->output();
		
		//$dompdf->stream("Invoice.pdf");
		
		$file_location = "./answerpapers/AnswerPaper_".$curtime.".pdf";
		file_put_contents($file_location,$output);
		
		return $file_location;
		
	}
    
    // Count 
	
    public function GetAllConferenceRegistrantCount() {
       	
	    $arr = Array();
				    
       	$query = $this-> db -> query('select id from ceat_confregistration where paymentstatus="captured"');
       	$row = $query->result_array();
	    $arr['member_count'] = count($row);
	    return $arr;
        
    }
	
	public function GetAllPreconferenceRegistrantCount() {
       	
	    $arr = Array();
				    
       	$query = $this-> db -> query('select id from ceat_preconfregistration where paymentstatus="captured"');
       	$row = $query->result_array();
	    $arr['member_count'] = count($row);
	    return $arr;
        
    }
	
	public function GetAllNomineesCount() {
       	
	    $arr = Array();
				    
       	$query = $this-> db -> query('select id from ceat_nominee');
       	$row = $query->result_array();
	    $arr['member_count'] = count($row);
	    return $arr;
        
    }
	
	public function GetAllElectionCount() {
       	
	    $arr = Array();
				    
       	$query = $this-> db -> query('select id from ceat_election');
       	$row = $query->result_array();
	    $arr['member_count'] = count($row);
	    return $arr;
        
    }
	
	public function GetAllPresentationCount() {
       	
	    $arr = Array();
				    
       	$query = $this-> db -> query('select id from ceat_presentation');
       	$row = $query->result_array();
	    $arr['member_count'] = count($row);
	    return $arr;
        
    }
	
	public function GetAllPGRegistrantCount() {
       	
	    $arr = Array();
				    
       	$query = $this-> db -> query('select id from ceat_regform  where paymentstatus="captured"');
       	$row = $query->result_array();
	    $arr['member_count'] = count($row);
	    return $arr;
        
    }
	
	public function GetAllPGRegistrant_filter(){
		
		$arr = Array();
		
		$arr['list'] = "";
		
                //$this->datatables->set_database("default");
		$this->datatables->select('id,type,name,phone,college,city') 
            ->edit_column('type', '<a href="'.base_url().'pgmemberpage?id=$1">$2</a>', 'id,type') 
            ->edit_column('name', '<a href="'.base_url().'pgmemberpage?id=$1">$2</a>', 'id,name') 
            ->from('ceat_regform')->where('paymentstatus',"captured");           
        $table =  $this->datatables->generate();
		
		return $table;
	}
	
	public function GetSessionList() {
       	
	    $arr['list'] = '<select id="mem_filter"><option value="">All Sessions</option>';
				    
       	$query = $this-> db -> query('select distinct sessionno from ceat_presentationsession ORDER BY sessionno ASC');
       	$row = $query->result_array();
	    for($i=0;$i<count($row);$i++){
			
			$arr['list'] .= '<option value="'.$row[$i]['sessionno'].'">'.$row[$i]['sessionno'].'</option>';
			
		}
		
		$arr['list'] .= '</select>';
		
	    return $arr;
        
    }
    
    public function GetAllConferenceRegistrant_filter(){
		
		$arr = Array();
		
		$arr['list'] = "";
		
                //$this->datatables->set_database("default");
		$this->datatables->select('id,regno,memtype,name,mobile,email,contactcity,memberid') 
            ->edit_column('regno', '<a href="'.base_url().'confmemberpage?id=$1">$2</a>', 'id,regno') 
            ->edit_column('memtype', '<a href="'.base_url().'confmemberpage?id=$1">$2</a>', 'id,memtype') 
            ->edit_column('name', '<a href="'.base_url().'confmemberpage?id=$1">$2</a>', 'id,name') 
            ->from('ceat_confregistration')->where('paymentstatus',"captured");           
        $table =  $this->datatables->generate();
		
		return $table;
	}
	
	public function GetAllPreconferenceRegistrant_filter(){
		
		$arr = Array();
		
		$arr['list'] = "";
		
                //$this->datatables->set_database("default");
		$this->datatables->select('ceat_preconfregistration.id,ceat_confregistration.regno,ceat_confregistration.memtype,ceat_preconfregistration.name,ceat_preconfregistration.mobile,ceat_preconfregistration.email,ceat_preconfregistration.preconfname,ceat_preconfregistration.paymenttime') 
            ->edit_column('regno', '<a href="'.base_url().'preconfmemberpage?id=$1">$2</a>', 'id,regno') 
            ->edit_column('memtype', '<a href="'.base_url().'preconfmemberpage?id=$1">$2</a>', 'id,memtype') 
            ->edit_column('name', '<a href="'.base_url().'preconfmemberpage?id=$1">$2</a>', 'id,name') 
            ->from('ceat_preconfregistration')
			->join('ceat_confregistration', 'ceat_preconfregistration.regid=ceat_confregistration.id', 'LEFT')
			->where('ceat_preconfregistration.paymentstatus',"captured");
		
        $table =  $this->datatables->generate();
		
		return $table;
	}
	
	public function GetKnowMember_filter(){

		$arr = Array();

		$arr['list'] = "";

                //$this->datatables->set_database("default");

		$this->datatables->select('userid,name,role,verifystatus') 

            ->from('ceat_users');
                
                $table =  $this->datatables->generate();

		

		return $table;

	}    
	
	public function GetAllNominees_filter(){
		
		$arr = Array();
		
		$arr['list'] = "";
		
                //$this->datatables->set_database("default");
		$this->datatables->select('id,memberid,name,mobile,email,cname,applyfor,created') 
            ->edit_column('name', '<a href="'.base_url().'nomineedetails?id=$1">$2</a>', 'id,name') 
            ->from('ceat_nominee');
		
        $table =  $this->datatables->generate();
		
		return $table;
	}
	
	public function GetAllElection_filter(){
		
		$arr = Array();
		
		$arr['list'] = "";
		
                //$this->datatables->set_database("default");
		$this->datatables->select('id,userid,name,designation,created') 
            ->from('ceat_election');
		
        $table =  $this->datatables->generate();
		
		return $table;
	}
	
	public function GetAllPresentation_filter(){
		
		$arr = Array();
		
		$arr['list'] = "";
		
                //$this->datatables->set_database("default");
		$this->datatables->select('id,confregno,iacdeno,name,mobile,email,pfile,created,ceat_presentationsession.sessionno') 
			 ->edit_column('pfile', '<a href="http://harveedesigns.in/ceatuploads/download.php?id=$1&file=$2&sessionno=$3">Download</a>', 'confregno,pfile,sessionno')
			->join('ceat_presentationsession', 'ceat_presentationsession.regno=ceat_presentation.confregno', 'LEFT')
            ->from('ceat_presentation');
		
        $table =  $this->datatables->generate();
		
		return $table;
	}
    
	public function GetAllAnnualmeetCount() {
       	
	    $arr = Array();
				    
       	$query = $this-> db -> query('select id from ceat_annualmeet');
       	$row = $query->result_array();
	    $arr['member_count'] = count($row);
	    return $arr;
        
    }
	
	public function GetAllAnnualmeet_filter(){
		
		$arr = Array();
		
		$arr['list'] = "";
		
                //$this->datatables->set_database("default");
		$this->datatables->select('name,email,mobile,institution,created') 
            ->from('ceat_annualmeet');
		
        $table =  $this->datatables->generate();
		
		return $table;
	}
	
	public function GetConfMemberProfile($memberid) {
		
		$arr = Array();
       	   		    
       	$query = $this-> db -> query('select memtype,regno,memberid,name,dob,gender,mobile,phone,email,address,contactaddress,contactcity,contactstate,contactpin,college,designation,paymenttime,paymentamount,paymentmode,organisation,proof,remarks,paymentdate,paymentphoto from ceat_confregistration where id="'.$memberid.'"');
       	$row = $query->result_array();
		if($row){
			$arr['memid'] = $row[0]['memberid'];
            $arr['memtype'] = $row[0]['memtype'];
            $arr['regno'] = $row[0]['regno'];
            $arr['name'] = $row[0]['name'];
            $arr['dob'] = $row[0]['dob'];
            $arr['sex'] = $row[0]['gender'];
			$arr['mobile'] = $row[0]['mobile'];
			$arr['phone'] = $row[0]['phone'];
			$arr['email'] = $row[0]['email'];
			$arr['address'] = $row[0]['address'];
			$arr['contactaddress'] = $row[0]['contactaddress'];
			$arr['contactcity'] = $row[0]['contactcity'];
			$arr['contactstate'] = $row[0]['contactstate'];
			$arr['contactpin'] = $row[0]['contactpin'];			
			$arr['college'] = $row[0]['college'];
			$arr['designation'] = $row[0]['designation'];
			$arr['organisation'] = $row[0]['organisation'];
		$arr['proof'] = $row[0]['proof'];
		$arr['remarks'] = $row[0]['remarks'];
            $arr['paymenttime'] = $row[0]['paymenttime'];
            $arr['paymentamount'] = $row[0]['paymentamount'];
            $arr['paymentmode'] = $row[0]['paymentmode'];
			$arr['paymentdate'] = $row[0]['paymentdate'];
			$arr['paymentphoto'] = $row[0]['paymentphoto'];
            
					
		}
		return $arr;
    }
	
	public function GetPreconfMemberProfile($memberid) {
		
		$arr = Array();
		
		$arr['memtype'] = "";
		$arr['regno'] = "";
       	   		    
       	$query = $this-> db -> query('select pr.* from ceat_preconfregistration as pr where pr.id="'.$memberid.'"');
       	$row = $query->result_array();
		if($row){
			
			$regid = $row[0]['regid'];
			
			$query1 = $this-> db -> query('select c.memtype,c.regno from ceat_confregistration as c where c.id="'.$regid.'"');
			$row1 = $query1->result_array();
			if($row1){
				$arr['memtype'] = $row1[0]['memtype'];
				$arr['regno'] = $row1[0]['regno'];
			}
			
            $arr['name'] = $row[0]['name'];
            $arr['sex'] = $row[0]['gender'];
			$arr['mobile'] = $row[0]['mobile'];
			$arr['phone'] = $row[0]['phone'];
			$arr['email'] = $row[0]['email'];
			$arr['address'] = $row[0]['address'];
			$arr['city'] = $row[0]['city'];
			$arr['state'] = $row[0]['state'];
			$arr['pincode'] = $row[0]['pincode'];			
			$arr['designation'] = $row[0]['designation'];
			$arr['organisation'] = $row[0]['organisation'];
            $arr['paymenttime'] = $row[0]['paymenttime'];
            $arr['paymentamount'] = $row[0]['paymentamount'];
            $arr['paymentmode'] = $row[0]['paymentmode'];
			$arr['paymentdate'] = $row[0]['paymentdate'];
			$arr['paymentphoto'] = $row[0]['paymentphoto'];
			
			$preconfname = $row[0]['preconfname'];
			$preconfamount =  $row[0]['preconfamount'];
			
			$preconfarr = array_filter(explode('|',$preconfname));
            $preconfamount = array_filter(explode('|',$preconfamount));
			
			$arr['preconfname'] = '<span1 style="color:#333">';
			foreach($preconfarr as $key=>$confname){
				
				$arr['preconfname'] .= $confname.' - &#8377; '.$preconfamount[$key].'<br />';
			}
			
			$arr['preconfname'] .= '</span1>';
					
		}
		return $arr;
    }
	
	public function GetNomineesProfile($memberid) {
		
		$arr = Array();
       	   		    
       	$query = $this-> db -> query('select * from ceat_nominee where id="'.$memberid.'"');
       	$row = $query->result_array();
		if($row){
            $arr['memberid'] = $row[0]['memberid'];
            $arr['name'] = $row[0]['name'];
			$arr['mobile'] = $row[0]['mobile'];
			$arr['email'] = $row[0]['email'];
			$arr['cname'] = $row[0]['cname'];
            $arr['appby'] = $row[0]['appby'];
            $arr['applyfor'] = $row[0]['applyfor'];
            $arr['cv'] = $row[0]['cv'];
			$arr['casefiles'] = $row[0]['casefiles'];
			$arr['created'] = $row[0]['created'];
					
		}
		return $arr;
    }
	
	public function GetPGMemberProfile($memberid) {
		
		$arr = Array();
       	   		    
       	$query = $this-> db -> query('select id,type,name,phone,email,city,state,college,dcino,paymenttime,paymentamount,paymentmode,paymentid,paymentstatus,created from ceat_regform where id="'.$memberid.'"');
       	$row = $query->result_array();
		if($row){
			$arr['id'] = $row[0]['id'];
            $arr['type'] = $row[0]['type'];
            $arr['name'] = $row[0]['name'];
			$arr['phone'] = $row[0]['phone'];
			$arr['email'] = $row[0]['email'];
			$arr['city'] = $row[0]['city'];
			$arr['state'] = $row[0]['state'];
			$arr['college'] = $row[0]['college'];
			$arr['dcino'] = $row[0]['dcino'];
            $arr['paymenttime'] = $row[0]['paymenttime'];
            $arr['paymentamount'] = $row[0]['paymentamount'];
            $arr['paymentmode'] = $row[0]['paymentmode'];
			$arr['paymentid'] = $row[0]['paymentid'];
			$arr['paymentstatus'] = $row[0]['paymentstatus'];
            
					
		}
		return $arr;
    }
	
	public function CreateRegistrants($title,$name,$userid,$role,$age,$mobile,$phone,$email,$gender,$address,$contactcity,$contactstate,$contactpin,$college,$designation,$organisation,$payamount,$paymode,$payid) {
		
		$result = array(0 => "");
		
		$query = $this-> db -> query('select memberid from ceat_confregistration where memberid="'.$userid.'" and paymentstatus="captured"');
		$row = $query->result_array();
		if($row){
		
			$result = array(0 => "exists");
            return $result;
		
		}else{
			
			$offset=5*60*60 + 30*60;
			$dateformat = 'Y-m-d_H-i-s';
			$curtime = gmdate($dateformat, time()+$offset);

			$id = uniqid();
			
			 $query1 = $this-> db -> query('select regno from ceat_confregistration where paymentstatus="captured" and regno<>"" ');
			 $rowcount = $query1->num_rows();
			 $input = $rowcount + 1 ;
			 $rowcount = str_pad($input, 4, "0", STR_PAD_LEFT);
			 $regno = "SZC".$rowcount;

		
			$query2  = $this-> db -> query('insert into ceat_confregistration (`id`,`memberid`,`memtype`,`title`,`name`,`age`,`gender`,`mobile`,`phone`,`email`,`address`,`contactcity`,`contactstate`,`contactpin`,`organisation`,`paymentmode`,`designation`,`paymentamount`,`paymentid`,`paymentstatus`,`paymenttime`,`regno`,`college`) values ("'.$id.'","'.$userid.'","'.$role.'","'.$title.'","'.$name.'","'.$age.'","'.$gender.'","'.$mobile.'","'.$phone.'","'.$email.'","'.$address.'","'.$contactcity.'","'.$contactstate.'","'.$contactpin.'","'.$organisation.'","'.$paymode.'","'.$designation.'","'.$payamount.'","'.$payid.'","captured","'.$curtime.'","'.$regno.'","'.$college.'")');
			
			if($query2){
				
				$this->Emailconfirmation($id);
				$result = array(0 => "success");
            	return $result;
			}
			
		}
		
		return $result;
		
	}
	
public function Emailconfirmation($refno){
	
		$todaydate = date('d-m-Y');
		$confdate = date('d-m-Y',strtotime('2018-08-01'));

		if(strtotime($todaydate) >= strtotime($confdate))
		{
			$Delegates = 7000;
			$Students = 6000;
		}
		else{
			$Delegates = 6000;
			$Students = 5000;
		}
	
$query = $this-> db -> query('select * from ceat_confregistration where id="'.$refno.'"');
$row = $query->result_array();

if($row)
{
	$memtype = $row[0]['memtype'];
	$title = $row[0]['title'];
	$name = $row[0]['name'];
	$mobile = $row[0]['mobile'];
	$email = $row[0]['email'];
	$regno = $row[0]['regno'];
	
	$payamount = $row[0]['paymentamount'];
	$paymentstatus = $row[0]['paymentstatus'];
	$created = $row[0]['paymenttime'];
	
	$created = date("d-m-Y H:i:s A",strtotime($created));
	
	
	if($paymentstatus=="captured")$status = "Payment Successful"; else $status = "Payment failed";
	
	
	$body = "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.=
w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\"><html><head><meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\"></head><body>

<table style=\"background:#fff;border:1px solid #E8E8E8; border-radius:15px; border-collapse:collapse; overflow:hidden;padding:10px;margin:0 auto; font-size: 15px; width:600px\"><tbody>

<tr><td style=\"text-align:center; width:600px; color:#333; padding:20px;\"><img src=\"http://www.theceat.com/images/logo.jpg\" alt=\"CEAT\" width=\"137px\"></td></tr>

<tr><td style=\"text-align:center;font-size:18px;line-height:33px;color:#333;\"><strong>Conservative and Endodontic Association of Tamilnadu - Annual Conference</strong></td></tr>

<tr><td style=\"text-align:center;font-size:18px;line-height:33px;color:#333;\">Payment receipt</td></tr>

<tr><td>&nbsp;</td></tr>

<tr ><td style=\"text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;\"><p style=\"float:left\">Reg No : ".$regno."</p><p style=\"float:right;margin-right:5px;\"> Date: ".$created."</p></td></tr>

<tr><td style=\"text-align:justify;font-size:14px;line-height:25px;padding:0 10px;color:#333;\">Received with thanks from <strong>".$title.". ".$name."</strong> a sum of <strong>&#8377; ".$payamount."</strong> towards Conference Registration (Conservative and Endodontic Association of Tamilnadu - Annual Conference).</td></tr>

<tr><td>&nbsp;</td></tr>
<tr><td style=\"text-align:left; padding-left:10px;  color:#333;\">Regards<br>CEAT</td></tr>
<tr style=\"background:#EEEEEE; font-size: 12px;\"><td style=\"text-align:center; padding:10px 20px;  color:#999;\">Copyright &copy; ".date('Y')." CEAT. All Rights Reserved. <a style=\"color:#0986C5; text-decoration:none;\" href=\"http://www.theceat.com/\">www.theceat.com</a></td></tr>

</tbody></table>

</body></html>";


$subject = "CEAT Conference Registration - Successfull";
$toemail = $email;
$fromname = "CEAT Conference";
$replyto = "ceatfamily@gmail.com";
$subject = $subject;
$pname = "CEAT";

$finalbody = urlencode($body);


$substr = 'webtag=Theri&toemail='.$toemail.'&fromname='.$fromname."&replyto=".$replyto."&pname=".$pname."&subject=".$subject."&body=".$finalbody;

$url = "http://35.88.44.130/sendmail?";

$ch = curl_init($url);

curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, $substr);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_HEADER, 0);  // DO NOT RETURN HTTP HEADERS 
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);  // RETURN THE CONTENTS OF THE CALL

$return_val = curl_exec($ch);
	

			$messTemplate = 'uname=harvee1&pass=g~I)n!g2&send=CEATtn&dest=NuMbER&msg=Dear%20[MeMbEr],%20You%20have%20successfully%20registered%20for%20the%201st%20IACDE%20Zonal%20Conference%20-%20South%20Zone%20,%20your%20registration%20id:%20[ReGnO].%20For%20queries:%209884310206.';

			$substr = $messTemplate;

			$searchFOr = 'NuMbER';
			$replacewith = $mobile;
			$substr = str_replace($searchFOr, $replacewith, $substr);

			$searchFOr = '[MeMbEr]';
			$replacewith = $name;
			$substr = str_replace($searchFOr, $replacewith, $substr);

			$searchFOr = '[ReGnO]';
			$replacewith = $regno;
			$substr = str_replace($searchFOr, $replacewith, $substr);


			$url = "https://instaalerts.zone/SendSMS/sendmsg.php?";

			$ch = curl_init($url);


			curl_setopt($ch, CURLOPT_POST, 1);
			curl_setopt($ch, CURLOPT_POSTFIELDS, $substr);
			curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
			curl_setopt($ch, CURLOPT_HEADER, 0);  // DO NOT RETURN HTTP HEADERS 
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);  // RETURN THE CONTENTS OF THE CALL

			$return_val = curl_exec($ch);

            $this->sendMailSMStoAdmin($refno,$name,$mobile,$email,$payamount,$created,$status,$regno,$memtype);


}

}

public function sendMailSMStoAdmin($refno,$name,$mobile,$email,$payamount,$created,$status,$regno,$memtype) {
	
		$body = "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.=
w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\"><html><head><meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\"></head><body>

<table style=\"background:#fff;border:1px solid #e5e5e5;border-collapse:collapse;padding-top:4px;margin:1.5em auto;width:600px\"><tbody>

<tr><td style=\"text-align:center;font-size:18px;line-height:33px;color:#333;\"><img src=\"http://www.theceat.com/images/logo.jpg\" /></td></tr>

<tr><td style=\"text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;\">We have a successfully got a ".$memtype." registration</td></tr>

<tr><td style=\"text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;\"><strong>Name <span style=\"margin-left: 73px;\">:</span> </strong> ".$name."</td></tr>

<tr><td style=\"text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;\"><strong>Mobile <span style=\"margin-left: 64px;\">:</span> </strong> ".$mobile."</td></tr>

<tr><td style=\"text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;\"><strong>Email <span style=\"margin-left: 76px;\">:</span></strong> ".$email."</td></tr>

<tr><td style=\"text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;\"><strong>Registration ID <span style=\"margin-left: 10px;\">:</span> </strong> ".$regno."</td></tr>

<tr><td style=\"text-align:left;font-size:14px;line-height:20px;padding-left:10px;color:#333;\">Regards <br/>CEAT</td></tr>

</tbody></table>

</body></html>";


$subject = "CEAT Conference Registration - Successfull";
$toemail = "ceatfamily@gmail.com";
$bccmail = "harish@harvee.co.uk";
	//$bccmail = "";
	//$toemail = "krishnan@harvee.co.uk";
$fromname = "CEAT Conference";
$replyto = "";
$subject = $subject;
$pname = "CEAT";

$finalbody = urlencode($body);


$substr = 'webtag=Theri&toemail='.$toemail.'&fromname='.$fromname."&replyto=".$replyto."&pname=".$pname."&subject=".$subject."&bccmail=".$bccmail."&body=".$finalbody;

$url = "http://35.88.44.130/sendmail?";

$ch = curl_init($url);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, $substr);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_HEADER, 0);  // DO NOT RETURN HTTP HEADERS 
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);  // RETURN THE CONTENTS OF THE CALL

$return_val = curl_exec($ch);
	
	
			$dest = "9884310206,9444192005,9894276263";
			//$mobile= "9629090346";

			$messTemplate = 'uname=harvee1&pass=g~I)n!g2&send=CEATtn&dest=NuMbER&msg=We%20have%20a%20successfully%20got%20 a%20[MeMbErTyPe]%20registration%20[NaMe]%20[MoBiLe]%20and%20[EmAiLiD].%20Registration%20ID:%20[ReGnO].';

			$substr = $messTemplate;

			$searchFOr = 'NuMbER';
			$replacewith = $dest;
			$substr = str_replace($searchFOr, $replacewith, $substr);

			$searchFOr = '[MeMbErTyPe]';
			$replacewith = $memtype;
			$substr = str_replace($searchFOr, $replacewith, $substr);
	
			$searchFOr = '[NaMe]';
			$replacewith = $name;
			$substr = str_replace($searchFOr, $replacewith, $substr);
	
			$searchFOr = '[MoBiLe]';
			$replacewith = $mobile;
			$substr = str_replace($searchFOr, $replacewith, $substr);
	
			$searchFOr = '[EmAiLiD]';
			$replacewith = $email;
			$substr = str_replace($searchFOr, $replacewith, $substr);
	
			$searchFOr = '[ReGnO]';
			$replacewith = $regno;
			$substr = str_replace($searchFOr, $replacewith, $substr);
	
	
			$url = "https://instaalerts.zone/SendSMS/sendmsg.php?";

			$ch = curl_init($url);
			curl_setopt($ch, CURLOPT_POST, 1);
			curl_setopt($ch, CURLOPT_POSTFIELDS, $substr);
			curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
			curl_setopt($ch, CURLOPT_HEADER, 0);  // DO NOT RETURN HTTP HEADERS 
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);  // RETURN THE CONTENTS OF THE CALL

			$return_val = curl_exec($ch);


        }
	
	
	//Test
	
	public function GetAllTestRegistrantCount() {
       	
	    $arr = Array();
				    
       	$query = $this-> db -> query('select id from ceat_testregistration where paymentstatus="SUCCESS"');
       	$row = $query->result_array();
	    $arr['member_count'] = count($row);
	    return $arr;
        
    }
    
    public function GetAllTestRegistrant_filter(){
		
		$arr = Array();
		
		$arr['list'] = "";
		
                //$this->datatables->set_database("default");
		$this->datatables->select('id,acdiuserid,name,phone,email,paymentamount,paymenttime') 
            ->edit_column('acdiuserid', '<a href="'.base_url().'testmemberpage?id=$1">$2</a>', 'id,acdiuserid') 
            ->edit_column('name', '<a href="'.base_url().'testmemberpage?id=$1">$2</a>', 'id,name') 
            ->from('ceat_testregistration')->where('paymentstatus',"SUCCESS");           
        $table =  $this->datatables->generate();
		
		return $table;
	}
    
    
	
	public function GetTestMemberProfile($memberid) {
		
		$arr = Array();
       	   		    
       	$query = $this-> db -> query('select confid,acdiuserid,name,age,phone,email,qualification,paymenttime,paymentamount,paymentmode,paymentid from ceat_testregistration where id="'.$memberid.'"');
       	$row = $query->result_array();
		if($row){
            $arr['userid'] = $row[0]['acdiuserid'];
            $arr['name'] = $row[0]['name'];
            $arr['dob'] = $row[0]['age'];
			$arr['phone'] = $row[0]['phone'];
			$arr['email'] = $row[0]['email'];
			$arr['qualification'] = $row[0]['qualification'];
            $arr['paymenttime'] = $row[0]['paymenttime'];
            $arr['paymentamount'] = $row[0]['paymentamount'];
            $arr['paymentmode'] = $row[0]['paymentmode'];
			$arr['paymentid'] = $row[0]['paymentid'];
            
					
		}
		return $arr;
    }
	
	public function searchconfbyNameorid($name,$regno) {
       	
		$arr = '';
		
		$whereclause = "";
		
		if($name!="") $whereclause = 'and name LIKE "%'.$name.'%"';
		
		if($regno!="") $whereclause = 'and regno LIKE "%'.$regno.'%"';
		
		if($name!="" && $regno!="") $whereclause = 'and name LIKE "%'.$name.'%" and regno LIKE "%'.$regno.'%"';
				
		$query = $this-> db -> query('select regno,name from ceat_confregistration where paymentstatus="captured" '.$whereclause);
       	$row = $query->result_array();
			
		if($row) {
			
			$arr = '<table id="confListsearch"><tbody>
					<tr>
					  <th scope="col">Reg No</th>
					  <th scope="col">Name</th>
					</tr>';
						
			for( $j = 0; $j < count($row);$j++) {
				
				$name = $row[$j]['name'];
				$regno = $row[$j]['regno'];								
				
				$arr .= '<tr><td>'.$regno.'</td><td>'.$name.'</td></tr>';
				
			}
			
			$arr .= '</tbody></table>';
		}
		else{
			$arr .= '<table id="confListsearch"><tr><td colspan="2" style="text-align: center;">Member not found.</td></table>';
		}
		
		return $arr;
		
    }
	
	public function GetConfUserDetails($regno) {
		
		$arr = Array();
		
		$query = $this-> db -> query('select regno,memberid,name,mobile,email,organisation from ceat_confregistration where paymentstatus="captured" and regno="'.$regno.'" ');
       	$row = $query->result_array();
			
		if($query->num_rows()==1) {
			
			$arr['name'] = $row[0]['name'];
			$arr['regno'] = $row[0]['regno'];
			$arr['userid'] = $row[0]['memberid'];
			$arr['mobile'] = $row[0]['mobile'];
			$arr['email'] = $row[0]['email'];
			$arr['organisation'] = $row[0]['organisation'];
			
		}
		
		return $arr;
		
	}
	
	public function GetAbstractDetails($regno) {
		
		$arr = Array();
		
		$query = $this-> db -> query('select regno,iacdeno,name,contactnumber,email,authors,title,abstract from ceat_abstract where regno="'.$regno.'" ');
       	$row = $query->result_array();
			
		if($query->num_rows()==1) {
			
			$arr['name'] = $row[0]['name'];
			$arr['regno'] = $row[0]['regno'];
			$arr['iacdeno'] = $row[0]['iacdeno'];
			$arr['mobile'] = $row[0]['contactnumber'];
			$arr['email'] = $row[0]['email'];
			$arr['title'] = $row[0]['title'];
			$arr['authors'] = $row[0]['authors'];
			$arr['abstract'] = $row[0]['abstract'];
			
		}
		
		return $arr;
		
	}
	
	public function SubmitAbstract($id,$name,$mobile,$email,$iacdeno,$regno,$title,$authors,$abstract,$regcategory,$institution,$bfileName,$pcategory,$subject,$ptype,$pfileName,$comments){
		
		$result = array(0=>"");
		
		$query0 = $this-> db -> query('select regno from ceat_abstract where regno="'.$regno.'" and iacdeno="'.$iacdeno.'"');
		$row0 = $query0->result_array();
		if($row0){
		
			$result = array(0 => "exists");
            return $result;
		
		}
		
		$abstract = htmlspecialchars($abstract);
		
		$query = $this-> db -> query('insert into ceat_abstract (`id`, `name`, `email`, `contactnumber`, `iacdeno`, `regno`, `regcategory`, `institution`, `bonafiedcert`, `pcategory`, `subject`, `ptype`, `title`, `authors`, `abstract`, `photo`, `comments`) values ("'.$id.'","'.$name.'","'.$email.'","'.$mobile.'","'.$iacdeno.'","'.$regno.'","'.$regcategory.'","'.$institution.'","'.$bfileName.'","'.$pcategory.'","'.$subject.'","'.$ptype.'","'.$title.'","'.$authors.'","'.$abstract.'","'.$pfileName.'","'.$comments.'")');
		
		if($query){
			
			$result = array(0=>"success");
			return $result;
			
		}else{
			$result = array(0=>"fail");
			return $result;
		}		
		
		return $result;
		
	}
	
	public function SubmitPresentation($id,$name,$mobile,$email,$iacdeno,$regno,$pfileName){
		
		$result = array(0=>"");
		
		$query0 = $this-> db -> query('select confregno from ceat_presentation where confregno="'.$regno.'" and iacdeno="'.$iacdeno.'"');
		$row0 = $query0->result_array();
		if($row0){
		
			$result = array(0 => "exists");
            return $result;
		
		}
		
		$offset=5*60*60 + 30*60;
		$dateformat = 'Y-m-d H:i:s';
		$curtime = gmdate($dateformat, time()+$offset);
		
		$query = $this-> db -> query('insert into ceat_presentation (`id`, `name`, `email`, `mobile`, `iacdeno`, `confregno`, `pfile`,`created`) values ("'.$id.'","'.$name.'","'.$email.'","'.$mobile.'","'.$iacdeno.'","'.$regno.'","'.$pfileName.'","'.$curtime.'")');
		
		if($query){
			
			$this->PresentationConfirmation($name,$email,$mobile,$iacdeno,$regno);
			
			$result = array(0=>"success");
			return $result;
			
		}else{
			$result = array(0=>"fail");
			return $result;
		}		
		
		return $result;
		
	}
	
public function PresentationConfirmation($name,$email,$mobile,$iacdeno,$regno){	
	
	$body = "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.=
w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\"><html><head><meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\"></head><body>

<table style=\"background:#fff;border:1px solid #E8E8E8; border-radius:15px; border-collapse:collapse; overflow:hidden;padding:10px;margin:0 auto; font-size: 15px; width:600px\"><tbody>

<tr><td style=\"text-align:center; width:600px; color:#333; padding:20px;\"><img src=\"http://www.theceat.com/images/logo.jpg\" alt=\"CEAT\" width=\"137px\"></td></tr>

<tr><td style=\"text-align:center;font-size:18px;line-height:33px;color:#333;\"><strong>Conservative and Endodontic Association of Tamilnadu - Annual Conference</strong></td></tr>

<tr><td style=\"text-align:center;font-size:18px;line-height:33px;color:#333;\">Presentation Upload</td></tr>

<tr><td>&nbsp;</td></tr>

<tr ><td style=\"text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;\"><p style=\"float:left\">Reg No : ".$regno."</p></td></tr>

<tr><td style=\"text-align:justify;font-size:14px;line-height:25px;padding:0 10px;color:#333;\">Your presentation submitted successfully.</td></tr>

<tr><td>&nbsp;</td></tr>
<tr><td style=\"text-align:left; padding-left:10px;  color:#333;\">Regards<br>CEAT</td></tr>
<tr style=\"background:#EEEEEE; font-size: 12px;\"><td style=\"text-align:center; padding:10px 20px;  color:#999;\">Copyright &copy; ".date('Y')." CEAT. All Rights Reserved. <a style=\"color:#0986C5; text-decoration:none;\" href=\"http://www.theceat.com/\">www.theceat.com</a></td></tr>

</tbody></table>

</body></html>";


$subject = "CEAT Presentation Confirmation";
$toemail = $email;
	$bccmail = "harish@harvee.co.uk,drkrithikadatta@hotmail.com";
$fromname = "CEAT Presentation";
$replyto = "ceatfamily@gmail.com";
$subject = $subject;
$pname = "CEAT";

$finalbody = urlencode($body);


$substr = 'webtag=Theri&toemail='.$toemail.'&fromname='.$fromname."&replyto=".$replyto."&pname=".$pname."&subject=".$subject."&bccmail=".$bccmail."&body=".$finalbody;

$url = "http://35.88.44.130/sendmail?";

$ch = curl_init($url);

curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, $substr);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_HEADER, 0);  // DO NOT RETURN HTTP HEADERS 
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);  // RETURN THE CONTENTS OF THE CALL

$return_val = curl_exec($ch);

}
	
	
public function SubmitContest($id,$name,$mobile,$email,$collegename,$food,$bfileName,$pfileName){
		
		$result = array(0=>"");
		
		$query0 = $this-> db -> query('select mobile from ceat_starcontest where mobile="'.$mobile.'" or email="'.$email.'"');
		$row0 = $query0->result_array();
		if($row0){
		
			$result = array(0 => "exists");
            return $result;
		
		}
	
		$offset=5*60*60 + 30*60;
		$dateformat = 'Y-m-d H:i:s';
		$curtime = gmdate($dateformat, time()+$offset);
	
		//$abstract = htmlspecialchars($abstract);
		
		$query = $this-> db -> query('insert into ceat_starcontest (`id`, `name`, `email`, `mobile`, `college`, `food`, `bonafiedcert`, `marksheet`, `created`) values ("'.$id.'","'.$name.'","'.$email.'","'.$mobile.'","'.$collegename.'","'.$food.'","'.$bfileName.'","'.$pfileName.'","'.$curtime.'")');
		
		if($query){
			
			$this->ContestConfirmation($id,$name,$email,$mobile,$collegename,$food,$curtime);
			
			$result = array(0=>"success");
			return $result;
			
		}else{
			$result = array(0=>"fail");
			return $result;
		}		
		
		return $result;
		
	}
	
public function ContestConfirmation($id,$name,$email,$mobile,$collegename,$food,$created){	
	
	$body = "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.=
w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\"><html><head><meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\"></head><body>

<table style=\"background:#fff;border:1px solid #E8E8E8; border-radius:15px; border-collapse:collapse; overflow:hidden;padding:10px;margin:0 auto; font-size: 15px; width:600px\"><tbody>

<tr><td style=\"text-align:center; width:600px; color:#333; padding:20px;\"><img src=\"http://www.theceat.com/images/logo.jpg\" alt=\"CEAT\" width=\"137px\"></td></tr>

<tr><td style=\"text-align:center;font-size:18px;line-height:33px;color:#333;\"><strong>Conservative and Endodontic Association of Tamilnadu - Annual Conference</strong></td></tr>

<tr><td>&nbsp;</td></tr>

<tr><td style=\"text-align:justify;font-size:14px;line-height:25px;padding:0 10px;color:#333;\"> Budding Star Contest registered successfully.</td></tr>

<tr ><td style=\"text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;\"><p style=\"float:left\">Reference No : ".$id."</p><p style=\"float:right;margin-right:5px;\"> Date: ".date("d-m-Y h:i:s A",strtotime($created))."</p></td></tr>

<tr><td>&nbsp;</td></tr>
<tr><td style=\"text-align:left; padding-left:10px;  color:#333;\">Regards<br>CEAT</td></tr>
<tr style=\"background:#EEEEEE; font-size: 12px;\"><td style=\"text-align:center; padding:10px 20px;  color:#999;\">Copyright &copy; ".date('Y')." CEAT. All Rights Reserved. <a style=\"color:#0986C5; text-decoration:none;\" href=\"http://www.theceat.com/\">www.theceat.com</a></td></tr>

</tbody></table>

</body></html>";


$subject = "CEAT Budding Star Contest Confirmation";
$toemail = $email;
	$bccmail = "harish@harvee.co.uk,ceatfamily@gmail.com";
	//$bccmail = "";
$fromname = "CEAT Budding Star Contest";
$replyto = "ceatfamily@gmail.com";
$subject = $subject;
$pname = "CEAT";

$finalbody = urlencode($body);


$substr = 'webtag=Theri&toemail='.$toemail.'&fromname='.$fromname."&replyto=".$replyto."&pname=".$pname."&subject=".$subject."&bccmail=".$bccmail."&body=".$finalbody;

$url = "http://35.88.44.130/sendmail?";

$ch = curl_init($url);

curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, $substr);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_HEADER, 0);  // DO NOT RETURN HTTP HEADERS 
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);  // RETURN THE CONTENTS OF THE CALL

$return_val = curl_exec($ch);
	
	
			$messTemplate = 'uname=harvee1&pass=g~I)n!g2&send=CEATtn&dest=NuMbER&msg=Dear%20[MeMbEr],%20You%20have%20successfully%20registered%20for%20the%20Budding%20Star%20Contest.';

			$substr = $messTemplate;

			$searchFOr = 'NuMbER';
			$replacewith = $mobile;
			$substr = str_replace($searchFOr, $replacewith, $substr);

			$searchFOr = '[MeMbEr]';
			$replacewith = $name;
			$substr = str_replace($searchFOr, $replacewith, $substr);

			/*$searchFOr = '[ReGnO]';
			$replacewith = $regno;
			$substr = str_replace($searchFOr, $replacewith, $substr);*/


			$url = "https://instaalerts.zone/SendSMS/sendmsg.php?";

			$ch = curl_init($url);


			curl_setopt($ch, CURLOPT_POST, 1);
			curl_setopt($ch, CURLOPT_POSTFIELDS, $substr);
			curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
			curl_setopt($ch, CURLOPT_HEADER, 0);  // DO NOT RETURN HTTP HEADERS 
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);  // RETURN THE CONTENTS OF THE CALL

			$return_val = curl_exec($ch);
	
	$this->ContestConfirmationAdmin($name,$email,$mobile,$collegename,$food);

}
	
public function ContestConfirmationAdmin($name,$email,$mobile,$collegename,$food){	
	
	$body = "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.=
w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\"><html><head><meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\"></head><body>

<table style=\"background:#fff;border:1px solid #E8E8E8; border-radius:15px; border-collapse:collapse; overflow:hidden;padding:10px;margin:0 auto; font-size: 15px; width:600px\"><tbody>

<tr><td style=\"text-align:center; width:600px; color:#333; padding:20px;\"><img src=\"http://www.theceat.com/images/logo.jpg\" alt=\"CEAT\" width=\"137px\"></td></tr>

<tr><td style=\"text-align:center;font-size:18px;line-height:33px;color:#333;\"><strong>Conservative and Endodontic Association of Tamilnadu - Annual Conference</strong></td></tr>

<tr><td>&nbsp;</td></tr>

<tr><td style=\"text-align:justify;font-size:14px;line-height:25px;padding:0 10px;color:#333;\"> We have successfully got a Budding Star Contest registration.</td></tr>

<tr><td style=\"text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;\"><strong>Name <span style=\"margin-left: 78px;\">:</span> </strong> ".$name."</td></tr>

<tr><td style=\"text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;\"><strong>Mobile <span style=\"margin-left: 72px;\">:</span> </strong> ".$mobile."</td></tr>

<tr><td style=\"text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;\"><strong>Email <span style=\"margin-left: 78px;\">:</span></strong> ".$email."</td></tr>

<tr><td style=\"text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;\"><strong>College Name <span style=\"margin-left: 30px;\">:</span></strong> ".$collegename."</td></tr>

<tr><td style=\"text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;\"><strong>Food Preference<span style=\"margin-left: 19px;\">:</span></strong> ".$food."</td></tr>

<tr><td>&nbsp;</td></tr>
<tr><td style=\"text-align:left; padding-left:10px;  color:#333;\">Regards<br>CEAT</td></tr>
<tr style=\"background:#EEEEEE; font-size: 12px;\"><td style=\"text-align:center; padding:10px 20px;  color:#999;\">Copyright &copy; ".date('Y')." CEAT. All Rights Reserved. <a style=\"color:#0986C5; text-decoration:none;\" href=\"http://www.theceat.com/\">www.theceat.com</a></td></tr>

</tbody></table>

</body></html>";


$subject = "CEAT Budding Star Contest Confirmation";
$toemail = "ceatfamily@gmail.com";
	$bccmail = "harish@harvee.co.uk";
	//$bccmail = "";
$fromname = "CEAT Budding Star Contest";
$replyto = "ceatfamily@gmail.com";
$subject = $subject;
$pname = "CEAT";

$finalbody = urlencode($body);


$substr = 'webtag=Theri&toemail='.$toemail.'&fromname='.$fromname."&replyto=".$replyto."&pname=".$pname."&subject=".$subject."&bccmail=".$bccmail."&body=".$finalbody;

$url = "http://35.88.44.130/sendmail?";

$ch = curl_init($url);

curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, $substr);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_HEADER, 0);  // DO NOT RETURN HTTP HEADERS 
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);  // RETURN THE CONTENTS OF THE CALL

$return_val = curl_exec($ch);
	

}
	
	public function GetAllAbstractRegistrantCount() {
       	
	    $arr = Array();
				    
       	$query = $this-> db -> query('select id from ceat_abstract where regno<>"" and iacdeno<>""');
       	$row = $query->result_array();
	    $arr['member_count'] = count($row);
	    return $arr;
        
    }
    
    public function GetAllAbstractRegistrant_filter(){
		
		$arr = Array();
		
		$arr['list'] = "";
		
                //$this->datatables->set_database("default");
		$this->datatables->select('id,regno,name,contactnumber,email') 
            ->edit_column('regno', '<a href="'.base_url().'abstractview?id=$1">$2</a>', 'id,regno') 
            ->edit_column('name', '<a href="'.base_url().'abstractview?id=$1">$2</a>', 'id,name') 
            ->from('ceat_abstract')->where('regno <>',"");           
        $table =  $this->datatables->generate();
		
		return $table;
	}
	
	public function GetAbstractProfile($id) {
		
		$arr = Array();
       	   		    
       	$query = $this-> db -> query('select `id`, `name`, `email`, `contactnumber`, `iacdeno`, `regno`, `regcategory`, `institution`, `bonafiedcert`, `pcategory`, `subject`, `ptype`, `title`, `authors`, `abstract`, `photo`, `comments` from ceat_abstract where id="'.$id.'"');
       	$row = $query->result_array();
		if($row){
            $arr['regno'] = $row[0]['regno'];
			$arr['iacdeno'] = $row[0]['iacdeno'];
            $arr['name'] = $row[0]['name'];
			$arr['mobile'] = $row[0]['contactnumber'];
			$arr['email'] = $row[0]['email'];
			$arr['regcategory'] = $row[0]['regcategory'];
            $arr['institution'] = $row[0]['institution'];
			$arr['bcert'] = $row[0]['bonafiedcert'];
			$arr['pcategory'] = $row[0]['pcategory'];
			$arr['subject'] = $row[0]['subject'];
			$arr['ptype'] = $row[0]['ptype'];
			$arr['title'] = $row[0]['title'];			
			$arr['authors'] = $row[0]['authors'];
			$arr['abstract'] = $row[0]['abstract'];
            $arr['photo'] = $row[0]['photo'];
            $arr['comments'] = $row[0]['comments'];            
					
		}
		return $arr;
    }
	
	public function GetWaitingApprovalConfernece(){
		
		$arr = Array();
				    
       	$query = $this-> db -> query('select id,name,memtype,mobile,paymentmode,paymentid from ceat_confregistration where paymentid<>"" and status="open"');
       	$row = $query->result_array();
		$arr['conf_count'] = count($row);
		
		if($row) {
			
			$arr['conf_list'] = '<tr class="title"><td width="230">Name</td><td width="110">Membership Type</td><td width="110">Mobile No.</td><td>Payment Status</td><td>View</td></tr>';
						
			for( $j = 0; $j < count($row);$j++) {
				
				$id = $row[$j]['id'];
				$name = $row[$j]['name'];
				$memtype = $row[$j]['memtype'];
				$mobile = $row[$j]['mobile'];
				$paymentmode = $row[$j]['paymentmode'];
				$paymentid = $row[$j]['paymentid'];								
				
				$arr['conf_list'] .= '<tr><td>'.$name.'</td><td>'.$memtype.'</td><td>'.$mobile.'</td><td>'.$paymentmode.'- '.$paymentid.'</td><td><a style="text-decoration:underline" href="confapprovemember?id='.$id.'">view</a></td></tr>';
				
			}			
			
		}else{
			
			$arr['conf_list'] = '<tr><td colspan="4" style="text-align:center;">No Records Found</td></tr>';
			
		}
		
		return $arr;
		
	}
	
	public function GetConferenceApprovalDetails($memid){
		
		$arr = Array();
       	   		    
       	$query = $this-> db -> query('select memberid,memtype,title,name,age,dob,gender,mobile,phone,email,address,contactaddress,contactcity,contactstate,contactpin,qualification,college,designation,organisation,proof,remarks,paymentamount,paymentmode,paymentid,status,paymentdate,paymentphoto,paymentstatus from ceat_confregistration where id="'.$memid.'"');
       	$row = $query->result_array();
		
		$arr['id'] = $memid;
		$arr['memberid'] = $row[0]['memberid'];
		$arr['memtype'] = $row[0]['memtype'];
		$arr['title'] = $row[0]['title'];
		$arr['name'] = $row[0]['name'];
		$arr['age'] = $row[0]['age'];
		$arr['gender'] = $row[0]['gender'];
		$arr['mobile'] = $row[0]['mobile'];
		$arr['phone'] = $row[0]['phone'];
		$arr['email'] = $row[0]['email'];
		$arr['designation'] = $row[0]['designation'];
		$arr['organisation'] = $row[0]['organisation'];
		$arr['proof'] = $row[0]['proof'];
		$arr['remarks'] = $row[0]['remarks'];
		$arr['gender'] = $row[0]['gender'];
		$arr['address'] = $row[0]['address'];
		$arr['contactaddress'] = $row[0]['contactaddress'];
		$arr['contactstate'] = $row[0]['contactstate'];
		$arr['contactpin'] = $row[0]['contactpin'];
		$arr['contactcity'] = $row[0]['contactcity'];
		$arr['paymentamount'] = $row[0]['paymentamount'];
		$arr['modeofpay'] = $row[0]['paymentmode'];
		$arr['paymentid'] = $row[0]['paymentid'];
		$arr['paymentdate'] = $row[0]['paymentdate'];
		$arr['paymentphoto'] = $row[0]['paymentphoto'];
		$arr['paymentstatus'] = $row[0]['paymentstatus'];
		
		$arr['status'] = $row[0]['status'];
				
				$paymodearr = "DD,NEFT,ONLINE,CASH,card,netbanking,wallet,emi,upi,Offline";
				$paymodearr = explode(",",$paymodearr);
				$arr['paymentmode'] = '<option>Choose</option>';
				foreach ($paymodearr as $pmval) { 
					if($arr['modeofpay']==$pmval){
						$arr['paymentmode'] .= "<option selected>".$pmval."</option>";
					}else{
						$arr['paymentmode'] .= "<option>".$pmval."</option>";
					}	   				
				}
						
		return $arr;
		
	}
	
	public function DeleteConfMemberRequest($confid) {
		
		$query = $this-> db -> query('update ceat_confregistration set status="closed",paymentstatus="" where id="'.$confid.'"');
		
	}
	
	public function ConfApproveMemberRequest($approveid,$name,$title,$userid,$role,$mobile,$phone,$email,$gender,$age,$address,$organisation,$designation,$payamount,$paydate,$paymode,$payid,$city,$state,$pincode) {
		
		$result = array(0 => "");
		
		$query1 = $this-> db -> query('select regno from ceat_confregistration where paymentstatus="captured" and regno<>"" ');
		 $rowcount = $query1->num_rows();
		 $input = $rowcount + 1 ;
		 $rowcount = str_pad($input, 4, "0", STR_PAD_LEFT);
		 $regno = "SZC".$rowcount;
		
		$paydate = date('Y-m-d',strtotime($paydate));
		
		$query2  = $this-> db -> query('UPDATE `ceat_confregistration` SET `memberid`="'.$userid.'",`regno`="'.$regno.'",`memtype`="'.$role.'",`title`="'.$title.'",`name`="'.$name.'",`age`="'.$age.'",`gender`="'.$gender.'",`mobile`="'.$mobile.'",`phone`="'.$phone.'",`email`="'.$email.'",`address`="'.$address.'",`contactcity`="'.$city.'",`contactstate`="'.$state.'",`contactpin`="'.$pincode.'",`designation`="'.$designation.'",`organisation`="'.$organisation.'",`paymentmode`="'.$paymode.'",`paymentdate`="'.$paydate.'",`paymentstatus`="captured",`status`="approved" WHERE id="'.$approveid.'"');

		if($query2){
			
			$this->Emailconfirmation($approveid);
			$result = array(0 => "success");
			return $result;
		}
					
		return $result;
		
	}
	
	
	public function GetWaitingApprovalPreconfernece(){
		
		$arr = Array();
				    
       	$query = $this-> db -> query('select pr.id,pr.regid,pr.name,c.memtype,pr.mobile,pr.paymentmode,pr.paymentid from ceat_preconfregistration as pr,ceat_confregistration as c where pr.regid=c.id and pr.paymentid<>"" and pr.status="open"');
       	$row = $query->result_array();
		$arr['conf_count'] = count($row);
		
		if($row) {
			
			$arr['conf_list'] = '<tr class="title"><td width="230">Name</td><td width="110">Membership Type</td><td width="110">Mobile No.</td><td>Payment Status</td><td>View</td></tr>';
						
			for( $j = 0; $j < count($row);$j++) {
				
				$id = $row[$j]['id'];
				$regid = $row[$j]['regid'];
				$name = $row[$j]['name'];
				$memtype = $row[$j]['memtype'];
				$mobile = $row[$j]['mobile'];
				$paymentmode = $row[$j]['paymentmode'];
				$paymentid = $row[$j]['paymentid'];								
				
				$arr['conf_list'] .= '<tr><td>'.$name.'</td><td>'.$memtype.'</td><td>'.$mobile.'</td><td>'.$paymentmode.'- '.$paymentid.'</td><td><a style="text-decoration:underline" href="preconfapprovemember?id='.$id.'">view</a></td></tr>';
				
			}			
			
		}else{
			
			$arr['conf_list'] = '<tr><td colspan="4" style="text-align:center;">No Records Found</td></tr>';
			
		}
		
		return $arr;
		
	}
	
	public function GetPreconferenceApprovalDetails($memid){
		
		$arr = Array();
       	   		    
       	$query = $this-> db -> query('select memberid,title,name,age,gender,mobile,phone,email,address,address,city,state,pincode,designation,organisation,paymentamount,paymentmode,paymentid,status,paymentdate,paymentphoto,paymentstatus,preconfname,preconfamount from ceat_preconfregistration where id="'.$memid.'"');
       	$row = $query->result_array();
		
		$arr['id'] = $memid;
		$arr['memberid'] = $row[0]['memberid'];
		$arr['title'] = $row[0]['title'];
		$arr['name'] = $row[0]['name'];
		$arr['age'] = $row[0]['age'];
		$arr['gender'] = $row[0]['gender'];
		$arr['mobile'] = $row[0]['mobile'];
		$arr['phone'] = $row[0]['phone'];
		$arr['email'] = $row[0]['email'];
		$arr['designation'] = $row[0]['designation'];
		$arr['organisation'] = $row[0]['organisation'];
		$arr['gender'] = $row[0]['gender'];
		$arr['address'] = $row[0]['address'];
		$arr['contactstate'] = $row[0]['state'];
		$arr['contactpin'] = $row[0]['pincode'];
		$arr['contactcity'] = $row[0]['city'];
		$arr['paymentamount'] = $row[0]['paymentamount'];
		$arr['modeofpay'] = $row[0]['paymentmode'];
		$arr['paymentid'] = $row[0]['paymentid'];
		$arr['paymentdate'] = $row[0]['paymentdate'];
		$arr['paymentphoto'] = $row[0]['paymentphoto'];
		$arr['paymentstatus'] = $row[0]['paymentstatus'];
		
		$arr['status'] = $row[0]['status'];
				
				$paymodearr = "DD,NEFT,ONLINE,CASH,card,netbanking,wallet,emi,upi,Offline";
				$paymodearr = explode(",",$paymodearr);
				$arr['paymentmode'] = '<option>Choose</option>';
				foreach ($paymodearr as $pmval) { 
					if($arr['modeofpay']==$pmval){
						$arr['paymentmode'] .= "<option selected>".$pmval."</option>";
					}else{
						$arr['paymentmode'] .= "<option>".$pmval."</option>";
					}	   				
				}
		
			$preconfname = $row[0]['preconfname'];
			$preconfamount =  $row[0]['preconfamount'];
			
			$preconfarr = array_filter(explode('|',$preconfname));
            $preconfamount = array_filter(explode('|',$preconfamount));
			
			$arr['preconfname'] = '<span1 style="color:#333;display: inline-block;vertical-align: middle;">';
			foreach($preconfarr as $key=>$confname){
				
				$arr['preconfname'] .= $confname.' - &#8377; '.$preconfamount[$key].'<br />';
			}
			
			$arr['preconfname'] .= '</span1>';
						
		return $arr;
		
	}
	
	public function DeletePreconfMemberRequest($confid) {
		
		$query = $this-> db -> query('update ceat_preconfregistration set status="closed",paymentstatus="" where id="'.$confid.'"');
		
	}
	
	public function PreconfApproveMemberRequest($approveid,$name,$title,$userid,$role,$mobile,$phone,$email,$gender,$age,$address,$organisation,$designation,$payamount,$paydate,$paymode,$payid,$city,$state,$pincode) {
		
		$result = array(0 => "");
				
		$paydate = date('Y-m-d',strtotime($paydate));
		
		$query2  = $this-> db -> query('UPDATE `ceat_preconfregistration` SET `memberid`="'.$userid.'",`title`="'.$title.'",`name`="'.$name.'",`age`="'.$age.'",`gender`="'.$gender.'",`mobile`="'.$mobile.'",`phone`="'.$phone.'",`email`="'.$email.'",`address`="'.$address.'",`city`="'.$city.'",`state`="'.$state.'",`pincode`="'.$pincode.'",`designation`="'.$designation.'",`organisation`="'.$organisation.'",`paymentmode`="'.$paymode.'",`paymentdate`="'.$paydate.'",`paymentstatus`="captured",`status`="approved" WHERE id="'.$approveid.'"');

		if($query2){
			
			//$this->Emailconfirmation($approveid);
			$result = array(0 => "success");
			return $result;
		}
					
		return $result;
		
	}
	
	public function PreconfExportFields(){
		
		$query  = $this->db->query('SELECT name,email,contactnumber,iacdeno,regno,regcategory,institution,pcategory,subject,ptype,title,authors,abstract,comments,created FROM ceat_abstract where regno<>"" order by created asc');
		$row = $query->result_array();
		return $query;
		
	}
	
	public function ConfExportFields(){
		
		$query  = $this->db->query('SELECT regno,memtype,title,name,age,dob,gender,mobile,phone,email,address,contactaddress,contactcity,contactstate,contactpin,designation,organisation,qualification,remarks,paymentamount,paymentmode,paymentid,paymentdate,paymentstatus,paymenttime from ceat_confregistration where regno<>"" order by paymenttime asc');
		$row = $query->result_array();
		return $query;
		
	}
	   
  }
?>

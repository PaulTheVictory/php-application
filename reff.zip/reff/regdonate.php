<?php

require('includes/db.php');

//print_r($_POST);exit;

$name = isset($_POST['payname'])?$_POST['payname']:'';
$mobile = isset($_POST['paymobile'])?$_POST['paymobile']:'';
$email = isset($_POST['payemail'])?$_POST['payemail']:'';
$address = isset($_POST['address'])?$_POST['address']:'';
$city = isset($_POST['city'])?$_POST['city']:'';
$state = isset($_POST['state'])?$_POST['state']:'';
$pincode = isset($_POST['pincode'])?$_POST['pincode']:'';
$payamount = isset($_POST['payamount'])?$_POST['payamount']:'';


$id = uniqid();	

$offset=5*60*60 + 30*60;
$dateformat = 'Y-m-d H:i:s';
$curtime = gmdate($dateformat, time()+$offset);
	
	$sql1 = 'insert into ceat_donate (`id`,`name`,`mobile`,`email`,`payamount`,`created`) values ("'.$id.'","'.$name.'","'.$mobile.'","'.$email.'","'.$payamount.'","'.$curtime.'")';

	$result1 = mysqli_query($Connect,$sql1);


	if($result1){
		echo json_encode(array(0=>'success',1=>$id));
		exit(0);
	}else {
		echo json_encode(array(0=>'fail'));
		exit(0);
	}
		
echo json_encode(array(0=>''));
exit(0);

?>
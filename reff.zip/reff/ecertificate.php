<?php

use \setasign\Fpdi;

require_once(dirname(__FILE__).'/fpdf/fpdf.php');
require_once(dirname(__FILE__).'/FPDI/src/autoload.php');

include('includes/db.php');

//require('fpdf/makefont/makefont.php');
//MakeFont('fpdf/fonts/STENCIL.TTF','cp1252');

$confregno  = isset($_POST['confregno'])?$_POST['confregno']:'';
$name  = isset($_POST['name'])?$_POST['name']:'';

$confregno = strtoupper($confregno);

$name = ucwords(strtolower($name));

$name = "Dr. ".$name;

$checksql = 'select title,name from ceat_confregistration where regno="'.$confregno.'" and regno NOT IN ("SZC0019","SZC0085","SZC0086","SZC0129","SZC0165","SZC0257","SZC0547","SZC0663","SZC0525","SZC0444")';
$checkresult = mysqli_query($Connect,$checksql);
$checkrow = mysqli_num_rows($checkresult);
$row = mysqli_fetch_assoc($checkresult);

if($checkrow == 1 ){
	
	$title = $row['title'];
	$name = $row['name'];
	
	$fulname = $title.'. '.ucwords(strtolower($name));

// initiate FPDI
$pdf = new Fpdi\Fpdi();

// get the page count
$pageCount = $pdf->setSourceFile(dirname(__FILE__).'/images/certificate/ecertificate.pdf');
// iterate through all pages
for ($pageNo = 1; $pageNo <= $pageCount; $pageNo++) {
    // import a page
    $templateId = $pdf->importPage($pageNo);
	
	$pdf->AddFont('tt0144m_','','tt0144m_.php');

    $pdf->AddPage();
    // use the imported page and adjust the page size
    $pdf->useTemplate($templateId, ['adjustPageSize' => true]);

    $pdf->SetFont('tt0144m_','','22');
	$pdf->SetTextColor('47' ,'36' ,'130');
    $pdf->SetXY(40, 121);
    $pdf->Write(8, $fulname);
}

// Output the new PDF
$pdf->Output(); 
	
}else{
	echo '<script>alert("Invalid Member.");javascript:history.go(-1);</script>';
}

?>
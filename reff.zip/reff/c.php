<?php

require('includes/db.php');


			
$regnameceatalent = mysqli_real_escape_string($Connect,$_POST['regnameceatalent']);
$regphoneceatalent = mysqli_real_escape_string($Connect,$_POST['regphoneceatalent']);
$regemailceatalent = mysqli_real_escape_string($Connect,$_POST['regemailceatalent']);
$regcollegeceatalent = mysqli_real_escape_string($Connect,$_POST['regcollegeceatalent']);
$regyearceatalent = mysqli_real_escape_string($Connect,$_POST['regyearceatalent']);
$regpresentationceatalent = mysqli_real_escape_string($Connect,$_POST['regpresentationceatalent']);
$regmemberceatalent = mysqli_real_escape_string($Connect,$_POST['regmemberceatalent']);




$sql = "INSERT INTO ceatalent_form(name,phone,email,college,year,presentation,ceatmember) VALUES ('$regnameceatalent','$regphoneceatalent','$regemailceatalent','$regcollegeceatalent','$regyearceatalent','$regpresentationceatalent','$regmemberceatalent')";


$result = mysqli_query($Connect,$sql);

if($result){
	sendmail($regnameceatalent,$regphoneceatalent,$regemailceatalent,$regcollegeceatalent,$regyearceatalent,$regpresentationceatalent,$regmemberceatalent);
	echo json_encode(array(0=>'success'));
	exit(0);
}else {
	echo json_encode(array(0=>'fail'));
	exit(0);
}


function sendmail($regnameceatalent,$regphoneceatalent,$regemailceatalent,$regcollegeceatalent,$regyearceatalent,$regpresentationceatalent,$regmemberceatalent){

	
	$body = "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.=w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\"><html><head><meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\"></head><body>

	<table style=\"padding-top:4px;margin:0em auto;width:600px\"><tbody>
	<tr><td style=\"text-align:center;font-size:14px;padding-left:10px;color:#333;width:150px\">This message was sent from: " . getenv("HTTP_REFERER") . " - [" . $_SERVER['REMOTE_ADDR'] ."]</td></tr></tbody></table>

	<table style=\"background:#f5f5f5;border:2px solid #e5e5e5;border-collapse:collapse;padding-top:4px;margin:1.5em auto;width:600px\"><tbody>

	<tr><td style=\"border-right:2px solid #e5e5e5;border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:150px\">Name</td><td style=\"border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:450px\">" . $regnameceatalent . "</td></tr>

	<tr><td style=\"border-right:2px solid #e5e5e5;border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:150px\">Phone</td><td style=\"border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:450px\">" . $regphoneceatalent . "</td></tr>

	<tr><td style=\"border-right:2px solid #e5e5e5;border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:150px\">Email</td><td style=\"border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:450px\">" . $regemailceatalent . "</td></tr>

	<tr><td style=\"border-right:2px solid #e5e5e5;border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:150px\">College Name</td><td style=\"border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:450px\">" . $regcollegeceatalent . "</td></tr>
	
	<tr><td style=\"border-right:2px solid #e5e5e5;border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:150px\">Year of study</td><td style=\"border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:450px\">" . $regyearceatalent . "</td></tr>
	
	<tr><td style=\"border-right:2px solid #e5e5e5;border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:150px\">Presentation</td><td style=\"border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:450px\">" . $regpresentationceatalent . "</td></tr>
	
	<tr><td style=\"border-right:2px solid #e5e5e5;border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:150px\">Ceat Member</td><td style=\"border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:450px\">" . $regmemberceatalent . "</td></tr>
	
	

	</tbody></table>

	</body></html>";

	
$subject = "CEATALENT – REGISTRATION Register Form";
	
$toemail = "paul@harvee.co.uk";

$fromname = "CEATALENT – REGISTRATION";
	
$replyto = $regemailceatalent;
$pname = $regnameceatalent;

$finalbody = urlencode($body);

$substr = 'webtag=Theri&toemail='.$toemail.'&fromname='.$fromname."&replyto=".$replyto."&pname=".$pname."&subject=".$subject."&body=".$finalbody;

$url = "http://35.88.44.130/sendmail?";


$ch = curl_init($url);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, $substr);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_HEADER, 0);  // DO NOT RETURN HTTP HEADERS 
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);  // RETURN THE CONTENTS OF THE CALL
$return_val = curl_exec($ch);


}

mysqli_close($Connect);

?>
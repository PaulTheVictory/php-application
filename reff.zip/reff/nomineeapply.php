<?php

require('includes/db.php');

//print_r($_POST);exit;

$memid  = isset($_POST['userid'])?$_POST['userid']:'';
$name  = isset($_POST['name'])?$_POST['name']:'';
$mobile  = isset($_POST['mobile'])?$_POST['mobile']:'';
$email = isset($_POST['email'])?$_POST['email']:'';
$appfor  = isset($_POST['appfor'])?$_POST['appfor']:'';
$applyfor  = isset($_POST['applyfor'])?$_POST['applyfor']:'';
	$ccname  = isset($_POST['ccname'])?$_POST['ccname']:'';
	//$cv  = isset($_POST['cv'])?$_POST['paymode']:'';
	//$casefiles  = isset($_POST['casefiles'])?$_POST['casefiles']:'';

$id = uniqid();

$profilepic = "";
$cv = "";
$casefiles = "";
	
	$offset=5*60*60 + 30*60;
	$dateformat = 'Y-m-d H:i:s';
	$curtime = gmdate($dateformat, time()+$offset);
	
$checksql = 'select id from ceat_nominee where mobile="'.$mobile.'" or email="'.$email.'"';
$checkresult = mysqli_query($Connect,$checksql);
$checkrow = mysqli_num_rows($checkresult);

if($checkrow == 0 ){
	
	$imageExtensions = array('.doc', '.docx');
	
	$imagenewExtensions = array('.jpg', '.jpeg', '.png');
	
	$dirname = dirname(__FILE__).'/member_area/docs/nominee/'.$memid.'/';
	
	$dirprofile = dirname(__FILE__).'/member_area/docs/profile/';
	
	$dirprofilefull = dirname(__FILE__).'/member_area/docs/profile/main/';
	
	if(isset($_FILES["profilepic"]) && !empty($_FILES["profilepic"]['name'])){
		
		if ($_FILES["profilepic"]["size"] > 4194304) {
			echo json_encode(array(0=>'pmaxsize'));
			exit(0);
		}
			
		$fileExtension = strrchr($_FILES['profilepic']['name'], ".");
		$profilepic = $memid."".$fileExtension;
		$destinationfull = $dirprofile .$profilepic;
		$destinationprofilefull = $dirprofilefull.$profilepic;
		
		if (in_array(strtolower($fileExtension), $imagenewExtensions)) {
			
			if(move_uploaded_file($_FILES['profilepic']['tmp_name'],$destinationfull)){
				
				$sqlimg = 'update ceat_users set profileimg="'.$profilepic.'" where userid="'.$memid.'"';
				$resultimg = mysqli_query($Connect,$sqlimg);
			
			
			copy($destinationfull,$destinationprofilefull);
			
			if($_POST['x']!="" && $_POST['y']!="" && $_POST['w']!="" && $_POST['h']!=""){
				
				$targ_w = 140;
				$targ_h = 160;
				$jpeg_quality = 90;

				$src = $dirprofile.$profilepic;
				
				if($fileExtension==".jpg" || $fileExtension==".jpeg"){
					$img_r = imagecreatefromjpeg($src);
					$dst_r = ImageCreateTrueColor( $targ_w, $targ_h );

					$output_filename = $dirprofile.$profilepic;

					imagecopyresampled($dst_r,$img_r,0,0,$_POST['x'],$_POST['y'],$targ_w,$targ_h,$_POST['w'],$_POST['h']);
					imagejpeg($dst_r,$output_filename,$jpeg_quality);
				}
				else if($fileExtension==".png"){
					$img_r = imagecreatefrompng($src);
					$dst_r = ImageCreateTrueColor( $targ_w, $targ_h );

					$output_filename = $dirprofile.$profilepic;

					imagecopyresampled($dst_r,$img_r,0,0,$_POST['x'],$_POST['y'],$targ_w,$targ_h,$_POST['w'],$_POST['h']);
					imagepng($dst_r,$output_filename,9);
				}
				
			}
			}
		}else {
			echo json_encode(array(0=>'pextfail'));
			exit(0);
		}
	}
	
	if(isset($_FILES["cv"]) && !empty($_FILES["cv"]['name'])){
		
		if(!file_exists($dirname)) {                                    
			mkdir($dirname, 0777);                                  
		 }
	
		$fileExtension = strrchr($_FILES['cv']['name'], ".");
		$cv = "resume_".$id."".$fileExtension;
		$destinationfull = $dirname .$cv;
				
		if (in_array(strtolower($fileExtension), $imageExtensions)) {
			
			move_uploaded_file($_FILES['cv']['tmp_name'],$destinationfull);
			
		}else {
			echo json_encode(array(0=>'extfail'));
			exit(0);
		}
	}
	
	if(isset($_FILES["casefiles"]) && !empty($_FILES["casefiles"]['name']) && ($applyfor=="Emerging Star" || $applyfor=="Outstanding Clinician")){
		
		if ($_FILES["casefiles"]["size"] > 10485760) {
			echo json_encode(array(0=>'fmaxsize'));
			exit(0);
		}
		
		if(!file_exists($dirname)) {                                    
			mkdir($dirname, 0777);                                  
		 }
	
		$fileExtension = strrchr($_FILES['casefiles']['name'], ".");
		$casefiles = "casefile_".$id."".$fileExtension;
		$destinationfull = $dirname .$casefiles;
				
		if (in_array(strtolower($fileExtension), $imageExtensions)) {
			
			move_uploaded_file($_FILES['casefiles']['tmp_name'],$destinationfull);
			
		}else {
			echo json_encode(array(0=>'extfail'));
			exit(0);
		}
	}

	
	
$sql = 'insert into ceat_nominee (`id`,`memberid`,`name`,`mobile`,`email`,`cname`,`appby`,`applyfor`,`cv`,`casefiles`,`created`) values ("'.$id.'","'.$memid.'","'.$name.'","'.$mobile.'","'.$email.'","'.$ccname.'","'.$appfor.'","'.$applyfor.'","'.$cv.'","'.$casefiles.'","'.$curtime.'")';

//$ALT_Db = @mysql_select_db($DB_DBName, $Connect) or die("Couldnt select database");
$result = mysqli_query($Connect,$sql);

if($result){
	echo json_encode(array(0=>'success',1=>$id));
	/*if($paymode=="Offline"){
		Emailconfirmation($Connect,$id,$paymentamount,$paymentstatus,$curtime,$Delegates,$Students,$onlinecharges);
	}*/
	exit(0);
}else {
	echo json_encode(array(0=>'fail'));
	exit(0);
}
	
}else {
	echo json_encode(array(0=>'exists'));
	exit(0);
}

echo json_encode(array(0=>''));
exit(0);


function Emailconfirmation($Connect,$refno,$payamount,$paymentstatus,$created,$Delegates,$Students,$onlinecharges){
	
	
$sql = 'select * from ceat_confregistration where id="'.$refno.'"';

$result = @mysqli_query($Connect,$sql);

$row = mysqli_fetch_assoc($result);

if($row)
{
	$memtype = $row['memtype'];
	$name = $row['name'];
	$mobile = $row['mobile'];
	$email = $row['email'];
	$regno = $row['regno'];
	
	$confamount = "";
	if($memtype=="Delegates"){ $confamount = $Delegates;}
	else if($memtype=="Students"){$confamount = $Students;}
	$payamount = $payamount - ($confamount*$onlinecharges);
	
	$created = date("d-m-Y H:i:s A",strtotime($created));
	
	
	if($paymentstatus=="captured")$status = "Payment Successful"; else $status = "Payment failed";
	
	$preconflist = "";
	
	$sql1 = 'select * from ceat_preconfregistration where regid="'.$refno.'"';
	$result1 = @mysqli_query($Connect,$sql1);
	$row1 = mysqli_fetch_assoc($result1);
	if($row1){
		
		$preconfname = $row1['preconfname'];
		$preconfamount = $row1['preconfamount'];
		
		$preconfarr = explode('|',$preconfname);
		$preconfamountarr = explode('|',$preconfamount);
		
		$preconflist = "<tr><td style=\"text-align:justify;font-size:14px;line-height:25px;padding:0 10px;color:#333;\"><strong>Pre Conference Workshop</strong></td></tr>";
		
		foreach($preconfarr as $key => $confname){
			$preconflist .= "<tr><td style=\"text-align:justify;font-size:14px;line-height:25px;padding:0 10px;color:#333;\">".$confname." - &#8377; ".$preconfamountarr[$key]."</td></tr>";
		}
		
	}
	
	
	$body = "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.=
w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\"><html><head><meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\"></head><body>

<table style=\"background:#fff;border:1px solid #E8E8E8; border-radius:15px; border-collapse:collapse; overflow:hidden;padding:10px;margin:0 auto; font-size: 15px; width:600px\"><tbody>

<tr><td style=\"text-align:center; width:600px; color:#333; padding:20px;\"><img src=\"http://www.theceat.com/images/logo.jpg\" alt=\"CEAT\" width=\"137px\"></td></tr>

<tr><td style=\"text-align:center;font-size:18px;line-height:33px;color:#333;\"><strong>Conservative and Endodontic Association of Tamilnadu - Annual Conference</strong></td></tr>

<tr><td style=\"text-align:center;font-size:18px;line-height:33px;color:#333;\">Payment receipt</td></tr>

<tr><td>&nbsp;</td></tr>

<tr ><td style=\"text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;\"><p style=\"float:left\">Reg No : ".$regno."</p><p style=\"float:right;margin-right:5px;\"> Date: ".$created."</p></td></tr>

<tr><td style=\"text-align:justify;font-size:14px;line-height:25px;padding:0 10px;color:#333;\">Received with thanks from <strong>".$name."</strong> a sum of <strong>&#8377; ".$payamount."</strong> towards Conference Registration (Conservative and Endodontic Association of Tamilnadu - Annual Conference).</td></tr>

".$preconflist."

<tr><td>&nbsp;</td></tr>
<tr><td style=\"text-align:left; padding-left:10px;  color:#333;\">Regards<br>CEAT</td></tr>
<tr style=\"background:#EEEEEE; font-size: 12px;\"><td style=\"text-align:center; padding:10px 20px;  color:#999;\">Copyright &copy; ".date('Y')." CEAT. All Rights Reserved. <a style=\"color:#0986C5; text-decoration:none;\" href=\"http://www.theceat.com/\">www.theceat.com</a></td></tr>

</tbody></table>

</body></html>";


$subject = "CEAT Conference Registration - Successfull";
$toemail = $email;
$fromname = "CEAT Conference";
$replyto = "ceatfamily@gmail.com";
$subject = $subject;
$pname = "CEAT";

$finalbody = urlencode($body);


$substr = 'webtag=Theri&toemail='.$toemail.'&fromname='.$fromname."&replyto=".$replyto."&pname=".$pname."&subject=".$subject."&body=".$finalbody;

$url = "http://35.88.44.130/sendmail?";

$ch = curl_init($url);

curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, $substr);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_HEADER, 0);  // DO NOT RETURN HTTP HEADERS 
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);  // RETURN THE CONTENTS OF THE CALL

$return_val = curl_exec($ch);
	

			$messTemplate = 'uname=harvee1&pass=g~I)n!g2&send=CEATtn&dest=NuMbER&msg=Dear%20[MeMbEr],%20You%20have%20successfully%20registered%20for%20the%201st%20IACDE%20Zonal%20Conference%20-%20South%20Zone%20,%20your%20registration%20id:%20[ReGnO].%20For%20queries:%209884310206.';

			$substr = $messTemplate;

			$searchFOr = 'NuMbER';
			$replacewith = $mobile;
			$substr = str_replace($searchFOr, $replacewith, $substr);

			$searchFOr = '[MeMbEr]';
			$replacewith = $name;
			$substr = str_replace($searchFOr, $replacewith, $substr);

			$searchFOr = '[ReGnO]';
			$replacewith = $regno;
			$substr = str_replace($searchFOr, $replacewith, $substr);


			$url = "https://instaalerts.zone/SendSMS/sendmsg.php?";

			$ch = curl_init($url);


			curl_setopt($ch, CURLOPT_POST, 1);
			curl_setopt($ch, CURLOPT_POSTFIELDS, $substr);
			curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
			curl_setopt($ch, CURLOPT_HEADER, 0);  // DO NOT RETURN HTTP HEADERS 
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);  // RETURN THE CONTENTS OF THE CALL

			$return_val = curl_exec($ch);

            sendMailSMStoAdmin($refno,$name,$mobile,$email,$payamount,$created,$status,$regno,$memtype,$preconflist);


}

}

function sendMailSMStoAdmin($refno,$name,$mobile,$email,$payamount,$created,$status,$regno,$memtype,$preconflist) {
	
		$body = "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.=
w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\"><html><head><meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\"></head><body>

<table style=\"background:#fff;border:1px solid #e5e5e5;border-collapse:collapse;padding-top:4px;margin:1.5em auto;width:600px\"><tbody>

<tr><td style=\"text-align:center;font-size:18px;line-height:33px;color:#333;\"><img src=\"http://www.theceat.com/images/logo.jpg\" /></td></tr>

<tr><td style=\"text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;\">We have a successfully got a ".$memtype." registration</td></tr>

<tr><td style=\"text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;\"><strong>Name <span style=\"margin-left: 73px;\">:</span> </strong> ".$name."</td></tr>

<tr><td style=\"text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;\"><strong>Mobile <span style=\"margin-left: 64px;\">:</span> </strong> ".$mobile."</td></tr>

<tr><td style=\"text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;\"><strong>Email <span style=\"margin-left: 76px;\">:</span></strong> ".$email."</td></tr>

<tr><td style=\"text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;\"><strong>Registration ID <span style=\"margin-left: 10px;\">:</span> </strong> ".$regno."</td></tr>

".$preconflist."

<tr><td style=\"text-align:left;font-size:14px;line-height:20px;padding-left:10px;color:#333;\">Regards <br/>CEAT</td></tr>

</tbody></table>

</body></html>";


$subject = "CEAT Conference Registration - Successfull";
$toemail = "ceatfamily@gmail.com";
	$bccmail = "harish@harvee.co.uk";
	//$toemail = "krishnan@harvee.co.uk";
$fromname = "CEAT Conference";
$replyto = "";
$subject = $subject;
$pname = "CEAT";

$finalbody = urlencode($body);


$substr = 'webtag=Theri&toemail='.$toemail.'&fromname='.$fromname."&replyto=".$replyto."&pname=".$pname."&subject=".$subject."&bccmail=".$bccmail."&body=".$finalbody;

$url = "http://35.88.44.130/sendmail?";

$ch = curl_init($url);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, $substr);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_HEADER, 0);  // DO NOT RETURN HTTP HEADERS 
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);  // RETURN THE CONTENTS OF THE CALL

$return_val = curl_exec($ch);
	
	
			$dest = "9884310206,9444192005,9894276263";
			//$mobile= "9629090346";

			$messTemplate = 'uname=harvee1&pass=g~I)n!g2&send=CEATtn&dest=NuMbER&msg=We%20have%20a%20successfully%20got%20 a%20[MeMbErTyPe]%20registration%20[NaMe]%20[MoBiLe]%20and%20[EmAiLiD].%20Registration%20ID:%20[ReGnO].';

			$substr = $messTemplate;

			$searchFOr = 'NuMbER';
			$replacewith = $dest;
			$substr = str_replace($searchFOr, $replacewith, $substr);

			$searchFOr = '[MeMbErTyPe]';
			$replacewith = $memtype;
			$substr = str_replace($searchFOr, $replacewith, $substr);
	
			$searchFOr = '[NaMe]';
			$replacewith = $name;
			$substr = str_replace($searchFOr, $replacewith, $substr);
	
			$searchFOr = '[MoBiLe]';
			$replacewith = $mobile;
			$substr = str_replace($searchFOr, $replacewith, $substr);
	
			$searchFOr = '[EmAiLiD]';
			$replacewith = $email;
			$substr = str_replace($searchFOr, $replacewith, $substr);
	
			$searchFOr = '[ReGnO]';
			$replacewith = $regno;
			$substr = str_replace($searchFOr, $replacewith, $substr);
	
	
			$url = "https://instaalerts.zone/SendSMS/sendmsg.php?";

			$ch = curl_init($url);
			curl_setopt($ch, CURLOPT_POST, 1);
			curl_setopt($ch, CURLOPT_POSTFIELDS, $substr);
			curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
			curl_setopt($ch, CURLOPT_HEADER, 0);  // DO NOT RETURN HTTP HEADERS 
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);  // RETURN THE CONTENTS OF THE CALL

			$return_val = curl_exec($ch);


        }

?>
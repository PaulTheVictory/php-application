<?php

require('includes/db.php');


include('razorpay/Razorpay.php');

use Razorpay\Api\Api;

$refno  = isset($_POST['merchantid'])?$_POST['merchantid']:'';
$paymentid = isset($_POST['paymentid'])?$_POST['paymentid']:'';
$payamount = isset($_POST['totalfees'])?$_POST['totalfees']:'';

$api = new Api($APIkey, $secretkey);

$payment = $api->payment->fetch($paymentid);

if($payment['status']!="captured")
{
	$payment = $payment->capture(array('amount' => $payment['amount']));
}

//print_r($payment);exit;

$payamount = $payment['amount']/100;
$paymentstatus = $payment['status'];
$method = $payment['method'];

date_default_timezone_set('Asia/Kolkata');
$created = date("Y-m-d H:i:s",$payment['created_at']);

$rzpay = 'INSERT INTO `razor_payment`(`rzpaymentid`, `rzentity`, `rzamount`, `rzstatus`, `rzcaptured`, `rzcard_id`, `rzerror_code`, `rzerror_description`, `rzcreated_at`) VALUES ("'.$payment['id'].'","'.$payment['entity'].'","'.$payment['amount'].'","'.$payment['status'].'","'.$payment['captured'].'","'.$payment['card_id'].'","'.$payment['error_code'].'","'.$payment['error_description'].'","'.$created.'")';
$rzresult = @mysqli_query($Connect,$rzpay);

$sql = 'update ceat_rrr set paymentamount="'.$payamount.'", paymentmode="'.$method.'", paymentid="'.$paymentid.'", paymentstatus="'.$paymentstatus.'",paymenttime="'.$created.'" where id="'.$refno.'"';

$result = @mysqli_query($Connect,$sql);



if($result){
	echo $refno;
	Emailconfirmation($Connect,$refno,$payamount,$method,$paymentstatus,$created);
}else {
	echo "";
}

function Emailconfirmation($Connect,$refno,$payamount,$method,$paymentstatus,$created){
	
$sql = 'select * from ceat_rrr where id="'.$refno.'"';

$result = @mysqli_query($Connect,$sql);

$row = mysqli_fetch_assoc($result);

if($row)
{
	$name = $row['name'];
	$mobile = $row['phone'];
	$email = $row['email'];
	
	if($paymentstatus=="captured")$status = "Payment Successful"; else $status = "Payment failed";
	
	$body = "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.=
w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\"><html><head><meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\"></head><body>

<table style=\"background:#fff;border:2px solid #e5e5e5;border-collapse:collapse;padding-top:4px;margin:1.5em auto;width:800px\"><tbody>

<tr><td style=\"text-align:center;font-size:18px;line-height:33px;color:#333;\"><img src=\"http://www.theceat.com/images/logo.jpg\" /></td></tr>

<tr><td style=\"text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;\">Dear ".$name.",</td></tr>

<tr><td style=\"text-align:justify;font-size:14px;line-height:33px;padding:0 10px;color:#333;\">Greetings, We have received your online registration for RRR 2022.</td></tr>

<tr><td style=\"text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;\">Payment Information:</td></tr>

<tr><td style=\"text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;\"><strong>Amount Paid <span style=\"margin-left: 38px;\">:</span> &#8377; </strong> ".$payamount."</td></tr>

<tr><td style=\"text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;\"><strong>Mode of Payment <span style=\"margin-left: 12px;\">:</span> </strong> ".ucfirst($method)."</td></tr>

<tr><td style=\"text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;\"><strong>Payment Date <span style=\"margin-left: 34px;\">:</span> </strong> ".date("d M Y, H:i:s A",strtotime($created))."</td></tr>

<tr><td style=\"text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;\"><strong>Status <span style=\"margin-left: 81px;\">:</span> </strong> ".$status."</td></tr>

<tr><td style=\"text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;\"><strong>Reference No <span style=\"margin-left: 39px;\">:</span> </strong> ".$refno."</td></tr>

<tr><td style=\"text-align:left;font-size:14px;line-height:20px;padding-left:10px;color:#333;\">Regards <br/>Head office,<br/>CEAT.</td></tr>

</tbody></table>

</body></html>";

$subject = "RRR 2022 Registration Payment Confirmation";
$toemail = $email;
$fromname = "RRR 2022 Registration";
$replyto = "ceatfamily@gmail.com";
$subject = $subject;
$pname = "CEAT";

$finalbody = urlencode($body);


$substr = 'webtag=Theri&toemail='.$toemail.'&fromname='.$fromname."&replyto=".$replyto."&pname=".$pname."&subject=".$subject."&body=".$finalbody;

$url = "http://35.88.44.130/sendmail?";

	

$ch = curl_init($url);

curl_setopt($ch, CURLOPT_POST, 1);

curl_setopt($ch, CURLOPT_POSTFIELDS, $substr);

curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);

curl_setopt($ch, CURLOPT_HEADER, 0);  // DO NOT RETURN HTTP HEADERS 

curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);  // RETURN THE CONTENTS OF THE CALL

$return_val = curl_exec($ch);


	sendMailAdmin($Connect,$refno);
	
}
	
	
}
	
	
function sendMailAdmin($Connect,$refno){

	
$sql = 'select * from ceat_rrr where id="'.$refno.'"';

$result = @mysqli_query($Connect,$sql);

$row = mysqli_fetch_assoc($result);

if($row)
{
	
	$name = $row['name'];
	$clinic = $row['clinic'];
	// $designation = $row['designation'];
	/*$year = $row['year'];*/
	$phone = $row['phone'];
	$email = $row['email'];
	
	
	
	$body = "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.=w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\"><html><head><meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\"></head><body>

	<table style=\"padding-top:4px;margin:0em auto;width:600px\"><tbody>
	<tr><td style=\"text-align:center;font-size:14px;padding-left:10px;color:#333;width:150px\">This message was sent from: " . getenv("HTTP_REFERER") . " - [" . $_SERVER['REMOTE_ADDR'] ."]</td></tr></tbody></table>

	<table style=\"background:#f5f5f5;border:2px solid #e5e5e5;border-collapse:collapse;padding-top:4px;margin:1.5em auto;width:600px\"><tbody>


	<tr><td colpan=\"2\" style=\"text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;\">Dear Admin,</td></tr>

	<tr><td colspan=\"2\" style=\"border-right:0px solid #e5e5e5;border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:600px\">Greetings, We have received the online registration for RRR 2022.</td></tr>

	<tr><td style=\"border-right:2px solid #e5e5e5;border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:150px\">Name</td><td style=\"border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:450px\">" . $name . "</td></tr>
	
	<tr><td style=\"border-right:2px solid #e5e5e5;border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:150px\">Institution / Clinic</td><td style=\"border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:450px\">" . $clinic . "</td></tr>
	
	

	
	

	

	<tr><td style=\"border-right:2px solid #e5e5e5;border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:150px\">Mobile</td><td style=\"border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:450px\">" . $phone . "</td></tr>

	
	
	<tr><td style=\"border-right:2px solid #e5e5e5;border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:150px\">Email</td><td style=\"border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:450px\">" . $email . "</td></tr>
	
	

	</tbody></table>

	</body></html>";

	
$subject = "RRR 2022 Registration Confirmation ";
	
$toemail = "paulthevictory@gmail.com";


$fromname = "RRR 2022 Registration";
	
$replyto = $email;
$pname = $name;

$finalbody = urlencode($body);

$substr = 'webtag=Theri&toemail='.$toemail.'&fromname='.$fromname."&replyto=".$replyto."&pname=".$pname."&subject=".$subject."&body=".$finalbody;

$url = "http://35.88.44.130/sendmail?";


$ch = curl_init($url);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, $substr);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_HEADER, 0);  // DO NOT RETURN HTTP HEADERS 
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);  // RETURN THE CONTENTS OF THE CALL
$return_val = curl_exec($ch);
	
}


}

//print_r($payment);

<?php

ob_start();

require('includes/db.php');

$refno = $_GET['ref'];

$sql = 'select * from ceat_registration where id="'.$refno.'"';

//$ALT_Db = @mysql_select_db($DB_DBName, $Connect) or die("Couldnt select database");
$result = @mysqli_query($Connect,$sql);

$row = mysqli_fetch_assoc($result);

if($row)
{
	
	
	$memtype = $row['memtype'];
	$name = $row['name'];
	$dob = $row['dob'];
	$sex = $row['sex'];
	$mobile = $row['mobile'];
	$email = $row['email'];
	$sameaddress = $row['sameaddress'];
	$address = $row['address'];
	$address2 = $row['address2'];
	$city = $row['city'];
	$state = $row['state'];
	$pincode = $row['pincode'];
	$contactaddress = $row['contactaddress'];
	$contactaddress2 = $row['contactaddress2'];
	$contactcity = $row['contactcity'];
	$contactstate = $row['contactstate'];
	$contactpin = $row['contactpin'];
	$qualification = $row['qualification'];
	$college = $row['college'];
	
	if ($row['phone']!=""): $phone = $row['phone']; else : $phone = "-"; endif;
	if ($row['designation']!=""): $designation = $row['designation']; else : $designation = "-"; endif;
	if ($row['clinicaddress']!=""): $clinicaddress = $row['clinicaddress']; else : $clinicaddress = "-"; endif;
	if ($row['clinicaddress2']!=""): $clinicaddress2 = $row['clinicaddress2']; else : $clinicaddress2 = "-"; endif;
	if ($row['clinicphone']!=""): $clinicphone = $row['clinicphone']; else : $clinicphone = "-"; endif;
	if ($row['cliniccity']!=""): $cliniccity = $row['cliniccity']; else : $cliniccity = "-"; endif;
	if ($row['clinicstate']!=""): $clinicstate = $row['clinicstate']; else : $clinicstate = "-"; endif;
	if ($row['clinicpin']!=""): $clinicpin = $row['clinicpin']; else : $clinicpin = "-"; endif;


	$caddress = "<tr><td style=\"border-right:2px solid #e5e5e5;border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:150px;font-weight:bold;\" colspan=\"2\">Residential Address </td</tr>
	
	<tr><td style=\"border-right:2px solid #e5e5e5;border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:150px\">Address</td><td style=\"border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:450px\">" . $contactaddress . "</td></tr>

<tr><td style=\"border-right:2px solid #e5e5e5;border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:150px\">Address 2</td><td style=\"border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:450px\">" . $contactaddress2 . "</td></tr>

<tr><td style=\"border-right:2px solid #e5e5e5;border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:150px\">City</td><td style=\"border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:450px\">" . $contactcity . "</td></tr>

<tr><td style=\"border-right:2px solid #e5e5e5;border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:150px\">State</td><td style=\"border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:450px\">" . $contactstate . "</td></tr>

<tr><td style=\"border-right:2px solid #e5e5e5;border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:150px\">Pincode</td><td style=\"border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:450px\">" . $contactpin . "</td></tr>
	";
	
$cliaddress = "<tr><td style=\"border-right:2px solid #e5e5e5;border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:150px;font-weight:bold;\" colspan=\"2\">Clinic Address </td</tr>
	
	<tr><td style=\"border-right:2px solid #e5e5e5;border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:150px\">Address</td><td style=\"border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:450px\">" . $clinicaddress . "</td></tr>

<tr><td style=\"border-right:2px solid #e5e5e5;border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:150px\">Address 2</td><td style=\"border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:450px\">" . $clinicaddress2 . "</td></tr>

<tr><td style=\"border-right:2px solid #e5e5e5;border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:150px\">Phone</td><td style=\"border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:450px\">" . $clinicphone . "</td></tr>

<tr><td style=\"border-right:2px solid #e5e5e5;border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:150px\">City</td><td style=\"border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:450px\">" . $cliniccity . "</td></tr>

<tr><td style=\"border-right:2px solid #e5e5e5;border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:150px\">State</td><td style=\"border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:450px\">" . $clinicstate . "</td></tr>

<tr><td style=\"border-right:2px solid #e5e5e5;border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:150px\">Pincode</td><td style=\"border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:450px\">" . $clinicpin . "</td></tr>
	";
	
	
 $subject = "CEAT Registration";
 $redirect_url = "http://www.theceat.com/member_area/home" ;
 
 $retry_url = "http://www.theceat.com/regemail.php?ref=".$refno ;
  
 //========================================
// Do not change anything below this line
//========================================
 
$body = "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.=

w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\"><html><head><meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\"></head><body>



<table style=\"padding-top:4px;margin:0em auto;width:600px\"><tbody>

<tr><td style=\"text-align:center;font-size:14px;padding-left:10px;color:#333;width:150px\">This message was sent from: " . getenv("HTTP_REFERER") . " - [" . $_SERVER['REMOTE_ADDR'] ."]</td></tr>

</tbody></table>



<table style=\"background:#f5f5f5;border:2px solid #e5e5e5;border-collapse:collapse;padding-top:4px;margin:1.5em auto;width:600px\"><tbody>


<tr><td style=\"border-right:2px solid #e5e5e5;border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:150px\">Member Type</td><td style=\"border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:450px\">" . $memtype . "</td></tr>

<tr><td style=\"border-right:2px solid #e5e5e5;border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:150px\">Name</td><td style=\"border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:450px\">" . $name . "</td></tr>

<tr><td style=\"border-right:2px solid #e5e5e5;border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:150px\">Mobile</td><td style=\"border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:450px\">" . $mobile . "</td></tr>

<tr><td style=\"border-right:2px solid #e5e5e5;border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:150px\">Phone</td><td style=\"border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:450px\">" . $phone . "</td></tr>

<tr><td style=\"border-right:2px solid #e5e5e5;border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:150px\">Email</td><td style=\"border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:450px\">" . $email . "</td></tr>

<tr><td style=\"border-right:2px solid #e5e5e5;border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:150px\">Sex</td><td style=\"border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:450px\">" . $sex . "</td></tr>

<tr><td style=\"border-right:2px solid #e5e5e5;border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:150px\">Date of Birth</td><td style=\"border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:450px\">" . $dob . "</td></tr>

<tr><td style=\"border-right:2px solid #e5e5e5;border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:150px\">Address</td><td style=\"border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:450px\">" . $address . "</td></tr>

<tr><td style=\"border-right:2px solid #e5e5e5;border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:150px\">Address 2</td><td style=\"border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:450px\">" . $address2 . "</td></tr>

<tr><td style=\"border-right:2px solid #e5e5e5;border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:150px\">City</td><td style=\"border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:450px\">" . $city . "</td></tr>

<tr><td style=\"border-right:2px solid #e5e5e5;border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:150px\">State</td><td style=\"border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:450px\">" . $state . "</td></tr>

<tr><td style=\"border-right:2px solid #e5e5e5;border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:150px\">Pincode</td><td style=\"border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:450px\">" . $pincode . "</td></tr>

".$caddress."

<tr><td style=\"border-right:2px solid #e5e5e5;border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:150px\">BDS College</td><td style=\"border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:450px\">" . $qualification . "</td></tr>

<tr><td style=\"border-right:2px solid #e5e5e5;border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:150px\">MDS College</td><td style=\"border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:450px\">" . $college . "</td></tr>

<tr><td style=\"border-right:2px solid #e5e5e5;border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:150px\">Designation</td><td style=\"border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:450px\">" . $designation . "</td></tr>

".$cliaddress."

</tbody></table>

</body></html>";


$toemail = "ceatfamily@gmail.com";
//$toemail = "krishnan@harvee.co.uk";
$fromname = "CEAT Registration";
$replyto = "ceatfamily@gmail.com";
$subject = $subject;
$pname = "CEAT";

$finalbody = urlencode($body);


$substr = 'webtag=Theri&toemail='.$toemail.'&fromname='.$fromname."&replyto=".$replyto."&pname=".$pname."&subject=".$subject."&body=".$finalbody;

$url = "http://35.88.44.130/sendmail?";

	

$ch = curl_init($url);

curl_setopt($ch, CURLOPT_POST, 1);

curl_setopt($ch, CURLOPT_POSTFIELDS, $substr);

curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);

curl_setopt($ch, CURLOPT_HEADER, 0);  // DO NOT RETURN HTTP HEADERS 

curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);  // RETURN THE CONTENTS OF THE CALL

$return_val = curl_exec($ch);


if ($return_val == "success") {
	
    echo "<script language='javascript'> alert('Registered successfully');location.assign('".$redirect_url."');</script>";
	exit;

} else {
	
   echo "<script language='javascript'> var r=confirm('Registered successfully and Email Error.Click OK to retry or click CANCEL');if(r)location.assign('regemail.php?ref=".$refno."'); else location.assign('".$redirect_url."');</script>";
   exit;
}

}

?>

<?php
//include('mime.php');


 $subject = "Change Membership Student to Life - CEAT Website";
 
 //========================================
// Do not change anything below this line
//========================================

if (empty($_POST["name"])) { 
	echo "<script language='javascript'> alert('Fill in all mandatory fields')</script>";
   	echo "<script language='javascript'> window.open('http://www.theceat.com/member_area/home','_self')</script>";
   	exit; }
 
/*ob_start();
require("class.phpmailer.php");

$mail = new PHPMailer();

$mail->SetLanguage( 'en', 'phpmailer/language/' );
//$mail->IsSMTP();               // set mailer to use SMTP
$mail->Host = "smtp.gmail.com";  // specify main and backup server or localhost
$mail->SMTPAuth = true;     // turn on SMTP authentication
$mail->Username = "todo@harvee.co.uk";  // SMTP username
$mail->Password = "29R63757"; // SMTP password

$mail->From = $mail->Username;	//Default From email same as smtp user
$mail->FromName = "Online Scanned Copy";

//$mail->AddAddress("latheef@harvee.co.uk", "Latheef"); //Email address where you wish to receive/collect those emails.

//$mail->AddAddress("info@iacde.in", "CEAT"); //Email address where you wish to receive/collect those emails.
$mail->AddAddress("krishnan@harvee.co.uk", "CEAT");
//$mail->AddBcc("harish@harvee.co.uk", "Harish Harvee");


$mail->WordWrap = 50;                                 // set word wrap to 50 characters
$mail->IsHTML(true);                                  // set email format to HTML

$mail->Subject = $subject;


if(is_uploaded_file($_FILES['uploaded_file']['tmp_name'])) {
            $file = $_FILES['uploaded_file'];
            }*/
			
$attachment_path_1 = $_FILES["uploaded_file_1"]["tmp_name"];
$attachment_name_1 = basename($_FILES['uploaded_file_1']['name']);

//$mail->AddAttachment($attachment_path_1, $attachment_name_1);

$attachment_path_2 = $_FILES["uploaded_file_2"]["tmp_name"];
$attachment_name_2 = basename($_FILES['uploaded_file_2']['name']);

//$mail->AddAttachment($attachment_path_2, $attachment_name_2);

$type_of_uploaded_file1 = substr($attachment_name_1,  strrpos($attachment_name_1, '.') + 1);
$type_of_uploaded_file2 = substr($attachment_name_2,  strrpos($attachment_name_2, '.') + 1);

if ($attachment_path_1=="") { 
	echo "<script language='javascript'> alert('Upload Certificate')</script>";
   	echo "<script language='javascript'> window.open('http://www.theceat.com/member_area/home','_self')</script>";
   	exit; }		                


$text = "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.=
w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\"><html><head><meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\"></head><body>

<table style=\"padding-top:4px;margin:0em auto;width:600px\"><tbody>
<tr><td style=\"text-align:center;font-size:14px;padding-left:10px;color:#333;width:150px\">This message was sent from: " . getenv("HTTP_REFERER") . " - [" . $_SERVER['REMOTE_ADDR'] ."]</td></tr>
</tbody></table>

<table style=\"background:#f5f5f5;border:2px solid #e5e5e5;border-collapse:collapse;padding-top:4px;margin:1.5em auto;width:600px\"><tbody>

<tr><td style=\"border-right:2px solid #e5e5e5;border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:150px\">Name</td><td style=\"border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:450px\">" .$_POST["name"]. "</td></tr>

<tr><td style=\"border-right:2px solid #e5e5e5;border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:150px\">Membership ID</td><td style=\"border-bottom:2px solid #e5e5e5;text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;width:450px\">" .$_POST["memid"]. "</td></tr>

</tbody></table>

</body></html>";

/*$text = str_replace('\"', '"', $text);
$text = str_replace("\'", "'", $text);

$mime = new Mail_mime();
 
$mime->setHTMLBody($text);
$mime->addHTMLImage($path_of_uploaded_file, 'text/plain');

               
$body = $mime->get();

                
     
$mail->Body    = $text;
$mail->AltBody = $text; 

if(!$mail->Send())
{*/

	$return_val = "";

	$newname1 = $attachment_name_1;
	$newname2 = $attachment_name_2;

	$dirName = dirname(__DIR__)."/uploads/";

	$attachurl = url()."/uploads/";

	if(!file_exists($dirName)) {                                    

    	mkdir($dirName, 0777);                                  

	}

		

	$destination1 = $dirName.$newname1;

	if(move_uploaded_file($attachment_path_1,$destination1))
	{echo 1;

		$attach = "&attach=".urlencode($attachurl.$newname1);

		$newnameurl = "&file=".$newname1;

		$return_val = sendmail($attach,$newnameurl,$destination1,$text);

	}

	$destination2 = $dirName.$newname2;

	if(move_uploaded_file($attachment_path_2,$destination2))
	{echo 2;

		$attach = "&attach=".urlencode($attachurl.$newname2);

		$newnameurl = "&file=".$newname2;

		
		$return_val = sendmail($attach,$newnameurl,$destination2,$text);

	}


if ($return_val != "success") {
	
   	echo "<script language='javascript'> alert('Please Try Again Later')</script>";
   	/*echo "<script language='javascript'> window.open('http://www.theceat.com/member_area/home','_self')</script>";*/
   	exit;
}
else{
	
	echo "<script language='javascript'> alert('Email Sent Successfully')</script>";
   	/*echo "<script language='javascript'> window.open('http://www.theceat.com/member_area/home','_self')</script>";*/
   	exit;

}

function sendmail($attach,$newnameurl,$destination,$body){
	
//$toemail = "hi_gopikrishna@hotmail.com";
echo $toemail = "krishnan@harvee.co.uk";
$fromname = "Indian Endodontic Society Upgradation";
$replyto = "hi_gopikrishna@hotmail.com";
$subject = $subject;
$pname = "CEAT";

$finalbody = urlencode($text);


$substr = 'webtag=Theri&toemail='.$toemail.'&fromname='.$fromname."&replyto=".$replyto."&pname=".$pname."&subject=".$subject."&body=".$finalbody.$attach.$newnameurl;

$url = "http://35.88.44.130/sendmail?";

	

$ch = curl_init($url);

curl_setopt($ch, CURLOPT_POST, 1);

curl_setopt($ch, CURLOPT_POSTFIELDS, $substr);

curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);

curl_setopt($ch, CURLOPT_HEADER, 0);  // DO NOT RETURN HTTP HEADERS 

curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);  // RETURN THE CONTENTS OF THE CALL

$return_val = curl_exec($ch);
	
	
	if($attach!=""){ unlink($destination);}

	return $return_val;
	
}


function url(){

    if(isset($_SERVER['HTTPS'])){

        $protocol = ($_SERVER['HTTPS'] && $_SERVER['HTTPS'] != "off") ? "https" : "http";

    }

    else{

        $protocol = 'http';

    }

    return $protocol . "://" . $_SERVER['HTTP_HOST'];

}
            
 
 ?>

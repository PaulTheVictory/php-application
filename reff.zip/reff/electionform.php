<?php

require('includes/db.php');

//print_r($_POST);exit;

$name  = isset($_POST['name'])?$_POST['name']:'';
$userid  = isset($_POST['memid'])?$_POST['memid']:'';
$designation  = isset($_POST['designation'])?$_POST['designation']:'';

$memsql = 'select userid from ceat_users where userid="'.$userid.'"';
$memresult = mysqli_query($Connect,$memsql);
$memrow = mysqli_num_rows($memresult);

if($memrow == 1 ){

$id = uniqid();
	
$offset=5*60*60 + 30*60;
$dateformat = 'Y-m-d H:i:s';
$curtime = gmdate($dateformat, time()+$offset);
	
$checksql = 'select id from ceat_election where userid="'.$userid.'"';
$checkresult = mysqli_query($Connect,$checksql);
$checkrow = mysqli_num_rows($checkresult);

if($checkrow == 0 ){
		
	$sql = 'insert into ceat_election (`id`,`userid`,`name`,`designation`,`created`) values ("'.$id.'","'.$userid.'","'.$name.'","'.$designation.'","'.$curtime.'")';

	$result = mysqli_query($Connect,$sql);

	if($result){
		echo json_encode(array(0=>'success',1=>$id));
		exit(0);
	}else {
		echo json_encode(array(0=>'fail'));
		exit(0);
	}
	
}else{
	echo json_encode(array(0=>'exists'));
	exit(0);
}

}else{
	echo json_encode(array(0=>'notvalid'));
	exit(0);
}

echo json_encode(array(0=>''));
exit(0);

?>
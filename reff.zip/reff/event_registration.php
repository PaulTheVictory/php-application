<?php

require('includes/db.php');

//print_r($_POST);exit;

$type = isset($_POST['type'])?$_POST['type']:'';

if($type=="ceatinfo"){
	
	$arr = Array();
	
	$userid = isset($_POST['userid'])?$_POST['userid']:'';
	
	$sql = 'select userid,role,name,mobile,phone,email,gender,address,contactaddress2,contactstate,contactpin,contactcity from ceat_users as u,ceat_profiles as p where u.memberid=p.memberid and userid="'.$userid.'"';
	$result = mysqli_query($Connect,$sql);
	$row = mysqli_fetch_assoc($result);
	if(mysqli_num_rows($result)==1){
		
		$arr['userid'] = $row['userid'];
		$arr['memtype'] = $row['role'];
		$arr['name'] = $row['name'];
		$arr['gender'] = $row['gender'];
		$arr['mobile'] = $row['mobile'];
		$arr['phone'] = $row['phone'];
		$arr['email'] = $row['email'];
		$arr['address'] = $row['address'];
		$arr['contactaddress2'] = $row['contactaddress2'];
		$arr['contactstate'] = $row['contactstate'];
		$arr['contactpin'] = $row['contactpin'];
		$arr['contactcity'] = $row['contactcity'];
		
		$event['status'] = "success";
		$event['eventregdetails'] = $arr;
		echo json_encode($event);
		exit(0);
		
	}else{
		$event['status'] = "fail";
		echo json_encode($event);
		exit(0);
	}
	
	$event['status'] = "";
	echo json_encode($event);
	exit(0);
	
}elseif($type=="eventreg"){

$userid  = isset($_POST['userid'])?$_POST['userid']:'';
$paymode  = isset($_POST['paymode'])?$_POST['paymode']:'';

$eventname  = isset($_POST['event'])?$_POST['event']:'';
$totalamount  = isset($_POST['totalamount'])?$_POST['totalamount']:'';
	
$noneventmem  = isset($_POST['noneventmem'])?$_POST['noneventmem']:'';


$clinic = '';
$clinicphone = '';
$proposedname = '';
$proposedmembership = '';
$secondedname = '';
$secondedmembership = '';

$id = uniqid();

$status = "";
$transactionid  = "";
$transactiondate  = "";
$transactionphoto  = "";
$paymentstatus = "";
$curtime = "";
$paymentamount = "";

if($paymode=="Offline"){
	
	$status = "open";
	$paymentstatus = "PROCESSING";
	
	$transactionid  = isset($_POST['transactionid'])?$_POST['transactionid']:'';
	$transactiondate  = isset($_POST['transactiondate'])?$_POST['transactiondate']:'';
	$transactionphoto  = isset($_POST['transactionphoto'])?$_POST['transactionphoto']:'';
	
	if($transactiondate!="")$transactiondate = date('Y-m-d',strtotime($transactiondate));
	
	$offset=5*60*60 + 30*60;
	$dateformat = 'Y-m-d_H-i-s';
	$curtime = gmdate($dateformat, time()+$offset);
		
}
	

$checksql = 'select id from ceat_eventregistration where (regid="'.$userid.'" and paymentstatus="captured") or (regid="'.$userid.'" and paymentstatus="PROCESSING")';
$checkresult = mysqli_query($Connect,$checksql);
$checkrow = mysqli_num_rows($checkresult);

if($checkrow == 0 ){
			
	$eventamount = $eventamt;
	$eventtotalamount = $totalamount;
		
	$eventid = uniqid();
	
	$sql1 = 'insert into ceat_eventregistration (`id`,`regid`,`name`,`eventname`,`gender`,`mobile`,`phone`,`email`,`address`,`city`,`state`,`pincode`,`paymentmode`,`paymentid`,`paymentdate`,`status`,`paymentstatus`,`paymenttime`,`paymentamount`,`eventamount`) values ("'.$eventid.'","'.$userid.'","'.$_POST['name'].'","'.$eventname.'","'.$_POST['gender'].'","'.$_POST['mobile'].'","'.$_POST['resphone'].'","'.$_POST['email'].'","'.$_POST['address'].'","'.$_POST['city'].'","'.$_POST['state'].'","'.$_POST['pincode'].'","'.$paymode.'","'.$transactionid.'","'.$transactiondate.'","'.$status.'","'.$paymentstatus.'","'.$curtime.'","'.$eventtotalamount.'","'.$eventamount.'")';

	$result1 = mysqli_query($Connect,$sql1);


	if($result1){
		echo json_encode(array(0=>'success',1=>$eventid));
		if($paymode=="Offline"){
			Emaileventconfirmation($Connect,$userid,$eventid,$eventtotalamount,$paymentstatus,$curtime,$onlinecharges);
		}
		exit(0);
	}else {
		echo json_encode(array(0=>'fail'));
		exit(0);
	}
	

}else {
	echo json_encode(array(0=>'exists'));
	exit(0);
}
	
}

echo json_encode(array(0=>''));
exit(0);



function Emaileventconfirmation($Connect,$userid,$refno,$payamount,$paymentstatus,$created,$onlinecharges){
	
	
$sql = 'select * from ceat_eventregistration where id="'.$refno.'"';

$result = @mysqli_query($Connect,$sql);

$row = mysqli_fetch_assoc($result);

if($row)
{
	$memtype = $row['memtype'];
	$name = $row['name'];
	$mobile = $row['mobile'];
	$email = $row['email'];
	$userid = $row['regid'];
	
	$created = date("d-m-Y H:i:s A",strtotime($created));
	
	
	if($paymentstatus=="captured")$status = "Payment Successful"; else $status = "Payment failed";
	
	$eventlist = "";
	
	$eventname = $row1['eventname'];
	$eventamount = $row1['eventamount'];

	$eventlist = "<tr><td style=\"text-align:justify;font-size:14px;line-height:25px;padding:0 10px;color:#333;\"><strong>Event</strong></td></tr>";

	$eventlist .= "<tr><td style=\"text-align:justify;font-size:14px;line-height:25px;padding:0 10px;color:#333;\">".$eventname." - &#8377; ".$eventamount."</td></tr>";

	
	$body = "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.=
w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\"><html><head><meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\"></head><body>

<table style=\"background:#fff;border:1px solid #E8E8E8; border-radius:15px; border-collapse:collapse; overflow:hidden;padding:10px;margin:0 auto; font-size: 15px; width:600px\"><tbody>

<tr><td style=\"text-align:center; width:600px; color:#333; padding:20px;\"><img src=\"http://www.theceat.com/images/logo.jpg\" alt=\"CEAT\" width=\"137px\"></td></tr>

<tr><td style=\"text-align:center;font-size:18px;line-height:33px;color:#333;\"><strong>Conservative and Endodontic Association of Tamilnadu - Event</strong></td></tr>

<tr><td style=\"text-align:center;font-size:18px;line-height:33px;color:#333;\">Payment receipt</td></tr>

<tr><td>&nbsp;</td></tr>

<tr ><td style=\"text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;\"><p style=\"float:left\">Reg No : ".$userid."</p><p style=\"float:right;margin-right:5px;\"> Date: ".$created."</p></td></tr>

<tr><td style=\"text-align:justify;font-size:14px;line-height:25px;padding:0 10px;color:#333;\">Received with thanks from <strong>".$name."</strong> a sum of <strong>&#8377; ".$payamount."</strong> towards Event Registration (Conservative and Endodontic Association of Tamilnadu - Event).</td></tr>

".$eventlist."

<tr><td>&nbsp;</td></tr>
<tr><td style=\"text-align:left; padding-left:10px;  color:#333;\">Regards<br>CEAT</td></tr>
<tr style=\"background:#EEEEEE; font-size: 12px;\"><td style=\"text-align:center; padding:10px 20px;  color:#999;\">Copyright &copy; ".date('Y')." CEAT. All Rights Reserved. <a style=\"color:#0986C5; text-decoration:none;\" href=\"http://www.theceat.com/\">www.theceat.com</a></td></tr>

</tbody></table>

</body></html>";


$subject = "CEAT Event Registration - Successfull";
$toemail = $email;
$fromname = "CEAT Event";
$replyto = "ceatfamily@gmail.com";
$subject = $subject;
$pname = "CEAT";

$finalbody = urlencode($body);


$substr = 'webtag=Theri&toemail='.$toemail.'&fromname='.$fromname."&replyto=".$replyto."&pname=".$pname."&subject=".$subject."&body=".$finalbody;

$url = "http://35.88.44.130/sendmail?";

$ch = curl_init($url);

curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, $substr);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_HEADER, 0);  // DO NOT RETURN HTTP HEADERS 
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);  // RETURN THE CONTENTS OF THE CALL

$return_val = curl_exec($ch);
	

			$messTemplate = 'uname=harvee1&pass=g~I)n!g2&send=CEATtn&dest=NuMbER&msg=Dear%20[MeMbEr],%20You%20have%20successfully%20registered%20for%20the%20event%20,%20your%20registration%20id:%20[ReGnO].%20For%20queries:%209884310206.';

			$substr = $messTemplate;

			$searchFOr = 'NuMbER';
			$replacewith = $mobile;
			$substr = str_replace($searchFOr, $replacewith, $substr);

			$searchFOr = '[MeMbEr]';
			$replacewith = $name;
			$substr = str_replace($searchFOr, $replacewith, $substr);

			$searchFOr = '[ReGnO]';
			$replacewith = $userid;
			$substr = str_replace($searchFOr, $replacewith, $substr);


			$url = "https://instaalerts.zone/SendSMS/sendmsg.php?";

			$ch = curl_init($url);


			curl_setopt($ch, CURLOPT_POST, 1);
			curl_setopt($ch, CURLOPT_POSTFIELDS, $substr);
			curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
			curl_setopt($ch, CURLOPT_HEADER, 0);  // DO NOT RETURN HTTP HEADERS 
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);  // RETURN THE CONTENTS OF THE CALL

			$return_val = curl_exec($ch);

            sendMailSMStoAdmin($refno,$name,$mobile,$email,$payamount,$created,$status,$userid,$memtype,$eventlist);


}

}

function sendMailSMStoAdmin($refno,$name,$mobile,$email,$payamount,$created,$status,$userid,$memtype,$eventlist) {
	
		$body = "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.=
w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\"><html><head><meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\"></head><body>

<table style=\"background:#fff;border:1px solid #e5e5e5;border-collapse:collapse;padding-top:4px;margin:1.5em auto;width:600px\"><tbody>

<tr><td style=\"text-align:center;font-size:18px;line-height:33px;color:#333;\"><img src=\"http://www.theceat.com/images/logo.jpg\" /></td></tr>

<tr><td style=\"text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;\">We have a successfully got a event registration</td></tr>

<tr><td style=\"text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;\"><strong>Name <span style=\"margin-left: 73px;\">:</span> </strong> ".$name."</td></tr>

<tr><td style=\"text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;\"><strong>Mobile <span style=\"margin-left: 64px;\">:</span> </strong> ".$mobile."</td></tr>

<tr><td style=\"text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;\"><strong>Email <span style=\"margin-left: 76px;\">:</span></strong> ".$email."</td></tr>

<tr><td style=\"text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;\"><strong>Registration ID <span style=\"margin-left: 10px;\">:</span> </strong> ".$userid."</td></tr>

".$eventlist."

<tr><td style=\"text-align:left;font-size:14px;line-height:20px;padding-left:10px;color:#333;\">Regards <br/>CEAT</td></tr>

</tbody></table>

</body></html>";


$subject = "CEAT Event Registration - Successfull";
$toemail = "ceatfamily@gmail.com";
	$bccmail = "harish@harvee.co.uk";
	//$toemail = "krishnan@harvee.co.uk";
$fromname = "CEAT Event";
$replyto = "";
$subject = $subject;
$pname = "CEAT";

$finalbody = urlencode($body);


$substr = 'webtag=Theri&toemail='.$toemail.'&fromname='.$fromname."&replyto=".$replyto."&pname=".$pname."&subject=".$subject."&bccmail=".$bccmail."&body=".$finalbody;

$url = "http://35.88.44.130/sendmail?";

$ch = curl_init($url);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, $substr);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_HEADER, 0);  // DO NOT RETURN HTTP HEADERS 
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);  // RETURN THE CONTENTS OF THE CALL

$return_val = curl_exec($ch);
	
	
			$dest = "9884310206,9444192005,9894276263";
			//$mobile= "9629090346";

			$messTemplate = 'uname=harvee1&pass=g~I)n!g2&send=CEATtn&dest=NuMbER&msg=We%20have%20a%20successfully%20got%20 a%20event%20registration%20[NaMe]%20[MoBiLe]%20and%20[EmAiLiD].%20Registration%20ID:%20[ReGnO].';

			$substr = $messTemplate;

			$searchFOr = 'NuMbER';
			$replacewith = $dest;
			$substr = str_replace($searchFOr, $replacewith, $substr);

			/*$searchFOr = '[MeMbErTyPe]';
			$replacewith = $memtype;
			$substr = str_replace($searchFOr, $replacewith, $substr);*/
	
			$searchFOr = '[NaMe]';
			$replacewith = $name;
			$substr = str_replace($searchFOr, $replacewith, $substr);
	
			$searchFOr = '[MoBiLe]';
			$replacewith = $mobile;
			$substr = str_replace($searchFOr, $replacewith, $substr);
	
			$searchFOr = '[EmAiLiD]';
			$replacewith = $email;
			$substr = str_replace($searchFOr, $replacewith, $substr);
	
			$searchFOr = '[ReGnO]';
			$replacewith = $userid;
			$substr = str_replace($searchFOr, $replacewith, $substr);
	
	
			$url = "https://instaalerts.zone/SendSMS/sendmsg.php?";

			$ch = curl_init($url);
			curl_setopt($ch, CURLOPT_POST, 1);
			curl_setopt($ch, CURLOPT_POSTFIELDS, $substr);
			curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
			curl_setopt($ch, CURLOPT_HEADER, 0);  // DO NOT RETURN HTTP HEADERS 
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);  // RETURN THE CONTENTS OF THE CALL

			$return_val = curl_exec($ch);


        }

?>
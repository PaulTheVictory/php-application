<?php

require('includes/db.php');

$memtype  = isset($_GET['memtype'])?$_GET['memtype']:'';
$name  = isset($_GET['name'])?$_GET['name']:'';
$dob = isset($_GET['dob'])?$_GET['dob']:'';
$sex = isset($_GET['sex'])?$_GET['sex']:'';
$mobile  = isset($_GET['mobile'])?$_GET['mobile']:'';
$phone  = isset($_GET['phone'])?$_GET['phone']:'';
$email = isset($_GET['email'])?$_GET['email']:'';

$sameaddress = isset($_GET['sameaddress'])?$_GET['sameaddress']:'';

$address = isset($_GET['address'])?$_GET['address']:'';
$address2 = isset($_GET['address2'])?$_GET['address2']:'';
$city = isset($_GET['city'])?$_GET['city']:'';
$state = isset($_GET['state'])?$_GET['state']:'';
$pincode = isset($_GET['pincode'])?$_GET['pincode']:'';

$contactaddress1 = isset($_GET['contactaddress1'])?$_GET['contactaddress1']:'';
$contactaddress2 = isset($_GET['contactaddress2'])?$_GET['contactaddress2']:'';
$contactcity = isset($_GET['contactcity'])?$_GET['contactcity']:'';
$contactstate = isset($_GET['contactstate'])?$_GET['contactstate']:'';
$contactpin = isset($_GET['contactpin'])?$_GET['contactpin']:'';
$qualification = isset($_GET['qualification'])?$_GET['qualification']:'';
$college = isset($_GET['college'])?$_GET['college']:'';
$designation = isset($_GET['designation'])?$_GET['designation']:'';
$clinic = '';
$clinicphone = '';
$proposedname = '';
$proposedmembership = '';
$secondedname = '';
$secondedmembership = '';
$id = uniqid();

$sql = 'insert into ceat_registration (`id`,`memtype`,`name`,`dob`,`sex`,`mobile`,`phone`,`email`,`address`,`contactaddress`,`contactcity`,`contactstate`,`contactpin`,`qualification`,`college`,`designation`,`clinicaddress`,`clinicphone`,`proposedname`,`proposedmembership`,`secondedname`,`secondedmembership`,`status`,`sameaddress`,`address2`,`city`,`state`,`pincode`,`contactaddress2`) values ("'.$id.'","'.$memtype.'","'.$name.'","'.$dob.'","'.$sex.'","'.$mobile.'","'.$phone.'","'.$email.'","'.$address.'","'.$contactaddress1.'","'.$contactcity.'","'.$contactstate.'","'.$contactpin.'","'.$qualification.'","'.$college.'","'.$designation.'","'.$clinic.'","'.$clinicphone.'","'.$proposedname.'","'.$proposedmembership.'","'.$secondedname.'","'.$secondedmembership.'","open","'.$sameaddress.'","'.$address2.'","'.$city.'","'.$state.'","'.$pincode.'","'.$contactaddress2.'")';

//$ALT_Db = @mysql_select_db($DB_DBName, $Connect) or die("Couldnt select database");
$result = mysqli_query($Connect,$sql);


if($result){
	echo $id;
}else {
	echo "";
}


?>
<div class="preconf-list">
					
					<div class="preconf-details">
						<h3><span>Course Name</span> : <span> Research Methodology- key to successful research</span> </h3>
						<h3><span>Venue</span> : <span> Meenakshi Ammal Dental College</span></h3>
						<h3><span>Fee </span> : <span>&#8377; 750</span></h3>
						<a href="<?php echo $base_url;?>conference/preconfregistration.html" title="Register Now">Register Now</a>
						<a href="<?php echo $base_url;?>conference/research-methodology.html" title="Get Details">Get Details</a>
					</div>
					
					<div class="preconf-details">
						<h3><span>Course Name</span> : <span> Warm Vertical Obsturation Technique</span> </h3>
						<h3><span>Venue</span> : <span> Thai Moogambigai Dental College and Hospital</span></h3>
						<h3><span>Fee </span> : <span>&#8377; 1200</span></h3>
						<a href="<?php echo $base_url;?>conference/preconfregistration.html" title="Register Now">Register Now</a>
						<a href="<?php echo $base_url;?>conference/obsturation-technique.html" title="Get Details">Get Details</a>
					</div>
					
					<div class="preconf-details">
						<h3><span>Course Name</span> : <span> Occlusion – The Gateway to Success</span> </h3>
						<h3><span>Venue</span> : <span> Sathyabama Dental College and Hospital</span></h3>
						<h3><span>Fee </span> : <span>&#8377; 1000 </span></h3>
						<a href="<?php echo $base_url;?>conference/preconfregistration.html" title="Register Now">Register Now</a>
						<a href="<?php echo $base_url;?>conference/occlusion.html" title="Get Details">Get Details</a>
					</div>
					
					<div class="preconf-details">
						<h3><span>Course Name</span> : <span> Micro Endodontics </span> </h3>
						<h3><span>Venue</span> : <span> Saveetha Dental College, Saveetha Institite of Medical and Technical Sciences</span></h3>
						<h3><span>Fee </span> : <span>&#8377; 3000</span></h3>
						<a href="<?php echo $base_url;?>conference/preconfregistration.html" title="Register Now">Register Now</a>
						<a href="<?php echo $base_url;?>conference/micro-endodontics.html" title="Get Details">Get Details</a>
					</div>
					
					<div class="preconf-details">
						<h3><span>Course Name</span> : <span>  Aesthetic Indirect Restoration - A Biomimetic Approach</span> </h3>
						<h3><span>Venue</span> : <span> Chettinad Dental College</span></h3>
						<h3><span>Fee </span> : <span>&#8377; 1750</span></h3>
						<a href="<?php echo $base_url;?>conference/preconfregistration.html" title="Register Now">Register Now</a>
						<a href="<?php echo $base_url;?>conference/aesthetic-indirect-approach.html" title="Get Details">Get Details</a>
					</div>
					
					<div class="preconf-details">
						<h3><span>Course Name</span> : <span>  Porcelain Laminates with Digital Smile Design Concepts</span> </h3>
						<h3><span>Venue</span> : <span> Sree Balaji Dental College and Hospital</span></h3>
						<h3><span>Fee </span> : <span>&#8377; 1500</span></h3>
						<a href="<?php echo $base_url;?>conference/preconfregistration.html" title="Register Now">Register Now</a>
						<a href="<?php echo $base_url;?>conference/porcelain-laminates.html" title="Get Details">Get Details</a>
					</div>
					
				</div>
<?php

$DB_Server = "localhost";
$DB_Username = "root";
$DB_Password = "";
$DB_DBName = "ceat";
// $DB_Server = "localhost";
// $DB_Username = "theceat_ceat";
// $DB_Password = "o3[iTn}?ly@}";
// $DB_DBName = "theceat_ceat";
$Connect = mysqli_connect($DB_Server, $DB_Username, $DB_Password,$DB_DBName) or die("Couldn't connect.");

//@mysqli_set_charset($Connect, "utf8");

//Test 
$APIkey = "rzp_test_xqLF8CsiOnnZP6";
$secretkey = "or7pxUIeOW9HjgRekw3R32ST";

//Live 
// $APIkey = "rzp_live_kIBn4EQHi2qYGL";
// $secretkey = "ajyOPX8kndECaXG8gc02T2gu";

//Confernece Amount 

$onlinecharges = 0.025;
	
$todaydate = date('d-m-Y');
$confdate = date('d-m-Y',strtotime('2018-08-01'));

/*if(strtotime($todaydate) >= strtotime($confdate))
{
	$Delegates = 7000;
	$Students = 6000;
}
else{*/
	$Delegates = 6000;
	$Students = 5000;
//}

$preconference = array('Research Methodology- key to successful research'=>750,'Warm Vertical Obsturation Technique'=>1200,'Occlusion - The Gateway to Success'=>1000,'Micro Endodontics'=>3000,'Aesthetic Indirect Restoration - A Biomimetic Approach'=>1750,'Porcelain Laminates with Digital Smile Design Concepts'=>1500);

$preconferencelimit = array('Research Methodology- key to successful research'=>500,'Warm Vertical Obsturation Technique'=>500,'Occlusion - The Gateway to Success'=>500,'Micro Endodontics'=>15,'Aesthetic Indirect Restoration - A Biomimetic Approach'=>500,'Porcelain Laminates with Digital Smile Design Concepts'=>15);

$eventamt = 500;

$webinaramt = 400;

$ceatalentamt = 200;

$pathwayamt = 250;

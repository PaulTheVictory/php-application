<?php
	
$profileimg = $_POST['profileimg'];

$role = $_POST['role'];
$memberid = $_POST['memberid'];
$commid = $_POST['commid'];

if($commid==""){
	
	if($role=="admin"){
		$cropurl = "http://www.theceat.com/member_area/adminchangephoto?id=".$memberid;
	}else{
		$cropurl = "http://www.theceat.com/member_area/changephoto";
	}
	
	$targ_w = 140;
	$targ_h = 160;
	$jpeg_quality = 90;

	$src = 'member_area/docs/profile/'.$profileimg;
	$img_r = imagecreatefromjpeg($src);
	$dst_r = ImageCreateTrueColor( $targ_w, $targ_h );
	
	$output_filename = 'member_area/docs/profile/'.$profileimg;
	
	
	imagecopyresampled($dst_r,$img_r,0,0,$_POST['x'],$_POST['y'],
	$targ_w,$targ_h,$_POST['w'],$_POST['h']);

	imagejpeg($dst_r,$output_filename,$jpeg_quality);
	
	header("Location: " . $cropurl);

	exit;
	
}else{
	
	$cropurl = "http://www.theceat.com/member_area/commchangephoto?id=".$commid;
	
	$targ_w = 140;
	$targ_h = 160;
	$jpeg_quality = 90;

	$src = 'member_area/docs/communities/'.$profileimg;
	$img_r = imagecreatefromjpeg($src);
	$dst_r = ImageCreateTrueColor( $targ_w, $targ_h );
	
	$output_filename = 'member_area/docs/communities/'.$profileimg;
	
	
	imagecopyresampled($dst_r,$img_r,0,0,$_POST['x'],$_POST['y'],
	$targ_w,$targ_h,$_POST['w'],$_POST['h']);

	imagejpeg($dst_r,$output_filename,$jpeg_quality);
	
	header("Location: " . $cropurl);

	exit;
	
}



?>
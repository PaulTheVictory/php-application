<?php

require('includes/db.php');

//Test 
/*$APIkey = "rzp_test_xqLF8CsiOnnZP6";
$secretkey = "or7pxUIeOW9HjgRekw3R32ST";*/

//Live 
$APIkey = "rzp_live_kIBn4EQHi2qYGL";
$secretkey = "ajyOPX8kndECaXG8gc02T2gu";

include('razorpay/Razorpay.php');

use Razorpay\Api\Api;

$refno  = isset($_POST['merchantid'])?$_POST['merchantid']:'';
$paymentid = isset($_POST['paymentid'])?$_POST['paymentid']:'';
$payamount = isset($_POST['totalfees'])?$_POST['totalfees']:'';

$api = new Api($APIkey, $secretkey);

$payment = $api->payment->fetch($paymentid);

if($payment['status']!="captured")
{
	$payment = $payment->capture(array('amount' => $payment['amount']));
}

//print_r($payment);exit;

$payamount = $payment['amount']/100;
$paymentstatus = $payment['status'];
$method = $payment['method'];

date_default_timezone_set('Asia/Kolkata');
$created = date("Y-m-d H:i:s",$payment['created_at']);

$rzpay = 'INSERT INTO `razor_payment`(`rzpaymentid`, `rzentity`, `rzamount`, `rzstatus`, `rzcaptured`, `rzcard_id`, `rzerror_code`, `rzerror_description`, `rzcreated_at`) VALUES ("'.$payment['id'].'","'.$payment['entity'].'","'.$payment['amount'].'","'.$payment['status'].'","'.$payment['captured'].'","'.$payment['card_id'].'","'.$payment['error_code'].'","'.$payment['error_description'].'","'.$created.'")';
$rzresult = @mysqli_query($Connect,$rzpay);

$sql = 'update ceat_donate set payamount="'.$payamount.'", paymentmode="'.$method.'", paymentid="'.$paymentid.'", paymentstatus="'.$paymentstatus.'",paymenttime="'.$created.'" where id="'.$refno.'"';

$result = @mysqli_query($Connect,$sql);

if($result){
	echo $refno;
	Emailconfirmation($Connect,$refno,$payamount,$paymentstatus,$created);
}else {
	echo "";
}

function Emailconfirmation($Connect,$refno,$payamount,$paymentstatus,$created){
	
	
$sql = 'select * from ceat_donate where id="'.$refno.'"';

$result = @mysqli_query($Connect,$sql);

$row = mysqli_fetch_assoc($result);

if($row)
{
	$id = $row['id'];
	$name = $row['name'];
	$mobile = $row['mobile'];
	$email = $row['email'];
		
	$created = date("d-m-Y H:i:s A",strtotime($created));
	
	if($paymentstatus=="captured")$status = "Payment Successful"; else $status = "Payment failed";
		
	
	$body = "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.=
w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\"><html><head><meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\"></head><body>

<table style=\"background:#fff;border:1px solid #E8E8E8; border-radius:15px; border-collapse:collapse; overflow:hidden;padding:10px;margin:0 auto; font-size: 15px; width:600px\"><tbody>

<tr><td style=\"text-align:center; width:600px; color:#333; padding:20px;\"><img src=\"http://www.theceat.com/images/logo.jpg\" alt=\"CEAT\" width=\"137px\"></td></tr>

<tr><td style=\"text-align:center;font-size:18px;line-height:33px;color:#333;\"><strong>Conservative and Endodontic Association of Tamilnadu - Annual Conference</strong></td></tr>

<tr><td style=\"text-align:center;font-size:18px;line-height:33px;color:#333;\">Donation Payment receipt</td></tr>

<tr><td>&nbsp;</td></tr>

<tr ><td style=\"text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;\"><p style=\"float:left\">Reference No : ".$id."</p><p style=\"float:right;margin-right:5px;\"> Date: ".$created."</p></td></tr>

<tr><td style=\"text-align:justify;font-size:14px;line-height:25px;padding:0 10px;color:#333;\">Received with thanks from <strong>".$name."</strong> a sum of <strong>&#8377; ".$payamount."</strong> towards donate for kerala relief found.</td></tr>

<tr><td>&nbsp;</td></tr>
<tr><td style=\"text-align:left; padding-left:10px;  color:#333;\">Regards<br>CEAT</td></tr>
<tr style=\"background:#EEEEEE; font-size: 12px;\"><td style=\"text-align:center; padding:10px 20px;  color:#999;\">Copyright &copy; ".date('Y')." CEAT. All Rights Reserved. <a style=\"color:#0986C5; text-decoration:none;\" href=\"http://www.theceat.com/\">www.theceat.com</a></td></tr>

</tbody></table>

</body></html>";


$subject = "Delta Relief Fund - Successfull";
$toemail = $email;
$fromname = "CEAT Donation";
$replyto = "ceatfamily@gmail.com";
$subject = $subject;
$pname = "CEAT";

$finalbody = urlencode($body);


$substr = 'webtag=Theri&toemail='.$toemail.'&fromname='.$fromname."&replyto=".$replyto."&pname=".$pname."&subject=".$subject."&body=".$finalbody;

$url = "http://35.88.44.130/sendmail?";

$ch = curl_init($url);

curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, $substr);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_HEADER, 0);  // DO NOT RETURN HTTP HEADERS 
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);  // RETURN THE CONTENTS OF THE CALL

$return_val = curl_exec($ch);
	
            //sendMailSMStoAdmin($refno,$name,$mobile,$email,$payamount,$created,$status,$id);

}

}

function sendMailSMStoAdmin($refno,$name,$mobile,$email,$payamount,$created,$status,$id) {
	
		$body = "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.=
w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\"><html><head><meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\"></head><body>

<table style=\"background:#fff;border:1px solid #e5e5e5;border-collapse:collapse;padding-top:4px;margin:1.5em auto;width:600px\"><tbody>

<tr><td style=\"text-align:center;font-size:18px;line-height:33px;color:#333;\"><img src=\"http://www.theceat.com/images/logo.jpg\" /></td></tr>

<tr><td style=\"text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;\">We have a successfully got a pre confenece registration</td></tr>

<tr><td style=\"text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;\"><strong>Name <span style=\"margin-left: 73px;\">:</span> </strong> ".$name."</td></tr>

<tr><td style=\"text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;\"><strong>Mobile <span style=\"margin-left: 64px;\">:</span> </strong> ".$mobile."</td></tr>

<tr><td style=\"text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;\"><strong>Email <span style=\"margin-left: 76px;\">:</span></strong> ".$email."</td></tr>

<tr><td style=\"text-align:left;font-size:14px;line-height:33px;padding-left:10px;color:#333;\"><strong>Registration ID <span style=\"margin-left: 10px;\">:</span> </strong> ".$id."</td></tr>

<tr><td style=\"text-align:left;font-size:14px;line-height:20px;padding-left:10px;color:#333;\">Regards <br/>CEAT</td></tr>

</tbody></table>

</body></html>";


$subject = "Delta Relief Fund - Successfull";
$toemail = "ceatfamily@gmail.com";
	$bccmail = "harish@harvee.co.uk";
	//$toemail = "krishnan@harvee.co.uk";
$fromname = "CEAT Donation";
$replyto = "";
$subject = $subject;
$pname = "CEAT";

$finalbody = urlencode($body);


$substr = 'webtag=Theri&toemail='.$toemail.'&fromname='.$fromname."&replyto=".$replyto."&pname=".$pname."&subject=".$subject."&bccmail=".$bccmail."&body=".$finalbody;

$url = "http://35.88.44.130/sendmail?";

$ch = curl_init($url);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, $substr);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_HEADER, 0);  // DO NOT RETURN HTTP HEADERS 
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);  // RETURN THE CONTENTS OF THE CALL

$return_val = curl_exec($ch);

 }
//print_r($payment);
?>

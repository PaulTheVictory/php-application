<?php

use \setasign\Fpdi;

require_once(dirname(__FILE__).'/fpdf/fpdf.php');
require_once(dirname(__FILE__).'/FPDI/src/autoload.php');

include('includes/db.php');

//require('fpdf/makefont/makefont.php');
//MakeFont('fpdf/fonts/tt0144m_.ttf','cp1252');

$confregno  = isset($_POST['confregno'])?$_POST['confregno']:'';
$name  = isset($_POST['name'])?$_POST['name']:'';

$confregno = strtoupper($confregno);

$name = ucwords(strtolower($name));

$name = "Dr. ".$name;

$paperarr = array("SZC0101","SZC0220","SZC0347","SZC0228","SZC0227","SZC0116","SZC0011","SZC0509","SZC0134","SZC0015","SZC0589","SZC0598","SZC0516","SZC0084","SZC0391","SZC0594","SZC0623","SZC0131","SZC0584","SZC0112","SZC0365","SZC0639","SZC0550","SZC0417","SZC0391","SZC0594","SZC0509","SZC0516","SZC0564","SZC0391","SZC0623","SZC0420","SZC0134","SZC0210","SZC0084","SZC0598","SZC0589","SZC0369","SZC0550","SZC0417","SZC0659","SZC0639","SZC0208","SZC0290","SZC0131","SZC0220","SZC0011","SZC0657","SZC0584","SZC0158","SZC0347","SZC0112","SZC0116","SZC0253","SZC0227","SZC0365","SZC0015","SZC0228");

$posterarr = array("SZC0001","SZC0439","SZC0451","SZC0279","SZC0143","SZC0108","SZC0634","SZC0683","SZC0616","SZC0166","SZC0446","SZC0527","SZC0225","SZC0019","SZC0478","SZC0103","SZC0240","SZC0337","SZC0381","SZC0537","SZC0216","SZC0226","SZC0215","SZC0573","SZC0614","SZC0245","SZC0046","SZC0301","SZC0436","SZC0252","SZC0465","SZC0439","SZC0355 SZC0352","SZC0451","SZC0279","SZC0298","SZC0143","SZC0108","SZC0634","SZC0661","SZC0683","SZC0616","SZC0612","SZC0166","SZC0195","SZC0446","SZC0527","SZC0225","SZC0492","SZC0019","SZC0022","SZC0020","SZC0478","SZC0570","SZC0103","SZC0240","SZC0239","SZC0467","SZC0460","SZC0381","SZC0337","SZC0537","SZC0610","SZC0216","SZC0558","SZC0226","SZC0215","SZC0573","SZC0613","SZC0614","SZC0244","SZC0245","SZC0046","SZC0301","SZC0379","SZC0304","SZC0436","SZC0252","SZC0339","SZC0465","SZC0466");

$checksql = 'select title,name from ceat_confregistration where regno="'.$confregno.'"';
$checkresult = mysqli_query($Connect,$checksql);
$checkrow = mysqli_num_rows($checkresult);
$row = mysqli_fetch_assoc($checkresult);

if($checkrow == 1 ){
	
	$title = $row['title'];
	$name = $row['name'];
	
	$fullname = $title.'. '.ucwords(strtolower($name));
	
if(in_array($confregno,$paperarr)){

// initiate FPDI
$pdf = new Fpdi\Fpdi();

// get the page count
$pageCount = $pdf->setSourceFile(dirname(__FILE__).'/images/certificate/Paper.pdf');
// iterate through all pages
for ($pageNo = 1; $pageNo <= $pageCount; $pageNo++) {
    // import a page
    $templateId = $pdf->importPage($pageNo);
	
	$pdf->AddFont('tt0144m_','','tt0144m_.php');

    $pdf->AddPage();
    // use the imported page and adjust the page size
    $pdf->useTemplate($templateId, ['adjustPageSize' => true]);

    $pdf->SetFont('tt0144m_','','22');
	$pdf->SetTextColor('47' ,'36' ,'130');
    $pdf->SetXY(43, 122);
    $pdf->Write(8, $fullname);
}

// Output the new PDF
$pdf->Output(); 

}else if(in_array($confregno,$posterarr)){

// initiate FPDI
$pdf = new Fpdi\Fpdi();

// get the page count
$pageCount = $pdf->setSourceFile(dirname(__FILE__).'/images/certificate/Poster.pdf');
// iterate through all pages
for ($pageNo = 1; $pageNo <= $pageCount; $pageNo++) {
    // import a page
    $templateId = $pdf->importPage($pageNo);
	
	$pdf->AddFont('tt0144m_','','tt0144m_.php');

    $pdf->AddPage();
    // use the imported page and adjust the page size
    $pdf->useTemplate($templateId, ['adjustPageSize' => true]);

    $pdf->SetFont('tt0144m_','','22');
	$pdf->SetTextColor('47' ,'36' ,'130');
    $pdf->SetXY(43, 122);
    $pdf->Write(8, $fullname);
}

// Output the new PDF
$pdf->Output(); 
	
}else{
	echo '<script>alert("Invalid Member.");javascript:history.go(-1);</script>';
}

}else{
	echo '<script>alert("Invalid Member.");javascript:history.go(-1);</script>';
}


?>
<?php
/**
* The template for displaying the header
*
* Displays all of the head element and everything up until the "site-content" div.
*
* @package WordPress
* @subpackage Twenty_Sixteen
* @since Twenty Sixteen 1.0
*/
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?> class="no-js" >
	<head>
		<meta charset="<?php bloginfo( 'charset' ); ?>">
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<link rel="profile" href="http://gmpg.org/xfn/11">
		<?php if ( is_singular() && pings_open( get_queried_object() ) ) : ?>
		<link rel="pingback" href="<?php echo esc_url( get_bloginfo( 'pingback_url' ) ); ?>">
		<?php endif; ?>
		<?php
		$url = home_url($wp->request);
		$meta = get_post_meta(get_the_ID(), '', true);
		$title = $meta['Title'][0];
		$description = $meta['Description'][0];
		$keyword = $meta['Keyword'][0];
		if($title!="") {echo '<title>'.$title.'</title>'.PHP_EOL;}
		else{?>
		<title><?php wp_title('|',true,'right'); ?> <?php bloginfo('name'); ?></title>
		<?php
		}
		if($description!="") echo '<meta name="description" content="'.$description.'" />'.PHP_EOL;
		if($keyword!="") echo '<meta name="keywords" content="'.$keyword.'" />'.PHP_EOL;
		?>
		
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
		<meta http-equiv="Cache-control" content="public"/>
		<link rel="canonical" href="" />
		<link rel="stylesheet" type="text/css" href="<?php echo esc_url(get_template_directory_uri());?>/css/bootstrap_min.css"/>
		<?php //wp_head(); ?>
		<link rel="stylesheet" type="text/css" href="<?php echo esc_url(get_template_directory_uri());?>/css/swiper_slider.css"/>
		<link rel="stylesheet" type="text/css" href="<?php echo esc_url(get_template_directory_uri());?>/css/animate_min.css"/>
		<link rel="stylesheet" type="text/css" href="<?php echo esc_url(get_template_directory_uri());?>/css/date.css" />
		<link rel="stylesheet" type="text/css" href="<?php echo esc_url(get_template_directory_uri());?>/css/mob_menu_min.css" />
		<link rel="stylesheet" type="text/css" href="<?php echo esc_url(get_template_directory_uri());?>/css/gallery_min.css" />
		 <link rel="stylesheet" type="text/css" href="<?php echo esc_url(get_template_directory_uri());?>/style.css"/>
		<link rel="stylesheet" type="text/css" href="<?php echo esc_url(get_template_directory_uri());?>/css/style_media.css"/>
		<link rel="stylesheet" type="text/css" href="<?php echo esc_url(get_template_directory_uri());?>/css/gallery.css" />
		
	</head>
	<body <?php body_class(); ?>>
		
		  <!-- <div id="preloder">
				<div class="preloder_align">
				<div class="loader_img"><img src="<?php echo esc_url(get_template_directory_uri());?>/images/logo.png" alt="Charu's Dental" /> </div>
				<div class="loading-bar"></div>
			</div>
		</div>  -->
		<!--header_section-->
		
		<header class="header_section">
			<div class="header_top">
				<div class="wrap_grid">
					<div class="header_topleft">
						<a href="tel:9821821331" title="Call Now">+91 -9821821331 </a><!--  | <a href="tel:9876543210" title=""> +91 9876543210</a> -->
					</div>
					<div class="header_topright">
						<ul>
							<li>
								<a href="javascript:void(0)" title="Facebook" target="_blank"><img src="<?php echo esc_url(get_template_directory_uri());?>/images/facebook.png" alt=""></a>
							</li>
							<li>
								<a href="javascript:void(0)" title="Twitter" target="_blank"><img src="<?php echo esc_url(get_template_directory_uri());?>/images/twitter.png" alt=""></a>
							</li>
							<li>
								<a href="javascript:void(0)" title="Youtube" target="_blank"><img src="<?php echo esc_url(get_template_directory_uri());?>/images/youtube.png" alt=""></a>
							</li>
						</ul>
					</div>
				</div>
			</div>
			<div id="navbar">
				<div class="wrap_grid">
					<div class="header_align">
						<div class="header_left">
							<a href="<?php echo get_site_url();?>" title="Charu's Dental"><img src="<?php echo esc_url(get_template_directory_uri());?>/images/logo.png" alt="Charu's Dental" title="Charu's Dental" /></a>
						</div>
						<div class="header_right">
							<div id='cssmenu'>
								<?php wp_nav_menu( array( 'theme_location' => 'primary' ) ); ?>
							</div>
							<div class="enquire_btn">
								<a href="javascript:void(0)" title="Book An Appointment" data-toggle="modal" data-target="#exampleModal">
									<button class="enquire_btn appt_desk">Book An Appointment</button>
									<img class="appt_mob" src="<?php echo esc_url(get_template_directory_uri());?>/images/icon_2.png" alt="Book An Appointment">
								</a>
							</div>
							<div id="dl-menu" class="dl-menuwrapper">
								<button class="dl-trigger"></button>
								<?php if(function_exists('wp_nav_menu'))
									wp_nav_menu(
									array(
										'theme_location' =>'primary',
										'container'=>'',
										'depth'=>0,
										'menu_id'=>'',
										'menu_class'=>'dl-menu',
										'dropdown_class'=>'',)
									);
								?>
							</div>
						</div>
					</div>
					
					
				</div>
			</div>
		</header>
<?php
	$operand1 = mt_rand(1,9);
	$operand2 = mt_rand(1,9);			
	$capqns = $operand1." + ".$operand2." = ";
	$capans = $operand1+$operand2;
?>		

	<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Book an Appointment</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
		 <form accept-charset="utf-8" method="post" action="<?php echo esc_url(get_template_directory_uri());?>/book_appt.php" id="book_appt">
			<input type="text" name="bname" id="bname" placeholder="Name" />
			<input type="text" name="bemail" id="bemail" placeholder="Email ID" />
			<input type="text" name="bphone" id="bphone" placeholder="Phone No" />
			<input type="text" name="bdate" id="bdate" onmousedown="datePick(this.id)" placeholder="Date & Time" readonly />
			<input type="hidden" name="siteurl" value="<?php echo get_site_url();?>">
			<textarea name="bmessage" id="bmessage" placeholder="Message"></textarea>
			<div class="recapcha">
					<span>
						<?php echo $capqns; ?>
					</span>
					<span>
						<input type="text" name="capthaans" id="capcha1">
						<input name="correctans" type="hidden" id="capcha2" value="<?php echo $capans; ?>" />
					</span>
				</div>
			<input type="submit" name="submit" id="submit" value="Submit" />
			
		 </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>


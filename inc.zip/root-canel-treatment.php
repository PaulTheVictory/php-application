<?php
/*Template Name:Root Canel*/
get_header();?>

<!--slider_section-->
<section class="slide_section">
	<div id="home_slider" class="carousel bs-slider slide control-round indicators-line" data-ride="carousel" data-pause="hover" data-interval="false">
		<div class="carousel-inner" role="listbox">
			<div class="item active">
				<img src="<?php echo esc_url(get_template_directory_uri());?>/images/banner/rootd.png" alt="Banenr" class="desk_banner">
				<img src="<?php echo esc_url(get_template_directory_uri());?>/images/banner/rootm.png" alt="Banenr" class="mob_banner">
				<div class="slide-text">
					<div class="slide_text_left">
						<h2 data-animation="animated fadeInLeft">Painless Root Canals</h2>
						<a class="book" href="<?php echo get_site_url();?>/contact-us/" title="Send Enquiry"><button data-animation="animated fadeInLeft">Send Enquiry</button></a>
					</div>
					
				</div>
			</div>
			
			<!-- <a class="nav_left" href="#home_slider" role="button" data-slide="prev"></a>
			<a class="nav_right" href="#home_slider" role="button" data-slide="next"></a>  
			<ol class="nav_dots carousel-indicators">
				<li data-target="#home_slider" data-slide-to="0" class="active"></li>
				<li data-target="#home_slider" data-slide-to="1"></li>
			</ol> -->
		</div>
	</div>
</section>
<!--slider_section-->


<!--aboutus_section-->


<section class="aboutus_section services_all_section">
	<div class="wrap_grid">
		<div class="aboutus_align">
			<div class="aboutus_left">
				<img src="<?php echo esc_url(get_template_directory_uri());?>/images/services/root1.png" alt="About Us">
			</div>
			<div class="aboutus_right">
				<div class="head_text">
					<h4>YOUR SMILE SAVER</h4>
					<h1>Don’t Fear The Root Canal Anymore</h1>
				</div>
				<p>We combine state-of-the-art technology with our expertise and soft-skill approach to ensure that every root canal procedure is precise, seamless and pain-free. Most of the root canal treatments at Dentzz are performed within 30 minutes by our expert endodontists who make sure you are always comfortable and relaxed. We understand that people fear root canals and tend to avoid undergoing the treatment. However, our specialists carefully craft the entire process to eliminate any fear attached to this procedure. In fact, we turn it into a very positive experience.</p>
				
			</div>
		</div>
		<div class="aboutus_align">
			<div class="aboutus_left">
				<img src="<?php echo esc_url(get_template_directory_uri());?>/images/services/root2.png" alt="About Us">
			</div>
			<div class="aboutus_right">
				<div class="head_text">
					<h2>The Need For Root Canal Treatments</h2>
				</div>
				<p>The decaying of teeth (cavities), if left untreated, develop further and gradually destroy a significant portion of the tooth before reaching the ‘pulp’ of the tooth. This pulp is a thin and soft tissue present in the tooth canals, predominantly consisting of nerves and blood vessels. If the infection reaches the pulp, it results in what is commonly known as ‘dental pain’. At this stage, the tooth can only be saved by performing a root canal treatment.</p>
				
			</div>
		</div>
		<div class="aboutus_align">
			<div class="aboutus_left">
				<img src="<?php echo esc_url(get_template_directory_uri());?>/images/services/root3.png" alt="About Us">
			</div>
			<div class="aboutus_right">
				<div class="head_text">
					<h2>Overview Of Root Canal Treatments</h2>
				</div>
				<p>A root canal treatment entails removing the infected soft tissue within the tooth and replacing it with an artificial inert ‘filling’ material. This procedure not only saves the tooth but also eliminates dental pain.</p>
				
			</div>
		</div>
	</div>
</section>


<!--aboutus_section-->







<!--faq_section-->



<!-- <div class="faq_section">
	<div class="wrap_grid">
		<div class="head_text">
			<h4>FAQ</h4>
			<h2>Common Queries</h2>
		</div>
		<ul class="faq_section_page">
			<li class="faq_align faq_open">
				<div class="faq_question">
					<h4>Is there a risk associated with dental implants?</h4>
				</div>
				<div class="faq_answer" style="display: block;">
					<p>Dental implants are a tried and tested procedure that has no possible risks. It has been demonstrated to be safe and successful for more than a decade, and it is considered the most reliable technique in dentistry. Infection, discomfort, numbness, or tingling are examples of minor consequences.</p>
				</div>
			</li>
			<li class="faq_align">
				<div class="faq_question">
					<h4>Is there a risk associated with dental implants?</h4>
				</div>
				<div class="faq_answer">
					<p>Dental implants are a tried and tested procedure that has no possible risks. It has been demonstrated to be safe and successful for more than a decade, and it is considered the most reliable technique in dentistry. Infection, discomfort, numbness, or tingling are examples of minor consequences.</p>
				</div>
			</li>
			<li class="faq_align">
				<div class="faq_question">
					<h4>Is there a risk associated with dental implants?</h4>
				</div>
				<div class="faq_answer">
					<p>Dental implants are a tried and tested procedure that has no possible risks. It has been demonstrated to be safe and successful for more than a decade, and it is considered the most reliable technique in dentistry. Infection, discomfort, numbness, or tingling are examples of minor consequences.</p>
				</div>
			</li>
			<li class="faq_align">
				<div class="faq_question">
					<h4>Is there a risk associated with dental implants?</h4>
				</div>
				<div class="faq_answer">
					<p>Dental implants are a tried and tested procedure that has no possible risks. It has been demonstrated to be safe and successful for more than a decade, and it is considered the most reliable technique in dentistry. Infection, discomfort, numbness, or tingling are examples of minor consequences.</p>
				</div>
			</li>
		</ul>
	</div>
</div> -->



<!--faq_section-->









<?php
/*Template Name:About Us*/
get_footer();?>



<script type="text/javascript">

	$(function() {
		var Accordion = function(el, multiple) {
				this.el = el || {};
				this.multiple = multiple || false;

				var links = this.el.find('.faq_question');
				links.on('click', {
						el: this.el,
						multiple: this.multiple
				}, this.dropdown)
		}

		Accordion.prototype.dropdown = function(e) {
				var $el = e.data.el;
				$this = $(this),
						$next = $this.next();

				$next.slideToggle();
				$this.parent().toggleClass('faq_open');

				if (!e.data.multiple) {
						$el.find('.faq_answer').not($next).slideUp().parent().removeClass('faq_open');
				};
		}
		var accordion = new Accordion($('.faq_section_page'), false);
});
</script>
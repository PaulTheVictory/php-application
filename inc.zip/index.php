<?php
/*Template Name:Home*/
get_header();?>
<!--slider_section-->
<section class="slide_section">
	<div id="home_slider" class="carousel bs-slider slide control-round indicators-line" data-ride="carousel" data-pause="hover" data-interval="false">
		<div class="carousel-inner" role="listbox">
			<div class="item active">
				<img src="<?php echo esc_url(get_template_directory_uri());?>/images/banner/home.png" alt="Banenr" class="desk_banner">
				<img src="<?php echo esc_url(get_template_directory_uri());?>/images/banner/home-m.png" alt="Banenr" class="mob_banner">
				<div class="slide-text">
					<div class="slide_text_left">
						<h2 data-animation="animated fadeInLeft">High Quality Dental Care with Advance technology</h2>
						<a class="book" href="<?php echo get_site_url();?>" title="Book An Appointment"><button data-animation="animated fadeInLeft">Book An Appointment</button></a>
					</div>

				</div>
			</div>

			<!-- <a class="nav_left" href="#home_slider" role="button" data-slide="prev"></a>
			<a class="nav_right" href="#home_slider" role="button" data-slide="next"></a>
			<ol class="nav_dots carousel-indicators">
				<li data-target="#home_slider" data-slide-to="0" class="active"></li>
				<li data-target="#home_slider" data-slide-to="1"></li>
			</ol> -->
		</div>
	</div>
</section>
<!--slider_section-->




<!--aboutus_section-->


<section class="aboutus_section">
	<div class="wrap_grid">
		<div class="aboutus_align">
			<div class="aboutus_left">
				<img src="<?php echo esc_url(get_template_directory_uri());?>/images/about-us.png" alt="About Us">
			</div>
			<div class="aboutus_right">
				<div class="head_text">
					<h4>ABOUT US</h4>
					<h1>Welcome to<br>
Dr. Charu’s Dental Clinic</h1>
				</div>
				<p>We are a team of highly qualified specialists from all the fields of dentistry with over 15 years of experience, handling both local and international patients.The calm and relaxing ambience of our clinic, will completely reduce anxiety of phobia about the dental treatments.
We maintain the highest standards of hygiene and adhere to stringent sterilization protocols for your safety.
</p>
				<a href="<?php echo get_site_url();?>/about-us/" title="Learn More">
					<button>Learn More</button>
				</a>
			</div>
		</div>
	</div>
</section>


<!--aboutus_section-->



<!--whychooseus_section-->



<section class="whychooseus_section">
	<div class="wrap_grid">
		<div class="whychooseus_align">
			<div class="whychooseus_left">
				<div class="head_text">
					<h4>Why Doctor Charu</h4>
					<h2>Why Choose Us</h2>
				</div>
				<p>Our friendly, professional team of dentists and dental surgeons are always available to meet with our patients personally and to address any of their concerns. We schedule our patient’s appointments with plenty of time in-between so each of them receive our full and focused attention.</p>
			</div>
			<div class="whychooseus_right">
				<ul>
					<li>
						<div class="why_box">
							<img src="<?php echo esc_url(get_template_directory_uri());?>/images/w1.png" alt="Dentist at Work">
							<h4>5</h4>
							<p>Dentist at Work</p>
						</div>
					</li>
					<li>
						<div class="why_box">
							<img src="<?php echo esc_url(get_template_directory_uri());?>/images/w2.png" alt="Patients Treated">
							<h4>5000</h4>
							<p>Patients Treated</p>
						</div>
					</li>
					<li>
						<div class="why_box">
							<img src="<?php echo esc_url(get_template_directory_uri());?>/images/w3.png" alt="Happy Smiles">
							<h4>100%</h4>
							<p>Happy Smiles</p>
						</div>
					</li>
					<li>
						<div class="why_box">
							<img src="<?php echo esc_url(get_template_directory_uri());?>/images/w4.png" alt="Years Experinced">
							<h4>15</h4>
							<p>Years of Experience</p>
						</div>
					</li>
				</ul>
			</div>
		</div>
	</div>
</section>



<!--whychooseus_section-->



<!--ourservice_section-->


<section class="ourservice_section">
	<div class="wrap_grid">
		<div class="head_text">
			<h4>services</h4>
			<h2>Our Specialize Care</h2>
		</div>
		<div class="slide-wrap">
		<ul class="service_slider">
			<div class="swiper-wrapper">
			<li class="swiper-slide">
				<div class="services_box">
					<img src="<?php echo esc_url(get_template_directory_uri());?>/images/rooticon.png" alt="Our Service">
					<h4>Root Canal Treatment</h4>
					<p>We combine state-of-the-art technology with our expertise and soft-skill approach to ensure that every root canal procedure is precise, seamless and pain-free. Most of the root canal ...</p>
					<a href="<?php echo get_site_url();?>/root-canal-treatment/" title="Learn More">
						<button>Learn More</button>
					</a>
				</div>
			</li>
			<li class="swiper-slide">
				<div class="services_box">
					<img src="<?php echo esc_url(get_template_directory_uri());?>/images/s3.png" alt="Our Service">
					<h4>Orthodontic Braces</h4>
					<p>Invisible braces are a great alternative when you want to straighten your teeth without the discomfort of metal braces in your mouth. Crooked, uneven teeth can make you feel self-conscious.</p>
					<a href="<?php echo get_site_url();?>/orthodontic-braces/" title="Learn More">
						<button>Learn More</button>
					</a>
				</div>
			</li>
			<li class="swiper-slide">
				<div class="services_box">
					<img src="<?php echo esc_url(get_template_directory_uri());?>/images/fullmicon.png" alt="Our Service">
					<h4>Full Mouth Reconstruction</h4>
					<p>In certain cases, the teeth in both the upper and lower jaw need to be rebuilt and restored in a process called a full mouth reconstruction. In cases where oral health has been ..</p>
					<a href="<?php echo get_site_url();?>/full-mouth-reconstruction/" title="Learn More">
						<button>Learn More</button>
					</a>
				</div>
			</li>
			<li class="swiper-slide">
				<div class="services_box">
					<img src="<?php echo esc_url(get_template_directory_uri());?>/images/s1.png" alt="Our Service">
					<h4>Dental Implants</h4>
					<p>Dental implants are easily the most popular and also the ideal solution, for replacing your missing tooth/teeth. They have definitely changed the course of dentistry in the last quarter...</p>
					<a href="<?php echo get_site_url();?>/dental-implants/" title="Learn More">
						<button>Learn More</button>
					</a>
				</div>
			</li>
			<li class="swiper-slide">
				<div class="services_box">
					<img src="<?php echo esc_url(get_template_directory_uri());?>/images/wisdomicon.png" alt="Our Service">
					<h4>Wisdom Teeth Removal</h4>
					<p>‘Wisdom teeth removal’ is one of the most searched topics about dentistry in google. There are various aspects of it such as when the teeth erupt, does it hurt if it grows in an ...  </p>
					<a href="<?php echo get_site_url();?>/wisdom-teeth-removal/" title="Learn More">
						<button>Learn More</button>
					</a>
				</div>
			</li>
			<li class="swiper-slide">
				<div class="services_box">
					<img src="<?php echo esc_url(get_template_directory_uri());?>/images/s2.png" alt="Our Service">
					<h4>Crowns and Bridges</h4>
					<p>As many of us know, when you have a missing tooth, it can be difficult to communicate, speak, bite or even eat effectively. When a tooth is missing, it is essential to visit your dentist ... </p>
					<a href="<?php echo get_site_url();?>/crowns-and-bridges/" title="Learn More">
						<button>Learn More</button>
					</a>
				</div>
			</li>
			<li class="swiper-slide">
				<div class="services_box">
					<img src="<?php echo esc_url(get_template_directory_uri());?>/images/teethicon.png" alt="Our Service">
					<h4>Teeth Whitening</h4>
					<p>Bleaching or Teeth whitening treatment is a simple, painless way to make your teeth whiter. Although teeth are very hard, the outer layer, enamel, has microscopic pores that can ...  </p>
					<a href="<?php echo get_site_url();?>/teeth-whitening/" title="Learn More">
						<button>Learn More</button>
					</a>
				</div>
			</li>
			<li class="swiper-slide">
				<div class="services_box">
					<img src="<?php echo esc_url(get_template_directory_uri());?>/images/pediatricicon.png" alt="Our Service">
					<h4>Pediatric Treatments</h4>
					<p>Proper dental care is necessary to maintain good dental health from childhood through adulthood. Beginning regular dental appointments is important at an early age. A child should... </p>
					<a href="<?php echo get_site_url();?>/pediatric-treatments/" title="Learn More">
						<button>Learn More</button>
					</a>
				</div>
			</li>
			</div>

		</ul>

<div class="service_prev"></div>
		<div class="service_next"></div>
		<div class="service_pagination"></div>
		</div>
	</div>
</section>



<!--ourservice_section-->





<!--testimonials_section-->


<section class="testimonials_section">
	<div class="wrap_grid">
		<div class="testimonials_align">
			<div class="testimonials_left">
				<img src="<?php echo esc_url(get_template_directory_uri());?>/images/test-default.png" alt="testimonials">
			</div>
			<div class="testimonials_right">
				<div class="head_text">
					<h4>Testimonials</h4>
					<h2>Let’s Hear about us</h2>
				</div>
				<ul class="testi_slider">
					<div class="swiper-wrapper">
					<li class="swiper-slide">
						<h4>Manoharan R</h4>
						<h5>Chennai.</h5>
						<img src="<?php echo esc_url(get_template_directory_uri());?>/images/rating.png" alt="testimonials">
						<p>Dr. Charu is caring and a patient doctor.
She treats patients with utmost care. She explains what the problem is and wat should be done and wat shouldn't be done.....</p>
					</li>
					<li class="swiper-slide">
						<h4>Sangeetha</h4>
						<h5>Chennai.</h5>
						<img src="<?php echo esc_url(get_template_directory_uri());?>/images/rating.png" alt="testimonials">
						<p>I visited this clinic few days back due to tooth pain. The doctor was very considerate and gave me good advice and treatment. I will recommend this clinic.</p>
					</li>
					</div>
				</ul>
				<div class="testi_nav">
					<div class="testi_prev"></div>
					<div class="testi_next"></div>
				</div>
				<div class="testi_pagination"></div>
			</div>
		</div>
	</div>
</section>


<!--testimonials_section-->




<!--ourteam_section-->


<!-- <section class="ourteam_section">
	<div class="wrap_grid">
		<div class="head_text">
			<h4>TEAM</h4>
			<h2>Our Expert team</h2>
		</div>
		<div class="testi_wrap">
		<ul class="team_slider">
			<div class="swiper-wrapper">
			<li class="swiper-slide">
				<div class="team_box">
					<a href="<?php echo get_site_url();?>/dr-charu-priyadarshini/" title="Dr. Charu priyadarshini"><img src="<?php echo esc_url(get_template_directory_uri());?>/images/ourteam.png" alt="ourteam"></a>
					<div class="desgination">
						<h4>Dr. Charu priyadarshini</h4>
						<p>Chief Doctor</p>
					</div>
				</div>
			</li>
			<li class="swiper-slide">
				<div class="team_box">
					<img src="<?php echo esc_url(get_template_directory_uri());?>/images/ourteam.png" alt="ourteam">
					<div class="desgination">
						<h4>Dr. Joseph Fernandez</h4>
						<p>Pedodontics</p>
					</div>
				</div>
			</li>
			<li class="swiper-slide">
				<div class="team_box">
					<img src="<?php echo esc_url(get_template_directory_uri());?>/images/ourteam.png" alt="ourteam">
					<div class="desgination">
						<h4>Dr. Joseph Fernandez</h4>
						<p>Pedodontics</p>
					</div>
				</div>
			</li>
			</div>
		</ul>
		<div class="team_prev"></div>
		<div class="team_next"></div>
		<div class="team_pagination"></div>
		</div>
	</div>
</section> -->

<section class="aboutus_section founder_home">
	<div class="wrap_grid">
		<div class="aboutus_align">
			<div class="aboutus_left">
				<img src="<?php echo esc_url(get_template_directory_uri());?>/images/founder.png" alt="About Us">
			</div>
			<div class="aboutus_right">
				<div class="head_text">
					<h4>OUR FOUNDER</h4>
					<h1>Dr. Charu priyadarshini</h1>
				</div>
				<p>Dr. Charu priyadarshini having a 15 years of experience of professional clinical experience with a deep knowledge in examining radiography providing diagnosis n best treatments plans ,as well as performing restorative, prosthodontics, orthodontics and endodontics procedure with at most care and comfort.
</p>
				<a href="<?php echo get_site_url();?>/about-us/" title="Learn More">
					<button>Learn More</button>
				</a>
			</div>
		</div>
	</div>
</section>

<!--ourteam_section-->





<!--ourgallery_section-->

<!--
<section class="ourgallery_section">
	<div class="wrap_grid">
		<div class="head_text">
			<h4>Gallery</h4>
			<h2>Our Clinical gallery </h2>
		</div>
	</div>
	<ul>
		<li>
			<a href="<?php echo esc_url(get_template_directory_uri());?>/images/g1.png" data-fancybox="gallery" data-caption="Our Gallery">
				<img src="<?php echo esc_url(get_template_directory_uri());?>/images/g1.png" alt="Our Gallery">
			</a>
		</li>
		<li>
			<a href="<?php echo esc_url(get_template_directory_uri());?>/images/g1.png" data-fancybox="gallery" data-caption="Our Gallery">
				<img src="<?php echo esc_url(get_template_directory_uri());?>/images/g1.png" alt="Our Gallery">
			</a>
		</li>
		<li>
			<a href="<?php echo esc_url(get_template_directory_uri());?>/images/g1.png" data-fancybox="gallery" data-caption="Our Gallery">
				<img src="<?php echo esc_url(get_template_directory_uri());?>/images/g1.png" alt="Our Gallery">
			</a>
		</li>
		<li>
			<a href="<?php echo esc_url(get_template_directory_uri());?>/images/g1.png" data-fancybox="gallery" data-caption="Our Gallery">
				<img src="<?php echo esc_url(get_template_directory_uri());?>/images/g1.png" alt="Our Gallery">
			</a>
		</li>
		<li>
			<a href="<?php echo esc_url(get_template_directory_uri());?>/images/g1.png" data-fancybox="gallery" data-caption="Our Gallery">
				<img src="<?php echo esc_url(get_template_directory_uri());?>/images/g1.png" alt="Our Gallery">
			</a>
		</li>
		<li>
			<a href="<?php echo esc_url(get_template_directory_uri());?>/images/g1.png" data-fancybox="gallery" data-caption="Our Gallery">
				<img src="<?php echo esc_url(get_template_directory_uri());?>/images/g1.png" alt="Our Gallery">
			</a>
		</li>
		<li>
			<a href="<?php echo esc_url(get_template_directory_uri());?>/images/g1.png" data-fancybox="gallery" data-caption="Our Gallery">
				<img src="<?php echo esc_url(get_template_directory_uri());?>/images/g1.png" alt="Our Gallery">
			</a>
		</li>
		<li>
			<a href="<?php echo esc_url(get_template_directory_uri());?>/images/g1.png" data-fancybox="gallery" data-caption="Our Gallery">
				<img src="<?php echo esc_url(get_template_directory_uri());?>/images/g1.png" alt="Our Gallery">
			</a>
		</li>
	</ul>
</section> -->


<!--ourgallery_section-->





<!--smilegallery_section-->



<section class="smilegallery_section">
	<div class="wrap_grid">
		<div class="head_text">
			<h4>Smile gallery</h4>
			<h2>Before and After</h2>
		</div>
		<div class="sm_wrap">
		<ul class="sm_slider">
			<div class="swiper-wrapper">
			<li class="swiper-slide">
				<div class="smile_box">
					<img src="<?php echo esc_url(get_template_directory_uri());?>/images/sg1.png" alt="Smile Gallery">
				</div>
			</li>
			<li class="swiper-slide">
				<div class="smile_box">
					<img src="<?php echo esc_url(get_template_directory_uri());?>/images/sg1.png" alt="Smile Gallery">
				</div>
			</li>
			</div>
		</ul>
		<div class="sm_nav">
			<div class="sm_prev"></div>
			<div class="sm_next"></div>
		</div>
		<div class="sm_pagination"></div>
		</div>
	</div>
</section>



<!--smilegallery_section-->





<!--appointment_section-->


<section class="appointment_section">
	<div class="wrap_grid">
		<div class="head_text">
			<h4>appointment</h4>
			<h2>Fix your appointments</h2>
		</div>
		<form accept-charset="utf-8" method="post" action="<?php echo esc_url(get_template_directory_uri());?>/fix_appointment.php" id="fix_appt">
			<ul>
				<li><input type="text" name="fixname" placeholder="Enter your name" id="fixname"></li>
				<li><input type="text" name="fixphone" placeholder="Phone number" id="fixphone"><input type="hidden" name="siteurl" value="<?php echo get_site_url();?>"></li>

				<li><input type="text" name="fixdate" placeholder="Date" id="fixdate" onmousedown="datePick(this.id)" readonly></li>
				<li><input type="submit" name="submit" value="Book Now" id="fixsubmit"></li>
			</ul>
		</form>
	</div>
</section>


<!--appointment_section-->


























<?php get_footer();?>
<script>


$(document).ready(function(){
$("#fix_appt").submit(function(e){


	var fixname = document.getElementById("fixname").value;
	var fixphone = document.getElementById("fixphone").value;
	var fixdate = document.getElementById("fixdate").value;



	 var regex='';
    var valid;

    regex   = '^[a-zA-Z][a-zA-Z\. ]{2,40}$';
    valid = validateInputs(fixname,regex);

	if( (!valid) || (fixname  == "")) {
         alert('Please enter valid name');
         return false;
     }


    regex   = '^[0-9 \-]{10,20}$';
    valid = validateInputs(fixphone,regex);

   if( (!valid) || (fixphone == "") ) {
         alert('Please enter valid phone number');
         return false;
    }

	if(fixdate == '') {

      alert("Please enter valid date");
      return false;
    }






	$("#fix_appt").submit();

	e.preventDefault();


});


function validateInputs(value,pattern) {

    var regexppattern;
    regexppattern = new RegExp(pattern);
    var valid     = regexppattern.test(value);

    return valid;
}
});

</script>


<script type="text/javascript">

	new Swiper('.sm_slider', {
        loop: true,
        speed: 1500,
        parallax: true,
        slidesPerView: 2,
        paginationClickable: true,
        spaceBetween: 20,
         autoplay: {
            delay: 3500,
            disableOnInteraction: false,
        },
        watchSlidesProgress: true,
        navigation: {
            nextEl: '.sm_next',
            prevEl: '.sm_prev',
        },
        pagination: {
            el: '.sm_pagination',
            clickable: true,
        },
        breakpoints: {
            1920: {
                slidesPerView: 2,
                spaceBetween: 20
            },
            1200: {
                slidesPerView: 2,
                spaceBetween: 20
            },
            956: {
                slidesPerView: 2,
                spaceBetween: 20
            },
            768: {
                slidesPerView: 2,
                spaceBetween: 20
            },
            580: {
                slidesPerView: 2,
                spaceBetween: 20
            },
            320: {
                slidesPerView: 1,
                spaceBetween: 0
            }
        }
    });

    //

	new Swiper('.team_slider', {
        loop: true,
        speed: 1500,
        parallax: true,
        slidesPerView: 3,
        paginationClickable: true,
        spaceBetween: 20,
         autoplay: {
            delay: 3500,
            disableOnInteraction: false,
        },
        watchSlidesProgress: true,
        navigation: {
            nextEl: '.team_next',
            prevEl: '.team_prev',
        },
        pagination: {
            el: '.team_pagination',
            clickable: true,
        },
        breakpoints: {
            1920: {
                slidesPerView: 3,
                spaceBetween: 20
            },
            1200: {
                slidesPerView: 3,
                spaceBetween: 20
            },
            956: {
                slidesPerView: 2,
                spaceBetween: 20
            },
            768: {
                slidesPerView: 2,
                spaceBetween: 20
            },
            580: {
                slidesPerView: 2,
                spaceBetween: 20
            },
            320: {
                slidesPerView: 1,
                spaceBetween: 0
            }
        }
    });


    //
	new Swiper('.service_slider', {
        loop: true,
        speed: 1500,
        parallax: true,
        slidesPerView: 3,
        paginationClickable: true,
        spaceBetween: 8,
         autoplay: {
            delay: 3500,
            disableOnInteraction: false,
        },
        watchSlidesProgress: true,
        navigation: {
            nextEl: '.service_next',
            prevEl: '.service_prev',
        },
        pagination: {
            el: '.service_pagination',
            clickable: true,
        },
        breakpoints: {
            1920: {
                slidesPerView: 3,
                spaceBetween: 8
            },
            1200: {
                slidesPerView: 3,
                spaceBetween: 8
            },
            956: {
                slidesPerView: 2,
                spaceBetween: 8
            },
            768: {
                slidesPerView: 2,
                spaceBetween: 8
            },
            580: {
                slidesPerView: 2,
                spaceBetween: 8
            },
            320: {
                slidesPerView: 1,
                spaceBetween: 0
            }
        }
    });

    //

    new Swiper('.testi_slider', {
        loop: true,
        speed: 1500,
        parallax: true,
        slidesPerView: 1,
        paginationClickable: true,
        spaceBetween: 0,
         autoplay: {
            delay: 3500,
            disableOnInteraction: false,
        },
        watchSlidesProgress: true,
        navigation: {
            nextEl: '.testi_next',
            prevEl: '.testi_prev',
        },
        pagination: {
            el: '.testi_pagination',
            clickable: true,
        },
        breakpoints: {
            1920: {
                slidesPerView: 1,
                spaceBetween: 0
            },
            320: {
                slidesPerView: 1,
                spaceBetween: 0
            }
        }
    });

</script>

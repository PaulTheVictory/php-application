<?php
/*Template Name:Teeth Whitening*/
get_header();?>

<!--slider_section-->
<section class="slide_section">
	<div id="home_slider" class="carousel bs-slider slide control-round indicators-line" data-ride="carousel" data-pause="hover" data-interval="false">
		<div class="carousel-inner" role="listbox">
			<div class="item active">
				<img src="<?php echo esc_url(get_template_directory_uri());?>/images/banner/teethd.png" alt="Banenr" class="desk_banner">
				<img src="<?php echo esc_url(get_template_directory_uri());?>/images/banner/teethm.png" alt="Banenr" class="mob_banner">
				<div class="slide-text">
					<div class="slide_text_left">
						<h2 data-animation="animated fadeInLeft">Teeth Whitening</h2>
						<a class="book" href="<?php echo get_site_url();?>/contact-us/" title="Send Enquiry"><button data-animation="animated fadeInLeft">Send Enquiry</button></a>
					</div>
					
				</div>
			</div>
			
			<!-- <a class="nav_left" href="#home_slider" role="button" data-slide="prev"></a>
			<a class="nav_right" href="#home_slider" role="button" data-slide="next"></a>  
			<ol class="nav_dots carousel-indicators">
				<li data-target="#home_slider" data-slide-to="0" class="active"></li>
				<li data-target="#home_slider" data-slide-to="1"></li>
			</ol> -->
		</div>
	</div>
</section>
<!--slider_section-->


<!--aboutus_section-->


<section class="aboutus_section services_all_section">
	<div class="wrap_grid">
		<div class="aboutus_align">
			<div class="aboutus_left">
				<img src="<?php echo esc_url(get_template_directory_uri());?>/images/services/teeth1.png" alt="About Us">
			</div>
			<div class="aboutus_right">
				<div class="head_text">
					<h4>YOUR SMILE SAVER</h4>
					<h1>Teeth Whitening</h1>
				</div>
				<p><strong>Bleaching</strong></p>
				<p>Bleaching or Teeth whitening treatment is a simple, painless way to make your teeth whiter. Although teeth are very hard, the outer layer, enamel, has microscopic pores that can discolour over time, from smoking and food colouring. Sometimes, discolouration can occur during early tooth formation from antibiotics and fluoride consumption.</p>
				<p><strong>Home Bleaching</strong></p>
				<p>The bleaching gel applied in a transparent tray fits snugly over the teeth. It can be used during the day or while sleeping. The process takes from several days to a couple of weeks.</p>
				<p><strong>Office-bleaching</strong></p>
				<p>This bleaching technique is fast and effective. The gel is applied on all front teeth and the whitening process is activated by laser light. It is done in one or two visits. All kinds of bleaching can cause post-treatment sensitivity and some amount of gum irritation. These symptoms disappear within one to three days after completion of treatment. The whitening lasts for 6 months to 1 year, depending on your personal habits, such as smoking, paan chewing and drinking coffee and tea. The outcome of every case is different.</p>
			</div>
		</div>
		<div class="aboutus_align">
			<div class="aboutus_left">
				<img src="<?php echo esc_url(get_template_directory_uri());?>/images/services/teeth2.png" alt="About Us">
			</div>
			<div class="aboutus_right">
				<div class="head_text">
					<h2>Grins ARE VALUABLE</h2>
				</div>
				<p>Measurements uncover that we put a high incentive on our teeth whitening treatment grins. As per an American Academy of Cosmetic Dentistry overview:</p>
				<ul>
					<li>Essentially all grown-ups (99.7%) trust a grin is a critical social resource. 96% of grown-ups trust an alluring teeth whitening treatment grains makes a man additionally speaking to individuals from the contrary attraction</li>
					<li>Seventy five percent (75%) of grown-ups feel an ugly grin can hurt a man’s possibility for vocation achievement.</li>
					<li>Furthermore, when respondents were asked, “What might you want to enhance most about your  teeth whitening treatment grin?” The most well-known reaction was: Whiter and brighter teeth. On the off chance that you are not content with your grin, teeth brightening might be a decent initial step.</li>
				</ul>
				<p>Similarly as there are various approaches to help teeth whitening or light up teeth, there are additionally a few distinctive routes for teeth to wind up stained.</p>
				<p>To get a cost estimate for Teeth Whitening Treatment process, Get in touch with us today.</p>
			</div>
		</div>
		
		
		</div>
	</div>
</section>


<!--aboutus_section-->







<!--faq_section-->



<!-- <div class="faq_section">
	<div class="wrap_grid">
		<div class="head_text">
			<h4>FAQ</h4>
			<h2>Common Queries</h2>
		</div>
		<ul class="faq_section_page">
			<li class="faq_align faq_open">
				<div class="faq_question">
					<h4>Is there a risk associated with dental implants?</h4>
				</div>
				<div class="faq_answer" style="display: block;">
					<p>Dental implants are a tried and tested procedure that has no possible risks. It has been demonstrated to be safe and successful for more than a decade, and it is considered the most reliable technique in dentistry. Infection, discomfort, numbness, or tingling are examples of minor consequences.</p>
				</div>
			</li>
			<li class="faq_align">
				<div class="faq_question">
					<h4>Is there a risk associated with dental implants?</h4>
				</div>
				<div class="faq_answer">
					<p>Dental implants are a tried and tested procedure that has no possible risks. It has been demonstrated to be safe and successful for more than a decade, and it is considered the most reliable technique in dentistry. Infection, discomfort, numbness, or tingling are examples of minor consequences.</p>
				</div>
			</li>
			<li class="faq_align">
				<div class="faq_question">
					<h4>Is there a risk associated with dental implants?</h4>
				</div>
				<div class="faq_answer">
					<p>Dental implants are a tried and tested procedure that has no possible risks. It has been demonstrated to be safe and successful for more than a decade, and it is considered the most reliable technique in dentistry. Infection, discomfort, numbness, or tingling are examples of minor consequences.</p>
				</div>
			</li>
			<li class="faq_align">
				<div class="faq_question">
					<h4>Is there a risk associated with dental implants?</h4>
				</div>
				<div class="faq_answer">
					<p>Dental implants are a tried and tested procedure that has no possible risks. It has been demonstrated to be safe and successful for more than a decade, and it is considered the most reliable technique in dentistry. Infection, discomfort, numbness, or tingling are examples of minor consequences.</p>
				</div>
			</li>
		</ul>
	</div>
</div> -->



<!--faq_section-->









<?php
/*Template Name:About Us*/
get_footer();?>



<script type="text/javascript">

	$(function() {
		var Accordion = function(el, multiple) {
				this.el = el || {};
				this.multiple = multiple || false;

				var links = this.el.find('.faq_question');
				links.on('click', {
						el: this.el,
						multiple: this.multiple
				}, this.dropdown)
		}

		Accordion.prototype.dropdown = function(e) {
				var $el = e.data.el;
				$this = $(this),
						$next = $this.next();

				$next.slideToggle();
				$this.parent().toggleClass('faq_open');

				if (!e.data.multiple) {
						$el.find('.faq_answer').not($next).slideUp().parent().removeClass('faq_open');
				};
		}
		var accordion = new Accordion($('.faq_section_page'), false);
});
</script>
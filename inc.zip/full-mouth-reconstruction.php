<?php
/*Template Name:Full mouth Reconstruction*/
get_header();?>

<!--slider_section-->
<section class="slide_section">
	<div id="home_slider" class="carousel bs-slider slide control-round indicators-line" data-ride="carousel" data-pause="hover" data-interval="false">
		<div class="carousel-inner" role="listbox">
			<div class="item active">
				<img src="<?php echo esc_url(get_template_directory_uri());?>/images/banner/fullmd.png" alt="Banenr" class="desk_banner">
				<img src="<?php echo esc_url(get_template_directory_uri());?>/images/banner/fullmm.png" alt="Banenr" class="mob_banner">
				<div class="slide-text">
					<div class="slide_text_left">
						<h2 data-animation="animated fadeInLeft">Full mouth Reconstruction</h2>
						<a class="book" href="<?php echo get_site_url();?>/contact-us/" title="Send Enquiry"><button data-animation="animated fadeInLeft">Send Enquiry</button></a>
					</div>
					
				</div>
			</div>
			
			<!-- <a class="nav_left" href="#home_slider" role="button" data-slide="prev"></a>
			<a class="nav_right" href="#home_slider" role="button" data-slide="next"></a>  
			<ol class="nav_dots carousel-indicators">
				<li data-target="#home_slider" data-slide-to="0" class="active"></li>
				<li data-target="#home_slider" data-slide-to="1"></li>
			</ol> -->
		</div>
	</div>
</section>
<!--slider_section-->


<!--aboutus_section-->


<section class="aboutus_section services_all_section">
	<div class="wrap_grid">
		<div class="aboutus_align">
			<div class="aboutus_left">
				<img src="<?php echo esc_url(get_template_directory_uri());?>/images/services/fullm1.png" alt="About Us">
			</div>
			<div class="aboutus_right">
				<div class="head_text">
					<h4>YOUR SMILE SAVER</h4>
					<h1>Full mouth Reconstruction</h1>
				</div>
				<p>In certain cases, the teeth in both the upper and lower jaw need to be rebuilt and restored in a process called a full mouth reconstruction. In cases where oral health has been severely compromised, this can be a life-changing procedure.</p>
				<p>When researching or discussing the process, it may also be referred to as a full mouth restoration or full mouth rehabilitation.</p>
				<p>What is a full mouth restoration? A full mouth restoration tailors a series of dental procedures to the patient’s individual needs. Jaw joints, bite, smile, and facial support treatment options are all considered when reconstructing the mouth and restoring dental health.</p>
				<p>With such extensive dental procedures, it’s crucial to choose natural, biocompatible materials. At Rejuvenation Dentistry, we say no to potential toxins and yes to safe ingredients in all of our full mouth reconstructions.</p>
			</div>
		</div>
		<div class="aboutus_align">
			<div class="aboutus_left">
				<img src="<?php echo esc_url(get_template_directory_uri());?>/images/services/fullm2.png" alt="About Us">
			</div>
			<div class="aboutus_right">
				<div class="head_text">
					<h2>Benefits of Full mouth Reconstruction</h2>
				</div>
				<p>A full mouth reconstruction is designed with the following benefits in mind:</p>
				<ul>
					<li>An improved bite and ease while chewing</li>
					<li>Addressing tooth decay</li>
					<li>Increased gum health</li>
					<li>Clearer speech</li>
					<li>Boosted self-confidence</li>
					<li>Restored facial and lip support</li>
					<li>A smile makeover</li>
				</ul>
				<p>It’s also quite common for sinus pain, headaches, and bad breath to fade out after a full mouth reconstruction.</p>
			</div>
		</div>
		
		<div class="aboutus_align">
			<div class="aboutus_left">
				<img src="<?php echo esc_url(get_template_directory_uri());?>/images/services/fullm3.png" alt="About Us">
			</div>
			<div class="aboutus_right">
				<div class="head_text">
					<h2>Who Requires a Full mouth Reconstruction?</h2>
				</div>
				<p>Typically, the best candidates for a full mouth reconstruction are patients with multiple dental problems. These conditions may include:</p>
				<ul>
					<li>Heavy wear and tear on the teeth, such as cracked or broken teeth due to bruxism</li>
					<li>Gum disease</li>
					<li>Multiple missing teeth</li>
					<li>Severe acid reflux (GERD)</li>
					<li>Ground-down teeth due to bruxism</li>
					<li>Misaligned bite</li>
					<li>Pain in the temporomandibular joint</li>
					<li>Severe decay</li>
					<li>Loss of density in the jawbone</li>
					<li>Harmful metals used in dental repairs</li>
				</ul>
			</div>
		</div>
		<div class="aboutus_align">
			<div class="aboutus_left">
				<img src="<?php echo esc_url(get_template_directory_uri());?>/images/services/fullm4.png" alt="About Us">
			</div>
			<div class="aboutus_right">
				<p>If a patient is experiencing severe pain, tooth loss, difficulty eating, or toxicity due to synthetic materials, it may be time for a full mouth reconstruction with us.</p>
				<p>With this amount of work, you’ll want to go with a cosmetic dentist with a biologic approach to avoid unnecessary chemicals. We also have decades of experience treating patients with dental anxiety. We’ll put you at ease while we provide the best quality dental care.</p>
			</div>
		</div>
		<div class="aboutus_align">
			<div class="aboutus_left">
				<img src="<?php echo esc_url(get_template_directory_uri());?>/images/services/fullm5.png" alt="About Us">
			</div>
			<div class="aboutus_right">
				<div class="head_text">
					<h2>Parts of the mouth a dentist will examine</h2>
				</div>
				<p>As anyone familiar with biologic dentistry knows, the mouth is more than just teeth. To get a full scope of the issue and plan a tailor-made dental reconstruction, your dentist will need to get a comprehensive understanding of your mouth.</p>
				<p>Here’s what, and where, your dentist will be examining in your mouth:</p>
				<p>Bite. Malocclusion, or a misaligned bite, can cause problems with chewing, shifting teeth, frequently biting the tongue or cheeks, and shifting teeth. You may need orthodontic treatments or even a night guard to adjust the bite and alignment inside the mouth. Many patients who seek a full mouth reconstruction have trouble eating due to bite issues.</p>
			</div>
		</div>
		<div class="aboutus_align">
			<div class="aboutus_left">
				<img src="<?php echo esc_url(get_template_directory_uri());?>/images/services/fullm6.png" alt="About Us">
			</div>
			<div class="aboutus_right">
				<p>Gum tissues. In cases of periodontal disease, deep cleaning procedures like scaling and planing may be needed to improve gum health. In some more severe cases, gum or bone grafting can help to add support and structure back to the mouth before oral surgery. If the gums aren’t healthy, additional problems like missing teeth and jaw damage can occur. Gum contouring can also be an option for patients looking to improve the appearance of their smiles.</p>
				<p>Teeth. Cracking, wear and tear, and tooth decay can all compromise oral health. Any and all issues with individual teeth and missing teeth will be taken care of as part of a full mouth reconstruction. Treatment options include root canals, dental crowns, dental implants, and dental bridges.</p>
				<p>Temporomandibular joints and jaw muscles. Patients with TMJ and jaw pain will be treated, potentially in conjunction with bite issues. We sometimes use Botox while getting to the root cause of jaw pain and headaches.</p>
			</div>
		</div>
		<div class="aboutus_align">
			<div class="aboutus_left">
				<img src="<?php echo esc_url(get_template_directory_uri());?>/images/services/fullm7.png" alt="About Us">
			</div>
			<div class="aboutus_right">
				<p>Esthetics. When considering the full mouth restoration, the color, shape, and proportion of teeth will be important. Teeth whitening, porcelain veneers, and onlays are options when designing your new teeth.</p>
				<p>As you can see, each full mouth reconstruction is individual and based on the root causes of pain and decay that need to be addressed, as well as cosmetic alterations they’d like to make.</p>
				<p>In order to observe all of these facets of the mouth, a dentist may use x-rays, impressions of upper and lower teeth, and take note of prior dental procedures that may use toxic materials or be showing wear and tear.</p>
				<p>A full mouth reconstruction is different from a smile makeover: A smile makeover primarily addresses cosmetic concerns, while a full mouth reconstruction changes both the appearance and function of the mouth.</p>
			</div>
		</div>
		<div class="aboutus_align">
			<div class="aboutus_left">
				<img src="<?php echo esc_url(get_template_directory_uri());?>/images/services/fullm8.png" alt="About Us">
			</div>
			<div class="aboutus_right">
				<div class="head_text">
					<h2>9 steps of full mouth reconstruction</h2>
				</div>
				<p>Comprehensive, restorative full mouth reconstruction must be done in steps. The survival of your procedures depends on it. Long-lasting cosmetic procedures like porcelain veneers can fail if you don’t address overall oral health and root causes.</p>
				<p>The bottom line is that you need a healthy mouth to support your reconstruction.</p>
			</div>
		</div>
	</div>
</section>


<!--aboutus_section-->







<!--faq_section-->



<!-- <div class="faq_section">
	<div class="wrap_grid">
		<div class="head_text">
			<h4>FAQ</h4>
			<h2>Common Queries</h2>
		</div>
		<ul class="faq_section_page">
			<li class="faq_align faq_open">
				<div class="faq_question">
					<h4>Is there a risk associated with dental implants?</h4>
				</div>
				<div class="faq_answer" style="display: block;">
					<p>Dental implants are a tried and tested procedure that has no possible risks. It has been demonstrated to be safe and successful for more than a decade, and it is considered the most reliable technique in dentistry. Infection, discomfort, numbness, or tingling are examples of minor consequences.</p>
				</div>
			</li>
			<li class="faq_align">
				<div class="faq_question">
					<h4>Is there a risk associated with dental implants?</h4>
				</div>
				<div class="faq_answer">
					<p>Dental implants are a tried and tested procedure that has no possible risks. It has been demonstrated to be safe and successful for more than a decade, and it is considered the most reliable technique in dentistry. Infection, discomfort, numbness, or tingling are examples of minor consequences.</p>
				</div>
			</li>
			<li class="faq_align">
				<div class="faq_question">
					<h4>Is there a risk associated with dental implants?</h4>
				</div>
				<div class="faq_answer">
					<p>Dental implants are a tried and tested procedure that has no possible risks. It has been demonstrated to be safe and successful for more than a decade, and it is considered the most reliable technique in dentistry. Infection, discomfort, numbness, or tingling are examples of minor consequences.</p>
				</div>
			</li>
			<li class="faq_align">
				<div class="faq_question">
					<h4>Is there a risk associated with dental implants?</h4>
				</div>
				<div class="faq_answer">
					<p>Dental implants are a tried and tested procedure that has no possible risks. It has been demonstrated to be safe and successful for more than a decade, and it is considered the most reliable technique in dentistry. Infection, discomfort, numbness, or tingling are examples of minor consequences.</p>
				</div>
			</li>
		</ul>
	</div>
</div> -->



<!--faq_section-->









<?php
/*Template Name:About Us*/
get_footer();?>



<script type="text/javascript">

	$(function() {
		var Accordion = function(el, multiple) {
				this.el = el || {};
				this.multiple = multiple || false;

				var links = this.el.find('.faq_question');
				links.on('click', {
						el: this.el,
						multiple: this.multiple
				}, this.dropdown)
		}

		Accordion.prototype.dropdown = function(e) {
				var $el = e.data.el;
				$this = $(this),
						$next = $this.next();

				$next.slideToggle();
				$this.parent().toggleClass('faq_open');

				if (!e.data.multiple) {
						$el.find('.faq_answer').not($next).slideUp().parent().removeClass('faq_open');
				};
		}
		var accordion = new Accordion($('.faq_section_page'), false);
});
</script>
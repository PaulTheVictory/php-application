<?php 



get_header();



if(is_home() || is_front_page()){$url = get_site_url();}else{$url = home_url( $wp->request )."/";}



?>



  <div class="blog_section">
   <div class="wrap_grid">
    <h1><?php single_cat_title( '', true ); ?></h1>
      <div class="blog_section_top">
	  <div class="blog_section_top_left">
	<article>


<?php  
		
		$uploaddir = wp_upload_dir('2018/12');

		/*$page_object = get_queried_object(); 


		$temp = $wp_query; $wp_query= null;


		$wp_query = new WP_Query(); $wp_query->query('category_name='.$page_object->cat_name.'&showposts=10' . '&paged='.$paged);*/


		if (have_posts() && strlen( trim(get_search_query()) ) != 0) : while (have_posts()) : the_post()
		
		?>

            
             <a href="<?php the_permalink() ?>" title="<?php the_title() ?>">
             
             <?php if ( has_post_thumbnail() ) {the_post_thumbnail('medium_large');}else{?> 
								
					<img src="<?php echo esc_url(get_template_directory_uri());?>/images/harvee-blog.jpg" alt="Harvee Blog" />	
									
				<?php } ?>
			            
			<div class="blogdate">
          
           		<h2><?php the_title(); ?></h2>
           		
           		<div class="clear"></div>
           		
				<div class="post-date">
					<span></span>
					<?php the_time('F d,Y'); ?>
				</div>
          		<!--|
          		<div class="post-comment">
          			<span></span>
					<?php //echo get_comments_number(); ?>
				</div>-->
           
            </div>
               
            <div class="post-desc">               
             
				<p> <?php echo substr(wp_strip_all_tags(get_the_excerpt(''),true),0,130);?>...<a href="<?php the_permalink() ?>" title="<?php the_title() ?>"><span><font style="font-size:16px;color:#017dad;text-decoration:none;font-weight:bold">Read more</font></span></a></p>
            
				<?php 

				 $catname = "";
				foreach((get_the_category()) as $category){
					$category_link = get_category_link( $category->cat_ID );
					$catname .=  '<a href="'.esc_url( $category_link ).'" title="'.$category->name.'">'.$category->name.'</a> / ';
					}
				
				$catname = trim($catname);

				?>
				<?php if($catname!=""){?>	
				 <div class="post-cat">
					 <span></span>
				 	<?php echo substr($catname,0,-1);?>
     			 </div>
     			 <?php } ?>
     			 
			</div>
      
      </a>
      
      <hr>
       

		<?php endwhile; ?>


		
<?php
the_posts_pagination( array(
	'mid_size'  => 2,
	'prev_text' => __( 'Previous', 'textdomain' ),
	'next_text' => __( 'Next', 'textdomain' ),
) );
?>

		<?php wp_reset_postdata(); ?>



    <?php else : ?>

            <h1 class="search-title">No results Found</h1>
               <p class="search-text">
                  It seems we can’t find what you’re looking for.
                  Perhaps you should try again with a different search term.
               </p>
               
         <?php endif; ?>


	</article>


    </div>    

<div class="blog_section_top_right">
    <?php include('includes/sidebar.php');?>
</div>
    

 </div>
</div>
</div>


<?php 



get_footer();



?>
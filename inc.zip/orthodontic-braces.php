<?php
/*Template Name:Orthodontic Braces*/
get_header();?>

<!--slider_section-->
<section class="slide_section">
	<div id="home_slider" class="carousel bs-slider slide control-round indicators-line" data-ride="carousel" data-pause="hover" data-interval="false">
		<div class="carousel-inner" role="listbox">
			<div class="item active">
				<img src="<?php echo esc_url(get_template_directory_uri());?>/images/banner/bracesd.png" alt="Banenr" class="desk_banner">
				<img src="<?php echo esc_url(get_template_directory_uri());?>/images/banner/bracesm.png" alt="Banenr" class="mob_banner">
				<div class="slide-text">
					<div class="slide_text_left">
						<h2 data-animation="animated fadeInLeft">Orthodontic Braces</h2>
						<a class="book" href="<?php echo get_site_url();?>/contact-us/" title="Send Enquiry"><button data-animation="animated fadeInLeft">Send Enquiry</button></a>
					</div>
					
				</div>
			</div>
			
			<!-- <a class="nav_left" href="#home_slider" role="button" data-slide="prev"></a>
			<a class="nav_right" href="#home_slider" role="button" data-slide="next"></a>  
			<ol class="nav_dots carousel-indicators">
				<li data-target="#home_slider" data-slide-to="0" class="active"></li>
				<li data-target="#home_slider" data-slide-to="1"></li>
			</ol> -->
		</div>
	</div>
</section>
<!--slider_section-->


<!--aboutus_section-->


<section class="aboutus_section services_all_section">
	<div class="wrap_grid">
		<div class="aboutus_align">
			<div class="aboutus_left">
				<img src="<?php echo esc_url(get_template_directory_uri());?>/images/services/braces1.png" alt="About Us">
			</div>
			<div class="aboutus_right">
				<div class="head_text">
					<h4>YOUR SMILE SAVER</h4>
					<h1>Orthodontic Braces</h1>
				</div>
				<p>Invisible braces are a great alternative when you want to straighten your teeth without the discomfort of metal braces in your mouth. Crooked, uneven teeth can make you feel self-conscious. Well-aligned teeth are not only cosmetically pleasing but also help to maintain a healthy mouth. Traditionally metal braces have been used to correct problems of teeth alignment. But they are uncomfortable and can embarrass you while you speak and smile. Invisible braces are the best option in such cases. Thousands of teenagers and adult patients have been able to transform their smile with Invisible Braces.</p>
				
			</div>
		</div>
		<div class="aboutus_align">
			<div class="aboutus_left">
				<img src="<?php echo esc_url(get_template_directory_uri());?>/images/services/braces2.png" alt="About Us">
			</div>
			<div class="aboutus_right">
				<div class="head_text">
					<h2>Transparent braces/ Aligner:</h2>
				</div>
				<p>Transparent braces/ Aligner is a comfortable and removable option to braces. It transforms your smile without interfering with your day-to-day life. It is a series of transparent and removable aligners that straighten your teeth. These aligners are lightweight and fit snugly to your teeth. Each aligner provides minor tooth movement. There are multiple sets of aligners that gradually move your teeth and straighten them. Each aligner is worn for 2 weeks and replaced by the next one in the series. You can easily take them out of your teeth.</p>
				
			</div>
		</div>
		<div class="aboutus_align">
			<div class="aboutus_left">
				<img src="<?php echo esc_url(get_template_directory_uri());?>/images/services/braces3.png" alt="About Us">
			</div>
			<div class="aboutus_right">
				<div class="head_text">
					<h2>Benefits of Transparent braces/ Aligner:</h2>
				</div>
				<p>They are comfortable as there are no metal brackets or wires to irritate the mouth. Being removable, you can eat and drink as per your wish during treatment. Brushing and flossing are also easy. Being transparent the aligners are hardly noticeable. You can also remove them for special occasions.</p>
				
			</div>
		</div>
		<div class="aboutus_align">
			<div class="aboutus_left">
				<img src="<?php echo esc_url(get_template_directory_uri());?>/images/services/braces4.png" alt="About Us">
			</div>
			<div class="aboutus_right">
				<div class="head_text">
					<h2>How does it work?</h2>
				</div>
				<p>Our dentists will take scans of your teeth at the initial visit. The latest 3D Scanner and printers plan your aligners and customize them to your teeth. The cutting-edge technology fabricates each aligner with precise control. The optimum amount of force to move each tooth is decided beforehand. You can visualize the results beforehand. It takes between 6-12 months to achieve the desired results.</p>
				
			</div>
		</div>
		<div class="aboutus_align">
			<div class="aboutus_left">
				<img src="<?php echo esc_url(get_template_directory_uri());?>/images/services/braces5.png" alt="About Us">
			</div>
			<div class="aboutus_right">
				<div class="head_text">
					<h2>Ceramic braces:</h2>
				</div>
				<p>They are made of tooth-colored material and hence are less visible on your teeth in comparison with metal braces. They are similar to metal braces when it comes to the strength & functionality. Being minimally visible they are preferred by patients as a cosmetic alternative to regular braces.</p>
				
			</div>
		</div>
		<div class="aboutus_align">
			<div class="aboutus_left">
				<img src="<?php echo esc_url(get_template_directory_uri());?>/images/services/braces6.png" alt="About Us">
			</div>
			<div class="aboutus_right">
				<div class="head_text">
					<h2>Lingual braces:</h2>
				</div>
				<p>Unlike traditional braces, in lingual braces, the brackets and wires are placed on the inner surface of the teeth which makes them invisible from outside. These braces are an ideal choice for those who are concerned about their cosmetic appearance during orthodontic treatment. They are customized to the contour of your teeth which makes them comfortable.</p>
				<p>At Signature Smiles, your invisible braces treatment is customized according to your needs, expectations and lifestyle. We make straightening your teeth as affordable as possible. The cost of invisible braces depends on the severity of the tooth alignment problem and the type of braces used.</p>
				<p>Our expert highly experienced and certified Orthodontists will help you determine the best invisible braces option for your individual needs as well as the cost of treatment. So if you are thinking of having perfectly straight teeth, then call us today to schedule an appointment and find out if you are a candidate for invisible braces.</p>
			</div>
		</div>
	</div>
</section>


<!--aboutus_section-->







<!--faq_section-->



<!-- <div class="faq_section">
	<div class="wrap_grid">
		<div class="head_text">
			<h4>FAQ</h4>
			<h2>Common Queries</h2>
		</div>
		<ul class="faq_section_page">
			<li class="faq_align faq_open">
				<div class="faq_question">
					<h4>Is there a risk associated with dental implants?</h4>
				</div>
				<div class="faq_answer" style="display: block;">
					<p>Dental implants are a tried and tested procedure that has no possible risks. It has been demonstrated to be safe and successful for more than a decade, and it is considered the most reliable technique in dentistry. Infection, discomfort, numbness, or tingling are examples of minor consequences.</p>
				</div>
			</li>
			<li class="faq_align">
				<div class="faq_question">
					<h4>Is there a risk associated with dental implants?</h4>
				</div>
				<div class="faq_answer">
					<p>Dental implants are a tried and tested procedure that has no possible risks. It has been demonstrated to be safe and successful for more than a decade, and it is considered the most reliable technique in dentistry. Infection, discomfort, numbness, or tingling are examples of minor consequences.</p>
				</div>
			</li>
			<li class="faq_align">
				<div class="faq_question">
					<h4>Is there a risk associated with dental implants?</h4>
				</div>
				<div class="faq_answer">
					<p>Dental implants are a tried and tested procedure that has no possible risks. It has been demonstrated to be safe and successful for more than a decade, and it is considered the most reliable technique in dentistry. Infection, discomfort, numbness, or tingling are examples of minor consequences.</p>
				</div>
			</li>
			<li class="faq_align">
				<div class="faq_question">
					<h4>Is there a risk associated with dental implants?</h4>
				</div>
				<div class="faq_answer">
					<p>Dental implants are a tried and tested procedure that has no possible risks. It has been demonstrated to be safe and successful for more than a decade, and it is considered the most reliable technique in dentistry. Infection, discomfort, numbness, or tingling are examples of minor consequences.</p>
				</div>
			</li>
		</ul>
	</div>
</div> -->



<!--faq_section-->









<?php
/*Template Name:About Us*/
get_footer();?>



<script type="text/javascript">

	$(function() {
		var Accordion = function(el, multiple) {
				this.el = el || {};
				this.multiple = multiple || false;

				var links = this.el.find('.faq_question');
				links.on('click', {
						el: this.el,
						multiple: this.multiple
				}, this.dropdown)
		}

		Accordion.prototype.dropdown = function(e) {
				var $el = e.data.el;
				$this = $(this),
						$next = $this.next();

				$next.slideToggle();
				$this.parent().toggleClass('faq_open');

				if (!e.data.multiple) {
						$el.find('.faq_answer').not($next).slideUp().parent().removeClass('faq_open');
				};
		}
		var accordion = new Accordion($('.faq_section_page'), false);
});
</script>
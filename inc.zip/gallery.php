<?php
/*Template Name:Gallery*/
get_header();?>

<!--slider_section-->
<section class="slide_section">
	<div id="home_slider" class="carousel bs-slider slide control-round indicators-line" data-ride="carousel" data-pause="hover" data-interval="false">
		<div class="carousel-inner" role="listbox">
			<div class="item active">
				<img src="<?php echo esc_url(get_template_directory_uri());?>/images/banner/gallery.png" alt="Banenr" class="desk_banner">
				<img src="<?php echo esc_url(get_template_directory_uri());?>/images/banner/gallerym.png" alt="Banenr" class="mob_banner">
				<div class="slide-text">
					<div class="slide_text_left">
						<h2 data-animation="animated fadeInLeft">We help to
create Wide and beautiful smile</h2>
						<a class="book" href="<?php echo get_site_url();?>/contact-us/" title="Send Enquiry"><button data-animation="animated fadeInLeft">Send Enquiry</button></a>
					</div>
					
				</div>
			</div>
			
			<!-- <a class="nav_left" href="#home_slider" role="button" data-slide="prev"></a>
			<a class="nav_right" href="#home_slider" role="button" data-slide="next"></a>  
			<ol class="nav_dots carousel-indicators">
				<li data-target="#home_slider" data-slide-to="0" class="active"></li>
				<li data-target="#home_slider" data-slide-to="1"></li>
			</ol> -->
		</div>
	</div>
</section>
<!--slider_section-->




<!--inner_smile_gallery_section-->

<main class="cd-main-content">
<div class="inner_smile_gallery_section">
	<div class="wrap_grid">
		<div class="head_text">
			<h4>Smile Gallery</h4>
			<h1>Smile Before and After</h1>
		</div>
		<div class="inner_smile_gallery_align">
			<div class="inner_smile_gallery_left">

				<div class="cd-tab-filter-wrapper">
					<h2>Catergories</h2>
					<div class="cd-tab-filter">
						<ul class="cd-filters" id="test">
							<li class="placeholder"> 
								<a data-type="all" href="javascript:void(0)">All</a> <!-- selected option on mobile -->
							</li> 
							<li class="filter"><a class="selected" href="javascript:void(0)" data-type="all">All</a></li>
							<li class="filter" value="prosthodontics" data-filter=".prosthodontics"><a href="javascript:void(0)" data-type="prosthodontics">Prosthodontics</a></li>
							<li class="filter" value="pediatricdentistry" data-filter=".pediatricdentistry"><a href="javascript:void(0)" data-type="pediatricdentistry">Pediatric Dentistry</a></li>
							<li class="filter" value="orthodontic" data-filter=".orthodontic"><a href="javascript:void(0)" data-type="orthodontic">Orthodontic</a></li>
							<li class="filter" value="laserdentistry" data-filter=".laserdentistry"><a href="javascript:void(0)" data-type="laserdentistry">Laser Dentistry</a></li>
							<li class="filter" value="sedationdentistry" data-filter=".sedationdentistry"><a href="javascript:void(0)" data-type="sedationdentistry">Sedation Dentistry</a></li>
							<li class="filter" value="rootcanaltreatment" data-filter=".rootcanaltreatment"><a href="javascript:void(0)" data-type="rootcanaltreatment">Root Canal Treatment</a></li>
							<li class="filter" value="flossing" data-filter=".flossing"><a href="javascript:void(0)" data-type="flossing">Flossing</a></li>
							<li class="filter" value="brushingtechniques" data-filter=".brushingtechniques"><a href="javascript:void(0)" data-type="brushingtechniques">Brushing Techniques</a></li>
						</ul>
					</div>
				</div>
			</div>
			<div class="inner_smile_gallery_right">
				<section class="cd-gallery">
					<div class="cd_gallery_wrap">
					<ul>
						<li class="mix prosthodontics">
	<a href="<?php echo esc_url(get_template_directory_uri());?>/images/smile-gallery/1.png" data-fancybox="beforeafter" data-caption="Before &amp; After">
		<img src="<?php echo esc_url(get_template_directory_uri());?>/images/smile-gallery/1.png" alt="Before &amp; After" title="Before &amp; After">
	</a>
</li>
<li class="mix pediatricdentistry">
	<a href="<?php echo esc_url(get_template_directory_uri());?>/images/smile-gallery/1.png" data-fancybox="beforeafter" data-caption="Before &amp; After">
		<img src="<?php echo esc_url(get_template_directory_uri());?>/images/smile-gallery/1.png" alt="Before &amp; After" title="Before &amp; After">
	</a>
</li>
<li class="mix prosthodontics">
	<a href="<?php echo esc_url(get_template_directory_uri());?>/images/smile-gallery/1.png" data-fancybox="beforeafter" data-caption="Before &amp; After">
		<img src="<?php echo esc_url(get_template_directory_uri());?>/images/smile-gallery/1.png" alt="Before &amp; After" title="Before &amp; After">
	</a>
</li>
<li class="mix pediatricdentistry">
	<a href="<?php echo esc_url(get_template_directory_uri());?>/images/smile-gallery/1.png" data-fancybox="beforeafter" data-caption="Before &amp; After">
		<img src="<?php echo esc_url(get_template_directory_uri());?>/images/smile-gallery/1.png" alt="Before &amp; After" title="Before &amp; After">
	</a>
</li>
<li class="mix prosthodontics">
	<a href="<?php echo esc_url(get_template_directory_uri());?>/images/smile-gallery/1.png" data-fancybox="beforeafter" data-caption="Before &amp; After">
		<img src="<?php echo esc_url(get_template_directory_uri());?>/images/smile-gallery/1.png" alt="Before &amp; After" title="Before &amp; After">
	</a>
</li>
<li class="mix pediatricdentistry">
	<a href="<?php echo esc_url(get_template_directory_uri());?>/images/smile-gallery/1.png" data-fancybox="beforeafter" data-caption="Before &amp; After">
		<img src="<?php echo esc_url(get_template_directory_uri());?>/images/smile-gallery/1.png" alt="Before &amp; After" title="Before &amp; After">
	</a>
</li>
					</ul>
					<div class="cd-fail-message">No results found</div>
					</div>
				</section>
			</div>
		</div>
	</div>
</div>
</main>

<!--inner_smile_gallery_section-->
















<?php
/*Template Name:About Us*/
get_footer();?>



<script type="text/javascript">
	$('[data-fancybox="beforeafter"]').fancybox({
            buttons: [
                "slideShow",
                "thumbs",
                "zoom",
                "fullScreen",
                //"share",
                "close"
            ],
            loop: false,
            protect: true
        })
</script>
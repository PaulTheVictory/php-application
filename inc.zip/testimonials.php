<?php
/*Template Name:Testimonials*/
get_header();?>

<!--slider_section-->
<section class="slide_section">
	<div id="home_slider" class="carousel bs-slider slide control-round indicators-line" data-ride="carousel" data-pause="hover" data-interval="false">
		<div class="carousel-inner" role="listbox">
			<div class="item active">
				<img src="<?php echo esc_url(get_template_directory_uri());?>/images/banner/testimonials.png" alt="Banenr" class="desk_banner">
				<img src="<?php echo esc_url(get_template_directory_uri());?>/images/banner/testimonialsm.png" alt="Banenr" class="mob_banner">
				<div class="slide-text">
					<div class="slide_text_left">
						<h2 data-animation="animated fadeInLeft">Our Patients are
happy with our Service</h2>
						<a class="book" href="<?php echo get_site_url();?>/contact-us/" title="Send Enquiry"><button data-animation="animated fadeInLeft">Send Enquiry</button></a>
					</div>
					
				</div>
			</div>
			
			<!-- <a class="nav_left" href="#home_slider" role="button" data-slide="prev"></a>
			<a class="nav_right" href="#home_slider" role="button" data-slide="next"></a>  
			<ol class="nav_dots carousel-indicators">
				<li data-target="#home_slider" data-slide-to="0" class="active"></li>
				<li data-target="#home_slider" data-slide-to="1"></li>
			</ol> -->
		</div>
	</div>
</section>
<!--slider_section-->




<!--testimonials_listing_section-->


<div class="testimonials_listing_section">
	<div class="wrap_grid">
		<div class="head_text">
			<h4>Testimonials</h4>
			<h1>Our Patients</h1>
		</div>
		<ul>
			<li>
				<div class="testi_listing_box">
					<img src="<?php echo esc_url(get_template_directory_uri());?>/images/testimonials/testi.png" alt="testimonials" class="main_img">
					<div class="content_testi">
					<img src="<?php echo esc_url(get_template_directory_uri());?>/images/rating.png" alt="rating" class="main_img">
					<h4>Vasanthi</h4>
					<p>Really appreciate Dr.Charu's treatment. All my teeth now looks neat. Could smile happily. She is so kind and friendly in assisting me towards caring my teeth. Upon seeing the treatment done one me, my sister and nephew are waiting for the travel opportunity to resume. Even though we are from Malaysia we don't mind visiting SRI GIRIRAJ DENTAL and Dr. Charu.</p>
					</div>
				</div>
			</li>
			<li>
				<div class="testi_listing_box">
					<img src="<?php echo esc_url(get_template_directory_uri());?>/images/testimonials/testi.png" alt="testimonials" class="main_img">
					<div class="content_testi">
					<img src="<?php echo esc_url(get_template_directory_uri());?>/images/rating.png" alt="rating" class="main_img">
					<h4>Divya Kathir</h4>
					<p>Review from another Happy patient! I have gone for Root canal, tooth fillings. Dr.Charu is a good dentist who clearly understands patient needs, takes time in explaining the problem in detail, who does the treatment so comfortably. I also admire her honesty, patience, kind-hearted, lovable character. Charu mam always thinks from patient perspective and never prescribe medicines/antibiotics unnecessarily unless & until it's highly required to opt for. I always appreciate her for the quick replies over WhatsApp for my queries. Thanks for the best dental treatment!.</p>
					</div>
				</div>
			</li>
			<li>
				<div class="testi_listing_box">
					<img src="<?php echo esc_url(get_template_directory_uri());?>/images/testimonials/testi.png" alt="testimonials" class="main_img">
					<div class="content_testi">
					<img src="<?php echo esc_url(get_template_directory_uri());?>/images/rating.png" alt="rating" class="main_img">
					<h4>Soundararajan</h4>
					<p>Dr. Charu Priyadarshini is very considerate when handling patients. Her experience and expertise in detal care is evident.  Dr. Charu recommended right dose and alleviated the issue for one of my relative, when there was an issue regarding the drug dose by other practitioner. When performing extraction also, Dr. Charu is very concious and careful. Overall, A good service and patient care.</p>
					</div>
				</div>
			</li>
			<li>
				<div class="testi_listing_box">
					<img src="<?php echo esc_url(get_template_directory_uri());?>/images/testimonials/testi.png" alt="testimonials" class="main_img">
					<div class="content_testi">
					<img src="<?php echo esc_url(get_template_directory_uri());?>/images/rating.png" alt="rating" class="main_img">
					<h4>Vidhya</h4>
					<p>Excellent Dentist!!!
Very friendly and professional Dental Care.
I recommend this clinic because the Dentist is very professional and honest.Very thorough and caring.She goes the extra mile to make you feel comfortable.</p>
					</div>
				</div>
			</li>
			<li>
				<div class="testi_listing_box">
					<img src="<?php echo esc_url(get_template_directory_uri());?>/images/testimonials/testi.png" alt="testimonials" class="main_img">
					<div class="content_testi">
					<img src="<?php echo esc_url(get_template_directory_uri());?>/images/rating.png" alt="rating" class="main_img">
					<h4>Sangeetha</h4>
					<p>I visited this clinic few days back due to tooth pain. The doctor was very considerate and gave me good advice and treatment. I will recommend this clinic.</p>
					</div>
				</div>
			</li>
			<li>
				<div class="testi_listing_box">
					<img src="<?php echo esc_url(get_template_directory_uri());?>/images/testimonials/testi.png" alt="testimonials" class="main_img">
					<div class="content_testi">
					<img src="<?php echo esc_url(get_template_directory_uri());?>/images/rating.png" alt="rating" class="main_img">
					<h4>Muniandy</h4>
					<p>Did crowning for my upper jaw incisors 8 years ago.
Still in good form and matches to the rest. Good job done. Very happy with the services.</p>
					</div>
				</div>
			</li>
			<li>
				<div class="testi_listing_box">
					<img src="<?php echo esc_url(get_template_directory_uri());?>/images/testimonials/testi.png" alt="testimonials" class="main_img">
					<div class="content_testi">
					<img src="<?php echo esc_url(get_template_directory_uri());?>/images/rating.png" alt="rating" class="main_img">
					<h4>Manoharan R</h4>
					<p>Dr. Charu is caring and a patient doctor.
She treats patients with utmost care. She explains what the problem is and wat should be done and wat shouldn't be done.....</p>
					</div>
				</div>
			</li>
			<li>
				<div class="testi_listing_box">
					<img src="<?php echo esc_url(get_template_directory_uri());?>/images/testimonials/testi.png" alt="testimonials" class="main_img">
					<div class="content_testi">
					<img src="<?php echo esc_url(get_template_directory_uri());?>/images/rating.png" alt="rating" class="main_img">
					<h4>Hina</h4>
					<p>Experience with Dr charu ma'am is amazing...she is very nice and polite and will go again in future if i need any dental treatment 🙂</p>
					</div>
				</div>
			</li>
			<li>
				<div class="testi_listing_box">
					<img src="<?php echo esc_url(get_template_directory_uri());?>/images/testimonials/testi.png" alt="testimonials" class="main_img">
					<div class="content_testi">
					<img src="<?php echo esc_url(get_template_directory_uri());?>/images/rating.png" alt="rating" class="main_img">
					<h4>Ramya</h4>
					<p>Excellent dental care and the ma’am is very patient and supportive and it’s highly recommended</p>
					</div>
				</div>
			</li>
			<li>
				<div class="testi_listing_box">
					<img src="<?php echo esc_url(get_template_directory_uri());?>/images/testimonials/testi.png" alt="testimonials" class="main_img">
					<div class="content_testi">
					<img src="<?php echo esc_url(get_template_directory_uri());?>/images/rating.png" alt="rating" class="main_img">
					<h4>Saraswathy</h4>
					<p>Very professional and patience....she explains clearly about the treatment...👌👌👌👌</p>
					</div>
				</div>
			</li>
			<li>
				<div class="testi_listing_box">
					<img src="<?php echo esc_url(get_template_directory_uri());?>/images/testimonials/testi.png" alt="testimonials" class="main_img">
					<div class="content_testi">
					<img src="<?php echo esc_url(get_template_directory_uri());?>/images/rating.png" alt="rating" class="main_img">
					<h4>Jayakumar</h4>
					<p>All Kinds of Dental Treatments Done</p>
					</div>
				</div>
			</li>
			
		</ul>
	</div>
</div>


<!--testimonials_listing_section-->





















<?php
/*Template Name:About Us*/
get_footer();?>




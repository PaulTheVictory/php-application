<?php
/*Template Name:Crowns and Bridges*/
get_header();?>

<!--slider_section-->
<section class="slide_section">
	<div id="home_slider" class="carousel bs-slider slide control-round indicators-line" data-ride="carousel" data-pause="hover" data-interval="false">
		<div class="carousel-inner" role="listbox">
			<div class="item active">
				<img src="<?php echo esc_url(get_template_directory_uri());?>/images/banner/bridged.png" alt="Banenr" class="desk_banner">
				<img src="<?php echo esc_url(get_template_directory_uri());?>/images/banner/bridgem.png" alt="Banenr" class="mob_banner">
				<div class="slide-text">
					<div class="slide_text_left">
						<h2 data-animation="animated fadeInLeft">Crowns and Bridges</h2>
						<a class="book" href="<?php echo get_site_url();?>/contact-us/" title="Send Enquiry"><button data-animation="animated fadeInLeft">Send Enquiry</button></a>
					</div>
					
				</div>
			</div>
			
			<!-- <a class="nav_left" href="#home_slider" role="button" data-slide="prev"></a>
			<a class="nav_right" href="#home_slider" role="button" data-slide="next"></a>  
			<ol class="nav_dots carousel-indicators">
				<li data-target="#home_slider" data-slide-to="0" class="active"></li>
				<li data-target="#home_slider" data-slide-to="1"></li>
			</ol> -->
		</div>
	</div>
</section>
<!--slider_section-->


<!--aboutus_section-->


<section class="aboutus_section services_all_section">
	<div class="wrap_grid">
		<div class="aboutus_align">
			<div class="aboutus_left">
				<img src="<?php echo esc_url(get_template_directory_uri());?>/images/services/bridge1.png" alt="About Us">
			</div>
			<div class="aboutus_right">
				<div class="head_text">
					<h4>YOUR SMILE SAVER</h4>
					<h1>Crowns and Bridges</h1>
				</div>
				<p>As many of us know, when you have a missing tooth, it can be difficult to communicate, speak, bite or even eat effectively. When a tooth is missing, it is essential to visit your dentist to discuss the dental options for replacement.</p>
				<p>Dental bridges are utilized in dentistry to replace the missing teeth and provide a bridge that connects the adjoining teeth. The teeth on either side of the missing tooth are called abutment teeth and the replacement tooth is called the pontic (false tooth).</p>
			</div>
		</div>
		<div class="aboutus_align">
			<div class="aboutus_left">
				<img src="<?php echo esc_url(get_template_directory_uri());?>/images/services/bridge2.png" alt="About Us">
			</div>
			<div class="aboutus_right">
				<div class="head_text">
					<h2>Why are Bridges Important?</h2>
				</div>
				<p>Dental bridges will help restore your smile and maintain the appropriate face shape. They can also help you properly chew food, speak and place the jaws together when biting, which helps prevent other teeth in the mouth from moving out of place or drifting apart.</p>
				
				<p>Bridges and crowns are fixed prosthetic devices that are cemented onto existing teeth or implants, by a dentist or prosthodontist. Crowns are used most commonly to entirely cover or "cap" a damaged tooth or cover an implant. Your dentist may recommend a crown to:</p>
			</div>
		</div>
		
		<div class="aboutus_align">
			<div class="aboutus_left">
				<img src="<?php echo esc_url(get_template_directory_uri());?>/images/services/bridge3.png" alt="About Us">
			</div>
			<div class="aboutus_right">
				<ul>
					<li>Replace a large filling when there isn't enough tooth remaining</li>
					<li>Protect a weak tooth from fracturing</li>
					<li>Restore a fractured tooth</li>
					<li>Attach a bridge</li>
					<li>Cover a dental implant</li>
					<li>Cover a discolored or poorly shaped tooth</li>
					<li>Cover a tooth that has had root canal treatment</li>
					<li>Gaps left by missing teeth eventually cause the remaining teeth to shift resulting in a bad bite. This can also lead to gum disease and TMJ disorders. Bridges are commonly used if you’re missing one or more teeth. They cover the space where the teeth are missing and are cemented to natural teeth or implants surrounding the space.</li>
				</ul>
			</div>
		</div>
		<div class="aboutus_align">
			<div class="aboutus_left">
				<img src="<?php echo esc_url(get_template_directory_uri());?>/images/services/bridge4.png" alt="About Us">
			</div>
			<div class="aboutus_right">
				<p>Bridges and crowns are fixed prosthetic devices that are cemented onto existing teeth or implants by a dentist or prosthodontist. Crowns are used most commonly to entirely cover or "cap" a damaged tooth or cover an implant. Bridges are commonly used to cover a space if you’re missing one or more teeth. They are cemented to natural teeth or implants surrounding the space where the tooth once stood.</p>
			</div>
		</div>
		<div class="aboutus_align">
			<div class="aboutus_left">
				<img src="<?php echo esc_url(get_template_directory_uri());?>/images/services/bridge5.png" alt="About Us">
			</div>
			<div class="aboutus_right">
				<div class="head_text">
					<h2>Benefits of BRIDGES & CROWNS</h2>
				</div>
				<p>In addition to strengthening a damaged tooth, bridges and crowns can be used to improve a tooth’s appearance, shape, alignment and dental occlusion (bite). Gaps left by missing teeth can cause the remaining teeth to shift, which can result in a bad bite. Bridges and crowns help prevent this from happening.</p>
				<ul>
					<li>While crowns and bridges can last a lifetime, they do sometimes come loose or fall out. The most important step you can take to ensure the longevity of your crown is to practice good oral hygiene.</li>
					<li>Keep your gums and teeth healthy by brushing with fluoride toothpaste twice a day and flossing daily</li>
					<li>See your dentist or hygienist regularly for checkups and professional cleanings</li>
					<li>To prevent damage to your new crown or bridge, avoid chewing hard foods, ice or other hard objects</li>
				</ul>
			</div>
		</div>
	</div>
</section>


<!--aboutus_section-->







<!--faq_section-->



<!-- <div class="faq_section">
	<div class="wrap_grid">
		<div class="head_text">
			<h4>FAQ</h4>
			<h2>Common Queries</h2>
		</div>
		<ul class="faq_section_page">
			<li class="faq_align faq_open">
				<div class="faq_question">
					<h4>Is there a risk associated with dental implants?</h4>
				</div>
				<div class="faq_answer" style="display: block;">
					<p>Dental implants are a tried and tested procedure that has no possible risks. It has been demonstrated to be safe and successful for more than a decade, and it is considered the most reliable technique in dentistry. Infection, discomfort, numbness, or tingling are examples of minor consequences.</p>
				</div>
			</li>
			<li class="faq_align">
				<div class="faq_question">
					<h4>Is there a risk associated with dental implants?</h4>
				</div>
				<div class="faq_answer">
					<p>Dental implants are a tried and tested procedure that has no possible risks. It has been demonstrated to be safe and successful for more than a decade, and it is considered the most reliable technique in dentistry. Infection, discomfort, numbness, or tingling are examples of minor consequences.</p>
				</div>
			</li>
			<li class="faq_align">
				<div class="faq_question">
					<h4>Is there a risk associated with dental implants?</h4>
				</div>
				<div class="faq_answer">
					<p>Dental implants are a tried and tested procedure that has no possible risks. It has been demonstrated to be safe and successful for more than a decade, and it is considered the most reliable technique in dentistry. Infection, discomfort, numbness, or tingling are examples of minor consequences.</p>
				</div>
			</li>
			<li class="faq_align">
				<div class="faq_question">
					<h4>Is there a risk associated with dental implants?</h4>
				</div>
				<div class="faq_answer">
					<p>Dental implants are a tried and tested procedure that has no possible risks. It has been demonstrated to be safe and successful for more than a decade, and it is considered the most reliable technique in dentistry. Infection, discomfort, numbness, or tingling are examples of minor consequences.</p>
				</div>
			</li>
		</ul>
	</div>
</div> -->



<!--faq_section-->









<?php
/*Template Name:About Us*/
get_footer();?>



<script type="text/javascript">

	$(function() {
		var Accordion = function(el, multiple) {
				this.el = el || {};
				this.multiple = multiple || false;

				var links = this.el.find('.faq_question');
				links.on('click', {
						el: this.el,
						multiple: this.multiple
				}, this.dropdown)
		}

		Accordion.prototype.dropdown = function(e) {
				var $el = e.data.el;
				$this = $(this),
						$next = $this.next();

				$next.slideToggle();
				$this.parent().toggleClass('faq_open');

				if (!e.data.multiple) {
						$el.find('.faq_answer').not($next).slideUp().parent().removeClass('faq_open');
				};
		}
		var accordion = new Accordion($('.faq_section_page'), false);
});
</script>
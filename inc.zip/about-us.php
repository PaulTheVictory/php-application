<?php
/*Template Name:About Us*/
get_header();?>

<!--slider_section-->
<section class="slide_section">
	<div id="home_slider" class="carousel bs-slider slide control-round indicators-line" data-ride="carousel" data-pause="hover" data-interval="false">
		<div class="carousel-inner" role="listbox">
			<div class="item active">
				<img src="<?php echo esc_url(get_template_directory_uri());?>/images/banner/aboutus.png" alt="Banenr" class="desk_banner">
				<img src="<?php echo esc_url(get_template_directory_uri());?>/images/banner/aboutusm.png" alt="Banenr" class="mob_banner">
				<div class="slide-text">
					<div class="slide_text_left">
						<h2 data-animation="animated fadeInLeft">Creating Beautiful Smiles over 15 Years </h2>
						<a class="book" href="<?php echo get_site_url();?>/contact-us/" title="Send Enquiry"><button data-animation="animated fadeInLeft">Send Enquiry</button></a>
					</div>
					
				</div>
			</div>
			
			<!-- <a class="nav_left" href="#home_slider" role="button" data-slide="prev"></a>
			<a class="nav_right" href="#home_slider" role="button" data-slide="next"></a>  
			<ol class="nav_dots carousel-indicators">
				<li data-target="#home_slider" data-slide-to="0" class="active"></li>
				<li data-target="#home_slider" data-slide-to="1"></li>
			</ol> -->
		</div>
	</div>
</section>
<!--slider_section-->


<!--aboutus_section-->


<section class="aboutus_section aboutus_section1">
	<div class="wrap_grid">
		<div class="aboutus_align">
			<div class="aboutus_left">
				<img src="<?php echo esc_url(get_template_directory_uri());?>/images/about-us/aboutus.png" alt="About Us">
			</div>
			<div class="aboutus_right">
				<div class="head_text">
					<h4>WHO WE ARE</h4>
					<h1>Provide The Best Services
For Our Patients</h1>
				</div>
				<p>We are a team of highly qualified specialists from all the fields of dentistry with over 15 years of experience, handling both local and international patients.The calm and relaxing ambience of our clinic, will completely reduce anxiety of phobia about the dental treatments.
We maintain the highest standards of hygiene and adhere to stringent sterilization protocols for your safety. At Charu Dental Clinic, you get all kinds of dental procedures like Cosmetic Dentistry, Dental Implants, Smile Makeover, Braces, and Kid’s Dentistry etc, backed by modern technology and professional dental care experts.
</p>
				<!-- <a href="javascript:void(0)" title="Learn More">
					<button>Learn More</button>
				</a> -->
			</div>
		</div>
	</div>
</section>


<!--aboutus_section-->



<!--technologies_section-->


<div class="technologies_section">
		<div class="wrap_grid">
			<div class="technologies_align">
				<div class="technologies_left">
					<div class="head_text">
						<h2>We Have Advanced
Technologies</h2>
					</div>
					<p>Our mission is to create and sustain long term relationships with our patients. We aim to serve the patients with the safest and highest-quality dental care services to exceed their expectations at affordable costs. As well as, our mission is to improve the oral health and overall health of our society.
 </p>
				</div>
				<div class="technologies_right">
					<ul>
						<li>
							<div class="tech_box">
								<span>
									<img src="<?php echo esc_url(get_template_directory_uri());?>/images/about-us/t1.png" alt="Technologies">
								</span>
								<span>
									<h4>15 years of Experience</h4>
									<!-- <p></p> -->
								</span>
							</div>
						</li>
						<li>
							<div class="tech_box">
								<span>
									<img src="<?php echo esc_url(get_template_directory_uri());?>/images/about-us/t2.png" alt="Technologies">
								</span>
								<span>
									<h4>Advance Technology</h4>
									<!-- <p>Lorem Ipsums do vacites</p> -->
								</span>
							</div>
						</li>
						<li>
							<div class="tech_box">
								<span>
									<img src="<?php echo esc_url(get_template_directory_uri());?>/images/about-us/t3.png" alt="Technologies">
								</span>
								<span>
									<h4>Competitive Price
</h4>
									<!-- <p>Lorem Ipsums do vacites</p> -->
								</span>
							</div>
						</li>
						<li>
							<div class="tech_box">
								<span>
									<img src="<?php echo esc_url(get_template_directory_uri());?>/images/about-us/t4.png" alt="Technologies">
								</span>
								<span>
									<h4>Painless Treatment</h4>
									<!-- <p>Lorem Ipsums do vacites</p> -->
								</span>
							</div>
						</li>
					</ul>
				</div>
			</div>
		</div>
</div>


<!--technologies_section-->




<!--ourservice_section-->


<section class="ourservice_section">
	<div class="wrap_grid">
		<div class="head_text">
			<h4>services</h4>
			<h2>Our Specialize Care</h2>
		</div>
		<div class="slide-wrap">
		<ul class="service_slider">
			<div class="swiper-wrapper">
			<li class="swiper-slide">
				<div class="services_box">
					<img src="<?php echo esc_url(get_template_directory_uri());?>/images/about-us/vision.png" alt="Our Service">
					<h4>Vision</h4>
					<p>To be a household name, when it comes to the most trusted, caring and reputable dental practice in India.
</p>
					<!-- <a href="javascript:void(0)" title="Learn More">
						<button>Learn More</button>
					</a> -->
				</div>
			</li>
			<li class="swiper-slide">
				<div class="services_box">
					<img src="<?php echo esc_url(get_template_directory_uri());?>/images/about-us/mission.png" alt="Our Service">
					<h4>Mission</h4>
					<p>Adding value to the health and lives of people across the globe, by providing beautiful, healthy smiles, through the highest quality dentistry with personalized care.”</p>
					<!-- <a href="javascript:void(0)" title="Learn More">
						<button>Learn More</button>
					</a> -->
				</div>
			</li>
			<li class="swiper-slide">
				<div class="services_box">
					<img src="<?php echo esc_url(get_template_directory_uri());?>/images/about-us/values.png" alt="Our Service">
					<h4>Values</h4>
					<p>We understand that a relationship of trust and genuine care is our most valuable asset when it comes to helping you achieve optimal oral health. Each patient is an important person to us, a member of our dental family. </p>
					<!-- <a href="javascript:void(0)" title="Learn More">
						<button>Learn More</button>
					</a> -->
				</div>
			</li>
			</div>

		</ul>

<div class="service_prev"></div>
		<div class="service_next"></div>
		<div class="service_pagination"></div>
		</div>
	</div>
</section>



<!--ourservice_section-->






<!--founder_section-->


<div class="founder_section">
	<div class="wrap_grid">
		<div class="founder_align">
			<div class="founder_left">
				<div class="head_text">
					<h4>Founder</h4>
					<h2>Dr. Charu priyadarshini</h2>
				</div>
				<p>Dr. Charu priyadarshini having a 15 years of experience of professional clinical experience with a deep knowledge in examining radiography providing diagnosis n best treatments plans ,as well as performing restorative, prosthodontics, orthodontics and endodontics procedure with at most care and comfort. <a href="<?php echo get_site_url();?>/dr-charu-priyadarshini/" title="Dr. Charu priyadarshini" style="color: #000;font-weight: 700;"> read more..</a> </p>
				
			</div>
			<div class="founder_right">
					<img src="<?php echo esc_url(get_template_directory_uri());?>/images/about-us/founder.png" alt="Founder">
			</div>
		</div>
	</div>
</div>


<!--founder_section-->






<!--ourteam_section-->


<section class="ourteam_section ourteam_section_inner">
	<div class="wrap_grid">
		<div class="head_text">
			<h4>TEAM</h4>
			<h2>Our Expert team</h2>
		</div>
		<div class="testi_wrap">
		<ul class="team_slider">
			<div class="swiper-wrapper">
			<li class="swiper-slide">
				<div class="team_box">
					<a href="<?php echo get_site_url();?>/dr-charu-priyadarshini/" title="Dr. Charu priyadarshini"><img src="<?php echo esc_url(get_template_directory_uri());?>/images/ourteam.png" alt="ourteam"></a>
					<div class="desgination">
						<h4>Dr. Charu priyadarshini</h4>
						<p>Chief Doctor</p>
					</div>
				</div>
			</li>
			<li class="swiper-slide">
				<div class="team_box">
					<img src="<?php echo esc_url(get_template_directory_uri());?>/images/ourteam.png" alt="ourteam">
					<div class="desgination">
						<h4>Dr. Joseph Fernandez</h4>
						<p>Pedodontics</p>
					</div>
				</div>
			</li>
			<li class="swiper-slide">
				<div class="team_box">
					<img src="<?php echo esc_url(get_template_directory_uri());?>/images/ourteam.png" alt="ourteam">
					<div class="desgination">
						<h4>Dr. Joseph Fernandez</h4>
						<p>Pedodontics</p>
					</div>
				</div>
			</li>
			</div>
		</ul>
		<div class="team_prev"></div>
		<div class="team_next"></div>
		<div class="team_pagination"></div>
		</div>
	</div>
</section>



<!--ourteam_section-->





<?php
/*Template Name:About Us*/
get_footer();?>



<script type="text/javascript">

	new Swiper('.service_slider', {
        loop: true,
        speed: 1500,
        parallax: true,
        slidesPerView: 3,
        paginationClickable: true,
        spaceBetween: 8,
         autoplay: {
            delay: 3500,
            disableOnInteraction: false,
        },
        watchSlidesProgress: true,
        navigation: {
            nextEl: '.service_next',
            prevEl: '.service_prev',
        },
        pagination: {
            el: '.service_pagination',
            clickable: true,
        },
        breakpoints: {
            1920: {
                slidesPerView: 3,
                spaceBetween: 8
            },
            1200: {
                slidesPerView: 3,
                spaceBetween: 8
            },
            956: {
                slidesPerView: 2,
                spaceBetween: 8
            },
            768: {
                slidesPerView: 2,
                spaceBetween: 8
            },
            580: {
                slidesPerView: 2,
                spaceBetween: 8
            },
            320: {
                slidesPerView: 1,
                spaceBetween: 0
            }
        }
    });

	//
	new Swiper('.team_slider', {
        loop: true,
        speed: 1500,
        parallax: true,
        slidesPerView: 3,
        paginationClickable: true,
        spaceBetween: 20,
         autoplay: {
            delay: 3500,
            disableOnInteraction: false,
        },
        watchSlidesProgress: true,
        navigation: {
            nextEl: '.team_next',
            prevEl: '.team_prev',
        },
        pagination: {
            el: '.team_pagination',
            clickable: true,
        },
        breakpoints: {
            1920: {
                slidesPerView: 3,
                spaceBetween: 20
            },
            1200: {
                slidesPerView: 3,
                spaceBetween: 20
            },
            956: {
                slidesPerView: 2,
                spaceBetween: 20
            },
            768: {
                slidesPerView: 2,
                spaceBetween: 20
            },
            580: {
                slidesPerView: 2,
                spaceBetween: 20
            },
            320: {
                slidesPerView: 1,
                spaceBetween: 0
            }
        }
    });
</script>
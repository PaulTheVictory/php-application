<?php
/*Template Name:Contact Us*/
get_header();?>

<!--slider_section-->
<section class="slide_section">
	<div id="home_slider" class="carousel bs-slider slide control-round indicators-line" data-ride="carousel" data-pause="hover" data-interval="false">
		<div class="carousel-inner" role="listbox">
			<div class="item active">
				<img src="<?php echo esc_url(get_template_directory_uri());?>/images/banner/contact-us.png" alt="Banenr" class="desk_banner">
				<img src="<?php echo esc_url(get_template_directory_uri());?>/images/banner/contact-usm.png" alt="Banenr" class="mob_banner">
				<div class="slide-text">
					<div class="slide_text_left">
						<h2 data-animation="animated fadeInLeft">Happiness in your
Smile Near you</h2>
						<a class="book" href="<?php echo get_site_url();?>/contact-us/" title="Send Enquiry"><button data-animation="animated fadeInLeft">Send Enquiry</button></a>
					</div>
					
				</div>
			</div>
			
			<!-- <a class="nav_left" href="#home_slider" role="button" data-slide="prev"></a>
			<a class="nav_right" href="#home_slider" role="button" data-slide="next"></a>  
			<ol class="nav_dots carousel-indicators">
				<li data-target="#home_slider" data-slide-to="0" class="active"></li>
				<li data-target="#home_slider" data-slide-to="1"></li>
			</ol> -->
		</div>
	</div>
</section>
<!--slider_section-->




<!--inner_contactus_section-->


<div class="inner_contactus_section">
	<div class="wrap_grid">
		<div class="head_text">
			<h4>CONATCT US</h4>
			<h1>Get In Touch With Us</h1>
		</div>
		<div class="inner_contactus_align">
			<div class="inner_contactus_left">
				<ul>
					<li class="">
No 4 Phase, 1, Mahalakshmi Garden, Cheran ma Nagar, Villankurichi, Tamil Nadu 641035</li>
					<li class=""><a href="tel:9821821331" title="Call Now">+91 -9821821331 </a></li>
					<li class=""><a href="mailto:charubala108@gmail.com" title="Mail To">charubala108@gmail.com</a></li>
				</ul>
			</div>
			<div class="inner_contactus_right">
				<form accept-charset="utf-8" method="post" action="<?php echo esc_url(get_template_directory_uri());?>/book.php" id="book">
					<h2>Book an appointment</h2>
					<input type="text" name="cname" id="cname" placeholder="NAME">
					<input type="text" name="cphone" id="cphone" placeholder="PHONE">
					<input type="hidden" name="siteurl" value="<?php echo get_site_url();?>">
					<input type="text" name="cemail" id="cemail" placeholder="EMAIL ID">
					<textarea placeholder="MESSAGE" id="cmessage" name="cmessage"></textarea>
					<button type="submit">Submit Now</button>
				</form>
			</div>
		</div>
	</div>
</div>



<!--inner_contactus_section-->



<!--innermaps_section-->


<div class="innermaps_section">
	<img src="<?php echo esc_url(get_template_directory_uri());?>/images/contactus/maps.png" alt="Maps">
	<iframe src="https://www.google.com/maps/embed?pb=!1m26!1m12!1m3!1d62656.44722614298!2d76.95764865122186!3d11.036529689133062!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!4m11!3e6!4m3!3m2!1d11.0117096!2d76.967235!4m5!1s0x3ba85719c76d4d49%3A0xa2e2c7406514df19!2sDr.%20Charu&#39;s%20Multispeciality%20dental%20clinic!3m2!1d11.0574155!2d77.0185192!5e0!3m2!1sen!2sin!4v1654322895090!5m2!1sen!2sin" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
</div>


<!--innermaps_section-->






















<?php
/*Template Name:About Us*/
get_footer();?>


<script>

	
$(document).ready(function(){
$("#book").submit(function(e){
		
	
	var cname = document.getElementById("cname").value;
	var cphone = document.getElementById("cphone").value;
	var cemail = document.getElementById("cemail").value;
	
	var cmessage = document.getElementById("cmessage").value;
	// var capcha1 = document.getElementById("capcha1").value;
	// var capcha2 = document.getElementById("capcha2").value;
	
	 var regex='';
    var valid;

    regex   = '^[a-zA-Z][a-zA-Z\. ]{2,40}$';
    valid = validateInputs(cname,regex);

	if( (!valid) || (cname  == "")) {
         alert('Please enter valid name');
         return false;
     }
    regex   = '^[0-9 \-]{10,20}$';
    valid = validateInputs(cphone,regex);
   
   if( (!valid) || (cphone == "") ) {
         alert('Please enter valid phone number');
         return false;
    }

    regex   = '^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$';
    valid = validateInputs(cemail,regex);
    if((!valid) || (cemail == "") ) {
         alert('Please enter valid email address');
         return false;
    }
      
   
	
	
	
	if(cmessage == '') {

      alert("Please enter some valid message");
      return false;
    }
	 
	
	 // if(capcha1 != capcha2) {
		 
		//   alert("Invalid Capthca Code");
  //     return false;
	 // }
	
	$("#book").submit();
	
	e.preventDefault();
		
	
});


function validateInputs(value,pattern) {
    
    var regexppattern;
    regexppattern = new RegExp(pattern);
    var valid     = regexppattern.test(value);
    
    return valid;
}
});

</script>

<?php
/**
 * The template for displaying 404 pages (not found)
 *
 * @package WordPress
 * @subpackage Twenty_Fifteen
 * @since Twenty Fifteen 1.0
 */

get_header(); ?>















<div class="all_pages">
	<div class="wrap_grid">
		<div class="single_blog blog_page_listing_left_single">
			<div class="head_text">
				<h1>Oops! That page can&rsquo;t be found.</h1>
			</div>
			<a href="<?php echo get_site_url();?>" title="Krdentalcare"><button class="back_home" style="margin: 30px auto auto auto;display: flex;">Home</button></a>
		</div>
	</div>
</div>
	
	
	
	
	
	
	
	
	
	

<?php get_footer(); ?>
<script>$( ".carousel-inner .item:first-child" ).addClass( "active" );</script>
-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 15, 2022 at 06:41 PM
-- Server version: 10.3.16-MariaDB
-- PHP Version: 7.3.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `adi_admin`
--

-- --------------------------------------------------------

--
-- Table structure for table `activity`
--

CREATE TABLE `activity` (
  `act_id` bigint(20) NOT NULL,
  `thread_id` int(11) NOT NULL,
  `com_id` int(11) NOT NULL,
  `mem_id` int(11) NOT NULL,
  `content` text CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `type` tinyint(1) NOT NULL,
  `time` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `adi_awards`
--

CREATE TABLE `adi_awards` (
  `id` varchar(50) NOT NULL,
  `memberid` varchar(50) NOT NULL,
  `name` varchar(250) NOT NULL,
  `authority` varchar(250) NOT NULL,
  `licenseno` varchar(100) NOT NULL,
  `frommonth` varchar(20) NOT NULL,
  `fromyear` smallint(6) NOT NULL,
  `tomonth` varchar(20) NOT NULL,
  `toyear` smallint(6) NOT NULL,
  `certexpire` smallint(6) NOT NULL,
  `url` varchar(250) NOT NULL,
  `description` varchar(500) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `adi_case`
--

CREATE TABLE `adi_case` (
  `id` varchar(50) NOT NULL,
  `name` varchar(250) NOT NULL,
  `mobile` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `membershipid` varchar(100) NOT NULL,
  `designation` varchar(100) NOT NULL,
  `file` varchar(100) NOT NULL,
  `created` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `adi_clinics`
--

CREATE TABLE `adi_clinics` (
  `clinicid` varchar(50) NOT NULL,
  `cname` varchar(500) NOT NULL,
  `email` varchar(100) NOT NULL,
  `stdcode` varchar(10) NOT NULL,
  `landline` varchar(100) NOT NULL,
  `mobile` varchar(100) NOT NULL,
  `website` varchar(250) NOT NULL,
  `address` varchar(250) NOT NULL,
  `area` varchar(250) NOT NULL,
  `city` varchar(100) NOT NULL,
  `state` varchar(100) NOT NULL,
  `pincode` varchar(6) NOT NULL,
  `landmark` varchar(500) NOT NULL,
  `latitude` varchar(500) NOT NULL,
  `longitude` varchar(500) NOT NULL,
  `category` varchar(100) NOT NULL,
  `profilepic` varchar(250) NOT NULL,
  `profilepicfull` varchar(250) NOT NULL,
  `created_time` datetime NOT NULL,
  `urlname` varchar(500) NOT NULL,
  `datapercent` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `adi_colleges`
--

CREATE TABLE `adi_colleges` (
  `collegeid` varchar(100) NOT NULL,
  `userid` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `collegename` varchar(500) NOT NULL,
  `address` varchar(500) NOT NULL,
  `city` varchar(100) NOT NULL,
  `state` varchar(100) NOT NULL,
  `pincode` varchar(6) NOT NULL,
  `contactnumber` varchar(100) NOT NULL,
  `email` varchar(50) NOT NULL,
  `pg` varchar(3) NOT NULL,
  `journals` text NOT NULL,
  `events` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `adi_college_staffs`
--

CREATE TABLE `adi_college_staffs` (
  `collegeid` varchar(100) NOT NULL,
  `staffid` varchar(100) NOT NULL,
  `name` varchar(250) NOT NULL,
  `designation` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `adi_communities`
--

CREATE TABLE `adi_communities` (
  `commid` varchar(50) NOT NULL,
  `name` varchar(100) NOT NULL,
  `profileimg` varchar(50) NOT NULL,
  `adminid` varchar(50) NOT NULL,
  `adminname` varchar(100) NOT NULL,
  `creationtime` datetime NOT NULL,
  `description` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `adi_comm_members`
--

CREATE TABLE `adi_comm_members` (
  `memberid` varchar(50) NOT NULL,
  `commid` varchar(50) NOT NULL,
  `joinedtime` datetime NOT NULL,
  `unjoinedtime` datetime NOT NULL,
  `status` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `adi_comm_members`
--

INSERT INTO `adi_comm_members` (`memberid`, `commid`, `joinedtime`, `unjoinedtime`, `status`) VALUES
('61b862bbef4c8', '5166674f32377', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1);

-- --------------------------------------------------------

--
-- Table structure for table `adi_conferencebid`
--

CREATE TABLE `adi_conferencebid` (
  `id` varchar(50) NOT NULL,
  `userid` varchar(50) NOT NULL,
  `bidname` varchar(200) NOT NULL,
  `created` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `adi_conferences`
--

CREATE TABLE `adi_conferences` (
  `ide` int(11) NOT NULL,
  `name` varchar(500) NOT NULL,
  `link` varchar(100) NOT NULL,
  `date` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `adi_confregistration`
--

CREATE TABLE `adi_confregistration` (
  `id` varchar(100) NOT NULL,
  `memberid` varchar(50) NOT NULL,
  `regno` varchar(100) NOT NULL,
  `memtype` varchar(20) NOT NULL,
  `name` varchar(100) NOT NULL,
  `dob` varchar(10) NOT NULL,
  `sex` varchar(10) NOT NULL,
  `mobile` varchar(20) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `address` varchar(250) NOT NULL,
  `contactaddress` varchar(250) NOT NULL,
  `contactcity` varchar(50) NOT NULL,
  `contactstate` varchar(50) NOT NULL,
  `contactpin` int(6) NOT NULL,
  `qualification` varchar(50) NOT NULL,
  `college` varchar(200) NOT NULL,
  `designation` varchar(50) NOT NULL,
  `paymentamount` varchar(100) NOT NULL,
  `paymentmode` varchar(50) NOT NULL,
  `paymentid` varchar(50) NOT NULL,
  `paymentstatus` varchar(250) NOT NULL,
  `paymenttime` datetime NOT NULL,
  `status` varchar(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `adi_connections`
--

CREATE TABLE `adi_connections` (
  `memberid` varchar(100) NOT NULL,
  `connections` text NOT NULL,
  `requestin` text NOT NULL,
  `requestout` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `adi_connections`
--

INSERT INTO `adi_connections` (`memberid`, `connections`, `requestin`, `requestout`) VALUES
('61b862bbef4c8', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `adi_education`
--

CREATE TABLE `adi_education` (
  `id` varchar(50) NOT NULL,
  `memberid` varchar(50) NOT NULL,
  `eduschool` varchar(500) NOT NULL,
  `edudegree` varchar(500) NOT NULL,
  `edustudy` varchar(250) NOT NULL,
  `edugrade` float NOT NULL,
  `eduactivity` varchar(500) NOT NULL,
  `edufromyear` smallint(6) NOT NULL,
  `edutoyear` smallint(6) NOT NULL,
  `edudescription` varchar(500) NOT NULL,
  `edufile` varchar(250) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `adi_education`
--

INSERT INTO `adi_education` (`id`, `memberid`, `eduschool`, `edudegree`, `edustudy`, `edugrade`, `eduactivity`, `edufromyear`, `edutoyear`, `edudescription`, `edufile`) VALUES
('61b85968cb2d9', '559f866a94a04', 'test', 'Test', '', 0, '', 0, 0, '', '61b85968cb2d9.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `adi_eventregister`
--

CREATE TABLE `adi_eventregister` (
  `id` varchar(50) NOT NULL,
  `eid` varchar(50) NOT NULL,
  `userid` varchar(50) NOT NULL,
  `memberid` varchar(50) NOT NULL,
  `role` varchar(10) NOT NULL,
  `uname` varchar(250) NOT NULL,
  `uemail` varchar(250) NOT NULL,
  `umobile` varchar(20) NOT NULL,
  `created` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `adi_events`
--

CREATE TABLE `adi_events` (
  `eid` varchar(50) NOT NULL,
  `ename` varchar(500) NOT NULL,
  `eplace` varchar(250) NOT NULL,
  `edate` date NOT NULL,
  `ecreated` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `adi_experience`
--

CREATE TABLE `adi_experience` (
  `id` varchar(50) NOT NULL,
  `memberid` varchar(50) NOT NULL,
  `title` varchar(250) NOT NULL,
  `company` varchar(250) NOT NULL,
  `location` varchar(250) NOT NULL,
  `frommonth` varchar(50) NOT NULL,
  `fromyear` smallint(6) NOT NULL,
  `tomonth` varchar(50) NOT NULL,
  `toyear` smallint(6) NOT NULL,
  `workhere` smallint(6) NOT NULL,
  `description` varchar(500) NOT NULL,
  `media` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `adi_forgetpass`
--

CREATE TABLE `adi_forgetpass` (
  `fuserid` varchar(25) NOT NULL,
  `femailid` varchar(50) NOT NULL,
  `flogintype` varchar(25) NOT NULL,
  `fstatus` varchar(25) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `adi_messages`
--

CREATE TABLE `adi_messages` (
  `messageid` varchar(100) NOT NULL,
  `from` varchar(250) NOT NULL,
  `fromname` varchar(250) NOT NULL,
  `to` text NOT NULL,
  `toname` text NOT NULL,
  `subject` varchar(250) NOT NULL,
  `message` longtext NOT NULL,
  `date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `adi_mess_conversations`
--

CREATE TABLE `adi_mess_conversations` (
  `conversationid` varchar(100) NOT NULL,
  `messages` text NOT NULL,
  `subject` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `adi_mess_log`
--

CREATE TABLE `adi_mess_log` (
  `memberid` varchar(100) NOT NULL,
  `conversationid` varchar(100) NOT NULL,
  `date` datetime NOT NULL,
  `category` varchar(5) NOT NULL,
  `status` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `adi_newcase`
--

CREATE TABLE `adi_newcase` (
  `id` varchar(50) NOT NULL,
  `memberid` varchar(50) NOT NULL,
  `title` varchar(500) NOT NULL,
  `toothnum` tinyint(4) NOT NULL,
  `author1` varchar(250) NOT NULL,
  `author2` varchar(250) NOT NULL,
  `affiliation` varchar(250) NOT NULL,
  `abstract` text NOT NULL,
  `image1` varchar(50) NOT NULL,
  `image2` varchar(50) NOT NULL,
  `image3` varchar(50) NOT NULL,
  `image4` varchar(50) NOT NULL,
  `image5` varchar(50) NOT NULL,
  `pubstatus` varchar(10) NOT NULL,
  `pubdetails` varchar(500) NOT NULL,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  `status` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `adi_notifications`
--

CREATE TABLE `adi_notifications` (
  `notifyid` varchar(100) NOT NULL,
  `link` varchar(500) NOT NULL,
  `news` varchar(250) NOT NULL,
  `date` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `adi_posts`
--

CREATE TABLE `adi_posts` (
  `postid` varchar(50) NOT NULL,
  `commid` varchar(50) NOT NULL,
  `memberid` varchar(50) NOT NULL,
  `time` datetime NOT NULL,
  `type` varchar(10) NOT NULL,
  `content` varchar(200) NOT NULL,
  `image` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `adi_profiledata`
--

CREATE TABLE `adi_profiledata` (
  `id` varchar(50) NOT NULL,
  `memberid` varchar(50) NOT NULL,
  `clinicid` varchar(50) NOT NULL,
  `dname` varchar(250) NOT NULL,
  `cname` varchar(250) NOT NULL,
  `area` varchar(250) NOT NULL,
  `city` varchar(100) NOT NULL,
  `state` varchar(200) NOT NULL,
  `pincode` varchar(10) NOT NULL,
  `timing` text NOT NULL,
  `fees` varchar(10) NOT NULL,
  `datapercent` tinyint(4) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `adi_profiles`
--

CREATE TABLE `adi_profiles` (
  `memberid` varchar(50) NOT NULL,
  `mobile` varchar(20) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `sameaddress` varchar(10) NOT NULL,
  `address` varchar(250) NOT NULL,
  `address2` varchar(250) NOT NULL,
  `city` varchar(100) NOT NULL,
  `state` varchar(100) NOT NULL,
  `pincode` varchar(10) NOT NULL,
  `clinicaddress` varchar(250) NOT NULL,
  `clinicaddress2` varchar(250) NOT NULL,
  `cliniccity` varchar(100) NOT NULL,
  `clinicstate` varchar(100) NOT NULL,
  `clinicpin` varchar(10) NOT NULL,
  `clinicphone` varchar(20) NOT NULL,
  `contactaddress` varchar(250) NOT NULL,
  `contactaddress2` varchar(250) NOT NULL,
  `contactcity` varchar(100) NOT NULL,
  `contactstate` varchar(50) NOT NULL,
  `contactpin` int(6) NOT NULL,
  `designation` varchar(50) NOT NULL,
  `qualification` varchar(50) NOT NULL,
  `college` varchar(200) NOT NULL,
  `dob` varchar(10) NOT NULL,
  `gender` varchar(6) NOT NULL,
  `about` text NOT NULL,
  `interests` text NOT NULL,
  `mtype` varchar(100) NOT NULL,
  `mstudent` text NOT NULL,
  `mfaculty` text NOT NULL,
  `mname` varchar(250) NOT NULL,
  `maddress1` text NOT NULL,
  `maddress2` text NOT NULL,
  `mcity` varchar(250) NOT NULL,
  `mstate` varchar(250) NOT NULL,
  `mpincode` varchar(200) NOT NULL,
  `mdesignation` text NOT NULL,
  `mlandline` text NOT NULL,
  `mmobile` text NOT NULL,
  `mgeo` text NOT NULL,
  `mclinictiming` text NOT NULL,
  `checkcard` varchar(10) NOT NULL,
  `checkcertificate` varchar(10) NOT NULL,
  `clinicid` text NOT NULL,
  `area` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `adi_profiles`
--

INSERT INTO `adi_profiles` (`memberid`, `mobile`, `phone`, `email`, `sameaddress`, `address`, `address2`, `city`, `state`, `pincode`, `clinicaddress`, `clinicaddress2`, `cliniccity`, `clinicstate`, `clinicpin`, `clinicphone`, `contactaddress`, `contactaddress2`, `contactcity`, `contactstate`, `contactpin`, `designation`, `qualification`, `college`, `dob`, `gender`, `about`, `interests`, `mtype`, `mstudent`, `mfaculty`, `mname`, `maddress1`, `maddress2`, `mcity`, `mstate`, `mpincode`, `mdesignation`, `mlandline`, `mmobile`, `mgeo`, `mclinictiming`, `checkcard`, `checkcertificate`, `clinicid`, `area`) VALUES
('559f866a94a04', '6369021751', '', 'paul@harvee.co.uk', 'Yes', 'test', 'test', 'test', 'test', '641113', '', '', '', '', '', '', 'test', 'test', 'test', 'test', 641113, '', '', '', '', '', '', '', 'Student', 'test,test,,test,Tamil Nadu,641113', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
('61b862bbef4c8', '5555555555', '', 'paul@harvee.co.uk', 'Yes', 'test', 'test', 'test', 'test', '641113', '', '', '', '', '', '', 'test', 'test', 'test', 'test', 641113, '', '', '', '08-08-1990', 'Male', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `adi_push`
--

CREATE TABLE `adi_push` (
  `id` varchar(100) NOT NULL,
  `deviceid` varchar(100) NOT NULL,
  `newscount` varchar(100) NOT NULL,
  `date` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `adi_questions`
--

CREATE TABLE `adi_questions` (
  `questid` varchar(100) NOT NULL,
  `subjectid` varchar(100) NOT NULL,
  `question` text NOT NULL,
  `option1` text NOT NULL,
  `option2` text NOT NULL,
  `option3` text NOT NULL,
  `option4` text NOT NULL,
  `answer` varchar(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `adi_registration`
--

CREATE TABLE `adi_registration` (
  `id` varchar(50) NOT NULL,
  `memtype` varchar(20) NOT NULL,
  `name` varchar(100) NOT NULL,
  `dob` varchar(10) NOT NULL,
  `sex` varchar(6) NOT NULL,
  `mobile` varchar(20) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `sameaddress` varchar(10) NOT NULL,
  `address` varchar(250) NOT NULL,
  `address2` varchar(250) NOT NULL,
  `city` varchar(100) NOT NULL,
  `state` varchar(100) NOT NULL,
  `pincode` varchar(10) NOT NULL,
  `contactaddress` varchar(250) NOT NULL,
  `contactaddress2` varchar(250) NOT NULL,
  `contactcity` varchar(100) NOT NULL,
  `contactstate` varchar(50) NOT NULL,
  `contactpin` int(6) NOT NULL,
  `qualification` varchar(50) NOT NULL,
  `college` varchar(200) NOT NULL,
  `designation` varchar(50) NOT NULL,
  `clinicaddress` varchar(250) NOT NULL,
  `clinicaddress2` varchar(250) NOT NULL,
  `cliniccity` varchar(100) NOT NULL,
  `clinicstate` varchar(100) NOT NULL,
  `clinicpin` varchar(10) NOT NULL,
  `clinicphone` varchar(20) NOT NULL,
  `proposedname` varchar(100) NOT NULL,
  `proposedmembership` varchar(25) NOT NULL,
  `secondedname` varchar(100) NOT NULL,
  `secondedmembership` varchar(25) NOT NULL,
  `paymentamount` varchar(100) NOT NULL,
  `paymentmode` varchar(50) NOT NULL,
  `paymentid` varchar(50) NOT NULL,
  `status` varchar(20) NOT NULL,
  `created` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `adi_registration`
--

INSERT INTO `adi_registration` (`id`, `memtype`, `name`, `dob`, `sex`, `mobile`, `phone`, `email`, `sameaddress`, `address`, `address2`, `city`, `state`, `pincode`, `contactaddress`, `contactaddress2`, `contactcity`, `contactstate`, `contactpin`, `qualification`, `college`, `designation`, `clinicaddress`, `clinicaddress2`, `cliniccity`, `clinicstate`, `clinicpin`, `clinicphone`, `proposedname`, `proposedmembership`, `secondedname`, `secondedmembership`, `paymentamount`, `paymentmode`, `paymentid`, `status`, `created`) VALUES
('61b862bbf31b8', 'ASSOCIATES', 'paul', '08-08-1990', 'Male', '5555555555', '', 'paul@harvee.co.uk', 'Yes', 'test', 'test', 'test', 'test', '641113', 'test', 'test', 'test', 'test', 641113, '', '', '', '', '', '', '', '', '', '', '', '', '', '6500', 'DD', '', 'approved', '2021-12-14 09:24:12'),
('61bdcdac4ab68', 'STUDENT', 'test member', '27-02-1951', 'Male', '6369021751', '', 'paul@harvee.co.uk', 'Yes', 'test address', 'test address', 'test city', 'Andhra Pradesh', '641113', 'test address', 'test address', 'test city', 'Andhra Pradesh', 641113, 'test', 'test', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'open', '2021-12-18 12:01:48');

-- --------------------------------------------------------

--
-- Table structure for table `adi_regteachermeet`
--

CREATE TABLE `adi_regteachermeet` (
  `id` varchar(50) NOT NULL,
  `userid` varchar(10) NOT NULL,
  `memberid` varchar(50) NOT NULL,
  `name` varchar(100) NOT NULL,
  `mobile` varchar(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `college` varchar(200) NOT NULL,
  `designation` varchar(50) NOT NULL,
  `paymentamount` varchar(100) NOT NULL,
  `paymentmode` varchar(50) NOT NULL,
  `paymentid` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `adi_sessions`
--

CREATE TABLE `adi_sessions` (
  `sessionid` varchar(50) NOT NULL,
  `ip` varchar(50) NOT NULL,
  `userid` varchar(50) NOT NULL,
  `agent` varchar(50) NOT NULL,
  `start_time` datetime NOT NULL,
  `end_time` datetime NOT NULL,
  `status` varchar(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `adi_sessions`
--

INSERT INTO `adi_sessions` (`sessionid`, `ip`, `userid`, `agent`, `start_time`, `end_time`, `status`) VALUES
('0130803ba04616c85641e67c46a4bf82', '::1', '0000', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebK', '2021-12-14 10:33:58', '2021-12-14 10:35:53', 'c'),
('83537677dab600465d8d494ae279f25b', '::1', '0000', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebK', '2021-12-14 10:36:14', '0000-00-00 00:00:00', 'o'),
('60d51a85193ead36eeb2cda8b082dfd1', '::1', '0000', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebK', '2021-12-14 12:31:05', '0000-00-00 00:00:00', 'o'),
('e9a24becfeb62d03f14b90f87dfae6d5', '::1', '0000', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebK', '2021-12-14 12:36:12', '0000-00-00 00:00:00', 'o'),
('c7abc19ae92136242e86b02c4fe03ff7', '::1', '0000', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebK', '2021-12-14 14:25:01', '2021-12-14 14:25:12', 'c'),
('28afef2a6db4e272660d778dc85fea27', '::1', '0000', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebK', '2021-12-14 14:25:31', '2021-12-14 14:26:48', 'c'),
('eb75e8312dcea01831f589734aa74a8f', '::1', 'admin', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebK', '2021-12-14 14:28:12', '2021-12-14 14:28:41', 'c'),
('a377031cf474345a2b937ef59cf3fac0', '::1', 'admin', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebK', '2021-12-14 14:28:49', '0000-00-00 00:00:00', 'o'),
('86a5278daff5c7f6c7d50edc6d4dfc98', '::1', '0000', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebK', '2021-12-14 16:05:24', '0000-00-00 00:00:00', 'o'),
('f3724009320a8b501eb7c71a3c99332a', '::1', '0000', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebK', '2021-12-14 17:21:35', '0000-00-00 00:00:00', 'o'),
('2242199031c67fde2eb02b3fa5c339b0', '::1', 'admin', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebK', '2021-12-14 18:35:25', '0000-00-00 00:00:00', 'o'),
('5ce2a1cb5b49b4ce9ac840b754e18b0c', '::1', 'admin', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebK', '2021-12-15 09:28:10', '2021-12-15 09:31:44', 'c'),
('23a3cfc71650a0927692a0a460c9b11a', '::1', '0000', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebK', '2021-12-15 09:31:51', '2021-12-15 09:32:52', 'c'),
('9b75fc7b9b3b887e19af2ded07aa75b7', '::1', 'admin', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebK', '2021-12-15 09:39:40', '0000-00-00 00:00:00', 'o'),
('f2d0bad9dc1d26df5dfc0961a658f769', '127.0.0.1', '0000', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebK', '2022-01-17 11:32:42', '0000-00-00 00:00:00', 'o'),
('b0d38d3a22b00f9cb0ecc013ffe9933c', '::1', '0000', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebK', '2022-07-01 17:48:26', '0000-00-00 00:00:00', 'o'),
('8b826c53257d4797cd09b2ff57c19681', '::1', '0000', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebK', '2022-07-01 17:55:38', '2022-07-01 17:57:20', 'c'),
('0bd64ce25d0149104c619b6051fc9295', '::1', '0000', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebK', '2022-07-01 18:20:00', '2022-07-01 18:23:42', 'c');

-- --------------------------------------------------------

--
-- Table structure for table `adi_subjects`
--

CREATE TABLE `adi_subjects` (
  `subjectid` varchar(100) NOT NULL,
  `title` varchar(500) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `adi_subjects`
--

INSERT INTO `adi_subjects` (`subjectid`, `title`) VALUES
('61b863fd0f0be', 'test');

-- --------------------------------------------------------

--
-- Table structure for table `adi_tokens`
--

CREATE TABLE `adi_tokens` (
  `id` varchar(100) NOT NULL,
  `token` varchar(1000) NOT NULL,
  `date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `adi_users`
--

CREATE TABLE `adi_users` (
  `userid` varchar(25) NOT NULL,
  `password` varchar(50) NOT NULL,
  `memberid` varchar(50) NOT NULL,
  `name` varchar(100) NOT NULL,
  `role` varchar(10) NOT NULL,
  `search` int(11) NOT NULL,
  `profileimg` varchar(50) NOT NULL,
  `dateofjoin` varchar(10) NOT NULL,
  `verifycode` varchar(10) NOT NULL,
  `verifystatus` varchar(10) NOT NULL,
  `biostatus` varchar(10) NOT NULL,
  `regid` varchar(50) NOT NULL,
  `institute` varchar(250) NOT NULL,
  `subjectinterest` varchar(50) NOT NULL,
  `topicinterest` varchar(50) NOT NULL,
  `topictitle` varchar(500) NOT NULL,
  `associatecompany` varchar(500) NOT NULL,
  `curriculumvitae` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `adi_users`
--

INSERT INTO `adi_users` (`userid`, `password`, `memberid`, `name`, `role`, `search`, `profileimg`, `dateofjoin`, `verifycode`, `verifystatus`, `biostatus`, `regid`, `institute`, `subjectinterest`, `topicinterest`, `topictitle`, `associatecompany`, `curriculumvitae`) VALUES
('0000', '39dfa55283318d31afe5a3ff4a0e3253e2045e43', '559f866a94a04', 'Test Member', 'LIFE', 0, '0000.jpg', '2018-02-20', '304458', 'VERIFIED', 'Registered', '', '', '', '', '', '', ''),
('12345', '39dfa55283318d31afe5a3ff4a0e3253e2045e43', '61b862bbef4c8', 'paul', 'ASSOCIATES', 1, 'dp.jpg', '2021-12-14', '', '', '', '', '', '', '', '', '', ''),
('admin', '39dfa55283318d31afe5a3ff4a0e3253e2045e43', '', 'ADI Admin', 'admin', 0, '0000.jpg', '2018-02-20', '304458', 'VERIFIED', 'Registered', '', '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `adi_videos`
--

CREATE TABLE `adi_videos` (
  `id` varchar(50) NOT NULL,
  `title` varchar(500) NOT NULL,
  `description` text NOT NULL,
  `videoid` varchar(20) NOT NULL,
  `created` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `communities`
--

CREATE TABLE `communities` (
  `com_id` int(11) NOT NULL,
  `com_name` char(50) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `com_members` int(11) NOT NULL,
  `dp` char(100) NOT NULL,
  `creator` int(11) NOT NULL,
  `creator_name` char(100) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `description` char(250) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `doc` date NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `fingerprint`
--

CREATE TABLE `fingerprint` (
  `id` varchar(20) NOT NULL,
  `min1` text NOT NULL,
  `min2` text NOT NULL,
  `min3` text NOT NULL,
  `userid` varchar(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `login_manager`
--

CREATE TABLE `login_manager` (
  `token_id` char(32) NOT NULL,
  `mem_id` int(11) NOT NULL,
  `log_ip` char(16) NOT NULL,
  `log_t` bigint(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `memberdlreport`
--

CREATE TABLE `memberdlreport` (
  `ide` int(11) NOT NULL,
  `name` varchar(500) NOT NULL,
  `mid` varchar(100) NOT NULL,
  `dest` varchar(100) NOT NULL,
  `stime` varchar(100) NOT NULL,
  `dtime` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL,
  `reason` varchar(100) NOT NULL,
  `message` varchar(500) NOT NULL,
  `clinicid` varchar(100) NOT NULL,
  `created_time` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `temp`
--

CREATE TABLE `temp` (
  `id` int(11) NOT NULL,
  `name` char(255) NOT NULL,
  `desig` char(100) NOT NULL,
  `add` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `user_comments`
--

CREATE TABLE `user_comments` (
  `comment_id` int(11) NOT NULL,
  `mem_id` int(11) NOT NULL,
  `comments` char(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `time` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `user_list`
--

CREATE TABLE `user_list` (
  `mem_id` int(11) NOT NULL,
  `mem_pass` char(20) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT 'colgate',
  `DP` char(100) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT 'dp.png',
  `comm_id` text CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `comm_no` int(3) NOT NULL DEFAULT 0,
  `mem_name` char(100) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `search` binary(1) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `user_profiles`
--

CREATE TABLE `user_profiles` (
  `mem_id` int(11) NOT NULL,
  `dob` date NOT NULL,
  `sex` binary(1) NOT NULL DEFAULT '0',
  `nationality` char(20) COLLATE utf8_bin NOT NULL,
  `qualification` char(20) COLLATE utf8_bin NOT NULL,
  `designation` char(50) COLLATE utf8_bin NOT NULL,
  `residential` char(250) COLLATE utf8_bin NOT NULL,
  `clinic` char(250) COLLATE utf8_bin NOT NULL,
  `college` char(250) COLLATE utf8_bin NOT NULL,
  `communication` char(250) COLLATE utf8_bin NOT NULL,
  `clinicno` char(15) COLLATE utf8_bin NOT NULL,
  `tel` char(15) COLLATE utf8_bin NOT NULL,
  `mobile` char(15) COLLATE utf8_bin NOT NULL,
  `email` char(50) COLLATE utf8_bin NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `activity`
--
ALTER TABLE `activity`
  ADD PRIMARY KEY (`act_id`);

--
-- Indexes for table `adi_case`
--
ALTER TABLE `adi_case`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `adi_clinics`
--
ALTER TABLE `adi_clinics`
  ADD PRIMARY KEY (`clinicid`);

--
-- Indexes for table `adi_communities`
--
ALTER TABLE `adi_communities`
  ADD PRIMARY KEY (`commid`);

--
-- Indexes for table `adi_conferencebid`
--
ALTER TABLE `adi_conferencebid`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `adi_conferences`
--
ALTER TABLE `adi_conferences`
  ADD PRIMARY KEY (`ide`);

--
-- Indexes for table `adi_confregistration`
--
ALTER TABLE `adi_confregistration`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `adi_eventregister`
--
ALTER TABLE `adi_eventregister`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `adi_events`
--
ALTER TABLE `adi_events`
  ADD PRIMARY KEY (`eid`);

--
-- Indexes for table `adi_newcase`
--
ALTER TABLE `adi_newcase`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `adi_notifications`
--
ALTER TABLE `adi_notifications`
  ADD PRIMARY KEY (`notifyid`);

--
-- Indexes for table `adi_posts`
--
ALTER TABLE `adi_posts`
  ADD PRIMARY KEY (`postid`);

--
-- Indexes for table `adi_profiledata`
--
ALTER TABLE `adi_profiledata`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `adi_profiles`
--
ALTER TABLE `adi_profiles`
  ADD PRIMARY KEY (`memberid`);

--
-- Indexes for table `adi_push`
--
ALTER TABLE `adi_push`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `adi_registration`
--
ALTER TABLE `adi_registration`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `mobile` (`mobile`),
  ADD KEY `email` (`email`);

--
-- Indexes for table `adi_regteachermeet`
--
ALTER TABLE `adi_regteachermeet`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `adi_tokens`
--
ALTER TABLE `adi_tokens`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `adi_users`
--
ALTER TABLE `adi_users`
  ADD PRIMARY KEY (`userid`),
  ADD KEY `regid` (`regid`),
  ADD KEY `role` (`role`),
  ADD KEY `userid` (`userid`);

--
-- Indexes for table `adi_videos`
--
ALTER TABLE `adi_videos`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `communities`
--
ALTER TABLE `communities`
  ADD PRIMARY KEY (`com_id`);

--
-- Indexes for table `fingerprint`
--
ALTER TABLE `fingerprint`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `login_manager`
--
ALTER TABLE `login_manager`
  ADD PRIMARY KEY (`token_id`);

--
-- Indexes for table `memberdlreport`
--
ALTER TABLE `memberdlreport`
  ADD PRIMARY KEY (`ide`),
  ADD KEY `patientid` (`name`);

--
-- Indexes for table `temp`
--
ALTER TABLE `temp`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_comments`
--
ALTER TABLE `user_comments`
  ADD PRIMARY KEY (`comment_id`);

--
-- Indexes for table `user_list`
--
ALTER TABLE `user_list`
  ADD PRIMARY KEY (`mem_id`);

--
-- Indexes for table `user_profiles`
--
ALTER TABLE `user_profiles`
  ADD PRIMARY KEY (`mem_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `activity`
--
ALTER TABLE `activity`
  MODIFY `act_id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `memberdlreport`
--
ALTER TABLE `memberdlreport`
  MODIFY `ide` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `user_comments`
--
ALTER TABLE `user_comments`
  MODIFY `comment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `user_list`
--
ALTER TABLE `user_list`
  MODIFY `mem_id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
